# -*- coding: utf-8 -*-
"""Keep PKM ListItem metadata on Kodi's attached InfoTagVideo object."""
from __future__ import absolute_import, unicode_literals

import math

import xbmc


_WARNED_FIELDS = set()
_UNSET = object()
_MEDIA_TYPES = {
    "video",
    "movie",
    "tvshow",
    "season",
    "episode",
    "musicvideo",
    "set",
}


def _warn_once(field, exc):
    """Log at most once per failed field; never flood large library builds."""
    key = str(field or "unknown")
    if key in _WARNED_FIELDS:
        return
    _WARNED_FIELDS.add(key)
    try:
        xbmc.log(
            "[plugin.video.km] INFOTAGVIDEO_FIELD_SKIP_V1843 "
            "field=%s error=%s" % (key, exc),
            xbmc.LOGWARNING,
        )
    except Exception:
        pass


def _call(tag, method_name, *args):
    try:
        method = getattr(tag, method_name, None)
        if method is None:
            raise AttributeError(method_name)
        method(*args)
        return True
    except Exception as exc:
        _warn_once(method_name, exc)
        return False


def _text(value):
    try:
        return str(value or "")
    except Exception:
        return ""


def _integer(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _string_list(value, separators=()):
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        raw_values = list(value)
    else:
        raw_values = [value]

    result = []
    for raw_value in raw_values:
        parts = [_text(raw_value)]
        for separator in separators:
            split_parts = []
            for part in parts:
                split_parts.extend(part.split(separator))
            parts = split_parts
        for part in parts:
            clean = _text(part).strip()
            if clean and clean not in result:
                result.append(clean)
    return result


def _media_type(value):
    media_type = _text(value).strip().lower()
    if media_type == "show":
        media_type = "tvshow"
    return media_type if media_type in _MEDIA_TYPES else "video"


def _actor_list(cast_items):
    actors = []
    for order, cast_item in enumerate(cast_items or []):
        if isinstance(cast_item, dict):
            name = _text(cast_item.get("name") or cast_item.get("Name")).strip()
            role = _text(cast_item.get("role") or cast_item.get("Role")).strip()
            thumbnail = _text(
                cast_item.get("thumbnail")
                or cast_item.get("thumb")
                or cast_item.get("Thumb")
            ).strip()
        elif isinstance(cast_item, (list, tuple)):
            name = _text(cast_item[0] if len(cast_item) > 0 else "").strip()
            role = _text(cast_item[1] if len(cast_item) > 1 else "").strip()
            thumbnail = _text(cast_item[2] if len(cast_item) > 2 else "").strip()
        else:
            name = _text(cast_item).strip()
            role = ""
            thumbnail = ""
        if not name:
            continue
        try:
            actors.append(xbmc.Actor(name, role, int(order), thumbnail))
        except Exception as exc:
            _warn_once("Actor", exc)
    return actors


def apply_video_info(listitem, info, cast=_UNSET):
    """Apply a legacy-style video info dict through Kodi's InfoTagVideo API.

    Each field is isolated so one malformed optional value cannot prevent the
    title, year, duration, media type, or episode identity from being applied.
    No deprecated setInfo fallback is used on the Kodi 21 PKM target.
    """
    if listitem is None:
        return False
    try:
        tag = listitem.getVideoInfoTag()
    except Exception as exc:
        _warn_once("getVideoInfoTag", exc)
        return False
    if tag is None:
        _warn_once("getVideoInfoTag", "returned_none")
        return False

    values = info if isinstance(info, dict) else {}

    text_fields = (
        ("title", "setTitle"),
        ("sorttitle", "setSortTitle"),
        ("originaltitle", "setOriginalTitle"),
        ("plot", "setPlot"),
        ("dateadded", "setDateAdded"),
        ("tvshowtitle", "setTvShowTitle"),
        ("mpaa", "setMpaa"),
        ("premiered", "setPremiered"),
    )
    for key, method_name in text_fields:
        if key in values:
            _call(tag, method_name, _text(values.get(key)))

    integer_fields = (
        ("year", "setYear"),
        ("duration", "setDuration"),
        ("season", "setSeason"),
        ("episode", "setEpisode"),
    )
    for key, method_name in integer_fields:
        if key in values:
            _call(tag, method_name, _integer(values.get(key)))

    if "mediatype" in values:
        _call(tag, "setMediaType", _media_type(values.get("mediatype")))
    if "genre" in values:
        _call(tag, "setGenres", _string_list(values.get("genre"), (",", " / ")))
    if "director" in values:
        _call(tag, "setDirectors", _string_list(values.get("director"), (" / ",)))
    if "writer" in values:
        _call(tag, "setWriters", _string_list(values.get("writer"), (" / ",)))

    if "rating" in values:
        try:
            rating = float(values.get("rating") or 0.0)
            if math.isfinite(rating) and rating > 0.0:
                _call(tag, "setRating", rating, 0, "", True)
        except Exception as exc:
            _warn_once("setRating", exc)

    cast_value = cast
    if cast_value is _UNSET and "castandrole" in values:
        cast_value = values.get("castandrole")
    elif cast_value is _UNSET and "cast" in values:
        cast_value = values.get("cast")
    if cast_value is not _UNSET:
        _call(tag, "setCast", _actor_list(cast_value))

    return True
