# -*- coding: utf-8 -*-
"""R175: Netflix-style 3-step rating shown while the video is paused.

Pause -> (immediately, 0.3 s debounce) rate dialog window 1113 with the logo
(title text when there is no clear logo) and three pills: dislike / like / love.
A click stores a Plex user rating on the movie or the series, shows a short
confirmation, closes the dialog and resumes playback.  Resume, stop or Back
close it without rating.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui

DIALOG_ID = 1113
DWELL_SEC = 0.3
STEPS = {"dislike": 2, "like": 7, "love": 10}
_STATE_NAME = {2: "dislike", 7: "like", 10: "love"}

_lock = threading.Lock()
_armed = [0]


def _win():
    return xbmcgui.Window(10000)


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] PKM_RATE_R175 %s" % msg, level)
    except Exception:
        pass


def _now_key():
    w = _win()
    return (w.getProperty("PlexKM.NowPlaying.RatingKey") or w.getProperty("PlexKM.MainPlaybackRatingKey") or "").strip()


def _fetch_target(rk):
    """Return (target_key, title, logo_url, user_rating). Episodes rate their series."""
    from resources.lib import pkm_plex_client as pc
    root = pc.plex_request_xml("/library/metadata/%s" % rk, timeout=6, log_failures=False)
    node = None
    for child in root:
        node = child
        break
    if node is None:
        return rk, "", "", 0, False, ""
    target = rk
    title = node.get("title") or ""
    if (node.get("type") or "") == "episode" and node.get("grandparentRatingKey"):
        target = node.get("grandparentRatingKey")
        title = node.get("grandparentTitle") or title
        try:
            root = pc.plex_request_xml("/library/metadata/%s" % target, timeout=6, log_failures=False)
            for child in root:
                node = child
                break
        except Exception:
            pass
    is_tv = (node.get("type") or "") in ("show", "episode", "season")
    year = str(node.get("year") or "")
    logo = ""
    for img in node.iter("Image"):
        if (img.get("type") or "").lower() == "clearlogo" and img.get("url"):
            logo = pc.plex_url(img.get("url"), include_token=True)
            break
    try:
        user = int(float(node.get("userRating") or 0))
    except Exception:
        user = 0
    return target, title, logo, user, is_tv, year


_LOGO_CACHE = {}


def _cache_path():
    import os
    import xbmcvfs
    return os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "rate_logo_cache.json")


def _cache_load():
    if _LOGO_CACHE:
        return
    try:
        import json
        with open(_cache_path(), "r", encoding="utf-8") as fh:
            _LOGO_CACHE.update(json.load(fh) or {})
    except Exception:
        pass


SNOOZE_DAYS = 7
_SNOOZE = {}


def _snooze_path():
    import os
    import xbmcvfs
    return os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "rate_snooze.json")


def _snooze_load():
    if _SNOOZE:
        return
    try:
        import json
        with open(_snooze_path(), "r", encoding="utf-8") as fh:
            _SNOOZE.update(json.load(fh) or {})
    except Exception:
        pass


def _snooze_set(target):
    try:
        import json
        _snooze_load()
        now = time.time()
        _SNOOZE[str(target)] = now
        for k in [k for k, v in _SNOOZE.items() if now - v > SNOOZE_DAYS * 86400]:
            _SNOOZE.pop(k, None)
        with open(_snooze_path(), "w", encoding="utf-8") as fh:
            json.dump(_SNOOZE, fh)
    except Exception:
        pass


def _snoozed(target):
    _snooze_load()
    t = _SNOOZE.get(str(target))
    return bool(t) and (time.time() - t) < SNOOZE_DAYS * 86400


def _cache_save():
    try:
        import json
        with open(_cache_path(), "w", encoding="utf-8") as fh:
            json.dump(_LOGO_CACHE, fh, ensure_ascii=False)
    except Exception:
        pass


def _tmdb_dir(url):
    import json
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": url, "media": "video", "properties": ["title", "year", "art", "uniqueid"]}}
    res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    return (res.get("result") or {}).get("files") or []


def _tmdb_logo(target, title, year, is_tv):
    """Clear logo from TMDb Helper (TMDb images). Plex (sjva agent) carries none."""
    import re
    import sqlite3
    import os
    import xbmcvfs
    from urllib.parse import quote
    ttype = "tv" if is_tv else "movie"
    tid = ""
    try:
        dbp = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "plex_km.db")
        conn = sqlite3.connect(dbp, timeout=2.0)
        try:
            row = conn.execute("SELECT raw_json FROM items WHERE rating_key=? LIMIT 1", (str(target),)).fetchone()
            m = re.search(r"tmdb://(\d+)", str(row[0] if row else ""))
            tid = m.group(1) if m else ""
        finally:
            conn.close()
    except Exception:
        pass
    if not tid and title:
        for q in (title, re.split(r"\s*[:：]\s+", title, maxsplit=1)[0].strip()):
            if not q:
                continue
            for it in _tmdb_dir("plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=%s&query=%s" % (ttype, quote(q))):
                try:
                    ok = (not year) or abs(int(it.get("year") or 0) - int(year)) <= 1
                except Exception:
                    ok = True
                if ok:
                    tid = str((it.get("uniqueid") or {}).get("tmdb") or "")
                    if tid:
                        break
            if tid:
                break
    if not tid:
        return ""
    for it in _tmdb_dir("plugin://plugin.video.themoviedb.helper/?info=details&tmdb_type=%s&tmdb_id=%s" % (ttype, tid)):
        art = it.get("art") or {}
        for key in ("clearlogo", "tvshow.clearlogo"):
            if art.get(key):
                return str(art[key])
    return ""


def _async_logo(target, title, year, is_tv):
    def _run():
        logo = ""
        try:
            logo = _tmdb_logo(target, title, year, is_tv)
        except Exception as exc:
            _log("logo lookup failed target=%s err=%r" % (target, exc), xbmc.LOGWARNING)
        _LOGO_CACHE[target] = logo
        _cache_save()
        _log("logo target=%s found=%d" % (target, 1 if logo else 0))
        try:
            if logo and (_win().getProperty("PlexKM.Rate.Target") == target):
                _win().setProperty("PlexKM.Rate.Logo", logo)
        except Exception:
            pass
    t = threading.Thread(target=_run, name="pkm-rate-logo")
    t.daemon = True
    t.start()


def prefetch():
    """Call at playback start so the pause screen already has the logo."""
    _cache_load()
    rk = _now_key()
    if not rk:
        return

    def _run():
        try:
            target, title, logo, user, is_tv, year = _fetch_target(rk)
            if not logo and target not in _LOGO_CACHE:
                _async_logo(target, title, year, is_tv)
        except Exception as exc:
            _log("prefetch failed rk=%s err=%r" % (rk, exc), xbmc.LOGWARNING)
    t = threading.Thread(target=_run, name="pkm-rate-prefetch")
    t.daemon = True
    t.start()


def _prepare():
    _cache_load()
    rk = _now_key()
    if not rk:
        return False
    w = _win()
    try:
        target, title, logo, user, is_tv, year = _fetch_target(rk)
    except Exception as exc:
        _log("fetch failed rk=%s err=%s" % (rk, exc), xbmc.LOGWARNING)
        target, title, logo, user, is_tv, year = rk, xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or xbmc.getInfoLabel("VideoPlayer.Title"), "", 0, False, ""
    if user > 0:
        _log("skip already rated target=%s" % target)
        return False
    if _snoozed(target):
        _log("skip snoozed target=%s" % target)
        return False
    if not logo:
        logo = _LOGO_CACHE.get(target, "")
        if not logo and target not in _LOGO_CACHE:
            _async_logo(target, title, year, is_tv)
    w.setProperty("PlexKM.Rate.Target", target)
    w.setProperty("PlexKM.Rate.Title", title or "")
    w.setProperty("PlexKM.Rate.Logo", logo or "")
    st = _STATE_NAME.get(user, "")
    w.setProperty("PlexKM.Rate.State", st)
    for name in ("dislike", "like", "love"):
        w.setProperty("PlexKM.Rate.Mark." + name, "\u2713  " if name == st else "")
    w.clearProperty("PlexKM.Rate.Msg")
    return True


def _is_paused():
    return bool(xbmc.getCondVisibility("Player.Paused"))


def schedule_open():
    """Call from onPlayBackPaused (user pauses only)."""
    with _lock:
        _armed[0] += 1
        token = _armed[0]

    def _run():
        end = time.time() + DWELL_SEC
        while time.time() < end:
            xbmc.sleep(60)
            if _armed[0] != token or not _is_paused():
                return
        if _armed[0] != token or not _is_paused():
            return
        if xbmc.getCondVisibility("Window.IsActive(videoosd) | Window.IsActive(fullscreeninfo) | Window.IsActive(1198) | System.HasModalDialog"):
            return
        if _win().getProperty("PlexKM.SeekOsd.Active") == "1":
            return
        if not _prepare():
            return
        _win().clearProperty("PlexKM.Rate.Do")
        xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
        _log("opened rk=%s" % _now_key())
        for _ in range(30):
            if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
                break
            xbmc.sleep(50)
        _watch()

    t = threading.Thread(target=_run, name="pkm-rate-open")
    t.daemon = True
    t.start()


def cancel():
    """Call on resume / stop / seek: disarm and close without rating."""
    with _lock:
        _armed[0] += 1
    try:
        if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            xbmc.executebuiltin("Dialog.Close(%d,true)" % DIALOG_ID)
    except Exception:
        pass


def _apply(do):
    """do = 'set:<step>' or 'clear' (the skin already updated the UI instantly)."""
    w = _win()
    target = w.getProperty("PlexKM.Rate.Target") or _now_key()
    if not target:
        return
    if do.startswith("set:"):
        value = STEPS.get(do[4:])
        if value is None:
            return
    else:
        value = 0
    try:
        from resources.lib import pkm_plex_client as pc
        pc.plex_request("/:/rate", {"key": target, "identifier": "com.plexapp.plugins.library", "rating": value},
                        timeout=6, method="PUT")
        _log("rated target=%s do=%s value=%s" % (target, do, value))
    except Exception as exc:
        _log("rate failed target=%s err=%s" % (target, exc), xbmc.LOGWARNING)
        w.setProperty("PlexKM.Rate.Msg", "평가를 저장하지 못했어요")


def _watch():
    """Runs while the dialog is open: pick up clicks from the skin without a plugin round-trip."""
    w = _win()
    target = w.getProperty("PlexKM.Rate.Target")
    rated = False
    while xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
        do = w.getProperty("PlexKM.Rate.Do")
        if do:
            w.clearProperty("PlexKM.Rate.Do")
            _apply(do)
            if do.startswith("set:"):
                rated = True
        xbmc.sleep(60)
    if not rated and target:
        _snooze_set(target)
