# -*- coding: utf-8 -*-
"""User-confirmed PKM repository update flow (v2169 core, v2375 startup gate).

Flow:
- Start the remote repository check immediately while the PKM startup logo owns the screen.
- Hold Plex authority/Home composition only until the update decision is known.
- If no update exists, release Home immediately.
- If an update exists, show the existing PKM notice/confirmation before library work.
- Apply Skin, required service.pkm.ratings, and plugin.video.km from verified repository ZIPs;
  plugin.video.km is committed last so its hard dependency already exists on disk.
- After a legacy 1.0.15 -> 1.0.16 transition, automatically repair a missing required
  ratings service before library authority work and defer activation until the next Kodi start.
- Show truthful Korean startup-logo text for update checking/install/finalization.
- On explicit package update completion, show the established 3-2-1 exit flow.

Kodi's native automatic update mode remains guarded; the verified direct-package path
prevents active-skin reloads from destroying PKM's custom progress surface.
"""
from __future__ import absolute_import, unicode_literals

import glob
import json
import os
import re
import sqlite3
import threading
import time
import zipfile
import xml.etree.ElementTree as ET
try:
    from urllib.request import Request, urlopen
except Exception:
    from urllib2 import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None

ADDON_ID = "plugin.video.km"
SKIN_ID = "skin.plex.km"
RATINGS_SERVICE_ID = "service.pkm.ratings"
RATINGS_MIN_VERSION_V2375 = "0.1.1"
REMOTE_MANIFEST_URL = "https://raw.githubusercontent.com/kmfly/kodiskin/master/Plexkm.KM/addon_list.xml"
PACKAGE_URL_TEMPLATE_V2321 = "https://github.com/kmfly/kodiskin/raw/refs/heads/master/Plexkm.KM/zip/{addon_id}/{addon_id}-{version}.zip"
PACKAGE_CACHE_DIR_V2321 = "special://temp/pkm_update_v2321"
STATE_FILE = "special://profile/addon_data/plugin.video.km/pkm_update_flow_v2169.json"
CONFIRM_XML = "plexkm_pkm_confirm_no_default_dialog.xml"
CONFIRM_CHOICE_PROP_V2646 = "PlexKM.UpdateConfirmChoiceV2646"
PROGRESS_XML = "plexkm_update_progress_v2169.xml"
RESTART_XML = "plexkm_update_restart_v2169.xml"

NOTICE_SECONDS = 3.0
PROMPT_TIMEOUT_SECONDS = 10.0
REPO_SETTLE_SECONDS = 4.0
REPO_RETRY_SECONDS = 20.0
INSTALL_TIMEOUT_SECONDS = 120.0


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


_log("PKM_PATCH_ACTIVE v2419 ratings_zero_addonmanager_error_disk_version_jsonrpc_enable")


def _component_label_v2375(addon_id):
    if addon_id == SKIN_ID:
        return "Skin"
    if addon_id == RATINGS_SERVICE_ID:
        return "평점 서비스"
    return "PKM"


def _set_startup_update_phase_v2375(phase, text, block=True):
    """Publish the update state to the startup logo and Home gate.

    The startup cover is owned by service.py, so the updater communicates through
    Window(10000) properties.  If the delayed Korean status is already visible,
    update it in place immediately.
    """
    try:
        win = xbmcgui.Window(10000)
        phase = str(phase or "")
        text = str(text or "")
        if phase:
            win.setProperty("PlexKM.Startup.UpdatePhaseV2375", phase)
        else:
            win.clearProperty("PlexKM.Startup.UpdatePhaseV2375")
        if text:
            win.setProperty("PlexKM.Startup.UpdateTextV2375", text)
        else:
            win.clearProperty("PlexKM.Startup.UpdateTextV2375")
        if block:
            win.setProperty("PlexKM.Startup.UpdateBlockV2375", "1")
        else:
            win.clearProperty("PlexKM.Startup.UpdateBlockV2375")
        if text and win.getProperty("PlexKM.Startup.SlowVisibleV2365") == "1":
            win.setProperty("PlexKM.Startup.SlowTextV2365", text)
            win.setProperty("PlexKM.Startup.SlowPhaseV2365", "update_" + (phase or "active"))
        _log("PKM_UPDATE_STARTUP_PHASE_V2375 phase=%s block=%d text=%s" % (phase, 1 if block else 0, text))
    except Exception as exc:
        _log("PKM_UPDATE_STARTUP_PHASE_FAILED_V2375 err=%s" % exc, xbmc.LOGWARNING)


def _clear_startup_update_phase_v2375(reason=""):
    try:
        win = xbmcgui.Window(10000)
        win.clearProperty("PlexKM.Startup.UpdatePhaseV2375")
        win.clearProperty("PlexKM.Startup.UpdateTextV2375")
        win.clearProperty("PlexKM.Startup.UpdateBlockV2375")
        _log("PKM_UPDATE_STARTUP_GATE_CLEAR_V2375 reason=%s" % (reason or ""))
    except Exception:
        pass


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return path


def _ensure_parent(path):
    parent = os.path.dirname(_translate(path))
    if not parent:
        return
    try:
        if not xbmcvfs.exists(parent):
            xbmcvfs.mkdirs(parent)
    except Exception:
        try:
            if not os.path.isdir(parent):
                os.makedirs(parent)
        except Exception:
            pass


def _read_state():
    path = _translate(STATE_FILE)
    try:
        if not xbmcvfs.exists(path):
            return {}
        fh = xbmcvfs.File(path, "r")
        raw = fh.read()
        fh.close()
        data = json.loads(raw or "{}")
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        _log("PKM_UPDATE_STATE_READ_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        return {}


def _write_state(data):
    path = _translate(STATE_FILE)
    tmp = path + ".tmp"
    _ensure_parent(path)
    payload = json.dumps(data or {}, ensure_ascii=False, sort_keys=True, indent=2)
    try:
        fh = xbmcvfs.File(tmp, "w")
        fh.write(payload)
        fh.close()
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass
        if not xbmcvfs.rename(tmp, path):
            fh = xbmcvfs.File(path, "w")
            fh.write(payload)
            fh.close()
            try:
                xbmcvfs.delete(tmp)
            except Exception:
                pass
        return True
    except Exception as exc:
        _log("PKM_UPDATE_STATE_WRITE_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        return False


def _delete_state():
    try:
        path = _translate(STATE_FILE)
        if xbmcvfs.exists(path):
            return bool(xbmcvfs.delete(path))
    except Exception:
        pass
    return False



def _addon_database_path_v2320():
    """Return the active Kodi Addons*.db path (Kodi 21.3 => Addons33.db)."""
    try:
        root = _translate("special://database/")
        candidates = glob.glob(os.path.join(root, "Addons*.db"))
        if not candidates:
            return ""
        def key(path):
            name = os.path.basename(path)
            match = re.search(r"Addons(\d+)\.db$", name, re.I)
            return int(match.group(1)) if match else -1
        candidates.sort(key=key, reverse=True)
        return candidates[0]
    except Exception:
        return ""


def _read_pkm_update_rules_v2320():
    """Read per-addon update rules that make Kodi treat PKM as non-auto-updateable."""
    path = _addon_database_path_v2320()
    if not path:
        raise RuntimeError("Kodi Addons database not found")
    con = sqlite3.connect(path, timeout=3.0)
    try:
        con.execute("PRAGMA busy_timeout=3000")
        rows = con.execute(
            "SELECT addonID, updateRule FROM update_rules WHERE addonID IN (?, ?) ORDER BY addonID, updateRule",
            (ADDON_ID, SKIN_ID),
        ).fetchall()
        return [[str(row[0]), int(row[1])] for row in rows]
    finally:
        con.close()


def _write_pkm_update_rules_v2320(saved_rules, clear_only=False):
    """Atomically clear/restore only PKM's rows in Kodi's update_rules table."""
    path = _addon_database_path_v2320()
    if not path:
        raise RuntimeError("Kodi Addons database not found")
    con = sqlite3.connect(path, timeout=3.0)
    try:
        con.execute("PRAGMA busy_timeout=3000")
        con.execute("BEGIN IMMEDIATE")
        con.execute("DELETE FROM update_rules WHERE addonID IN (?, ?)", (ADDON_ID, SKIN_ID))
        if not clear_only:
            for row in saved_rules or []:
                if not isinstance(row, (list, tuple)) or len(row) != 2:
                    continue
                addon_id = str(row[0] or "")
                if addon_id not in (ADDON_ID, SKIN_ID):
                    continue
                con.execute(
                    "INSERT OR IGNORE INTO update_rules(addonID, updateRule) VALUES(?, ?)",
                    (addon_id, int(row[1])),
                )
        con.commit()
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        raise
    finally:
        con.close()



def _repo_versions_v2320():
    """Diagnostic: versions Kodi's Addons DB currently sees for PKM repo entries."""
    path = _addon_database_path_v2320()
    if not path:
        return []
    con = sqlite3.connect(path, timeout=1.0)
    try:
        con.execute("PRAGMA busy_timeout=1000")
        rows = con.execute(
            "SELECT addons.addonID, addons.version, repo.addonID "
            "FROM addons JOIN addonlinkrepo ON addonlinkrepo.idAddon=addons.id "
            "JOIN repo ON repo.id=addonlinkrepo.idRepo "
            "WHERE addons.addonID IN (?, ?) ORDER BY addons.addonID, addons.version",
            (ADDON_ID, SKIN_ID),
        ).fetchall()
        return [[str(a), str(v), str(r)] for a, v, r in rows]
    except Exception:
        return []
    finally:
        con.close()


def _jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 2169, "method": method}
    if params is not None:
        req["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(req))
        data = json.loads(raw or "{}")
        if isinstance(data, dict) and "error" not in data:
            return data.get("result")
    except Exception as exc:
        _log("PKM_UPDATE_JSONRPC_FAILED_V2169 method=%s err=%s" % (method, exc), xbmc.LOGWARNING)
    return None


def _get_setting_value(setting):
    result = _jsonrpc("Settings.GetSettingValue", {"setting": setting})
    if isinstance(result, dict) and "value" in result:
        return result.get("value")
    return None


def _set_setting_value(setting, value):
    result = _jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})
    return result is True


def _ratings_registration_details_v2419():
    """Return ratings add-on details through JSON-RPC only.

    JSON-RPC failure is returned as data and does not instantiate an invalid
    xbmcaddon.Addon object.  This is safe for a disabled/newly discovered
    service on Kodi 21.
    """
    result = _jsonrpc("Addons.GetAddonDetails", {
        "addonid": RATINGS_SERVICE_ID,
        "properties": ["version", "path"],
    })
    if not isinstance(result, dict):
        return {}
    addon = result.get("addon")
    return addon if isinstance(addon, dict) else {}


def _ensure_ratings_enabled_v2419():
    """At a real Kodi start, safely register/enable an on-disk ratings service.

    A service copied during the previous run can be present in addons/ yet be
    disabled or missing from the live AddonManager map.  Do not use
    xbmcaddon.Addon/System.HasAddon because those calls themselves write ERROR
    lines.  Instead use Kodi's normal JSON-RPC enable path.
    """
    disk = _addon_version_disk(RATINGS_SERVICE_ID)
    if not disk:
        return False

    details = _ratings_registration_details_v2419()
    if not details:
        # This function runs only while PKM service is starting, before any
        # same-session ratings overlay can happen. A local rescan here is safe
        # and gives manually copied installs one chance to enter AddonManager.
        try:
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.sleep(150)
        except Exception:
            pass
        details = _ratings_registration_details_v2419()

    if not details:
        _log("RATINGS_SERVICE_REGISTER_WAIT_V2419 disk=%s action=no_invalid_probe_next_start" % disk, xbmc.LOGWARNING)
        return False

    result = _jsonrpc("Addons.SetAddonEnabled", {
        "addonid": RATINGS_SERVICE_ID,
        "enabled": True,
    })
    if result is True or str(result or "").upper() == "OK":
        _log("RATINGS_SERVICE_ENABLE_OK_V2419 disk=%s method=jsonrpc normal_kodi_service_start=1" % disk)
        return True

    _log("RATINGS_SERVICE_ENABLE_DEFER_V2419 disk=%s method=jsonrpc result=%s" % (disk, result), xbmc.LOGWARNING)
    return False


def _addon_version_runtime(addon_id):
    # v2419: never ask Kodi's AddonManager for service.pkm.ratings through
    # System.HasAddon() or xbmcaddon.Addon().  On Kodi 21 both probes can emit
    # an ERROR line for a present-on-disk but not-yet-enabled service even when
    # Python catches the failure.  Ratings version authority is addon.xml on disk.
    if addon_id == RATINGS_SERVICE_ID:
        return ""
    try:
        return str(xbmcaddon.Addon(addon_id).getAddonInfo("version") or "")
    except Exception:
        return ""


def _addon_version_disk(addon_id):
    """Read the on-disk addon.xml version, bypassing AddonManager runtime cache.

    During plugin.video.km self-update Kodi can replace addon.xml before the
    current Python service instance is recycled. xbmcaddon.Addon(...).version
    can therefore remain stale for the remainder of that service instance.
    The update transaction must use the newest authoritative view so it can
    advance instead of remaining stuck on the Plugin install stage.
    """
    try:
        path = _translate("special://home/addons/%s/addon.xml" % addon_id)
        if not path or not xbmcvfs.exists(path):
            return ""
        fh = xbmcvfs.File(path, "r")
        raw = fh.read()
        fh.close()
        root = ET.fromstring(raw or "")
        return str(root.attrib.get("version") or "")
    except Exception:
        return ""


def _addon_version(addon_id):
    # v2419: ratings is disk-only.  This keeps startup/update discovery at
    # exactly zero invalid-addon probes while still comparing the verified
    # package version correctly.
    if addon_id == RATINGS_SERVICE_ID:
        return _addon_version_disk(addon_id)
    runtime = _addon_version_runtime(addon_id)
    disk = _addon_version_disk(addon_id)
    if runtime and disk and runtime != disk:
        chosen = disk if _version_tuple(disk) >= _version_tuple(runtime) else runtime
        _log("PKM_UPDATE_VERSION_VIEW_V2317 addon=%s runtime=%s disk=%s chosen=%s" % (addon_id, runtime, disk, chosen))
        return chosen
    return disk or runtime or ""


def current_versions():
    return {
        "plugin": _addon_version(ADDON_ID),
        "skin": _addon_version(SKIN_ID),
        "ratings": _addon_version(RATINGS_SERVICE_ID),
    }


def _version_tuple(value):
    return tuple(int(x) for x in re.findall(r"\d+", str(value or ""))) or (0,)


def _is_newer(value, baseline):
    return _version_tuple(value) > _version_tuple(baseline)


def _at_least(value, target):
    return _version_tuple(value) >= _version_tuple(target)


def _target_reached(current, target):
    return _at_least((current or {}).get("plugin"), (target or {}).get("plugin")) and \
        _at_least((current or {}).get("skin"), (target or {}).get("skin")) and \
        _at_least((current or {}).get("ratings"), (target or {}).get("ratings"))


def _parse_manifest_versions(raw):
    root = ET.fromstring(raw)
    versions = {}
    nodes = [root] if root.tag == "addon" else list(root.findall(".//addon"))
    for node in nodes:
        addon_id = str(node.attrib.get("id") or "")
        if addon_id == ADDON_ID:
            versions["plugin"] = str(node.attrib.get("version") or "")
            reqs = node.find("requires")
            if reqs is not None:
                for imp in reqs.findall("import"):
                    if str(imp.attrib.get("addon") or "") == RATINGS_SERVICE_ID:
                        versions["ratings_required"] = str(imp.attrib.get("version") or RATINGS_MIN_VERSION_V2375)
                        break
        elif addon_id == SKIN_ID:
            versions["skin"] = str(node.attrib.get("version") or "")
        elif addon_id == RATINGS_SERVICE_ID:
            versions["ratings"] = str(node.attrib.get("version") or "")
    return versions


def _fetch_remote_versions():
    request = Request(REMOTE_MANIFEST_URL, headers={"User-Agent": "PlexKM/2169 Kodi"})
    response = urlopen(request, timeout=5.0)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    return _parse_manifest_versions(raw)


def _package_url_v2321(addon_id, version):
    return PACKAGE_URL_TEMPLATE_V2321.format(addon_id=str(addon_id or ""), version=str(version or ""))


def _download_package_v2321(addon_id, version, progress_start=15, progress_end=55):
    """Download the exact Git repository ZIP without invoking Kodi AddonManager.

    Updating the active skin through Kodi's repository updater unloads/reloads the
    current skin immediately, destroying the updater WindowXMLDialog mid-transaction.
    v2321 downloads the same published ZIP directly so the active GUI remains intact
    until the explicit Kodi restart boundary.
    """
    cache_root = _translate(PACKAGE_CACHE_DIR_V2321)
    try:
        if not os.path.isdir(cache_root):
            os.makedirs(cache_root)
    except Exception:
        try:
            xbmcvfs.mkdirs(cache_root)
        except Exception:
            pass
    filename = "%s-%s.zip" % (addon_id, version)
    dest = os.path.join(cache_root, filename)
    tmp = dest + ".part"
    url = _package_url_v2321(addon_id, version)
    request = Request(url, headers={"User-Agent": "PlexKM/2321 Kodi"})
    response = urlopen(request, timeout=20.0)
    try:
        try:
            total = int(response.headers.get("Content-Length") or 0)
        except Exception:
            total = 0
        done = 0
        with open(tmp, "wb") as fh:
            while True:
                chunk = response.read(262144)
                if not chunk:
                    break
                fh.write(chunk)
                done += len(chunk)
                if total > 0:
                    ratio = min(1.0, float(done) / float(total))
                    percent = int(progress_start + ((progress_end - progress_start) * ratio))
                    _set_progress("Plex KM 업데이트", "%s 패키지를 다운로드합니다." % _component_label_v2375(addon_id), "%s / %s" % (done, total), percent)
    finally:
        try:
            response.close()
        except Exception:
            pass
    if not os.path.isfile(tmp) or os.path.getsize(tmp) <= 0:
        raise RuntimeError("downloaded package is empty")
    try:
        if os.path.exists(dest):
            os.remove(dest)
    except Exception:
        pass
    os.replace(tmp, dest)
    _log("PKM_UPDATE_PACKAGE_DOWNLOADED_V2321 addon=%s version=%s bytes=%s url=%s" % (addon_id, version, os.path.getsize(dest), url))
    return dest


def _validate_package_v2321(zip_path, addon_id, version):
    addon_xml = "%s/addon.xml" % addon_id
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = [str(x).replace("\\\\", "/") for x in zf.namelist()]
        if addon_xml not in names:
            raise RuntimeError("package addon.xml missing")
        for name in names:
            clean = name.replace("\\\\", "/")
            if clean.startswith("/") or ".." in clean.split("/"):
                raise RuntimeError("unsafe package path: %s" % clean)
            if clean and not clean.startswith(addon_id + "/") and clean != addon_id:
                raise RuntimeError("unexpected package root: %s" % clean)
        root = ET.fromstring(zf.read(addon_xml))
        actual_id = str(root.attrib.get("id") or "")
        actual_version = str(root.attrib.get("version") or "")
        if actual_id != addon_id:
            raise RuntimeError("package id mismatch: %s" % actual_id)
        if _version_tuple(actual_version) != _version_tuple(version):
            raise RuntimeError("package version mismatch: %s != %s" % (actual_version, version))
        bad = zf.testzip()
        if bad:
            raise RuntimeError("package CRC failed: %s" % bad)
    _log("PKM_UPDATE_PACKAGE_VALID_V2321 addon=%s version=%s" % (addon_id, version))
    return True


def _zip_member_matches_disk_v2322(zf, info, dest):
    """Return True when the installed file is byte-identical to the ZIP member."""
    try:
        if not os.path.isfile(dest):
            return False
        expected_size = int(getattr(info, "file_size", 0) or 0)
        if os.path.getsize(dest) != expected_size:
            return False
        with zf.open(info, "r") as src, open(dest, "rb") as cur:
            while True:
                a = src.read(262144)
                b = cur.read(262144)
                if a != b:
                    return False
                if not a:
                    return True
    except Exception:
        return False


def _apply_package_overlay_v2321(zip_path, addon_id, version, progress_start=55, progress_end=95):
    """Overlay only changed verified files, writing addon.xml last as commit marker.

    v2322 intentionally skips byte-identical files. This is required for the active
    PKM skin on Windows because Kodi keeps media/Textures.xbt open while the skin is
    running. Replacing an identical locked XBT is unnecessary and fails with
    WinError 5. Changed files are still written atomically through .pkmnew, and
    addon.xml remains the last commit marker.
    """
    addon_root = _translate("special://home/addons/%s" % addon_id)
    if not addon_root:
        raise RuntimeError("addon destination unavailable")
    if not os.path.isdir(addon_root):
        os.makedirs(addon_root)
    with zipfile.ZipFile(zip_path, "r") as zf:
        members = []
        total = 0
        for info in zf.infolist():
            name = str(info.filename or "").replace("\\\\", "/")
            if not name.startswith(addon_id + "/"):
                continue
            rel = name[len(addon_id) + 1:]
            if not rel or name.endswith("/"):
                continue
            members.append((info, rel))
            if rel != "addon.xml":
                total += max(0, int(getattr(info, "file_size", 0) or 0))
        members.sort(key=lambda pair: 1 if pair[1] == "addon.xml" else 0)
        done = 0
        changed_count = 0
        skipped_count = 0
        for info, rel in members:
            dest = os.path.normpath(os.path.join(addon_root, *rel.split("/")))
            if not (dest == addon_root or dest.startswith(addon_root + os.sep)):
                raise RuntimeError("unsafe destination: %s" % rel)
            parent = os.path.dirname(dest)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            tmp = dest + ".pkmnew"

            # A previous failed v2321 run can leave a completed .pkmnew beside an
            # active locked file. It is not authoritative and must never be reused.
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

            file_size = max(0, int(getattr(info, "file_size", 0) or 0))
            if _zip_member_matches_disk_v2322(zf, info, dest):
                skipped_count += 1
                if rel != "addon.xml":
                    done += file_size
                    if total > 0:
                        ratio = min(1.0, float(done) / float(total))
                        percent = int(progress_start + ((progress_end - progress_start) * ratio))
                        _set_progress("Plex KM 업데이트", "%s 파일을 확인합니다." % _component_label_v2375(addon_id), rel, percent)
                if rel == "media/Textures.xbt":
                    _log("PKM_UPDATE_IDENTICAL_LOCKED_ASSET_SKIP_V2322 addon=%s file=%s bytes=%s" % (addon_id, rel, file_size))
                continue

            with zf.open(info, "r") as src, open(tmp, "wb") as out:
                while True:
                    chunk = src.read(262144)
                    if not chunk:
                        break
                    out.write(chunk)
                    if rel != "addon.xml":
                        done += len(chunk)
                        if total > 0:
                            ratio = min(1.0, float(done) / float(total))
                            percent = int(progress_start + ((progress_end - progress_start) * ratio))
                            _set_progress("Plex KM 업데이트", "%s 파일을 적용합니다." % _component_label_v2375(addon_id), rel, percent)
            os.replace(tmp, dest)
            changed_count += 1
    disk = _addon_version_disk(addon_id)
    if not _at_least(disk, version):
        raise RuntimeError("disk version verify failed: %s < %s" % (disk, version))
    _log("PKM_UPDATE_PACKAGE_APPLIED_V2322 addon=%s target=%s disk=%s changed=%s skipped_identical=%s reload=deferred_to_kodi_restart" % (addon_id, version, disk, changed_count, skipped_count))
    try:
        os.remove(zip_path)
    except Exception:
        pass
    return True


class PKMUpdatePackageError(RuntimeError):
    def __init__(self, component, cause):
        self.component = str(component or "PKM")
        self.cause = cause
        super(PKMUpdatePackageError, self).__init__("%s update failed: %s" % (self.component, cause))


def _install_pending_packages_v2321(current, target):
    """Apply every required PKM component, including the ratings service.

    v2375 deliberately keeps plugin.video.km last.  This means the declared
    dependency is already present on disk before addon.xml is committed.
    """
    pending = []
    if not _at_least((current or {}).get("skin"), (target or {}).get("skin")):
        pending.append((SKIN_ID, (target or {}).get("skin")))
    if not _at_least((current or {}).get("ratings"), (target or {}).get("ratings")):
        pending.append((RATINGS_SERVICE_ID, (target or {}).get("ratings")))
    if not _at_least((current or {}).get("plugin"), (target or {}).get("plugin")):
        pending.append((ADDON_ID, (target or {}).get("plugin")))

    if not pending:
        return True

    span_start = 15.0
    span_end = 96.0
    width = (span_end - span_start) / float(len(pending))
    for index, (addon_id, version) in enumerate(pending):
        stage0 = int(span_start + width * index)
        stage1 = int(span_start + width * (index + 1))
        download_end = int(stage0 + max(1.0, (stage1 - stage0) * 0.46))
        apply_start = download_end
        label = _component_label_v2375(addon_id)
        phase = "install_ratings" if addon_id == RATINGS_SERVICE_ID else "install_addon"
        phase_text = "평점 서비스를 설치하고 있습니다" if addon_id == RATINGS_SERVICE_ID else "PKM 애드온 업데이트 중입니다"
        _set_startup_update_phase_v2375(phase, phase_text, block=True)
        if addon_id == RATINGS_SERVICE_ID:
            _log("RATINGS_SERVICE_INSTALL_BEGIN_V2375 target=%s source=pkm_update" % (version or ""))
        try:
            _set_progress("Plex KM 업데이트", "%s 업데이트를 준비합니다." % label, "Git 패키지를 확인하고 있습니다.", stage0)
            zip_path = _download_package_v2321(addon_id, version, stage0, download_end)
            _validate_package_v2321(zip_path, addon_id, version)
            _set_progress("Plex KM 업데이트", "%s 패키지를 확인했습니다." % label, "파일을 안전하게 적용합니다.", apply_start)
            _apply_package_overlay_v2321(zip_path, addon_id, version, apply_start, stage1)
            if addon_id == RATINGS_SERVICE_ID:
                _log("RATINGS_SERVICE_INSTALL_OK_V2375 target=%s disk=%s" % (version or "", _addon_version_disk(RATINGS_SERVICE_ID)))
        except Exception as exc:
            if addon_id == RATINGS_SERVICE_ID:
                _log("RATINGS_SERVICE_INSTALL_FAILED_V2375 target=%s err=%s" % (version or "", exc), xbmc.LOGERROR)
            raise PKMUpdatePackageError(label, exc)
    return True


def _mark_ratings_restart_pending_v2418(version="", reason="ratings_overlay_applied"):
    """Mark same-session activation as intentionally deferred.

    Fresh addon folders are not guaranteed to be registered by Kodi's
    AddonManager until the next process start. Calling RunAddon or directly
    executing service.py in that window causes the user-visible add-on error
    that v2418 eliminates.
    """
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Ratings.RestartPendingV2418", "1")
        win.setProperty("PlexKM.Ratings.RestartPendingVersionV2418", str(version or ""))
    except Exception:
        pass
    _log("RATINGS_SERVICE_RESTART_PENDING_V2418 version=%s reason=%s action=next_kodi_start_no_same_session_activation" % (
        str(version or "-") , str(reason or "-")
    ))


def _activate_ratings_service_v2375():
    """v2418: never activate a freshly overlaid service in the same Kodi run.

    The on-disk package is already verified by the updater. Kodi owns add-on
    registration and normal service startup on the next process start.
    Deliberately do NOT call UpdateLocalAddons, Addons.SetAddonEnabled,
    RunAddon, or RunScript(service.py) here.
    """
    disk = _addon_version_disk(RATINGS_SERVICE_ID)
    _mark_ratings_restart_pending_v2418(disk, reason="activate_deferred_v2418")
    return False


def _repair_required_ratings_service_v2375(version):
    """Repair a missing required dependency before library authority work.

    This path is intentionally automatic.  During the v2376 migration bridge
    Kodi sees service.pkm.ratings as an optional import so legacy PKM updaters
    can boot the new plugin even when the service is still absent.  PKM itself
    still treats the service as required and repairs it before library work.
    """
    version = str(version or RATINGS_MIN_VERSION_V2375)
    _set_startup_update_phase_v2375("install_ratings", "평점 서비스를 설치하고 있습니다", block=True)
    _log("RATINGS_SERVICE_REPAIR_BEGIN_V2375 target=%s" % version)
    zip_path = _download_package_v2321(RATINGS_SERVICE_ID, version, 20, 55)
    _validate_package_v2321(zip_path, RATINGS_SERVICE_ID, version)
    _apply_package_overlay_v2321(zip_path, RATINGS_SERVICE_ID, version, 55, 92)
    disk = _addon_version_disk(RATINGS_SERVICE_ID)
    if not _at_least(disk, version):
        raise RuntimeError("ratings service disk verify failed: %s < %s" % (disk, version))
    _activate_ratings_service_v2375()
    _log("RATINGS_SERVICE_REPAIR_OK_V2418 target=%s disk=%s activation=deferred_to_next_kodi_start" % (version, disk))
    _clear_startup_update_phase_v2375(reason="ratings_dependency_repaired")
    return True


def _set_confirm_props(title, message, yes_label, no_label):
    try:
        win = xbmcgui.Window(10000)
        for key, value in (
            ("PlexKM.Confirm.Title", title),
            ("PlexKM.Confirm.Message", message),
            ("PlexKM.Confirm.Yes", yes_label),
            ("PlexKM.Confirm.No", no_label),
            ("PlexKM.Confirm.Icon1", ""),
            ("PlexKM.Confirm.Icon2", ""),
            ("PlexKM.Confirm.HasIcons", ""),
            ("PlexKM.Confirm.WindowedVideo", ""),
            ("PlexKM.Confirm.HasCine21Rows", ""),
        ):
            win.setProperty(key, str(value or ""))
    except Exception:
        pass


def _clear_confirm_props():
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Confirm.Title", "PlexKM.Confirm.Message", "PlexKM.Confirm.Yes", "PlexKM.Confirm.No",
            "PlexKM.Confirm.Icon1", "PlexKM.Confirm.Icon2", "PlexKM.Confirm.HasIcons",
            "PlexKM.Confirm.WindowedVideo", "PlexKM.Confirm.HasCine21Rows",
        ):
            win.clearProperty(key)
    except Exception:
        pass


class PKMUpdateConfirmDialogV2169(xbmcgui.WindowXMLDialog):
    YES_ID = 300
    NO_ID = 301
    # Kodi/Windows can deliver remote/keyboard OK to WindowXMLDialog only as
    # onAction(), without following it with onClick() for the focused button.
    # Keep the same select/enter set already used by PKM's proven completion UI.
    SELECT_ACTION_IDS = (7, 68, 79, 100, 135)
    BACK_ACTION_IDS = (9, 10, 92, 216, 247)

    def __init__(self, *args, **kwargs):
        self.choice = None
        self.closed_by_user = False
        super(PKMUpdateConfirmDialogV2169, self).__init__(*args, **kwargs)

    def _focus_id(self):
        try:
            return int(self.getFocusId())
        except Exception:
            return -1

    def onInit(self):
        _log("PKM_UPDATE_CONFIRM_READY_V2316 focus=%s default=later" % self._focus_id())

    def _commit_choice(self, value, source, action_id=None, control_id=None):
        if self.choice is not None:
            return
        focus_id = self._focus_id()
        self.choice = bool(value)
        self.closed_by_user = True
        try:
            xbmcgui.Window(10000).setProperty(CONFIRM_CHOICE_PROP_V2646, "update" if value else "later")
        except Exception:
            pass
        _log(
            "PKM_UPDATE_CONFIRM_CHOICE_V2316 choice=%s source=%s action=%s control=%s focus=%s"
            % (
                "update" if value else "later",
                source or "unknown",
                "" if action_id is None else action_id,
                "" if control_id is None else control_id,
                focus_id,
            )
        )
        try:
            self.close()
        except Exception:
            pass

    def onClick(self, control_id):
        try:
            cid = int(control_id)
        except Exception:
            cid = -1
        if cid == self.YES_ID:
            self._commit_choice(True, "onclick", control_id=cid)
        elif cid == self.NO_ID:
            self._commit_choice(False, "onclick", control_id=cid)

    def onAction(self, action):
        try:
            aid = int(action.getId())
        except Exception:
            aid = -1
        if aid in self.SELECT_ACTION_IDS:
            # v2316 root fix: commit the actually focused visible button when
            # Kodi supplies SELECT/ENTER as onAction() without onClick().
            focus_id = self._focus_id()
            if focus_id == self.YES_ID:
                self._commit_choice(True, "onaction", action_id=aid, control_id=focus_id)
                return
            if focus_id == self.NO_ID:
                self._commit_choice(False, "onaction", action_id=aid, control_id=focus_id)
                return
            _log("PKM_UPDATE_CONFIRM_SELECT_IGNORED_V2316 action=%s focus=%s" % (aid, focus_id), xbmc.LOGWARNING)
            return
        if aid in self.BACK_ACTION_IDS:
            self._commit_choice(False, "back", action_id=aid, control_id=self._focus_id())


class PKMUpdateProgressDialogV2169(xbmcgui.WindowXMLDialog):
    def onInit(self):
        # The visible bar is XML slice-owned (same deterministic strategy as
        # plexkm_sync_progress.xml v2040). Keep this log to prove the custom
        # update surface, not Kodi's native progress UI, owns rendering.
        _log("PKM_UPDATE_PROGRESS_READY_V2317 renderer=xml_percent_slices no_property_progress_info=1")

    def onAction(self, action):
        return

    def onClick(self, control_id):
        return


def _set_progress(title="Plex KM 업데이트", line1="", line2="", percent=0):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.UpdateV2169.Title", str(title or "Plex KM 업데이트"))
        win.setProperty("PlexKM.UpdateV2169.Line1", str(line1 or ""))
        win.setProperty("PlexKM.UpdateV2169.Line2", str(line2 or ""))
        win.setProperty("PlexKM.UpdateV2169.Percent", str(max(0, min(100, int(percent or 0)))))
    except Exception:
        pass


def _clear_progress():
    try:
        win = xbmcgui.Window(10000)
        for key in ("PlexKM.UpdateV2169.Title", "PlexKM.UpdateV2169.Line1", "PlexKM.UpdateV2169.Line2", "PlexKM.UpdateV2169.Percent"):
            win.clearProperty(key)
    except Exception:
        pass


def _set_restart(old_versions, new_versions, count=None, line=""):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.UpdateRestart.TitleV2169", "Plex KM 업데이트 완료")
        win.setProperty(
            "PlexKM.UpdateRestart.VersionV2169",
            "PKM %s → %s / Skin %s → %s" % (
                (old_versions or {}).get("plugin") or "-", (new_versions or {}).get("plugin") or "-",
                (old_versions or {}).get("skin") or "-", (new_versions or {}).get("skin") or "-",
            ),
        )
        win.setProperty("PlexKM.UpdateRestart.LineV2169", str(line or ""))
        win.setProperty("PlexKM.UpdateRestart.CountV2169", "" if count is None else str(count))
    except Exception:
        pass


def _clear_restart():
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.UpdateRestart.TitleV2169", "PlexKM.UpdateRestart.VersionV2169",
            "PlexKM.UpdateRestart.LineV2169", "PlexKM.UpdateRestart.CountV2169",
        ):
            win.clearProperty(key)
    except Exception:
        pass


def _show_countdown(old_versions, new_versions, monitor=None):
    detail = "Plex KM 업데이트가 완료되었습니다."
    return request_kodi_exit_v2171(
        reason="pkm_update_complete_v2171",
        title="Kodi 종료",
        detail=detail,
        monitor=monitor,
    )


class PKMUpdateFlowV2169(object):
    """Non-blocking update state machine called from the PKM service loop."""

    def __init__(self, request_service_stop=None):
        self.request_service_stop = request_service_stop
        self.started_at = time.time()
        self.protection_ready = False
        self.protection_retry_at = 0.0
        self.state = _read_state()
        self.deferred_this_run = False
        self.check_started = False
        self.check_done = False
        self.check_result = None
        self.check_error = None
        self.check_lock = threading.Lock()
        self.notice_token = ""
        self.notice_until = 0.0
        self.prompt = None
        self.prompt_started_at = 0.0
        self.progress = None
        self.finished = False
        self.install_invoked_at = 0.0
        self.install_retry_count = 0
        self.repo_refresh_invoked_at = 0.0
        self.phase_started_at = 0.0
        self.update_rules_ready_v2320 = False
        self.process_token = self._process_token_v2317()
        self.resumed_after_completed_update = False
        _log("PKM_PATCH_ACTIVE v2375 startup_first_update_gate_ratings_dependency_install_korean_status")
        # v2419: this is a real process-start path. Safely enable a ratings
        # package that was copied during a previous run, without ever creating
        # an invalid Addon() object.
        _ensure_ratings_enabled_v2419()
        self._resume_or_seed_state()
        if self.resumed_after_completed_update:
            # Completed update + real Kodi restart is a committed transaction boundary.
            # Publish that fact to the startup owner before it begins Home composition.
            # This is not a timeout/fail-open path: the updater has already verified the
            # installed target versions in _resume_or_seed_state().
            _clear_startup_update_phase_v2375(reason="completed_update_restart_boundary")
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.PostUpdateRestartCommitted", "1")
                win.setProperty("PlexKM.PostUpdateRestartTargetPlugin", str(current_version(PLUGIN_ID) or ""))
                win.setProperty("PlexKM.PostUpdateRestartTargetSkin", str(current_version(SKIN_ID) or ""))
            except Exception:
                pass
            self.finished = True
            _log("PKM_UPDATE_POST_RESTART_COMPLETE action=transaction_committed no_duplicate_remote_check=1 startup_block=0")
            return
        active_phase_v2375 = str(self.state.get("phase") or "")
        if active_phase_v2375 in ("direct_packages_v2321", "repo_auto_install", "repo_refresh", "install_plugin", "install_skin", "finalize"):
            _set_startup_update_phase_v2375("install_addon", "PKM 애드온 업데이트 중입니다", block=True)
        else:
            _set_startup_update_phase_v2375("checking", "PKM 업데이트를 확인하고 있습니다", block=True)
            self._start_remote_check()

    def _process_token_v2317(self):
        """Return a Kodi-process token that survives add-on service reload only.

        Window(10000) properties survive plugin service self-restart but are
        cleared by a real Kodi process restart. This lets the updater distinguish
        the two boundaries and prevents a plugin self-update from being mistaken
        for the requested Kodi restart.
        """
        try:
            win = xbmcgui.Window(10000)
            key = "PlexKM.Update.ProcessTokenV2317"
            token = str(win.getProperty(key) or "")
            if not token:
                token = "%d_%d" % (int(time.time() * 1000), id(self))
                win.setProperty(key, token)
            return token
        except Exception:
            return "%d_%d" % (int(time.time() * 1000), id(self))

    def _resume_or_seed_state(self):
        current = current_versions()
        target = self.state.get("target") if isinstance(self.state.get("target"), dict) else None
        phase = str(self.state.get("phase") or "")
        origin_process = str(self.state.get("origin_process_token") or "")
        try:
            self.phase_started_at = float(self.state.get("phase_started_epoch") or 0.0)
        except Exception:
            self.phase_started_at = 0.0
        if target and _target_reached(current, target):
            if origin_process and origin_process == self.process_token:
                # The plugin updated and Kodi recycled only this service inside the
                # same process. That is NOT the requested Kodi restart boundary.
                # Re-enter finalize so the completion/quit flow still runs.
                self.state["phase"] = "finalize"
                self.state["phase_started_epoch"] = time.time()
                self.state["updated_at"] = int(time.time())
                _write_state(self.state)
                self.phase_started_at = float(self.state.get("phase_started_epoch") or time.time())
                _log("PKM_UPDATE_RESUME_SELF_RESTART_COMPLETE_V2317 process=same plugin=%s skin=%s" % (current.get("plugin"), current.get("skin")))
            else:
                # Window properties were cleared, so Kodi itself restarted. The
                # requested restart boundary has genuinely been crossed. Restore any
                # temporary PKM update-rule override left by an interrupted exit.
                _log("PKM_UPDATE_RESUME_AFTER_KODI_RESTART_V2317 plugin=%s skin=%s" % (current.get("plugin"), current.get("skin")))
                self._restore_pkm_update_rules_v2320()
                original = self._restore_original_update_mode_value()
                self.state = {"schema": 1, "phase": "guard", "original_addonupdates": original}
                _write_state(self.state)
                self.resumed_after_completed_update = True
        elif phase == "direct_packages_v2321" or phase == "repo_auto_install" or phase.startswith("install_") or phase in ("repo_refresh", "finalize"):
            _log("PKM_UPDATE_RESUME_ACTIVE_V2319 phase=%s target=%s process_same=%d explicit=%d" % (
                phase, target, 1 if origin_process and origin_process == self.process_token else 0,
                1 if self.state.get("explicit_update") else 0,
            ))

    def _protect_from_silent_auto_update(self):
        if self.protection_ready:
            return True
        now = time.time()
        if now < self.protection_retry_at:
            return False
        mode = _get_setting_value("general.addonupdates")
        if mode is None:
            self.protection_retry_at = now + 1.0
            return False
        try:
            mode = int(mode)
        except Exception:
            self.protection_retry_at = now + 2.0
            return False

        phase = str(self.state.get("phase") or "")
        explicit_active = bool(self.state.get("explicit_update")) and phase in (
            "repo_auto_install", "repo_refresh", "install_skin", "install_plugin", "finalize"
        )
        if explicit_active:
            # The user already confirmed this persisted transaction. Keep Kodi's
            # native auto-update path enabled across plugin service self-restarts
            # until both requested PKM versions are observed or the transaction fails.
            if mode != 0:
                if not _set_setting_value("general.addonupdates", 0):
                    self.protection_retry_at = now + 1.0
                    return False
                _log("PKM_UPDATE_AUTO_MODE_V2319 changed=%s_to_0 reason=explicit_transaction_resume" % mode)
            self.protection_ready = True
            return True

        if "original_addonupdates" not in self.state or self.state.get("original_addonupdates") is None:
            self.state["schema"] = 1
            self.state["phase"] = self.state.get("phase") or "guard"
            self.state["original_addonupdates"] = mode
            _write_state(self.state)
        # 0 is Kodi automatic install; 1 is notify only. Keep 2 (never) untouched.
        if mode == 0:
            if not _set_setting_value("general.addonupdates", 1):
                self.protection_retry_at = now + 1.0
                return False
            _log("PKM_UPDATE_AUTO_GUARD_V2169 changed=0_to_1 scope=until_pkm_check_or_restart")
        else:
            _log("PKM_UPDATE_AUTO_GUARD_V2169 changed=0 current_mode=%s" % mode)
        self.protection_ready = True
        return True

    def _prepare_pkm_update_rules_v2320(self):
        """Temporarily remove PKM per-addon pins/auto-update blocks for this explicit update.

        Kodi 21.3's repository updater calls CheckAndInstallAddonUpdates(), which then
        removes every candidate for which IsAutoUpdateable(id) is false. Any row in
        update_rules makes that false. PKM normally keeps automatic updates blocked,
        so v2319 could refresh the repository forever while Skin stayed at 40%.
        Save the exact rows, clear only PKM's rows, refresh Kodi's in-memory rule map,
        and restore the rows on every success/failure exit path.
        """
        if self.update_rules_ready_v2320:
            return True
        saved = self.state.get("saved_update_rules_v2320")
        if saved is None:
            try:
                saved = _read_pkm_update_rules_v2320()
            except Exception as exc:
                _log("PKM_UPDATE_RULES_READ_FAILED_V2320 err=%s" % exc, xbmc.LOGERROR)
                return False
            self.state["saved_update_rules_v2320"] = saved
            self.state["updated_at"] = int(time.time())
            if not _write_state(self.state):
                return False
        try:
            _write_pkm_update_rules_v2320(saved, clear_only=True)
            # Refresh AddonManager's cached rule map after the DB transaction.
            xbmc.executebuiltin("UpdateLocalAddons")
            self.update_rules_ready_v2320 = True
            _log("PKM_UPDATE_RULES_CLEARED_V2320 saved=%s scope=plugin_skin_only" % saved)
            return True
        except Exception as exc:
            _log("PKM_UPDATE_RULES_CLEAR_FAILED_V2320 err=%s" % exc, xbmc.LOGERROR)
            return False

    def _restore_pkm_update_rules_v2320(self):
        saved = self.state.get("saved_update_rules_v2320")
        if saved is None:
            return True
        try:
            _write_pkm_update_rules_v2320(saved, clear_only=False)
            xbmc.executebuiltin("UpdateLocalAddons")
            self.update_rules_ready_v2320 = False
            _log("PKM_UPDATE_RULES_RESTORED_V2320 restored=%s" % saved)
            return True
        except Exception as exc:
            _log("PKM_UPDATE_RULES_RESTORE_FAILED_V2320 err=%s" % exc, xbmc.LOGERROR)
            return False

    def _restore_original_update_mode_value(self):
        """Restore the user's pre-PKM add-on update mode without deleting transaction state."""
        original = self.state.get("original_addonupdates")
        try:
            original = int(original)
        except Exception:
            original = None
        if original is None:
            return None
        current = _get_setting_value("general.addonupdates")
        try:
            current = int(current)
        except Exception:
            current = None
        if current is not None and current != original:
            if _set_setting_value("general.addonupdates", original):
                _log("PKM_UPDATE_AUTO_MODE_RESTORE_V2319 mode=%s" % original)
            else:
                _log("PKM_UPDATE_AUTO_MODE_RESTORE_FAILED_V2319 mode=%s current=%s" % (original, current), xbmc.LOGWARNING)
        return original

    def _restore_original_update_mode(self):
        self._restore_pkm_update_rules_v2320()
        self._restore_original_update_mode_value()
        self.state = {}
        _delete_state()


    def _blocked(self):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win.getProperty("PlexKM.FullResetInProgressV2149") == "1":
                return True
        except Exception:
            pass
        try:
            if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                return True
        except Exception:
            pass
        return False

    def _start_remote_check(self):
        if self.check_started:
            return
        self.check_started = True

        def worker():
            result = None
            error = None
            try:
                result = _fetch_remote_versions()
            except Exception as exc:
                error = str(exc)
            with self.check_lock:
                self.check_result = result
                self.check_error = error
                self.check_done = True

        thread = threading.Thread(target=worker, name="PKMUpdateCheckV2169", daemon=True)
        thread.daemon = True
        thread.start()
        _log("PKM_UPDATE_REMOTE_CHECK_START_V2169")

    def _available_target(self):
        with self.check_lock:
            remote = dict(self.check_result or {})
        current = current_versions()
        target = dict(current)
        available = False
        if remote.get("plugin") and _is_newer(remote.get("plugin"), current.get("plugin")):
            target["plugin"] = remote.get("plugin")
            available = True
        if remote.get("skin") and _is_newer(remote.get("skin"), current.get("skin")):
            target["skin"] = remote.get("skin")
            available = True

        required = remote.get("ratings_required") or RATINGS_MIN_VERSION_V2375
        published = remote.get("ratings") or ""
        if published and _version_tuple(published) < _version_tuple(required):
            _log("RATINGS_SERVICE_REPOSITORY_TOO_OLD_V2375 published=%s required=%s" % (published, required), xbmc.LOGERROR)
        ratings_target = required
        if ratings_target and not _at_least(current.get("ratings"), ratings_target):
            target["ratings"] = ratings_target
            available = True
        return available, current, target

    def _show_notice(self, current, target):
        self.notice_until = time.time() + NOTICE_SECONDS
        _set_startup_update_phase_v2375("available", "PKM 업데이트가 준비되었습니다", block=True)
        if pkm_notify:
            try:
                changed = []
                if not _at_least(current.get("plugin"), target.get("plugin")):
                    changed.append("PKM %s" % (target.get("plugin") or "-"))
                if not _at_least(current.get("skin"), target.get("skin")):
                    changed.append("Skin %s" % (target.get("skin") or "-"))
                if not _at_least(current.get("ratings"), target.get("ratings")):
                    changed.append("평점 서비스 %s" % (target.get("ratings") or "-"))
                self.notice_token = pkm_notify.pkm_notice_set(
                    "PKM 업데이트",
                    "업데이트할 항목이 있습니다",
                    " / ".join(changed) or "업데이트를 준비했습니다.",
                    token="pkm_update_v2169_%d" % int(time.time() * 1000),
                    sticky=False,
                    force_replace=False,
                )
            except Exception as exc:
                _log("PKM_UPDATE_NOTICE_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        _log("PKM_UPDATE_AVAILABLE_NOTICE_V2375 current=%s target=%s" % (current, target))

    def _clear_notice(self):
        if pkm_notify and self.notice_token:
            try:
                pkm_notify.pkm_notice_clear(expected_token=self.notice_token, force=False)
            except Exception:
                pass
        self.notice_token = ""

    def _open_prompt(self):
        if self.prompt is not None:
            return
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        _set_confirm_props("PKM 업데이트", "업데이트를 진행하겠습니까?", "업데이트", "나중에")
        self.prompt = PKMUpdateConfirmDialogV2169(CONFIRM_XML, addon_path, "Default", "1080i")
        self.prompt.show()
        self.prompt_started_at = time.time()
        _set_startup_update_phase_v2375("prompt", "PKM 업데이트가 준비되었습니다", block=True)
        _log("PKM_UPDATE_CONFIRM_OPEN_V2375 timeout_sec=%s default=later" % PROMPT_TIMEOUT_SECONDS)

    def _close_prompt(self):
        try:
            if self.prompt is not None:
                self.prompt.close()
        except Exception:
            pass
        self.prompt = None
        self.prompt_started_at = 0.0
        _clear_confirm_props()

    def _show_progress(self):
        if self.progress is not None:
            return
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        self.progress = PKMUpdateProgressDialogV2169(PROGRESS_XML, addon_path, "Default", "1080i")
        self.progress.show()
        _log("PKM_UPDATE_PROGRESS_OPEN_V2317 renderer=xml_percent_slices")

    def _close_progress(self):
        try:
            if self.progress is not None:
                self.progress.close()
        except Exception:
            pass
        self.progress = None
        _clear_progress()

    def _save_active(self, phase, current, target):
        original = self.state.get("original_addonupdates")
        now = time.time()
        self.state = {
            "schema": 2,
            "phase": phase,
            "explicit_update": 1,
            "original_addonupdates": original,
            "before": dict(current or {}),
            "target": dict(target or {}),
            "origin_process_token": self.process_token,
            "phase_started_epoch": now,
            "refresh_requested_epoch": 0.0,
            "updated_at": int(now),
        }
        _write_state(self.state)
        self.phase_started_at = now
        self.install_invoked_at = 0.0
        self.install_retry_count = 0
        self.repo_refresh_invoked_at = 0.0

    def _begin_update(self, current, target):
        _log("PKM_UPDATE_BEGIN_V2375 before=%s target=%s mode=direct_verified_packages_with_ratings_dependency" % (current, target))
        self._close_prompt()
        self._save_active("direct_packages_v2321", current, target)
        _set_startup_update_phase_v2375("install_addon", "PKM 애드온 업데이트 중입니다", block=True)
        self._show_progress()
        _set_progress("Plex KM 업데이트", "업데이트 패키지를 준비합니다.", "PKM 필수 구성요소까지 함께 적용합니다.", 10)

    def _fail(self, message, error=None):
        _log("PKM_UPDATE_FAILED_V2375 message=%s err=%s" % (message, error or ""), xbmc.LOGERROR)
        self._close_progress()
        _clear_startup_update_phase_v2375(reason="update_failed")
        self._restore_original_update_mode()
        if pkm_notify:
            try:
                pkm_notify.pkm_notice_set(
                    "PKM 업데이트 실패", message, "다음 실행에서 다시 시도합니다",
                    token="pkm_update_fail_v2169_%d" % int(time.time() * 1000), force_replace=True,
                )
            except Exception:
                pass
        self.deferred_this_run = True


    def _tick_active_update(self, monitor=None):
        phase = str(self.state.get("phase") or "")
        target = self.state.get("target") if isinstance(self.state.get("target"), dict) else {}
        before = self.state.get("before") if isinstance(self.state.get("before"), dict) else current_versions()
        if not target:
            self._fail("업데이트 대상 버전 정보를 찾지 못했습니다.")
            return False

        # Migrate an already-confirmed v2319/v2320 transaction into v2321's
        # non-reloading direct package path. Do not invoke Kodi RepositoryUpdater.
        if phase != "direct_packages_v2321":
            if self.state.get("explicit_update"):
                phase = "direct_packages_v2321"
                self.state["phase"] = phase
                self.state["phase_started_epoch"] = time.time()
                self.state["updated_at"] = int(time.time())
                _write_state(self.state)
                self.phase_started_at = float(self.state.get("phase_started_epoch") or time.time())
                _log("PKM_UPDATE_PHASE_MIGRATE_V2321 phase=direct_packages_v2321")
            else:
                self._fail("이전 업데이트 상태를 안전하게 재개할 수 없습니다.")
                return False

        current = current_versions()
        if not _target_reached(current, target):
            try:
                _install_pending_packages_v2321(current, target)
            except PKMUpdatePackageError as exc:
                self._fail("%s 업데이트를 적용하지 못했습니다." % exc.component, exc)
                return False
            except Exception as exc:
                self._fail("업데이트 패키지를 적용하지 못했습니다.", exc)
                return False
            current = current_versions()

        if not _target_reached(current, target):
            self._fail("업데이트 파일 적용 후 버전 확인에 실패했습니다.")
            return False

        _log("PKM_UPDATE_TARGET_REACHED_V2375 current=%s target=%s phase=%s runtime_skin_reload=0" % (current, target, phase))
        _set_startup_update_phase_v2375("finalizing", "PKM 업데이트를 마무리하고 있습니다", block=True)
        self._show_progress()
        _set_progress("Plex KM 업데이트", "업데이트가 완료되었습니다.", "필수 구성요소 설치를 확인했습니다. Kodi를 다시 시작합니다.", 100)
        if monitor is not None:
            monitor.waitForAbort(0.9)
        else:
            xbmc.sleep(900)

        # The progress dialog is still valid because v2321 never asked Kodi to
        # unload/reload the active skin. Close it only after the 100% frame was
        # visibly held, then hand off to the established 3-2-1 exit surface.
        self._close_progress()
        original = self.state.get("original_addonupdates")
        self.state = {"schema": 2, "phase": "guard", "original_addonupdates": original}
        _write_state(self.state)
        _log("PKM_UPDATE_KODI_EXIT_V2321 action=visible_countdown_after_100")
        countdown_ok = _show_countdown(before, current, monitor=monitor)
        _log("PKM_UPDATE_KODI_EXIT_RETURN_V2321 countdown_ok=%d" % (1 if countdown_ok else 0))
        self.finished = True
        return True

    def tick(self, monitor=None):
        if self.finished:
            return True

        if not self._protect_from_silent_auto_update():
            return False

        phase = str(self.state.get("phase") or "")
        if phase in ("direct_packages_v2321", "repo_auto_install", "repo_refresh", "install_plugin", "install_skin", "finalize"):
            return self._tick_active_update(monitor=monitor)

        if self.deferred_this_run or self._blocked():
            return False

        # v2375: update discovery is a pre-Home startup gate.  The remote check
        # starts in __init__ and must never wait for Home/authority sync first.
        if not self.check_started:
            _set_startup_update_phase_v2375("checking", "PKM 업데이트를 확인하고 있습니다", block=True)
            self._start_remote_check()
            return False
        if not self.check_done:
            return False

        if self.check_error:
            _log("PKM_UPDATE_REMOTE_CHECK_FAILED_V2375 err=%s action=fail_open_home" % self.check_error, xbmc.LOGWARNING)
            _clear_startup_update_phase_v2375(reason="remote_check_failed")
            self._restore_original_update_mode()
            self.deferred_this_run = True
            return False

        available, current, target = self._available_target()
        if not available:
            _log("PKM_UPDATE_NONE_V2375 plugin=%s skin=%s ratings=%s" % (
                current.get("plugin") or "-", current.get("skin") or "-", current.get("ratings") or "-"
            ))
            _clear_startup_update_phase_v2375(reason="no_update")
            self._restore_original_update_mode()
            self.deferred_this_run = True
            return False

        plugin_changed_v2375 = not _at_least(current.get("plugin"), target.get("plugin"))
        skin_changed_v2375 = not _at_least(current.get("skin"), target.get("skin"))
        ratings_changed_v2375 = not _at_least(current.get("ratings"), target.get("ratings"))
        if ratings_changed_v2375 and not plugin_changed_v2375 and not skin_changed_v2375:
            try:
                _log("RATINGS_SERVICE_REQUIRED_REPAIR_V2375 current=%s target=%s action=prehome_auto_repair" % (
                    current.get("ratings") or "missing", target.get("ratings") or RATINGS_MIN_VERSION_V2375
                ))
                _repair_required_ratings_service_v2375(target.get("ratings"))
                self._restore_original_update_mode()
                self.deferred_this_run = True
                return False
            except Exception as ratings_repair_exc_v2375:
                _log("RATINGS_SERVICE_REPAIR_FAILED_V2375 err=%s action=fail_open_home" % ratings_repair_exc_v2375, xbmc.LOGERROR)
                _clear_startup_update_phase_v2375(reason="ratings_repair_failed")
                self._restore_original_update_mode()
                self.deferred_this_run = True
                if pkm_notify:
                    try:
                        pkm_notify.pkm_notice_set(
                            "평점 서비스 설치 실패",
                            "평점 서비스 설치에 실패했습니다",
                            "네트워크와 저장소를 확인해주세요",
                            token="pkm_ratings_repair_fail_v2375_%d" % int(time.time() * 1000),
                            force_replace=True,
                        )
                    except Exception:
                        pass
                return False

        if not self.notice_until and self.prompt is None:
            self._show_notice(current, target)
            return False

        if self.notice_until:
            if time.time() < self.notice_until:
                return False
            self._clear_notice()
            self.notice_until = 0.0
            self._open_prompt()
            return False

        if self.prompt is not None:
            choice = self.prompt.choice
            try:
                _p = xbmcgui.Window(10000).getProperty(CONFIRM_CHOICE_PROP_V2646)
            except Exception:
                _p = ""
            if choice is None and _p == "update":
                choice = True
                _log("PKM_UPDATE_CONFIRM_FALLBACK_V2646 choice=update source=xml_property")
            elif choice is None and _p == "later":
                choice = False
            if choice is True:
                self._begin_update(current, target)
                return False
            if choice is False:
                self._close_prompt()
                self.deferred_this_run = True
                _clear_startup_update_phase_v2375(reason="user_defer")
                _log("PKM_UPDATE_DEFER_V2375 source=user next_kodi_start=1")
                # Intentionally keep global add-on mode guarded this session; restoring automatic
                # mode would allow the pending PKM version to install silently after "나중에".
                return False
            if (time.time() - self.prompt_started_at) >= PROMPT_TIMEOUT_SECONDS:
                self._close_prompt()
                self.deferred_this_run = True
                _clear_startup_update_phase_v2375(reason="prompt_timeout")
                _log("PKM_UPDATE_DEFER_V2375 source=timeout timeout_sec=%s next_kodi_start=1" % PROMPT_TIMEOUT_SECONDS)
                return False

        return False
