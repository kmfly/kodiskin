# -*- coding: utf-8 -*-
"""PKM settings flow and small PKM-styled modal dialogs.

This module is intentionally UI/settings-only.  It was split out of
``default.py`` from the v626 stable baseline so later sync/cache patches do not
accidentally revive old settings-dialog code paths.

Rules for this module:
- keep one WindowXMLDialog alive and switch pages in-place;
- do not open Kodi's default add-on settings window;
- keep Plex DB path selection inside the PKM styled dialog;
- cancel/Esc preserves existing settings values.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import sys
import os
import json
import time
import sqlite3
import traceback
import threading
import hashlib
import string
import xml.etree.ElementTree as ET
try:
    from urllib.parse import urlparse
except Exception:
    from urlparse import urlparse

import xbmcvfs

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None

try:
    from resources.lib import pkm_plex_client
except Exception:
    pkm_plex_client = None

try:
    from resources.lib import pkm_spinner
except Exception:
    pkm_spinner = None

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")


def _display_text_for_kodi(value):
    """Normalize Plex library title separators for Kodi WindowXML text rendering."""
    text = str(value or "")
    try:
        table = {
            ord("\u007C"): "|",
            ord("\u00A6"): "|",
            ord("\u01C0"): "|",
            ord("\u2016"): "|",
            ord("\u2223"): "|",
            ord("\u2225"): "|",
            ord("\u23AA"): "|",
            ord("\u23D0"): "|",
            ord("\u2502"): "|",
            ord("\u2503"): "|",
            ord("\u2758"): "|",
            ord("\u2759"): "|",
            ord("\u275A"): "|",
            ord("\u3163"): "|",
            ord("\u4E28"): "|",
            ord("\uFF5C"): "|",
            ord("\uFFE8"): "|",
        }
        return text.translate(table)
    except Exception:
        return text


def _core():
    """Return the running default.py module without importing a second copy."""
    return sys.modules.get("default") or sys.modules.get("__main__")


def _sync_runtime_plex_auth_settings_v1690(token_module):
    """Mirror the newly authenticated state into every live Addon wrapper.

    Kodi can keep one settings snapshot per ``xbmcaddon.Addon`` Python wrapper.
    The Plex URL is edited by this module, while plex.tv/link stores the selected
    Home user's token in ``pkm_token_import``.  The running ``default.py`` can
    therefore still see its pre-dialog empty snapshot and abort before the live
    ``/library/sections`` request.  Keep the existing settings architecture and
    only make the three already-running wrappers equivalent before continuing.
    """
    try:
        server = (ADDON.getSetting("plex_url") or "").strip()
        token_addon = getattr(token_module, "ADDON", None)
        token = (token_addon.getSetting("plex_token") or "").strip() if token_addon else ""
        account = (token_addon.getSetting("plex_account_name") or "").strip() if token_addon else ""
        if not server or not token:
            _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_INCOMPLETE_V1690 server=%s token=%s" % (
                "1" if server else "0", "1" if token else "0"
            ), xbmc.LOGWARNING)
            return False

        targets = []
        for candidate in (ADDON, token_addon, getattr(_core(), "ADDON", None)):
            if candidate is not None and all(candidate is not existing for existing in targets):
                targets.append(candidate)

        verified = True
        for target in targets:
            target.setSetting("plex_url", server)
            target.setSetting("plex_token", token)
            target.setSetting("plex_account_name", account)
            if (target.getSetting("plex_url") or "").strip() != server:
                verified = False
            if (target.getSetting("plex_token") or "").strip() != token:
                verified = False

        # v1732: the already-open Home window can keep an older xbmcaddon.Addon
        # settings snapshot even after the settings dialog writes the new values.
        # Publish the authenticated endpoint in the global Kodi window as the
        # current-run source of truth so Home can render immediately without a
        # Kodi restart. Persistent add-on settings remain the next-run source.
        try:
            runtime = xbmcgui.Window(10000)
            runtime.setProperty("PlexKM.Runtime.PlexURL", server)
            runtime.setProperty("PlexKM.Runtime.PlexToken", token)
            runtime.setProperty("PlexKM.Runtime.PlexAccount", account)
            runtime.setProperty("PlexKM.Runtime.PlexAuthAuthoritative", "1")
        except Exception:
            verified = False

        _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_V1732 server=1 token=1 targets=%d verified=%s bridge=global_window" % (
            len(targets), "1" if verified else "0"
        ), xbmc.LOGINFO if verified else xbmc.LOGWARNING)
        return verified
    except Exception:
        _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_FAILED_V1690\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return False


def _log(message, level=xbmc.LOGINFO):
    core = _core()
    try:
        if core and hasattr(core, "log"):
            core.log(message, level)
            return
    except Exception:
        pass
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)



def _offline_or_server_switch_pending_v1382():
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.PlexOffline") == "1":
            return True
        if win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
            return True
    except Exception:
        pass
    return False

def _plex_server_settings_ready_v1702():
    """Return True only when both PMS address and Plex token exist.

    Use the live default.py wrappers when available so the settings dialog does
    not repeat the stale xbmcaddon.Addon snapshot problem fixed in v1690.
    """
    core = _core()
    try:
        if core and hasattr(core, "clean_server_url"):
            server = (core.clean_server_url() or "").strip()
        else:
            server = (ADDON.getSetting("plex_url") or "").strip().rstrip("/")
        if core and hasattr(core, "plex_token"):
            token = (core.plex_token() or "").strip()
        else:
            token = (ADDON.getSetting("plex_token") or "").strip()
        return bool(server and token)
    except Exception:
        return bool((ADDON.getSetting("plex_url") or "").strip() and (ADDON.getSetting("plex_token") or "").strip())


def _require_plex_server_settings_v1702(source="settings"):
    if _plex_server_settings_ready_v1702():
        return True
    _log("PKM_SETTINGS_SERVER_REQUIRED_V1702 source=%s" % str(source or "settings"), xbmc.LOGINFO)
    _notify("Plex 서버 설정이 먼저 필요합니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
    return False


def _notify(message, heading=ADDON_NAME, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    core = _core()
    try:
        if core and hasattr(core, "notify"):
            core.notify(message, heading=heading, icon=icon, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(heading or ADDON_NAME, message, "", ms=ms):
            return
    except Exception:
        pass
    _log("PKM_NATIVE_NOTIFICATION_SUPPRESSED heading=%s message=%s" % (str(heading or ""), str(message or "")), xbmc.LOGINFO)


def _set_confirm_global_props(title, message, yes_label, no_label, icon1="", icon2="", cine21_rows=None, logo_icon="", critic_icon="", audience_icon="", windowed_video=False):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Confirm.Title", _display_text_for_kodi(title or "Plex KM"))
        win.setProperty("PlexKM.Confirm.Message", _display_text_for_kodi(message or ""))
        win.setProperty("PlexKM.Confirm.Yes", _display_text_for_kodi(yes_label or "확인"))
        win.setProperty("PlexKM.Confirm.No", _display_text_for_kodi(no_label or ""))
        win.setProperty("PlexKM.Confirm.Icon1", icon1 or "")
        win.setProperty("PlexKM.Confirm.Icon2", icon2 or "")
        win.setProperty("PlexKM.Confirm.HasIcons", "1" if (icon1 or icon2) else "")
        win.setProperty("PlexKM.Confirm.WindowedVideo", "1" if windowed_video else "")
        rows = list(cine21_rows or [])[:3]
        win.setProperty("PlexKM.Confirm.HasCine21Rows", "1" if rows else "")
        win.setProperty("PlexKM.Confirm.Cine21LogoIcon", logo_icon or "")
        win.setProperty("PlexKM.Confirm.Cine21CriticIcon", critic_icon or "")
        win.setProperty("PlexKM.Confirm.Cine21AudienceIcon", audience_icon or "")
        for idx in range(1, 4):
            row = rows[idx - 1] if idx <= len(rows) else {}
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Title" % idx, _display_text_for_kodi(row.get("title") or ""))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Critic" % idx, str(row.get("critic") or "-"))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Audience" % idx, str(row.get("audience") or "-"))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Visible" % idx, "1" if row else "")
    except Exception:
        pass


def _clear_confirm_global_props():
    try:
        win = xbmcgui.Window(10000)
        keys = ["PlexKM.Confirm.Title", "PlexKM.Confirm.Message", "PlexKM.Confirm.Yes", "PlexKM.Confirm.No", "PlexKM.Confirm.Icon1", "PlexKM.Confirm.Icon2", "PlexKM.Confirm.HasIcons", "PlexKM.Confirm.HasCine21Rows", "PlexKM.Confirm.Cine21LogoIcon", "PlexKM.Confirm.Cine21CriticIcon", "PlexKM.Confirm.Cine21AudienceIcon", "PlexKM.Confirm.WindowedVideo"]
        for idx in range(1, 4):
            keys.extend([
                "PlexKM.Confirm.Cine21.Row%d.Title" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Critic" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Audience" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Visible" % idx,
            ])
        for key in keys:
            win.clearProperty(key)
    except Exception:
        pass


class PKMListDialog(xbmcgui.WindowXMLDialog):
    """Small PKM-styled modal list dialog for settings/library selection."""
    LIST_ID = 200
    OK_ID = 300
    HOME_ID = 302
    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "")
        self.items = kwargs.pop("items", [])
        self.multiselect = bool(kwargs.pop("multiselect", False))
        self.require_confirm = bool(kwargs.pop("require_confirm", False))
        self.preselect = set(int(x) for x in (kwargs.pop("preselect", []) or []))
        self.result = None
        self._list = None
        super(PKMListDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self.setProperty("PlexKM.Dialog.Title", self.title or "Plex KM")
            mode = "multi" if self.multiselect else ("single_confirm" if self.require_confirm else "single")
            self.setProperty("PlexKM.Dialog.Mode", mode)
            if self.multiselect:
                hint = "선택 / 저장 / 뒤로"
            elif self.require_confirm:
                hint = "선택 / 확인 / 뒤로"
            else:
                hint = "선택 / 뒤로"
            self.setProperty("PlexKM.Dialog.Hint", hint)
        except Exception:
            pass
        try:
            self._list = self.getControl(self.LIST_ID)
            self._list.reset()
            listitems = []
            for idx, label in enumerate(self.items):
                li = xbmcgui.ListItem(label=_display_text_for_kodi(label))
                li.setProperty("index", str(idx))
                li.setProperty("checked", "1" if idx in self.preselect else "0")
                li.setProperty("showcheck", "1" if (self.multiselect or self.require_confirm) else "0")
                listitems.append(li)
            self._list.addItems(listitems)
            self.setFocusId(self.LIST_ID)
        except Exception:
            _log("PKM_SETTINGS_DIALOG_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _toggle_focused(self):
        if not self._list:
            return
        pos = int(self._list.getSelectedPosition())
        if pos < 0 or pos >= len(self.items):
            return
        if pos in self.preselect:
            self.preselect.remove(pos)
        else:
            self.preselect.add(pos)
        item = self._list.getListItem(pos)
        checked = pos in self.preselect
        item.setProperty("checked", "1" if checked else "0")

    def _select_single_confirm_focused_v1691(self):
        """Select exactly one Plex Home row and expose the PKM square check.

        v1689 closed the dialog immediately from the list click, so Kodi never
        had a stable frame in which to draw the checked square.  Keep one-press
        row selection, but make confirmation an explicit second control action:
        Enter fills the selected row's PKM square and moves focus to 확인.
        """
        if not self._list:
            return None
        pos = int(self._list.getSelectedPosition())
        if pos < 0 or pos >= len(self.items):
            return None
        for idx in range(len(self.items)):
            try:
                self._list.getListItem(idx).setProperty("checked", "1" if idx == pos else "0")
            except Exception:
                pass
        self.preselect = set([pos])
        self.result = None
        _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_ROW_CHECKED_V1705 choice=%d focus=list xml_right_to_confirm=1" % pos, xbmc.LOGINFO)
        return pos

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        try:
            if controlId == self.LIST_ID:
                pos = int(self._list.getSelectedPosition()) if self._list else -1
                if self.multiselect:
                    self._toggle_focused()
                elif self.require_confirm:
                    # v1691: Enter selects one Home user and visibly fills the
                    # PKM square at the right.  Focus then moves to 확인 so the
                    # user can commit the checked row without a hidden selection.
                    self._select_single_confirm_focused_v1691()
                else:
                    self.result = pos if 0 <= pos < len(self.items) else None
                    self.close()
            elif controlId == self.OK_ID:
                if self.multiselect:
                    self.result = sorted(self.preselect)
                elif self.require_confirm:
                    chosen = sorted(self.preselect)
                    if not chosen:
                        _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_REQUIRED_V1691", xbmc.LOGINFO)
                        try:
                            self.setFocusId(self.LIST_ID)
                        except Exception:
                            pass
                        return
                    self.result = int(chosen[0])
                    _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_ACCEPT_V1691 choice=%d" % self.result, xbmc.LOGINFO)
                else:
                    self.result = None
                self.close()
        except Exception:
            _log("PKM_SETTINGS_DIALOG_CLICK_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            self.result = None
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = None
            self.close()



class PKMTextInputDialog(xbmcgui.WindowXMLDialog):
    """PKM-native text input with one shared Python string buffer.

    v1704 removes Kodi ``ControlEdit`` entirely.  The focused PKM input row is
    a plain PKM button, so Enter can never open Kodi's stock keyboard.  Physical
    keyboard events are decoded from ``Action.getButtonCode()`` and appended to
    the same value used by the on-screen PKM keyboard.  Consumed letter keys do
    not fall through to global Kodi shortcuts such as H -> PVR.
    """
    TITLE_ID = 100
    VALUE_ID = 101
    KEYBOARD_ID = 200
    KEYS = list("1234567890") + list("abcdefghijklmnopqrstuvwxyz") + [
        ":", "/", ".", "-", "_", "@", "?", "&", "=", "%", "#", "+",
        "공백", "삭제", "지우기", "저장", "취소",
    ]

    # Kodi's hardware-independent VKEY range is KEY_VKEY | (symbol & 0x03ff).
    _KEY_VKEY = 0xF000
    _KEY_VKEY_MAX = 0xF3FF
    _KEY_VKEY_MASK = 0x03FF

    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "입력")
        self.value = str(kwargs.pop("value", "") or "")
        self.hidden = bool(kwargs.pop("hidden", False))
        self.result = None
        self._value_control = None
        self._keyboard = None
        super(PKMTextInputDialog, self).__init__(*args, **kwargs)

    def _visible_value_v1704(self):
        if not self.value:
            return "입력하세요"
        if self.hidden:
            return "•" * len(self.value)
        return self.value

    def _render_value_v1704(self):
        try:
            if self._value_control:
                self._value_control.setLabel(_display_text_for_kodi(self._visible_value_v1704()))
        except Exception:
            pass

    def _replace_value_v1704(self, value):
        self.value = str(value or "")
        self._render_value_v1704()

    def _append_value_v1704(self, char):
        self.value += str(char or "")
        self._render_value_v1704()

    def _delete_last_v1704(self):
        self.value = self.value[:-1]
        self._render_value_v1704()

    @classmethod
    def _decode_physical_key_v1704(cls, action):
        """Return ('char', text), ('backspace', ''), ('save', '') or None.

        Kodi 21 forwards the original button code even when a global keymap has
        translated the key to another action.  Decoding that original VKEY lets
        this modal consume printable keys before PVR/search/player shortcuts can
        run.  The mapping deliberately covers the ASCII set needed by server
        URLs and remote paths, plus numpad digits/operators.
        """
        try:
            raw = int(action.getButtonCode() or 0) & 0xFFFFFFFF
        except Exception:
            raw = 0
        if not raw:
            return None

        low = raw & 0xFFFF
        is_vkey = cls._KEY_VKEY <= low <= cls._KEY_VKEY_MAX
        if is_vkey:
            key = low & cls._KEY_VKEY_MASK
        elif 0 < low <= cls._KEY_VKEY_MASK:
            # Some Kodi/platform combinations expose the symbol without the
            # KEY_VKEY prefix to Python WindowXML callbacks.
            key = low
        else:
            return None

        # Compatibility with older KEY_ASCII/KEY_UNICODE-style encodings where
        # the printable byte is stored in the low 8 bits.
        if key > 0x10D:
            legacy = low & 0xFF
            if 0x20 <= legacy <= 0x7E:
                key = legacy
            else:
                return None

        if key == 0x08:  # backspace
            return ("backspace", "")
        if key in (0x0D, 0x65):  # Return / numpad Enter
            return ("save", "")
        if key in (0x7F, 0x87):  # Delete variants
            return ("backspace", "")

        if is_vkey:
            numpad_digits = {
                0x70: "0", 0x71: "1", 0x72: "2", 0x73: "3", 0x74: "4",
                0x75: "5", 0x76: "6", 0x77: "7", 0x78: "8", 0x79: "9",
            }
            numpad_ops = {0x61: "/", 0x62: "*", 0x63: "-", 0x64: "+", 0x66: "."}
            if key in numpad_digits:
                return ("char", numpad_digits[key])
            if key in numpad_ops:
                return ("char", numpad_ops[key])

        if 0x41 <= key <= 0x5A:
            return ("char", chr(key).lower())
        if 0x30 <= key <= 0x39:
            return ("char", chr(key))
        if key == 0x20:
            return ("char", " ")
        if 0x21 <= key <= 0x2F or 0x3A <= key <= 0x40 or 0x5B <= key <= 0x60 or 0x7B <= key <= 0x7E:
            return ("char", chr(key))
        return None

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self.getControl(self.TITLE_ID).setLabel(_display_text_for_kodi(self.title))
            self._value_control = self.getControl(self.VALUE_ID)
            self._keyboard = self.getControl(self.KEYBOARD_ID)
            self._render_value_v1704()
            self._keyboard.reset()
            items = []
            for key in self.KEYS:
                li = xbmcgui.ListItem(label=_display_text_for_kodi(key))
                li.setProperty("PKMKey", key)
                items.append(li)
            self._keyboard.addItems(items)
            # XML owns all focus movement.  The input row is the native default;
            # Down enters the PKM on-screen keyboard and Up returns to it.
            _log("PKM_TEXT_INPUT_BUFFER_READY_V1704", xbmc.LOGINFO)
        except Exception:
            _log("PKM_TEXT_INPUT_INIT_FAILED_V1704\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.VALUE_ID:
            # Enter confirms the current buffer.  This is a plain PKM button,
            # not ControlEdit, so Kodi's stock keyboard cannot be launched.
            self.result = self.value
            self.close()
            return
        if controlId != self.KEYBOARD_ID or not self._keyboard:
            return
        try:
            item = self._keyboard.getSelectedItem()
            key = item.getProperty("PKMKey") or item.getLabel()
            if key == "저장":
                self.result = self.value
                self.close()
                return
            if key == "취소":
                self.result = None
                self.close()
                return
            if key == "삭제":
                self._delete_last_v1704()
            elif key == "지우기":
                self._replace_value_v1704("")
            elif key == "공백":
                self._append_value_v1704(" ")
            else:
                self._append_value_v1704(key)
        except Exception:
            _log("PKM_TEXT_INPUT_CLICK_FAILED_V1704\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        physical = self._decode_physical_key_v1704(action)
        if physical:
            kind, payload = physical
            if kind == "char":
                self._append_value_v1704(payload)
            elif kind == "backspace":
                self._delete_last_v1704()
            elif kind == "save":
                self.result = self.value
                self.close()
            # Do not call the base handler: this consumes global H/P/S/etc.
            return

        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = None
            self.close()

def open_pkm_text_input(title, current="", hidden=False):
    """Use Kodi's native keyboard engine with the PKM-skinned DialogKeyboard.

    v1705 deliberately removes custom Python/VKEY text handling.  Kodi owns
    physical keyboard input, IME, Backspace/Delete, confirmation and cancel;
    skin.plex.km only changes the visual presentation of DialogKeyboard.xml.
    """
    try:
        keyboard = xbmc.Keyboard(str(current or ""), str(title or "입력"), bool(hidden))
        keyboard.doModal()
        if keyboard.isConfirmed():
            value = keyboard.getText()
            _log("PKM_NATIVE_KEYBOARD_CONFIRMED_V1705 length=%d" % len(value or ""), xbmc.LOGINFO)
            return value
        _log("PKM_NATIVE_KEYBOARD_CANCELLED_V1705", xbmc.LOGINFO)
        return None
    except Exception:
        _log("PKM_NATIVE_KEYBOARD_FAILED_V1705\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return None


def _window_stack_snapshot_v1747():
    """Return the current Kodi base/dialog stack without mutating GUI state."""
    base_id = -1
    dialog_id = -1
    try:
        base_id = int(xbmcgui.getCurrentWindowId())
    except Exception:
        pass
    try:
        dialog_id = int(xbmcgui.getCurrentWindowDialogId())
    except Exception:
        pass
    visible = {}
    for wid in (13030, 13031, 13032):
        try:
            visible[wid] = 1 if xbmc.getCondVisibility("Window.IsVisible(%d)" % wid) else 0
        except Exception:
            visible[wid] = -1
    try:
        current_window = xbmc.getInfoLabel("System.CurrentWindow") or ""
    except Exception:
        current_window = ""
    try:
        current_control = xbmc.getInfoLabel("System.CurrentControl") or ""
    except Exception:
        current_control = ""
    return base_id, dialog_id, visible, current_window, current_control


def _log_window_stack_v1747(stage, extra=""):
    try:
        base_id, dialog_id, visible, current_window, current_control = _window_stack_snapshot_v1747()
        _log(
            "PKM_WINDOW_STACK_V1747 stage=%s base=%s dialog=%s vis13030=%s vis13031=%s vis13032=%s current_window=%s current_control=%s%s" % (
                stage or "unknown", base_id, dialog_id,
                visible.get(13030, -1), visible.get(13031, -1), visible.get(13032, -1),
                str(current_window or "").replace(" ", "_"),
                str(current_control or "").replace(" ", "_"),
                (" " + str(extra)) if extra else "",
            ),
            xbmc.LOGINFO,
        )
    except Exception:
        pass


def _start_window_stack_probe_v1747(label, duration_ms=1400, interval_ms=10):
    """Log only native window-stack state changes during confirm→progress handoff."""
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.Sync.HandoffProbeV1747", "1")
    except Exception:
        pass
    def _probe():
        started = time.perf_counter()
        previous = None
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            elapsed_ms = int((time.perf_counter() - started) * 1000.0)
            if elapsed_ms > int(duration_ms or 0):
                break
            state = _window_stack_snapshot_v1747()
            compact = (state[0], state[1], state[2].get(13030), state[2].get(13031), state[2].get(13032), state[3], state[4])
            if compact != previous:
                previous = compact
                _log_window_stack_v1747("probe_%s" % (label or "handoff"), "t_ms=%d" % elapsed_ms)
            xbmc.sleep(max(1, int(interval_ms or 10)))
        _log_window_stack_v1747("probe_%s_end" % (label or "handoff"), "duration_ms=%d" % int(duration_ms or 0))
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Sync.HandoffProbeV1747")
        except Exception:
            pass
    try:
        thread = threading.Thread(target=_probe, name="PKMWindowStackProbeV1747", daemon=True)
        thread.daemon = True
        thread.start()
    except Exception:
        _log("PKM_WINDOW_STACK_PROBE_START_FAILED_V1747\n%s" % traceback.format_exc(), xbmc.LOGWARNING)


class PKMConfirmDialog(xbmcgui.WindowXMLDialog):
    YES_ID = 300
    NO_ID = 301

    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "Plex KM")
        self.message = kwargs.pop("message", "")
        self.yes_label = kwargs.pop("yes_label", "확인")
        self.no_label = kwargs.pop("no_label", "취소")
        self.icon1 = kwargs.pop("icon1", "")
        self.icon2 = kwargs.pop("icon2", "")
        self.cine21_rows = kwargs.pop("cine21_rows", [])
        self.cine21_logo_icon = kwargs.pop("cine21_logo_icon", "")
        self.cine21_critic_icon = kwargs.pop("cine21_critic_icon", "")
        self.cine21_audience_icon = kwargs.pop("cine21_audience_icon", "")
        self.windowed_video = bool(kwargs.pop("windowed_video", False))
        self.yes_prepare = kwargs.pop("yes_prepare", None)
        # v2150: focus still belongs exclusively to Kodi XML.  Keep the requested
        # default so open_pkm_confirm_dialog can choose the matching XML whose
        # <defaultcontrol> owns initial focus; Python never moves Left/Right focus.
        self.default_focus = str(kwargs.pop("default_focus", "") or "").strip().lower()
        self.result = False
        super(PKMConfirmDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        _log_window_stack_v1747("confirm_oninit", "window=13031")
        try:
            _set_confirm_global_props(self.title, self.message, self.yes_label, self.no_label, self.icon1, self.icon2, self.cine21_rows, self.cine21_logo_icon, self.cine21_critic_icon, self.cine21_audience_icon, self.windowed_video)
            self.setProperty("PlexKM.Confirm.Title", _display_text_for_kodi(self.title or "Plex KM"))
            self.setProperty("PlexKM.Confirm.Message", _display_text_for_kodi(self.message or ""))
            self.setProperty("PlexKM.Confirm.Yes", _display_text_for_kodi(self.yes_label or "확인"))
            self.setProperty("PlexKM.Confirm.No", _display_text_for_kodi(self.no_label or ""))
            self.setProperty("PlexKM.Confirm.Icon1", self.icon1 or "")
            self.setProperty("PlexKM.Confirm.Icon2", self.icon2 or "")
            self.setProperty("PlexKM.Confirm.HasIcons", "1" if (self.icon1 or self.icon2) else "")
            self.setProperty("PlexKM.Confirm.WindowedVideo", "1" if self.windowed_video else "")
            self.setProperty("PlexKM.Confirm.HasCine21Rows", "1" if self.cine21_rows else "")
            self.setProperty("PlexKM.Confirm.Cine21LogoIcon", self.cine21_logo_icon or "")
            self.setProperty("PlexKM.Confirm.Cine21CriticIcon", self.cine21_critic_icon or "")
            self.setProperty("PlexKM.Confirm.Cine21AudienceIcon", self.cine21_audience_icon or "")
            for idx in range(1, 4):
                row = self.cine21_rows[idx - 1] if idx <= len(self.cine21_rows or []) else {}
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Title" % idx, _display_text_for_kodi(row.get("title") or ""))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Critic" % idx, str(row.get("critic") or "-"))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Audience" % idx, str(row.get("audience") or "-"))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Visible" % idx, "1" if row else "")
            # v2150: Never move button focus from Python during dialog init.
            # The selected XML owns the initial focus.  Destructive reset uses
            # defaultcontrol=301 (아니오), and only a real Left/Right action can
            # move focus to 예.
            default_control_v2150 = 301 if self.default_focus == "no" else 300
            _log("PKM_CONFIRM_XML_FOCUS_OWNER_V2150 defaultcontrol=%d python_focus_write=0 requested=%s yes_label=%s no_label=%s" % (
                default_control_v2150, self.default_focus or "yes",
                self.yes_label or "", self.no_label or "",
            ), xbmc.LOGINFO)
        except Exception:
            _log("PKM_CONFIRM_DIALOG_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.YES_ID:
            if callable(self.yes_prepare):
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Settings.SyncHandoffCoverV1747", "1")
                except Exception:
                    pass
                _start_window_stack_probe_v1747("confirm_to_progress")
                _log_window_stack_v1747("confirm_yes_pressed", "window=13031 sync_handoff_cover=1")
                try:
                    prepared = self.yes_prepare()
                except Exception:
                    _log("PKM_CONFIRM_YES_PREPARE_FAILED_V1747\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                    prepared = False
                if prepared is False:
                    try:
                        xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
                    except Exception:
                        pass
                    _log("PKM_CONFIRM_YES_PREPARE_ABORT_V1747 window=13031", xbmc.LOGWARNING)
                    _log_window_stack_v1747("confirm_yes_prepare_abort", "window=13031 sync_handoff_cover=0")
                    return
                _log("PKM_CONFIRM_YES_PREPARE_READY_V1747 window=13031", xbmc.LOGINFO)
            _log_window_stack_v1747("confirm_close_request", "window=13031 result=1")
            self.result = True
            self.close()
        elif controlId == self.NO_ID:
            self.result = False
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = False
            self.close()



def open_pkm_confirm_dialog(title, message, yes_label="예", no_label="아니요", icon1="", icon2="", cine21_rows=None, cine21_logo_icon="", cine21_critic_icon="", cine21_audience_icon="", windowed_video=False, yes_prepare=None, default_focus=None):
    # v2150: destructive confirmation may explicitly request a safe default
    # on the NO button.  That path must always remain a two-button dialog and
    # uses a dedicated XML with defaultcontrol=301.  Other legacy "취소"
    # one-button dialogs keep their existing behavior.
    requested_default_v2150 = str(default_focus or "").strip().lower()
    force_two_button_v2150 = requested_default_v2150 == "no"
    remove_cancel_button = (str(no_label or "").strip() == "취소") and not force_two_button_v2150
    if force_two_button_v2150:
        dialog_xml = "plexkm_pkm_confirm_no_default_dialog.xml"
    else:
        dialog_xml = "plexkm_pkm_confirm_single_dialog.xml" if remove_cancel_button else "plexkm_pkm_confirm_dialog.xml"
    effective_no_label = "" if remove_cancel_button else no_label
    dlg = None
    try:
        _set_confirm_global_props(title, message, yes_label, effective_no_label, icon1, icon2, cine21_rows, cine21_logo_icon, cine21_critic_icon, cine21_audience_icon, windowed_video)
        dlg = PKMConfirmDialog(
            dialog_xml,
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            title=title,
            message=message,
            yes_label=yes_label,
            no_label=effective_no_label,
            icon1=icon1,
            icon2=icon2,
            cine21_rows=cine21_rows or [],
            cine21_logo_icon=cine21_logo_icon,
            cine21_critic_icon=cine21_critic_icon,
            cine21_audience_icon=cine21_audience_icon,
            windowed_video=windowed_video,
            yes_prepare=yes_prepare,
            default_focus=default_focus,
        )
        dlg.doModal()
        if not dlg.result:
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
        _log_window_stack_v1747("confirm_modal_return", "window=13031 result=%d" % (1 if dlg.result else 0))
        return bool(dlg.result)
    except Exception:
        _log("PKM_CONFIRM_DIALOG_OPEN_FAILED no_kodi_fallback\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
    finally:
        try:
            _clear_confirm_global_props()
        except Exception:
            pass
        try:
            del dlg
        except Exception:
            pass


def open_pkm_message_dialog(title, message, ok_label="확인", icon1="", icon2=""):
    return open_pkm_confirm_dialog(
        title, message, yes_label=ok_label or "확인", no_label="", icon1=icon1, icon2=icon2,
    )


def open_pkm_cine21_match_dialog(title, rows, ok_label="닫기", logo_icon="", critic_icon="", audience_icon=""):
    """PKM-styled Cine21 rating sample popup with inline row icons.

    Data-only input.  No DB work, network work, navigation, or focus-flow logic.
    """
    return open_pkm_confirm_dialog(
        title,
        "",
        yes_label=ok_label or "닫기",
        no_label="",
        cine21_rows=list(rows or [])[:3],
        cine21_logo_icon=logo_icon,
        cine21_critic_icon=critic_icon,
        cine21_audience_icon=audience_icon,
    )


def open_pkm_list_dialog(title, labels, multiselect=False, preselect=None):
    dlg = None
    try:
        dlg = PKMListDialog(
            "plexkm_pkm_list_dialog.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            title=title,
            items=list(labels or []),
            multiselect=multiselect,
            preselect=preselect or [],
        )
        dlg.doModal()
        return dlg.result
    except Exception:
        _log("PKM_SETTINGS_DIALOG_OPEN_FAILED no_kodi_fallback\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass


def addon_get_bool(setting_id, default=False):
    try:
        return ADDON.getSettingBool(setting_id)
    except Exception:
        value = ADDON.getSetting(setting_id)
        if value == "":
            return bool(default)
        return str(value).lower() == "true"


def addon_set_bool(setting_id, value):
    value = bool(value)
    try:
        ADDON.setSettingBool(setting_id, value)
    except Exception:
        ADDON.setSetting(setting_id, "true" if value else "false")


def addon_get_int(setting_id, default=0):
    try:
        return int(ADDON.getSettingInt(setting_id))
    except Exception:
        try:
            return int(ADDON.getSetting(setting_id) or default)
        except Exception:
            return int(default)


def addon_set_int(setting_id, value):
    value = int(value)
    try:
        ADDON.setSettingInt(setting_id, value)
    except Exception:
        ADDON.setSetting(setting_id, str(value))


def mask_secret(value):
    value = value or ""
    if not value:
        return "(비어 있음)"
    if len(value) <= 8:
        return "********"
    return value[:4] + "****" + value[-4:]


def short_setting_value(value, max_len=34):
    value = value or ""
    if not value:
        return "(비어 있음)"
    if len(value) <= max_len:
        return value
    return value[:max_len]


def bool_label(value):
    return "켜짐" if value else "꺼짐"


def pkm_setting_input(label, current, hidden=False):
    return open_pkm_text_input(label, current=current or "", hidden=hidden)


def pkm_setting_number(label, current, minimum=None, maximum=None):
    raw = pkm_setting_input(label, str(current))
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except Exception:
        _notify("숫자만 입력해야 합니다", icon=xbmcgui.NOTIFICATION_WARNING)
        return None
    if minimum is not None:
        value = max(int(minimum), value)
    if maximum is not None:
        value = min(int(maximum), value)
    return value


def pkm_setting_file_browse(title, current_value=""):
    """PKM-only path input; never opens Kodi's native file browser."""
    return pkm_setting_input(title or "파일 경로", str(current_value or ""))


def _plex_db_path_clean_v1700(value):
    text = str(value or "").strip().strip('"')
    if not text:
        return ""
    if "://" in text:
        return text
    try:
        return os.path.normpath(text)
    except Exception:
        return text


def _plex_db_join_v1700(base_path, name):
    base_path = str(base_path or "")
    name = str(name or "").strip("/\\")
    if "://" in base_path or base_path.startswith("special://"):
        return base_path.rstrip("/\\") + "/" + name
    return os.path.join(base_path, name)


def _plex_db_parent_v1700(path, root_path=""):
    path = _plex_db_path_clean_v1700(path)
    root_path = _plex_db_path_clean_v1700(root_path)
    if not path or path == root_path:
        return ""
    if "://" in path or path.startswith("special://"):
        trimmed = path.rstrip("/\\")
        scheme_pos = trimmed.find("://")
        min_pos = scheme_pos + 3 if scheme_pos >= 0 else 0
        slash_pos = trimmed.rfind("/")
        if slash_pos < min_pos:
            return ""
        parent = trimmed[:slash_pos]
        if root_path and len(parent) < len(root_path.rstrip("/\\")):
            return root_path
        return parent
    try:
        parent = os.path.dirname(path.rstrip("/\\"))
        if not parent or parent == path:
            return ""
        if root_path:
            try:
                if os.path.commonpath([os.path.abspath(parent), os.path.abspath(root_path)]) != os.path.abspath(root_path):
                    return root_path
            except Exception:
                pass
        return parent
    except Exception:
        return ""


def _plex_db_read_header_v1700(path):
    path = _plex_db_path_clean_v1700(path)
    if not path:
        return b""
    translated = xbmcvfs.translatePath(path) if path.startswith("special://") else path
    try:
        if os.path.isfile(translated):
            with open(translated, "rb") as fh:
                return fh.read(16)
    except Exception:
        pass
    handle = None
    try:
        handle = xbmcvfs.File(path, "rb")
        data = handle.read(16)
        if isinstance(data, str):
            data = data.encode("latin-1", "ignore")
        return bytes(data or b"")
    except Exception:
        return b""
    finally:
        try:
            if handle:
                handle.close()
        except Exception:
            pass


def _validate_plex_db_path_v1700(path, notify=True):
    path = _plex_db_path_clean_v1700(path)
    if not path:
        return False
    if not path.lower().split("?", 1)[0].endswith(".db"):
        if notify:
            _notify(".db 파일을 선택해야 합니다", icon=xbmcgui.NOTIFICATION_WARNING)
        return False
    header = _plex_db_read_header_v1700(path)
    if not header.startswith(b"SQLite format 3"):
        if notify:
            _notify("Plex DB 파일을 읽을 수 없습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4500)
        _log("PKM_PLEX_DB_VALIDATE_FAIL_V1700 path=%s header=%s" % (path, repr(header[:16])), xbmc.LOGWARNING)
        return False
    _log("PKM_PLEX_DB_VALIDATE_OK_V1700 path=%s remote=%s" % (path, "1" if "://" in path else "0"), xbmc.LOGINFO)
    return True


def _windows_drive_roots_v1700():
    rows = []
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            path = letter + ":\\"
            try:
                if os.path.exists(path):
                    rows.append(("%s 드라이브" % letter, path))
            except Exception:
                pass
    return rows


def _local_storage_roots_v1700():
    rows = _windows_drive_roots_v1700()
    candidates = [
        ("Kodi 홈 폴더", "special://home/"),
        ("Kodi 프로필 폴더", "special://profile/"),
        ("Android 내부 저장소", "/storage/emulated/0"),
        ("Android 저장소", "/storage"),
    ]
    seen = set(path for _, path in rows)
    for label, path in candidates:
        try:
            translated = xbmcvfs.translatePath(path) if path.startswith("special://") else path
            exists = bool(xbmcvfs.exists(path) or os.path.exists(translated))
        except Exception:
            exists = False
        if exists and path not in seen:
            rows.append((label, path))
            seen.add(path)
    return rows


def _kodi_file_sources_v1700():
    result = []
    seen = set()
    source_file = xbmcvfs.translatePath("special://profile/sources.xml")
    try:
        root = ET.parse(source_file).getroot()
        for section_name in ("files", "video", "music", "pictures"):
            section = root.find(section_name)
            if section is None:
                continue
            for source in section.findall("source"):
                name = (source.findtext("name") or "Kodi 소스").strip()
                paths = source.findall("path")
                for path_node in paths:
                    path = (path_node.text or "").strip()
                    if not path or path in seen:
                        continue
                    if "://" not in path and not path.startswith("special://"):
                        continue
                    result.append((name, path))
                    seen.add(path)
    except Exception:
        _log("PKM_KODI_SOURCES_READ_FAIL_V1700 path=%s err=%s" % (source_file, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
    return result


def _plex_db_list_directory_v1700(path):
    path = _plex_db_path_clean_v1700(path)
    dirs, files = xbmcvfs.listdir(path)
    out = []
    for name in sorted([str(x or "").rstrip("/\\") for x in dirs or [] if str(x or "").strip()], key=lambda x: x.lower()):
        out.append({"kind": "dir", "name": name, "path": _plex_db_join_v1700(path, name)})
    for name in sorted([str(x or "").rstrip("/\\") for x in files or [] if str(x or "").lower().endswith(".db")], key=lambda x: x.lower()):
        out.append({"kind": "file", "name": name, "path": _plex_db_join_v1700(path, name)})
    return out


def _live_plex_addon_targets_v1922():
    targets = []
    candidates = [ADDON, getattr(_core(), "ADDON", None)]
    for module_name in ("resources.lib.pkm_token_import", "pkm_token_import"):
        try:
            candidates.append(getattr(sys.modules.get(module_name), "ADDON", None))
        except Exception:
            pass
    for candidate in candidates:
        if candidate is not None and all(candidate is not existing for existing in targets):
            targets.append(candidate)
    return targets


def _publish_live_plex_settings_v1922(server=None, token=None, account=None, reason=""):
    """Publish one authoritative URL/token set to every live wrapper and Home."""
    server = (ADDON.getSetting("plex_url") or "").strip() if server is None else str(server or "").strip()
    token = (ADDON.getSetting("plex_token") or "").strip() if token is None else str(token or "").strip()
    account = (ADDON.getSetting("plex_account_name") or "").strip() if account is None else str(account or "").strip()
    verified = True
    targets = _live_plex_addon_targets_v1922()
    for target in targets:
        try:
            target.setSetting("plex_url", server)
            target.setSetting("plex_token", token)
            target.setSetting("plex_account_name", account)
        except Exception:
            verified = False
    try:
        runtime = xbmcgui.Window(10000)
        runtime.setProperty("PlexKM.Runtime.PlexURL", server)
        runtime.setProperty("PlexKM.Runtime.PlexToken", token)
        runtime.setProperty("PlexKM.Runtime.PlexAccount", account)
        runtime.setProperty("PlexKM.Runtime.PlexAuthAuthoritative", "1")
    except Exception:
        verified = False
    _log("PKM_PLEX_RUNTIME_AUTHORITATIVE_V1922 reason=%s server=%s token=%s targets=%d verified=%s" % (
        str(reason or ""), "1" if server else "0", "1" if token else "0", len(targets), "1" if verified else "0"
    ), xbmc.LOGINFO if verified else xbmc.LOGWARNING)
    return verified


def _probe_candidate_plex_url_v1922(server):
    try:
        if not pkm_plex_client or not hasattr(pkm_plex_client, "probe_server_identity_explicit"):
            raise RuntimeError("explicit Plex identity probe is unavailable")
        pkm_plex_client.probe_server_identity_explicit(server, timeout=3.5, env=_settings_plex_client_env())
        _log("PKM_PLEX_URL_CANDIDATE_OK_V1922 server=%s" % str(server or ""), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log("PKM_PLEX_URL_CANDIDATE_REJECT_V1922 server=%s err=%s" % (str(server or ""), str(exc)), xbmc.LOGWARNING)
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                token = pkm_notify.pkm_notice_set(
                    "Plex 서버에 연결할 수 없습니다",
                    "주소와 포트를 확인해주세요",
                    "",
                    sticky=False,
                    force_replace=True,
                )
                if hasattr(pkm_notify, "pkm_notice_clear_later"):
                    pkm_notify.pkm_notice_clear_later(token, ms=5200)
        except Exception:
            pass
        return False


def _reset_plex_connection_v1922():
    """Clear only Plex server/authentication values; preserve PKM DB and library data."""
    try:
        for target in _live_plex_addon_targets_v1922():
            for key in ("plex_url", "plex_token", "plex_account_name", "plex_url_history"):
                try:
                    target.setSetting(key, "")
                except Exception:
                    pass
        _publish_live_plex_settings_v1922(server="", token="", account="", reason="connection_reset_v1997")

        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Settings.ServerSwitchPendingV1310",
            "PlexKM.Settings.ServerSwitchPendingReasonV1310",
            "PlexKM.Home.ServerSwitchPending",
            "PlexKM.Home.ServerSwitchPendingLine1",
            "PlexKM.Home.ServerSwitchPendingLine2",
            "PlexKM.Home.ServerSwitchPendingReason",
            "PlexKM.Home.ServerSwitchPendingAt",
            "PlexKM.PlexOffline",
            "PlexKM.PlexOfflineReason",
            "PlexKM.PlexOfflineLine1",
            "PlexKM.PlexOfflineLine2",
            "PlexKM.PlexOfflineAt",
        ):
            try:
                win.clearProperty(key)
            except Exception:
                pass
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear"):
                pkm_notify.pkm_notice_clear(force=True)
        except Exception:
            pass
        # v2013: the Home WindowXML remains alive behind the settings modal.
        # Rebuild its empty connection-reset surface immediately so the menu
        # selection is normalized to Home before the modal is closed.
        # This uses the existing live-home purge path; it does not delete the
        # preserved PKM database or library metadata.
        _signal_home_refresh_from_settings(reason="plex_connection_reset_full_v2005")
        try:
            win.setProperty("PlexKM.Home.ConnectionResetReturnV2013", "1")
        except Exception:
            pass
        _log("PKM_PLEX_CONNECTION_ONLY_RESET_DONE home_refresh=1 db_preserved=1", xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_PLEX_CONNECTION_ONLY_RESET_FAILED_V1997 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return False

def _clear_plex_connection_state(reason="settings_probe_ok"):
    """Clear sticky Plex offline/connection notice after a confirmed settings probe."""
    cleared_notice = False
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear_if_title"):
            cleared_notice = bool(pkm_notify.pkm_notice_clear_if_title(["Plex 연결 실패", "Plex 연결 확인 중"], force=True))
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Notify.Title") in ("Plex 연결 실패", "Plex 연결 확인 중"):
            for key in ("PlexKM.Notify.Active", "PlexKM.Notify.Title", "PlexKM.Notify.Line1", "PlexKM.Notify.Line2", "PlexKM.Notify.Token", "PlexKM.Notify.Sticky"):
                win.clearProperty(key)
            cleared_notice = True
        for key in ("PlexKM.PlexOffline", "PlexKM.PlexOfflineReason", "PlexKM.PlexOfflineLine1", "PlexKM.PlexOfflineLine2", "PlexKM.PlexOfflineAt"):
            win.clearProperty(key)
    except Exception:
        pass
    _log("PKM_SETTINGS_PLEX_NOTICE_CLEAR_V1310 reason=%s cleared=%s" % (str(reason or ""), "1" if cleared_notice else "0"), xbmc.LOGINFO)
    return True


def _settings_plex_client_env():
    return {
        "addon": ADDON,
        "addon_name": ADDON_NAME,
        "log": _log,
        "pkm_notice_set": getattr(pkm_notify, "pkm_notice_set", None) if pkm_notify else None,
        "pkm_notice_clear": getattr(pkm_notify, "pkm_notice_clear", None) if pkm_notify else None,
        "pkm_notice_clear_later": getattr(pkm_notify, "pkm_notice_clear_later", None) if pkm_notify else None,
        "pkm_notice_clear_if_title": getattr(pkm_notify, "pkm_notice_clear_if_title", None) if pkm_notify else None,
        "pkm_show_notice": getattr(pkm_notify, "pkm_show_notice", None) if pkm_notify else None,
    }


def _server_host_key_v1310(url):
    try:
        text = str(url or "").strip()
        if not text:
            return ""
        if "://" not in text:
            text = "http://" + text
        parsed = urlparse(text)
        host = (getattr(parsed, "netloc", "") or "").strip().lower()
        if "@" in host:
            host = host.rsplit("@", 1)[-1]
        return host.rstrip("/")
    except Exception:
        return ""


def _current_server_identity_v1310():
    try:
        server = (ADDON.getSetting("plex_url") or "").strip().rstrip("/")
        token = (ADDON.getSetting("plex_token") or "").strip()
        host = _server_host_key_v1310(server)
        if not server or not token or not host:
            return {}
        sig = hashlib.sha1(("v1310|%s|%s" % (host, token)).encode("utf-8")).hexdigest()
        return {"signature": sig, "server_url": server, "server_host": host}
    except Exception:
        return {}


def _save_current_server_identity_v1310(core=None, reason=""):
    try:
        info = _current_server_identity_v1310()
        if not info:
            return False
        core = core or _core()
        state = core.load_state() if core and hasattr(core, "load_state") else {}
        if not isinstance(state, dict):
            state = {}
        state["plex_server_signature_v1310"] = info.get("signature", "")
        state["plex_server_url_v1310"] = info.get("server_url", "")
        state["plex_server_host_v1310"] = info.get("server_host", "")
        state["plex_server_identity_saved_at_v1310"] = int(time.time())
        state["plex_server_identity_reason_v1310"] = str(reason or "")
        if core and hasattr(core, "save_state"):
            core.save_state(state)
            _log("PKM_SETTINGS_SERVER_IDENTITY_SAVE_V1310 reason=%s host=%s sig=%s" % (str(reason or ""), info.get("server_host", ""), (info.get("signature", "")[:10] if info.get("signature") else "")), xbmc.LOGINFO)
            return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_IDENTITY_SAVE_FAILED_V1310 reason=%s err=%s" % (str(reason or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
    return False


def _clear_server_switch_side_files_v1310(reason=""):
    removed = []
    try:
        base = ADDON.getAddonInfo("profile")
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        for name in ("playstate_continue_preload.json", "playstate_resume.json", "large_wall_focus_state.json"):
            path = os.path.join(base, name)
            try:
                if path and os.path.exists(path):
                    os.remove(path)
                    removed.append(name)
            except Exception:
                pass
    except Exception:
        pass
    _log("PKM_SETTINGS_SERVER_SWITCH_SIDE_FILES_CLEAR_V1310 reason=%s removed=%s" % (str(reason or ""), ",".join(removed)), xbmc.LOGINFO)
    return removed


def _signal_home_refresh_from_settings(reason="settings_plex_connected_v1310"):
    try:
        core = _core()
        if core and hasattr(core, "_signal_home_data_refresh"):
            core._signal_home_data_refresh(reason=reason)
            return True
    except Exception:
        pass
    try:
        token = "%d" % int(time.time() * 1000)
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.DataRefreshToken", token)
        win.setProperty("PlexKM.Home.DataRefreshReason", str(reason or "settings_plex_connected_v1310"))
        _log("HOME_DATA_REFRESH_SIGNAL reason=%s token=%s" % (str(reason or ""), token), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _set_server_switch_pending_v1310(value=True, reason=""):
    try:
        win = xbmcgui.Window(10000)
        if value:
            win.setProperty("PlexKM.Settings.ServerSwitchPendingV1310", "1")
            win.setProperty("PlexKM.Settings.ServerSwitchPendingReasonV1310", str(reason or "url_changed"))
            _set_server_switch_pending_home_ui_v1310(
                "Plex 서버 연결 확인 중",
                "라이브러리 정보를 확인합니다",
                reason=reason or "url_changed",
            )
        else:
            win.clearProperty("PlexKM.Settings.ServerSwitchPendingV1310")
            win.clearProperty("PlexKM.Settings.ServerSwitchPendingReasonV1310")
        _log("PKM_SETTINGS_SERVER_SWITCH_PENDING_V1310 value=%s reason=%s" % ("1" if value else "0", str(reason or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _server_switch_pending_v1310():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.Settings.ServerSwitchPendingV1310") == "1"
    except Exception:
        return False


def _set_server_switch_pending_home_ui_v1310(line1="Plex 서버 연결 확인 중", line2="라이브러리 정보를 확인합니다", reason=""):
    """Hide stale Home widgets as soon as the server/token is changed.

    The DB may still contain the previous server until the new server is fully
    validated and synced.  Keep old widgets hidden, but do not draw a large
    blank-screen text overlay; status is shown only through the PKM notice.
    """
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.ServerSwitchPending", "1")
        win.setProperty("PlexKM.Home.ServerSwitchPendingLine1", _display_text_for_kodi(line1 or "Plex 서버 연결 확인 중"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingLine2", _display_text_for_kodi(line2 or "라이브러리 정보를 확인합니다"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingReason", str(reason or "settings_server_switch_pending_v1310"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingAt", str(int(time.time() * 1000)))
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                pkm_notify.pkm_notice_set(
                    "Plex 연결 확인 중",
                    _display_text_for_kodi(line1 or "Plex 서버 연결 확인 중"),
                    "라이브러리 정보를 확인합니다",
                    sticky=True,
                    force_replace=True,
                )
        except Exception:
            pass
        # v1312: do not use Kodi native toast here. The PKM XML overlay is
        # drawn inside the settings dialog so the notice style matches Home.
        _signal_home_refresh_from_settings(reason="settings_server_switch_pending_v1310")
        _log("PKM_SETTINGS_SERVER_SWITCH_NOTICE_ONLY_PENDING_V1310 reason=%s line1=%s" % (str(reason or ""), _display_text_for_kodi(line1 or "")), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_HOME_PENDING_FAILED_V1310 reason=%s err=%s" % (str(reason or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        return False


def _clear_server_switch_pending_home_ui_v1310(reason=""):
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Home.ServerSwitchPending",
            "PlexKM.Home.ServerSwitchPendingLine1",
            "PlexKM.Home.ServerSwitchPendingLine2",
            "PlexKM.Home.ServerSwitchPendingReason",
            "PlexKM.Home.ServerSwitchPendingAt",
        ):
            win.clearProperty(key)
        _log("PKM_SETTINGS_SERVER_SWITCH_HOME_PENDING_CLEAR_V1310 reason=%s" % (str(reason or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _reset_sidebar_order_file_v1310(section_ids):
    try:
        base = ADDON.getAddonInfo("profile")
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        if base and not os.path.isdir(base):
            os.makedirs(base, exist_ok=True)
        path = os.path.join(base, "sidebar_order.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"version": 1, "section_order": [str(x) for x in (section_ids or []) if str(x)]}, f, ensure_ascii=False, indent=2)
        _log("PKM_SETTINGS_SERVER_SWITCH_SIDEBAR_ORDER_RESET_V1310 count=%d path=%s" % (len(section_ids or []), path), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SIDEBAR_ORDER_RESET_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return False


def _clear_server_cache_tables_v1310(core):
    removed = {}
    try:
        conn = core.init_db()
        try:
            for table in (
                "items", "sections", "sync_state",
                "item_people", "item_genres", "item_countries", "item_ratings", "item_studios", "item_recommend_index_state",
                "cine21_matches", "cine21_match_summary"
            ):
                try:
                    cur = conn.execute("DELETE FROM %s" % table)
                    removed[table] = int(getattr(cur, "rowcount", 0) or 0)
                except Exception:
                    removed[table] = -1
            conn.commit()
        finally:
            conn.close()
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_CACHE_CLEAR_FAILED_V1310 main err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        if hasattr(core, "search_db_path"):
            sconn = sqlite3.connect(core.search_db_path(), timeout=8.0)
            try:
                if hasattr(core, "init_search_db"):
                    core.init_search_db(sconn)
                try:
                    sconn.execute("DELETE FROM search_items")
                except Exception:
                    pass
                try:
                    sconn.execute("UPDATE search_index_state SET source_count=0, search_count=0, source_max_synced_at=0, indexed_at=?, last_error='' WHERE id=1", (int(time.time()),))
                except Exception:
                    pass
                sconn.commit()
            finally:
                sconn.close()
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SEARCH_CLEAR_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        _clear_server_switch_side_files_v1310(reason="server_cache_clear_v1310")
    except Exception:
        pass
    _log("PKM_SETTINGS_SERVER_SWITCH_CACHE_CLEAR_V1310 removed=%s" % ",".join(["%s:%s" % (k, removed.get(k)) for k in sorted(removed.keys())]), xbmc.LOGINFO)
    return True


def _write_remote_sections_v1310(core, sections):
    count = 0
    conn = core.init_db()
    try:
        for section in sections or []:
            try:
                if hasattr(core, "upsert_section"):
                    core.upsert_section(conn, section)
                else:
                    conn.execute(
                        "INSERT OR REPLACE INTO sections(section_id,title,section_type,thumb,art,scanned_at,item_count) VALUES(?,?,?,?,?,?,?)",
                        (str(section.get("section_id", "")), section.get("title", ""), section.get("section_type", ""), section.get("thumb", ""), section.get("art", ""), int(section.get("scanned_at", 0) or 0), int(section.get("item_count", 0) or 0))
                    )
                count += 1
            except Exception:
                pass
        conn.commit()
    finally:
        conn.close()
    _log("PKM_SETTINGS_SERVER_SWITCH_SECTIONS_WRITE_V1310 count=%d" % count, xbmc.LOGINFO)
    return count


def _reset_selection_for_server_sections_v1310(core, sections, reason="server_switch_v1310"):
    section_ids = [str(s.get("section_id", "")) for s in (sections or []) if str(s.get("section_id", ""))]
    default_ids = section_ids[:min(3, len(section_ids))]
    try:
        state = core.load_state() if hasattr(core, "load_state") else {}
        if not isinstance(state, dict):
            state = {}
        state["section_order"] = list(section_ids)
        state["section_order_updated_at"] = int(time.time())
        state["selected_sections"] = list(default_ids)
        state["selected_sections_configured"] = True
        state["selected_sections_updated_at"] = int(time.time())
        state["selected_sections_bootstrap_reason"] = str(reason or "server_switch_v1310")
        state["server_switch_reset_v1310_at"] = int(time.time())
        try:
            ident = _current_server_identity_v1310()
            if ident:
                state["plex_server_signature_v1310"] = ident.get("signature", "")
                state["plex_server_url_v1310"] = ident.get("server_url", "")
                state["plex_server_host_v1310"] = ident.get("server_host", "")
                state["plex_server_identity_saved_at_v1310"] = int(time.time())
                state["plex_server_identity_reason_v1310"] = str(reason or "server_switch_v1310")
        except Exception:
            pass
        if hasattr(core, "save_state"):
            core.save_state(state)
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_STATE_SAVE_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        if hasattr(core, "set_initial_sync_done"):
            core.set_initial_sync_done(False)
    except Exception:
        pass
    try:
        if hasattr(core, "set_last_auto_sync_at"):
            core.set_last_auto_sync_at(0)
    except Exception:
        pass
    _reset_sidebar_order_file_v1310(section_ids)
    _log("PKM_SETTINGS_SERVER_SWITCH_SELECTION_RESET_V1310 sections=%d default_selected=%s" % (len(section_ids), ",".join(default_ids)), xbmc.LOGINFO)
    return default_ids


def _apply_server_switch_reset_v1310(remote_sections, reason="settings_probe_ok_v1310"):
    core = _core()
    if not core:
        _log("PKM_SETTINGS_SERVER_SWITCH_RESET_SKIP_V1310 reason=no_core", xbmc.LOGWARNING)
        return []
    remote_sections = list(remote_sections or [])
    if not remote_sections:
        _log("PKM_SETTINGS_SERVER_SWITCH_RESET_SKIP_V1310 reason=no_sections", xbmc.LOGWARNING)
        return []
    _clear_server_cache_tables_v1310(core)
    _write_remote_sections_v1310(core, remote_sections)
    default_ids = _reset_selection_for_server_sections_v1310(core, remote_sections, reason=reason)
    try:
        if default_ids and hasattr(core, "sync_all_sections"):
            notice_token = ""
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    notice_token = pkm_notify.pkm_notice_set(
                        "PKM 업데이트 중",
                        "라이브러리 0/%d 준비 중" % len(default_ids),
                        "라이브러리 싱크 중",
                        sticky=True,
                        force_replace=True,
                    )
                    _log("PKM_SETTINGS_INITIAL_SYNC_NOTICE_SET_V1311 token=%s sections=%s" % (str(notice_token or ""), ",".join(default_ids)), xbmc.LOGINFO)
            except Exception:
                pass
            _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_BEGIN_V1310 sections=%s" % ",".join(default_ids), xbmc.LOGINFO)
            fetched = core.sync_all_sections(show_prompt=False, show_progress=False, mark_auto_sync=True, section_ids=default_ids, progress_title="라이브러리 싱크")
            _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_DONE_V1310 sections=%s fetched=%s" % (",".join(default_ids), str(fetched)), xbmc.LOGINFO)
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    done_token = pkm_notify.pkm_notice_set(
                        "PKM 업데이트 완료",
                        "라이브러리 %d개 싱크 완료" % len(default_ids),
                        "홈 위젯 갱신 중",
                        sticky=False,
                        force_replace=True,
                    )
                    if hasattr(pkm_notify, "pkm_notice_clear_later"):
                        pkm_notify.pkm_notice_clear_later(done_token, ms=1800)
            except Exception:
                pass
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                pkm_notify.pkm_notice_set("PKM 업데이트 실패", "라이브러리 싱크 실패", "Plex 서버 상태를 확인해주세요", sticky=True, force_replace=True)
        except Exception:
            pass
        return []
    return default_ids


def _show_plex_connected_notice_v1310(line2="홈 위젯을 갱신합니다"):
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            notice_token = pkm_notify.pkm_notice_set("Plex 연결됨", "Plex 서버 연결 확인 완료", line2, sticky=False, force_replace=True)
            _log("PKM_SETTINGS_PLEX_CONNECTED_NOTICE_SET_V1310 token=%s line2=%s" % (str(notice_token or ""), _display_text_for_kodi(line2 or "")), xbmc.LOGINFO)
            if hasattr(pkm_notify, "pkm_notice_clear_later"):
                pkm_notify.pkm_notice_clear_later(notice_token, ms=7200)
    except Exception:
        _log("PKM_SETTINGS_PLEX_CONNECTED_NOTICE_SET_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    # v1312: PKM XML overlay only; no Kodi native text-only toast.


def _show_plex_library_probe_failed_v1310(exc, reason="settings_probe_sections_fail_v1310"):
    msg = str(exc or "")
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.PlexOffline", "1")
        win.setProperty("PlexKM.PlexOfflineReason", str(reason or "settings_sections_probe_fail_v1310"))
        win.setProperty("PlexKM.PlexOfflineLine1", "Plex 라이브러리 접근 실패")
        win.setProperty("PlexKM.PlexOfflineLine2", "주소/포트/토큰을 확인해주세요")
        win.setProperty("PlexKM.PlexOfflineAt", str(int(time.time())))
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 라이브러리 접근 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
    except Exception:
        pass
    try:
        _set_server_switch_pending_home_ui_v1310("Plex 라이브러리 접근 실패", "주소/포트/토큰 확인 후 다시 저장해주세요", reason=reason or "settings_sections_probe_fail_v1310")
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 라이브러리 접근 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
            _log("PKM_SETTINGS_PLEX_FAIL_NOTICE_RESTORE_V1312 type=library", xbmc.LOGINFO)
    except Exception:
        pass
    # v1312: PKM XML overlay only; no Kodi native text-only toast.
    _log("PKM_SETTINGS_PLEX_LIBRARY_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), msg), xbmc.LOGWARNING)


def _show_plex_connection_probe_failed_v1310(exc, reason="settings_identity_probe_fail_v1310"):
    msg = str(exc or "")
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.PlexOffline", "1")
        win.setProperty("PlexKM.PlexOfflineReason", str(reason or "settings_identity_probe_fail_v1310"))
        win.setProperty("PlexKM.PlexOfflineLine1", "Plex 서버 연결 실패")
        win.setProperty("PlexKM.PlexOfflineLine2", "주소/포트/토큰을 확인해주세요")
        win.setProperty("PlexKM.PlexOfflineAt", str(int(time.time())))
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 서버 연결 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
    except Exception:
        pass
    try:
        _set_server_switch_pending_home_ui_v1310("Plex 서버 연결 실패", "주소/포트/토큰 확인 후 다시 저장해주세요", reason=reason or "settings_identity_probe_fail_v1310")
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 서버 연결 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
            _log("PKM_SETTINGS_PLEX_FAIL_NOTICE_RESTORE_V1312 type=identity", xbmc.LOGINFO)
    except Exception:
        pass
    # v1312: PKM XML overlay only; no Kodi native text-only toast.
    _log("PKM_SETTINGS_PLEX_CONNECTION_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), msg), xbmc.LOGWARNING)



def _normalize_plex_server_url_v1313(value):
    """Normalize the user-entered Plex server URL without dropping the port."""
    text = str(value or "").strip()
    if not text:
        return ""
    if "://" not in text:
        text = "http://" + text
    # Keep host:port exactly as entered, but remove trailing slash/path spaces.
    return text.rstrip("/")



def _show_plex_endpoint_error_v1730(line1, line2=""):
    """Show a PKM-owned address/port validation notice without opening Kodi UI."""
    title = "Plex 서버 주소 오류"
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set(title, str(line1 or ""), str(line2 or ""), sticky=False, force_replace=True)
            return
    except Exception:
        pass
    try:
        xbmcgui.Dialog().notification(title, str(line1 or ""), xbmcgui.NOTIFICATION_WARNING, 3500)
    except Exception:
        pass


def _split_plex_server_endpoint_v1730(value, default_port="32400"):
    """Return (address_without_port, port) for the split inline editor.

    Missing ports are shown as the editable default only.  This helper never
    writes the default back to settings; the user must confirm the split form.
    """
    text = str(value or "").strip().rstrip("/")
    if not text:
        return "", str(default_port or "32400")
    parse_text = text if "://" in text else "http://" + text
    try:
        parsed = urlparse(parse_text)
        host = str(parsed.hostname or "").strip()
        if not host:
            return text, str(default_port or "32400")
        try:
            port = str(parsed.port) if parsed.port is not None else str(default_port or "32400")
        except Exception:
            port = ""
        host_display = ("[" + host + "]") if (":" in host and not host.startswith("[")) else host
        address = "%s://%s" % (str(parsed.scheme or "http").lower(), host_display)
        path = str(parsed.path or "").rstrip("/")
        if path:
            address += path
        return address, port
    except Exception:
        return text, str(default_port or "32400")


def _combine_plex_server_endpoint_v1730(address, port, notify=True):
    """Validate split fields and build one explicit PMS endpoint."""
    raw_address = str(address or "").strip().rstrip("/")
    raw_port = str(port or "").strip()
    if not raw_address:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소를 입력해주세요", "주소 입력칸을 확인해주세요")
        return "", "address"
    if not raw_port:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트가 없습니다", "포트 입력칸을 확인해주세요")
        return "", "port"
    if not raw_port.isdigit():
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트가 올바르지 않습니다", "숫자 포트를 입력해주세요")
        return "", "port"
    port_num = int(raw_port)
    if port_num < 1 or port_num > 65535:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트 범위가 올바르지 않습니다", "1부터 65535 사이로 입력해주세요")
        return "", "port"

    parse_text = raw_address if "://" in raw_address else "http://" + raw_address
    try:
        parsed = urlparse(parse_text)
        scheme = str(parsed.scheme or "http").lower()
        if scheme not in ("http", "https"):
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "http:// 또는 https:// 주소를 입력해주세요")
            return "", "address"
        if parsed.username or parsed.password:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "사용자 정보가 없는 서버 주소를 입력해주세요")
            return "", "address"
        try:
            embedded_port = parsed.port
        except Exception:
            embedded_port = -1
        if embedded_port is not None:
            if notify:
                _show_plex_endpoint_error_v1730("포트가 주소 입력칸에 포함되어 있습니다", "포트는 오른쪽 포트 입력칸에 입력해주세요")
            return "", "address"
        host = str(parsed.hostname or "").strip()
        if not host:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "서버 호스트 주소를 확인해주세요")
            return "", "address"
        if parsed.query or parsed.fragment:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "쿼리나 앵커를 제거해주세요")
            return "", "address"
        host_display = ("[" + host + "]") if (":" in host and not host.startswith("[")) else host
        path = str(parsed.path or "").rstrip("/")
        return "%s://%s:%d%s" % (scheme, host_display, port_num, path), ""
    except Exception:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "주소와 포트를 확인해주세요")
        return "", "address"


def _validate_saved_plex_endpoint_v1730(value, notify=True):
    """Require an explicit valid port before Plex link authentication starts."""
    text = str(value or "").strip().rstrip("/")
    if not text:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소를 먼저 입력해주세요", "서버 주소와 포트를 저장한 후 인증해주세요")
        return False
    parse_text = text if "://" in text else "http://" + text
    try:
        parsed = urlparse(parse_text)
        if not parsed.hostname:
            raise ValueError("missing host")
        port = parsed.port
        if port is None:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 포트가 없습니다", "서버 주소에서 포트를 설정한 후 인증해주세요")
            return False
        if int(port) < 1 or int(port) > 65535:
            raise ValueError("port range")
        if str(parsed.scheme or "").lower() not in ("http", "https"):
            raise ValueError("scheme")
        return True
    except ValueError as exc:
        if "missing host" in str(exc):
            line1, line2 = "Plex 서버 주소가 올바르지 않습니다", "서버 주소를 다시 입력해주세요"
        elif "port range" in str(exc):
            line1, line2 = "Plex 서버 포트 범위가 올바르지 않습니다", "1부터 65535 사이로 입력해주세요"
        elif "scheme" in str(exc):
            line1, line2 = "Plex 서버 주소 형식이 올바르지 않습니다", "http:// 또는 https:// 주소를 입력해주세요"
        else:
            line1, line2 = "Plex 서버 포트가 올바르지 않습니다", "주소와 포트를 다시 입력해주세요"
        if notify:
            _show_plex_endpoint_error_v1730(line1, line2)
        return False
    except Exception:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소가 올바르지 않습니다", "주소와 포트를 다시 입력해주세요")
        return False


def _fetch_remote_sections_direct_v1313(reason="settings_probe_sections_v1313"):
    """Probe /library/sections through the same settings Plex client/env used for /identity.

    v1312 called default.py fetch_sections() after /identity.  In settings-dialog
    RunScript mode that path could still use an older/cached server URL and drop
    the :32400 port, producing a false library failure even though the dialog
    displayed the corrected URL.  This direct probe keeps identity and sections
    on the same freshly saved server setting.
    """
    sections = []
    server = _normalize_plex_server_url_v1313(ADDON.getSetting("plex_url") or "")
    try:
        ADDON.setSetting("plex_url", server)
    except Exception:
        pass
    try:
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_V1313 reason=%s server=%s" % (str(reason or ""), server), xbmc.LOGINFO)
        root = pkm_plex_client.plex_request_xml("/library/sections", timeout=20, log_failures=False, env=_settings_plex_client_env())
        now = int(time.time())
        for d in list(root):
            try:
                if getattr(d, "tag", "") != "Directory":
                    continue
                section_type = d.get("type", "")
                if section_type not in ("movie", "show"):
                    continue
                section_updated_at = 0
                try:
                    section_updated_at = int(d.get("updatedAt", "0") or 0)
                except Exception:
                    section_updated_at = 0
                if not section_updated_at:
                    section_updated_at = now
                sections.append({
                    "section_id": d.get("key", ""),
                    "title": d.get("title", ""),
                    "section_type": section_type,
                    "thumb": d.get("thumb", "") or "",
                    "art": d.get("art", "") or "",
                    "scanned_at": section_updated_at,
                    "updated_at": section_updated_at,
                    "item_count": 0,
                })
            except Exception:
                pass
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_OK_V1313 sections=%d server=%s" % (len(sections), server), xbmc.LOGINFO)
        return sections
    except Exception:
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_FAIL_V1313 server=%s err=%s" % (server, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        raise

def _probe_plex_after_connection_setting(reason="settings_plex_connection_changed_v1310", server_changed=False):
    """Probe new Plex URL/token and refresh Home without Kodi restart.

    v1310 verifies both /identity and /library/sections.  The old v1306 path
    declared success after /identity only, so a server/proxy that accepted
    identity but refused library access could clear the error notice while Home
    still showed old cached widgets.
    """
    try:
        server = (ADDON.getSetting("plex_url") or "").strip()
        token = (ADDON.getSetting("plex_token") or "").strip()
        if not server or not token:
            _log("PKM_SETTINGS_PLEX_PROBE_SKIP_V1310 reason=%s server=%s token=%s" % (str(reason or ""), "1" if server else "0", "1" if token else "0"), xbmc.LOGINFO)
            return False
    except Exception:
        return False

    pending_server_switch = bool(server_changed or _server_switch_pending_v1310())

    def _worker():
        try:
            if not pkm_plex_client:
                _log("PKM_SETTINGS_PLEX_PROBE_SKIP_V1310 reason=module_missing", xbmc.LOGWARNING)
                return
            _log("PKM_SETTINGS_PLEX_PROBE_BEGIN_V1310 reason=%s path=/identity timeout=3.50 server_switch=%s" % (str(reason or ""), "1" if pending_server_switch else "0"), xbmc.LOGINFO)
            try:
                pkm_plex_client.plex_request_xml("/identity", timeout=3.5, log_failures=False, env=_settings_plex_client_env())
            except Exception as identity_exc:
                _show_plex_connection_probe_failed_v1310(identity_exc)
                return

            core = _core()
            remote_sections = []
            try:
                _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_BEGIN_V1313 path=/library/sections timeout=20 mode=direct_same_client", xbmc.LOGINFO)
                remote_sections = list(_fetch_remote_sections_direct_v1313(reason=reason or "settings_probe_sections_v1313") or [])
            except Exception as section_exc:
                _show_plex_library_probe_failed_v1310(section_exc)
                return
            if not remote_sections:
                _show_plex_library_probe_failed_v1310("no movie/show sections")
                return
            _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_OK_V1313 sections=%d" % len(remote_sections), xbmc.LOGINFO)

            _clear_plex_connection_state(reason="settings_probe_ok_v1310")
            default_ids = []
            if pending_server_switch:
                default_ids = _apply_server_switch_reset_v1310(remote_sections, reason="server_switch_v1310")
                if not default_ids:
                    _log("PKM_SETTINGS_PLEX_PROBE_WAIT_SYNC_V1311 reason=%s" % str(reason or ""), xbmc.LOGWARNING)
                    return
                _set_server_switch_pending_v1310(False, reason="probe_ok_reset_done")
                _clear_server_switch_pending_home_ui_v1310(reason="probe_ok_reset_done")
            else:
                _clear_server_switch_pending_home_ui_v1310(reason="probe_ok_no_server_switch")
                _save_current_server_identity_v1310(core, reason="probe_ok_no_server_switch_v1310")
            _show_plex_connected_notice_v1310("라이브러리 %d개 싱크 완료" % len(default_ids) if default_ids else "홈 위젯을 갱신합니다")
            _signal_home_refresh_from_settings(reason="settings_plex_connected_v1310")
            _log("PKM_SETTINGS_PLEX_PROBE_OK_V1313 reason=%s server_switch=%s default_selected=%s" % (str(reason or ""), "1" if pending_server_switch else "0", ",".join(default_ids)), xbmc.LOGINFO)
        except Exception as exc:
            _log("PKM_SETTINGS_PLEX_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), str(exc)), xbmc.LOGWARNING)

    try:
        t = threading.Thread(target=_worker, name="PKMSettingsPlexProbeV1310", daemon=True)
        t.daemon = True
        t.start()
        return True
    except Exception:
        return False



class PKMSettingsFlowDialog(xbmcgui.WindowXMLDialog):
    """Single PKM settings dialog with in-place page navigation."""
    LIST_ID = 200
    OK_ID = 300
    HOME_ID = 302
    INLINE_KEYBOARD_ID = 500
    INLINE_VALUE_ID = 501
    INLINE_MODE_ID = 502
    INLINE_HISTORY_ID = 503
    INLINE_HISTORY_CLEAR_ID = 504
    INLINE_PORT_ID_V1730 = 505
    INLINE_DB_VALUE_ID_V1730 = 506
    INLINE_CONFIRM_ID_V1731 = 507
    INLINE_HISTORY_SETTING_V1713 = "plex_url_history"
    INLINE_DB_PATH_HISTORY_SETTING_V1719 = "plex_db_path_history"
    INLINE_HISTORY_LIMIT_V1713 = 20

    # v1712: compact address-only keyboard.  Every mode ends with the same
    # native panel mode/actions so no separate "영문 주소 키보드" caption is needed.
    INLINE_ADDRESS_MODE_KEYS_V1712 = ["영문", "한글", "숫자", "기호", "빠른입력"]
    INLINE_ADDRESS_ACTION_KEYS_V1712 = ["←", "→", "삭제", "전체삭제"]
    INLINE_PORT_KEYS_V1730 = list("1234567890") + INLINE_ADDRESS_ACTION_KEYS_V1712
    INLINE_ADDRESS_KEYS = {
        "EN": list("abcdefghijklmnopqrstuvwxyz") + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "KO": [
            "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ", "ㅈ", "ㅊ",
            "ㅋ", "ㅌ", "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ", "ㅔ", "ㅕ",
            "ㅗ", "ㅛ", "ㅜ", "ㅠ", "ㅡ", "ㅣ",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "NUM": list("1234567890") + [".", ":", "/", "-", "_", "@"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "SYM": ["!", "?", "#", "%", "&", "+", "=", "_", "@", "'", '"', ",", ".", ":", "/", "-", "(", ")", "[", "]"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        # v1741: quick tokens occupy four complete visual rows after the two
        # edit actions, then all five mode-switch keys share one dedicated row.
        # This keeps 영문/한글/숫자/기호/빠른입력 grouped instead of splitting
        # them across the token/action rows.
        "DOMAIN": [
            "http://", "https://", "www.", "192.168.0.1", "192.168.",
            "10.0.", "172.16.", "127.0.0.1", "localhost",
            ".com", ".net", ".org", ".co.kr", ".mywire", ".mywire.org",
            ".iptime", ".iptime.org", ".duckdns.org",
        ] + INLINE_ADDRESS_ACTION_KEYS_V1712 + INLINE_ADDRESS_MODE_KEYS_V1712,
    }

    # v1719: the same inline keyboard layout is reused for direct Plex DB paths.
    # Only the path quick keys differ; font, geometry, history and navigation stay shared.
    INLINE_DB_PATH_KEYS = {
        "EN": list("abcdefghijklmnopqrstuvwxyz") + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "KO": [
            "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ", "ㅈ", "ㅊ",
            "ㅋ", "ㅌ", "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ", "ㅔ", "ㅕ",
            "ㅗ", "ㅛ", "ㅜ", "ㅠ", "ㅡ", "ㅣ",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "NUM": list("1234567890") + [".", ":", "/", "\\", "-", "_", "@"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "SYM": ["!", "?", "#", "%", "&", "+", "=", "_", "@", "'", '"', ",", ".", ":", "/", "\\", "-", "(", ")", "[", "]"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        # v1741: add one compact Windows root token so the path quick page has
        # fifteen data keys.  The five mode switches then occupy one complete
        # row and the two edit actions remain together below it.
        "DOMAIN": [
            "smb://", "nfs://", "http://", "https://", "file://", "special://",
            "/", "\\", ":", "//", ".db", "Plex Media Server",
            "Plug-in Support", "Databases", "C:\\",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
    }

    _INLINE_KO_CONSONANTS_V1712 = set("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
    _INLINE_KO_VOWELS_V1712 = set("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
    _INLINE_CHO_V1712 = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
    _INLINE_JUNG_V1712 = ["ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"]
    _INLINE_JONG_V1712 = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]

    def _inline_is_db_path_v1719(self):
        return str(getattr(self, "_inline_input_kind_v1719", "plex_url") or "plex_url") == "plex_db_path"

    def _inline_history_setting_v1719(self):
        return self.INLINE_DB_PATH_HISTORY_SETTING_V1719 if self._inline_is_db_path_v1719() else self.INLINE_HISTORY_SETTING_V1713

    def _inline_current_keys_v1719(self):
        if (not self._inline_is_db_path_v1719()) and getattr(self, "_inline_active_field_v1730", "address") == "port":
            return list(self.INLINE_PORT_KEYS_V1730)
        key_map = self.INLINE_DB_PATH_KEYS if self._inline_is_db_path_v1719() else self.INLINE_ADDRESS_KEYS
        return key_map.get(self._inline_address_mode_v1711, [])

    def _inline_normalize_value_v1719(self, value):
        value = str(value or "").strip()
        if self._inline_is_db_path_v1719():
            return _plex_db_path_clean_v1700(value)
        return _normalize_plex_server_url_v1313(value)

    def _inline_current_setting_value_v1719(self):
        setting_id = "plex_db_path" if self._inline_is_db_path_v1719() else "plex_url"
        return str(ADDON.getSetting(setting_id) or "")

    def _inline_placeholder_v1719(self):
        return "Plex Server DB 경로 입력" if self._inline_is_db_path_v1719() else "Plex 서버 주소 입력"

    def _inline_history_empty_label_v1719(self):
        return "저장된 경로 없음" if self._inline_is_db_path_v1719() else "저장된 주소 없음"

    def _inline_address_mode_label_v1711(self):
        # v1712: mode is represented by the mode keys at the end of every panel.
        return ""

    def _inline_compose_syllable_v1712(self, cho, jung, jong=""):
        try:
            l = self._INLINE_CHO_V1712.index(cho)
            v = self._INLINE_JUNG_V1712.index(jung)
            t = self._INLINE_JONG_V1712.index(jong or "")
            return chr(0xAC00 + (l * 21 + v) * 28 + t)
        except Exception:
            return (cho or "") + (jung or "") + (jong or "")

    def _inline_compose_tokens_value_v1971(self, tokens):
        out = []
        L = V = T = None

        def commit():
            nonlocal L, V, T
            if L and V:
                out.append(self._inline_compose_syllable_v1712(L, V, T or ""))
            elif L:
                out.append(L)
            elif V:
                out.append(V)
            L = V = T = None

        for token in list(tokens or []):
            ch = token or ""
            if len(ch) != 1:
                commit()
                out.append(ch)
                continue
            if ch in self._INLINE_KO_CONSONANTS_V1712:
                if L is None:
                    L = ch
                elif V is None:
                    out.append(L)
                    L = ch
                elif T is None and ch in self._INLINE_JONG_V1712:
                    T = ch
                else:
                    commit()
                    L = ch
            elif ch in self._INLINE_KO_VOWELS_V1712:
                if L is None:
                    commit()
                    V = ch
                    commit()
                elif V is None:
                    V = ch
                elif T is not None:
                    old_t = T
                    out.append(self._inline_compose_syllable_v1712(L, V, ""))
                    L, V, T = old_t, ch, None
                else:
                    commit()
                    V = ch
                    commit()
            else:
                commit()
                out.append(ch)
        commit()
        return "".join(out)

    def _inline_recompose_tokens_v1712(self):
        self._inline_address_value_v1711 = self._inline_compose_tokens_value_v1971(
            self._inline_address_tokens_v1712
        )
        self._inline_cursor_index_v1971 = max(0, min(
            int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_address_tokens_v1712)) or 0),
            len(self._inline_address_tokens_v1712),
        ))

    def _inline_cursor_render_value_v1971(self):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        left = self._inline_compose_tokens_value_v1971(tokens[:cursor])
        right = self._inline_compose_tokens_value_v1971(tokens[cursor:])
        return left + "│" + right

    def _inline_append_token_v1712(self, token):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        inserted = list(str(token or ""))
        tokens[cursor:cursor] = inserted
        self._inline_address_tokens_v1712 = tokens
        self._inline_cursor_index_v1971 = cursor + len(inserted)
        self._inline_recompose_tokens_v1712()
        _log("PKM_INLINE_CURSOR_INSERT_V1971 cursor=%s length=%s" % (self._inline_cursor_index_v1971, len(tokens)), xbmc.LOGINFO)

    def _inline_delete_token_v1712(self):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        if cursor > 0:
            del tokens[cursor - 1]
            cursor -= 1
        self._inline_address_tokens_v1712 = tokens
        self._inline_cursor_index_v1971 = cursor
        self._inline_recompose_tokens_v1712()
        _log("PKM_INLINE_CURSOR_DELETE_V1971 cursor=%s length=%s" % (cursor, len(tokens)), xbmc.LOGINFO)

    def _inline_move_cursor_v1971(self, delta):
        tokens = list(self._inline_address_tokens_v1712 or [])
        old = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        new = max(0, min(old + int(delta or 0), len(tokens)))
        self._inline_cursor_index_v1971 = new
        _log("PKM_INLINE_CURSOR_MOVE_V1971 from=%s to=%s length=%s" % (old, new, len(tokens)), xbmc.LOGINFO)

    def _inline_clear_tokens_v1712(self):
        self._inline_address_tokens_v1712 = []
        self._inline_address_value_v1711 = ""
        self._inline_cursor_index_v1971 = 0

    def _inline_commit_active_field_v1730(self):
        if self._inline_is_db_path_v1719():
            return
        field = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
        if field == "port":
            self._inline_server_port_value_v1730 = str(self._inline_address_value_v1711 or "")
            self._inline_server_port_tokens_v1730 = list(self._inline_address_tokens_v1712 or [])
            self._inline_server_port_cursor_v1971 = int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_server_port_tokens_v1730)) or 0)
        else:
            self._inline_server_address_value_v1730 = str(self._inline_address_value_v1711 or "")
            self._inline_server_address_tokens_v1730 = list(self._inline_address_tokens_v1712 or [])
            self._inline_server_address_cursor_v1971 = int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_server_address_tokens_v1730)) or 0)

    def _inline_switch_server_field_v1730(self, field, repopulate=True):
        if self._inline_is_db_path_v1719():
            return
        field = "port" if str(field or "") == "port" else "address"
        current = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
        if field == current:
            try:
                self.setProperty("PlexKM.Dialog.InlineActiveField", field)
            except Exception:
                pass
            return
        self._inline_commit_active_field_v1730()
        self._inline_active_field_v1730 = field
        if field == "port":
            self._inline_address_value_v1711 = str(getattr(self, "_inline_server_port_value_v1730", "32400") or "")
            self._inline_address_tokens_v1712 = list(getattr(self, "_inline_server_port_tokens_v1730", []) or list(self._inline_address_value_v1711))
            self._inline_cursor_index_v1971 = max(0, min(int(getattr(self, "_inline_server_port_cursor_v1971", len(self._inline_address_tokens_v1712)) or 0), len(self._inline_address_tokens_v1712)))
        else:
            self._inline_address_value_v1711 = str(getattr(self, "_inline_server_address_value_v1730", "") or "")
            self._inline_address_tokens_v1712 = list(getattr(self, "_inline_server_address_tokens_v1730", []) or list(self._inline_address_value_v1711))
            self._inline_cursor_index_v1971 = max(0, min(int(getattr(self, "_inline_server_address_cursor_v1971", len(self._inline_address_tokens_v1712)) or 0), len(self._inline_address_tokens_v1712)))
        try:
            self.setProperty("PlexKM.Dialog.InlineActiveField", field)
        except Exception:
            pass
        if repopulate:
            self._inline_address_populate_v1711(0)
        else:
            self._inline_address_render_v1711()
        _log("PKM_INLINE_SERVER_FIELD_ACTIVE_V1730 field=%s" % field, xbmc.LOGINFO)

    def _inline_address_render_v1711(self):
        try:
            if self._inline_is_db_path_v1719():
                shown = self._inline_cursor_render_value_v1971() if self._inline_address_active_v1711 else (self._inline_address_value_v1711 or self._inline_placeholder_v1719())
                if self._inline_db_value_control_v1730:
                    self._inline_db_value_control_v1730.setLabel(_display_text_for_kodi(shown))
            else:
                field = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
                address = self._inline_cursor_render_value_v1971() if field == "address" else str(getattr(self, "_inline_server_address_value_v1730", "") or "")
                port = self._inline_cursor_render_value_v1971() if field == "port" else str(getattr(self, "_inline_server_port_value_v1730", "32400") or "")
                if self._inline_value_control_v1711:
                    self._inline_value_control_v1711.setLabel(_display_text_for_kodi(address or "Plex 서버 주소 입력"))
                if self._inline_port_control_v1730:
                    
                    if field != "port" and str(port or "") == "32400":
                        port_label = "기본포트  32400"
                    elif port:
                        port_label = "포트  " + str(port)
                    else:
                        port_label = "포트 입력"
                    self._inline_port_control_v1730.setLabel(_display_text_for_kodi(port_label))
            if self._inline_mode_control_v1711:
                self._inline_mode_control_v1711.setLabel(_display_text_for_kodi(self._inline_address_mode_label_v1711()))
        except Exception:
            pass

    def _inline_address_populate_v1711(self, focus_pos=0):
        if not self._inline_keyboard_v1711:
            return
        try:
            self._inline_keyboard_v1711.reset()
            items = []
            for key in self._inline_current_keys_v1719():
                li = xbmcgui.ListItem(label=_display_text_for_kodi(key))
                li.setProperty("PKMAddressKey", key)
                li.setProperty("PKMAddressMode", self._inline_address_mode_v1711)
                if self._inline_address_mode_v1711 == "DOMAIN" and key in self.INLINE_ADDRESS_MODE_KEYS_V1712:
                    li.setProperty("PKMAddressGroup", "mode")
                elif key in self.INLINE_ADDRESS_ACTION_KEYS_V1712:
                    li.setProperty("PKMAddressGroup", "action")
                else:
                    li.setProperty("PKMAddressGroup", "content")
                items.append(li)
            self._inline_keyboard_v1711.addItems(items)
            if items:
                self._inline_keyboard_v1711.selectItem(max(0, min(int(focus_pos or 0), len(items) - 1)))
            self._inline_address_render_v1711()
        except Exception:
            _log("PKM_INLINE_ADDRESS_POPULATE_FAILED_V1711\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_load_v1713(self):
        raw = (ADDON.getSetting(self._inline_history_setting_v1719()) or "").strip()
        rows = []
        if raw:
            try:
                decoded = json.loads(raw)
                if isinstance(decoded, list):
                    rows = decoded
            except Exception:
                # Compatibility with a possible old newline-separated value.
                rows = raw.splitlines()
        clean = []
        seen = set()
        for value in rows:
            value = str(value or "").strip()
            if not value:
                continue
            normalized = self._inline_normalize_value_v1719(value)
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            clean.append(normalized)
            if len(clean) >= self.INLINE_HISTORY_LIMIT_V1713:
                break
        self._inline_address_history_v1713 = clean
        return list(clean)

    def _inline_history_store_v1713(self):
        clean = list(getattr(self, "_inline_address_history_v1713", []) or [])[:self.INLINE_HISTORY_LIMIT_V1713]
        try:
            ADDON.setSetting(self._inline_history_setting_v1719(), json.dumps(clean, ensure_ascii=False, separators=(",", ":")))
        except Exception:
            _log("PKM_INLINE_ADDRESS_HISTORY_STORE_FAILED_V1713\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_remember_v1713(self, value):
        value = self._inline_normalize_value_v1719(value)
        if not value:
            return
        rows = [x for x in (getattr(self, "_inline_address_history_v1713", []) or []) if x != value]
        rows.insert(0, value)
        self._inline_address_history_v1713 = rows[:self.INLINE_HISTORY_LIMIT_V1713]
        self._inline_history_store_v1713()

    def _inline_history_populate_v1713(self, focus_pos=0):
        if not self._inline_history_control_v1713:
            return
        try:
            self._inline_history_control_v1713.reset()
            items = []
            for value in list(getattr(self, "_inline_address_history_v1713", []) or []):
                li = xbmcgui.ListItem(label=_display_text_for_kodi(value))
                li.setProperty("PKMAddressHistory", value)
                li.setProperty("PKMAddressHistoryEmpty", "0")
                items.append(li)
            if not items:
                li = xbmcgui.ListItem(label=_display_text_for_kodi(self._inline_history_empty_label_v1719()))
                li.setProperty("PKMAddressHistoryEmpty", "1")
                items.append(li)
            self._inline_history_control_v1713.addItems(items)
            if items:
                self._inline_history_control_v1713.selectItem(max(0, min(int(focus_pos or 0), len(items) - 1)))
        except Exception:
            _log("PKM_INLINE_ADDRESS_HISTORY_POPULATE_FAILED_V1713\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_seed_current_v1713(self):
        self._inline_history_load_v1713()
        current = self._inline_normalize_value_v1719(self._inline_current_setting_value_v1719())
        skip_default = (not self._inline_is_db_path_v1719()) and current == "http://127.0.0.1:32400"
        if current and not skip_default and current not in self._inline_address_history_v1713:
            self._inline_address_history_v1713.insert(0, current)
            self._inline_address_history_v1713 = self._inline_address_history_v1713[:self.INLINE_HISTORY_LIMIT_V1713]
            self._inline_history_store_v1713()
        self._inline_history_populate_v1713(0)

    def _inline_history_select_v1713(self):
        if not self._inline_history_control_v1713:
            return
        try:
            item = self._inline_history_control_v1713.getSelectedItem()
            if not item or item.getProperty("PKMAddressHistoryEmpty") == "1":
                return
            value = item.getProperty("PKMAddressHistory") or item.getLabel()
        except Exception:
            return
        value = str(value or "").strip()
        if not value:
            return
        if self._inline_is_db_path_v1719():
            self._inline_address_value_v1711 = value
            self._inline_address_tokens_v1712 = list(value)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        else:
            address, port = _split_plex_server_endpoint_v1730(value, default_port="32400")
            self._inline_server_address_value_v1730 = address
            self._inline_server_port_value_v1730 = port or "32400"
            self._inline_server_address_tokens_v1730 = list(address)
            self._inline_server_port_tokens_v1730 = list(self._inline_server_port_value_v1730)
            self._inline_server_address_cursor_v1971 = len(self._inline_server_address_tokens_v1730)
            self._inline_server_port_cursor_v1971 = len(self._inline_server_port_tokens_v1730)
            self._inline_active_field_v1730 = "address"
            self._inline_address_value_v1711 = address
            self._inline_address_tokens_v1712 = list(address)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
            try:
                self.setProperty("PlexKM.Dialog.InlineActiveField", "address")
            except Exception:
                pass
        self._inline_address_render_v1711()
        # v1731: after loading history, focus the dedicated long 확인 button.
        try:
            self.setFocusId(self.INLINE_CONFIRM_ID_V1731)
        except Exception:
            pass
        _log("PKM_INLINE_ADDRESS_HISTORY_SELECTED_V1713 value=%s" % value, xbmc.LOGINFO)

    def _inline_history_clear_v1713(self):
        self._inline_address_history_v1713 = []
        self._inline_history_store_v1713()
        self._inline_history_populate_v1713(0)
        try:
            self.setFocusId(self.INLINE_CONFIRM_ID_V1731)
        except Exception:
            pass
        _log("PKM_INLINE_ADDRESS_HISTORY_CLEARED_V1731", xbmc.LOGINFO)

    def _open_inline_address_v1711(self, input_kind="plex_url"):
        self._inline_address_active_v1711 = True
        self._inline_input_kind_v1719 = "plex_db_path" if str(input_kind or "") == "plex_db_path" else "plex_url"
        self._inline_restore_list_pos_v1719 = self._current_list_position_v1691()
        current_value = self._inline_current_setting_value_v1719()
        self._inline_address_mode_v1711 = "EN"
        if self._inline_is_db_path_v1719():
            self._inline_address_value_v1711 = current_value
            self._inline_address_tokens_v1712 = list(self._inline_address_value_v1711)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        else:
            if current_value == "http://127.0.0.1:32400":
                current_value = ""
            address, port = _split_plex_server_endpoint_v1730(current_value, default_port="32400")
            self._inline_server_address_value_v1730 = address
            self._inline_server_port_value_v1730 = port or "32400"
            self._inline_server_address_tokens_v1730 = list(address)
            self._inline_server_port_tokens_v1730 = list(self._inline_server_port_value_v1730)
            self._inline_server_address_cursor_v1971 = len(self._inline_server_address_tokens_v1730)
            self._inline_server_port_cursor_v1971 = len(self._inline_server_port_tokens_v1730)
            self._inline_active_field_v1730 = "address"
            self._inline_address_value_v1711 = address
            self._inline_address_tokens_v1712 = list(address)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        self._inline_history_seed_current_v1713()
        try:
            self.setProperty("PlexKM.Dialog.InlineKeyboard", "1")
            if self._inline_is_db_path_v1719():
                self.clearProperty("PlexKM.Dialog.InlineServerSplit")
                self.clearProperty("PlexKM.Dialog.InlineActiveField")
            else:
                self.setProperty("PlexKM.Dialog.InlineServerSplit", "1")
                self.setProperty("PlexKM.Dialog.InlineActiveField", "address")
            self.setProperty("PlexKM.Dialog.Hint", "경로 키 선택 / 확인 / 뒤로" if self._inline_is_db_path_v1719() else "주소와 포트 선택 / 확인 / 뒤로")
            row_label = "원격 DB 경로 직접 입력" if self._inline_is_db_path_v1719() else self._plex_connection_rows_v1703()[0]
            self.setProperty("PlexKM.Dialog.InlineRowLabel", _display_text_for_kodi(row_label))
            self.setProperty("PlexKM.Dialog.InlineHistoryTitle", _display_text_for_kodi("최근 경로" if self._inline_is_db_path_v1719() else "최근 주소"))
            self.setProperty("PlexKM.Dialog.InlineHistoryClear", _display_text_for_kodi("경로 히스토리 삭제" if self._inline_is_db_path_v1719() else "히스토리 삭제"))
        except Exception:
            pass
        self._inline_address_populate_v1711(focus_pos=0)
        try:
            self.setFocusId(self.INLINE_KEYBOARD_ID)
        except Exception:
            pass
        _log("PKM_INLINE_INPUT_OPEN_V1733 single_border_muted_text_visible_divider kind=%s mode=EN length=%d" % (self._inline_input_kind_v1719, len(self._inline_address_value_v1711 or "")), xbmc.LOGINFO)

    def _close_inline_address_v1711(self, restore_focus=True):
        self._inline_address_active_v1711 = False
        try:
            self.clearProperty("PlexKM.Dialog.InlineKeyboard")
            self.clearProperty("PlexKM.Dialog.InlineRowLabel")
            self.clearProperty("PlexKM.Dialog.InlineHistoryTitle")
            self.clearProperty("PlexKM.Dialog.InlineHistoryClear")
            self.clearProperty("PlexKM.Dialog.InlineServerSplit")
            self.clearProperty("PlexKM.Dialog.InlineActiveField")
            self.setProperty("PlexKM.Dialog.Hint", "선택 / 홈 / 뒤로")
        except Exception:
            pass
        if restore_focus:
            try:
                self._list.selectItem(max(0, int(getattr(self, "_inline_restore_list_pos_v1719", 0) or 0)))
                self.setFocusId(self.LIST_ID)
            except Exception:
                pass
        _log("PKM_INLINE_ADDRESS_CLOSE_V1711", xbmc.LOGINFO)

    def _save_inline_address_v1711(self):
        raw = str(self._inline_address_value_v1711 or "").strip()
        if self._inline_is_db_path_v1719():
            new_value = _plex_db_path_clean_v1700(raw)
            if not new_value:
                return
            if not _validate_plex_db_path_v1700(new_value, notify=True):
                return
            self._inline_history_remember_v1713(new_value)
            self._close_inline_address_v1711(restore_focus=False)
            self._save_plex_db_path_v1700(new_value)
            _log("PKM_INLINE_DB_PATH_SAVED_V1719 path=%s" % new_value, xbmc.LOGINFO)
            return

        self._inline_commit_active_field_v1730()
        address = str(getattr(self, "_inline_server_address_value_v1730", "") or "").strip()
        port = str(getattr(self, "_inline_server_port_value_v1730", "") or "").strip()
        new_value, error_field = _combine_plex_server_endpoint_v1730(address, port, notify=True)
        if not new_value:
            self._inline_switch_server_field_v1730(error_field or "address", repopulate=True)
            try:
                self.setFocusId(self.INLINE_PORT_ID_V1730 if error_field == "port" else self.INLINE_VALUE_ID)
            except Exception:
                pass
            return
        old_value = _normalize_plex_server_url_v1313((ADDON.getSetting("plex_url") or ""))
        changed = new_value != old_value
        if changed and not _probe_candidate_plex_url_v1922(new_value):
            self._inline_switch_server_field_v1730("address", repopulate=True)
            try:
                self.setFocusId(self.INLINE_VALUE_ID)
            except Exception:
                pass
            return
        ADDON.setSetting("plex_url", new_value)
        _publish_live_plex_settings_v1922(server=new_value, reason="inline_url_saved_v1922")
        if new_value:
            self._inline_history_remember_v1713(new_value)
        token_ready = bool((ADDON.getSetting("plex_token") or "").strip())
        if changed and token_ready:
            _set_server_switch_pending_v1310(True, reason="inline_url_saved_v1711")
        elif changed:
            _set_server_switch_pending_v1310(False, reason="inline_url_saved_wait_token_v1730")
            _clear_server_switch_pending_home_ui_v1310(reason="inline_url_saved_wait_token_v1730")
        if changed:
            _log("PKM_SETTINGS_PLEX_URL_SAVED_V1730 configured=%s server_changed=1 token_ready=%s server=%s" % (
                "1" if new_value else "0", "1" if token_ready else "0", new_value,
            ), xbmc.LOGINFO)
        self._close_inline_address_v1711(restore_focus=False)
        self._refresh_plex_connection_in_place_v1703(focus_pos=0)
        if changed and token_ready:
            _set_server_switch_pending_home_ui_v1310(
                "Plex 서버 연결 확인 중",
                "라이브러리 정보를 확인합니다",
                reason="settings_inline_connection_changed_v1711",
            )
            _probe_plex_after_connection_setting(reason="settings_inline_plex_url_saved_v1711", server_changed=True)
        elif changed:
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    pkm_notify.pkm_notice_set(
                        "Plex 서버 주소 저장됨",
                        "포트 %s로 저장했습니다" % port,
                        "Plex 토큰 인증을 진행해주세요",
                        sticky=False,
                        force_replace=True,
                    )
            except Exception:
                pass

    def _handle_inline_address_key_v1711(self):
        if not self._inline_keyboard_v1711:
            return
        try:
            item = self._inline_keyboard_v1711.getSelectedItem()
            key = item.getProperty("PKMAddressKey") or item.getLabel()
        except Exception:
            return
        if (not self._inline_is_db_path_v1719()) and getattr(self, "_inline_active_field_v1730", "address") == "port":
            if key not in ("←", "→", "삭제", "전체삭제", "확인") and not str(key or "").isdigit():
                _show_plex_endpoint_error_v1730("포트에는 숫자만 입력할 수 있습니다", "1부터 65535 사이로 입력해주세요")
                return
        mode_map = {"영문": "EN", "한글": "KO", "숫자": "NUM", "기호": "SYM", "빠른입력": "DOMAIN"}
        if key in mode_map:
            self._inline_address_mode_v1711 = mode_map[key]
            self._inline_address_populate_v1711(0)
            return
        if key == "확인":
            self._save_inline_address_v1711()
            return
        if key == "←":
            self._inline_move_cursor_v1971(-1)
        elif key == "→":
            self._inline_move_cursor_v1971(1)
        elif key == "삭제":
            self._inline_delete_token_v1712()
        elif key == "전체삭제":
            self._inline_clear_tokens_v1712()
        else:
            self._inline_append_token_v1712(key)
        self._inline_address_render_v1711()

    def __init__(self, *args, **kwargs):
        self._list = None
        self._page = "root"
        self._items = []
        self._stack = []
        self._multiselect = False
        self._preselect = set()
        self._actionable = None
        self._show_checks = set()
        self._payload = None
        self.result_action = None
        self._initial_page = kwargs.pop("initial_page", "root")
        self._last_click_ms_v1382 = 0
        self._plex_db_browser_root_v1700 = ""
        self._plex_db_browser_path_v1700 = ""
        self._inline_keyboard_v1711 = None
        self._inline_value_control_v1711 = None
        self._inline_mode_control_v1711 = None
        self._inline_port_control_v1730 = None
        self._inline_db_value_control_v1730 = None
        self._inline_history_control_v1713 = None
        self._inline_address_history_v1713 = []
        self._inline_address_active_v1711 = False
        self._inline_address_value_v1711 = ""
        self._inline_address_mode_v1711 = "EN"
        self._inline_address_tokens_v1712 = []
        self._inline_cursor_index_v1971 = 0
        self._inline_server_address_cursor_v1971 = 0
        self._inline_server_port_cursor_v1971 = 5
        self._inline_input_kind_v1719 = "plex_url"
        self._inline_restore_list_pos_v1719 = 0
        self._inline_active_field_v1730 = "address"
        self._inline_server_address_value_v1730 = ""
        self._inline_server_port_value_v1730 = "32400"
        self._inline_server_address_tokens_v1730 = []
        self._inline_server_port_tokens_v1730 = list("32400")
        super(PKMSettingsFlowDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        _log("PKM_PATCH_ACTIVE v1971 inline_keyboard_cursor_left_right_middle_edit", xbmc.LOGINFO)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self._list = self.getControl(self.LIST_ID)
            try:
                self._inline_keyboard_v1711 = self.getControl(self.INLINE_KEYBOARD_ID)
                self._inline_value_control_v1711 = self.getControl(self.INLINE_VALUE_ID)
                self._inline_mode_control_v1711 = self.getControl(self.INLINE_MODE_ID)
                self._inline_port_control_v1730 = self.getControl(self.INLINE_PORT_ID_V1730)
                self._inline_db_value_control_v1730 = self.getControl(self.INLINE_DB_VALUE_ID_V1730)
                self._inline_history_control_v1713 = self.getControl(self.INLINE_HISTORY_ID)
            except Exception:
                self._inline_keyboard_v1711 = None
                self._inline_value_control_v1711 = None
                self._inline_mode_control_v1711 = None
                self._inline_port_control_v1730 = None
                self._inline_db_value_control_v1730 = None
                self._inline_history_control_v1713 = None
            self.clearProperty("PlexKM.Dialog.InlineKeyboard")
            self.clearProperty("PlexKM.Dialog.InlineRowLabel")
            self.clearProperty("PlexKM.Dialog.InlineHistoryTitle")
            self.clearProperty("PlexKM.Dialog.InlineHistoryClear")
            self.clearProperty("PlexKM.Dialog.InlineServerSplit")
            self.clearProperty("PlexKM.Dialog.InlineActiveField")
            if self._initial_page == "plex_connection":
                self._show_plex_connection(push=False)
            else:
                self._show_root(push=False)
            self.setFocusId(self.LIST_ID)
        except Exception:
            _log("PKM_SETTINGS_FLOW_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            self.close()

    def _make_item(self, label, idx):
        li = xbmcgui.ListItem(label=_display_text_for_kodi(label))
        li.setProperty("index", str(idx))
        checked = idx in self._preselect
        li.setProperty("checked", "1" if checked else "0")
        show_check = self._multiselect or idx in self._show_checks
        li.setProperty("showcheck", "1" if show_check else "0")
        actionable = self._actionable is None or idx in self._actionable
        li.setProperty("actionable", "1" if actionable else "0")
        return li

    def _current_list_position_v1691(self):
        try:
            return int(self._list.getSelectedPosition()) if self._list else 0
        except Exception:
            return 0

    def _render(self, title, items, page, multiselect=False, preselect=None, payload=None,
                push=True, actionable=None, focus_pos=None, show_checks=None):
        try:
            # v2015: Every in-place PKM page refresh returns to the row that
            # launched the operation.  Capture before reset because resetting
            # the native list otherwise snaps selection to row 0.
            preserve_same_page_focus_v2015 = None
            if (not push) and focus_pos is None and str(page or "") == str(self._page or ""):
                preserve_same_page_focus_v2015 = self._current_list_position_v1691()
            if push:
                saved_actionable = None if self._actionable is None else set(self._actionable)
                self._stack.append((
                    self._page, list(self._items), self._multiselect, set(self._preselect),
                    self._payload, self.getProperty("PlexKM.Dialog.Title"), saved_actionable,
                    self._current_list_position_v1691(), set(self._show_checks),
                ))
            self._page = page
            self._items = [_display_text_for_kodi(x) for x in list(items or [])]
            self._multiselect = bool(multiselect)
            self._preselect = set(int(x) for x in (preselect or []))
            self._actionable = None if actionable is None else set(int(x) for x in actionable)
            self._show_checks = set(int(x) for x in (show_checks or []))
            self._payload = payload
            self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi(title or "Plex KM"))
            self.setProperty("PlexKM.Dialog.Mode", "multi" if self._multiselect else "single")
            self.setProperty("PlexKM.Dialog.Hint", "저장 / 홈 / 뒤로" if self._multiselect else "선택 / 홈 / 뒤로")
            self._list.reset()
            self._list.addItems([self._make_item(label, idx) for idx, label in enumerate(self._items)])
            self.setFocusId(self.LIST_ID)
            target = focus_pos
            if target is None and preserve_same_page_focus_v2015 is not None:
                target = preserve_same_page_focus_v2015
            if target is None and self._actionable:
                target = min(self._actionable)
            if target is not None and self._items:
                target = max(0, min(int(target), len(self._items) - 1))
                if self._actionable and target not in self._actionable:
                    target = min(self._actionable)
                self._list.selectItem(target)
            if page == "plex_connection":
                _log("PKM_SETTINGS_ACTIONABLE_ROWS_V1691 page=plex_connection rows=%s focus=%s" % (
                    ",".join(str(x) for x in sorted(self._actionable or [])),
                    self._current_list_position_v1691(),
                ), xbmc.LOGINFO)
        except Exception:
            _log("PKM_SETTINGS_FLOW_RENDER_FAILED page=%s\n%s" % (page, traceback.format_exc()), xbmc.LOGWARNING)

    def _restore(self, state):
        page, items, multiselect, preselect, payload, title, actionable, focus_pos, show_checks = state
        self._page = page
        self._items = list(items or [])
        self._multiselect = bool(multiselect)
        self._preselect = set(preselect or [])
        self._actionable = None if actionable is None else set(actionable)
        self._show_checks = set(show_checks or [])
        self._payload = payload
        self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi(title or "Plex KM"))
        self.setProperty("PlexKM.Dialog.Mode", "multi" if self._multiselect else "single")
        self.setProperty("PlexKM.Dialog.Hint", "저장 / 홈 / 뒤로" if self._multiselect else "선택 / 홈 / 뒤로")
        self._list.reset()
        self._list.addItems([self._make_item(label, idx) for idx, label in enumerate(self._items)])
        self.setFocusId(self.LIST_ID)
        if self._items:
            focus_pos = max(0, min(int(focus_pos or 0), len(self._items) - 1))
            if self._actionable and focus_pos not in self._actionable:
                focus_pos = min(self._actionable)
            self._list.selectItem(focus_pos)

    def _back(self):
        if self._stack:
            self._restore(self._stack.pop())
        else:
            self.close()

    def _show_root(self, push=True, focus_pos=None):
        # v1382: Offline/connection-failure settings must open on the fixable
        # connection page first, without offering a network-backed library
        # selection as the first focused row.  This keeps PKM 설정 responsive.
        if _offline_or_server_switch_pending_v1382():
            self._render("Plex KM", [
                "Plex 서버 연결",
                "스피너 설정",
                "라이브러리 선택/관리",
                "외부 평점 관리",
                "초기화",
            ], "root_offline", push=push, focus_pos=focus_pos)
            _log("PKM_SETTINGS_FLOW_ROOT_OFFLINE_FAST_V1382", xbmc.LOGWARNING)
            return
        # v1926: Library additions are synchronised from the library manager,
        # and later Plex changes are checked automatically at Kodi startup.
        # Keep the root menu limited to distinct user-facing functions.
        self._render("Plex KM", [
            "Plex 서버 연결",
            "스피너 설정",
            "라이브러리 선택/관리",
            "외부 평점 관리",
            "초기화",
        ], "root", push=push, focus_pos=focus_pos)

    def _run_full_reset_v1997(self):
        # v2007: Reset remains inside the Plex KM settings flow.  Do not arm
        # Home/startup-logo transitions for an operation that only clears data.
        confirmed = open_pkm_confirm_dialog(
            "초기화 확인",
            "Plex KM을 완전히 초기화합니다.\n\n"
            "진행 중인 모든 PKM 작업을 먼저 중지한 뒤 Plex 서버 정보, 토큰, "
            "라이브러리 설정, 기존 DB와 모든 PKM 캐시/저장 데이터를 삭제합니다.\n\n"
            "이 작업은 되돌릴 수 없습니다. 계속하려면 방향키로 '예'를 선택하세요.",
            yes_label="예",
            no_label="아니오",
            default_focus="no",
        )
        if not confirmed:
            # Keep the existing root menu and focus exactly as-is.
            return
        ok = True
        win_reset_v2149 = xbmcgui.Window(10000)
        reset_success_v2150 = False
        base = ADDON.getAddonInfo("profile") or ""
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        try:
            # v2149: full reset is a real background-work barrier, not just a
            # file purge.  Signal every sync/prewarm worker BEFORE credentials
            # or DB files disappear.  The service/startup sync observes this
            # property and releases sync.lock cooperatively.
            now_ms_v2149 = int(time.time() * 1000)
            reset_token_v2151 = str(now_ms_v2149)
            # v2151: clear previous ACK/request state BEFORE publishing the reset
            # trigger.  Doing this afterward leaves a small race where a fast Home
            # drain can ACK and the settings thread can accidentally erase it.
            for _prop_v2151 in (
                "PlexKM.Home.FullResetWorkersStoppedV2151",
                "PlexKM.Home.FullResetWorkersPendingV2151",
                "PlexKM.Home.FullResetMemoryPurgedV2151",
                "PlexKM.Home.FullResetPurgeRequestV2151",
                "PlexKM.ServiceFullResetStoppedV2151",
            ):
                try:
                    win_reset_v2149.clearProperty(_prop_v2151)
                except Exception:
                    pass
            # v2150: Full reset is a hard lifetime barrier.  Keep both the v2149
            # compatibility property and the new semantic property asserted for
            # the remainder of this Kodi process after a successful reset.  This
            # prevents any surviving daemon/prewarm worker from recreating the DB
            # or cache after the purge.  Window properties naturally disappear on
            # the next Kodi launch.
            win_reset_v2149.setProperty("PlexKM.FullResetInProgressV2149", "1")
            win_reset_v2149.setProperty("PlexKM.FullResetInProgressV2150", "1")
            win_reset_v2149.setProperty("PlexKM.FullResetRequestedAtV2149", str(now_ms_v2149))
            win_reset_v2149.setProperty("PlexKM.FullResetRequestedAtV2150", str(now_ms_v2149))
            win_reset_v2149.setProperty("PlexKM.SettingsQuietUntilMs", str(now_ms_v2149 + 86400000))
            win_reset_v2149.setProperty("PlexKM.Home.BackgroundAbortV2150", "1")
            _log("PKM_FULL_RESET_BARRIER_BEGIN_V2150 profile=%s credentials_cleared=0 hard_stop=1" % (base or ""), xbmc.LOGINFO)

            # v2151: V2150 only drained sync.lock/Plex/artwork.  A live Home can
            # still have recommendation/cast/poster workers whose final data-only
            # step is outside those counters.  The live Home owns those threads, so
            # require its explicit stop ACK before credentials or profile files move.
            home_live_v2151 = False
            try:
                home_live_v2151 = win_reset_v2149.getProperty("PlexKM.HomeWindowActive") == "true"
            except Exception:
                home_live_v2151 = False
            home_waited_v2151 = 0
            if home_live_v2151:
                while home_waited_v2151 < 22000:
                    if win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersStoppedV2151") == reset_token_v2151:
                        break
                    xbmc.sleep(25)
                    home_waited_v2151 += 25
                home_workers_ok_v2151 = win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersStoppedV2151") == reset_token_v2151
            else:
                home_workers_ok_v2151 = True
            service_running_v2151 = False
            try:
                service_running_v2151 = win_reset_v2149.getProperty("PlexKM.ServiceRunningV2151") == "1"
            except Exception:
                service_running_v2151 = False
            service_waited_v2151 = 0
            if service_running_v2151:
                while service_waited_v2151 < 22000:
                    if win_reset_v2149.getProperty("PlexKM.ServiceFullResetStoppedV2151") == "1":
                        break
                    xbmc.sleep(25)
                    service_waited_v2151 += 25
                service_workers_ok_v2151 = win_reset_v2149.getProperty("PlexKM.ServiceFullResetStoppedV2151") == "1"
            else:
                service_workers_ok_v2151 = True
            _log("PKM_FULL_RESET_OWNER_DRAIN_V2151 token=%s home_live=%d home_waited_ms=%d home_ok=%d home_pending=%s service_live=%d service_waited_ms=%d service_ok=%d credentials_cleared=0" % (
                reset_token_v2151, 1 if home_live_v2151 else 0, home_waited_v2151, 1 if home_workers_ok_v2151 else 0,
                win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersPendingV2151") or "-",
                1 if service_running_v2151 else 0, service_waited_v2151, 1 if service_workers_ok_v2151 else 0
            ), xbmc.LOGINFO if (home_workers_ok_v2151 and service_workers_ok_v2151) else xbmc.LOGWARNING)
            if not home_workers_ok_v2151 or not service_workers_ok_v2151:
                raise RuntimeError("PKM Home/service workers did not fully stop before reset purge")

            # v2067: a full reset is also a UI/background ownership boundary.
            # Retire every shared busy token before profile files disappear so a
            # stale library/section operation cannot repaint a spinner afterward.
            try:
                from resources.lib import pkm_global_busy
                pkm_global_busy.cancel_all(reason="full_reset_v2150")
            except Exception:
                pass
            try:
                from resources.lib import pkm_artwork_scheduler
                if hasattr(pkm_artwork_scheduler, "request_full_reset_stop_v2150"):
                    pkm_artwork_scheduler.request_full_reset_stop_v2150()
            except Exception:
                pass
            try:
                from resources.lib import pkm_plex_client
                if hasattr(pkm_plex_client, "request_full_reset_stop_v2150"):
                    pkm_plex_client.request_full_reset_stop_v2150()
            except Exception:
                pass

            # Wait while any real sync / Plex HTTP / artwork owner is still in
            # flight.  No new work can enter after the hard reset barrier.
            # not a fixed UI delay.  Normal LAN sync exits in a few checks; the
            # upper bound covers one in-flight 12 s partial metadata request.
            sync_lock_v2149 = os.path.join(base, "sync.lock") if base else ""
            waited_ms_v2149 = 0
            sync_active_v2149 = False
            plex_inflight_v2150 = 0
            artwork_active_v2150 = 0
            artwork_waiting_v2150 = 0
            while waited_ms_v2149 < 22000:
                sync_active_v2149 = bool(sync_lock_v2149 and os.path.exists(sync_lock_v2149))
                try:
                    from resources.lib import pkm_plex_client
                    plex_inflight_v2150 = int(pkm_plex_client.full_reset_inflight_count_v2150()) if hasattr(pkm_plex_client, "full_reset_inflight_count_v2150") else 0
                except Exception:
                    plex_inflight_v2150 = 0
                try:
                    from resources.lib import pkm_artwork_scheduler
                    art_state_v2150 = pkm_artwork_scheduler.stats_snapshot()
                    artwork_active_v2150 = int(art_state_v2150.get("active", 0) or 0)
                    artwork_waiting_v2150 = int(art_state_v2150.get("waiting", 0) or 0)
                    artwork_inflight_v2150 = int(art_state_v2150.get("inflight", 0) or 0)
                except Exception:
                    artwork_active_v2150 = 0
                    artwork_waiting_v2150 = 0
                    artwork_inflight_v2150 = 0
                if not sync_active_v2149 and plex_inflight_v2150 <= 0 and artwork_active_v2150 <= 0 and artwork_waiting_v2150 <= 0 and artwork_inflight_v2150 <= 0:
                    break
                xbmc.sleep(50)
                waited_ms_v2149 += 50
            _log("PKM_FULL_RESET_BACKGROUND_DRAIN_V2150 waited_ms=%d sync_lock=%d plex_inflight=%d artwork_active=%d artwork_waiting=%d artwork_inflight=%d credentials_cleared=0" % (
                waited_ms_v2149, 1 if sync_active_v2149 else 0, plex_inflight_v2150,
                artwork_active_v2150, artwork_waiting_v2150, artwork_inflight_v2150
            ), xbmc.LOGINFO if (not sync_active_v2149 and plex_inflight_v2150 <= 0 and artwork_active_v2150 <= 0 and artwork_waiting_v2150 <= 0 and artwork_inflight_v2150 <= 0) else xbmc.LOGWARNING)
            if sync_active_v2149 or plex_inflight_v2150 > 0 or artwork_active_v2150 > 0 or artwork_waiting_v2150 > 0 or artwork_inflight_v2150 > 0:
                raise RuntimeError("PKM background work did not fully stop before reset purge")

            # Clear every user-facing addon setting in all live Addon wrappers
            # only AFTER existing sync owners have retired.
            setting_ids = (
                "plex_url", "plex_token", "plex_account_name", "plex_url_history",
                "chunk_size", "sync_on_open", "auto_sync_on_start",
                "auto_sync_interval_minutes", "auto_sync_show_progress",
                "max_sync_items", "startup_prewarm",
                "art_mode", "spinner_size", "cine21_ratings_db_path",
                "watcha_build_db_path", "debug_log", "perf_log",
            )
            for target in _live_plex_addon_targets_v1922():
                for key in setting_ids:
                    try:
                        target.setSetting(key, "")
                    except Exception:
                        pass
            _publish_live_plex_settings_v1922(server="", token="", account="", reason="full_reset_v1997")

            # Reset in-memory authoritative state before removing persisted files.
            core = _core()
            if core:
                try:
                    if hasattr(core, "set_initial_sync_done"):
                        core.set_initial_sync_done(False)
                    if hasattr(core, "set_last_auto_sync_at"):
                        core.set_last_auto_sync_at(0)
                except Exception:
                    pass

            deletion_errors_v2149 = []
            if base and os.path.isdir(base):
                # The addon profile is the single PKM persistence/cache root:
                # DB, cast_cache, wall poster viewport cache, episode thumb cache,
                # playstate snapshots and settings are all removed recursively.
                # A transient Windows sharing violation is retried, and final
                # success is decided from REAL survivors rather than one failed
                # os.remove() attempt.
                for root, dirs, files in os.walk(base, topdown=False):
                    for name in files:
                        path = os.path.join(root, name)
                        removed_v2149 = False
                        for _attempt_v2149 in range(6):
                            try:
                                if os.path.exists(path):
                                    os.remove(path)
                                removed_v2149 = True
                                break
                            except Exception as exc_v2149:
                                if _attempt_v2149 < 5:
                                    xbmc.sleep(80)
                                else:
                                    deletion_errors_v2149.append((path, str(exc_v2149)))
                        if not removed_v2149 and not os.path.exists(path):
                            removed_v2149 = True
                    for name in dirs:
                        path = os.path.join(root, name)
                        try:
                            os.rmdir(path)
                        except Exception:
                            pass

            # Remove now-empty profile directories including the plugin profile
            # root itself.  Full reset leaves no DB, WAL/SHM, JSON sidecar, cache,
            # lock, temp file, or empty subdirectory behind.
            try:
                if base and os.path.isdir(base):
                    for root_v2150, dirs_v2150, _files_v2150 in os.walk(base, topdown=False):
                        for name_v2150 in dirs_v2150:
                            path_v2150 = os.path.join(root_v2150, name_v2150)
                            try:
                                if os.path.isdir(path_v2150):
                                    os.rmdir(path_v2150)
                            except Exception:
                                pass
                    for _dir_try_v2150 in range(6):
                        try:
                            if os.path.isdir(base):
                                os.rmdir(base)
                            break
                        except Exception:
                            if _dir_try_v2150 < 5:
                                xbmc.sleep(80)
            except Exception as exc_v2150:
                deletion_errors_v2149.append((base or "", str(exc_v2150)))

            survivors_v2149 = []
            try:
                if base and os.path.isdir(base):
                    for root_v2149, dirs_v2149, files_v2149 in os.walk(base):
                        for name_v2149 in files_v2149:
                            survivors_v2149.append("FILE:" + os.path.relpath(os.path.join(root_v2149, name_v2149), base))
                        for name_v2149 in dirs_v2149:
                            survivors_v2149.append("DIR:" + os.path.relpath(os.path.join(root_v2149, name_v2149), base))
                    if not survivors_v2149:
                        survivors_v2149.append("DIR:.")
            except Exception as exc_v2149:
                deletion_errors_v2149.append((base or "", str(exc_v2149)))

            ok = not bool(survivors_v2149)
            reset_success_v2150 = bool(ok)
            _log("PKM_FULL_RESET_PROFILE_PURGE_V2150 base=%s survivors=%s transient_delete_errors=%d profile_dir_exists=%d final_ok=%d" % (
                base or "", ",".join(survivors_v2149) if survivors_v2149 else "-",
                len(deletion_errors_v2149), 1 if (base and os.path.isdir(base)) else 0, 1 if ok else 0
            ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            if deletion_errors_v2149:
                _log("PKM_FULL_RESET_DELETE_RETRY_V2149 errors=%s" % " | ".join(
                    "%s:%s" % (os.path.basename(path_v2149), err_v2149)
                    for path_v2149, err_v2149 in deletion_errors_v2149[:8]
                ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            # v2150: Do not recreate sidebar_order.json or signal a Home rebuild
            # after a successful purge.  Either action could recreate profile DB/
            # cache state immediately after deletion.  The hard reset barrier stays
            # latched until Kodi exits; the next process starts clean.
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.FullResetCompletedV2150", "1" if ok else "")
            win.setProperty("PlexKM.Home.ConnectionResetV1970", "1")
            win.setProperty("PlexKM.Home.ConnectionResetAtV1970", str(int(time.time() * 1000)))
            win.clearProperty("PlexKM.Home.PostResetLogoPendingV2008")

            # v2151: only after the profile is proven absent may the already-live
            # Home object discard its ListItems/scenes/properties.  This command is
            # handled by the reset-control sentinel, not by a normal Home refresh,
            # so it cannot reopen DB/network work after the purge.
            if ok and home_live_v2151:
                win.setProperty("PlexKM.Home.FullResetPurgeRequestV2151", reset_token_v2151)
                purge_waited_v2151 = 0
                while purge_waited_v2151 < 5000:
                    if win.getProperty("PlexKM.Home.FullResetMemoryPurgedV2151") == reset_token_v2151:
                        break
                    xbmc.sleep(25)
                    purge_waited_v2151 += 25
                home_purge_ok_v2151 = win.getProperty("PlexKM.Home.FullResetMemoryPurgedV2151") == reset_token_v2151
                _log("PKM_FULL_RESET_LIVE_HOME_PURGE_ACK_V2151 token=%s waited_ms=%d ok=%d" % (
                    reset_token_v2151, purge_waited_v2151, 1 if home_purge_ok_v2151 else 0
                ), xbmc.LOGINFO if home_purge_ok_v2151 else xbmc.LOGWARNING)
                if not home_purge_ok_v2151:
                    ok = False
                    reset_success_v2150 = False
                    win.setProperty("PlexKM.FullResetCompletedV2150", "")
            elif ok:
                _log("PKM_FULL_RESET_LIVE_HOME_PURGE_ACK_V2151 token=%s home_live=0 ok=1" % reset_token_v2151, xbmc.LOGINFO)
        except Exception:
            ok = False
            _log("PKM_FULL_RESET_FAILED_V1997 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            # v2150: once the user has explicitly confirmed a destructive full
            # reset, fail closed.  Whether purge succeeds or a locked survivor is
            # detected, NO PKM background work is allowed to resume in this Kodi
            # process.  This prevents a partial/failed reset from regenerating the
            # DB or cache.  Kodi restart creates a fresh process and clears these
            # transient Window properties.
            _log("PKM_FULL_RESET_BARRIER_LATCHED_V2150 ok=%d until=kodi_restart background_resume=0" % (1 if ok and reset_success_v2150 else 0), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        except Exception:
            pass

        # v2035: a successful full reset does not open a second completion
        # dialog. Redraw the same settings window immediately. Only a failure
        # still needs an explicit warning dialog.
        if not ok:
            open_pkm_message_dialog(
                "초기화 확인",
                "일부 파일을 삭제하지 못했습니다. Kodi를 종료한 뒤 다시 초기화해주세요.",
                ok_label="확인",
            )
        # v2151: after a successful reset the existing Home has already been
        # atomically replaced with the first-run surface behind this modal.  Close
        # the settings dialog now; keeping it open was the V2150 path that exposed
        # the stale pre-reset Home when the user later backed out.
        self.result_action = ""
        if ok:
            _log("PKM_FULL_RESET_FIRST_RUN_HANDOFF_V2151 ok=1 settings_close=1 stale_home_frames=0 background_resume=0", xbmc.LOGINFO)
            try:
                self.close()
            except Exception:
                pass
        else:
            _log("PKM_FULL_RESET_FIRST_RUN_HANDOFF_V2151 ok=0 settings_close=0 background_resume=0", xbmc.LOGWARNING)
        return

    def _show_external_rating_menu(self, push=True):
        self._render("외부 평점 관리", [
            "씨네21 평점",
            "왓챠피디아 평점",
        ], "external_rating_menu", push=push)

    def _show_cine21_menu(self, push=True):
        self._render("씨네21 평점", [
            "씨네21 평점 DB 가져오기",
            "평점 현황",
            "최근 추가 영화 확인",
            "매칭 테스트",
            "수집 및 갱신 안내",
        ], "cine21_menu", push=push)

    def _show_watcha_menu(self, push=True):
        self._render("왓챠피디아 평점", [
            "왓챠피디아 평점 DB 가져오기",
            "평점 현황",
            "최근 추가 영화 확인",
            "매칭 테스트",
            "수집 및 갱신 안내",
        ], "watcha_menu", push=push)

    def _show_library_selection(self, push=True, auth_initial=False, focus_pos=None):
        core = _core()
        # v1688: the authenticated first-run chooser is gated by a live
        # /library/sections response using the same PMS request path as the
        # former manual token flow. Cached rows cannot open this dialog.
        all_sections, labels, preselect = core._library_selection_rows(live_required=bool(auth_initial))
        if not all_sections:
            if auth_initial:
                # The live request has finished.  Never leave the old URL-save
                # "Plex 연결 확인 중" notice sticky forever after auth failure.
                try:
                    if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear_if_title"):
                        pkm_notify.pkm_notice_clear_if_title("Plex 연결 확인 중", force=True)
                except Exception:
                    pass
                _clear_server_switch_pending_home_ui_v1310(reason="token_auth_library_rows_failed_v1726")
                self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_NOT_OPENED_V1726 parent_focus=1", xbmc.LOGWARNING)
            return False
        # v1687: the legacy manual-token bootstrap preselected the first three
        # libraries.  plex.tv/link authentication has a different contract:
        # immediately show the chooser and let the user explicitly choose the
        # initial libraries.  Existing settings-menu visits still preserve the
        # current selection as before.
        self._library_select_auth_initial_v1687 = bool(auth_initial)
        if auth_initial:
            preselect = []
            # A successful live sections response completes the pending
            # URL+token connection check. Clear the sticky status before the
            # chooser is rendered, then keep the chooser's native list focused.
            _clear_plex_connection_state(reason="token_auth_live_sections_v1726")
            _clear_server_switch_pending_home_ui_v1310(reason="token_auth_live_sections_v1726")
            _set_server_switch_pending_v1310(False, reason="token_auth_live_sections_v1726")
            _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_EMPTY_V1726 sections=%d" % len(all_sections), xbmc.LOGINFO)
        self._render("PKM 라이브러리 선택", labels, "library_select", multiselect=True, preselect=preselect, payload=all_sections, push=push, focus_pos=focus_pos)
        if auth_initial:
            try:
                notice_token_v2045 = xbmcgui.Window(10000).getProperty("PlexKM.Auth.LibraryChooserNoticeTokenV2045") or ""
                if notice_token_v2045 and pkm_notify:
                    pkm_notify.pkm_notice_clear(expected_token=notice_token_v2045, force=True)
                    xbmcgui.Window(10000).clearProperty("PlexKM.Auth.LibraryChooserNoticeTokenV2045")
                    _log("PKM_LIBRARY_CHOOSER_NOTICE_CLEAR_V2045 token=%s" % notice_token_v2045, xbmc.LOGINFO)
            except Exception:
                pass
        _log("PKM_LIBRARY_SELECTION_RENDERED_V1748 auth_initial=%s focus_pos=%s actual=%s" % (("1" if auth_initial else "0"), str(focus_pos if focus_pos is not None else "default"), self._current_list_position_v1691()), xbmc.LOGINFO)
        return True

    def _show_addon_root(self, push=True):
        # Compatibility entry retained for old stack states. Open the Plex
        # server page directly; the intermediate one-row settings page is gone.
        self._show_plex_connection(push=push)

    def _return_to_plex_connection_v1700(self):
        while self._stack:
            state = self._stack.pop()
            if state and state[0] == "plex_connection":
                break
        self._show_plex_connection(push=False, focus_pos=2)

    def _save_plex_db_path_v1700(self, value):
        value = _plex_db_path_clean_v1700(value)
        if not _validate_plex_db_path_v1700(value, notify=True):
            return False
        ADDON.setSetting("plex_db_path", value)
        _notify("Plex Server DB 경로를 저장했습니다", ms=2400)
        _log("PKM_PLEX_DB_PATH_SAVED_V1700 path=%s" % value, xbmc.LOGINFO)
        self._return_to_plex_connection_v1700()
        return True

    def _show_plex_db_source_menu_v1700(self, push=True):
        current = (ADDON.getSetting("plex_db_path") or "").strip()
        items = [
            "로컬 / 연결 드라이브",
            "Kodi 네트워크 소스",
            "원격 DB 경로 직접 입력",
        ]
        payload = [
            {"action": "local"},
            {"action": "kodi_sources"},
            {"action": "direct"},
        ]
        if current:
            items.append("현재 DB 경로 지우기")
            payload.append({"action": "clear"})
        self._render("Plex Server DB 경로", items, "plex_db_source_v1700", push=push, payload=payload)
        self.setProperty("PlexKM.Dialog.Hint", "%s / 선택 / 홈 / 뒤로" % (short_setting_value(current, 42) if current else "DB 경로 선택"))

    def _show_plex_db_roots_v1700(self, roots, page, title, push=True):
        roots = list(roots or [])
        if not roots:
            _notify("사용 가능한 경로가 없습니다", icon=xbmcgui.NOTIFICATION_WARNING)
            return
        items = ["%s    %s" % (label, short_setting_value(path, 54)) for label, path in roots]
        payload = [{"kind": "root", "name": label, "path": path} for label, path in roots]
        self._render(title, items, page, push=push, payload=payload)

    def _show_plex_db_browser_v1700(self, path, root_path=None, push=True, focus_pos=None):
        path = _plex_db_path_clean_v1700(path)
        root_path = _plex_db_path_clean_v1700(root_path or path)
        try:
            entries = _plex_db_list_directory_v1700(path)
        except Exception:
            _notify("폴더를 열 수 없습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4000)
            _log("PKM_PLEX_DB_BROWSER_LIST_FAIL_V1700 path=%s err=%s" % (path, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return
        parent = _plex_db_parent_v1700(path, root_path)
        rows = []
        payload = []
        if parent:
            rows.append("상위 폴더")
            payload.append({"kind": "parent", "path": parent})
        for entry in entries:
            if entry["kind"] == "dir":
                rows.append("폴더    %s" % entry["name"])
            else:
                rows.append("DB 파일    %s" % entry["name"])
            payload.append(entry)
        if not rows:
            _notify("하위 폴더나 DB 파일이 없습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3600)
            return
        self._plex_db_browser_root_v1700 = root_path
        self._plex_db_browser_path_v1700 = path
        self._render("Plex Server DB 선택", rows, "plex_db_browser_v1700", push=push, focus_pos=focus_pos, payload={"entries": payload, "root": root_path, "path": path})
        self.setProperty("PlexKM.Dialog.Hint", "%s / 선택 / 홈 / 뒤로" % short_setting_value(path, 50))

    def _show_spinner_settings(self, push=True, focus_pos=None):
        # v1697: fixed Apple-ring style is shown in the header hint, not as a
        # non-actionable list row.  The list therefore contains only the three
        # selectable sizes, so Up from the first size cannot lose visible focus.
        current = pkm_spinner.get_size() if pkm_spinner else (ADDON.getSetting("spinner_size") or "medium")
        size_rows = (
            ("large", "대", 256),
            ("medium", "중", 128),
            ("small", "소", 64),
        )
        rows = []
        current_row = 1
        for row_index, (size, label, pixels) in enumerate(size_rows):
            rows.append("크기  %s (%dpx)" % (label, pixels))
            if size == current:
                current_row = row_index
        target_row = current_row if focus_pos is None else focus_pos
        self._render(
            "스피너 설정",
            rows,
            "spinner_settings",
            push=push,
            focus_pos=target_row,
            preselect=(current_row,),
            show_checks=(0, 1, 2),
        )
        self.setProperty("PlexKM.Dialog.Hint", "Apple 링 스타일 / 선택 / 홈 / 뒤로")
        _log("PKM_SPINNER_SETTINGS_MENU_V1697 style=apple_ring size=%s focus=%s square_row=%s" % (
            current,
            self._current_list_position_v1691(),
            current_row,
        ), xbmc.LOGINFO)

    def _plex_connection_rows_v1703(self):
        token = (ADDON.getSetting("plex_token") or "").strip()
        account = (ADDON.getSetting("plex_account_name") or "").strip()
        auth_label = "인증됨" + ((" · " + account) if account else "") if token else "미인증"
        server_value = (ADDON.getSetting("plex_url") or "").strip()
        if server_value == "http://127.0.0.1:32400":
            ADDON.setSetting("plex_url", "")
            server_value = ""
        return [
            "Plex 서버주소    %s" % (short_setting_value(server_value, 64) if server_value else "주소 입력"),
            "Plex 토큰 인증    %s" % auth_label,
            "Plex 연결 초기화",
        ]

    def _show_plex_connection(self, push=True, focus_pos=None):
        # v1699: Kodi-native navigation only.  Every visible row is actionable.
        self._render("Plex 서버 연결", self._plex_connection_rows_v1703(),
                     "plex_connection", push=push, focus_pos=focus_pos)

    def _refresh_plex_connection_in_place_v1703(self, focus_pos=None):
        """Refresh labels without resetting the parent list/window.

        Plex Home selection is a nested modal dialog.  Rebuilding the parent
        list immediately after it closes can leave Kodi focused on the nested
        dialog's 확인/취소 controls.  Keep the same native list control and update
        only its ListItems, then restore the parent's single-page properties.
        """
        rows = [_display_text_for_kodi(x) for x in self._plex_connection_rows_v1703()]
        self._items = list(rows)
        self._page = "plex_connection"
        self._multiselect = False
        self._preselect = set()
        self._actionable = None
        self._show_checks = set()
        self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi("Plex 서버 연결"))
        self.setProperty("PlexKM.Dialog.Mode", "single")
        self.setProperty("PlexKM.Dialog.Hint", "선택 / 홈 / 뒤로")
        for pos, label in enumerate(rows):
            try:
                item = self._list.getListItem(pos)
                item.setLabel(label)
                item.setProperty("actionable", "1")
                item.setProperty("showcheck", "0")
                item.setProperty("checked", "0")
            except Exception:
                pass
        target = self._current_list_position_v1691() if focus_pos is None else int(focus_pos)
        target = max(0, min(target, max(0, len(rows) - 1)))
        try:
            self._list.selectItem(target)
            self.setFocusId(self.LIST_ID)
        except Exception:
            pass
        _log("PKM_PLEX_CONNECTION_PARENT_FOCUS_RESTORED_V1703 row=%d" % target, xbmc.LOGINFO)

    def _toggle_focused(self):
        pos = int(self._list.getSelectedPosition()) if self._list else -1
        if pos < 0 or pos >= len(self._items):
            return
        if pos in self._preselect:
            self._preselect.remove(pos)
        else:
            self._preselect.add(pos)
        item = self._list.getListItem(pos)
        item.setProperty("checked", "1" if pos in self._preselect else "0")

    def _selected(self):
        try:
            return int(self._list.getSelectedPosition()) if self._list else -1
        except Exception:
            return -1

    def _set_single_checked_row_in_place_v1697(self, selected_idx):
        """Update one-of-N PKM square selection without rebuilding the list."""
        selected_idx = int(selected_idx)
        self._preselect = set([selected_idx])
        for pos in sorted(self._show_checks or []):
            if pos < 0 or pos >= len(self._items):
                continue
            try:
                item = self._list.getListItem(pos)
                item.setProperty("checked", "1" if pos == selected_idx else "0")
            except Exception:
                pass
        try:
            self.setFocusId(self.LIST_ID)
            self._list.selectItem(selected_idx)
        except Exception:
            pass

    def _reload_current(self):
        focus_pos = self._current_list_position_v1691()
        if self._page == "plex_connection":
            self._show_plex_connection(push=False, focus_pos=focus_pos)
        elif self._page == "addon_root":
            self._show_addon_root(push=False)
        elif self._page == "spinner_settings":
            self._show_spinner_settings(push=False)

    def _handle_single(self, idx):
        if idx < 0:
            return
        if self._page == "root":
            # v1926: Distinct root actions only.  Library selection owns the
            # sync of newly added libraries; startup owns later change checks.
            if idx == 0:
                self._show_plex_connection()
            elif idx == 1:
                self._show_spinner_settings()
            elif idx == 2:
                self._show_library_selection()
            elif idx == 3:
                if not _require_plex_server_settings_v1702("external_rating"):
                    return
                self._show_external_rating_menu()
            elif idx == 4:
                self._run_full_reset_v1997()
        elif self._page == "root_offline":
            if idx == 0:
                self._show_plex_connection()
            elif idx == 1:
                self._show_spinner_settings()
            elif idx == 2:
                self._show_library_selection()
            elif idx == 3:
                if not _require_plex_server_settings_v1702("external_rating_offline"):
                    return
                self._show_external_rating_menu()
            elif idx == 4:
                self._run_full_reset_v1997()
        elif self._page == "external_rating_menu":
            if idx == 0:
                self._show_cine21_menu()
            elif idx == 1:
                self._show_watcha_menu()
        elif self._page == "cine21_menu":
            core = _core()
            if idx == 0:
                selected = pkm_setting_file_browse("cine21_rate_build.db 선택", ADDON.getSetting("cine21_ratings_db_path"))
                if selected:
                    expected = "cine21_rate_build.db"
                    actual = str(selected or "").replace("\\", "/").rsplit("/", 1)[-1].lower()
                    if actual != expected:
                        open_pkm_message_dialog(
                            "씨네21 평점 DB 가져오기",
                            "파일명이 올바르지 않습니다.\n\n선택할 파일: cine21_rate_build.db",
                            ok_label="닫기",
                        )
                    else:
                        ADDON.setSetting("cine21_ratings_db_path", selected)
                        if core and hasattr(core, "cine21_import_ratings_db_from_settings"):
                            _log("PKM_SETTINGS_FLOW_CINE21_IMPORT_BEGIN path=%s" % selected, xbmc.LOGINFO)
                            core.cine21_import_ratings_db_from_settings({"ratings_db": selected, "source": "settings_import"})
                            _log("PKM_SETTINGS_FLOW_CINE21_IMPORT_END", xbmc.LOGINFO)
                self._show_cine21_menu(push=False)
            elif idx == 1:
                if core and hasattr(core, "cine21_show_match_summary_from_settings"):
                    core.cine21_show_match_summary_from_settings({"source": "settings_summary"})
                self._show_cine21_menu(push=False)
            elif idx == 2:
                if core and hasattr(core, "cine21_show_recent_target_summary_from_settings"):
                    core.cine21_show_recent_target_summary_from_settings({"source": "settings_recent_target"})
                self._show_cine21_menu(push=False)
            elif idx == 3:
                _log("PKM_SETTINGS_FLOW_CINE21_RECENT_MATCH_TEST_CLICK", xbmc.LOGINFO)
                if core and hasattr(core, "cine21_show_recent_match_test_from_settings"):
                    result = core.cine21_show_recent_match_test_from_settings({"source": "settings_recent_match_test"})
                    _log("PKM_SETTINGS_FLOW_CINE21_RECENT_MATCH_TEST_END result=%s" % result, xbmc.LOGINFO)
                else:
                    open_pkm_message_dialog("씨네21 매칭 테스트", "매칭 테스트 실행 함수를 찾지 못했습니다.\nKodi 로그를 확인하세요.", ok_label="닫기")
                self._show_cine21_menu(push=False)
            elif idx == 4:
                message = (
                    "씨네21 평점은 Kodi 유휴 시간에 신규 영화 중심으로 자동 수집됩니다.\n\n"
                    "전체 평점 DB를 수동으로 다시 만들면 아래 파일로 저장됩니다.\n"
                    "cine21_rate_build.db\n\n"
                    "전체 생성은 2시간 이상 걸릴 수 있습니다."
                )
                if open_pkm_confirm_dialog("씨네21 수집 및 갱신 안내", message, yes_label="전체 생성", no_label="닫기"):
                    if core and hasattr(core, "cine21_generate_ratings_db_from_settings"):
                        _log("PKM_SETTINGS_FLOW_CINE21_GENERATE_BEGIN", xbmc.LOGINFO)
                        core.cine21_generate_ratings_db_from_settings({"source": "settings_generate"})
                        _log("PKM_SETTINGS_FLOW_CINE21_GENERATE_END", xbmc.LOGINFO)
                self._show_cine21_menu(push=False)
        elif self._page == "watcha_menu":
            core = _core()
            if idx == 0:
                selected = pkm_setting_file_browse("watcha_rate_build.db 선택", ADDON.getSetting("watcha_build_db_path"))
                if selected:
                    expected = "watcha_rate_build.db"
                    actual = str(selected or "").replace("\\", "/").rsplit("/", 1)[-1].lower()
                    if actual != expected:
                        open_pkm_message_dialog(
                            "왓챠피디아 평점 DB 가져오기",
                            "파일명이 올바르지 않습니다.\n\n선택할 파일: watcha_rate_build.db",
                            ok_label="닫기",
                        )
                    else:
                        ADDON.setSetting("watcha_build_db_path", selected)
                        if core and hasattr(core, "watcha_import_build_db_from_settings"):
                            _log("PKM_SETTINGS_FLOW_WATCHA_IMPORT_BEGIN path=%s" % selected, xbmc.LOGINFO)
                            core.watcha_import_build_db_from_settings({"build_db": selected, "source": "settings_import"})
                            _log("PKM_SETTINGS_FLOW_WATCHA_IMPORT_END", xbmc.LOGINFO)
                        else:
                            open_pkm_message_dialog("왓챠피디아 평점", "가져오기 실행 함수를 찾지 못했습니다.\nKodi 로그를 확인하세요.", ok_label="닫기")
                self._show_watcha_menu(push=False)
            elif idx == 1:
                if core and hasattr(core, "watcha_show_match_summary_from_settings"):
                    core.watcha_show_match_summary_from_settings({"source": "settings_summary"})
                self._show_watcha_menu(push=False)
            elif idx == 2:
                if core and hasattr(core, "watcha_show_recent_target_summary_from_settings"):
                    core.watcha_show_recent_target_summary_from_settings({"source": "settings_recent_target"})
                self._show_watcha_menu(push=False)
            elif idx == 3:
                if core and hasattr(core, "watcha_show_recent_match_test_from_settings"):
                    core.watcha_show_recent_match_test_from_settings({"source": "settings_recent_match_test"})
                self._show_watcha_menu(push=False)
            elif idx == 4:
                if core and hasattr(core, "watcha_show_build_script_notice_from_settings"):
                    core.watcha_show_build_script_notice_from_settings({"source": "settings_script_notice"})
                self._show_watcha_menu(push=False)
        elif self._page == "addon_root":
            if idx == 0:
                self._show_plex_connection()
        elif self._page == "spinner_settings":
            # v1697: all rows are real size choices.  Update the three list-item
            # properties in place so selection does not flash/recreate the page.
            sizes = ("large", "medium", "small")
            if 0 <= idx < len(sizes):
                size = sizes[idx]
                if pkm_spinner:
                    pkm_spinner.set_size(size, reason="pkm_settings_v1697")
                else:
                    ADDON.setSetting("spinner_size", size)
                self._set_single_checked_row_in_place_v1697(idx)
                _log("PKM_SPINNER_SIZE_SELECTED_V1697 size=%s pixels=%s row=%s inplace=1" % (
                    size,
                    {"small": 64, "medium": 128, "large": 256}.get(size, 128),
                    idx,
                ), xbmc.LOGINFO)
        elif self._page == "plex_db_source_v1700":
            if not isinstance(self._payload, list) or idx < 0 or idx >= len(self._payload):
                return
            action_name = str((self._payload[idx] or {}).get("action") or "")
            if action_name == "local":
                self._show_plex_db_roots_v1700(_local_storage_roots_v1700(), "plex_db_local_roots_v1700", "로컬 / 연결 드라이브")
            elif action_name == "kodi_sources":
                sources = _kodi_file_sources_v1700()
                if not sources:
                    _notify("Kodi에 등록된 네트워크 소스가 없습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4000)
                    return
                self._show_plex_db_roots_v1700(sources, "plex_db_kodi_sources_v1700", "Kodi 네트워크 소스")
            elif action_name == "direct":
                self._open_inline_address_v1711(input_kind="plex_db_path")
                return
            elif action_name == "clear":
                if open_pkm_confirm_dialog("Plex Server DB 경로", "저장된 DB 경로를 지우시겠습니까?", yes_label="지우기", no_label="취소"):
                    ADDON.setSetting("plex_db_path", "")
                    self._return_to_plex_connection_v1700()
        elif self._page in ("plex_db_local_roots_v1700", "plex_db_kodi_sources_v1700"):
            if not isinstance(self._payload, list) or idx < 0 or idx >= len(self._payload):
                return
            entry = self._payload[idx] or {}
            path = str(entry.get("path") or "")
            if path:
                self._show_plex_db_browser_v1700(path, root_path=path, push=True)
        elif self._page == "plex_db_browser_v1700":
            payload = self._payload if isinstance(self._payload, dict) else {}
            entries = payload.get("entries") or []
            if idx < 0 or idx >= len(entries):
                return
            entry = entries[idx] or {}
            kind = str(entry.get("kind") or "")
            path = str(entry.get("path") or "")
            root_path = str(payload.get("root") or self._plex_db_browser_root_v1700 or "")
            if kind == "parent":
                # Native page history owns parent navigation.  Do not rebuild the
                # same directory in Python because that would duplicate a stack
                # frame and require Back twice.
                self._back()
            elif kind == "dir":
                self._show_plex_db_browser_v1700(path, root_path=root_path, push=True)
            elif kind == "file":
                self._save_plex_db_path_v1700(path)
        elif self._page == "plex_connection":
            changed_connection = False
            server_changed = False
            token_authenticated_v1680 = False
            # v1925 native list indices: server input, token auth, reset.
            # Recommendation index maintenance is always enabled through the
            # normal Plex API sync and no external Plex DB path is required.
            if idx == 0:
                self._open_inline_address_v1711()
                return
            elif idx == 1:
                if not _validate_saved_plex_endpoint_v1730(ADDON.getSetting("plex_url") or "", notify=True):
                    self._refresh_plex_connection_in_place_v1703(focus_pos=0)
                    _log("PKM_TOKEN_AUTH_BLOCKED_INVALID_ENDPOINT_V1730", xbmc.LOGWARNING)
                    return
                imported = False
                try:
                    from resources.lib import pkm_token_import
                    imported = bool(pkm_token_import.run_token_import())
                except Exception:
                    _log("PKM_TOKEN_IMPORT_RUN_FAILED_V1672\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                if imported:
                    # v1690: URL and token were written through different live
                    # xbmcaddon.Addon wrappers.  Synchronise those wrappers before
                    # the default.py-owned live sections gate reads them.  This is
                    # still the manual-token flow after acquisition; no cache or
                    # connection-state shortcut is introduced.
                    if not _sync_runtime_plex_auth_settings_v1690(pkm_token_import):
                        imported = False
                        _notify("Plex 인증값을 적용하지 못했습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4200)
                    else:
                        token_authenticated_v1680 = True
                        _log("PKM_TOKEN_AUTH_SAVED_MANUAL_EQUIVALENT_V1686", xbmc.LOGINFO)
            elif idx == 2:
                confirmed = open_pkm_confirm_dialog(
                    "Plex 연결 초기화",
                    "저장된 Plex 서버 주소와 토큰 정보를 삭제하시겠습니까?",
                    yes_label="초기화",
                    no_label="취소",
                    default_focus="yes",
                )
                if confirmed:
                    # v2050: keep the already visible Plex connection page and
                    # update only its three native ListItem labels.  The reset
                    # itself already clears the live server/token values; this
                    # in-place refresh makes that state visible immediately
                    # without closing/reopening the settings modal or rebuilding
                    # its list control.  Selection remains on the reset row.
                    ok_reset_v2050 = _reset_plex_connection_v1922()
                    if ok_reset_v2050:
                        self._refresh_plex_connection_in_place_v1703(focus_pos=2)
                    _log(
                        "PKM_PLEX_CONNECTION_RESET_LABEL_REFRESH_V2050 "
                        "ok=%s focus=reset_row redraw=in_place home_open=0"
                        % (1 if ok_reset_v2050 else 0),
                        xbmc.LOGINFO if ok_reset_v2050 else xbmc.LOGWARNING,
                    )
                # A cancelled confirmation also returns naturally to the same
                # native row; do not rebuild the parent page in either case.
                return
            if token_authenticated_v1680:
                # v1726: the QR dialog was closed on its owning thread and the
                # Plex Home user dialog has completed. Re-anchor the live parent
                # list first, then render the explicit library chooser.
                self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                xbmc.sleep(120)
                opened_v1726 = self._show_library_selection(push=True, auth_initial=True)
                if opened_v1726:
                    _log("PKM_TOKEN_AUTH_OPEN_LIBRARY_SELECTION_V1726 mode=link_user_then_library focus=list", xbmc.LOGINFO)
                else:
                    self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                return
            self._reload_current()
            if changed_connection:
                if server_changed or _server_switch_pending_v1310():
                    _set_server_switch_pending_home_ui_v1310(
                        "Plex 서버 연결 확인 중",
                        "라이브러리 정보를 확인합니다",
                        reason="settings_connection_changed_v1310",
                    )
                _probe_plex_after_connection_setting(reason="settings_plex_url_or_token_saved_v1310", server_changed=server_changed)

    def onFocus(self, controlId):
        audit_event(self, "onFocus", control_id=controlId)
        try:
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.Sync.HandoffProbeV1747") == "1":
                    _log("PKM_SETTINGS_FOCUS_DURING_SYNC_HANDOFF_V1747 page=%s control=%s" % (
                        str(self._page or ""), controlId
                    ), xbmc.LOGINFO)
            except Exception:
                pass
            if not self._inline_address_active_v1711 or self._inline_is_db_path_v1719():
                return
            if controlId == self.INLINE_VALUE_ID:
                self._inline_switch_server_field_v1730("address", repopulate=True)
            elif controlId == self.INLINE_PORT_ID_V1730:
                self._inline_switch_server_field_v1730("port", repopulate=True)
        except Exception:
            _log("PKM_INLINE_SERVER_FIELD_FOCUS_FAILED_V1730 control=%s" % controlId, xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        try:
            # v1382: Some key paths can deliver duplicate clicks while the
            # sidebar is recovering from an offline state.  Ignore same-dialog
            # click bursts so PKM 설정 does not open the first item twice.
            now_ms = int(time.time() * 1000)
            if controlId in (self.LIST_ID, self.OK_ID, self.HOME_ID):
                if now_ms - int(getattr(self, "_last_click_ms_v1382", 0) or 0) < 260:
                    _log("PKM_SETTINGS_FLOW_CLICK_DEBOUNCE_V1382 control=%s page=%s" % (controlId, self._page), xbmc.LOGINFO)
                    return
                self._last_click_ms_v1382 = now_ms
            if controlId in (getattr(self, "INLINE_VALUE_ID", -1), getattr(self, "INLINE_PORT_ID_V1730", -1)):
                if self._inline_address_active_v1711 and not self._inline_is_db_path_v1719():
                    self._inline_switch_server_field_v1730("port" if controlId == self.INLINE_PORT_ID_V1730 else "address", repopulate=True)
                    try:
                        self.setFocusId(self.INLINE_KEYBOARD_ID)
                    except Exception:
                        pass
                return
            if controlId == getattr(self, "INLINE_CONFIRM_ID_V1731", -1):
                if self._inline_address_active_v1711:
                    self._save_inline_address_v1711()
                return
            if controlId == getattr(self, "INLINE_HISTORY_ID", -1):
                if self._inline_address_active_v1711:
                    self._inline_history_select_v1713()
                return
            if controlId == getattr(self, "INLINE_HISTORY_CLEAR_ID", -1):
                if self._inline_address_active_v1711:
                    self._inline_history_clear_v1713()
                return
            if controlId == getattr(self, "INLINE_KEYBOARD_ID", -1):
                self._handle_inline_address_key_v1711()
                return
            if controlId == self.LIST_ID:
                if self._inline_address_active_v1711:
                    return
                if self._multiselect:
                    self._toggle_focused()
                else:
                    self._handle_single(self._selected())
            elif controlId == self.OK_ID:
                if self._page == "library_select":
                    core = _core()
                    chosen = sorted(self._preselect)
                    auth_initial = bool(getattr(self, "_library_select_auth_initial_v1687", False))
                    if auth_initial and not chosen:
                        _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_REQUIRED_V1687", xbmc.LOGINFO)
                        try:
                            _notify("라이브러리를 1개 이상 선택하세요", icon=xbmcgui.NOTIFICATION_WARNING, ms=3000)
                        except Exception:
                            pass
                        return
                    restore_pos_v1748 = self._current_list_position_v1691()
                    _log("PKM_LIBRARY_SELECTION_FOCUS_CAPTURE_V1748 pos=%s chosen=%s" % (restore_pos_v1748, ",".join(str(x) for x in chosen)), xbmc.LOGINFO)
                    apply_result = core._apply_library_selection(self._payload or [], chosen, force=False, auth_initial=auth_initial)
                    if apply_result:
                        self._library_select_auth_initial_v1687 = False
                        if apply_result == "restart_exit":
                            # v2090: library-add completion owns an exit-only modal.
                            # Do not close settings toward Home and do not request a
                            # live Home refresh while Kodi is terminating.
                            self.result_action = "restart_exit"
                            _log("PKM_LIBRARY_ADD_RESTART_EXIT_V2090 result=restart_exit home_reopen=0", xbmc.LOGINFO)
                            return
                        if auth_initial or apply_result == "open_home":
                            # Completed library sync closes the settings stack and
                            # returns directly to the existing Home window.
                            try:
                                xbmcgui.Window(10000).setProperty("PlexKM.Home.SettingsXmlFocusV2023", "1")
                            except Exception:
                                pass
                            self.result_action = "open_home"
                            if auth_initial:
                                _log("TOKEN_AUTH_OPEN_HOME_AFTER_SYNC_V1688", xbmc.LOGINFO)
                            else:
                                _log("PKM_LIBRARY_SYNC_OPEN_HOME result=open_home", xbmc.LOGINFO)
                            self.close()
                            return
                        self._show_library_selection(push=False, auth_initial=False, focus_pos=restore_pos_v1748)
                        _log("PKM_LIBRARY_SELECTION_FOCUS_RESTORE_V1748 requested=%s actual=%s" % (restore_pos_v1748, self._current_list_position_v1691()), xbmc.LOGINFO)
                elif self._multiselect:
                    self._back()
            elif controlId == self.HOME_ID:
                # Home remains alive under the modal. XML performs the only
                # focus handoff when this dialog unloads; no Python focus, timer,
                # retry, or animation guard is used.
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Home.SettingsXmlFocusV2023", "1")
                except Exception:
                    pass
                self.result_action = "open_home"
                _log("PKM_SETTINGS_FLOW_HOME_REQUEST page=%s owner=xml_onunload_9000" % self._page, xbmc.LOGINFO)
                self.close()
        except Exception:
            _log("PKM_SETTINGS_FLOW_CLICK_FAILED page=%s\n%s" % (self._page, traceback.format_exc()), xbmc.LOGWARNING)
            self.close()

    def onAction(self, action):
        # v1699: Up/Down is intentionally not handled in Python.  Kodi owns
        # native list movement through the XML list control.  Python handles
        # only Back-family actions.
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if self._inline_address_active_v1711:
            if aid in (9, 10, 92, 216, 247):
                self._close_inline_address_v1711(restore_focus=True)
            elif aid not in (1, 2, 3, 4, 7, 100):
                _log("PKM_INLINE_ADDRESS_PHYSICAL_KEY_BLOCKED_V1712 action=%s" % aid, xbmc.LOGINFO)
            # While the inline panel is active, every non-navigation action is
            # consumed here so H/P/S and other physical keys cannot open Kodi UI.
            return
        if aid in (9, 10, 92, 216, 247):
            self._back()


def open_pkm_settings_flow_dialog():
    dlg = None
    try:
        dlg = PKMSettingsFlowDialog(
            "plexkm_pkm_dialog.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            initial_page="root",
        )
        dlg.doModal()
        return dlg.result_action
    except Exception:
        _log("PKM_SETTINGS_FLOW_OPEN_FAILED fallback_to_root_list\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass


def open_pkm_addon_settings_dialog(handle=-1):
    """Compatibility entry for action=addon_settings.

    Keep the v626-safe single-dialog flow instead of opening Kodi's stock
    add-on settings UI or stacked dialogs.
    """
    result = open_pkm_settings_flow_dialog()
    if handle != -1:
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    return result
