# -*- coding: utf-8 -*-
"""
PKM Watcha build DB generator

Version
- v4 integrated fallback fix11
- Keep fix10 release-title fallback skip.
- Add franchise/subtitle/generic-keyword guard for specials/live/concert series false positives.
- Keep original v3 matching as phase 1.
- Run fallback only when phase 1 returns NO_MATCH.
- With --retry-nomatch, retry only PENDING/NO_MATCH and skip existing MATCHED/RATING_MISSING.

Purpose
- Read movie list from plex_km.db only.
- Crawl Watcha Pedia ratings with Playwright.
- Save results into watcha_rate_build.db only.
- Do NOT update plex_km.db in this step.

Example
    python make_watcha_build_db_local.py --full --delay 1.5 --jitter 1.0 --timeout 10

Requirements
    pip install playwright
    python -m playwright install chromium
"""

from __future__ import annotations

import argparse
import datetime as _dt
import difflib
import os
import random
import re
import sqlite3
import sys
import time
import traceback
import unicodedata
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote_plus

try:
    from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
    from playwright.sync_api import sync_playwright
except Exception:  # noqa: BLE001
    sync_playwright = None
    PlaywrightTimeoutError = Exception


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PLEX_DB = os.path.join(SCRIPT_DIR, "plex_km.db")
DEFAULT_OUT_DB = os.path.join(SCRIPT_DIR, "watcha_rate_build.db")

DEFAULT_LOG_FILE = os.path.join(SCRIPT_DIR, "watcha_build_%s.log" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
DEFAULT_DEBUG_DIR = os.path.join(SCRIPT_DIR, "watcha_debug_dump")
WATCHA_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36"
)
WATCHA_HEADERS = {
    "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
}


class Logger:
    def __init__(self, path: str):
        self.path = os.path.abspath(path)
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self.fp = open(self.path, "a", encoding="utf-8", buffering=1)

    def close(self) -> None:
        try:
            self.fp.close()
        except Exception:
            pass

    def log(self, *args: object) -> None:
        msg = " ".join(str(a) for a in args)
        line = "[%s] %s" % (now_text(), msg)
        print(msg)
        try:
            self.fp.write(line + "\n")
        except Exception:
            pass


LOGGER: Optional[Logger] = None
DEBUG_MATCH = False


def log_print(*args: object) -> None:
    if LOGGER is not None:
        LOGGER.log(*args)
    else:
        print(*args)

NOISE_PATTERNS = re.compile(
    r"(?i)\b(1080p|720p|2160p|4320p|bluray|blu-ray|h264|h\.264|x264|x265|hevc|"
    r"hdlight|web-dl|webdl|webrip|hdrip|brrip|dvdrip|aac|dts|dd5\.1|ddp5\.1|"
    r"atmos|rarbg|yts|fgt|chd|wiki|nf|netflix|amzn|amazon|dsnp|disney|"
    r"tving|wavve|watcha|proper|repack|remux|extended|unrated|limited)\b"
)
YEAR_PAT = re.compile(r"\b(19\d{2}|20\d{2})\b")
MOVIE_LINK_SELECTOR = 'a[href*="/ko/contents/m"]'

# Release/file-name cleanup helpers.
# Examples:
#   The.Uninvited.2009.1080p.BluRay.H264.AAC-RARBG -> The Uninvited
#   American.Pie.Presents.Band.Camp.2005.1080p...   -> American Pie Presents Band Camp
RELEASE_TAIL_PAT = re.compile(
    r"(?i)(?:^|[ ._\-])("
    r"1080p|720p|2160p|4320p|bluray|blu-ray|h264|h\.264|x264|x265|hevc|"
    r"web-dl|webdl|webrip|hdrip|brrip|dvdrip|aac|dts|dd5\.1|ddp5\.1|"
    r"atmos|rarbg|yts|fgt|chd|wiki|proper|repack|remux|extended|unrated|limited"
    r").*$"
)


def looks_like_release_filename(value: Optional[str]) -> bool:
    if not value:
        return False
    v = value.strip()
    if not v:
        return False
    dot_count = v.count('.')
    has_release_token = bool(NOISE_PATTERNS.search(v))
    has_year = bool(YEAR_PAT.search(v))
    return (dot_count >= 2 and has_year) or (has_release_token and has_year)


def release_title_variants(value: Optional[str]) -> List[str]:
    """Return safer search variants for torrent/release-like titles."""
    if not value:
        return []
    raw = unicodedata.normalize("NFC", value).strip()
    variants: List[str] = []

    # Remove bracketed groups first.
    s = re.sub(r"\[.*?\]|\(.*?\)|\{.*?\}", " ", raw)
    s = s.replace("_", ".")

    # Cut everything after the first year, then after the first release-tail token.
    m = YEAR_PAT.search(s)
    if m and m.start() > 0:
        variants.append(s[:m.start()])
    variants.append(RELEASE_TAIL_PAT.sub(" ", s))

    cleaned: List[str] = []
    for v in variants:
        v = v.replace(".", " ").replace("_", " ").replace("-", " ")
        v = NOISE_PATTERNS.sub(" ", v)
        v = YEAR_PAT.sub(" ", v)
        v = re.sub(r"\s+", " ", v).strip(" ._-'")
        if v and v not in cleaned:
            cleaned.append(v)
    return cleaned


def mixed_title_variants(value: Optional[str]) -> List[str]:
    """Split titles such as '\'젊음의 샘\' - Fountain of Youth'."""
    if not value:
        return []
    raw = unicodedata.normalize("NFC", value).strip()
    variants: List[str] = []
    # Remove surrounding Apple/streaming-style quote marks and keep the inner text.
    stripped = raw.strip(" \'\"“”‘’")
    if stripped and stripped != raw:
        variants.append(stripped)
    # Split Korean/English composite titles on dash-like separators.
    for sep in [" - ", " – ", " — "]:
        if sep in raw:
            left, right = raw.split(sep, 1)
            for part in (left, right):
                part = part.strip(" \'\"“”‘’")
                if part:
                    variants.append(part)
    # Ampersand variants.
    if "&" in raw:
        variants.append(raw.replace("&", "앤"))
        variants.append(raw.replace("&", "and"))
        variants.append(raw.replace("&", " "))
    out: List[str] = []
    for v in variants:
        v = pre_clean_query(v)
        if v and v not in out:
            out.append(v)
    return out


@dataclass(frozen=True)
class MovieRow:
    rating_key: str
    title: str
    original_title: str
    year: Optional[int]
    section_id: str


@dataclass(frozen=True)
class WatchaCandidate:
    code: str
    title: str
    year: str
    href: str


@dataclass(frozen=True)
class WatchaMatch:
    code: str
    title: str
    year: str
    match_type: str
    match_score: float


def now_text() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def clean_title(title: Optional[str]) -> str:
    if not title:
        return ""
    return re.sub(r"[^가-힣A-Za-z0-9]", "", unicodedata.normalize("NFC", title)).lower()


def pre_clean_query(query: Optional[str]) -> str:
    if not query:
        return ""
    q = unicodedata.normalize("NFC", query)
    q = q.replace(".", " ").replace("_", " ").replace("-", " ")
    q = re.sub(r"\[.*?\]|\(.*?\)|\{.*?\}", " ", q)
    q = NOISE_PATTERNS.sub(" ", q)
    q = re.sub(r"\s+", " ", q)
    return q.strip()


def get_jaccard_sim(str1: str, str2: str) -> float:
    if not str1 or not str2:
        return 0.0
    set1, set2 = set(str1), set(str2)
    union = set1 | set2
    if not union:
        return 0.0
    return len(set1 & set2) / len(union)


def safe_int_year(value: object) -> Optional[int]:
    try:
        if value is None or value == "":
            return None
        y = int(value)
        if 1900 <= y <= 2100:
            return y
    except Exception:  # noqa: BLE001
        return None
    return None


def connect_readonly(db_path: str) -> sqlite3.Connection:
    abs_path = os.path.abspath(db_path)
    return sqlite3.connect(f"file:{abs_path}?mode=ro", uri=True)


def load_movie_snapshot(plex_db_path: str, limit: int = 0, random_order: bool = False) -> List[MovieRow]:
    conn = connect_readonly(plex_db_path)
    try:
        sql = """
            SELECT rating_key,
                   COALESCE(title, '') AS title,
                   COALESCE(original_title, '') AS original_title,
                   year,
                   COALESCE(section_id, '') AS section_id
              FROM items
             WHERE plex_type = 'movie'
                OR kodi_type = 'movie'
             ORDER BY %s
        """ % ("RANDOM()" if random_order else "CAST(rating_key AS INTEGER), rating_key")
        if limit and limit > 0:
            sql += " LIMIT %d" % int(limit)
        rows = []
        for rating_key, title, original_title, year, section_id in conn.execute(sql):
            if not rating_key or not title:
                continue
            rows.append(MovieRow(str(rating_key), title, original_title or "", safe_int_year(year), str(section_id or "")))
        return rows
    finally:
        conn.close()


def init_build_db(out_db_path: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(out_db_path)) or ".", exist_ok=True)
    conn = sqlite3.connect(out_db_path, timeout=30)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS watcha_ratings (
                rating_key TEXT PRIMARY KEY,
                title TEXT,
                original_title TEXT,
                year INTEGER,
                section_id TEXT,

                watcha_rating REAL,
                watcha_count TEXT,

                watcha_code TEXT,
                watcha_title TEXT,
                watcha_year TEXT,
                match_status TEXT,
                match_type TEXT,
                match_score REAL,
                error TEXT,
                updated_at TEXT
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_watcha_ratings_status ON watcha_ratings(match_status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_watcha_ratings_title_year ON watcha_ratings(title, year)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS build_meta (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            """
        )
        conn.execute(
            "INSERT OR REPLACE INTO build_meta(key, value) VALUES('schema_version', '4_integrated_fallback_fix11_franchise_subtitle_guard')"
        )
        conn.commit()
    finally:
        conn.close()


def seed_movie_snapshot(out_db_path: str, movies: Sequence[MovieRow], overwrite: bool = False) -> None:
    conn = sqlite3.connect(out_db_path, timeout=30)
    try:
        if overwrite:
            conn.execute("DELETE FROM watcha_ratings")
        conn.executemany(
            """
            INSERT OR IGNORE INTO watcha_ratings
                (rating_key, title, original_title, year, section_id, match_status, updated_at)
            VALUES (?, ?, ?, ?, ?, 'PENDING', ?)
            """,
            [
                (m.rating_key, m.title, m.original_title, m.year, m.section_id, now_text())
                for m in movies
            ],
        )
        conn.execute("INSERT OR REPLACE INTO build_meta(key, value) VALUES('source_movie_count', ?)", (str(len(movies)),))
        conn.execute("INSERT OR REPLACE INTO build_meta(key, value) VALUES('last_seeded_at', ?)", (now_text(),))
        conn.commit()
    finally:
        conn.close()


def load_pending_rows(
    out_db_path: str,
    retry_failed: bool = False,
    retry_nomatch: bool = False,
    limit: int = 0,
    random_order: bool = False,
    title_filters: Optional[Sequence[str]] = None,
) -> List[MovieRow]:
    conn = sqlite3.connect(out_db_path, timeout=30)
    try:
        if retry_failed and retry_nomatch:
            where = "(match_status IS NULL OR match_status IN ('PENDING','ERROR','TIMEOUT','RATING_MISSING','NO_MATCH'))"
        elif retry_failed:
            where = "(match_status IS NULL OR match_status IN ('PENDING','ERROR','TIMEOUT','RATING_MISSING'))"
        elif retry_nomatch:
            where = "(match_status IS NULL OR match_status IN ('PENDING','NO_MATCH'))"
        else:
            where = "(match_status IS NULL OR match_status = 'PENDING')"

        params: List[object] = []
        if title_filters:
            title_filters = [t for t in title_filters if t]
            if title_filters:
                placeholders = ",".join(["?"] * len(title_filters))
                where += f" AND (title IN ({placeholders}) OR original_title IN ({placeholders}))"
                params.extend(title_filters)
                params.extend(title_filters)

        sql = f"""
            SELECT rating_key, title, COALESCE(original_title, ''), year, COALESCE(section_id, '')
              FROM watcha_ratings
             WHERE {where}
             ORDER BY %s
        """ % ("RANDOM()" if random_order else "CAST(rating_key AS INTEGER), rating_key")
        if limit and limit > 0:
            sql += " LIMIT %d" % int(limit)
        return [MovieRow(str(rk), t or "", ot or "", safe_int_year(y), s or "") for rk, t, ot, y, s in conn.execute(sql, params)]
    finally:
        conn.close()


def save_result(
    out_db_path: str,
    movie: MovieRow,
    rating: Optional[float],
    count: Optional[str],
    match: Optional[WatchaMatch],
    status: str,
    error: str = "",
) -> None:
    conn = sqlite3.connect(out_db_path, timeout=30)
    try:
        conn.execute(
            """
            UPDATE watcha_ratings
               SET watcha_rating = ?,
                   watcha_count = ?,
                   watcha_code = ?,
                   watcha_title = ?,
                   watcha_year = ?,
                   match_status = ?,
                   match_type = ?,
                   match_score = ?,
                   error = ?,
                   updated_at = ?
             WHERE rating_key = ?
            """,
            (
                rating,
                count,
                match.code if match else None,
                match.title if match else None,
                match.year if match else None,
                status,
                match.match_type if match else None,
                match.match_score if match else None,
                error[:500] if error else "",
                now_text(),
                movie.rating_key,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def search_watcha_dom(page, query: str, timeout_ms: int, candidate_limit: int = 5) -> List[WatchaCandidate]:
    q_clean = pre_clean_query(query).replace("&", " 앤 ")
    if not q_clean:
        return []
    url = "https://pedia.watcha.com/ko/search?query=" + quote_plus(q_clean)
    candidates: List[WatchaCandidate] = []
    try:
        page.goto(url, wait_until="commit", timeout=timeout_ms)
        try:
            page.wait_for_selector(MOVIE_LINK_SELECTOR, timeout=min(3000, timeout_ms))
        except PlaywrightTimeoutError:
            return []

        limit = max(1, int(candidate_limit or 5))
        for idx, link in enumerate(page.locator(MOVIE_LINK_SELECTOR).all()):
            if idx >= limit:
                break
            href = link.get_attribute("href") or ""
            if not href:
                continue
            text = link.inner_text(timeout=min(2000, timeout_ms)) or ""
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            title_cand = lines[0] if lines else ""
            year_cand = ""
            for line in lines:
                m = YEAR_PAT.search(line)
                if m:
                    year_cand = m.group(1)
                    break
            code = href.rstrip("/").split("/")[-1]
            if code.startswith("m") and title_cand:
                candidates.append(WatchaCandidate(code=code, title=title_cand, year=year_cand, href=href))
    except Exception:
        return candidates
    return candidates


def find_best_movie(movie: MovieRow, candidates: Sequence[WatchaCandidate]) -> Optional[WatchaMatch]:
    if not candidates:
        return None

    norm_title = clean_title(pre_clean_query(movie.title))
    norm_orig = clean_title(pre_clean_query(movie.original_title)) if movie.original_title else ""
    target_year = movie.year
    title_len = len(norm_title)
    is_short_title = 0 < title_len <= 3

    # 1) exact title, wider year tolerance for imported/release-year differences.
    # Exact match is always safe, including very short Korean titles such as "시간" or "로봇".
    for c in candidates:
        norm_cand = clean_title(c.title)
        cand_year = safe_int_year(c.year)
        exact = norm_cand == norm_title or (norm_orig and norm_cand == norm_orig)
        if exact:
            if not target_year or not cand_year or abs(target_year - cand_year) <= 3:
                if DEBUG_MATCH and is_short_title:
                    log_print("[SHORT_EXACT_OK]", movie.title, "->", c.title, "year", c.year)
                return WatchaMatch(c.code, c.title, c.year, "EXACT", 1.0)

    # 2) similar title.
    # Important guard:
    #   For short 2~3 character titles, partial containment is too dangerous.
    #   Examples that must NOT match:
    #     로봇 (2010) -> 로봇 앤 프랭크
    #     시간 (2006) -> 시간을 달리는 소녀
    #   Therefore short titles require near-exact similarity and cannot use contains matching.
    best: Optional[Tuple[WatchaCandidate, float]] = None
    for c in candidates:
        norm_cand = clean_title(c.title)
        if not norm_cand:
            continue
        sim_title = get_jaccard_sim(norm_title, norm_cand)
        sim_orig = get_jaccard_sim(norm_orig, norm_cand) if norm_orig else 0.0
        sim = max(sim_title, sim_orig)
        cand_year = safe_int_year(c.year)
        year_ok = not target_year or not cand_year or abs(target_year - cand_year) <= 2
        if not year_ok:
            continue

        if is_short_title:
            # No substring rescue for very short titles. Only near-identical strings pass.
            len_delta = abs(len(norm_cand) - len(norm_title))
            if sim < 0.92:
                if DEBUG_MATCH:
                    log_print("[SHORT_GUARD_REJECT]", movie.title, "->", c.title, "sim=%.4f" % sim, "len_delta=%d" % len_delta, "year", c.year)
                continue
            len_ok = len_delta <= 1
            if not len_ok and DEBUG_MATCH:
                log_print("[SHORT_GUARD_REJECT]", movie.title, "->", c.title, "sim=%.4f" % sim, "len_delta=%d" % len_delta, "year", c.year)
        else:
            contains = bool(norm_title and (norm_title in norm_cand or norm_cand in norm_title))
            len_ok = abs(len(norm_cand) - len(norm_title)) <= 12
            if not (sim >= 0.70 or contains):
                continue

        if len_ok and (best is None or sim > best[1]):
            best = (c, sim)

    if best:
        c, sim = best
        return WatchaMatch(c.code, c.title, c.year, "SIMILAR", round(sim, 4))
    return None

def parse_rating_and_count(body_text: str, body_html: str) -> Tuple[Optional[float], Optional[str]]:
    rating = None
    # Examples may appear as: 평균 3.7, 평균 ★3.7, 평균 별점 3.7
    for pat in (
        r"평균\s*(?:별점)?\s*(?:★\s*)?([0-5](?:\.[0-9])?)",
        r"평균\s*([0-5](?:\.[0-9])?)",
    ):
        m = re.search(pat, body_text)
        if m:
            try:
                rating = float(m.group(1))
                break
            except Exception:  # noqa: BLE001
                pass

    count = None
    count_patterns = (
        r"평가\s*([0-9,\.]+\s*(?:만)?명)",
        r"([0-9,\.]+\s*(?:만)?명)\s*평가",
        r"\(([^)]*(?:명|만명))\)",
    )
    target_text = body_text + "\n" + body_html
    for pat in count_patterns:
        m = re.search(pat, target_text)
        if m:
            count = re.sub(r"\s+", "", m.group(1)).strip()
            break

    return rating, count


def fetch_movie_detail_rating(page, code: str, timeout_ms: int) -> Tuple[Optional[float], Optional[str]]:
    url = "https://pedia.watcha.com/ko/contents/" + code
    for retry in range(2):
        try:
            page.goto(url, wait_until="commit", timeout=timeout_ms)
            try:
                page.wait_for_function("() => document.body && document.body.innerText.includes('평균')", timeout=min(1200, timeout_ms))
            except PlaywrightTimeoutError:
                pass
            body = page.locator("body")
            body_text = body.inner_text(timeout=min(3000, timeout_ms))
            body_html = page.content()
            rating, count = parse_rating_and_count(body_text, body_html)
            if rating is not None:
                return rating, count or "0명"
        except Exception:
            if retry == 0:
                time.sleep(0.5)

    return None, None


def fetch_movie_detail_text_and_rating(page, code: str, timeout_ms: int) -> Tuple[str, str, Optional[float], Optional[str]]:
    """Fetch detail page text/html and parse rating. Used only by fallback detail probe.

    This is intentionally separated from v3 path. It lets fallback verify candidates
    whose search-card title is translated differently from Plex title, e.g.
    PKM title/original "Exit Protocol" while Watcha card title is Korean.
    """
    url = "https://pedia.watcha.com/ko/contents/" + code
    for retry in range(2):
        try:
            page.goto(url, wait_until="commit", timeout=timeout_ms)
            try:
                page.wait_for_selector("body", timeout=min(2000, timeout_ms))
            except PlaywrightTimeoutError:
                pass
            body = page.locator("body")
            body_text = body.inner_text(timeout=min(3000, timeout_ms))
            body_html = page.content()
            rating, count = parse_rating_and_count(body_text, body_html)
            return body_text or "", body_html or "", rating, count
        except Exception:
            if retry == 0:
                time.sleep(0.5)
    return "", "", None, None


def _strip_year_from_query(value: str) -> str:
    return YEAR_PAT.sub(" ", value or "")


def _is_mostly_latin(value: str) -> bool:
    value = value or ""
    letters = re.findall(r"[A-Za-z가-힣]", value)
    if not letters:
        return False
    latin = re.findall(r"[A-Za-z]", value)
    return len(latin) / max(1, len(letters)) >= 0.65


def _series_markers_from_text(value: Optional[str]) -> set:
    """Extract explicit sequel/part markers, avoiding release years.

    This is used only by fallback safety checks. It intentionally detects
    obvious sequel markers such as:
      - 파트 2 / Part 2
      - 시즌 2 / Season 2
      - 2기 / 3기
      - terminal sequel number, e.g. 휴가 친구 2

    It must not treat title years like 2001, 1917, 2049, or 1984 as sequel numbers.
    """
    if not value:
        return set()
    raw = unicodedata.normalize("NFC", str(value)).lower()
    text = pre_clean_query(raw).lower()
    markers = set()

    word_map = {
        "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
        "i": "1", "ii": "2", "iii": "3", "iv": "4", "v": "5",
        "원": "1", "투": "2", "쓰리": "3", "포": "4", "파이브": "5",
    }

    # Explicit part/season/chapter markers.
    for pat in (
        r"(?:파트|part|pt|시즌|season|chapter|챕터|에디션|edition|스페셜\s*에디션|special\s*edition|movie|무비)\s*([0-9]+|one|two|three|four|five|i|ii|iii|iv|v|원|투|쓰리|포|파이브)",
        r"([0-9]+)\s*(?:기|편|부)",
        r"(?:제)\s*([0-9]+)\s*(?:편|부)",
    ):
        for m in re.finditer(pat, text, flags=re.IGNORECASE):
            token = (m.group(1) or "").lower()
            token = word_map.get(token, token)
            if token.isdigit() and 1 <= int(token) <= 9:
                markers.add(token)

    # Terminal sequel number, but do not treat 4-digit title years as markers.
    # Examples: 휴가 친구 2, 패밀리 플랜 2.
    m = re.search(r"(?:^|\s)([2-9])\s*$", text)
    if m:
        markers.add(m.group(1))

    # Release-style explicit series number before year/noise: Jaws.3.1983, Movie_2_2015.
    # Avoid treating 4-digit years as markers by requiring a single digit token.
    for m in re.finditer(r"(?:^|[ ._\-])([2-9])(?:[ ._\-]|$)", raw, flags=re.IGNORECASE):
        markers.add(m.group(1))

    # Normalized compact forms: 피어스트리트파트2 / fearstreetpart2 / 스페셜에디션3.
    compact = clean_title(text)
    for pat in (
        r"(?:파트|part|season|시즌|에디션|edition|스페셜에디션|specialedition|movie|무비)([2-9])",
        r"([2-9])기",
    ):
        for m in re.finditer(pat, compact, flags=re.IGNORECASE):
            markers.add(m.group(1))

    # Compact terminal sequel number without a space: 마마2, 죠스3, 러그래츠2.
    # This closes the fix8 hole where candidate title 마마2 passed even though
    # the source title Hell Girl had no sequel marker. 4-digit numeric endings
    # remain ignored as likely title years.
    m = re.search(r"(?<!\d)([2-9])$", compact)
    if m and not re.search(r"(?:19|20)\d{2}$", compact):
        markers.add(m.group(1))

    return markers


def _target_series_markers(movie: MovieRow, query: Optional[str] = None, norm_targets: Optional[Sequence[str]] = None) -> set:
    markers = set()
    for src in (movie.title, movie.original_title, query):
        markers |= _series_markers_from_text(src)
    # Use normalized targets only for explicit compact part markers, not raw digits.
    for t in norm_targets or []:
        for m in re.finditer(r"(?:파트|part|season|시즌)([2-9])", t or "", flags=re.IGNORECASE):
            markers.add(m.group(1))
    return markers


def _candidate_sequel_mismatch(movie: MovieRow, cand_title: str, query: Optional[str] = None, norm_targets: Optional[Sequence[str]] = None) -> bool:
    """Reject fallback candidates with different sequel/part numbers.

    Examples to reject:
      - Vacation Friends (2021) -> 휴가 친구 2
      - 피어 스트리트 파트 2: 1978 -> 피어 스트리트 파트 3: 1666
    """
    cand_markers = _series_markers_from_text(cand_title)
    if not cand_markers:
        return False
    target_markers = _target_series_markers(movie, query=query, norm_targets=norm_targets)
    if not target_markers:
        # Candidate has explicit sequel marker but target does not. Safer to reject.
        return True
    return cand_markers.isdisjoint(target_markers)


def _candidate_is_truncated_subtitle(movie: MovieRow, norm_cand: str) -> bool:
    # Reject base-title-only matches for titles that clearly have a subtitle.
    # Examples: 봉신연의: 탁탑천왕 -> 봉신연의, 친위대: 태자의 위기 -> 친위대.
    raw = movie.title or ""
    if not any(sep in raw for sep in [":", "：", " - ", " – ", " — "]):
        return False
    full = clean_title(pre_clean_query(raw))
    if not full or not norm_cand:
        return False
    if norm_cand in full and len(norm_cand) <= max(4, int(len(full) * 0.55)):
        return True
    return False


def _split_title_subtitle_for_guard(value: Optional[str]) -> Optional[Tuple[str, str]]:
    """Return (base, subtitle) for real subtitle separators.

    For Apple/streaming-style titles like:
      '스누피 스페셜: 루시의 새해맞이' - Snoopy Presents: For Auld Lang Syne
    use the left Korean/localized title before the dash and then split its colon.
    This lets us reject franchise-only matches where the subtitle is different:
      스누피 스페셜: 루시... -> 스누피 스페셜: 작은 실천의 힘
    """
    raw = unicodedata.normalize("NFC", value or "").strip()
    if not raw:
        return None

    # If this is quoted-local-title + dash + original title, keep the localized
    # left side for subtitle checks instead of disabling the guard entirely.
    if raw.startswith(("'", '"', "“", "‘")):
        for dash_sep in [" - ", " – ", " — "]:
            if dash_sep in raw:
                raw = raw.split(dash_sep, 1)[0].strip(" \'\"“”‘’")
                break

    for sep in [":", "：", " - ", " – ", " — ", "~"]:
        if sep in raw:
            left, right = raw.split(sep, 1)
            base = clean_title(pre_clean_query(left))
            sub = clean_title(pre_clean_query(right))
            if len(base) >= 4 and len(sub) >= 3:
                return base, sub
    return None


def _candidate_has_conflicting_subtitle(movie: MovieRow, cand_title: str) -> bool:
    """Reject fallback candidate that shares the base title but has a different subtitle.

    Example to reject:
      기동전사 건담 SEED DESTINY 스페셜 에디션: 자유의 대상
        -> 기동전사 건담 SEED Destiny 스페셜 에디션 3: 운명의 업화
    """
    split = _split_title_subtitle_for_guard(movie.title)
    if not split:
        return False
    base, sub = split
    cand = clean_title(pre_clean_query(cand_title))
    if not cand:
        return False
    # Same/near same base but the original subtitle is absent => likely another part/special.
    if base in cand and sub not in cand:
        return True
    return False


def _generic_guard_tokens(value: Optional[str]) -> List[str]:
    """Return distinctive tokens for franchise/special/live fallback safety.

    Common words such as special/live/concert/25th-anniversary are intentionally
    ignored because they caused false positives like:
      Yanni live -> Miss Saigon 25th anniversary concert
      High School Musical Christmas special -> Kinky Boots live
      Snoopy Presents: one special -> another Snoopy special
    """
    raw = unicodedata.normalize("NFC", value or "").lower()
    if not raw:
        return []
    # Remove release noise and years so they cannot become overlap evidence.
    raw = NOISE_PATTERNS.sub(" ", raw)
    raw = YEAR_PAT.sub(" ", raw)
    # For quoted local title + original title, preserve both sides as possible
    # evidence, but tokenization below removes generic connective words.
    cleaned = pre_clean_query(raw).lower()

    generic_words = {
        # Korean generic franchise/special/live words
        "스페셜", "특별", "특집", "공연", "콘서트", "라이브", "뮤지컬",
        "크리스마스", "새해", "기념", "주년", "극장판", "영화", "무비",
        "시즌", "파트", "에피소드", "레슨", "편", "부", "장", "기",
        "이야기", "말하지", "못한", "영국", "라이브러리",
        # English generic words
        "special", "presents", "present", "live", "concert", "musical",
        "christmas", "anniversary", "edition", "episode", "part", "chapter",
        "movie", "film", "season", "story", "stories", "untold", "uk",
        "home", "one", "two", "three", "four", "five", "for", "and", "the",
        "of", "to", "in", "on", "a", "an", "with", "from", "now", "ever",
    }

    tokens: List[str] = []
    # Split Latin/Korean/numeric chunks. Keep CJK chunks long enough to be names
    # and Latin chunks long enough to be meaningful names.
    for t in re.findall(r"[가-힣A-Za-z0-9]+", cleaned):
        t = t.lower().strip()
        if not t or t in generic_words:
            continue
        if re.fullmatch(r"\d+", t):
            continue
        # Remove pure ordinal/anniversary-style remains.
        if re.fullmatch(r"[0-9]+(?:th|st|nd|rd)?", t):
            continue
        if re.search(r"[가-힣]", t):
            if len(t) < 2:
                continue
        else:
            if len(t) < 4:
                continue
        if t not in tokens:
            tokens.append(t)

    # Add compact normalized chunk when it is not just generic. This helps names
    # such as highschoolmusical, snoopy, yanni, misssaigon.
    compact = clean_title(cleaned)
    for gw in generic_words:
        compact = compact.replace(clean_title(gw), " ")
    for t in re.findall(r"[가-힣A-Za-z0-9]+", compact):
        t = t.lower().strip()
        if len(t) >= 4 and not re.fullmatch(r"\d+", t) and t not in tokens:
            tokens.append(t)
    return tokens


def _is_special_franchise_risk(value: Optional[str]) -> bool:
    raw = unicodedata.normalize("NFC", value or "").lower()
    if not raw:
        return False
    risk_words = (
        "스페셜", "특별", "특집", "라이브", "콘서트", "뮤지컬", "브로드웨이",
        "presents", "special", "live", "concert", "musical", "untold",
        "anniversary", "christmas", "snoopy", "high school musical",
    )
    return any(w in raw for w in risk_words) or bool(_split_title_subtitle_for_guard(raw))


def _has_distinctive_overlap(movie: MovieRow, cand_title: str, query: Optional[str] = None) -> bool:
    target_tokens: List[str] = []
    for src in (movie.title, movie.original_title, query):
        for tok in _generic_guard_tokens(src):
            if tok not in target_tokens:
                target_tokens.append(tok)
    cand_tokens = _generic_guard_tokens(cand_title)
    if not target_tokens or not cand_tokens:
        return False
    # Exact token overlap.
    if set(target_tokens) & set(cand_tokens):
        return True
    # Containment for translated/spacing variants, but do not let very short
    # chunks rescue unrelated titles.
    for a in target_tokens:
        for b in cand_tokens:
            if min(len(a), len(b)) >= 4 and (a in b or b in a):
                return True
    return False


def _candidate_generic_only_mismatch(movie: MovieRow, cand_title: str, query: Optional[str] = None) -> bool:
    """Reject special/franchise/live matches supported only by generic words.

    This is intentionally activated only for risky title shapes so normal alternate
    Korean titles such as 백사의 결별 -> 병사와 수녀 are not affected.
    """
    if not (_is_special_franchise_risk(movie.title) or _is_special_franchise_risk(movie.original_title) or _is_special_franchise_risk(query) or _is_special_franchise_risk(cand_title)):
        return False
    return not _has_distinctive_overlap(movie, cand_title, query=query)


def _candidate_struct_mismatch(movie: MovieRow, cand_title: str, query: Optional[str] = None, norm_targets: Optional[Sequence[str]] = None) -> bool:
    norm_cand = clean_title(cand_title)
    return (
        _candidate_sequel_mismatch(movie, cand_title, query=query, norm_targets=norm_targets)
        or _candidate_is_truncated_subtitle(movie, norm_cand)
        or _candidate_has_conflicting_subtitle(movie, cand_title)
        or _candidate_generic_only_mismatch(movie, cand_title, query=query)
    )


def _is_tiny_or_numeric_query(q: Optional[str]) -> bool:
    n = clean_title(pre_clean_query(q))
    if not n:
        return True
    if len(n) <= 3:
        return True
    if re.fullmatch(r"\d+", n):
        return True
    return False


def fallback_detail_probe(page, movie: MovieRow, candidates: Sequence[WatchaCandidate], query: str, timeout_ms: int, probe_limit: int = 5) -> Tuple[Optional[float], Optional[str], Optional[WatchaMatch], str, str]:
    """Safe detail-page fallback.

    Search result cards sometimes expose only the Korean title, while the detail page
    contains the original English title. Example:
        PKM: Exit Protocol (2025)
        Watcha card: 킬러 대 킬러 대 킬러 (2025)
        Detail page contains: Exit Protocol

    This probe only accepts a candidate when the year is close and the detail body
    contains a strong normalized title/original-title/query token. It should not
    rescue unrelated short/common Korean titles.
    """
    if not candidates:
        return None, None, None, "NO_MATCH", "fallback_detail_no_candidate"

    target_years = fallback_target_years(movie)

    def year_ok(cand_year_text: str) -> bool:
        cand_year = safe_int_year(cand_year_text)
        if cand_year is None or not target_years:
            return False
        return min(abs(cand_year - y) for y in target_years) <= 2

    # Fix5: detail probing is powerful and therefore dangerous. Use it mainly
    # for Latin original/release titles, e.g. Exit Protocol -> 킬러 대 킬러 대 킬러.
    # Do not use short Korean fragments as detail needles.
    raw_needles: List[Tuple[str, str]] = []  # (needle, source_type)

    def add_needle(src: Optional[str], source_type: str) -> None:
        q = pre_clean_query(src)
        if not q:
            return
        item = (q, source_type)
        if item not in raw_needles:
            raw_needles.append(item)

    add_needle(movie.original_title, "original")
    add_needle(_strip_year_from_query(query), "query")
    # Use movie.title only if it is mostly Latin or release-like. Korean title-body
    # hits cause false positives through generic text on detail pages.
    if _is_mostly_latin(movie.title) or looks_like_release_filename(movie.title):
        add_needle(movie.title, "title")

    for src, source_type in ((movie.original_title, "original_variant"), (movie.title, "title_variant")):
        for v in fallback_text_variants(src):
            if _is_mostly_latin(v) or looks_like_release_filename(src):
                add_needle(v, source_type)

    needles: List[Tuple[str, str]] = []
    for n, source_type in raw_needles:
        cn = clean_title(n)
        if len(cn) >= 8 and not re.fullmatch(r"\d+", cn):
            # Detail probe accepts mostly-Latin needles only. This avoids cases like
            # 감옥정사 -> 제일베이트, 노트르담 드 파리 -> 노틀담의 꼽추.
            if _is_mostly_latin(n) and (cn, source_type) not in needles:
                needles.append((cn, source_type))

    if not needles:
        return None, None, None, "NO_MATCH", "fallback_detail_no_substantial_needle"

    for c in list(candidates)[:max(1, int(probe_limit or 5))]:
        if not year_ok(c.year):
            continue
        body_text, body_html, rating, count = fetch_movie_detail_text_and_rating(page, c.code, timeout_ms)
        body_norm = clean_title(body_text + "\n" + body_html)
        norm_cand = clean_title(c.title)
        targets = _norm_targets_for_movie(movie, query)
        if _candidate_struct_mismatch(movie, c.title, query=query, norm_targets=targets):
            if DEBUG_MATCH:
                log_print("[FALLBACK_DETAIL_STRUCT_REJECT]", movie.title, "->", c.title, "query", query, "year", c.year)
            continue

        hit = None
        hit_type = None
        for needle, source_type in needles:
            if needle in body_norm:
                hit = needle
                hit_type = source_type
                break
        if not hit:
            if DEBUG_MATCH:
                log_print("[FALLBACK_DETAIL_REJECT]", movie.title, "->", c.title, "query", query, "year", c.year)
            continue
        match = WatchaMatch(c.code, c.title, c.year, "FALLBACK_DETAIL_ORIGINAL", 0.96)
        if rating is not None:
            return rating, count or "0명", match, "MATCHED", ""
        return None, None, match, "RATING_MISSING", "rating_not_found"

    return None, None, None, "NO_MATCH", "fallback_detail_candidate_found_but_not_verified"


def candidate_queries(movie: MovieRow) -> List[str]:
    queries: List[str] = []

    def add(q: Optional[str]) -> None:
        q2 = pre_clean_query(q)
        if q2 and q2 not in queries:
            queries.append(q2)

    # Release/file-name titles should try a clean title first.
    # The.Uninvited.2009.1080p.BluRay.H264.AAC-RARBG -> The Uninvited
    if looks_like_release_filename(movie.title):
        for v in release_title_variants(movie.title):
            add(v)

    # Mixed title variants, e.g. "'젊음의 샘' - Fountain of Youth".
    for v in mixed_title_variants(movie.title):
        add(v)

    base = pre_clean_query(movie.title)
    if base:
        add(base)

    if any(ch in movie.title for ch in [":", "-", "–", "—"]):
        alt = pre_clean_query(movie.title.replace(":", " ").replace("-", " ").replace("–", " ").replace("—", " "))
        add(alt)

    # Original title fallback. Also clean it as a release name if needed.
    if looks_like_release_filename(movie.original_title):
        for v in release_title_variants(movie.original_title):
            add(v)
    for v in mixed_title_variants(movie.original_title):
        add(v)
    orig = pre_clean_query(movie.original_title)
    if orig:
        add(orig)

    return queries



def extract_years_from_text(value: Optional[str]) -> List[int]:
    years: List[int] = []
    if not value:
        return years
    for m in YEAR_PAT.finditer(value):
        y = safe_int_year(m.group(1))
        if y is not None and y not in years:
            years.append(y)
    return years


_ROMAN_MAP = {
    " i ": " 1 ",
    " ii ": " 2 ",
    " iii ": " 3 ",
    " iv ": " 4 ",
    " v ": " 5 ",
}

_NUMBER_WORD_MAP = {
    " 원 ": " 1 ",
    " 투 ": " 2 ",
    " 쓰리 ": " 3 ",
    " 포 ": " 4 ",
    " 파이브 ": " 5 ",
    " 넘버 투 ": " 2 ",
    " 넘버 원 ": " 1 ",
    " 넘버 쓰리 ": " 3 ",
}


def fallback_text_variants(value: Optional[str]) -> List[str]:
    """Aggressive but isolated variants used only after v3 NO_MATCH."""
    out: List[str] = []

    def add(q: Optional[str]) -> None:
        q2 = pre_clean_query(q)
        if q2 and q2 not in out:
            out.append(q2)

    if not value:
        return out
    raw = unicodedata.normalize("NFC", value).strip()

    # Keep v3 variants first.
    for v in release_title_variants(raw):
        add(v)
    for v in mixed_title_variants(raw):
        add(v)
    add(raw)

    # Strip common suffix markers that often differ between Plex and Watcha.
    s = raw
    suffix_patterns = [
        r"(?i)\bthe\s+final\b",
        r"(?i)\bthe\s+movie\b",
        r"(?i)\bmovie\b",
        r"(?i)\bpart\s*[0-9ivx]+\b",
        r"(?i)\bchapter\s*[0-9ivx]+\b",
        r"(?i)\bextended\s+edition\b",
        r"극장판",
        r"더\s*파이널",
        r"파이널",
    ]
    for pat in suffix_patterns:
        add(re.sub(pat, " ", s))

    # Colon/dash separators: try each major part independently.
    for sep in [":", " - ", " – ", " — ", "~", "："]:
        if sep in raw:
            for part in raw.split(sep):
                add(part)

    # Number word and roman numeral variants.
    padded = " " + pre_clean_query(raw).lower() + " "
    for k, v in _NUMBER_WORD_MAP.items():
        if k in padded:
            add(padded.replace(k, v))
    for k, v in _ROMAN_MAP.items():
        if k in padded:
            add(padded.replace(k, v))

    # Compact dotted release names with the embedded year stripped.
    if looks_like_release_filename(raw):
        m = YEAR_PAT.search(raw)
        if m and m.start() > 0:
            left = raw[:m.start()].replace('.', ' ').replace('_', ' ')
            # Avoid numeric/too-short release titles such as '31.2016...'.
            if not _is_tiny_or_numeric_query(left):
                add(left)
                # For series releases, also try progressively shorter prefixes,
                # but never down to numeric/tiny fragments.
                parts = [p for p in re.split(r"[ ._\-]+", left) if p]
                for cut in range(len(parts), max(1, len(parts) - 3), -1):
                    q = " ".join(parts[:cut])
                    if not _is_tiny_or_numeric_query(q):
                        add(q)

    return out


def fallback_candidate_queries(movie: MovieRow) -> List[str]:
    queries: List[str] = []

    def add(q: Optional[str]) -> None:
        q2 = pre_clean_query(q)
        if q2 and q2 not in queries:
            queries.append(q2)

    for source in (movie.title, movie.original_title):
        for v in fallback_text_variants(source):
            add(v)

    # Add year-qualified searches. This is especially useful for franchises
    # such as "미션 임파서블" where the correct old movie may be below top results.
    target_years = fallback_target_years(movie)
    base_variants = list(queries)
    for y in target_years:
        for q in base_variants[:10]:
            add(f"{q} {y}")

    return queries


def fallback_target_years(movie: MovieRow) -> List[int]:
    years: List[int] = []
    if movie.year is not None:
        years.append(movie.year)

    # Only use years embedded in the title/original title when the string looks
    # like a release filename. Plain movie titles often contain numbers that are
    # not release years, e.g. "2001 스페이스 오디세이", "블레이드 러너 2049",
    # "1917", "1984 최동원". Treating those numbers as target years creates
    # false year matches.
    for src in (movie.title, movie.original_title):
        if looks_like_release_filename(src):
            for y in extract_years_from_text(src):
                if y not in years:
                    years.append(y)
    return years


def _norm_targets_for_movie(movie: MovieRow, query: Optional[str] = None) -> List[str]:
    targets: List[str] = []

    def add(q: Optional[str]) -> None:
        n = clean_title(pre_clean_query(q))
        if n and n not in targets:
            targets.append(n)

    # Original v3 targets.
    add(movie.title)
    add(movie.original_title)
    # Fallback variants become valid match targets too. This fixes mixed titles
    # such as "'젊음의 샘' - Fountain of Youth" where Watcha returns only one side.
    for source in (movie.title, movie.original_title):
        for v in fallback_text_variants(source):
            add(v)
    if query:
        add(query)
    return targets


def fallback_find_best_movie(movie: MovieRow, candidates: Sequence[WatchaCandidate], query: str = "") -> Optional[WatchaMatch]:
    if not candidates:
        return None

    targets = _norm_targets_for_movie(movie, query)
    target_years = fallback_target_years(movie)
    short_targets = [t for t in targets if 0 < len(t) <= 3]

    def year_distance(cand_year_text: str) -> Optional[int]:
        cand_year = safe_int_year(cand_year_text)
        if cand_year is None or not target_years:
            return None
        return min(abs(cand_year - y) for y in target_years)

    # 1) exact against any fallback target.
    for c in candidates:
        norm_cand = clean_title(c.title)
        yd = year_distance(c.year)
        if _candidate_struct_mismatch(movie, c.title, query=query, norm_targets=targets):
            if DEBUG_MATCH:
                log_print("[FALLBACK_EXACT_STRUCT_REJECT]", movie.title, "->", c.title, "year", c.year)
            continue
        if norm_cand in targets:
            # Fallback exact is stricter than v3 exact. Short/generic titles such
            # as "헝거", "편지", "추적" are easy to collide across years.
            # Allow 1-year drift for short titles and 2-year drift for longer titles.
            if yd is None:
                return WatchaMatch(c.code, c.title, c.year, "FALLBACK_EXACT", 1.0)
            max_yd = 1 if len(norm_cand) <= 3 else 2
            if yd <= max_yd:
                return WatchaMatch(c.code, c.title, c.year, "FALLBACK_EXACT", 1.0)
            if DEBUG_MATCH:
                log_print("[FALLBACK_EXACT_YEAR_REJECT]", movie.title, "->", c.title, "candidate_year", c.year, "target_years", target_years, "yd", yd)

    # 2) similar against any fallback target.
    best: Optional[Tuple[WatchaCandidate, float, str]] = None
    for c in candidates:
        norm_cand = clean_title(c.title)
        if not norm_cand:
            continue
        if _candidate_struct_mismatch(movie, c.title, query=query, norm_targets=targets):
            if DEBUG_MATCH:
                log_print("[FALLBACK_SIMILAR_STRUCT_REJECT]", movie.title, "->", c.title, "year", c.year)
            continue
        yd = year_distance(c.year)
        if yd is not None and yd > 2:
            continue

        for target in targets:
            if not target:
                continue
            sim_j = get_jaccard_sim(target, norm_cand)
            sim_seq = difflib.SequenceMatcher(None, target, norm_cand).ratio()
            sim = max(sim_j, sim_seq)
            contains = bool(target and (target in norm_cand or norm_cand in target))
            len_delta = abs(len(norm_cand) - len(target))

            # Reject very short candidate rescue unless it is exact. This prevents
            # false positives such as "평범한 사건" -> "사건" or series-base
            # truncations being accepted by containment.
            if len(norm_cand) <= 3 and norm_cand not in targets:
                if DEBUG_MATCH:
                    log_print("[FALLBACK_SHORT_CAND_REJECT]", movie.title, "->", c.title, "target", target, "sim=%.4f" % sim, "len_delta=%d" % len_delta, "year", c.year)
                continue

            if len(target) <= 3 or short_targets:
                # Keep v3 short-title safety. Do not rescue "시간" -> "시간을 달리는 소녀".
                if sim < 0.92 or len_delta > 1:
                    if DEBUG_MATCH:
                        log_print("[FALLBACK_SHORT_REJECT]", movie.title, "->", c.title, "target", target, "sim=%.4f" % sim, "len_delta=%d" % len_delta, "year", c.year)
                    continue
            else:
                # Similar fallback should be fairly strict; containment alone is
                # allowed only when the shorter side is still substantial.
                substantial_contains = contains and min(len(target), len(norm_cand)) >= 4 and len_delta <= 12
                if not (sim >= 0.78 or substantial_contains):
                    continue
                if len_delta > 14 and sim < 0.88:
                    continue

            if best is None or sim > best[1]:
                best = (c, sim, "FALLBACK_SIMILAR")

    if best:
        c, sim, mtype = best
        return WatchaMatch(c.code, c.title, c.year, mtype, round(sim, 4))

    # 3) Fix5: disable automatic TOP_YEAR matching. It reduced NO_MATCH but caused
    # false positives. Detail-original verification is safer for translated titles.
    return None


def fallback_crawl_one(page, movie: MovieRow, timeout_ms: int, candidate_limit: int = 25) -> Tuple[Optional[float], Optional[str], Optional[WatchaMatch], str, str]:
    last_candidates: List[WatchaCandidate] = []
    last_error = "fallback_no_candidate"
    for query in fallback_candidate_queries(movie):
        candidates = search_watcha_dom(page, query, timeout_ms, candidate_limit=candidate_limit)
        last_candidates = candidates or last_candidates
        match = fallback_find_best_movie(movie, candidates, query=query)
        if match:
            rating, count = fetch_movie_detail_rating(page, match.code, timeout_ms)
            if rating is not None:
                return rating, count, match, "MATCHED", ""
            return None, None, match, "RATING_MISSING", "rating_not_found"

        # Fix4: if the search-card title is translated differently, verify detail page
        # original title/body before declaring NO_MATCH. This is still fallback-only.
        if candidates:
            rating, count, detail_match, status, error = fallback_detail_probe(
                page, movie, candidates, query, timeout_ms, probe_limit=min(5, max(1, int(candidate_limit or 25)))
            )
            if status != "NO_MATCH":
                return rating, count, detail_match, status, error
            last_error = error

    if last_candidates:
        return None, None, None, "NO_MATCH", last_error or "fallback_candidate_found_but_not_matched"
    return None, None, None, "NO_MATCH", "fallback_no_candidate"

def crawl_one(page, movie: MovieRow, timeout_ms: int, enable_fallback: bool = True, fallback_candidate_limit: int = 25) -> Tuple[Optional[float], Optional[str], Optional[WatchaMatch], str, str]:
    # Phase 1: original v3 logic. Keep this first to preserve proven matches.
    last_candidates: List[WatchaCandidate] = []
    for query in candidate_queries(movie):
        candidates = search_watcha_dom(page, query, timeout_ms)
        last_candidates = candidates or last_candidates
        match = find_best_movie(movie, candidates)
        if match:
            rating, count = fetch_movie_detail_rating(page, match.code, timeout_ms)
            if rating is not None:
                return rating, count, match, "MATCHED", ""
            return None, None, match, "RATING_MISSING", "rating_not_found"

    # Phase 2: fallback only after v3 NO_MATCH.
    # Do not change RATING_MISSING decisions from phase 1 because the movie was already found.
    # Fix10: release/file-name style titles are usually metadata-unmatched library items.
    # Do not spend fallback effort or risk false positives here; leave them as NO_MATCH
    # so they can be corrected by the later metadata rematch workflow.
    if enable_fallback and (looks_like_release_filename(movie.title) or looks_like_release_filename(movie.original_title)):
        return None, None, None, "NO_MATCH", "release_filename_skipped_for_metadata_rematch"

    if enable_fallback:
        rating, count, match, status, error = fallback_crawl_one(page, movie, timeout_ms, candidate_limit=fallback_candidate_limit)
        if status != "NO_MATCH":
            return rating, count, match, status, error
        # If fallback also failed, keep fallback reason for diagnostics.
        return rating, count, match, status, error

    if last_candidates:
        return None, None, None, "NO_MATCH", "candidate_found_but_not_matched"
    return None, None, None, "NO_MATCH", "no_candidate"



def safe_filename(value: str, max_len: int = 80) -> str:
    value = re.sub(r"[^가-힣A-Za-z0-9._-]+", "_", value or "")
    value = value.strip("._-")
    return (value[:max_len] or "dump")


def dump_debug_page(page, debug_dir: str, idx: int, movie: MovieRow, reason: str) -> None:
    try:
        os.makedirs(debug_dir, exist_ok=True)
        base = "%04d_%s_%s" % (idx, safe_filename(movie.title), safe_filename(reason))
        html_path = os.path.join(debug_dir, base + ".html")
        txt_path = os.path.join(debug_dir, base + ".txt")
        png_path = os.path.join(debug_dir, base + ".png")
        try:
            html = page.content()
        except Exception as e:  # noqa: BLE001
            html = "<failed to read html: %r>" % e
        try:
            body_text = page.locator("body").inner_text(timeout=2000)
        except Exception as e:  # noqa: BLE001
            body_text = "<failed to read body text: %r>" % e
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("url: %s\n" % getattr(page, "url", ""))
            f.write("title: %s\n" % movie.title)
            f.write("year: %s\n" % (movie.year or ""))
            f.write("reason: %s\n\n" % reason)
            f.write(body_text)
        try:
            page.screenshot(path=png_path, full_page=True, timeout=5000)
        except Exception:
            pass
        log_print("[DUMP]", html_path)
    except Exception as e:  # noqa: BLE001
        log_print("[DUMP_ERROR]", repr(e))

def print_summary(out_db_path: str) -> None:
    conn = sqlite3.connect(out_db_path)
    try:
        total = conn.execute("SELECT COUNT(*) FROM watcha_ratings").fetchone()[0]
        log_print("\n================================================================================")
        log_print("Watcha build DB summary")
        log_print("================================================================================")
        log_print("DB    :", os.path.abspath(out_db_path))
        log_print("total :", total)
        for status, count in conn.execute(
            "SELECT COALESCE(match_status, 'NULL'), COUNT(*) FROM watcha_ratings GROUP BY COALESCE(match_status, 'NULL') ORDER BY 1"
        ):
            log_print("%-16s %s" % (status, count))
        ok = conn.execute("SELECT COUNT(*) FROM watcha_ratings WHERE watcha_rating IS NOT NULL").fetchone()[0]
        log_print("rating filled:", ok)
    finally:
        conn.close()


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Create watcha_rate_build.db from ./plex_km.db in the script folder.")
    # Fixed default paths by user request:
    #   input  = same folder as this py / plex_km.db
    #   output = same folder as this py / watcha_rate_build.db
    # --plex-db and --out are intentionally not exposed. Keep execution simple and safe.
    parser.add_argument("--full", action="store_true", help="Accepted for compatibility. Current build uses all movie rows by default.")
    parser.add_argument("--limit", type=int, default=0, help="Limit source movie count for test run.")
    parser.add_argument("--pending-limit", type=int, default=0, help="Limit pending crawl rows after seeding/title filter. Use this for safe NO_MATCH fallback tests.")
    parser.add_argument("--delay", type=float, default=0.7, help="Base delay between items. Default: 0.7")
    parser.add_argument("--jitter", type=float, default=0.3, help="Random jitter added to delay. Default: 0.3")
    parser.add_argument("--timeout", type=float, default=10.0, help="Navigation timeout in seconds. Default: 10")
    parser.add_argument("--reset-every", type=int, default=25, help="Reset browser context every N items. Default: 25")
    parser.add_argument("--overwrite", action="store_true", help="Clear watcha_ratings table before seeding.")
    parser.add_argument("--random", action="store_true", help="Randomly sample source movie rows. Use with --limit and usually --overwrite for match-rate tests.")
    parser.add_argument("--title", action="append", default=[], help="Only crawl exact title from plex_km.db. Can be used multiple times for targeted tests, e.g. --title 로봇 --title 시간")
    parser.add_argument("--debug-match", action="store_true", help="Print candidate rejection/acceptance details for short-title guard tests.")
    parser.add_argument("--retry-failed", action="store_true", help="Retry ERROR/TIMEOUT/RATING_MISSING rows too. RATING_MISSING remains retryable by design.")
    parser.add_argument("--retry-nomatch", action="store_true", help="Retry NO_MATCH rows too. Existing MATCHED rows are always skipped.")
    parser.add_argument("--no-fallback", action="store_true", help="Disable integrated fallback and run original v3 matching only.")
    parser.add_argument("--fallback-candidate-limit", type=int, default=25, help="Candidate count used only by fallback phase after v3 NO_MATCH. Default: 25")
    parser.add_argument("--headful", action="store_true", help="Run Chromium with visible window.")
    parser.add_argument("--seed-only", action="store_true", help="Only create DB and seed movie snapshot. Do not crawl.")
    parser.add_argument("--log-file", default=DEFAULT_LOG_FILE, help="Log file path. Default: watcha_build_YYYYMMDD_HHMMSS.log in script folder.")
    parser.add_argument("--cooldown-every", type=int, default=100, help="Take a longer pause every N items. Default: 100")
    parser.add_argument("--cooldown-sec", type=float, default=60.0, help="Cooldown seconds. Default: 60")
    parser.add_argument("--max-consecutive-fail", type=int, default=20, help="Stop if consecutive non-MATCHED rows reach this count. Default: 20")
    parser.add_argument("--debug-dump-dir", default=DEFAULT_DEBUG_DIR, help="Directory for HTML/TXT/PNG dumps on no_candidate. Default: ./watcha_debug_dump")
    parser.add_argument("--dump-on-no-candidate", action="store_true", help="Save HTML/TXT/PNG dump when search returns no candidates. Useful for Linux/headless debugging.")
    args = parser.parse_args(argv)
    global LOGGER, DEBUG_MATCH
    DEBUG_MATCH = bool(args.debug_match)
    LOGGER = Logger(args.log_file)
    log_print("log file      :", LOGGER.path)
    args.plex_db = DEFAULT_PLEX_DB
    args.out = DEFAULT_OUT_DB

    if not os.path.exists(args.plex_db):
        log_print("ERROR: plex_km.db not found in script folder: %s" % args.plex_db)
        log_print("Put plex_km.db in the same folder as make_watcha_build_db.py and run again.")
        return 2

    init_build_db(args.out)
    source_limit = 0 if args.title else args.limit
    movies = load_movie_snapshot(args.plex_db, source_limit, random_order=args.random)
    if args.title:
        wanted = set(args.title)
        movies = [m for m in movies if m.title in wanted or (m.original_title and m.original_title in wanted)]
        if args.limit and args.limit > 0:
            movies = movies[:args.limit]
    seed_movie_snapshot(args.out, movies, overwrite=args.overwrite)
    log_print("movie snapshot:", len(movies))
    log_print("random sample :", "YES" if args.random else "NO")
    if args.title:
        log_print("title filter  :", ", ".join(args.title))
    log_print("out DB        :", os.path.abspath(args.out))

    if args.seed_only:
        print_summary(args.out)
        return 0

    if sync_playwright is None:
        log_print("ERROR: playwright is not installed. Run: pip install playwright && python -m playwright install chromium")
        return 3

    pending = load_pending_rows(args.out, retry_failed=args.retry_failed, retry_nomatch=args.retry_nomatch, limit=args.pending_limit, random_order=args.random, title_filters=args.title)
    if not pending:
        log_print("No pending Watcha rows.")
        print_summary(args.out)
        return 0

    timeout_ms = int(max(1.0, args.timeout) * 1000)
    log_print("pending crawl :", len(pending))
    log_print("timeout       :", args.timeout)
    log_print("delay/jitter  :", args.delay, args.jitter)
    log_print("fallback      :", "OFF" if args.no_fallback else "ON", "candidate_limit=%s" % args.fallback_candidate_limit)
    log_print("retry_nomatch :", "YES" if args.retry_nomatch else "NO")
    if args.title:
        log_print("pending title scope:", "YES")
    if args.pending_limit:
        log_print("pending limit:", args.pending_limit)

    def new_watcha_context(browser_obj):
        return browser_obj.new_context(
            viewport={"width": 1366, "height": 900},
            locale="ko-KR",
            timezone_id="Asia/Seoul",
            user_agent=WATCHA_USER_AGENT,
            extra_http_headers=WATCHA_HEADERS,
        )

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=not args.headful,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
            ],
        )
        context = new_watcha_context(browser)
        page = context.new_page()
        try:
            page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        except Exception:
            pass
        try:
            page.goto("https://pedia.watcha.com/ko", wait_until="domcontentloaded", timeout=timeout_ms)
        except Exception:
            pass

        consecutive_fail = 0
        try:
            for idx, movie in enumerate(pending, 1):
                if args.reset_every > 0 and idx > 1 and (idx - 1) % args.reset_every == 0:
                    try:
                        page.close()
                    except Exception:
                        pass
                    try:
                        context.close()
                    except Exception:
                        pass
                    context = new_watcha_context(browser)
                    page = context.new_page()
                    try:
                        page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                    except Exception:
                        pass
                    try:
                        page.goto("https://pedia.watcha.com/ko", wait_until="commit", timeout=timeout_ms)
                    except Exception:
                        pass

                label = "%d/%d %s (%s)" % (idx, len(pending), movie.title, movie.year or "")
                try:
                    rating, count, match, status, error = crawl_one(page, movie, timeout_ms, enable_fallback=not args.no_fallback, fallback_candidate_limit=args.fallback_candidate_limit)
                    save_result(args.out, movie, rating, count, match, status, error)
                    if rating is not None:
                        consecutive_fail = 0
                        log_print("[OK]", label, "=>", rating, count or "0명", "/", match.title if match else "")
                    else:
                        if args.dump_on_no_candidate and status == "NO_MATCH" and error == "no_candidate":
                            dump_debug_page(page, args.debug_dump_dir, idx, movie, error)
                        consecutive_fail += 1
                        log_print("[%s]" % status, label, error, "consecutive_fail=%d" % consecutive_fail)
                except Exception as e:  # noqa: BLE001
                    consecutive_fail += 1
                    save_result(args.out, movie, None, None, None, "ERROR", repr(e))
                    log_print("[ERROR]", label, repr(e), "consecutive_fail=%d" % consecutive_fail)
                    log_print(traceback.format_exc())

                if args.max_consecutive_fail > 0 and consecutive_fail >= args.max_consecutive_fail:
                    log_print("STOP: consecutive failures reached", args.max_consecutive_fail)
                    log_print("This is a safety stop to avoid continuing during network/block/markup-change conditions.")
                    break

                if args.cooldown_every > 0 and idx < len(pending) and idx % args.cooldown_every == 0:
                    cool = max(0.0, args.cooldown_sec + random.uniform(0.0, max(0.0, args.cooldown_sec * 0.2)))
                    log_print("[COOLDOWN]", "processed=%d" % idx, "sleep=%.1fs" % cool)
                    time.sleep(cool)

                sleep_s = max(0.0, args.delay + random.uniform(0.0, max(0.0, args.jitter)))
                if sleep_s:
                    time.sleep(sleep_s)
        finally:
            try:
                context.close()
            except Exception:
                pass
            browser.close()

    print_summary(args.out)
    if LOGGER is not None:
        log_print("log file      :", LOGGER.path)
        LOGGER.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
