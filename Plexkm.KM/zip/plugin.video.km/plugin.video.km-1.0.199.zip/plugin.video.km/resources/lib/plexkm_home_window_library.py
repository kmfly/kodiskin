# -*- coding: utf-8 -*-
"""PKM home window part (R73): 라이브러리 월/정렬/인덱스.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartLibraryR73
    def _library_firstpaint_materialize_v2496(self, listitems, visible_count=18, reason="", allow_network=True):
        """Make every Library first-paint poster a verified local file before publish.

        The wall is fail-closed: remote/Kodi-cache presence alone never authorizes
        visibility.  Legitimate no-source items use the existing missing-poster card;
        transient fetch failures keep the source scene visible and never become a
        fake missing-poster placeholder.
        """
        started = _pkm_speed_ms()
        lis = list(listitems or [])
        limit = max(0, min(int(visible_count or 0), len(lis)))
        if limit <= 0:
            return True, 0, 0, 0

        records = []
        poster_source_sets = []
        ready_count = 0
        local_bound = 0
        downloaded_unique = 0
        legitimate_missing = 0
        for idx, li in enumerate(lis[:limit]):
            try:
                sources = tuple(self._poster_authority_sources_v2498(li) or [])
                primary = str(sources[0] if sources else "").strip()
                fallback = ""
                rating_key = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                explicit_missing = str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1"
            except Exception:
                primary = fallback = rating_key = ""
                sources = tuple()
                explicit_missing = False
            records.append({
                "idx": idx, "li": li, "primary": primary, "fallback": fallback,
                "sources": sources, "rating_key": rating_key,
                "explicit_missing": bool(explicit_missing), "ready": False,
            })
            poster_source_sets.append(list(sources))

        local_paths = self._poster_primary_local_paths_v2498(poster_source_sets)
        unresolved = {}
        for rec in records:
            if rec["explicit_missing"]:
                try:
                    rec["li"].setProperty("PlexKM.PosterFallbackArt", "")
                    rec["li"].setProperty("PlexKM.PosterFallbackArtActive", "")
                    rec["li"].setProperty("PlexKM.PosterFallbackRoleV2498", "")
                    rec["li"].setProperty("PlexKM.WallPosterDisplayV1644", "")
                except Exception:
                    pass
                rec["ready"] = True
                legitimate_missing += 1
                ready_count += 1
                continue
            idx = int(rec["idx"])
            local = str(local_paths[idx] if idx < len(local_paths) else "").strip()
            if local and self._startup_bind_local_poster_v2498(rec["li"], local, source="textures13_exact_poster"):
                rec["ready"] = True
                local_bound += 1
                ready_count += 1
                continue

            small_url = ""
            try:
                small_url = self._viewport_poster_url_v1937(rec["sources"], rating_key=rec["rating_key"])
            except Exception:
                small_url = ""
            small_local = self._wall_poster_local_path_v1644(small_url) if small_url else ""
            if small_local and self._local_poster_file_ready_v1865(small_local):
                if self._startup_bind_local_poster_v2498(rec["li"], small_local, source="pkm_server_small_poster"):
                    rec["ready"] = True
                    local_bound += 1
                    ready_count += 1
                    continue

            # No poster source at all is a legitimate missing-poster item, not a
            # transient network failure.  The existing XML card is render-safe.
            if not rec["sources"] and not rec["primary"]:
                try:
                    rec["li"].setProperty("PlexKM.PosterMissingV1963", "1")
                    rec["li"].setProperty("PlexKM.PosterMissingReasonV1963", "no_source")
                    rec["li"].setProperty("PlexKM.WallPosterDisplayV1644", "")
                    rec["li"].setProperty("PlexKM.PosterFallbackArt", "")
                except Exception:
                    pass
                rec["ready"] = True
                legitimate_missing += 1
                ready_count += 1
                continue

            key = small_url or ("rk:%s|%s" % (rec["rating_key"], "|".join(rec["sources"])))
            unresolved.setdefault(key, {
                "small_url": small_url, "sources": rec["sources"],
                "rating_key": rec["rating_key"], "records": []
            })["records"].append(rec)

        if unresolved and allow_network and not self._closing_event_v1841.is_set():
            self._startup_force_slow_notice_if_due_v2494("포스터 이미지를 준비 중입니다", "library_firstpaint_v2496")

            def _fetch_job(job, timeout_sec):
                try:
                    small_url = str(job.get("small_url") or "").strip()
                    if small_url:
                        local = self._wall_poster_download_bounded_v1862(
                            small_url, timeout_sec=max(0.8, float(timeout_sec)),
                            max_bytes=2 * 1024 * 1024,
                            priority=pkm_artwork_scheduler.PRIORITY_FOREGROUND,
                            cancel_check=lambda: self._closing_event_v1841.is_set(),
                        )
                        if local and self._local_poster_file_ready_v1865(local):
                            return local
                    return self._resolve_visible_poster_sources_server_small_v1937(
                        job.get("sources") or (), rating_key=job.get("rating_key") or "",
                        timeout_sec=max(0.8, float(timeout_sec)),
                        cancel_check=lambda: self._closing_event_v1841.is_set(),
                    ) or ""
                except Exception:
                    return ""

            pending = dict(unresolved)
            # V2712 UHD3 KPI: the U+ path owns only six first-paint cards. Do not
            # spend a second 3.2 s foreground retry on a poster that missed the
            # first bounded attempt. The existing V2530 stable fail-soft card
            # releases the atomic wall; normal runway work remains post-visible.
            _firstpaint_passes_v2712 = ((1, 1.25),) if self._uhd_kpi_proxy_v2605() else ((1, 2.2), (2, 3.2))
            _log("UHD3_LIBRARY_FIRSTPAINT_BUDGET_V2712 reason=%s uhd=%d visible=%d passes=%s foreground_retry2=%d" % (
                reason or "", 1 if self._uhd_kpi_proxy_v2605() else 0, limit,
                ",".join("%.2f" % float(x[1]) for x in _firstpaint_passes_v2712),
                0 if self._uhd_kpi_proxy_v2605() else 1
            ))
            for attempt, timeout_sec in _firstpaint_passes_v2712:
                if not pending or self._closing_event_v1841.is_set():
                    break
                next_pending = {}
                # R23: 2 -> 4 on UHD; random sort fetched 6 visible posters in 3.6 s.
                workers = min(4 if self._uhd_kpi_proxy_v2605() else 6, max(1, len(pending)))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    future_map = {executor.submit(_fetch_job, job, timeout_sec): key for key, job in pending.items()}
                    for future in as_completed(future_map):
                        key = future_map[future]
                        job = pending[key]
                        try:
                            local = str(future.result() or "").strip()
                        except Exception:
                            local = ""
                        if local and self._local_poster_file_ready_v1865(local):
                            failed_records = []
                            bound_any = False
                            for rec in job["records"]:
                                if rec.get("ready"):
                                    continue
                                if self._startup_bind_local_poster_v2498(rec["li"], local, source="downloaded_poster_only"):
                                    rec["ready"] = True
                                    ready_count += 1
                                    bound_any = True
                                else:
                                    failed_records.append(rec)
                            if bound_any:
                                downloaded_unique += 1
                            if failed_records:
                                retry = dict(job)
                                retry["records"] = failed_records
                                next_pending[key] = retry
                        else:
                            next_pending[key] = job
                pending = next_pending
                _log("LIBRARY_FIRSTPAINT_FETCH_PASS_V2496 reason=%s attempt=%d unique_remaining=%d timeout_ms=%d" % (
                    reason or "", attempt, len(pending), int(timeout_sec * 1000.0)
                ))
        else:
            pending = dict(unresolved)

        # v2530: after the bounded network policy has genuinely exhausted both
        # attempts, do not let one transient poster deadlock the whole surface.
        # Use the already-supported stable missing-poster card for this session
        # only; never publish a blank and never live-swap the poster later.
        if pending and allow_network and not self._closing_event_v1841.is_set():
            failsoft_items_v2530 = 0
            for job in list(pending.values()):
                for rec in list(job.get("records") or []):
                    if rec.get("ready"):
                        continue
                    if self._startup_mark_transient_missing_poster_v2530(rec, reason=reason or "library_firstpaint"):
                        ready_count += 1
                        failsoft_items_v2530 += 1
            if failsoft_items_v2530:
                _log("LIBRARY_FIRSTPAINT_FAILSOFT_V2530 reason=%s items=%d action=release_with_stable_missing_card blank=0 live_popin=0" % (
                    reason or "", failsoft_items_v2530
                ), xbmc.LOGWARNING)
            pending = {}

        unresolved_records = [rec for rec in records if not rec.get("ready")]
        ok = bool(not unresolved_records and ready_count >= limit)
        missing_keys = ",".join(str(rec.get("rating_key") or "-") for rec in unresolved_records[:18]) or "-"
        elapsed_v2498 = _pkm_speed_ms() - started
        _log("LIBRARY_FIRSTPAINT_GATE_V2496 reason=%s requested=%d ready=%d local_bound=%d legitimate_missing=%d downloaded_unique=%d unresolved=%d missing_keys=%s actual_local_required=1 transient_placeholder=0 fail_closed=%d wait_ms=%d" % (
            reason or "", limit, ready_count, local_bound, legitimate_missing, downloaded_unique,
            len(unresolved_records), missing_keys, 0 if ok else 1, elapsed_v2498
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        _log("LIBRARY_POSTER_PROVENANCE_ACCEPTANCE_V2498 result=%s requested=%d ready=%d unresolved=%d poster_only=1 fallback_art_used=0 portrait_required=1 wait_ms=%d" % (
            "PASS" if ok else "FAIL", limit, ready_count, len(unresolved_records), elapsed_v2498
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        return ok, ready_count, limit, len(unresolved_records)

    def _library_rows_signature_v2470(self, rows):
        try:
            payload = self._json_safe_v2467(list(rows or []))
            raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            return hashlib.sha1(raw).hexdigest()
        except Exception:
            return ""

    # PKM_PATCH_ACTIVE v2585 sidebar_firstpaint_lazy_destination_hydrate
    def _library_focus_lazy_hydrate_v2585(self, cache_key, section_id):
        """Hydrate only the Library destination the user actually selected.

        V2584 intentionally removed all off-screen Library hydration from startup.
        The cold-focus fallback therefore paid the full TV aggregate query (2-5 s
        on the PC trace, much worse on UHD3) even though a restart-safe prepared
        scene already existed on disk.  V2585 keeps startup light and restores
        just this one destination on demand before falling back to the DB.
        """
        key = str(cache_key or "")
        sid = str(section_id or "").strip()
        if not key or not sid:
            return False
        try:
            if bool(self._section_rows_cache.get(key)):
                return True
            started = _pkm_speed_ms()
            rec = (self._library_persistent_cache_load_v2470() or {}).get(key) or {}
            if not isinstance(rec, dict) or str(rec.get("section_id") or "").strip() != sid:
                _log("LIBRARY_FOCUS_LAZY_HYDRATE_V2585 key=%s section=%s result=miss elapsed_ms=%d" % (
                    key, sid, _pkm_speed_ms() - started
                ))
                return False
            if int(rec.get("fingerprint_version") or 0) != 2471:
                _log("LIBRARY_FOCUS_LAZY_HYDRATE_V2585 key=%s section=%s result=version_reject elapsed_ms=%d" % (
                    key, sid, _pkm_speed_ms() - started
                ), xbmc.LOGWARNING)
                return False
            rows = []
            for raw in list(rec.get("rows") or []):
                if isinstance(raw, list):
                    rows.append(tuple(raw))
                elif isinstance(raw, dict):
                    d = dict(raw)
                    if isinstance(d.get("row"), list):
                        d["row"] = tuple(d.get("row") or [])
                    rows.append(d)
                else:
                    rows.append(raw)
            if not rows:
                return False
            expected = str(rec.get("row_signature") or "")
            if expected and self._library_rows_signature_v2470(rows) != expected:
                _log("LIBRARY_FOCUS_LAZY_HYDRATE_V2585 key=%s section=%s result=signature_reject rows=%d elapsed_ms=%d" % (
                    key, sid, len(rows), _pkm_speed_ms() - started
                ), xbmc.LOGWARNING)
                return False
            self._section_rows_cache[key] = list(rows)
            self._section_total_cache[key] = int(rec.get("total") or 0)
            # V2588: the persisted alphabetical index is not first-paint content.
            # Do not copy thousands of index dictionaries on the sidebar callback;
            # _library_defer_index_after_visible_v2585() rebuilds/binds it after
            # the wall is visible and after the rapid-scroll grace period.
            persisted_index_rows_v2588 = rec.get("index_rows") or []
            persisted_index_count_v2588 = len(persisted_index_rows_v2588) if isinstance(persisted_index_rows_v2588, list) else 0
            index_rows = []
            snaps = list(rec.get("render_snapshots_v2473") or [])
            if len(snaps) == len(rows):
                # The snapshot is presentation data only.  A later dirty/invalidate
                # event still owns authority; this fast path never contacts Plex.
                self._library_render_snapshots_v2473[key] = snaps
            self._library_persistent_hit_keys_v2470.add(key)
            self._library_post_reveal_data_warm_keys_v2472.add(key)
            _log("LIBRARY_FOCUS_LAZY_HYDRATE_V2588 key=%s section=%s result=hit rows=%d persistent_index_rows=%d foreground_index_copy=0 snapshots=%d elapsed_ms=%d db_query=0 plex=0" % (
                key, sid, len(rows), persisted_index_count_v2588, len(snaps), _pkm_speed_ms() - started
            ))
            return True
        except Exception:
            _log("LIBRARY_FOCUS_LAZY_HYDRATE_FAILED_V2585 key=%s section=%s err=%s" % (
                key, sid, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _library_defer_index_after_visible_v2585(self, cache_key, section_id, title, total, sort_key, sort_dir, genre=""):
        """Build the expensive full Library index only after the wall is visible.

        The sidebar spinner still covers a genuinely slow first viewport, but a
        2k-show alphabetical/index scan can no longer hold the first paint.
        """
        key = str(cache_key or "")
        sid = str(section_id or "").strip()
        if not key or not sid:
            return False
        # R101: the right index is alphabetical (# A ㄱ..ㅎ) with offsets in
        # title order, so it is only meaningful for the title sort.  Other sorts
        # hide it instead of jumping to wrong rows.  Shield used to skip the
        # build entirely (V2659), so the index never appeared there; it now
        # builds in the background a little later than on PC.
        # R102: title -> 가나다 index, date/year sorts -> year index.
        if str(sort_key or "title").strip().lower() not in ("title", "added", "year", "release", "first_air"):
            for _t_r101 in (self, xbmcgui.Window(10000)):
                try:
                    _t_r101.setProperty("PlexKM.Section.IndexVisible", "")
                except Exception:
                    pass
            _log("LIBRARY_INDEX_SORT_HIDE_R101 key=%s section=%s sort=%s" % (key, sid, sort_key or ""))
            return False
        _delay_r101 = 0.6  # R102b: index shows ~0.6 s after the wall instead of 2.5 s
        def _worker():
            monitor = xbmc.Monitor()
            # Give the newly visible wall and immediate DOWN input priority.
            if monitor.waitForAbort(_delay_r101):
                return
            # While the user is actively rapid-scrolling, keep postponing the
            # nonessential right-side index.  Cap the delay so it eventually
            # materializes when the user settles.
            for _ in range(8):
                try:
                    if str(getattr(self, "active_section_id", "") or "") != sid:
                        _log("LIBRARY_INDEX_DEFERRED_ABORT_R102 key=%s section=%s active=%s stage=scroll_wait" % (
                            key, sid, getattr(self, "active_section_id", "")))
                        return
                    if not self._wall_rapid_scroll_active_v2581():
                        break
                except Exception:
                    break
                if monitor.waitForAbort(0.75):
                    return
            if str(getattr(self, "active_section_id", "") or "") != sid:
                _log("LIBRARY_INDEX_DEFERRED_ABORT_R102 key=%s section=%s active=%s stage=before_build" % (
                    key, sid, getattr(self, "active_section_id", "")))
                return
            started = _pkm_speed_ms()
            try:
                self._section_index_build_for_section(sid, reason="post_visible_v2585")
                index_rows = list(self._section_index_current_rows_r102(sid) or [])
                rows = list(self._section_rows_cache.get(key) or [])
                _same_sort_r102 = str(getattr(self, "sort", "") or "").strip().lower() == str(sort_key or "").strip().lower()
                if rows and _same_sort_r102:
                    self._library_persistent_scene_store_v2470(
                        key, sid, title, total, rows, sort_key=sort_key,
                        sort_dir=sort_dir, genre=genre, index_rows=index_rows,
                    )
                _log("LIBRARY_INDEX_DEFERRED_READY_V2585 key=%s section=%s index=%d elapsed_ms=%d firstpaint_block=0" % (
                    key, sid, len(index_rows), _pkm_speed_ms() - started
                ))
            except Exception:
                _log("LIBRARY_INDEX_DEFERRED_FAILED_V2585 key=%s section=%s err=%s" % (
                    key, sid, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        # R102: not in the UHD3 speculative list -- on Shield that gate dropped the
        # index build after 8 s whenever navigation stayed "hot", so the index
        # never appeared.  This worker already waits for the wall to settle.
        _PKMHomeThreadV2151(target=_worker, name="PKMLibraryIndexR102", daemon=True).start()
        _log("LIBRARY_INDEX_DEFERRED_ARM_V2585 key=%s section=%s delay_ms=1200 spinner_owner=0" % (key, sid))
        return True

    def _library_index_listitems_from_rows_v2470(self, index_rows):
        items = []
        try:
            for entry in list(index_rows or []):
                if not isinstance(entry, dict):
                    continue
                ikey = str(entry.get("key") or "#")
                li = xbmcgui.ListItem(label=str(entry.get("label") or ikey))
                li.setProperty("PlexKM.IndexKey", ikey)
                li.setProperty("PlexKM.IndexOffset", str(int(entry.get("offset", 0) or 0)))
                li.setProperty("PlexKM.IndexActive", "")
                items.append(li)
        except Exception:
            return []
        return items

    def _library_bind_prebuilt_index_v2470(self, cache_key, section_id):
        """Bind an already-built hidden right index without DB work."""
        key = str(cache_key or "")
        sid = str(section_id or "").strip()
        items = list(getattr(self, "_library_prebuilt_indexitems_v2470", {}).get(key) or [])
        try:
            ctrl = self.getControl(SECTION_INDEX_ID)
            ctrl.reset()
            if items:
                try:
                    ctrl.addItems(items)
                except Exception:
                    for li in items:
                        ctrl.addItem(li)
            self._section_index_last_section_id = sid
            # R102: persisted index rows belong to this key's sort.
            _sort_r101 = str(getattr(self, "sort", "title") or "title").strip().lower()
            value = "1" if (items and _sort_r101 in ("title", "added", "year", "release", "first_air")) else ""
            self.setProperty("PlexKM.Section.IndexVisible", value)
            xbmcgui.Window(10000).setProperty("PlexKM.Section.IndexVisible", value)
            _log("LIBRARY_INDEX_PREBUILT_BIND_V2470 key=%s section=%s items=%d focus_io=0" % (
                key, sid, len(items)
            ))
            return True
        except Exception:
            _log("LIBRARY_INDEX_PREBUILT_BIND_FAILED_V2470 key=%s section=%s err=%s" % (
                key, sid, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _library_render_busy_arm_v2475(self, sid, cache_key, reason=""):
        """Arm a Library foreground transaction with a sidebar-only 1000ms ring."""
        try:
            sid = str(sid or "").strip()
            key = str(cache_key or "").strip()
            if not sid or not key:
                return ""
            token = "libraryrender:%s:%d" % (sid, int(time.time() * 1000))
            lock = getattr(self, "_library_render_busy_lock_v2475", None)
            if lock is None:
                self._library_render_busy_lock_v2475 = threading.RLock()
                lock = self._library_render_busy_lock_v2475
            prior = ""
            with lock:
                prior = str(getattr(self, "_library_render_busy_gate_token_v2475", "") or "")
                self._library_render_busy_gate_token_v2475 = token
                self._library_render_busy_key_v2475 = key
                started = getattr(self, "_library_render_busy_started_v2475", None)
                if not isinstance(started, dict):
                    started = {}
                    self._library_render_busy_started_v2475 = started
                started[token] = self._now_ms()
            if prior and prior != token:
                self._library_render_busy_finish_v2475(prior, reason="superseded", visible=False)

            # v2476: Library is a separate user action from sidebar focus.
            # Its 1000ms budget starts when the Library transition starts, never
            # from how long the user happened to sit on the sidebar beforehand.
            remaining_ms_v2475 = 1000

            def _promote_v2475():
                monitor = xbmc.Monitor()
                if remaining_ms_v2475 > 0 and monitor.waitForAbort(remaining_ms_v2475 / 1000.0):
                    return
                busy_token = ""
                with lock:
                    if token != str(getattr(self, "_library_render_busy_gate_token_v2475", "") or ""):
                        return
                    if key != str(getattr(self, "_library_render_busy_key_v2475", "") or ""):
                        return
                    busy_map = getattr(self, "_library_render_busy_tokens_v2475", None)
                    if not isinstance(busy_map, dict):
                        busy_map = {}
                        self._library_render_busy_tokens_v2475 = busy_map
                    if str(busy_map.get(token) or ""):
                        return
                    try:
                        busy_token = pkm_global_busy.begin(
                            reason="library_render_v2475:%s:%s" % (sid, key),
                            scope="sidebar", owner="library:%s" % sid, replace_scope=True
                        )
                    except Exception:
                        busy_token = ""
                    if busy_token:
                        busy_map[token] = busy_token
                if not busy_token:
                    return
                with lock:
                    valid = bool(
                        token == str(getattr(self, "_library_render_busy_gate_token_v2475", "") or "")
                        and key == str(getattr(self, "_library_render_busy_key_v2475", "") or "")
                    )
                    if not valid:
                        try:
                            (getattr(self, "_library_render_busy_tokens_v2475", {}) or {}).pop(token, None)
                        except Exception:
                            pass
                if not valid:
                    try:
                        pkm_global_busy.end(busy_token, reason="library_v2475_race_cancel")
                    except Exception:
                        pass
                    return
                try:
                    pkm_global_busy.promote(busy_token, reason="library_1000ms_v2482:%s" % sid)
                except Exception:
                    pass
                _log("LIBRARY_DELAYED_SPINNER_PROMOTE_V2482 section=%s key=%s token=%s threshold_ms=1000 remaining_at_arm_ms=%d previous_scene_hold=1 actual_visible_pending=1" % (
                    sid, key, token, remaining_ms_v2475
                ))

            _PKMHomeThreadV2151(
                target=_promote_v2475,
                name="PKMLibrarySpinner1000V2482",
                daemon=True,
            ).start()
            _log("LIBRARY_RENDER_WAIT_ARM_V2482 key=%s section=%s token=%s threshold_ms=1000 remaining_ms=%d broker_begin_deferred=1 action_anchored=1" % (
                key, sid, token, remaining_ms_v2475
            ))
            return token
        except Exception:
            return ""

    def _library_render_busy_finish_v2475(self, token, reason="", visible=False):
        """Retire one Library 1000ms transaction; visible=True owns the final GUI frame."""
        try:
            token = str(token or "")
            if not token:
                return False
            lock = getattr(self, "_library_render_busy_lock_v2475", None)
            if lock is None:
                return False
            if visible and not xbmc.getCondVisibility("System.Platform.Android"):
                xbmc.sleep(16)
            busy_token = ""
            started_ms = 0
            key = ""
            with lock:
                try:
                    busy_token = (getattr(self, "_library_render_busy_tokens_v2475", {}) or {}).pop(token, "")
                except Exception:
                    busy_token = ""
                try:
                    started_ms = int((getattr(self, "_library_render_busy_started_v2475", {}) or {}).pop(token, 0) or 0)
                except Exception:
                    started_ms = 0
                if token == str(getattr(self, "_library_render_busy_gate_token_v2475", "") or ""):
                    key = str(getattr(self, "_library_render_busy_key_v2475", "") or "")
                    self._library_render_busy_gate_token_v2475 = ""
                    self._library_render_busy_key_v2475 = ""
            try:
                pkm_global_busy.end(busy_token, reason="library_actual_visible_v2475:%s" % (reason or ""))
            except Exception:
                pass
            elapsed = max(0, self._now_ms() - started_ms) if started_ms > 0 else 0
            _log("LIBRARY_RENDER_BUSY_RELEASE_V2475 token=%s key=%s elapsed_ms=%d spinner_token=%d visible=%d frame_wait_ms=%d reason=%s" % (
                token, key, elapsed, 1 if busy_token else 0, 1 if visible else 0, 16 if visible else 0, reason or ""
            ))
            if visible:
                try:
                    _kpi_win_v2606 = xbmcgui.Window(10000)
                    _kpi_win_v2606.setProperty("PlexKM.KPI.LibraryVisibleMs", str(int(elapsed or 0)))
                    _kpi_win_v2606.setProperty("PlexKM.KPI.LibrarySpinnerUsed", "1" if busy_token else "0")
                    _kpi_win_v2606.setProperty("PlexKM.KPI.LibraryReason", str(reason or ""))
                    _kpi_win_v2606.setProperty("PlexKM.KPI.LibraryStamp", str(self._now_ms()))
                    _log("KPI_LIBRARY_VISIBLE_SAMPLE_V2606 elapsed_ms=%d spinner=%d key=%s reason=%s" % (
                        int(elapsed or 0), 1 if busy_token else 0, key, reason or ""
                    ))
                    self._sort_kpi_finish_v2610(
                        key=key, spinner_used=bool(busy_token), reason="library_visible:%s" % (reason or "")
                    )
                    try:
                        _sid_sort_v2626 = str(getattr(self, "active_section_id", "") or "").strip()
                        if _sid_sort_v2626 and not _PKM_ANDROID_RUNTIME_V2595:
                            pkm_sort_index_v2626.prewarm_async([_sid_sort_v2626], priority_section=_sid_sort_v2626, reason="library_visible_v2626")
                            _log("SORT_INDEX_LIBRARY_PRIORITY_ARM_V2626 section=%s foreground_wait=0" % _sid_sort_v2626)
                        elif _sid_sort_v2626:
                            _log("SORT_INDEX_UHD3_LAZY_V2659 section=%s action=defer_until_sort_intent" % _sid_sort_v2626)
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    sid = key.split(":", 1)[1].split(":", 1)[0] if key.startswith("library:") else str(getattr(self, "active_section_id", "") or "")
                    select_started = int(getattr(self, "_sidebar_ui_select_started_v1650", 0) or 0)
                    select_sid = str(getattr(self, "_sidebar_ui_select_section_v1650", "") or "")
                    focus_elapsed = max(0, self._now_ms() - select_started) if select_started > 0 else 0
                    _log("SIDEBAR_UI_LIBRARY_VISIBLE_V2475 section=%s elapsed_ms=%d key=%s spinner_token=%d" % (
                        select_sid or sid, focus_elapsed, key, 1 if busy_token else 0
                    ))
                    try:
                        pkm_uhd_diag_v2600.event(
                            "LIBRARY_VISIBLE", extra="section=%s elapsed_ms=%d key=%s spinner=%d" % (
                                select_sid or sid, focus_elapsed, key, 1 if busy_token else 0
                            )
                        )
                    except Exception:
                        pass
                    if select_started > 0 and select_sid:
                        self._sidebar_ui_select_logged_v1650 = True
                except Exception:
                    pass
            return True
        except Exception:
            return False

    def _sync_legacy_library_apply_global_busy_v1883(self, active=None, reason=""):
        """Bridge the cross-process library apply flag into the one busy broker.

        The settings script can only publish Window(10000) properties. It must not
        own a second spinner implementation. Home converts that durable flag into
        a normal token and the shared 1000ms rule owns the visual lifecycle.
        """
        try:
            win = xbmcgui.Window(10000)
            if active is None:
                active = win.getProperty("PlexKM.Home.LibraryApplyBusyV1754") == "1"
            token = str(getattr(self, "_library_apply_global_busy_token_v1883", "") or "")
            if active:
                if not token:
                    token = self._scene_busy_arm_v2482(
                        reason="library_apply:%s" % (reason or "home_return"),
                        scope="library_apply", owner="home", replace_scope=True, threshold_ms=1000
                    )
                    self._library_apply_global_busy_token_v1883 = token
                    _log("LIBRARY_HOME_APPLY_GLOBAL_BUSY_BEGIN_V1883 token=%s reason=%s delay_ms=%d" % (
                        token, reason or "", 1000
                    ))
                return token
            if token:
                self._scene_busy_finish_v2482(token, reason="library_apply_done:%s" % (reason or ""))
                self._library_apply_global_busy_token_v1883 = ""
                _log("LIBRARY_HOME_APPLY_GLOBAL_BUSY_END_V1883 token=%s reason=%s" % (
                    token, reason or ""
                ))
            return ""
        except Exception:
            _log("LIBRARY_HOME_APPLY_GLOBAL_BUSY_BRIDGE_FAILED_V1883 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return ""


    def _wall_item_key(self, li):
        try:
            if li is None:
                return ""
            for name in ("PlexKM.RatingKey", "PlexKM.PlayUrl", "PlexKM.ShowUrl", "PlexKM.Title"):
                value = li.getProperty(name) or ""
                if value:
                    return "%s:%s" % (name, value)
            return "label:%s" % (li.getLabel() or "")
        except Exception:
            return ""

    def _sync_wall_first_key(self, reason=""):
        """Remember the first item identity in the current wall.

        This intentionally does not use column or visible-poster-count math.
        Poster count can change with resolution/sidebar width, but the first
        wall item identity is stable for Home and all sections.
        """
        try:
            wall = self.getControl(WALL_ID)
            if wall.size() > 0:
                self._wall_first_key = self._wall_item_key(wall.getListItem(0))
            else:
                self._wall_first_key = ""
            _log("WALL_FIRST_KEY_SYNC reason=%s first_key=%s" % (reason, self._wall_first_key))
        except Exception:
            self._wall_first_key = ""

    # PKM_PATCH_ACTIVE v2576 uhd3_library_append_foreground_runway_restore
    def _ensure_library_append_runway_v2576(self, reason=""):
        """Keep the Library wall runway alive from the already-prefetched local rows.

        This is foreground-critical navigation work, not Home background/prewarm.
        It performs no Plex request and only commits when Kodi 9100 is the active
        visible wall.  The extra edge guard also recovers if a native DOWN action
        reached the last two rows before the older low-watermark callback armed.
        """
        try:
            if self.getProperty("PlexKM.Window.IsSectionWall") != "1":
                return 0
            if self._safe_focus_id() != WALL_ID:
                return 0
            wall = self.getControl(WALL_ID)
            pos = int(wall.getSelectedPosition())
            size = int(wall.size())
            if pos < 0 or size <= 0:
                return 0
            if self.wall_total and int(self.wall_offset or 0) >= int(self.wall_total or 0):
                return 0
            columns = max(1, int(self._wall_column_count() or 6))
            current_row = max(0, pos // columns)
            loaded_rows = max(1, (size + columns - 1) // columns)
            remaining_rows = max(0, loaded_rows - current_row - 1)

            armed = bool(getattr(self, "_library_append_request_v2070", False))
            if not armed:
                armed = bool(self._request_library_append_v2070(reason="v2576:%s" % (reason or "track")))

            # Hard edge recovery: never let navigation hit the physical end just
            # because a previous pre-native callback missed the low-watermark.
            if not armed and remaining_rows <= 2:
                self._library_append_request_v2070 = True
                self._start_library_append_prefetch_v2070(reason="v2576_edge:%s" % (reason or "track"))
                armed = True
                _log("LIBRARY_APPEND_EDGE_ARM_V2576 section=%s pos=%d row=%d size=%d remaining_rows=%d offset=%d total=%d reason=%s" % (
                    self.active_section_id, pos, current_row, size, remaining_rows,
                    int(self.wall_offset or 0), int(self.wall_total or 0), reason or ""
                ))

            if not armed:
                return 0
            _append_t0_v2600 = time.perf_counter()
            added = self._publish_requested_library_append_v2070(
                reason="v2576_post_selection:%s" % (reason or "track"),
                allow_commit_v2071=True
            )
            _append_ms_v2600 = (time.perf_counter() - _append_t0_v2600) * 1000.0
            if int(added or 0) > 0:
                _log("LIBRARY_APPEND_FOREGROUND_COMMIT_V2593 section=%s added=%d pos=%d size=%d offset=%d total=%d reason=%s plex=0 spinner=%d" % (
                    self.active_section_id, int(added or 0), pos, int(wall.size()),
                    int(self.wall_offset or 0), int(self.wall_total or 0), reason or "",
                    1 if str(getattr(self, "_library_rapid_poster_spinner_token_v2593", "") or "") else 0
                ))
                _log("LIBRARY_APPEND_COST_V2600 section=%s added=%d elapsed_ms=%.1f pos=%d size=%d rapid=%d" % (
                    self.active_section_id, int(added or 0), _append_ms_v2600, pos, int(wall.size()),
                    1 if self._wall_rapid_scroll_active_v2581() else 0
                ))
                try:
                    if self._is_android_v2591() or _append_ms_v2600 >= 40.0:
                        pkm_uhd_diag_v2600.event(
                            "LIB_APPEND", extra="section=%s added=%d append_ms=%.1f pos=%d size=%d rapid=%d" % (
                                self.active_section_id, int(added or 0), _append_ms_v2600, pos, int(wall.size()),
                                1 if self._wall_rapid_scroll_active_v2581() else 0
                            )
                        )
                except Exception:
                    pass
            return int(added or 0)
        except Exception:
            _log("LIBRARY_APPEND_FOREGROUND_FAILED_V2576 section=%s reason=%s err=%s" % (
                self.active_section_id, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0

    def _track_wall_selection(self, reason=""):
        try:
            wall = self.getControl(WALL_ID)
            pos = self._wall_selected_position()
            li = None
            try:
                li = wall.getSelectedItem()
            except Exception:
                pass
            key = self._wall_item_key(li)
            if not key and pos >= 0 and wall.size() > pos:
                key = self._wall_item_key(wall.getListItem(pos))
            self._wall_tracked_pos = max(0, int(pos)) if pos >= 0 else 0
            self._wall_tracked_key = key or ""
            if not self._wall_first_key:
                self._sync_wall_first_key("track_missing_first:%s" % reason)
            # v2576: use the final Kodi-selected position as a second append gate.
            # This makes DOWN/PageDown continuous even when the older action-time
            # gate observed the pre-move position or the prefetch became ready a
            # few milliseconds after that callback.
            if self._is_android_v2591():
                self._schedule_library_append_commit_v2600()
            else:
                self._ensure_library_append_runway_v2576(reason=reason or "wall_track")
            _log("WALL_TRACK_NO_HARDCODE reason=%s pos=%s key=%s first_key=%s" % (
                reason, self._wall_tracked_pos, self._wall_tracked_key, self._wall_first_key))
        except Exception:
            pass

    def _wall_column_count(self):
        # v148 fix: Kodi does not expose label values for controls with
        # <visible>false</visible> via getLabel(). The XML label trick
        # (id=9191/9192) always returns "" at runtime, causing _wall_item_width_from_xml()
        # and _wall_width_from_xml() to return 0, and the column count to fall back to 1.
        # With columns=1, every poster satisfies (pos % 1 == 0), so LEFT always
        # sends focus to the menu regardless of horizontal position.
        #
        # Fix: use Python-side constants that mirror the XML itemlayout/panel widths.
        # Keep these in sync with plexkm_home_window.xml:
        #   <control type="panel" id="9100"> width=1820
        #   <itemlayout width="280" ...>
        WALL_ITEM_WIDTH = 240    # itemlayout/focusedlayout width in XML (R99 L3: 280 -> 240, 7 columns)
        WALL_PANEL_WIDTH = 1820  # panel id=9100 width in XML
        try:
            wall = self.getControl(WALL_ID)
            wall_width = 0
            try:
                wall_width = int(wall.getWidth())
            except Exception:
                wall_width = 0
            if wall_width <= 0:
                wall_width = WALL_PANEL_WIDTH
                source = "const"
            else:
                source = "control"
            columns = max(1, int(wall_width // WALL_ITEM_WIDTH))
            if not bool(getattr(self, "_suppress_item_diag_v2473", False)):
                _log("WALL_COLUMN_COUNT width=%s item_width=%s columns=%s source=%s" % (
                wall_width, WALL_ITEM_WIDTH, columns, source))
            return columns
        except Exception:
            pass
        _log("WALL_COLUMN_COUNT_FALLBACK columns=6", xbmc.LOGWARNING)
        return max(1, WALL_PANEL_WIDTH // WALL_ITEM_WIDTH)

    def _debug_wall_geometry(self, li=None, pos=-1):
        """Return stable geometry/debug data for wall focus decisions.

        Kodi WindowXML does not expose the actual rendered item rectangle here,
        so this logs the geometry implied by the XML constants:
        panel left/top=410/235, item width/height=280/500, columns=6.
        It also logs row-local index/column so we can compare visual-left vs
        widget-row-left without using Korean row labels.
        """
        try:
            panel_left = 410
            panel_top = 235
            item_w = 280
            item_h = 500
            columns = self._wall_column_count()
            gpos = _safe_int(pos, -1)
            row_start = -1
            row_index = -1
            row_id = ""
            row_type = ""
            row_first = ""
            title = ""
            rating_key = ""
            if li is not None:
                row_start = _safe_int(li.getProperty("PlexKM.HomeRowStart"), -1)
                row_index = _safe_int(li.getProperty("PlexKM.HomeRowIndex"), -1)
                row_id = li.getProperty("PlexKM.HomeRowId") or ""
                row_type = li.getProperty("PlexKM.HomeRowType") or ""
                row_first = li.getProperty("PlexKM.HomeRowFirst") or ""
                title = li.getProperty("PlexKM.Title") or li.getLabel() or ""
                rating_key = li.getProperty("PlexKM.RatingKey") or ""
                if gpos < 0:
                    dbg_pos = _safe_int(li.getProperty("PlexKM.DebugGlobalPos"), -1)
                    if dbg_pos >= 0:
                        gpos = dbg_pos
            global_col = (gpos % columns) if (gpos >= 0 and columns > 0) else -1
            global_row = (gpos // columns) if (gpos >= 0 and columns > 0) else -1
            global_x = panel_left + (global_col * item_w) if global_col >= 0 else -1
            global_y = panel_top + (global_row * item_h) if global_row >= 0 else -1
            row_col = (row_index % columns) if (row_index >= 0 and columns > 0) else -1
            row_visual_row = (row_index // columns) if (row_index >= 0 and columns > 0) else -1
            row_x = panel_left + (row_col * item_w) if row_col >= 0 else -1
            row_y = panel_top + (row_visual_row * item_h) if row_visual_row >= 0 else -1
            visual_left_by_global = (global_col == 0)
            visual_left_by_row = (row_col == 0)
            row_first_by_index = (row_index == 0)
            return (
                "pos=%s columns=%s panel=(%s,%s) item=(%s,%s) "
                "global_col=%s global_row=%s global_xy=(%s,%s) "
                "row_id=%s row_type=%s row_start=%s row_index=%s row_col=%s row_visual_row=%s row_xy=(%s,%s) row_first=%s "
                "left_by_global=%s left_by_row=%s row_first_by_index=%s rating_key=%s title=%s"
            ) % (
                gpos, columns, panel_left, panel_top, item_w, item_h,
                global_col, global_row, global_x, global_y,
                row_id, row_type, row_start, row_index, row_col, row_visual_row, row_x, row_y, row_first or "0",
                str(visual_left_by_global).lower(), str(visual_left_by_row).lower(), str(row_first_by_index).lower(), rating_key, title
            )
        except Exception:
            return "geom_error=%s" % traceback.format_exc().replace(chr(10), " | ")

    def _visible_row_index_for_control(self, control_id):
        try:
            fid = int(control_id)
            scope, _stack_id = self._row_anchor_scope_for_control(fid)
            if not scope:
                return -1
            rows = self._visible_row_controls_for_scope(scope)
            if fid in rows:
                return rows.index(fid)
        except Exception:
            pass
        return -1

    def _home_row_index_for_control(self, control_id=None):
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
            visible_idx = self._visible_row_index_for_control(fid)
            if visible_idx >= 0:
                return visible_idx
            ids = self._home_row_ids_for_control(fid)
            return list(ids).index(fid)
        except Exception:
            return -1

    # PKM_SHIELD_NAV_CAST_PROFILE_GUARDED
    def _pkm_home_append_restore_cursor(self, ctrl, control_id, expected_pos, expected_key, prefix):
        """Restore the focused Home rail's immutable item after native list rebind.

        Must execute before Kodi handles the triggering RIGHT action. No focus
        transfer is done, and no existing row is reordered or removed.
        """
        try:
            if int(self.getFocusId()) != int(control_id):
                return True
            size = int(ctrl.size() or 0)
            target = int(expected_pos)
            if not (0 <= target < size):
                return False
            # A ListItem key is stronger evidence than a position after rebind.
            if expected_key:
                try:
                    current = str(self._wall_item_key(ctrl.getListItem(target)) or "")
                except Exception:
                    current = ""
                if current != expected_key:
                    found = -1
                    for idx in range(min(size, max(0, int(prefix)))):
                        try:
                            if str(self._wall_item_key(ctrl.getListItem(idx)) or "") == expected_key:
                                found = idx
                                break
                        except Exception:
                            continue
                    if found < 0:
                        _log("HOME_LAZY_CURSOR_MISMATCH key=%s control=%s action=abort_unproven_restore" % (
                            expected_key, control_id), xbmc.LOGWARNING)
                        return False
                    target = found
            # Prefer the existing guarded native selector, which verifies both
            # position and stable list item identity after LABEL_BIND.
            ok, observed, attempts = self._restore_library_append_selection_v2122(
                ctrl, target, expected_key=expected_key,
                stable_prefix_size=prefix)
            _log("HOME_LAZY_CURSOR_RESTORE control=%s target=%d observed=%d size=%d ok=%d attempts=%d" % (
                control_id, target, observed, size, 1 if ok else 0, attempts))
            return bool(ok)
        except Exception:
            _log("HOME_LAZY_CURSOR_RESTORE_ERROR control=%s err=%s" % (
                control_id, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _home_lazy_append_row_v2591(self, control_id, chunk=6):
        """Append a small Home rail runway only when RIGHT approaches its edge."""
        try:
            if not self._is_android_v2591():
                return 0
            cid = int(control_id)
            if cid not in HOME_ROW_IDS:
                return 0
            grouped = getattr(self, "_home_row_items_cache", None)
            if not isinstance(grouped, list):
                return 0
            row_idx = list(HOME_ROW_IDS).index(cid)
            if row_idx >= len(grouped):
                return 0
            entries = list(grouped[row_idx] or [])
            ctrl = self.getControl(cid)
            existing = max(0, int(ctrl.size() or 0))
            if existing >= len(entries):
                return 0
            # Kodi can reset the native selected index to zero on addItems().
            # Save the existing focused card before binding the runway.
            _home_focused_before = int(self.getFocusId()) == cid
            _home_before_pos = int(ctrl.getSelectedPosition() or 0) if _home_focused_before else -1
            _home_before_key = ""
            if _home_focused_before and 0 <= _home_before_pos < existing:
                try:
                    _home_before_key = str(self._wall_item_key(ctrl.getListItem(_home_before_pos)) or "")
                except Exception:
                    pass
            end = min(len(entries), existing + max(1, int(chunk or 6)))
            home_index = getattr(self, "_home_lazy_home_index_v2591", {}) or {}
            fast_index = getattr(self, "_home_lazy_fast_index_v2591", {}) or {}
            progress_map = getattr(self, "_home_lazy_progress_map_v2591", {}) or {}
            fast_enabled = bool(getattr(self, "_home_lazy_fast_enabled_v2591", False))
            built = []
            old_rapid = bool(getattr(self, "_library_rapid_skeleton_v2584", False))
            try:
                for item_idx, entry in enumerate(entries[existing:end], start=existing):
                    li = None
                    if fast_enabled and home_index:
                        li = self._home_li_from_persistent_snapshot_v2500(entry, home_index, progress_map)
                    if li is None and fast_enabled and fast_index:
                        li = self._home_li_from_runtime_snapshot_v2499(entry, fast_index, progress_map)
                    if li is None:
                        self._library_rapid_skeleton_v2584 = True
                        li = self._li_from_row(
                            entry.get("row"),
                            row_title=_display_library_title(entry.get("row_title", "")),
                            row_type=entry.get("row_type", ""),
                            row_first=(item_idx == 0),
                            row_id=entry.get("row_id", ""),
                            row_start=0,
                            row_index=item_idx,
                        )
                    if li is not None:
                        built.append(li)
            finally:
                self._library_rapid_skeleton_v2584 = old_rapid
            if built:
                # HOME_CONTINUE_PROGRESS_ATOMIC_R20D:
                # Android binds Home rails in chunks. Apply the same progress-only
                # poster gate to newly appended Continue cards before publishing
                # that chunk, so later cards obey the same poster+bar contract.
                try:
                    _lazy_is_continue_r20d = bool(
                        existing < len(entries)
                        and str((entries[existing].get("row_type") if isinstance(entries[existing], dict) else "") or "") == "continue"
                    )
                except Exception:
                    _lazy_is_continue_r20d = False
                if _lazy_is_continue_r20d:
                    _lazy_progress_candidates_r20d = 0
                    for _li_r20d in list(built or []):
                        try:
                            if (
                                _safe_int(_li_r20d.getProperty("PlexKM.ResumePercent"), 0) > 0
                                and str(_li_r20d.getProperty("PlexKM.IsWatched") or "") != "1"
                            ):
                                _lazy_progress_candidates_r20d += 1
                        except Exception:
                            pass
                    if _lazy_progress_candidates_r20d:
                        self._progress_overlay_poster_gate_v2716(
                            built,
                            reason="HOME_CONTINUE_LAZY_PROGRESS_R20D"
                        )
                    _log("HOME_CONTINUE_LAZY_PROGRESS_R20D control=%s candidates=%d added=%d" % (
                        cid, _lazy_progress_candidates_r20d, len(built)
                    ))
                try:
                    ctrl.addItems(built)
                except Exception:
                    for li in built:
                        ctrl.addItem(li)
                if _home_focused_before:
                    _home_restored = self._pkm_home_append_restore_cursor(
                        ctrl, cid, _home_before_pos, _home_before_key, existing)
                    if not _home_restored:
                        _log("HOME_LAZY_CURSOR_RESTORE_FAIL control=%d before_pos=%d before_size=%d action=no_automatic_focus_zero" % (
                            cid, _home_before_pos, existing), xbmc.LOGWARNING)
            _log("UHD3_HOME_LAZY_APPEND_V2591 row=%s before=%d added=%d after=%d total=%d ratings=0 canonical=0" % (
                cid, existing, len(built), int(ctrl.size() or 0), len(entries)
            ))
            return len(built)
        except Exception:
            _log("UHD3_HOME_LAZY_APPEND_FAILED_V2591 row=%s err=%s" % (control_id, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _wall_selected_position(self):
        try:
            wall = self.getControl(WALL_ID)
        except Exception:
            return -1

        # v303 root fix:
        # Do not "correct" getSelectedPosition() with getSelectedItem().
        # In Kodi Panel/WindowXML, getSelectedItem() can briefly return the
        # first item while getSelectedPosition() still reports the useful raw
        # position.  The old correction changed raw=16 into actual=0 and then
        # LEFT treated the first poster as focused, jumping to the menu.
        # Keep raw as the container position and log stale getSelectedItem()
        # only for diagnostics.  Widget LEFT uses the tracked logical cursor.
        pos_raw = -1
        try:
            pos_raw = int(wall.getSelectedPosition())
        except Exception:
            pos_raw = -1

        # V2622: after a section wall reset Kodi can expose the previous section's
        # numeric position for one callback (for example 234 while the new wall
        # contains only 18 items). Never index the new container with that stale
        # value. This is telemetry-only clamping; Kodi/XML remains the selection owner.
        try:
            size_v2622 = int(wall.size() or 0)
        except Exception:
            size_v2622 = 0
        if size_v2622 <= 0:
            return -1
        if pos_raw < 0 or pos_raw >= size_v2622:
            _log("LIBRARY_SELECTION_STALE_RANGE_CLAMP_V2622 raw=%d size=%d section=%s telemetry_pos=0 selection_write=0" % (
                int(pos_raw), int(size_v2622), str(getattr(self, "active_section_id", "") or "")
            ))
            pos_raw = 0

        try:
            selected = wall.getSelectedItem()
            selected_key = self._wall_item_key(selected)
            raw_key = ""
            if pos_raw >= 0 and size_v2622 > 0:
                try:
                    raw_key = self._wall_item_key(wall.getListItem(pos_raw)) or ""
                except Exception:
                    raw_key = ""
            if selected_key and raw_key and selected_key != raw_key:
                _log("WALL_SELECTEDITEM_STALE raw=%s raw_key=%s selected_key=%s tracked=%s tracked_key=%s" % (
                    pos_raw, raw_key, selected_key, self._wall_tracked_pos, self._wall_tracked_key or ""))
        except Exception:
            pass

        return pos_raw

    def _library_wall_is_native_owner_v2070(self):
        """True while Kodi panel 9100 is the sole Library selection owner."""
        try:
            sid = str(getattr(self, "active_section_id", "") or "")
            explicit_owner = str(getattr(self, "_library_native_owner_section_v2070", "") or "")
            visible_wall = (self.getProperty("PlexKM.Window.IsSectionWall") == "1"
                            or xbmcgui.Window(10000).getProperty("PlexKM.Window.IsSectionWall") == "1")
            return bool(sid not in ("", "__home__") and (visible_wall or explicit_owner == sid))
        except Exception:
            return False

    def _sync_library_selection_telemetry_v2070(self, reason=""):
        """Mirror Kodi's native position into legacy diagnostics; never vice versa."""
        try:
            if not self._library_wall_is_native_owner_v2070():
                return -1
            pos = int(self._wall_selected_position())
            if pos >= 0:
                self._last_wall_pos = pos
                self._logical_wall_pos = pos
                self._wall_tracked_pos = pos
            _log("LIBRARY_SELECTION_OWNER_V2070 owner=kodi_9100 pos=%s write=0 reason=%s" % (pos, reason or ""))
            return pos
        except Exception:
            return -1

    def _reset_wall_cursor(self, reason=""):
        try:
            self._logical_wall_pos = 0
            self._last_wall_pos = 0
            self._last_left_from_wall_pos = -1
            self._suppress_next_wall_right_logical = False
            self._wall_first_key = ""
            self._wall_tracked_key = ""
            self._wall_tracked_pos = 0
            _log("WALL_CURSOR_RESET reason=%s" % reason)
        except Exception:
            pass

    def _wall_meta_commit_ping_v2600(self):
        """Apply final Android wall hero metadata after remote motion settles.

        Kodi panel 9100 remains the sole selection mover. This method only reads
        the already-selected ListItem and publishes local/cache metadata.
        """
        try:
            lock_v2600 = getattr(self, "_wall_meta_lock_v2600", None)
            if lock_v2600 is None:
                return False
            with lock_v2600:
                pending_v2600 = getattr(self, "_wall_meta_pending_v2600", None)
                self._wall_meta_pending_v2600 = None
                self._wall_meta_worker_active_v2600 = False
            if not pending_v2600:
                return False
            token_v2600, armed_ms_v2600 = pending_v2600
            if self._safe_focus_id() != WALL_ID or self.getProperty("PlexKM.Window.IsSectionWall") != "1":
                return False
            li_v2600 = self._focused_wall_item()
            if li_v2600 is None:
                return False
            t0_v2600 = time.perf_counter()
            self._set_home_meta_from_item(li_v2600, reason="wall_focus_stable_v2600")
            self._r155_rating_schedule(li_v2600, reason="wall_stable")
            try:
                wall_v2600 = self.getControl(WALL_ID)
                pos_v2600 = int(wall_v2600.getSelectedPosition())
                key_v2600 = self._wall_item_key(li_v2600) or ""
                self._wall_tracked_pos = max(0, pos_v2600) if pos_v2600 >= 0 else 0
                self._wall_tracked_key = key_v2600
                self._last_focus_id = WALL_ID
                self._remember_focus_position()
                self._section_index_sync_for_item(li_v2600, reason="wall_focus_stable_v2600")
            except Exception:
                pos_v2600 = -1
            meta_ms_v2600 = (time.perf_counter() - t0_v2600) * 1000.0
            # V2676: wall movement is navigation-critical on UHD3. Do not start
            # actor portrait/TMDb work from a wall focus commit. Info/actor entry
            # owns that work after navigation has stopped.
            _cast_prime_v2607 = 0
            _log("WALL_META_COMMIT_V2607 token=%s section=%s pos=%d stable_ms=%d meta_ms=%.1f art_preload=0 trailer=0 cast_prime=%d python_move=0" % (
                token_v2600, self.active_section_id or "-", pos_v2600,
                max(0, self._now_ms() - int(armed_ms_v2600 or 0)), meta_ms_v2600, int(_cast_prime_v2607 or 0)
            ))
            try:
                pkm_uhd_diag_v2600.event(
                    "WALL_META", extra="section=%s pos=%d meta_ms=%.1f" % (self.active_section_id or "-", pos_v2600, meta_ms_v2600)
                )
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _schedule_wall_meta_commit_v2600(self):
        """V2676: coalesce Android wall metadata for 240 ms; never moves selection."""
        try:
            if not self._is_android_v2591():
                return False
            lock_v2600 = getattr(self, "_wall_meta_lock_v2600", None)
            if lock_v2600 is None:
                lock_v2600 = threading.RLock()
                self._wall_meta_lock_v2600 = lock_v2600
            with lock_v2600:
                token_v2600 = int(getattr(self, "_wall_meta_token_v2600", 0) or 0) + 1
                self._wall_meta_token_v2600 = token_v2600
                self._wall_meta_pending_v2600 = (token_v2600, self._now_ms())
                if bool(getattr(self, "_wall_meta_worker_active_v2600", False)):
                    return True
                self._wall_meta_worker_active_v2600 = True

            def _worker_v2600():
                posted_v2600 = False
                try:
                    while not self._closing_event_v1841.is_set():
                        with lock_v2600:
                            pending1_v2600 = getattr(self, "_wall_meta_pending_v2600", None)
                        if not pending1_v2600:
                            break
                        token1_v2600 = int(pending1_v2600[0])
                        if self._closing_event_v1841.wait(0.160):
                            break
                        with lock_v2600:
                            pending2_v2600 = getattr(self, "_wall_meta_pending_v2600", None)
                        if not pending2_v2600:
                            break
                        if int(pending2_v2600[0]) != token1_v2600:
                            continue
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        posted_v2600 = True
                        return
                except Exception:
                    pass
                finally:
                    if not posted_v2600:
                        try:
                            with lock_v2600:
                                self._wall_meta_worker_active_v2600 = False
                        except Exception:
                            pass
            _PKMHomeThreadV2151(target=_worker_v2600, name="PKMWallMetaV2600", daemon=True).start()
            return True
        except Exception:
            return False

    def _bind_append_runway_posters_v2621(self, rows, listitems):
        """Bind a prepared local poster by map lookup; cold cards use small Plex URL."""
        local_bound = 0
        remote_bound = 0
        sid = str(getattr(self, "active_section_id", "") or "")
        try:
            for row, li in zip(list(rows or []), list(listitems or [])):
                t = tuple(row or ())
                rk = str(t[0] or "").strip() if t else ""
                canonical = self._library_row_poster_canonical_v2580(row)
                local = self._library_texture_runway_lookup_v2621(sid, rk, canonical)
                if local:
                    try:
                        fanart = str(li.getArt("fanart") or "")
                        li.setArt({"poster": local, "thumb": local, "icon": local, "fanart": fanart})
                        li.setProperty("PlexKM.WallPosterDisplayV1644", local)
                        li.setProperty("PlexKM.WidgetPosterReadyV1644", "1")
                        li.setProperty("PlexKM.ViewportTextureV1866", "1")
                        li.setProperty("PlexKM.PosterFallbackArt", "")
                        li.setProperty("PlexKM.PosterFallbackArtActive", "")
                        li.setProperty("PlexKM.PosterFallbackRoleV2498", "")
                        li.setProperty("PlexKM.PosterLocalSourceV2498", "runway_v2621")
                        li.setProperty("PlexKM.PosterMissingV1963", "")
                        li.setProperty("PlexKM.PosterMissingReasonV1963", "")
                        local_bound += 1
                        continue
                    except Exception:
                        pass
                if canonical:
                    try:
                        fanart = str(li.getArt("fanart") or "")
                        li.setArt({"poster": canonical, "thumb": canonical, "icon": canonical, "fanart": fanart})
                        li.setProperty("PlexKM.WallPosterRemoteV1644", canonical)
                        li.setProperty("PlexKM.WallPosterDisplayV1644", canonical)
                        li.setProperty("PlexKM.PosterAuthorityV2498", canonical)
                        li.setProperty("PlexKM.PosterLocalSourceV2498", "")
                        remote_bound += 1
                    except Exception:
                        pass
        except Exception:
            pass
        return int(local_bound), int(remote_bound)

    def _library_append_commit_ping_v2600(self):
        """Check/publish Android wall runway outside the remote-key callback.

        During an active burst, only local-DB prefetch is armed while more than
        one native row remains.  The expensive Kodi ControlList rebind is allowed
        only after ~140 ms input quiet, or at the physical edge where it is
        required to prevent a hard stop.
        """
        try:
            lock_v2600 = getattr(self, "_library_append_post_lock_v2600", None)
            if lock_v2600 is None:
                return False
            with lock_v2600:
                if not bool(getattr(self, "_library_append_post_pending_v2600", False)):
                    self._library_append_post_active_v2600 = False
                    return False
                self._library_append_post_pending_v2600 = False
                self._library_append_post_active_v2600 = False
                last_input_ms_v2600 = int(getattr(self, "_library_append_last_input_ms_v2600", 0) or 0)
            if not self._is_android_v2591() or self._safe_focus_id() != WALL_ID:
                return False
            if self.getProperty("PlexKM.Window.IsSectionWall") != "1":
                return False

            wall_v2600 = self.getControl(WALL_ID)
            pos_v2600 = int(wall_v2600.getSelectedPosition())
            size_v2600 = int(wall_v2600.size())
            cols_v2600 = max(1, int(self._wall_column_count() or 6))
            loaded_rows_v2600 = max(1, (max(0, size_v2600) + cols_v2600 - 1) // cols_v2600)
            current_row_v2600 = max(0, pos_v2600 // cols_v2600) if pos_v2600 >= 0 else 0
            remaining_rows_v2600 = max(0, loaded_rows_v2600 - current_row_v2600 - 1)
            input_age_v2600 = max(0, self._now_ms() - last_input_ms_v2600) if last_input_ms_v2600 > 0 else 999999

            # Arm/query the next local chunk here, never in onAction(). This is
            # background SQLite only and returns without a native container bind.
            if remaining_rows_v2600 <= max(2, int(self._library_wall_low_watermark_rows_v2077())):
                self._request_library_append_v2070(reason="post_gui_probe_v2600")

            if bool(getattr(self, "_library_append_ready_post_r52", False)):
                self._library_append_ready_post_r52 = False
                if remaining_rows_v2600 > 1:
                    # R52: data-ready post is only for a user parked at the edge;
                    # mid-scroll rebinds stay on the normal key/idle path.
                    _log("LIBRARY_APPEND_READY_POST_SKIP_R52 section=%s pos=%d remaining_rows=%d" % (
                        self.active_section_id, pos_v2600, remaining_rows_v2600))
                    return True
            if input_age_v2600 < 140 and remaining_rows_v2600 > 1:
                _log("LIBRARY_APPEND_IDLE_DEFER_V2600 section=%s pos=%d remaining_rows=%d input_age_ms=%d rebind=0" % (
                    self.active_section_id, pos_v2600, remaining_rows_v2600, input_age_v2600
                ))
                return True

            added_v2600 = self._ensure_library_append_runway_v2576(
                reason=("post_gui_edge_v2600" if remaining_rows_v2600 <= 1 else "post_gui_idle_v2600")
            )
            if int(added_v2600 or 0) > 0:
                _log("LIBRARY_APPEND_IDLE_POLICY_V2600 section=%s added=%d remaining_rows_before=%d input_age_ms=%d forced_edge=%d" % (
                    self.active_section_id, int(added_v2600 or 0), remaining_rows_v2600, input_age_v2600,
                    1 if remaining_rows_v2600 <= 1 else 0
                ))
            return True
        except Exception:
            return False

    def _schedule_library_append_commit_v2600(self, from_ready_r51=False):
        """Post one cheap Android runway check after the key callback returns."""
        try:
            if not self._is_android_v2591():
                return False
            lock_v2600 = getattr(self, "_library_append_post_lock_v2600", None)
            if lock_v2600 is None:
                lock_v2600 = threading.RLock()
                self._library_append_post_lock_v2600 = lock_v2600
            with lock_v2600:
                if not from_ready_r51:
                    self._library_append_last_input_ms_v2600 = self._now_ms()
                self._library_append_post_pending_v2600 = True
                if bool(getattr(self, "_library_append_post_active_v2600", False)):
                    return True
                self._library_append_post_active_v2600 = True

            def _post_v2600():
                posted_v2600 = False
                try:
                    if self._closing_event_v1841.wait(0.040):
                        return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    posted_v2600 = True
                except Exception:
                    pass
                finally:
                    if not posted_v2600:
                        try:
                            with lock_v2600:
                                self._library_append_post_active_v2600 = False
                        except Exception:
                            pass
            _PKMHomeThreadV2151(target=_post_v2600, name="PKMLibraryAppendPostV2600", daemon=True).start()
            return True
        except Exception:
            return False

    def _normalize_sort_dir(self, sort_dir):
        return pkm_library_sort.normalize_sort_dir(sort_dir)

    def _default_sort_dir(self, sort_key):
        return pkm_library_sort.default_sort_dir(sort_key)

    def _sort_kpi_begin_v2610(self, item, reason=""):
        """Arm one user-initiated Library sort transition across every movie/TV sort key."""
        try:
            reason_s = str(reason or "")
            if not reason_s.startswith(("dropdown:", "cycle:", "dir_toggle:")):
                self._sort_kpi_pending_v2610 = None
                return None
            sid = self._section_sid_from_item(item)
            if not sid:
                return None
            media = self._section_sort_media_kind(item)
            sort_key = self._normalize_section_sort(getattr(self, "sort", "title"), media_kind=media)
            sort_dir = self._normalize_sort_dir(getattr(self, "sort_dir", self._default_sort_dir(sort_key)))
            genre = ""
            try:
                if str(getattr(self, "_active_genre_section_id", "") or "") == str(sid):
                    genre = str(getattr(self, "_active_genre_filter", "") or "")
            except Exception:
                genre = ""
            target_key = self._section_cache_key(sid, sort_key, sort_dir) + ":genre=" + genre
            mem_warm = bool((getattr(self, "_section_rows_cache", {}) or {}).get(target_key))
            persist_loaded = False
            try:
                pcache = getattr(self, "_library_persistent_cache_v2470", None)
                persist_loaded = isinstance(pcache, dict) and bool(pcache.get(target_key))
            except Exception:
                persist_loaded = False
            warm = bool(mem_warm or persist_loaded)
            token = "%s:%s" % (str(self._now_ms()), target_key)
            rec = {
                "token": token, "started_ms": int(self._now_ms()), "section": str(sid),
                "media": str(media), "sort": str(sort_key), "dir": str(sort_dir),
                "target_key": str(target_key), "cold": 0 if warm else 1,
                "warm_source": "memory" if mem_warm else ("persistent_loaded" if persist_loaded else "cold"),
                "reason": reason_s,
            }
            self._sort_kpi_pending_v2610 = rec
            _log("SORT_TRANSITION_BEGIN_V2610 media=%s section=%s sort=%s dir=%s cold=%d warm_source=%s key=%s reason=%s" % (
                media, sid, sort_key, sort_dir, int(rec["cold"]), rec["warm_source"], target_key, reason_s
            ))
            return rec
        except Exception:
            self._sort_kpi_pending_v2610 = None
            _log("SORT_TRANSITION_BEGIN_FAILED_V2610 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return None

    def _sort_kpi_finish_v2610(self, key="", spinner_used=False, reason=""):
        """Publish one exact sort visible sample without tying it to one specific sort type."""
        try:
            rec = getattr(self, "_sort_kpi_pending_v2610", None)
            if not isinstance(rec, dict) or not rec:
                return False
            target_key = str(rec.get("target_key") or "")
            if key and target_key and str(key) != target_key:
                return False
            visible_ms = max(0, int(self._now_ms()) - int(rec.get("started_ms") or self._now_ms()))
            win = xbmcgui.Window(10000)
            props = {
                "PlexKM.KPI.SortVisibleMs": str(visible_ms),
                "PlexKM.KPI.SortMedia": str(rec.get("media") or ""),
                "PlexKM.KPI.SortSection": str(rec.get("section") or ""),
                "PlexKM.KPI.SortKey": str(rec.get("sort") or ""),
                "PlexKM.KPI.SortDir": str(rec.get("dir") or ""),
                "PlexKM.KPI.SortCold": str(int(rec.get("cold") or 0)),
                "PlexKM.KPI.SortWarmSource": str(rec.get("warm_source") or ""),
                "PlexKM.KPI.SortSpinnerUsed": "1" if spinner_used else "0",
                "PlexKM.KPI.SortReason": str(reason or rec.get("reason") or ""),
                "PlexKM.KPI.SortStamp": str(self._now_ms()),
            }
            for pk, pv in props.items():
                win.setProperty(pk, pv)
            _log("SORT_TRANSITION_VISIBLE_V2610 media=%s section=%s sort=%s dir=%s cold=%d visible_ms=%d spinner=%d warm_source=%s reason=%s" % (
                rec.get("media") or "", rec.get("section") or "", rec.get("sort") or "", rec.get("dir") or "",
                int(rec.get("cold") or 0), visible_ms, 1 if spinner_used else 0, rec.get("warm_source") or "", reason or rec.get("reason") or ""
            ))
            try:
                _matrix_v2626 = getattr(self, "_sort_matrix_seen_v2626", None)
                if not isinstance(_matrix_v2626, dict):
                    _matrix_v2626 = {"movie": {"cold": set(), "warm": set()}, "tv": {"cold": set(), "warm": set()}}
                    self._sort_matrix_seen_v2626 = _matrix_v2626
                _media_v2626 = "tv" if str(rec.get("media") or "") == "tv" else "movie"
                _temp_v2626 = "cold" if int(rec.get("cold") or 0) else "warm"
                _sort_v2626 = str(rec.get("sort") or "")
                if _sort_v2626:
                    _matrix_v2626[_media_v2626][_temp_v2626].add(_sort_v2626)
                _all_seen_v2626 = set(_matrix_v2626[_media_v2626]["cold"]) | set(_matrix_v2626[_media_v2626]["warm"])
                _expected_v2626 = 12
                win.setProperty("PlexKM.KPI.Sort%sCoverage" % ("TV" if _media_v2626 == "tv" else "Movie"), "%d/%d" % (len(_all_seen_v2626), _expected_v2626))
                win.setProperty("PlexKM.KPI.Sort%sKeys" % ("TV" if _media_v2626 == "tv" else "Movie"), ",".join(sorted(_all_seen_v2626)))
                win.setProperty("PlexKM.KPI.Sort%sColdKeys" % ("TV" if _media_v2626 == "tv" else "Movie"), ",".join(sorted(_matrix_v2626[_media_v2626]["cold"])))
                win.setProperty("PlexKM.KPI.Sort%sWarmKeys" % ("TV" if _media_v2626 == "tv" else "Movie"), ",".join(sorted(_matrix_v2626[_media_v2626]["warm"])))
                _log("SORT_MATRIX_COVERAGE_V2626 media=%s coverage=%d/12 cold=%s warm=%s complete=%d" % (
                    _media_v2626, len(_all_seen_v2626), ",".join(sorted(_matrix_v2626[_media_v2626]["cold"])) or "-",
                    ",".join(sorted(_matrix_v2626[_media_v2626]["warm"])) or "-", 1 if len(_all_seen_v2626) == 12 else 0
                ))
            except Exception:
                pass
            self._sort_kpi_pending_v2610 = None
            try:
                self._sort_head_apply_target_v2628 = ""
            except Exception:
                pass
            return True
        except Exception:
            _log("SORT_TRANSITION_FINISH_FAILED_V2610 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _sort_head_signature_v2628(self, sid, sort_key, sort_dir, genre=""):
        return "%s|%s|%s|%s" % (
            str(sid or ""), str(sort_key or ""), str(sort_dir or ""), str(genre or "")
        )

    def _sort_head_mark_apply_target_v2628(self, sort_key):
        try:
            item = self._current_section_menu_item()
            sid = self._section_sid_from_item(item)
            if not sid:
                return ""
            media = self._section_sort_media_kind()
            key = pkm_library_sort.normalize_sort_key(sort_key, media_kind=media)
            sort_dir = pkm_library_sort.default_sort_dir(key)
            genre = ""
            if str(getattr(self, "_active_genre_section_id", "") or "") == str(sid):
                genre = str(getattr(self, "_active_genre_filter", "") or "")
            signature = self._sort_head_signature_v2628(sid, key, sort_dir, genre)
            self._sort_head_apply_target_v2628 = signature
            allowed = set(getattr(self, "_sort_head_allowed_v2628", set()) or set())
            allowed.add(signature)
            self._sort_head_allowed_v2628 = allowed
            return signature
        except Exception:
            return ""

    def _home_db_genre_value_v1801(self, rating_key, parent_rating_key="", grandparent_rating_key="", plex_type="", section_id="", show_title=""):
        """Return one canonical local genre string for all Home/section item types.

        v2258 keeps the existing key-first inheritance, but episode rows also
        resolve the parent show from the local DB when the episode tuple lacks a
        usable grandparent key or item_genres has not yet been normalized.
        raw_json Genre tags are accepted as a local fallback. No Plex/network
        request is performed here, so the first focused frame can already carry
        the show genre.
        """
        ptype = str(plex_type or "").strip().lower()
        rk = str(rating_key or "").strip()
        parent = str(parent_rating_key or "").strip()
        grandparent = str(grandparent_rating_key or "").strip()
        sid = str(section_id or "").strip()
        show_name = str(show_title or "").strip()

        if ptype == "episode":
            candidates = (grandparent, parent, rk)
        elif ptype == "season":
            candidates = (parent, grandparent, rk)
        else:
            candidates = (rk, grandparent, parent)

        ordered = []
        seen_keys = set()
        for key in candidates:
            if key and key not in seen_keys:
                seen_keys.add(key)
                ordered.append(key)

        try:
            cache = getattr(self, "_home_db_genre_cache_v1801", None)
            if cache is None:
                cache = {}
                self._home_db_genre_cache_v1801 = cache
            title_cache = getattr(self, "_home_db_show_genre_cache_v2258", None)
            if title_cache is None:
                title_cache = {}
                self._home_db_show_genre_cache_v2258 = title_cache

            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""

            conn = None

            def _genres_from_raw(raw):
                if not raw:
                    return ""
                try:
                    node = json.loads(raw) if isinstance(raw, str) else raw
                except Exception:
                    return ""
                values = []
                seen = set()

                def _add(value):
                    value = str(value or "").strip()
                    folded = value.casefold()
                    if value and folded not in seen:
                        seen.add(folded)
                        values.append(value)

                try:
                    source = node.get("Genre")
                    if source in (None, ""):
                        source = node.get("genre")
                    if isinstance(source, str):
                        for part in source.split(","):
                            _add(part)
                    elif isinstance(source, dict):
                        _add(source.get("tag") or source.get("title") or source.get("name"))
                    elif isinstance(source, (list, tuple)):
                        for item in source:
                            if isinstance(item, dict):
                                _add(item.get("tag") or item.get("title") or item.get("name"))
                            else:
                                _add(item)
                except Exception:
                    return ""
                return ", ".join(values)

            def _genre_for_key(source_key):
                nonlocal conn
                source_key = str(source_key or "").strip()
                if not source_key:
                    return ""
                if source_key in cache:
                    return cache.get(source_key) or ""
                if conn is None:
                    conn = _pkm_ro_connect(dbp, timeout=2.0)

                rows = conn.execute(
                    "SELECT genre FROM item_genres WHERE rating_key=? AND IFNULL(genre,'')<>'' ORDER BY rowid",
                    (source_key,),
                ).fetchall()
                genres = []
                seen = set()
                for row in rows or []:
                    value = str((row[0] if row else "") or "").strip()
                    folded = value.casefold()
                    if value and folded not in seen:
                        seen.add(folded)
                        genres.append(value)
                result = ", ".join(genres)

                # v2258: the show row can already contain Plex Genre tags in
                # raw_json even when item_genres has not been normalized yet.
                if not result:
                    raw_row = conn.execute(
                        "SELECT raw_json FROM items WHERE rating_key=? LIMIT 1",
                        (source_key,),
                    ).fetchone()
                    result = _genres_from_raw(raw_row[0] if raw_row else "")

                cache[source_key] = result
                return result

            # Existing exact-key inheritance remains first priority.
            for source_key in ordered:
                result = _genre_for_key(source_key)
                if result:
                    if source_key != rk:
                        _log("SECTION_GENRE_INHERIT_V1801 rating_key=%s source_key=%s type=%s genre=%s" % (
                            rk, source_key, ptype or "unknown", _short_log_value(result, 120)
                        ))
                    return result

            # v2258 episode fallback: resolve the local SHOW row by section and
            # title. This fixes tuples where grandparent_rating_key is missing,
            # stale, or the show genre only exists in the show's raw_json.
            if ptype == "episode" and show_name:
                title_key = self._dedup_text_key(show_name)
                cache_key = "%s|%s" % (sid, title_key)
                if cache_key in title_cache:
                    result = title_cache.get(cache_key) or ""
                    if result:
                        _log("HOME_EPISODE_GENRE_LOCAL_INHERIT_V2258 rating_key=%s show=%s source=title_cache genre=%s" % (
                            rk, _short_log_value(show_name, 100), _short_log_value(result, 120)
                        ))
                    return result

                if conn is None:
                    conn = _pkm_ro_connect(dbp, timeout=2.0)
                if sid:
                    show_rows = conn.execute(
                        """SELECT rating_key, title, raw_json
                           FROM items
                           WHERE section_id=? AND plex_type='show'
                           LIMIT 600""",
                        (sid,),
                    ).fetchall()
                else:
                    show_rows = conn.execute(
                        """SELECT rating_key, title, raw_json
                           FROM items
                           WHERE plex_type='show'
                           LIMIT 1200"""
                    ).fetchall()

                result = ""
                source_show_key = ""
                for show_row in show_rows or []:
                    candidate_title = str((show_row[1] if len(show_row) > 1 else "") or "").strip()
                    if self._dedup_text_key(candidate_title) != title_key:
                        continue
                    source_show_key = str((show_row[0] if show_row else "") or "").strip()
                    result = _genre_for_key(source_show_key)
                    if not result:
                        result = _genres_from_raw(show_row[2] if len(show_row) > 2 else "")
                    if result:
                        break

                title_cache[cache_key] = result
                if result:
                    _log("HOME_EPISODE_GENRE_LOCAL_INHERIT_V2258 rating_key=%s show_key=%s show=%s source=local_show genre=%s" % (
                        rk, source_show_key, _short_log_value(show_name, 100), _short_log_value(result, 120)
                    ))
                return result

            return ""
        except Exception:
            try:
                _log("SECTION_GENRE_DB_READ_FAILED_V2258 rating_key=%s err=%s" % (
                    rk, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            except Exception:
                pass
            return ""
        finally:
            try:
                if 'conn' in locals() and conn is not None:
                    conn.close()
            except Exception:
                pass

    def _listitem_genre_fallback(self, li, current=""):
        value = str(current or "").strip()
        if value:
            return value
        if not li:
            return ""
        try:
            value = str(li.getProperty("PlexKM.Genre") or "").strip()
            if value:
                return value
        except Exception:
            pass
        try:
            tag = li.getVideoInfoTag()
        except Exception:
            tag = None
        if tag:
            for attr in ("getGenres", "getGenre"):
                try:
                    getter = getattr(tag, attr, None)
                    if not getter:
                        continue
                    raw = getter()
                    if isinstance(raw, (list, tuple)):
                        parts = [str(x or "").strip() for x in raw if str(x or "").strip()]
                        value = ", ".join(parts)
                    else:
                        value = str(raw or "").strip()
                    if value:
                        return value
                except Exception:
                    pass
        return ""

    def _first_wall_item_for_home_meta(self):
        """Return the first real item from the canonical Home XML row controls.

        Home metadata readiness has one owner: HOME_ROW_IDS (9410~9600).
        The old flat WALL_ID fallback has been removed completely because it is
        not part of the Home widget stack and can only create false readiness or
        false waiting states.
        """
        def _is_media_item(li):
            try:
                return li is not None and bool(
                    li.getProperty("PlexKM.RatingKey") or
                    li.getProperty("PlexKM.PlayUrl") or
                    li.getProperty("PlexKM.ShowUrl")
                )
            except Exception:
                return False

        for cid in HOME_ROW_IDS:
            try:
                ctrl = self.getControl(cid)
                if int(ctrl.size()) <= 0:
                    continue
                try:
                    li = ctrl.getSelectedItem()
                except Exception:
                    li = None
                if _is_media_item(li):
                    _log("HOME_FIRST_META_SOURCE_V1757 source=row_selected control=%s size=%s" % (cid, ctrl.size()))
                    return li
                try:
                    li = ctrl.getListItem(0)
                except Exception:
                    li = None
                if _is_media_item(li):
                    _log("HOME_FIRST_META_SOURCE_V1757 source=row_first control=%s size=%s" % (cid, ctrl.size()))
                    return li
            except Exception:
                continue

        _nonempty_rows_v1757 = []
        for cid in HOME_ROW_IDS:
            try:
                if int(self.getControl(cid).size()) > 0:
                    _nonempty_rows_v1757.append(str(cid))
            except Exception:
                pass
        _log("HOME_FIRST_META_SOURCE_V1757 source=none rendered_rows=%s" % ",".join(_nonempty_rows_v1757))
        return None


    def _canonical_movie_duplicate_index_build_v1942(self, dbp):
        """Build the duplicate-movie index from one SQLite snapshot.

        This helper deliberately performs no GUI/control work, so it is safe to
        run in the background after a usable index already exists.
        """
        index = {}
        conn = None
        rows = []
        try:
            conn = _pkm_ro_connect(dbp, timeout=5.0)
            rows = conn.execute("""
                SELECT i.rating_key, i.title, i.original_title, i.year, i.duration, i.raw_json,
                       r.score, r.rating, r.audience_rating, r.user_rating
                FROM items i
                LEFT JOIN item_ratings r ON r.rating_key=i.rating_key
                WHERE i.plex_type='movie'
                  AND CAST(COALESCE(i.year,'') AS TEXT)<>''
            """).fetchall()
            for rr in rows or []:
                rk = str(rr[0] or "").strip()
                yy = str(rr[3] or "").strip()
                if not rk or not yy:
                    continue
                candidate = (rk, _safe_int(rr[4], 0), rr[5] if len(rr) > 5 else "",
                             rr[6] if len(rr) > 6 else "", rr[7] if len(rr) > 7 else "",
                             rr[8] if len(rr) > 8 else "", rr[9] if len(rr) > 9 else "")
                seen_names = set()
                for name in (rr[1] if len(rr) > 1 else "", rr[2] if len(rr) > 2 else ""):
                    ns = str(name or "").strip().casefold()
                    if ns and ns not in seen_names:
                        seen_names.add(ns)
                        index.setdefault((ns, yy), []).append(candidate)
            return index, len(rows or [])
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def _canonical_movie_duplicate_index_refresh_worker_v1942(self, dbp, requested_mtime):
        """Refresh a stale but usable index without blocking sidebar rendering."""
        started = time.time()
        row_count = 0
        try:
            index, row_count = self._canonical_movie_duplicate_index_build_v1942(dbp)
            try:
                final_mtime = os.path.getmtime(dbp)
            except Exception:
                final_mtime = requested_mtime
            lock = getattr(self, "_canonical_movie_duplicate_index_lock_v1942", None)
            if lock is None:
                self._canonical_movie_duplicate_index_lock_v1942 = threading.RLock()
                lock = self._canonical_movie_duplicate_index_lock_v1942
            with lock:
                self._canonical_movie_duplicate_index_cache_v1817 = index
                # If SQLite changed again while the snapshot was read, retain the
                # requested mtime. The next UI lookup will schedule one later refresh
                # rather than treating a potentially older snapshot as fully current.
                if float(final_mtime or 0) == float(requested_mtime or 0):
                    self._canonical_movie_duplicate_index_mtime_v1817 = final_mtime
                else:
                    self._canonical_movie_duplicate_index_mtime_v1817 = requested_mtime
                self._canonical_movie_duplicate_meta_cache_v1816 = {}
                self._canonical_movie_duplicate_index_refresh_running_v1942 = False
                self._canonical_movie_duplicate_index_last_refresh_v1942 = time.time()
            _log("CANONICAL_MOVIE_META_INDEX_BG_READY_V1942 rows=%d keys=%d requested_mtime=%.6f final_mtime=%.6f elapsed=%.1fms gui_block_ms=0" % (
                row_count, len(index), float(requested_mtime or 0), float(final_mtime or 0),
                (time.time() - started) * 1000.0
            ))
        except Exception:
            try:
                lock = getattr(self, "_canonical_movie_duplicate_index_lock_v1942", None)
                if lock is None:
                    self._canonical_movie_duplicate_index_lock_v1942 = threading.RLock()
                    lock = self._canonical_movie_duplicate_index_lock_v1942
                with lock:
                    self._canonical_movie_duplicate_index_refresh_running_v1942 = False
                    # Avoid immediately starting another full scan on every ListItem.
                    self._canonical_movie_duplicate_index_refresh_not_before_v1942 = time.time() + 5.0
            except Exception:
                pass
            _log("CANONICAL_MOVIE_META_INDEX_BG_ERROR_V1942 requested_mtime=%.6f rows=%d err=%s" % (
                float(requested_mtime or 0), row_count,
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _canonical_movie_duplicate_index_v1817(self):
        """Return an O(1) duplicate-movie index without blocking revisits.

        The first load still builds synchronously under the startup splash. Once
        an index exists, DB mtime changes use stale-while-revalidate: sidebar and
        widget ListItems keep using the last complete immutable dictionary while
        one daemon worker rebuilds the next snapshot. This removes the observed
        ~1 second 23k-row SQLite scan from the GUI/menu path.
        """
        dbp = self._profile_db_path()
        if not dbp or not os.path.exists(dbp):
            return {}
        try:
            mtime = os.path.getmtime(dbp)
        except Exception:
            mtime = 0

        lock = getattr(self, "_canonical_movie_duplicate_index_lock_v1942", None)
        if lock is None:
            self._canonical_movie_duplicate_index_lock_v1942 = threading.RLock()
            lock = self._canonical_movie_duplicate_index_lock_v1942

        with lock:
            cache = getattr(self, "_canonical_movie_duplicate_index_cache_v1817", None)
            cache_mtime = getattr(self, "_canonical_movie_duplicate_index_mtime_v1817", None)
            if isinstance(cache, dict) and cache_mtime == mtime:
                return cache

            if isinstance(cache, dict):
                now = time.time()
                running = bool(getattr(self, "_canonical_movie_duplicate_index_refresh_running_v1942", False))
                not_before = float(getattr(self, "_canonical_movie_duplicate_index_refresh_not_before_v1942", 0.0) or 0.0)
                scheduled = False
                if (not running) and now >= not_before:
                    self._canonical_movie_duplicate_index_refresh_running_v1942 = True
                    # A DB incremental sync can update mtime several times in a row.
                    # One refresh per five seconds is sufficient for fallback metadata
                    # and prevents a chain of full-table scans.
                    self._canonical_movie_duplicate_index_refresh_not_before_v1942 = now + 5.0
                    worker = _PKMHomeThreadV2151(
                        target=self._canonical_movie_duplicate_index_refresh_worker_v1942,
                        args=(dbp, mtime),
                        name="PKMCanonicalMovieIndexV1942",
                        daemon=True,
                    )
                    worker.start()
                    scheduled = True

                stale_key = (float(cache_mtime or 0), float(mtime or 0))
                if scheduled or getattr(self, "_canonical_movie_duplicate_index_stale_log_key_v1942", None) != stale_key:
                    self._canonical_movie_duplicate_index_stale_log_key_v1942 = stale_key
                    _log("CANONICAL_MOVIE_META_INDEX_STALE_HIT_V1942 old_mtime=%.6f new_mtime=%.6f keys=%d gui_block_ms=0 background_refresh=%d refresh_running=%d" % (
                        float(cache_mtime or 0), float(mtime or 0), len(cache),
                        1 if scheduled else 0,
                        1 if (running or scheduled) else 0,
                    ))
                return cache

        # V2591 Android: duplicate metadata is decorative. A cold full movie-table
        # scan must never sit on Home/Library foreground. Schedule the existing
        # immutable index worker and let the current card render without it.
        if self._is_android_v2591():
            with lock:
                running = bool(getattr(self, "_canonical_movie_duplicate_index_refresh_running_v1942", False))
                if not running:
                    self._canonical_movie_duplicate_index_refresh_running_v1942 = True
                    self._canonical_movie_duplicate_index_refresh_not_before_v1942 = time.time() + 5.0
                    worker = _PKMHomeThreadV2151(
                        target=self._canonical_movie_duplicate_index_refresh_worker_v1942,
                        args=(dbp, mtime),
                        name="PKMCanonicalMovieIndexV1942",
                        daemon=True,
                    )
                    worker.start()
                    _log("UHD3_CANONICAL_COLD_DEFER_V2591 mtime=%.6f foreground_scan=0 background_after_idle=1" % float(mtime or 0))
            return {}

        # Cold start only: no usable dictionary exists yet. Build once while the
        # PKM startup cover owns the screen, then every later refresh is asynchronous.
        started = time.time()
        try:
            index, row_count = self._canonical_movie_duplicate_index_build_v1942(dbp)
            try:
                final_mtime = os.path.getmtime(dbp)
            except Exception:
                final_mtime = mtime
            with lock:
                self._canonical_movie_duplicate_index_cache_v1817 = index
                self._canonical_movie_duplicate_index_mtime_v1817 = final_mtime
                self._canonical_movie_duplicate_meta_cache_v1816 = {}
                self._canonical_movie_duplicate_index_refresh_running_v1942 = False
                self._canonical_movie_duplicate_index_last_refresh_v1942 = time.time()
            _startup_progress_v1845(75, reason="canonical_movie_index_ready")
            _log("CANONICAL_MOVIE_META_BULK_INDEX_V1817 rows=%d keys=%d elapsed=%.1fms cold_start=1" % (
                row_count, len(index), (time.time() - started) * 1000.0
            ))
            return index
        except Exception:
            _log("CANONICAL_MOVIE_META_BULK_INDEX_ERROR_V1817 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return {}

    def _build_wall_listitems_v1841(self, rows, log_prefix="WALL_PREPARE"):
        """Build a complete native wall replacement before the visible reset."""
        try:
            self._preload_visible_row_ratings(rows, reason="%s_wall_rows" % (log_prefix or ""))
        except Exception:
            pass
        prepared = []
        for row in rows or []:
            if isinstance(row, dict):
                li = self._li_from_row(row.get("row"), row_title=row.get("row_title", ""), row_type=row.get("row_type", ""), row_first=bool(row.get("row_first")), row_id=row.get("row_id", ""), row_start=row.get("row_start", -1), row_index=row.get("row_index", -1))
            else:
                li = self._li_from_row(row)
            prepared.append(li)
        return prepared

    def _set_wall_items_from_rows(self, rows, log_prefix="CACHE_RESTORE", prepared_listitems_v1841=None, suppress_postbind_v2470=False):
        # v1841: `_li_from_row()` can fail on malformed/corrupt metadata. Build
        # every replacement item before clearing the visible wall so a failure
        # cannot turn a valid previous view into a blank panel.
        _cast_prewarm_lis_v1336 = (
            list(prepared_listitems_v1841)
            if prepared_listitems_v1841 is not None
            else self._build_wall_listitems_v1841(rows, log_prefix=log_prefix)
        )
        wall = self.getControl(WALL_ID)
        # Keep a short-lived reference to the currently published native items.
        # If reset/add fails, restore them before propagating the error.  This is
        # synchronous on the WindowXML callback and does not retain ListItems in
        # a background worker.
        previous_items_v1841 = []
        previous_pos_v1841 = 0
        try:
            previous_pos_v1841 = max(0, int(wall.getSelectedPosition()))
            previous_items_v1841 = [
                wall.getListItem(i) for i in range(max(0, int(wall.size())))
            ]
        except Exception:
            previous_items_v1841 = []
            previous_pos_v1841 = 0
        # PKM_SMOOTH_TRANSITION_R33: Library -> Library replaces the rows of the
        # already-visible panel 9100, which used to hard-cut.  Flip the a/b token
        # immediately before reset/addItems; XML restarts a 35%->100% fade on
        # each flip.  Only when the wall is the visible scene and had rows, so
        # Home/Recommend -> Library keeps its own IsSectionWall fade.
        try:
            def _first_key_r33(items_r33):
                try:
                    return str(items_r33[0].getProperty("PlexKM.RatingKey") or items_r33[0].getLabel() or "") if items_r33 else ""
                except Exception:
                    return ""
            # Same first row = an in-place refresh of the same list: no fade.
            if (previous_items_v1841 and self.getProperty("PlexKM.Window.IsSectionWall") == "1"
                    and _first_key_r33(previous_items_v1841) != _first_key_r33(_cast_prewarm_lis_v1336)):
                swap_next_r33 = "b" if self.getProperty("PlexKM.Scene.WallSwapR33") == "a" else "a"
                self.setProperty("PlexKM.Scene.WallSwapR33", swap_next_r33)
                _log("WALL_SWAP_FADE_R33 token=%s reason=%s previous=%d" % (
                    swap_next_r33, log_prefix or "", len(previous_items_v1841)))
        except Exception:
            pass
        try:
            wall.reset()
            self._reset_wall_cursor("set_wall_items:%s" % log_prefix)
            try:
                wall.addItems(_cast_prewarm_lis_v1336)
            except Exception:
                for li in _cast_prewarm_lis_v1336:
                    wall.addItem(li)
        except Exception:
            try:
                wall.reset()
                if previous_items_v1841:
                    try:
                        wall.addItems(previous_items_v1841)
                    except Exception:
                        for old_li_v1841 in previous_items_v1841:
                            wall.addItem(old_li_v1841)
                    if wall.size() > 0:
                        wall.selectItem(min(previous_pos_v1841, wall.size() - 1))
                _log("%s_ROLLBACK_V1841 restored=%d reason=publish_failed" % (
                    log_prefix, len(previous_items_v1841)
                ), xbmc.LOGERROR)
            except Exception:
                _log("%s_ROLLBACK_FAILED_V1841 err=%s" % (
                    log_prefix, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGERROR)
            raise
        if not suppress_postbind_v2470:
            try:
                self._schedule_info_cast_prewarm_for_listitems(_cast_prewarm_lis_v1336, reason="%s_wall_visible_buffer_v1339" % (log_prefix or "wall"), limit=CAST_PREWARM_VISIBLE_LIMIT_V1339)
            except Exception:
                pass
        else:
            _log("LIBRARY_FOCUS_POSTBIND_SKIP_V2470 reason=%s cast_prewarm=0 focus_io=0" % (log_prefix or ""))
        self._sync_wall_first_key(log_prefix)
        self.wall_offset = len(rows or [])
        _log("LIBRARY_POSTER_AHEAD_PREFETCH_SUPPRESS_V1865 section=%s loaded=%d reason=%s next_chunk=on_down" % (
            self.active_section_id, len(rows or []), log_prefix or ""
        ))
        try:
            if wall.size() > 0:
                if self._library_wall_is_native_owner_v2070():
                    self._sync_library_selection_telemetry_v2070(reason="publish:%s" % (log_prefix or ""))
                else:
                    target = min(max(0, self._last_wall_pos), wall.size() - 1)
                    wall.selectItem(target)
                    self._logical_wall_pos = target
                    self._last_wall_pos = target
                if not suppress_postbind_v2470:
                    self._set_home_meta_from_item(reason=log_prefix)
                    self._section_index_sync_for_item(self._focused_wall_item(), reason=log_prefix)
        except Exception:
            pass
        _log("%s section=%s added=%d offset=%d total=%d" % (
            log_prefix, self.active_section_id, self.wall_offset, self.wall_offset, self.wall_total))
        return len(_cast_prewarm_lis_v1336)

    def _home_filter_continue_membership(self, rows, publish_authority=False, uncapped_r29=False):
        """Return Home Continue rows that represent a real resumable state.

        TV membership is evaluated on *logical* episodes, not physical Plex
        copies.  Parallel copies such as 1080p/2160p or base/4K season folders
        are merged by normalized show title + story season + episode number.

        Policy:
        - if every logical episode currently available has a watched copy,
          the show is complete and does not belong in Continue;
        - zero-progress Plex onDeck "next episode" entries do not belong in
          Continue;
        - an active TV Continue card must have 60s..90% progress;
        - if more than one logical episode has active progress, the later
          season/episode wins;
        - completed shows remain eligible for the existing TV "다시 보기"
          recommendation row; this function only removes them from Continue.

        This function is network-free. It uses one batched items-table read plus
        the already-existing local-resume and Continue-preload stores.
        """
        source_rows = [tuple(row or ()) for row in list(rows or [])]
        if not source_rows:
            return source_rows

        started = _pkm_speed_ms()
        core_mod = _ensure_core()

        def _story_season(value):
            season_num = _safe_int(value, 0)
            return season_num - 100 if 101 <= season_num <= 199 else season_num

        def _group_key_from_values(values):
            values = tuple(values or ())
            show_title = str(values[18] if len(values) > 18 else "").strip()
            if show_title:
                normalized = pkm_media_versions.normalize_title(show_title)
                if normalized:
                    return "title:%s" % normalized
            show_key = str(values[22] if len(values) > 22 else "").strip()
            return "key:%s" % show_key if show_key else ""

        def _group_key_from_item(item):
            show_title = str((item or {}).get("show_title") or "").strip()
            if show_title:
                normalized = pkm_media_versions.normalize_title(show_title)
                if normalized:
                    return "title:%s" % normalized
            show_key = str((item or {}).get("grandparent_rating_key") or "").strip()
            return "key:%s" % show_key if show_key else ""

        def _resume_record(off, duration, resume_duration, stamp, source):
            try:
                off_ms, dur_ms, pct = getattr(core_mod, "_pkm_progress_pair")(
                    off, duration, resume_duration
                )
            except Exception:
                return None
            off_ms = max(0, _safe_int(off_ms, 0))
            dur_ms = max(0, _safe_int(dur_ms, 0))
            pct = int(max(0, min(100, _safe_int(pct, 0))))
            if off_ms < 30000 or dur_ms <= 0 or not (0 < pct < 90):  # R31 (was 60 s)
                return None
            return {
                "offset_ms": off_ms,
                "duration_ms": dur_ms,
                "pct": pct,
                "stamp": _safe_int(stamp, 0),
                "source": str(source or ""),
            }

        # Resume state indexed by physical Plex ratingKey. A newer source wins.
        resume_by_rk = {}

        def _put_resume(rk, off, duration, resume_duration, stamp, source):
            rk = str(rk or "").strip()
            if not rk:
                return
            rec = _resume_record(off, duration, resume_duration, stamp, source)
            if not rec:
                return
            old = resume_by_rk.get(rk)
            if old is None or (
                _safe_int(rec.get("stamp"), 0),
                _safe_int(rec.get("offset_ms"), 0),
            ) >= (
                _safe_int(old.get("stamp"), 0),
                _safe_int(old.get("offset_ms"), 0),
            ):
                resume_by_rk[rk] = rec

        # Current Continue rows are already normalized to the extended row shape.
        for values in source_rows:
            if str(values[2] if len(values) > 2 else "").strip().lower() not in ("episode", "movie"):
                continue
            _put_resume(
                values[0] if len(values) > 0 else "",
                values[23] if len(values) > 23 else 0,
                values[9] if len(values) > 9 else 0,
                values[24] if len(values) > 24 else 0,
                values[25] if len(values) > 25 else (values[17] if len(values) > 17 else 0),
                values[26] if len(values) > 26 else "continue_row",
            )

        # Durable preload can contain a different episode of the same drama than
        # the single physical row currently chosen by Plex/onDeck.
        try:
            reader = getattr(core_mod, "_read_continue_preload_items", None)
            preload_result = reader(max_age=0) if reader else ([], 0)
            preload_items = preload_result[0] if isinstance(preload_result, tuple) else preload_result
        except Exception:
            preload_items = []
        preload_by_group = {}
        for item in list(preload_items or []):
            if not isinstance(item, dict):
                continue
            rk = str(item.get("rating_key") or "").strip()
            if rk:
                _put_resume(
                    rk,
                    item.get("view_offset"),
                    item.get("duration"),
                    item.get("resume_duration_ms"),
                    item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at"),
                    item.get("resume_source") or "continue_preload",
                )
            key = _group_key_from_item(item)
            if key:
                preload_by_group.setdefault(key, []).append(item)

        # Kodi's stop-position sidecar is the freshest local resume authority.
        try:
            local_states = getattr(core_mod, "_read_local_resume_states", lambda: {})() or {}
        except Exception:
            local_states = {}
        for rk, state in dict(local_states or {}).items():
            if not isinstance(state, dict):
                continue
            _put_resume(
                rk,
                state.get("time"),
                0,
                state.get("duration"),
                state.get("updated_at"),
                state.get("reason") or "kodi_local_resume",
            )

        # Movies already have strict progress validation in the core Continue
        # query. TV is the path that deliberately admitted zero-progress onDeck
        # "next" entries, so only TV rows need membership reconciliation here.
        tv_source_groups = {}
        passthrough_movies = []
        for values in source_rows:
            plex_type = str(values[2] if len(values) > 2 else "").strip().lower()
            if plex_type != "episode":
                passthrough_movies.append(values)
                continue
            key = _group_key_from_values(values)
            if key:
                tv_source_groups.setdefault(key, []).append(values)

        if not tv_source_groups:
            return source_rows

        # U5: detect exact same input AND local resume decisions; only reuse
        # when all cached episode watch states and section authority still match.
        _member_sig_u5 = ""
        _sig_parts_r25 = {}
        try:
            _authority_u5 = self._persistent_selected_section_authority_combined_v2489() or ""
            # R25: hash each input separately so a miss names what changed.
            def _h_r25(value):
                return hashlib.sha256(repr(value).encode("utf-8", "replace")).hexdigest()[:16]
            _sig_parts_r25 = {
                "rows": _h_r25(source_rows),
                "resume": _h_r25(sorted(resume_by_rk.items())),
                "groups": _h_r25(sorted(tv_source_groups)),
                "authority": _h_r25(_authority_u5),
            }
            _member_sig_u5 = self._continue_sig_parts_r25(_sig_parts_r25)
            _hit_u5 = self._continue_membership_cache_check_u5(_member_sig_u5, _sig_parts_r25)
            if _hit_u5 is not None:
                if publish_authority:
                    self._continue_membership_authority_rows = list(_hit_u5)
                    self._continue_membership_authority_updated_ms = int(time.time() * 1000)
                    self._continue_membership_progress_map = self._home_runtime_progress_map_v2499_build(_hit_u5)
                return _hit_u5
        except Exception:
            _member_sig_u5 = ""

        exact_titles = set()
        show_keys = set()
        for group_rows in tv_source_groups.values():
            for values in group_rows:
                title = str(values[18] if len(values) > 18 else "").strip()
                if title:
                    exact_titles.add(title)
                gp = str(values[22] if len(values) > 22 else "").strip()
                if gp:
                    show_keys.add(gp)
        for items in preload_by_group.values():
            for item in items:
                title = str(item.get("show_title") or "").strip()
                if title:
                    exact_titles.add(title)
                gp = str(item.get("grandparent_rating_key") or "").strip()
                if gp:
                    show_keys.add(gp)

        # PKM_U7_CONTINUE_EPISODE_DB_CACHE_20261011
        # Cache the expensive 1GB DB episode metadata SELECT, NOT the Continue
        # decision. On every call the current Plex/onDeck rows and Kodi resume
        # sidecar are processed again below; watch-state and episode presence
        # are trusted only when the SQLite DB+WAL file identity is unchanged.
        # If database identity cannot be proven, fall back to the original query.
        def _db_epoch_u7(base):
            try:
                if not base or not os.path.isfile(base):
                    return None
                stamps = []
                for suffix in ('', '-wal', '-journal'):
                    candidate = base + suffix
                    if os.path.exists(candidate):
                        st = os.stat(candidate)
                        stamps.append((suffix, int(st.st_size), int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000)))))
                    else:
                        stamps.append((suffix, -1, -1))
                return tuple(stamps)
            except Exception:
                return None

        _dbp_u7 = self._profile_db_path()
        _epoch_u7 = _db_epoch_u7(_dbp_u7)
        _selected_sig_u7 = ''
        try:
            _selected_sig_u7, _ = self._startup_prepare_selected_signature_v2477()
        except Exception:
            pass
        _query_sig_u7 = hashlib.sha256(repr((sorted(exact_titles), sorted(show_keys),
                                              str(_selected_sig_u7 or ''))).encode('utf-8','replace')).hexdigest()
        _cache_path_u7 = self._derived_cache_path_v2467('continue_episode_db_rows_u7.json')
        _cache_hit_u7 = False
        db_rows = []
        if _epoch_u7 is not None and _selected_sig_u7 and _cache_path_u7:
            try:
                if os.path.isfile(_cache_path_u7):
                    with open(_cache_path_u7, 'r', encoding='utf-8') as fh:
                        _cache_data_u7 = json.load(fh)
                    if (isinstance(_cache_data_u7, dict)
                            and _cache_data_u7.get('version') == 8
                            and _cache_data_u7.get('query') == _query_sig_u7
                            and tuple(tuple(x) for x in _cache_data_u7.get('epoch', [])) == _epoch_u7
                            and isinstance(_cache_data_u7.get('rows'), list)
                            and _cache_data_u7['rows']
                            and _db_epoch_u7(_dbp_u7) == _epoch_u7):
                        db_rows = [tuple(x) for x in _cache_data_u7['rows']]
                        if len(db_rows) <= 10000 and all(len(x) == 24 for x in db_rows):
                            _cache_hit_u7 = True
                            _log('HOME_CONTINUE_DB_ROWS_HIT_U7 rows=%d original_query_skipped=1' % len(db_rows))
                        else:
                            db_rows = []
            except Exception:
                db_rows = []
        # R38: the capped GUI attempt for this exact input already hit its
        # deadline and the uncapped R29 background run is pending (4 s).  A second
        # foreground try (sidebar focus then ENTER) can only end the same way, so
        # keep the source rows now instead of paying another 250-400 ms.
        if not _cache_hit_u7 and not uncapped_r29 and _member_sig_u5:
            try:
                _r38_bg_pending = (
                    bool(self._is_android_v2591())
                    and getattr(self, "_r29_continue_bg_sig", None) == _member_sig_u5
                    and (time.monotonic() - float(getattr(self, "_r29_continue_bg_t_r38", 0.0) or 0.0)) < 20.0
                )
            except Exception:
                _r38_bg_pending = False
            if _r38_bg_pending:
                _log("HOME_CONTINUE_SQL_SKIP_BG_PENDING_R38 action=source_rows_keep_no_false_empty")
                if publish_authority:
                    self._continue_membership_authority_rows = list(source_rows)
                    self._continue_membership_authority_updated_ms = int(time.time() * 1000)
                    self._continue_membership_progress_map = self._home_runtime_progress_map_v2499_build(source_rows)
                return source_rows
        if not _cache_hit_u7:
            db_rows = []
            conn = None
            try:
                db_path = self._profile_db_path()
                if db_path and os.path.exists(db_path):
                    conn = sqlite3.connect(db_path, timeout=0.25)
                    _u2_sql_capped = bool(self._is_android_v2591()) and not uncapped_r29
                    _u2_sql_begin = time.monotonic()
                    if _u2_sql_capped:
                        conn.set_progress_handler(lambda: 1 if (time.monotonic() - _u2_sql_begin) > 0.25 else 0, 3000)
                    # R25: "show_title IN (...) OR grandparent_rating_key IN (...)"
                    # had no usable index for show_title, so SQLite scanned the
                    # whole items table and read every raw_json blob.  Resolve
                    # titles to show ratingKeys through the show rows (plex_type
                    # leading index), then read episodes by grandparent key
                    # (idx_items_episode_show_progress).  raw_json is loaded
                    # later only for the few rows that become Continue cards.
                    _r25_t0 = time.monotonic()
                    gp_keys_r25 = set(show_keys)
                    unresolved_titles_r25 = set(exact_titles)
                    if exact_titles:
                        title_list_r25 = sorted(exact_titles)
                        for i_r25 in range(0, len(title_list_r25), 400):
                            chunk_r25 = title_list_r25[i_r25:i_r25 + 400]
                            marks = ",".join("?" for _ in chunk_r25)
                            for show_rk_r25, show_title_r25 in conn.execute(
                                "SELECT rating_key, title FROM items "
                                "WHERE plex_type='show' AND title IN (%s)" % marks,
                                tuple(chunk_r25)
                            ).fetchall():
                                if str(show_rk_r25 or "").strip():
                                    gp_keys_r25.add(str(show_rk_r25).strip())
                                    unresolved_titles_r25.discard(show_title_r25)
                    _r25_resolve_ms = int((time.monotonic() - _r25_t0) * 1000)
                    select_r25 = (
                        "SELECT rating_key, section_id, plex_type, kodi_type, title, "
                        "original_title, sort_title, year, summary, duration, added_at, "
                        "updated_at, thumb, art, media_file, part_key, view_count, "
                        "last_viewed_at, show_title, season, episode, parent_rating_key, "
                        "grandparent_rating_key, '' AS raw_json FROM items "
                    )
                    seen_r25 = set()
                    gp_list_r25 = sorted(gp_keys_r25)
                    for i_r25 in range(0, len(gp_list_r25), 400):
                        chunk_r25 = gp_list_r25[i_r25:i_r25 + 400]
                        marks = ",".join("?" for _ in chunk_r25)
                        for row_r25 in conn.execute(
                            select_r25 +
                            "WHERE plex_type='episode' AND grandparent_rating_key IN (%s)" % marks,
                            tuple(chunk_r25)
                        ).fetchall():
                            if row_r25[0] not in seen_r25:
                                seen_r25.add(row_r25[0])
                                db_rows.append(row_r25)
                    # R30: titles with no matching show row used a show_title
                    # scan of the whole table (title_fallback=4 cost ~5 s on
                    # SHIELD).  Those shows are already covered by their own
                    # grandparent key from the Continue row; only the search
                    # for extra parallel copies is skipped.
                    _r25_fallback = len(unresolved_titles_r25)
                    _log("HOME_CONTINUE_EPISODE_QUERY_R25 titles=%d show_keys=%d resolved_shows=%d "
                         "title_fallback=%d rows=%d resolve_ms=%d total_ms=%d raw_json=deferred" % (
                             len(exact_titles), len(show_keys), len(gp_keys_r25), _r25_fallback,
                             len(db_rows), _r25_resolve_ms, int((time.monotonic() - _r25_t0) * 1000)))
                    if _u2_sql_capped:
                        conn.set_progress_handler(None, 0)
            except sqlite3.OperationalError as _u2_exc:
                if (self._is_android_v2591() and "interrupt" in str(_u2_exc).lower()):
                    _log("HOME_CONTINUE_SQL_DEADLINE_U2 elapsed_ms=%d action=source_rows_keep_no_false_empty" % int((time.monotonic() - _u2_sql_begin) * 1000))
                    # R29: on SHIELD the 250 ms cap was hit on every start, so
                    # nothing was ever stored and the cache missed forever.
                    # Finish the same work once in the background (no cap);
                    # it stores the U7/U5 caches so the next start hits.
                    try:
                        # R30: once per distinct input (was once per session, so a
                        # Continue change after playback never got cached again).
                        if getattr(self, "_r29_continue_bg_sig", None) != _member_sig_u5:
                            self._r29_continue_bg_sig = _member_sig_u5
                            self._r29_continue_bg_t_r38 = time.monotonic()
                            _bg_rows_r29 = [tuple(x) for x in source_rows]

                            def _bg_membership_r29():
                                try:
                                    xbmc.sleep(4000)
                                    _t0_r29 = time.monotonic()
                                    _res_r29 = self._home_filter_continue_membership(
                                        _bg_rows_r29, publish_authority=False, uncapped_r29=True)
                                    _log("HOME_CONTINUE_BG_COMPLETE_R29 rows=%d elapsed_ms=%d cache_stored_for_next_start=1" % (
                                        len(_res_r29 or []), int((time.monotonic() - _t0_r29) * 1000)))
                                except Exception:
                                    _log("HOME_CONTINUE_BG_FAILED_R29 err=%s" % traceback.format_exc().replace(chr(10), " | "),
                                         xbmc.LOGWARNING)
                            _PKMHomeThreadV2151(target=_bg_membership_r29, name="PKMContinueBgR29", daemon=True).start()
                            _log("HOME_CONTINUE_BG_SCHEDULED_R29 delay_ms=4000")
                    except Exception:
                        pass
                    if publish_authority:
                        self._continue_membership_authority_rows = list(source_rows)
                        self._continue_membership_authority_updated_ms = int(time.time() * 1000)
                        self._continue_membership_progress_map = self._home_runtime_progress_map_v2499_build(source_rows)
                    return source_rows
                _log("HOME_CONTINUE_SQL_ERROR_U2 err=%s" % str(_u2_exc), xbmc.LOGWARNING)
            except Exception:
                _log(
                    "HOME_CONTINUE_MEMBERSHIP_DB_FAILED err=%s" %
                    traceback.format_exc().replace(chr(10), " | "),
                    xbmc.LOGWARNING,
                )
                db_rows = []
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass

            # The expensive SQL is complete. Persist its precise 24-column
            # rows only if no writer changed DB/WAL identity during this query.
            if (db_rows and len(db_rows) <= 10000 and _epoch_u7 is not None
                    and _epoch_u7 == _db_epoch_u7(_dbp_u7)
                    and _selected_sig_u7 and _cache_path_u7):
                try:
                    _payload_u7 = {'version': 8, 'query': _query_sig_u7,
                                   'epoch': _epoch_u7, 'rows': db_rows}
                    _raw_u7 = json.dumps(_payload_u7, ensure_ascii=False, separators=(',',':'))
                    if len(_raw_u7) <= 4000000 and _epoch_u7 == _db_epoch_u7(_dbp_u7):
                        _tmp_u7 = _cache_path_u7 + '.tmp'
                        with open(_tmp_u7, 'w', encoding='utf-8') as _fh_u7:
                            _fh_u7.write(_raw_u7)
                        os.replace(_tmp_u7, _cache_path_u7)
                        _log('HOME_CONTINUE_DB_ROWS_STORE_U7 rows=%d bytes=%d next_run_reuse=1' % (
                            len(db_rows), len(_raw_u7)))
                except Exception:
                    pass

        # Metadata grouped by logical show and logical episode.
        metadata_by_group = {}
        for raw in list(db_rows or []):
            row = tuple(raw or ())
            if len(row) < 24:
                continue
            show_title = str(row[18] or "").strip()
            normalized = pkm_media_versions.normalize_title(show_title) if show_title else ""
            key = "title:%s" % normalized if normalized else (
                "key:%s" % str(row[22] or "").strip() if str(row[22] or "").strip() else ""
            )
            if key not in tv_source_groups:
                continue
            metadata_by_group.setdefault(key, []).append(row)

        output = list(passthrough_movies)
        kept_tv = 0
        removed_complete = 0
        removed_no_resume = 0
        replaced_tv = 0

        # Preserve the original overall source order: one TV card per logical show.
        emitted_groups = set()
        ordered_tv = []
        for values in source_rows:
            if str(values[2] if len(values) > 2 else "").strip().lower() != "episode":
                continue
            key = _group_key_from_values(values)
            if key and key not in emitted_groups:
                emitted_groups.add(key)
                ordered_tv.append((key, values))

        kept_tv, rebuilt_tv_by_key, removed_complete, removed_no_resume, replaced_tv = self._home_filter_continue_membership_step1(_story_season, kept_tv, metadata_by_group, ordered_tv, removed_complete, removed_no_resume, replaced_tv, resume_by_rk)

        # R25: the episode query no longer reads raw_json for every episode.
        # Load it only for the rebuilt Continue cards (a handful of rows,
        # primary-key lookups).
        final_rows = self._home_filter_continue_membership_step2(_group_key_from_values, _member_sig_u5, _sig_parts_r25, db_rows, kept_tv, publish_authority, rebuilt_tv_by_key, removed_complete, removed_no_resume, replaced_tv, source_rows, started)
        return final_rows

    def _home_filter_continue_membership_step1(self, _story_season, kept_tv, metadata_by_group, ordered_tv, removed_complete, removed_no_resume, replaced_tv, resume_by_rk):
        """Step 1 of _home_filter_continue_membership (R76 split, moved verbatim). Logs: HOME_CONTINUE_MEMBERSHIP_KEEP, HOME_CONTINUE_MEMBERSHIP_REMOVE."""
        rebuilt_tv_by_key = {}
        for group_key, source_values in ordered_tv:
            physical_rows = list(metadata_by_group.get(group_key) or [])

            # Continue is a strict resume row even if library metadata is
            # temporarily unavailable. A watched card or a zero-progress onDeck
            # card must not survive merely because the metadata lookup missed.
            if not physical_rows:
                source_rk = str(source_values[0] if len(source_values) > 0 else "").strip()
                source_resume = resume_by_rk.get(source_rk)
                source_watched = _safe_int(
                    source_values[16] if len(source_values) > 16 else 0, 0
                ) > 0
                if source_resume and not source_watched:
                    rebuilt_tv_by_key[group_key] = source_values
                    kept_tv += 1
                    _log(
                        "HOME_CONTINUE_MEMBERSHIP_KEEP show=%s rating_key=%s reason=metadata_unavailable_active_resume pct=%d" % (
                            str(source_values[18] if len(source_values) > 18 else ""),
                            source_rk,
                            _safe_int(source_resume.get("pct"), 0),
                        )
                    )
                else:
                    removed_no_resume += 1
                    _log(
                        "HOME_CONTINUE_MEMBERSHIP_REMOVE show=%s rating_key=%s reason=metadata_unavailable_no_active_resume watched=%d" % (
                            str(source_values[18] if len(source_values) > 18 else ""),
                            source_rk,
                            1 if source_watched else 0,
                        )
                    )
                continue

            logical = {}
            by_rk = {}
            for row in physical_rows:
                rk = str(row[0] or "").strip()
                by_rk[rk] = row
                logical_key = (_story_season(row[19]), _safe_int(row[20], 0))
                state = logical.setdefault(logical_key, {"rows": [], "watched": False})
                state["rows"].append(row)
                if _safe_int(row[16], 0) > 0:
                    state["watched"] = True

            logical_total = len(logical)
            logical_watched = sum(1 for state in logical.values() if state.get("watched"))

            # Track each physical show/version separately as well.  A 1080p copy
            # can be fully watched while a parallel 2160p copy is untouched.
            # For user-facing "이어보기", one fully-watched version means the
            # logical show is complete and must not remain in Continue.
            version_states = {}
            for row in physical_rows:
                gp = str(row[22] or "").strip()
                if not gp:
                    continue
                episode_key = (_story_season(row[19]), _safe_int(row[20], 0))
                state = version_states.setdefault(gp, {})
                prior = state.get(episode_key, False)
                state[episode_key] = bool(prior or (_safe_int(row[16], 0) > 0))

            version_progress = {}
            any_version_complete = False
            for gp, episode_states in version_states.items():
                total_v = len(episode_states)
                watched_v = sum(1 for flag in episode_states.values() if flag)
                version_progress[gp] = (total_v, watched_v)
                if total_v > 0 and watched_v >= total_v:
                    any_version_complete = True

            if any_version_complete or (logical_total > 0 and logical_watched >= logical_total):
                removed_complete += 1
                _log(
                    "HOME_CONTINUE_MEMBERSHIP_REMOVE show=%s reason=show_complete logical=%d watched=%d complete_version=%d versions=%d route=rewatch" % (
                        str(source_values[18] if len(source_values) > 18 else ""),
                        logical_total,
                        logical_watched,
                        1 if any_version_complete else 0,
                        len(version_progress),
                    )
                )
                continue

            candidates = []
            for logical_key, state in logical.items():
                # A watched copy means this logical episode is complete even if
                # another resolution/copy reports unwatched or stale resume data.
                if state.get("watched"):
                    continue
                best_copy = None
                for row in state.get("rows") or []:
                    rk = str(row[0] or "").strip()
                    resume = resume_by_rk.get(rk)
                    if not resume:
                        continue
                    rec = {
                        "row": row,
                        "rk": rk,
                        "story_season": logical_key[0],
                        "episode": logical_key[1],
                        "resume": resume,
                    }
                    if best_copy is None or (
                        _safe_int(resume.get("stamp"), 0),
                        _safe_int(resume.get("offset_ms"), 0),
                        rk,
                    ) > (
                        _safe_int(best_copy["resume"].get("stamp"), 0),
                        _safe_int(best_copy["resume"].get("offset_ms"), 0),
                        str(best_copy.get("rk") or ""),
                    ):
                        best_copy = rec
                if best_copy is not None:
                    candidates.append(best_copy)

            if not candidates:
                # "이어보기" for TV is not limited to a half-played episode.
                # If at least one episode was finished and more remain, the show
                # is still being continued between episodes.  Keep it and show
                # SERIES completion progress; never show a check mark.
                partial_versions = []
                for gp, pair in version_progress.items():
                    total_v, watched_v = pair
                    if total_v > 0 and 0 < watched_v < total_v:
                        partial_versions.append((float(watched_v) / float(total_v), watched_v, total_v, gp))

                if not partial_versions:
                    removed_no_resume += 1
                    _log(
                        "HOME_CONTINUE_MEMBERSHIP_REMOVE show=%s reason=not_started_or_no_progress logical=%d watched=%d" % (
                            str(source_values[18] if len(source_values) > 18 else ""),
                            logical_total,
                            logical_watched,
                        )
                    )
                    continue

                partial_versions.sort(reverse=True)
                _ratio, watched_v, total_v, preferred_gp = partial_versions[0]
                preferred_rows = [
                    row for row in physical_rows
                    if str(row[22] or "").strip() == str(preferred_gp or "")
                ]
                preferred_rows.sort(
                    key=lambda row: (_story_season(row[19]), _safe_int(row[20], 0), str(row[0] or ""))
                )

                watched_keys = [
                    (_story_season(row[19]), _safe_int(row[20], 0))
                    for row in preferred_rows if _safe_int(row[16], 0) > 0
                ]
                highest_watched = max(watched_keys) if watched_keys else (-1, -1)
                next_rows = [
                    row for row in preferred_rows
                    if _safe_int(row[16], 0) <= 0
                    and (_story_season(row[19]), _safe_int(row[20], 0)) > highest_watched
                ]
                if not next_rows:
                    next_rows = [row for row in preferred_rows if _safe_int(row[16], 0) <= 0]
                if not next_rows:
                    removed_no_resume += 1
                    _log(
                        "HOME_CONTINUE_MEMBERSHIP_REMOVE show=%s reason=no_unwatched_representative watched=%d total=%d" % (
                            str(source_values[18] if len(source_values) > 18 else ""),
                            watched_v, total_v,
                        )
                    )
                    continue

                metadata = tuple(next_rows[0] or ())
                series_pct = int(max(1, min(99, round((float(watched_v) * 100.0) / float(total_v)))))
                rebuilt = list(metadata[:23])
                rebuilt.extend([
                    series_pct * 1000,   # synthetic progress pair for section ListItems
                    100000,
                    _safe_int(metadata[17] if len(metadata) > 17 else 0, 0),
                    "home_continue_series_progress",
                    metadata[23] if len(metadata) > 23 else "",
                ])
                if len(source_values) > 12 and str(source_values[12] or "").strip():
                    rebuilt[12] = source_values[12]
                if len(source_values) > 13 and str(source_values[13] or "").strip():
                    rebuilt[13] = source_values[13]
                rebuilt_tuple = tuple(rebuilt)
                rebuilt_tv_by_key[group_key] = rebuilt_tuple
                kept_tv += 1
                if str(source_values[0] if len(source_values) > 0 else "") != str(rebuilt_tuple[0]):
                    replaced_tv += 1
                _log(
                    "HOME_CONTINUE_MEMBERSHIP_KEEP show=%s source_rk=%s target_rk=%s season=%d episode=%d pct=%d watched=%d total=%d reason=series_progress" % (
                        str(rebuilt_tuple[18] if len(rebuilt_tuple) > 18 else ""),
                        str(source_values[0] if len(source_values) > 0 else ""),
                        str(rebuilt_tuple[0] if len(rebuilt_tuple) > 0 else ""),
                        _story_season(rebuilt_tuple[19] if len(rebuilt_tuple) > 19 else 0),
                        _safe_int(rebuilt_tuple[20] if len(rebuilt_tuple) > 20 else 0, 0),
                        series_pct, watched_v, total_v,
                    )
                )
                continue

            # User-facing priority: later season/episode first. Timestamp only
            # resolves multiple physical copies of the same logical episode.
            candidates.sort(
                key=lambda rec: (
                    _safe_int(rec.get("story_season"), 0),
                    _safe_int(rec.get("episode"), 0),
                    _safe_int((rec.get("resume") or {}).get("stamp"), 0),
                    _safe_int((rec.get("resume") or {}).get("offset_ms"), 0),
                ),
                reverse=True,
            )
            chosen = candidates[0]
            metadata = tuple(chosen.get("row") or ())
            resume = dict(chosen.get("resume") or {})

            # Rebuild the exact extended Home row shape:
            # metadata[0:23] + resume fields + raw_json.
            rebuilt = list(metadata[:23])
            rebuilt.extend([
                _safe_int(resume.get("offset_ms"), 0),
                _safe_int(resume.get("duration_ms"), 0),
                _safe_int(resume.get("stamp"), 0),
                "home_continue_active",
                metadata[23] if len(metadata) > 23 else "",
            ])
            # Continue cards use logical-show poster/fanart authority.
            if len(source_values) > 12 and str(source_values[12] or "").strip():
                rebuilt[12] = source_values[12]
            if len(source_values) > 13 and str(source_values[13] or "").strip():
                rebuilt[13] = source_values[13]

            rebuilt_tuple = tuple(rebuilt)
            rebuilt_tv_by_key[group_key] = rebuilt_tuple
            kept_tv += 1
            if str(source_values[0] if len(source_values) > 0 else "") != str(rebuilt_tuple[0]):
                replaced_tv += 1
            _log(
                "HOME_CONTINUE_MEMBERSHIP_KEEP show=%s source_rk=%s target_rk=%s season=%d episode=%d pct=%d logical=%d watched=%d reason=active_resume" % (
                    str(rebuilt_tuple[18] if len(rebuilt_tuple) > 18 else ""),
                    str(source_values[0] if len(source_values) > 0 else ""),
                    str(rebuilt_tuple[0] if len(rebuilt_tuple) > 0 else ""),
                    _safe_int(chosen.get("story_season"), 0),
                    _safe_int(chosen.get("episode"), 0),
                    _safe_int(resume.get("pct"), 0),
                    logical_total,
                    logical_watched,
                )
            )
        return kept_tv, rebuilt_tv_by_key, removed_complete, removed_no_resume, replaced_tv

    def _home_filter_continue_membership_step2(self, _group_key_from_values, _member_sig_u5, _sig_parts_r25, db_rows, kept_tv, publish_authority, rebuilt_tv_by_key, removed_complete, removed_no_resume, replaced_tv, source_rows, started):
        """Step 2 of _home_filter_continue_membership (R76 split, moved verbatim). Logs: HOME_CONTINUE_RAW_JSON_HYDRATE_R25, HOME_CONTINUE_RAW_JSON_HYDRATE_R25_FAILED, HOME_CONTINUE_MEMBERSHIP, CONTINUE_MEMBERSHIP_AUTHORITY_PUBLISH."""
        try:
            need_raw_r25 = {}
            for _gk_r25, _row_r25 in list(rebuilt_tv_by_key.items()):
                if len(_row_r25) > 27 and not str(_row_r25[27] or ""):
                    need_raw_r25.setdefault(str(_row_r25[0] or ""), []).append(_gk_r25)
            need_raw_r25.pop("", None)
            if need_raw_r25:
                _raw_t0_r25 = time.monotonic()
                _raw_db_r25 = self._profile_db_path()
                _raw_conn_r25 = sqlite3.connect(_raw_db_r25, timeout=0.25)
                try:
                    _rks_r25 = sorted(need_raw_r25)
                    _marks_r25 = ",".join("?" for _ in _rks_r25)
                    _found_r25 = dict(_raw_conn_r25.execute(
                        "SELECT rating_key, raw_json FROM items WHERE rating_key IN (%s)" % _marks_r25,
                        tuple(_rks_r25)
                    ).fetchall())
                finally:
                    _raw_conn_r25.close()
                for _rk_r25, _gks_r25 in need_raw_r25.items():
                    _raw_val_r25 = _found_r25.get(_rk_r25)
                    if not _raw_val_r25:
                        continue
                    for _gk_r25 in _gks_r25:
                        _lst_r25 = list(rebuilt_tv_by_key[_gk_r25])
                        _lst_r25[27] = _raw_val_r25
                        rebuilt_tv_by_key[_gk_r25] = tuple(_lst_r25)
                _log("HOME_CONTINUE_RAW_JSON_HYDRATE_R25 rows=%d found=%d elapsed_ms=%d" % (
                    len(need_raw_r25), len(_found_r25), int((time.monotonic() - _raw_t0_r25) * 1000)))
        except Exception:
            _log("HOME_CONTINUE_RAW_JSON_HYDRATE_R25_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "),
                 xbmc.LOGWARNING)

        # Recreate the original ordering while replacing all physical episode
        # duplicates with one authoritative logical-show card.
        final_rows = []
        emitted_tv = set()
        for values in source_rows:
            plex_type = str(values[2] if len(values) > 2 else "").strip().lower()
            if plex_type != "episode":
                final_rows.append(values)
                continue
            key = _group_key_from_values(values)
            if not key or key in emitted_tv:
                continue
            emitted_tv.add(key)
            replacement = rebuilt_tv_by_key.get(key)
            if replacement is not None:
                final_rows.append(replacement)

        if _member_sig_u5 and db_rows:
            self._continue_membership_cache_store_u5(_member_sig_u5, db_rows, final_rows, _sig_parts_r25)
        _log(
            "HOME_CONTINUE_MEMBERSHIP result=done source=%d final=%d tv_kept=%d replaced=%d removed_complete=%d removed_no_resume=%d db_rows=%d elapsed_ms=%d network=0" % (
                len(source_rows),
                len(final_rows),
                kept_tv,
                replaced_tv,
                removed_complete,
                removed_no_resume,
                len(db_rows),
                _pkm_speed_ms() - started,
            )
        )
        if publish_authority:
            try:
                self._continue_membership_authority_rows = list(final_rows or [])
                self._continue_membership_authority_updated_ms = int(time.time() * 1000)
                # Build once for the exact final Continue rows. Section
                # Recommendation reuses this same map; no second policy exists.
                self._continue_membership_progress_map = self._home_runtime_progress_map_v2499_build(
                    self._continue_membership_authority_rows
                )
                _log(
                    "CONTINUE_MEMBERSHIP_AUTHORITY_PUBLISH rows=%d progress_shows=%d source=home_current_membership" % (
                        len(self._continue_membership_authority_rows),
                        len(self._continue_membership_progress_map or {}),
                    )
                )
            except Exception:
                pass
        return final_rows

    def _show_home_wall(self, force=False):
        _prev_active_v1555, _sync_reentry_hold_v1555, home_dirty, home_source_mode_v2479, wall = self._show_home_wall_step1(force)

        if not force and self._home_wall_ready and self._home_rows_cache is not None:
            # Home can be restored from the rendered/session cache before the
            # Continue query below runs. Validate only the cached Continue row
            # membership first; if it changed, skip the early reuse and let the
            # normal off-screen Home rebuild publish the corrected row.
            try:
                cached_continue_rows = []
                for cached_entry in list(self._home_rows_cache or []):
                    if not isinstance(cached_entry, dict):
                        continue
                    if str(cached_entry.get("row_type") or "").strip().lower() != "continue":
                        continue
                    cached_row = cached_entry.get("row")
                    if cached_row is not None:
                        cached_continue_rows.append(tuple(cached_row or ()))

                if cached_continue_rows:
                    validated_continue_rows = self._home_filter_continue_membership(
                        cached_continue_rows
                    )

                    def _continue_signature(values):
                        values = tuple(values or ())
                        return (
                            str(values[0] if len(values) > 0 else ""),
                            str(values[2] if len(values) > 2 else ""),
                            str(values[18] if len(values) > 18 else ""),
                            _safe_int(values[19] if len(values) > 19 else 0, 0),
                            _safe_int(values[20] if len(values) > 20 else 0, 0),
                            _safe_int(values[23] if len(values) > 23 else 0, 0),
                            _safe_int(values[24] if len(values) > 24 else 0, 0),
                            str(values[26] if len(values) > 26 else ""),
                        )

                    cached_signatures = [
                        _continue_signature(row) for row in cached_continue_rows
                    ]
                    validated_signatures = [
                        _continue_signature(row) for row in list(validated_continue_rows or [])
                    ]

                    # R55: every Home ENTER was rejected here (same 24 rows, but
                    # the validator re-attaches resume offset/duration/source
                    # fields, so the full signature never matched) -> full Home
                    # rebuild (~1.9s on Shield) instead of reusing the rendered
                    # rows.  Membership/order is what decides reuse; progress
                    # after playback is handled by the post-stop refresh path
                    # (PLAYSTATE_HOME_REFRESH_CONSUME clears this cache).
                    def _membership_r55(values):
                        values = tuple(values or ())
                        return (str(values[0] if len(values) > 0 else ""), str(values[2] if len(values) > 2 else ""))
                    cached_members_r55 = [_membership_r55(r) for r in cached_continue_rows]
                    validated_members_r55 = [_membership_r55(r) for r in list(validated_continue_rows or [])]
                    if cached_signatures != validated_signatures and cached_members_r55 == validated_members_r55:
                        try:
                            for _i_r55, (_a_r55, _b_r55) in enumerate(zip(cached_signatures, validated_signatures)):
                                if _a_r55 != _b_r55:
                                    _log("HOME_CONTINUE_CACHE_RESUME_FIELDS_DIFF_R55 idx=%d cached=%s validated=%s action=reuse_membership_same" % (
                                        _i_r55, str(_a_r55)[:160], str(_b_r55)[:160]))
                                    break
                        except Exception:
                            pass
                        cached_signatures = validated_signatures
                    if cached_signatures != validated_signatures:
                        _log(
                            "HOME_CONTINUE_CACHE_REJECT cached=%d validated=%d reason=membership_or_resume_changed" % (
                                len(cached_continue_rows),
                                len(validated_continue_rows or []),
                            )
                        )
                        # Do not clear/delete any cache file and do not blank the
                        # current UI. We only prevent the stale rendered rows from
                        # winning this Home entry; the normal replacement build
                        # below commits atomically when ready.
                        self._home_wall_ready = False
                    else:
                        _log(
                            "HOME_CONTINUE_CACHE_ACCEPT rows=%d reason=membership_current" %
                            len(cached_continue_rows)
                        )
            except Exception:
                _log(
                    "HOME_CONTINUE_CACHE_VALIDATE_FAILED err=%s" %
                    traceback.format_exc().replace(chr(10), " | "),
                    xbmc.LOGWARNING,
                )

        if not force and self._home_wall_ready and self._home_rows_cache is not None:
            # v004: Home rows are already rendered in dedicated XML controls
            # (9410~9450).  Library recommendation rows use separate controls,
            # so returning to Home from the sidebar does not require rebuilding
            # 20 Home rows / hundreds of ListItems.  Reuse the existing controls
            # first; only repaint from cache when the controls were actually
            # cleared or the window has just been created.
            if self._home_reuse_rendered_xml_rows(reason="HOME_MENU_REENTRY_REUSE"):
                try:
                    self._set_home_plex_pending_v1476(False, reason="home_reentry_reuse_rows_ready")
                except Exception:
                    pass
                if self._home_target_hidden_v2479:
                    self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_reentry_reuse")
                self._release_widget_stack_transition_later(reason="home_reentry_reuse_rows_ready", delay_ms=15)
                return
            self.wall_total = len(self._home_rows_cache)
            first_title = "홈"
            try:
                if self._home_rows_cache:
                    first = self._home_rows_cache[0]
                    if isinstance(first, dict):
                        first_title = first.get("row_title") or first_title
            except Exception:
                pass
            self._set_header("홈", first_title)
            if wall.size() == self.wall_total and self.wall_total > 0:
                self._sync_wall_first_key("home_already_rendered")
                self._set_home_meta_from_item(reason="home_already_rendered")
                try:
                    self._set_home_plex_pending_v1476(False, reason="home_already_rendered_rows_ready")
                except Exception:
                    pass
                if self._startup_full_compose_required_v1643():
                    self._mark_startup_full_scene_composed_v1643(reason="home_already_rendered_v1643")
                    self._schedule_startup_atomic_release_v1619(reason="home_already_rendered_v1643")
                if self._home_target_hidden_v2479:
                    self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_already_rendered")
                _log("HOME_APPEND_SKIPPED reason=already_rendered added=%d" % self.wall_total)
                return
            try:
                self._home_progressive_generation_v1642 += 1
                _gen_restore_v1642 = self._home_progressive_generation_v1642
                _wr_restore_v1642 = xbmcgui.Window(10000)
                _wr_restore_v1642.setProperty("PlexKM.Home.ProgressiveModeV1642", "1")
                _wr_restore_v1642.clearProperty("PlexKM.Home.ProgressiveReadyV1642")
                self.clearProperty("PlexKM.Home.ProgressiveReadyV1642")
                if (not self._startup_full_compose_required_v1643()) and self._home_render_fast_first_paint(self._home_rows_cache, reason="HOME_CACHE_FIRST_COMMIT_V1642"):
                    self._start_home_watcha_preload_async_v1642(reason="home_cache_restore")
                    self._home_progressive_fill_v1642(self._home_rows_cache, _gen_restore_v1642)
                    try:
                        self._set_home_plex_pending_v1476(False, reason="home_cache_first_commit_v1642")
                    except Exception:
                        pass
                    if self._home_target_hidden_v2479:
                        self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_cache_progressive")
                    _log("HOME_CACHE_RESTORE_PROGRESSIVE_V1642 rows=%d no_full_reset=1" % len(self._home_rows_cache or []))
                    return
            except Exception:
                _log("HOME_CACHE_RESTORE_PROGRESSIVE_FAILED_V1642 fallback=full err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            _cache_rendered_v1643 = self._home_render_xml_rows(self._home_rows_cache, reason="HOME_CACHE_RESTORE_FALLBACK")
            try:
                self._set_home_plex_pending_v1476(False, reason="home_cache_restore_rows_ready")
            except Exception:
                pass
            if _cache_rendered_v1643 and self._startup_full_compose_required_v1643():
                self._mark_startup_full_scene_composed_v1643(reason="home_cache_restore_full_v1643")
                self._schedule_startup_atomic_release_v1619(reason="home_cache_restore_full_v1643")
            if _cache_rendered_v1643 and self._home_target_hidden_v2479:
                self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_cache_fallback")
            self._release_widget_stack_transition_later(reason="home_cache_restore_rows_ready", delay_ms=20)
            return

        # v608: Build the replacement Home rows first and clear/render XML row
        # controls only after we know the rebuilt data is non-empty.  The startup
        # Plex sync can briefly update the local DB/cache while Home is already
        # visible; if Home rebuild starts during that window, clearing 9410~9600
        # before the DB query completes can leave the screen with metadata only
        # and no poster widgets.  This is data-safe only; no playback/focus flow
        # is changed.
        added = 0
        rows_cache = []
        # v945: first-paint hero meta/fanart as soon as the first Home row is known,
        # before all off-screen rows and rating preloads are built.
        home_initial_meta_prepainted = False
        added, continue_rows, home_columns = self._show_home_wall_step2(added, force, home_initial_meta_prepainted, rows_cache)

        if added <= 0:
            # v608: Preserve the currently visible Home widgets when a rebuild
            # returns empty.  Empty Home is not a valid steady state when the
            # sidebar has sections; it usually means DB/cache is transiently busy
            # during Plex startup sync or a query failed.  Keep previous rows
            # instead of resetting 9410~9600 and leaving only metadata.
            if self._home_rendered_xml_rows_ready():
                self.wall_total = len(self._home_rows_cache or [])
                self.wall_offset = self.wall_total
                try:
                    self._set_home_plex_pending_v1476(False, reason="home_empty_preserve_existing_widgets")
                except Exception:
                    pass
                if self._home_target_hidden_v2479:
                    self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_empty_preserve_existing")
                _log("HOME_REBUILD_EMPTY_PRESERVE reason=home rows_cached=%d sections=%d continue=%d action=keep_existing_widgets" % (self.wall_total, len(self.sections or []), len(continue_rows or [])), xbmc.LOGWARNING)
                return
            if self._home_rows_cache:
                try:
                    self._home_render_xml_rows(self._home_rows_cache, reason="HOME_EMPTY_RESTORE_CACHE")
                    self.wall_total = len(self._home_rows_cache or [])
                    self.wall_offset = self.wall_total
                    try:
                        self._set_home_plex_pending_v1476(False, reason="home_empty_restore_cache")
                    except Exception:
                        pass
                    if self._home_target_hidden_v2479:
                        self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_empty_restore_cache")
                    _log("HOME_REBUILD_EMPTY_RESTORE_CACHE reason=home rows_cached=%d sections=%d continue=%d" % (self.wall_total, len(self.sections or []), len(continue_rows or [])), xbmc.LOGWARNING)
                    return
                except Exception:
                    _log("HOME_REBUILD_EMPTY_RESTORE_CACHE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            self._home_target_hidden_v2479 = False
            _log("HOME_REBUILD_EMPTY_NO_CACHE reason=home sections=%d continue=%d" % (len(self.sections or []), len(continue_rows or [])), xbmc.LOGWARNING)
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1":
                    self._set_home_plex_offline_confirmed_v1477(True, reason="home_rebuild_empty_no_cache_offline")
            except Exception:
                pass

        try:
            if added > 0:
                self._set_home_plex_pending_v1476(False, reason="home_rows_built")
                self._set_home_plex_offline_confirmed_v1477(False, reason="home_rows_built")
        except Exception:
            pass

        # v1642: initial Home uses one visible commit followed by append-only
        # completion.  Never reset those first rows after they become visible.
        if added > 0 and (not force) and (not self._home_wall_ready) and (not self._startup_full_compose_required_v1643()):
            try:
                self._home_progressive_generation_v1642 += 1
                _gen1642 = self._home_progressive_generation_v1642
                _w1642 = xbmcgui.Window(10000)
                _w1642.setProperty("PlexKM.Home.ProgressiveModeV1642", "1")
                _w1642.clearProperty("PlexKM.Home.ProgressiveReadyV1642")
                self.clearProperty("PlexKM.Home.ProgressiveReadyV1642")
                if self._home_render_fast_first_paint(rows_cache, reason="HOME_FIRST_COMMIT_V1642"):
                    if self._home_target_hidden_v2479:
                        self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_first_commit_progressive")
                    self._start_home_watcha_preload_async_v1642(reason="home_first_commit")
                    self._home_progressive_fill_v1642(rows_cache, _gen1642)
                    _log("HOME_FIRST_COMMIT_DONE_V1642 visible_rows=2 source_rows=%d no_second_reset=1" % len(rows_cache or []))
                    return
            except Exception:
                self._home_first_paint_critical_v1642 = False
                _log("HOME_FIRST_COMMIT_FAILED_V1642 fallback=full_render err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        self._show_home_wall_step3(_prev_active_v1555, _sync_reentry_hold_v1555, added, continue_rows, home_dirty, home_source_mode_v2479, rows_cache, wall)
        _log("HOME_APPEND_XML_ROWS reason=home added=%d sections=%d continue=%d columns=%d row_item_limit=%d" % (added, len(self.sections or []), len(continue_rows or []), home_columns, HOME_ROW_ITEM_LIMIT))
        _log("PKM_PATCH_ACTIVE v1291 widget_anchor_stable no_widget_slide")
        _log("PKM_PATCH_ACTIVE v1292 widget_transition_atomic no_title_overlap")
        _log("PKM_PATCH_ACTIVE v1293 sidebar_focus_no_widget_anchor_scroll")
        _log("PKM_PATCH_ACTIVE v1294 sidebar_preview_freeze_recent_added_stable")
        _log("PKM_PATCH_ACTIVE v1295 sidebar_preview_updates_anchor_guarded")
        _log("PKM_PATCH_ACTIVE v1296 sidebar_direct_preview_no_ab_swap")
        _log("PKM_PATCH_ACTIVE v1305 sidebar_placeholder_exact_slots_no_ab_no_push")
        _log("PKM_PATCH_ACTIVE v1315 sidebar_cached_posters_no_placeholder_fast_reveal")
        _log("PKM_PATCH_ACTIVE v1318 section_recommend_home_viewport_clip_no_tab_overlap")
        _log("PKM_PATCH_ACTIVE v1485 section_wall_16x9_top136_poster240x360_item280_row495_no_sort_ellipsis")

    def _show_home_wall_step1(self, force):
        """Step 1 of _show_home_wall (R76 split, moved verbatim). Logs: HOME_TARGET_FIRST_STAGE_V2479, PLAYSTATE_HOME_REFRESH_BOOTSTRAP_DEFER_V1632, PLAYSTATE_HOME_REFRESH_CONSUME_V1632, HOME_SOURCE_MODE_RETAIN_V2479."""
        self._library_native_owner_section_v2070 = ""
        # R61: remember the just-stopped item before the v1632 consume branch
        # below clears the post-stop properties.
        try:
            _w_r61 = xbmcgui.Window(10000)
            self._post_stop_key_r61 = (
                _w_r61.getProperty("PlexKM.Playback.LocalResumeRatingKeyV2575")
                or _w_r61.getProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632")
                or ""
            )
        except Exception:
            self._post_stop_key_r61 = ""
        home_source_mode_v2479 = self._pkm_surface_mode_v2479()
        self._home_target_hidden_v2479 = bool(home_source_mode_v2479 != "home")
        # R55: every Home commit path (incl. the rendered-rows reuse) clears the
        # Library wall 9100 at the commit frame, never before (R54 rule).
        self._home_wall_reset_pending_r54 = bool(self._home_target_hidden_v2479)
        if self._home_target_hidden_v2479:
            _log("HOME_TARGET_FIRST_STAGE_V2479 source=%s force=%d source_held=1 home_visible=0" % (
                home_source_mode_v2479, 1 if force else 0
            ))
        # v1632: playback stop refreshes only Continue Watching and is queued
        # during navigation. Consume it exactly once here, when Home is naturally
        # shown. Replacement rows are built before XML reset, so a section remains
        # visible until the completed Home stack is committed.
        try:
            win_v1632 = xbmcgui.Window(10000)
            bootstrap_v1632 = bool(getattr(self, "_home_bootstrap_in_progress_v1632", False))
            playstate_home_pending_v1632 = bool(
                self._playstate_home_refresh_pending_v1632
                or win_v1632.getProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632") == "1"
            )
            if playstate_home_pending_v1632 and bootstrap_v1632:
                _log("PLAYSTATE_HOME_REFRESH_BOOTSTRAP_DEFER_V1632 action=restore_cached_home pending=1 consume=later_natural_home_entry")
            elif playstate_home_pending_v1632:
                self._playstate_home_refresh_pending_v1632 = False
                win_v1632.clearProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632")
                win_v1632.clearProperty("PlexKM.Playback.PostStopHomeRefreshTokenV1632")
                win_v1632.clearProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632")
                self._home_rows_cache = None
                self._home_wall_ready = False
                _log("PLAYSTATE_HOME_REFRESH_CONSUME_V1632 action=natural_home_entry current_scene_kept_until_rows_ready=1")
        except Exception:
            bootstrap_v1632 = False
            playstate_home_pending_v1632 = False
        # v1555: when a committed sync is being consumed from another visible
        # content stack, keep that old stack visible until replacement Home rows
        # are fully populated.  This is the hidden/re-entry equivalent of the
        # live Home previous-row cover and prevents a blank widget frame.
        try:
            _prev_active_v1555 = str(getattr(self, "active_section_id", "") or "")
            _sync_reentry_hold_v1555 = bool(
                _prev_active_v1555 != "__home__"
                and (self._sync_widget_refresh_pending_v1555() or (playstate_home_pending_v1632 and not bootstrap_v1632))
            )
        except Exception:
            _prev_active_v1555 = ""
            _sync_reentry_hold_v1555 = False
        try:
            self._section_placeholder_clear_v1305(reason="show_home_wall")
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Window.HomeLayout", "1")
            self.setProperty("PlexKM.Window.HomeLayout", "1")
            if not _sync_reentry_hold_v1555 and not self._home_target_hidden_v2479:
                xbmcgui.Window(10000).clearProperty("PlexKM.Window.IsSectionRecommend")
                xbmcgui.Window(10000).clearProperty("PlexKM.Window.IsSectionWall")
                xbmcgui.Window(10000).clearProperty("PlexKM.Window.IsSectionCategory")
                self.clearProperty("PlexKM.Window.IsSectionRecommend")
                self.clearProperty("PlexKM.Window.IsSectionWall")
                self.clearProperty("PlexKM.Window.IsSectionCategory")
            elif self._home_target_hidden_v2479:
                _log("HOME_SOURCE_MODE_RETAIN_V2479 source=%s reason=target_not_ready" % home_source_mode_v2479)
            else:
                _log("SYNC_WIDGET_REFRESH_REENTRY_HOLD_SHOW_OLD_STACK_V1555 previous=%s" % _prev_active_v1555)
        except Exception:
            pass
        if bootstrap_v1632 and self._session_cache_restored_v1632 and self._home_rows_cache:
            home_dirty = False
            _log("PLEX_UPDATE_HOME_BOOTSTRAP_DEFER_V1632 action=restore_session_cache dirty_consumption=next_natural_home_entry rows=%d" % len(self._home_rows_cache or []))
        else:
            home_dirty = self._consume_plex_update_home_dirty(reason="show_home_wall", force=force)
        if home_dirty:
            _log("PLEX_UPDATE_REUSE_BLOCKED scope=home reason=dirty")
        self.active_section_id = "__home__"
        self._last_rendered_section_id = "__home__"
        self._reset_wall_cursor("show_home_wall")
        self._append_guard = set()
        wall = self.getControl(WALL_ID)
        try:
            self._maybe_show_home_plex_pending_v1476(reason="show_home_wall_before_first_query")
        except Exception:
            pass
        return _prev_active_v1555, _sync_reentry_hold_v1555, home_dirty, home_source_mode_v2479, wall

    def _show_home_wall_step2(self, added, force, home_initial_meta_prepainted, rows_cache):
        """Step 2 of _show_home_wall (R76 split, moved verbatim). Logs: HOME_CONTINUE_MEMBERSHIP_FAILED, HOME_CONTINUE_SKIP_DUP_TITLE, HOME_CONTINUE_SKIP_DUP_SHOW, HOME_RECENT_EXCLUDE_CONTINUE_KEYS."""
        try:
            home_columns = max(1, int(self._wall_column_count()))
        except Exception:
            home_columns = 6

        # 1) Plex Home first row: Continue Watching, only when PMS has resume/on-deck items.
        #    Display only one visual row, but collect a wider set of resume keys.
        #
        #    v226 important rule:
        #    - Continue Watching == playback/resume state.
        #    - Recent Added rows == Plex library/file addedAt only.
        #    A resumed movie/episode must never leak into any "최근 <라이브러리>에 추가됨"
        #    row, across all libraries.  Therefore we collect more than the visible
        #    Continue row and use that key set only while building Home, before any
        #    ListItem is added.  No post-render reset/filter is used, so poster focus,
        #    LEFT navigation, playback, and cast/meta prewarm remain unchanged.
        continue_limit = HOME_ROW_ITEM_LIMIT
        continue_key_limit = max(120, continue_limit)
        try:
            # Use the service-startup Continue Watching preload for normal Home entry.
            # Playback-stop dirty refreshes pass force=True and bypass the preload so
            # just-finished progress still reflects immediately.
            # R61: playback-stop refreshes (force=True) used to bypass the
            # snapshot and call Plex /library/onDeck on the GUI thread (8 s
            # timeout; it timed out on SHIELD right after Stop and the Info
            # Back took 8 s, then showed a 1-row 이어보기).  The stop already
            # wrote the local resume sidecar, so build from the snapshot +
            # sidecar and refresh the snapshot in the background.
            if force:
                continue_all_rows = core.query_continue_watching_wall_light(
                    limit=continue_key_limit, prefer_preload=True,
                    post_stop_local_r61=(getattr(self, "_post_stop_key_r61", "") or "1"))
            else:
                continue_all_rows = core.query_continue_watching_wall_light(limit=continue_key_limit, prefer_preload=True)
        except Exception:
            continue_all_rows = []
        try:
            continue_all_rows = self._home_filter_continue_membership(continue_all_rows, publish_authority=True)
        except Exception:
            _log(
                "HOME_CONTINUE_MEMBERSHIP_FAILED err=%s" %
                traceback.format_exc().replace(chr(10), " | "),
                xbmc.LOGWARNING,
            )
        continue_rating_keys = set()
        continue_show_keys = set()
        try:
            for row in list(continue_all_rows or []):
                t = tuple(row or ())
                rk = str((t[0] if len(t) > 0 else "") or "")
                if rk:
                    continue_rating_keys.add(rk)
                if str(t[2] if len(t) > 2 else "") == "episode":
                    gp = str((t[22] if len(t) > 22 else "") or "").strip()
                    if gp:
                        continue_show_keys.add(gp)
                    show_title_key = pkm_media_versions.normalize_title(t[18] if len(t) > 18 else "")
                    if show_title_key:
                        continue_show_keys.add("title:%s" % show_title_key)
        except Exception:
            pass
        try:
            # Continue Watching is a show/movie poster row.  Plex can return
            # multiple episodes from the same drama; Home should show one poster
            # per drama, using the newest row from the already-sorted source.
            continue_rows = []
            seen_continue_movies = set()
            seen_continue_shows = set()
            for row in list(continue_all_rows or []):
                t = tuple(row or ())
                plex_type = str(t[2] if len(t) > 2 else "")
                title = str(t[4] if len(t) > 4 else "").strip()
                year = str(t[7] if len(t) > 7 else "").strip()
                if plex_type == "movie" and title:
                    dedup_key = ("movie", " ".join(title.lower().split()), year)
                    if dedup_key in seen_continue_movies:
                        try:
                            rk = str(t[0] if len(t) > 0 else "")
                            _log("HOME_CONTINUE_SKIP_DUP_TITLE rating_key=%s title=%s year=%s" % (rk, title, year))
                        except Exception:
                            pass
                        continue
                    seen_continue_movies.add(dedup_key)
                elif plex_type == "episode":
                    # v2114: Continue Watching is a logical-show card. Different
                    # Plex libraries/encodes may have different grandparent keys,
                    # so prefer the normalized show title across libraries.
                    show_title = str(t[18] if len(t) > 18 else "").strip()
                    show_key = "title:%s" % pkm_media_versions.normalize_title(show_title) if show_title else str((t[22] if len(t) > 22 else "") or "").strip()
                    if show_key:
                        if show_key in seen_continue_shows:
                            try:
                                rk = str(t[0] if len(t) > 0 else "")
                                _log("HOME_CONTINUE_SKIP_DUP_SHOW rating_key=%s show_key=%s title=%s" % (rk, show_key, title))
                            except Exception:
                                pass
                            continue
                        seen_continue_shows.add(show_key)
                continue_rows.append(row)
                if len(continue_rows) >= continue_limit:
                    break
        except Exception:
            continue_rows = []
        if continue_rating_keys:
            _log("HOME_RECENT_EXCLUDE_CONTINUE_KEYS count=%d visible=%d limit=%d" % (len(continue_rating_keys), len(continue_rows or []), continue_key_limit))
        try:
            _poster_ready_v2497 = 0
            _poster_missing_v2497 = 0
            for _row_v2497 in list(continue_rows or []):
                _t_v2497 = tuple(_row_v2497 or ())
                _type_v2497 = str(_t_v2497[2] if len(_t_v2497) > 2 else "").strip().lower()
                if _type_v2497 in ("movie", "episode", "show"):
                    if str(_t_v2497[12] if len(_t_v2497) > 12 else "").strip():
                        _poster_ready_v2497 += 1
                    else:
                        _poster_missing_v2497 += 1
            _log("HOME_CONTINUE_POSTER_ACCEPTANCE_V2497 result=%s rows=%d poster_ready=%d missing=%d landscape_art_as_poster=0" % (
                "PASS" if _poster_missing_v2497 == 0 else "FAIL", len(continue_rows or []),
                _poster_ready_v2497, _poster_missing_v2497
            ), xbmc.LOGINFO if _poster_missing_v2497 == 0 else xbmc.LOGWARNING)
        except Exception:
            _log("HOME_CONTINUE_POSTER_ACCEPTANCE_V2497 result=FAIL reason=diagnostic_exception landscape_art_as_poster=0", xbmc.LOGWARNING)
        _log("HOME_POSTER_ROLE_POLICY_ACTIVE_V2498 continue=poster_only generic_cards_no_art_fallback=1")
        if continue_rows:
            for idx, row in enumerate(continue_rows):
                entry = {"row_title": "이어보기", "row_type": "continue", "row_first": idx == 0, "row_id": "home:continue", "row_start": added - idx, "row_index": idx, "row": row}
                rows_cache.append(entry)
                if not home_initial_meta_prepainted:
                    home_initial_meta_prepainted = self._prepaint_home_meta_from_row(row, row_title="이어보기", row_type="continue", reason="home_continue_first_row")
                # v091: Home items are rendered into XML row lists after rows_cache is complete.
                added += 1


        # v1642: data composition stays off-screen, then the two visible rows
        # are committed once.  The remaining rows are appended later without a
        # second reset, so fast first paint no longer causes a blink.
        try:
            if (not force) and (not self._home_wall_ready):
                _startup_progress_v1845(55, reason="home_first_rows_ready")
                _log("HOME_FIRST_PAINT_PLAN_V1642 mode=two_phase_no_reset rows_partial=%d" % len(rows_cache or []))
        except Exception:
            pass

        # 2) Plex Home recent rows: every Plex library/menu section in sidebar order.
        #    Recent means real Plex library/file addedAt. Playback/resume state is
        #    excluded globally via continue_rating_keys before rows are rendered.
        #    Do not hardcode section ids or names.  When the user adds/removes a Plex
        #    library, Home follows the sidebar automatically.
        for section in self.sections:
            sid = str(section.get("section_id", ""))
            title = _display_library_title(section.get("title", "") or sid)
            row_title = self._home_row_title_for_section(title)
            try:
                # Fetch a little extra so excluding Continue Watching duplicates
                # still leaves a full visual row when possible.
                rows = core.query_items_wall_light(sid, sort="added", limit=max(HOME_ROW_ITEM_LIMIT * 2, HOME_ROW_ITEM_LIMIT + 6), offset=0, plex_type=None)
            except Exception:
                rows = []
            if not rows:
                continue
            visible_rows = []
            seen_recent_logical_v2114 = set()
            for row in rows:
                try:
                    rk = str((tuple(row or ())[0]) or "")
                except Exception:
                    rk = ""
                if rk and rk in continue_rating_keys:
                    _log("HOME_RECENT_SKIP_CONTINUE_DUP section=%s rating_key=%s row_title=%s" % (sid, rk, row_title))
                    continue
                try:
                    t_recent = tuple(row or ())
                    gp_recent = str((t_recent[22] if len(t_recent) > 22 else "") or "").strip()
                    show_title_recent = pkm_media_versions.normalize_title(t_recent[18] if len(t_recent) > 18 else "")
                    show_title_recent_key = "title:%s" % show_title_recent if show_title_recent else ""
                    if ((gp_recent and gp_recent in continue_show_keys) or
                            (show_title_recent_key and show_title_recent_key in continue_show_keys)):
                        _log("HOME_RECENT_SKIP_CONTINUE_SHOW_DUP section=%s show_key=%s rating_key=%s row_title=%s" % (sid, show_title_recent_key or gp_recent, rk, row_title))
                        continue
                except Exception:
                    pass
                try:
                    t_logic = tuple(row or ())
                    typ_logic = str(t_logic[2] if len(t_logic) > 2 else "").strip().lower()
                    raw_logic = t_logic[27] if len(t_logic) > 27 else ""
                    # v2261: TV must be grouped by parent SHOW before inspecting
                    # the episode GUID. Every episode has its own Plex GUID, so the
                    # old GUID-first order defeated the v2259 show de-dup entirely.
                    if typ_logic in ("episode", "show"):
                        show_visual_key_v2261 = self._tv_visual_dedup_key_from_row(row)
                        if show_visual_key_v2261:
                            logical_key_v2114 = ("tvshow", show_visual_key_v2261)
                        else:
                            logical_key_v2114 = (
                                "tvshow",
                                str(t_logic[22] if len(t_logic) > 22 else "")
                                or pkm_media_versions.normalize_title(t_logic[18] if len(t_logic) > 18 else "")
                                or str(t_logic[0] if len(t_logic) > 0 else "")
                            )
                    else:
                        guid_logic = pkm_media_versions.raw_guid(raw_logic)
                        if guid_logic:
                            logical_key_v2114 = (typ_logic, "guid", guid_logic)
                        elif typ_logic == "movie":
                            logical_key_v2114 = (
                                "movie",
                                pkm_media_versions.normalize_title(t_logic[4] if len(t_logic) > 4 else ""),
                                str(t_logic[7] if len(t_logic) > 7 else "")
                            )
                        else:
                            logical_key_v2114 = (typ_logic, str(t_logic[0] if len(t_logic) > 0 else ""))
                    if logical_key_v2114 in seen_recent_logical_v2114:
                        if typ_logic in ("episode", "show"):
                            _log("HOME_RECENT_SKIP_DUP_SHOW_V2261 section=%s rating_key=%s logical=%s" % (sid, rk, logical_key_v2114))
                        else:
                            _log("HOME_RECENT_SKIP_MEDIA_VERSION_DUP_V2114 section=%s rating_key=%s logical=%s" % (sid, rk, logical_key_v2114))
                        continue
                    seen_recent_logical_v2114.add(logical_key_v2114)
                except Exception:
                    pass
                visible_rows.append(row)
                if len(visible_rows) >= HOME_ROW_ITEM_LIMIT:
                    break
            if not visible_rows:
                continue
            for idx, row in enumerate(visible_rows):
                row_id = "home:recent:%s" % sid
                entry = {"row_title": row_title, "row_type": "recent", "section_id": sid, "row_first": idx == 0, "row_id": row_id, "row_start": added - idx, "row_index": idx, "row": row}
                rows_cache.append(entry)
                if not home_initial_meta_prepainted:
                    home_initial_meta_prepainted = self._prepaint_home_meta_from_row(row, row_title=row_title, row_type="recent", reason="home_recent_first_row")
                # v091: Home items are rendered into XML row lists after rows_cache is complete.
                added += 1
        return added, continue_rows, home_columns

    def _show_home_wall_step3(self, _prev_active_v1555, _sync_reentry_hold_v1555, added, continue_rows, home_dirty, home_source_mode_v2479, rows_cache, wall):
        """Step 3 of _show_home_wall (R76 split, moved verbatim). Logs: UHD3_STARTUP_DECORATION_PRELOAD_BYPASS_V2583, R110_STARTUP_WATCHA_BULK_DEFERRED, STARTUP_CURRENT_HOME_PRELOAD_FAILED_V1643, HOME_WALL_RESET_DEFER_R54."""
        if added > 0 and self._startup_full_compose_required_v1643():
            try:
                _startup_progress_v1845(65, reason="home_full_preload_begin")
                _startup_local_first_v2583 = bool(
                    getattr(self, "_startup_established_current_home_only_v2535", False)
                    and xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                )
                if _startup_local_first_v2583:
                    # V2583: ratings/Watcha are decoration, not a reveal barrier.
                    # Exact values are restored from persistent render snapshots
                    # when present; misses are allowed to fill after Home opens.
                    _log("UHD3_STARTUP_DECORATION_PRELOAD_BYPASS_V2583 rows=%d watcha_bulk=0 ratings_bulk=0 canonical_bulk=0" % len(rows_cache or []))
                else:
                    # R110: rating bulk preload is decoration, not an atomic Home
                    # readiness requirement. Individual rating lookups still work;
                    # do not read ~10k DB rows on the foreground startup path.
                    _log("R110_STARTUP_WATCHA_BULK_DEFERRED rows=%d reason=noncritical_rating_decoration" % len(rows_cache or []))
            except Exception:
                _log("STARTUP_CURRENT_HOME_PRELOAD_FAILED_V1643 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        # R54: while the previous scene (Library wall 9100) is still the visible
        # source (target-first stage), clearing 9100 here blanked the screen for
        # the whole Home build (field video 50s: 11.7s -> 14.35s empty).  Defer the
        # reset to the atomic Home commit, the same frame the wall is retired.
        if bool(getattr(self, "_home_target_hidden_v2479", False)):
            self._home_wall_reset_pending_r54 = True
            _log("HOME_WALL_RESET_DEFER_R54 reason=source_visible_until_home_commit")
        else:
            self._home_wall_reset_pending_r54 = False
            try:
                wall.reset()
            except Exception:
                pass
        self._sync_wall_first_key("home_append")
        self._home_rows_cache = rows_cache
        self._home_wall_ready = True
        self.wall_total = added
        self.wall_offset = added
        try:
            first_row_title = _display_library_title(rows_cache[0].get("row_title") if rows_cache else "홈")
        except Exception:
            first_row_title = "홈"
        if not _sync_reentry_hold_v1555:
            self._set_header("홈", _display_library_title(first_row_title))
        home_xml_render_ok_v1555 = False
        try:
            rendered_home_items_v1555 = self._home_render_xml_rows(rows_cache, reason="HOME_APPEND")
            home_xml_render_ok_v1555 = bool(rendered_home_items_v1555 > 0)
            if home_xml_render_ok_v1555 and self._home_target_hidden_v2479:
                self._home_atomic_commit_v2479(home_source_mode_v2479, reason="home_full_rows_ready")
            if _sync_reentry_hold_v1555 and home_xml_render_ok_v1555:
                # Make completed Home rows visible first, then retire the old
                # section/wall stack.  Overlap is harmless; a blank frame is not.
                self._set_header("홈", _display_library_title(first_row_title))
                try:
                    _w_v1555 = xbmcgui.Window(10000)
                    _w_v1555.clearProperty("PlexKM.Window.IsSectionRecommend")
                    _w_v1555.clearProperty("PlexKM.Window.IsSectionWall")
                    self.clearProperty("PlexKM.Window.IsSectionRecommend")
                    self.clearProperty("PlexKM.Window.IsSectionWall")
                except Exception:
                    pass
                _log("SYNC_WIDGET_REFRESH_REENTRY_COMMIT_HOME_V1555 previous=%s rows=%d no_blank_frame=1" % (
                    _prev_active_v1555, rendered_home_items_v1555
                ))
            self._release_widget_stack_transition_later(reason="home_append_rows_ready", delay_ms=20)
        except Exception:
            _log("HOME_XML_RENDER_AFTER_BUILD_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        # v1555: pending sync is acknowledged only after the replacement Home
        # controls contain committed-DB rows.  When Home was hidden, this is the
        # no-blink re-entry path; when Home was visible, the old-row overlay was
        # covering the reset/add sequence.
        try:
            if home_dirty and home_xml_render_ok_v1555:
                mode_v1555 = "atomic_visible_cover" if self.getProperty("PlexKM.HomeRefreshPrevVisibleV1555") == "1" else "hidden_home_reentry"
                self._sync_widget_refresh_ack_v1555(reason="show_home_wall", mode=mode_v1555)
        except Exception:
            _log("SYNC_WIDGET_REFRESH_ACK_AFTER_HOME_RENDER_FAILED_V1555 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            _wready1642 = xbmcgui.Window(10000)
            _wready1642.setProperty("PlexKM.Home.InitialWidgetsReady", "1")
            _wready1642.setProperty("PlexKM.Home.InitialWidgetsReadyAt", str(int(time.time() * 1000)))
            _wready1642.setProperty("PlexKM.Home.ProgressiveModeV1642", "0")
            _wready1642.setProperty("PlexKM.Home.ProgressiveReadyV1642", "1")
            self.setProperty("PlexKM.Home.InitialWidgetsReady", "1")
            self.setProperty("PlexKM.Home.ProgressiveReadyV1642", "1")
        except Exception:
            pass
        if self._startup_full_compose_required_v1643():
            # v1986: an intentionally empty Home is a complete startup surface,
            # not a render failure.  This is the canonical state after an initial
            # library sync is canceled/failed and no library has been atomically
            # activated.  The sidebar (Home / Plex KM settings / Kodi settings)
            # is already populated, so zero widget rows must release the real
            # startup barrier instead of holding the logo forever.
            empty_home_complete_v1986 = bool(
                (not home_xml_render_ok_v1555)
                and int(added or 0) == 0
                and len(self.sections or []) == 0
                and len(continue_rows or []) == 0
            )
            if home_xml_render_ok_v1555 or empty_home_complete_v1986:
                compose_reason_v1986 = "home_empty_complete_v1986" if empty_home_complete_v1986 else "home_full_rows_ready"
                self._mark_startup_full_scene_composed_v1643(reason=compose_reason_v1986)
                self._schedule_startup_atomic_release_v1619(reason=compose_reason_v1986)
                if empty_home_complete_v1986:
                    _log("STARTUP_EMPTY_HOME_COMPLETE_V1986 active_sections=0 rows=0 continue=0 release=real_progress_100_hold300 focus_owner=xml_menu9000")
            else:
                _log("STARTUP_CURRENT_HOME_FULL_RENDER_FAILED_V1643 action=keep_splash_until_real_scene_complete", xbmc.LOGWARNING)
        else:
            self._schedule_startup_atomic_release_v1619(reason="home_full_rows_ready")

    def _query_library_wall_rows_v1870(self, section_id, sort="title", sort_dir=None,
                                        limit=0, offset=0, random_seed=None,
                                        genre=None):
        """Use the V2626 full sort matrix index, with the old core path only as a one-time miss fallback."""
        sid = str(section_id or "").strip()
        is_tv_v2626 = self._is_tv_library_section_v1870(sid)
        try:
            if is_tv_v2626:
                rows_v2626 = pkm_sort_index_v2626.query_tv(
                    sid, sort, sort_dir, limit, offset, genre=genre, random_seed=random_seed
                )
            else:
                rows_v2626 = pkm_sort_index_v2626.query_movie(
                    sid, sort, sort_dir, limit, offset, genre=genre, random_seed=random_seed
                )
            if rows_v2626 is not None:
                _log("LIBRARY_SORT_MATRIX_ROUTE_V2626 section=%s media=%s sort=%s dir=%s source=v2626 rows=%d limit=%s offset=%s genre=%s" % (
                    sid, "tv" if is_tv_v2626 else "movie", sort or "", sort_dir or "", len(rows_v2626 or []), limit, offset, genre or ""
                ))
                return rows_v2626 or []
        except Exception:
            _log("LIBRARY_SORT_MATRIX_ROUTE_FAILED_V2626 section=%s media=%s sort=%s err=%s action=core_fallback" % (
                sid, "tv" if is_tv_v2626 else "movie", sort or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        _fallback_t0_v2626 = time.perf_counter()
        if is_tv_v2626:
            query = getattr(_ensure_core(), "query_tv_shows_wall_light", None)
            if callable(query):
                rows = query(
                    sid, sort=sort, sort_dir=sort_dir,
                    limit=limit, offset=offset,
                    random_seed=random_seed, genre=genre,
                )
                _log("SORT_MATRIX_QUERY_V2626 media=tv section=%s sort=%s dir=%s source=core_fallback index_ready=0 rows=%d query_ms=%.1f" % (
                    sid, sort or "", sort_dir or "", len(rows or []), (time.perf_counter()-_fallback_t0_v2626)*1000.0
                ))
                _log("TV_LIBRARY_WALL_ROUTE_V1911 section=%s mode=shows sort=%s dir=%s limit=%s offset=%s genre=%s rows=%d" % (
                    sid, sort or "", sort_dir or "", limit, offset, genre or "", len(rows or [])
                ))
                return rows or []
        rows = _ensure_core().query_items_wall_light(
            sid, sort=sort, sort_dir=sort_dir,
            limit=limit, offset=offset, plex_type=None,
            random_seed=random_seed, genre=genre,
        )
        _log("SORT_MATRIX_QUERY_V2626 media=movie section=%s sort=%s dir=%s source=core_fallback index_ready=0 rows=%d query_ms=%.1f" % (
            sid, sort or "", sort_dir or "", len(rows or []), (time.perf_counter()-_fallback_t0_v2626)*1000.0
        ))
        return rows

    def _query_library_wall_total_v1870(self, section_id, genre=None):
        """Return show count for TV; None means use the movie section total."""
        sid = str(section_id or "").strip()
        if not self._is_tv_library_section_v1870(sid):
            return None
        query = getattr(_ensure_core(), "query_tv_shows_count", None)
        if not callable(query):
            return None
        try:
            count = int(query(sid, genre=genre) or 0)
            _log("TV_LIBRARY_TOTAL_ROUTE_V1911 section=%s genre=%s shows=%d" % (
                sid, genre or "", count
            ))
            return count
        except Exception:
            _log("TV_LIBRARY_TOTAL_ROUTE_FAILED_V1870 section=%s genre=%s err=%s" % (
                sid, genre or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return None

    def _build_movie_extra_rows_cache_from_index(self, sid, title, home_columns, added_start):
        """Build the four movie extra rows from local recommendation index DB.

        v224 policy:
        - taste Korean / foreign: current section only, rating + random.
        - director / actor: random person from the full movie pool, at least 10 works when possible.
        - no Plex HTTP calls during widget construction.
        """
        speed_start = _pkm_speed_ms()
        extra_rows_cache = []
        added = int(added_start or 0)
        sid = str(sid or "").strip()
        exclude = set()
        try:
            if not hasattr(core, "query_recommend_index_rows"):
                _speed_log("movie_extra_index_unavailable", section=sid, reason="no_core_api")
                return None
            row_limit = max(10, min(HOME_ROW_ITEM_LIMIT, max(int(home_columns or 5) * 2, 10)))
            rating_min = float(self._movie_extra_score_threshold())
            _speed_log("movie_extra_index_strategy", section=sid, title=title, row_limit=row_limit, rating_min=rating_min, policy="v227_db_index_main_actor_fast_no_metadata", nonce=getattr(self, "_movie_extra_random_nonce", ""), metadata_fetch=0)
            _speed_log("movie_extra_widget_build_begin", section=sid, title=title, source="db_local", expected_widgets=4, min_rows=10, metadata_fetch=0)

            q0 = _pkm_speed_ms()
            rows = core.query_recommend_index_rows(sid, kind="korean", limit=row_limit, exclude_keys=list(exclude), min_score=rating_min, min_person_items=10)
            q_ms = _pkm_speed_ms() - q0
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, "취향 한국영화", rows, sid, added)
            _tot,_thumbs,_arts = self._recommend_db_row_art_stats(rows)
            _speed_log("movie_extra_index_row_append", section=sid, type="taste_korean", title="취향 한국영화", rows=len(rows or []), added_delta=added-before, min_rows=10, query_ms=q_ms, source="db_local", result="ok" if len(rows or []) >= 10 else "short", thumb_ready=_thumbs, art_ready=_arts, metadata_fetch=0)
            for r in rows or []:
                try:
                    exclude.add(str(tuple(r)[0] or ""))
                except Exception:
                    pass

            q0 = _pkm_speed_ms()
            rows = core.query_recommend_index_rows(sid, kind="foreign", limit=row_limit, exclude_keys=list(exclude), min_score=rating_min, min_person_items=10)
            q_ms = _pkm_speed_ms() - q0
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, "취향 외국영화", rows, sid, added)
            _tot,_thumbs,_arts = self._recommend_db_row_art_stats(rows)
            _speed_log("movie_extra_index_row_append", section=sid, type="taste_foreign", title="취향 외국영화", rows=len(rows or []), added_delta=added-before, min_rows=10, query_ms=q_ms, source="db_local", result="ok" if len(rows or []) >= 10 else "short", thumb_ready=_thumbs, art_ready=_arts, metadata_fetch=0)
            for r in rows or []:
                try:
                    exclude.add(str(tuple(r)[0] or ""))
                except Exception:
                    pass

            q0 = _pkm_speed_ms()
            rows = core.query_recommend_index_rows(sid, kind="director", limit=row_limit, exclude_keys=list(exclude), min_score=None, min_person_items=10)
            q_ms = _pkm_speed_ms() - q0
            director_name = self._movie_extra_person_name_from_db_rows(rows)
            director_title = "%s 감독작" % director_name if director_name else "감독작"
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, director_title, rows, sid, added)
            _tot,_thumbs,_arts = self._recommend_db_row_art_stats(rows)
            _speed_log("movie_extra_index_row_append", section=sid, type="director", title=director_title, person=director_name, rows=len(rows or []), added_delta=added-before, min_rows=10, query_ms=q_ms, source="db_local", result="ok" if len(rows or []) >= 10 else "short", thumb_ready=_thumbs, art_ready=_arts, metadata_fetch=0)
            for r in rows or []:
                try:
                    exclude.add(str(tuple(r)[0] or ""))
                except Exception:
                    pass

            q0 = _pkm_speed_ms()
            rows = core.query_recommend_index_rows(sid, kind="actor", limit=row_limit, exclude_keys=list(exclude), min_score=None, min_person_items=10)
            q_ms = _pkm_speed_ms() - q0
            actor_name = self._movie_extra_person_name_from_db_rows(rows)
            actor_title = "%s 출연작" % actor_name if actor_name else "배우작"
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, actor_title, rows, sid, added)
            _tot,_thumbs,_arts = self._recommend_db_row_art_stats(rows)
            _speed_log("movie_extra_index_row_append", section=sid, type="actor", title=actor_title, person=actor_name, rows=len(rows or []), added_delta=added-before, min_rows=10, query_ms=q_ms, source="db_local", result="ok" if len(rows or []) >= 10 else "short", thumb_ready=_thumbs, art_ready=_arts, actor_main_only=1, actor_order_range="1-3", metadata_fetch=0)

            total_items = 0
            try:
                total_items = sum([len(x.get("items", []) or []) for x in (extra_rows_cache or []) if isinstance(x, dict)])
            except Exception:
                total_items = 0
            _speed_log("movie_extra_index_rows_build_end", section=sid, title=title, rows=len(extra_rows_cache or []), items=total_items, total_ms=_pkm_speed_ms()-speed_start, result="ok", source="db_local", policy="v227_db_index_main_actor_fast_no_metadata", metadata_fetch=0, target_total_ms=1000)
            return extra_rows_cache
        except Exception:
            _log("MOVIE_EXTRA_INDEX_ROWS_BUILD_FAILED section=%s\n%s" % (sid, traceback.format_exc()), xbmc.LOGWARNING)
            _speed_log("movie_extra_index_rows_build_end", section=sid, title=title, rows=len(extra_rows_cache or []), total_ms=_pkm_speed_ms()-speed_start, result="error")
            return None


    def _library_wall_viewport_count_v1865(self):
        """Return only the cards that can actually be seen before first DOWN.

        V2588 used a 12-card (6x2) PC viewport.  The UHD field video shows the
        1080p Android layout exposing one six-card row while Kodi spends seconds
        decoding posters that were already present as local files.  V2593 therefore
        verifies only the visible six cards on Android; desktop keeps the proven
        12-card contract.
        """
        return 6 if self._uhd_kpi_proxy_v2605() else 12

    def _library_wall_initial_bound_count_v2077(self):
        """Keep a native runway large enough to absorb remote-key bursts.

        V2600 Android binds 30 lightweight cards but still validates only the
        visible six posters before publish.  The extra four rows are local/native
        runway so ControlList rebinds do not have to occur on every DOWN burst.
        Desktop retains the proven 18-card bind.
        """
        if self._uhd_kpi_proxy_v2605():
            _log("UHD3_LIBRARY_NATIVE_BIND_BUDGET_V2712 bound=18 visible=6 previous_bound=30 append_postvisible=1")
            return 18
        return 18

    def _library_wall_low_watermark_rows_v2077(self):
        """Refill early enough that native DOWN never reaches a hard edge.

        v2609: UHD/Android requests the next local-DB chunk with four native
        rows still in hand.  This moves query work away from the physical edge
        without changing Kodi's focus owner or adding foreground Plex work.
        """
        return 4 if self._uhd_kpi_proxy_v2605() else 6

    def _library_wall_prefetch_count_v2077(self):
        """Prepare a bounded local-DB runway ahead of UHD scrolling."""
        return 36 if self._uhd_kpi_proxy_v2605() else 48

    def _library_wall_append_count_v1932(self):
        """V2593: Android publishes two rows per rebind; desktop keeps four."""
        if self._uhd_kpi_proxy_v2605():
            return 12
        return max(12, int(getattr(self, "batch", 24) or 24))

    def _library_wall_render_settle_v1865(self, reason="", item_count=0):
        """Allow two GUI frames after binding already-decoded viewport textures.

        Kodi does not expose per-ControlImage decode completion to Python. v2147
        therefore publishes only already-complete local image files and lets Kodi
        own final scaling/cropping. This remains only a two-frame GUI handoff; it
        is not treated as a fabricated texture-readiness test.
        """
        started = _pkm_speed_ms()
        frames = 0
        while frames < 2 and not self._closing_event_v1841.is_set():
            xbmc.sleep(16)
            frames += 1
        _log("LIBRARY_VIEWPORT_GUI_HANDOFF_V1866 reason=%s items=%d frames=%d wait_ms=%d python_image_processing=0 kodi_geometry_owner=1" % (
            reason or "", int(item_count or 0), frames, _pkm_speed_ms() - started
        ))

    def _library_append_prefetch_key_v2070(self, owner=None, offset=None):
        owner = tuple(owner if owner is not None else (getattr(self, "_library_wall_owner_v2069", ()) or ()))
        off = int(self.wall_offset if offset is None else offset)
        return (owner, off)

    # PKM_PATCH_ACTIVE v2581 uhd3_wall_rapid_scroll_input_priority
    def _wall_rapid_scroll_mark_v2581(self, action_id=0):
        """Track a short wall key burst without sleeping or touching selection.

        Two DOWN/PAGEDOWN actions inside 550 ms arm a 900 ms quiet window.
        While armed, Home-only visual/prewarm work is suppressed and artwork
        prefetch uses the tiny latest-target queue below. The property is also
        visible to diagnostics/background helpers without retaining GUI objects.
        """
        try:
            now = int(_pkm_speed_ms())
            prev = int(getattr(self, "_wall_rapid_last_key_ms_v2581", 0) or 0)
            self._wall_rapid_last_key_ms_v2581 = now
            already = now < int(getattr(self, "_wall_rapid_until_ms_v2581", 0) or 0)
            burst = bool(already or (prev > 0 and (now - prev) <= 550))
            if burst:
                self._wall_rapid_until_ms_v2581 = now + 900
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.WallRapidScrollV2581", "1")
                    self.setProperty("PlexKM.WallRapidScrollV2581", "1")
                except Exception:
                    pass
            return burst
        except Exception:
            return False

    def _wall_rapid_scroll_active_v2581(self):
        try:
            now = int(_pkm_speed_ms())
            active = now < int(getattr(self, "_wall_rapid_until_ms_v2581", 0) or 0)
            if not active:
                try:
                    xbmcgui.Window(10000).clearProperty("PlexKM.WallRapidScrollV2581")
                    self.clearProperty("PlexKM.WallRapidScrollV2581")
                except Exception:
                    pass
            return bool(active)
        except Exception:
            return False

    # PKM_PATCH_ACTIVE v2579 uhd3_wall_append_poster_ahead_focus_stability
    def _library_row_poster_sources_v2579(self, row):
        """Return portrait poster authority URLs from a raw Library row only.

        This helper deliberately avoids xbmcgui.ListItem creation so it is safe to
        run in the local-DB prefetch worker before the next 24 native wall items are
        published.  It mirrors the portrait authority used by _li_from_row closely
        enough for cache warming: movie/show use thumb; season prefers the season
        ratingKey poster; episode prefers the show poster.
        """
        try:
            t = tuple(row or ())
            if len(t) < 13:
                return tuple()
            rating_key = str(t[0] or "").strip()
            plex_type = str(t[2] or "").strip().lower()
            thumb = str(t[12] or "").strip()
            parent_key = str(t[21] or "").strip() if len(t) > 21 else ""
            grandparent_key = str(t[22] or "").strip() if len(t) > 22 else ""
            values = []

            def _add(value):
                value = str(value or "").strip()
                if not value:
                    return
                try:
                    normalized = _plex_art(value, width=720, height=1080) or value
                except Exception:
                    normalized = value
                normalized = str(normalized or "").strip()
                if normalized and normalized not in values:
                    values.append(normalized)

            if plex_type == "season" and parent_key and ":season:" not in parent_key:
                _add("/library/metadata/%s/thumb" % parent_key)
                _add(thumb)
            elif plex_type == "episode" and grandparent_key:
                _add("/library/metadata/%s/thumb" % grandparent_key)
                _add(thumb)
            else:
                _add(thumb)
                if not values and rating_key:
                    _add("/library/metadata/%s/thumb" % rating_key)
            return tuple(values)
        except Exception:
            return tuple()

    # PKM_PATCH_ACTIVE v2580 wall_append_canonical_small_cache_nonblocking
    def _library_row_poster_canonical_v2580(self, row):
        """Return the exact 240x360 Plex-small URL used by the poster worker/cache.

        V2579 queued source-authority URLs but the worker canonicalized them to the
        shared 240x360 transcode URL before downloading.  The readiness gate then
        hashed the *source* URL, so a successfully downloaded small poster still
        looked missing forever.  V2580 makes queue, readiness and append binding
        use this one canonical cache key.
        """
        try:
            t = tuple(row or ())
            rk = str(t[0] or "").strip() if t else ""
            sources = self._library_row_poster_sources_v2579(row)
            if not sources and not rk:
                return ""
            return str(self._viewport_poster_url_v1937(sources, rating_key=rk) or "").strip()
        except Exception:
            return ""

    def _library_row_poster_local_v2580(self, row):
        """Return a verified local canonical small poster without network I/O."""
        try:
            canonical = self._library_row_poster_canonical_v2580(row)
            if not canonical:
                return ""
            local = self._wall_poster_local_path_v1644(canonical)
            if local and self._local_portrait_poster_file_ready_v2498(local):
                return local
        except Exception:
            pass
        return ""

    def _library_rapid_poster_spinner_finish_v2593(self, reason=""):
        try:
            token = str(getattr(self, "_library_rapid_poster_spinner_token_v2593", "") or "")
            self._library_rapid_poster_spinner_token_v2593 = ""
            if token:
                self._scene_busy_finish_v2482(token, reason="library_rapid_poster_v2593:%s" % (reason or ""))
                _log("LIBRARY_RAPID_POSTER_SPINNER_FINISH_V2593 section=%s token=%s reason=%s" % (
                    str(getattr(self, "active_section_id", "") or ""), token, reason or ""
                ))
            return bool(token)
        except Exception:
            return False

    def _peek_library_append_prefetch_v2579(self):
        try:
            key = self._library_append_prefetch_key_v2070()
            with self._library_append_prefetch_lock_v2070:
                rows = self._library_append_prefetch_rows_v2070.get(key)
                return None if rows is None else list(rows)
        except Exception:
            return None

    def _start_library_deep_prefetch_v2622(self, owner, start_offset, pages=2, reason=""):
        """Keep TV data + poster identity two 48-row pages ahead off the GUI thread."""
        try:
            owner = tuple(owner or ())
            if not owner or len(owner) < 5:
                return False
            sid, sort_key, sort_dir, genre, generation = owner[:5]
            sid = str(sid or "")
            if not sid or not self._is_tv_library_section_v1870(sid):
                return False
            if sid != str(getattr(self, "active_section_id", "") or ""):
                return False
            start_offset = max(0, int(start_offset or 0))
            pages = max(1, min(2, int(pages or 2)))
            # One deep query chain per active wall owner. Multiple overlapping
            # aggregate queries would hurt the weak U+ CPU/SQLite path more than
            # they help runway depth.
            active_key = owner
            with self._library_deep_prefetch_lock_v2622:
                if active_key in self._library_deep_prefetch_active_v2622:
                    return True
                self._library_deep_prefetch_active_v2622.add(active_key)
            limit = int(self._library_wall_prefetch_count_v2077())
            random_seed = getattr(self, "_wall_random_seed_v1644", None)
            closing = self._closing_event_v1841

            def _worker_v2622():
                off = start_offset
                try:
                    for distance in range(1, pages + 1):
                        if closing.is_set() or tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()) != owner:
                            return
                        key = self._library_append_prefetch_key_v2070(owner, off)
                        with self._library_append_prefetch_lock_v2070:
                            cached = self._library_append_prefetch_rows_v2070.get(key)
                            if cached is not None:
                                step = len(cached) or limit
                                off += step
                                continue
                            if key in self._library_append_prefetch_inflight_v2070:
                                off += limit
                                continue
                            self._library_append_prefetch_inflight_v2070.add(key)
                        rows_v2622 = []
                        q0 = time.perf_counter()
                        try:
                            rows_v2622 = list(self._query_library_wall_rows_v1870(
                                sid, sort=sort_key, sort_dir=sort_dir, limit=limit, offset=off,
                                random_seed=random_seed, genre=(genre or None)
                            ) or [])
                            if closing.is_set() or tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()) != owner:
                                return
                            with self._library_append_prefetch_lock_v2070:
                                self._library_append_prefetch_rows_v2070[key] = rows_v2622
                            queued = self._queue_library_texture_runway_v2621(
                                rows_v2622, owner, off, reason="tv_deep_runway_v2622",
                                distance_pages_v2622=distance
                            )
                            _log("LIBRARY_TV_DEEP_RUNWAY_READY_V2622 section=%s offset=%d rows=%d distance=%d query_ms=%.1f poster_queued=%d navigation_gate=0" % (
                                sid, off, len(rows_v2622), distance, (time.perf_counter()-q0)*1000.0, int(queued or 0)
                            ))
                        finally:
                            with self._library_append_prefetch_lock_v2070:
                                self._library_append_prefetch_inflight_v2070.discard(key)
                        if not rows_v2622:
                            break
                        off += len(rows_v2622)
                except Exception:
                    _log("LIBRARY_TV_DEEP_RUNWAY_FAILED_V2622 section=%s offset=%d err=%s" % (
                        sid, start_offset, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    with self._library_deep_prefetch_lock_v2622:
                        self._library_deep_prefetch_active_v2622.discard(active_key)

            _PKMHomeThreadV2151(target=_worker_v2622, name="PKMTVDeepRunwayV2622", daemon=True).start()
            _log("LIBRARY_TV_DEEP_RUNWAY_ARM_V2622 section=%s start_offset=%d pages=%d reason=%s" % (
                sid, start_offset, pages, reason or ""
            ))
            return True
        except Exception:
            return False

    def _start_library_append_prefetch_v2070(self, reason=""):
        """Query the next append chunk off the GUI thread; never touches Kodi controls."""
        try:
            owner = tuple(getattr(self, "_library_wall_owner_v2069", ()) or ())
            if not owner or len(owner) < 5:
                return False
            sid, sort_key, sort_dir, genre, _generation = owner[:5]
            offset = int(getattr(self, "wall_offset", 0) or 0)
            total = int(getattr(self, "wall_total", 0) or 0)
            if total and offset >= total:
                return False
            key = self._library_append_prefetch_key_v2070(owner, offset)
            cached_v2622 = None
            with self._library_append_prefetch_lock_v2070:
                if key in self._library_append_prefetch_rows_v2070:
                    cached_v2622 = list(self._library_append_prefetch_rows_v2070.get(key) or [])
                elif key in self._library_append_prefetch_inflight_v2070:
                    return True
                else:
                    self._library_append_prefetch_inflight_v2070.add(key)
            if cached_v2622 is not None:
                if cached_v2622 and self._is_tv_library_section_v1870(sid):
                    # V2623: a 24-row reserve can become the current append source
                    # without re-entering the DB worker. V2622 skipped poster
                    # reprioritization on this cached path, leaving those cards as
                    # old AHEAD/BACKGROUND work. Re-arm them as the current deadline
                    # window immediately; no DB query and no foreground wait.
                    queued_cached_v2623 = self._queue_library_texture_runway_v2621(
                        cached_v2622, owner, offset, reason="cached_current_v2623", distance_pages_v2622=0
                    )
                    _log("LIBRARY_TV_CACHED_RUNWAY_REARM_V2623 section=%s offset=%d rows=%d queued=%d db_query=0 foreground_wait=0" % (
                        sid, offset, len(cached_v2622), int(queued_cached_v2623 or 0)
                    ))
                    self._start_library_deep_prefetch_v2622(
                        owner, offset + len(cached_v2622), pages=2, reason="cached_current_v2622:%s" % (reason or "")
                    )
                return True
            limit = int(self._library_wall_prefetch_count_v2077())
            random_seed = getattr(self, "_wall_random_seed_v1644", None)
            closing = self._closing_event_v1841

            def _worker():
                rows = None
                try:
                    if closing.is_set():
                        return
                    # V2602 UHD: a pending wall runway query must not wake SQLite
                    # while Info/Actor owns the foreground. The request remains
                    # logically pending and will be armed again by the wall path
                    # after Back; no hidden 1s append query competes with Info.
                    if self._uhd_kpi_proxy_v2605():
                        try:
                            _fg_win_v2602 = xbmcgui.Window(10000)
                            _info_active_v2602 = (_fg_win_v2602.getProperty("PlexKM.Info.InlineActive") == "1")
                            _actor_active_v2602 = (_fg_win_v2602.getProperty("PlexKM.ActorProfile.Active") == "1")
                        except Exception:
                            _info_active_v2602 = False
                            _actor_active_v2602 = False
                        if _info_active_v2602 or _actor_active_v2602:
                            _log("LIBRARY_APPEND_PREFETCH_FOREGROUND_SUPPRESS_V2605 section=%s offset=%d info=%d actor=%d query=0 proxy=%d" % (
                                sid, offset, 1 if _info_active_v2602 else 0, 1 if _actor_active_v2602 else 0,
                                0 if self._is_android_v2591() else 1
                            ))
                            return
                    try:
                        _fgk_win_v2605 = xbmcgui.Window(10000)
                        _fgk_proxy_v2605 = (_fgk_win_v2605.getProperty("PlexKM.Diag.KPIProxyV2605") == "1")
                        _fgk_info_v2605 = (_fgk_win_v2605.getProperty("PlexKM.Info.InlineActive") == "1")
                        _fgk_actor_v2605 = (_fgk_win_v2605.getProperty("PlexKM.ActorProfile.Active") == "1")
                        if _fgk_proxy_v2605 and (_fgk_info_v2605 or _fgk_actor_v2605):
                            _fgk_win_v2605.setProperty("PlexKM.KPI.AppendFgViolationStamp", str(self._now_ms()))
                            _log("LIBRARY_APPEND_FOREGROUND_QUERY_VIOLATION_V2605 section=%s offset=%d info=%d actor=%d" % (
                                sid, offset, 1 if _fgk_info_v2605 else 0, 1 if _fgk_actor_v2605 else 0
                            ), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    rows = list(self._query_library_wall_rows_v1870(
                        sid, sort=sort_key, sort_dir=sort_dir, limit=limit, offset=offset,
                        random_seed=random_seed, genre=(genre or None)
                    ) or [])
                    if closing.is_set():
                        return
                    if tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()) != owner:
                        _log("LIBRARY_APPEND_PREFETCH_STALE_V2070 section=%s offset=%d reason=%s" % (sid, offset, reason or ""))
                        return
                    # V2620 desktop continuous-DOWN runway: raw local-DB rows are
                    # publishable immediately.  The first V2619 progress request spent
                    # ~0.8 s warming Cine21/Watcha before setting READY, so a user could
                    # reach the 18-card edge while the next 48 rows were already queried
                    # but artificially withheld.  Navigation owns readiness; presentation
                    # ratings warm afterwards on this background worker.
                    # R55: warm 왓챠/씨네21 sort-line text off the GUI thread.
                    if str(sort_key or "").strip().lower() in ("watcha", "cine21") and rows:
                        try:
                            getattr(_ensure_core(), "wall_provider_display_for_keys_r55")(
                                sid, str(sort_key).strip().lower(), [str(tuple(r or ())[0]) for r in rows if r])
                        except Exception:
                            pass
                    with self._library_append_prefetch_lock_v2070:
                        self._library_append_prefetch_rows_v2070[key] = rows
                    _log("LIBRARY_APPEND_PREFETCH_READY_EARLY_V2620 section=%s offset=%d rows=%d generation=%s rating_gate_ms=0 reason=%s" % (
                        sid, offset, len(rows), owner[-1], reason or ""))
                    # V2621: navigation remains READY immediately, but future
                    # posters now get a real local runway.  This is background-only:
                    # no append/key callback waits for Textures13 or network.
                    queued_texture_v2621 = self._queue_library_texture_runway_v2621(
                        rows, owner, offset, reason="append_prefetch_v2621"
                    )
                    _log("LIBRARY_APPEND_POSTER_RUNWAY_V2621 section=%s offset=%d rows=%d queued=%d android=%d foreground_wait_ms=0" % (
                        sid, offset, len(rows), int(queued_texture_v2621 or 0), 1 if self._is_android_v2591() else 0
                    ))
                    if rows and self._is_tv_library_section_v1870(sid):
                        self._start_library_deep_prefetch_v2622(
                            owner, offset + len(rows), pages=2, reason="after_current_ready_v2622:%s" % (reason or "")
                        )
                    _log("LIBRARY_APPEND_PREFETCH_READY_V2070 section=%s offset=%d rows=%d generation=%s reason=%s" % (
                        sid, offset, len(rows), owner[-1], reason or ""))
                    # R51: the user may already be parked on the last loaded row
                    # (field log: rows ready 10:36:42.5, but published only on the
                    # next key at 10:36:47.8).  Post one GUI-thread runway check
                    # now; it keeps the existing edge/idle rebind policy.
                    try:
                        if (rows and bool(getattr(self, "_library_append_request_v2070", False))
                                and self._is_android_v2591()
                                and tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()) == owner):
                            self._library_append_ready_post_r52 = True
                            self._schedule_library_append_commit_v2600(from_ready_r51=True)
                            _log("LIBRARY_APPEND_READY_POST_R51 section=%s offset=%d rows=%d" % (sid, offset, len(rows)))
                    except Exception:
                        pass

                    # Full rating content is not removed.  Warm it only after the
                    # runway has become consumable, and serialize the cold bulk warm
                    # so multiple 48-row prefetch workers cannot duplicate the same
                    # expensive Watcha/Cine21 initialization.
                    if (not self._is_android_v2591()) and str(sort_key or "").strip().lower() == "progress" and rows:
                        do_rating_warm_v2620 = False
                        with self._library_append_prefetch_lock_v2070:
                            if not bool(getattr(self, "_pc_progress_rating_warm_inflight_v2620", False)):
                                self._pc_progress_rating_warm_inflight_v2620 = True
                                do_rating_warm_v2620 = True
                        if do_rating_warm_v2620:
                            rating_started_v2620 = time.time()
                            try:
                                try:
                                    self._preload_visible_row_ratings(rows, reason="append_prefetch_v2620_progress_postready")
                                except Exception:
                                    pass
                                try:
                                    for rr_v2620 in rows:
                                        tt_v2620 = tuple(rr_v2620 or ())
                                        if len(tt_v2620) >= 8 and str(tt_v2620[2] or "").strip().lower() == "movie":
                                            self._home_watcha_preload_props(
                                                str(tt_v2620[0] or ""), title=str(tt_v2620[4] or ""),
                                                original_title=str(tt_v2620[5] or ""), year=str(tt_v2620[7] or "")
                                            )
                                            break
                                except Exception:
                                    pass
                                _log("LIBRARY_PROGRESS_RATING_POSTREADY_V2620 section=%s offset=%d rows=%d elapsed_ms=%.1f navigation_gate=0" % (
                                    sid, offset, len(rows), (time.time() - rating_started_v2620) * 1000.0
                                ))
                            finally:
                                with self._library_append_prefetch_lock_v2070:
                                    self._pc_progress_rating_warm_inflight_v2620 = False
                        else:
                            _log("LIBRARY_PROGRESS_RATING_POSTREADY_SKIP_V2620 section=%s offset=%d rows=%d reason=warm_inflight navigation_gate=0" % (
                                sid, offset, len(rows)
                            ))
                except Exception:
                    _log("LIBRARY_APPEND_PREFETCH_FAILED_V2070 section=%s offset=%d reason=%s err=%s" % (
                        sid, offset, reason or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    try:
                        with self._library_append_prefetch_lock_v2070:
                            self._library_append_prefetch_inflight_v2070.discard(key)
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_worker, name="PKMLibraryAppendPrefetchV2070", daemon=True).start()
            _log("LIBRARY_APPEND_PREFETCH_START_V2070 section=%s offset=%d limit=%d generation=%s reason=%s" % (
                sid, offset, limit, owner[-1], reason or ""))
            return True
        except Exception:
            return False

    def _take_library_append_prefetch_v2070(self):
        try:
            key = self._library_append_prefetch_key_v2070()
            with self._library_append_prefetch_lock_v2070:
                if key not in self._library_append_prefetch_rows_v2070:
                    return None
                return self._library_append_prefetch_rows_v2070.pop(key)
        except Exception:
            return None

    def _request_library_append_v2070(self, reason=""):
        """Arm append ahead of the loaded edge without querying on the key callback."""
        try:
            if self.getProperty("PlexKM.Window.IsSectionWall") != "1":
                return False
            wall = self.getControl(WALL_ID)
            pos = int(wall.getSelectedPosition())
            size = int(wall.size())
            if pos < 0 or size <= 0 or (self.wall_total and self.wall_offset >= self.wall_total):
                return False
            columns = max(1, int(self._wall_column_count() or 6))
            loaded_rows = max(1, (size + columns - 1) // columns)
            current_row = max(0, pos // columns)
            # v2077: refill by runway, not at the physical edge.  With 6 columns,
            # the default low-watermark is six full rows (36 native items).  The
            # next 48 rows are queried from local DB in the background from the
            # moment the previous bind completes, so this gate normally performs
            # an immediate in-memory publish long before the last row is visible.
            low_rows_v2077 = max(2, int(self._library_wall_low_watermark_rows_v2077()))
            request_row = max(1, loaded_rows - low_rows_v2077)
            if current_row < request_row:
                return False
            self._library_append_request_v2070 = True
            self._start_library_append_prefetch_v2070(reason="request:%s" % (reason or ""))
            _log("LIBRARY_APPEND_REQUEST_V2077 section=%s pos=%d row=%d request_row=%d low_watermark_rows=%d size=%d remaining_items=%d offset=%d reason=%s" % (
                self.active_section_id, pos, current_row, request_row, low_rows_v2077, size,
                max(0, size - pos - 1), int(self.wall_offset or 0), reason or ""))
            return True
        except Exception:
            return False

    def _publish_requested_library_append_v2070(self, reason="", allow_commit_v2071=False):
        """Publish one prefetched chunk through the single v2073 rebind transaction.

        Kodi 21.3's Python ControlList API does not expose a true tail-add operation:
        both addItem() and addItems() send GUI_MSG_LABEL_BIND, whose native container
        handler resets the Panel and selects item 0.  Therefore every live Library
        append snapshots Kodi 9100's current absolute selected position, performs one
        batch bind, then immediately re-selects that *same numeric position* once.
        This is transport-level compensation for Kodi's bind semantics, not a second
        logical selection owner: no rating key, tracked position, wall_pos, or index
        state is allowed to choose the target.
        """
        try:
            if not bool(getattr(self, "_library_append_request_v2070", False)):
                return 0
            if not bool(allow_commit_v2071):
                _log("LIBRARY_APPEND_COMMIT_BLOCKED_V2071 section=%s offset=%d reason=%s policy=post_native_only" % (
                    self.active_section_id, int(self.wall_offset or 0), reason or ""))
                return 0
            if self.getProperty("PlexKM.Window.IsSectionWall") != "1" or self._safe_focus_id() != WALL_ID:
                _log("LIBRARY_APPEND_COMMIT_DEFER_V2071 section=%s offset=%d reason=%s focus=%s wall_visible=%s" % (
                    self.active_section_id, int(self.wall_offset or 0), reason or "",
                    self._safe_focus_id(), self.getProperty("PlexKM.Window.IsSectionWall") or "0"))
                return 0
            peek_rows_v2579 = self._peek_library_append_prefetch_v2579()
            if peek_rows_v2579 is None:
                self._start_library_append_prefetch_v2070(reason="publish_pending:%s" % (reason or ""))
                _log("LIBRARY_APPEND_PUBLISH_PENDING_V2071 section=%s offset=%d reason=%s navigation_block=0" % (
                    self.active_section_id, int(self.wall_offset or 0), reason or ""))
                return 0

            wall_gate_v2579 = self.getControl(WALL_ID)
            gate_pos_v2579 = int(wall_gate_v2579.getSelectedPosition())
            gate_size_v2579 = max(0, int(wall_gate_v2579.size()))
            gate_cols_v2579 = max(1, int(self._wall_column_count() or 6))
            gate_loaded_rows_v2579 = max(1, (gate_size_v2579 + gate_cols_v2579 - 1) // gate_cols_v2579)
            gate_current_row_v2579 = max(0, gate_pos_v2579 // gate_cols_v2579)
            gate_remaining_rows_v2579 = max(0, gate_loaded_rows_v2579 - gate_current_row_v2579 - 1)
            owner_gate_v2579 = tuple(getattr(self, "_library_wall_owner_v2069", ()) or ())

            # One native rebind per actual selection position.  v2077 could consume
            # both 24-item halves of a 48-row reserve at the same focus position,
            # causing back-to-back LABEL_BIND resets while a DOWN key was still in
            # flight.  Wait for the next real selection move unless we are at the
            # hard edge.
            last_commit_v2579 = getattr(self, "_library_append_last_commit_v2579", None)
            if isinstance(last_commit_v2579, tuple) and len(last_commit_v2579) >= 3:
                last_owner_v2579, last_before_v2579, last_after_v2579 = last_commit_v2579[:3]
                if (tuple(last_owner_v2579 or ()) == owner_gate_v2579
                        and gate_pos_v2579 in (int(last_before_v2579), int(last_after_v2579))
                        and gate_remaining_rows_v2579 > 2):
                    _log("LIBRARY_APPEND_SAME_POSITION_DEFER_V2579 section=%s pos=%d remaining_rows=%d offset=%d reason=%s next_native_move=1" % (
                        self.active_section_id, gate_pos_v2579, gate_remaining_rows_v2579,
                        int(self.wall_offset or 0), reason or ""
                    ))
                    return 0

            if self._is_android_v2591():
                # V2600 UHD hard-minimal: never gate a native wall append on
                # Python poster download/decode. The wall may show a transient
                # placeholder; navigation and already-prefetched row data win.
                rapid_gate_v2581 = self._wall_rapid_scroll_active_v2581()
                _log("UHD_APPEND_POSTER_GATE_BYPASS_V2600 section=%s pos=%d remaining_rows=%d offset=%d art_queue=0 wait_ms=0 placeholder_allowed=1" % (
                    self.active_section_id, gate_pos_v2579, gate_remaining_rows_v2579, int(self.wall_offset or 0)
                ))
            else:
                # V2619 PC reference: no append waits for poster I/O. Newly
                # appended ListItems are rebound to Plex's canonical 240x360 URL,
                # so Kodi can paint them immediately and cache them natively.
                rapid_gate_v2581 = self._wall_rapid_scroll_active_v2581()
                _log("LIBRARY_APPEND_POSTER_GATE_BYPASS_V2619 section=%s pos=%d remaining_rows=%d offset=%d rapid=%d wait_ms=0 readiness_probe=0 python_art_jobs=0 kodi_small_remote=1" % (
                    self.active_section_id, gate_pos_v2579, gate_remaining_rows_v2579,
                    int(self.wall_offset or 0), 1 if rapid_gate_v2581 else 0
                ))
                try:
                    gate_state_v2619 = getattr(self, "_library_append_poster_gate_started_v2580", None)
                    if isinstance(gate_state_v2619, dict):
                        gate_state_v2619.pop((owner_gate_v2579, int(self.wall_offset or 0)), None)
                except Exception:
                    pass
                self._library_rapid_poster_spinner_finish_v2593(reason="v2619_pc_gate_bypass")


            rows = self._take_library_append_prefetch_v2070()
            if rows is None:
                return 0
            # v2077: a DB fetch returns 48 raw rows, but a live native rebind
            # publishes only 24 (4 rows). The second half stays as an in-memory
            # reserve under the next offset, so the following refill does not
            # wait for SQLite at all.
            fetched_rows_v2077 = list(rows or [])
            # V2582: one ControlList.addItems() is a full LABEL_BIND reset on
            # Kodi 21.3, not a real tail append.  During rapid scroll consume the
            # whole already-prefetched 48-row runway in ONE rebind instead of two
            # 24-row resets.  This halves reset/focus-repair frequency.
            if rapid_gate_v2581 and (not self._is_android_v2591()):
                if self._is_tv_library_section_v1870(self.active_section_id):
                    # V2622: TV cards carry more state than movie cards. A 48-item
                    # Kodi LABEL_BIND cost 130-205 ms in the PC trace; keep one live
                    # TV rebind to four rows (24 items) while the remaining 24 stay
                    # prepared in memory. Movies retain V2620's 48-item single bind.
                    publish_limit_v2077 = min(24, max(1, len(fetched_rows_v2077)))
                    _log("LIBRARY_TV_RAPID_CHUNK_V2622 section=%s fetched=%d publish=%d reserve=%d target_bind_ms_lt100=1" % (
                        self.active_section_id, len(fetched_rows_v2077), publish_limit_v2077,
                        max(0, len(fetched_rows_v2077) - publish_limit_v2077)
                    ))
                else:
                    publish_limit_v2077 = max(1, len(fetched_rows_v2077))
                    _log("LIBRARY_APPEND_PC_RAPID_FULL_RUNWAY_V2620 section=%s fetched=%d publish=%d reserve=0 rebinds_saved=1" % (
                        self.active_section_id, len(fetched_rows_v2077), publish_limit_v2077
                    ))
            else:
                publish_limit_v2077 = max(1, int(self._library_wall_append_count_v1932()))
            publish_rows_v2077 = fetched_rows_v2077[:publish_limit_v2077]
            reserve_rows_v2077 = fetched_rows_v2077[publish_limit_v2077:]
            if rapid_gate_v2581:
                _log("LIBRARY_APPEND_RAPID_BATCH_V2584 section=%s fetched=%d publish=%d reserve=%d skeletal=1 one_rebind=1" % (
                    self.active_section_id, len(fetched_rows_v2077), len(publish_rows_v2077), len(reserve_rows_v2077)
                ))
            wall = self.getControl(WALL_ID)
            pos_before = int(wall.getSelectedPosition())
            size_before = int(wall.size())
            columns_v2073 = max(1, int(self._wall_column_count() or 6))
            column_before_v2073 = pos_before % columns_v2073 if pos_before >= 0 else -1
            key_before = ""
            try:
                if 0 <= pos_before < size_before:
                    key_before = self._wall_item_key(wall.getListItem(pos_before)) or ""
            except Exception:
                key_before = ""
            self._library_append_request_v2070 = False
            added = self._append_section_rows(
                reason="prefetched_v2071", rows_override_v2070=publish_rows_v2077,
                preserve_selection_pos=pos_before, preserve_selection_key=key_before,
                commit_authorized_v2071=True
            )
            if int(added or 0) > 0 and reserve_rows_v2077:
                try:
                    owner_v2077 = tuple(getattr(self, "_library_wall_owner_v2069", ()) or ())
                    reserve_offset_v2077 = int(self.wall_offset or 0)
                    reserve_key_v2077 = self._library_append_prefetch_key_v2070(owner_v2077, reserve_offset_v2077)
                    with self._library_append_prefetch_lock_v2070:
                        self._library_append_prefetch_rows_v2070[reserve_key_v2077] = list(reserve_rows_v2077)
                    _log("LIBRARY_APPEND_RESERVE_READY_V2077 section=%s fetched=%d published=%d reserve=%d reserve_offset=%d generation=%s" % (
                        self.active_section_id, len(fetched_rows_v2077), int(added or 0), len(reserve_rows_v2077),
                        reserve_offset_v2077, owner_v2077[-1] if owner_v2077 else ""
                    ))
                except Exception:
                    _log("LIBRARY_APPEND_RESERVE_STORE_FAILED_V2077 section=%s err=%s" % (
                        self.active_section_id, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            pos_after = int(wall.getSelectedPosition())
            if int(added or 0) > 0:
                try:
                    self._library_append_last_commit_v2579 = (
                        tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()),
                        int(pos_before), int(pos_after)
                    )
                except Exception:
                    pass
            column_after_v2073 = pos_after % columns_v2073 if pos_after >= 0 else -1
            key_after = ""
            try:
                if 0 <= pos_after < int(wall.size()):
                    key_after = self._wall_item_key(wall.getListItem(pos_after)) or ""
            except Exception:
                key_after = ""
            _log("LIBRARY_APPEND_REBIND_TRANSACTION_V2073 section=%s pos_before=%d pos_after=%d col_before=%d col_after=%d columns=%d size_before=%d size_after=%d key_same=%d added=%d bind_count=1 same_position_restore=1 logical_owner_write=0 focus_write=0 viewport_write=0 reason=%s" % (
                self.active_section_id, pos_before, pos_after, column_before_v2073, column_after_v2073, columns_v2073,
                size_before, int(wall.size()), 1 if (not key_before or key_before == key_after) else 0,
                int(added or 0), reason or ""
            ))
            if int(added or 0) > 0 and (pos_after != pos_before or column_after_v2073 != column_before_v2073):
                _log("LIBRARY_APPEND_COLUMN_INVARIANT_FAIL_V2073 section=%s pos_before=%d pos_after=%d col_before=%d col_after=%d size_after=%d reason=%s" % (
                    self.active_section_id, pos_before, pos_after, column_before_v2073, column_after_v2073, int(wall.size()), reason or ""
                ), xbmc.LOGERROR)
            # V2632: the just-published reserve is already enough for the next native
            # moves. Starting the following DB/art runway from this GUI callback can
            # immediately contend on Python/GIL with Kodi's LABEL_BIND and inflated the
            # outer append cost to 200-300 ms even when the bind itself was ~8 ms.
            # Arm it just after the callback returns; no foreground wait is introduced.
            _next_reason_v2632 = "after_publish_v2632:%s" % (reason or "")
            def _deferred_refill_v2632():
                try:
                    if self._closing_event_v1841.wait(0.035):
                        return
                    self._start_library_append_prefetch_v2070(reason=_next_reason_v2632)
                except Exception:
                    pass
            _PKMHomeThreadV2151(target=_deferred_refill_v2632, name="PKMLibraryRefillV2632", daemon=True).start()
            _log("LIBRARY_APPEND_REFILL_DEFER_V2632 section=%s offset=%d delay_ms=35 foreground_start=0" % (
                self.active_section_id, int(self.wall_offset or 0)))
            return int(added or 0)
        except Exception:
            _log("LIBRARY_APPEND_PUBLISH_FAILED_V2071 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _wall_poster_local_path_v1644(self, url):
        try:
            if not url:
                return ""
            if not os.path.isdir(self._wall_poster_cache_dir_v1644):
                os.makedirs(self._wall_poster_cache_dir_v1644, exist_ok=True)
            # Plex image transcode/original poster responses are JPEG in this path.
            # Keep a real image suffix so Kodi's image loader never depends on
            # content sniffing for append-loaded wall entries.
            name = hashlib.sha1(str(url).encode("utf-8", "ignore")).hexdigest() + ".jpg"
            return os.path.join(self._wall_poster_cache_dir_v1644, name)
        except Exception:
            return ""

    def _wall_poster_download_one_v1644(self, url, priority=None, pause_when_playing=True, cancel_check=None):
        """Download one poster through the shared artwork scheduler.

        Background callers are paused/cancelled when playback starts. Foreground
        callers may pass a higher priority and disable playback pausing.
        """
        if self._closing_event_v1841.is_set():
            return ""
        local = self._wall_poster_local_path_v1644(url)
        try:
            if local and os.path.exists(local) and os.path.getsize(local) > 1024:
                return local
        except Exception:
            pass
        if not local or not url:
            return ""
        tmp = "%s.%s.tmp" % (local, threading.get_ident())

        def _cancel_v1937():
            try:
                if self._closing_event_v1841.is_set():
                    return True
                if callable(cancel_check) and cancel_check():
                    return True
            except Exception:
                return True
            return False

        try:
            data = pkm_artwork_scheduler.fetch_bytes(
                url, timeout=8.0, max_bytes=8 * 1024 * 1024,
                headers={"User-Agent": "plexkm-wall-poster-v1937/1.0"},
                priority=(pkm_artwork_scheduler.PRIORITY_BACKGROUND if priority is None else int(priority)),
                tag="wall_poster", cancel_check=_cancel_v1937,
                pause_check=_pkm_playback_active_v1411,
                pause_when_playing=bool(pause_when_playing),
            )
            if _cancel_v1937() or not data:
                return ""
            with open(tmp, "wb") as fh:
                fh.write(data)
            if os.path.getsize(tmp) <= 1024:
                return ""
            os.replace(tmp, local)
            return local
        except Exception:
            return ""
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

    def _wall_poster_download_bounded_v1862(self, url, timeout_sec=1.8, max_bytes=8 * 1024 * 1024, priority=None, cancel_check=None):
        """Resolve one poster into PKM's local cache through the shared scheduler.

        This foreground path never retains native ListItems in worker threads.
        Same-URL requests are coalesced and the global network budget is three.
        """
        if self._closing_event_v1841.is_set():
            return ""
        url = str(url or "").strip()
        if not url:
            return ""
        local = self._wall_poster_local_path_v1644(url)
        try:
            if local and self._local_poster_file_ready_v1865(local):
                return local
            if local and os.path.exists(local):
                os.remove(local)
        except Exception:
            pass
        if not local or not url.lower().startswith(("http://", "https://")):
            return ""
        tmp = "%s.v1937.%s.tmp" % (local, threading.get_ident())

        def _cancel_v1937():
            try:
                if self._closing_event_v1841.is_set():
                    return True
                if callable(cancel_check) and cancel_check():
                    return True
            except Exception:
                return True
            return False

        try:
            byte_limit = max(64 * 1024, min(8 * 1024 * 1024, int(max_bytes or 8 * 1024 * 1024)))
            data = pkm_artwork_scheduler.fetch_bytes(
                url, timeout=max(0.4, float(timeout_sec or 1.8)), max_bytes=byte_limit,
                headers={"User-Agent": "plexkm-first-viewport-v1937/1.0"},
                priority=(pkm_artwork_scheduler.PRIORITY_FOREGROUND if priority is None else int(priority)),
                tag="first_viewport", cancel_check=_cancel_v1937,
                pause_when_playing=False,
            )
            if _cancel_v1937() or not data:
                return ""
            with open(tmp, "wb") as fh:
                fh.write(data)
            if not self._local_poster_file_ready_v1865(tmp):
                return ""
            os.replace(tmp, local)
            return local
        except Exception:
            return ""
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

    def _viewport_poster_url_v1937(self, sources, rating_key=""):
        """Build a shared Plex-server small-poster URL for the Library wall.

        Plex preserves the source aspect ratio, so the returned JPEG is usually
        about 245~255x360 rather than byte-for-byte 240x360. That is valid: the
        Kodi XML poster box owns the final 240x360 visual crop/scale.
        """
        nested_url = ""
        try:
            c = _ensure_core()
            server = str(c.clean_server_url() or "").rstrip("/")
            server_parts = urlsplit(server) if server else None
            for raw in list(sources or []):
                value = str(raw or "").strip()
                if not value:
                    continue
                lower = value.lower()
                if lower.startswith(("special://", "resource://", "image://", "file://")):
                    continue
                if value.startswith("/"):
                    parsed = urlsplit(value)
                    path = parsed.path or ""
                    query_pairs = [
                        (k, v) for k, v in parse_qsl(parsed.query or "", keep_blank_values=True)
                        if str(k or "").lower() != "x-plex-token"
                    ]
                elif lower.startswith(("http://", "https://")):
                    parsed = urlsplit(value)
                    same_server = bool(
                        server_parts and parsed.netloc and
                        parsed.netloc.lower() == server_parts.netloc.lower()
                    )
                    if not same_server:
                        continue
                    path = parsed.path or ""
                    query_pairs = [
                        (k, v) for k, v in parse_qsl(parsed.query or "", keep_blank_values=True)
                        if str(k or "").lower() != "x-plex-token"
                    ]
                else:
                    continue

                query = dict(query_pairs)
                if path.rstrip("/") == "/photo/:/transcode":
                    nested = str(query.get("url") or "").strip()
                    if nested:
                        nested_parts = urlsplit(nested)
                        nested_path = nested_parts.path or nested
                        nested_pairs = [
                            (k, v) for k, v in parse_qsl(nested_parts.query or "", keep_blank_values=True)
                            if str(k or "").lower() != "x-plex-token"
                        ]
                        nested_url = urlunsplit(("", "", nested_path, urlencode(nested_pairs), ""))
                else:
                    nested_url = urlunsplit(("", "", path, urlencode(query_pairs), ""))
                if nested_url:
                    break

            rk = str(rating_key or "").strip()
            if not nested_url and rk.isdigit():
                nested_url = "/library/metadata/%s/thumb" % rk
            if not nested_url:
                return ""
            return c.plex_url(
                "/photo/:/transcode",
                params={
                    "width": 240,
                    "height": 360,
                    "minSize": 1,
                    "upscale": 1,
                    "format": "jpg",
                    "url": nested_url,
                },
                include_token=True,
            )
        except Exception:
            _log("LIBRARY_POSTER_URL_FAILED_V1937 rating_key=%s err=%s" % (
                str(rating_key or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return ""

    def _prime_first_viewport_posters_v1862(self, listitems, visible_count=12, reason="",
                                                timeout_sec=1.8, retry_missing=0,
                                                require_all=False):
        """Prepare verified local poster files for the requested viewport.

        v2147 uses one shared server-small-poster path on every platform. Worker
        pools may prepare immutable inputs in parallel, but all PKM-managed image
        network transfers pass through the global three-slot scheduler.
        """
        started = _pkm_speed_ms()
        scene_generation_v1937 = int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0)

        def _scene_stale_v1937():
            try:
                return bool(
                    self._closing_event_v1841.is_set()
                    or int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0) != scene_generation_v1937
                )
            except Exception:
                return True

        try:
            limit = max(0, min(int(visible_count or 0), len(listitems or [])))
        except Exception:
            limit = 0
        if limit <= 0:
            return 0, 0

        payloads = []
        source_cache_hits = set()
        item_keys = {}
        requested = limit
        for idx, li in enumerate(list(listitems or [])[:limit]):
            try:
                item_keys[idx] = str(li.getProperty("PlexKM.RatingKey") or "")
            except Exception:
                item_keys[idx] = ""
            try:
                sources = tuple(self._startup_widget_poster_sources_v1644(li) or [])
            except Exception:
                sources = tuple()
            try:
                small_url = self._viewport_poster_url_v1937(sources, rating_key=item_keys.get(idx, ""))
                small_local = self._wall_poster_local_path_v1644(small_url)
                if small_local and self._local_poster_file_ready_v1865(small_local):
                    source_cache_hits.add(idx)
            except Exception:
                pass
            payloads.append((idx, sources))

        _log("LIBRARY_SERVER_SMALL_VIEWPORT_BEGIN_V1937 reason=%s requested=%d cached=%d require_all=%d scheduler_limit=%d platform_shared=1 device_branch=0" % (
            reason or "", requested, len(source_cache_hits), 1 if require_all else 0,
            int(pkm_artwork_scheduler.MAX_ACTIVE_DOWNLOADS)
        ))

        local_results = {}
        self._library_viewport_poster_active_v1866.set()
        try:
            attempts = max(1, 1 + int(retry_missing or 0))
            pending = dict(payloads)
            for attempt in range(attempts):
                if not pending or self._closing_event_v1841.is_set():
                    break
                # Threads prepare independent immutable results; the scheduler, not
                # these worker counts, owns the actual network concurrency budget.
                workers = min(2 if self._is_android_v2591() else 6, max(1, len(pending)))
                _log("FIRST_VIEWPORT_POSTER_WORKERS_V1937 reason=%s attempt=%d pending=%d workers=%d scheduler_limit=%d source_cached=%d" % (
                    reason or "", attempt + 1, len(pending), workers,
                    int(pkm_artwork_scheduler.MAX_ACTIVE_DOWNLOADS), len(source_cache_hits)
                ))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    future_map = {
                        executor.submit(
                            self._resolve_visible_poster_sources_server_small_v1937,
                            sources, item_keys.get(idx, ""),
                            max(0.8, min(3.5, float(timeout_sec or 3.0))),
                            _scene_stale_v1937
                        ): idx
                        for idx, sources in pending.items()
                    }
                    next_pending = {}
                    for future in as_completed(future_map):
                        idx = future_map[future]
                        try:
                            local = future.result() or ""
                        except Exception:
                            local = ""
                        if local:
                            local_results[idx] = local
                        else:
                            next_pending[idx] = pending.get(idx, tuple())
                    pending = next_pending
                if pending and attempt + 1 < attempts:
                    _log("FIRST_VIEWPORT_POSTER_RETRY_V1937 reason=%s attempt=%d missing=%d require_all=%d" % (
                        reason or "", attempt + 1, len(pending), 1 if require_all else 0
                    ))
        finally:
            self._library_viewport_poster_active_v1866.clear()

        if _scene_stale_v1937():
            _log("FIRST_VIEWPORT_POSTER_STALE_DISCARD_V1937 reason=%s generation=%d current=%d results=%d control_publish=0" % (
                reason or "", scene_generation_v1937,
                int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0), len(local_results)
            ))
            local_results = {}

        applied = 0
        for idx, local in local_results.items():
            try:
                li = listitems[idx]
                if not self._startup_bind_local_poster_v2498(li, local, source="first_viewport_poster_only"):
                    continue
                # xbmcgui.ListItem does not provide the same clearProperty contract
                # as Window.  Using clearProperty here caused a successful local
                # result to be counted as viewport_ready=0 after setArt had already
                # succeeded.  Empty-string assignment is the portable ListItem clear.
                li.setProperty("PlexKM.PosterMissingV1963", "")
                li.setProperty("PlexKM.PosterMissingReasonV1963", "")
                # The first viewport is publishable even when another item is missing.
                li.setProperty("PlexKM.LibraryInitialAtomicV1868", "1")
                applied += 1
            except Exception:
                pass


        # v1963: a missing poster is an item-level condition, never a wall-level failure.
        # Use an in-memory ListItem flag only; no permanent placeholder/negative image
        # is written, so a later Plex thumb/updatedAt change is picked up on rebuild.
        missing_indices_v1963 = []
        for idx in range(requested):
            if idx in local_results:
                continue
            try:
                li = listitems[idx]
                li.setProperty("PlexKM.PosterMissingV1963", "1")
                li.setProperty("PlexKM.PosterMissingReasonV1963", "fetch_unavailable")
                li.setProperty("PlexKM.LibraryInitialAtomicV1868", "1")
                li.setProperty("PlexKM.WallPosterDisplayV1644", "")
                li.setProperty("PlexKM.PosterFallbackArt", "")
                li.setProperty("PlexKM.PosterFallbackArtActive", "")
                missing_indices_v1963.append(idx)
                _log("POSTER_PLACEHOLDER_ITEM_V1963 rating_key=%s index=%d title=%s transient=1 retry_on_rebuild=1 publish_continue=1" % (
                    item_keys.get(idx, "") or "-", idx,
                    _short_log_value(li.getProperty("PlexKM.WallTitleLine1") or li.getLabel())
                ), xbmc.LOGWARNING)
            except Exception:
                pass

        fallback_remote = max(0, requested - applied)
        downloaded = max(0, applied - len(source_cache_hits))
        _log("FIRST_VIEWPORT_POSTER_GATE_V1937 reason=%s requested=%d source_cache_hit=%d viewport_ready=%d downloaded=%d missing=%d wait_ms=%d server_small=1 require_all=%d attempts=%d" % (
            reason or "", requested, len(source_cache_hits), applied, downloaded,
            fallback_remote, _pkm_speed_ms() - started, 1 if require_all else 0,
            max(1, 1 + int(retry_missing or 0))
        ))
        _log("LIBRARY_SERVER_SMALL_VIEWPORT_DONE_V1937 reason=%s requested=%d ready=%d missing=%d cached=%d downloaded=%d atomic=%d platform_shared=1" % (
            reason or "", requested, applied, fallback_remote,
            len(source_cache_hits), downloaded, 1 if require_all else 0
        ))
        try:
            pkm_artwork_scheduler.log_stats("first_viewport:%s" % (reason or ""))
        except Exception:
            pass
        try:
            item_status = "|".join(
                "%d:%s:C%d:E%d" % (
                    idx, item_keys.get(idx, "") or "-",
                    1 if idx in source_cache_hits else 0,
                    1 if idx in local_results else 0,
                )
                for idx in range(requested)
            )
            _log("FIRST_VIEWPORT_POSTER_ITEM_STATUS_V1937 reason=%s items=%s C=source_cache E=exact_texture" % (
                reason or "", item_status
            ))
        except Exception:
            pass
        return applied, fallback_remote

    def _wall_poster_prefetch_worker_v1644(self):
        restart_workers_v1644 = False
        generation_v1841 = int(self._lifecycle_generation_v1841)
        try:
            monitor_v1644 = xbmc.Monitor()
            while (not monitor_v1644.abortRequested()
                   and self._worker_alive_v1841(generation_v1841)):
                # Poster prefetch is lower priority than playback and the atomic
                # first Library viewport. Do not compete for network/disk/decode IO.
                if getattr(self, "_library_viewport_poster_active_v1866", None) is not None \
                        and self._library_viewport_poster_active_v1866.is_set():
                    if monitor_v1644.waitForAbort(0.05):
                        return
                    continue
                if _pkm_playback_active_v1411():
                    if monitor_v1644.waitForAbort(0.25):
                        return
                    continue
                with self._wall_poster_prefetch_lock_v1644:
                    if not self._wall_poster_prefetch_queue_v1644:
                        return
                    payload_v1838 = self._wall_poster_prefetch_queue_v1644.pop(0)
                remote = str(payload_v1838.get("remote") or "")
                fallback = str(payload_v1838.get("fallback") or "")
                sources = []
                # v2498: both payload slots are poster-authority candidates only.
                for src in (remote, fallback):
                    src = str(src or "").strip()
                    if src and src not in sources:
                        sources.append(src)
                try:
                    small_url_v1937 = self._viewport_poster_url_v1937(sources, rating_key="")
                    if small_url_v1937 and small_url_v1937 not in sources:
                        sources.insert(0, small_url_v1937)
                except Exception:
                    pass
                token = str(payload_v1838.get("token") or remote or fallback)
                priority_v1937 = int(payload_v1838.get("priority") or pkm_artwork_scheduler.PRIORITY_BACKGROUND)
                discard_generation_v1937 = bool(int(payload_v1838.get("discard_on_generation") or 0))
                payload_generation_v1937 = int(payload_v1838.get("generation") or 0)
                payload_section_v1937 = str(payload_v1838.get("section_id") or "")
                payload_viewport_generation_v2594 = int(payload_v1838.get("viewport_generation_v2594") or 0)
                discard_viewport_v2594 = bool(int(payload_v1838.get("discard_on_viewport_v2594") or 0))
                if discard_generation_v1937 and (
                        payload_generation_v1937 != int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0)
                        or (payload_section_v1937 and payload_section_v1937 != str(getattr(self, "active_section_id", "") or ""))):
                    with self._wall_poster_prefetch_lock_v1644:
                        self._wall_poster_prefetch_attempts_v1644.pop(token, None)
                        self._wall_poster_prefetch_seen_v1644.discard(token)
                    _log("WALL_POSTER_PREFETCH_STALE_DISCARD_V1937 token=%s section=%s active=%s generation=%d current=%d control_publish=0" % (
                        token, payload_section_v1937, str(getattr(self, "active_section_id", "") or ""),
                        payload_generation_v1937, int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0)
                    ))
                    continue
                if discard_viewport_v2594 and payload_viewport_generation_v2594 != int(getattr(self, "_library_poster_viewport_generation_v2594", 0) or 0):
                    with self._wall_poster_prefetch_lock_v1644:
                        self._wall_poster_prefetch_attempts_v1644.pop(token, None)
                        self._wall_poster_prefetch_seen_v1644.discard(token)
                    _log("LIBRARY_POSTER_VIEWPORT_STALE_DISCARD_V2594 token=%s section=%s viewport=%d current=%d control_publish=0" % (
                        token, payload_section_v1937, payload_viewport_generation_v2594,
                        int(getattr(self, "_library_poster_viewport_generation_v2594", 0) or 0)
                    ))
                    continue
                local = ""
                runway_fetch_started_v2623 = time.perf_counter() if token.startswith("v2621runway:") else 0.0
                deadline_preempted_v2624 = [False]
                def _poster_payload_stale_v2594():
                    if not self._worker_alive_v1841(generation_v1841):
                        return True
                    if discard_viewport_v2594 and payload_viewport_generation_v2594 != int(getattr(self, "_library_poster_viewport_generation_v2594", 0) or 0):
                        return True
                    if payload_section_v1937 and payload_section_v1937 != str(getattr(self, "active_section_id", "") or ""):
                        return True
                    # V2625: if the actual Movie/TV viewport still has missing
                    # posters, an already-started future runway transfer must yield
                    # the single U+ lane immediately. Poster authority is now common
                    # to both media kinds; DB/append behavior remains unchanged.
                    try:
                        if token.startswith("v2621runway:") and payload_section_v1937:
                            vp_sid = str(getattr(self, "_library_texture_viewport_sid_v2624", "") or "")
                            vp_start = max(0, int(getattr(self, "_library_texture_viewport_start_v2624", 0) or 0))
                            vp_end = max(vp_start, int(getattr(self, "_library_texture_viewport_end_v2624", vp_start + 18) or (vp_start + 18)))
                            vp_missing = max(0, int(getattr(self, "_library_texture_visible_missing_v2624", 0) or 0))
                            abs_idx = int(payload_v1838.get("absolute_index_v2622") or -1)
                            if vp_sid == payload_section_v1937 and abs_idx >= 0:
                                if abs_idx < max(0, vp_start - 6):
                                    deadline_preempted_v2624[0] = True
                                    return True
                                if vp_missing > 0 and not (vp_start <= abs_idx < vp_end):
                                    deadline_preempted_v2624[0] = True
                                    return True
                    except Exception:
                        pass
                    return False
                for src in sources:
                    if not self._worker_alive_v1841(generation_v1841):
                        return
                    local = self._wall_poster_download_one_v1644(
                        src, priority=priority_v1937,
                        pause_when_playing=True,
                        cancel_check=_poster_payload_stale_v2594
                    )
                    if local:
                        break
                # v1838: never retain or mutate xbmcgui.ListItem instances in a
                # downloader thread. A wall reset invalidates those native
                # objects and late setProperty() calls can terminate Kodi.
                if token.startswith("v2621runway:"):
                    try:
                        _log("LIBRARY_TEXTURE_FETCH_V2623 section=%s abs=%d priority=%d ok=%d elapsed_ms=%.1f queue_remaining=%d" % (
                            payload_section_v1937, int(payload_v1838.get("absolute_index_v2622") or -1),
                            priority_v1937, 1 if local else 0,
                            ((time.perf_counter() - runway_fetch_started_v2623) * 1000.0) if runway_fetch_started_v2623 else 0.0,
                            len(getattr(self, "_wall_poster_prefetch_queue_v1644", []) or [])
                        ))
                    except Exception:
                        pass
                if deadline_preempted_v2624[0] and token.startswith("v2621runway:"):
                    try:
                        media_kind_preempt_v2625 = str(payload_v1838.get("media_kind_v2625") or "") or ("tv" if self._is_tv_library_section_v1870(payload_section_v1937) else "movie")
                        if media_kind_preempt_v2625 == "tv":
                            _log("LIBRARY_TEXTURE_ACTIVE_PREEMPT_V2624 section=%s abs=%d priority=%d viewport=%d-%d missing=%d action=cancel_future_transfer_rearm_later" % (
                                payload_section_v1937, int(payload_v1838.get("absolute_index_v2622") or -1), priority_v1937,
                                int(getattr(self, "_library_texture_viewport_start_v2624", 0) or 0),
                                max(0, int(getattr(self, "_library_texture_viewport_end_v2624", 0) or 0) - 1),
                                int(getattr(self, "_library_texture_visible_missing_v2624", 0) or 0)
                            ))
                        _log("LIBRARY_TEXTURE_ACTIVE_PREEMPT_V2625 media=%s section=%s abs=%d priority=%d viewport=%d-%d missing=%d action=cancel_future_transfer_rearm_later" % (
                            media_kind_preempt_v2625, payload_section_v1937, int(payload_v1838.get("absolute_index_v2622") or -1), priority_v1937,
                            int(getattr(self, "_library_texture_viewport_start_v2624", 0) or 0),
                            max(0, int(getattr(self, "_library_texture_viewport_end_v2624", 0) or 0) - 1),
                            int(getattr(self, "_library_texture_visible_missing_v2624", 0) or 0)
                        ))
                    except Exception:
                        pass
                if local and token.startswith("v2621runway:"):
                    try:
                        self._library_texture_runway_store_v2621(
                            payload_section_v1937,
                            str(payload_v1838.get("rating_key_v2621") or ""),
                            str(payload_v1838.get("canonical_v2621") or remote or ""),
                            local
                        )
                        # Coalesced 20 ms SendClick; no ListItem is touched from
                        # this worker. If the user stops pressing DOWN, the poster
                        # still appears as soon as its local file is ready.
                        self._schedule_library_texture_runway_commit_v2621()
                    except Exception:
                        pass
                with self._wall_poster_prefetch_lock_v1644:
                    if local:
                        self._wall_poster_prefetch_attempts_v1644.pop(token, None)
                    elif deadline_preempted_v2624[0]:
                        # Do not consume retry budget or put a stale/future card
                        # straight back at the head. A later viewport arm will
                        # re-add it if it becomes relevant.
                        self._wall_poster_prefetch_attempts_v1644.pop(token, None)
                        self._wall_poster_prefetch_seen_v1644.discard(token)
                    else:
                        attempts = int(self._wall_poster_prefetch_attempts_v1644.get(token, 0) or 0) + 1
                        self._wall_poster_prefetch_attempts_v1644[token] = attempts
                        if (attempts < 3
                                and self._worker_alive_v1841(generation_v1841)):
                            self._wall_poster_prefetch_queue_v1644.append(payload_v1838)
                        else:
                            self._wall_poster_prefetch_attempts_v1644.pop(token, None)
                            self._wall_poster_prefetch_seen_v1644.discard(token)
        finally:
            with self._wall_poster_prefetch_lock_v1644:
                self._wall_poster_prefetch_worker_count_v1644 = max(
                    0, int(self._wall_poster_prefetch_worker_count_v1644 or 0) - 1
                )
                if self._wall_poster_prefetch_worker_count_v1644 == 0:
                    self._wall_poster_prefetch_running_v1644 = False
                    restart_workers_v1644 = bool(self._wall_poster_prefetch_queue_v1644)
            if restart_workers_v1644 and self._worker_alive_v1841(generation_v1841):
                self._start_wall_poster_workers_v1644()

    def _start_wall_poster_workers_v1644(self):
        with self._wall_poster_prefetch_lock_v1644:
            if (self._closing_event_v1841.is_set()
                    or self._wall_poster_prefetch_running_v1644
                    or not self._wall_poster_prefetch_queue_v1644):
                return
            worker_count = min(
                max(1, int(pkm_artwork_scheduler.MAX_ACTIVE_DOWNLOADS)),
                2, max(1, len(self._wall_poster_prefetch_queue_v1644))
            )
            if self._uhd_kpi_proxy_v2605():
                _log("UHD3_LIBRARY_POSTER_WORKER_BUDGET_V2712 workers=%d max=2 queue=%d navigation_visible_priority=1" % (
                    worker_count, len(self._wall_poster_prefetch_queue_v1644)
                ))
            self._wall_poster_prefetch_running_v1644 = True
            self._wall_poster_prefetch_worker_count_v1644 = worker_count
            for idx in range(worker_count):
                _PKMHomeThreadV2151(
                    target=self._wall_poster_prefetch_worker_v1644,
                    name="PKMWallPosterV1644-%d" % idx, daemon=True
                ).start()

    def _restore_library_append_selection_v2122(self, wall, expected_pos, expected_key="", stable_prefix_size=None):
        """Keep the exact pre-append item selected after Kodi's list rebind.

        Kodi 21.3 can report a one-item native cursor skew immediately after
        ControlList.addItems()+selectItem() on the focused panel.  A numeric
        position write alone therefore is not a sufficient invariant.  v2122
        verifies the immutable pre-append item key and uses the observed native
        delta as bounded feedback.  It never changes focus, viewport, sidebar
        ownership, or logical wall state.
        """
        try:
            expected_pos = int(expected_pos)
        except Exception:
            expected_pos = -1
        expected_key = str(expected_key or "")
        try:
            size = int(wall.size())
        except Exception:
            size = 0
        if expected_pos < 0 or expected_pos >= size:
            return False, -1, 0

        # Tail append must not reorder existing rows.  When a key snapshot is
        # available, confirm its actual post-bind index before asking Kodi to
        # select anything.  Search only the pre-append stable prefix so a
        # duplicated key in newly appended rows can never steal ownership.
        target_pos = expected_pos
        if expected_key:
            try:
                key_at_expected = self._wall_item_key(wall.getListItem(expected_pos)) or ""
            except Exception:
                key_at_expected = ""
            if key_at_expected != expected_key:
                try:
                    stable_limit = int(stable_prefix_size)
                except Exception:
                    stable_limit = size
                stable_limit = max(0, min(size, stable_limit))
                found = -1
                for idx in range(stable_limit):
                    try:
                        if (self._wall_item_key(wall.getListItem(idx)) or "") == expected_key:
                            found = idx
                            break
                    except Exception:
                        continue
                if found < 0:
                    # R52: key not readable/found right after LABEL_BIND (field
                    # log: selected_after=0, attempts=0 -> focus jumped to the
                    # first poster).  Tail append never reorders the prefix, so
                    # fall back to the captured numeric position.
                    _log("LIBRARY_APPEND_RESTORE_KEY_MISS_NUMERIC_R52 expected_pos=%d size=%d" % (expected_pos, size))
                    expected_key = ""
                    found = expected_pos
                target_pos = found

        requested = target_pos
        attempts = 0
        last_pos = -1
        for _ in range(3):
            attempts += 1
            try:
                wall.selectItem(max(0, min(size - 1, int(requested))))
                actual = int(wall.getSelectedPosition())
            except Exception:
                actual = -1
            last_pos = actual
            actual_key = ""
            try:
                if 0 <= actual < size:
                    actual_key = self._wall_item_key(wall.getListItem(actual)) or ""
            except Exception:
                actual_key = ""
            if actual == target_pos and (not expected_key or actual_key == expected_key):
                return True, actual, attempts
            # Feedback uses the *observed* native delta; there is no hard-coded
            # +1/-1 assumption.  If selectItem(34) lands on 33, the next request
            # becomes 35.  Stop if the API stops making progress.
            if actual < 0:
                break
            # R53: ControlList.selectItem() is queued (SendThreadMessage) after
            # the LABEL_BIND, so getSelectedPosition() right here can still be
            # the pre-bind/reset value.  The old "observed delta" correction then
            # queued a SECOND select at target+delta, which Kodi applied last
            # (field log: expected 42 -> landed 65 = 그린북 instead of 괴물,
            # expected 78 -> 84).  One select to the exact target is correct.
            break
        return False, last_pos, attempts

    def _focused_wall_item(self):
        try:
            # Home rows 9410~9450 and section recommendation rows 8410~8450
            # are both HomeLayout poster rows.  Info/meta must be sourced from
            # the actual focused row item, not from the hidden/legacy wall.
            if self._is_home_row_control():
                return self._home_focused_item()
            return self.getControl(WALL_ID).getSelectedItem()
        except Exception:
            return None
