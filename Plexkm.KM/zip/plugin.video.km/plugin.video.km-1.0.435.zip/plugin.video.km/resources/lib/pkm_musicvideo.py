# -*- coding: utf-8 -*-
"""PlexKM 뮤직비디오: 라이브러리에 등록한 뮤직비디오 폴더를 읽어 사이드메뉴와 목록으로 보여 준다.

이름 읽기·색인·갱신은 script.module.pkm.musicagent(종속 모듈)가 한다. 모듈이 없으면 이 파일은
아무 일도 하지 않고(available() == False) PlexKM 은 그대로 동작한다.
1차 버전: 사이드메뉴 항목 -> 코디 기본 목록(아티스트 -> 영상). 인포 페이지·격자 보기는 시안 확정 뒤.
"""
import os
import threading
import time
import traceback

try:
    from urllib.parse import quote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import xbmcaddon
except Exception:  # pragma: no cover
    xbmcaddon = None

try:
    import pkm_musicagent as _agent
except Exception:  # 모듈이 아직 설치되지 않은 기기
    _agent = None

from resources.lib import pkm_sources as ps

PLUGIN = "plugin://plugin.video.km/"
_STORE = [None]
_WATCH = {}


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] MV_R337 " + msg, level)
    except Exception:
        pass


def available():
    return _agent is not None


def _store():
    if _STORE[0] is None:
        base = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
        _STORE[0] = _agent.IndexStore(base)
    return _STORE[0]


# ------------------------------------------------------------------ 소스
def sources():
    return [s for s in ps.kodi_sources() if s.get("content") == ps.KODI_CONTENT_MUSICVIDEOS]


def _root(src):
    return ps.normalize_folder(src.get("path") or "")


def _folder_name(src):
    parts = [x for x in (src.get("path") or "").replace("\\", "/").split("/") if x and not x.endswith(":")]
    return parts[-1] if parts else ""


def display_name(src):
    return ps.lib_pref(src.get("id"), "name", "") or src.get("label") or _folder_name(src) or "뮤직비디오"


def visible_sources():
    return [s for s in sources() if not ps.lib_pref(s.get("id"), "hidden", False)]


def sidebar_sig():
    return tuple((s.get("id"), display_name(s)) for s in visible_sources())


def bump():
    """사이드메뉴가 항목을 다시 만들게 한다(기존 코디 라이브러리 감시 스레드가 이 값을 본다)."""
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.SyncedAtR108", str(time.time()))
    except Exception:
        pass


def summary(src):
    """설정 화면용: (개수, 마지막 스캔 시각)."""
    if not available():
        return 0, 0
    try:
        idx = _store().load(src["id"])
        return len(idx.get("items", [])), int(idx.get("scanned_at") or 0)
    except Exception:
        return 0, 0


# ------------------------------------------------------------------ 스캔
def _listdir_for(root):
    def listdir(rel):
        path = root + (rel + "/" if rel else "")
        dirs, files = xbmcvfs.listdir(path)
        # 느린 네트워크 폴더라 파일마다 Stat 을 부르지 않는다(크기·시각 0). 추가·삭제는 목록 차이로 감지.
        return [(d, True, 0, 0) for d in dirs] + [(f, False, 0, 0) for f in files]
    return listdir


def _reader_for(root):
    def read_text(rel):
        f = xbmcvfs.File(root + rel)
        try:
            return f.read()
        finally:
            f.close()
    return read_text


def scan_source(src, notify=True):
    """백그라운드로 스캔하고, 끝나면 알림 + 사이드메뉴 갱신. 이미 돌고 있으면 False."""
    if not available():
        return False
    sid = src["id"]
    root = _root(src)
    st = _store()
    if not st.scan_async(sid, _listdir_for(root), _reader_for(root), None, default_kind="mv"):
        return False
    name = display_name(src)
    if notify:
        _toast("%s 스캔을 시작했습니다" % name)

    def _watch():
        mon = xbmc.Monitor()
        while not mon.abortRequested():
            state = (st.progress.get(sid) or {}).get("state")
            if state != "running":
                break
            if mon.waitForAbort(1.0):
                return
        res = (st.progress.get(sid) or {})
        if res.get("state") == "done":
            r = res.get("result") or {}
            ps.set_lib_pref(sid, synced_at=int(time.time()))
            if notify:
                _toast("%s 정리를 마쳤습니다: %d개" % (name, int(r.get("total") or 0)), ms=5000)
        else:
            _log("scan_failed sid=%s %s" % (sid, res.get("error", "")), xbmc.LOGWARNING)
            if notify:
                _toast("%s 스캔에 실패했습니다" % name, ms=5000)
        bump()
    threading.Thread(target=_watch, name="PKMMusicVideoScanWatch", daemon=True).start()
    return True


def _toast(msg, ms=3500):
    try:
        from resources.lib import pkm_notify
        pkm_notify.pkm_show_notice("뮤직비디오", msg, "", ms=ms)
        return
    except Exception:
        pass
    try:
        xbmcgui.Dialog().notification("PlexKM", msg, xbmcgui.NOTIFICATION_INFO, ms)
    except Exception:
        pass


# ------------------------------------------------------------------ 목록
def view_url(sid, view="", artist=""):
    q = {"action": "musicvideo", "source": sid}
    if view:
        q["view"] = view
    if artist != "":
        q["artist"] = artist
    return PLUGIN + "?" + urlencode(q)


def _thumb(full):
    return "image://video@%s/" % quote(full, safe="")


def _full(root, rel):
    return root + rel


def _art(root, it):
    imgs = it.get("images") or {}
    art = {}
    if imgs.get("thumb"):
        art["thumb"] = _full(root, imgs["thumb"])
    if imgs.get("poster"):
        art["poster"] = _full(root, imgs["poster"])
    if imgs.get("fanart"):
        art["fanart"] = _full(root, imgs["fanart"])
    if it.get("poster") and "poster" not in art:
        art["poster"] = it["poster"]
    if it.get("fanart"):
        art.setdefault("fanart", it["fanart"])
    if "thumb" not in art:
        art["thumb"] = art.get("poster") or _thumb(_full(root, it["path"]))
    art["icon"] = art["thumb"]
    return art


_CATS = (("mv", "뮤직비디오", ("mv",)), ("broadcast", "음악방송", ("broadcast",)),
         ("concert", "콘서트·공연", ("concert", "disc", "other")))


def _end(handle, items, content="musicvideos"):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def list_view(handle, sid, view="", artist=""):
    src = next((s for s in sources() if s.get("id") == sid), None)
    if src is None or not available():
        _end(handle, [])
        return
    root = _root(src)
    idx = _store().load(sid)
    items = idx.get("items", [])
    if not view:
        cats = [(v, t, [i for i in items if i["kind"] in kinds]) for v, t, kinds in _CATS]
        cats = [c for c in cats if c[2]]
        if len(cats) == 1:
            view = cats[0][0]
        else:
            rows = []
            for v, t, its in cats:
                li = xbmcgui.ListItem(label=t)
                li.setLabel2("%d" % len(its))
                li.setArt({"icon": "DefaultFolder.png"})
                rows.append((view_url(sid, v), li, True))
            _end(handle, rows, "files")
            return
    if view == "mv":
        mv = [i for i in items if i["kind"] == "mv"]
        if artist == "":
            _list_artists(handle, sid, root, mv)
        else:
            _list_artist_videos(handle, root, mv, artist)
    elif view == "broadcast":
        _list_broadcast(handle, root, [i for i in items if i["kind"] == "broadcast"])
    else:
        _list_concerts(handle, root, [i for i in items if i["kind"] in ("concert", "disc", "other")])


def _group_artists(mv):
    """같은 아티스트의 표기 차이(한글/영문 병기 순서, 영문만 등)를 하나로 묶는다. -> [{'name','items'}]"""
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    keys = []
    for it in mv:
        vs = _agent.parser.name_variants(it.get("artist", "")) or ["_"]
        for v in vs[1:]:
            parent[find(v)] = find(vs[0])
        keys.append(vs[0])
    groups = {}
    for it, k in zip(mv, keys):
        groups.setdefault(find(k), []).append(it)
    out = []
    for k, its in groups.items():
        names = {}
        for it in its:
            names[it.get("artist") or ""] = names.get(it.get("artist") or "", 0) + 1
        name = max(names.items(), key=lambda kv: (kv[1], -len(kv[0])))[0]
        out.append({"name": name, "items": its})
    out.sort(key=lambda g: (g["name"] == "", (g["name"] or "~").lower()))
    return out


def _list_artists(handle, sid, root, mv):
    rows = []
    for g in _group_artists(mv):
        li = xbmcgui.ListItem(label=g["name"] or "아티스트를 알 수 없음")
        li.setLabel2("%d" % len(g["items"]))
        li.setArt(_art(root, g["items"][0]))
        rows.append((view_url(sid, "mv", g["name"] or "-"), li, True))
    _end(handle, rows, "artists")


def _list_artist_videos(handle, root, mv, artist):
    name = "" if artist == "-" else artist
    sel = next((g["items"] for g in _group_artists(mv) if g["name"] == name), [])
    sel = sorted(sel, key=lambda i: (-(i.get("year") or 0), (i.get("title") or "").lower()))
    rows = []
    for it in sel:
        label = it.get("title") or os.path.basename(it["path"])
        tags = [t for t in (it.get("tags") or []) if t != "hq"]
        if tags:
            label += " (" + ", ".join(tags) + ")"
        li = xbmcgui.ListItem(label=label)
        li.setArt(_art(root, it))
        _tag(li, it, "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_broadcast(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("date") or "", i.get("path") or ""), reverse=True)
    rows = []
    for it in items:
        who = it.get("artist") or ""
        what = it.get("title") or os.path.basename(it["path"])
        li = xbmcgui.ListItem(label=("%s - %s" % (who, what)) if who else what)
        li.setLabel2(" ".join(x for x in (it.get("date"), it.get("show")) if x))
        li.setArt(_art(root, it))
        _tag(li, it, "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_concerts(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("title") or "").lower())
    rows = []
    for it in items:
        li = xbmcgui.ListItem(label=it.get("title") or os.path.basename(it["path"]))
        if it.get("year"):
            li.setLabel2(str(it["year"]))
        li.setArt(_art(root, it))
        _tag(li, it, "video")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows, "videos")


def _tag(li, it, mediatype):
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        tag.setTitle(it.get("title") or "")
        if it.get("artist") and mediatype == "musicvideo":
            try:
                tag.setArtists([it["artist"]])
            except Exception:
                pass
        if it.get("year"):
            tag.setYear(int(it["year"]))
        if it.get("album"):
            try:
                tag.setAlbum(it["album"])
            except Exception:
                pass
        if it.get("plot"):
            tag.setPlot(it["plot"])
        if it.get("genre"):
            tag.setGenres(list(it["genre"]) if isinstance(it["genre"], (list, tuple)) else [it["genre"]])
        if it.get("duration"):
            tag.setDuration(int(it["duration"]))
    except Exception:
        _log("tag_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
