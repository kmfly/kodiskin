# -*- coding: utf-8 -*-
"""Lightweight entry point for PKM quick seek keymap.

This file is intentionally tiny.  FullscreenVideo LEFT/RIGHT launches this
script instead of the heavy default.py router, so the quick-seek property is set
as early as possible and the full VideoOSD is suppressed quickly.
"""
from __future__ import absolute_import, unicode_literals

import sys
import traceback

import xbmc

ADDON_ID = "plugin.video.km"


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][seek_quick] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _parse_args(argv):
    params = {}
    for arg in argv[1:]:
        if arg is None:
            continue
        text = str(arg)
        if text.startswith('?'):
            text = text[1:]
        for part in text.split('&'):
            part = part.strip()
            if not part:
                continue
            if '=' in part:
                k, v = part.split('=', 1)
                params[k.strip()] = v.strip()
            else:
                params[part.strip()] = '1'
    return params


def main():
    params = _parse_args(sys.argv)
    try:
        import pkm_seek_quick
        if str(params.get("mode", "")).lower() in ("preread", "pre_read", "cache", "precache") or str(params.get("preread", "")) == "1":
            _log("PKM_MANUAL_PREREAD_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
            pkm_seek_quick.manual_preread(params)
            return

        if params.get("menu") or params.get("step_menu"):
            _log("PKM_SEEK_STEP_MENU_ENTRY_DISPATCH_V1460 params=%s argv=%s" % (params, sys.argv))
            if hasattr(pkm_seek_quick, "show_step_menu"):
                pkm_seek_quick.show_step_menu(params)
            return

        if params.get("key") or params.get("action"):
            _log("PKM_PLAYER_KEY_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
            pkm_seek_quick.handle_player_key(params)
            return

        # Seek-only path: keep VideoOSD from staying on top if Kodi opened it
        # for a fullscreen arrow key.  Do not close the real VideoOSD when the
        # request came from a VideoOSD button; buttons must remain alive after
        # quick seek and long jump clicks.
        if str(params.get("use_videoosd", "")) != "1":
            try:
                xbmc.executebuiltin('Dialog.Close(videoosd,true)')
            except Exception:
                pass
        _log("PKM_SEEK_QUICK_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
        pkm_seek_quick.request(params)
    except Exception:
        _log("PKM_SEEK_QUICK_ENTRY_FAILED params=%s\n%s" % (params, traceback.format_exc()), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
