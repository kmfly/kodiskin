# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import os
import sys
import random
import socket
import struct
import threading
import time
import traceback
import zlib
import json
import uuid
import xml.etree.ElementTree as ET
try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qs, urlparse, urlencode, quote
    from urllib.request import Request, urlopen
except Exception:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from urlparse import parse_qs, urlparse
    from urllib import urlencode, quote
    from urllib2 import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon(id="plugin.video.km")
ADDON_PATH = ADDON.getAddonInfo("path")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

# The bundled qrcode package uses absolute imports (``qrcode.*``).
# v1689: Kodi can retain another add-on's partially imported ``qrcode`` module
# in sys.modules.  Merely adding our vendor directory to sys.path is then not
# enough and QR generation silently becomes unavailable.  Always place our
# vendor path first and discard only foreign qrcode modules before importing.
_VENDOR_PATH = os.path.join(ADDON_PATH, "resources", "lib", "vendor")
try:
    while _VENDOR_PATH in sys.path:
        sys.path.remove(_VENDOR_PATH)
except Exception:
    pass
sys.path.insert(0, _VENDOR_PATH)
try:
    _loaded_qr = sys.modules.get("qrcode")
    _loaded_qr_file = os.path.abspath(getattr(_loaded_qr, "__file__", "") or "") if _loaded_qr else ""
    if _loaded_qr and not _loaded_qr_file.startswith(os.path.abspath(_VENDOR_PATH) + os.sep):
        for _name in list(sys.modules):
            if _name == "qrcode" or _name.startswith("qrcode."):
                try:
                    del sys.modules[_name]
                except Exception:
                    pass
    import qrcode
    if not hasattr(qrcode, "QRCode"):
        raise ImportError("bundled qrcode.QRCode missing")
except Exception:
    qrcode = None
    _QR_IMPORT_ERROR = traceback.format_exc().replace("\n", " | ")
else:
    _QR_IMPORT_ERROR = ""


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Plex KM] %s" % message, level)
    except Exception:
        pass


def _local_ip():
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    finally:
        try:
            if sock:
                sock.close()
        except Exception:
            pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    return "127.0.0.1"


def _png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def _write_qr_png(text, path, scale=8, border=4):
    if qrcode is None:
        return False
    qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=1, border=0)
    qr.add_data(text)
    qr.make(fit=True)
    matrix = qr.get_matrix()
    size = len(matrix)
    width = (size + border * 2) * scale
    rows = []
    for y in range(-border, size + border):
        row = bytearray([0])
        for x in range(-border, size + border):
            black = 0 <= y < size and 0 <= x < size and matrix[y][x]
            value = 0 if black else 255
            row.extend([value] * scale)
        expanded = bytes(row)
        for _ in range(scale):
            rows.append(expanded)
    raw = b"".join(rows)
    data = b"\x89PNG\r\n\x1a\n"
    data += _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, width, 8, 0, 0, 0, 0))
    data += _png_chunk(b"IDAT", zlib.compress(raw, 9))
    data += _png_chunk(b"IEND", b"")
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "wb") as handle:
        handle.write(data)
    return True



PLEX_PIN_CREATE_URL = "https://plex.tv/pins.xml"
PLEX_PIN_POLL_URL = "https://plex.tv/pins/{pin_id}.xml"
PLEX_PIN_LINK_URL = "https://plex.tv/link"
PLEX_PRODUCT = "PKM"
PLEX_VERSION = "0.3.331"


def _client_identifier():
    value = (ADDON.getSetting("plex_client_identifier") or "").strip()
    if value:
        return value
    value = "pkm-" + uuid.uuid4().hex
    try:
        ADDON.setSetting("plex_client_identifier", value)
    except Exception:
        pass
    return value


def _plex_headers(client_id):
    return {
        "Accept": "application/json",
        "X-Plex-Product": PLEX_PRODUCT,
        "X-Plex-Version": PLEX_VERSION,
        "X-Plex-Client-Identifier": client_id,
        "X-Plex-Platform": "Kodi",
        "X-Plex-Device": "Android TV",
    }


def _xml_request(url, headers, data=None, timeout=12):
    """PlexKodiConnect 방식과 동일한 XML PIN API 요청."""
    payload = data.encode("utf-8") if isinstance(data, str) else data
    req = Request(url, data=payload, headers=headers)
    response = urlopen(req, timeout=timeout)
    raw = response.read()
    return ET.fromstring(raw)


class _ReusableHTTPServer(HTTPServer):
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        _log("PKM_TOKEN_IMPORT_HANDLER_ERROR client=%s error=%s" % (
            client_address,
            traceback.format_exc().replace("\n", " | ")
        ), xbmc.LOGERROR)


class TokenImportSession(object):
    def __init__(self):
        self.code = "%06d" % random.randint(0, 999999)
        self.ip = _local_ip()
        self.port = 0
        # v1735: publish the fixed Plex Link URL immediately so the dialog can
        # paint before the network PIN request completes.
        self.url = PLEX_PIN_LINK_URL
        self.qr_path = os.path.join(PROFILE, "token_import_qr.png")
        self.server = None
        self.thread = None
        self.dialog = None
        self.saved = threading.Event()
        self.ready = threading.Event()
        self.stop_requested = threading.Event()
        self.error = ""
        self.client_id = _client_identifier()
        self.pin_id = 0
        self.pin_code = ""
        self.plex_auth_url = ""
        self.poll_thread = None
        self.prepare_thread = None
        self.pending_token = ""
        self.account_name = ""

    def _create_plex_pin(self):
        # PlexKodiConnect resources/lib/plex_tv.py PinLogin 방식:
        # POST https://plex.tv/pins.xml -> <pin><id/><code/></pin>
        headers = _plex_headers(self.client_id)
        headers["Accept"] = "application/xml"
        result = _xml_request(PLEX_PIN_CREATE_URL, headers, data=b"")
        pin_id = result.findtext("id")
        pin_code = result.findtext("code")
        self.pin_id = int((pin_id or "0").strip())
        self.pin_code = (pin_code or "").strip()
        if not self.pin_id or not self.pin_code:
            raise RuntimeError("invalid Plex XML PIN response")
        self.plex_auth_url = PLEX_PIN_LINK_URL
        _log("PKM_PLEX_PIN_CREATED_LEGACY id=%s pin=%s" % (self.pin_id, self.pin_code), xbmc.LOGINFO)

    def _poll_plex_pin(self):
        # PlexKodiConnect와 동일하게 /pins/{id}.xml의 auth_token을 조회한다.
        headers = _plex_headers(self.client_id)
        headers["Accept"] = "application/xml"
        url = PLEX_PIN_POLL_URL.format(pin_id=self.pin_id)
        while not self.stop_requested.is_set() and not self.saved.is_set():
            try:
                result = _xml_request(url, headers, timeout=10)
                token = (result.findtext("auth_token") or "").strip()
                if token:
                    self.pending_token = token
                    self.saved.set()
                    _log("PKM_PLEX_PIN_AUTHORIZED_V1726 token_received=1 ui_close=main_thread", xbmc.LOGINFO)
                    # v1726: never close a Kodi WindowXMLDialog from the polling
                    # worker.  Background-thread close calls can pop the modal
                    # stack before Kodi restores focus, leaving the next Plex Home
                    # user chooser with no focused control.  run_token_import()
                    # observes saved and closes this dialog from its owning thread.
                    return
            except Exception as exc:
                _log("PKM_PLEX_PIN_POLL_RETRY_LEGACY error=%s" % exc, xbmc.LOGWARNING)
            self.stop_requested.wait(1.0)

    def _prepare_async_v1735(self):
        """Create the Plex PIN and QR without blocking the Kodi dialog paint."""
        try:
            self._create_plex_pin()
        except Exception:
            self.error = "plex_pin_create_failed"
            self.ready.set()
            _log("PKM_PLEX_PIN_CREATE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
            return

        if self.stop_requested.is_set():
            self.ready.set()
            _log("PKM_TOKEN_IMPORT_PREPARE_CANCELLED_V1735 stage=after_pin", xbmc.LOGINFO)
            return

        # v1672: QR and displayed URL point directly to Plex Link.
        # No local HTTP bridge, LAN address, or Android-emulator port is needed.
        try:
            if not _write_qr_png(self.url, self.qr_path):
                _log("PKM_TOKEN_IMPORT_QR_GENERATOR_UNAVAILABLE_V1689 import_error=%s" % (_QR_IMPORT_ERROR or "unknown"), xbmc.LOGERROR)
            else:
                _log("PKM_TOKEN_IMPORT_QR_GENERATED_V1689 path=%s bytes=%d" % (self.qr_path, os.path.getsize(self.qr_path)), xbmc.LOGINFO)
        except Exception:
            _log("PKM_TOKEN_IMPORT_QR_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

        if self.stop_requested.is_set():
            try:
                if os.path.exists(self.qr_path):
                    os.remove(self.qr_path)
            except Exception:
                pass
            self.ready.set()
            _log("PKM_TOKEN_IMPORT_PREPARE_CANCELLED_V1735 stage=after_qr", xbmc.LOGINFO)
            return

        self.poll_thread = threading.Thread(target=self._poll_plex_pin, name="PKMPlexPinPoll", daemon=True)
        self.poll_thread.daemon = True
        self.poll_thread.start()
        self.ready.set()
        _log("PKM_TOKEN_IMPORT_STARTED ip=%s port=%d code_enabled=1 mode=plex_pin async_prepare=1" % (self.ip, self.port), xbmc.LOGINFO)

    def start_async_v1735(self):
        self.prepare_thread = threading.Thread(target=self._prepare_async_v1735, name="PKMPlexPinPrepare", daemon=True)
        self.prepare_thread.daemon = True
        self.prepare_thread.start()
        _log("PKM_TOKEN_IMPORT_PREPARE_ASYNC_V1735 dialog_can_paint=1", xbmc.LOGINFO)
        return True

    def stop(self):
        self.stop_requested.set()
        try:
            if self.server:
                self.server.shutdown()
                self.server.server_close()
        except Exception:
            pass
        self.server = None
        try:
            if os.path.exists(self.qr_path):
                os.remove(self.qr_path)
        except Exception:
            pass
        _log("PKM_TOKEN_IMPORT_STOPPED saved=%s" % ("1" if self.saved.is_set() else "0"), xbmc.LOGINFO)


class TokenImportDialog(xbmcgui.WindowXMLDialog):
    CLOSE_ID = 10
    QR_ID = 20

    def __init__(self, *args, **kwargs):
        self.session = kwargs.pop("session")
        self.cancelled_v1726 = False
        self.initialized_v1735 = False
        super(TokenImportDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        self.session.dialog = self
        self.setProperty("PKM.TokenImport.Ready", "0")
        self.setProperty("PKM.TokenImport.URL", self.session.url)
        self.setProperty("PKM.TokenImport.Code", "")
        self.setProperty("PKM.TokenImport.QR", "")
        self.initialized_v1735 = True
        try:
            self.setFocusId(self.CLOSE_ID)
        except Exception:
            pass
        _log("PKM_TOKEN_IMPORT_DIALOG_PAINTED_IMMEDIATE_V1735 ready=0", xbmc.LOGINFO)

    def apply_ready_state_v1735(self):
        """Publish PIN/QR from the dialog-owning thread after async prepare."""
        self.setProperty("PKM.TokenImport.URL", self.session.url)
        self.setProperty("PKM.TokenImport.Code", self.session.pin_code)
        qr_path = self.session.qr_path if os.path.exists(self.session.qr_path) else ""
        self.setProperty("PKM.TokenImport.QR", qr_path)
        # v1665: Android/Kodi can resolve an image path property before the
        # generated file is visible to the texture loader and cache the empty
        # result. Set the image control directly on the owning thread.
        if qr_path:
            try:
                self.getControl(self.QR_ID).setImage(qr_path, False)
                _log("PKM_TOKEN_IMPORT_QR_SHOWN bytes=%d" % os.path.getsize(qr_path), xbmc.LOGINFO)
            except Exception:
                _log("PKM_TOKEN_IMPORT_QR_CONTROL_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        else:
            _log("PKM_TOKEN_IMPORT_QR_MISSING", xbmc.LOGWARNING)
        self.setProperty("PKM.TokenImport.Ready", "1")
        _log("PKM_TOKEN_IMPORT_DIALOG_READY_V1735 pin_ready=1 qr=%s" % ("1" if qr_path else "0"), xbmc.LOGINFO)

    def onClick(self, control_id):
        audit_event(self, "onClick", control_id=control_id)
        if control_id == self.CLOSE_ID:
            self.cancelled_v1726 = True
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        if action.getId() in (9, 10, 92, 216, 247):
            self.cancelled_v1726 = True
            self.close()


def _account_name(token):
    try:
        headers = _plex_headers(_client_identifier())
        headers["Accept"] = "application/xml"
        headers["X-Plex-Token"] = token
        root = _xml_request("https://plex.tv/users/account", headers, timeout=12)
        return (root.get("username") or root.get("title") or root.get("email") or "").strip()
    except Exception:
        _log("PKM_PLEX_ACCOUNT_READ_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return ""


class PKMPlexHomeUserDialog(xbmcgui.WindowXMLDialog):
    """Credits-style Plex Home user selector.

    v1727 deliberately uses the same 282px horizontal slot, 248px idle
    portrait, 294px centre expansion and 280px white focus ring as the movie
    Credits rail.  Kodi owns left/right navigation; Python only supplies items,
    centres short rows and returns the item activated with Enter.
    """
    PANEL_ID = 200
    SLOT_WIDTH = 282
    VIEW_WIDTH = 1760

    def __init__(self, *args, **kwargs):
        self.users = list(kwargs.pop("users", []) or [])
        self.result = None
        self._panel = None
        super(PKMPlexHomeUserDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        try:
            self.setProperty("PlexKM.PlexUser.Title", "Plex 사용자 선택")
            try:
                from resources.lib import pkm_notify
                notice_token_v2045 = xbmcgui.Window(10000).getProperty("PlexKM.Auth.UserChooserNoticeTokenV2045") or ""
                if notice_token_v2045:
                    pkm_notify.pkm_notice_clear(expected_token=notice_token_v2045, force=True)
                    xbmcgui.Window(10000).clearProperty("PlexKM.Auth.UserChooserNoticeTokenV2045")
                    _log("PKM_USER_CHOOSER_NOTICE_CLEAR_V2045 token=%s" % notice_token_v2045, xbmc.LOGINFO)
            except Exception:
                pass
            self.setProperty("PlexKM.PlexUser.Hint", "좌우 이동  /  Enter 선택  /  뒤로")
            self._panel = self.getControl(self.PANEL_ID)
            self._panel.reset()
            placeholder = (
                "special://home/addons/plugin.video.km/resources/skins/Default/"
                "media/info/cast/cast-placeholder-circle.png"
            )
            items = []
            for idx, user in enumerate(self.users):
                name = (user.get("title") or user.get("username") or "Plex 사용자").strip()
                li = xbmcgui.ListItem(label=name)
                li.setProperty("PlexKM.User.Index", str(idx))
                li.setProperty("PlexKM.User.Name", name)
                li.setProperty("PlexKM.User.Thumb", placeholder)
                li.setProperty("PlexKM.User.Protected", "1" if user.get("protected") == "1" else "0")
                items.append(li)
            self._panel.addItems(items)

            count = max(1, len(items))
            if count <= 3:
                width = self.SLOT_WIDTH * count
                left = int((1920 - width) / 2)
            else:
                width = self.VIEW_WIDTH
                left = int((1920 - width) / 2)
            try:
                self._panel.setPosition(left, 350)
                self._panel.setWidth(width)
            except Exception:
                _log("PKM_PLEX_HOME_USER_GEOMETRY_APPLY_FAILED_V1727 %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            try:
                self._panel.selectItem(0)
            except Exception:
                pass
            try:
                self.setFocus(self._panel)
            except Exception:
                try:
                    self.setFocusId(self.PANEL_ID)
                except Exception:
                    pass
            _log(
                "PKM_PLEX_HOME_USER_CREDITS_READY_V1727 users=%d left=%d width=%d first=0" %
                (len(items), left, width),
                xbmc.LOGINFO,
            )
        except Exception:
            _log("PKM_PLEX_HOME_USER_DIALOG_INIT_FAILED_V1727 %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
            self.result = None
            self.close()

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId != self.PANEL_ID:
            return
        try:
            pos = int(self._panel.getSelectedPosition()) if self._panel else -1
        except Exception:
            pos = -1
        self.result = pos if 0 <= pos < len(self.users) else None
        _log("PKM_PLEX_HOME_USER_CREDITS_ENTER_V1727 choice=%s" % self.result, xbmc.LOGINFO)
        self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        if action.getId() in (9, 10, 92, 216, 247):
            self.result = None
            self.close()


def _select_home_user(owner_token):
    """Show every Plex Home user in the Credits-style rail and switch on Enter."""
    headers = _plex_headers(_client_identifier())
    headers["Accept"] = "application/xml"
    headers["X-Plex-Token"] = owner_token
    try:
        root = _xml_request("https://plex.tv/api/home/users/", headers, timeout=12)
        users = list(root)
    except Exception:
        _log("PKM_PLEX_HOME_USERS_READ_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return owner_token, _account_name(owner_token)

    # Keep the selector visible even for one account, as requested.  A rare
    # empty response is represented by the authenticated owner so the same
    # one-item Credits interaction remains available.
    if not users:
        users = [{
            "id": "",
            "title": _account_name(owner_token) or "Plex",
            "username": "",
            "protected": "0",
            "admin": "1",
            "_pkm_owner_direct": "1",
        }]

    user_dlg = None
    try:
        user_dlg = PKMPlexHomeUserDialog(
            "plexkm_plex_home_user_select.xml",
            ADDON_PATH,
            "Default",
            "1080i",
            users=users,
        )
        _log(
            "PKM_PLEX_HOME_USER_DIALOG_OPEN_V1727 class=PKMPlexHomeUserDialog xml=plexkm_plex_home_user_select.xml users=%d" % len(users),
            xbmc.LOGINFO,
        )
        user_dlg.doModal()
        choice = user_dlg.result
        _log("PKM_PLEX_HOME_USER_DIALOG_RESULT_V1727 choice=%s" % choice, xbmc.LOGINFO)
    except Exception:
        _log("PKM_PLEX_HOME_USER_DIALOG_FAILED_V1727\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Plex 사용자 선택",
            "PKM 사용자 선택창을 열지 못했습니다.\nKodi 로그의 PKM_PLEX_HOME_USER_DIALOG_FAILED_V1727 항목을 확인해주세요.",
        )
        return "", ""
    finally:
        try:
            del user_dlg
        except Exception:
            pass

    if choice is None or int(choice) < 0:
        return "", ""
    user = users[int(choice)]
    user_id = (user.get("id") or "").strip()
    name = (user.get("title") or user.get("username") or "").strip()
    pin = ""
    if user.get("protected") == "1":
        pin = xbmcgui.Dialog().numeric(0, "%s 홈 사용자 PIN" % name) or ""
        if not pin:
            return "", ""

    # The authenticated owner already has the correct token.  This also covers
    # the synthetic one-user fallback where the home endpoint returned no row.
    if user.get("_pkm_owner_direct") == "1" or (user.get("admin") == "1" and not pin):
        _log("PKM_PLEX_HOME_USER_OWNER_TOKEN_REUSE_V1727 name=%s" % name, xbmc.LOGINFO)
        return owner_token, name or _account_name(owner_token)

    if not user_id:
        return owner_token, name or _account_name(owner_token)
    url = "https://plex.tv/api/home/users/%s/switch" % quote(user_id, safe="")
    if pin:
        url += "?" + urlencode({"pin": pin})
    switch_headers = _plex_headers(_client_identifier())
    switch_headers["Accept"] = "application/xml"
    switch_headers["X-Plex-Token"] = owner_token
    try:
        result = _xml_request(url, switch_headers, data=b"", timeout=12)
        switched = (result.get("authenticationToken") or result.get("authToken") or "").strip()
        if not switched:
            raise RuntimeError("home user token missing")
        _log("PKM_PLEX_HOME_USER_SWITCH_OK_V1727 name=%s" % name, xbmc.LOGINFO)
        return switched, name
    except Exception:
        _log("PKM_PLEX_HOME_USER_SWITCH_FAILED_V1727 %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Plex 사용자 선택", "선택한 Plex 사용자로 전환하지 못했습니다.\nPIN을 확인한 후 다시 시도해주세요.")
        return "", ""



def _show_auth_verified_notice_v2045(owner_token):
    """Publish a bounded two-line transition notice until the user chooser opens."""
    owner_name = _account_name(owner_token) or "Plex"
    notice_token = ""
    try:
        from resources.lib import pkm_notify
        notice_token = pkm_notify.pkm_notice_set(
            "Plex 계정 확인",
            "Plex 계정이 확인되었습니다.",
            "사용자 선택으로 이동합니다",
            sticky=False,
            force_replace=True,
        )
        xbmcgui.Window(10000).setProperty("PlexKM.Auth.UserChooserNoticeTokenV2045", str(notice_token or ""))
    except Exception:
        try:
            xbmcgui.Dialog().notification(
                "Plex 계정 확인",
                "Plex 계정이 확인되었습니다.",
                xbmcgui.NOTIFICATION_INFO,
                2200,
            )
        except Exception:
            pass
    _log("PKM_TOKEN_AUTH_VERIFIED_NOTICE_V2045 account=%s token=%s" % (owner_name, notice_token), xbmc.LOGINFO)
    return owner_name

def run_token_import():
    _log("PKM_PATCH_ACTIVE v1735 immediate_token_dialog_async_pin_prepare", xbmc.LOGINFO)
    session = TokenImportSession()
    dlg = None
    try:
        dlg = TokenImportDialog("plexkm_token_import.xml", ADDON_PATH, "Default", "1080i", session=session)
        # v1735: schedule the Plex PIN request on a worker and paint the dialog
        # immediately.  The owning plugin thread alone updates Kodi controls.
        session.start_async_v1735()
        dlg.show()
        monitor = xbmc.Monitor()
        ready_applied_v1735 = False
        while not session.saved.is_set() and not bool(getattr(dlg, "cancelled_v1726", False)):
            if session.ready.is_set() and bool(getattr(dlg, "initialized_v1735", False)) and not ready_applied_v1735:
                if session.error:
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    xbmc.sleep(80)
                    xbmcgui.Dialog().ok("Plex 토큰 인증", "Plex 로그인 준비에 실패했습니다.\n인터넷 연결을 확인해주세요.")
                    return False
                dlg.apply_ready_state_v1735()
                ready_applied_v1735 = True
            if monitor.waitForAbort(0.05):
                return False
        if bool(getattr(dlg, "cancelled_v1726", False)):
            return False
        if session.error or not session.saved.is_set() or not session.pending_token:
            return False
        try:
            dlg.close()
        except Exception:
            pass
        xbmc.sleep(220)

        # Required order: link authorization -> finite confirmation -> Plex Home
        # user selection -> save selected token -> settings library chooser.
        owner_name = _show_auth_verified_notice_v2045(session.pending_token)
        final_token, account_name = _select_home_user(session.pending_token)
        if not final_token:
            return False
        account_name = account_name or owner_name or _account_name(final_token)
        ADDON.setSetting("plex_token", final_token)
        ADDON.setSetting("plex_account_name", account_name)
        verified = (ADDON.getSetting("plex_token") or "").strip() == final_token
        _log("PKM_PLEX_TOKEN_MAIN_THREAD_SAVE_V1726 verified=%s account=%s" % ("1" if verified else "0", account_name), xbmc.LOGINFO)
        if not verified:
            xbmcgui.Dialog().ok("Plex 토큰 인증", "토큰 저장 확인에 실패했습니다. 다시 시도해주세요.")
            return False
        try:
            from resources.lib import pkm_notify
            library_notice_token_v2045 = pkm_notify.pkm_notice_set(
                "사용자 선택 완료",
                "사용자 선택이 완료되었습니다.",
                "라이브러리 선택으로 이동합니다",
                sticky=False,
                force_replace=True,
            )
            xbmcgui.Window(10000).setProperty("PlexKM.Auth.LibraryChooserNoticeTokenV2045", str(library_notice_token_v2045 or ""))
            _log("PKM_USER_SELECTED_LIBRARY_NOTICE_V2045 account=%s token=%s" % (account_name, library_notice_token_v2045), xbmc.LOGINFO)
        except Exception:
            pass
        return True
    except Exception:
        _log("PKM_TOKEN_IMPORT_DIALOG_FAILED_V1726 %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False

    finally:
        session.stop()
        try:
            del dlg
        except Exception:
            pass
