# -*- coding: utf-8 -*-
"""PKM home window part (R73): 배우 페이지/출연진/위키 소개.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartActorR73
    def _startup_all_sidebar_cast_images_r63(self):
        """R64: prepare portraits for the first visible items of EVERY widget row.

        Covers off-screen rows reached by vertical scrolling, not only the first
        two recommendation rows. Reads already built ListItems; never scans the
        full Plex catalogue or modifies GUI controls from this worker.
        """
        try:
            sections = [sec for sec in list(getattr(self, 'sections', []) or [])
                        if isinstance(sec, dict)]
            prebuilt = getattr(self, '_section_prebuilt_listitems_v1644', {}) or {}
            library_prebuilt = getattr(self, '_library_prebuilt_listitems_v2470', {}) or {}
            lib_states = getattr(self, '_section_last_library_state_by_sid_v2471', {}) or {}
            urls = set()
            portrait_bindings = []
            destinations = items_checked = widget_rows = 0
            expected_rows = 0
            unresolved_portrait_slots = 0
            for sec in sections:
                if self._closing_event_v1841.is_set():
                    return False
                sid = str(sec.get('section_id') or sec.get('key') or '').strip()
                if not sid:
                    continue
                groups = list(prebuilt.get('recommend:%s' % sid) or [])
                expected_rows += len(groups)
                # Every row, including those below the initial vertical viewport.
                # Limit the *horizontal* first viewport per row, not row count.
                for group in groups:
                    lis = list(group or [])[:10]
                    if not lis:
                        # An empty source row is not an image preparation failure;
                        # it is a legitimate empty widget, but still accounted for.
                        widget_rows += 1
                        continue
                    widget_rows += 1
                    destinations += 1
                    for li in lis:
                        items_checked += 1
                        for idx in range(1, 9):
                            if not str(li.getProperty('PlexKM.Cast%d.Name' % idx) or '').strip():
                                continue
                            url = str(li.getProperty('PlexKM.Cast%d.OriginalThumb' % idx)
                                      or li.getProperty('PlexKM.Cast%d.Thumb' % idx) or '').strip()
                            if url.startswith(('http://', 'https://')):
                                urls.add(url)
                                portrait_bindings.append((li, idx, url))
                            elif not url:
                                # An absent Plex portrait is a legitimate no-photo slot.
                                pass
                state = lib_states.get(sid) or {}
                lib_key = str(state.get('cache_key') or '') if isinstance(state, dict) else ''
                lib_limit = max(1, int(self._library_wall_viewport_count_v1865() or 18))
                lib_items = list(library_prebuilt.get(lib_key) or [])[:lib_limit] if lib_key else []
                if lib_items:
                    destinations += 1
                for li in lib_items:
                    items_checked += 1
                    for idx in range(1, 9):
                        if not str(li.getProperty('PlexKM.Cast%d.Name' % idx) or '').strip():
                            continue
                        url = str(li.getProperty('PlexKM.Cast%d.OriginalThumb' % idx)
                                  or li.getProperty('PlexKM.Cast%d.Thumb' % idx) or '').strip()
                        if url.startswith(('http://', 'https://')):
                            urls.add(url)
                            portrait_bindings.append((li, idx, url))
            ready = failed = 0
            prepared_paths = {}
            for idx, url in enumerate(sorted(urls)):
                if self._closing_event_v1841.is_set():
                    return False
                try:
                    path = (self._existing_cast_cache_path(url)
                            or self._download_cast_thumb_to_cache(url, idx + 1))
                    if path:
                        prepared_paths[url] = path
                        ready += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1
            bound = 0
            # Only touch detached/prebuilt ListItems in this preparation worker.
            # Do not modify live Kodi controls or replace original Plex artwork.
            for li, idx, url in portrait_bindings:
                path = prepared_paths.get(url)
                if path:
                    try:
                        li.setProperty('PlexKM.Cast%d.LocalThumb' % idx, path)
                        bound += 1
                    except Exception:
                        failed += 1
            self._startup_actor_portraits_stats_r63 = {
                'destinations': destinations, 'widget_rows': widget_rows,
                'items': items_checked, 'requested': len(urls),
                'ready': ready, 'failed': failed, 'local_bound': bound,
                'binding_expected': len(portrait_bindings),
                'expected_rows': expected_rows, 'coverage_ok': bool(widget_rows == expected_rows and destinations >= len(sections) and bound == len(portrait_bindings)),
            }
            _log('R64_ALL_WIDGET_ROWS_CAST sections=%d rows=%d destinations=%d items=%d requested=%d ready=%d failed=%d' % (
                len(sections), widget_rows, destinations, items_checked, len(urls), ready, failed))
            return (failed == 0 and widget_rows == expected_rows
                    and destinations >= len(sections) and bound == len(portrait_bindings))
        except Exception:
            _log('R64_ALL_WIDGET_ROWS_CAST error=%s' % traceback.format_exc().replace(chr(10), ' | '), xbmc.LOGWARNING)
            return False

    def _startup_hydrate_actor_caches_v2480(self, reason=""):
        """Load only already-persisted actor caches during startup.

        This is intentionally disk-only.  PKM must not enumerate every person in
        the library or call TMDb Helper during startup: one unseen actor can cost
        several seconds and a whole-library person prewarm would make startup
        unbounded.  Previously visited actor pages/profile records are cheap to
        hydrate here so their first post-restart open stays on the prepared path.
        """
        started = time.time()
        page_entries = 0
        profile_entries = 0
        try:
            page_cache = self._actor_page_prepared_cache_load_v2467()
            page_entries = len(page_cache or {}) if isinstance(page_cache, dict) else 0
        except Exception:
            page_entries = 0
        try:
            path = self._actor_profile_cache_path_v2454()
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                entries = dict((payload or {}).get("entries") or {}) if isinstance(payload, dict) else {}
                now = time.time()
                mem = getattr(self, "_actor_profile_memory_cache_v2454", None)
                if not isinstance(mem, dict):
                    mem = {}
                    self._actor_profile_memory_cache_v2454 = mem
                for key, rec in entries.items():
                    if not isinstance(rec, dict):
                        continue
                    profile = dict(rec.get("profile") or {})
                    ts = float(rec.get("ts") or 0.0)
                    if not profile.get("tmdb_id") or ts <= 0:
                        continue
                    # v2539: do not hydrate legacy profiles whose Actor Page
                    # portrait still follows the parent cast image / primary art.
                    # They are lazily rebuilt on actor focus/click with the restored
                    # TMDb Person Images alternative policy.
                    if int(profile.get("portrait_policy_version_v2539") or 0) < 2539:
                        continue
                    ttl = 604800.0 if profile.get("biography") else 1800.0
                    if max(0.0, now - ts) > ttl:
                        continue
                    mem[str(key)] = {"ts": ts, "profile": profile}
                    profile_entries += 1
        except Exception:
            profile_entries = 0
        _log("ACTOR_PAGE_STARTUP_HYDRATE_V2480 pages=%d profiles=%d disk_only=1 network=0 native=0 elapsed_ms=%d reason=%s" % (
            page_entries, profile_entries, int((time.time() - started) * 1000.0), reason or ""
        ))
        return page_entries

    def _actor_page_prepared_cache_load_v2467(self):
        cache = getattr(self, "_actor_page_prepared_cache_v2467", None)
        if isinstance(cache, dict):
            return cache
        cache = {}
        path = self._derived_cache_path_v2467("actor_page_prepared_cache_v2468.json")
        try:
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                if isinstance(payload, dict): cache = dict(payload.get("entries") or {})
        except Exception:
            cache = {}
        self._actor_page_prepared_cache_v2467 = cache
        return cache

    def _actor_page_prepared_key_v2467(self, actor_name, current_rating_key=""):
        """Stable actor identity for the persistent prepared page.

        Prefer Plex person tag_id so the same actor is warm across different
        movies/shows while same-name people cannot share a prepared page.  This
        is a local DB-only lookup; no Plex/TMDb I/O is introduced on click.
        """
        actor_norm = " ".join(str(actor_name or "").strip().casefold().split())
        if not actor_norm:
            return ""
        source_rk = str(current_rating_key or "").strip()
        dbp = self._profile_db_path()
        try:
            if dbp and os.path.exists(dbp):
                conn = sqlite3.connect(dbp, timeout=1.0)
                try:
                    cur = conn.cursor()
                    canonical_rk = source_rk
                    if canonical_rk:
                        src = cur.execute(
                            "SELECT plex_type,parent_rating_key,grandparent_rating_key "
                            "FROM items WHERE rating_key=? LIMIT 1",
                            (canonical_rk,)
                        ).fetchone()
                        if src:
                            ptype = str(src[0] or "").strip().lower()
                            if ptype == "episode":
                                canonical_rk = str(src[2] or src[1] or canonical_rk).strip()
                            elif ptype == "season":
                                canonical_rk = str(src[1] or canonical_rk).strip()
                    tag_id = ""
                    if canonical_rk:
                        row = cur.execute(
                            "SELECT IFNULL(tag_id,'') FROM item_people "
                            "WHERE rating_key=? AND person_type='actor' AND person_name=? "
                            "ORDER BY IFNULL(sort_order,999) ASC LIMIT 1",
                            (canonical_rk, str(actor_name or "").strip())
                        ).fetchone()
                        if row:
                            tag_id = str(row[0] or "").strip()
                    if not tag_id:
                        tags = cur.execute(
                            "SELECT DISTINCT IFNULL(tag_id,'') FROM item_people "
                            "WHERE person_type='actor' AND person_name=? AND IFNULL(tag_id,'')<>'' LIMIT 2",
                            (str(actor_name or "").strip(),)
                        ).fetchall()
                        tags = [str(r[0] or "").strip() for r in (tags or []) if str(r[0] or "").strip()]
                        if len(tags) == 1:
                            tag_id = tags[0]
                    if tag_id:
                        return "tag:%s|name:%s" % (tag_id, actor_norm)
                    if canonical_rk:
                        # Ambiguous/no-tag fallback is context-bound rather than
                        # risking a same-name actor collision.
                        return "namectx:%s|%s" % (actor_norm, canonical_rk)
                finally:
                    conn.close()
        except Exception:
            pass
        return "name:%s" % actor_norm

    def _actor_profile_metadata_ready_v2611(self, profile):
        """True only when actor identity was actually resolved beyond local-first data."""
        try:
            profile = dict(profile or {})
            if bool(profile.get("_v2599_provisional")):
                return False
            return bool(str(profile.get("tmdb_id") or "").strip())
        except Exception:
            return False

    def _actor_profile_metadata_needs_enrich_v2611(self, profile):
        try:
            return not self._actor_profile_metadata_ready_v2611(profile)
        except Exception:
            return True

    def _actor_profile_publish_meta_kpi_v2611(self, actor_name, status, source="", profile=None):
        """Publish post-visible actor metadata completion without touching GUI controls."""
        try:
            actor_name = str(actor_name or "").strip()
            if not actor_name:
                return False
            visible_name = str(getattr(self, "_actor_profile_visible_name_v2610", "") or "").strip()
            if not visible_name or actor_name.casefold() != visible_name.casefold():
                return False
            visible_epoch = int(getattr(self, "_actor_profile_visible_epoch_ms_v2610", 0) or 0)
            elapsed = max(0, self._now_ms() - visible_epoch) if visible_epoch > 0 else 0
            profile = dict(profile or {})
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.KPI.ActorMetaStatus", str(status or ""))
            win.setProperty("PlexKM.KPI.ActorMetaReadyMs", str(int(elapsed)))
            win.setProperty("PlexKM.KPI.ActorMetaSource", str(source or profile.get("source") or ""))
            win.setProperty("PlexKM.KPI.ActorMetaTmdb", "1" if str(profile.get("tmdb_id") or "").strip() else "0")
            win.setProperty("PlexKM.KPI.ActorMetaHasBio", "1" if str(profile.get("biography") or "").strip() else "0")
            win.setProperty("PlexKM.KPI.ActorMetaHasBirthday", "1" if str(profile.get("birthday") or "").strip() else "0")
            if str(status or "").startswith("ready"):
                try:
                    structural = int(float(win.getProperty("PlexKM.KPI.ActorCompleteMs") or 0))
                except Exception:
                    structural = 0
                win.setProperty("PlexKM.KPI.ActorCompleteMs", str(max(structural, int(elapsed))))
            win.setProperty("PlexKM.KPI.ActorMetaStamp", str(self._now_ms()))
            _log("ACTOR_PROFILE_META_KPI_V2611 actor=%s status=%s meta_ready_ms=%d tmdb=%d bio=%d birthday=%d source=%s" % (
                _short_log_value(actor_name,80), status or "", int(elapsed),
                1 if str(profile.get("tmdb_id") or "").strip() else 0,
                1 if str(profile.get("biography") or "").strip() else 0,
                1 if str(profile.get("birthday") or "").strip() else 0,
                _short_log_value(source or profile.get("source") or "",100)
            ))
            return True
        except Exception:
            return False

    def _actor_page_session_ready_get_v2526(self, actor_name, current_rating_key="", max_age_s=300.0):
        """Return an in-session actor page without persistent authority I/O.

        Since V2599 the payload may be local-first/provisional so ActorProfile can
        open immediately. V2611 therefore keeps structural click-readiness separate
        from TMDb metadata readiness; callers must not treat session_ready as proof
        that identity/biography enrichment has completed.
        """
        try:
            key = self._actor_page_prepared_key_v2467(actor_name, current_rating_key)
            if not key:
                return None
            lock = getattr(self, "_actor_page_session_ready_lock_v2526", None)
            if lock is None:
                lock = threading.RLock()
                self._actor_page_session_ready_lock_v2526 = lock
            with lock:
                rec = dict((getattr(self, "_actor_page_session_ready_v2526", {}) or {}).get(key) or {})
            if not rec:
                return None
            age = max(0.0, time.time() - float(rec.get("ts") or 0.0))
            if age > float(max_age_s or 300.0):
                with lock:
                    try:
                        self._actor_page_session_ready_v2526.pop(key, None)
                    except Exception:
                        pass
                return None
            payload = {
                "profile": dict(rec.get("profile") or {}),
                "movie": list(rec.get("movie") or []),
                "show": list(rec.get("show") or []),
                "local_thumb": str(rec.get("local_thumb") or ""),
                "session_ready_v2526": 1,
                "metadata_ready_v2611": 1 if self._actor_profile_metadata_ready_v2611(rec.get("profile") or {}) else 0,
            }
            _log("ACTOR_PAGE_SESSION_READY_HIT_V2526 actor=%s age_ms=%d movies=%d tv=%d persistent_authority_io=0" % (
                _short_log_value(actor_name,80), int(age * 1000.0), len(payload["movie"]), len(payload["show"])
            ))
            return payload
        except Exception:
            return None

    def _actor_page_session_ready_put_v2526(self, actor_name, current_rating_key, profile, movie_rows, tv_rows, local_thumb="", source=""):
        """Publish one complete immutable actor page to the current session."""
        try:
            key = self._actor_page_prepared_key_v2467(actor_name, current_rating_key)
            if not key:
                return False
            rec = {
                "ts": time.time(),
                "source_rk": str(current_rating_key or "").strip(),
                "profile": dict(profile or {}),
                "movie": list(movie_rows or []),
                "show": list(tv_rows or []),
                "local_thumb": str(local_thumb or ""),
                "source": str(source or ""),
            }
            lock = getattr(self, "_actor_page_session_ready_lock_v2526", None)
            if lock is None:
                lock = threading.RLock()
                self._actor_page_session_ready_lock_v2526 = lock
            with lock:
                cache = getattr(self, "_actor_page_session_ready_v2526", None)
                if not isinstance(cache, dict):
                    cache = {}
                    self._actor_page_session_ready_v2526 = cache
                cache[key] = rec
                if len(cache) > 32:
                    for old_key, _ in sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0.0))[:-32]:
                        cache.pop(old_key, None)
            try:
                same = (
                    str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold()
                    == str(actor_name or "").strip().casefold()
                    and str(getattr(self, "_actor_profile_prewarm_source_rk_v2481", "") or "").strip()
                    == str(current_rating_key or "").strip()
                )
                if same:
                    evt = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                    if evt is not None:
                        evt.set()
            except Exception:
                pass
            _log("ACTOR_PAGE_SESSION_READY_V2526 actor=%s movies=%d tv=%d thumb_local=%d source=%s ready_before_persistent_store=1" % (
                _short_log_value(actor_name,80), len(movie_rows or []), len(tv_rows or []),
                1 if local_thumb else 0, source or ""
            ))
            try:
                self._actor_profile_prebuild_lis_r101(actor_name, list(movie_rows or []) + list(tv_rows or []))
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _actor_page_prepared_get_v2467(self, actor_name, current_rating_key=""):
        # v2526: session-ready data is already content-complete and belongs to
        # this live WindowXML session; do not recompute the expensive persistent
        # authority fingerprint on the actor-click path.
        session_v2526 = self._actor_page_session_ready_get_v2526(actor_name, current_rating_key)
        if session_v2526:
            return session_v2526
        key = self._actor_page_prepared_key_v2467(actor_name, current_rating_key)
        if not key:
            return None
        try:
            rec = self._actor_page_prepared_cache_load_v2467().get(key)
            if not isinstance(rec, dict): return None
            if int(rec.get("fingerprint_version") or 0) != 2468:
                self._actor_page_prepared_cache_v2467.pop(key, None)
                return None
            content_ok_v2487, content_reason_v2487 = self._persistent_entry_content_match_v2487(rec, entry_key="actor:%s" % key)
            if not content_ok_v2487:
                self._actor_page_prepared_cache_v2467.pop(key, None)
                _log("ACTOR_PAGE_PREPARED_CACHE_REJECT_V2487 actor=%s reason=content_authority_changed detail=%s" % (
                    _short_log_value(actor_name,80), content_reason_v2487
                ))
                return None
            if max(0.0, time.time() - float(rec.get("ts") or 0.0)) > 2592000.0:
                self._actor_page_prepared_cache_v2467.pop(key, None)
                return None
            cached_profile_v2539 = dict(rec.get("profile") or {})
            if cached_profile_v2539.get("tmdb_id") and int(cached_profile_v2539.get("portrait_policy_version_v2539") or 0) < 2539:
                self._actor_page_prepared_cache_v2467.pop(key, None)
                _log("ACTOR_PAGE_PREPARED_CACHE_REJECT_V2539 actor=%s reason=legacy_cast_portrait_policy" % (
                    _short_log_value(actor_name,80)
                ))
                return None
            def restore_rows(values):
                out = []
                for row in list(values or []):
                    out.append(tuple(row) if isinstance(row, list) else row)
                return out
            payload = {
                "profile": cached_profile_v2539,
                "movie": restore_rows(rec.get("movie") or []),
                "show": restore_rows(rec.get("show") or []),
                "local_thumb": str(rec.get("local_thumb") or ""),
            }
            _log("ACTOR_PAGE_PREPARED_CACHE_HIT_V2468 actor=%s movies=%d tv=%d spinner=0 authority=match" % (
                _short_log_value(actor_name,80), len(payload["movie"]), len(payload["show"])
            ))
            return payload
        except Exception:
            return None

    def _actor_page_prepared_store_v2467(self, actor_name, current_rating_key, profile, movie_rows, tv_rows, local_thumb=""):
        lock_v2481 = getattr(self, "_actor_page_prepared_lock_v2481", None)
        if lock_v2481 is None:
            lock_v2481 = threading.RLock()
            self._actor_page_prepared_lock_v2481 = lock_v2481
        with lock_v2481:
            try:
                fp = self._persistent_authority_fingerprint_v2467(include_playstate=False)
                if not fp: return False
                key = self._actor_page_prepared_key_v2467(actor_name, current_rating_key)
                cache = self._actor_page_prepared_cache_load_v2467()
                cache[key] = {
                    "ts": time.time(), "authority_model": "content_v2487",
                    "authority_fp": fp, "fingerprint_version": 2468,
                    "profile": self._json_safe_v2467(dict(profile or {})),
                    "movie": self._json_safe_v2467(list(movie_rows or [])),
                    "show": self._json_safe_v2467(list(tv_rows or [])),
                    "local_thumb": str(local_thumb or ""),
                }
                if len(cache) > 512:
                    ordered = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0))
                    for old_key, _ in ordered[:-512]: cache.pop(old_key, None)
                path = self._derived_cache_path_v2467("actor_page_prepared_cache_v2468.json")
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump({"version": 2468, "entries": cache}, f, ensure_ascii=False, separators=(",", ":"))
                os.replace(tmp, path)
                _log("ACTOR_PAGE_PREPARED_CACHE_STORE_V2487 actor=%s movies=%d tv=%d authority=content_bound presentation_independent=1" % (
                    _short_log_value(actor_name,80), len(movie_rows or []), len(tv_rows or [])
                ))
                return True
            except Exception:
                return False

    def _actor_profile_localize_thumb_v2467(self, thumb, actor_name="", max_wait_ms=1800, cancel_check_v2541=None, priority_r15=None):
        """Cache the already-selected TMDb/Plex portrait before actor-page reveal.

        v2485 unwraps Kodi image:// encoded TMDb URLs.
        v2540 records query/download/ready timing.
        v2541 adds per-URL in-flight dedupe so a background portrait prefetch and
        a foreground actor-page open never download the same image twice.
        """
        portrait_localize_started_v2540 = time.perf_counter()
        actor_timing_v2540 = {}
        try:
            timing_map_v2540 = getattr(self, "_actor_profile_portrait_timing_v2540", None)
            if isinstance(timing_map_v2540, dict):
                actor_timing_v2540 = dict(timing_map_v2540.get(str(actor_name or "").strip().casefold()) or {})
        except Exception:
            actor_timing_v2540 = {}
        url = str(thumb or "").strip()
        if not url:
            _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=photo_ready ok=0 reason=empty_thumb elapsed_ms=0.0" % (
                _short_log_value(actor_name,80)
            ))
            return ""
        fetch_url_v2485 = url
        if url.lower().startswith("image://"):
            try:
                encoded_v2485 = url[len("image://"):]
                if encoded_v2485.endswith("/"):
                    encoded_v2485 = encoded_v2485[:-1]
                decoded_v2485 = unquote(encoded_v2485)
                if decoded_v2485.lower().startswith(("http://", "https://")):
                    fetch_url_v2485 = decoded_v2485
                    _log("ACTOR_PROFILE_IMAGE_URI_UNWRAP_V2485 actor=%s source=image_scheme remote=1" % (
                        _short_log_value(actor_name,80)
                    ))
            except Exception:
                fetch_url_v2485 = url
        if not fetch_url_v2485.lower().startswith(("http://", "https://")):
            return url

        def _timing_cache_hit_v2540(dst_v2541, bytes_v2541, dedupe_join_v2541=0, join_wait_ms_v2541=0.0):
            now_v2540 = time.perf_counter()
            query_ms_v2540 = float(actor_timing_v2540.get("query_ms") or 0.0)
            query_done_v2540 = float(actor_timing_v2540.get("query_done") or 0.0)
            select_gap_ms_v2540 = max(0.0, (now_v2540 - query_done_v2540) * 1000.0) if query_done_v2540 > 0.0 else -1.0
            total_from_query_ms_v2540 = max(0.0, (now_v2540 - float(actor_timing_v2540.get("query_started") or now_v2540)) * 1000.0) if actor_timing_v2540.get("query_started") else -1.0
            _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=image_download elapsed_ms=0.0 ok=1 cache_hit=1 bytes=%d max_wait_ms=%d dedupe_join=%d join_wait_ms=%.1f" % (
                _short_log_value(actor_name,80), int(bytes_v2541 or 0), int(max_wait_ms or 0),
                1 if dedupe_join_v2541 else 0, float(join_wait_ms_v2541 or 0.0)
            ))
            _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=photo_ready query_ms=%.1f selection_to_ready_ms=%.1f download_ms=0.0 network_sum_ms=%.1f total_from_query_start_ms=%.1f cache_hit=1 bytes=%d dedupe_join=%d join_wait_ms=%.1f" % (
                _short_log_value(actor_name,80), query_ms_v2540, select_gap_ms_v2540, query_ms_v2540,
                total_from_query_ms_v2540, int(bytes_v2541 or 0), 1 if dedupe_join_v2541 else 0,
                float(join_wait_ms_v2541 or 0.0)
            ))
            return dst_v2541

        try:
            root = self._derived_cache_path_v2467("actor_profile_images_v2467")
            if root and not os.path.isdir(root):
                os.makedirs(root, exist_ok=True)
            ext = os.path.splitext(urlsplit(fetch_url_v2485).path)[1].lower()
            if ext not in (".jpg", ".jpeg", ".png", ".webp"):
                ext = ".jpg"
            dst = os.path.join(root, hashlib.sha1(fetch_url_v2485.encode("utf-8", "replace")).hexdigest() + ext)
            if os.path.isfile(dst) and os.path.getsize(dst) > 1024:
                return _timing_cache_hit_v2540(dst, int(os.path.getsize(dst)))

            inflight_lock_v2541 = getattr(self, "_actor_portrait_download_lock_v2541", None)
            if inflight_lock_v2541 is None:
                inflight_lock_v2541 = threading.RLock()
                self._actor_portrait_download_lock_v2541 = inflight_lock_v2541
            inflight_map_v2541 = getattr(self, "_actor_portrait_download_inflight_v2541", None)
            if not isinstance(inflight_map_v2541, dict):
                inflight_map_v2541 = {}
                self._actor_portrait_download_inflight_v2541 = inflight_map_v2541

            owner_v2541 = False
            entry_v2541 = None
            with inflight_lock_v2541:
                entry_v2541 = inflight_map_v2541.get(dst)
                if not isinstance(entry_v2541, dict) or not isinstance(entry_v2541.get("event"), threading.Event):
                    entry_v2541 = {
                        "event": threading.Event(),
                        "actor": str(actor_name or ""),
                        "started": time.perf_counter(),
                    }
                    inflight_map_v2541[dst] = entry_v2541
                    owner_v2541 = True

            if not owner_v2541:
                join_started_v2541 = time.perf_counter()
                wait_s_v2541 = max(0.05, float(max_wait_ms or 1800) / 1000.0)
                joined_v2541 = bool(entry_v2541["event"].wait(wait_s_v2541))
                join_wait_ms_v2541 = (time.perf_counter() - join_started_v2541) * 1000.0
                ready_v2541 = bool(os.path.isfile(dst) and os.path.getsize(dst) > 1024)
                _log("ACTOR_PROFILE_PORTRAIT_DOWNLOAD_DEDUPE_JOIN_V2541 actor=%s owner_actor=%s wait_ms=%.1f signaled=%d ready=%d max_wait_ms=%d" % (
                    _short_log_value(actor_name,80), _short_log_value(entry_v2541.get("actor") or "",80),
                    join_wait_ms_v2541, 1 if joined_v2541 else 0, 1 if ready_v2541 else 0, int(max_wait_ms or 0)
                ))
                if ready_v2541:
                    return _timing_cache_hit_v2540(
                        dst, int(os.path.getsize(dst)), dedupe_join_v2541=1, join_wait_ms_v2541=join_wait_ms_v2541
                    )
                return url

            download_started_v2540 = time.perf_counter()
            query_done_v2540 = float(actor_timing_v2540.get("query_done") or 0.0)
            selection_to_download_ms_v2540 = max(0.0, (download_started_v2540 - query_done_v2540) * 1000.0) if query_done_v2540 > 0.0 else -1.0
            _log("ACTOR_PROFILE_PORTRAIT_DOWNLOAD_OWNER_V2541 actor=%s selection_to_download_ms=%.1f max_wait_ms=%d" % (
                _short_log_value(actor_name,80), selection_to_download_ms_v2540, int(max_wait_ms or 0)
            ))

            def _cancel_fetch_v2541():
                try:
                    if self._closing_event_v1841.is_set():
                        return True
                except Exception:
                    pass
                if callable(cancel_check_v2541):
                    try:
                        return bool(cancel_check_v2541())
                    except Exception:
                        return False
                return False

            try:
                data = pkm_artwork_scheduler.fetch_bytes(
                    fetch_url_v2485, timeout=max(0.4, float(max_wait_ms or 1800) / 1000.0),
                    max_bytes=16 * 1024 * 1024,
                    headers={"User-Agent": "Kodi-PKM/1.0"},
                    priority=(pkm_artwork_scheduler.PRIORITY_VISIBLE if priority_r15 is None else int(priority_r15)),
                    tag="actor_profile_v2541",
                    cancel_check=_cancel_fetch_v2541,
                    pause_when_playing=False,
                )
                download_ms_v2540 = (time.perf_counter() - download_started_v2540) * 1000.0
                if not data or len(data) <= 1024:
                    _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=image_download elapsed_ms=%.1f ok=0 cache_hit=0 bytes=%d max_wait_ms=%d selection_to_download_ms=%.1f" % (
                        _short_log_value(actor_name,80), download_ms_v2540, len(data or b""), int(max_wait_ms or 0),
                        selection_to_download_ms_v2540
                    ), xbmc.LOGWARNING)
                    return url
                _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=image_download elapsed_ms=%.1f ok=1 cache_hit=0 bytes=%d max_wait_ms=%d selection_to_download_ms=%.1f" % (
                    _short_log_value(actor_name,80), download_ms_v2540, len(data), int(max_wait_ms or 0),
                    selection_to_download_ms_v2540
                ))
                tmp = dst + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, dst)
                _log("ACTOR_PROFILE_IMAGE_LOCAL_READY_V2467 actor=%s bytes=%d file=%s" % (
                    _short_log_value(actor_name,80), len(data), os.path.basename(dst)
                ))
                now_v2540 = time.perf_counter()
                query_ms_v2540 = float(actor_timing_v2540.get("query_ms") or 0.0)
                total_from_query_ms_v2540 = max(0.0, (now_v2540 - float(actor_timing_v2540.get("query_started") or now_v2540)) * 1000.0) if actor_timing_v2540.get("query_started") else -1.0
                selection_to_ready_ms_v2540 = max(0.0, (now_v2540 - query_done_v2540) * 1000.0) if query_done_v2540 > 0.0 else -1.0
                _log("ACTOR_PROFILE_PORTRAIT_TIMING_V2540 actor=%s phase=photo_ready query_ms=%.1f selection_to_download_ms=%.1f selection_to_ready_ms=%.1f download_ms=%.1f network_sum_ms=%.1f total_from_query_start_ms=%.1f cache_hit=0 bytes=%d localize_total_ms=%.1f" % (
                    _short_log_value(actor_name,80), query_ms_v2540, selection_to_download_ms_v2540, selection_to_ready_ms_v2540,
                    download_ms_v2540, query_ms_v2540 + download_ms_v2540, total_from_query_ms_v2540, len(data),
                    (now_v2540 - portrait_localize_started_v2540) * 1000.0
                ))
                return dst
            finally:
                try:
                    entry_v2541["event"].set()
                except Exception:
                    pass
                try:
                    with inflight_lock_v2541:
                        if inflight_map_v2541.get(dst) is entry_v2541:
                            inflight_map_v2541.pop(dst, None)
                except Exception:
                    pass
        except Exception:
            return url

    def _count_cached_cast_locals_for_item(self, li):
        """Return how many visible cast slots already have local circular PNGs."""
        count = 0
        try:
            if li is None:
                return 0
            for idx in range(1, 9):
                name = li.getProperty("PlexKM.Cast%d.Name" % idx) or ""
                if not name:
                    continue
                local = li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) or ""
                if local and not local.lower().startswith(("http://", "https://")):
                    count += 1
                    continue
                thumb = li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or li.getProperty("PlexKM.Cast%d.Thumb" % idx) or ""
                if thumb and self._existing_cast_cache_path(thumb):
                    count += 1
        except Exception:
            pass
        return count

    def _wait_for_active_cast_prewarm(self, li, rating_key, max_wait_ms=90):
        """Very short click-path wait only when the selected item is already prewarming.

        v213 rule:
        - Never start downloads synchronously on click.
        - If a focus prewarm is already active, wait at most ~90ms for the last
          local circle PNGs to land, then use them for the first Info paint.
        - This avoids the visible actor-image pop-in for the common case where
          the user clicks while the prewarm worker is just about to finish.
        """
        try:
            if not rating_key or rating_key not in self._info_prewarm_active:
                return 0
            start = time.time()
            waited = 0
            last_local = self._count_cached_cast_locals_for_item(li)
            while waited < max_wait_ms:
                if rating_key not in self._info_prewarm_active:
                    break
                local_count = self._count_cached_cast_locals_for_item(li)
                if local_count >= 8:
                    last_local = local_count
                    break
                if local_count > last_local:
                    last_local = local_count
                xbmc.sleep(15)
                waited = int((time.time() - start) * 1000.0)
            _log("INFO_CLICK_CAST_PREWARM_WAIT rating_key=%s waited=%dms local=%d active=%s" % (
                rating_key, waited, last_local, "1" if rating_key in self._info_prewarm_active else "0"))
            return waited
        except Exception:
            return 0

    def _person_list_display_text(self, text, limit=72):
        return pkm_info_data.person_list_display_text(text, limit)

    def _profile_db_path(self):
        try:
            profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
        except Exception:
            try:
                profile = xbmc.translatePath("special://profile/addon_data/plugin.video.km/")
            except Exception:
                profile = os.path.join(os.path.expanduser("~"), ".kodi", "userdata", "addon_data", "plugin.video.km")
        return os.path.join(profile, "plex_km.db")

    def _person_filter_candidates_from_section(self, section_id, tag_name, country_mode="any", exclude_keys=None, limit=12):
        """Pick random director/actor filter candidates from current section only.

        v202: /library/sections/{sid}/all often does not include Role/Director
        children, so we first sample movies from the section and then read a
        small number of full metadata nodes to extract usable Director/Role ids.
        This stays inside the current section, so split libraries such as 4K
        never borrow people from other movie sections.
        """
        sid = str(section_id or "").strip()
        tag = str(tag_name or "").strip()
        mode = str(country_mode or "any")
        people = []
        seen = set()
        req_ms = 0
        meta_ms = 0
        meta_checked = 0
        meta_with_tag = 0
        status = "ok"
        try:
            if not sid or tag not in ("Director", "Role"):
                status = "invalid_args"
                return []
            # v204: person rows are random, so do not ask Plex to sort a large
            # section by audienceRating just to choose a random Director/Role.
            # On large libraries that sort was the slowest part of the extra
            # widget worker.  Request a small random section-local pool instead.
            person_pool_size = 24
            person_meta_budget_ms = 450
            params = {
                "type": "1",
                "sort": "random",
                "X-Plex-Container-Start": 0,
                "X-Plex-Container-Size": person_pool_size,
            }
            req_start = _pkm_speed_ms()
            root = core.plex_request_xml("/library/sections/%s/all" % sid, params=params, timeout=1)
            req_ms = _pkm_speed_ms() - req_start
            _speed_log("movie_extra_person_fast_policy", section=sid, tag=tag, pool_size=person_pool_size, meta_budget_ms=person_meta_budget_ms, sort="random", timeout=1, policy="v211_fast_probe")
            excluded = set(str(x) for x in (exclude_keys or set()) if x)
            sample = []
            for node in list(root or []):
                if getattr(node, "tag", "") != "Video":
                    continue
                rk = str(node.get("ratingKey") or node.get("key") or "").strip()
                if rk and rk in excluded:
                    continue
                is_korean = self._node_is_korean_movie(node)
                if mode == "korean" and not is_korean:
                    continue
                if mode == "foreign" and is_korean:
                    continue
                if rk:
                    sample.append(rk)
            try:
                random.SystemRandom().shuffle(sample)
            except Exception:
                random.shuffle(sample)

            # Read only a bounded number of full metadata records.  This runs in
            # the background worker, not in the first paint path.  Keep a soft
            # time budget so large sections do not keep working while the user
            # is already navigating rows 1~3.
            max_meta = max(1, min(3, len(sample)))
            person_meta_start = _pkm_speed_ms()
            for rk in sample[:max_meta]:
                if (_pkm_speed_ms() - person_meta_start) >= person_meta_budget_ms:
                    status = "budget_stop"
                    break
                try:
                    mstart = _pkm_speed_ms()
                    mroot = core.plex_request_xml("/library/metadata/%s" % rk, timeout=1)
                    meta_ms += (_pkm_speed_ms() - mstart)
                    meta_checked += 1
                    mnode = None
                    for ch in list(mroot or []):
                        if getattr(ch, "tag", "") in ("Video", "Directory"):
                            mnode = ch
                            break
                    if mnode is None:
                        continue
                    local_candidates = self._node_tag_candidates(mnode, tag)
                    if local_candidates:
                        meta_with_tag += 1
                    for name, ident in local_candidates:
                        if not name or not ident:
                            continue
                        key = "%s:%s" % (tag, ident)
                        if key in seen:
                            continue
                        seen.add(key)
                        people.append((name, ident))
                        if len(people) >= max(1, int(limit or 12)):
                            raise StopIteration
                except StopIteration:
                    break
                except Exception:
                    continue
            try:
                random.SystemRandom().shuffle(people)
            except Exception:
                random.shuffle(people)
        except StopIteration:
            pass
        except Exception:
            status = "error"
            _log("MOVIE_EXTRA_PERSON_PICK_FAILED section=%s tag=%s mode=%s err=%s" % (sid, tag, mode, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        finally:
            _speed_log(
                "movie_extra_person_candidates",
                section=sid,
                tag=tag,
                country_mode=mode,
                request_ms=req_ms,
                metadata_ms=meta_ms,
                metadata_checked=meta_checked,
                metadata_with_tag=meta_with_tag,
                candidates=len(people),
                status=status,
            )
        return people[:max(1, int(limit or 12))]

    def _movie_rows_from_person_global_sections(self, section_id, section_title, filter_name, filter_id, exclude_keys=None, limit=10):
        """Collect director/actor rows from all movie sections.

        v210: director/actor are intentionally movie-wide, unlike Korean/foreign
        taste rows which remain section scoped.
        """
        start_ms = _pkm_speed_ms()
        want = max(1, int(limit or 10))
        collected = []
        excluded = set(str(x) for x in (exclude_keys or set()) if x)
        unique = set()
        section_ids = self._movie_global_section_ids(section_id)
        for sid in section_ids:
            if len(collected) >= want:
                break
            try:
                need = want - len(collected)
                rows = self._movie_rows_from_section_filter(
                    sid, section_title, filter_name, filter_id,
                    exclude_keys=excluded, limit=max(need, 5), sort="random",
                    country_mode="any", min_score=0, require_rating=False,
                )
                for r in rows or []:
                    try:
                        rk = str((tuple(r or ())[0]) or "")
                        if rk and rk in excluded:
                            continue
                        uk = self._movie_extra_unique_key(r) or rk
                        if uk and uk in unique:
                            continue
                        if rk:
                            excluded.add(rk)
                        if uk:
                            unique.add(uk)
                        collected.append(r)
                        if len(collected) >= want:
                            break
                    except Exception:
                        continue
            except Exception:
                continue
        collected = self._shuffle_recommend_rows(collected, section_id, "%s:%s" % (filter_name or "person", filter_id or ""), "global_person")
        _speed_log("movie_extra_person_global_rows", base_section=section_id, filter=filter_name, filter_id=filter_id, rows=len(collected), target=want, sections=len(section_ids), total_ms=_pkm_speed_ms()-start_ms)
        return collected[:want]

    def _pick_movie_extra_person_global(self, section_id, tag_name, exclude_keys=None, target_min=5, row_limit=10):
        """Pick random director/actor from the whole movie pool.

        The selected person is accepted preferably when at least target_min works
        are found across all movie sections. If none meet the target, use the
        best available non-empty candidate.
        """
        sid = str(section_id or "").strip()
        tag = str(tag_name or "").strip()
        start_ms = _pkm_speed_ms()
        section_ids_all = self._movie_global_section_ids(sid)
        rng = random.SystemRandom()
        section_ids = []
        if sid:
            section_ids.append(sid)
        others = [x for x in section_ids_all if str(x) != sid]
        try:
            rng.shuffle(others)
        except Exception:
            random.shuffle(others)
        section_ids.extend(others[:2])
        candidates = []
        seen = set()
        # v211: Probe only current section + a couple of random movie sections.
        # The previous all-section scan could take 10s+ before actor/director
        # rows appeared. Rows are still collected from all movie sections after
        # a person is selected.
        for probe_sid in section_ids:
            try:
                local = self._person_filter_candidates_from_section(probe_sid, tag, country_mode="any", exclude_keys=exclude_keys, limit=8)
                for name, ident in local or []:
                    key = "%s:%s" % (tag, ident)
                    if ident and key not in seen:
                        seen.add(key)
                        candidates.append((name, ident, probe_sid))
                if len(candidates) >= 16:
                    break
            except Exception:
                continue
        try:
            rng.shuffle(candidates)
        except Exception:
            random.shuffle(candidates)
        _speed_log("movie_extra_global_person_candidates", section=sid, tag=tag, candidates=len(candidates), sections=len(section_ids_all), probed_sections=",".join(section_ids), sample="|".join([str(x[0]) for x in candidates[:8]]), policy="v211_fast")
        best = ("", "", [], "")
        attempts = 0
        max_attempts = 4
        for name, ident, source_sid in candidates[:max_attempts]:
            attempts += 1
            rows = self._movie_rows_from_person_global_sections(sid, "", "director" if tag == "Director" else "actor", ident, exclude_keys=exclude_keys, limit=row_limit)
            if len(rows or []) > len(best[2] or []):
                best = (name, ident, rows or [], source_sid)
            if len(rows or []) >= int(target_min or 5):
                _speed_log("movie_extra_random_person_selected", section=sid, tag=tag, name=name, filter_id=ident, rows=len(rows or []), attempts=attempts, max_attempts=max_attempts, scope="all_movie_sections", source_section=source_sid, total_ms=_pkm_speed_ms()-start_ms, policy="v211_fast")
                return name, ident, rows or []
        name, ident, rows, source_sid = best
        _speed_log("movie_extra_random_person_selected", section=sid, tag=tag, name=name, filter_id=ident, rows=len(rows or []), attempts=attempts, max_attempts=max_attempts, scope="all_movie_sections_best_effort", source_section=source_sid, total_ms=_pkm_speed_ms()-start_ms, policy="v211_fast")
        return name, ident, rows or []

    def _movie_extra_person_name_from_db_rows(self, rows):
        return pkm_movie_recommend.db_row_person_name(rows)

    def _detach_info_actor_work_item_v2082(self, source_li, source_control=0):
        """Detach an actor-work selection from its native Kodi container.

        A ListItem returned by ControlList.getSelectedItem() is a native wrapper
        owned by that control.  Info -> related work -> Info rebuilds the related
        rows, so retaining that wrapper while resetting the source row can leave
        Python/Kodi holding an item whose native container has just been rebound.
        v2082 copies only stable PKM identity/metadata into a standalone ListItem;
        the normal local DB Info enrichment then fills/normalizes the clone.
        """
        try:
            if source_li is None:
                return None
            rating_key = str(source_li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rating_key:
                return None
            try:
                label = source_li.getLabel() or source_li.getProperty("PlexKM.Title") or ""
            except Exception:
                label = source_li.getProperty("PlexKM.Title") or ""
            try:
                path = source_li.getPath() or ""
            except Exception:
                path = ""
            detached = xbmcgui.ListItem(label=label or "", path=path or "")
            try:
                if path:
                    detached.setPath(path)
            except Exception:
                pass

            # Stable properties used before/while _apply_local_db_info_to_li()
            # enriches the detached item.  Do not copy debug/container ownership
            # fields: the clone must not pretend to belong to the old row.
            prop_names = (
                "RatingKey", "SectionId", "Type", "KodiType", "Title",
                "OriginalTitle", "SortTitle", "Year", "Summary", "Duration",
                "AddedAt", "UpdatedAt", "Thumb", "EpisodeThumb", "Art",
                "PartKey", "ViewCount", "IsWatched", "Genre", "Director",
                "Writer", "ContentRating", "Rating", "ShowTitle", "Season",
                "Episode", "ParentRatingKey", "GrandparentRatingKey", "ViewOffset",
                "ResumeDurationMs", "ResumeUpdatedAt", "ResumeSource", "PlayUrl",
                "ShowUrl", "MetaLine", "Premiered", "SourceResolutionFirstVNext", "Is4K",
            )
            copied = 0
            for name in prop_names:
                try:
                    value = source_li.getProperty("PlexKM.%s" % name) or ""
                    if value:
                        detached.setProperty("PlexKM.%s" % name, value)
                        copied += 1
                except Exception:
                    pass
            if not detached.getProperty("PlexKM.Title") and label:
                detached.setProperty("PlexKM.Title", label)

            for idx in range(1, 9):
                for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                    try:
                        value = source_li.getProperty("PlexKM.Cast%d.%s" % (idx, subkey)) or ""
                        if value:
                            detached.setProperty("PlexKM.Cast%d.%s" % (idx, subkey), value)
                    except Exception:
                        pass
            try:
                art = {}
                for key in ("poster", "thumb", "icon", "fanart", "landscape"):
                    try:
                        value = source_li.getArt(key) or ""
                    except Exception:
                        value = ""
                    if value:
                        art[key] = value
                if art:
                    detached.setArt(art)
            except Exception:
                pass
            _log("INFO_ACTOR_WORK_SOURCE_DETACH_V2082 control=%s rating_key=%s copied_props=%d native_source_retained=0" % (
                source_control or 0, rating_key, copied
            ))
            return detached
        except Exception:
            _log("INFO_ACTOR_WORK_SOURCE_DETACH_FAILED_V2082 control=%s err=%s" % (
                source_control or 0, traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGWARNING)
            return None

    def _cast_cache_url_for_display(self, url):
        text = _clean_external_image_url(url)
        if not text:
            return ""
        # 180x180 actor rail does not need TMDb original. Fetching w185 makes
        # the modal info window open with all visible credits ready together.
        try:
            if "image.tmdb.org/t/p/original/" in text:
                text = text.replace("image.tmdb.org/t/p/original/", "image.tmdb.org/t/p/w185/")
        except Exception:
            pass
        return text


    def _cast_placeholder_thumb(self):
        """Return a safe placeholder used when every actor-image source fails.

        v2508: this resource is immutable for the WindowXML lifetime.  The old
        path translated + os.path.exists() checked it for every missing actor
        slot, which cost ~20ms per call on the captured Windows trace.  Resolve
        it once and reuse the exact same special:// path; visual semantics do not
        change.
        """
        cached_v2508 = str(getattr(self, "_cast_placeholder_thumb_cached_v2508", "") or "")
        if cached_v2508:
            return cached_v2508
        candidates = (
            "special://home/addons/plugin.video.km/resources/skins/Default/media/info/cast/cast-placeholder-circle.png",
            "special://home/addons/plugin.video.km/resources/skins/Default/media/info/cast/cast-placeholder.png",
            "special://home/addons/plugin.video.km/resources/skins/Default/media/info/cast/cast_default.png",
            "special://home/addons/plugin.video.km/resources/skins/Default/media/common/defaults/DefaultActor.png",
            "special://home/addons/plugin.video.km/resources/skins/Default/media/common/defaults/DefaultActor.png",
        )
        selected_v2508 = ""
        try:
            for item in candidates:
                if item.startswith("special://"):
                    real = core.xbmcvfs.translatePath(item)
                    if real and os.path.exists(real):
                        selected_v2508 = item
                        break
                elif item:
                    selected_v2508 = item
                    break
        except Exception:
            selected_v2508 = ""
        if not selected_v2508:
            selected_v2508 = "special://home/addons/plugin.video.km/resources/skins/Default/media/info/cast/cast-placeholder-circle.png"
        self._cast_placeholder_thumb_cached_v2508 = selected_v2508
        _log("CAST_PLACEHOLDER_PATH_CACHE_V2508 source=%s resolved_once=1" % selected_v2508)
        return selected_v2508

    def _is_legacy_cast_cache_thumb_v1349(self, thumb):
        """True for old cast_cache PNGs made with earlier 180px geometry.

        v2147: any Python-generated cast circle PNG is legacy. Movie/TV Info XML
        applies cast-circle-diffuse.png to the raw portrait, so reusing a pre-masked
        PNG only adds another image-processing format and can double-mask geometry.
        """
        try:
            text = str(thumb or "").strip().lower().replace("\\", "/")
            if not text:
                return False
            if "cast_cache" not in text:
                return False
            base = os.path.basename(text)
            return base.startswith("cast_") and "_circle_" in base
        except Exception:
            return False

    def _is_cast_placeholder_thumb(self, thumb):
        """Return True for the built-in grey actor placeholder.

        v1213: During startup/partial sync the DB can have cast names before
        actor thumb URLs are filled.  Those placeholders must never be treated as
        valid local actor art; otherwise Info freezes grey avatars and later
        refresh passes think the cast row is already complete.
        """
        try:
            text = str(thumb or "").strip().lower().replace("\\", "/")
            if not text:
                return True
            return (
                "cast-placeholder" in text or
                "defaultactor" in text or
                "/media/common/defaults/defaultactor" in text
            )
        except Exception:
            return True

    def _li_cast_thumb_stats_for_info(self, li):
        """Return (cast_names, real_thumbs) for the current Info ListItem."""
        cast_names = 0
        real_thumbs = 0
        try:
            if li is None:
                return (0, 0)
            for idx in range(1, 9):
                name = li.getProperty("PlexKM.Cast%d.Name" % idx) or ""
                if not name:
                    continue
                cast_names += 1
                thumb = (
                    li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) or
                    li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or
                    li.getProperty("PlexKM.Cast%d.Thumb" % idx) or
                    ""
                )
                if thumb and not self._is_cast_placeholder_thumb(thumb) and not self._is_legacy_cast_cache_thumb_v1349(thumb):
                    real_thumbs += 1
        except Exception:
            pass
        return (cast_names, real_thumbs)

    def _cast_slots_thumb_stats(self, slots):
        """Return (cast_names, real_thumbs) for cached/local DB cast slots.

        v1215: the local DB can already contain the correct Plex/TMDb actor
        thumbnail URLs while a temporary Home/meta cache contains only names or
        placeholder thumbs.  Compare cast-slot quality before allowing a cache
        layer to overwrite DB-backed actor artwork.
        """
        cast_names = 0
        real_thumbs = 0
        try:
            for slot in slots or []:
                if not isinstance(slot, dict):
                    continue
                name = str(slot.get("Name") or slot.get("name") or "").strip()
                if not name:
                    continue
                cast_names += 1
                thumb = _clean_external_image_url(
                    slot.get("Thumb") or slot.get("thumb") or slot.get("OriginalThumb") or slot.get("thumbnail") or ""
                )
                if thumb and not self._is_cast_placeholder_thumb(thumb) and not self._is_legacy_cast_cache_thumb_v1349(thumb):
                    real_thumbs += 1
        except Exception:
            pass
        return (cast_names, real_thumbs)

    def _cast_slots_from_li_properties(self, li, max_count=8):
        """Read current ListItem cast slots without touching Window properties.

        Preserve current-item DB/Home names when a later Plex metadata response
        contains no <Role> nodes.  This does not invent actors and does not read
        stale Window(10000) cast properties.
        """
        slots = []
        try:
            if li is None:
                return slots
            limit = max(1, int(max_count or 8))
            for idx in range(1, limit + 1):
                name = str(li.getProperty("PlexKM.Cast%d.Name" % idx) or "").strip()
                if not name:
                    continue
                role = str(li.getProperty("PlexKM.Cast%d.Role" % idx) or "").strip()
                thumb = _clean_external_image_url(
                    li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or
                    li.getProperty("PlexKM.Cast%d.Thumb" % idx) or
                    ""
                )
                slots.append({"Name": name, "Role": role, "Thumb": thumb})
        except Exception:
            pass
        return slots

    def _li_cast_thumb_ready_for_info(self, li):
        """True when current Info ListItem has real cast artwork.

        Cast names alone are not enough for the movie Credits row.  If the DB is
        mid-sync and only names are present, force a Plex metadata repair before
        the Info screen is revealed so the visible row does not become all grey
        placeholders.
        """
        try:
            if li is None:
                return True
            cast_names, real_thumbs = self._li_cast_thumb_stats_for_info(li)
            if cast_names <= 0:
                return True
            # v1215: one real thumb among an eight-person cast is not enough to
            # publish the Credits row.  That allowed a partial/stale cache to pass
            # and the remaining slots were filled with grey placeholders.  Require
            # a small majority for larger casts, and all available thumbs for tiny
            # casts.  Plex items that genuinely have no actor thumbs will still
            # fail this check and can be shown without freezing placeholder data.
            required = cast_names if cast_names <= 3 else min(4, cast_names)
            return real_thumbs >= required
        except Exception:
            return True

    def _ensure_info_plex_cast_source_before_publish(self, li, reason="", timeout=2.4, allow_network=True):
        """PKM_UHD_STABILITY_U1: never block Info for actor portrait discovery.

        Cast names and the current Plex Role URLs already on the ListItem are
        sufficient for first paint. The existing post-visible cast repair owns
        missing portraits; no global item_people scan is allowed here.
        """
        started = time.time()
        if li is None:
            return False
        try:
            rk = str(li.getProperty('PlexKM.RatingKey') or '').strip()
            names, real = self._li_cast_thumb_stats_for_info(li)
            if names > 0:
                _log('INFO_CAST_FASTPASS_U1 rating_key=%s names=%d real=%d pending=%d elapsed_ms=%.1f reason=%s' % (
                    rk, names, real, max(0, names-real), (time.time()-started)*1000, reason or ''))
                return True
            # Only absence of cast identity can justify a short current-item
            # Plex lookup. Missing portraits must never delay Info publication.
            repaired = False
            if allow_network and float(timeout or 0) > 0:
                budget = min(0.35, max(0.0, float(timeout or 0)))
                if budget:
                    repaired = bool(self._apply_plex_metadata_repair_to_li(
                        li, reason='info_identity_only_u1', update_visual=False,
                        timeout=budget, cast_fast_v2207=True))
            after_names, after_real = self._li_cast_thumb_stats_for_info(li)
            _log('INFO_CAST_FASTPASS_U1 rating_key=%s names=%d real=%d repaired=%d elapsed_ms=%.1f reason=%s' % (
                rk, after_names, after_real, int(repaired), (time.time()-started)*1000, reason or ''))
            return bool(after_names > 0 or repaired)
        except Exception:
            _log('INFO_CAST_FASTPASS_U1_FAILED err=%s' % traceback.format_exc().replace(chr(10), ' | '), xbmc.LOGWARNING)
            return False

    def _local_actor_thumb_map_v1876(self, actor_names, preferred_rating_keys=None):
        """Resolve already-indexed actor thumbnails from PKM's local DB only.

        v1876 policy:
        - Never search Plex people endpoints for a missing Role thumb.
        - Prefer exact actor-name thumbs from the current/duplicate item keys.
        - Otherwise reuse the most frequently indexed exact-name thumb already
          stored in item_people. No network request is made here.
        """
        names = []
        for value in list(actor_names or []):
            name = str(value or "").strip()
            if name and name not in names:
                names.append(name)
        if not names:
            return {}
        preferred = []
        for value in list(preferred_rating_keys or []):
            key = str(value or "").strip()
            if key and key not in preferred:
                preferred.append(key)
        result = {}
        try:
            cache = getattr(self, "_local_actor_thumb_cache_v1876", None)
            if not isinstance(cache, dict):
                cache = {}
                self._local_actor_thumb_cache_v1876 = cache
            for name in names:
                cached = cache.get(name)
                if cached:
                    result[name] = cached
        except Exception:
            cache = None
        unresolved = [name for name in names if name not in result]
        if not unresolved:
            return result
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return result
            conn = _pkm_ro_connect(dbp, timeout=2.0)
            try:
                # First use current/same-title sibling keys in caller-provided order.
                for key in preferred:
                    if not unresolved:
                        break
                    placeholders = ",".join("?" for _ in unresolved)
                    rows = conn.execute("""
                        SELECT person_name, person_thumb
                        FROM item_people
                        WHERE rating_key=? AND person_type='actor'
                          AND person_name IN (%s)
                          AND TRIM(IFNULL(person_thumb,''))<>''
                        ORDER BY sort_order ASC
                    """ % placeholders, tuple([key] + unresolved)).fetchall()
                    for person_name, person_thumb in rows:
                        name = str(person_name or "").strip()
                        thumb = _clean_external_image_url(person_thumb or "")
                        if name and thumb and name not in result:
                            result[name] = thumb
                    unresolved = [name for name in unresolved if name not in result]

                # Then reuse the dominant exact-name local thumb across indexed items.
                if unresolved and not _is_android_platform_v1931():
                    placeholders = ",".join("?" for _ in unresolved)
                    rows = conn.execute("""
                        SELECT person_name, person_thumb, COUNT(*) AS freq,
                               MAX(IFNULL(indexed_at,0)) AS latest
                        FROM item_people
                        WHERE person_type='actor'
                          AND person_name IN (%s)
                          AND TRIM(IFNULL(person_thumb,''))<>''
                        GROUP BY person_name, person_thumb
                        ORDER BY person_name COLLATE NOCASE, freq DESC, latest DESC
                    """ % placeholders, tuple(unresolved)).fetchall()
                    for person_name, person_thumb, _freq, _latest in rows:
                        name = str(person_name or "").strip()
                        thumb = _clean_external_image_url(person_thumb or "")
                        if name and thumb and name not in result:
                            result[name] = thumb
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            # PKM_CAST_ACTOR_MASTER_R16: names still unresolved in Plex's own
            # item_people rows fall back to the local Actor Master DB
            # (service.pkm.actor) TMDb profile_path.  Local SQLite only, no
            # network; enabled on Android too because the lookup is indexed.
            _still_r16 = [name for name in names if name not in result]
            if _still_r16:
                try:
                    for _name_r16, _url_r16 in (self._actor_master_portrait_map_r16(_still_r16) or {}).items():
                        if _name_r16 and _url_r16 and _name_r16 not in result:
                            result[_name_r16] = _url_r16
                except Exception:
                    pass
            if result:
                try:
                    for name, thumb in result.items():
                        if cache is not None and thumb:
                            cache[name] = thumb
                except Exception:
                    pass
                _log("CAST_LOCAL_ACTOR_REUSE_V1876 requested=%d resolved=%d preferred=%s names=%s" % (
                    len(names), len(result), ",".join(preferred),
                    ",".join([name for name in names if name in result])
                ))
        except Exception:
            _log("CAST_LOCAL_ACTOR_REUSE_FAILED_V1876 names=%s err=%s" % (
                ",".join(names), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        return result

    def _actor_master_portrait_map_r16(self, actor_names):
        """PKM_CAST_ACTOR_MASTER_R16: name -> TMDb portrait URL from Actor Master.

        Identity rules (no TMDb id is available on Plex list-sync Role rows):
          1. actors.source_name_normalized (the Plex spelling the master row was
             built from; unique per row) is authoritative;
          2. otherwise actor_alias.alias_compact must resolve to exactly ONE
             tmdb_id; a name shared by two people is skipped (Plex fallback).
        A per-process cache holds hits and misses; no GUI calls, no network.
        """
        names = []
        for value in list(actor_names or []):
            name = str(value or "").strip()
            if name and name not in names:
                names.append(name)
        if not names:
            return {}
        lock = getattr(self, "_actor_master_portrait_lock_r16", None)
        if lock is None:
            lock = threading.Lock()
            self._actor_master_portrait_lock_r16 = lock
        with lock:
            cache = getattr(self, "_actor_master_portrait_cache_r16", None)
            if not isinstance(cache, dict):
                cache = {}
                self._actor_master_portrait_cache_r16 = cache
        out = {}
        todo = []
        for name in names:
            if name in cache:
                if cache[name]:
                    out[name] = cache[name]
            else:
                todo.append(name)
        if not todo:
            return out
        dbp = ""
        try:
            dbp = str(self._pkm_actor_local_db_path_u1() or "").strip()
        except Exception:
            dbp = ""
        if not dbp or not os.path.isfile(dbp):
            try:
                cand = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/service.pkm.actor/"), "actor_ko_master.db")
                if os.path.isfile(cand) and os.path.getsize(cand) > 4096:
                    dbp = cand
            except Exception:
                pass
        if not dbp or not os.path.isfile(dbp):
            return out
        t0 = time.perf_counter()
        hits = ambiguous = 0
        conn = None
        try:
            conn = sqlite3.connect("file:%s?mode=ro" % dbp, uri=True, timeout=0.20)
            for name in todo:
                url = ""
                try:
                    norm = " ".join(unicodedata.normalize("NFKC", name).strip().casefold().split())
                    compact = re.sub(r"[\W_]+", "", norm, flags=re.UNICODE)
                    if not compact:
                        cache[name] = ""
                        continue
                    row = conn.execute(
                        "SELECT profile_path FROM actors WHERE source_name_normalized=? LIMIT 1", (compact,)
                    ).fetchone()
                    path = str((row or [""])[0] or "").strip() if row else ""
                    if not row:
                        rows = conn.execute(
                            "SELECT DISTINCT a.tmdb_id, IFNULL(a.profile_path,'') FROM actor_alias x "
                            "JOIN actors a ON a.tmdb_id=x.tmdb_id WHERE x.alias_compact=? LIMIT 3", (compact,)
                        ).fetchall()
                        if len(rows) == 1:
                            path = str(rows[0][1] or "").strip()
                        elif len(rows) > 1:
                            ambiguous += 1
                            path = ""
                    if path.startswith("/"):
                        url = "https://image.tmdb.org/t/p/original" + path
                except Exception:
                    url = ""
                cache[name] = url
                if url:
                    out[name] = url
                    hits += 1
        except Exception:
            _log("CAST_ACTOR_MASTER_PORTRAIT_FAILED_R16 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
        try:
            if len(cache) > 4096:
                for key in list(cache.keys())[:1024]:
                    cache.pop(key, None)
        except Exception:
            pass
        _log("CAST_ACTOR_MASTER_PORTRAIT_R16 requested=%d resolved=%d ambiguous_skip=%d elapsed_ms=%.1f names=%s" % (
            len(todo), hits, ambiguous, (time.perf_counter() - t0) * 1000.0,
            _short_log_value(",".join(n for n in todo if cache.get(n)), 160)
        ))
        return out

    def _local_actor_thumb_v1876(self, actor_name, rating_key=""):
        name = str(actor_name or "").strip()
        if not name:
            return ""
        return (self._local_actor_thumb_map_v1876([name], [rating_key] if rating_key else []) or {}).get(name, "") or ""

    def _resolve_missing_cast_from_global_library_v2208(self, slots, rating_key="", reason="", max_candidates_per_actor=4, timeout=1.45, allow_network_candidates=True):
        """Resolve missing actor portraits from *other Plex library items*.

        v2208 restores the project rule that actor artwork is library-global, not
        tied to Role@thumb on the currently opened movie/show.  The local DB is
        still the zero-network fast path.  When it only has actor names, use its
        actor/tag index to pick a few other works across every indexed library,
        fetch those works from Plex, and reuse an exact Role portrait found there.

        Positive results are written back to all matching blank item_people rows
        (prefer tag_id, fall back to exact name) so the next Info open is local.
        No placeholder is persisted and current-item metadata is never overwritten.
        """
        rk = str(rating_key or "").strip()
        started = time.time()
        targets = []
        try:
            for pos, slot in enumerate(list(slots or []), 1):
                if not isinstance(slot, dict):
                    continue
                name = str(slot.get("name") or slot.get("Name") or "").strip()
                if not name:
                    continue
                thumb = _clean_external_image_url(
                    slot.get("thumb") or slot.get("Thumb") or slot.get("OriginalThumb") or ""
                )
                if thumb and not self._is_cast_placeholder_thumb(thumb):
                    continue
                idx = _safe_int(slot.get("idx"), pos) or pos
                targets.append({"idx": idx, "name": name, "slot": slot, "tag_id": "", "section_id": ""})
        except Exception:
            targets = []
        if not targets:
            return 0

        # First consume any portrait already present anywhere in item_people.
        try:
            local_map = self._local_actor_thumb_map_v1876([x["name"] for x in targets], [rk] if rk else []) or {}
        except Exception:
            local_map = {}
        local_hits = 0
        for target in targets:
            thumb = _clean_external_image_url(local_map.get(target["name"]) or "")
            if not thumb:
                continue
            slot = target["slot"]
            if "thumb" in slot or "idx" in slot:
                slot["thumb"] = thumb
                slot["original"] = thumb
                slot["source"] = "pkm_global_actor_db_v2208"
            else:
                slot["Thumb"] = thumb
                slot["RawThumb"] = thumb
                slot["Source"] = "pkm_global_actor_db_v2208"
            local_hits += 1
        targets = [x for x in targets if not _clean_external_image_url(
            x["slot"].get("thumb") or x["slot"].get("Thumb") or x["slot"].get("OriginalThumb") or ""
        )]
        if not targets:
            _log("CAST_GLOBAL_LIBRARY_RESOLVE_V2208 rating_key=%s requested=%d local=%d plex=0 unresolved=0 elapsed=%.1fms reason=%s" % (
                rk, local_hits, local_hits, (time.time() - started) * 1000.0, reason or ""
            ))
            return local_hits

        # v2298 foreground/prewarm rule: reuse portraits already indexed from
        # other Plex works, but never walk candidate works over the network just
        # to prove that an actor has no image. Current-item Role thumbs are read
        # separately by the normal metadata repair. Missing actors are therefore
        # decided immediately from the authoritative current Role response plus
        # the already-synced cross-library portrait index.
        if not allow_network_candidates:
            _log("CAST_GLOBAL_LIBRARY_LOCAL_ONLY_V2298 rating_key=%s requested=%d local=%d unresolved=%d elapsed=%.1fms reason=%s action=no_candidate_network" % (
                rk, len(targets) + local_hits, local_hits, len(targets),
                (time.time() - started) * 1000.0, reason or ""
            ))
            return local_hits

        dbp = self._profile_db_path()
        if not dbp or not os.path.exists(dbp):
            return local_hits

        candidate_lists = {}
        try:
            conn = sqlite3.connect(dbp, timeout=2.0)
            conn.row_factory = sqlite3.Row
            try:
                # Current item identity: tag_id is safer than name when Plex has
                # two people with the same display name.
                current_rows = conn.execute("""
                    SELECT person_name, tag_id, section_id
                    FROM item_people
                    WHERE rating_key=? AND person_type='actor'
                """, (rk,)).fetchall() if rk else []
                identity = {}
                for row in current_rows:
                    nm = str(row["person_name"] or "").strip()
                    if nm and nm not in identity:
                        identity[nm] = (str(row["tag_id"] or "").strip(), str(row["section_id"] or "").strip())

                for target in targets:
                    name = target["name"]
                    tag_id, section_id = identity.get(name, ("", ""))
                    target["tag_id"] = tag_id
                    target["section_id"] = section_id
                    limit = max(1, int(max_candidates_per_actor or 4))
                    if tag_id:
                        rows = conn.execute("""
                            SELECT p.rating_key, p.section_id,
                                   IFNULL(i.updated_at,0) AS updated_at,
                                   IFNULL(i.added_at,0) AS added_at
                            FROM item_people p
                            LEFT JOIN items i ON i.rating_key=p.rating_key
                            WHERE p.person_type='actor' AND p.tag_id=? AND p.rating_key<>?
                            GROUP BY p.rating_key
                            ORDER BY CASE WHEN p.section_id=? THEN 0 ELSE 1 END,
                                     updated_at DESC, added_at DESC
                            LIMIT ?
                        """, (tag_id, rk, section_id, limit)).fetchall()
                        # Some libraries assign different Role ids to the same
                        # person. If tag_id produced too few works, exact name is
                        # the cross-library fallback the existing PKM policy used.
                        if len(rows) < limit:
                            more = conn.execute("""
                                SELECT p.rating_key, p.section_id,
                                       IFNULL(i.updated_at,0) AS updated_at,
                                       IFNULL(i.added_at,0) AS added_at
                                FROM item_people p
                                LEFT JOIN items i ON i.rating_key=p.rating_key
                                WHERE p.person_type='actor' AND p.person_name=? AND p.rating_key<>?
                                GROUP BY p.rating_key
                                ORDER BY CASE WHEN p.section_id=? THEN 0 ELSE 1 END,
                                         updated_at DESC, added_at DESC
                                LIMIT ?
                            """, (name, rk, section_id, limit)).fetchall()
                            seen = {str(r["rating_key"] or "") for r in rows}
                            rows = list(rows) + [r for r in more if str(r["rating_key"] or "") not in seen]
                    else:
                        rows = conn.execute("""
                            SELECT p.rating_key, p.section_id,
                                   IFNULL(i.updated_at,0) AS updated_at,
                                   IFNULL(i.added_at,0) AS added_at
                            FROM item_people p
                            LEFT JOIN items i ON i.rating_key=p.rating_key
                            WHERE p.person_type='actor' AND p.person_name=? AND p.rating_key<>?
                            GROUP BY p.rating_key
                            ORDER BY CASE WHEN p.section_id=? THEN 0 ELSE 1 END,
                                     updated_at DESC, added_at DESC
                            LIMIT ?
                        """, (name, rk, section_id, limit)).fetchall()
                    candidate_lists[name] = [str(r["rating_key"] or "").strip() for r in rows if str(r["rating_key"] or "").strip()]
            finally:
                conn.close()
        except Exception:
            _log("CAST_GLOBAL_LIBRARY_DB_CANDIDATES_FAILED_V2208 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return local_hits

        # Interleave works actor-by-actor.  The first network batch therefore
        # gives every missing actor one chance instead of spending the whole
        # foreground budget on one actor's filmography.
        candidate_order = []
        max_rank = max([len(v) for v in candidate_lists.values()] or [0])
        for rank in range(max_rank):
            for target in targets:
                values = candidate_lists.get(target["name"]) or []
                if rank < len(values):
                    key = values[rank]
                    if key and key not in candidate_order:
                        candidate_order.append(key)
        if not candidate_order:
            _log("CAST_GLOBAL_LIBRARY_NO_CANDIDATES_V2208 rating_key=%s names=%s reason=%s" % (
                rk, ",".join([x["name"] for x in targets]), reason or ""
            ))
            return local_hits

        target_by_name = {x["name"]: x for x in targets}
        resolved = {}

        def _fetch_work(key):
            hit = {}
            try:
                root = core.plex_request_xml(
                    "/library/metadata/%s" % key,
                    params=None,
                    timeout=float(timeout or 1.45),
                    log_failures=False,
                )
                node = _first_metadata_node(root)
                if node is None:
                    return key, hit
                for role in node.iter("Role"):
                    role_name = str(role.get("tag") or role.get("title") or role.get("name") or "").strip()
                    role_id = str(role.get("id") or "").strip()
                    raw_thumb = str(role.get("thumb") or "").strip()
                    if not raw_thumb:
                        continue
                    for name, target in target_by_name.items():
                        if name in resolved:
                            continue
                        tag_id = str(target.get("tag_id") or "").strip()
                        exact = (role_name == name)
                        same_id = bool(tag_id and role_id and tag_id == role_id)
                        if not (same_id or exact):
                            continue
                        thumb = _clean_external_image_url(_plex_art(raw_thumb, width=320, height=320))
                        if thumb and not self._is_cast_placeholder_thumb(thumb):
                            hit[name] = (thumb, key)
                            break
            except Exception:
                _log("CAST_GLOBAL_LIBRARY_WORK_FAIL_V2208 rating_key=%s source_key=%s timeout=%.2f err=%s" % (
                    rk, key, float(timeout or 1.45), _short_log_value(traceback.format_exc(), 220)
                ), xbmc.LOGWARNING)
            return key, hit

        # Bounded 3-request batches. Stop as soon as all names are resolved.
        batch_size = 1 if _is_android_platform_v1931() else 3
        max_queries = min(len(candidate_order), max(3, len(targets) * max(1, int(max_candidates_per_actor or 4))))
        queried = 0
        for offset in range(0, max_queries, batch_size):
            batch = candidate_order[offset:offset + batch_size]
            if not batch:
                break
            queried += len(batch)
            try:
                with ThreadPoolExecutor(max_workers=len(batch)) as executor:
                    futures = [executor.submit(_fetch_work, key) for key in batch]
                    for future in as_completed(futures):
                        _key, hits = future.result()
                        for name, payload in (hits or {}).items():
                            if name not in resolved:
                                resolved[name] = payload
            except Exception:
                _log("CAST_GLOBAL_LIBRARY_BATCH_FAIL_V2208 rating_key=%s batch=%s err=%s" % (
                    rk, ",".join(batch), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            if all(x["name"] in resolved for x in targets):
                break

        # Apply and persist only positive Plex portraits.
        plex_hits = 0
        for target in targets:
            payload = resolved.get(target["name"])
            if not payload:
                continue
            thumb, source_key = payload
            slot = target["slot"]
            if "thumb" in slot or "idx" in slot:
                slot["thumb"] = thumb
                slot["original"] = thumb
                slot["source"] = "plex_global_library_v2208"
                slot["source_rating_key"] = source_key
            else:
                slot["Thumb"] = thumb
                slot["RawThumb"] = thumb
                slot["Source"] = "plex_global_library_v2208"
                slot["SourceRatingKey"] = source_key
            plex_hits += 1
            try:
                cache = getattr(self, "_local_actor_thumb_cache_v1876", None)
                if not isinstance(cache, dict):
                    cache = {}
                    self._local_actor_thumb_cache_v1876 = cache
                cache[target["name"]] = thumb
            except Exception:
                pass

        if resolved:
            try:
                conn = sqlite3.connect(dbp, timeout=2.0)
                try:
                    for target in targets:
                        payload = resolved.get(target["name"])
                        if not payload:
                            continue
                        thumb, _source_key = payload
                        tag_id = str(target.get("tag_id") or "").strip()
                        if tag_id:
                            conn.execute("""
                                UPDATE item_people SET person_thumb=?
                                WHERE person_type='actor' AND tag_id=?
                                  AND TRIM(IFNULL(person_thumb,''))=''
                            """, (thumb, tag_id))
                        else:
                            conn.execute("""
                                UPDATE item_people SET person_thumb=?
                                WHERE person_type='actor' AND person_name=?
                                  AND TRIM(IFNULL(person_thumb,''))=''
                            """, (thumb, target["name"]))
                    conn.commit()
                finally:
                    conn.close()
            except Exception:
                _log("CAST_GLOBAL_LIBRARY_PERSIST_FAIL_V2208 rating_key=%s err=%s" % (
                    rk, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        unresolved = max(0, len(targets) - plex_hits)
        _log("CAST_GLOBAL_LIBRARY_RESOLVE_V2208 rating_key=%s requested=%d local=%d plex=%d unresolved=%d candidates=%d queried=%d elapsed=%.1fms reason=%s names=%s" % (
            rk, len(targets) + local_hits, local_hits, plex_hits, unresolved,
            len(candidate_order), queried, (time.time() - started) * 1000.0, reason or "",
            ",".join([x["name"] for x in targets])
        ))
        return local_hits + plex_hits

    def _actor_master_name_ko_v2702(self, actor_name, tmdb_id=""):
        """Fast local-only Korean actor-name lookup from service.pkm.actor.

        Search/matching callers keep the original Plex name.  This helper is
        display-only: local SQLite, no network, process cache after first hit.
        """
        original = str(actor_name or "").strip()
        if not original:
            return original
        tmdb_id = str(tmdb_id or "").strip()
        key = "%s|%s" % (tmdb_id, unicodedata.normalize("NFKC", original).strip().casefold())
        cache = getattr(self, "_actor_master_name_cache_v2701", None)
        if cache is None:
            cache = {}
            self._actor_master_name_cache_v2701 = cache
        if key in cache:
            return cache[key]
        conn = None
        try:
            win = xbmcgui.Window(10000)
            if not self._pkm_actor_local_db_path_u1():
                # V2702: service may become ready after the Actor page is first opened.
                # Never cache this temporary miss, otherwise the Plex spelling is pinned
                # for the whole Kodi process even after actor_ko_master.db is available.
                return original
            dbp = str(win.getProperty("PKM.Actor.DB") or "").strip()
            if dbp.lower().startswith("special://"):
                dbp = xbmcvfs.translatePath(dbp)
            if not dbp or not os.path.isfile(dbp):
                # V2702: same rule as Ready=0 -- this is a transient service state.
                return original

            # ACTOR_MASTER_DB_THREADSAFE_V2704
            # sqlite3 connections are thread-affine by default. Never reuse a
            # connection created by another Actor/Profile worker.
            conn = sqlite3.connect("file:%s?mode=ro" % dbp, uri=True, timeout=0.15)
            conn.row_factory = sqlite3.Row

            schema = getattr(self, "_actor_master_schema_v2701", None)
            schema_path = str(getattr(self, "_actor_master_schema_path_v2704", "") or "")
            if schema is None or schema_path != dbp:
                def cols(table):
                    return [str(r[1]) for r in conn.execute("PRAGMA table_info(%s)" % table)]
                ac = cols("actors")
                al = cols("actor_alias")
                def pick(columns, names):
                    low = {c.casefold(): c for c in columns}
                    for n in names:
                        if n.casefold() in low:
                            return low[n.casefold()]
                    return ""
                schema = {
                    "actor_id": pick(ac, ("tmdb_id", "id", "actor_id")),
                    "actor_ko": pick(ac, ("name_ko", "ko_name", "korean_name", "name_korean", "display_name_ko")),
                    "actor_name": pick(ac, ("name", "name_en", "english_name", "original_name")),
                    # ACTOR_MASTER_IDLESS_AUTHORITY_R10:
                    # Actor Master was built from source/Plex spellings as well as
                    # canonical TMDb names.  These columns must participate before
                    # any network identity lookup.
                    "actor_source": pick(ac, ("source_name",)),
                    "actor_source_norm": pick(ac, ("source_name_normalized",)),
                    "alias_id": pick(al, ("tmdb_id", "actor_id", "person_id")),
                    "alias_name": pick(al, ("alias", "name", "alias_name")),
                    "alias_norm": pick(al, ("alias_normalized", "normalized_alias", "name_normalized")),
                    "alias_compact": pick(al, ("alias_compact",)),
                }
                self._actor_master_schema_v2701 = schema
                self._actor_master_schema_path_v2704 = dbp

            q = lambda c: '"%s"' % str(c).replace('"', '""')
            ko = ""
            aid, ako, aname = schema["actor_id"], schema["actor_ko"], schema["actor_name"]
            asource = schema.get("actor_source") or ""
            asource_norm = schema.get("actor_source_norm") or ""
            alias_id = schema.get("alias_id") or ""
            alias_name = schema.get("alias_name") or ""
            alias_norm = schema.get("alias_norm") or ""
            alias_compact = schema.get("alias_compact") or ""
            original_norm_r10 = " ".join(
                unicodedata.normalize("NFKC", original).strip().casefold().split()
            )
            original_compact_r10 = re.sub(r"[\W_]+", "", original_norm_r10, flags=re.UNICODE)

            # R10 identity order:
            # 1) exact TMDb person id
            # 2) exact source/Plex spelling stored by Actor Master
            # 3) normalized source spelling
            # 4) canonical Korean name
            # 5) original/TMDb name
            # 6) exact/normalized aliases
            # No network or fuzzy person guessing is used here.
            if tmdb_id and aid and ako:
                row = conn.execute(
                    "SELECT %s AS ko FROM actors WHERE CAST(%s AS TEXT)=? LIMIT 1" % (q(ako), q(aid)),
                    (tmdb_id,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and ako and asource and original:
                row = conn.execute(
                    "SELECT %s AS ko FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (q(ako), q(asource)),
                    (original,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and ako and asource_norm and original_norm_r10:
                row = conn.execute(
                    "SELECT %s AS ko FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (q(ako), q(asource_norm)),
                    (original_norm_r10,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and ako and original:
                row = conn.execute(
                    "SELECT %s AS ko FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (q(ako), q(ako)),
                    (original,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and ako and aname and original:
                row = conn.execute(
                    "SELECT %s AS ko FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (q(ako), q(aname)),
                    (original,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and aid and ako and alias_id and alias_name and original:
                row = conn.execute(
                    "SELECT a.%s AS ko FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        q(ako), q(aid), q(alias_id), q(alias_name)
                    ), (original,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and aid and ako and alias_id and alias_norm and original_norm_r10:
                row = conn.execute(
                    "SELECT a.%s AS ko FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        q(ako), q(aid), q(alias_id), q(alias_norm)
                    ), (original_norm_r10,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            if not ko and aid and ako and alias_id and alias_compact and original_compact_r10:
                row = conn.execute(
                    "SELECT a.%s AS ko FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        q(ako), q(aid), q(alias_id), q(alias_compact)
                    ), (original_compact_r10,)
                ).fetchone()
                if row:
                    ko = str(row["ko"] or "").strip()
            result = ko or original
            cache[key] = result
            if result != original:
                _log("ACTOR_MASTER_KO_HIT_V2702 source=local_db tmdb=%s plex=%s display=%s" % (
                    tmdb_id, _short_log_value(original, 80), _short_log_value(result, 80)
                ))
            return result
        except Exception:
            cache[key] = original
            _log("ACTOR_MASTER_KO_LOOKUP_FAILED_V2702 name=%s err=%s" % (
                _short_log_value(original,80), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return original
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass

    def _pkm_actor_local_db_path_u1(self):
        """PKM_UHD_STABILITY_U1: recover downloaded Actor DB without a Ready flag."""
        try:
            win = xbmcgui.Window(10000)
            dbp = str(win.getProperty('PKM.Actor.DB') or '').strip()
            if dbp.lower().startswith('special://'):
                dbp = xbmcvfs.translatePath(dbp)
            if dbp and os.path.isfile(dbp):
                return dbp
            # Read only the actor service's own tiny state file, never the
            # 30MB master DB contents and never another user's data directory.
            addon = xbmcaddon.Addon('service.pkm.actor')
            profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            state = os.path.join(profile, 'state.json')
            if not os.path.isfile(state):
                return ''
            with open(state, 'r', encoding='utf-8') as fh:
                entry = (json.load(fh) or {}).get('database') or {}
            candidate = str(entry.get('path') or '').strip()
            if not candidate and entry.get('filename'):
                candidate = os.path.join(profile, os.path.basename(str(entry['filename'])))
            if not candidate or not os.path.isfile(candidate):
                return ''
            # State is written only after the actor service verifies the DB.
            # Cheap SQLite header validation avoids rehashing 30MB on GUI.
            with open(candidate, 'rb') as fh:
                if fh.read(16) != b'SQLite format 3\x00':
                    return ''
            win.setProperty('PKM.Actor.DB', candidate)
            win.setProperty('PKM.Actor.Ready', '1')
            _log('ACTOR_LOCAL_STATE_RECOVER_U1 ready=1 db=%s' % _short_log_value(candidate,180))
            return candidate
        except Exception:
            return ''

    def _actor_master_profile_ko_v2703(self, actor_name, tmdb_id=""):
        """Read Korean display name + biography directly from local Actor Master DB.

        Diagnostic path is intentionally verbose so kodi.log proves:
          service ready -> DB path -> schema -> identity match -> Korean bio -> UI source.
        No network is used here.
        """
        original = str(actor_name or "").strip()
        tmdb_id = str(tmdb_id or "").strip()
        out = {"name_ko": "", "biography_ko": "", "tmdb_id": tmdb_id, "source": "local_db_v2703"}
        conn = None
        try:
            win = xbmcgui.Window(10000)
            ready = str(win.getProperty("PKM.Actor.Ready") or "").strip()
            dbp = self._pkm_actor_local_db_path_u1()
            if dbp:
                ready = '1'
            exists = bool(dbp and os.path.isfile(dbp))
            _log("ACTOR_MASTER_DB_STATE_V2703 actor=%s ready=%s exists=%d db=%s" % (
                _short_log_value(original,80), ready or "0", 1 if exists else 0, _short_log_value(dbp,220)
            ))
            # PKM_UHD4K_ACTOR_FIX_R2: use the verified local file regardless of
            # whether the service has published its volatile Window property.
            if not exists:
                try:
                    actor_dir = xbmcvfs.translatePath("special://profile/addon_data/service.pkm.actor/")
                    state_path = os.path.join(actor_dir, "state.json")
                    candidate_paths = []
                    if os.path.isfile(state_path):
                        with open(state_path, "r", encoding="utf-8") as _actor_state_fp:
                            _actor_state = json.load(_actor_state_fp)
                        _actor_candidate = str((_actor_state.get("database") or {}).get("path") or "")
                        if _actor_candidate.lower().startswith("special://"):
                            _actor_candidate = xbmcvfs.translatePath(_actor_candidate)
                        if _actor_candidate:
                            candidate_paths.append(_actor_candidate)
                    candidate_paths.append(os.path.join(actor_dir, "actor_ko_master.db"))
                    for _actor_candidate in candidate_paths:
                        if os.path.isfile(_actor_candidate) and os.path.getsize(_actor_candidate) > 4096:
                            dbp, exists = _actor_candidate, True
                            _log("ACTOR_UHD4K_DB_FILE_RECOVERED actor=%s source=local_disk" % _short_log_value(original, 80))
                            break
                except Exception as _actor_recovery_error:
                    _log("ACTOR_UHD4K_DB_RECOVERY_ERROR actor=%s type=%s" % (_short_log_value(original, 80), type(_actor_recovery_error).__name__))
            if exists:
                ready = "1"
            if ready != "1" or not exists:
                _log("ACTOR_MASTER_PROFILE_MISS_V2703 actor=%s tmdb=%s reason=%s" % (
                    _short_log_value(original,80), tmdb_id, "service_not_ready" if ready != "1" else "db_missing"
                ))
                return out

            # ACTOR_MASTER_DB_THREADSAFE_V2704
            # Per-call read-only connection: the connection is created, queried,
            # and closed on the SAME worker/GUI thread.
            conn = sqlite3.connect("file:%s?mode=ro" % dbp, uri=True, timeout=0.20)
            conn.row_factory = sqlite3.Row
            _log("ACTOR_MASTER_DB_OPEN_V2704 actor=%s tmdb=%s thread=%s mode=per_call_readonly" % (
                _short_log_value(original,80), tmdb_id, str(threading.get_ident())
            ))

            def cols(table):
                try:
                    return [str(r[1]) for r in conn.execute("PRAGMA table_info(%s)" % table)]
                except Exception:
                    _log("ACTOR_MASTER_SCHEMA_FAILED_V2704 actor=%s tmdb=%s table=%s err=%s" % (
                        _short_log_value(original,80), tmdb_id, table,
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                    raise
            ac = cols("actors")
            al = cols("actor_alias")
            def pick(columns, names):
                low = {c.casefold(): c for c in columns}
                for n in names:
                    if n.casefold() in low:
                        return low[n.casefold()]
                return ""
            aid = pick(ac, ("tmdb_id", "id", "actor_id", "person_id"))
            ako = pick(ac, ("name_ko", "ko_name", "korean_name", "name_korean", "display_name_ko"))
            aname = pick(ac, ("name", "name_en", "english_name", "original_name"))
            # ACTOR_MASTER_IDLESS_AUTHORITY_R10:
            # source_name is the Plex/source spelling used when the master row was
            # created.  It is the strongest local identity when TMDb id is not yet known.
            asource = pick(ac, ("source_name",))
            asource_norm = pick(ac, ("source_name_normalized",))
            abio = pick(ac, (
                "biography_ko", "bio_ko", "korean_biography", "biography_korean",
                "biography", "bio", "overview_ko", "overview", "profile_ko", "description_ko"
            ))
            alias_id = pick(al, ("tmdb_id", "actor_id", "person_id"))
            alias_name = pick(al, ("alias", "name", "alias_name"))
            alias_norm = pick(al, ("alias_normalized", "normalized_alias", "name_normalized"))
            alias_compact = pick(al, ("alias_compact",))
            _log("ACTOR_MASTER_SCHEMA_V2703 actors_cols=%s alias_cols=%s id=%s name_ko=%s name=%s bio=%s alias_id=%s alias_name=%s" % (
                ",".join(ac), ",".join(al), aid or "-", ako or "-", aname or "-", abio or "-", alias_id or "-", alias_name or "-"
            ))
            if not ac or not abio:
                _log("ACTOR_MASTER_PROFILE_MISS_V2703 actor=%s tmdb=%s reason=no_biography_column" % (
                    _short_log_value(original,80), tmdb_id
                ))
                return out

            q = lambda c: '"%s"' % str(c).replace('"', '""')
            select_cols = []
            if aid: select_cols.append("%s AS tmdb_id" % q(aid))
            if ako: select_cols.append("%s AS name_ko" % q(ako))
            if aname: select_cols.append("%s AS original_name" % q(aname))
            select_cols.append("%s AS biography_ko" % q(abio))
            select_sql = ", ".join(select_cols)
            row = None
            matched_by = ""

            original_norm_r10 = " ".join(
                unicodedata.normalize("NFKC", original).strip().casefold().split()
            )
            original_compact_r10 = re.sub(r"[\W_]+", "", original_norm_r10, flags=re.UNICODE)

            if tmdb_id and aid:
                row = conn.execute(
                    "SELECT %s FROM actors WHERE CAST(%s AS TEXT)=? LIMIT 1" % (select_sql, q(aid)),
                    (tmdb_id,)
                ).fetchone()
                if row: matched_by = "tmdb_id"

            # R10: a local Actor Master hit must not depend on TMDb Helper first
            # discovering the person id.  Prefer the exact source/Plex spelling,
            # then normalized source, canonical Korean name, original name, aliases.
            if row is None and asource and original:
                row = conn.execute(
                    "SELECT %s FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (select_sql, q(asource)),
                    (original,)
                ).fetchone()
                if row: matched_by = "source_name"
            if row is None and asource_norm and original_norm_r10:
                row = conn.execute(
                    "SELECT %s FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (select_sql, q(asource_norm)),
                    (original_norm_r10,)
                ).fetchone()
                if row: matched_by = "source_name_normalized"
            if row is None and ako and original:
                row = conn.execute(
                    "SELECT %s FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (select_sql, q(ako)),
                    (original,)
                ).fetchone()
                if row: matched_by = "korean_name"
            if row is None and aname and original:
                row = conn.execute(
                    "SELECT %s FROM actors WHERE %s=? COLLATE NOCASE LIMIT 1" % (select_sql, q(aname)),
                    (original,)
                ).fetchone()
                if row: matched_by = "actor_name"
            if row is None and aid and alias_id and alias_name and original:
                row = conn.execute(
                    "SELECT %s FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        ", ".join("a."+x if " AS " not in x else x.replace(q(aid), "a."+q(aid)).replace(q(ako), "a."+q(ako)).replace(q(aname), "a."+q(aname)).replace(q(abio), "a."+q(abio)) for x in select_cols),
                        q(aid), q(alias_id), q(alias_name)
                    ), (original,)
                ).fetchone()
                if row: matched_by = "actor_alias"
            if row is None and aid and alias_id and alias_norm and original_norm_r10:
                row = conn.execute(
                    "SELECT %s FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        ", ".join("a."+x if " AS " not in x else x.replace(q(aid), "a."+q(aid)).replace(q(ako), "a."+q(ako)).replace(q(aname), "a."+q(aname)).replace(q(abio), "a."+q(abio)) for x in select_cols),
                        q(aid), q(alias_id), q(alias_norm)
                    ), (original_norm_r10,)
                ).fetchone()
                if row: matched_by = "actor_alias_normalized"
            if row is None and aid and alias_id and alias_compact and original_compact_r10:
                row = conn.execute(
                    "SELECT %s FROM actor_alias x JOIN actors a ON a.%s=x.%s "
                    "WHERE x.%s=? COLLATE NOCASE LIMIT 1" % (
                        ", ".join("a."+x if " AS " not in x else x.replace(q(aid), "a."+q(aid)).replace(q(ako), "a."+q(ako)).replace(q(aname), "a."+q(aname)).replace(q(abio), "a."+q(abio)) for x in select_cols),
                        q(aid), q(alias_id), q(alias_compact)
                    ), (original_compact_r10,)
                ).fetchone()
                if row: matched_by = "actor_alias_compact"

            if row is None:
                _log("ACTOR_MASTER_PROFILE_MISS_V2703 actor=%s tmdb=%s reason=no_matching_row" % (
                    _short_log_value(original,80), tmdb_id
                ))
                return out

            keys = set(row.keys())
            out["tmdb_id"] = str(row["tmdb_id"] or tmdb_id).strip() if "tmdb_id" in keys else tmdb_id
            out["name_ko"] = str(row["name_ko"] or "").strip() if "name_ko" in keys else ""
            out["biography_ko"] = str(row["biography_ko"] or "").strip() if "biography_ko" in keys else ""
            _log("ACTOR_MASTER_PROFILE_ROW_V2703 actor=%s request_tmdb=%s row_tmdb=%s matched_by=%s name_ko=%s bio_chars=%d bio_hangul=%d" % (
                _short_log_value(original,80), tmdb_id, out["tmdb_id"], matched_by,
                _short_log_value(out["name_ko"],80), len(out["biography_ko"]),
                1 if re.search(r"[가-힣]", out["biography_ko"]) else 0
            ))
            if out["biography_ko"]:
                _log("ACTOR_MASTER_BIO_HIT_V2703 source=local_db actor=%s tmdb=%s chars=%d preview=%s" % (
                    _short_log_value(original,80), out["tmdb_id"], len(out["biography_ko"]),
                    _short_log_value(out["biography_ko"],160)
                ))
            else:
                _log("ACTOR_MASTER_PROFILE_MISS_V2703 actor=%s tmdb=%s reason=matched_row_bio_empty" % (
                    _short_log_value(original,80), out["tmdb_id"]
                ))
            return out
        except Exception:
            _log("ACTOR_MASTER_PROFILE_FAILED_V2703 actor=%s tmdb=%s err=%s" % (
                _short_log_value(original,80), tmdb_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return out
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass

    def _actor_profile_set_prop_v2454(self, key, value=""):
        value = "" if value is None else str(value)
        name = "PlexKM.ActorProfile.%s" % str(key or "")
        try:
            self.setProperty(name, value)
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).setProperty(name, value)
        except Exception:
            pass

    def _actor_profile_arm_bio_scroll_r12(self, actor_name, delay_ms=3000):
        """Reveal Actor biography autoscroll 3s after the Actor page becomes active."""
        actor_name = str(actor_name or "").strip()
        token = int(getattr(self, "_actor_profile_bio_scroll_token_r12", 0) or 0) + 1
        self._actor_profile_bio_scroll_token_r12 = token
        self._actor_profile_set_prop_v2454("BioScrollReady", "")
        # ACTOR_BIO_SCROLL_R14:
        # Keep ONE textbox alive from first paint.  Its label starts as the
        # 4-line box-fit preview; after exactly 3 seconds the label is replaced
        # with the untouched full biography.  Kodi can then autoscroll the same
        # already-visible textbox instead of trying to start a newly-visible one.
        _bio_preview_r14 = str(
            xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BiographyDisplay")
            or self.getProperty("PlexKM.ActorProfile.BiographyDisplay")
            or ""
        )
        _bio_full_r14 = str(
            xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.Biography")
            or self.getProperty("PlexKM.ActorProfile.Biography")
            or ""
        )
        self._actor_profile_set_prop_v2454("BiographyViewport", _bio_preview_r14 or _bio_full_r14)
        _log("ACTOR_PROFILE_BIO_SCROLL_ARM_R14 actor=%s delay_ms=%d token=%d preview_chars=%d full_chars=%d" % (
            _short_log_value(actor_name,80), int(delay_ms), token,
            len(_bio_preview_r14), len(_bio_full_r14)
        ))

        def _worker():
            try:
                time.sleep(max(0, int(delay_ms)) / 1000.0)
                if token != int(getattr(self, "_actor_profile_bio_scroll_token_r12", 0) or 0):
                    return
                if not self._actor_profile_is_active_v2454():
                    return
                current_actor = str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip()
                if actor_name and current_actor and actor_name.casefold() != current_actor.casefold():
                    return
                _bio_full_ready_r14 = str(
                    xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.Biography")
                    or self.getProperty("PlexKM.ActorProfile.Biography")
                    or ""
                )
                # ACTOR_PROFILE_LAYOUT_SCROLL_R15:
                # One trailing blank line forces Kodi to scroll one line farther,
                # so the real final biography line is fully visible rather than
                # stopping half-clipped on the lower edge of the textbox.
                _bio_scroll_payload_r15 = (
                    _bio_full_ready_r14.rstrip() + "[CR]"
                    if _bio_full_ready_r14.strip() else ""
                )
                self._actor_profile_set_prop_v2454("BiographyViewport", _bio_scroll_payload_r15)
                self._actor_profile_set_prop_v2454("BioScrollReady", "1")
                _log("ACTOR_PROFILE_BIO_SCROLL_READY_R15 actor=%s token=%d full_chars=%d payload_chars=%d action=preview_to_full_same_textbox_bottom_pad" % (
                    _short_log_value(actor_name,80), token,
                    len(_bio_full_ready_r14), len(_bio_scroll_payload_r15)
                ))
            except Exception:
                _log("ACTOR_PROFILE_BIO_SCROLL_FAILED_R12 actor=%s err=%s" % (
                    _short_log_value(actor_name,80),
                    traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        threading.Thread(
            target=_worker,
            name="PKMActorBioScrollR12",
            daemon=True,
        ).start()
        return True

    def _actor_profile_is_active_v2454(self):
        try:
            return bool(
                self._actor_profile_active_v2454
                or self.getProperty("PlexKM.ActorProfile.Active") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.Active") == "1"
            )
        except Exception:
            return bool(getattr(self, "_actor_profile_active_v2454", False))

    def _actor_profile_cache_path_v2454(self):
        try:
            root = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
            if root and not os.path.isdir(root):
                os.makedirs(root, exist_ok=True)
            return os.path.join(root, "actor_profile_tmdb_cache_v2466.json")
        except Exception:
            return ""

    def _actor_profile_apply_master_authority_r5(self, actor_name, profile, stage=""):
        """ACTOR_MASTER_BIO_AUTHORITY_R5: local Korean Actor Master always wins.

        This is deliberately applied at cache read AND cache write boundaries.
        Therefore a legacy English TMDb Helper biography may remain on disk, but
        it can never become authoritative when actor_ko_master.db has biography_ko.
        No cache deletion/migration is required.
        """
        if not isinstance(profile, dict):
            return profile
        merged = dict(profile)
        try:
            tmdb_id = str(merged.get("tmdb_id") or "").strip()
            master = self._actor_master_profile_ko_v2703(actor_name, tmdb_id) or {}
            bio_ko = str(master.get("biography_ko") or "").strip()
            name_ko = str(master.get("name_ko") or "").strip()
            master_tmdb = str(master.get("tmdb_id") or tmdb_id).strip()
            if master_tmdb and not tmdb_id:
                merged["tmdb_id"] = master_tmdb
            if name_ko:
                merged["name_ko"] = name_ko
            if bio_ko:
                old_source = str(merged.get("biography_source") or merged.get("source") or "missing")
                old_bio = str(merged.get("biography") or "")
                merged["biography"] = bio_ko
                merged["biography_source"] = "actor_master_local_db_r5"
                merged["actor_master_authority"] = "1"
                merged["actor_master_bio_stage"] = str(stage or "")
                _log("ACTOR_MASTER_BIO_AUTHORITY_R5 actor=%s tmdb=%s stage=%s old_source=%s old_chars=%d new_chars=%d hangul=%d action=local_db_override" % (
                    _short_log_value(actor_name,80), master_tmdb, str(stage or ""),
                    _short_log_value(old_source,100), len(old_bio), len(bio_ko),
                    1 if re.search(r"[가-힣]", bio_ko) else 0
                ))
            else:
                _log("ACTOR_MASTER_BIO_AUTHORITY_R5 actor=%s tmdb=%s stage=%s action=db_miss_keep_fallback source=%s chars=%d" % (
                    _short_log_value(actor_name,80), tmdb_id, str(stage or ""),
                    _short_log_value(str(merged.get("biography_source") or merged.get("source") or "missing"),100),
                    len(str(merged.get("biography") or ""))
                ))
        except Exception:
            _log("ACTOR_MASTER_BIO_AUTHORITY_R5 actor=%s stage=%s action=lookup_failed_keep_fallback err=%s" % (
                _short_log_value(actor_name,80), str(stage or ""),
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        return merged

    def _actor_profile_cache_get_v2454(self, actor_name, ttl_s=604800):
        key = " ".join(str(actor_name or "").strip().casefold().split())
        if not key:
            return None
        now = time.time()
        try:
            rec = (getattr(self, "_actor_profile_memory_cache_v2454", {}) or {}).get(key)
            if isinstance(rec, dict):
                profile = rec.get("profile") or {}
                age_s = now - float(rec.get("ts") or 0)
                # v2455: a profile without Biography is partial. Cache it only
                # briefly; never let one incomplete Helper response suppress
                # Korean/exact-ID retries for seven days.
                cache_ttl = float(ttl_s) if profile.get("biography") else 1800.0
                if profile.get("tmdb_id") and age_s <= cache_ttl:
                    if int(profile.get("portrait_policy_version_v2539") or 0) >= 2539:
                        return self._actor_profile_apply_master_authority_r5(
                            actor_name, dict(profile), stage="memory_cache_read"
                        )
                    migrated = dict(profile)
                    for _legacy_art_key in ("portrait_local_v2544", "portrait_selection_v2539", "portrait_image_count_v2544"):
                        migrated.pop(_legacy_art_key, None)
                    migrated["portrait_policy_version_v2539"] = 2544
                    _log("ACTOR_PROFILE_CACHE_IDENTITY_MIGRATE actor=%s source=memory portrait_cache=reset korean_bio=preserved" % (
                        _short_log_value(actor_name,80)))
                    return self._actor_profile_apply_master_authority_r5(
                        actor_name, migrated, stage="memory_legacy_identity_migrate")
        except Exception:
            pass
        path = self._actor_profile_cache_path_v2454()
        if not path or not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            rec = (payload.get("entries") or {}).get(key) if isinstance(payload, dict) else None
            if not isinstance(rec, dict):
                return None
            profile = rec.get("profile") or {}
            age_s = now - float(rec.get("ts") or 0)
            cache_ttl = float(ttl_s) if profile.get("biography") else 1800.0
            if age_s > cache_ttl or not profile.get("tmdb_id"):
                return None
            if int(profile.get("portrait_policy_version_v2539") or 0) < 2539:
                profile = dict(profile)
                for _legacy_art_key in ("portrait_local_v2544", "portrait_selection_v2539", "portrait_image_count_v2544"):
                    profile.pop(_legacy_art_key, None)
                profile["portrait_policy_version_v2539"] = 2544
                _log("ACTOR_PROFILE_CACHE_IDENTITY_MIGRATE actor=%s source=disk portrait_cache=reset korean_bio=preserved" % (
                    _short_log_value(actor_name,80)))
            profile = self._actor_profile_apply_master_authority_r5(
                actor_name, dict(profile), stage="disk_cache_read"
            )
            self._actor_profile_memory_cache_v2454[key] = {"ts": now, "profile": dict(profile)}
            _log("ACTOR_PROFILE_CACHE_HIT_V2454 actor=%s tmdb=%s age_s=%d" % (
                _short_log_value(actor_name, 80), profile.get("tmdb_id") or "",
                int(max(0, now - float(rec.get("ts") or now)))
            ))
            return dict(profile)
        except Exception:
            return None

    def _actor_profile_cache_put_v2454(self, actor_name, profile):
        key = " ".join(str(actor_name or "").strip().casefold().split())
        if not key or not isinstance(profile, dict) or not profile.get("tmdb_id"):
            return False
        # R5 authority boundary: never persist a legacy English/helper biography
        # as authoritative when the local Actor Master already has Korean bio.
        profile = self._actor_profile_apply_master_authority_r5(
            actor_name, dict(profile), stage="cache_write"
        )
        now = time.time()
        try:
            self._actor_profile_memory_cache_v2454[key] = {"ts": now, "profile": dict(profile)}
        except Exception:
            pass
        path = self._actor_profile_cache_path_v2454()
        if not path:
            return False
        try:
            payload = {"version": 1, "entries": {}}
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        old = json.load(f)
                    if isinstance(old, dict):
                        payload["entries"] = dict(old.get("entries") or {})
                except Exception:
                    pass
            payload["entries"][key] = {"ts": now, "profile": dict(profile)}
            # Bound the derived cache.
            entries = payload["entries"]
            if len(entries) > 256:
                for old_key, _ in sorted(entries.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0))[:-256]:
                    entries.pop(old_key, None)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            return True
        except Exception:
            return False

    def _actor_profile_prewarm_cancelled_v2481(self, token, actor_name="", source_rk=""):
        """Return True when a low-priority actor intent no longer owns the target.

        This intentionally inspects only Python-side transaction state.  Worker
        threads never read or mutate Kodi controls, which keeps the old v248
        GUI-thread crash-stop rule intact.
        """
        try:
            if not token:
                return False
            if self._closing_event_v1841.is_set():
                return True
            if int(token) != int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0):
                return True
            fg = str(getattr(self, "_actor_profile_foreground_actor_v2481", "") or "").strip()
            actor_name = str(actor_name or "").strip()
            if fg and actor_name and fg.casefold() != actor_name.casefold():
                return True
            # v2526: source_rk is still carried for identity/dedupe, but do not
            # compare it to _last_info_rating_key here.  Media-ahead prewarm starts
            # on Home before the new Info becomes _last_info_rating_key; the old
            # comparison incorrectly cancelled exactly that useful runway.  Target
            # replacement is governed by the monotonic prewarm token + actor guard.
            source_rk = str(source_rk or "").strip()
            return False
        except Exception:
            return True

    def _actor_profile_local_rows_cache_get_v2522(self, actor_name, source_rk="", max_age_s=15.0):
        try:
            key = (str(actor_name or "").strip().casefold(), str(source_rk or "").strip())
            if not key[0]:
                return None
            with self._actor_profile_local_rows_lock_v2522:
                rec = dict((self._actor_profile_local_rows_cache_v2522 or {}).get(key) or {})
            if not rec:
                return None
            age = max(0.0, time.time() - float(rec.get("ts") or 0.0))
            if age > float(max_age_s or 15.0):
                return None
            return {
                "movie": list(rec.get("movie") or []),
                "show": list(rec.get("show") or []),
                "age_ms": int(age * 1000.0),
            }
        except Exception:
            return None

    def _actor_profile_local_rows_cache_put_v2522(self, actor_name, source_rk, works):
        try:
            key = (str(actor_name or "").strip().casefold(), str(source_rk or "").strip())
            if not key[0]:
                return False
            rec = {
                "ts": time.time(),
                "movie": list((works or {}).get("movie") or []),
                "show": list((works or {}).get("show") or []),
            }
            with self._actor_profile_local_rows_lock_v2522:
                cache = self._actor_profile_local_rows_cache_v2522
                cache[key] = rec
                if len(cache) > 24:
                    oldest = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0.0))[:-24]
                    for old_key, _ in oldest:
                        cache.pop(old_key, None)
            return True
        except Exception:
            return False

    def _schedule_actor_profile_item_prewarm_v2481(self, actor_name, source_rk="", fallback_thumb="", reason="cast_intent", settle_ms_v2526=250):
        """Schedule one immutable actor target; v2526 can start it media-ahead."""
        try:
            actor_name = str(actor_name or "").strip()
            source_rk = str(source_rk or "").strip()
            fallback_thumb = str(fallback_thumb or "").strip()
            settle_ms_v2526 = max(0, int(settle_ms_v2526 or 0))
            if not actor_name:
                return False

            # V2599: a provisional local-first page is click-ready but must not
            # suppress background TMDb enrichment. Only a complete session wins.
            existing_session_v2599 = self._actor_page_session_ready_get_v2526(actor_name, source_rk)
            if existing_session_v2599:
                existing_profile_v2599 = dict(existing_session_v2599.get("profile") or {})
                if self._actor_profile_metadata_ready_v2611(existing_profile_v2599):
                    _log("ACTOR_PROFILE_MEDIA_AHEAD_SKIP_V2526 actor=%s source=%s reason=session_ready_complete" % (
                        _short_log_value(actor_name,80), source_rk or ""
                    ))
                    return True
                _log("ACTOR_PROFILE_SESSION_INCOMPLETE_RESUME_V2611 actor=%s source=%s reason=%s tmdb=0 provisional=%d" % (
                    _short_log_value(actor_name,80), source_rk or "", _short_log_value(reason or "",100),
                    1 if bool(existing_profile_v2599.get("_v2599_provisional")) else 0
                ))

            # Critical v2526 rule: actor-row focus must not cancel/restart the same
            # actor that Home cast prewarm already started several seconds earlier.
            same_inflight_v2526 = bool(
                getattr(self, "_actor_profile_prewarm_inflight_v2526", False)
                and str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold() == actor_name.casefold()
                and str(getattr(self, "_actor_profile_prewarm_source_rk_v2481", "") or "").strip() == source_rk
            )
            if same_inflight_v2526:
                age_ms_v2526 = max(0, self._now_ms() - int(getattr(self, "_actor_profile_prewarm_started_ms_v2526", 0) or 0))
                _log("ACTOR_PROFILE_PREWARM_DEDUPE_V2526 actor=%s source=%s age_ms=%d reason=%s action=keep_earlier_worker" % (
                    _short_log_value(actor_name,80), source_rk or "", age_ms_v2526, reason or ""
                ))
                # V2672: the visible-page TMDb request can collide with the earlier
                # LOCAL-ONLY cast-focus worker. V2526 dedupe used to discard the
                # visible request permanently; after the local worker returned, no
                # owner remained to fetch biography/birthday/TMDb identity. Queue
                # exactly one deferred retry and run it only while this actor page
                # is still the visible target.
                if str(reason or "").startswith("actor_visible_enrich_"):
                    _pending_key_v2672 = (actor_name.casefold(), source_rk)
                    if getattr(self, "_actor_profile_visible_enrich_retry_v2672", None) != _pending_key_v2672:
                        self._actor_profile_visible_enrich_retry_v2672 = _pending_key_v2672
                        def _retry_visible_enrich_v2672():
                            try:
                                deadline_v2672 = time.time() + 6.0
                                while time.time() < deadline_v2672 and not self._closing_event_v1841.is_set():
                                    same_now_v2672 = bool(
                                        getattr(self, "_actor_profile_prewarm_inflight_v2526", False)
                                        and str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold() == actor_name.casefold()
                                        and str(getattr(self, "_actor_profile_prewarm_source_rk_v2481", "") or "").strip() == source_rk
                                    )
                                    if not same_now_v2672:
                                        break
                                    if self._closing_event_v1841.wait(0.10):
                                        return
                                visible_same_v2672 = bool(
                                    getattr(self, "_actor_profile_active_v2454", False)
                                    and str(getattr(self, "_actor_profile_visible_name_v2610", "") or "").strip().casefold() == actor_name.casefold()
                                )
                                if visible_same_v2672 and self._actor_profile_metadata_needs_enrich_v2611(
                                    self._actor_profile_cache_get_v2454(actor_name) or {}
                                ):
                                    _log("ACTOR_PROFILE_VISIBLE_ENRICH_REARM_V2672 actor=%s source=%s prior_age_ms=%d action=retry_after_local_worker" % (
                                        _short_log_value(actor_name,80), source_rk or "", age_ms_v2526
                                    ))
                                    self._schedule_actor_profile_item_prewarm_v2481(
                                        actor_name, source_rk=source_rk, fallback_thumb=fallback_thumb,
                                        reason="actor_visible_enrich_v2672", settle_ms_v2526=0
                                    )
                                else:
                                    _log("ACTOR_PROFILE_VISIBLE_ENRICH_REARM_SKIP_V2672 actor=%s visible_same=%d metadata_needed=%d" % (
                                        _short_log_value(actor_name,80), 1 if visible_same_v2672 else 0,
                                        1 if self._actor_profile_metadata_needs_enrich_v2611(self._actor_profile_cache_get_v2454(actor_name) or {}) else 0
                                    ))
                            except Exception:
                                _log("ACTOR_PROFILE_VISIBLE_ENRICH_REARM_FAILED_V2672 actor=%s err=%s" % (
                                    _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                                ), xbmc.LOGWARNING)
                            finally:
                                if getattr(self, "_actor_profile_visible_enrich_retry_v2672", None) == _pending_key_v2672:
                                    self._actor_profile_visible_enrich_retry_v2672 = None
                        _PKMHomeThreadV2151(target=_retry_visible_enrich_v2672, name="ActorProfileEnrichV2672", daemon=True).start()
                        _log("ACTOR_PROFILE_VISIBLE_ENRICH_DEFER_V2672 actor=%s source=%s reason=local_worker_inflight" % (
                            _short_log_value(actor_name,80), source_rk or ""
                        ))
                return True

            worker = self._schedule_actor_profile_item_prewarm_v2481_step1(actor_name, fallback_thumb, reason, settle_ms_v2526, source_rk)

            _PKMHomeThreadV2151(target=worker, name="ActorProfileIntentV2526", daemon=True).start()
            return True
        except Exception:
            _log("ACTOR_PROFILE_FOCUS_PREWARM_ARM_FAILED_V2526 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _schedule_actor_profile_item_prewarm_v2481_step1(self, actor_name, fallback_thumb, reason, settle_ms_v2526, source_rk):
        """Step 1 of _schedule_actor_profile_item_prewarm_v2481 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_FOCUS_PREWARM_ARM_V2526, ACTOR_PROFILE_LOCAL_ROWS_PREWARM_READY_V2522, ACTOR_PROFILE_PORTRAIT_PREWARM_V2544, ACTOR_PROFILE_CLICK_READY_V2526."""
        self._actor_profile_prewarm_token_v2481 = int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0) + 1
        token = int(self._actor_profile_prewarm_token_v2481)
        self._actor_profile_prewarm_actor_v2481 = actor_name
        self._actor_profile_prewarm_source_rk_v2481 = source_rk
        self._actor_profile_prewarm_inflight_v2526 = True
        self._actor_profile_prewarm_started_ms_v2526 = self._now_ms()
        self._actor_profile_prewarm_ready_event_v2526 = threading.Event()
        self._actor_profile_prewarm_reason_v2543 = str(reason or "")
        self._actor_profile_prewarm_helper_started_ms_v2543 = 0
        _log("ACTOR_PROFILE_FOCUS_PREWARM_ARM_V2526 actor=%s source=%s token=%d settle_ms=%d gui_worker=0 local_rows=1 helper_profile=background native=0 reason=%s" % (
            _short_log_value(actor_name,80), source_rk or "", token, settle_ms_v2526, reason or ""
        ))

        def _valid_local_thumb_v2526(value):
            try:
                value = str(value or "").strip()
                if not value or value.lower().startswith(("http://", "https://", "image://")):
                    return ""
                if self._is_cast_placeholder_thumb(value):
                    return ""
                translated = xbmcvfs.translatePath(value) if value.lower().startswith("special://") else value
                if os.path.isfile(translated) and os.path.getsize(translated) > 1024:
                    return translated
            except Exception:
                pass
            return ""

        def worker():
            started = time.time()
            ready_published_v2526 = False
            try:
                if settle_ms_v2526:
                    xbmc.sleep(settle_ms_v2526)
                if self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk):
                    _log("ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2481 actor=%s token=%d stage=settle" % (_short_log_value(actor_name,80), token))
                    return
                # All prepared-cache I/O stays off the GUI focus callback.
                prepared_existing_v2526 = self._actor_page_prepared_get_v2467(actor_name, source_rk)
                if prepared_existing_v2526:
                    prepared_profile_v2611 = dict(prepared_existing_v2526.get("profile") or {})
                    if self._actor_profile_metadata_ready_v2611(prepared_profile_v2611):
                        self._actor_page_session_ready_put_v2526(
                            actor_name, source_rk, prepared_profile_v2611,
                            prepared_existing_v2526.get("movie") or [],
                            prepared_existing_v2526.get("show") or [],
                            local_thumb=prepared_existing_v2526.get("local_thumb") or "",
                            source="prepared_existing_v2526",
                        )
                        ready_published_v2526 = True
                        _log("ACTOR_PROFILE_FOCUS_PREWARM_SKIP_V2526 actor=%s reason=prepared session_ready=1 metadata_ready=1" % _short_log_value(actor_name,80))
                        return
                    _log("ACTOR_PROFILE_PREPARED_INCOMPLETE_RESUME_V2611 actor=%s reason=%s tmdb=0 provisional=%d action=continue_postvisible_enrich" % (
                        _short_log_value(actor_name,80), _short_log_value(reason or "",100),
                        1 if bool(prepared_profile_v2611.get("_v2599_provisional")) else 0
                    ))
                self._actor_profile_prewarm_running_v2481 = True
                rows_t0_v2522 = time.time()
                works = self._actor_profile_local_works_v2454(actor_name, current_rating_key=source_rk, limit=None)
                movie_rows = list((works or {}).get("movie") or [])
                tv_rows = list((works or {}).get("show") or [])
                self._actor_profile_local_rows_cache_put_v2522(actor_name, source_rk, {"movie": movie_rows, "show": tv_rows})
                _log("ACTOR_PROFILE_LOCAL_ROWS_PREWARM_READY_V2522 actor=%s token=%d movies=%d tv=%d elapsed_ms=%d network=0 native=0" % (
                    _short_log_value(actor_name,80), token, len(movie_rows), len(tv_rows), int((time.time()-rows_t0_v2522)*1000.0)
                ))
                if self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk):
                    _log("ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2522 actor=%s token=%d stage=local_rows" % (_short_log_value(actor_name,80), token))
                    return
                profile = self._actor_profile_cache_get_v2454(actor_name) or {}
                local_fallback_v2526 = _valid_local_thumb_v2526(fallback_thumb)
                if self._actor_profile_metadata_needs_enrich_v2611(profile):
                    # V2611: any local-first/incomplete profile (not only an empty
                    # dict) remains click-ready but must still continue to TMDb after
                    # ActorProfile is visible. This prevents session_ready from
                    # swallowing identity/biography enrichment.
                    provisional_v2599 = dict(profile or {})
                    provisional_v2599.setdefault("label", actor_name)
                    provisional_v2599.setdefault("name", actor_name)
                    provisional_v2599.setdefault("biography", "")
                    provisional_v2599.setdefault("birthday", "")
                    provisional_v2599.setdefault("department", "")
                    provisional_v2599["source"] = provisional_v2599.get("source") or "local_first_v2599"
                    provisional_v2599["_v2599_provisional"] = 1
                    if not movie_rows and not tv_rows:
                        provisional_v2599["_v2669_zero_works_retry"] = 1
                        _log("ACTOR_PROFILE_ZERO_WORKS_PROVISIONAL_V2669 actor=%s source=%s action=do_not_treat_as_authoritative_empty" % (_short_log_value(actor_name,80), source_rk or ""))
                    self._actor_page_session_ready_put_v2526(
                        actor_name, source_rk, provisional_v2599, movie_rows, tv_rows,
                        local_thumb=local_fallback_v2526, source="local_first_v2599"
                    )
                    ready_published_v2526 = True
                    try:
                        evt_fast_v2599 = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                        if evt_fast_v2599 is not None and not evt_fast_v2599.is_set():
                            evt_fast_v2599.set()
                    except Exception:
                        pass
                    _log("ACTOR_PROFILE_CLICK_READY_V2599 actor=%s source=%s elapsed_ms=%d local_works=%d tmdb_wait=0 provisional=1" % (
                        _short_log_value(actor_name,80), source_rk or "", int((time.time()-started)*1000.0),
                        len(movie_rows) + len(tv_rows)
                    ))
                    # V2601 Android: cast-focus prewarm is LOCAL ONLY. Starting
                    # TMDb merely because the user paused on an actor competes with
                    # Info navigation and makes the later click feel blocked. Only
                    # an already-visible Actor page may request TMDb enrichment.
                    if self._uhd_kpi_proxy_v2605() and not str(reason or "").startswith("actor_visible_enrich_"):
                        _log("ACTOR_PROFILE_PRECLICK_HELPER_SKIP_V2601 actor=%s token=%d reason=%s local_rows_ready=1 click_ready=1 tmdb=0" % (
                            _short_log_value(actor_name,80), token, _short_log_value(reason or "",120)
                        ))
                        return
                    # Visible-page enrichment is low priority and waits for input idle.
                    if self._uhd_kpi_proxy_v2605():
                        idle_gate_t0_v2600 = self._now_ms()
                        idle_wait_v2600 = 0
                        while not self._closing_event_v1841.is_set():
                            if self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk):
                                _log("ACTOR_PROFILE_HELPER_IDLE_GATE_CANCEL_V2600 actor=%s token=%d wait_ms=%d" % (
                                    _short_log_value(actor_name,80), token, idle_wait_v2600
                                ))
                                return
                            try:
                                nav_hot_v2600 = bool(self._uhd3_foreground_isolation_active_v2591())
                            except Exception:
                                nav_hot_v2600 = False
                            if not nav_hot_v2600:
                                break
                            idle_wait_v2600 = max(0, self._now_ms() - idle_gate_t0_v2600)
                            if idle_wait_v2600 >= 8000:
                                # V2679: biography/identity is eventual, not best-effort.
                                # Keep yielding to foreground navigation, then retry while
                                # this actor remains the active page.
                                _active_same_v2679 = bool(
                                    self._actor_profile_is_active_v2454()
                                    and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                                )
                                if not _active_same_v2679:
                                    _log("ACTOR_PROFILE_ENRICH_CANCEL_V2679 actor=%s token=%d reason=page_changed" % (
                                        _short_log_value(actor_name,80), token
                                    ))
                                    return
                                _log("ACTOR_PROFILE_ENRICH_RESCHEDULE_V2679 actor=%s token=%d wait_ms=%d reason=navigation_still_hot action=keep_waiting" % (
                                    _short_log_value(actor_name,80), token, idle_wait_v2600
                                ))
                                idle_gate_t0_v2600 = self._now_ms()
                                idle_wait_v2600 = 0
                            if self._closing_event_v1841.wait(0.20):
                                return
                        idle_wait_v2600 = max(0, self._now_ms() - idle_gate_t0_v2600)
                        _log("ACTOR_PROFILE_HELPER_IDLE_GATE_V2600 actor=%s token=%d wait_ms=%d navigation_hot=0 external_work=allowed" % (
                            _short_log_value(actor_name,80), token, idle_wait_v2600
                        ))
                    helper_t0_v2523 = time.time()
                    try:
                        if int(token) == int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0):
                            self._actor_profile_prewarm_helper_started_ms_v2543 = self._now_ms()
                    except Exception:
                        pass
                    _log("ACTOR_PROFILE_HELPER_OWNERSHIP_V2543 actor=%s token=%d reason=%s helper_started_ms=%d" % (
                        _short_log_value(actor_name,80), token, _short_log_value(reason or "",120),
                        int(getattr(self, "_actor_profile_prewarm_helper_started_ms_v2543", 0) or 0)
                    ))
                    _log("ACTOR_PROFILE_HELPER_PREWARM_BEGIN_V2526 actor=%s token=%d source=%s local_rows_ready=1 local_portrait=%d native=0" % (
                        _short_log_value(actor_name,80), token, source_rk or "", 1 if local_fallback_v2526 else 0
                    ))
                    try:
                        pkm_uhd_diag_v2600.event(
                            "ACTOR_HELPER_BEGIN",
                            extra="actor=%s token=%d local_works=%d" % (
                                _short_log_value(actor_name,60), token, len(movie_rows) + len(tv_rows)
                            )
                        )
                    except Exception:
                        pass
                    # R77: when Actor Master has no usable Korean bio, start the
                    # Korean Wikipedia lookup now (in parallel with TMDB) instead
                    # of at page open: wikidata + kowiki take ~2.5 s, which the
                    # user otherwise watched as an empty bio box (배성우).
                    try:
                        _master_r77 = self._actor_master_profile_ko_v2703(actor_name) or {}
                        _master_bio_r77 = " ".join(str(_master_r77.get("biography_ko") or "").split())
                        if len(_master_bio_r77) < self._WIKI_BIO_SHORT_R68:
                            if self._actor_wiki_bio_schedule_r68(
                                    actor_name,
                                    {"tmdb_id": str(_master_r77.get("tmdb_id") or ""), "biography": _master_bio_r77},
                                    reason="focus_prewarm_r77"):
                                _log("ACTOR_WIKI_BIO_PREWARM_R77 actor=%s master_chars=%d" % (
                                    _short_log_value(actor_name, 80), len(_master_bio_r77)))
                    except Exception:
                        pass
                    profile = self._actor_profile_fetch_tmdb_korean_v2454(
                        actor_name,
                        prewarm_token_v2481=token,
                        prewarm_source_rk_v2481=source_rk,
                        existing_local_thumb_v2526=local_fallback_v2526,
                    ) or {}
                    if not profile:
                        cancelled_v2523 = self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk)
                        _helper_ms_v2600 = int((time.time()-helper_t0_v2523)*1000.0)
                        if str(reason or "").startswith("actor_visible_enrich_") and not cancelled_v2523:
                            self._actor_profile_publish_meta_kpi_v2611(actor_name, "unavailable", source="helper_no_profile", profile={})
                        _log("ACTOR_PROFILE_HELPER_PREWARM_END_V2526 actor=%s token=%d ready=0 cancelled=%d elapsed_ms=%d" % (
                            _short_log_value(actor_name,80), token, 1 if cancelled_v2523 else 0, _helper_ms_v2600
                        ))
                        try:
                            pkm_uhd_diag_v2600.event(
                                "ACTOR_HELPER_END",
                                extra="actor=%s token=%d ready=0 cancelled=%d helper_ms=%d" % (
                                    _short_log_value(actor_name,60), token, 1 if cancelled_v2523 else 0, _helper_ms_v2600
                                )
                            )
                        except Exception:
                            pass
                        return
                    try:
                        profile.pop("_v2599_provisional", None)
                        profile["_v2611_metadata_ready"] = 1
                    except Exception:
                        pass
                    _helper_ms_v2600 = int((time.time()-helper_t0_v2523)*1000.0)
                    _log("ACTOR_PROFILE_HELPER_PREWARM_END_V2526 actor=%s token=%d ready=1 cancelled=0 elapsed_ms=%d source=%s" % (
                        _short_log_value(actor_name,80), token, _helper_ms_v2600, profile.get("source") or ""
                    ))
                    try:
                        pkm_uhd_diag_v2600.event(
                            "ACTOR_HELPER_END",
                            extra="actor=%s token=%d ready=1 helper_ms=%d source=%s" % (
                                _short_log_value(actor_name,60), token, _helper_ms_v2600, _short_log_value(profile.get("source") or "",80)
                            )
                        )
                    except Exception:
                        pass
                    # V2613 desktop reference: once identity/biography is known
                    # during cast focus, start Person Images immediately as a
                    # background prewarm.  This is intentionally NOT enabled on
                    # Android/U+; it gives PC the complete reference behavior and
                    # lets the alternate portrait already be local by click time.
                    try:
                        if (not self._uhd_kpi_proxy_v2605()) and str(profile.get("tmdb_id") or "").strip() and not str(profile.get("portrait_local_v2544") or "").strip():
                            _armed_portrait_v2613 = self._actor_profile_schedule_portrait_upgrade_v2544(actor_name, profile, previsible_v2613=True)
                            _log("ACTOR_PROFILE_PORTRAIT_PRECLICK_ARM_V2613 actor=%s tmdb=%s armed=%d desktop_reference=1 android=0" % (
                                _short_log_value(actor_name,80), profile.get("tmdb_id") or "", 1 if _armed_portrait_v2613 else 0
                            ))
                    except Exception:
                        _log("ACTOR_PROFILE_PORTRAIT_PRECLICK_ARM_FAILED_V2613 actor=%s err=%s" % (
                            _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                if self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk):
                    _log("ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2523 actor=%s token=%d stage=profile" % (_short_log_value(actor_name,80), token))
                    return

                # v2544: prewarm never waits for Person Images. Reuse a previously
                # cached TMDb alternate when it already exists locally; otherwise
                # publish the parent Info cast portrait as the complete first-paint
                # image. TMDb upgrade starts only after an ActorProfile is visible.
                actor_thumb = ""
                actor_thumb_source_v2539 = "placeholder_v2544"
                cached_alt_v2544 = str(profile.get("portrait_local_v2544") or "").strip()
                try:
                    if cached_alt_v2544 and not cached_alt_v2544.lower().startswith(("http://", "https://", "image://")):
                        cached_alt_v2544 = xbmcvfs.translatePath(cached_alt_v2544) if cached_alt_v2544.lower().startswith("special://") else cached_alt_v2544
                        if os.path.isfile(cached_alt_v2544) and os.path.getsize(cached_alt_v2544) > 1024:
                            actor_thumb = cached_alt_v2544
                            actor_thumb_source_v2539 = "tmdb_alt_global_cache_v2544"
                except Exception:
                    actor_thumb = ""
                if not actor_thumb and local_fallback_v2526:
                    actor_thumb = local_fallback_v2526
                    actor_thumb_source_v2539 = "info_cast_first_v2544"
                _log("ACTOR_PROFILE_PORTRAIT_PREWARM_V2544 actor=%s source=%s cached_tmdb=%d info_cast=%d network_wait=0" % (
                    _short_log_value(actor_name,80), actor_thumb_source_v2539,
                    1 if actor_thumb_source_v2539 == "tmdb_alt_global_cache_v2544" else 0,
                    1 if actor_thumb_source_v2539 == "info_cast_first_v2544" else 0
                ))
                if self._actor_profile_prewarm_cancelled_v2481(token, actor_name, source_rk):
                    _log("ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2481 actor=%s token=%d stage=session_ready" % (_short_log_value(actor_name,80), token))
                    return

                # Publish complete click-ready data BEFORE persistent hashing.
                self._actor_page_session_ready_put_v2526(
                    actor_name, source_rk, profile, movie_rows, tv_rows,
                    local_thumb=actor_thumb,
                    source="media_ahead_v2526" if str(reason or "").startswith("media_cast_ahead_v2526") else "actor_intent_v2526",
                )
                ready_published_v2526 = True
                # V2599: if the provisional Actor page is already
                # visible, publish only metadata properties on the GUI thread.
                try:
                    with self._actor_profile_enrich_lock_v2599:
                        self._actor_profile_enrich_pending_v2599 = (actor_name, dict(profile or {}))
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass
                ready_elapsed_v2526 = int((time.time()-started)*1000.0)
                _log("ACTOR_PROFILE_CLICK_READY_V2526 actor=%s source=%s elapsed_ms=%d persistent_store_pending=1 complete_profile=1 local_works=1 local_thumb=%d" % (
                    _short_log_value(actor_name,80), source_rk or "", ready_elapsed_v2526, 1 if actor_thumb else 0
                ))

                # Persistence is valuable for future sessions but is not part of
                # the current-session readiness barrier.
                self._actor_page_prepared_store_v2467(
                    actor_name, source_rk, profile, movie_rows, tv_rows, local_thumb=actor_thumb
                )
                _log("ACTOR_PROFILE_FOCUS_PREWARM_DONE_V2526 actor=%s movies=%d tv=%d elapsed_ms=%d native=0 gui_write=0 session_ready_before_persist=1" % (
                    _short_log_value(actor_name,80), len(movie_rows), len(tv_rows), int((time.time()-started)*1000.0)
                ))
            except Exception:
                _log("ACTOR_PROFILE_FOCUS_PREWARM_FAILED_V2526 actor=%s err=%s" % (
                    _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            finally:
                try:
                    if int(token) == int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0):
                        self._actor_profile_prewarm_running_v2481 = False
                        self._actor_profile_prewarm_inflight_v2526 = False
                        self._actor_profile_prewarm_reason_v2543 = ""
                        self._actor_profile_prewarm_helper_started_ms_v2543 = 0
                        # Wake any foreground wait even on failure; the click can
                        # then execute the authoritative cold fallback itself.
                        evt = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                        if evt is not None and not evt.is_set():
                            evt.set()
                except Exception:
                    pass
        return worker

    def _schedule_actor_profile_focus_prewarm_v2481(self, control_id, reason="cast_focus"):
        """Capture the currently focused cast item and schedule data-only prewarm."""
        try:
            control_id = int(control_id or 0)
            if control_id not in (6100, 6110):
                return False
            ctrl = self.getControl(control_id)
            selected = ctrl.getSelectedItem() if ctrl else None
            if selected is None:
                return False
            actor_name = str(selected.getProperty("PlexKM.Cast.Name") or selected.getLabel() or "").strip()
            source_rk = str(getattr(self, "_last_info_rating_key", "") or "").strip()
            fallback_thumb = str(selected.getProperty("PlexKM.Cast.Thumb") or "").strip()
            index = str(selected.getProperty("PlexKM.Cast.Index") or "").strip()
            if index:
                try:
                    fallback_thumb = str(
                        xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast%s.OriginalThumb" % index)
                        or fallback_thumb
                    ).strip()
                except Exception:
                    pass
            # V2615 desktop reference: same-panel focus is the authoritative actor
            # intent. Give rapid key repeats one tiny 80 ms cancellation window, then
            # start TMDb immediately. Android/U+ keeps the existing local-first path;
            # its pre-visible helper network is still blocked by the proxy policy.
            _focus_settle_v2615 = 350 if self._uhd_kpi_proxy_v2605() else 80
            return self._schedule_actor_profile_item_prewarm_v2481(
                actor_name, source_rk=source_rk, fallback_thumb=fallback_thumb, reason=reason,
                settle_ms_v2526=_focus_settle_v2615
            )
        except Exception:
            return False

    def _schedule_actor_profile_direction_target_v2481(self, control_id, action_id, reason="cast_direction"):
        """Capture the next horizontal cast item before Kodi moves the panel.

        onFocus is not guaranteed for each item inside the same panel.  Direction
        actions therefore pre-arm the exact next item using the current native
        position while still on the GUI thread; the worker receives only strings.
        """
        try:
            control_id = int(control_id or 0)
            if control_id not in (6100, 6110) or action_id not in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
                return False
            ctrl = self.getControl(control_id)
            size = int(ctrl.size()) if ctrl else 0
            pos = int(ctrl.getSelectedPosition()) if ctrl else -1
            if size <= 0 or pos < 0:
                return False
            # V2615 PC trace proved Kodi's onAction callback observes the panel
            # AFTER native horizontal selection has already advanced. V2614 then
            # added +/-1 again and warmed the actor one slot ahead (e.g. moving to
            # Ewan McGregor armed Maisy Stella). On desktop/reference use the
            # current native position as the exact target. Keep Android/U+ on the
            # previously proven pre-move calculation until the real box is measured.
            # V2671: Kodi is the sole horizontal mover on every platform.
            # onAction observes the native selected position; never add +/-1 in Python.
            # The old Android branch could prewarm the actor one slot ahead and made
            # one key press look like a two-item jump under load.
            target = pos
            _target_mode_v2615 = "native_postmove_current_v2671"
            if target < 0 or target >= size:
                return False
            try:
                item = ctrl.getListItem(target)
            except Exception:
                item = None
            if item is None:
                return False
            actor_name = str(item.getProperty("PlexKM.Cast.Name") or item.getLabel() or "").strip()
            fallback_thumb = str(item.getProperty("PlexKM.Cast.Thumb") or "").strip()
            index = str(item.getProperty("PlexKM.Cast.Index") or "").strip()
            if index:
                try:
                    fallback_thumb = str(
                        xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast%s.OriginalThumb" % index)
                        or fallback_thumb
                    ).strip()
                except Exception:
                    pass
            _log("ACTOR_PROFILE_DIRECTION_TARGET_V2615 control=%d action=%d pos=%d target=%d actor=%s mode=%s" % (
                control_id, action_id, pos, target, _short_log_value(actor_name,80), _target_mode_v2615
            ))
            return self._schedule_actor_profile_item_prewarm_v2481(
                actor_name,
                source_rk=str(getattr(self, "_last_info_rating_key", "") or "").strip(),
                fallback_thumb=fallback_thumb,
                reason=reason,
                # V2615: desktop target is no longer speculative one-slot-ahead, so
                # a short 80 ms repeat-key debounce is enough. This gives the exact
                # actor hundreds of milliseconds of useful TMDb runway before a
                # typical click without allowing every rapid LEFT/RIGHT to own the
                # Helper language lock. Android/U+ keeps 1500 ms unchanged.
                settle_ms_v2526=(180 if self._uhd_kpi_proxy_v2605() else 80),
            )
        except Exception:
            return False

    def _actor_profile_helper_korean_value_v2454(self, helper):
        """Resolve Helper's Korean option from its installed settings schema.

        v0.0.11 proved 5.4.16 uses raw language=38 for Korean (South Korea),
        but production still discovers the option instead of depending on that index.
        """
        try:
            helper_root = str(helper.getAddonInfo("path") or "").strip()
            settings_path = os.path.join(helper_root, "resources", "settings.xml")
            if os.path.exists(settings_path):
                root = ET.parse(settings_path).getroot()
                lang_node = None
                for node in root.iter("setting"):
                    if str(node.get("id") or "").strip() == "language":
                        lang_node = node
                        break
                if lang_node is not None:
                    options = []
                    for opt in lang_node.iter("option"):
                        value = str((opt.text or opt.get("value") or "")).strip()
                        raw_label = str(opt.get("label") or "").strip()
                        label = raw_label
                        if raw_label.isdigit():
                            try:
                                label = str(helper.getLocalizedString(int(raw_label)) or raw_label)
                            except Exception:
                                label = raw_label
                        options.append((value, raw_label, label))
                    if not options:
                        values = [v.strip() for v in str(lang_node.get("values") or "").split("|") if v.strip()]
                        labels = [v.strip() for v in str(lang_node.get("lvalues") or lang_node.get("labels") or "").split("|") if v.strip()]
                        for idx in range(max(len(values), len(labels))):
                            value = values[idx] if idx < len(values) else str(idx)
                            raw_label = labels[idx] if idx < len(labels) else value
                            label = raw_label
                            if raw_label.isdigit():
                                try:
                                    label = str(helper.getLocalizedString(int(raw_label)) or raw_label)
                                except Exception:
                                    pass
                            options.append((value, raw_label, label))
                    for value, raw_label, label in options:
                        blob = "%s %s %s" % (value, raw_label, label)
                        folded = blob.casefold()
                        if "korean" in folded or "한국" in blob or "ko-kr" in folded or folded.strip() == "ko":
                            return value, label
        except Exception:
            _log("ACTOR_PROFILE_HELPER_LANGUAGE_DISCOVERY_FAILED_V2454 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if str(helper.getAddonInfo("version") or "").strip() == "5.4.16":
                return "38", "Korean (South Korea)"
        except Exception:
            pass
        return "", ""

    def _actor_profile_parse_helper_item_v2454(self, item):
        if not isinstance(item, dict):
            return {}
        raw = item.get("customproperties") or {}
        props = {str(k or "").strip().casefold(): v for k, v in raw.items()} if isinstance(raw, dict) else {}
        def _p(name):
            return str(props.get(str(name or "").casefold()) or "").strip()
        unique = item.get("uniqueid") or {}
        tmdb_id = _p("TMDb_ID")
        if not tmdb_id and isinstance(unique, dict):
            tmdb_id = str(unique.get("tmdb") or unique.get("TMDb") or unique.get("TMDB") or "").strip()
        art = item.get("art") or {}
        thumb = str(item.get("thumbnail") or (art.get("thumb") if isinstance(art, dict) else "") or "").strip()
        if thumb:
            try:
                thumb = _clean_external_image_url(thumb) or thumb
            except Exception:
                pass
        return {
            "label": str(item.get("label") or item.get("title") or "").strip(),
            "tmdb_id": tmdb_id,
            "birthday": _p("Birthday"),
            "born": _p("Born"),
            "deathday": _p("Deathday"),
            "age": _p("Age"),
            "biography": _p("Biography") or str(item.get("plot") or "").strip(),
            "aliases": _p("Aliases"),
            "gender": _p("Gender"),
            "department": _p("Department"),
            "thumbnail": thumb,
            "hero_thumbnail": "",
        }

    def _actor_profile_publish_upgrade_kpi_v2610(self, actor_name, status, source="", visual=0):
        try:
            actor_name = str(actor_name or "").strip()
            visible_name = str(getattr(self, "_actor_profile_visible_name_v2610", "") or "").strip()
            if not actor_name or not visible_name or actor_name.casefold() != visible_name.casefold():
                return False
            visible_epoch = int(getattr(self, "_actor_profile_visible_epoch_ms_v2610", 0) or 0)
            elapsed = max(0, self._now_ms() - visible_epoch) if visible_epoch > 0 else 0
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.KPI.ActorUpgradeStatus", str(status or ""))
            win.setProperty("PlexKM.KPI.ActorUpgradeMs", str(int(elapsed)))
            win.setProperty("PlexKM.KPI.ActorUpgradeSource", str(source or ""))
            win.setProperty("PlexKM.KPI.ActorUpgradeVisual", "1" if visual else "0")
            win.setProperty("PlexKM.KPI.ActorUpgradeStamp", str(self._now_ms()))
            _log("ACTOR_PROFILE_UPGRADE_KPI_V2610 actor=%s status=%s upgrade_ms=%d visual=%d source=%s" % (
                _short_log_value(actor_name,80), status or "", int(elapsed), 1 if visual else 0, _short_log_value(source,100)
            ))
            return True
        except Exception:
            return False

    def _actor_profile_schedule_portrait_upgrade_idle_v2610(self, actor_name, profile, delay_ms=450, reason="after_visible"):
        """Allow TMDb portrait enrichment only after ActorProfile is visible and input is quiet."""
        try:
            actor_name = str(actor_name or "").strip()
            profile = dict(profile or {})
            tmdb_id = str(profile.get("tmdb_id") or "").strip()
            if not actor_name or not tmdb_id:
                return False
            key = "%s|%s" % (tmdb_id, " ".join(actor_name.casefold().split()))
            lock = getattr(self, "_actor_profile_upgrade_idle_lock_v2610", None)
            if lock is None:
                lock = threading.RLock()
                self._actor_profile_upgrade_idle_lock_v2610 = lock
            with lock:
                pending = getattr(self, "_actor_profile_upgrade_idle_pending_v2610", None)
                if not isinstance(pending, set):
                    pending = set()
                    self._actor_profile_upgrade_idle_pending_v2610 = pending
                if key in pending:
                    _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_IDLE_DEDUPE_V2610 actor=%s tmdb=%s" % (_short_log_value(actor_name,80), tmdb_id))
                    return False
                pending.add(key)
            self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "scheduled", source=reason, visual=0)
            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_IDLE_ARM_V2610 actor=%s tmdb=%s delay_ms=%d reason=%s" % (
                _short_log_value(actor_name,80), tmdb_id, int(delay_ms), reason or ""
            ))

            def _idle_worker_v2610():
                try:
                    monitor = xbmc.Monitor()
                    if monitor.waitForAbort(max(0, int(delay_ms)) / 1000.0):
                        return
                    gate_start = self._now_ms()
                    while not monitor.abortRequested():
                        active_same = bool(
                            self._actor_profile_is_active_v2454()
                            and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                        )
                        if not active_same:
                            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_IDLE_CANCEL_V2610 actor=%s reason=page_changed" % _short_log_value(actor_name,80))
                            return
                        try:
                            hot = bool(self._uhd3_foreground_isolation_active_v2591())
                        except Exception:
                            hot = False
                        try:
                            last_action = int(getattr(self, "_last_action_ms", 0) or 0)
                            input_age = (_pkm_speed_ms() - last_action) if last_action > 0 else 999999
                        except Exception:
                            input_age = 999999
                        if input_age >= 260 or True:
                            # R101: start the TMDb query/download right away.
                            # Waiting for an idle remote postponed it by up to
                            # 7.5 s on Shield while the user browsed the works
                            # rail; the fetch runs on a worker thread anyway.
                            break
                        if (self._now_ms() - gate_start) >= 8000:
                            # V2679: navigation pressure may postpone enrichment, but must
                            # never permanently discard it while the same actor page is open.
                            _wait_ms_v2679 = self._now_ms() - gate_start
                            _log("ACTOR_PROFILE_PORTRAIT_RESCHEDULE_V2679 actor=%s reason=input_hot wait_ms=%d action=keep_waiting" % (
                                _short_log_value(actor_name,80), _wait_ms_v2679
                            ))
                            self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "rescheduled", source=reason, visual=0)
                            gate_start = self._now_ms()
                        if monitor.waitForAbort(0.12):
                            return
                    _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_IDLE_START_V2610 actor=%s tmdb=%s wait_ms=%d postvisible=1" % (
                        _short_log_value(actor_name,80), tmdb_id, max(0, self._now_ms() - gate_start)
                    ))
                    self._actor_profile_schedule_portrait_upgrade_v2544(actor_name, profile)
                finally:
                    try:
                        with lock:
                            pending = getattr(self, "_actor_profile_upgrade_idle_pending_v2610", None)
                            if isinstance(pending, set):
                                pending.discard(key)
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_idle_worker_v2610, name="ActorPortraitIdleV2610", daemon=True).start()
            return True
        except Exception:
            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_IDLE_ARM_FAILED_V2610 actor=%s err=%s" % (
                _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _actor_profile_schedule_portrait_upgrade_v2544(self, actor_name, profile, previsible_v2613=False):
        """Fetch/cache the V2539 alternate TMDb portrait.

        Android/U+ still calls this only after ActorProfile is visible. V2613 lets
        desktop reference mode start the same background worker during cast focus,
        so the final portrait can already be local when the actor is clicked. The
        current page is mutated only when the same actor is actually active.
        """
        actor_name = str(actor_name or "").strip()
        profile = dict(profile or {})
        tmdb_id = str(profile.get("tmdb_id") or "").strip()
        if not actor_name or not tmdb_id:
            return False

        def _valid_local_v2544(value):
            try:
                value = str(value or "").strip()
                if not value or value.lower().startswith(("http://", "https://", "image://")):
                    return ""
                value = xbmcvfs.translatePath(value) if value.lower().startswith("special://") else value
                if os.path.isfile(value) and os.path.getsize(value) > 1024:
                    return value
            except Exception:
                pass
            return ""

        existing_local_v2544 = _valid_local_v2544(profile.get("portrait_local_v2544"))
        if existing_local_v2544:
            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_SKIP_V2544 actor=%s tmdb=%s reason=global_local_cache file=%s" % (
                _short_log_value(actor_name,80), tmdb_id, os.path.basename(existing_local_v2544)
            ))
            return False

        key_v2544 = "%s|%s" % (tmdb_id, " ".join(actor_name.casefold().split()))
        lock_v2544 = getattr(self, "_actor_profile_upgrade_lock_v2544", None)
        if lock_v2544 is None:
            lock_v2544 = threading.RLock()
            self._actor_profile_upgrade_lock_v2544 = lock_v2544
        with lock_v2544:
            inflight_v2544 = getattr(self, "_actor_profile_upgrade_inflight_v2544", None)
            if not isinstance(inflight_v2544, dict):
                inflight_v2544 = {}
                self._actor_profile_upgrade_inflight_v2544 = inflight_v2544
            if key_v2544 in inflight_v2544:
                _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_DEDUPE_V2544 actor=%s tmdb=%s action=keep_existing_worker" % (
                    _short_log_value(actor_name,80), tmdb_id
                ))
                return False
            inflight_v2544[key_v2544] = time.time()

        _worker_v2544 = self._actor_profile_schedule_portrait_upgrade_v2544_step1(_valid_local_v2544, actor_name, inflight_v2544, key_v2544, lock_v2544, previsible_v2613, profile, tmdb_id)

        _PKMHomeThreadV2151(
            target=_worker_v2544, name="ActorPortraitUpgradeV2544", daemon=True
        ).start()
        return True

    def _actor_profile_schedule_portrait_upgrade_v2544_step1(self, _valid_local_v2544, actor_name, inflight_v2544, key_v2544, lock_v2544, previsible_v2613, profile, tmdb_id):
        """Step 1 of _actor_profile_schedule_portrait_upgrade_v2544 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_PORTRAIT_UPGRADE_BEGIN_V2544, ACTOR_PROFILE_PORTRAIT_UPGRADE_QUERY_V2544, ACTOR_PROFILE_PORTRAIT_UPGRADE_READY_V2544, ACTOR_PROFILE_PORTRAIT_UPGRADE_FAILED_V2544."""
        primary_v2544 = str(profile.get("thumbnail_details_v2539") or profile.get("thumbnail") or "").strip()
        _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_BEGIN_V2544 actor=%s tmdb=%s after_visible=%d previsible=%d current_source=info_or_cached" % (
            _short_log_value(actor_name,80), tmdb_id, 0 if previsible_v2613 else 1, 1 if previsible_v2613 else 0
        ))

        def _worker_v2544():
            started_v2544 = time.perf_counter()
            query_ms_v2544 = 0.0
            image_count_v2544 = 0
            selected_v2544 = ""
            local_v2544 = ""
            selection_v2544 = ""
            _desktop_remote_visual_v2616 = False
            _desktop_remote_thumb_v2616 = ""
            try:
                image_dir_v2544 = (
                    "plugin://plugin.video.themoviedb.helper/"
                    "?info=images&tmdb_type=person&tmdb_id=%s"
                ) % quote(tmdb_id, safe="")
                request_v2544 = {
                    "jsonrpc": "2.0", "id": 254401, "method": "Files.GetDirectory",
                    "params": {
                        "directory": image_dir_v2544, "media": "files",
                        "properties": ["title", "thumbnail", "art", "uniqueid", "customproperties"]
                    }
                }
                query_t0_v2544 = time.perf_counter()
                # R103: background TMDB fill jobs use the same TMDB Helper and
                # doubled this query on the Shield (3.0 s).  Hold new fill
                # helper calls while the visible actor's portrait is fetched.
                self._tmdb_helper_priority_until_r103 = time.monotonic() + 8.0
                try:
                    raw_v2544 = xbmc.executeJSONRPC(json.dumps(request_v2544, ensure_ascii=False))
                finally:
                    self._tmdb_helper_priority_until_r103 = 0.0
                payload_v2544 = json.loads(raw_v2544 or "{}")
                query_ms_v2544 = (time.perf_counter() - query_t0_v2544) * 1000.0
                if payload_v2544.get("error"):
                    raise RuntimeError("JSON-RPC images %s" % payload_v2544.get("error"))
                files_v2544 = ((payload_v2544.get("result") or {}).get("files") or [])
                image_count_v2544 = len(files_v2544)

                def _clean_url_v2544(item_v2544):
                    if not isinstance(item_v2544, dict):
                        return ""
                    art_v2544 = item_v2544.get("art") or {}
                    for value_v2544 in (
                        item_v2544.get("thumbnail"),
                        art_v2544.get("thumb") if isinstance(art_v2544, dict) else "",
                        art_v2544.get("poster") if isinstance(art_v2544, dict) else "",
                        art_v2544.get("fanart") if isinstance(art_v2544, dict) else "",
                        item_v2544.get("file"),
                    ):
                        value_v2544 = str(value_v2544 or "").strip()
                        if not value_v2544 or value_v2544.casefold().startswith("plugin://"):
                            continue
                        try:
                            value_v2544 = _clean_external_image_url(value_v2544) or value_v2544
                        except Exception:
                            pass
                        if value_v2544:
                            return value_v2544
                    return ""

                def _identity_v2544(value_v2544):
                    value_v2544 = str(value_v2544 or "").strip()
                    if not value_v2544:
                        return ""
                    try:
                        value_v2544 = _clean_external_image_url(value_v2544) or value_v2544
                    except Exception:
                        pass
                    value_v2544 = re.sub(
                        r"(?i)(image\.tmdb\.org/t/p/)(w45|w92|w154|w185|w342|w500|h632|original)(/)",
                        r"\1{size}\3", value_v2544,
                    )
                    value_v2544 = re.sub(
                        r"(?i)(image\.tmdb\.org%2[fF]t%2[fF]p%2[fF])(w45|w92|w154|w185|w342|w500|h632|original)(%2[fF])",
                        r"\1{size}\3", value_v2544,
                    )
                    return value_v2544.casefold()

                primary_id_v2544 = _identity_v2544(primary_v2544)
                seen_v2544 = set()
                candidates_v2544 = []
                for item_v2544 in files_v2544:
                    url_v2544 = _clean_url_v2544(item_v2544)
                    ident_v2544 = _identity_v2544(url_v2544)
                    if not url_v2544 or not ident_v2544 or ident_v2544 == primary_id_v2544 or ident_v2544 in seen_v2544:
                        continue
                    seen_v2544.add(ident_v2544)
                    candidates_v2544.append(url_v2544)
                if len(candidates_v2544) >= 2:
                    selected_v2544 = candidates_v2544[1]
                    selection_v2544 = "third_overall_preferred"
                elif len(candidates_v2544) == 1:
                    selected_v2544 = candidates_v2544[0]
                    selection_v2544 = "second_overall_fallback"

                _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_QUERY_V2544 actor=%s tmdb=%s elapsed_ms=%.1f image_count=%d distinct=%d selected=%d selection=%s" % (
                    _short_log_value(actor_name,80), tmdb_id, query_ms_v2544, image_count_v2544,
                    len(candidates_v2544), 1 if selected_v2544 else 0, selection_v2544 or "none"
                ))
                if not selected_v2544:
                    if not previsible_v2613:
                        self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "no_candidate", source="person_images", visual=0)
                    return

                # V2616 desktop reference: once Person Images has selected the final
                # alternate portrait, show that remote texture immediately instead of
                # waiting another 1-1.3 s for PKM's private file download.  The same
                # worker still localizes and persists the image for subsequent opens.
                if not self._uhd_kpi_proxy_v2605():
                    try:
                        _desktop_remote_thumb_v2616 = _cast_remote_display_url_v2608(selected_v2544) or selected_v2544
                        _active_remote_v2616 = bool(
                            (not previsible_v2613)
                            and self._actor_profile_is_active_v2454()
                            and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                        )
                        if _active_remote_v2616 and _desktop_remote_thumb_v2616:
                            self._actor_profile_set_prop_v2454("UpgradeThumb", _desktop_remote_thumb_v2616)
                            _desktop_remote_visual_v2616 = True
                            _log("ACTOR_PROFILE_PORTRAIT_REMOTE_VISUAL_V2616 actor=%s tmdb=%s query_ms=%.1f source=%s remote_first=1 local_backfill=1" % (
                                _short_log_value(actor_name,80), tmdb_id, query_ms_v2544, selection_v2544
                            ))
                            self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "visual_commit", source=selection_v2544 + "_remote_v2616", visual=1)
                    except Exception:
                        _desktop_remote_visual_v2616 = False

                # PKM_CAST_PROGRESSIVE_R15: a pre-click portrait upgrade must not
                # compete with the visible Info cast rail for the 2 artwork lanes.
                local_v2544 = self._actor_profile_localize_thumb_v2467(
                    selected_v2544, actor_name=actor_name, max_wait_ms=4000,
                    priority_r15=(pkm_artwork_scheduler.PRIORITY_PREWARM if previsible_v2613
                                  else pkm_artwork_scheduler.PRIORITY_VISIBLE)
                ) or ""
                local_v2544 = _valid_local_v2544(local_v2544)
                if not local_v2544:
                    _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_FAILED_V2544 actor=%s tmdb=%s reason=localize_failed elapsed_ms=%d" % (
                        _short_log_value(actor_name,80), tmdb_id,
                        int((time.perf_counter()-started_v2544)*1000.0)
                    ), xbmc.LOGWARNING)
                    if not previsible_v2613:
                        self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "failed_localize", source="person_images", visual=0)
                    return

                merged_v2544 = self._actor_profile_cache_get_v2454(actor_name) or dict(profile)
                if str(merged_v2544.get("tmdb_id") or "").strip() not in ("", tmdb_id):
                    _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_FAILED_V2544 actor=%s tmdb=%s reason=cache_identity_changed" % (
                        _short_log_value(actor_name,80), tmdb_id
                    ), xbmc.LOGWARNING)
                    return
                merged_v2544["tmdb_id"] = tmdb_id
                merged_v2544["thumbnail"] = selected_v2544
                merged_v2544["portrait_local_v2544"] = local_v2544
                merged_v2544["portrait_selection_v2539"] = selection_v2544
                merged_v2544["portrait_policy_version_v2539"] = 2544
                merged_v2544["portrait_image_count_v2544"] = int(image_count_v2544)
                merged_v2544["portrait_upgrade_source_v2544"] = "person_images_previsible_v2613" if previsible_v2613 else "person_images_after_visible_v2544"
                merged_v2544["portrait_upgrade_ts_v2544"] = int(time.time())
                self._actor_profile_cache_put_v2454(actor_name, merged_v2544)

                total_ms_v2544 = (time.perf_counter()-started_v2544)*1000.0
                _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_READY_V2544 actor=%s tmdb=%s query_ms=%.1f total_ms=%.1f bytes=%d selection=%s cached_global=1" % (
                    _short_log_value(actor_name,80), tmdb_id, query_ms_v2544, total_ms_v2544,
                    int(os.path.getsize(local_v2544)), selection_v2544
                ))
                if not previsible_v2613:
                    self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "ready_local", source=selection_v2544, visual=0)

                # Visual upgrade is allowed only for the same still-active actor.
                # The next visit reads portrait_local_v2544 directly and therefore
                # starts with the TMDb portrait instead of replaying the fade.
                try:
                    active_same_v2544 = bool(
                        self._actor_profile_is_active_v2454()
                        and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                    )
                    # R113: a portrait that arrives seconds after the page is
                    # visible reads as the photo "changing" under the viewer
                    # (SHIELD: +3.2 s).  Late results are cached for the next
                    # visit but do not swap the visible photo now.
                    if active_same_v2544 and not previsible_v2613 and not _desktop_remote_visual_v2616 and total_ms_v2544 > 900.0:
                        _log("ACTOR_PROFILE_PORTRAIT_LATE_SWAP_SKIP_R113 actor=%s tmdb=%s total_ms=%.0f cached_for_next_visit=1" % (
                            _short_log_value(actor_name,80), tmdb_id, total_ms_v2544))
                        active_same_v2544 = False
                    if active_same_v2544:
                        win_v2544 = xbmcgui.Window(10000)
                        current_thumb_v2544 = str(win_v2544.getProperty("PlexKM.ActorProfile.Thumb") or "").strip()
                        if _desktop_remote_visual_v2616:
                            # The remote overlay is already the visible final portrait.
                            # Promote the downloaded copy underneath it and retire the
                            # overlay after a few frames; no second visual transition.
                            self._actor_profile_set_prop_v2454("Thumb", local_v2544)
                            self._actor_profile_bg_blur_schedule_r92(actor_name, local_v2544)
                            xbmc.Monitor().waitForAbort(0.048)
                            if (
                                self._actor_profile_is_active_v2454()
                                and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                            ):
                                self._actor_profile_set_prop_v2454("UpgradeThumb", "")
                                _log("ACTOR_PROFILE_PORTRAIT_REMOTE_TO_LOCAL_COMMIT_V2616 actor=%s tmdb=%s local=%s current_page=1 visual_transition=0" % (
                                    _short_log_value(actor_name,80), tmdb_id, os.path.basename(local_v2544)
                                ))
                        elif os.path.normcase(os.path.abspath(current_thumb_v2544)) != os.path.normcase(os.path.abspath(local_v2544)):
                            # v2548: V2544 already produced and cached the correct local TMDb
                            # portrait, but the skin had no control bound to UpgradeThumb.
                            # Bind a real visible overlay in XML, fade it over the already
                            # visible Info/cached portrait, then promote the same local file
                            # to the base Thumb after the fade.  The page never waits for
                            # this path and Biography/layout are not touched.
                            self._actor_profile_set_prop_v2454("UpgradeThumb", local_v2544)
                            _log("ACTOR_PROFILE_PORTRAIT_LATE_COMMIT_V2679 actor=%s tmdb=%s source=tmdb_alt_local" % (
                                _short_log_value(actor_name,80), tmdb_id
                            ))
                            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_VISUAL_V2544 actor=%s fade_ms=260 source=tmdb_alt_local late_pop=soft_overlay" % (
                                _short_log_value(actor_name,80)
                            ))
                            _log("ACTOR_PROFILE_PORTRAIT_OVERLAY_BEGIN_V2548 actor=%s tmdb=%s fade_ms=260 local=%s" % (
                                _short_log_value(actor_name,80), tmdb_id, os.path.basename(local_v2544)
                            ))

                            # Keep the local TMDb portrait as the visible overlay for the
                            # full fade duration. Afterwards rebind the base Thumb to the
                            # same decoded local texture, wait a few render frames, and
                            # retire the overlay. If the user left/reopened/switched actor,
                            # do not mutate the current page; the global cache is already
                            # ready for the next entry.
                            if not xbmc.Monitor().waitForAbort(0.320):
                                active_commit_v2548 = bool(
                                    self._actor_profile_is_active_v2454()
                                    and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                                )
                                upgrade_now_v2548 = str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.UpgradeThumb") or "").strip()
                                if active_commit_v2548 and upgrade_now_v2548 == local_v2544:
                                    self._actor_profile_set_prop_v2454("Thumb", local_v2544)
                                    self._actor_profile_bg_blur_schedule_r92(actor_name, local_v2544)
                                    _log("ACTOR_PROFILE_PORTRAIT_BASE_REBIND_V2548 actor=%s tmdb=%s after_ms=320 local=%s" % (
                                        _short_log_value(actor_name,80), tmdb_id, os.path.basename(local_v2544)
                                    ))
                                    xbmc.Monitor().waitForAbort(0.048)
                                    active_clear_v2548 = bool(
                                        self._actor_profile_is_active_v2454()
                                        and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                                    )
                                    upgrade_clear_v2548 = str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.UpgradeThumb") or "").strip()
                                    base_clear_v2548 = str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.Thumb") or "").strip()
                                    if active_clear_v2548 and upgrade_clear_v2548 == local_v2544 and base_clear_v2548 == local_v2544:
                                        self._actor_profile_set_prop_v2454("UpgradeThumb", "")
                                        _log("ACTOR_PROFILE_PORTRAIT_ATOMIC_COMMIT_V2548 actor=%s tmdb=%s fade_ms=260 base_rebind_ms=320 overlay_clear_ms=368 current_page=1" % (
                                            _short_log_value(actor_name,80), tmdb_id
                                        ))
                                        self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "visual_commit", source=selection_v2544, visual=1)
                                    else:
                                        _log("ACTOR_PROFILE_PORTRAIT_COMMIT_SKIP_V2548 actor=%s tmdb=%s stage=overlay_clear active=%d same_upgrade=%d same_base=%d" % (
                                            _short_log_value(actor_name,80), tmdb_id,
                                            1 if active_clear_v2548 else 0,
                                            1 if upgrade_clear_v2548 == local_v2544 else 0,
                                            1 if base_clear_v2548 == local_v2544 else 0
                                        ))
                                else:
                                    _log("ACTOR_PROFILE_PORTRAIT_COMMIT_SKIP_V2548 actor=%s tmdb=%s stage=base_rebind active=%d same_upgrade=%d cached_for_next=1" % (
                                        _short_log_value(actor_name,80), tmdb_id,
                                        1 if active_commit_v2548 else 0,
                                        1 if upgrade_now_v2548 == local_v2544 else 0
                                    ))
                except Exception:
                    _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_VISUAL_FAILED_V2544 actor=%s err=%s" % (
                        _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            except Exception:
                _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_FAILED_V2544 actor=%s tmdb=%s reason=worker_error err=%s" % (
                    _short_log_value(actor_name,80), tmdb_id, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
                if not previsible_v2613:
                    self._actor_profile_publish_upgrade_kpi_v2610(actor_name, "failed_worker", source="person_images", visual=0)
            finally:
                try:
                    with lock_v2544:
                        inflight_v2544.pop(key_v2544, None)
                except Exception:
                    pass
        return _worker_v2544

    def _actor_profile_fetch_tmdb_korean_v2454(self, actor_name, prewarm_token_v2481=0, prewarm_source_rk_v2481="", existing_local_thumb_v2526=""):
        """Fetch person profile Korean-first with exact-ID and original-language bio fallback.

        v2455 fixes a V2454 quality bug: a partial Helper result containing only
        birthday/born was accepted as complete and cached for seven days even when
        Biography was empty. Korean is still authoritative; original Helper language
        is used only as a Biography fallback when Korean remains unavailable.
        """
        actor_name = str(actor_name or "").strip()
        if not actor_name:
            return {}
        # PKM_UHD4K_ACTOR_FIX_R2: cached English must never outrank local Korean BIO.
        cached = self._actor_profile_cache_get_v2454(actor_name)
        try:
            _master = self._actor_master_profile_ko_v2703(actor_name, str((cached or {}).get("tmdb_id") or "")) or {}
            _korean_bio = str(_master.get("biography_ko") or "").strip()
            if _korean_bio and re.search(r"[가-힣]", _korean_bio):
                _local_profile = dict(cached or {})
                _local_profile["biography"] = _korean_bio
                _local_profile["biography_source"] = "actor_master_local_db_uhd4k"
                _local_profile["actor_master_authority"] = "1"
                _local_profile["tmdb_id"] = str(_master.get("tmdb_id") or _local_profile.get("tmdb_id") or "")
                if _master.get("name_ko"):
                    _local_profile["name_ko"] = _master["name_ko"]
                _local_profile["source"] = "actor_master_local_first_uhd4k"
                self._actor_profile_cache_put_v2454(actor_name, _local_profile)
                _log("ACTOR_UHD4K_LOCAL_BIO_READY actor=%s chars=%d helper=0" % (_short_log_value(actor_name,80), len(_korean_bio)))
                return _local_profile
        except Exception as _master_error:
            _log("ACTOR_UHD4K_LOCAL_BIO_ERROR actor=%s type=%s" % (_short_log_value(actor_name,80), type(_master_error).__name__))
        if cached:
            cached["source"] = "tmdb_helper_profile_cache_v2460"
            return cached
        try:
            helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        except Exception:
            _log("ACTOR_PROFILE_HELPER_MISSING_V2455 actor=%s" % _short_log_value(actor_name, 80), xbmc.LOGWARNING)
            return {}

        def _query_person(directory, request_id):
            request = {
                "jsonrpc": "2.0", "id": int(request_id), "method": "Files.GetDirectory",
                "params": {"directory": directory, "media": "files",
                           "properties": ["title", "plot", "thumbnail", "art", "uniqueid", "customproperties"]}
            }
            raw = xbmc.executeJSONRPC(json.dumps(request, ensure_ascii=False))
            payload = json.loads(raw or "{}")
            if payload.get("error"):
                raise RuntimeError("JSON-RPC %s" % payload.get("error"))
            files = ((payload.get("result") or {}).get("files") or [])
            # info=details person directory always exposes the actual person as item 0.
            profile = self._actor_profile_parse_helper_item_v2454(files[0]) if files else {}
            return profile, files

        def _query_person_bio_v2547(directory, request_id):
            """Biography-only JSON-RPC projection for the original-language fallback.

            TMDb Helper still performs the exact-ID lean lookup, but Kodi no longer
            asks it to serialize artwork/thumbnail fields that V2544 deliberately
            removed from the ActorProfile critical path.  This is a small but safe
            reduction on top of the larger Korean detailed=false change.
            """
            request = {
                "jsonrpc": "2.0", "id": int(request_id), "method": "Files.GetDirectory",
                "params": {"directory": directory, "media": "files",
                           "properties": ["title", "plot", "uniqueid", "customproperties"]}
            }
            raw = xbmc.executeJSONRPC(json.dumps(request, ensure_ascii=False))
            payload = json.loads(raw or "{}")
            if payload.get("error"):
                raise RuntimeError("JSON-RPC bio %s" % payload.get("error"))
            files = ((payload.get("result") or {}).get("files") or [])
            profile = self._actor_profile_parse_helper_item_v2454(files[0]) if files else {}
            return profile, files

        started = time.time()
        with self._actor_profile_tmdb_lock_v2454:
            # v2481: a same-actor focus-intent worker may have completed while a
            # foreground click waited for Helper's global language lock. Recheck
            # the cache after acquiring the lock so the click never repeats the
            # 3-5 second Helper transaction.
            cached_locked_v2481 = self._actor_profile_cache_get_v2454(actor_name)
            if cached_locked_v2481:
                cached_locked_v2481["source"] = "tmdb_helper_profile_cache_locked_v2481"
                _log("ACTOR_PROFILE_HELPER_LOCK_RECHECK_HIT_V2481 actor=%s elapsed=%.1fms" % (
                    _short_log_value(actor_name,80), (time.time()-started)*1000.0
                ))
                return cached_locked_v2481
            if self._actor_profile_prewarm_cancelled_v2481(prewarm_token_v2481, actor_name, prewarm_source_rk_v2481):
                _log("ACTOR_PROFILE_HELPER_PREWARM_ABORT_V2481 actor=%s stage=before_lock_work" % _short_log_value(actor_name,80))
                return {}
            original = ""
            korean_value = ""
            korean_label = ""
            switched = False
            profile = {}
            korean_exact_retry = False
            original_bio_fallback = False
            plex_bio_event_v2546 = None
            plex_bio_state_v2546 = {}
            try:
                original = str(helper.getSetting("language") or "").strip()
                korean_value, korean_label = self._actor_profile_helper_korean_value_v2454(helper)
                if not korean_value:
                    _log("ACTOR_PROFILE_HELPER_KOREAN_OPTION_MISSING_V2455 actor=%s helper=%s" % (
                        _short_log_value(actor_name, 80), helper.getAddonInfo("version") or ""
                    ), xbmc.LOGWARNING)
                    return {}

                files, profile, switched = self._actor_profile_fetch_tmdb_korean_v2454_step1(_query_person, actor_name, helper, korean_value, original, switched)
                if self._actor_profile_prewarm_cancelled_v2481(prewarm_token_v2481, actor_name, prewarm_source_rk_v2481):
                    _log("ACTOR_PROFILE_HELPER_PREWARM_ABORT_V2481 actor=%s stage=after_search" % _short_log_value(actor_name,80))
                    return {}

                # V2454 accepted birthday/born-only data as complete. If Korean
                # Biography is empty, retry the already-resolved exact Person ID.
                tmdb_id = str(profile.get("tmdb_id") or "").strip()
                # v2526: a query-based person details item already carries the
                # resolved TMDb id and, in the common case, birthday. Re-running
                # the same Korean details route solely because Biography is empty
                # costs another full Helper plugin invocation and does not create a
                # Korean biography that TMDb does not have. Keep exact-ID repair
                # only when an essential identity field (birthday) is also missing.
                if tmdb_id and not str(profile.get("biography") or "").strip() and not str(profile.get("birthday") or "").strip():
                    korean_exact_retry = True
                    # v2481: the exact-ID request follows the same already-set
                    # Korean Helper language; an extra 220ms sleep had no state
                    # transition to settle and only extended every no-bio cold open.
                    exact_dir = (
                        "plugin://plugin.video.themoviedb.helper/"
                        "?info=details&tmdb_type=person&tmdb_id=%s&detailed=true&cacheonly=false&fanarttv=false"
                    ) % quote(tmdb_id, safe="")
                    _exact_t0_v2542 = time.perf_counter()
                    exact_profile, exact_files = _query_person(exact_dir, 24552)
                    _log("ACTOR_PROFILE_HELPER_STAGE_V2542 actor=%s phase=korean_exact elapsed_ms=%.1f" % (
                        _short_log_value(actor_name,80), (time.perf_counter()-_exact_t0_v2542)*1000.0
                    ))
                    if self._actor_profile_prewarm_cancelled_v2481(prewarm_token_v2481, actor_name, prewarm_source_rk_v2481):
                        _log("ACTOR_PROFILE_HELPER_PREWARM_ABORT_V2481 actor=%s stage=after_exact" % _short_log_value(actor_name,80))
                        return {}
                    if exact_profile:
                        # Prefer exact-ID fields where present, without losing the
                        # actor-name search identity/thumb fallback.
                        merged = dict(profile)
                        for k, v in exact_profile.items():
                            if v:
                                merged[k] = v
                        profile = merged
                        files = exact_files or files

                # v2544: Person Images is no longer on the actor-open critical path.
                # The first visible portrait is the already-rendered local Info cast
                # image.  After the completed actor page is visible, a background
                # worker fetches the V2539-ranked TMDb alternative and softly fades
                # it over the Info portrait.  The local TMDb result is then persisted
                # globally by actor so another movie can reuse it immediately.
                tmdb_id = str(profile.get("tmdb_id") or "").strip()
                profile["hero_thumbnail"] = ""
                details_primary_v2539 = str(profile.get("thumbnail") or "").strip()
                profile["thumbnail_details_v2539"] = details_primary_v2539
                profile["portrait_policy_version_v2539"] = 2544
                if not str(profile.get("portrait_local_v2544") or "").strip():
                    profile["portrait_selection_v2539"] = "info_cast_first_deferred_v2544"
                profile_image_override_v2466 = bool(str(profile.get("portrait_local_v2544") or "").strip())
                profile_image_source_v2466 = (
                    "tmdb_alt_global_cache_v2544" if profile_image_override_v2466
                    else "deferred_after_visible_v2544"
                )
                profile_image_count_v2466 = int(profile.get("portrait_image_count_v2544") or 0)
                person_images_query_ok_v2539 = bool(profile_image_override_v2466)
                _log("ACTOR_PROFILE_PORTRAIT_CRITICAL_PATH_SKIP_V2544 actor=%s tmdb=%s cached_alt=%d first_source=info_cast_local" % (
                    _short_log_value(actor_name,80), tmdb_id, 1 if profile_image_override_v2466 else 0
                ))

                # V2614 desktop reference: Person Images does not depend on the
                # biography fallback.  Start it as soon as the Korean identity pass
                # resolves TMDb ID so its ~1-2 s query/download overlaps the
                # original-language biography request instead of running afterwards.
                try:
                    if (
                        (not self._uhd_kpi_proxy_v2605() or (
                            self._actor_profile_is_active_v2454()
                            and str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip().casefold() == actor_name.casefold()
                        ))
                        and tmdb_id
                        and not str(profile.get("portrait_local_v2544") or "").strip()
                    ):
                        _early_portrait_v2614 = self._actor_profile_schedule_portrait_upgrade_v2544(
                            actor_name, dict(profile or {}), previsible_v2613=True
                        )
                        _log("ACTOR_PROFILE_PORTRAIT_IDENTITY_EARLY_ARM_V2614 actor=%s tmdb=%s armed=%d overlap=original_bio_fallback" % (
                            _short_log_value(actor_name,80), tmdb_id, 1 if _early_portrait_v2614 else 0
                        ))
                except Exception:
                    _log("ACTOR_PROFILE_PORTRAIT_IDENTITY_EARLY_ARM_FAILED_V2614 actor=%s err=%s" % (
                        _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

                if self._actor_profile_prewarm_cancelled_v2481(prewarm_token_v2481, actor_name, prewarm_source_rk_v2481):
                    _log("ACTOR_PROFILE_HELPER_PREWARM_ABORT_V2481 actor=%s stage=before_bio_fallback" % _short_log_value(actor_name,80))
                    return {}

                # v2547: V2546 Plex Discover runtime path is deliberately disabled.
                # It failed with HTTPError for every measured actor and could add up
                # to the 120 ms grace without ever producing Biography.  Preserve
                # the proven TMDb original-language lean fallback directly.
                original_bio_fallback = self._actor_profile_fetch_tmdb_korean_v2454_step2(_query_person, _query_person_bio_v2547, actor_name, helper, korean_value, original, profile, tmdb_id, original_bio_fallback)

                # v2544: no portrait join here. Biography/profile correctness remains
                # atomic, while Person Images is deferred until after ActorProfile is
                # visible. This removes image-server latency from the spinner gate.
                _log("ACTOR_PROFILE_PORTRAIT_NOJOIN_V2544 actor=%s tmdb=%s person_images_wait_ms=0 cached_alt=%d" % (
                    _short_log_value(actor_name,80), tmdb_id, 1 if profile_image_override_v2466 else 0
                ))

                if self._actor_profile_prewarm_cancelled_v2481(prewarm_token_v2481, actor_name, prewarm_source_rk_v2481):
                    _log("ACTOR_PROFILE_HELPER_PREWARM_ABORT_V2481 actor=%s stage=after_parallel_complete" % _short_log_value(actor_name,80))
                    return {}

                if profile.get("tmdb_id"):
                    profile["source"] = "tmdb_helper_korean_v2455"
                    profile["helper_version"] = str(helper.getAddonInfo("version") or "")
                    profile["helper_language"] = korean_value
                    profile["helper_language_label"] = korean_label
                    if not profile.get("biography_source"):
                        profile["biography_source"] = "helper_korean" if profile.get("biography") else "missing"
                    # V2614: an early Person Images worker may finish while the
                    # original-language biography request is still running. Preserve
                    # those portrait fields when the completed metadata profile is
                    # persisted so the later write cannot erase a ready local image.
                    try:
                        _portrait_merge_v2614 = self._actor_profile_cache_get_v2454(actor_name) or {}
                        for _pk_v2614 in (
                            "portrait_local_v2544", "portrait_selection_v2539",
                            "portrait_policy_version_v2539", "portrait_image_count_v2544",
                            "portrait_upgrade_source_v2544", "thumbnail_details_v2539"
                        ):
                            if _portrait_merge_v2614.get(_pk_v2614):
                                profile[_pk_v2614] = _portrait_merge_v2614.get(_pk_v2614)
                    except Exception:
                        pass
                    # R10: apply Actor Master to the LIVE helper profile, not only
                    # to the copy persisted inside cache_put.  This prevents the
                    # caller/session from keeping an English fallback object.
                    profile = self._actor_profile_apply_master_authority_r5(
                        actor_name, dict(profile), stage="helper_resolved_r10"
                    )
                    self._actor_profile_cache_put_v2454(actor_name, profile)

                _log("ACTOR_PROFILE_HELPER_PROFILE_V2466 actor=%s tmdb=%s original_lang=%s korean_lang=%s switched=%d results=%d elapsed=%.1fms bio_chars=%d bio_source=%s exact_retry=%d original_fallback=%d person_images_used=%d image_count=%d image_source=%s" % (
                    _short_log_value(actor_name, 80), profile.get("tmdb_id") or "", original or "",
                    korean_value, 1 if switched else 0, len(files or []), (time.time()-started)*1000.0,
                    len(profile.get("biography") or ""), profile.get("biography_source") or "missing",
                    1 if korean_exact_retry else 0, 1 if original_bio_fallback else 0,
                    1 if profile_image_override_v2466 else 0,
                    int(profile_image_count_v2466 or 0),
                    profile_image_source_v2466
                ))
                return profile
            except Exception:
                _log("ACTOR_PROFILE_HELPER_FETCH_FAILED_V2455 actor=%s err=%s" % (
                    _short_log_value(actor_name, 80), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
                return {}
            finally:
                # Always restore the user's Helper setting, regardless of which
                # fallback stage was active when the transaction ended.
                try:
                    current = str(xbmcaddon.Addon("plugin.video.themoviedb.helper").getSetting("language") or "").strip()
                except Exception:
                    current = ""
                if original and current != original:
                    try:
                        helper.setSetting("language", original)
                        # v2522: setSetting is synchronous for the add-on settings
                        # store. The old fixed 100 ms verification sleep was on the
                        # actor-click critical path but did not contribute page data.
                        restored = str(xbmcaddon.Addon("plugin.video.themoviedb.helper").getSetting("language") or "").strip()
                        _log("ACTOR_PROFILE_HELPER_LANGUAGE_RESTORE_V2522 original=%s restored=%s ok=%d wait_ms=0" % (
                            original, restored, 1 if restored == original else 0
                        ))
                    except Exception:
                        _log("ACTOR_PROFILE_HELPER_LANGUAGE_RESTORE_FAILED_V2455 original=%s err=%s" % (
                            original, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGERROR)

    def _actor_profile_fetch_tmdb_korean_v2454_step1(self, _query_person, actor_name, helper, korean_value, original, switched):
        """Step 1 of _actor_profile_fetch_tmdb_korean_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_HELPER_LANGUAGE_SWITCH_V2542, ACTOR_PROFILE_KOREAN_LEAN_V2547, ACTOR_PROFILE_HELPER_SINGLE_QUERY_V2616, ACTOR_PROFILE_KOREAN_FULL_RETRY_V2547."""
        if original != korean_value:
            _lang_t0_v2542 = time.perf_counter()
            helper.setSetting("language", korean_value)
            switched = True
            # v2542: setSetting is synchronous.  A fresh TMDb Helper plugin
            # invocation reads the setting after this call, so do not pay the
            # old unconditional 500 ms sleep.  Only retry briefly if immediate
            # readback itself proves the value has not committed yet.
            _lang_wait_v2542 = 0
            _lang_readback_v2542 = str(helper.getSetting("language") or "").strip()
            if _lang_readback_v2542 != korean_value:
                xbmc.sleep(120)
                _lang_wait_v2542 = 120
                _lang_readback_v2542 = str(helper.getSetting("language") or "").strip()
            _log("ACTOR_PROFILE_HELPER_LANGUAGE_SWITCH_V2542 actor=%s phase=korean target=%s readback=%s wait_ms=%d elapsed_ms=%.1f" % (
                _short_log_value(actor_name,80), korean_value, _lang_readback_v2542, _lang_wait_v2542,
                (time.perf_counter()-_lang_t0_v2542)*1000.0
            ))

        # v2547: V2546 Plex Discover fallback was a runtime miss in the
        # measured environment (HTTPError on every tested actor), so do not
        # spend any request/grace time on it.  Instead make the authoritative
        # Korean Helper pass lean as well.  Actor portrait/images are already
        # post-visible under V2544, so detailed=true is unnecessary on the
        # common path.  Fall back to the old full query only when the lean
        # result itself fails or does not resolve a TMDb identity.
        search_dir = (
            "plugin://plugin.video.themoviedb.helper/"
            "?info=details&tmdb_type=person&query=%s&detailed=false&cacheonly=false&fanarttv=false"
        ) % quote(actor_name, safe="")
        _details_t0_v2542 = time.perf_counter()
        _v2547_korean_retry_full = False
        _v2547_korean_retry_reason = ""
        profile, files = {}, []
        # V2615: before paying a cold Helper/TMDb request, ask the Helper
        # cache for the same lean Korean person. This is network-free by
        # contract and is especially useful after another Kodi surface or
        # prior session already populated TMDb Helper's own cache even when
        # PKM's actor JSON has not been warmed yet.
        # V2616: do not invoke TMDb Helper twice.  V2615's separate
        # cacheonly=true Files.GetDirectory call still paid the full plugin
        # invocation cost (1.3-1.6 s in the PC trace).  The normal Helper
        # request already consults its own cache internally, so use one call.
        _ko_cache_hit_v2615 = False
        _v2616_ko_t0 = time.perf_counter()
        try:
            profile, files = _query_person(search_dir, 26161)
        except Exception:
            profile, files = {}, []
            _v2547_korean_retry_full = True
            _v2547_korean_retry_reason = "lean_query_error"
            _log("ACTOR_PROFILE_KOREAN_LEAN_V2547 actor=%s ok=0 retry_full=1 reason=%s elapsed_ms=%.1f err=%s" % (
                _short_log_value(actor_name,80), _v2547_korean_retry_reason,
                (time.perf_counter()-_details_t0_v2542)*1000.0,
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        _log("ACTOR_PROFILE_HELPER_SINGLE_QUERY_V2616 actor=%s stage=korean elapsed_ms=%.1f tmdb=%s bio_chars=%d" % (
            _short_log_value(actor_name,80), (time.perf_counter()-_v2616_ko_t0)*1000.0,
            str((profile or {}).get("tmdb_id") or ""), len(str((profile or {}).get("biography") or ""))
        ))
        _v2547_lean_tmdb = str((profile or {}).get("tmdb_id") or "").strip()
        if not profile:
            _v2547_korean_retry_full = True
            _v2547_korean_retry_reason = _v2547_korean_retry_reason or "lean_empty_profile"
        elif not _v2547_lean_tmdb:
            _v2547_korean_retry_full = True
            _v2547_korean_retry_reason = _v2547_korean_retry_reason or "lean_missing_tmdb"
        _log("ACTOR_PROFILE_KOREAN_LEAN_V2547 actor=%s ok=%d elapsed_ms=%.1f tmdb=%s bio_chars=%d birthday=%d results=%d retry_full=%d reason=%s cache_hit=%d" % (
            _short_log_value(actor_name,80), 1 if profile else 0, (time.perf_counter()-_details_t0_v2542)*1000.0,
            _v2547_lean_tmdb, len(str((profile or {}).get("biography") or "")),
            1 if str((profile or {}).get("birthday") or "").strip() else 0, len(files or []),
            1 if _v2547_korean_retry_full else 0, _v2547_korean_retry_reason or "none",
            1 if _ko_cache_hit_v2615 else 0
        ))

        if _v2547_korean_retry_full:
            search_dir_full_v2547 = (
                "plugin://plugin.video.themoviedb.helper/"
                "?info=details&tmdb_type=person&query=%s&detailed=true&cacheonly=false&fanarttv=false"
            ) % quote(actor_name, safe="")
            _v2547_full_t0 = time.perf_counter()
            profile, files = _query_person(search_dir_full_v2547, 25472)
            _log("ACTOR_PROFILE_KOREAN_FULL_RETRY_V2547 actor=%s reason=%s elapsed_ms=%.1f tmdb=%s bio_chars=%d birthday=%d" % (
                _short_log_value(actor_name,80), _v2547_korean_retry_reason or "compatibility",
                (time.perf_counter()-_v2547_full_t0)*1000.0,
                str((profile or {}).get("tmdb_id") or ""), len(str((profile or {}).get("biography") or "")),
                1 if str((profile or {}).get("birthday") or "").strip() else 0
            ))

        _log("ACTOR_PROFILE_HELPER_STAGE_V2542 actor=%s phase=korean_details elapsed_ms=%.1f tmdb=%s bio_chars=%d birthday=%d" % (
            _short_log_value(actor_name,80), (time.perf_counter()-_details_t0_v2542)*1000.0,
            str((profile or {}).get("tmdb_id") or ""), len(str((profile or {}).get("biography") or "")),
            1 if str((profile or {}).get("birthday") or "").strip() else 0
        ))
        return files, profile, switched

    def _actor_profile_fetch_tmdb_korean_v2454_step2(self, _query_person, _query_person_bio_v2547, actor_name, helper, korean_value, original, profile, tmdb_id, original_bio_fallback):
        """Step 2 of _actor_profile_fetch_tmdb_korean_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_BIO_PLEX_DISABLED_V2547, ACTOR_PROFILE_HELPER_LANGUAGE_SWITCH_V2542, ACTOR_PROFILE_HELPER_SINGLE_QUERY_V2616, ACTOR_PROFILE_BIO_FAST_V2545."""
        if tmdb_id and not str(profile.get("biography") or "").strip():
            _log("ACTOR_PROFILE_BIO_PLEX_DISABLED_V2547 actor=%s tmdb=%s reason=v2546_runtime_http_error_use_tmdb_lean_direct" % (
                _short_log_value(actor_name,80), tmdb_id
            ))

        # Korean-first profile identity is preserved.  Only a missing Korean
        # Biography uses the user's original Helper language.  v2542 removes
        # the unconditional 350 ms sleep exactly like the Korean switch above.
        if tmdb_id and not str(profile.get("biography") or "").strip() and original and original != korean_value:
            try:
                _fallback_switch_t0_v2542 = time.perf_counter()
                helper.setSetting("language", original)
                _fallback_wait_v2542 = 0
                _fallback_readback_v2542 = str(helper.getSetting("language") or "").strip()
                if _fallback_readback_v2542 != original:
                    xbmc.sleep(120)
                    _fallback_wait_v2542 = 120
                    _fallback_readback_v2542 = str(helper.getSetting("language") or "").strip()
                _log("ACTOR_PROFILE_HELPER_LANGUAGE_SWITCH_V2542 actor=%s phase=original_fallback target=%s readback=%s wait_ms=%d elapsed_ms=%.1f" % (
                    _short_log_value(actor_name,80), original, _fallback_readback_v2542, _fallback_wait_v2542,
                    (time.perf_counter()-_fallback_switch_t0_v2542)*1000.0
                ))
                # v2545: Original-language fallback only needs the Person
                # biography. The old route forced detailed=true, which makes
                # TMDb Helper build the full detailed person directory even
                # though portrait/images are already deferred by V2544. Ask
                # for the lean exact-ID details item first. On Helper error,
                # an empty result, or a mismatched identity, immediately fall
                # back to the proven detailed=true route so correctness wins.
                fallback_dir = (
                    "plugin://plugin.video.themoviedb.helper/"
                    "?info=details&tmdb_type=person&tmdb_id=%s&detailed=false&cacheonly=false&fanarttv=false"
                ) % quote(tmdb_id, safe="")
                _fallback_t0_v2542 = time.perf_counter()
                fallback_profile = {}
                fallback_files = []
                _v2545_retry_full = False
                _v2545_retry_reason = ""
                # V2616: same rule for original-language fallback: one
                # Helper invocation only.  A separate cacheonly probe is not
                # a cheap local read and was adding another ~1.4 s on misses.
                _orig_cache_hit_v2615 = False
                _v2616_orig_t0 = time.perf_counter()
                try:
                    fallback_profile, fallback_files = _query_person_bio_v2547(fallback_dir, 26162)
                except Exception:
                    _v2545_retry_full = True
                    _v2545_retry_reason = "lean_query_error"
                    _log("ACTOR_PROFILE_BIO_FAST_V2545 actor=%s phase=original_lean ok=0 retry_full=1 reason=%s elapsed_ms=%.1f err=%s" % (
                        _short_log_value(actor_name,80), _v2545_retry_reason,
                        (time.perf_counter()-_fallback_t0_v2542)*1000.0,
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                _log("ACTOR_PROFILE_HELPER_SINGLE_QUERY_V2616 actor=%s stage=original elapsed_ms=%.1f tmdb=%s bio_chars=%d" % (
                    _short_log_value(actor_name,80), (time.perf_counter()-_v2616_orig_t0)*1000.0, tmdb_id,
                    len(str((fallback_profile or {}).get("biography") or ""))
                ))
                _lean_tmdb_v2545 = str((fallback_profile or {}).get("tmdb_id") or "").strip()
                _lean_bio_v2545 = str((fallback_profile or {}).get("biography") or "").strip()
                if not fallback_profile:
                    _v2545_retry_full = True
                    _v2545_retry_reason = _v2545_retry_reason or "lean_empty_profile"
                elif _lean_tmdb_v2545 and _lean_tmdb_v2545 != tmdb_id:
                    _v2545_retry_full = True
                    _v2545_retry_reason = "lean_tmdb_mismatch"
                elif not _lean_bio_v2545:
                    _v2545_retry_full = False
                    _v2545_retry_reason = "lean_bio_empty_negative_v2546"
                _log("ACTOR_PROFILE_BIO_FAST_V2545 actor=%s phase=original_lean ok=%d elapsed_ms=%.1f tmdb=%s bio_chars=%d results=%d retry_full=%d reason=%s cache_hit=%d" % (
                    _short_log_value(actor_name,80), 1 if fallback_profile else 0,
                    (time.perf_counter()-_fallback_t0_v2542)*1000.0,
                    _lean_tmdb_v2545, len(_lean_bio_v2545), len(fallback_files or []),
                    1 if _v2545_retry_full else 0, _v2545_retry_reason or "none",
                    1 if _orig_cache_hit_v2615 else 0
                ))

                if _v2545_retry_full:
                    fallback_dir_full_v2545 = (
                        "plugin://plugin.video.themoviedb.helper/"
                        "?info=details&tmdb_type=person&tmdb_id=%s&detailed=true&cacheonly=false&fanarttv=false"
                    ) % quote(tmdb_id, safe="")
                    _fallback_full_t0_v2545 = time.perf_counter()
                    fallback_profile, fallback_files = _query_person(fallback_dir_full_v2545, 25452)
                    _log("ACTOR_PROFILE_BIO_FULL_RETRY_V2545 actor=%s reason=%s elapsed_ms=%.1f bio_chars=%d" % (
                        _short_log_value(actor_name,80), _v2545_retry_reason or "compatibility",
                        (time.perf_counter()-_fallback_full_t0_v2545)*1000.0,
                        len(str((fallback_profile or {}).get("biography") or "").strip())
                    ))

                _fallback_ms_v2542 = (time.perf_counter()-_fallback_t0_v2542)*1000.0
                fallback_bio = str((fallback_profile or {}).get("biography") or "").strip()
                _log("ACTOR_PROFILE_HELPER_STAGE_V2542 actor=%s phase=original_bio_fallback elapsed_ms=%.1f bio_chars=%d" % (
                    _short_log_value(actor_name,80), _fallback_ms_v2542, len(fallback_bio)
                ))
                if fallback_bio:
                    profile["biography"] = fallback_bio
                    profile["biography_source"] = "helper_original_language_fallback_v2545_lean" if not _v2545_retry_full else "helper_original_language_fallback"
                    original_bio_fallback = True
            finally:
                pass
        return original_bio_fallback

    def _actor_profile_enrich_commit_v2599(self):
        """Apply background actor metadata only after the page is already interactive."""
        try:
            with self._actor_profile_enrich_lock_v2599:
                pending = self._actor_profile_enrich_pending_v2599
                self._actor_profile_enrich_pending_v2599 = None
            if not pending:
                return False
            actor_name, profile = pending
            if not self._actor_profile_is_active_v2454():
                return False
            current_actor = str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip()
            if not current_actor or current_actor.casefold() != str(actor_name or "").strip().casefold():
                return False
            profile = dict(profile or {})
            # R10 final authority barrier: background TMDb enrichment is allowed
            # to supply identity/birthday/etc., but it must never overwrite a
            # Korean biography already present in Actor Master.
            profile = self._actor_profile_apply_master_authority_r5(
                actor_name, profile, stage="late_enrich_commit_r10"
            )
            try:
                profile = self._actor_wiki_bio_apply_r68(actor_name, profile)
            except Exception:
                pass
            _display_name_v2701 = self._actor_master_name_ko_v2702(actor_name)
            english_name = actor_name if _display_name_v2701 != actor_name and re.search(r"[A-Za-z]", actor_name) else self._actor_profile_english_name_v2454(actor_name, profile)
            birthday_age = self._actor_profile_prepare_birthday_age_v2711(actor_name, profile)
            bio_full, bio_lang = self._actor_profile_biography_display_v2488(profile)
            bio_display = self._actor_profile_biography_boxfit_v2504(
                bio_full, inner_width_px=696, inner_height_px=144
            )
            self._actor_profile_set_prop_v2454("EnglishName", english_name)
            self._actor_profile_set_prop_v2454("Department", self._actor_profile_department_ko_v2454(profile.get("department")))
            self._actor_profile_set_prop_v2454("TMDbId", profile.get("tmdb_id") or "")
            self._actor_profile_set_prop_v2454("Birthday", profile.get("birthday") or "")
            self._actor_profile_set_prop_v2454("BirthdayAge", birthday_age)
            self._actor_profile_set_prop_v2454("Born", profile.get("born") or "")
            self._actor_profile_set_prop_v2454("Age", profile.get("age") or "")
            self._actor_profile_set_prop_v2454("Aliases", profile.get("aliases") or "")
            self._actor_profile_set_prop_v2454("Biography", profile.get("biography") or "한국어/기본 언어 배우 소개 정보가 없습니다.")
            self._actor_profile_set_prop_v2454("BiographyKo", self._actor_profile_korean_biography_v2459(profile.get("biography")))
            self._actor_profile_set_prop_v2454("BiographyDisplay", bio_display)
            _bio_ready_r14 = (
                str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BioScrollReady") or "").strip() == "1"
                or str(self.getProperty("PlexKM.ActorProfile.BioScrollReady") or "").strip() == "1"
            )
            _bio_full_payload_r15 = (
                str(bio_full or "").rstrip() + "[CR]"
                if str(bio_full or "").strip() else ""
            )
            self._actor_profile_set_prop_v2454(
                "BiographyViewport",
                _bio_full_payload_r15 if _bio_ready_r14 else bio_display
            )
            self._actor_profile_set_prop_v2454("BiographyLanguage", bio_lang)
            self._actor_profile_set_prop_v2454("BiographySource", profile.get("biography_source") or "missing")
            # R92: late data fills the info line and biography preview in place.
            self._actor_profile_publish_info_line_r92(profile)
            self._actor_profile_publish_bio_preview_r92(bio_full)
            self._actor_profile_set_prop_v2454("Source", profile.get("source") or "tmdb_background_v2599")
            _log("ACTOR_PROFILE_LATE_ENRICH_COMMIT_V2600 actor=%s tmdb=%d bio_chars=%d visible_block_ms=0 gui_properties_only=1" % (
                _short_log_value(actor_name,80), 1 if profile.get("tmdb_id") else 0, len(str(profile.get("biography") or ""))
            ))
            _log("ACTOR_PROFILE_IDENTITY_READY_V2679 actor=%s tmdb=%s" % (
                _short_log_value(actor_name,80), str(profile.get("tmdb_id") or "")
            ))
            try:
                self._actor_wiki_bio_schedule_r68(actor_name, profile, reason="late_enrich")
            except Exception:
                pass
            if str(profile.get("biography") or "").strip():
                _log("ACTOR_PROFILE_BIO_LATE_COMMIT_V2679 actor=%s bio_chars=%d" % (
                    _short_log_value(actor_name,80), len(str(profile.get("biography") or ""))
                ))
            try:
                pkm_uhd_diag_v2600.event(
                    "ACTOR_ENRICH", extra="actor=%s tmdb=%d bio_chars=%d" % (
                        _short_log_value(actor_name,60), 1 if profile.get("tmdb_id") else 0, len(str(profile.get("biography") or ""))
                    )
                )
            except Exception:
                pass
            # V2611: metadata readiness is a separate Actor KPI. This is the
            # completion event for a page that was intentionally opened local-first.
            self._actor_profile_publish_meta_kpi_v2611(
                actor_name, "ready_postvisible", source=profile.get("source") or "tmdb_background_v2611", profile=profile
            )
            # v2610: provisional pages learn TMDb identity only here.  Once the
            # visible metadata enrichment supplies that ID, arm the same low-priority
            # portrait upgrade path instead of leaving the Info portrait forever.
            try:
                if str(profile.get("tmdb_id") or "").strip() and not str(profile.get("portrait_local_v2544") or "").strip():
                    self._actor_profile_schedule_portrait_upgrade_idle_v2610(
                        actor_name, profile, delay_ms=250, reason="late_enrich_v2610"
                    )
            except Exception:
                pass
            return True
        except Exception:
            _log("ACTOR_PROFILE_LATE_ENRICH_COMMIT_FAILED_V2599 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _actor_profile_department_ko_v2454(self, value):
        value = str(value or "").strip()
        mapped = {
            "acting": "배우", "directing": "감독", "writing": "각본",
            "production": "제작", "creator": "크리에이터", "sound": "음향",
            "camera": "촬영", "editing": "편집", "art": "미술"
        }
        return mapped.get(value.casefold(), value or "배우")

    def _actor_profile_birthday_text_v2454(self, birthday, age=""):
        birthday = str(birthday or "").strip()
        out = birthday
        m = re.match(r"^(\\d{4})-(\\d{1,2})-(\\d{1,2})$", birthday)
        if m:
            out = "%d년 %d월 %d일" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        age = str(age or "").strip()
        if age:
            out = "%s (%s세)" % (out, age) if out else "%s세" % age
        return out

    def _actor_profile_english_name_v2454(self, actor_name, profile):
        actor_name = str(actor_name or "").strip()
        label = str((profile or {}).get("label") or "").strip()
        if label and label.casefold() != actor_name.casefold() and re.search(r"[A-Za-z]", label):
            return label
        aliases = str((profile or {}).get("aliases") or "")
        # R67: the old pattern r"[|,/;\\n]+" was a raw string, so "\\n" meant
        # a backslash and the LETTER n: "Eunji" was split into "Eu" + "ji".
        latin = []
        for part in re.split(r"[|,/;\n]+", aliases):
            part = part.strip()
            if part and part.casefold() != actor_name.casefold() and re.search(r"[A-Za-z]", part) \
                    and not re.search(r"[\uac00-\ud7a3]", part):
                latin.append(part)
        if not latin:
            return ""
        # Prefer a full romanised name ("Jung Eun-ji") over a stage nickname.
        full = [p for p in latin if " " in p]
        return (full or latin)[0]

    def _actor_profile_local_works_v2454(self, actor_name, current_rating_key="", limit=None):
        """Return every local Plex work for the actor, split movie/show.

        v2456 removes the actor-page 20/30-item presentation cap.  Plex/PKM
        selected libraries remain authoritative, canonical-family dedup remains
        in place, and items without poster art are still kept so no library work
        silently disappears from the actor page.
        """
        actor_name = str(actor_name or "").strip()
        empty = {"movie": [], "show": []}
        if not actor_name:
            return empty
        dbp = self._profile_db_path()
        if not dbp or not os.path.exists(dbp):
            return empty
        try:
            core_mod = _ensure_core()
            selected, configured = core_mod.selected_sections_state()
            allowed = [str(x) for x in (selected or []) if str(x or "").strip()] if configured else []
        except Exception:
            configured = False
            allowed = []
        try:
            conn = sqlite3.connect(dbp, timeout=3.0)
            conn.row_factory = sqlite3.Row
            try:
                cur = conn.cursor()
                source_rk = str(current_rating_key or "").strip()
                if source_rk:
                    src = cur.execute(
                        "SELECT plex_type,parent_rating_key,grandparent_rating_key "
                        "FROM items WHERE rating_key=? LIMIT 1",
                        (source_rk,)
                    ).fetchone()
                    if src:
                        ptype = str(src["plex_type"] or "").strip().lower()
                        if ptype == "episode":
                            source_rk = str(
                                src["grandparent_rating_key"]
                                or src["parent_rating_key"]
                                or source_rk
                            ).strip()
                        elif ptype == "season":
                            source_rk = str(src["parent_rating_key"] or source_rk).strip()

                identity = None
                if source_rk:
                    identity = cur.execute("""
                        SELECT IFNULL(tag_id,'') AS tag_id,
                               IFNULL(person_thumb,'') AS person_thumb
                        FROM item_people
                        WHERE rating_key=? AND person_type='actor' AND person_name=?
                        ORDER BY IFNULL(sort_order,999) ASC
                        LIMIT 1
                    """, (source_rk, actor_name)).fetchone()
                tag_id = str((identity["tag_id"] if identity else "") or "").strip()

                if self._uhd_kpi_proxy_v2605():
                    # V2605: ActorProfile renders identity/title/poster/year only on U+/Android reduced runtime.
                    # Ratings joins over the ~1GB local DB are wasted on the weak
                    # STB critical path; keep tuple shape with NULL aliases.
                    select_sql = """
                        SELECT i.rating_key, i.section_id, i.plex_type, i.kodi_type,
                               i.title, i.original_title, i.sort_title, i.year,
                               i.summary, i.duration, i.added_at, i.updated_at,
                               i.thumb, i.art, i.media_file, i.part_key,
                               i.view_count, i.last_viewed_at, i.show_title,
                               i.season, i.episode, i.parent_rating_key,
                               i.grandparent_rating_key,
                               NULL AS critic_rating, NULL AS audience_rating,
                               NULL AS imdb_rating, NULL AS imdb_audience,
                               NULL AS imdb_user, NULL AS imdb_score
                        FROM item_people p
                        JOIN items i ON i.rating_key=p.rating_key
                        WHERE p.person_type='actor'
                          AND i.plex_type IN ('movie','show')
                    """
                    _log("ACTOR_PROFILE_LOCAL_WORKS_SQL_V2605 actor=%s ratings_join=0 platform_android=%d proxy=%d" % (
                        _short_log_value(actor_name,80), 1 if self._is_android_v2591() else 0, 0 if self._is_android_v2591() else 1
                    ))
                else:
                    select_sql = """
                        SELECT i.rating_key, i.section_id, i.plex_type, i.kodi_type,
                               i.title, i.original_title, i.sort_title, i.year,
                               i.summary, i.duration, i.added_at, i.updated_at,
                               i.thumb, i.art, i.media_file, i.part_key,
                               i.view_count, i.last_viewed_at, i.show_title,
                               i.season, i.episode, i.parent_rating_key,
                               i.grandparent_rating_key,
                               cm.critic_rating, cm.audience_rating,
                               ir.rating AS imdb_rating,
                               ir.audience_rating AS imdb_audience,
                               ir.user_rating AS imdb_user,
                               ir.score AS imdb_score
                        FROM item_people p
                        JOIN items i ON i.rating_key=p.rating_key
                        LEFT JOIN cine21_matches cm ON cm.rating_key=i.rating_key
                          AND IFNULL(cm.match_status,'') IN ('MATCHED','CINE21_OK','OK')
                        LEFT JOIN item_ratings ir ON ir.rating_key=i.rating_key
                        WHERE p.person_type='actor'
                          AND i.plex_type IN ('movie','show')
                    """
                if configured:
                    if not allowed:
                        return empty
                    ph = ",".join("?" for _ in allowed)
                    section_clause = " AND CAST(i.section_id AS TEXT) IN (%s)" % ph
                else:
                    section_clause = ""

                def query_exact(field, value):
                    if not value:
                        return []
                    # v2456: intentionally no LIMIT.  Actor pages must expose every
                    # matching movie/show from the selected local Plex libraries.
                    sql = (
                        select_sql
                        + " AND p.%s=?" % field
                        + section_clause
                        + " GROUP BY i.rating_key"
                    )
                    params = [value] + list(allowed)
                    return cur.execute(sql, params).fetchall()

                rows = []
                seen_rk = set()

                # V2675 invariant: an actor clicked from an Info cast row has at
                # least one authoritative work -- the source title itself. Seed
                # that title BEFORE actor-index lookup, then merge/dedupe every
                # additional local work. This makes works=0 structurally
                # unreachable for a valid Info->Actor transition instead of
                # treating the source title as an after-the-fact fallback.
                if source_rk:
                    try:
                        seed_row_v2675 = cur.execute("""
                            SELECT i.rating_key, i.section_id, i.plex_type, i.kodi_type,
                                   i.title, i.original_title, i.sort_title, i.year,
                                   i.summary, i.duration, i.added_at, i.updated_at,
                                   i.thumb, i.art, i.media_file, i.part_key,
                                   i.view_count, i.last_viewed_at, i.show_title,
                                   i.season, i.episode, i.parent_rating_key,
                                   i.grandparent_rating_key,
                                   NULL AS critic_rating, NULL AS audience_rating,
                                   NULL AS imdb_rating, NULL AS imdb_audience,
                                   NULL AS imdb_user, NULL AS imdb_score
                            FROM items i
                            WHERE i.rating_key=? AND i.plex_type IN ('movie','show')
                            LIMIT 1
                        """, (source_rk,)).fetchone()
                        if seed_row_v2675 is not None:
                            seed_rk_v2675 = str(seed_row_v2675["rating_key"] or "").strip()
                            if seed_rk_v2675:
                                rows.append(seed_row_v2675)
                                seen_rk.add(seed_rk_v2675)
                                _log("ACTOR_PROFILE_SOURCE_WORK_SEED_V2675 actor=%s source=%s type=%s mandatory=1 before_actor_lookup=1" % (
                                    _short_log_value(actor_name,80), source_rk,
                                    str(seed_row_v2675["plex_type"] or "").strip().lower()
                                ))
                    except Exception:
                        _log("ACTOR_PROFILE_SOURCE_WORK_SEED_FAILED_V2675 actor=%s source=%s err=%s" % (
                            _short_log_value(actor_name,80), source_rk, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)

                for field, value in (("tag_id", tag_id), ("person_name", actor_name)):
                    for row in query_exact(field, value):
                        rk = str(row["rating_key"] or "").strip()
                        if not rk or rk in seen_rk:
                            continue
                        seen_rk.add(rk)
                        rows.append(row)

                # v2457 actor-page ordering: filmography is chronological,
                # newest first. Rating no longer changes the visual order.
                def year_order(row):
                    try:
                        year = int(row["year"] or 0)
                    except Exception:
                        year = 0
                    title = str(row["title"] or "").strip().casefold()
                    return (-year, title)

                rows.sort(key=year_order)

                buckets = {"movie": [], "show": []}
                families = set()
                for row in rows:
                    ptype = str(row["plex_type"] or "").strip().lower()
                    if ptype not in buckets:
                        continue
                    name = str(row["original_title"] or row["title"] or "").strip().casefold()
                    year = str(row["year"] or "").strip()
                    family = (ptype, " ".join(name.split()), year)
                    if family in families:
                        continue
                    families.add(family)
                    buckets[ptype].append(self._info_movie_row_tuple_from_db_row(row))

                # V2670 hard contract: every actor opened from an Info cast row must have a work rail.
                # If the actor index is incomplete/stale, the parent movie/show is still authoritative
                # evidence for this actor because the click originated from that title's cast row.
                # Bind that source title as a one-item fallback instead of exposing an empty actor page.
                if not buckets["movie"] and not buckets["show"] and source_rk:
                    try:
                        fallback_row_v2670 = cur.execute("""
                            SELECT i.rating_key, i.section_id, i.plex_type, i.kodi_type,
                                   i.title, i.original_title, i.sort_title, i.year,
                                   i.summary, i.duration, i.added_at, i.updated_at,
                                   i.thumb, i.art, i.media_file, i.part_key,
                                   i.view_count, i.last_viewed_at, i.show_title,
                                   i.season, i.episode, i.parent_rating_key,
                                   i.grandparent_rating_key,
                                   NULL AS critic_rating, NULL AS audience_rating,
                                   NULL AS imdb_rating, NULL AS imdb_audience,
                                   NULL AS imdb_user, NULL AS imdb_score
                            FROM items i
                            WHERE i.rating_key=? AND i.plex_type IN ('movie','show')
                            LIMIT 1
                        """, (source_rk,)).fetchone()
                        if fallback_row_v2670 is not None:
                            fallback_type_v2670 = str(fallback_row_v2670["plex_type"] or "").strip().lower()
                            if fallback_type_v2670 in buckets:
                                buckets[fallback_type_v2670].append(self._info_movie_row_tuple_from_db_row(fallback_row_v2670))
                                _log("ACTOR_PROFILE_SOURCE_WORK_FALLBACK_V2670 actor=%s source=%s type=%s works=1 reason=local_actor_index_empty" % (
                                    _short_log_value(actor_name,80), source_rk, fallback_type_v2670
                                ))
                    except Exception:
                        _log("ACTOR_PROFILE_SOURCE_WORK_FALLBACK_FAILED_V2670 actor=%s source=%s err=%s" % (
                            _short_log_value(actor_name,80), source_rk, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)

                _log(
                    "ACTOR_PROFILE_LOCAL_WORKS_V2456 actor=%s source=%s tag=%s "
                    "movies=%d tv=%d total=%d selected_sections=%d network=0 no_limit=1 order=year_desc"
                    % (
                        _short_log_value(actor_name, 80),
                        source_rk or "",
                        tag_id or "-",
                        len(buckets["movie"]),
                        len(buckets["show"]),
                        len(buckets["movie"]) + len(buckets["show"]),
                        len(allowed),
                    )
                )
                return buckets
            finally:
                conn.close()
        except Exception:
            _log(
                "ACTOR_PROFILE_LOCAL_WORKS_FAILED_V2456 actor=%s err=%s"
                % (
                    _short_log_value(actor_name, 80),
                    traceback.format_exc().replace(chr(10), " | "),
                ),
                xbmc.LOGWARNING,
            )
            return empty

    def _actor_profile_lis_signature_r101(self, actor_name, rows):
        try:
            return (str(actor_name or "").strip().casefold(),
                    tuple(str((tuple(r or ()) or ("",))[0]) for r in list(rows or [])))
        except Exception:
            return None

    def _actor_profile_lis_cache_put_r115(self, sig, lis):
        """R115: keep prebuilt work cards for the last few actors, not just one.
        A single slot meant opening actor B threw away actor A's cards, so going
        back to A rebuilt ~21-44 cards on the click (~0.5 s dark screen)."""
        try:
            cache = getattr(self, "_actor_profile_lis_cache_r115", None)
            if not isinstance(cache, dict):
                cache = {}
                self._actor_profile_lis_cache_r115 = cache
            cache.pop(sig, None)
            cache[sig] = list(lis or [])
            while len(cache) > 6:
                cache.pop(next(iter(cache)))
        except Exception:
            pass

    def _actor_profile_prebuild_lis_r101(self, actor_name, rows):
        """R101: build the Actor Profile poster ListItems in the background.

        Shield log: the click handler spent 1175 ms building 39 posters on the
        GUI thread before the page appeared (the press looked ignored).  The
        rows are already known when focus settles on a cast circle, so build
        the ListItems then and let the click only bind them."""
        rows = list(rows or [])
        if not rows:
            return

        def _order(row):
            try:
                y = int((row or ())[7] or 0)
            except Exception:
                y = 0
            try:
                t = str((row or ())[4] or "").strip().casefold()
            except Exception:
                t = ""
            return (-y, t)

        ordered = sorted(rows, key=_order)
        sig = self._actor_profile_lis_signature_r101(actor_name, ordered)
        cur = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
        if isinstance(cur, dict) and cur.get("sig") == sig:
            return
        if sig in (getattr(self, "_actor_profile_lis_cache_r115", None) or {}):
            return

        # R115: let a click that lands while these cards are still being built
        # wait for them instead of building the same cards again in parallel.
        _evt_r115 = threading.Event()
        try:
            _inflight_r115 = getattr(self, "_actor_profile_lis_inflight_r115", None)
            if not isinstance(_inflight_r115, dict):
                _inflight_r115 = {}
                self._actor_profile_lis_inflight_r115 = _inflight_r115
            _inflight_r115[sig] = _evt_r115
        except Exception:
            pass

        def _work():
            try:
                t0 = time.time()
                try:
                    lis = self._actor_profile_build_work_listitems_v2454(
                        ordered, actor_name, row_title="내 라이브러리 출연작")
                    self._actor_profile_prebuilt_lis_r101 = {"sig": sig, "lis": lis, "ts": time.time()}
                    self._actor_profile_lis_cache_put_r115(sig, lis)
                finally:
                    _evt_r115.set()
                    try:
                        (getattr(self, "_actor_profile_lis_inflight_r115", None) or {}).pop(sig, None)
                    except Exception:
                        pass
                _log("ACTOR_PROFILE_LIS_PREBUILT_R101 actor=%s items=%d elapsed_ms=%d thread=background" % (
                    _short_log_value(actor_name, 80), len(lis), int((time.time() - t0) * 1000)))
                # R109: works without a local small poster were bound to a remote
                # 720x1080 transcode and showed as blank cards for ~1.5 s after the
                # page opened (Shield).  Fetch the small posters of the first
                # visible cards now, while focus rests on the cast circle, then
                # rebuild so the click binds local files only.
                fetched = self._actor_profile_fetch_small_posters_r109(actor_name, ordered, sig)
                cur2 = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
                if fetched and isinstance(cur2, dict) and cur2.get("sig") == sig:
                    t1 = time.time()
                    lis2 = self._actor_profile_build_work_listitems_v2454(
                        ordered, actor_name, row_title="내 라이브러리 출연작")
                    cur3 = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
                    if isinstance(cur3, dict) and cur3.get("sig") == sig:
                        self._actor_profile_prebuilt_lis_r101 = {"sig": sig, "lis": lis2, "ts": time.time()}
                        self._actor_profile_lis_cache_put_r115(sig, lis2)
                    _log("ACTOR_PROFILE_LIS_REBUILT_R109 actor=%s items=%d fetched=%d elapsed_ms=%d" % (
                        _short_log_value(actor_name, 80), len(lis2), fetched, int((time.time() - t1) * 1000)))
            except Exception:
                _log("ACTOR_PROFILE_LIS_PREBUILT_R101_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        _PKMHomeThreadV2151(target=_work, name="ActorProfileLisR101", daemon=True).start()

    def _actor_profile_fetch_small_posters_r109(self, actor_name, rows, sig, limit=16):
        """R109: download missing PKM small posters (240x360) for the first
        visible actor works.  Background thread only; stops when the prepared
        actor changes or the window closes."""
        t0 = time.time()
        have = missing = fetched = 0
        try:
            urls = []
            for row in list(rows or [])[:max(0, int(limit))]:
                if self._library_row_poster_local_v2580(row):
                    have += 1
                    continue
                url = self._library_row_poster_canonical_v2580(row)
                if url:
                    urls.append(url)
            missing = len(urls)

            def _cancel():
                cur = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
                return (not isinstance(cur, dict)) or cur.get("sig") != sig

            # Three at a time: the visible cards are ready ~3x sooner, so an
            # early click (shortly after landing on the circle) still binds
            # local posters.
            lock = threading.Lock()
            queue = list(urls)
            box = {"n": 0}

            def _worker():
                while True:
                    with lock:
                        if not queue:
                            return
                        url = queue.pop(0)
                    if self._closing_event_v1841.is_set() or _cancel():
                        return
                    if self._wall_poster_download_one_v1644(
                            url, priority=pkm_artwork_scheduler.PRIORITY_PREWARM, cancel_check=_cancel):
                        with lock:
                            box["n"] += 1

            workers = [threading.Thread(target=_worker, name="ActorSmallPosterR109_%d" % i)
                       for i in range(min(3, len(queue)))]
            for w in workers:
                w.daemon = True
                w.start()
            for w in workers:
                w.join(12.0)
            fetched = box["n"]
        except Exception:
            _log("ACTOR_PROFILE_SMALL_POSTER_R109_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        _log("ACTOR_PROFILE_SMALL_POSTER_R109 actor=%s local=%d missing=%d fetched=%d elapsed_ms=%d" % (
            _short_log_value(actor_name, 80), have, missing, fetched, int((time.time() - t0) * 1000)))
        return fetched

    def _actor_profile_build_work_listitems_v2454(self, rows, actor_name, row_title="출연작"):
        # v2522: actor profile rails need the same native identity/poster contract
        # as Info actor-work rows, but not Home/Library rating, genre, duplicate-
        # family and wall-sort enrichment. Reuse the proven v2509 lightweight
        # builder and bind the actor-name property only.
        out = []
        started_v2522 = time.time()
        fallback_heavy_v2522 = 0
        for idx, row in enumerate(list(rows or [])):
            try:
                row_for_li = tuple(row or ())
                try:
                    t = list(row_for_li)
                    visible_title = str(t[4] if len(t) > 4 else "").strip()
                    original_title = str(t[5] if len(t) > 5 else "").strip()
                    show_title = str(t[18] if len(t) > 18 else "").strip()
                    if not re.search(r"[가-힣]", visible_title):
                        korean_candidate = ""
                        for candidate in (original_title, show_title):
                            if candidate and re.search(r"[가-힣]", candidate):
                                korean_candidate = candidate
                                break
                        if korean_candidate and len(t) > 4:
                            t[4] = korean_candidate
                    row_for_li = tuple(t)
                except Exception:
                    row_for_li = tuple(row or ())

                li = self._info_actor_work_li_from_row_v2509(
                    row_for_li, row_title=row_title, row_first=(idx == 0),
                    row_id="actor_profile_works_v2454", row_start=0, row_index=0
                )
                if li is None:
                    fallback_heavy_v2522 += 1
                    li = self._li_from_row(
                        row_for_li, row_title=row_title, row_type="info_actor_works_v1966",
                        row_first=(idx == 0), row_id="actor_profile_works_v2454",
                        row_start=0, row_index=0
                    )
                li.setProperty("PlexKM.ActorProfile.ActorName", actor_name or "")
                out.append(li)
            except Exception:
                _log("ACTOR_PROFILE_WORK_LI_FAILED_V2522 actor=%s idx=%d err=%s" % (
                    _short_log_value(actor_name,80), idx, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        _log("ACTOR_PROFILE_WORK_LI_BUILD_V2522 actor=%s row=%s items=%d elapsed_ms=%d lightweight=%d heavy_fallback=%d" % (
            _short_log_value(actor_name,80), row_title or "", len(out),
            int((time.time()-started_v2522)*1000.0), len(out)-fallback_heavy_v2522, fallback_heavy_v2522
        ))
        return out

    def _actor_profile_focus_first_work_v2456(self, movie_count=0, tv_count=0, allow_wait=True, stage_v2522="postcommit"):
        """Own the first ActorProfile poster before the first rendered Actor frame.

        v2522 first attempts focus synchronously, with no sleep/yield. When called
        immediately after Active=1 and before swap finish this keeps Kodi from
        painting the normal itemlayout first and enlarging it one frame later.
        """
        target = 6500 if int(movie_count or 0) > 0 else (6510 if int(tv_count or 0) > 0 else 0)
        if not target:
            return False
        try:
            ctrl = self.getControl(target)
            if int(ctrl.size()) <= 0:
                return False
            ctrl.selectItem(0)
        except Exception:
            _log("ACTOR_PROFILE_INITIAL_FOCUS_FAILED_V2522 target=%s stage=prepare err=%s" % (
                target, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

        # R94: when the biography has more to show, the page opens on 더보기
        # (6486).  The rail still selects item 0 so Down lands on the first work.
        try:
            bio_more_r94 = str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BiographyMore") or "") == "1"
        except Exception:
            bio_more_r94 = False

        def _commit_once_v2708():
            # V2708: keep ActorProfile focus ownership synchronous with this
            # Window callback.  Queued SetFocus builtins can fire after the old
            # Info control retires and Kodi then rejects container 6500/6510.
            try:
                ctrl.selectItem(0)
            except Exception:
                pass
            if bio_more_r94:
                try:
                    self.setFocusId(6486)
                    if int(self.getFocusId()) == 6486:
                        return True
                except Exception:
                    pass
            try:
                self.setFocus(ctrl)
            except Exception:
                try:
                    self.setFocusId(target)
                except Exception:
                    pass
            try:
                return int(self.getFocusId()) == target and int(ctrl.getSelectedPosition()) == 0
            except Exception:
                return False

        # No sleep before this attempt: on the normal path the renderer cannot
        # expose ActorProfile between Active=1 and this focus ownership change.
        if _commit_once_v2708():
            self._last_focus_id = target
            _log("ACTOR_PROFILE_INITIAL_FOCUS_PREPAINT_V2522 target=%d row=%s stage=%s attempt=0 sleep_ms=0" % (
                target, "movie" if target == 6500 else "tv", stage_v2522 or ""
            ))
            return True
        if not allow_wait:
            _log("ACTOR_PROFILE_INITIAL_FOCUS_PREPAINT_PENDING_V2522 target=%d row=%s stage=%s fallback_after_commit=1" % (
                target, "movie" if target == 6500 else "tv", stage_v2522 or ""
            ))
            return False

        # V2708: after the atomic swap commits, Kodi may need one rendered frame
        # before container 6500/6510 becomes focusable. Retry only across a small
        # bounded post-visible window and always select item 0 before focus.
        for attempt_v2708, delay_ms_v2708 in enumerate((16, 24, 32), 1):
            try:
                xbmc.sleep(delay_ms_v2708)
                visible_now = bool(xbmc.getCondVisibility("Control.IsVisible(%d)" % target))
            except Exception:
                visible_now = True
            if visible_now and _commit_once_v2708():
                self._last_focus_id = target
                _log("ACTOR_PROFILE_INITIAL_FOCUS_POSTVISIBLE_V2708 target=%d row=%s attempt=%d delay_ms=%d stage=%s" % (
                    target, "movie" if target == 6500 else "tv", attempt_v2708,
                    delay_ms_v2708, stage_v2522 or ""
                ))
                return True
        try:
            focus_now = int(self.getFocusId())
        except Exception:
            focus_now = -1
        _log("ACTOR_PROFILE_INITIAL_FOCUS_DEFER_V2708 target=%d focus_now=%d retries=3 stage=%s native_owner=1" % (
            target, focus_now, stage_v2522 or ""
        ))
        return False

    def _actor_profile_parse_date_v2711(self, value):
        """R91: tolerant date parser -> (year, month, day) or None.

        month/day are 0 when only a year is known. Accepts 1943-12-31,
        1943.12.31, 1943/12/31, 1943-12-31T00:00:00 and 1943년 12월 31일.
        """
        text = str(value or "").strip()
        if not text:
            return None
        m = re.match(r"^(\d{4})\D+(\d{1,2})\D+(\d{1,2})", text)
        if m:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if y >= 1000 and 1 <= mo <= 12 and 1 <= d <= 31:
                return (y, mo, d)
        m = re.match(r"^(\d{4})(?:\D|$)", text)
        if m and int(m.group(1)) >= 1000:
            return (int(m.group(1)), 0, 0)
        return None

    def _actor_profile_birthday_age_v2457(self, birthday, helper_age="", deathday=""):
        """R91: one display rule for every actor.

        Age is always computed from the birthday (up to the death date when
        there is one) so it is never stale or missing. The helper age is used
        only when no usable birthday exists.
        """
        birthday = str(birthday or "").strip()
        b = self._actor_profile_parse_date_v2711(birthday)
        d = self._actor_profile_parse_date_v2711(deathday)
        deceased = bool(d)
        age = ""
        if b and b[1] and b[2]:
            if d and d[1] and d[2]:
                ref = d
            else:
                now = time.localtime()
                ref = (int(now.tm_year), int(now.tm_mon), int(now.tm_mday))
            age_n = ref[0] - b[0] - (1 if (ref[1], ref[2]) < (b[1], b[2]) else 0)
            if 0 <= age_n <= 130:
                age = str(age_n)
        if not age and not b:
            helper_age = str(helper_age or "").strip()
            if helper_age.isdigit():
                age = helper_age
        if b and b[1] and b[2]:
            birthday_display = "%04d.%02d.%02d" % b
        elif b:
            birthday_display = "%d년" % b[0]
        else:
            birthday_display = birthday
        age_text = ("향년 %s세" if deceased else "%s세") % age if age else ""
        if birthday_display and age_text:
            return "%s  ·  %s" % (birthday_display, age_text)
        return birthday_display or age_text or ""

    def _actor_profile_prepare_birthday_age_v2711(self, actor_name, profile):
        """R91: fill a missing birthday from the local Actor Master DB, then format."""
        if not isinstance(profile, dict):
            return ""
        try:
            if not str(profile.get("birthday") or "").strip():
                names = [str(actor_name or "").strip()]
                try:
                    ko_name = str(self._actor_master_name_ko_v2702(actor_name, profile.get("tmdb_id")) or "").strip()
                    if ko_name and ko_name not in names:
                        names.append(ko_name)
                except Exception:
                    pass
                for nm in names:
                    if not nm:
                        continue
                    _wid, master_birthday = self._wiki_master_identity_r68(nm, profile.get("tmdb_id"))
                    if master_birthday and self._actor_profile_parse_date_v2711(master_birthday):
                        profile["birthday"] = master_birthday
                        break
        except Exception:
            pass
        return self._actor_profile_birthday_age_v2457(
            profile.get("birthday"), profile.get("age"), profile.get("deathday")
        )

    # ------------------------------------------------------------------
    # R92: ActorProfile page redesign helpers (info line, 4-line biography
    # preview + 더보기, actor-owned blurred background).  Every helper treats
    # missing data as normal: a field that is unknown is simply left out.
    # ------------------------------------------------------------------
    def _actor_profile_country_ko_r92(self, born):
        """R92: place of birth -> short country label ("영국"), or "" when unknown."""
        country_ko = {
            "uk": "영국", "united kingdom": "영국", "england": "영국",
            "scotland": "영국", "wales": "영국", "northern ireland": "영국",
            "great britain": "영국", "britain": "영국",
            "usa": "미국", "us": "미국",
            "united states": "미국", "united states of america": "미국", "america": "미국",
            "south korea": "한국", "korea": "한국", "republic of korea": "한국",
            "korea, south": "한국", "north korea": "북한",
            "japan": "일본", "china": "중국", "people's republic of china": "중국",
            "hong kong": "홍콩", "british hong kong": "홍콩", "taiwan": "대만", "macau": "마카오",
            "france": "프랑스", "germany": "독일", "west germany": "독일", "east germany": "독일",
            "italy": "이탈리아", "spain": "스페인", "portugal": "포르투갈", "ireland": "아일랜드",
            "canada": "캐나다", "australia": "호주", "new zealand": "뉴질랜드",
            "india": "인도", "british india": "인도", "pakistan": "파키스탄",
            "mexico": "멕시코", "brazil": "브라질", "argentina": "아르헨티나", "chile": "칠레",
            "colombia": "콜롬비아", "cuba": "쿠바", "puerto rico": "푸에르토리코",
            "russia": "러시아", "russian federation": "러시아", "soviet union": "러시아",
            "ussr": "러시아", "ukraine": "우크라이나", "poland": "폴란드",
            "czech republic": "체코", "czechia": "체코", "czechoslovakia": "체코",
            "hungary": "헝가리", "austria": "오스트리아", "switzerland": "스위스",
            "netherlands": "네덜란드", "the netherlands": "네덜란드", "belgium": "벨기에",
            "sweden": "스웨덴", "norway": "노르웨이", "denmark": "덴마크", "finland": "핀란드",
            "iceland": "아이슬란드", "greece": "그리스", "turkey": "튀르키예", "türkiye": "튀르키예",
            "israel": "이스라엘", "iran": "이란", "egypt": "이집트", "south africa": "남아프리카 공화국",
            "nigeria": "나이지리아", "kenya": "케냐", "thailand": "태국", "vietnam": "베트남",
            "philippines": "필리핀", "indonesia": "인도네시아", "malaysia": "말레이시아",
            "singapore": "싱가포르", "mongolia": "몽골", "romania": "루마니아",
            "serbia": "세르비아", "yugoslavia": "세르비아", "croatia": "크로아티아",
        }
        us_states = frozenset((
            "alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut",
            "delaware", "florida", "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa",
            "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts", "michigan",
            "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada",
            "new hampshire", "new jersey", "new mexico", "new york", "north carolina",
            "north dakota", "ohio", "oklahoma", "oregon", "pennsylvania", "rhode island",
            "south carolina", "south dakota", "tennessee", "texas", "utah", "vermont", "virginia",
            "washington", "west virginia", "wisconsin", "wyoming", "district of columbia",
            "dc",
        ))
        text = " ".join(str(born or "").replace("\n", " ").split()).strip(" ,.")
        if not text:
            return ""
        parts = [p.strip(" .") for p in re.split(r"[,，]", text) if p.strip(" .")]
        if not parts:
            return ""
        last = parts[-1]
        if re.search(r"[가-힣]", last):
            if "대한민국" in last or last in ("한국", "남한"):
                return "한국"
            # Korean TMDb text is usually "도시, 나라"; a long single segment is kept short.
            return last if len(last) <= 12 else ""
        key = re.sub(r"^\s*now\s+", "", last.casefold()).strip()
        key = re.sub(r"\s*\[.*?\]|\s*\(.*?\)", "", key).strip().replace(".", "")
        if key in country_ko:
            return country_ko[key]
        if key in us_states:
            return "미국"
        # Unknown English country: show it as written rather than guessing.
        return last if 0 < len(last) <= 24 else ""

    def _actor_profile_life_text_r92(self, birthday, deathday="", helper_age=""):
        """R92: "1943.12.31 (82세)" / "1943.12.31 ~ 2020.01.05 (향년 76세)" / "1943년생" / "82세" / ""."""
        b = self._actor_profile_parse_date_v2711(birthday)
        d = self._actor_profile_parse_date_v2711(deathday)
        if b and b[1] and b[2]:
            if d and d[1] and d[2]:
                ref = d
            else:
                now = time.localtime()
                ref = (int(now.tm_year), int(now.tm_mon), int(now.tm_mday))
            age_n = ref[0] - b[0] - (1 if (ref[1], ref[2]) < (b[1], b[2]) else 0)
            born_text = "%04d.%02d.%02d" % b
            if d:
                died_text = ("%04d.%02d.%02d" % d) if (d[1] and d[2]) else ("%d" % d[0])
                if d[1] and d[2] and 0 <= age_n <= 130:
                    return "%s ~ %s (향년 %d세)" % (born_text, died_text, age_n)
                return "%s ~ %s" % (born_text, died_text)
            if 0 <= age_n <= 130:
                return "%s (%d세)" % (born_text, age_n)
            return born_text
        if b:
            if d:
                return "%d ~ %d" % (b[0], d[0])
            return "%d년생" % b[0]
        helper_age = str(helper_age or "").strip()
        if helper_age.isdigit() and 0 < int(helper_age) <= 130 and not d:
            return "%s세" % helper_age
        return ""

    def _actor_profile_info_line_r92(self, profile, works_count=None):
        profile = profile if isinstance(profile, dict) else {}
        parts = []
        try:
            life = self._actor_profile_life_text_r92(
                profile.get("birthday"), profile.get("deathday"), profile.get("age")
            )
            if life:
                parts.append(life)
        except Exception:
            pass
        try:
            country = self._actor_profile_country_ko_r92(profile.get("born"))
            if country:
                parts.append(country)
        except Exception:
            pass
        try:
            if works_count is None:
                works_count = int(
                    xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.WorksCount")
                    or self.getProperty("PlexKM.ActorProfile.WorksCount") or 0
                )
            works_count = int(works_count or 0)
        except Exception:
            works_count = 0
        if works_count > 0:
            parts.append("내 라이브러리 출연 %d편" % works_count)
        return "  ·  ".join(parts)

    def _actor_profile_publish_info_line_r92(self, profile, works_count=None):
        line = ""
        try:
            line = self._actor_profile_info_line_r92(profile, works_count)
        except Exception:
            line = ""
        self._actor_profile_set_prop_v2454("InfoLine", line)
        return line

    def _actor_profile_bio_preview_r92(self, text):
        """R92/R93: 4-line preview for the 1020 px text column, cut at a sentence end.

        R93 measures against 990 px so Kodi never wraps the preview onto a 5th line.

        Returns (preview, more).  more is True when the preview is shorter than
        the full biography, i.e. when "더보기" has something to show.
        """
        full = " ".join(str(text or "").replace("\r", " ").replace("\n", " ").split())
        if not full:
            return "", False
        fit = self._actor_profile_biography_boxfit_v2504(full, inner_width_px=990, inner_height_px=144)
        if not fit or fit == full:
            return full, False
        body = fit[:-3] if fit.endswith("...") else fit
        best = -1
        for m in re.finditer(r"[.!?。](?=[\s\"'”’)\]]|$)", body):
            best = m.end()
        if best > 0 and best >= int(len(body) * 0.45):
            return body[:best].rstrip(), True
        return fit, True

    def _actor_profile_publish_bio_preview_r92(self, text):
        full = " ".join(str(text or "").replace("\r", " ").replace("\n", " ").split())
        try:
            preview, more = self._actor_profile_bio_preview_r92(full)
        except Exception:
            preview, more = full, False
        self._actor_profile_bio_full_r92 = full
        self._actor_profile_set_prop_v2454("BiographyFull", full)
        self._actor_profile_set_prop_v2454("BiographyPreview", preview)
        self._actor_profile_set_prop_v2454("BiographyMore", "1" if (more and full) else "")
        if not (more and full):
            # A late, shorter biography hides 더보기; never leave focus on a hidden button.
            try:
                if int(self.getFocusId() or 0) == 6486:
                    self.setFocusId(6500)
            except Exception:
                pass
        return preview, more

    def _actor_profile_bio_popup_is_open_r93(self):
        try:
            return str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BioPopup") or "") == "1"
        except Exception:
            return False

    def _actor_profile_open_bio_dialog_r92(self):
        """R93: 더보기 -> full biography as an overlay inside this window.

        R92 used a separate WindowXMLDialog; while it was the active window every
        Window.Property() lookup in the sidebar read the dialog (empty) and the
        collapsed pill turned white.  The overlay keeps this window active, so
        nothing behind it changes.  Focus 6487 pages the text, OK/Back closes.
        """
        if not self._actor_profile_is_active_v2454():
            return False
        full = str(
            getattr(self, "_actor_profile_bio_full_r92", "")
            or xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BiographyFull")
            or ""
        ).strip()
        if not full:
            return False
        self._actor_profile_set_prop_v2454("BioPopup", "1")
        try:
            self.setFocusId(6487)
        except Exception:
            pass
        _log("ACTOR_PROFILE_BIO_POPUP_OPEN_R93 actor=%s chars=%d" % (
            _short_log_value(getattr(self, "_actor_profile_return_name_v2454", ""), 80), len(full)))
        return True

    def _actor_profile_close_bio_popup_r93(self, restore_focus=True):
        if not self._actor_profile_bio_popup_is_open_r93():
            return False
        self._actor_profile_set_prop_v2454("BioPopup", "")
        if restore_focus and self._actor_profile_is_active_v2454():
            try:
                if xbmc.getCondVisibility("Control.IsVisible(6486)"):
                    self.setFocusId(6486)
                else:
                    self.setFocusId(6500)
            except Exception:
                pass
        _log("ACTOR_PROFILE_BIO_POPUP_CLOSE_R93")
        return True

    def _actor_profile_bg_blur_source_r92(self, thumb):
        """Only a local, already cached portrait is used; never a network fetch."""
        src = str(thumb or "").strip()
        if not src or src.lower().startswith(("http://", "https://", "image://")):
            return ""
        try:
            if src.lower().startswith("special://"):
                src = xbmcvfs.translatePath(src)
            if os.path.isfile(src) and os.path.getsize(src) > 1024:
                return src
        except Exception:
            pass
        return ""

    def _actor_profile_bg_blur_path_r92(self, src, bg_color):
        try:
            st = os.stat(src)
            key = "%s|%d|%d|%s|r92a" % (os.path.normcase(os.path.abspath(src)), int(st.st_size), int(st.st_mtime), str(bg_color or ""))
        except Exception:
            key = "%s|%s|r92a" % (src, bg_color)
        root = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/actor_bg_r92/")
        return os.path.join(root, hashlib.sha1(key.encode("utf-8", "replace")).hexdigest()[:24] + ".jpg")

    def _actor_profile_bg_blur_build_r92(self, src, dst, bg_color):
        """Blur + darken the portrait into a 452x270 JPEG whose left edge fades to BgColor."""
        from PIL import Image, ImageFilter
        try:
            c = str(bg_color or "FF222324").strip()
            c = c[-6:] if len(c) >= 6 else "222324"
            base_rgb = (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16))
        except Exception:
            base_rgb = (34, 35, 36)
        im = Image.open(src)
        try:
            im.draft("RGB", (180, 270))
        except Exception:
            pass
        im = im.convert("RGB")
        w, h = im.size
        if w < 8 or h < 8:
            return False
        out_w, out_h = 452, 270
        # Landscape slice of the portrait around the face (upper third).
        crop_h = max(1, min(h, int(round(w * out_h / float(out_w)))))
        top = max(0, min(h - crop_h, int(round(h * 0.10))))
        im = im.crop((0, top, w, top + crop_h))
        im = im.resize((48, 29), Image.BILINEAR)
        im = im.filter(ImageFilter.GaussianBlur(2.6))
        im = im.resize((out_w, out_h), Image.BILINEAR)
        im = im.filter(ImageFilter.GaussianBlur(6))
        # Darken toward the page colour so text stays readable.
        base = Image.new("RGB", (out_w, out_h), base_rgb)
        dark = Image.new("RGB", (out_w, out_h), tuple(int(v * 0.35) for v in base_rgb))
        im = Image.blend(im, dark, 0.50)
        # Left edge -> exact BgColor, so the sidebar gap strips join without a seam.
        ramp_w = int(out_w * 0.22)
        mask = Image.new("L", (out_w, out_h), 255)
        # linear_gradient runs 0 (top) -> 255 (bottom); rotated 90 deg it runs 0 (left)
        # -> 255 (right): mask 0 = BgColor at the very edge, 255 = blurred portrait.
        ramp = Image.linear_gradient("L").rotate(90, expand=True).resize((ramp_w, out_h))
        mask.paste(ramp, (0, 0))
        im = Image.composite(im, base, mask)
        folder = os.path.dirname(dst)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = "%s.%s.tmp" % (dst, threading.get_ident())
        im.save(tmp, "JPEG", quality=82)
        os.replace(tmp, dst)
        return True

    def _actor_profile_bg_blur_schedule_r92(self, actor_name, thumb, bg_color=""):
        """Publish PlexKM.ActorProfile.BgBlur for the current actor.

        Cache hit -> set immediately (same frame as the page).  Miss -> build on a
        worker and fade in.  No portrait / no Pillow -> stays empty and the XML
        falls back to BgColor + bottom fade.
        """
        actor_name = str(actor_name or "").strip()
        try:
            bg_color = str(
                bg_color
                or xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BgColor")
                or "FF222324"
            ).strip()
            src = self._actor_profile_bg_blur_source_r92(thumb)
            if not src:
                return False
            dst = self._actor_profile_bg_blur_path_r92(src, bg_color)
            if os.path.isfile(dst) and os.path.getsize(dst) > 512:
                self._actor_profile_set_prop_v2454("BgBlur", dst)
                return True
        except Exception:
            return False
        token = int(getattr(self, "_actor_profile_bg_blur_token_r92", 0) or 0) + 1
        self._actor_profile_bg_blur_token_r92 = token

        def _worker():
            t0 = time.time()
            try:
                ok = self._actor_profile_bg_blur_build_r92(src, dst, bg_color)
            except Exception:
                _log("ACTOR_PROFILE_BG_BLUR_FAILED_R92 actor=%s err=%s" % (
                    _short_log_value(actor_name, 80), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
                return
            if not ok or token != int(getattr(self, "_actor_profile_bg_blur_token_r92", 0) or 0):
                return
            current = str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip()
            if actor_name and current and current.casefold() != actor_name.casefold():
                return
            self._actor_profile_set_prop_v2454("BgBlur", dst)
            _log("ACTOR_PROFILE_BG_BLUR_READY_R92 actor=%s build_ms=%d" % (
                _short_log_value(actor_name, 80), int((time.time() - t0) * 1000.0)
            ))

        threading.Thread(target=_worker, name="PKMActorBgBlurR92", daemon=True).start()
        return True

    def _actor_profile_korean_biography_v2459(self, biography):
        """Expose biography only when the text is genuinely Korean.

        v2459 used a simple "contains Hangul" test. An English biography such
        as "Ryu Jun-yeol (Hangul: 류준열) ..." therefore passed accidentally.
        v2463 requires a meaningful Korean-character ratio instead.
        """
        text = str(biography or "").strip()
        if not text:
            return ""

        hangul = len(re.findall(r"[가-힣]", text))
        latin = len(re.findall(r"[A-Za-z]", text))
        letters = hangul + latin

        # Genuine Korean biography: enough Korean content and Korean must be a
        # substantial share of the actual alphabetic text.
        if hangul < 12:
            return ""
        if letters > 0 and (float(hangul) / float(letters)) < 0.35:
            return ""
        return text

    def _wiki_bio_cache_r68(self):
        cache = getattr(self, "_wiki_bio_cache_mem_r68", None)
        if isinstance(cache, dict):
            return cache
        cache = {}
        try:
            path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/actor_wiki_bio_r68.json")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if isinstance(data, dict):
                    cache = data
        except Exception:
            cache = {}
        self._wiki_bio_cache_mem_r68 = cache
        return cache

    def _wiki_bio_cache_save_r68(self):
        try:
            path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/actor_wiki_bio_r68.json")
            with self._WIKI_BIO_LOCK_R68:
                data = dict(self._wiki_bio_cache_r68())
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception:
            pass

    @staticmethod
    def _wiki_bio_key_r68(actor_name, profile):
        tmdb = str((profile or {}).get("tmdb_id") or "").strip()
        return ("tmdb:%s" % tmdb) if tmdb else ("name:%s" % str(actor_name or "").strip().casefold())

    def _wiki_bio_cached_r68(self, actor_name, profile):
        """Return (found, text): found=False when no fresh cache entry exists."""
        cache = self._wiki_bio_cache_r68()
        keys = [self._wiki_bio_key_r68(actor_name, profile), "name:%s" % str(actor_name or "").strip().casefold()]
        for key in keys:
            rec = cache.get(key)
            if not isinstance(rec, dict):
                continue
            text = str(rec.get("text") or "")
            ttl = self._WIKI_BIO_TTL_R68 if text else self._WIKI_BIO_NEG_TTL_R68
            if time.time() - float(rec.get("t") or 0) < ttl:
                return True, text
        return False, ""

    def _wiki_bio_better_r68(self, current, wiki):
        current = " ".join(str(current or "").split())
        wiki = " ".join(str(wiki or "").split())
        if not wiki:
            return False
        if not current:
            return True
        return len(current) < self._WIKI_BIO_SHORT_R68 and len(wiki) > len(current) + 20

    def _actor_wiki_bio_apply_r68(self, actor_name, profile):
        profile = dict(profile or {})
        found, text = self._wiki_bio_cached_r68(actor_name, profile)
        if found and self._wiki_bio_better_r68(profile.get("biography"), text):
            profile["biography"] = text
            profile["biography_source"] = "wikipedia_ko"
            _log("ACTOR_WIKI_BIO_APPLY_R68 actor=%s chars=%d source=cache" % (_short_log_value(actor_name, 80), len(text)))
        return profile

    @staticmethod
    def _wiki_clean_intro_r68(text):
        text = str(text or "").strip()
        text = re.sub(r"(한국 )?한자\s*:\s*[^,)]*,?\s*", "", text)
        text = re.sub(r"[\u4e00-\u9fff]+\s*,\s*", "", text)

        def _paren(m):
            inner = m.group(1)
            keep = [x.strip() for x in inner.split(",")
                    if re.search(r"[가-힣0-9]", x) and not re.search(r"[一-鿿]", x)]
            return "(%s)" % ", ".join(keep) if keep else ""
        # Drop hanja / romanisation inside the first parenthesis only.
        text = re.sub(r"\(([^()]{0,120})\)", _paren, text, count=1)
        text = re.sub(r"\s+\)", ")", text)
        return " ".join(text.split())

    def _wiki_build_bio_r68(self, extract):
        """Lead paragraph + prose sections; list sections become 주요 출연작."""
        extract = str(extract or "")
        parts = re.split(r"\n(={2,})\s*(.*?)\s*\1\n", "\n" + extract + "\n")
        intro = self._wiki_clean_intro_r68(parts[0])
        prose = []
        titles = []
        i = 1
        while i + 2 < len(parts) + 1 and i + 1 < len(parts):
            heading = str(parts[i + 1] or "").strip()
            body = str(parts[i + 2] if i + 2 < len(parts) else "")
            i += 3
            if re.search(r"(학력|음반|수상|각주|참고|외부|같이|광고|뮤직 비디오|디스코그래피|작사|피처링)", heading):
                continue
            for line in body.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if re.match(r"^\d{4}년", line) and "《" in line:
                    if re.search(r"(드라마|영화|출연|작품)", heading) or True:
                        m = re.search(r"《([^》]{1,40})》", line)
                        if m and m.group(1) not in titles:
                            titles.append(m.group(1))
                    continue
                if len(line) >= 40 and re.search(r"[가-힣]", line) and re.search(r"(다|요)\.?$", line):
                    prose.append(line)
        out = intro
        for para in prose:
            if len(out) >= 700:
                break
            out = (out + " " + para).strip()
        if titles and len(out) < 260:
            recent = titles[-6:][::-1]
            out = (out + " 주요 출연작: " + ", ".join(recent) + ".").strip()
        return out[:900]

    def _wiki_http_json_r68(self, url):
        req = Request(url, headers={"User-Agent": self._WIKI_UA_R68, "Accept": "application/json"})
        resp = urlopen(req, timeout=4.0)
        try:
            return json.loads(resp.read().decode("utf-8", "replace") or "{}")
        finally:
            resp.close()

    def _wiki_master_identity_r68(self, actor_name, tmdb_id):
        """(wikidata_id, birthday) from the local Actor Master DB, read-only."""
        try:
            dbp = self._pkm_actor_local_db_path_u1()
            if not dbp or not os.path.isfile(dbp):
                return "", ""
            conn = sqlite3.connect("file:%s?mode=ro" % dbp, uri=True, timeout=0.5)
            try:
                row = None
                if tmdb_id:
                    row = conn.execute("SELECT wikidata_id, birthday FROM actors WHERE CAST(tmdb_id AS TEXT)=? LIMIT 1",
                                       (str(tmdb_id),)).fetchone()
                if row is None and actor_name:
                    row = conn.execute("SELECT wikidata_id, birthday FROM actors WHERE korean_name=? OR source_name=? LIMIT 1",
                                       (actor_name, actor_name)).fetchone()
            finally:
                conn.close()
            if row:
                return str(row[0] or "").strip(), str(row[1] or "").strip()
        except Exception:
            pass
        return "", ""

    def _wiki_fetch_bio_r68(self, actor_name, tmdb_id, birthday):
        wikidata_id, master_birthday = self._wiki_master_identity_r68(actor_name, tmdb_id)
        birthday = str(birthday or master_birthday or "")
        year = birthday[:4] if re.match(r"^\d{4}", birthday) else ""
        titles = []
        if re.match(r"^Q\d+$", wikidata_id):
            try:
                data = self._wiki_http_json_r68(
                    "https://www.wikidata.org/w/api.php?action=wbgetentities&ids=%s&props=sitelinks&sitefilter=kowiki&format=json"
                    % wikidata_id)
                t = (((data.get("entities") or {}).get(wikidata_id) or {}).get("sitelinks") or {}).get("kowiki", {}).get("title")
                if t:
                    titles.append((t, "wikidata"))
            except Exception:
                pass
        if not titles:
            for t in (actor_name, "%s (배우)" % actor_name, "%s (가수)" % actor_name):
                titles.append((t, "name"))
        for title, how in titles:
            try:
                data = self._wiki_http_json_r68(
                    "https://ko.wikipedia.org/w/api.php?action=query&prop=extracts|pageprops&explaintext=1"
                    "&exsectionformat=wiki&exchars=4000&redirects=1&format=json&titles=%s" % quote(title))
            except Exception:
                continue
            pages = list(((data.get("query") or {}).get("pages") or {}).values())
            if not pages or "missing" in pages[0]:
                continue
            page = pages[0]
            if "disambiguation" in (page.get("pageprops") or {}):
                continue
            extract = str(page.get("extract") or "")
            lead = extract.split("\n==", 1)[0]
            if how == "name":
                # Name lookups must prove the identity: birth year, else an
                # occupation word in the lead sentence.
                if year and year not in lead:
                    continue
                if not year and not re.search(r"(배우|가수|탤런트|연기자|코미디언|방송인|모델|성우)", lead):
                    continue
            text = self._wiki_build_bio_r68(extract)
            if text:
                return text, page.get("title") or title, how
        return "", "", "none"

    def _actor_wiki_bio_schedule_r68(self, actor_name, profile, reason=""):
        actor_name = str(actor_name or "").strip()
        if not actor_name:
            return False
        profile = dict(profile or {})
        current = profile.get("biography") or ""
        if len(" ".join(str(current).split())) >= self._WIKI_BIO_SHORT_R68:
            return False
        found, _text = self._wiki_bio_cached_r68(actor_name, profile)
        if found:
            return False
        inflight = getattr(self, "_wiki_bio_inflight_r68", None)
        if inflight is None:
            inflight = set()
            self._wiki_bio_inflight_r68 = inflight
        key = self._wiki_bio_key_r68(actor_name, profile)
        name_key_r77 = "name:%s" % actor_name.casefold()
        if key in inflight or name_key_r77 in inflight:
            return False
        inflight.add(key)
        inflight.add(name_key_r77)
        tmdb_id = str(profile.get("tmdb_id") or "")
        birthday = str(profile.get("birthday") or "")

        def _worker():
            t0 = time.time()
            try:
                text, title, how = self._wiki_fetch_bio_r68(actor_name, tmdb_id, birthday)
                with self._WIKI_BIO_LOCK_R68:
                    cache = self._wiki_bio_cache_r68()
                    rec = {"t": time.time(), "text": text, "title": title}
                    cache[key] = rec
                    cache["name:%s" % actor_name.casefold()] = rec
                self._wiki_bio_cache_save_r68()
                _log("ACTOR_WIKI_BIO_FETCH_R68 actor=%s tmdb=%s via=%s title=%s chars=%d elapsed_ms=%d reason=%s" % (
                    _short_log_value(actor_name, 80), tmdb_id or "-", how, _short_log_value(title, 60),
                    len(text), int((time.time() - t0) * 1000), reason or ""))
                if text and self._wiki_bio_better_r68(current, text) and not self._closing_event_v1841.is_set():
                    self._wiki_bio_pending_r68 = (actor_name, text)
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
            except Exception:
                _log("ACTOR_WIKI_BIO_FAILED_R68 actor=%s err=%s" % (
                    _short_log_value(actor_name, 80), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            finally:
                try:
                    inflight.discard(key)
                    inflight.discard(name_key_r77)
                except Exception:
                    pass

        threading.Thread(target=_worker, name="PKMActorWikiBioR68", daemon=True).start()
        return True

    def _actor_wiki_bio_commit_r68(self):
        pending = getattr(self, "_wiki_bio_pending_r68", None)
        if not pending:
            return False
        self._wiki_bio_pending_r68 = None
        actor_name, text = pending
        if not self._actor_profile_is_active_v2454():
            return False
        current_actor = str(getattr(self, "_actor_profile_return_name_v2454", "") or "").strip()
        if not current_actor or current_actor.casefold() != str(actor_name or "").strip().casefold():
            return False
        display = self._actor_profile_biography_boxfit_v2504(text, inner_width_px=696, inner_height_px=144)
        self._actor_profile_set_prop_v2454("Biography", text)
        self._actor_profile_set_prop_v2454("BiographyKo", text)
        self._actor_profile_set_prop_v2454("BiographyDisplay", display)
        scroll_ready = (
            str(xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.BioScrollReady") or "").strip() == "1"
            or str(self.getProperty("PlexKM.ActorProfile.BioScrollReady") or "").strip() == "1"
        )
        self._actor_profile_set_prop_v2454("BiographyViewport", (text.rstrip() + "[CR]") if scroll_ready else display)
        self._actor_profile_publish_bio_preview_r92(text)
        self._actor_profile_set_prop_v2454("BiographyLanguage", "ko")
        self._actor_profile_set_prop_v2454("BiographySource", "wikipedia_ko")
        _log("ACTOR_WIKI_BIO_COMMIT_R68 actor=%s chars=%d scroll_ready=%d" % (
            _short_log_value(actor_name, 80), len(text), 1 if scroll_ready else 0))
        return True

    def _actor_profile_biography_display_v2488(self, profile):
        """Return actor biography using strict TMDb Korean-first semantics.

        V2488 intentionally does not infer display language from the user's Kodi
        locale.  The TMDb Helper transaction already queried Korean first.  If
        that Korean person record supplied Biography, it is authoritative and is
        displayed even when the text contains names/phrases in Latin script.  Only
        when the Korean Biography was genuinely empty may the original Helper
        language fallback be shown.  Legacy cached profiles without a source tag
        use Hangul detection only as a migration aid; they are never allowed to
        override a known helper_korean result with an English fallback.
        """
        profile = dict(profile or {})
        text = " ".join(str(profile.get("biography") or "").replace("\r", " ").replace("\n", " ").split())
        if not text:
            return "", "missing"
        source = str(profile.get("biography_source") or "").strip().casefold()
        if source in ("helper_korean", "wikipedia_ko"):
            return text, "ko"
        if source == "helper_original_language_fallback":
            return text, "original_fallback"
        # Legacy/migrated cache: a genuinely Korean body is still preferred.
        if self._actor_profile_korean_biography_v2459(text):
            return text, "ko_legacy"
        return text, "original_legacy"

    def _actor_profile_biography_boxfit_v2504(self, text, inner_width_px=1076, inner_height_px=321):
        """Fit Actor biography by the rendered card box, never by a fixed char count.

        V2537 uses the compact biography box (1100x345, 12px inset =>
        1076x321). The fitter derives wrapping and line budget from the supplied
        pixel box; there is no fixed character limit. Ellipsis is appended only
        when the measured wrapped text would overflow that real box.
        """
        value = " ".join(str(text or "").replace("\r", " ").replace("\n", " ").split())
        if not value:
            return ""

        # Keep a small right-edge safety margin for Kodi's font rasterization.
        line_limit = max(80, int(inner_width_px) - 12)
        # NotoSansKR-Medium 25px renders at roughly 36-38px line pitch here.
        # The visible line budget is always derived from the current inner height,
        # so widening/tallening the XML box automatically permits more biography.
        # ACTOR_BIO_SCROLL_R13:
        # The 186px ActorProfile viewport visibly fits five lines with the
        # current plexkm_font12.  38px floored the budget to four lines and
        # placed "..." one line too early.
        line_pitch = 36
        max_lines = max(1, int(inner_height_px) // line_pitch)

        def _glyph_px(ch):
            if not ch:
                return 0.0
            if ch.isspace():
                return 6.0
            if unicodedata.east_asian_width(ch) in ("W", "F"):
                return 24.0
            if ch in ".,'`":
                return 7.0
            if ch in "()[]{}":
                return 9.0
            if ch in "!?:;":
                return 9.0
            if ch in "·/\\|-_":
                return 12.0
            if "A" <= ch <= "Z":
                return 16.0
            if "a" <= ch <= "z":
                return 14.0
            if "0" <= ch <= "9":
                return 14.0
            if unicodedata.category(ch).startswith("P"):
                return 12.0
            return 15.0

        def _line_count(candidate):
            if not candidate:
                return 0
            lines = 1
            used = 0.0
            for word in candidate.split(" "):
                if not word:
                    continue
                ww = sum(_glyph_px(ch) for ch in word)
                sw = 6.0 if used else 0.0
                if ww <= line_limit:
                    if used and used + sw + ww > line_limit:
                        lines += 1
                        used = ww
                    else:
                        used += sw + ww
                else:
                    if used:
                        lines += 1
                        used = 0.0
                    for ch in word:
                        cw = _glyph_px(ch)
                        if used and used + cw > line_limit:
                            lines += 1
                            used = 0.0
                        used += cw
                if lines > max_lines:
                    return lines
            return lines

        if _line_count(value) <= max_lines:
            return value

        ellipsis = "..."
        lo, hi, best = 0, len(value), 0
        while lo <= hi:
            mid = (lo + hi) // 2
            cut = value[:mid].rstrip().rstrip(" .,;:·/")
            probe = (cut + ellipsis) if cut else ellipsis
            if _line_count(probe) <= max_lines:
                best = mid
                lo = mid + 1
            else:
                hi = mid - 1
        cut = value[:best].rstrip().rstrip(" .,;:·/")
        while cut and _line_count(cut + ellipsis) > max_lines:
            cut = cut[:-1].rstrip().rstrip(" .,;:·/")
        return (cut + ellipsis) if cut else ellipsis

    def _actor_profile_open_from_cast_v2454(self, control_id, reason="cast_click"):
        now_ms = self._now_ms()
        if now_ms - int(getattr(self, "_actor_profile_open_guard_ms_v2454", 0) or 0) < 650:
            return False
        if self._actor_profile_is_active_v2454():
            return True
        if not (self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
            return False
        try:
            ctrl = self.getControl(int(control_id))
            selected = ctrl.getSelectedItem()
            pos = int(ctrl.getSelectedPosition())
        except Exception:
            selected = None
            pos = -1
        if selected is None:
            return False
        actor_name = str(selected.getProperty("PlexKM.Cast.Name") or selected.getLabel() or "").strip()
        if not actor_name:
            return False
        # v2612: ActorProfile can be re-entered synchronously by focus/layout
        # callbacks while an older click invocation is still on the stack.  The
        # newest invocation owns publication; an older invocation may finish its
        # local work but must never publish a second, slower Actor visible event.
        # V2614: suppress synchronous/re-entrant duplicate opens while the first
        # invocation is still constructing the same Actor surface.  V2613 could
        # spend >1 s in a desktop persistent-authority check, leaving a large
        # window for a second callback to enter and later publish a duplicate page.
        _actor_inflight_v2614 = str(getattr(self, "_actor_profile_open_inflight_v2614", "") or "").strip()
        if _actor_inflight_v2614 and not self._actor_profile_is_active_v2454():
            _log("ACTOR_PROFILE_REENTRY_SUPPRESS_V2614 actor=%s inflight=%s action=keep_first" % (
                _short_log_value(actor_name,80), _short_log_value(_actor_inflight_v2614,80)
            ))
            return True
        _actor_open_seq_v2612, _actor_selected_index_v2524, _actor_selected_local_v2524, _actor_selected_original_v2524, _actor_selected_thumb_v2524, _actor_selected_visible_v2610 = self._actor_profile_open_from_cast_v2454_step1(actor_name, now_ms, selected)
        _actor_open_started_v2481 = self._actor_profile_open_from_cast_v2454_step2(actor_name, control_id, now_ms, pos)
        current_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or getattr(self, "_last_info_rating_key", "") or "").strip()
        # V2614: persistent content-authority validation is never a foreground
        # ActorProfile prerequisite, including on the PC reference platform.
        # The V2613 desktop branch accidentally restored _actor_page_prepared_get,
        # and the latest trace shows prepared_lookup taking ~1.2 s even on Ryzen.
        # Session memory is authoritative for the current window; otherwise local
        # filmography + the small actor-profile cache build the first frame.
        busy, prepared_v2467 = self._actor_profile_open_from_cast_v2454_step3(_actor_open_started_v2481, actor_name, current_rk)
        try:
            if prepared_v2467:
                profile = dict(prepared_v2467.get("profile") or {})
                movie_rows = list(prepared_v2467.get("movie") or [])
                tv_rows = list(prepared_v2467.get("show") or [])
                rows_cached_v2522 = True
                rows_event_v2522 = None
                rows_box_v2522 = {}
                _log("ACTOR_PROFILE_OPEN_TIMING_V2526 actor=%s phase=prepared_complete elapsed_ms=%d source=session_or_persistent incomplete_reveal=0" % (
                    _short_log_value(actor_name,80), int((time.time()-_actor_open_started_v2481)*1000.0)
                ))
            else:
                # v2526 fallback contract: never expose a skeleton ActorProfile.
                # Local filmography can still prepare in parallel, but TMDb profile
                # completion remains behind the parent Info surface. In normal use
                # media-ahead makes this rare; a truly first-ever cold target cannot
                # be both externally complete and zero-latency before its source data
                # exists, so correctness wins over a visible late morph.
                rows_cached_v2522 = self._actor_profile_local_rows_cache_get_v2522(actor_name, current_rk, max_age_s=30.0)
                rows_event_v2522 = None
                rows_box_v2522 = {}
                if rows_cached_v2522:
                    movie_rows = list(rows_cached_v2522.get("movie") or [])
                    tv_rows = list(rows_cached_v2522.get("show") or [])
                    _log("ACTOR_PROFILE_LOCAL_ROWS_PREWARM_HIT_V2526 actor=%s age_ms=%d movies=%d tv=%d foreground_db_query=0" % (
                        _short_log_value(actor_name,80), int(rows_cached_v2522.get("age_ms") or 0), len(movie_rows), len(tv_rows)
                    ))
                else:
                    rows_event_v2522 = threading.Event()
                    def _rows_worker_v2526():
                        t0 = time.time()
                        try:
                            works_v2526 = self._actor_profile_local_works_v2454(actor_name, current_rating_key=current_rk, limit=None)
                            rows_box_v2522["movie"] = list((works_v2526 or {}).get("movie") or [])
                            rows_box_v2522["show"] = list((works_v2526 or {}).get("show") or [])
                            rows_box_v2522["elapsed_ms"] = int((time.time()-t0)*1000.0)
                            self._actor_profile_local_rows_cache_put_v2522(actor_name, current_rk, works_v2526)
                        finally:
                            rows_event_v2522.set()
                    _PKMHomeThreadV2151(target=_rows_worker_v2526, name="ActorProfileRowsV2526", daemon=True).start()

                _phase_v2481 = time.time()
                local_existing_v2526 = str(_actor_selected_local_v2524 or "").strip()
                profile = self._actor_profile_cache_get_v2454(actor_name) or {}
                if not profile:
                    # V2599 hard rule: external Helper/TMDb never blocks Actor
                    # visibility. Name + parent cast portrait + local works are the
                    # first frame; biography/birthday enrich later.
                    profile = {
                        "label": actor_name, "name": actor_name,
                        "source": "local_first_v2599", "_v2599_provisional": 1,
                        "biography": "", "birthday": "", "department": "",
                    }
                    _log("ACTOR_PROFILE_COLD_LOCAL_FIRST_V2599 actor=%s source=%s tmdb_wait=0 parent_info_hold=0" % (
                        _short_log_value(actor_name,80), current_rk or ""
                    ))
                if rows_event_v2522 is not None:
                    # V2673 mandatory-work gate: the old 120 ms peek published an
                    # empty page while the same local query completed ~1-2 s later.
                    # Hold Info + spinner until the local rail is actually ready.
                    _rows_wait_t0_v2673 = time.time()
                    _rows_done_v2673 = rows_event_v2522.wait(8.0 if self._uhd_kpi_proxy_v2605() else 5.0)
                    movie_rows = list(rows_box_v2522.get("movie") or [])
                    tv_rows = list(rows_box_v2522.get("show") or [])
                    _log("ACTOR_PROFILE_MANDATORY_ROWS_GATE_V2673 actor=%s source=%s wait_ms=%d done=%d movies=%d tv=%d" % (
                        _short_log_value(actor_name,80), current_rk or "", int((time.time()-_rows_wait_t0_v2673)*1000.0),
                        1 if _rows_done_v2673 else 0, len(movie_rows), len(tv_rows)
                    ))
                    if not _rows_done_v2673:
                        # Extremely slow/stuck worker: correctness still wins.
                        # Run one authoritative foreground lookup; its built-in
                        # V2670 source-title fallback guarantees >=1 work item.
                        works_v2673 = self._actor_profile_local_works_v2454(actor_name, current_rating_key=current_rk, limit=None)
                        movie_rows = list((works_v2673 or {}).get("movie") or [])
                        tv_rows = list((works_v2673 or {}).get("show") or [])
                        _log("ACTOR_PROFILE_MANDATORY_ROWS_TIMEOUT_FALLBACK_V2673 actor=%s source=%s movies=%d tv=%d" % (
                            _short_log_value(actor_name,80), current_rk or "", len(movie_rows), len(tv_rows)
                        ))
                elif not rows_cached_v2522:
                    works_v2526 = self._actor_profile_local_works_v2454(actor_name, current_rating_key=current_rk, limit=None)
                    movie_rows = list((works_v2526 or {}).get("movie") or [])
                    tv_rows = list((works_v2526 or {}).get("show") or [])
                # v2544: first cold paint never localizes a remote TMDb portrait.
                # If a prior visit already cached the alternate locally, use it;
                # otherwise the parent Info cast portrait is immediate and complete.
                session_thumb_v2526 = ""
                session_thumb_source_v2539 = "placeholder_v2544"
                cached_alt_v2544 = str(profile.get("portrait_local_v2544") or "").strip()
                try:
                    if cached_alt_v2544 and not cached_alt_v2544.lower().startswith(("http://", "https://", "image://")):
                        cached_alt_v2544 = xbmcvfs.translatePath(cached_alt_v2544) if cached_alt_v2544.lower().startswith("special://") else cached_alt_v2544
                        if os.path.isfile(cached_alt_v2544) and os.path.getsize(cached_alt_v2544) > 1024:
                            session_thumb_v2526 = cached_alt_v2544
                            session_thumb_source_v2539 = "tmdb_alt_global_cache_v2544"
                except Exception:
                    session_thumb_v2526 = ""
                if not session_thumb_v2526 and local_existing_v2526:
                    session_thumb_v2526 = local_existing_v2526
                    session_thumb_source_v2539 = "info_cast_first_v2544"
                _log("ACTOR_PROFILE_PORTRAIT_COLD_V2544 actor=%s source=%s cached_tmdb=%d info_cast=%d network_wait=0" % (
                    _short_log_value(actor_name,80), session_thumb_source_v2539,
                    1 if session_thumb_source_v2539 == "tmdb_alt_global_cache_v2544" else 0,
                    1 if session_thumb_source_v2539 == "info_cast_first_v2544" else 0
                ))
                self._actor_page_session_ready_put_v2526(
                    actor_name, current_rk, profile, movie_rows, tv_rows,
                    local_thumb=session_thumb_v2526, source="cold_complete_v2526"
                )
                prepared_v2467 = self._actor_page_session_ready_get_v2526(actor_name, current_rk)
                if prepared_v2467:
                    profile = dict(prepared_v2467.get("profile") or profile)
                    movie_rows = list(prepared_v2467.get("movie") or movie_rows)
                    tv_rows = list(prepared_v2467.get("show") or tv_rows)
                _log("ACTOR_PROFILE_COLD_COMPLETE_READY_V2526 actor=%s elapsed_ms=%d tmdb=%d bio=%d birthday=%d thumb_local=%d incomplete_reveal=0" % (
                    _short_log_value(actor_name,80), int((time.time()-_phase_v2481)*1000.0),
                    1 if profile.get("tmdb_id") else 0, 1 if str(profile.get("biography") or "").strip() else 0,
                    1 if str(profile.get("birthday") or "").strip() else 0, 1 if session_thumb_v2526 else 0
                ))
                _log("ACTOR_PROFILE_OPEN_TIMING_V2526 actor=%s phase=cold_complete_gate elapsed_ms=%d source=%s local_rows_parallel=%d pending_background=0 incomplete_reveal=0" % (
                    _short_log_value(actor_name,80), int((time.time()-_actor_open_started_v2481)*1000.0),
                    profile.get("source") or "", 0 if rows_cached_v2522 else 1
                ))
                # V2599: provisional local-first data is session-only. Never
                # persist it as a complete Actor page or it would suppress the
                # background TMDb enrichment on later visits.
                if not bool((profile or {}).get("_v2599_provisional")):
                    try:
                        persist_actor_v2526 = actor_name
                        persist_rk_v2526 = current_rk
                        persist_profile_v2526 = dict(profile or {})
                        persist_movie_v2526 = list(movie_rows or [])
                        persist_tv_v2526 = list(tv_rows or [])
                        persist_thumb_v2526 = str(session_thumb_v2526 or "")
                        def _persist_cold_actor_v2526():
                            self._actor_page_prepared_store_v2467(
                                persist_actor_v2526, persist_rk_v2526, persist_profile_v2526,
                                persist_movie_v2526, persist_tv_v2526, local_thumb=persist_thumb_v2526
                            )
                        _PKMHomeThreadV2151(target=_persist_cold_actor_v2526, name="ActorProfilePersistV2526", daemon=True).start()
                    except Exception:
                        pass
                else:
                    _log("ACTOR_PROFILE_PROVISIONAL_PERSIST_SKIP_V2599 actor=%s persistent_complete=0" % _short_log_value(actor_name,80))
            # v2529: Actor Profile has one In Library rail.  Movies and shows are
            # mixed into one stable year-descending sequence; media type remains on
            # each ListItem so opening a poster still routes to the correct Info type.
            _movie_count_v2529 = len(movie_rows or [])
            _tv_count_v2529 = len(tv_rows or [])
            in_library_rows_v2529 = list(movie_rows or []) + list(tv_rows or [])
            def _in_library_order_v2529(row_v2529):
                try:
                    year_v2529 = int((row_v2529 or ())[7] or 0)
                except Exception:
                    year_v2529 = 0
                try:
                    title_v2529 = str((row_v2529 or ())[4] or "").strip().casefold()
                except Exception:
                    title_v2529 = ""
                return (-year_v2529, title_v2529)
            in_library_rows_v2529.sort(key=_in_library_order_v2529)
            in_library_items_v2529 = None
            try:
                _pre_r101 = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
                if (isinstance(_pre_r101, dict)
                        and _pre_r101.get("sig") == self._actor_profile_lis_signature_r101(actor_name, in_library_rows_v2529)
                        and _pre_r101.get("lis")):
                    in_library_items_v2529 = list(_pre_r101.get("lis") or [])
                    self._actor_profile_prebuilt_lis_r101 = None
                    try:
                        (getattr(self, "_actor_profile_lis_cache_r115", None) or {}).pop(_pre_r101.get("sig"), None)
                    except Exception:
                        pass
                    _log("ACTOR_PROFILE_LIS_PREBUILT_HIT_R101 actor=%s items=%d" % (
                        _short_log_value(actor_name, 80), len(in_library_items_v2529)))
                else:
                    _sig_r115 = self._actor_profile_lis_signature_r101(actor_name, in_library_rows_v2529)
                    _wait_evt_r115 = (getattr(self, "_actor_profile_lis_inflight_r115", None) or {}).get(_sig_r115)
                    if _wait_evt_r115 is not None and not _wait_evt_r115.is_set():
                        _w0_r115 = time.time()
                        _wait_evt_r115.wait(1.0)
                        _log("ACTOR_PROFILE_LIS_INFLIGHT_WAIT_R115 actor=%s waited_ms=%d done=%d" % (
                            _short_log_value(actor_name, 80), int((time.time() - _w0_r115) * 1000),
                            1 if _wait_evt_r115.is_set() else 0))
                    _hit_r115 = (getattr(self, "_actor_profile_lis_cache_r115", None) or {}).pop(_sig_r115, None)
                    if _hit_r115:
                        in_library_items_v2529 = list(_hit_r115)
                        try:
                            _cur_r115 = getattr(self, "_actor_profile_prebuilt_lis_r101", None)
                            if isinstance(_cur_r115, dict) and _cur_r115.get("sig") == _sig_r115:
                                self._actor_profile_prebuilt_lis_r101 = None
                        except Exception:
                            pass
                        _log("ACTOR_PROFILE_LIS_PREBUILT_HIT_R115 actor=%s items=%d source=lru" % (
                            _short_log_value(actor_name, 80), len(in_library_items_v2529)))
            except Exception:
                in_library_items_v2529 = None
            if in_library_items_v2529 is None:
                in_library_items_v2529 = self._actor_profile_build_work_listitems_v2454(
                    in_library_rows_v2529, actor_name, row_title="내 라이브러리 출연작"
                )
            # R115: the prebuilt cards are consumed by this open, and a repeat open
            # of an already-prepared actor (session-ready hit) never rebuilt them,
            # so the click itself built ~21 cards (~0.5 s of dark screen on SHIELD).
            # Rebuild them off-thread once this page has settled.
            try:
                _rows_r115 = list(in_library_rows_v2529 or [])
                _name_r115 = actor_name
                if _rows_r115:
                    _t_r115 = threading.Timer(1.5, lambda: self._actor_profile_prebuild_lis_r101(_name_r115, _rows_r115))
                    _t_r115.daemon = True
                    _t_r115.start()
            except Exception:
                pass
            movie_items = in_library_items_v2529
            tv_items = []
            _in_library_count_v2529 = len(in_library_items_v2529)
            # Final geometry is fully known before ActorProfile.Active.  No second
            # rail and no post-commit vertical slide are part of the v2529 layout.
            _layout_mode_v2481 = "single" if _in_library_count_v2529 > 0 else "no_works"
            self._actor_profile_set_prop_v2454("LayoutMode", _layout_mode_v2481)
            _log("ACTOR_PROFILE_TARGET_GEOMETRY_READY_V2529 actor=%s mode=%s movies=%d tv=%d in_library=%d active=0 mixed_year_desc=1 second_rail=0" % (
                _short_log_value(actor_name,80), _layout_mode_v2481, _movie_count_v2529, _tv_count_v2529, _in_library_count_v2529
            ))
            _phase_bind_v2481 = time.time()
            try:
                in_library_ctrl_v2529 = self.getControl(6500)
                in_library_ctrl_v2529.reset()
                if in_library_items_v2529:
                    in_library_ctrl_v2529.addItems(in_library_items_v2529)
                    in_library_ctrl_v2529.selectItem(0)
                # Keep legacy control 6510 empty/inert for cumulative compatibility.
                try:
                    self.getControl(6510).reset()
                except Exception:
                    pass
            except Exception:
                _log("ACTOR_PROFILE_IN_LIBRARY_BIND_FAILED_V2529 actor=%s err=%s" % (
                    _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            _actor_works_ready_ms_v2610 = int((time.time()-_actor_open_started_v2481)*1000.0)
            _log("ACTOR_PROFILE_OPEN_TIMING_V2481 actor=%s phase=native_bind step_ms=%d elapsed_ms=%d" % (
                _short_log_value(actor_name,80), int((time.time()-_phase_bind_v2481)*1000.0),
                _actor_works_ready_ms_v2610
            ))
            _log("ACTOR_PROFILE_WORKS_READY_V2610 actor=%s works=%d movies=%d tv=%d ready_ms=%d" % (
                _short_log_value(actor_name,80), _in_library_count_v2529, _movie_count_v2529, _tv_count_v2529, _actor_works_ready_ms_v2610
            ))

            index = str(_actor_selected_index_v2524 or selected.getProperty("PlexKM.Cast.Index") or "").strip()
            # v2524: preserve the already-decoded local cast image on a cold page.
            # The old code overwrote it with OriginalThumb (remote URL), forcing a
            # redundant 270 ms download + 96 ms texture prime in the Brian Cox trace.
            fallback_thumb = str(
                _actor_selected_local_v2524
                or _actor_selected_thumb_v2524
                or _actor_selected_original_v2524
                or ""
            ).strip()
            if (not fallback_thumb or self._is_cast_placeholder_thumb(fallback_thumb)) and _actor_selected_original_v2524:
                fallback_thumb = str(_actor_selected_original_v2524).strip()
            primary_name = self._actor_master_name_ko_v2702(actor_name, profile.get("tmdb_id"))
            english_name = actor_name if primary_name != actor_name and re.search(r"[A-Za-z]", actor_name) else self._actor_profile_english_name_v2454(actor_name, profile)
            birthday_age_v2457 = self._actor_profile_prepare_birthday_age_v2711(actor_name, profile)
            birthday_text = self._actor_profile_birthday_text_v2454(profile.get("birthday"), profile.get("age"))
            _phase_thumb_v2481, actor_thumb_source_v2459, actor_thumb_v2459, born, department, meta_parts = self._actor_profile_open_from_cast_v2454_step4(_actor_selected_local_v2524, _actor_selected_visible_v2610, actor_name, birthday_text, fallback_thumb, prepared_v2467, profile)

            _actor_bg_v2455, biography_ko_v2459, profile = self._actor_profile_open_from_cast_v2454_step5(_actor_open_started_v2481, _phase_thumb_v2481, actor_name, actor_thumb_source_v2459, actor_thumb_v2459, birthday_age_v2457, department, english_name, fallback_thumb, meta_parts, primary_name, profile)
            self._actor_profile_set_prop_v2454("Born", born)
            self._actor_profile_set_prop_v2454("Age", profile.get("age") or "")
            self._actor_profile_set_prop_v2454("Aliases", profile.get("aliases") or "")
            self._actor_profile_set_prop_v2454("WorksTitle", "내 라이브러리 출연작")
            self._actor_profile_set_prop_v2454("WorksCount", str(_in_library_count_v2529))
            # R92: "1943.12.31 (82세)  ·  영국  ·  내 라이브러리 출연 7편"; unknown parts are omitted.
            self._actor_profile_publish_info_line_r92(profile, _in_library_count_v2529)
            # Keep legacy split-count properties accurate for diagnostics/cache compatibility,
            # but the v2529 UI no longer exposes separate movie/TV rails.
            self._actor_profile_set_prop_v2454("MovieWorksTitle", "")
            self._actor_profile_set_prop_v2454("MovieWorksCount", str(_movie_count_v2529))
            self._actor_profile_set_prop_v2454("TVWorksTitle", "")
            self._actor_profile_set_prop_v2454("TVWorksCount", str(_tv_count_v2529))
            self._actor_profile_set_prop_v2454("Source", profile.get("source") or "plex_local_fallback")
            self._actor_profile_set_prop_v2454("Loading", "")
            # v2467: persist the complete actor page BEFORE visibility.  This also
            # supports actors with no TMDb/profile image: profile may be partial,
            # but name + local works remain a complete reusable page.
            if not prepared_v2467:
                # v2526 cold fallback persistence was already queued immediately
                # after session readiness. Do not synchronously hash authority here.
                _log("ACTOR_PAGE_PREPARED_STORE_OFF_REVEAL_V2526 actor=%s action=background_or_media_ahead" % (
                    _short_log_value(actor_name,80)
                ))
            if int(getattr(self, "_actor_profile_open_seq_v2612", 0) or 0) != int(_actor_open_seq_v2612):
                _log("ACTOR_PROFILE_STALE_OPEN_ABORT_V2612 actor=%s open_seq=%d current_seq=%d elapsed_ms=%d action=no_publish" % (
                    _short_log_value(actor_name,80), int(_actor_open_seq_v2612),
                    int(getattr(self, "_actor_profile_open_seq_v2612", 0) or 0),
                    int((time.time()-_actor_open_started_v2481)*1000.0)
                ))
                return True
            # V2675 final atomic invariant: Info->Actor starts with the source
            # title as a mandatory seed, then merges local filmography. Therefore
            # zero works is never a valid Info-cast transition.
            if _in_library_count_v2529 <= 0:
                _log("ACTOR_PROFILE_PREENTRY_ABORT_V2675 actor=%s source=%s works=0 action=keep_parent_info" % (
                    _short_log_value(actor_name,80), current_rk or ""
                ), xbmc.LOGWARNING)
                return True
            actor_swap_token_v2479 = self._pkm_swap_settle_v2479(
                "info", "actor_profile", reason="actor_profile_complete:%s" % (reason or ""), wait_ms=16
            )
            _log("ACTOR_PROFILE_PREENTRY_READY_V2675 actor=%s source=%s works=%d action=atomic_publish" % (
                _short_log_value(actor_name,80), current_rk or "", _in_library_count_v2529
            ))
            self._actor_profile_active_v2454 = True
            self._actor_profile_set_prop_v2454("Active", "1")
            # v2522: take native focus in the same GUI callback that publishes
            # ActorProfile.Active, before yielding a render frame. The old helper
            # slept 16 ms first, so the page could paint with normal itemlayout and
            # then visibly resize/reposition when the first work received focus.
            focus_prepaint_v2522 = self._actor_profile_focus_first_work_v2456(
                movie_count=_in_library_count_v2529, tv_count=0,
                allow_wait=False, stage_v2522="before_swap_finish_v2529_single"
            )
            self._pkm_swap_finish_v2479(
                actor_swap_token_v2479, "info", "actor_profile", reason="actor_profile_active_commit:%s" % (reason or "")
            )
            # ACTOR_BIO_SCROLL_R13:
            # Start the 3-second hold from the ACTUAL visible swap commit, not
            # from the earlier hidden/active preparation phase.
            self._actor_profile_arm_bio_scroll_r12(actor_name, delay_ms=3000)
            if not focus_prepaint_v2522:
                self._actor_profile_focus_first_work_v2456(
                    movie_count=_in_library_count_v2529, tv_count=0,
                    allow_wait=True, stage_v2522="fallback_after_swap_finish_v2529_single"
                )
            _actor_visible_ms_v2600 = int((time.time()-_actor_open_started_v2481)*1000.0)
            _log("ACTOR_PROFILE_ATOMIC_VISIBLE_V2522 actor=%s mode=%s elapsed_ms=%d first_focus_prepaint=%d post_commit_motion_expected=%d final_geometry_before_active=1" % (
                _short_log_value(actor_name,80), _layout_mode_v2481, _actor_visible_ms_v2600,
                1 if focus_prepaint_v2522 else 0, 0 if focus_prepaint_v2522 else 1
            ))
            _log("ACTOR_PROFILE_ATOMIC_VISIBLE_V2600 actor=%s elapsed_ms=%d works=%d movies=%d tv=%d tmdb_before_visible=%d texture_prime_android_ms=0" % (
                _short_log_value(actor_name,80), _actor_visible_ms_v2600, _in_library_count_v2529,
                _movie_count_v2529, _tv_count_v2529,
                1 if (profile or {}).get("tmdb_id") and not bool((profile or {}).get("_v2599_provisional")) else 0
            ))
            self._actor_profile_open_from_cast_v2454_step6(_actor_open_seq_v2612, _actor_selected_visible_v2610, _actor_visible_ms_v2600, _actor_works_ready_ms_v2610, _in_library_count_v2529, actor_name, actor_thumb_source_v2459, actor_thumb_v2459, busy, current_rk, profile)

            _log(
                "ACTOR_PROFILE_OPEN_V2456 actor=%s tmdb=%s movies=%d tv=%d total=%d "
                "source_control=%d source_pos=%d parent_info=%s helper_source=%s "
                "bg=%s compact_profile=1 home_poster_geometry=1 no_work_limit=1"
                % (
                    _short_log_value(actor_name,80),
                    profile.get("tmdb_id") or "",
                    _movie_count_v2529,
                    _tv_count_v2529,
                    _in_library_count_v2529,
                    int(control_id),
                    pos,
                    current_rk or "",
                    profile.get("source") or "plex_local_fallback",
                    _actor_bg_v2455,
                )
            )
            _log(
                "ACTOR_PROFILE_LAYOUT_V2467 actor=%s portrait=240x360 "
                "portrait_source=%s portrait_policy=person_images_first "
                "portrait_side=left aspect=stretch_2x3 "
                "rounding=exact_home_widget_diffuse outline=0 separate_hero=0 "
                "bg=fanart_dynamic korean_bio_chars=%d birthday_age=%s "
                "works_label=내_라이브러리_출연작 mixed_movie_tv=1 order=year_desc single_rail=1 first_work_focus=1"
                % (
                    _short_log_value(actor_name,80),
                    actor_thumb_source_v2459,
                    len(biography_ko_v2459),
                    _short_log_value(birthday_age_v2457,60),
                )
            )
            _log("ACTOR_PROFILE_LAYOUT_V2529 actor=%s mode=%s movies=%d tv=%d in_library=%d single_rail=1 second_rail=0 focus_independent=1" % (
                _short_log_value(actor_name,80), _layout_mode_v2481, _movie_count_v2529, _tv_count_v2529, _in_library_count_v2529
            ))
            _log("ACTOR_PROFILE_LAYOUT_V2532 actor=%s portrait=320x480 top=90 bio=1340x325 birthday_bio_gap=24 rail_label=내_라이브러리 rail_top=660 bottom_clearance=30 superseded_by=v2537" % (_short_log_value(actor_name,80)))
            _log("ACTOR_PROFILE_LAYOUT_V2537 actor=%s portrait=320x480 top=90 radius_px=16 bio=1100x345 inner=1076x321 bio_bottom=570 portrait_bottom=570 rail_label=내_라이브러리 rail_top=660" % (_short_log_value(actor_name,80)))
            _log("ACTOR_PROFILE_PORTRAIT_SOURCE_V2544 actor=%s first_source=%s upgrade_pending=%d cached_global=%d" % (
                _short_log_value(actor_name,80), actor_thumb_source_v2459,
                1 if not str(profile.get("portrait_local_v2544") or "").strip() and not str(actor_thumb_source_v2459 or "").startswith("tmdb_alt_") else 0,
                1 if str(actor_thumb_source_v2459 or "").startswith("tmdb_alt_") else 0
            ))
            _log("ACTOR_PROFILE_PORTRAIT_SOURCE_V2539 actor=%s selection=%s source=%s local=%d parent_cast_reuse=%d" % (
                _short_log_value(actor_name,80), profile.get("portrait_selection_v2539") or "", actor_thumb_source_v2459,
                1 if actor_thumb_v2459 else 0,
                1 if str(actor_thumb_source_v2459 or "").startswith(("prepared_local_v2467", "cast_local_ready_v2526")) and profile.get("portrait_selection_v2539") == "cast_local_last_fallback" else 0
            ))
            _log("ACTOR_PROFILE_OPEN_TIMING_V2481 actor=%s phase=complete elapsed_ms=%d prepared=%d" % (
                _short_log_value(actor_name,80), int((time.time()-_actor_open_started_v2481)*1000.0), 1 if prepared_v2467 else 0
            ))
            return True
        finally:
            try:
                if str(getattr(self, "_actor_profile_foreground_actor_v2481", "") or "").casefold() == str(actor_name or "").casefold():
                    self._actor_profile_foreground_actor_v2481 = ""
            except Exception:
                pass
            try:
                if str(getattr(self, "_actor_profile_open_inflight_v2614", "") or "").casefold() == str(actor_name or "").casefold():
                    self._actor_profile_open_inflight_v2614 = ""
            except Exception:
                pass
            self._actor_profile_set_prop_v2454("TexturePreload", "")
            self._actor_profile_set_prop_v2454("Loading", "")
            if busy:
                try:
                    self._scene_busy_finish_v2482(busy, reason="actor_profile_ready_v2454")
                except Exception:
                    pass

    def _actor_profile_open_from_cast_v2454_step1(self, actor_name, now_ms, selected):
        """Step 1 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_CAST_LOCAL_CAPTURE_V2525, ACTOR_PROFILE_CAST_VISIBLE_CAPTURE_V2610."""
        self._actor_profile_open_inflight_v2614 = actor_name
        self._actor_profile_open_guard_ms_v2454 = now_ms
        _actor_open_seq_v2612 = int(getattr(self, "_actor_profile_open_seq_v2612", 0) or 0) + 1
        self._actor_profile_open_seq_v2612 = _actor_open_seq_v2612
        # v2524: capture the already-rendered cast portrait before any background
        # work.  Cold actor pages can use this immutable local file immediately
        # instead of downloading the same TMDb portrait again on the click path.
        _actor_selected_index_v2524 = str(selected.getProperty("PlexKM.Cast.Index") or "").strip()
        _actor_selected_thumb_v2524 = str(selected.getProperty("PlexKM.Cast.Thumb") or "").strip()
        _actor_selected_original_v2524 = ""
        if _actor_selected_index_v2524:
            try:
                _actor_selected_original_v2524 = str(
                    xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast%s.OriginalThumb" % _actor_selected_index_v2524) or ""
                ).strip()
            except Exception:
                _actor_selected_original_v2524 = ""
        _actor_selected_local_v2524 = ""
        _actor_selected_visible_v2610 = ""
        # v2525: the selected cast ListItem can lose the exact local cache path
        # even though the parent Info surface is already rendering that portrait.
        # Capture every GUI-thread-only local source before starting workers, with
        # the authoritative Info CastN.LocalThumb property first.
        try:
            _actor_local_candidates_v2525 = []
            if _actor_selected_index_v2524:
                _win_v2525 = xbmcgui.Window(10000)
                _actor_local_candidates_v2525.extend([
                    str(_win_v2525.getProperty("PlexKM.Info.Cast%s.LocalThumb" % _actor_selected_index_v2524) or "").strip(),
                    str(_win_v2525.getProperty("PlexKM.Info.DisplayCast%s.Thumb" % _actor_selected_index_v2524) or "").strip(),
                    str(_win_v2525.getProperty("PlexKM.Info.Cast%s.Thumb" % _actor_selected_index_v2524) or "").strip(),
                ])
            _actor_local_candidates_v2525.append(_actor_selected_thumb_v2524)
            try:
                _actor_local_candidates_v2525.append(str(selected.getArt("thumb") or "").strip())
            except Exception:
                pass
            if _actor_selected_original_v2524:
                _actor_local_candidates_v2525.append(_actor_selected_original_v2524)
            for _candidate_v2525 in _actor_local_candidates_v2525:
                _candidate_v2525 = str(_candidate_v2525 or "").strip()
                if not _candidate_v2525 or self._is_cast_placeholder_thumb(_candidate_v2525):
                    continue
                # v2610: the portrait that Kodi is ALREADY rendering in Info is a
                # valid first-frame source even when it is a remote URL.  Rejecting
                # http(s) here caused visible Info portraits (e.g. Plex/Daum Role
                # thumbs) to become placeholders on the Actor page.
                if not _actor_selected_visible_v2610:
                    _actor_selected_visible_v2610 = _candidate_v2525
                if _candidate_v2525.lower().startswith(("http://", "https://", "image://")):
                    continue
                try:
                    _translated_v2525 = xbmcvfs.translatePath(_candidate_v2525) if _candidate_v2525.lower().startswith("special://") else _candidate_v2525
                except Exception:
                    _translated_v2525 = _candidate_v2525
                if os.path.isfile(_translated_v2525) and os.path.getsize(_translated_v2525) > 1024:
                    _actor_selected_local_v2524 = _translated_v2525
                    _actor_selected_visible_v2610 = _translated_v2525
                    break
            _log("ACTOR_PROFILE_CAST_LOCAL_CAPTURE_V2525 actor=%s index=%s ready=%d file=%s" % (
                _short_log_value(actor_name,80), _actor_selected_index_v2524 or "",
                1 if _actor_selected_local_v2524 else 0,
                os.path.basename(_actor_selected_local_v2524) if _actor_selected_local_v2524 else ""
            ))
            _log("ACTOR_PROFILE_CAST_VISIBLE_CAPTURE_V2610 actor=%s index=%s available=%d local=%d remote=%d source=%s" % (
                _short_log_value(actor_name,80), _actor_selected_index_v2524 or "",
                1 if _actor_selected_visible_v2610 else 0, 1 if _actor_selected_local_v2524 else 0,
                1 if str(_actor_selected_visible_v2610 or "").lower().startswith(("http://", "https://", "image://")) else 0,
                _short_log_value(_actor_selected_visible_v2610,160)
            ))
        except Exception:
            _actor_selected_local_v2524 = ""
            _actor_selected_visible_v2610 = str(_actor_selected_thumb_v2524 or _actor_selected_original_v2524 or "").strip()
            if self._is_cast_placeholder_thumb(_actor_selected_visible_v2610):
                _actor_selected_visible_v2610 = ""
        return _actor_open_seq_v2612, _actor_selected_index_v2524, _actor_selected_local_v2524, _actor_selected_original_v2524, _actor_selected_thumb_v2524, _actor_selected_visible_v2610

    def _actor_profile_open_from_cast_v2454_step2(self, actor_name, control_id, now_ms, pos):
        """Step 2 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_FOREGROUND_STEAL_V2543, ACTOR_PROFILE_FOREGROUND_JOIN_PREWARM_V2523, ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2481, ACTOR_PROFILE_STALE_DIRECTION_CANCEL_V2543."""
        _actor_open_started_v2481 = time.time()
        self._actor_profile_foreground_actor_v2481 = actor_name

        # v2543: foreground click has priority over speculative direction prewarm.
        # If the same actor's direction worker is still only settling / doing local
        # rows, do not spend V2526's 1200 ms join budget waiting for it.  Cancel
        # that token, wake any waiter, and let this click execute the authoritative
        # cold path immediately.  Once Helper ownership has started we keep the
        # existing atomic transaction and join it; changing Helper language under
        # an active invocation would be unsafe.
        try:
            _v2543_pw_actor = str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip()
            _v2543_pw_reason = str(getattr(self, "_actor_profile_prewarm_reason_v2543", "") or "")
            _v2543_pw_helper_ms = int(getattr(self, "_actor_profile_prewarm_helper_started_ms_v2543", 0) or 0)
            _v2543_same = bool(
                getattr(self, "_actor_profile_prewarm_inflight_v2526", False)
                and _v2543_pw_actor
                and _v2543_pw_actor.casefold() == actor_name.casefold()
            )
            if _v2543_same and _v2543_pw_reason.startswith("cast_direction") and _v2543_pw_helper_ms <= 0:
                _v2543_old_token = int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0)
                self._actor_profile_prewarm_token_v2481 = _v2543_old_token + 1
                self._actor_profile_prewarm_inflight_v2526 = False
                self._actor_profile_prewarm_running_v2481 = False
                try:
                    _v2543_evt = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                    if _v2543_evt is not None and not _v2543_evt.is_set():
                        _v2543_evt.set()
                except Exception:
                    pass
                _log("ACTOR_PROFILE_FOREGROUND_STEAL_V2543 actor=%s old_token=%d reason=%s helper_started=0 action=cancel_speculative_no_join" % (
                    _short_log_value(actor_name,80), _v2543_old_token, _short_log_value(_v2543_pw_reason,120)
                ))
        except Exception:
            pass

        try:
            same_prewarm_v2523 = bool(
                getattr(self, "_actor_profile_prewarm_running_v2481", False)
                and str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold() == actor_name.casefold()
            )
            if same_prewarm_v2523:
                _log("ACTOR_PROFILE_FOREGROUND_JOIN_PREWARM_V2523 actor=%s token=%d action=share_helper_lock_no_duplicate_transaction" % (
                    _short_log_value(actor_name,80), int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0)
                ))
        except Exception:
            pass
        try:
            _prewarm_actor_v2481 = str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip()
            if _prewarm_actor_v2481 and _prewarm_actor_v2481.casefold() != actor_name.casefold():
                _v2543_cancel_reason = str(getattr(self, "_actor_profile_prewarm_reason_v2543", "") or "")
                _v2543_cancel_helper_ms = int(getattr(self, "_actor_profile_prewarm_helper_started_ms_v2543", 0) or 0)
                self._actor_profile_prewarm_token_v2481 = int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0) + 1
                if _v2543_cancel_reason.startswith("cast_direction") and _v2543_cancel_helper_ms <= 0:
                    self._actor_profile_prewarm_inflight_v2526 = False
                    self._actor_profile_prewarm_running_v2481 = False
                    try:
                        _v2543_cancel_evt = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                        if _v2543_cancel_evt is not None and not _v2543_cancel_evt.is_set():
                            _v2543_cancel_evt.set()
                    except Exception:
                        pass
                    _log("ACTOR_PROFILE_STALE_DIRECTION_CANCEL_V2543 actor=%s target=%s helper_started=0 action=release_without_lock_wait" % (
                        _short_log_value(_prewarm_actor_v2481,80), _short_log_value(actor_name,80)
                    ))
                elif _v2543_cancel_reason.startswith("cast_direction") and _v2543_cancel_helper_ms > 0:
                    _log("ACTOR_PROFILE_STALE_DIRECTION_LATE_V2543 actor=%s target=%s helper_started_ms=%d action=cooperative_abort_after_helper_call" % (
                        _short_log_value(_prewarm_actor_v2481,80), _short_log_value(actor_name,80), _v2543_cancel_helper_ms
                    ))
                _log("ACTOR_PROFILE_FOCUS_PREWARM_CANCEL_V2481 actor=%s reason=foreground_different target=%s" % (
                    _short_log_value(_prewarm_actor_v2481,80), _short_log_value(actor_name,80)
                ))
        except Exception:
            pass
        self._actor_profile_open_guard_ms_v2454 = now_ms
        self._actor_profile_return_control_v2454 = int(control_id or 0)
        self._actor_profile_return_pos_v2454 = pos
        self._actor_profile_return_name_v2454 = actor_name
        self._actor_profile_parent_origin_v2454 = (
            int(getattr(self, "_inline_info_origin_focus_id", 0) or 0),
            int(getattr(self, "_inline_info_origin_pos", -1) or -1),
            str(getattr(self, "_inline_info_origin_rating_key", "") or "")
        )
        self._actor_profile_set_prop_v2454("Loading", "1")
        # v2544: each actor page starts with one deterministic base portrait.
        # Any TMDb upgrade from an older actor must never bleed into this page.
        self._actor_profile_set_prop_v2454("UpgradeThumb", "")
        # R92: same rule for the new page fields - nothing from the previous actor.
        self._actor_profile_bg_blur_token_r92 = int(getattr(self, "_actor_profile_bg_blur_token_r92", 0) or 0) + 1
        self._actor_profile_bio_full_r92 = ""
        for _key_r92 in ("BgBlur", "InfoLine", "BiographyPreview", "BiographyMore", "BiographyFull", "BioPopup"):
            self._actor_profile_set_prop_v2454(_key_r92, "")
        return _actor_open_started_v2481

    def _actor_profile_open_from_cast_v2454_step3(self, _actor_open_started_v2481, actor_name, current_rk):
        """Step 3 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_PREENTRY_SPINNER_V2674, ACTOR_PROFILE_PREENTRY_SPINNER_PAINT_V2674, ACTOR_PROFILE_MANDATORY_WORKS_JOIN_V2672, ACTOR_PROFILE_MANDATORY_WORKS_JOIN_FAILED_V2672."""
        prepared_v2467 = self._actor_page_session_ready_get_v2526(actor_name, current_rk)
        # V2674: strict PRE-ENTRY spinner contract. ActorProfile itself must not
        # become visible while mandatory works are unresolved. Keep the complete
        # parent Info surface active, paint the busy spinner on that surface, then
        # publish ActorProfile.Active only after works >= 1 has been bound.
        try:
            self._actor_profile_active_v2454 = False
            self._actor_profile_set_prop_v2454("Active", "")
        except Exception:
            pass
        busy = ""
        try:
            _prepared_has_works_v2673 = bool(
                prepared_v2467 and (list(prepared_v2467.get("movie") or []) or list(prepared_v2467.get("show") or []))
            )
            if not _prepared_has_works_v2673:
                busy = self._scene_busy_arm_v2482(
                    reason="actor_mandatory_works_v2673:%s" % actor_name,
                    scope="actor", owner=actor_name, replace_scope=True, threshold_ms=0
                )
                _log("ACTOR_PROFILE_PREENTRY_SPINNER_V2674 actor=%s source=%s immediate=1 parent_info_hold=1 actor_active=0" % (
                    _short_log_value(actor_name,80), current_rk or ""
                ))
                # The mandatory rows wait below runs on the Python GUI callback.
                # Give Kodi's renderer a short paint opportunity after synchronous
                # busy promotion so the spinner is visibly ON *before* the wait.
                # This is presentation-only; ActorProfile.Active remains false.
                xbmc.sleep(45)
                _log("ACTOR_PROFILE_PREENTRY_SPINNER_PAINT_V2674 actor=%s hold_ms=45 actor_active=0" % (
                    _short_log_value(actor_name,80)
                ))
        except Exception:
            busy = ""
        # V2672: a provisional session with zero works is not a complete actor page.
        # The cast-focus worker may already be resolving the mandatory local rail;
        # join that SAME worker briefly instead of publishing a permanent no_works
        # page and launching a duplicate SQL scan. This is only used for the exact
        # actor/source pair and never adds Python navigation movement.
        try:
            _prepared_zero_v2672 = bool(
                prepared_v2467
                and not list(prepared_v2467.get("movie") or [])
                and not list(prepared_v2467.get("show") or [])
            )
            _same_rows_inflight_v2672 = bool(
                _prepared_zero_v2672
                and getattr(self, "_actor_profile_prewarm_inflight_v2526", False)
                and str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold() == actor_name.casefold()
                and str(getattr(self, "_actor_profile_prewarm_source_rk_v2481", "") or "").strip() == current_rk
            )
            if _same_rows_inflight_v2672:
                _evt_rows_v2672 = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                _join_t0_v2672 = time.time()
                if _evt_rows_v2672 is not None:
                    _evt_rows_v2672.wait(1.8 if self._uhd_kpi_proxy_v2605() else (0.15 if xbmc.getCondVisibility("System.Platform.Android") else 0.8))
                _join_ms_v2672 = int((time.time() - _join_t0_v2672) * 1000.0)
                _joined_v2672 = self._actor_page_session_ready_get_v2526(actor_name, current_rk)
                if _joined_v2672 and (list(_joined_v2672.get("movie") or []) or list(_joined_v2672.get("show") or [])):
                    prepared_v2467 = _joined_v2672
                _joined_has_works_v2673 = bool(prepared_v2467 and (list(prepared_v2467.get("movie") or []) or list(prepared_v2467.get("show") or [])))
                _log("ACTOR_PROFILE_MANDATORY_WORKS_JOIN_V2672 actor=%s source=%s wait_ms=%d works=%d hit=%d duplicate_sql=0" % (
                    _short_log_value(actor_name,80), current_rk or "", _join_ms_v2672,
                    len(list((prepared_v2467 or {}).get("movie") or [])) + len(list((prepared_v2467 or {}).get("show") or [])),
                    1 if _joined_has_works_v2673 else 0
                ))
                if not _joined_has_works_v2673:
                    prepared_v2467 = None
                    _log("ACTOR_PROFILE_ZERO_SESSION_REJECT_V2673 actor=%s source=%s action=cold_mandatory_gate" % (
                        _short_log_value(actor_name,80), current_rk or ""
                    ))
        except Exception:
            _log("ACTOR_PROFILE_MANDATORY_WORKS_JOIN_FAILED_V2672 actor=%s err=%s" % (
                _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        if not prepared_v2467:
            _log("ACTOR_PROFILE_PERSISTENT_AUTHORITY_BYPASS_V2614 actor=%s source=%s all_platforms=1 previsible_full_authority_scan=0" % (
                _short_log_value(actor_name,80), current_rk or ""
            ))

        # v2527: decide and arm actor feedback BEFORE any V2526 media-ahead join.
        # The prior order could block here for up to 1200 ms, then wait another
        # 500 ms scene threshold, so a cold actor click had no visible feedback
        # for roughly 0.5-1.7 s even though the source Info was intentionally held.
        # A true profile-cache miss is already known to require external Helper
        # work, so use the existing threshold=0 synchronous broker path. Prepared
        # or local-profile paths retain the anti-flash 500 ms grace period.
        profile_cache_hint_v2485 = None
        cold_network_expected_v2485 = False
        if not prepared_v2467:
            try:
                profile_cache_hint_v2485 = self._actor_profile_cache_get_v2454(actor_name)
            except Exception:
                profile_cache_hint_v2485 = None
            cold_network_expected_v2485 = not bool(profile_cache_hint_v2485)
        actor_spinner_threshold_v2527 = (350 if self._uhd_kpi_proxy_v2605() else 0) if cold_network_expected_v2485 else 500
        _log("ACTOR_PROFILE_BUSY_POLICY_V2527 actor=%s prepared=%d profile_cached=%d cold_network_expected=%d threshold_ms=%d arm_before_join=1 sync_cold=%d source_hold=1 incomplete_reveal=0 media_ahead=1" % (
            _short_log_value(actor_name,80), 1 if prepared_v2467 else 0,
            1 if profile_cache_hint_v2485 else 0, 1 if cold_network_expected_v2485 else 0,
            actor_spinner_threshold_v2527, 1 if actor_spinner_threshold_v2527 == 0 else 0
        ))
        # V2673: the actor surface is different from ordinary navigation: the
        # mandatory work rail must exist before reveal.  Preserve the immediate
        # spinner armed above for cold/zero-work sessions; warm prepared pages
        # still enter with no spinner.
        _log("ACTOR_PROFILE_BUSY_SUPPRESS_V2614 actor=%s prepared=%d profile_cached=%d cold=%d global_busy=%d spinner=%d action_block=0 source_hold=1 all_platforms=1" % (
            _short_log_value(actor_name,80), 1 if prepared_v2467 else 0,
            1 if profile_cache_hint_v2485 else 0, 1 if cold_network_expected_v2485 else 0,
            1 if busy else 0, 1 if busy else 0
        ))

        # v2526: Home media-ahead prewarm normally makes this a zero-wait memory
        # hit. If the external Helper is only a few frames from completion, hold
        # the parent Info (never reveal an incomplete ActorProfile) and join the
        # already-running worker for a short final window. v2527 has already armed
        # cold feedback above, so this wait can no longer create a silent click.
        if not prepared_v2467:
            try:
                same_ahead_v2526 = bool(
                    getattr(self, "_actor_profile_prewarm_inflight_v2526", False)
                    and str(getattr(self, "_actor_profile_prewarm_actor_v2481", "") or "").strip().casefold() == actor_name.casefold()
                    and str(getattr(self, "_actor_profile_prewarm_source_rk_v2481", "") or "").strip() == current_rk
                )
                if same_ahead_v2526:
                    ahead_age_v2526 = max(0, self._now_ms() - int(getattr(self, "_actor_profile_prewarm_started_ms_v2526", 0) or 0))
                    evt_v2526 = getattr(self, "_actor_profile_prewarm_ready_event_v2526", None)
                    # Media-ahead should normally be several seconds old by actor
                    # click. A 1200ms ceiling catches the tail without recreating
                    # V2524's half-page morph.
                    wait_budget_v2526 = 0
                    wait_t0_v2526 = time.time()
                    if evt_v2526 is not None:
                        evt_v2526.wait(wait_budget_v2526 / 1000.0)
                    wait_ms_v2526 = int((time.time()-wait_t0_v2526)*1000.0)
                    prepared_v2467 = self._actor_page_session_ready_get_v2526(actor_name, current_rk)
                    _log("ACTOR_PROFILE_MEDIA_AHEAD_JOIN_V2526 actor=%s source=%s prewarm_age_ms=%d wait_ms=%d hit=%d incomplete_reveal=0" % (
                        _short_log_value(actor_name,80), current_rk or "", ahead_age_v2526, wait_ms_v2526, 1 if prepared_v2467 else 0
                    ))
            except Exception:
                pass
        _log("ACTOR_PROFILE_OPEN_TIMING_V2481 actor=%s phase=prepared_lookup elapsed_ms=%d hit=%d" % (
            _short_log_value(actor_name,80), int((time.time()-_actor_open_started_v2481)*1000.0), 1 if prepared_v2467 else 0
        ))
        if prepared_v2467:
            _log("ACTOR_PROFILE_PREPARED_FAST_PATH_V2504 actor=%s spinner_threshold_ms=500 prepared=1 portrait_prime_ms=96 page_visible_after_bind=1" % _short_log_value(actor_name,80))
        return busy, prepared_v2467

    def _actor_profile_open_from_cast_v2454_step4(self, _actor_selected_local_v2524, _actor_selected_visible_v2610, actor_name, birthday_text, fallback_thumb, prepared_v2467, profile):
        """Step 4 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_INFO_CAST_HANDOFF_V2610, ACTOR_PROFILE_PORTRAIT_FIRST_V2544, ACTOR_PROFILE_PORTRAIT_LOCAL_GATE_V2485, ACTOR_PROFILE_BIO_OVERRIDE_V2703."""
        born = str(profile.get("born") or "").strip()
        meta_parts = [x for x in (birthday_text, born) if x]
        department = self._actor_profile_department_ko_v2454(profile.get("department"))
        _phase_thumb_v2481 = time.time()
        # v2610 portrait order:
        #   1) globally cached local TMDb alternative from any previous movie
        #   2) already-rendered local Info cast portrait
        #   3) the exact remote Info cast URL already visible/decoded by Kodi
        #   4) placeholder only when Info itself has no usable portrait
        # No NEW remote fetch is waited on before ActorProfile reveal.
        actor_thumb_v2459 = ""
        actor_thumb_source_v2459 = "placeholder_v2544"
        # V2670 visual contract: the first ActorProfile frame always inherits the exact
        # portrait already visible on the parent Info page. TMDb portrait is an upgrade,
        # never a prerequisite for page reveal.
        info_first_v2670 = str(_actor_selected_local_v2524 or _actor_selected_visible_v2610 or fallback_thumb or "").strip()
        if info_first_v2670 and not self._is_cast_placeholder_thumb(info_first_v2670):
            actor_thumb_v2459 = info_first_v2670
            actor_thumb_source_v2459 = (
                "info_cast_remote_v2670" if info_first_v2670.lower().startswith(("http://", "https://", "image://"))
                else "info_cast_first_v2670"
            )
        global_profile_v2544 = self._actor_profile_cache_get_v2454(actor_name) or {}
        cached_alt_local_v2544 = str(
            global_profile_v2544.get("portrait_local_v2544")
            or profile.get("portrait_local_v2544")
            or ""
        ).strip()
        try:
            if (not actor_thumb_v2459) and cached_alt_local_v2544 and not cached_alt_local_v2544.lower().startswith(("http://", "https://", "image://")):
                cached_alt_local_v2544 = xbmcvfs.translatePath(cached_alt_local_v2544) if cached_alt_local_v2544.lower().startswith("special://") else cached_alt_local_v2544
                if os.path.isfile(cached_alt_local_v2544) and os.path.getsize(cached_alt_local_v2544) > 1024:
                    actor_thumb_v2459 = cached_alt_local_v2544
                    actor_thumb_source_v2459 = "tmdb_alt_global_cache_v2544"
                    for k_v2544 in ("thumbnail", "portrait_local_v2544", "portrait_selection_v2539", "portrait_policy_version_v2539", "portrait_image_count_v2544", "portrait_upgrade_source_v2544"):
                        if global_profile_v2544.get(k_v2544):
                            profile[k_v2544] = global_profile_v2544.get(k_v2544)
        except Exception:
            actor_thumb_v2459 = ""

        # Compatibility: a V2539/V2542 prepared record may already contain the
        # selected TMDb alternate even before portrait_local_v2544 existed.
        if not actor_thumb_v2459 and prepared_v2467:
            legacy_local_v2544 = str(prepared_v2467.get("local_thumb") or "").strip()
            legacy_sel_v2544 = str(profile.get("portrait_selection_v2539") or "")
            try:
                if legacy_sel_v2544 in ("third_overall_preferred", "second_overall_fallback") and legacy_local_v2544:
                    legacy_local_v2544 = xbmcvfs.translatePath(legacy_local_v2544) if legacy_local_v2544.lower().startswith("special://") else legacy_local_v2544
                    if os.path.isfile(legacy_local_v2544) and os.path.getsize(legacy_local_v2544) > 1024:
                        actor_thumb_v2459 = legacy_local_v2544
                        actor_thumb_source_v2459 = "tmdb_alt_legacy_prepared_v2544"
            except Exception:
                pass

        if not actor_thumb_v2459:
            info_local_v2544 = str(_actor_selected_local_v2524 or "").strip()
            try:
                if info_local_v2544 and os.path.isfile(info_local_v2544) and os.path.getsize(info_local_v2544) > 1024:
                    actor_thumb_v2459 = info_local_v2544
                    actor_thumb_source_v2459 = "info_cast_first_v2544"
            except Exception:
                actor_thumb_v2459 = ""

        # v2610: if Info is already rendering a valid remote Role portrait,
        # hand that exact URL to ActorProfile instead of regressing to a
        # placeholder. Kodi normally already owns/decodes the same texture, so
        # this adds no pre-visible network wait and preserves the visual handoff.
        if not actor_thumb_v2459:
            info_visible_v2610 = str(_actor_selected_visible_v2610 or fallback_thumb or "").strip()
            if info_visible_v2610 and not self._is_cast_placeholder_thumb(info_visible_v2610):
                actor_thumb_v2459 = info_visible_v2610
                actor_thumb_source_v2459 = (
                    "info_cast_remote_v2610"
                    if info_visible_v2610.lower().startswith(("http://", "https://", "image://"))
                    else "info_cast_visible_v2610"
                )
                _log("ACTOR_PROFILE_INFO_CAST_HANDOFF_V2610 actor=%s source=%s remote=%d placeholder=0" % (
                    _short_log_value(actor_name,80), actor_thumb_source_v2459,
                    1 if actor_thumb_source_v2459 == "info_cast_remote_v2610" else 0
                ))

        if actor_thumb_v2459:
            _log("ACTOR_PROFILE_PORTRAIT_FIRST_V2544 actor=%s source=%s cached_tmdb=%d info_cast=%d remote_wait=0" % (
                _short_log_value(actor_name,80), actor_thumb_source_v2459,
                1 if actor_thumb_source_v2459.startswith("tmdb_alt_") else 0,
                1 if actor_thumb_source_v2459.startswith("info_cast_") else 0
            ))
            _log("ACTOR_PROFILE_PORTRAIT_LOCAL_GATE_V2485 actor=%s ready=1 remote_visible=%d source=%s" % (
                _short_log_value(actor_name,80),
                1 if str(actor_thumb_v2459 or "").lower().startswith(("http://", "https://", "image://")) else 0,
                actor_thumb_source_v2459
            ))
        else:
            _log("ACTOR_PROFILE_PORTRAIT_FIRST_V2544 actor=%s source=placeholder cached_tmdb=0 info_cast=0 remote_wait=0" % (
                _short_log_value(actor_name,80)
            ))
        # V2703: prove the full local Actor Master DB -> PKM UI biography path.
        # Local Korean biography is authoritative when present, including over
        # an already-cached English TMDb Helper fallback from an earlier run.
        _actor_master_profile_v2703 = self._actor_master_profile_ko_v2703(
            actor_name, profile.get("tmdb_id")
        )
        _actor_master_bio_v2703 = str(
            (_actor_master_profile_v2703 or {}).get("biography_ko") or ""
        ).strip()
        if _actor_master_bio_v2703:
            _previous_bio_source_v2703 = str(profile.get("biography_source") or "missing")
            profile["biography"] = _actor_master_bio_v2703
            profile["biography_source"] = "actor_master_local_db_v2703"
            if (_actor_master_profile_v2703 or {}).get("tmdb_id") and not profile.get("tmdb_id"):
                profile["tmdb_id"] = (_actor_master_profile_v2703 or {}).get("tmdb_id")
            _log("ACTOR_PROFILE_BIO_OVERRIDE_V2703 actor=%s tmdb=%s from=%s to=actor_master_local_db_v2703 chars=%d" % (
                _short_log_value(actor_name,80), str(profile.get("tmdb_id") or ""),
                _previous_bio_source_v2703, len(_actor_master_bio_v2703)
            ))
        else:
            _log("ACTOR_PROFILE_BIO_LOCAL_DB_MISS_V2703 actor=%s tmdb=%s keep_source=%s chars=%d" % (
                _short_log_value(actor_name,80), str(profile.get("tmdb_id") or ""),
                str(profile.get("biography_source") or "missing"),
                len(str(profile.get("biography") or ""))
            ))
        return _phase_thumb_v2481, actor_thumb_source_v2459, actor_thumb_v2459, born, department, meta_parts

    def _actor_profile_open_from_cast_v2454_step5(self, _actor_open_started_v2481, _phase_thumb_v2481, actor_name, actor_thumb_source_v2459, actor_thumb_v2459, birthday_age_v2457, department, english_name, fallback_thumb, meta_parts, primary_name, profile):
        """Step 5 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_BIO_READY_V2553, ACTOR_PROFILE_OPEN_TIMING_V2481, ACTOR_PROFILE_BIO_UI_COMMIT_V2703, ACTOR_PROFILE_TEXTURE_PRIME_V2485."""
        try:
            profile = self._actor_wiki_bio_apply_r68(actor_name, profile)
        except Exception:
            pass
        biography_ko_v2459 = self._actor_profile_korean_biography_v2459(
            profile.get("biography")
        )
        biography_full_v2488, biography_language_v2488 = self._actor_profile_biography_display_v2488(profile)
        # ACTOR_PROFILE_COMPACT_LAYOUT_R16:
        # Common ActorProfile policy: first page is ALWAYS 4 lines.
        # Width follows the compact 720px biography card; full Biography is untouched.
        biography_display_v2488 = self._actor_profile_biography_boxfit_v2504(
            biography_full_v2488, inner_width_px=696, inner_height_px=144
        )
        _log("ACTOR_PROFILE_BIO_READY_V2553 actor=%s source=%s language=%s full_chars=%d display_chars=%d box=720x270 preview_inner=696x144 preview_lines=4 scroll_inner=696x246 fixed_char_limit=0 korean_first=1" % (
            _short_log_value(actor_name,80), profile.get("biography_source") or "missing",
            biography_language_v2488, len(biography_full_v2488), len(biography_display_v2488)
        ))
        _log("ACTOR_PROFILE_OPEN_TIMING_V2481 actor=%s phase=portrait_ready step_ms=%d elapsed_ms=%d source=%s" % (
            _short_log_value(actor_name,80), int((time.time()-_phase_thumb_v2481)*1000.0),
            int((time.time()-_actor_open_started_v2481)*1000.0), actor_thumb_source_v2459
        ))
        try:
            _actor_bg_v2455 = str(
                xbmcgui.Window(10000).getProperty("PlexKM.Info.DynamicBgColor")
                or self.getProperty("PlexKM.Info.DynamicBgColor")
                or xbmcgui.Window(10000).getProperty("PlexKM.Home.DynamicBgColor")
                or self.getProperty("PlexKM.Home.DynamicBgColor")
                or "FF222324"
            ).strip()
        except Exception:
            _actor_bg_v2455 = "FF222324"
        self._actor_profile_set_prop_v2454("BgColor", _actor_bg_v2455)
        self._actor_profile_set_prop_v2454("Name", primary_name)
        self._actor_profile_set_prop_v2454("EnglishName", english_name)
        self._actor_profile_set_prop_v2454("Department", department)
        self._actor_profile_set_prop_v2454("MetaLine", "  |  ".join(meta_parts))
        self._actor_profile_set_prop_v2454(
            "Biography",
            profile.get("biography") or "한국어/기본 언어 배우 소개 정보가 없습니다."
        )
        self._actor_profile_set_prop_v2454("BiographyKo", biography_ko_v2459)
        self._actor_profile_set_prop_v2454("BiographyDisplay", biography_display_v2488)
        self._actor_profile_set_prop_v2454("BiographyViewport", biography_display_v2488)
        self._actor_profile_publish_bio_preview_r92(biography_full_v2488)
        self._actor_profile_set_prop_v2454("BiographyLanguage", biography_language_v2488)
        self._actor_profile_set_prop_v2454(
            "BiographySource", profile.get("biography_source") or "missing"
        )
        _log("ACTOR_PROFILE_BIO_UI_COMMIT_V2703 actor=%s tmdb=%s source=%s language=%s full_chars=%d display_chars=%d hangul=%d" % (
            _short_log_value(actor_name,80), str(profile.get("tmdb_id") or ""),
            str(profile.get("biography_source") or "missing"), biography_language_v2488,
            len(str(profile.get("biography") or "")), len(str(biography_display_v2488 or "")),
            1 if re.search(r"[가-힣]", str(biography_display_v2488 or "")) else 0
        ))
        try:
            self._actor_wiki_bio_schedule_r68(actor_name, profile, reason="page_open")
        except Exception:
            pass
        self._actor_profile_set_prop_v2454("Thumb", actor_thumb_v2459)
        # R92: actor-owned background (cache hit is published before Active).
        try:
            self._actor_profile_bg_blur_schedule_r92(actor_name, actor_thumb_v2459, _actor_bg_v2455)
        except Exception:
            pass
        # v2485: force Kodi to decode the local actor portrait while the opaque
        # parent Info surface is still the visible A/B source.  XML control 6479
        # is rendered underneath the Info overlay with background=false, so the
        # actual Actor portrait reuses an already-decoded texture on commit.
        # Filmography ListItems were bound above, therefore the first Actor frame
        # contains portrait + work rails together instead of a late portrait pop-in.
        if actor_thumb_v2459:
            try:
                # If ActorProfile reuses the exact local portrait already visible
                # in the parent cast rail, Kodi has decoded it already. A fixed
                # 96 ms off-screen prime adds latency without changing first paint.
                same_cast_local_v2522 = False
                try:
                    if fallback_thumb and actor_thumb_v2459:
                        if str(actor_thumb_v2459).lower().startswith(("http://", "https://", "image://")):
                            same_cast_local_v2522 = str(actor_thumb_v2459).strip() == str(fallback_thumb).strip()
                        else:
                            same_cast_local_v2522 = (
                                os.path.normcase(os.path.abspath(str(actor_thumb_v2459)))
                                == os.path.normcase(os.path.abspath(str(fallback_thumb)))
                            )
                except Exception:
                    same_cast_local_v2522 = False
                # V2632: a local portrait path is already final before Active. Do not
                # hold ActorProfile visibility for a synthetic texture-prime sleep; Kodi
                # owns decode/paint. This removes a fixed 96 ms from cold actor opens.
                prime_wait_v2522 = 0
                if prime_wait_v2522:
                    self._actor_profile_set_prop_v2454("TexturePreload", "1")
                prime_started_v2485 = time.time()
                if prime_wait_v2522:
                    xbmc.sleep(prime_wait_v2522)
                self._actor_profile_set_prop_v2454("TexturePreload", "")
                _log("ACTOR_PROFILE_TEXTURE_PRIME_V2522 actor=%s wait_ms=%d target_ms=%d local=1 same_cast_decoded=%d source_held=1 before_active=1" % (
                    _short_log_value(actor_name,80), int((time.time()-prime_started_v2485)*1000.0),
                    prime_wait_v2522, 1 if same_cast_local_v2522 else 0
                ))
            except Exception:
                self._actor_profile_set_prop_v2454("TexturePreload", "")
        else:
            self._actor_profile_set_prop_v2454("TexturePreload", "")
            _log("ACTOR_PROFILE_TEXTURE_PRIME_V2485 actor=%s wait_ms=0 local=0 placeholder_atomic=1 before_active=1" % (
                _short_log_value(actor_name,80)
            ))
        self._actor_profile_set_prop_v2454("HeroThumb", "")
        self._actor_profile_set_prop_v2454(
            "ThumbHighQuality", "1" if actor_thumb_v2459 else "0"
        )
        self._actor_profile_set_prop_v2454("TMDbId", profile.get("tmdb_id") or "")
        self._actor_profile_set_prop_v2454("Birthday", profile.get("birthday") or "")
        self._actor_profile_set_prop_v2454("BirthdayAge", birthday_age_v2457)
        return _actor_bg_v2455, biography_ko_v2459, profile

    def _actor_profile_open_from_cast_v2454_step6(self, _actor_open_seq_v2612, _actor_selected_visible_v2610, _actor_visible_ms_v2600, _actor_works_ready_ms_v2610, _in_library_count_v2529, actor_name, actor_thumb_source_v2459, actor_thumb_v2459, busy, current_rk, profile):
        """Step 6 of _actor_profile_open_from_cast_v2454 (R76 split, moved verbatim). Logs: ACTOR_PROFILE_KPI_V2610, ACTOR_VISIBLE, ACTOR_PROFILE_LATE_ENRICH_ARM_V2611, ACTOR_PROFILE_PORTRAIT_UPGRADE_WAIT_TMDB_V2670."""
        try:
            _kpi_win_v2604 = xbmcgui.Window(10000)
            _actor_info_cast_available_v2610 = bool(
                str(_actor_selected_visible_v2610 or "").strip()
                and not self._is_cast_placeholder_thumb(str(_actor_selected_visible_v2610 or "").strip())
            )
            _actor_placeholder_visible_v2610 = 1 if (
                not str(actor_thumb_v2459 or "").strip()
                or self._is_cast_placeholder_thumb(str(actor_thumb_v2459 or "").strip())
                or str(actor_thumb_source_v2459 or "").startswith("placeholder")
            ) else 0
            _actor_portrait_violation_v2610 = 1 if (_actor_info_cast_available_v2610 and _actor_placeholder_visible_v2610) else 0
            _actor_complete_ms_v2610 = max(int(_actor_visible_ms_v2600), int(_actor_works_ready_ms_v2610 or 0))
            self._actor_profile_visible_epoch_ms_v2610 = self._now_ms()
            self._actor_profile_visible_name_v2610 = actor_name
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorName", actor_name)
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorVisibleMs", str(int(_actor_visible_ms_v2600)))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorCompleteMs", str(int(_actor_complete_ms_v2610)))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorWorksReadyMs", str(int(_actor_works_ready_ms_v2610 or 0)))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorWorks", str(int(_in_library_count_v2529)))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorBusyUsed", "1" if bool(busy) else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorProxy", "1" if self._uhd_kpi_proxy_v2605() else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorFirstPortraitSource", str(actor_thumb_source_v2459 or "placeholder"))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorInfoCastAvailable", "1" if _actor_info_cast_available_v2610 else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorPlaceholderAtVisible", str(_actor_placeholder_visible_v2610))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorPortraitViolation", str(_actor_portrait_violation_v2610))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorPrevisibleNet", "0")
            _meta_ready_v2611 = self._actor_profile_metadata_ready_v2611(profile)
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorMetaStatus", "ready_on_visible" if _meta_ready_v2611 else "pending")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorMetaReadyMs", str(int(_actor_visible_ms_v2600)) if _meta_ready_v2611 else "")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorMetaTmdb", "1" if str(profile.get("tmdb_id") or "").strip() else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorMetaHasBio", "1" if str(profile.get("biography") or "").strip() else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorMetaHasBirthday", "1" if str(profile.get("birthday") or "").strip() else "0")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorUpgradeStatus",
                "cached" if str(actor_thumb_source_v2459 or "").startswith("tmdb_alt_") else ("pending" if str(profile.get("tmdb_id") or "").strip() or self._actor_profile_metadata_needs_enrich_v2611(profile) else "not_applicable"))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorUpgradeMs", "")
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorOpenSeq", str(int(_actor_open_seq_v2612)))
            _kpi_win_v2604.setProperty("PlexKM.KPI.ActorStamp", str(self._now_ms()))
            _log("ACTOR_PROFILE_KPI_V2610 actor=%s visible_ms=%d complete_ms=%d works_ready_ms=%d works=%d first_portrait=%s info_cast_available=%d placeholder_at_visible=%d portrait_violation=%d busy=%d previsible_net=0 proxy=%d" % (
                _short_log_value(actor_name,80), int(_actor_visible_ms_v2600), int(_actor_complete_ms_v2610), int(_actor_works_ready_ms_v2610 or 0),
                int(_in_library_count_v2529), actor_thumb_source_v2459 or "placeholder", 1 if _actor_info_cast_available_v2610 else 0,
                _actor_placeholder_visible_v2610, _actor_portrait_violation_v2610, 1 if bool(busy) else 0, 1 if self._uhd_kpi_proxy_v2605() else 0
            ))
        except Exception:
            pass
        try:
            pkm_uhd_diag_v2600.event(
                "ACTOR_VISIBLE", extra="actor=%s visible_ms=%d works=%d tmdb_before=%d" % (
                    _short_log_value(actor_name,60), _actor_visible_ms_v2600, _in_library_count_v2529,
                    1 if (profile or {}).get("tmdb_id") and not bool((profile or {}).get("_v2599_provisional")) else 0
                )
            )
        except Exception:
            pass
        if self._actor_profile_metadata_needs_enrich_v2611(profile):
            try:
                # Keep TMDb completely off the Actor first-visible path, then
                # start it soon after the page is visible and input is quiet.
                # The worker has an additional navigation-hot idle gate, so this
                # does not steal the U+ remote-control foreground.
                _late_delay_v2611 = 1800 if self._uhd_kpi_proxy_v2605() else 0
                self._schedule_actor_profile_item_prewarm_v2481(
                    actor_name, source_rk=current_rk, fallback_thumb=actor_thumb_v2459,
                    reason="actor_visible_enrich_v2611", settle_ms_v2526=_late_delay_v2611
                )
                _log("ACTOR_PROFILE_LATE_ENRICH_ARM_V2611 actor=%s delay_ms=%d visible_already=1 android_idle_gate=%d previsible_tmdb=0" % (
                    _short_log_value(actor_name,80), _late_delay_v2611, 1 if self._is_android_v2591() else 0
                ))
            except Exception:
                pass
        else:
            self._actor_profile_publish_meta_kpi_v2611(
                actor_name, "ready_on_visible", source=profile.get("source") or "prepared", profile=profile
            )

        # V2670: the actor page first inherits the parent Info portrait. TMDb
        # portrait work is strictly post-visible and idle; biography/profile data
        # may also arrive later without delaying the mandatory work rail.
        try:
            if str(profile.get("tmdb_id") or "").strip():
                self._actor_profile_schedule_portrait_upgrade_idle_v2610(
                    actor_name, profile,
                    delay_ms=180 if self._uhd_kpi_proxy_v2605() else 0,
                    reason="actor_visible_v2670"
                )
            else:
                _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_WAIT_TMDB_V2670 actor=%s reason=profile_id_pending info_cast_kept=1" % (
                    _short_log_value(actor_name,80)
                ))
        except Exception:
            _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_SCHEDULE_FAILED_V2670 actor=%s err=%s" % (
                _short_log_value(actor_name,80), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _actor_profile_close_to_parent_info_v2454(self, reason="back"):
        if not self._actor_profile_is_active_v2454():
            return False
        self._actor_profile_close_bio_popup_r93(restore_focus=False)  # R93
        control_id = int(getattr(self, "_actor_profile_return_control_v2454", 0) or 0)
        pos = int(getattr(self, "_actor_profile_return_pos_v2454", -1) or -1)
        actor_name = str(getattr(self, "_actor_profile_return_name_v2454", "") or "")

        # v2538: restore the preserved parent cast owner BEFORE ActorProfile is
        # retired.  The old order exposed Info first while Kodi still owned 6500;
        # Kodi could briefly choose a lower Info row, start the 420 ms v2079 body
        # animation, and only then receive the intended 6100/6110 cast focus.
        # That was visible as the parent page moving from below to above on Back.
        #
        # Movie cast 6100 is the native/base Y position, so hidden pre-focus is
        # enough. TV cast 6110 owns the -500 focus step; reuse the existing v2310
        # static+prime compensation while ActorProfile still covers the parent.
        # Cleanup happens after the native focus animation state has settled.
        pre_focus_ok_v2538 = False
        target_v2538 = -1
        history_pin_marker_v2538 = ""
        try:
            if control_id in (6100, 6110):
                ctrl = self.getControl(control_id)
                size = int(ctrl.size())
                if size > 0:
                    target_v2538 = min(max(0, pos if pos >= 0 else 0), size - 1)
                    ctrl.selectItem(target_v2538)
                    if control_id == 6110:
                        try:
                            _win_v2538 = xbmcgui.Window(10000)
                            history_pin_marker_v2538 = "actor_back:%s:%d" % (
                                _short_log_value(actor_name, 60), self._now_ms()
                            )
                            _win_v2538.setProperty("PlexKM.Info.HistoryBackActiveV2310", "1")
                            _win_v2538.setProperty("PlexKM.Info.HistoryBackLayoutReadyV2310", "1")
                            _win_v2538.setProperty("PlexKM.Info.HistoryBackPrimeV2310", "1")
                            _win_v2538.setProperty("PlexKM.Info.HistoryBackReturnFocusV2310", str(control_id))
                            _win_v2538.setProperty("PlexKM.Info.HistoryBackMarkerV2310", history_pin_marker_v2538)
                        except Exception:
                            history_pin_marker_v2538 = ""
                    if xbmc.getCondVisibility("Control.IsVisible(%d)" % control_id):
                        try:
                            self.setFocusId(control_id)
                        except TypeError:
                            self.setFocusId(control_id, target_v2538)
                        try:
                            pre_focus_ok_v2538 = (int(self.getFocusId()) == control_id)
                        except Exception:
                            pre_focus_ok_v2538 = False
                    else:
                        pre_focus_ok_v2538 = False
                        _log("ACTOR_PROFILE_BACK_HIDDEN_PREFOCUS_DEFER_VNEXT actor=%s control=%d pos=%d action=post_reveal_focus" % (
                            _short_log_value(actor_name, 80), control_id, target_v2538))
                    if pre_focus_ok_v2538:
                        self._last_focus_id = control_id
                    _log("ACTOR_PROFILE_BACK_PREFocus_V2538 actor=%s control=%d pos=%d ok=%d tv_pin=%d actor_still_visible=1" % (
                        _short_log_value(actor_name,80), control_id, target_v2538,
                        1 if pre_focus_ok_v2538 else 0, 1 if history_pin_marker_v2538 else 0
                    ))
        except Exception:
            pre_focus_ok_v2538 = False
            _log("ACTOR_PROFILE_BACK_PREFocus_FAILED_V2538 actor=%s control=%d pos=%d err=%s" % (
                _short_log_value(actor_name,80), control_id, pos,
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        actor_swap_token_v2479 = self._pkm_swap_settle_v2479(
            "actor_profile", "info", reason="actor_back_parent_preserved:%s" % (reason or ""), wait_ms=16
        )
        self._actor_profile_active_v2454 = False
        self._actor_profile_set_prop_v2454("Active", "")
        self._pkm_swap_finish_v2479(
            actor_swap_token_v2479, "actor_profile", "info", reason="actor_back_commit:%s" % (reason or "")
        )

        # Only fall back to the old post-reveal focus write when hidden pre-focus
        # genuinely failed.  Avoiding the normal second focus write is the key to
        # eliminating the visible bottom->top return animation.
        if not pre_focus_ok_v2538:
            try:
                if control_id in (6100, 6110):
                    ctrl = self.getControl(control_id)
                    size = int(ctrl.size())
                    if size > 0:
                        target = min(max(0, pos if pos >= 0 else 0), size - 1)
                        ctrl.selectItem(target)
                        try:
                            self.setFocusId(control_id)
                        except TypeError:
                            self.setFocusId(control_id, target)
                        self._last_focus_id = control_id
                        _log("ACTOR_PROFILE_BACK_FALLBACK_FOCUS_V2538 actor=%s control=%d pos=%d reason=prefocus_failed" % (
                            _short_log_value(actor_name,80), control_id, target
                        ), xbmc.LOGWARNING)
            except Exception:
                pass

        if history_pin_marker_v2538:
            try:
                self._inline_info_history_schedule_visual_cleanup_v2310(
                    history_pin_marker_v2538, parent_key="actor_profile_back"
                )
            except Exception:
                pass

        _log("ACTOR_PROFILE_BACK_TO_PARENT_INFO_V2538 actor=%s reason=%s return_control=%d return_pos=%d prefocus=%d rebuild=0 parent_info_preserved=1 zero_motion_target=1" % (
            _short_log_value(actor_name,80), reason or "", control_id, pos,
            1 if pre_focus_ok_v2538 else 0
        ))
        return True

    def _actor_profile_open_selected_work_v2454(self, reason="work_click"):
        if not self._actor_profile_is_active_v2454():
            return False
        now_ms = self._now_ms()
        if now_ms - int(getattr(self, "_actor_profile_work_open_guard_ms_v2454", 0) or 0) < 650:
            return True
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = 6500
        work_control_id = focus_id if focus_id in (6500, 6510) else 6500
        try:
            li = self.getControl(work_control_id).getSelectedItem()
        except Exception:
            li = None
        if li is None or not str(li.getProperty("PlexKM.RatingKey") or "").strip():
            return False
        target_rk_r35 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
        # R35: a second OK queued while the first actor-work Info (~1.3 s on
        # SHIELD) was opening re-opened the SAME title.  The 650 ms guard above
        # counts from the first click start; also skip the same target for
        # 1.5 s after the previous open finished.
        _last_r35 = getattr(self, "_actor_work_open_last_r35", None)
        if _last_r35 and _last_r35[0] == target_rk_r35 and now_ms - int(_last_r35[1] or 0) < 1500:
            _log("ACTOR_PROFILE_WORK_OPEN_DUP_SKIP_R35 target=%s since_open_end_ms=%d" % (
                target_rk_r35, now_ms - int(_last_r35[1] or 0)))
            return True
        self._actor_profile_work_open_guard_ms_v2454 = now_ms
        actor_name = str(getattr(self, "_actor_profile_return_name_v2454", "") or "")
        target_rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
        # v2479: Actor -> work Info is a real A/B handoff.  Keep ActorProfile
        # visible while the ordinary Info target is prepared completely underneath.
        # Retire ActorProfile only after InlineActive owns the requested rating key.
        self._inline_info_history_v2085 = []
        self._inline_info_chain_exit_after_back_v2152 = False
        self._actor_profile_work_open_v2454 = True
        try:
            _log("ACTOR_PROFILE_WORK_OPEN_STANDARD_INFO_V2479 actor=%s target=%s title=%s source_held=1 history=cleared actor_page_return=0" % (
                _short_log_value(actor_name,80), target_rk, _short_log_value(li.getLabel() or "",120)
            ))
            self._show_info(li=li)
            self._actor_work_open_last_r35 = (target_rk, self._now_ms())
            win_v2479 = xbmcgui.Window(10000)
            target_ready_v2479 = bool(
                (self.getProperty("PlexKM.Info.InlineActive") == "1" or win_v2479.getProperty("PlexKM.Info.InlineActive") == "1")
                and str(win_v2479.getProperty("PlexKM.Info.RatingKey") or self.getProperty("PlexKM.Info.RatingKey") or "").strip() == target_rk
            )
            if not target_ready_v2479:
                _log("ACTOR_PROFILE_WORK_SWAP_RETAIN_SOURCE_V2479 actor=%s target=%s reason=info_not_ready" % (
                    _short_log_value(actor_name,80), target_rk
                ), xbmc.LOGWARNING)
                return False
            actor_info_swap_v2479 = self._pkm_swap_settle_v2479(
                "actor_profile", "info", reason="actor_work_info_target_ready", wait_ms=16
            )
            self._actor_profile_active_v2454 = False
            self._actor_profile_set_prop_v2454("Active", "")
            self._pkm_swap_finish_v2479(
                actor_info_swap_v2479, "actor_profile", "info", reason="actor_work_info_commit"
            )
            _log("ACTOR_PROFILE_WORK_SWAP_DONE_V2479 actor=%s target=%s source_retired_after_info_ready=1" % (
                _short_log_value(actor_name,80), target_rk
            ))
            return True
        finally:
            self._actor_profile_work_open_v2454 = False

    def _plex_people_profile_thumb(self, actor_name, slot_index=0, rating_key="", allow_unverified_exact=False):
        """Resolve a missing Role thumb by asking Plex's own people/search index.

        v195 used exact-name hits from Plex global people search. That can be
        wrong for ambiguous names, e.g. different actors named 박지훈.  v197
        keeps this fallback but only accepts candidates that can be verified
        against the currently opened Plex ratingKey.

        v1344: some Plex items, especially Continue/OnDeck documentary entries,
        expose creator names in <Role> but no Role@thumb. Plex UI still shows the
        person portrait from the people/search result. In the background prewarm
        path only, allow an exact-title Plex people thumbnail when verification
        fails, so Info uses the same source Plex UI/recommendation paths can show.
        """
        actor_name = str(actor_name or "").strip()
        rating_key = str(rating_key or "").strip()
        if not actor_name:
            return ""
        try:
            cache = getattr(self, "_plex_people_thumb_cache", None)
            if cache is None:
                cache = {}
                setattr(self, "_plex_people_thumb_cache", cache)
            key = "%s|%s|%s" % (actor_name.lower(), rating_key, "u1" if allow_unverified_exact else "u0")
            if key in cache:
                thumb = cache.get(key) or ""
                _log("CAST_FALLBACK plex_people_cache slot=%s name=%s rating_key=%s thumb=%s" % (
                    slot_index, _short_log_value(actor_name, 80), rating_key, _short_log_value(thumb)))
                return thumb
        except Exception:
            cache = None
            key = "%s|%s|%s" % (actor_name.lower(), rating_key, "u1" if allow_unverified_exact else "u0")

        def _walk_candidates(node, parent_type=""):
            found = []
            try:
                node_type = (node.get("type") or parent_type or "").strip().lower()
                title = (node.get("title") or node.get("tag") or node.get("name") or "").strip()
                thumb = (node.get("thumb") or node.get("art") or "").strip()
                cand_key = (node.get("key") or node.get("fastKey") or node.get("ratingKey") or "").strip()
                if title == actor_name and thumb:
                    if node_type in ("actor", "tag", "person", "director") or parent_type in ("actor", "tag", "person", "director"):
                        found.append((thumb, cand_key, node_type or parent_type))
                child_parent = node_type or parent_type
                for child in list(node):
                    found.extend(_walk_candidates(child, child_parent))
            except Exception:
                pass
            return found

        searches = (
            ("hubs_search", "/hubs/search", {"query": actor_name, "limit": 20, "includeCollections": 0}),
            ("library_search", "/library/search", {"query": actor_name}),
        )
        start_all = time.time()
        for label, path, params in searches:
            try:
                t0 = time.time()
                root = core.plex_request_xml(path, params=params, timeout=0.9)
                candidates = _walk_candidates(root)
                accepted = ""
                unverified_exact = ""
                unverified_key = ""
                rejected = 0
                for thumb, cand_key, cand_type in candidates:
                    if thumb and not unverified_exact:
                        unverified_exact = thumb
                        unverified_key = cand_key
                    if self._plex_people_candidate_matches_item(cand_key, rating_key):
                        accepted = thumb
                        break
                    rejected += 1
                    _log("CAST_FALLBACK plex_people_reject_unverified source=%s slot=%s name=%s type=%s key=%s rating_key=%s thumb=%s" % (
                        label, slot_index, _short_log_value(actor_name, 80), cand_type,
                        _short_log_value(cand_key, 100), rating_key, _short_log_value(thumb)))
                if (not accepted) and allow_unverified_exact and unverified_exact:
                    accepted = unverified_exact
                    _log("CAST_FALLBACK plex_people_accept_unverified_exact_v1344 source=%s slot=%s name=%s key=%s rating_key=%s thumb=%s" % (
                        label, slot_index, _short_log_value(actor_name, 80), _short_log_value(unverified_key, 100), rating_key, _short_log_value(accepted)))
                _log("CAST_FALLBACK plex_people_%s slot=%s name=%s candidates=%d accepted=%s rejected=%d elapsed=%.1fms" % (
                    label, slot_index, _short_log_value(actor_name, 80), len(candidates), "yes" if accepted else "no", rejected, (time.time() - t0) * 1000.0))
                if accepted:
                    resolved = _plex_art(accepted, width=320, height=320)
                    resolved = _clean_external_image_url(resolved)
                    try:
                        if cache is not None:
                            cache[key] = resolved
                    except Exception:
                        pass
                    _log("CAST_FALLBACK source=plex_people_search_%s slot=%s name=%s rating_key=%s thumb=%s total=%.1fms" % (
                        "unverified_exact_v1344" if allow_unverified_exact and accepted == unverified_exact else "verified",
                        slot_index, _short_log_value(actor_name, 80), rating_key, _short_log_value(resolved), (time.time() - start_all) * 1000.0))
                    return resolved
            except Exception:
                _log("CAST_FALLBACK plex_people_%s_failed slot=%s name=%s error=%s" % (
                    label, slot_index, _short_log_value(actor_name, 80), _short_log_value(traceback.format_exc(), 220)), xbmc.LOGWARNING)
        # v2189: do not freeze a transient Plex search timeout/miss as a permanent
        # empty portrait for the rest of the Kodi session. Positive hits are cached;
        # misses remain retryable on a later focus/open.
        _log("CAST_FALLBACK plex_people_miss slot=%s name=%s rating_key=%s elapsed=%.1fms" % (
            slot_index, _short_log_value(actor_name, 80), rating_key, (time.time() - start_all) * 1000.0))
        return ""

    def _resolve_cast_thumb_fallback(self, actor_name, current_thumb, slot_index=0, rating_key="", allow_network=False):
        """Resolve actor artwork in strict Plex-first priority order.

        v2189 priority:
        1) Role thumb supplied by the *current Plex item* (authoritative first choice).
        2) Exact actor-name portrait already indexed in PKM's local Plex DB/cache.
        3) When ``allow_network`` is true, ask Plex's own people/search index for
           the exact actor/person portrait.  Verified current-item matches win;
           if Plex exposes only an exact-name person portrait, accept that as the
           final Plex fallback so Plex-visible portraits do not become grey PKM
           placeholders merely because Role@thumb is empty.
        4) Placeholder only after all Plex-backed sources above fail.
        """
        current_thumb = _clean_external_image_url(current_thumb)
        if current_thumb and self._is_cast_placeholder_thumb(current_thumb):
            _log("CAST_FALLBACK ignore_placeholder_current slot=%s name=%s thumb=%s" % (
                slot_index, _short_log_value(actor_name, 80), _short_log_value(current_thumb)))
            current_thumb = ""
        if current_thumb:
            _log("CAST_FALLBACK source=plex_role_thumb slot=%s name=%s thumb=%s" % (
                slot_index, _short_log_value(actor_name, 80), _short_log_value(current_thumb)))
            return current_thumb, "plex_role_thumb"

        local_db = self._local_actor_thumb_v1876(actor_name, rating_key=rating_key)
        if local_db:
            _log("CAST_FALLBACK source=pkm_local_actor_db_v2189 slot=%s name=%s rating_key=%s thumb=%s" % (
                slot_index, _short_log_value(actor_name, 80), rating_key, _short_log_value(local_db)))
            return local_db, "pkm_local_actor_db_v2189"

        if allow_network:
            try:
                plex_person = self._plex_people_profile_thumb(
                    actor_name,
                    slot_index=slot_index,
                    rating_key=rating_key,
                    allow_unverified_exact=True,
                )
            except Exception:
                plex_person = ""
                _log("CAST_FALLBACK plex_people_v2189_failed slot=%s name=%s rating_key=%s err=%s" % (
                    slot_index, _short_log_value(actor_name, 80), rating_key,
                    _short_log_value(traceback.format_exc(), 220)
                ), xbmc.LOGWARNING)
            plex_person = _clean_external_image_url(plex_person)
            if plex_person:
                _log("CAST_FALLBACK source=plex_people_v2189 slot=%s name=%s rating_key=%s thumb=%s" % (
                    slot_index, _short_log_value(actor_name, 80), rating_key, _short_log_value(plex_person)))
                return plex_person, "plex_people_v2189"

        placeholder = self._cast_placeholder_thumb()
        _log("CAST_FALLBACK source=placeholder_after_plex_v2189 slot=%s name=%s rating_key=%s network=%d thumb=%s" % (
            slot_index, _short_log_value(actor_name, 80), rating_key, 1 if allow_network else 0,
            _short_log_value(placeholder)))
        return placeholder, "placeholder"

    def _resolve_missing_cast_profiles_from_plex_v2189(self, slots, rating_key="", max_workers=0, reason="", allow_people_search=True, allow_global_network=True):
        """Fill only missing actor portraits from Plex people/search, in parallel.

        This helper never replaces a current-work Role thumb or a local Plex-backed
        portrait.  It is only a third-stage fallback for named cast slots whose
        portrait is still empty/placeholder.  Returned URLs are left for the normal
        cast download/cache pass, so the visible Info rail still publishes local
        files atomically before reveal.
        """
        rk = str(rating_key or "").strip()

        # v2207: stable-focus prewarm is opportunistic only.  Once focus has
        # moved, or the same item is being opened by the foreground Info
        # transaction, the background worker must not launch another pair of
        # Plex people searches.  In the failing 007 Spectre trace a stale
        # prewarm for the previous movie plus a same-item prewarm both kept
        # issuing /hubs/search + /library/search while the foreground Info
        # request was waiting.  That extra traffic made the actor fallback
        # time out and then the foreground path repeated the same searches.
        if str(reason or "").startswith("cast_prewarm:"):
            try:
                current_home_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Home.RatingKey") or "").strip()
            except Exception:
                current_home_rk = ""
            if current_home_rk and rk and current_home_rk != rk:
                _log("CAST_PLEX_PEOPLE_PREWARM_SKIP_V2207 rating_key=%s current=%s reason=%s action=stale_focus_no_network" % (
                    rk, current_home_rk, reason or ""
                ))
                return 0
            try:
                info_busy = bool(str(getattr(self, "_info_global_busy_token_v2145", "") or "").strip())
                info_rk = str(getattr(self, "_last_info_rating_key", "") or "").strip()
            except Exception:
                info_busy = False
                info_rk = ""
            if info_busy and rk and info_rk == rk:
                _log("CAST_PLEX_PEOPLE_PREWARM_SKIP_V2207 rating_key=%s current=%s reason=%s action=foreground_info_owns_network" % (
                    rk, current_home_rk, reason or ""
                ))
                return 0

        missing = []
        try:
            for pos, slot in enumerate(list(slots or []), 1):
                if not isinstance(slot, dict):
                    continue
                name = str(slot.get("name") or slot.get("Name") or "").strip()
                if not name:
                    continue
                thumb = _clean_external_image_url(
                    slot.get("thumb") or slot.get("Thumb") or slot.get("OriginalThumb") or ""
                )
                source = str(slot.get("source") or slot.get("Source") or "")
                if thumb and not self._is_cast_placeholder_thumb(thumb):
                    continue
                idx = _safe_int(slot.get("idx"), pos) or pos
                missing.append((idx, name, slot, source))
        except Exception:
            missing = []
        if not missing:
            return 0

        requested_total_v2208 = len(missing)
        global_hits_v2208 = 0
        try:
            global_hits_v2208 = self._resolve_missing_cast_from_global_library_v2208(
                slots, rating_key=rk, reason="%s:global_first_v2208" % (reason or "cast_resolve"),
                allow_network_candidates=bool(allow_global_network)
            )
        except Exception:
            global_hits_v2208 = 0
            _log("CAST_GLOBAL_LIBRARY_PREWARM_FAILED_V2208 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        # Rebuild missing after the global-library pass. Plex people/search is
        # now only the final fallback, not the primary cross-library resolver.
        missing = []
        for pos, slot in enumerate(list(slots or []), 1):
            if not isinstance(slot, dict):
                continue
            name = str(slot.get("name") or slot.get("Name") or "").strip()
            if not name:
                continue
            thumb = _clean_external_image_url(slot.get("thumb") or slot.get("Thumb") or slot.get("OriginalThumb") or "")
            if thumb and not self._is_cast_placeholder_thumb(thumb):
                continue
            idx = _safe_int(slot.get("idx"), pos) or pos
            missing.append((idx, name, slot, str(slot.get("source") or slot.get("Source") or "")))
        if not missing:
            _log("CAST_PLEX_PEOPLE_BULK_SKIP_V2208 rating_key=%s requested=%d global_resolved=%d action=all_library_resolved reason=%s" % (
                rk, requested_total_v2208, global_hits_v2208, reason or ""
            ))
            return global_hits_v2208

        if not allow_people_search:
            _log("CAST_PLEX_PEOPLE_SKIP_V2298 rating_key=%s requested=%d global_resolved=%d unresolved=%d reason=%s action=placeholder_no_people_network" % (
                rk, requested_total_v2208, global_hits_v2208, len(missing), reason or ""
            ))
            return global_hits_v2208

        workers = int(max_workers or 0)
        if workers <= 0:
            workers = 1 if _is_android_platform_v1931() else 4
        workers = max(1, min(workers, len(missing)))
        _log("CAST_PLEX_PEOPLE_BULK_BEGIN_V2189 rating_key=%s missing=%d workers=%d reason=%s" % (
            rk, len(missing), workers, reason or ""
        ))

        def _lookup(entry):
            idx, name, _slot, _source = entry
            try:
                thumb = self._plex_people_profile_thumb(
                    name,
                    slot_index=idx,
                    rating_key=rk,
                    allow_unverified_exact=True,
                ) or ""
                return entry, _clean_external_image_url(thumb)
            except Exception:
                _log("CAST_PLEX_PEOPLE_BULK_ITEM_FAILED_V2189 rating_key=%s slot=%d name=%s err=%s" % (
                    rk, idx, _short_log_value(name, 80), _short_log_value(traceback.format_exc(), 220)
                ), xbmc.LOGWARNING)
                return entry, ""

        resolved = int(global_hits_v2208 or 0)
        people_resolved_v2208 = 0
        try:
            with ThreadPoolExecutor(max_workers=workers) as executor:
                futures = [executor.submit(_lookup, entry) for entry in missing]
                for future in as_completed(futures):
                    entry, thumb = future.result()
                    idx, name, slot, _source = entry
                    if not thumb:
                        continue
                    if "thumb" in slot or "idx" in slot:
                        slot["thumb"] = thumb
                        slot["original"] = thumb
                        slot["source"] = "plex_people_v2189"
                    else:
                        slot["Thumb"] = thumb
                        slot["RawThumb"] = thumb
                        slot["Source"] = "plex_people_v2189"
                    resolved += 1
                    people_resolved_v2208 += 1
                    _log("CAST_PLEX_PEOPLE_BULK_HIT_V2189 rating_key=%s slot=%d name=%s thumb=%s" % (
                        rk, idx, _short_log_value(name, 80), _short_log_value(thumb)
                    ))
        except Exception:
            _log("CAST_PLEX_PEOPLE_BULK_FAILED_V2189 rating_key=%s reason=%s err=%s" % (
                rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        _log("CAST_PLEX_PEOPLE_BULK_DONE_V2189 rating_key=%s requested=%d resolved=%d unresolved=%d reason=%s global_library=%d people=%d" % (
            rk, requested_total_v2208, resolved, max(0, requested_total_v2208 - resolved), reason or "",
            global_hits_v2208, people_resolved_v2208
        ))
        return resolved

    def _download_cast_thumb_to_cache(self, url, slot_index=0, priority=None):
        url = self._cast_cache_url_for_display(url)
        if not url:
            return ""
        lower = url.lower()
        if not lower.startswith(("http://", "https://")):
            if self._is_legacy_cast_cache_thumb_v1349(url):
                return ""
            return url
        try:
            digest = hashlib.md5(url.encode("utf-8")).hexdigest()
            raw_path = os.path.join(self._info_cache_dir(), "cast_%s.raw.jpg" % digest)
            if os.path.exists(raw_path) and os.path.getsize(raw_path) > 0:
                _log("CAST_CACHE_HIT_RAW_V2147 slot=%s file=%s pil=0 platform_shared=1" % (slot_index, raw_path))
                return raw_path
            start = time.time()
            data = pkm_artwork_scheduler.fetch_bytes(
                url, timeout=2.5, max_bytes=2 * 1024 * 1024,
                headers={"User-Agent": "Kodi Plex KM"},
                # PKM_CAST_PROGRESSIVE_R15: open-Info cast jumps the shared
                # 2-lane artwork queue; focus prewarm waits behind it.
                priority=(pkm_artwork_scheduler.PRIORITY_VISIBLE if priority is None else int(priority)),
                tag="cast_thumb",
                cancel_check=self._closing_event_v1841.is_set,
                pause_check=_pkm_playback_active_v1411,
                pause_when_playing=False,
            )
            if not data or len(data) > 2 * 1024 * 1024:
                return ""

            # v2147: no PIL crop/PNG encode on any cast portrait path/platform.
            # Both movie and TV cast XML already use a fixed square control with
            # scalediffuse=false and cast-circle-diffuse.png, so the skin performs
            # the circular mask without changing geometry.  Cache the source bytes
            # only; this removes CPU encode latency while still guaranteeing a local
            # actor image before the Info surface is revealed.
            tmp = "%s.%s.tmp" % (raw_path, threading.get_ident())
            try:
                with open(tmp, "wb") as f:
                    f.write(data)

                # v2162: multiple cast-prewarm workers can legitimately resolve
                # the same actor URL at the same time.  On Windows the first
                # completed file may already be opened by Kodi's texture loader,
                # so replacing that live destination from a second worker can
                # raise WinError 5.  Once a valid peer result exists it is
                # authoritative; never overwrite a live raw portrait cache.
                try:
                    if os.path.exists(raw_path) and os.path.getsize(raw_path) > 0:
                        _log("CAST_CACHE_PEER_WON_V2162 slot=%s file=%s action=reuse_existing_before_replace" % (
                            slot_index, raw_path
                        ))
                        return raw_path
                except Exception:
                    pass

                try:
                    os.replace(tmp, raw_path)
                except PermissionError:
                    # Close the final check/replace race: another worker may have
                    # published the same file between the existence check above
                    # and os.replace().  If so, reuse it instead of logging a
                    # false download failure.
                    try:
                        if os.path.exists(raw_path) and os.path.getsize(raw_path) > 0:
                            _log("CAST_CACHE_PEER_WON_V2162 slot=%s file=%s action=reuse_existing_after_replace_race" % (
                                slot_index, raw_path
                            ))
                            return raw_path
                    except Exception:
                        pass
                    raise
            finally:
                try:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                except Exception:
                    pass
            _log("CAST_CACHE_SAVED_RAW_V2147 slot=%s bytes=%d elapsed=%.1fms file=%s pil=0 platform_shared=1 kodi_diffuse_owner=1" % (
                slot_index, len(data), (time.time() - start) * 1000.0, raw_path
            ))
            return raw_path
        except Exception:
            _log("CAST_CACHE download_failed slot=%s url=%s\n%s" % (slot_index, _short_log_value(url), traceback.format_exc()), xbmc.LOGWARNING)
        return ""

    def _existing_cast_cache_path(self, url):
        url = self._cast_cache_url_for_display(url)
        if not url or self._is_cast_placeholder_thumb(url):
            return ""
        lower = url.lower()
        if not lower.startswith(("http://", "https://")):
            if self._is_legacy_cast_cache_thumb_v1349(url):
                return ""
            return url
        digest = hashlib.md5(url.encode("utf-8")).hexdigest()
        # v2147: raw portrait cache is authoritative on every platform. The skin
        # owns circular masking; Python-generated circle PNG caches are ignored.
        raw_path = os.path.join(self._info_cache_dir(), "cast_%s.raw.jpg" % digest)
        try:
            if os.path.exists(raw_path) and os.path.getsize(raw_path) > 0:
                return raw_path
        except Exception:
            pass
        return ""

    def _schedule_info_cast_prewarm_for_visible_rows_v1339(self, row_items, reason=""):
        # v1642: broad speculative cast prewarm made Home sluggish for 20+ seconds
        # after first paint.  Cast is now prepared only for the item that remains
        # focused, through the debounced focus path below.
        try:
            _log("CAST_PREWARM_VISIBLE_DEFER_V1642 reason=%s policy=stable_focus_only" % (reason or ""))
        except Exception:
            pass
        return 0

    def _schedule_important_row_cast_prewarm_v1341(self, row_entries, row_title="", reason=""):
        """Priority prewarm for rows the user is most likely to open Info from.

        v1341 concentrates cast PNG cache on:
        - 이어보기
        - 취향 한국영화
        - 취향 외국영화

        These rows are visible/clicked most often, so they must jump ahead of broad
        idle/library queues instead of waiting behind lower-priority section work.
        """
        # v1642: no broad priority queue. Stable focus is the single source of
        # cast prewarm work.
        try:
            _log("CAST_PREWARM_IMPORTANT_DEFER_V1642 title=%s reason=%s" % (row_title or "", reason or ""))
        except Exception:
            pass
        return 0

    def _info_cast_prewarm_is_negative_v1340(self, rk, now_ms=None):
        try:
            rk = str(rk or "").strip()
            if not rk:
                return False
            if now_ms is None:
                now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            neg = getattr(self, "_info_cast_prewarm_negative", {}) or {}
            until = _safe_int(neg.get(rk), 0)
            if until and until > int(now_ms):
                return True
            if until and until <= int(now_ms):
                try:
                    neg.pop(rk, None)
                    self._info_cast_prewarm_negative = neg
                except Exception:
                    pass
            return False
        except Exception:
            return False

    def _info_cast_prewarm_mark_negative_v1340(self, rk, reason=""):
        try:
            rk = str(rk or "").strip()
            if not rk:
                return
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            neg = getattr(self, "_info_cast_prewarm_negative", None)
            if not isinstance(neg, dict):
                neg = {}
            neg[rk] = now_ms + int(CAST_PREWARM_NEGATIVE_TTL_MS_V1340)
            self._info_cast_prewarm_negative = neg
            _log("CAST_PREWARM_NEGATIVE_V1340 rating_key=%s ttl_ms=%d reason=%s" % (
                rk, int(CAST_PREWARM_NEGATIVE_TTL_MS_V1340), reason or ""), xbmc.LOGWARNING)
        except Exception:
            pass

    def _cancel_info_cast_prewarm_for_playback_v1450(self, reason=""):
        """Drop pending cast prewarm work as soon as playback starts.

        v1450: the 1976 log showed Kodi already in VideoPlayer::OpenFile while
        Home cast fallback workers were still issuing /hubs/search and
        /library/search requests. Those requests are not required for playback
        and can compete with the actual Plex file stream. Existing workers exit
        on the next playback-active check; clearing the queue prevents them from
        starting another network-heavy item.
        """
        try:
            qlen = 0
            running = 0
            with self._info_cast_prewarm_lock:
                try:
                    qlen = len(getattr(self, "_info_cast_prewarm_queue", []) or [])
                except Exception:
                    qlen = 0
                try:
                    running = len(getattr(self, "_info_cast_prewarm_running", set()) or set())
                except Exception:
                    running = 0
                self._info_cast_prewarm_queue = []
            _log("CAST_PREWARM_CANCEL_PLAYBACK_V1450 reason=%s queued=%d running=%d" % (reason or "", int(qlen), int(running)))
            return qlen
        except Exception:
            try:
                _log("CAST_PREWARM_CANCEL_PLAYBACK_FAILED_V1450 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return 0

    def _info_cast_prewarm_enqueue_locked_v1340(self, data, priority=False, now_ms=None):
        """Deduplicated queue insertion used by v1340.

        Priority focus/click-near items must jump ahead of broad section idle work.
        Remove any older queued copy of the same rating_key before inserting so the
        worker never wastes time on stale duplicates.
        """
        try:
            if not isinstance(data, dict):
                return False
            rk = str(data.get("rating_key") or "").strip()
            if not rk:
                return False
            if now_ms is None:
                now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            if self._info_cast_prewarm_is_negative_v1340(rk, now_ms=now_ms):
                if priority:
                    try:
                        neg = getattr(self, "_info_cast_prewarm_negative_v1340", {}) or {}
                        if rk in neg:
                            neg.pop(rk, None)
                            self._info_cast_prewarm_negative_v1340 = neg
                        _log("CAST_PREWARM_NEGATIVE_BYPASS_V1344 rating_key=%s reason=priority" % rk)
                    except Exception:
                        pass
                else:
                    return False
            if not self._info_cast_prewarm_should_schedule(rk, priority=priority):
                return False
            q = getattr(self, "_info_cast_prewarm_queue", []) or []
            self._info_cast_prewarm_queue = [x for x in q if str((x or {}).get("rating_key") or "").strip() != rk]
            data = dict(data)
            data["priority"] = bool(priority)
            if priority:
                self._info_cast_prewarm_queue.insert(0, data)
            else:
                self._info_cast_prewarm_queue.append(data)
            self._info_cast_prewarm_seen[rk] = now_ms
            return True
        except Exception:
            return False

    def _start_info_cast_prewarm_workers_locked_v1340(self):
        try:
            if _pkm_playback_active_v1411():
                try:
                    self._info_cast_prewarm_queue = []
                except Exception:
                    pass
                _log("CAST_PREWARM_WORKERS_SKIP_PLAYBACK_ACTIVE_V1450")
                return 0
            target = 1 if _PKM_ANDROID_RUNTIME_V2595 else max(1, int(CAST_PREWARM_WORKERS_V1340))
            try:
                _q = list(getattr(self, "_info_cast_prewarm_queue", []) or [])
                if (not _PKM_ANDROID_RUNTIME_V2595) and any(str((_x or {}).get("reason") or "").startswith("search_") for _x in _q):
                    target = max(target, 4)
            except Exception:
                pass
            count = _safe_int(getattr(self, "_info_cast_prewarm_worker_count", 0), 0)
            started = 0
            while count < target:
                count += 1
                self._info_cast_prewarm_worker_count = count
                self._info_cast_prewarm_worker_running = True
                _PKMHomeThreadV2151(target=self._info_cast_prewarm_worker, name="PlexKMCastPrewarmV1340-%d" % count, daemon=True).start()
                started += 1
            if started:
                _log("CAST_PREWARM_WORKERS_START_V1340 started=%d active=%d target=%d" % (started, count, target))
            return started
        except Exception:
            try:
                if not getattr(self, "_info_cast_prewarm_worker_running", False):
                    self._info_cast_prewarm_worker_running = True
                    self._info_cast_prewarm_worker_count = 1
                    _PKMHomeThreadV2151(target=self._info_cast_prewarm_worker, name="PlexKMCastPrewarmV1340", daemon=True).start()
                    return 1
            except Exception:
                pass
            return 0

    def _info_cast_db_actor_slots_v1342(self, rating_key, max_count=8):
        """Read actor slots from local DB for a rating key."""
        slots = []
        rk = str(rating_key or "").strip()
        if not rk:
            return slots
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return slots
            conn = _pkm_ro_connect(dbp, timeout=5.0)
            try:
                for row in conn.execute("""
                    SELECT person_name, role, person_thumb
                    FROM item_people
                    WHERE rating_key=? AND person_type='actor' AND IFNULL(person_name,'')<>''
                    ORDER BY sort_order ASC, person_name COLLATE NOCASE
                    LIMIT ?
                """, (rk, int(max_count or 8))).fetchall():
                    name = str(row[0] or "").strip()
                    if not name:
                        continue
                    slots.append({
                        "Name": name,
                        "Role": str(row[1] or "").strip(),
                        "Thumb": _clean_external_image_url(row[2] or ""),
                        "RawThumb": str(row[2] or "").strip(),
                        "Source": "db_item_people_v1342",
                    })
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            if slots:
                _log("CAST_PREWARM_DB_SLOTS_V1342 rating_key=%s slots=%d ready_raw=%d" % (
                    rk, len(slots), len([x for x in slots if (x or {}).get("Thumb")])
                ))
        except Exception:
            _log("CAST_PREWARM_DB_SLOTS_FAILED_V1342 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        return slots

    def _info_cast_duplicate_candidate_keys_v1342(self, data, base_keys=None, limit=6):
        """Find same-title/same-year sibling rating keys for cast-thumb prewarm."""
        out = []
        try:
            base = set(str(x or "").strip() for x in (base_keys or []) if str(x or "").strip())
            title = str((data or {}).get("title") or "").strip()
            rk = str((data or {}).get("rating_key") or "").strip()
            if not title and rk:
                try:
                    dbp0 = self._profile_db_path()
                    conn0 = _pkm_ro_connect(dbp0, timeout=5.0)
                    try:
                        row0 = conn0.execute("SELECT title FROM items WHERE rating_key=? LIMIT 1", (rk,)).fetchone()
                        title = str(row0[0] or "").strip() if row0 else ""
                    finally:
                        try:
                            conn0.close()
                        except Exception:
                            pass
                except Exception:
                    pass
            if not title:
                return out
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return out
            conn = sqlite3.connect(dbp, timeout=5.0)
            conn.row_factory = sqlite3.Row
            try:
                cur = conn.cursor()
                current = cur.execute("SELECT title, original_title, year, section_id, plex_type FROM items WHERE rating_key=? LIMIT 1", (rk,)).fetchone() if rk else None
                year = int((current["year"] if current else 0) or 0)
                section_id = str((current["section_id"] if current else (data or {}).get("section_id")) or "").strip()
                plex_type = str((current["plex_type"] if current else (data or {}).get("type")) or "").strip().lower()
                params = [title]
                where = "WHERE i.title=?"
                if year:
                    where += " AND IFNULL(i.year,0)=?"
                    params.append(year)
                if plex_type in ("movie", "show", "episode"):
                    where += " AND i.plex_type=?"
                    params.append(plex_type)
                params.extend([rk, section_id, int(limit or 6)])
                rows = cur.execute("""
                    SELECT i.rating_key, i.section_id,
                           SUM(CASE WHEN IFNULL(p.person_thumb,'')<>'' THEN 1 ELSE 0 END) AS thumb_count,
                           COUNT(p.person_name) AS people_count,
                           IFNULL(i.updated_at,0) AS updated_at,
                           IFNULL(i.added_at,0) AS added_at
                    FROM items i
                    LEFT JOIN item_people p ON p.rating_key=i.rating_key AND p.person_type='actor'
                    %s
                      AND i.rating_key<>?
                    GROUP BY i.rating_key
                    ORDER BY CASE WHEN i.section_id=? THEN 0 ELSE 1 END,
                             thumb_count DESC,
                             people_count DESC,
                             updated_at DESC,
                             added_at DESC
                    LIMIT ?
                """ % where, tuple(params)).fetchall()
                for row in rows:
                    key = str(row["rating_key"] or "").strip()
                    if key and key not in base and key not in out:
                        out.append(key)
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            if out:
                _log("CAST_PREWARM_DUP_KEYS_V1342 rating_key=%s title=%s keys=%s" % (
                    rk, _short_log_value(title, 80), ",".join(out)
                ))
        except Exception:
            _log("CAST_PREWARM_DUP_KEYS_FAILED_V1342 rating_key=%s err=%s" % (
                str((data or {}).get("rating_key") or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        return out

    def _info_cast_prewarm_candidate_keys_for_item(self, data):
        keys = []
        try:
            for key in (
                data.get("rating_key") if isinstance(data, dict) else "",
                data.get("grandparent_rating_key") if isinstance(data, dict) else "",
                data.get("parent_rating_key") if isinstance(data, dict) else "",
            ):
                key = str(key or "").strip()
                if key and key not in keys:
                    keys.append(key)
            dup_keys = []
            for key in self._info_cast_duplicate_candidate_keys_v1342(data, base_keys=keys, limit=6):
                if key and key not in keys and key not in dup_keys:
                    dup_keys.append(key)
            # v1344: onDeck/continue rows use a resume rating_key whose Role
            # entries can be name-only.  Recommendation widgets for the same title
            # are built from the canonical library keys.  For Continue we therefore
            # try duplicate/canonical keys FIRST for cast artwork, while keeping the
            # original rating_key for playback/resume.
            try:
                reason = str((data or {}).get("reason") or "") if isinstance(data, dict) else ""
                is_continue = bool("continue" in reason.lower() or "이어보기" in reason or "home:continue" in reason)
            except Exception:
                reason = ""
                is_continue = False
            if dup_keys and is_continue:
                original_keys = list(keys)
                keys = []
                for key in list(dup_keys) + original_keys:
                    if key and key not in keys:
                        keys.append(key)
                try:
                    _log("CAST_PREWARM_CONTINUE_CANONICAL_FIRST_V1344 rating_key=%s keys=%s reason=%s" % (
                        str((data or {}).get("rating_key") or ""), ",".join(keys), reason
                    ))
                except Exception:
                    pass
            else:
                for key in dup_keys:
                    if key and key not in keys:
                        keys.append(key)
            try:
                if dup_keys and is_continue:
                    _log("CAST_PREWARM_CONTINUE_CANONICAL_CANDIDATES_V1344 rating_key=%s dup_keys=%s reason=%s" % (
                        str((data or {}).get("rating_key") or ""), ",".join(dup_keys), reason
                    ))
            except Exception:
                pass
        except Exception:
            pass
        return keys

    def _info_cast_thumb_count_v1343(self, slots):
        try:
            n = 0
            for sl in list(slots or []):
                thumb = _clean_external_image_url((sl or {}).get("Thumb") or (sl or {}).get("RawThumb") or "")
                if thumb and not self._is_cast_placeholder_thumb(thumb):
                    n += 1
            return n
        except Exception:
            return 0

    def _info_cast_prewarm_should_schedule(self, rk, priority=False):
        try:
            rk = str(rk or "").strip()
            if not rk:
                return False
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            if self._info_cast_prewarm_is_negative_v1340(rk, now_ms=now_ms):
                return False
            cache = getattr(self, "_info_cast_prewarm_cache", {}) or {}
            rec = cache.get(rk) or {}
            if isinstance(rec, dict) and rec.get("ready", 0) and (now_ms - _safe_int(rec.get("ts"), 0)) < 6 * 60 * 60 * 1000:
                return False
            seen = getattr(self, "_info_cast_prewarm_seen", {}) or {}
            last = _safe_int(seen.get(rk), 0)
            # Focus scheduling is allowed to promote an already queued item to
            # the front. A later duplicate is harmless because a ready cache
            # record makes the duplicate return immediately.
            if priority:
                return True
            if last and (now_ms - last) < 180000:
                return False
            return True
        except Exception:
            return True

    def _schedule_info_cast_prewarm_for_listitems(self, listitems, reason="", limit=24, priority=False):
        """Queue visible/focused row items for background cast PNG prewarm.

        v1338: this is the real cache path.  The rendered Home/section/wall
        items are queued immediately after row paint, so Info only loads local
        cast_cache PNG files and never downloads/builds actor art on entry.
        """
        if not priority:
            try:
                _log("CAST_PREWARM_LIST_DEFER_V1642 reason=%s policy=stable_focus_only" % (reason or ""))
            except Exception:
                pass
            return 0
        try:
            # V2659 UHD3: cast is decorative and must never compete with navigation.
            # Priority focus prewarm is dropped rather than queued for later bursts.
            if _PKM_ANDROID_RUNTIME_V2595:
                try:
                    _w_v2659 = xbmcgui.Window(10000)
                    _until_v2659 = int(float(_w_v2659.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
                    if (_w_v2659.getProperty("PlexKM.Sidebar.Browsing") == "1"
                            or _w_v2659.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                            or (_until_v2659 and int(time.time() * 1000) < _until_v2659)):
                        _log("CAST_PREWARM_UHD3_DROP_V2659 reason=%s priority=%d navigation=1" % (reason or "", 1 if priority else 0))
                        return 0
                except Exception:
                    pass
            if self._settings_quiet_active_v1457():
                _log("CAST_PREWARM_SKIP_V1457 reason=settings_quiet request_reason=%s mode=listitems" % (reason or ""))
                return 0
            if _pkm_playback_active_v1411():
                _log("CAST_PREWARM_SKIP_PLAYBACK_ACTIVE_V1411 reason=%s mode=listitems" % (reason or ""))
                return 0
            items = []
            seen = set()
            for li in list(listitems or []):
                if li is None:
                    continue
                try:
                    rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                    ptype = str(li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "").strip().lower()
                except Exception:
                    rk = ""
                    ptype = ""
                if not rk or rk in seen:
                    continue
                if ptype not in ("movie", "show", "episode", "tv", "tvshow", "season"):
                    continue
                seen.add(rk)
                items.append(li)
                if len(items) >= max(1, int(limit or 1)):
                    break
            if not items:
                return 0
            added = 0
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            with self._info_cast_prewarm_lock:
                for li in items:
                    try:
                        rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                        data = {
                            "rating_key": rk,
                            "type": li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "",
                            "title": li.getProperty("PlexKM.Title") or li.getLabel() or "",
                            "parent_rating_key": li.getProperty("PlexKM.ParentRatingKey") or "",
                            "grandparent_rating_key": li.getProperty("PlexKM.GrandparentRatingKey") or "",
                            "section_id": li.getProperty("PlexKM.SectionId") or "",
                            "reason": reason or "",
                            "priority": bool(priority),
                            "search_token": li.getProperty("PlexKM.SearchPrewarmTokenV1783") or "",
                        }
                        if self._info_cast_prewarm_enqueue_locked_v1340(data, priority=priority, now_ms=now_ms):
                            added += 1
                    except Exception:
                        pass
                if added > 0:
                    self._start_info_cast_prewarm_workers_locked_v1340()
            if added > 0:
                _log("CAST_PREWARM_QUEUE_V1340 reason=%s added=%d candidates=%d limit=%d priority=%s" % (reason or "", added, len(items), int(limit or 0), "1" if priority else "0"))
            return added
        except Exception:
            _log("CAST_PREWARM_QUEUE_FAILED_V1339 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _info_cast_atomic_stats_v2629(self, li):
        """V2630 cast texture state: ready / remote / confirmed-missing / unknown.

        Unknown is deliberately NOT equivalent to no-photo. A missing Role URL can
        be caused by a bounded Plex metadata timeout; revealing a placeholder in
        that state caused V2629's false no-photo result.
        """
        names = local_ready = remote_pending = legitimate_missing = unknown = 0
        try:
            for idx in range(1, 9):
                name = str(li.getProperty("PlexKM.Cast%d.Name" % idx) or "").strip()
                if not name:
                    continue
                names += 1
                local = str(li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) or "").strip()
                current = str(li.getProperty("PlexKM.Cast%d.Thumb" % idx) or "").strip()
                original = str(li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or "").strip()
                source = str(li.getProperty("PlexKM.Cast%d.ThumbSource" % idx) or "").strip().lower()
                if (local and not self._is_cast_placeholder_thumb(local)
                        and not self._is_legacy_cast_cache_thumb_v1349(local)
                        and not local.lower().startswith(("http://", "https://"))):
                    local_ready += 1
                    continue
                resolved = False
                for candidate in (original, current):
                    candidate = str(candidate or "").strip()
                    if not candidate or self._is_cast_placeholder_thumb(candidate) or self._is_legacy_cast_cache_thumb_v1349(candidate):
                        continue
                    if candidate.lower().startswith(("http://", "https://")):
                        try:
                            local2 = str(self._existing_cast_cache_path(candidate) or "").strip()
                        except Exception:
                            local2 = ""
                        if local2 and not local2.lower().startswith(("http://", "https://")):
                            try:
                                li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, local2)
                                li.setProperty("PlexKM.Cast%d.Thumb" % idx, local2)
                            except Exception:
                                pass
                            local_ready += 1
                        else:
                            remote_pending += 1
                        resolved = True
                        break
                    else:
                        local_ready += 1
                        resolved = True
                        break
                if resolved:
                    continue
                if source.startswith("confirmed_missing_v2630"):
                    legitimate_missing += 1
                else:
                    unknown += 1
        except Exception:
            pass
        return names, local_ready, remote_pending, legitimate_missing, unknown

    def _info_cast_atomic_panel_gate_v2629(self, li, reason=""):
        """V2630 hold the cast rail until every named portrait state is resolved."""
        rk = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li is not None else ""
        names, local_ready, remote_pending, legitimate_missing, unknown = self._info_cast_atomic_stats_v2629(li)
        # PKM_CAST_PROGRESSIVE_R15: never hide the Credits group while portraits
        # are pending.  Names + placeholder circles are published with the Info
        # surface and each portrait is filled in place when it becomes local.
        self._info_clear_property_all("PlexKM.Info.CastAwaitingImages")
        if names <= 0:
            try:
                self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2629")
                self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2630")
                self._info_clear_property_all("PlexKM.Info.CastPanelReady")
            except Exception:
                pass
            return True
        if remote_pending <= 0 and unknown <= 0:
            try:
                self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2629")
                self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2630")
                self._info_set_property_all("PlexKM.Info.CastAtomicReadyV2629", "1")
                self._info_set_property_all("PlexKM.Info.CastAtomicReadyV2630", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.KPI.InfoCastAssetsReady", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.KPI.InfoCastTextureReady", "unknown")
            except Exception:
                pass
            _log("INFO_CAST_ATOMIC_FIRST_FRAME_V2630 rating_key=%s names=%d local=%d remote_pending=0 confirmed_missing=%d unknown=0 action=panel_ready placeholder_replacement_visible=0" % (
                rk, names, local_ready, legitimate_missing
            ))
            return True
        # PKM_KPI_VISUAL_FOLLOWUP_20261014
        # Metadata/URLs are known, but the real local images are not.  Do not
        # release the Credits group or report photographic first-frame PASS.
        try:
            self._info_set_property_all("PlexKM.Info.CastAtomicPendingV2629", "1")
            self._info_set_property_all("PlexKM.Info.CastAtomicPendingV2630", "1")
            self._info_clear_property_all("PlexKM.Info.CastAtomicReadyV2629")
            self._info_clear_property_all("PlexKM.Info.CastAtomicReadyV2630")
            xbmcgui.Window(10000).setProperty("PlexKM.KPI.InfoCastAssetsReady", "0")
            xbmcgui.Window(10000).setProperty("PlexKM.KPI.InfoCastTextureReady", "unknown")
        except Exception:
            pass
        _log("INFO_CAST_PROGRESSIVE_REVEAL_R15 rating_key=%s names=%d local=%d remote_pending=%d confirmed_missing=%d unknown=%d action=names_with_placeholders_fill_later reason=%s" % (
            rk, names, local_ready, remote_pending, legitimate_missing, unknown, reason or ""
        ))
        if remote_pending > 0 or unknown > 0:
            self._info_cast_early_prefetch_r15(li, rk)
        # Pending flags stay set so the post-visible late-fill worker is armed.
        return True

    def _info_cast_early_prefetch_r15(self, li, rk):
        """PKM_CAST_PROGRESSIVE_R15: start known role-URL downloads before the
        Info surface is visible.  Plain URLs only leave the GUI thread; the
        post-visible worker later finds the files in cast_cache or joins the
        in-flight transfer through pkm_artwork_scheduler coalescing."""
        try:
            urls = []
            unknown_names_r16 = []
            for idx in range(1, 9):
                _name_r16 = str(li.getProperty("PlexKM.Cast%d.Name" % idx) or "").strip()
                if not _name_r16:
                    continue
                url = ""
                for cand in (li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx),
                             li.getProperty("PlexKM.Cast%d.Thumb" % idx)):
                    cand = _clean_external_image_url(cand or "")
                    if cand.lower().startswith(("http://", "https://")) and not self._is_cast_placeholder_thumb(cand):
                        url = cand
                        break
                if not url:
                    # PKM_CAST_ACTOR_MASTER_R16: no Role URL on the current item;
                    # resolve it off-GUI from local Plex rows / Actor Master.
                    unknown_names_r16.append((idx, _name_r16))
                    continue
                try:
                    _cached_r15 = str(self._existing_cast_cache_path(url) or "").strip()
                    if _cached_r15 and not _cached_r15.lower().startswith(("http://", "https://")):
                        continue
                except Exception:
                    pass
                urls.append((idx, url))
            if not urls and not unknown_names_r16:
                return 0
            lanes = 1 if _is_android_platform_v1931() else 2
            _log("INFO_CAST_EARLY_PREFETCH_R15 rating_key=%s urls=%d local_lookup=%d lanes=%d priority=foreground" % (
                rk, len(urls), len(unknown_names_r16), lanes))

            def _prefetch():
                try:
                    if unknown_names_r16:
                        _map_r16 = self._local_actor_thumb_map_v1876([n for _i, n in unknown_names_r16], [rk]) or {}
                        for _idx_r16, _n_r16 in unknown_names_r16:
                            _u_r16 = _clean_external_image_url(_map_r16.get(_n_r16) or "")
                            if _u_r16.lower().startswith(("http://", "https://")):
                                urls.append((_idx_r16, _u_r16))
                    if not urls:
                        return
                    with ThreadPoolExecutor(max_workers=max(1, min(lanes, len(urls)))) as executor:
                        for idx, url in urls:
                            executor.submit(self._download_cast_thumb_to_cache, url, slot_index=idx,
                                            priority=pkm_artwork_scheduler.PRIORITY_FOREGROUND)
                except Exception:
                    _log("INFO_CAST_EARLY_PREFETCH_FAILED_R15 rating_key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

            _PKMHomeThreadV2151(target=_prefetch, name="PKMInfoCastEarlyR15", daemon=True).start()
            return len(urls)
        except Exception:
            return 0

    # PKM_CAST_SAME_TITLE_SINGLEFLIGHT
    def _info_cast_priority_r15(self, reason=""):
        """PKM_CAST_PROGRESSIVE_R15: artwork-queue priority for a cast pass."""
        r = str(reason or "")
        if r.startswith("info_") or "fast_click" in r:
            return pkm_artwork_scheduler.PRIORITY_FOREGROUND
        if r.startswith("focus_all8") or "prewarm" in r or "stable_focus" in r:
            return pkm_artwork_scheduler.PRIORITY_PREWARM
        return pkm_artwork_scheduler.PRIORITY_VISIBLE

    def _info_cast_atomic_localize_v2629(self, li=None, remote_rec=None, reason="", rating_key="", on_slot_ready=None):
        """Single-flight actor portrait cache localization per Plex title.

        No Kodi ListItem or GUI calls are introduced into worker threads.
        The original pipeline still resolves Plex role images and verifies all
        named portraits; only duplicate simultaneous downloads are serialized.
        """
        did_enter_work = False
        try:
            key = str(rating_key or "").strip()
            if not key and li is not None:
                key = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not key:
                key = str((remote_rec or {}).get("rating_key") or (remote_rec or {}).get("source_key") or "").strip()
            if not key:
                return self._info_cast_atomic_localize_impl_singleflight(
                    li=li, remote_rec=remote_rec, reason=reason, rating_key=rating_key,
                    on_slot_ready=on_slot_ready)
            table_lock = getattr(self, "_pkm_cast_flights_lock", None)
            if table_lock is None:
                with self._info_cast_prewarm_lock:
                    table_lock = getattr(self, "_pkm_cast_flights_lock", None)
                    if table_lock is None:
                        table_lock = threading.Lock()
                        self._pkm_cast_flights_lock = table_lock
                        self._pkm_cast_flights = {}
            with table_lock:
                slots = self._pkm_cast_flights
                flight = slots.get(key)
                if flight is None:
                    flight = threading.Lock()
                    slots[key] = flight
            before = self._now_ms()
            # PKM_CAST_PROGRESSIVE_R15: the open Info rail never queues behind a
            # stale focus-prewarm pass of the same title.  Duplicate URLs are
            # coalesced by pkm_artwork_scheduler (and bumped to foreground), and
            # the cast cache writer already tolerates a peer-won file.
            if (self._info_cast_priority_r15(reason) == pkm_artwork_scheduler.PRIORITY_FOREGROUND
                    and not flight.acquire(False)):
                did_enter_work = True
                _log("INFO_CAST_SINGLEFLIGHT_BYPASS_R15 title=%s reason=%s action=foreground_join_scheduler" % (key, reason or ""))
                result = self._info_cast_atomic_localize_impl_singleflight(
                    li=li, remote_rec=remote_rec, reason=reason, rating_key=rating_key,
                    on_slot_ready=on_slot_ready)
                _log("INFO_CAST_SINGLEFLIGHT_DONE title=%s waited_ms=0 ready=%d bypass_r15=1" % (
                    key, int((result or {}).get("ready") or 0)))
                return result
            if self._info_cast_priority_r15(reason) != pkm_artwork_scheduler.PRIORITY_FOREGROUND:
                flight.acquire()
            try:
                waited = max(0, self._now_ms() - before)
                did_enter_work = True
                if waited:
                    _log("INFO_CAST_SINGLEFLIGHT_WAIT title=%s waited_ms=%d" % (key, waited))
                result = self._info_cast_atomic_localize_impl_singleflight(
                    li=li, remote_rec=remote_rec, reason=reason, rating_key=rating_key,
                    on_slot_ready=on_slot_ready)
                _log("INFO_CAST_SINGLEFLIGHT_DONE title=%s waited_ms=%d ready=%d" % (
                    key, waited, int((result or {}).get("ready") or 0)))
                return result
            finally:
                flight.release()
        except Exception:
            # A failure inside the original implementation must not execute a
            # second identical image download pass.
            if did_enter_work:
                raise
            _log("INFO_CAST_SINGLEFLIGHT_FALLBACK err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return self._info_cast_atomic_localize_impl_singleflight(
                li=li, remote_rec=remote_rec, reason=reason, rating_key=rating_key,
                on_slot_ready=on_slot_ready)

    def _info_cast_atomic_localize_impl_singleflight(self, li=None, remote_rec=None, reason="", rating_key="", on_slot_ready=None):
        """V2630 prepare cast portraits off-GUI without converting unknown to missing."""
        rec = dict(remote_rec or {})
        rk = str(rating_key or "").strip()
        if not rk and li is not None:
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
        if not rk:
            rk = str(rec.get("rating_key") or rec.get("source_key") or "").strip()
        if not rk:
            return {}
        source_slots = [dict(x or {}) for x in list(rec.get("slots") or [])[:8]]
        source_by_name = {}
        for src in source_slots:
            src_name = str(src.get("Name") or src.get("name") or "").strip()
            if src_name:
                source_by_name.setdefault(src_name.casefold(), src)
        slots = []
        names_for_local = []
        for idx in range(1, 9):
            li_name = str(li.getProperty("PlexKM.Cast%d.Name" % idx) or "").strip() if li is not None else ""
            positional = source_slots[idx - 1] if idx <= len(source_slots) else {}
            src = source_by_name.get(li_name.casefold()) if li_name else None
            if not isinstance(src, dict):
                src = positional if isinstance(positional, dict) else {}
                if li_name and str(src.get("Name") or "").strip() and str(src.get("Name") or "").strip().casefold() != li_name.casefold():
                    src = {}
            name = str(src.get("Name") or li_name or "").strip()
            role = str(src.get("Role") or (li.getProperty("PlexKM.Cast%d.Role" % idx) if li is not None else "") or "")
            _preferred_plex_original = ""
            for _candidate_orig in (
                src.get("OriginalThumb"), src.get("DirectThumb"),
                src.get("Thumb"), src.get("RawThumb"),
                (li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) if li is not None else ""),
                (li.getProperty("PlexKM.Cast%d.Thumb" % idx) if li is not None else ""),
            ):
                _candidate_orig = _clean_external_image_url(_candidate_orig or "")
                if _candidate_orig and not self._is_cast_placeholder_thumb(_candidate_orig):
                    _preferred_plex_original = _candidate_orig
                    break
            original = _preferred_plex_original
            local = str(src.get("LocalThumb") or (li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) if li is not None else "") or "").strip()
            if (self._is_legacy_cast_cache_thumb_v1349(local)
                    or self._is_cast_placeholder_thumb(local)
                    or local.lower().startswith(("http://", "https://"))):
                local = ""
            if not local and original:
                try:
                    local = str(self._existing_cast_cache_path(original) or "").strip()
                except Exception:
                    local = ""
            source_proven = bool(name and isinstance(src, dict) and str(src.get("Name") or "").strip())
            slot = {
                "Name": name, "Role": role, "OriginalThumb": original,
                "LocalThumb": local, "SourceRatingKey": str(src.get("SourceRatingKey") or rec.get("source_key") or rk),
                "SourceProvenV2630": 1 if source_proven else 0,
                "DisplayNameKo": (str(src.get("DisplayNameKo") or "").strip() or
                                   (self._actor_master_name_ko_v2702(name) if name else "")),
            }
            slots.append(slot)
            # PKM_CAST_PROGRESSIVE_R15: an actor that already has a role URL goes
            # straight to the download lane; the cross-library name lookup is
            # only needed for actors whose current title has no portrait URL.
            if name and not local and not str(original or "").lower().startswith(("http://", "https://")):
                names_for_local.append(name)
        if names_for_local:
            try:
                local_map = self._local_actor_thumb_map_v1876(names_for_local, [rk] if rk else []) or {}
                for slot in slots:
                    if slot.get("Name") and not slot.get("LocalThumb"):
                        candidate = _clean_external_image_url(local_map.get(slot.get("Name")) or "")
                        if candidate:
                            if candidate.lower().startswith(("http://", "https://")):
                                # V2631: an exact-name portrait reused from another indexed
                                # Plex library item is a valid source even when item_people
                                # stores it as a remote URL. Localize it through the same
                                # cache/texture gate before the atomic cast reveal.
                                if not str(slot.get("OriginalThumb") or "").strip():
                                    slot["OriginalThumb"] = candidate
                                    slot["LocalReuseRemoteV2631"] = 1
                                try:
                                    existing_v2631 = str(self._existing_cast_cache_path(candidate) or "").strip()
                                except Exception:
                                    existing_v2631 = ""
                                if existing_v2631 and not existing_v2631.lower().startswith(("http://", "https://")):
                                    slot["LocalThumb"] = existing_v2631
                            else:
                                slot["LocalThumb"] = candidate
                                slot["LocalReuseReadyV2631"] = 1
            except Exception:
                pass
        jobs = []
        for idx, slot in enumerate(slots, 1):
            original = str(slot.get("OriginalThumb") or "").strip()
            if slot.get("Name") and original.lower().startswith(("http://", "https://")) and not slot.get("LocalThumb"):
                jobs.append((idx, original, slot))
        downloaded = 0
        if jobs:
            try:
                _tegra_android_vnext = bool(_is_android_platform_v1931()
                    and "tegra" in str(os.uname().release or "").lower())
            except Exception:
                _tegra_android_vnext = False
            # R28: SHIELD (Tegra) used 2 lanes, so 8 portraits arrived in four
            # separate waves.  Portraits are small (w342) network-bound files;
            # 4 lanes lets the first screen (6 slots) finish in about one wave.
            _lane_cap = 4 if _tegra_android_vnext else (1 if _is_android_platform_v1931() else 4)
            workers = max(1, min(_lane_cap, len(jobs)))
            _log("INFO_CAST_LOCALIZE_LANES_VNEXT title=%s jobs=%d workers=%d tegra=%d" % (
                rk, len(jobs), workers, 1 if _tegra_android_vnext else 0))
            _priority_r15 = self._info_cast_priority_r15(reason)
            with ThreadPoolExecutor(max_workers=workers) as executor:
                future_map = {executor.submit(self._download_cast_thumb_to_cache, url, slot_index=idx, priority=_priority_r15): slot for idx, url, slot in jobs}
                for future in as_completed(future_map):
                    slot = future_map[future]
                    try:
                        local = str(future.result() or "").strip()
                    except Exception:
                        local = ""
                    if local and not local.lower().startswith(("http://", "https://")):
                        slot["LocalThumb"] = local
                        downloaded += 1
                        # PKM_CAST_PROGRESSIVE_R15: hand each finished portrait to
                        # the GUI-thread fill immediately (plain data only).
                        if callable(on_slot_ready):
                            try:
                                on_slot_ready([dict(x) for x in slots])
                            except Exception:
                                pass
        named = real = confirmed_missing = unknown = 0
        reuse_sources_v2631 = sum(1 for _slot_v2631 in slots if int(_slot_v2631.get("LocalReuseRemoteV2631") or 0) == 1 or int(_slot_v2631.get("LocalReuseReadyV2631") or 0) == 1)
        for slot in slots:
            if not slot.get("Name"):
                slot["PortraitStateV2630"] = "empty"
                continue
            named += 1
            local = str(slot.get("LocalThumb") or "").strip()
            original = str(slot.get("OriginalThumb") or "").strip()
            if local and not local.lower().startswith(("http://", "https://")):
                slot["PortraitStateV2630"] = "ready"
                real += 1
            elif original.lower().startswith(("http://", "https://")):
                slot["PortraitStateV2630"] = "unknown_fetch"
                unknown += 1
            elif int(slot.get("SourceProvenV2630") or 0) == 1:
                slot["PortraitStateV2630"] = "confirmed_missing"
                confirmed_missing += 1
            else:
                slot["PortraitStateV2630"] = "unknown_source"
                unknown += 1
        out = {
            "ts": self._now_ms(), "slots": slots, "ready": real,
            "downloaded": downloaded, "source_key": str(rec.get("source_key") or rk),
            "named": named, "placeholders": confirmed_missing, "confirmed_missing": confirmed_missing,
            "unknown": unknown, "reason": reason or "", "atomic_v2629": 1, "unknown_safe_v2630": 1,
        }
        if str(reason or "").startswith("info_local_first_r16"):
            # PKM_CAST_LOCAL_FIRST_R16: partial local-only result; never store it
            # as the title's Plex Role authority (that would skip the real
            # metadata request and hide actors 4-8).
            _log("INFO_CAST_LOCAL_FIRST_R16 rating_key=%s named=%d real=%d unknown=%d downloaded=%d jobs=%d" % (
                rk, named, real, unknown, downloaded, len(jobs)))
            return out
        try:
            cache = getattr(self, "_info_cast_prewarm_cache", None)
            if not isinstance(cache, dict):
                cache = {}
            cache[rk] = dict(out)
            self._info_cast_prewarm_cache = cache
            with self._info_atomic_asset_lock_v2609:
                remote_cache = getattr(self, "_info_cast_remote_cache_v2608", None)
                if not isinstance(remote_cache, dict):
                    remote_cache = {}
                merged = dict(remote_cache.get(rk) or rec)
                merged["slots"] = [dict(x) for x in slots]
                merged["lead_local_v2609"] = real
                merged["atomic_local_v2629"] = real
                merged["unknown_v2630"] = unknown
                remote_cache[rk] = merged
                self._info_cast_remote_cache_v2608 = remote_cache
        except Exception:
            pass
        _log("INFO_CAST_ATOMIC_PREPARED_V2630 rating_key=%s named=%d real=%d confirmed_missing=%d unknown=%d downloaded=%d jobs=%d android_lane=%d gui_mutation=0 reason=%s" % (
            rk, named, real, confirmed_missing, unknown, downloaded, len(jobs), 1 if _is_android_platform_v1931() else 0, reason or ""
        ))
        _log("INFO_CAST_LOCAL_REUSE_MERGE_V2631 rating_key=%s reuse_sources=%d named=%d real=%d confirmed_missing=%d unknown=%d atomic_commit_unchanged=1" % (
            rk, reuse_sources_v2631, named, real, confirmed_missing, unknown
        ))
        return out

    def _info_cast_lead_texture_prime_v2609(self, rating_key, remote_rec, event=None, reason=""):
        """V2629: stable-focus prewarm localizes the whole visible cast rail.

        The event contract is kept for the existing click-time join, but the
        worker now prepares up to eight local textures rather than only three.
        """
        rk = str(rating_key or "").strip()
        try:
            # remote_rec is immutable plain data; keep the stable-focus worker
            # free of Kodi ListItem/control access.
            out = self._info_cast_atomic_localize_v2629(
                None, remote_rec=dict(remote_rec or {}),
                reason="focus_all8_v2629:%s" % (reason or ""), rating_key=rk
            )
            ready = int((out or {}).get("ready") or 0)
            _log("INFO_CAST_LEAD_TEXTURE_PRIME_V2609 rating_key=%s lead=8 local_ready=%d jobs=atomic_v2629 gui_mutation=0 reason=%s" % (
                rk, ready, reason or ""
            ))
            return ready
        except Exception:
            _log("INFO_CAST_LEAD_TEXTURE_PRIME_FAILED_V2609 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0
        finally:
            try:
                if event is not None:
                    event.set()
            except Exception:
                pass

    def _info_cast_remote_prime_v2608(self, data, reason="", timeout=0.80):
        """Fetch only current-item Plex Role metadata; never download portrait files.

        This is the fast lane used by focus-prewarm and fast-click late fill. It
        intentionally avoids the duplicate-title DB scan, Plex people search and
        custom image-file download performed by the full cast prewarm worker.
        """
        try:
            rk = str((data or {}).get("rating_key") or "").strip()
            if not rk:
                return {}
            cache = getattr(self, "_info_cast_remote_cache_v2608", None)
            if not isinstance(cache, dict):
                cache = {}
                self._info_cast_remote_cache_v2608 = cache
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            old = cache.get(rk) or {}
            if isinstance(old, dict) and list(old.get("slots") or []) and (now_ms - int(old.get("ts") or 0)) <= 300000:
                return old
            direct_keys = []
            for key in (
                (data or {}).get("rating_key"),
                (data or {}).get("grandparent_rating_key"),
                (data or {}).get("parent_rating_key"),
            ):
                key = str(key or "").strip()
                if key and key not in direct_keys:
                    direct_keys.append(key)
            total_request_ms = 0.0
            best_slots = []
            best_key = ""
            best_ready = 0
            for key in direct_keys[:3]:
                try:
                    t0 = time.perf_counter()
                    root = core.plex_request_xml(
                        "/library/metadata/%s" % key,
                        params={"includeGuids": 1, "includeCollections": 1},
                        timeout=float(timeout or 0.80),
                        log_failures=False,
                    )
                    total_request_ms += (time.perf_counter() - t0) * 1000.0
                    node = _first_metadata_node(root)
                    slots = _extract_cast_slots(node, max_count=8) if node is not None else []
                    normalized = []
                    ready = 0
                    for slot in slots:
                        if not isinstance(slot, dict):
                            continue
                        name = str(slot.get("Name") or slot.get("name") or "").strip()
                        if not name:
                            continue
                        role = str(slot.get("Role") or slot.get("role") or "").strip()
                        original = _clean_external_image_url(slot.get("Thumb") or slot.get("RawThumb") or slot.get("OriginalThumb") or "")
                        direct = _cast_remote_display_url_v2608(original) if original else ""
                        if direct and not self._is_cast_placeholder_thumb(direct):
                            ready += 1
                        normalized.append({
                            "Name": name, "Role": role, "OriginalThumb": original,
                            "DirectThumb": direct, "SourceRatingKey": key,
                        })
                    if ready > best_ready or (not best_slots and normalized):
                        best_slots = normalized
                        best_key = key
                        best_ready = ready
                    if ready > 0:
                        break
                except Exception:
                    continue
            rec = {
                "ts": now_ms, "slots": list(best_slots), "ready": int(best_ready),
                "source_key": best_key or rk, "request_ms": float(total_request_ms),
                "reason": str(reason or ""),
            }
            if best_slots:
                cache[rk] = rec
                # PKM_CAST_ROLE_WRITEBACK_R16: persist the full Plex Role list
                # (up to 8 actors + portrait URLs) so the next Info open reads
                # it from plex_km.db instead of waiting on Plex again.
                if int(best_ready or 0) > 0:
                    try:
                        self._info_cast_role_writeback_r16(best_key or rk, list(best_slots))
                    except Exception:
                        pass
                if len(cache) > 64:
                    ordered = sorted(cache.items(), key=lambda kv: int((kv[1] or {}).get("ts") or 0))
                    for old_rk, _ in ordered[:-64]:
                        cache.pop(old_rk, None)
            self._info_cast_remote_cache_v2608 = cache
            _log("INFO_CAST_REMOTE_PRIME_V2608 rating_key=%s source_key=%s slots=%d ready=%d request_ms=%.1f total_gate_download_ms=0 reason=%s" % (
                rk, best_key or "", len(best_slots), int(best_ready), float(total_request_ms), reason or ""
            ))
            return rec if best_slots else {}
        except Exception:
            _log("INFO_CAST_REMOTE_PRIME_FAILED_V2608 rating_key=%s err=%s" % (
                str((data or {}).get("rating_key") or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return {}

    def _info_cast_role_writeback_r16(self, rating_key, slots):
        """PKM_CAST_ROLE_WRITEBACK_R16: background upsert of movie Role rows.

        Movie list-sync stores only the first three Role names with no thumb.
        When a /library/metadata/<key> response has already been fetched for
        Info or focus prewarm, write its actors (max 8, with portrait URLs)
        into item_people.  Only movies; only when it adds actors or portraits;
        existing tag_id values are kept by name; one attempt per key/session.
        """
        key = str(rating_key or "").strip()
        rows_in = []
        for idx, slot in enumerate(list(slots or [])[:8]):
            name = str((slot or {}).get("Name") or "").strip()
            if not name:
                continue
            rows_in.append((name, str((slot or {}).get("Role") or "").strip(),
                            _clean_external_image_url((slot or {}).get("OriginalThumb") or "")))
        if not key or not rows_in:
            return False
        done = getattr(self, "_info_cast_role_writeback_done_r16", None)
        if not isinstance(done, set):
            done = set()
            self._info_cast_role_writeback_done_r16 = done
        if key in done:
            return False
        done.add(key)

        def _worker():
            conn = None
            action = "skip"
            try:
                if self._closing_event_v1841.is_set():
                    return
                dbp = self._profile_db_path()
                if not dbp or not os.path.exists(dbp):
                    return
                conn = sqlite3.connect(dbp, timeout=8.0)
                item = conn.execute("SELECT section_id, plex_type FROM items WHERE rating_key=?", (key,)).fetchone()
                if not item or str(item[1] or "") != "movie":
                    action = "not_movie"
                    return
                section_id = str(item[0] or "")
                old = conn.execute(
                    "SELECT person_name, IFNULL(person_thumb,''), IFNULL(tag_id,'') FROM item_people "
                    "WHERE rating_key=? AND person_type='actor'", (key,)
                ).fetchall()
                old_thumbs = sum(1 for r in old if str(r[1] or "").strip())
                new_thumbs = sum(1 for r in rows_in if r[2])
                if len(old) >= len(rows_in) and old_thumbs >= new_thumbs:
                    action = "already_complete"
                    return
                tag_by_name = {}
                for r in old:
                    nm = str(r[0] or "").strip()
                    if nm and str(r[2] or "").strip():
                        tag_by_name[nm.casefold()] = str(r[2])
                now = int(time.time())
                with conn:
                    conn.execute("DELETE FROM item_people WHERE rating_key=? AND person_type='actor'", (key,))
                    for order, (name, role, thumb) in enumerate(rows_in):
                        conn.execute(
                            "INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                            "person_thumb, tag_id, sort_order, source, indexed_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (key, section_id, "actor", name, role, thumb,
                             tag_by_name.get(name.casefold(), ""), order, "plex_api_role_writeback_r16", now)
                        )
                action = "written"
                try:
                    (getattr(self, "_info_local_db_cache", None) or {}).pop(key, None)
                except Exception:
                    pass
                _log("INFO_CAST_ROLE_WRITEBACK_R16 rating_key=%s actors_before=%d thumbs_before=%d actors_after=%d thumbs_after=%d" % (
                    key, len(old), old_thumbs, len(rows_in), new_thumbs))
            except Exception:
                action = "failed"
                try:
                    done.discard(key)
                except Exception:
                    pass
                _log("INFO_CAST_ROLE_WRITEBACK_FAILED_R16 rating_key=%s err=%s" % (
                    key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
                if action not in ("written", "failed"):
                    _log("INFO_CAST_ROLE_WRITEBACK_SKIP_R16 rating_key=%s reason=%s" % (key, action))

        _PKMHomeThreadV2151(target=_worker, name="PKMCastRoleWritebackR16", daemon=True).start()
        return True

    def _apply_info_cast_remote_prime_v2608(self, li, reason=""):
        """Apply cached Plex Role URLs to the detached/current Info ListItem."""
        try:
            if li is None:
                return 0
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            cache = getattr(self, "_info_cast_remote_cache_v2608", {}) or {}
            rec = cache.get(rk) or {}
            slots = list(rec.get("slots") or []) if isinstance(rec, dict) else []
            if not slots:
                return 0
            applied = 0
            direct_ready = 0
            for idx, slot in enumerate(slots[:8], 1):
                name = str((slot or {}).get("Name") or "").strip()
                if not name:
                    continue
                role = str((slot or {}).get("Role") or "")
                original = _clean_external_image_url((slot or {}).get("OriginalThumb") or "")
                direct = str((slot or {}).get("DirectThumb") or "").strip() or (_cast_remote_display_url_v2608(original) if original else "")
                local = str(li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) or (slot or {}).get("LocalThumb") or "").strip()
                if self._is_legacy_cast_cache_thumb_v1349(local):
                    local = ""
                # INFO_CAST_ATOMIC_LOCAL_PATCH_R4:
                # Never publish an unresolved HTTP portrait into the first Info frame.
                # A localized portrait may be published immediately; remote portraits
                # remain pending for the existing atomic-localize/late-fill path.
                valid_local = bool(
                    local
                    and not local.lower().startswith(("http://", "https://"))
                    and not self._is_legacy_cast_cache_thumb_v1349(local)
                )
                display = local if valid_local else self._cast_placeholder_thumb()
                display_name_v2701 = self._info_click_cached_ko_name(name, (slot or {}).get("DisplayNameKo") or "")
                li.setProperty("PlexKM.Cast%d.Name" % idx, display_name_v2701)
                li.setProperty("PlexKM.Cast%d.Role" % idx, role)
                li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, original)
                li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, str((slot or {}).get("SourceRatingKey") or rec.get("source_key") or rk))
                li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, "local_atomic_pending_r4" if not valid_local and direct else ("local_ready_r4" if valid_local else "confirmed_missing_r4"))
                li.setProperty("PlexKM.Cast%d.Thumb" % idx, display)
                if direct and not valid_local:
                    li.setProperty("PlexKM.Cast%d.RemotePending" % idx, "1")
                else:
                    li.setProperty("PlexKM.Cast%d.RemotePending" % idx, "")
                applied += 1
                if valid_local:
                    direct_ready += 1
            _log("INFO_CAST_REMOTE_APPLY_V2608 rating_key=%s applied=%d ready=%d reason=%s" % (
                rk, applied, direct_ready, reason or ""
            ))
            return applied
        except Exception:
            _log("INFO_CAST_REMOTE_APPLY_FAILED_V2608 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return 0

    def _info_schedule_cast_late_fill_v2606(self, li, reason=""):
        """V2630 post-visible cast resolver; unknown never becomes placeholder."""
        try:
            if li is None:
                return 0
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return 0
            names, local_ready, remote_pending, legitimate_missing, unknown = self._info_cast_atomic_stats_v2629(li)
            if names <= 0 or (remote_pending + unknown) <= 0:
                return 0
            token = int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) + 1
            self._info_cast_late_fill_token_v2606 = token
            self._info_cast_late_fill_pending_v2606 = None
            arm_ms = self._now_ms()
            data = {
                "rating_key": rk,
                "type": li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "",
                "title": li.getProperty("PlexKM.Title") or li.getLabel() or "",
                "parent_rating_key": li.getProperty("PlexKM.ParentRatingKey") or "",
                "grandparent_rating_key": li.getProperty("PlexKM.GrandparentRatingKey") or "",
                "section_id": li.getProperty("PlexKM.SectionId") or "",
            }
            _log("INFO_CAST_ATOMIC_ARM_V2630 rating_key=%s token=%d names=%d local=%d remote_pending=%d confirmed_missing=%d unknown=%d first_frame_panel_hidden=0 progressive_r15=1 info_wait=0" % (
                rk, token, names, local_ready, remote_pending, legitimate_missing, unknown
            ))

            fill_gate_r17 = {"lock": threading.Lock(), "armed": False, "last": 0}
            # R28: the first screen of the Credits rail shows ~6 portraits.
            # Hold progressive commits until every downloadable portrait in
            # those slots has arrived (or a short deadline passes) so they
            # appear together instead of popping in one or two at a time.
            first_gate_r28 = {"released": False, "timer": False}
            _R28_VISIBLE_SLOTS = 6
            _R28_FIRST_DEADLINE_MS = 900

            def _first_screen_pending_r28(slots_snapshot):
                pending_r28 = 0
                for slot_r28 in list(slots_snapshot or [])[:_R28_VISIBLE_SLOTS]:
                    slot_r28 = dict(slot_r28 or {})
                    if not str(slot_r28.get("Name") or "").strip():
                        continue
                    local_r28 = str(slot_r28.get("LocalThumb") or "").strip()
                    if local_r28 and not local_r28.lower().startswith(("http://", "https://")):
                        continue
                    orig_r28 = str(slot_r28.get("OriginalThumb") or slot_r28.get("DirectThumb") or "").strip()
                    if orig_r28.lower().startswith(("http://", "https://")):
                        pending_r28 += 1
                return pending_r28

            def _first_deadline_ping_r28():
                try:
                    if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                        return
                    if first_gate_r28["released"]:
                        return
                    first_gate_r28["released"] = True
                    if isinstance(getattr(self, "_info_cast_late_fill_pending_v2606", None), dict):
                        _log("INFO_CAST_FIRST_SCREEN_RELEASE_R28 rating_key=%s token=%d reason=deadline elapsed_ms=%d" % (
                            rk, token, max(0, self._now_ms() - arm_ms)))
                        with fill_gate_r17["lock"]:
                            fill_gate_r17["last"] = self._now_ms()
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            def _progress_r15(slots_snapshot, stage="slot"):
                # PKM_CAST_PROGRESSIVE_R15: worker thread -> plain data only; the
                # GUI-thread commit swaps placeholder circles for local files.
                try:
                    if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                        return
                    self._info_cast_late_fill_pending_v2606 = {
                        "phase": "progressive_r15", "token": token, "rating_key": rk,
                        "li": li, "prepared": {"slots": [dict(x or {}) for x in list(slots_snapshot or [])[:8]]},
                        "arm_ms": arm_ms, "stage": stage,
                    }
                    if not first_gate_r28["released"]:
                        waiting_r28 = _first_screen_pending_r28(slots_snapshot)
                        elapsed_r28 = max(0, self._now_ms() - arm_ms)
                        if waiting_r28 > 0 and elapsed_r28 < _R28_FIRST_DEADLINE_MS:
                            if not first_gate_r28["timer"]:
                                first_gate_r28["timer"] = True
                                _t_r28 = threading.Timer(
                                    (_R28_FIRST_DEADLINE_MS - elapsed_r28) / 1000.0, _first_deadline_ping_r28)
                                _t_r28.daemon = True
                                _t_r28.start()
                            return
                        first_gate_r28["released"] = True
                        _log("INFO_CAST_FIRST_SCREEN_RELEASE_R28 rating_key=%s token=%d reason=%s elapsed_ms=%d stage=%s" % (
                            rk, token, "all_visible_ready" if waiting_r28 <= 0 else "deadline", elapsed_r28, stage))
                        with fill_gate_r17["lock"]:
                            fill_gate_r17["last"] = self._now_ms()
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        return
                    # PKM_CAST_FADE_R17: coalesce portraits that finish close
                    # together into one GUI commit (>= 160ms apart).  The
                    # pending record always holds the newest superset, so a
                    # deferred ping publishes everything that arrived meanwhile;
                    # the skin's 300ms fadetime blends each batch in.
                    with fill_gate_r17["lock"]:
                        if fill_gate_r17["armed"]:
                            return
                        wait_ms = 160 - (self._now_ms() - int(fill_gate_r17["last"] or 0))
                        if wait_ms > 0:
                            fill_gate_r17["armed"] = True
                        else:
                            fill_gate_r17["last"] = self._now_ms()
                    if wait_ms > 0:
                        def _deferred_ping_r17():
                            with fill_gate_r17["lock"]:
                                fill_gate_r17["armed"] = False
                                fill_gate_r17["last"] = self._now_ms()
                            if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                                return
                            if isinstance(getattr(self, "_info_cast_late_fill_pending_v2606", None), dict):
                                xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        _t_r17 = threading.Timer(wait_ms / 1000.0, _deferred_ping_r17)
                        _t_r17.daemon = True
                        _t_r17.start()
                        return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            def _watcher():
                try:
                    xbmc.sleep(10)
                    if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                        return
                    win0 = xbmcgui.Window(10000)
                    active0 = str(win0.getProperty("PlexKM.Info.RatingKey") or self.getProperty("PlexKM.Info.RatingKey") or "").strip()
                    inline0 = str(win0.getProperty("PlexKM.Info.InlineActive") or self.getProperty("PlexKM.Info.InlineActive") or "")
                    if active0 != rk or inline0 != "1":
                        return
                    prepared = {}
                    # PKM_CAST_LOCAL_FIRST_R16: when the current item has no cached
                    # Plex Role URLs, publish every portrait resolvable locally
                    # (other Plex items / Actor Master) before waiting on the
                    # Plex metadata request, which can time out on slow servers.
                    try:
                        _rc_r16 = dict((getattr(self, "_info_cast_remote_cache_v2608", {}) or {}).get(rk) or {})
                        if not list(_rc_r16.get("slots") or []):
                            _local_r16 = self._info_cast_atomic_localize_v2629(
                                li, remote_rec={}, reason="info_local_first_r16:%s" % (reason or "visible"),
                                on_slot_ready=_progress_r15
                            ) or {}
                            if list(_local_r16.get("slots") or []):
                                _progress_r15(list(_local_r16.get("slots") or []), stage="local_first_r16")
                    except Exception:
                        _log("INFO_CAST_LOCAL_FIRST_FAILED_R16 rating_key=%s err=%s" % (
                            rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                    timeouts = (0.90, 1.20, 1.50)
                    for attempt, timeout_v2630 in enumerate(timeouts, 1):
                        if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                            return
                        remote_cache = getattr(self, "_info_cast_remote_cache_v2608", {}) or {}
                        remote_rec = dict(remote_cache.get(rk) or {})
                        if attempt > 1:
                            try:
                                remote_cache.pop(rk, None)
                                self._info_cast_remote_cache_v2608 = remote_cache
                            except Exception:
                                pass
                            remote_rec = {}
                        if not list(remote_rec.get("slots") or []):
                            remote_rec = self._info_cast_remote_prime_v2608(
                                data, reason="info_atomic_source_v2630:a%d:%s" % (attempt, reason or "visible"), timeout=timeout_v2630
                            ) or {}
                        prepared = self._info_cast_atomic_localize_v2629(
                            li, remote_rec=remote_rec, reason="info_postvisible_atomic_v2630:a%d:%s" % (attempt, reason or "visible"),
                            on_slot_ready=_progress_r15
                        ) or {}
                        unresolved = int(prepared.get("unknown") or 0)
                        if unresolved <= 0:
                            break
                        if not list(remote_rec.get("slots") or []):
                            _log("INFO_CAST_EMPTY_ROLE_FAST_FALLBACK rating_key=%s token=%d attempt=%d unknown=%d action=plex_people" % (
                                rk, token, attempt, unresolved))
                            break
                        _log("INFO_CAST_ATOMIC_UNKNOWN_RETRY_V2630 rating_key=%s token=%d attempt=%d unknown=%d timeout_ms=%d" % (
                            rk, token, attempt, unresolved, int(timeout_v2630 * 1000)
                        ))
                        xbmc.sleep(120 * attempt)
                    unresolved = int((prepared or {}).get("unknown") or 0)
                    if unresolved > 0 and list((prepared or {}).get("slots") or []):
                        # PKM_CAST_PROGRESSIVE_R15: publish every portrait that is
                        # already local before the slower Plex people search.
                        _progress_r15(list(prepared.get("slots") or []), stage="before_plex_late")
                    if unresolved > 0:
                        # INFO_CAST_PLEX_LATE_REPAIR_R9:
                        # The Info surface is already visible, so a missing/timeout
                        # current-item Role response must not permanently freeze
                        # Plex-visible actor photos as placeholders. Reuse the
                        # existing Plex authority chain:
                        #   current/local index -> other Plex works -> Plex people/search.
                        # No TMDb portrait fallback is introduced here.
                        fallback_slots_r9 = [dict(x or {}) for x in list((prepared or {}).get("slots") or [])[:8]]
                        plex_hits_r9 = 0
                        try:
                            plex_hits_r9 = int(self._resolve_missing_cast_profiles_from_plex_v2189(
                                fallback_slots_r9,
                                rating_key=rk,
                                reason="info_postvisible_plex_late_r9",
                                allow_people_search=True,
                                allow_global_network=True,
                            ) or 0)
                        except Exception:
                            plex_hits_r9 = 0
                            _log("INFO_CAST_PLEX_LATE_RESOLVE_FAILED_R9 rating_key=%s token=%d err=%s" % (
                                rk, token, traceback.format_exc().replace(chr(10), " | ")
                            ), xbmc.LOGWARNING)
                        if plex_hits_r9 > 0:
                            # v2189 writes Plex people/global results to Thumb/RawThumb.
                            # Normalize those existing resolver outputs into the
                            # OriginalThumb field consumed by v2629 localization.
                            _late_plex_url_count = 0
                            for _slot_r9 in fallback_slots_r9:
                                _old_url_r9 = str(_slot_r9.get("OriginalThumb") or "").strip()
                                _resolved_url_r9 = _clean_external_image_url(
                                    _slot_r9.get("Thumb") or _slot_r9.get("RawThumb") or "")
                                if (_resolved_url_r9.lower().startswith(("http://", "https://"))
                                        and (not _old_url_r9 or self._is_cast_placeholder_thumb(_old_url_r9))):
                                    _slot_r9["OriginalThumb"] = _resolved_url_r9
                                    _slot_r9["DirectThumb"] = _resolved_url_r9
                                    _late_plex_url_count += 1
                            _log("INFO_CAST_PLEX_LATE_URL_MERGE rating_key=%s plex_hits=%d valid_urls=%d" % (
                                rk, plex_hits_r9, _late_plex_url_count))
                            prepared = self._info_cast_atomic_localize_v2629(
                                li,
                                remote_rec={
                                    "slots": fallback_slots_r9,
                                    "source_key": rk,
                                    "rating_key": rk,
                                },
                                reason="info_postvisible_plex_late_localize_r9",
                                rating_key=rk,
                                on_slot_ready=_progress_r15,
                            ) or prepared
                            unresolved = int((prepared or {}).get("unknown") or 0)
                        _log("INFO_CAST_PLEX_LATE_RESOLVE_R9 rating_key=%s token=%d plex_hits=%d unknown_after=%d action=%s" % (
                            rk, token, plex_hits_r9, unresolved,
                            "atomic_commit" if unresolved <= 0 else "defer"
                        ))
                    if unresolved > 0:
                        # PKM_CAST_PROGRESSIVE_R15: artwork really remained
                        # unavailable after the bounded source search.  Those
                        # slots keep their placeholder; the final commit below
                        # still publishes every portrait that did resolve.
                        _log("INFO_CAST_PROGRESSIVE_UNRESOLVED_R15 rating_key=%s token=%d unknown=%d action=keep_placeholder" % (
                            rk, token, unresolved))
                    if int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0) != token:
                        return
                    self._info_cast_late_fill_pending_v2606 = {
                        "phase": "atomic_v2630", "token": token, "rating_key": rk,
                        "li": li, "prepared": prepared, "arm_ms": arm_ms,
                        "ready": int(prepared.get("ready") or 0),
                        "downloaded": int(prepared.get("downloaded") or 0),
                        "slots": len(list(prepared.get("slots") or [])),
                    }
                    try:
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    except Exception:
                        pass
                except Exception:
                    _log("INFO_CAST_ATOMIC_WATCH_FAILED_V2630 rating_key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

            _PKMHomeThreadV2151(target=_watcher, name="PKMInfoCastAtomicV2630", daemon=True).start()
            return 1
        except Exception:
            _log("INFO_CAST_ATOMIC_ARM_FAILED_V2630 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return 0

    def _info_cast_late_fill_commit_v2606(self):
        """V2630 GUI-thread cast rail commit.

        PKM_CAST_PROGRESSIVE_R15: the Credits rail is already visible with names
        and placeholder circles.  Each commit swaps finished local portraits into
        the existing panel items in place (focus/scroll untouched), never
        replaces a real portrait with a placeholder, and never blocks on an
        actor whose artwork is still unknown or genuinely missing.
        """
        try:
            rec = getattr(self, "_info_cast_late_fill_pending_v2606", None)
            if not isinstance(rec, dict):
                return False

            def _consume_r15():
                # Only clear the slot we read; a newer worker request may have
                # replaced it while this GUI-thread commit was running.
                if getattr(self, "_info_cast_late_fill_pending_v2606", None) is rec:
                    self._info_cast_late_fill_pending_v2606 = None

            token = int(rec.get("token") or 0)
            rk = str(rec.get("rating_key") or "").strip()
            phase = str(rec.get("phase") or "")
            if token != int(getattr(self, "_info_cast_late_fill_token_v2606", 0) or 0):
                _consume_r15()
                return False
            win = xbmcgui.Window(10000)
            active = str(win.getProperty("PlexKM.Info.RatingKey") or self.getProperty("PlexKM.Info.RatingKey") or "").strip()
            inline = str(win.getProperty("PlexKM.Info.InlineActive") or self.getProperty("PlexKM.Info.InlineActive") or "")
            if active != rk or inline != "1":
                _consume_r15()
                return False
            if phase == "cast_missing_reveal":
                self._info_clear_property_all("PlexKM.Info.CastAwaitingImages")
                _consume_r15()
                _log("INFO_CAST_MISSING_LABELS_VISIBLE rating_key=%s token=%d reason=no_downloadable_plex_portrait" % (rk, token))
                return True
            li = rec.get("li")
            prepared = dict(rec.get("prepared") or {})
            slots = [dict(x or {}) for x in list(prepared.get("slots") or [])[:8]]
            if li is None or not slots:
                _consume_r15()
                return False
            final_r15 = (phase != "progressive_r15")
            placeholder = self._cast_placeholder_thumb()
            displays = {}
            real = pending = named = 0
            for idx in range(1, 9):
                slot = slots[idx - 1] if idx <= len(slots) else {}
                name = str(slot.get("Name") or "").strip()
                if not name:
                    if final_r15:
                        for subkey in ("Name", "Role", "Thumb"):
                            self._info_clear_property_all("PlexKM.Info.DisplayCast%d.%s" % (idx, subkey))
                    continue
                named += 1
                role = str(slot.get("Role") or "")
                original = str(slot.get("OriginalThumb") or "").strip()
                local = str(slot.get("LocalThumb") or "").strip()
                # INFO_CAST_PLEX_LATE_REPAIR_R9: V2702 is display-only.
                display_name_v2701 = self._info_click_cached_ko_name(name, slot.get("DisplayNameKo") or "")
                valid_local = bool(local and not local.lower().startswith(("http://", "https://"))
                                   and not self._is_legacy_cast_cache_thumb_v1349(local)
                                   and not self._is_cast_placeholder_thumb(local))
                if valid_local:
                    display = local
                    real += 1
                else:
                    display = placeholder
                    pending += 1
                displays[idx] = (name, display_name_v2701, role, display, valid_local)
                if valid_local or final_r15:
                    li.setProperty("PlexKM.Cast%d.Name" % idx, name)
                    li.setProperty("PlexKM.Cast%d.Role" % idx, role)
                    li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, original)
                    li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, local if valid_local else "")
                    li.setProperty("PlexKM.Cast%d.Thumb" % idx, display)
                    li.setProperty("PlexKM.Cast%d.ThumbSource" % idx,
                                   "local_progressive_r15" if valid_local else "missing_progressive_r15")
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Name" % idx, display_name_v2701)
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Role" % idx, role)
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Thumb" % idx, display)
                    self._info_set_property_all("PlexKM.Info.Cast%d.Name" % idx, display_name_v2701)
                    self._info_set_property_all("PlexKM.Info.Cast%d.Role" % idx, role)
                    self._info_set_property_all("PlexKM.Info.Cast%d.Thumb" % idx, display)
                    self._info_set_property_all("PlexKM.Info.Cast%d.OriginalThumb" % idx, original)
                    self._info_set_property_all("PlexKM.Info.Cast%d.LocalThumb" % idx, local if valid_local else "")
            control_id = int(self._info_cast_control_id_v2074())
            ctrl = self.getControl(control_id)
            updated = 0
            rebuilt = 0
            in_place = False
            try:
                size = int(ctrl.size())
                index_map = {}
                for pos in range(size):
                    item = ctrl.getListItem(pos)
                    try:
                        index_map[int(item.getProperty("PlexKM.Cast.Index") or 0)] = item
                    except Exception:
                        pass
                if size > 0 and size == len(displays) and set(index_map.keys()) == set(displays.keys()):
                    in_place = True
                    for idx, (name, display_name_v2701, role, display, valid_local) in displays.items():
                        if not valid_local:
                            continue
                        item = index_map[idx]
                        if str(item.getProperty("PlexKM.Cast.Thumb") or "") == display:
                            continue
                        item.setProperty("PlexKM.Cast.Thumb", display)
                        try:
                            item.setArt({"thumb": display, "icon": display})
                        except Exception:
                            pass
                        updated += 1
            except Exception:
                in_place = False
            if not in_place:
                cast_items = []
                for idx, (name, display_name_v2701, role, display, valid_local) in sorted(displays.items()):
                    item = xbmcgui.ListItem(label=display_name_v2701)
                    item.setProperty("PlexKM.Cast.Name", name)
                    item.setProperty("PlexKM.Cast.DisplayName", display_name_v2701)
                    item.setProperty("PlexKM.Cast.Role", role)
                    item.setProperty("PlexKM.Cast.Thumb", display)
                    item.setProperty("PlexKM.Cast.Index", str(idx))
                    try:
                        item.setArt({"thumb": display, "icon": display})
                    except Exception:
                        pass
                    cast_items.append(item)
                try:
                    ctrl.reset()
                except Exception:
                    pass
                if cast_items:
                    try:
                        ctrl.addItems(cast_items)
                    except Exception:
                        for item in cast_items:
                            try:
                                ctrl.addItem(item)
                            except Exception:
                                pass
                rebuilt = 1
            self._pkm_cast_native_last_fingerprint = None
            try:
                added = int(ctrl.size())
            except Exception:
                added = len(displays)
            self._info_set_property_all("PlexKM.Info.CastPanelReady", "1" if added > 0 else "")
            self._info_set_property_all("PlexKM.Info.CastReady", "1" if added > 0 else "")
            self._info_clear_property_all("PlexKM.Info.CastAwaitingImages")
            elapsed = max(0, self._now_ms() - int(rec.get("arm_ms") or self._now_ms()))
            _consume_r15()
            _log("INFO_CAST_PROGRESSIVE_FILL_R15 rating_key=%s token=%d phase=%s stage=%s control=%d named=%d real=%d pending=%d updated=%d rebuilt=%d elapsed_ms=%d" % (
                rk, token, phase or "-", rec.get("stage") or "-", control_id, named, real, pending, updated, rebuilt, elapsed
            ))
            if not final_r15:
                return True
            self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2629")
            self._info_clear_property_all("PlexKM.Info.CastAtomicPendingV2630")
            self._info_set_property_all("PlexKM.Info.CastAtomicReadyV2629", "1" if added > 0 else "")
            self._info_set_property_all("PlexKM.Info.CastAtomicReadyV2630", "1" if added > 0 else "")
            win.setProperty("PlexKM.KPI.InfoCastPlaceholderFirstFrame", "1")
            win.setProperty("PlexKM.KPI.InfoCastSequentialPopin", "1")
            win.setProperty("PlexKM.KPI.InfoCastAtomicReady", "1" if added > 0 else "0")
            win.setProperty("PlexKM.KPI.InfoCastAssetsReady", "1" if real == named else "0")
            win.setProperty("PlexKM.KPI.InfoCastTextureReady", "unknown")
            win.setProperty("PlexKM.KPI.InfoCastAtomicMs", str(int(elapsed)))
            win.setProperty("PlexKM.KPI.InfoCastUnknown", str(int(pending)))
            _log("INFO_CAST_ATOMIC_REVEAL_V2630 rating_key=%s token=%d control=%d named=%d real=%d confirmed_missing=%d unknown=0 added=%d elapsed_ms=%d placeholder_first_frame=1 sequential_popin=1 panel_reset_once=%d focus_write=0 progressive_r15=1" % (
                rk, token, control_id, named, real, pending, added, elapsed, rebuilt
            ))
            return True
        except Exception:
            _log("INFO_CAST_ATOMIC_REVEAL_FAILED_V2630 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _schedule_info_cast_prewarm_around_focus(self, li=None, reason=""):
        """V2505 stable-focus cast prewarm using an immutable GUI-thread snapshot.

        V248 disabled the old focus prewarm because its delayed worker retained a
        Kodi ListItem and read/mutated it after the wall could be reset.  Later
        cache workers already accept plain dict payloads, so capture every required
        ListItem field NOW on the GUI callback, then let the 120ms worker touch only
        Python data/cache files.  Fast navigation cancels by token before any work.
        """
        try:
            if li is None:
                return 0
            # Capture native ListItem fields synchronously.  The delayed worker below
            # must never dereference ``li``.
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return 0
            data_v2505 = {
                "rating_key": rk,
                "type": str(li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or ""),
                "title": str(li.getProperty("PlexKM.Title") or li.getLabel() or ""),
                "parent_rating_key": str(li.getProperty("PlexKM.ParentRatingKey") or ""),
                "grandparent_rating_key": str(li.getProperty("PlexKM.GrandparentRatingKey") or ""),
                "section_id": str(li.getProperty("PlexKM.SectionId") or ""),
                "actor_hint": str(li.getProperty("PlexKM.Cast1.Name") or ""),
                "genre_hint": str(li.getProperty("PlexKM.Genre") or ""),
                "search_token": str(li.getProperty("PlexKM.SearchPrewarmTokenV1783") or ""),
                "reason": "stable_focus_idle_v2505:%s" % (reason or "focus"),
                "priority": True,
            }
            self._cast_focus_idle_token_v1642 = int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0) + 1
            token = self._cast_focus_idle_token_v1642
            _log("CAST_PREWARM_STABLE_FOCUS_ARM_V2608 rating_key=%s delay_ms=80 immutable_snapshot=1 background_listitem_access=0 fast_role_url_prime=1 reason=%s" % (
                rk, reason or ""
            ))

            def _worker():
                _gate_held_v2800 = [None]
                try:
                    # V2800 (C): 80ms was shorter than the Shield key repeat
                    # (~600ms), so every focus step started a full prewarm and
                    # 33-44 threads fought the GUI.  On Android wait 400ms and
                    # keep waiting (max ~1.2s) while keys are still arriving;
                    # only one heavy prewarm may run at a time.
                    _android_v2800 = False
                    try:
                        _android_v2800 = bool(self._is_android_v2591())
                    except Exception:
                        _android_v2800 = False
                    xbmc.sleep(400 if _android_v2800 else 80)
                    if _android_v2800:
                        for _i_v2800 in range(4):
                            if token != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                                break
                            _la_v2800 = int(getattr(self, "_last_action_ms", 0) or 0)
                            _age_v2800 = (_pkm_speed_ms() - _la_v2800) if _la_v2800 > 0 else 100000
                            if _age_v2800 >= 300:
                                break
                            xbmc.sleep(300)
                    if token != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                        _log("CAST_PREWARM_STABLE_FOCUS_CANCEL_V2505 rating_key=%s reason=focus_moved" % rk)
                        return
                    if _pkm_playback_active_v1411() or self._settings_quiet_active_v1457():
                        return
                    if bool(getattr(self, "_widget_transition_active", False)):
                        _log("CAST_PREWARM_STABLE_FOCUS_DEFER_V2505 rating_key=%s reason=widget_transition_active" % rk)
                        return
                    if _android_v2800:
                        _gate_v2800 = self.__dict__.setdefault("_cast_prewarm_gate_v2800", threading.Semaphore(1))
                        if not _gate_v2800.acquire(timeout=2.0):
                            _log("CAST_PREWARM_GATE_BUSY_V2800 rating_key=%s action=skip" % rk)
                            return
                        _gate_held_v2800[0] = _gate_v2800
                        if token != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                            _log("CAST_PREWARM_STABLE_FOCUS_CANCEL_V2505 rating_key=%s reason=focus_moved_after_gate" % rk)
                            return
                    # Start the click's exact local metadata lookup off-GUI.
                    # Do not wait for Role/actor names/network to finish first.
                    ptype_click_prime = str(data_v2505.get("type") or "").strip().lower()
                    if ptype_click_prime == "movie":
                        self._info_click_db_preload_start(rk, token)
                    # v2609: arm TV episode preparation in parallel with cast.
                    # Rapid focus changes invalidate publication by token; DB upserts
                    # remain safe and useful for a later visit.
                    ptype_v2609 = str(data_v2505.get("type") or "").strip().lower()
                    if ptype_v2609 in ("show", "tv", "tvshow", "series", "episode", "season"):
                        tv_event_v2609 = threading.Event()
                        with self._info_atomic_asset_lock_v2609:
                            self._info_tv_prewarm_events_v2609[rk] = tv_event_v2609
                        _PKMHomeThreadV2151(
                            target=lambda: self._info_focus_tv_rows_prewarm_v2609(dict(data_v2505), token, tv_event_v2609),
                            name="PKMInfoTVFocusPrimeV2609", daemon=True
                        ).start()

                    remote_rec_v2608 = self._info_cast_remote_prime_v2608(
                        dict(data_v2505), reason="stable_focus_role_url_v2608", timeout=0.80
                    )
                    # Keep the remote cache immediately available for a fast click.
                    # Names are localized below on this background worker only.
                    try:
                        slots_ko = [dict(x or {}) for x in list((remote_rec_v2608 or {}).get("slots") or [])[:8]]
                        for slot_ko in slots_ko:
                            if token != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                                break
                            nm_ko = str(slot_ko.get("Name") or "").strip()
                            if nm_ko:
                                slot_ko["DisplayNameKo"] = self._actor_master_name_ko_v2702(nm_ko)
                        else:
                            rec_ko = dict((getattr(self, "_info_cast_remote_cache_v2608", {}) or {}).get(rk) or {})
                            if rec_ko.get("ts") == (remote_rec_v2608 or {}).get("ts") and slots_ko:
                                rec_ko["slots"] = slots_ko
                                self._info_cast_remote_cache_v2608[rk] = rec_ko
                                remote_rec_v2608 = rec_ko
                                _log("INFO_CLICK_KO_PREWARM_READY key=%s actors=%d thread=background" % (rk, len(slots_ko)))
                    except Exception:
                        _log("INFO_CLICK_KO_PREWARM_FAILED key=%s err=%s" % (
                            rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                    remote_ready_v2608 = int((remote_rec_v2608 or {}).get("ready") or 0)
                    if token != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                        _log("CAST_PREWARM_STABLE_FOCUS_CANCEL_V2505 rating_key=%s reason=focus_moved_before_lead" % rk)
                        return
                    if remote_ready_v2608 > 0:
                        lead_event_v2609 = threading.Event()
                        with self._info_atomic_asset_lock_v2609:
                            self._info_cast_lead_events_v2609[rk] = lead_event_v2609
                        _PKMHomeThreadV2151(
                            target=lambda: self._info_cast_lead_texture_prime_v2609(
                                rk, dict(remote_rec_v2608), lead_event_v2609, reason="stable_focus_v2609"
                            ),
                            name="PKMInfoCastLeadV2609", daemon=True
                        ).start()
                    added = 0
                    # Missing Role portraits still use the existing heavier
                    # fallback, but it is no longer required for the lead rail.
                    if remote_ready_v2608 < 3 and token == int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                        added = self._schedule_info_cast_prewarm_for_data_v1339(
                            [dict(data_v2505)],
                            reason=data_v2505.get("reason") or "stable_focus_idle_v2505",
                            limit=1, priority=True
                        )
                    _log("CAST_PREWARM_STABLE_FOCUS_V2609 rating_key=%s delay_ms=80 remote_ready=%d lead_texture_prime=%d tv_rows_prime=%d full_worker_queued=%d immutable_snapshot=1" % (
                        rk, remote_ready_v2608, 1 if remote_ready_v2608 > 0 else 0,
                        1 if ptype_v2609 in ("show", "tv", "tvshow", "series", "episode", "season") else 0, int(added or 0)
                    ))
                    # v2508: run the two bounded movie-only DB preparations in
                    # this plain-data worker while cast prewarm proceeds in its
                    # own queue.  The click path consumes only a matching rk.
                    if str(data_v2505.get("type") or "").strip().lower() == "movie":
                        self._info_focus_movie_data_prewarm_v2508(dict(data_v2505), token)
                except Exception:
                    _log("CAST_PREWARM_STABLE_FOCUS_FAILED_V2505 rating_key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    try:
                        if _gate_held_v2800[0] is not None:
                            _gate_held_v2800[0].release()
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_worker, name="PlexKMCastStableFocusV2505", daemon=True).start()
            return 1
        except Exception:
            _log("CAST_PREWARM_FOCUS_QUEUE_FAILED_V2505 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0

    def _info_cast_prewarm_worker(self):
        try:
            monitor = xbmc.Monitor()
        except Exception:
            monitor = None
        try:
            processed = 0
            while True:
                if self._settings_quiet_active_v1457():
                    _log("CAST_PREWARM_WORKER_PAUSE_SETTINGS_QUIET_V1457 processed=%d" % processed)
                    try:
                        with self._info_cast_prewarm_lock:
                            self._info_cast_prewarm_queue = []
                            self._info_cast_prewarm_worker_count = max(0, _safe_int(getattr(self, "_info_cast_prewarm_worker_count", 1), 1) - 1)
                            if self._info_cast_prewarm_worker_count <= 0:
                                self._info_cast_prewarm_worker_running = False
                    except Exception:
                        pass
                    break
                if _pkm_playback_active_v1411():
                    _log("CAST_PREWARM_WORKER_PAUSE_PLAYBACK_ACTIVE_V1411 processed=%d" % processed)
                    try:
                        with self._info_cast_prewarm_lock:
                            self._info_cast_prewarm_worker_count = max(0, _safe_int(getattr(self, "_info_cast_prewarm_worker_count", 1), 1) - 1)
                            if self._info_cast_prewarm_worker_count <= 0:
                                self._info_cast_prewarm_worker_running = False
                    except Exception:
                        pass
                    break
                data = None
                try:
                    with self._info_cast_prewarm_lock:
                        if not self._info_cast_prewarm_queue:
                            self._info_cast_prewarm_worker_count = max(0, _safe_int(getattr(self, "_info_cast_prewarm_worker_count", 1), 1) - 1)
                            if self._info_cast_prewarm_worker_count <= 0:
                                self._info_cast_prewarm_worker_running = False
                            break
                        data = self._info_cast_prewarm_queue.pop(0)
                except Exception:
                    data = None
                if not data:
                    continue
                try:
                    if monitor is not None and monitor.abortRequested():
                        break
                except Exception:
                    pass
                try:
                    if _pkm_playback_active_v1411():
                        _log("CAST_PREWARM_WORKER_ABORT_BEFORE_ITEM_V1450 processed=%d" % processed)
                        try:
                            with self._info_cast_prewarm_lock:
                                self._info_cast_prewarm_queue = []
                        except Exception:
                            pass
                        break
                    rk = str(data.get("rating_key") or "").strip()
                    if not rk:
                        continue
                    _search_token_v1783 = str(data.get("search_token") or "")
                    if _search_token_v1783 and _search_token_v1783 != str(getattr(self, "_search_cast_prewarm_token_v1781", "") or ""):
                        _log("CAST_PREWARM_STALE_SEARCH_SKIP_V1783 rating_key=%s" % rk)
                        continue
                    if rk in self._info_cast_prewarm_running:
                        continue
                    self._info_cast_prewarm_running.add(rk)
                    try:
                        self._info_cast_prewarm_build_one(data)
                        processed += 1
                    finally:
                        try:
                            self._info_cast_prewarm_running.discard(rk)
                        except Exception:
                            pass
                except Exception:
                    _log("CAST_PREWARM_ITEM_FAILED_V1339 data=%s err=%s" % (_short_log_value(data, 160), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            _log("CAST_PREWARM_WORKER_DONE_V1340 processed=%d" % processed)
        except Exception:
            try:
                with self._info_cast_prewarm_lock:
                    self._info_cast_prewarm_worker_count = max(0, _safe_int(getattr(self, "_info_cast_prewarm_worker_count", 1), 1) - 1)
                    if self._info_cast_prewarm_worker_count <= 0:
                        self._info_cast_prewarm_worker_running = False
            except Exception:
                try:
                    self._info_cast_prewarm_worker_running = False
                except Exception:
                    pass
            _log("CAST_PREWARM_WORKER_FAILED_V1340 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _info_cast_prewarm_build_one(self, data):
        start = time.time()
        rk = str((data or {}).get("rating_key") or "").strip()
        if not rk:
            return False
        if self._settings_quiet_active_v1457():
            _log("CAST_PREWARM_BUILD_ABORT_SETTINGS_QUIET_V1457 rating_key=%s" % rk)
            return False
        if _pkm_playback_active_v1411():
            _log("CAST_PREWARM_BUILD_ABORT_PLAYBACK_ACTIVE_V1450 rating_key=%s" % rk)
            return False
        cache = getattr(self, "_info_cast_prewarm_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._info_cast_prewarm_cache = cache
        try:
            rec = cache.get(rk) or {}
            if isinstance(rec, dict) and rec.get("ready", 0):
                # v2542: a warm cast cache used to return before actor #1 media-ahead
                # could be armed.  Reuse the cached immutable slot immediately so a
                # cold ActorProfile can still prepare while the user is on Home/Info.
                try:
                    _cache_reason_v2542 = str((data or {}).get("reason") or "")
                    _cache_slots_v2542 = list(rec.get("slots") or [])
                    if "stable_focus_idle_v2505" in _cache_reason_v2542 and _cache_slots_v2542:
                        _cache_first_v2542 = dict(_cache_slots_v2542[0] or {})
                        _cache_name_v2542 = str(_cache_first_v2542.get("Name") or "").strip()
                        _cache_thumb_v2542 = str(_cache_first_v2542.get("LocalThumb") or _cache_first_v2542.get("OriginalThumb") or "").strip()
                        if _cache_name_v2542:
                            _cache_armed_v2542 = self._schedule_actor_profile_item_prewarm_v2481(
                                _cache_name_v2542, source_rk=rk, fallback_thumb=_cache_thumb_v2542,
                                reason="media_cast_cache_early_v2542:%s" % _cache_reason_v2542, settle_ms_v2526=0
                            )
                            _log("ACTOR_PROFILE_EARLY_MEDIA_AHEAD_CACHE_V2542 rating_key=%s actor=%s local_thumb=%d armed=%d" % (
                                rk, _short_log_value(_cache_name_v2542,80),
                                1 if _cache_first_v2542.get("LocalThumb") else 0, 1 if _cache_armed_v2542 else 0
                            ))
                except Exception:
                    _log("ACTOR_PROFILE_EARLY_MEDIA_AHEAD_CACHE_FAILED_V2542 rating_key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                return True
        except Exception:
            pass

        reason = str((data or {}).get("reason") or "")
        priority = bool((data or {}).get("priority"))
        search_token_v1783 = str((data or {}).get("search_token") or "")
        focus_token_v1883 = str((data or {}).get("focus_token_v1883") or "")
        speculative_search_v1783 = bool(reason.startswith("search_"))
        fast_selected_search_v1875 = bool(reason.startswith("search_selected_direct_v1875"))

        def _focus_stale_v1883(stage):
            if not focus_token_v1883:
                return False
            current = str(getattr(self, "_search_focus_cast_token_v1878", "") or "")
            if current == focus_token_v1883:
                return False
            _log("CAST_PREWARM_FOCUS_STALE_CANCEL_V1883 rating_key=%s stage=%s token=%s current=%s" % (
                rk, stage, focus_token_v1883, current
            ))
            return True
        fast_search_no_profile_fallback_v1875 = bool(reason.startswith("search_"))
        if search_token_v1783 and search_token_v1783 != str(getattr(self, "_search_cast_prewarm_token_v1781", "") or ""):
            _log("CAST_PREWARM_BUILD_STALE_SEARCH_SKIP_V1783 rating_key=%s stage=begin" % rk)
            return False
        if _focus_stale_v1883("begin"):
            return False
        # v2189: current-work Role thumbs still win.  Missing portraits may
        # reuse the local actor index and then Plex's own people/search portrait.
        # The network stage is background/precompose work, never a live post-reveal
        # image mutation.
        allow_profile_fallback = True
        candidate_keys = self._info_cast_prewarm_candidate_keys_for_item(data)
        slots = []
        source_key = ""
        request_ms = 0.0
        first_db_slots = []
        first_db_key = ""
        first_slots = []
        first_slots_key = ""
        for key in candidate_keys:
            try:
                if _focus_stale_v1883("before_metadata"):
                    return False
                if _pkm_playback_active_v1411():
                    _log("CAST_PREWARM_BUILD_ABORT_PLAYBACK_ACTIVE_V1450 rating_key=%s source_key=%s stage=metadata" % (rk, key))
                    return False
                db_slots = self._info_cast_db_actor_slots_v1342(key, max_count=8)
                db_thumb_count = self._info_cast_thumb_count_v1343(db_slots)
                if db_slots and not first_db_slots:
                    first_db_slots = db_slots
                    first_db_key = key
                t0 = time.time()
                root = core.plex_request_xml(
                    "/library/metadata/%s" % key,
                    params={"includeGuids": 1, "includeCollections": 1},
                    timeout=0.55 if speculative_search_v1783 else 1.6,
                    log_failures=False,
                )
                request_ms += (time.time() - t0) * 1000.0
                if _focus_stale_v1883("after_metadata"):
                    return False
                node = _first_metadata_node(root)
                test_slots = _extract_cast_slots(node, max_count=8) if node is not None else []
                if test_slots:
                    try:
                        db_thumb_by_name = {str((x or {}).get("Name") or "").strip(): _clean_external_image_url((x or {}).get("Thumb") or "") for x in (db_slots or [])}
                        for sl in test_slots:
                            if sl and not _clean_external_image_url((sl or {}).get("Thumb") or ""):
                                nm = str((sl or {}).get("Name") or "").strip()
                                if nm and db_thumb_by_name.get(nm):
                                    sl["Thumb"] = db_thumb_by_name.get(nm)
                                    sl["RawThumb"] = db_thumb_by_name.get(nm)
                                    sl["Source"] = "db_thumb_merge_v1342"
                    except Exception:
                        pass
                    # v1876: fill blank Role thumbs from PKM's already-indexed
                    # exact actor-name cache before deciding this source is partial.
                    try:
                        missing_names_v1876 = [
                            str((sl or {}).get("Name") or "").strip()
                            for sl in test_slots
                            if str((sl or {}).get("Name") or "").strip()
                            and not _clean_external_image_url((sl or {}).get("Thumb") or "")
                        ]
                        if missing_names_v1876:
                            local_map_v1876 = self._local_actor_thumb_map_v1876(
                                missing_names_v1876, preferred_rating_keys=candidate_keys
                            )
                            for sl in test_slots:
                                nm = str((sl or {}).get("Name") or "").strip()
                                if nm and not _clean_external_image_url((sl or {}).get("Thumb") or ""):
                                    local_thumb_v1876 = _clean_external_image_url(local_map_v1876.get(nm) or "")
                                    if local_thumb_v1876:
                                        sl["Thumb"] = local_thumb_v1876
                                        sl["RawThumb"] = local_thumb_v1876
                                        sl["Source"] = "pkm_local_actor_db_v1876"
                    except Exception:
                        _log("CAST_LOCAL_ACTOR_MERGE_FAILED_V1876 rating_key=%s source_key=%s err=%s" % (
                            rk, key, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                    thumb_count = self._info_cast_thumb_count_v1343(test_slots)
                    if test_slots and not first_slots:
                        first_slots = test_slots
                        first_slots_key = key
                    if thumb_count > 0:
                        slots = test_slots
                        source_key = key
                        if key != rk:
                            _log("CAST_PREWARM_CONTINUE_CANONICAL_SOURCE_V1343 rating_key=%s source_key=%s thumbs=%d reason=%s" % (
                                rk, key, thumb_count, reason
                            ))
                        break
                    # v1343: onDeck/continue metadata often returns actor names but
                    # blank Role thumbs.  Do not stop here; continue to duplicate
                    # canonical library keys, which is what recommendation widgets use.
                    _log("CAST_PREWARM_SOURCE_NO_THUMBS_V1343 rating_key=%s source_key=%s slots=%d reason=%s action=try_next_candidate" % (
                        rk, key, len(test_slots), reason
                    ))
                    continue
                if db_slots:
                    if db_thumb_count > 0:
                        slots = db_slots
                        source_key = key
                        if key != rk:
                            _log("CAST_PREWARM_CONTINUE_CANONICAL_DB_SOURCE_V1343 rating_key=%s source_key=%s thumbs=%d reason=%s" % (
                                rk, key, db_thumb_count, reason
                            ))
                        break
                    if db_slots and not first_slots:
                        first_slots = db_slots
                        first_slots_key = key
                    _log("CAST_PREWARM_DB_SOURCE_NO_THUMBS_V1343 rating_key=%s source_key=%s slots=%d reason=%s action=try_next_candidate" % (
                        rk, key, len(db_slots), reason
                    ))
            except Exception:
                request_ms += 550.0 if speculative_search_v1783 else 1600.0
                continue
        if not slots and first_slots:
            slots = first_slots
            source_key = first_slots_key or rk
        if not slots and first_db_slots:
            slots = first_db_slots
            source_key = first_db_key or rk

        if not slots:
            cache[rk] = {"ts": self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000), "slots": [], "ready": 0, "source_key": source_key or "", "negative": 1, "reason": reason}
            self._info_cast_prewarm_mark_negative_v1340(rk, reason="slots0:%s" % reason)
            _log("CAST_PREWARM_DONE_V1342 rating_key=%s source_key=%s slots=0 ready=0 downloaded=0 elapsed=%.1fms request_ms=%.1f reason=%s action=negative_cache" % (
                rk, source_key or "", (time.time() - start) * 1000.0, request_ms, reason), xbmc.LOGWARNING)
            return False

        if search_token_v1783 and search_token_v1783 != str(getattr(self, "_search_cast_prewarm_token_v1781", "") or ""):
            _log("CAST_PREWARM_BUILD_STALE_SEARCH_SKIP_V1783 rating_key=%s stage=before_images" % rk)
            return False

        if _focus_stale_v1883("before_local_fallback"):
            return False

        # v1878: one bulk local actor lookup is the final fallback pass.  Do not
        # repeat a DB query, TMDb Helper scan, or Plex people lookup per blank
        # actor slot.  Names still unresolved after this pass become placeholders.
        try:
            missing_final_v1878 = [
                str((sl or {}).get("Name") or "").strip()
                for sl in (slots or [])[:8]
                if str((sl or {}).get("Name") or "").strip()
                and not _clean_external_image_url((sl or {}).get("Thumb") or "")
            ]
            if missing_final_v1878:
                final_local_map_v1878 = self._local_actor_thumb_map_v1876(
                    missing_final_v1878, preferred_rating_keys=candidate_keys
                )
                for sl in (slots or [])[:8]:
                    nm = str((sl or {}).get("Name") or "").strip()
                    if nm and not _clean_external_image_url((sl or {}).get("Thumb") or ""):
                        local_thumb_v1878 = _clean_external_image_url(final_local_map_v1878.get(nm) or "")
                        if local_thumb_v1878:
                            sl["Thumb"] = local_thumb_v1878
                            sl["RawThumb"] = local_thumb_v1878
                            sl["Source"] = "pkm_local_actor_db_v1878_final_bulk"
                unresolved_v1878 = sum(
                    1 for sl in (slots or [])[:8]
                    if str((sl or {}).get("Name") or "").strip()
                    and not _clean_external_image_url((sl or {}).get("Thumb") or "")
                )
                _log("CAST_MISSING_PORTRAIT_FINAL_BULK_V1878 rating_key=%s requested=%d resolved=%d placeholder=%d network=0 tmdb_scan=0" % (
                    rk, len(missing_final_v1878), len(final_local_map_v1878 or {}), unresolved_v1878
                ))
        except Exception:
            _log("CAST_MISSING_PORTRAIT_FINAL_BULK_FAILED_V1878 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        # v2298: stable-focus prewarm is local-only. Current-work Role thumbs
        # plus already-indexed cross-library portraits are sufficient for the
        # first Info paint; missing actors become placeholders immediately.
        fallback_hits = 0
        if allow_profile_fallback:
            try:
                fallback_hits = self._resolve_missing_cast_profiles_from_plex_v2189(
                    slots,
                    rating_key=rk,
                    reason="cast_prewarm:%s" % (reason or ""),
                    allow_people_search=False,
                    allow_global_network=False,
                )
            except Exception:
                fallback_hits = 0
                _log("CAST_PREWARM_PLEX_PEOPLE_FAILED_V2189 rating_key=%s err=%s" % (
                    rk, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        jobs = []
        record_slots = []
        for idx, slot in enumerate(slots[:8], 1):
            name = str((slot or {}).get("Name") or "").strip()
            role = str((slot or {}).get("Role") or "").strip()
            original = _clean_external_image_url((slot or {}).get("Thumb") or "")
            if name and not original:
                # v2189: Role thumb, local actor index, and Plex people/search
                # have all missed.  Only now is a placeholder legitimate.
                _log("CAST_PREWARM_MISSING_PORTRAIT_AFTER_PLEX_V2189 rating_key=%s source_key=%s slot=%d name=%s" % (
                    rk, source_key or "", idx, _short_log_value(name, 80)
                ))
            local = self._existing_cast_cache_path(original) if original else ""
            entry = {"Name": name, "Role": role, "OriginalThumb": original, "LocalThumb": local, "SourceRatingKey": source_key or rk}
            record_slots.append(entry)
            if name and original and not local and original.lower().startswith(("http://", "https://")):
                jobs.append((idx, original, entry))

        # v2542: actor #1 used to wait until all 8 cast portraits finished
        # downloading before its TMDb profile prewarm was armed.  The V2541 log
        # measured ~0.8 s of avoidable runway loss.  Arm actor #1 as soon as the
        # immutable cast slots are known; cast portrait downloads continue in
        # parallel.  The old post-download arm below stays as a deduped safety net.
        try:
            _reason_v2542 = str(reason or "")
            if "stable_focus_idle_v2505" in _reason_v2542 and record_slots:
                _first_actor_v2542 = dict(record_slots[0] or {})
                _first_name_v2542 = str(_first_actor_v2542.get("Name") or "").strip()
                _first_thumb_v2542 = str(_first_actor_v2542.get("LocalThumb") or _first_actor_v2542.get("OriginalThumb") or "").strip()
                if _first_name_v2542:
                    _early_t0_v2542 = time.perf_counter()
                    _armed_v2542 = self._schedule_actor_profile_item_prewarm_v2481(
                        _first_name_v2542, source_rk=rk, fallback_thumb=_first_thumb_v2542,
                        reason="media_cast_early_v2542:%s" % _reason_v2542, settle_ms_v2526=0
                    )
                    _log("ACTOR_PROFILE_EARLY_MEDIA_AHEAD_ARM_V2542 rating_key=%s actor=%s local_thumb=%d cast_jobs_pending=%d armed=%d elapsed_ms=%.1f" % (
                        rk, _short_log_value(_first_name_v2542,80),
                        1 if _first_actor_v2542.get("LocalThumb") else 0, len(jobs),
                        1 if _armed_v2542 else 0, (time.perf_counter()-_early_t0_v2542)*1000.0
                    ))
        except Exception:
            _log("ACTOR_PROFILE_EARLY_MEDIA_AHEAD_ARM_FAILED_V2542 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        downloaded = 0
        if _focus_stale_v1883("before_images"):
            return False
        if jobs and _pkm_playback_active_v1411():
            _log("CAST_PREWARM_DOWNLOAD_ABORT_PLAYBACK_ACTIVE_V1450 rating_key=%s jobs=%d" % (rk, len(jobs)))
            jobs = []
        if jobs:
            worker_cap = (1 if _is_android_platform_v1931() else (6 if fast_selected_search_v1875 else 4))
            workers = max(1, min(worker_cap, len(jobs)))
            if speculative_search_v1783:
                _log("CAST_PREWARM_FAST_SEARCH_POLICY_V1875 rating_key=%s selected=%d jobs=%d workers=%d fallback=%d" % (
                    rk, 1 if fast_selected_search_v1875 else 0, len(jobs), workers, 1 if allow_profile_fallback else 0
                ))
            # PKM_CAST_PROGRESSIVE_R15: stable-focus prewarm yields the shared
            # artwork lanes to the open Info cast rail and visible posters.
            with ThreadPoolExecutor(max_workers=workers) as executor:
                future_map = {executor.submit(self._download_cast_thumb_to_cache, thumb, slot_index=idx,
                                              priority=pkm_artwork_scheduler.PRIORITY_PREWARM): entry for idx, thumb, entry in jobs}
                for future in as_completed(future_map):
                    entry = future_map[future]
                    try:
                        local = future.result() or ""
                    except Exception:
                        local = ""
                    if local and not local.lower().startswith(("http://", "https://")):
                        entry["LocalThumb"] = local
                        downloaded += 1
        ready = 0
        for entry in record_slots:
            if entry.get("Name") and entry.get("LocalThumb"):
                ready += 1
        if _focus_stale_v1883("before_cache_commit"):
            return False
        rec = {
            "ts": self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000),
            "slots": record_slots,
            "ready": ready,
            "downloaded": downloaded,
            "source_key": source_key or rk,
            "fallback_hits": fallback_hits,
            "negative": 0,
            "reason": reason,
        }
        cache[rk] = rec
        self._info_cast_prewarm_cache = cache
        # v2526: once stable Home/section cast data is ready, actor #1 is already
        # the exact target Kodi will focus first inside Info. Start its complete
        # TMDb/profile preparation NOW instead of waiting until the actor row gets
        # focus several seconds later. This is the only way a cold external profile
        # can be complete at click time without revealing a partial actor page.
        try:
            _reason_v2526 = str(reason or "")
            if "stable_focus_idle_v2505" in _reason_v2526 and record_slots:
                _first_actor_v2526 = dict(record_slots[0] or {})
                _first_name_v2526 = str(_first_actor_v2526.get("Name") or "").strip()
                _first_thumb_v2526 = str(_first_actor_v2526.get("LocalThumb") or _first_actor_v2526.get("OriginalThumb") or "").strip()
                if _first_name_v2526:
                    _armed_v2526 = self._schedule_actor_profile_item_prewarm_v2481(
                        _first_name_v2526, source_rk=rk, fallback_thumb=_first_thumb_v2526,
                        reason="media_cast_ahead_v2526:%s" % _reason_v2526, settle_ms_v2526=0
                    )
                    _log("ACTOR_PROFILE_MEDIA_AHEAD_ARM_V2526 rating_key=%s actor=%s local_thumb=%d settle_ms=0 armed=%d source=stable_media_cast" % (
                        rk, _short_log_value(_first_name_v2526,80),
                        1 if _first_actor_v2526.get("LocalThumb") else 0, 1 if _armed_v2526 else 0
                    ))
        except Exception:
            _log("ACTOR_PROFILE_MEDIA_AHEAD_ARM_FAILED_V2526 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        _log("CAST_PREWARM_DONE_V1342 rating_key=%s source_key=%s slots=%d ready=%d downloaded=%d fallback=%d elapsed=%.1fms request_ms=%.1f reason=%s title=%s" % (
            rk, source_key or "", len(record_slots), ready, downloaded, fallback_hits, (time.time() - start) * 1000.0, request_ms,
            reason, _short_log_value((data or {}).get("title") or "", 80)))
        return ready > 0

    def _apply_info_cast_prewarm_cache_to_li(self, li, reason=""):
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            cache = getattr(self, "_info_cast_prewarm_cache", {}) or {}
            rec = cache.get(rk) or {}
            slots = rec.get("slots") if isinstance(rec, dict) else []
            if not slots:
                return False
            applied = 0
            ready = 0
            cast_names = []
            source_key = str(rec.get("source_key") or rk)
            for idx in range(1, 9):
                slot = slots[idx - 1] if idx <= len(slots) else {}
                name = str((slot or {}).get("Name") or "")
                role = str((slot or {}).get("Role") or "")
                original = _clean_external_image_url((slot or {}).get("OriginalThumb") or "")
                local = str((slot or {}).get("LocalThumb") or "")
                if self._is_legacy_cast_cache_thumb_v1349(local):
                    local = ""
                if name:
                    cast_names.append(name)
                    applied += 1
                    if local:
                        ready += 1
                    # v1341: Info first paint consumes prepared local PNG only.
                    # If Plex has no portrait/local cache, publish the same high-quality
                    # placeholder circle instead of an empty/low-quality stretched thumb.
                    # PKM_UHD_CAST_CONTINUE_PRESENTATION_U5_20261011:
                    # Keep Plex's already-resolved portrait URL; never wait for a new download.
                    display = local or original or self._cast_placeholder_thumb()  # V2637
                    li.setProperty("PlexKM.Cast%d.Name" % idx, name)
                    li.setProperty("PlexKM.Cast%d.Role" % idx, role)
                    li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, original)
                    li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, local)
                    li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, "prewarm_v1336")
                    li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, source_key)
                    li.setProperty("PlexKM.Cast%d.Thumb" % idx, display)
                else:
                    li.setProperty("PlexKM.Cast%d.Name" % idx, "")
                    li.setProperty("PlexKM.Cast%d.Role" % idx, "")
                    li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, "")
                    li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, "")
                    li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, "")
                    li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, "")
                    li.setProperty("PlexKM.Cast%d.Thumb" % idx, "")
            if cast_names:
                li.setProperty("PlexKM.Cast", " / ".join(cast_names))
            _log("CAST_PREWARM_APPLY_V1342 rating_key=%s applied=%d ready=%d source_key=%s reason=%s" % (
                rk, applied, ready, source_key, reason or ""))
            return applied > 0
        except Exception:
            _log("CAST_PREWARM_APPLY_FAILED_V1339 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _reset_info_cast_panel(self, reason=""):
        """Clear cast panel and display-cast properties when a different Info item opens."""
        try:
            # v2066: movie cast panel 6100 and TV cast panel 6110 are isolated
            # XML controls but share the exact same ListItem/photo pipeline.
            for _cast_control_id_v2066 in (6100, 6110):
                try:
                    ctrl = self.getControl(_cast_control_id_v2066)
                    ctrl.reset()
                except Exception:
                    pass
            win = xbmcgui.Window(10000)
            for idx in range(1, 9):
                for subkey in ("Name", "Role", "Thumb"):
                    try:
                        self._info_clear_property_all("PlexKM.Info.DisplayCast%d.%s" % (idx, subkey))
                    except Exception:
                        pass
                for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                    try:
                        self._info_clear_property_all("PlexKM.Info.Cast%d.%s" % (idx, subkey))
                    except Exception:
                        pass
            for prop in (
                "PlexKM.Info.CastReady", "PlexKM.Info.CastPanelReady", "PlexKM.Info.CastAwaitingImages",
                "PlexKM.Info.CastAtomicPendingV2629", "PlexKM.Info.CastAtomicReadyV2629"
            ):
                try:
                    win.clearProperty(prop)
                    self.clearProperty(prop)
                except Exception:
                    pass
            _log("CAST_PANEL_RESET reason=%s" % (reason or ""))
        except Exception:
            _log("CAST_PANEL_RESET_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _prepare_info_cast_display_snapshot(self, li, stage_only=False, allow_download=True):
        """Prepare the visible info cast row as one local-circle snapshot.

        v2143 stage_only=True performs only target ListItem/cache preparation.
        It never writes PlexKM.Info.* properties and never mutates the 6100/6110
        native cast panel, so a completed parent Info can remain on screen while
        slow actor-circle downloads finish.

        v2146 first-paint rule:
        - DisplayCast*.Thumb never points at a remote HTTP image.
        - If Plex supplies an actor thumb, the selected Info waits on the still
          visible source surface until that thumb is cached locally.
        - Placeholder is used only when no usable Plex/local thumb exists after
          metadata repair or the actual image fetch fails.
        - All visible cast slots are finalized before the Info surface fades in;
          there is no actor-photo pop-in after reveal.
        - v1334: sync DisplayCast/Cast/CastReady to Window(10000), Window(13000),
          and self so skin includes that read Window.Property do not see an empty
          cast row while Python panel 6100 is already populated.
        """
        try:
            try:
                self._apply_info_cast_remote_prime_v2608(li, reason="display_snapshot_v2608")
            except Exception:
                pass
            win = xbmcgui.Window(10000)
            rating_key = li.getProperty("PlexKM.RatingKey") or ""
            active_key = win.getProperty("PlexKM.Info.RatingKey") or self.getProperty("PlexKM.Info.RatingKey") or ""
            if (not stage_only) and active_key and rating_key and active_key != rating_key:
                _log("CAST_CACHE snapshot_skip reason=stale_begin rating_key=%s active=%s" % (rating_key, active_key))
                return
            start = time.time()
            slots = []
            cleared = 0
            cast_items = []
            _pc_direct_atomic_v2617 = bool(
                (not allow_download) and (not self._is_android_v2591()) and (not self._uhd_kpi_proxy_v2605())
            )

            # First pass: resolve current item cast and collect remote thumbs.
            for idx in range(1, 9):
                name = li.getProperty("PlexKM.Cast%d.Name" % idx) or ""
                role = li.getProperty("PlexKM.Cast%d.Role" % idx) or ""
                original_thumb = li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or ""
                current_thumb = li.getProperty("PlexKM.Cast%d.Thumb" % idx) or ""
                if current_thumb and current_thumb.lower().startswith(("http://", "https://")):
                    original_thumb = current_thumb
                elif not original_thumb and current_thumb and not self._is_cast_placeholder_thumb(current_thumb):
                    original_thumb = current_thumb

                if not name:
                    cleared += 1
                    slots.append({"idx": idx, "name": "", "role": "", "thumb": "", "source": "", "local": ""})
                    continue

                thumb = original_thumb or current_thumb
                if _pc_direct_atomic_v2617:
                    # V2617 PC reference: Plex Role thumb is authoritative for the
                    # first frame. A Role with no thumb is a legitimate placeholder;
                    # do not spend tens of milliseconds searching other local works
                    # before Info becomes interactive. Background warmers may enrich
                    # future opens without mutating this atomic first frame.
                    if thumb and not self._is_cast_placeholder_thumb(thumb):
                        thumb_source = "plex_role_direct_v2617"
                    else:
                        thumb = ""
                        thumb_source = "placeholder_no_role_v2617"
                else:
                    thumb, thumb_source = self._resolve_cast_thumb_fallback(
                        name, thumb, slot_index=idx, rating_key=rating_key, allow_network=False
                    )
                if thumb and not original_thumb and not self._is_cast_placeholder_thumb(thumb):
                    original_thumb = thumb
                local_thumb = self._existing_cast_cache_path(thumb) if thumb else ""
                slots.append({
                    "idx": idx,
                    "name": name,
                    "role": role,
                    "thumb": thumb or "",
                    "source": thumb_source,
                    "original": original_thumb or thumb or "",
                    "local": local_thumb or "",
                })

            # v2298: after current-work Role thumbs, reuse only portraits already
            # indexed from other Plex works. Never run actor-name People searches
            # or candidate-work network walks while Info is opening.
            if _pc_direct_atomic_v2617:
                _log("INFO_CAST_MISSING_LOCAL_SCAN_BYPASS_V2617 rating_key=%s slots=%d policy=role_url_or_placeholder first_frame=atomic" % (
                    rating_key, len([x for x in slots if x.get("name")])
                ))
            else:
                try:
                    self._resolve_missing_cast_profiles_from_plex_v2189(
                        slots,
                        rating_key=rating_key,
                        reason="info_first_paint_stage" if stage_only else "info_first_paint",
                        allow_people_search=False,
                        allow_global_network=False,
                    )
                except Exception:
                    _log("CAST_PLEX_PEOPLE_FIRST_PAINT_FAILED_V2189 rating_key=%s err=%s" % (
                        rating_key, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

            # Second pass: v2146 actor photos are part of the atomic first paint.
            # Existing local files are reused immediately.  Any named slot with a
            # real remote thumb is fetched in parallel before reveal.
            jobs = []
            if allow_download:
                for slot in slots:
                    thumb = slot.get("thumb") or ""
                    if slot.get("name") and not slot.get("local") and thumb.lower().startswith(("http://", "https://")):
                        jobs.append(slot)
            downloaded = 0
            if jobs:
                try:
                    _busy_token_v2146 = str(getattr(self, "_info_global_busy_token_v2145", "") or "")
                    if _busy_token_v2146:
                        _log("INFO_CAST_FIRST_PAINT_SPINNER_DEFER_V2482 rating_key=%s jobs=%d threshold_ms=1000 source_surface_held=1 early_promote=0" % (
                            rating_key, len(jobs)
                        ))
                except Exception:
                    pass
                max_workers = max(1, min(1 if _is_android_platform_v1931() else 8, len(jobs)))
                _log("CAST_CACHE_WORKERS_V1931 jobs=%d workers=%d android=%d pil_android=0" % (
                    len(jobs), max_workers, 1 if _is_android_platform_v1931() else 0
                ))
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    future_map = {
                        executor.submit(self._download_cast_thumb_to_cache, slot.get("thumb") or "", slot_index=slot.get("idx") or 0): slot
                        for slot in jobs
                    }
                    for future in as_completed(future_map):
                        slot = future_map[future]
                        try:
                            local = future.result() or ""
                        except Exception:
                            local = ""
                        # Only local files or non-http placeholder-style paths are valid for DisplayCast.
                        if local and not local.lower().startswith(("http://", "https://")):
                            slot["local"] = local
                            downloaded += 1

            ready = 0
            placeholders = 0
            for slot in slots:
                idx = slot.get("idx") or 0
                name = slot.get("name") or ""
                role = slot.get("role") or ""
                thumb = slot.get("thumb") or ""
                local_thumb = slot.get("local") or ""
                source = slot.get("source") or ""
                original = slot.get("original") or thumb or ""
                if not name:
                    if not stage_only:
                        try:
                            for subkey in ("Name", "Role", "Thumb"):
                                self._info_clear_property_all("PlexKM.Info.DisplayCast%d.%s" % (idx, subkey))
                            for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                                self._info_clear_property_all("PlexKM.Info.Cast%d.%s" % (idx, subkey))
                        except Exception:
                            pass
                    continue

                if local_thumb:
                    display_thumb = local_thumb
                    ready += 1
                elif thumb and not self._is_cast_placeholder_thumb(thumb) and not self._is_legacy_cast_cache_thumb_v1349(thumb) and not str(thumb).lower().startswith(("http://", "https://")):
                    display_thumb = thumb
                    ready += 1
                elif thumb and not self._is_cast_placeholder_thumb(thumb) and str(thumb).lower().startswith(("http://", "https://")):
                    # V2642: Plex visual parity.  A real Plex Role.thumb is already
                    # authoritative display metadata.  Publish the HTTP(S) URL
                    # directly and let Kodi own texture/cache loading.  Do not
                    # replace a known Plex portrait with a PKM placeholder.
                    display_thumb = thumb
                    ready += 1
                else:
                    display_thumb = self._cast_placeholder_thumb()
                    placeholders += 1

                try:
                    li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, source)
                    li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, original or "")
                    li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, local_thumb or "")
                    li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, rating_key)
                    li.setProperty("PlexKM.Cast%d.Thumb" % idx, display_thumb)
                except Exception:
                    pass

                if not stage_only:
                    try:
                        cast_li = xbmcgui.ListItem(label=name)
                        cast_li.setProperty("PlexKM.Cast.Name", name or "")
                        cast_li.setProperty("PlexKM.Cast.Role", role or "")
                        cast_li.setProperty("PlexKM.Cast.Thumb", display_thumb or self._cast_placeholder_thumb())
                        cast_li.setProperty("PlexKM.Cast.Index", str(idx))
                        cast_items.append(cast_li)
                    except Exception:
                        pass
                    try:
                        self._info_set_property_all("PlexKM.Info.DisplayCast%d.Name" % idx, name)
                        self._info_set_property_all("PlexKM.Info.DisplayCast%d.Role" % idx, role)
                        self._info_set_property_all("PlexKM.Info.DisplayCast%d.Thumb" % idx, display_thumb)
                        self._info_set_property_all("PlexKM.Info.Cast%d.Name" % idx, name)
                        self._info_set_property_all("PlexKM.Info.Cast%d.Role" % idx, role)
                        self._info_set_property_all("PlexKM.Info.Cast%d.Thumb" % idx, display_thumb)
                        self._info_set_property_all("PlexKM.Info.Cast%d.ThumbSource" % idx, source)
                        self._info_set_property_all("PlexKM.Info.Cast%d.OriginalThumb" % idx, original or "")
                        self._info_set_property_all("PlexKM.Info.Cast%d.LocalThumb" % idx, local_thumb or "")
                        self._info_set_property_all("PlexKM.Info.Cast%d.SourceRatingKey" % idx, rating_key)
                    except Exception:
                        pass
            if stage_only:
                _log("INFO_CAST_FIRST_PAINT_REQUIRED_V2146 rating_key=%s stage=1 ready=%d downloaded=%d placeholders=%d cleared=%d network_wait=%d panel_mutation=0 elapsed=%.1fms" % (
                    rating_key, ready, downloaded, placeholders, cleared, 1 if allow_download else 0, (time.time() - start) * 1000.0))
                return True
            try:
                active_key = win.getProperty("PlexKM.Info.RatingKey") or self.getProperty("PlexKM.Info.RatingKey") or ""
                if active_key and rating_key and active_key != rating_key:
                    _log("CAST_CACHE snapshot_skip reason=stale_before_panel rating_key=%s active=%s" % (rating_key, active_key))
                    return
                panel_count = self._populate_info_cast_panel(cast_items=cast_items, reason="snapshot")
            except Exception:
                panel_count = -1
                _log("CAST_PANEL_POPULATE_FAILED reason=snapshot err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            _log("INFO_CAST_FIRST_PAINT_REQUIRED_V2146 rating_key=%s stage=0 ready=%d downloaded=%d placeholders=%d cleared=%d panel=%d network_wait=%d elapsed=%.1fms" % (
                rating_key, ready, downloaded, placeholders, cleared, panel_count, 1 if allow_download else 0, (time.time() - start) * 1000.0))
        except Exception:
            _log("CAST_CACHE snapshot_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            if not stage_only:
                try:
                    self._prepare_info_cast_cached_thumbs_fast(li)
                except Exception:
                    pass
            return False

    def _info_cast_control_id_v2074(self):
        """Return the one active cast-panel control for the current Info owner.

        Movie Info owns 6100. TV Info owns isolated 6110. All population/focus paths
        must resolve through this helper so the cast navigation target cannot diverge.
        """
        try:
            is_tv_v2074 = (
                self.getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(13000).getProperty("PlexKM.Info.IsTV") == "1"
            )
        except Exception:
            is_tv_v2074 = False
        return 6110 if is_tv_v2074 else 6100

    def _populate_info_cast_panel(self, cast_items=None, reason=""):
        """Populate the active Info cast panel (movie 6100 / TV 6110).

        v915: panel/list control must be populated explicitly before focus can land on it.
        v2066 isolated TV cast onto 6110. v2074 makes that control identity authoritative
        for both population and action-row focus so a stale 6100 target cannot steal focus.
        """
        try:
            if cast_items is None:
                cast_items = []
                win = xbmcgui.Window(10000)
                for idx in range(1, 9):
                    name = win.getProperty("PlexKM.Info.DisplayCast%d.Name" % idx) or win.getProperty("PlexKM.Info.Cast%d.Name" % idx) or ""
                    if not name:
                        continue
                    role = win.getProperty("PlexKM.Info.DisplayCast%d.Role" % idx) or win.getProperty("PlexKM.Info.Cast%d.Role" % idx) or ""
                    thumb = win.getProperty("PlexKM.Info.DisplayCast%d.Thumb" % idx) or win.getProperty("PlexKM.Info.Cast%d.Thumb" % idx) or ""
                    if (not thumb or self._is_cast_placeholder_thumb(thumb) or self._is_legacy_cast_cache_thumb_v1349(thumb)
                            or thumb.lower().startswith(("http://", "https://"))):
                        # PKM_CAST_PROGRESSIVE_R15: a pending remote portrait shows the
                        # placeholder circle until the late fill swaps in the local file.
                        # v1351: reject old local cast_cache geometry here too.
                        # v1328: keep actor names visible even when Plex has no actor
                        # image.  v1327 skipped placeholder slots here, so a movie with
                        # valid cast names but no portraits opened with an empty Credits
                        # panel.  Use the built-in placeholder instead.
                        thumb = self._cast_placeholder_thumb()
                        _log("CAST_PANEL_USE_PLACEHOLDER_SLOT_V1328 reason=%s slot=%d name=%s" % (
                            reason or "", idx, _short_log_value(name, 80)
                        ))
                    li = xbmcgui.ListItem(label=name)
                    li.setProperty("PlexKM.Cast.Name", name or "")
                    li.setProperty("PlexKM.Cast.Role", role or "")
                    li.setProperty("PlexKM.Cast.Thumb", thumb)
                    li.setProperty("PlexKM.Cast.Index", str(idx))
                    cast_items.append(li)

            # v1284: keep cast rows when actor names exist even if no real
            # actor photo is available.  The XML should show the built-in actor
            # placeholder circle and the actor name.  Only a truly empty cast
            # list hides the Credits panel.
            if not cast_items:
                try:
                    self._info_clear_property_all("PlexKM.Info.CastPanelReady")
                except Exception:
                    pass
                _log("CAST_PANEL_EMPTY reason=%s action=hide_panel_no_names" % (reason or ""), xbmc.LOGWARNING)

            # v2075: Keep the existing eight-slot cast metadata/cache pipeline visible.
            # v2066 limited the final panel to the first three actors even though the
            # snapshot already prepares up to eight.  Show all eight without adding
            # any new network lookup or changing the three lead-actor works rows.
            cast_items = list(cast_items or [])[:8]

            # v2152: explicit snapshot items bypassed the older window-property
            # placeholder normalization above. A named actor could therefore reach
            # XML with an empty/legacy thumb and render as text with no circle at all.
            # Normalize every named item immediately before the one panel commit.
            _placeholder_v2152 = self._cast_placeholder_thumb()
            _forced_placeholder_v2152 = 0
            for _cast_item_v2152 in cast_items:
                try:
                    _name_v2152 = _cast_item_v2152.getProperty("PlexKM.Cast.Name") or _cast_item_v2152.getLabel() or ""
                    if not _name_v2152:
                        continue
                    _thumb_v2152 = _cast_item_v2152.getProperty("PlexKM.Cast.Thumb") or ""
                    if (not _thumb_v2152 or self._is_cast_placeholder_thumb(_thumb_v2152)
                            or self._is_legacy_cast_cache_thumb_v1349(_thumb_v2152)):
                        _cast_item_v2152.setProperty("PlexKM.Cast.Thumb", _placeholder_v2152)
                        _forced_placeholder_v2152 += 1
                except Exception:
                    pass
            if _forced_placeholder_v2152:
                _log("CAST_PANEL_PLACEHOLDER_ENFORCE_V2152 reason=%s forced=%d requested=%d" % (
                    reason or "", _forced_placeholder_v2152, len(cast_items)
                ))

            _cast_control_id_v2066 = self._info_cast_control_id_v2074()
            _is_tv_cast_v2066 = (_cast_control_id_v2066 == 6110)
            ctrl = self.getControl(_cast_control_id_v2066)
            _cast_native_fingerprint = (
                str(self.getProperty("PlexKM.Info.RatingKey") or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or ""),
                _cast_control_id_v2066,
                tuple((str(x.getProperty("PlexKM.Cast.Name") or x.getLabel() or ""),
                       str(x.getProperty("PlexKM.Cast.Role") or ""),
                       str(x.getProperty("PlexKM.Cast.Thumb") or "")) for x in cast_items),
            )
            if reason == "before_visible_v2629_atomic_ready":
                try:
                    if (getattr(self, "_pkm_cast_native_last_fingerprint", None) == _cast_native_fingerprint
                            and int(ctrl.size()) == len(cast_items)):
                        _log("INFO_CAST_DUPLICATE_REBIND_SKIP_VNEXT rating_key=%s control=%d unchanged=%d" % (
                            _cast_native_fingerprint[0], _cast_control_id_v2066, len(cast_items)))
                        return len(cast_items)
                except Exception:
                    pass
            try:
                ctrl.reset()
            except Exception:
                pass

            try:
                placeholder_count = 0
                total_count = len(cast_items or [])
                for _cast_item in cast_items or []:
                    try:
                        if self._is_cast_placeholder_thumb(_cast_item.getProperty("PlexKM.Cast.Thumb") or ""):
                            placeholder_count += 1
                    except Exception:
                        pass
                if total_count > 0 and placeholder_count >= total_count:
                    _log("CAST_PANEL_PLACEHOLDER_ONLY reason=%s requested=%d action=show_names_with_placeholder" % (
                        reason or "", total_count
                    ), xbmc.LOGINFO)
            except Exception:
                pass

            added = 0
            # Use addItem loop first. It is more broadly supported by Kodi Python
            # controls than addItems() for XML panel/list instances.
            for item in cast_items or []:
                try:
                    ctrl.addItem(item)
                    added += 1
                except Exception:
                    pass

            if added <= 0 and cast_items:
                try:
                    ctrl.addItems(cast_items)
                    try:
                        added = ctrl.size()
                    except Exception:
                        added = len(cast_items)
                except Exception:
                    pass

            try:
                self._info_set_property_all("PlexKM.Info.CastPanelReady", "1" if added > 0 else "")
            except Exception:
                pass
            if added == len(cast_items):
                self._pkm_cast_native_last_fingerprint = _cast_native_fingerprint
            else:
                self._pkm_cast_native_last_fingerprint = None
            _log("CAST_PANEL_POPULATE_V2075 reason=%s control=%d is_tv=%d requested=%d added=%d" % (reason or "", _cast_control_id_v2066, 1 if _is_tv_cast_v2066 else 0, len(cast_items or []), added))
            return added
        except Exception:
            _log("CAST_PANEL_POPULATE_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _prepare_info_cast_cached_thumbs_fast(self, li):
        """Build a frozen display snapshot from the *current* item only.

        Do not read PlexKM.Info.Cast* window properties here. They can belong to
        the previously opened info item and caused stale actor images to be
        reused under a different movie/episode.  v2146 finalizes missing remote
        images before first reveal; the open Info window never live-swaps actor
        images after it becomes visible.
        """
        try:
            try:
                self._apply_info_cast_prewarm_cache_to_li(li, reason="fast_snapshot_v1336")
            except Exception:
                pass
            try:
                self._apply_info_cast_remote_prime_v2608(li, reason="fast_snapshot_v2608")
            except Exception:
                pass
            win = xbmcgui.Window(10000)
            rating_key = li.getProperty("PlexKM.RatingKey") or ""
            start = time.time()
            ready = 0
            remote = 0
            cleared = 0
            cast_items = []
            for idx in range(1, 9):
                name = li.getProperty("PlexKM.Cast%d.Name" % idx) or ""
                role = li.getProperty("PlexKM.Cast%d.Role" % idx) or ""
                original_thumb = li.getProperty("PlexKM.Cast%d.OriginalThumb" % idx) or ""
                current_thumb = li.getProperty("PlexKM.Cast%d.Thumb" % idx) or ""
                # v204: current item HTTP thumb is the source of truth. Do not
                # let a stale OriginalThumb from a previous info/cast snapshot win.
                if current_thumb and current_thumb.lower().startswith(("http://", "https://")):
                    original_thumb = current_thumb
                elif not original_thumb and current_thumb and not self._is_cast_placeholder_thumb(current_thumb):
                    original_thumb = current_thumb

                if not name:
                    cleared += 1
                    try:
                        for subkey in ("Name", "Role", "Thumb"):
                            self._info_clear_property_all("PlexKM.Info.DisplayCast%d.%s" % (idx, subkey))
                        for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                            self._info_clear_property_all("PlexKM.Info.Cast%d.%s" % (idx, subkey))
                    except Exception:
                        pass
                    continue

                thumb = original_thumb or current_thumb
                thumb, thumb_source = self._resolve_cast_thumb_fallback(
                    name, thumb, slot_index=idx, rating_key=rating_key, allow_network=False
                )
                if thumb and not original_thumb and not self._is_cast_placeholder_thumb(thumb):
                    original_thumb = thumb

                local_thumb = self._existing_cast_cache_path(thumb) if thumb else ""
                if local_thumb:
                    display_thumb = local_thumb
                    ready += 1
                elif thumb and not self._is_cast_placeholder_thumb(thumb) and not self._is_legacy_cast_cache_thumb_v1349(thumb) and not thumb.lower().startswith(("http://", "https://")):
                    display_thumb = thumb
                    ready += 1
                elif thumb and not self._is_cast_placeholder_thumb(thumb) and thumb.lower().startswith(("http://", "https://")):
                    # V2629: do not expose remote Role URLs through the active
                    # panel. Atomic commit will replace this hidden placeholder
                    # snapshot only after local textures are complete.
                    display_thumb = self._cast_placeholder_thumb()
                    remote += 1
                else:
                    display_thumb = self._cast_placeholder_thumb()

                try:
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Name" % idx, name)
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Role" % idx, role)
                    self._info_set_property_all("PlexKM.Info.DisplayCast%d.Thumb" % idx, display_thumb)

                    li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, thumb_source)
                    self._info_set_property_all("PlexKM.Info.Cast%d.Name" % idx, name)
                    self._info_set_property_all("PlexKM.Info.Cast%d.Role" % idx, role)
                    self._info_set_property_all("PlexKM.Info.Cast%d.ThumbSource" % idx, thumb_source)
                    li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, original_thumb or "")
                    self._info_set_property_all("PlexKM.Info.Cast%d.OriginalThumb" % idx, original_thumb or "")
                    li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, local_thumb or "")
                    self._info_set_property_all("PlexKM.Info.Cast%d.LocalThumb" % idx, local_thumb or "")
                    li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, rating_key)
                    self._info_set_property_all("PlexKM.Info.Cast%d.SourceRatingKey" % idx, rating_key)

                    if display_thumb and not self._is_cast_placeholder_thumb(display_thumb):
                        li.setProperty("PlexKM.Cast%d.Thumb" % idx, display_thumb)
                        self._info_set_property_all("PlexKM.Info.Cast%d.Thumb" % idx, display_thumb)
                    else:
                        _placeholder = self._cast_placeholder_thumb()
                        li.setProperty("PlexKM.Cast%d.Thumb" % idx, _placeholder)
                        self._info_set_property_all("PlexKM.Info.Cast%d.Thumb" % idx, _placeholder)
                except Exception:
                    pass
            _log("CAST_CACHE fast_ready rating_key=%s local=%d remote=%d cleared=%d elapsed=%.1fms" % (
                rating_key, ready, remote, cleared, (time.time() - start) * 1000.0))
        except Exception:
            _log("CAST_CACHE fast_ready_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _info_schedule_actor_widget_rows_postvisible_v2383(self, li, is_tv=False, source_control=0, reason=""):
        """Prepare related-work rows after first paint without touching Kodi GUI.

        The worker may use SQLite/Plex/cache logic, but it only publishes a Python
        data snapshot. Native ControlList reset/addItem stays on the WindowXML GUI
        thread via _info_widget_rebuild_try_commit_v2082().
        """
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            actor_hint = str(li.getProperty("PlexKM.Cast1.Name") or "")
            genre_hint = str(li.getProperty("PlexKM.Genre") or "")
            generation = int(getattr(self, "_info_postvisible_widget_generation_v2383", 0) or 0) + 1
            self._info_postvisible_widget_generation_v2383 = generation
            self._info_widget_rows_precomputed_v2332 = None
            self._info_widget_rebuild_request_v2082(
                rk, actor_hint=actor_hint, genre_hint=genre_hint,
                source_control=source_control, is_tv=bool(is_tv),
                reason="postvisible_data_pending_v2383:%s" % (reason or "info_visible")
            )
            _delay_log_v2601 = 260 if self._uhd_kpi_proxy_v2605() else 120
            _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_SCHEDULE_V2383 rating_key=%s generation=%d is_tv=%d delay_ms=%d gui_mutation=0 reason=%s" % (
                rk, generation, 1 if is_tv else 0, _delay_log_v2601, reason or ""
            ))

            def _worker_v2383():
                t0_v2383 = self._now_ms()
                try:
                    # V2601: on weak Android/U+ keep DB-heavy actor-work lookup
                    # away from the first interactive Info frames and from active
                    # remote navigation. Desktop retains the short legacy delay.
                    if self._uhd_kpi_proxy_v2605():
                        quiet_t0_v2601 = self._now_ms()
                        while not self._closing_event_v1841.is_set():
                            now_v2678 = self._now_ms()
                            last_v2678 = int(getattr(self, "_last_action_ms", 0) or 0)
                            input_age_v2678 = (now_v2678 - last_v2678) if last_v2678 > 0 else 999999
                            # v2678: actor DB work must not overlap the action-bar ->
                            # cast-row scroll. Require a real quiet window after the
                            # most recent remote key, not merely 700ms since scheduling.
                            if (now_v2678 - quiet_t0_v2601) >= 260 and input_age_v2678 >= 450:
                                try:
                                    if not self._uhd3_foreground_isolation_active_v2591():
                                        break
                                except Exception:
                                    break
                            if (now_v2678 - quiet_t0_v2601) >= 1800:
                                break
                            time.sleep(0.10)
                    else:
                        time.sleep(0.12)
                    if int(getattr(self, "_info_postvisible_widget_generation_v2383", 0) or 0) != generation:
                        _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_STALE_DROP_V2383 rating_key=%s generation=%d stage=before_query" % (rk, generation))
                        return
                    rows_v2383 = self._info_movie_cine21_widget_rows(
                        rk, limit=12, actor_hint=actor_hint, genre_hint=genre_hint
                    ) or []
                    if int(getattr(self, "_info_postvisible_widget_generation_v2383", 0) or 0) != generation:
                        _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_STALE_DROP_V2383 rating_key=%s generation=%d stage=after_query rows=%d" % (
                            rk, generation, len(rows_v2383)
                        ))
                        return
                    # R105: build the actor-work ListItems here, off the GUI
                    # thread.  The GUI bind (R88) cost 50-100 ms per poster on
                    # SHIELD (2.6 s for two rows); with prebuilt items it only
                    # adds them to the lists.
                    _pre_t0_r105 = self._now_ms()
                    _pre_n_r105 = 0
                    try:
                        _grp_r105 = None
                        _idx_r105 = 0
                        for _e_r105 in rows_v2383:
                            if int(getattr(self, "_info_postvisible_widget_generation_v2383", 0) or 0) != generation:
                                break
                            if not isinstance(_e_r105, dict):
                                continue
                            _rid_r105 = _e_r105.get("row_id") or _e_r105.get("row_title") or "row"
                            if _rid_r105 != _grp_r105:
                                _grp_r105 = _rid_r105
                                _idx_r105 = 0
                            else:
                                _idx_r105 += 1
                            if str(_e_r105.get("row_type") or "") != "info_actor_works_v1966":
                                continue
                            _li_r105 = self._info_actor_work_li_from_row_v2509(
                                _e_r105.get("row"), row_title=_display_library_title(_e_r105.get("row_title", "")),
                                row_first=(_idx_r105 == 0), row_id=_e_r105.get("row_id", ""), row_start=0, row_index=_idx_r105,
                                work_rating=_e_r105.get("work_rating", "")
                            )
                            if _li_r105 is not None:
                                _e_r105["_li_r105"] = _li_r105
                                _e_r105["_li_index_r105"] = _idx_r105
                                _pre_n_r105 += 1
                    except Exception:
                        _log("INFO_ACTOR_WIDGETS_LI_PREBUILD_FAILED_R105 rating_key=%s err=%s" % (
                            rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                    _log("INFO_ACTOR_WIDGETS_LI_PREBUILT_R105 rating_key=%s items=%d elapsed_ms=%d thread=background" % (
                        rk, _pre_n_r105, self._now_ms() - _pre_t0_r105))
                    if int(getattr(self, "_info_postvisible_widget_generation_v2383", 0) or 0) != generation:
                        _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_STALE_DROP_V2383 rating_key=%s generation=%d stage=after_prebuild" % (rk, generation))
                        return
                    self._info_widget_rows_precomputed_v2332 = {
                        "rating_key": rk,
                        "is_tv": bool(is_tv),
                        "rows": list(rows_v2383),
                        "actor_hint": actor_hint,
                        "genre_hint": genre_hint,
                    }
                    _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_DATA_READY_V2383 rating_key=%s generation=%d rows=%d elapsed_ms=%d gui_mutation=0" % (
                        rk, generation, len(rows_v2383), self._now_ms() - t0_v2383
                    ))
                    if self._uhd_kpi_proxy_v2605():
                        try:
                            xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        except Exception:
                            pass
                except Exception:
                    _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_WORKER_FAILED_V2383 rating_key=%s generation=%d err=%s" % (
                        rk, generation, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

            worker_v2383 = threading.Thread(
                target=_worker_v2383,
                name="PKMInfoActorRowsV2383-%s" % rk,
                daemon=True,
            )
            worker_v2383.start()
            return True
        except Exception:
            _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_SCHEDULE_FAILED_V2383 rating_key=%s err=%s" % (
                str(li.getProperty("PlexKM.RatingKey") or "") if li else "",
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_stage_actor_widget_rows_v2332(self, li, is_tv=False, reason=""):
        """Precompute all related-work DB rows without touching visible controls."""
        try:
            # R100b: warm the drama watched map in the background (non-blocking).
            try:
                self._info_show_watch_counts_r100()
            except Exception:
                pass
            if li is None:
                return []
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return []
            actor_hint = str(li.getProperty("PlexKM.Cast1.Name") or "")
            genre_hint = str(li.getProperty("PlexKM.Genre") or "")
            # v2508: the settled-focus worker may already have produced these
            # exact rows.  Reuse only a very fresh, signature-matching snapshot.
            try:
                with self._info_focus_prewarm_lock_v2508:
                    focus_rec_v2508 = dict(self._info_focus_prewarm_cache_v2508.get(rk) or {})
                age_v2508 = max(0.0, time.time() - float(focus_rec_v2508.get("ts") or 0.0))
                if (age_v2508 <= 15.0 and "widget_rows" in focus_rec_v2508
                        and str(focus_rec_v2508.get("actor_hint") or "") == actor_hint
                        and str(focus_rec_v2508.get("genre_hint") or "") == genre_hint):
                    rows = list(focus_rec_v2508.get("widget_rows") or [])
                    self._info_widget_rows_precomputed_v2332 = {
                        "rating_key": rk, "is_tv": bool(is_tv), "rows": list(rows),
                        "actor_hint": actor_hint, "genre_hint": genre_hint,
                    }
                    _log("INFO_WIDGET_ROWS_FOCUS_PREWARM_HIT_V2508 rating_key=%s is_tv=%d rows=%d age_ms=%d db_query=0 reason=%s" % (
                        rk, 1 if is_tv else 0, len(rows), int(age_v2508 * 1000.0), reason or ""
                    ))
                    return rows
            except Exception:
                pass
            t0 = self._now_ms()
            rows = self._info_movie_cine21_widget_rows(
                rk, limit=12, actor_hint=actor_hint, genre_hint=genre_hint
            ) or []
            self._info_widget_rows_precomputed_v2332 = {
                "rating_key": rk,
                "is_tv": bool(is_tv),
                "rows": list(rows),
                "actor_hint": actor_hint,
                "genre_hint": genre_hint,
            }
            _log("INFO_WIDGET_ROWS_PRECOMPUTED_V2332 rating_key=%s is_tv=%d rows=%d elapsed_ms=%d visible_mutation=0 reason=%s" % (
                rk, 1 if is_tv else 0, len(rows), self._now_ms() - t0, reason or ""
            ))
            return rows
        except Exception:
            self._info_widget_rows_precomputed_v2332 = None
            _log("INFO_WIDGET_ROWS_PRECOMPUTE_FAILED_V2332 rating_key=%s reason=%s err=%s" % (
                str(li.getProperty("PlexKM.RatingKey") or "") if li else "", reason or "",
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return []

    def _info_show_watch_counts_r100(self):
        """R100b: {show_rating_key: (episodes, watched_episodes)} from the local
        sync DB.  Returns the current map immediately (possibly empty) and
        refreshes it in a background thread at most every 10 minutes."""
        data = getattr(self, "_show_watch_counts_map_r100", None)
        stamp = float(getattr(self, "_show_watch_counts_at_r100", 0.0) or 0.0)
        if data is not None and (time.time() - stamp) < 600:
            return data
        if getattr(self, "_show_watch_counts_busy_r100", False):
            return data or {}
        self._show_watch_counts_busy_r100 = True

        def _work():
            conn = None
            t0 = time.time()
            try:
                dbp = self._profile_db_path()
                out = {}
                if dbp and os.path.exists(dbp):
                    conn = sqlite3.connect("file:%s?mode=ro" % dbp, uri=True, timeout=2.0)
                    for gk, total, seen in conn.execute(
                        "SELECT grandparent_rating_key, COUNT(*), "
                        "SUM(CASE WHEN COALESCE(view_count,0)>0 THEN 1 ELSE 0 END) "
                        "FROM items WHERE plex_type='episode' GROUP BY grandparent_rating_key"
                    ):
                        if gk:
                            out[str(gk)] = (_safe_int(total, 0), _safe_int(seen, 0))
                self._show_watch_counts_map_r100 = out
                self._show_watch_counts_at_r100 = time.time()
                _log("SHOW_WATCH_COUNTS_R100 shows=%d watched_any=%d elapsed_ms=%d thread=background" % (
                    len(out), sum(1 for v in out.values() if v[1] > 0), int((time.time() - t0) * 1000)))
            except Exception:
                _log("SHOW_WATCH_COUNTS_R100_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
                self._show_watch_counts_busy_r100 = False

        try:
            th = threading.Thread(target=_work, name="PKMShowWatchCountsR100")
            th.daemon = True
            th.start()
        except Exception:
            self._show_watch_counts_busy_r100 = False
        return data or {}

    def _info_actor_work_li_from_row_v2509(self, row, row_title="", row_first=False, row_id="", row_start=-1, row_index=-1, work_rating=""):
        """Build one Info related-work poster without Home/Library-only enrichment.

        V2509 keeps the exact local row identity and poster authority required by
        related-work navigation, but intentionally skips canonical-rating lookups,
        Cine21/Watcha/rating preload, wall-sort formatting and other Home/Library
        card work that is never rendered while Info owns these controls.  Child
        Info still passes through the normal prepared-cache/local-DB enrichment
        after selection, so no Info metadata authority is weakened.
        """
        try:
            row = tuple(row or ())
            if len(row) < 21:
                return None
            rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = row[:21]
            parent_rating_key = row[21] if len(row) > 21 else ""
            grandparent_rating_key = row[22] if len(row) > 22 else ""
            view_offset = row[23] if len(row) > 23 else ""
            resume_duration_ms = row[24] if len(row) > 24 else ""
            resume_updated_at = row[25] if len(row) > 25 else ""
            resume_source = row[26] if len(row) > 26 else ""

            rk = str(rating_key or "").strip()
            ptype = str(plex_type or "").strip().lower()
            if not rk:
                return None
            mediatype = kodi_type or ("tvshow" if ptype in ("show", "season") else ptype or "video")

            if part_key and ptype in ("movie", "episode"):
                url = _pkm_play_url(rk, part_key, mode="start")
            elif ptype == "show":
                url = core.build_plugin_url({"action": "show", "rating_key": rk, "section_id": section_id})
            else:
                url = core.build_plugin_url({"action": "noop"})

            # R115: offscreen=True. These work cards are built off the GUI thread
            # (info actor rows ~2 s after Info opens, actor page prebuild) and
            # only then handed to addItems(); a GUI-locked ListItem took Kodi's
            # render lock on every setProperty/setArt and stalled a slide that
            # overlapped it by 80-180 ms (SHIELD A/B: 3/6 stalls -> 0/6).
            li = xbmcgui.ListItem(label=title or "", path=url, offscreen=True)
            try:
                li.setPath(url)
            except Exception:
                pass
            if work_rating:
                li.setProperty("PlexKM.ActorWork.Rating", str(work_rating))

            raw_thumb = str(thumb or "").strip()
            display_thumb = _plex_art(raw_thumb, width=720, height=1080) if raw_thumb else ""
            canonical_thumb = _plex_art("/library/metadata/%s/thumb" % rk, width=720, height=1080)
            normalized_art = _plex_art(str(art or "").strip(), width=1920, height=1080) if str(art or "").strip() else ""
            poster = display_thumb or canonical_thumb
            poster_source = "db_normalized" if (display_thumb and display_thumb != raw_thumb) else ("db" if display_thumb else ("canonical" if canonical_thumb else "none"))
            fallback = canonical_thumb or ""
            # v2677: actor pages can contain dozens of works. Prefer an already
            # decoded/local Kodi poster when available so the page does not reveal
            # a text-only rail and then slowly fill remote textures. This is cache-
            # only: it never starts network I/O and falls back to the same authority.
            try:
                local_poster_v2677 = self._cached_poster_source_path_v1871(poster)
            except Exception:
                local_poster_v2677 = ""
            if not local_poster_v2677:
                # R30: the 720x1080 Info poster is often not cached yet, while
                # the library wall already keeps a verified local small poster
                # for most items.  Use it (cache-only, no network) so actor
                # pages do not show blank cards that fill in 2-3 s later.
                try:
                    local_poster_v2677 = self._library_row_poster_local_v2580(row)
                    if local_poster_v2677:
                        poster_source = "pkm_small_r30"
                except Exception:
                    local_poster_v2677 = ""
            if local_poster_v2677:
                poster = local_poster_v2677
                if poster_source != "pkm_small_r30":
                    poster_source = "local_cache_v2677"
            try:
                # v2552: expose the already-indexed work fanart to Kodi's native
                # ListItem art contract.  ActorProfile XML reads the selected 6500
                # item directly, so focus changes update the background without a
                # Python focus callback, DB query, or actor-page reveal wait.
                # V2670 UHD3: ActorProfile rail navigation must be poster-only on weak Android boxes.
                # Per-item fanart makes every LEFT/RIGHT focus change decode/swap a 1080p texture and
                # is purely decorative here; keep it on desktop, suppress it on the UHD3 hot path.
                actor_rail_fanart_v2670 = "" if self._uhd_kpi_proxy_v2605() else normalized_art
                li.setArt({"poster": poster, "thumb": poster, "icon": poster, "fanart": actor_rail_fanart_v2670})
            except Exception:
                pass

            # Keep Kodi's native title/year/plot identity for any skin expression
            # that reads ListItem.InfoTagVideo, but do not perform any rating or
            # canonical-duplicate database work here.
            try:
                info = {
                    "title": title or "", "sorttitle": sort_title or title or "",
                    "originaltitle": original_title or "", "year": _safe_int(year, 0),
                    "plot": summary or "", "duration": _safe_int(duration, 0),
                    "mediatype": mediatype,
                }
                if ptype in ("episode", "season"):
                    info.update({"tvshowtitle": show_title or title or "", "season": _safe_int(season, 0)})
                    if ptype == "episode":
                        info["episode"] = _safe_int(episode, 0)
                apply_video_info(li, info)
            except Exception:
                pass

            progress_percent = 0
            progress_350 = ""
            progress_370 = ""
            try:
                _off_ms, _dur_ms, progress_percent = getattr(_ensure_core(), "_pkm_progress_pair")(
                    _safe_int(view_offset, 0), duration, resume_duration_ms
                )
                progress_percent = int(max(0, min(100, _safe_int(progress_percent, 0))))
                if progress_percent > 0:
                    pp = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(progress_percent) or {}
                    progress_350 = str(pp.get("ResumeProgressComposite350x10") or "")
                    progress_370 = str(pp.get("ResumeProgressComposite370x10") or "")
            except Exception:
                progress_percent = 0

            # R100b: drama cards get the same watched / in-progress marks as movies.
            # Never query the DB here (this runs on the GUI thread per card; on
            # Shield one unindexed episode scan cost ~900 ms per card).  Counts
            # come from a session map built once in a background thread.
            show_watched_r100 = ""
            if ptype == "show":
                try:
                    _cnt_r100 = (self._info_show_watch_counts_r100() or {}).get(rk)
                    if _cnt_r100:
                        _total_r100, _seen_r100 = _cnt_r100
                        if _total_r100 > 0 and _seen_r100 >= _total_r100:
                            show_watched_r100 = "1"
                        elif _total_r100 > 0 and _seen_r100 > 0 and progress_percent <= 0:
                            progress_percent = int(max(1, min(99, round(100.0 * _seen_r100 / _total_r100))))
                            pp = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(progress_percent) or {}
                            progress_350 = str(pp.get("ResumeProgressComposite350x10") or "")
                            progress_370 = str(pp.get("ResumeProgressComposite370x10") or "")
                except Exception:
                    pass

            props = {
                "RatingKey": rk, "SectionId": section_id, "Type": ptype, "KodiType": mediatype,
                "Title": title, "OriginalTitle": original_title, "SortTitle": sort_title,
                "Year": year, "Summary": summary, "Duration": duration, "AddedAt": added_at,
                "UpdatedAt": updated_at, "Thumb": poster, "EpisodeThumb": raw_thumb,
                "Art": normalized_art, "PartKey": part_key, "ViewCount": view_count,
                "IsWatched": "1" if (_safe_int(view_count, 0) > 0 or show_watched_r100) else "", "ShowTitle": show_title,
                "Season": season, "Episode": episode, "ParentRatingKey": parent_rating_key,
                "GrandparentRatingKey": grandparent_rating_key, "ViewOffset": view_offset,
                "ResumeDurationMs": resume_duration_ms, "ResumeUpdatedAt": resume_updated_at,
                "ResumeSource": resume_source, "ResumePercent": progress_percent,
                "ResumeProgressComposite350x10": progress_350,
                "ResumeProgressComposite370x10": progress_370,
                "PlayUrl": url if (part_key and ptype in ("movie", "episode")) else "",
                "ShowUrl": url if ptype == "show" else "",
            }
            for k, v in props.items():
                try:
                    li.setProperty("PlexKM.%s" % k, str(v or ""))
                except Exception:
                    pass

            # Preserve the existing V2130/V2498 portrait-poster contract exactly;
            # only the expensive unrelated card metadata work is omitted.
            try:
                li.setProperty("PlexKM.WallPosterRemoteV1644", poster)
                li.setProperty("PlexKM.WallPosterDisplayV1644", poster)
                li.setProperty("PlexKM.PosterFallbackArt", fallback)
                li.setProperty("PlexKM.PosterFallbackRoleV2498", "poster" if fallback else "")
                li.setProperty("PlexKM.PosterAuthorityV2498", display_thumb or canonical_thumb or poster)
                li.setProperty("PlexKM.PosterLocalSourceV2498", local_poster_v2677 or "")
                li.setProperty("PlexKM.PosterFallbackArtActive", "")
                li.setProperty("PlexKM.PosterFallbackChecked", "")
                li.setProperty("PlexKM.ActorWorkPosterSourceV2130", poster_source)
                li.setProperty("PlexKM.ActorWorkPosterCanonicalFallbackV2130", "1" if fallback else "")
            except Exception:
                pass

            # Actor-work controls are Home-like only for native navigation.  Keep
            # the row identity properties their click/back logic expects.
            if row_title:
                rt = _display_library_title(row_title)
                li.setProperty("PlexKM.HomeRowTitle", rt)
                li.setProperty("PlexKM.HomeLayout", "1")
                li.setProperty("PlexKM.HomeRowId", str(row_id or rt or ""))
                li.setProperty("PlexKM.HomeRowStart", str(row_start if row_start is not None else -1))
                li.setProperty("PlexKM.HomeRowIndex", str(row_index if row_index is not None else -1))
            if row_first:
                li.setProperty("PlexKM.HomeRowFirst", "1")
            li.setProperty("PlexKM.HomeRowType", "info_actor_works_v1966")
            li.setProperty("PlexKM.WallTitleLine1", str(title or ""))
            li.setProperty("PlexKM.WallTitleFull", str(title or ""))
            li.setProperty("PlexKM.WallYearLine", str(year or ""))
            li.setProperty("PlexKM.WallSortLine", "")
            li.setProperty("PlexKM.WallMetaLine", "")
            li.setProperty("PlexKM.Is4K", "")
            if part_key and ptype in ("movie", "episode"):
                li.setProperty("IsPlayable", "true")
            return li
        except Exception:
            _log("INFO_ACTOR_WORK_LIGHT_ITEM_FAILED_V2509 rating_key=%s err=%s" % (
                str((tuple(row or ()) + ("",))[0] or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return None
