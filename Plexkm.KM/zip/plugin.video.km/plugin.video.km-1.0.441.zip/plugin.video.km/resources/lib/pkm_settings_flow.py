# -*- coding: utf-8 -*-
"""PKM settings flow and small PKM-styled modal dialogs.

This module is intentionally UI/settings-only.  It was split out of
``default.py`` from the v626 stable baseline so later sync/cache patches do not
accidentally revive old settings-dialog code paths.

Rules for this module:
- keep one WindowXMLDialog alive and switch pages in-place;
- do not open Kodi's default add-on settings window;
- keep Plex DB path selection inside the PKM styled dialog;
- cancel/Esc preserves existing settings values.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, ensure_focus, start_focus_monitor
from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171

import sys
import os
import json
import time
import sqlite3
import traceback
import threading
import hashlib
import string
import xml.etree.ElementTree as ET
try:
    from urllib.parse import urlparse
except Exception:
    from urlparse import urlparse

import xbmcvfs

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None

try:
    from resources.lib import pkm_plex_client
except Exception:
    pkm_plex_client = None

try:
    from resources.lib import pkm_spinner
except Exception:
    pkm_spinner = None

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")


def _display_text_for_kodi(value):
    """Normalize Plex library title separators for Kodi WindowXML text rendering."""
    text = str(value or "")
    try:
        table = {
            ord("\u007C"): "|",
            ord("\u00A6"): "|",
            ord("\u01C0"): "|",
            ord("\u2016"): "|",
            ord("\u2223"): "|",
            ord("\u2225"): "|",
            ord("\u23AA"): "|",
            ord("\u23D0"): "|",
            ord("\u2502"): "|",
            ord("\u2503"): "|",
            ord("\u2758"): "|",
            ord("\u2759"): "|",
            ord("\u275A"): "|",
            ord("\u3163"): "|",
            ord("\u4E28"): "|",
            ord("\uFF5C"): "|",
            ord("\uFFE8"): "|",
        }
        return text.translate(table)
    except Exception:
        return text


def _core():
    """Return the running default.py module without importing a second copy."""
    return sys.modules.get("default") or sys.modules.get("__main__")


def _sync_runtime_plex_auth_settings_v1690(token_module):
    """Mirror the newly authenticated state into every live Addon wrapper.

    Kodi can keep one settings snapshot per ``xbmcaddon.Addon`` Python wrapper.
    The Plex URL is edited by this module, while plex.tv/link stores the selected
    Home user's token in ``pkm_token_import``.  The running ``default.py`` can
    therefore still see its pre-dialog empty snapshot and abort before the live
    ``/library/sections`` request.  Keep the existing settings architecture and
    only make the three already-running wrappers equivalent before continuing.
    """
    try:
        server = (ADDON.getSetting("plex_url") or "").strip()
        token_addon = getattr(token_module, "ADDON", None)
        token = (token_addon.getSetting("plex_token") or "").strip() if token_addon else ""
        account = (token_addon.getSetting("plex_account_name") or "").strip() if token_addon else ""
        if not server or not token:
            _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_INCOMPLETE_V1690 server=%s token=%s" % (
                "1" if server else "0", "1" if token else "0"
            ), xbmc.LOGWARNING)
            return False

        targets = []
        for candidate in (ADDON, token_addon, getattr(_core(), "ADDON", None)):
            if candidate is not None and all(candidate is not existing for existing in targets):
                targets.append(candidate)

        verified = True
        for target in targets:
            target.setSetting("plex_url", server)
            target.setSetting("plex_token", token)
            target.setSetting("plex_account_name", account)
            if (target.getSetting("plex_url") or "").strip() != server:
                verified = False
            if (target.getSetting("plex_token") or "").strip() != token:
                verified = False

        # v1732: the already-open Home window can keep an older xbmcaddon.Addon
        # settings snapshot even after the settings dialog writes the new values.
        # Publish the authenticated endpoint in the global Kodi window as the
        # current-run source of truth so Home can render immediately without a
        # Kodi restart. Persistent add-on settings remain the next-run source.
        try:
            runtime = xbmcgui.Window(10000)
            runtime.setProperty("PlexKM.Runtime.PlexURL", server)
            runtime.setProperty("PlexKM.Runtime.PlexToken", token)
            runtime.setProperty("PlexKM.Runtime.PlexAccount", account)
            runtime.setProperty("PlexKM.Runtime.PlexAuthAuthoritative", "1")
        except Exception:
            verified = False

        _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_V1732 server=1 token=1 targets=%d verified=%s bridge=global_window" % (
            len(targets), "1" if verified else "0"
        ), xbmc.LOGINFO if verified else xbmc.LOGWARNING)
        return verified
    except Exception:
        _log("PKM_TOKEN_AUTH_RUNTIME_SETTINGS_SYNC_FAILED_V1690\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return False


def _log(message, level=xbmc.LOGINFO):
    core = _core()
    try:
        if core and hasattr(core, "log"):
            core.log(message, level)
            return
    except Exception:
        pass
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)



def _offline_or_server_switch_pending_v1382():
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.PlexOffline") == "1":
            return True
        if win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
            return True
    except Exception:
        pass
    return False

def _plex_server_settings_ready_v1702():
    """Return True only when both PMS address and Plex token exist.

    Use the live default.py wrappers when available so the settings dialog does
    not repeat the stale xbmcaddon.Addon snapshot problem fixed in v1690.
    """
    core = _core()
    try:
        if core and hasattr(core, "clean_server_url"):
            server = (core.clean_server_url() or "").strip()
        else:
            server = (ADDON.getSetting("plex_url") or "").strip().rstrip("/")
        if core and hasattr(core, "plex_token"):
            token = (core.plex_token() or "").strip()
        else:
            token = (ADDON.getSetting("plex_token") or "").strip()
        return bool(server and token)
    except Exception:
        return bool((ADDON.getSetting("plex_url") or "").strip() and (ADDON.getSetting("plex_token") or "").strip())


def _require_plex_server_settings_v1702(source="settings"):
    if _plex_server_settings_ready_v1702():
        return True
    _log("PKM_SETTINGS_SERVER_REQUIRED_V1702 source=%s" % str(source or "settings"), xbmc.LOGINFO)
    _notify("Plex 서버 설정이 먼저 필요합니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
    return False


def _notify(message, heading=ADDON_NAME, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    core = _core()
    try:
        if core and hasattr(core, "notify"):
            core.notify(message, heading=heading, icon=icon, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(heading or ADDON_NAME, message, "", ms=ms):
            return
    except Exception:
        pass
    _log("PKM_NATIVE_NOTIFICATION_SUPPRESSED heading=%s message=%s" % (str(heading or ""), str(message or "")), xbmc.LOGINFO)


def _set_confirm_global_props(title, message, yes_label, no_label, icon1="", icon2="", cine21_rows=None, logo_icon="", critic_icon="", audience_icon="", windowed_video=False):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Confirm.Title", _display_text_for_kodi(title or "PlexKM"))
        win.setProperty("PlexKM.Confirm.Message", _display_text_for_kodi(message or ""))
        win.setProperty("PlexKM.Confirm.Yes", _display_text_for_kodi(yes_label or "확인"))
        win.setProperty("PlexKM.Confirm.No", _display_text_for_kodi(no_label or ""))
        win.setProperty("PlexKM.Confirm.Icon1", icon1 or "")
        win.setProperty("PlexKM.Confirm.Icon2", icon2 or "")
        win.setProperty("PlexKM.Confirm.HasIcons", "1" if (icon1 or icon2) else "")
        win.setProperty("PlexKM.Confirm.WindowedVideo", "1" if windowed_video else "")
        # v2371: plexkm_pkm_confirm_dialog.xml tints white.png from these two
        # global properties.  Settings-flow dialogs never populated them, so
        # an empty colordiffuse rendered as raw white (white full-screen/panel,
        # white text disappearing on top).  Always provide PKM dark defaults.
        win.setProperty("PlexKM.Confirm.BackdropColor", "FF111214")
        win.setProperty("PlexKM.Confirm.PanelBgColor", "FA050607")
        rows = list(cine21_rows or [])[:3]
        win.setProperty("PlexKM.Confirm.HasCine21Rows", "1" if rows else "")
        win.setProperty("PlexKM.Confirm.Cine21LogoIcon", logo_icon or "")
        win.setProperty("PlexKM.Confirm.Cine21CriticIcon", critic_icon or "")
        win.setProperty("PlexKM.Confirm.Cine21AudienceIcon", audience_icon or "")
        for idx in range(1, 4):
            row = rows[idx - 1] if idx <= len(rows) else {}
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Title" % idx, _display_text_for_kodi(row.get("title") or ""))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Critic" % idx, str(row.get("critic") or "-"))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Audience" % idx, str(row.get("audience") or "-"))
            win.setProperty("PlexKM.Confirm.Cine21.Row%d.Visible" % idx, "1" if row else "")
    except Exception:
        pass


def _clear_confirm_global_props():
    try:
        win = xbmcgui.Window(10000)
        keys = ["PlexKM.Confirm.Title", "PlexKM.Confirm.Message", "PlexKM.Confirm.Yes", "PlexKM.Confirm.No", "PlexKM.Confirm.Icon1", "PlexKM.Confirm.Icon2", "PlexKM.Confirm.HasIcons", "PlexKM.Confirm.HasCine21Rows", "PlexKM.Confirm.Cine21LogoIcon", "PlexKM.Confirm.Cine21CriticIcon", "PlexKM.Confirm.Cine21AudienceIcon", "PlexKM.Confirm.WindowedVideo", "PlexKM.Confirm.BackdropColor", "PlexKM.Confirm.PanelBgColor"]
        for idx in range(1, 4):
            keys.extend([
                "PlexKM.Confirm.Cine21.Row%d.Title" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Critic" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Audience" % idx,
                "PlexKM.Confirm.Cine21.Row%d.Visible" % idx,
            ])
        for key in keys:
            win.clearProperty(key)
    except Exception:
        pass


class PKMListDialog(xbmcgui.WindowXMLDialog):
    """Small PKM-styled modal list dialog for settings/library selection."""
    LIST_ID = 200
    OK_ID = 300
    HOME_ID = 302
    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "")
        self.items = kwargs.pop("items", [])
        self.multiselect = bool(kwargs.pop("multiselect", False))
        self.require_confirm = bool(kwargs.pop("require_confirm", False))
        self.preselect = set(int(x) for x in (kwargs.pop("preselect", []) or []))
        self.result = None
        self._list = None
        super(PKMListDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self.setProperty("PlexKM.Dialog.Title", self.title or "PlexKM")
            mode = "multi" if self.multiselect else ("single_confirm" if self.require_confirm else "single")
            self.setProperty("PlexKM.Dialog.Mode", mode)
            if self.multiselect:
                hint = "선택 / 저장 / 뒤로"
            elif self.require_confirm:
                hint = "선택 / 확인 / 뒤로"
            else:
                hint = "선택 / 뒤로"
            self.setProperty("PlexKM.Dialog.Hint", hint)
        except Exception:
            pass
        try:
            self._list = self.getControl(self.LIST_ID)
            self._list.reset()
            listitems = []
            for idx, label in enumerate(self.items):
                li = xbmcgui.ListItem(label=_display_text_for_kodi(label))
                li.setProperty("index", str(idx))
                li.setProperty("checked", "1" if idx in self.preselect else "0")
                li.setProperty("showcheck", "1" if (self.multiselect or self.require_confirm) else "0")
                listitems.append(li)
            self._list.addItems(listitems)
            self.setFocusId(self.LIST_ID)
        except Exception:
            _log("PKM_SETTINGS_DIALOG_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _toggle_focused(self):
        if not self._list:
            return
        pos = int(self._list.getSelectedPosition())
        if pos < 0 or pos >= len(self.items):
            return
        if pos in self.preselect:
            self.preselect.remove(pos)
        else:
            self.preselect.add(pos)
        item = self._list.getListItem(pos)
        checked = pos in self.preselect
        item.setProperty("checked", "1" if checked else "0")

    def _select_single_confirm_focused_v1691(self):
        """Select exactly one Plex Home row and expose the PKM square check.

        v1689 closed the dialog immediately from the list click, so Kodi never
        had a stable frame in which to draw the checked square.  Keep one-press
        row selection, but make confirmation an explicit second control action:
        Enter fills the selected row's PlexKM square and moves focus to 확인.
        """
        if not self._list:
            return None
        pos = int(self._list.getSelectedPosition())
        if pos < 0 or pos >= len(self.items):
            return None
        for idx in range(len(self.items)):
            try:
                self._list.getListItem(idx).setProperty("checked", "1" if idx == pos else "0")
            except Exception:
                pass
        self.preselect = set([pos])
        self.result = None
        _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_ROW_CHECKED_V1705 choice=%d focus=list xml_right_to_confirm=1" % pos, xbmc.LOGINFO)
        return pos

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        try:
            if controlId == self.LIST_ID:
                pos = int(self._list.getSelectedPosition()) if self._list else -1
                if self.multiselect:
                    self._toggle_focused()
                elif self.require_confirm:
                    # v1691: Enter selects one Home user and visibly fills the
                    # PKM square at the right.  Focus then moves to 확인 so the
                    # user can commit the checked row without a hidden selection.
                    self._select_single_confirm_focused_v1691()
                else:
                    self.result = pos if 0 <= pos < len(self.items) else None
                    self.close()
            elif controlId == self.OK_ID:
                if self.multiselect:
                    self.result = sorted(self.preselect)
                elif self.require_confirm:
                    chosen = sorted(self.preselect)
                    if not chosen:
                        _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_REQUIRED_V1691", xbmc.LOGINFO)
                        try:
                            self.setFocusId(self.LIST_ID)
                        except Exception:
                            pass
                        return
                    self.result = int(chosen[0])
                    _log("PKM_SETTINGS_DIALOG_SINGLE_CONFIRM_ACCEPT_V1691 choice=%d" % self.result, xbmc.LOGINFO)
                else:
                    self.result = None
                self.close()
        except Exception:
            _log("PKM_SETTINGS_DIALOG_CLICK_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            self.result = None
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = None
            self.close()



class PKMTextInputDialog(xbmcgui.WindowXMLDialog):
    """PKM-native text input with one shared Python string buffer.

    v1704 removes Kodi ``ControlEdit`` entirely.  The focused PKM input row is
    a plain PKM button, so Enter can never open Kodi's stock keyboard.  Physical
    keyboard events are decoded from ``Action.getButtonCode()`` and appended to
    the same value used by the on-screen PKM keyboard.  Consumed letter keys do
    not fall through to global Kodi shortcuts such as H -> PVR.
    """
    TITLE_ID = 100
    VALUE_ID = 101
    KEYBOARD_ID = 200
    KEYS = list("1234567890") + list("abcdefghijklmnopqrstuvwxyz") + [
        ":", "/", ".", "-", "_", "@", "?", "&", "=", "%", "#", "+",
        "공백", "삭제", "지우기", "저장", "취소",
    ]

    # Kodi's hardware-independent VKEY range is KEY_VKEY | (symbol & 0x03ff).
    _KEY_VKEY = 0xF000
    _KEY_VKEY_MAX = 0xF3FF
    _KEY_VKEY_MASK = 0x03FF

    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "입력")
        self.value = str(kwargs.pop("value", "") or "")
        self.hidden = bool(kwargs.pop("hidden", False))
        self.result = None
        self._value_control = None
        self._keyboard = None
        super(PKMTextInputDialog, self).__init__(*args, **kwargs)

    def _visible_value_v1704(self):
        if not self.value:
            return "입력하세요"
        if self.hidden:
            return "•" * len(self.value)
        return self.value

    def _render_value_v1704(self):
        try:
            if self._value_control:
                self._value_control.setLabel(_display_text_for_kodi(self._visible_value_v1704()))
        except Exception:
            pass

    def _replace_value_v1704(self, value):
        self.value = str(value or "")
        self._render_value_v1704()

    def _append_value_v1704(self, char):
        self.value += str(char or "")
        self._render_value_v1704()

    def _delete_last_v1704(self):
        self.value = self.value[:-1]
        self._render_value_v1704()

    @classmethod
    def _decode_physical_key_v1704(cls, action):
        """Return ('char', text), ('backspace', ''), ('save', '') or None.

        Kodi 21 forwards the original button code even when a global keymap has
        translated the key to another action.  Decoding that original VKEY lets
        this modal consume printable keys before PVR/search/player shortcuts can
        run.  The mapping deliberately covers the ASCII set needed by server
        URLs and remote paths, plus numpad digits/operators.
        """
        try:
            raw = int(action.getButtonCode() or 0) & 0xFFFFFFFF
        except Exception:
            raw = 0
        if not raw:
            return None

        low = raw & 0xFFFF
        is_vkey = cls._KEY_VKEY <= low <= cls._KEY_VKEY_MAX
        if is_vkey:
            key = low & cls._KEY_VKEY_MASK
        elif 0 < low <= cls._KEY_VKEY_MASK:
            # Some Kodi/platform combinations expose the symbol without the
            # KEY_VKEY prefix to Python WindowXML callbacks.
            key = low
        else:
            return None

        # Compatibility with older KEY_ASCII/KEY_UNICODE-style encodings where
        # the printable byte is stored in the low 8 bits.
        if key > 0x10D:
            legacy = low & 0xFF
            if 0x20 <= legacy <= 0x7E:
                key = legacy
            else:
                return None

        if key == 0x08:  # backspace
            return ("backspace", "")
        if key in (0x0D, 0x65):  # Return / numpad Enter
            return ("save", "")
        if key in (0x7F, 0x87):  # Delete variants
            return ("backspace", "")

        if is_vkey:
            numpad_digits = {
                0x70: "0", 0x71: "1", 0x72: "2", 0x73: "3", 0x74: "4",
                0x75: "5", 0x76: "6", 0x77: "7", 0x78: "8", 0x79: "9",
            }
            numpad_ops = {0x61: "/", 0x62: "*", 0x63: "-", 0x64: "+", 0x66: "."}
            if key in numpad_digits:
                return ("char", numpad_digits[key])
            if key in numpad_ops:
                return ("char", numpad_ops[key])

        if 0x41 <= key <= 0x5A:
            return ("char", chr(key).lower())
        if 0x30 <= key <= 0x39:
            return ("char", chr(key))
        if key == 0x20:
            return ("char", " ")
        if 0x21 <= key <= 0x2F or 0x3A <= key <= 0x40 or 0x5B <= key <= 0x60 or 0x7B <= key <= 0x7E:
            return ("char", chr(key))
        return None

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self.getControl(self.TITLE_ID).setLabel(_display_text_for_kodi(self.title))
            self._value_control = self.getControl(self.VALUE_ID)
            self._keyboard = self.getControl(self.KEYBOARD_ID)
            self._render_value_v1704()
            self._keyboard.reset()
            items = []
            for key in self.KEYS:
                li = xbmcgui.ListItem(label=_display_text_for_kodi(key))
                li.setProperty("PKMKey", key)
                items.append(li)
            self._keyboard.addItems(items)
            # XML owns all focus movement.  The input row is the native default;
            # Down enters the PKM on-screen keyboard and Up returns to it.
            _log("PKM_TEXT_INPUT_BUFFER_READY_V1704", xbmc.LOGINFO)
        except Exception:
            _log("PKM_TEXT_INPUT_INIT_FAILED_V1704\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.VALUE_ID:
            # Enter confirms the current buffer.  This is a plain PKM button,
            # not ControlEdit, so Kodi's stock keyboard cannot be launched.
            self.result = self.value
            self.close()
            return
        if controlId != self.KEYBOARD_ID or not self._keyboard:
            return
        try:
            item = self._keyboard.getSelectedItem()
            key = item.getProperty("PKMKey") or item.getLabel()
            if key == "저장":
                self.result = self.value
                self.close()
                return
            if key == "취소":
                self.result = None
                self.close()
                return
            if key == "삭제":
                self._delete_last_v1704()
            elif key == "지우기":
                self._replace_value_v1704("")
            elif key == "공백":
                self._append_value_v1704(" ")
            else:
                self._append_value_v1704(key)
        except Exception:
            _log("PKM_TEXT_INPUT_CLICK_FAILED_V1704\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        physical = self._decode_physical_key_v1704(action)
        if physical:
            kind, payload = physical
            if kind == "char":
                self._append_value_v1704(payload)
            elif kind == "backspace":
                self._delete_last_v1704()
            elif kind == "save":
                self.result = self.value
                self.close()
            # Do not call the base handler: this consumes global H/P/S/etc.
            return

        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = None
            self.close()

def _window_stack_snapshot_v1747():
    """Return the current Kodi base/dialog stack without mutating GUI state."""
    base_id = -1
    dialog_id = -1
    try:
        base_id = int(xbmcgui.getCurrentWindowId())
    except Exception:
        pass
    try:
        dialog_id = int(xbmcgui.getCurrentWindowDialogId())
    except Exception:
        pass
    visible = {}
    for wid in (13030, 13031, 13032):
        try:
            visible[wid] = 1 if xbmc.getCondVisibility("Window.IsVisible(%d)" % wid) else 0
        except Exception:
            visible[wid] = -1
    try:
        current_window = xbmc.getInfoLabel("System.CurrentWindow") or ""
    except Exception:
        current_window = ""
    try:
        current_control = xbmc.getInfoLabel("System.CurrentControl") or ""
    except Exception:
        current_control = ""
    return base_id, dialog_id, visible, current_window, current_control


def _log_window_stack_v1747(stage, extra=""):
    try:
        base_id, dialog_id, visible, current_window, current_control = _window_stack_snapshot_v1747()
        _log(
            "PKM_WINDOW_STACK_V1747 stage=%s base=%s dialog=%s vis13030=%s vis13031=%s vis13032=%s current_window=%s current_control=%s%s" % (
                stage or "unknown", base_id, dialog_id,
                visible.get(13030, -1), visible.get(13031, -1), visible.get(13032, -1),
                str(current_window or "").replace(" ", "_"),
                str(current_control or "").replace(" ", "_"),
                (" " + str(extra)) if extra else "",
            ),
            xbmc.LOGINFO,
        )
    except Exception:
        pass


def _start_window_stack_probe_v1747(label, duration_ms=1400, interval_ms=10):
    """Log only native window-stack state changes during confirm→progress handoff."""
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.Sync.HandoffProbeV1747", "1")
    except Exception:
        pass
    def _probe():
        started = time.perf_counter()
        previous = None
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            elapsed_ms = int((time.perf_counter() - started) * 1000.0)
            if elapsed_ms > int(duration_ms or 0):
                break
            state = _window_stack_snapshot_v1747()
            compact = (state[0], state[1], state[2].get(13030), state[2].get(13031), state[2].get(13032), state[3], state[4])
            if compact != previous:
                previous = compact
                _log_window_stack_v1747("probe_%s" % (label or "handoff"), "t_ms=%d" % elapsed_ms)
            xbmc.sleep(max(1, int(interval_ms or 10)))
        _log_window_stack_v1747("probe_%s_end" % (label or "handoff"), "duration_ms=%d" % int(duration_ms or 0))
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Sync.HandoffProbeV1747")
        except Exception:
            pass
    try:
        thread = threading.Thread(target=_probe, name="PKMWindowStackProbeV1747", daemon=True)
        thread.daemon = True
        thread.start()
    except Exception:
        _log("PKM_WINDOW_STACK_PROBE_START_FAILED_V1747\n%s" % traceback.format_exc(), xbmc.LOGWARNING)


class PKMConfirmDialog(xbmcgui.WindowXMLDialog):
    YES_ID = 300
    NO_ID = 301

    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop("title", "PlexKM")
        self.message = kwargs.pop("message", "")
        self.yes_label = kwargs.pop("yes_label", "확인")
        self.no_label = kwargs.pop("no_label", "취소")
        self.icon1 = kwargs.pop("icon1", "")
        self.icon2 = kwargs.pop("icon2", "")
        self.cine21_rows = kwargs.pop("cine21_rows", [])
        self.cine21_logo_icon = kwargs.pop("cine21_logo_icon", "")
        self.cine21_critic_icon = kwargs.pop("cine21_critic_icon", "")
        self.cine21_audience_icon = kwargs.pop("cine21_audience_icon", "")
        self.windowed_video = bool(kwargs.pop("windowed_video", False))
        self.yes_prepare = kwargs.pop("yes_prepare", None)
        # v2150: focus still belongs exclusively to Kodi XML.  Keep the requested
        # default so open_pkm_confirm_dialog can choose the matching XML whose
        # <defaultcontrol> owns initial focus; Python never moves Left/Right focus.
        self.default_focus = str(kwargs.pop("default_focus", "") or "").strip().lower()
        self.result = False
        super(PKMConfirmDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        _log_window_stack_v1747("confirm_oninit", "window=13031")
        try:
            _set_confirm_global_props(self.title, self.message, self.yes_label, self.no_label, self.icon1, self.icon2, self.cine21_rows, self.cine21_logo_icon, self.cine21_critic_icon, self.cine21_audience_icon, self.windowed_video)
            self.setProperty("PlexKM.Confirm.Title", _display_text_for_kodi(self.title or "PlexKM"))
            self.setProperty("PlexKM.Confirm.Message", _display_text_for_kodi(self.message or ""))
            self.setProperty("PlexKM.Confirm.Yes", _display_text_for_kodi(self.yes_label or "확인"))
            self.setProperty("PlexKM.Confirm.No", _display_text_for_kodi(self.no_label or ""))
            self.setProperty("PlexKM.Confirm.Icon1", self.icon1 or "")
            self.setProperty("PlexKM.Confirm.Icon2", self.icon2 or "")
            self.setProperty("PlexKM.Confirm.HasIcons", "1" if (self.icon1 or self.icon2) else "")
            self.setProperty("PlexKM.Confirm.WindowedVideo", "1" if self.windowed_video else "")
            self.setProperty("PlexKM.Confirm.HasCine21Rows", "1" if self.cine21_rows else "")
            self.setProperty("PlexKM.Confirm.Cine21LogoIcon", self.cine21_logo_icon or "")
            self.setProperty("PlexKM.Confirm.Cine21CriticIcon", self.cine21_critic_icon or "")
            self.setProperty("PlexKM.Confirm.Cine21AudienceIcon", self.cine21_audience_icon or "")
            for idx in range(1, 4):
                row = self.cine21_rows[idx - 1] if idx <= len(self.cine21_rows or []) else {}
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Title" % idx, _display_text_for_kodi(row.get("title") or ""))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Critic" % idx, str(row.get("critic") or "-"))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Audience" % idx, str(row.get("audience") or "-"))
                self.setProperty("PlexKM.Confirm.Cine21.Row%d.Visible" % idx, "1" if row else "")
            # v2150: Never move button focus from Python during dialog init.
            # The selected XML owns the initial focus.  Destructive reset uses
            # defaultcontrol=301 (아니오), and only a real Left/Right action can
            # move focus to 예.
            default_control_v2150 = 301 if self.default_focus == "no" else 300
            _log("PKM_CONFIRM_XML_FOCUS_OWNER_V2150 defaultcontrol=%d python_focus_write=0 requested=%s yes_label=%s no_label=%s" % (
                default_control_v2150, self.default_focus or "yes",
                self.yes_label or "", self.no_label or "",
            ), xbmc.LOGINFO)
        except Exception:
            _log("PKM_CONFIRM_DIALOG_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.YES_ID:
            if callable(self.yes_prepare):
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Settings.SyncHandoffCoverV1747", "1")
                except Exception:
                    pass
                _start_window_stack_probe_v1747("confirm_to_progress")
                _log_window_stack_v1747("confirm_yes_pressed", "window=13031 sync_handoff_cover=1")
                try:
                    prepared = self.yes_prepare()
                except Exception:
                    _log("PKM_CONFIRM_YES_PREPARE_FAILED_V1747\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                    prepared = False
                if prepared is False:
                    try:
                        xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
                    except Exception:
                        pass
                    _log("PKM_CONFIRM_YES_PREPARE_ABORT_V1747 window=13031", xbmc.LOGWARNING)
                    _log_window_stack_v1747("confirm_yes_prepare_abort", "window=13031 sync_handoff_cover=0")
                    return
                _log("PKM_CONFIRM_YES_PREPARE_READY_V1747 window=13031", xbmc.LOGINFO)
            _log_window_stack_v1747("confirm_close_request", "window=13031 result=1")
            self.result = True
            self.close()
        elif controlId == self.NO_ID:
            self.result = False
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if aid in (9, 10, 92, 216, 247):
            self.result = False
            self.close()



def open_pkm_confirm_dialog(title, message, yes_label="예", no_label="아니요", icon1="", icon2="", cine21_rows=None, cine21_logo_icon="", cine21_critic_icon="", cine21_audience_icon="", windowed_video=False, yes_prepare=None, default_focus=None):
    # v2150: destructive confirmation may explicitly request a safe default
    # on the NO button.  That path must always remain a two-button dialog and
    # uses a dedicated XML with defaultcontrol=301.  Other legacy "취소"
    # one-button dialogs keep their existing behavior.
    requested_default_v2150 = str(default_focus or "").strip().lower()
    force_two_button_v2150 = requested_default_v2150 == "no"
    remove_cancel_button = (str(no_label or "").strip() == "취소") and not force_two_button_v2150
    card_r97 = False
    if force_two_button_v2150:
        dialog_xml = "plexkm_pkm_confirm_no_default_dialog.xml"
        # R97D: safe-default destructive confirms use the card style (mockup S5)
        # unless they carry Cine21 rows or logo icons.
        if not (cine21_rows or icon1 or icon2):
            dialog_xml = "plexkm_pkm_card_confirm_dialog.xml"
            card_r97 = True
    else:
        dialog_xml = "plexkm_pkm_confirm_single_dialog.xml" if remove_cancel_button else "plexkm_pkm_confirm_dialog.xml"
    effective_no_label = "" if remove_cancel_button else no_label
    dlg = None
    try:
        _set_confirm_global_props(title, message, yes_label, effective_no_label, icon1, icon2, cine21_rows, cine21_logo_icon, cine21_critic_icon, cine21_audience_icon, windowed_video)
        try:
            if card_r97:
                xbmcgui.Window(10000).setProperty("PlexKM.Confirm.Danger", "1")
            else:
                xbmcgui.Window(10000).clearProperty("PlexKM.Confirm.Danger")
        except Exception:
            pass
        dlg = PKMConfirmDialog(
            dialog_xml,
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            title=title,
            message=message,
            yes_label=yes_label,
            no_label=effective_no_label,
            icon1=icon1,
            icon2=icon2,
            cine21_rows=cine21_rows or [],
            cine21_logo_icon=cine21_logo_icon,
            cine21_critic_icon=cine21_critic_icon,
            cine21_audience_icon=cine21_audience_icon,
            windowed_video=windowed_video,
            yes_prepare=yes_prepare,
            default_focus=default_focus,
        )
        dlg.doModal()
        if not dlg.result:
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
        _log_window_stack_v1747("confirm_modal_return", "window=13031 result=%d" % (1 if dlg.result else 0))
        return bool(dlg.result)
    except Exception:
        _log("PKM_CONFIRM_DIALOG_OPEN_FAILED no_kodi_fallback\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
    finally:
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Confirm.Danger")
        except Exception:
            pass
        try:
            _clear_confirm_global_props()
        except Exception:
            pass
        try:
            del dlg
        except Exception:
            pass


def open_pkm_message_dialog(title, message, ok_label="확인", icon1="", icon2=""):
    return open_pkm_confirm_dialog(
        title, message, yes_label=ok_label or "확인", no_label="", icon1=icon1, icon2=icon2,
    )


def open_pkm_cine21_match_dialog(title, rows, ok_label="닫기", logo_icon="", critic_icon="", audience_icon=""):
    """PKM-styled Cine21 rating sample popup with inline row icons.

    Data-only input.  No DB work, network work, navigation, or focus-flow logic.
    """
    return open_pkm_confirm_dialog(
        title,
        "",
        yes_label=ok_label or "닫기",
        no_label="",
        cine21_rows=list(rows or [])[:3],
        cine21_logo_icon=logo_icon,
        cine21_critic_icon=critic_icon,
        cine21_audience_icon=audience_icon,
    )


def open_pkm_list_dialog(title, labels, multiselect=False, preselect=None):
    dlg = None
    try:
        dlg = PKMListDialog(
            "plexkm_pkm_list_dialog.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            title=title,
            items=list(labels or []),
            multiselect=multiselect,
            preselect=preselect or [],
        )
        dlg.doModal()
        return dlg.result
    except Exception:
        _log("PKM_SETTINGS_DIALOG_OPEN_FAILED no_kodi_fallback\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass


def short_setting_value(value, max_len=34):
    value = value or ""
    if not value:
        return "(비어 있음)"
    if len(value) <= max_len:
        return value
    return value[:max_len]


def _plex_db_path_clean_v1700(value):
    text = str(value or "").strip().strip('"')
    if not text:
        return ""
    if "://" in text:
        return text
    try:
        return os.path.normpath(text)
    except Exception:
        return text


def _plex_db_join_v1700(base_path, name):
    base_path = str(base_path or "")
    name = str(name or "").strip("/\\")
    if "://" in base_path or base_path.startswith("special://"):
        return base_path.rstrip("/\\") + "/" + name
    return os.path.join(base_path, name)


def _plex_db_parent_v1700(path, root_path=""):
    path = _plex_db_path_clean_v1700(path)
    root_path = _plex_db_path_clean_v1700(root_path)
    if not path or path == root_path:
        return ""
    if "://" in path or path.startswith("special://"):
        trimmed = path.rstrip("/\\")
        scheme_pos = trimmed.find("://")
        min_pos = scheme_pos + 3 if scheme_pos >= 0 else 0
        slash_pos = trimmed.rfind("/")
        if slash_pos < min_pos:
            return ""
        parent = trimmed[:slash_pos]
        if root_path and len(parent) < len(root_path.rstrip("/\\")):
            return root_path
        return parent
    try:
        parent = os.path.dirname(path.rstrip("/\\"))
        if not parent or parent == path:
            return ""
        if root_path:
            try:
                if os.path.commonpath([os.path.abspath(parent), os.path.abspath(root_path)]) != os.path.abspath(root_path):
                    return root_path
            except Exception:
                pass
        return parent
    except Exception:
        return ""


def _plex_db_read_header_v1700(path):
    path = _plex_db_path_clean_v1700(path)
    if not path:
        return b""
    translated = xbmcvfs.translatePath(path) if path.startswith("special://") else path
    try:
        if os.path.isfile(translated):
            with open(translated, "rb") as fh:
                return fh.read(16)
    except Exception:
        pass
    handle = None
    try:
        handle = xbmcvfs.File(path, "rb")
        data = handle.read(16)
        if isinstance(data, str):
            data = data.encode("latin-1", "ignore")
        return bytes(data or b"")
    except Exception:
        return b""
    finally:
        try:
            if handle:
                handle.close()
        except Exception:
            pass


def _validate_plex_db_path_v1700(path, notify=True):
    path = _plex_db_path_clean_v1700(path)
    if not path:
        return False
    if not path.lower().split("?", 1)[0].endswith(".db"):
        if notify:
            _notify(".db 파일을 선택해야 합니다", icon=xbmcgui.NOTIFICATION_WARNING)
        return False
    header = _plex_db_read_header_v1700(path)
    if not header.startswith(b"SQLite format 3"):
        if notify:
            _notify("Plex DB 파일을 읽을 수 없습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4500)
        _log("PKM_PLEX_DB_VALIDATE_FAIL_V1700 path=%s header=%s" % (path, repr(header[:16])), xbmc.LOGWARNING)
        return False
    _log("PKM_PLEX_DB_VALIDATE_OK_V1700 path=%s remote=%s" % (path, "1" if "://" in path else "0"), xbmc.LOGINFO)
    return True


def _windows_drive_roots_v1700():
    """Return Windows logical drive roots without touching each volume.

    v2372: probing A:\\..Z:\\ with os.path.exists() can block on mapped
    network/cloud drives before the browser is even drawn.  GetLogicalDrives
    reads the OS bitmask in one call and does not open the volume, so entering
    the PKM DB browser remains immediate even with NAS/Google Drive mappings.
    """
    rows = []
    if os.name != "nt":
        return rows
    try:
        import ctypes
        mask = int(ctypes.windll.kernel32.GetLogicalDrives())
        if mask:
            for idx, letter in enumerate(string.ascii_uppercase):
                if mask & (1 << idx):
                    rows.append(("%s:\\" % letter, letter + ":\\"))
            return rows
    except Exception:
        _log("PKM_WINDOWS_DRIVE_MASK_FAILED_V2372 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    # Fallback only when the Win32 bitmask is unavailable.
    for letter in string.ascii_uppercase:
        path = letter + ":\\"
        try:
            if os.path.exists(path):
                rows.append(("%s:\\" % letter, path))
        except Exception:
            pass
    return rows


def _local_storage_roots_v1700():
    rows = _windows_drive_roots_v1700()
    candidates = [
        ("Kodi 홈 폴더", "special://home/"),
        ("Kodi 프로필 폴더", "special://profile/"),
        ("Android 내부 저장소", "/storage/emulated/0"),
        ("Android 저장소", "/storage"),
    ]
    seen = set(path for _, path in rows)
    for label, path in candidates:
        try:
            translated = xbmcvfs.translatePath(path) if path.startswith("special://") else path
            exists = bool(xbmcvfs.exists(path) or os.path.exists(translated))
        except Exception:
            exists = False
        if exists and path not in seen:
            rows.append((label, path))
            seen.add(path)
    return rows


def _kodi_file_sources_v1700():
    result = []
    seen = set()
    source_file = xbmcvfs.translatePath("special://profile/sources.xml")
    try:
        root = ET.parse(source_file).getroot()
        for section_name in ("files", "video", "music", "pictures"):
            section = root.find(section_name)
            if section is None:
                continue
            for source in section.findall("source"):
                name = (source.findtext("name") or "Kodi 소스").strip()
                paths = source.findall("path")
                for path_node in paths:
                    path = (path_node.text or "").strip()
                    if not path or path in seen:
                        continue
                    if "://" not in path and not path.startswith("special://"):
                        continue
                    result.append((name, path))
                    seen.add(path)
    except Exception:
        _log("PKM_KODI_SOURCES_READ_FAIL_V1700 path=%s err=%s" % (source_file, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
    return result


def _plex_db_list_directory_v1700(path):
    path = _plex_db_path_clean_v1700(path)
    dirs, files = xbmcvfs.listdir(path)
    out = []
    for name in sorted([str(x or "").rstrip("/\\") for x in dirs or [] if str(x or "").strip()], key=lambda x: x.lower()):
        out.append({"kind": "dir", "name": name, "path": _plex_db_join_v1700(path, name)})
    for name in sorted([str(x or "").rstrip("/\\") for x in files or [] if str(x or "").lower().endswith(".db")], key=lambda x: x.lower()):
        out.append({"kind": "file", "name": name, "path": _plex_db_join_v1700(path, name)})
    return out


def _rating_db_list_directory_v2372(path, expected_name):
    """List folders plus only the requested external-rating DB filename."""
    path = _plex_db_path_clean_v1700(path)
    expected = str(expected_name or "").strip().lower()
    dirs, files = xbmcvfs.listdir(path)
    out = []
    for name in sorted([str(x or "").rstrip("/\\") for x in dirs or [] if str(x or "").strip()], key=lambda x: x.lower()):
        out.append({"kind": "dir", "name": name, "path": _plex_db_join_v1700(path, name)})
    for name in sorted([str(x or "").rstrip("/\\") for x in files or [] if str(x or "").strip()], key=lambda x: x.lower()):
        if expected and name.lower() != expected:
            continue
        if not expected and not name.lower().endswith(".db"):
            continue
        out.append({"kind": "file", "name": name, "path": _plex_db_join_v1700(path, name)})
    return out


def _live_plex_addon_targets_v1922():
    targets = []
    candidates = [ADDON, getattr(_core(), "ADDON", None)]
    for module_name in ("resources.lib.pkm_token_import", "pkm_token_import"):
        try:
            candidates.append(getattr(sys.modules.get(module_name), "ADDON", None))
        except Exception:
            pass
    for candidate in candidates:
        if candidate is not None and all(candidate is not existing for existing in targets):
            targets.append(candidate)
    return targets


def _publish_live_plex_settings_v1922(server=None, token=None, account=None, reason=""):
    """Publish one authoritative URL/token set to every live wrapper and Home."""
    server = (ADDON.getSetting("plex_url") or "").strip() if server is None else str(server or "").strip()
    token = (ADDON.getSetting("plex_token") or "").strip() if token is None else str(token or "").strip()
    account = (ADDON.getSetting("plex_account_name") or "").strip() if account is None else str(account or "").strip()
    verified = True
    targets = _live_plex_addon_targets_v1922()
    for target in targets:
        try:
            target.setSetting("plex_url", server)
            target.setSetting("plex_token", token)
            target.setSetting("plex_account_name", account)
        except Exception:
            verified = False
    try:
        runtime = xbmcgui.Window(10000)
        runtime.setProperty("PlexKM.Runtime.PlexURL", server)
        runtime.setProperty("PlexKM.Runtime.PlexToken", token)
        runtime.setProperty("PlexKM.Runtime.PlexAccount", account)
        runtime.setProperty("PlexKM.Runtime.PlexAuthAuthoritative", "1")
    except Exception:
        verified = False
    # R108: a saved Plex server becomes (or stays) a registered content source.
    if server and token:
        try:
            from resources.lib import pkm_sources as _pkm_sources_r108
            _pkm_sources_r108.add_plex_source(reason=str(reason or "plex_settings_saved"))
        except Exception as _exc_r108:
            _log("PKM_SOURCES_R108_ADD_PLEX_FAILED err=%s" % _exc_r108, xbmc.LOGWARNING)
    _log("PKM_PLEX_RUNTIME_AUTHORITATIVE_V1922 reason=%s server=%s token=%s targets=%d verified=%s" % (
        str(reason or ""), "1" if server else "0", "1" if token else "0", len(targets), "1" if verified else "0"
    ), xbmc.LOGINFO if verified else xbmc.LOGWARNING)
    return verified


def _r45_ddns_diagnostic(server, stage, error=None, elapsed_ms=None):
    """Read-only DNS/URL diagnostics. Never log tokens or query strings."""
    try:
        import socket
        parsed = urlparse(str(server or ""))
        host = parsed.hostname or ""
        scheme = (parsed.scheme or "http").lower()
        port = parsed.port or (443 if scheme == "https" else 80)
        if not host:
            _log("PKM_DDNS_DIAG_R45 stage=%s result=missing_host" % stage, xbmc.LOGWARNING)
            return
        try:
            infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            ips = sorted(set(str(info[4][0]) for info in infos if info[4]))
            dns_result = ",".join(ips) or "none"
        except Exception as dns_exc:
            dns_result = "ERROR:%s:%s" % (type(dns_exc).__name__, str(dns_exc)[:180])
        # Do not log authentication data or full URLs (which might contain credentials).
        _log("PKM_DDNS_DIAG_R45 stage=%s scheme=%s host=%s port=%s resolved_ips=%s elapsed_ms=%s error_type=%s error=%s" % (
            str(stage), scheme, host, port, dns_result,
            "-" if elapsed_ms is None else int(elapsed_ms),
            type(error).__name__ if error is not None else "none",
            str(error).replace("\n", " ")[:220] if error is not None else "none",
        ), xbmc.LOGWARNING if error is not None else xbmc.LOGINFO)
    except Exception as diag_exc:
        _log("PKM_DDNS_DIAG_R45 stage=%s diagnostic_error=%s" % (stage, str(diag_exc)[:160]), xbmc.LOGWARNING)


def _r252_is_private_host(url):
    """True when the server address is a LAN IP (a DDNS name cannot be verified from inside the LAN)."""
    try:
        import ipaddress
        from urllib.parse import urlparse
        return ipaddress.ip_address(urlparse(str(url or "")).hostname or "").is_private
    except Exception:
        return False


def _probe_candidate_plex_url_v1922(server, timeout=3.5):
    started = time.monotonic()
    _r45_ddns_diagnostic(server, "candidate_before_identity")
    try:
        if not pkm_plex_client or not hasattr(pkm_plex_client, "probe_server_identity_explicit"):
            raise RuntimeError("explicit Plex identity probe is unavailable")
        pkm_plex_client.probe_server_identity_explicit(server, timeout=timeout, env=_settings_plex_client_env())
        _r45_ddns_diagnostic(server, "candidate_identity_ok", elapsed_ms=(time.monotonic()-started)*1000)
        _log("PKM_PLEX_URL_CANDIDATE_OK_V1922 server=%s" % str(server or ""), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _r45_ddns_diagnostic(server, "candidate_identity_failed", error=exc, elapsed_ms=(time.monotonic()-started)*1000)
        _log("PKM_PLEX_URL_CANDIDATE_REJECT_V1922 server=%s err=%s" % (str(server or ""), str(exc)), xbmc.LOGWARNING)
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                token = pkm_notify.pkm_notice_set(
                    "Plex 서버 확인 필요",
                    "내부 주소 응답이 없습니다",
                    "주소와 포트를 확인하세요",
                    sticky=False,
                    force_replace=True,
                )
                if hasattr(pkm_notify, "pkm_notice_clear_later"):
                    pkm_notify.pkm_notice_clear_later(token, ms=5200)
        except Exception:
            pass
        return False


def _reset_plex_connection_v1922():
    """Clear only Plex server/authentication values; preserve PKM DB and library data."""
    try:
        for target in _live_plex_addon_targets_v1922():
            for key in ("plex_url", "plex_token", "plex_account_name", "plex_url_history"):
                try:
                    target.setSetting(key, "")
                except Exception:
                    pass
        _publish_live_plex_settings_v1922(server="", token="", account="", reason="connection_reset_v1997")

        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Settings.ServerSwitchPendingV1310",
            "PlexKM.Settings.ServerSwitchPendingReasonV1310",
            "PlexKM.Home.ServerSwitchPending",
            "PlexKM.Home.ServerSwitchPendingLine1",
            "PlexKM.Home.ServerSwitchPendingLine2",
            "PlexKM.Home.ServerSwitchPendingReason",
            "PlexKM.Home.ServerSwitchPendingAt",
            "PlexKM.PlexOffline",
            "PlexKM.PlexOfflineReason",
            "PlexKM.PlexOfflineLine1",
            "PlexKM.PlexOfflineLine2",
            "PlexKM.PlexOfflineAt",
        ):
            try:
                win.clearProperty(key)
            except Exception:
                pass
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear"):
                pkm_notify.pkm_notice_clear(force=True)
        except Exception:
            pass
        # v2013: the Home WindowXML remains alive behind the settings modal.
        # Rebuild its empty connection-reset surface immediately so the menu
        # selection is normalized to Home before the modal is closed.
        # This uses the existing live-home purge path; it does not delete the
        # preserved PKM database or library metadata.
        _signal_home_refresh_from_settings(reason="plex_connection_reset_full_v2005")
        try:
            win.setProperty("PlexKM.Home.ConnectionResetReturnV2013", "1")
        except Exception:
            pass
        _log("PKM_PLEX_CONNECTION_ONLY_RESET_DONE home_refresh=1 db_preserved=1", xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_PLEX_CONNECTION_ONLY_RESET_FAILED_V1997 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return False

def _clear_plex_connection_state(reason="settings_probe_ok"):
    """Clear sticky Plex offline/connection notice after a confirmed settings probe."""
    cleared_notice = False
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear_if_title"):
            cleared_notice = bool(pkm_notify.pkm_notice_clear_if_title(["Plex 연결 실패", "Plex 연결 확인 중"], force=True))
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Notify.Title") in ("Plex 연결 실패", "Plex 연결 확인 중"):
            for key in ("PlexKM.Notify.Active", "PlexKM.Notify.Title", "PlexKM.Notify.Line1", "PlexKM.Notify.Line2", "PlexKM.Notify.Token", "PlexKM.Notify.Sticky"):
                win.clearProperty(key)
            cleared_notice = True
        for key in ("PlexKM.PlexOffline", "PlexKM.PlexOfflineReason", "PlexKM.PlexOfflineLine1", "PlexKM.PlexOfflineLine2", "PlexKM.PlexOfflineAt"):
            win.clearProperty(key)
    except Exception:
        pass
    _log("PKM_SETTINGS_PLEX_NOTICE_CLEAR_V1310 reason=%s cleared=%s" % (str(reason or ""), "1" if cleared_notice else "0"), xbmc.LOGINFO)
    return True


def _settings_plex_client_env():
    return {
        "addon": ADDON,
        "addon_name": ADDON_NAME,
        "log": _log,
        "pkm_notice_set": getattr(pkm_notify, "pkm_notice_set", None) if pkm_notify else None,
        "pkm_notice_clear": getattr(pkm_notify, "pkm_notice_clear", None) if pkm_notify else None,
        "pkm_notice_clear_later": getattr(pkm_notify, "pkm_notice_clear_later", None) if pkm_notify else None,
        "pkm_notice_clear_if_title": getattr(pkm_notify, "pkm_notice_clear_if_title", None) if pkm_notify else None,
        "pkm_show_notice": getattr(pkm_notify, "pkm_show_notice", None) if pkm_notify else None,
    }


def _server_host_key_v1310(url):
    try:
        text = str(url or "").strip()
        if not text:
            return ""
        if "://" not in text:
            text = "http://" + text
        parsed = urlparse(text)
        host = (getattr(parsed, "netloc", "") or "").strip().lower()
        if "@" in host:
            host = host.rsplit("@", 1)[-1]
        return host.rstrip("/")
    except Exception:
        return ""


def _current_server_identity_v1310():
    try:
        server = (ADDON.getSetting("plex_url") or "").strip().rstrip("/")
        token = (ADDON.getSetting("plex_token") or "").strip()
        host = _server_host_key_v1310(server)
        if not server or not token or not host:
            return {}
        sig = hashlib.sha1(("v1310|%s|%s" % (host, token)).encode("utf-8")).hexdigest()
        return {"signature": sig, "server_url": server, "server_host": host}
    except Exception:
        return {}


def _save_current_server_identity_v1310(core=None, reason=""):
    try:
        info = _current_server_identity_v1310()
        if not info:
            return False
        core = core or _core()
        state = core.load_state() if core and hasattr(core, "load_state") else {}
        if not isinstance(state, dict):
            state = {}
        state["plex_server_signature_v1310"] = info.get("signature", "")
        state["plex_server_url_v1310"] = info.get("server_url", "")
        state["plex_server_host_v1310"] = info.get("server_host", "")
        state["plex_server_identity_saved_at_v1310"] = int(time.time())
        state["plex_server_identity_reason_v1310"] = str(reason or "")
        if core and hasattr(core, "save_state"):
            core.save_state(state)
            _log("PKM_SETTINGS_SERVER_IDENTITY_SAVE_V1310 reason=%s host=%s sig=%s" % (str(reason or ""), info.get("server_host", ""), (info.get("signature", "")[:10] if info.get("signature") else "")), xbmc.LOGINFO)
            return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_IDENTITY_SAVE_FAILED_V1310 reason=%s err=%s" % (str(reason or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
    return False


def _clear_server_switch_side_files_v1310(reason=""):
    removed = []
    try:
        base = ADDON.getAddonInfo("profile")
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        for name in ("playstate_continue_preload.json", "playstate_resume.json", "large_wall_focus_state.json"):
            path = os.path.join(base, name)
            try:
                if path and os.path.exists(path):
                    os.remove(path)
                    removed.append(name)
            except Exception:
                pass
    except Exception:
        pass
    _log("PKM_SETTINGS_SERVER_SWITCH_SIDE_FILES_CLEAR_V1310 reason=%s removed=%s" % (str(reason or ""), ",".join(removed)), xbmc.LOGINFO)
    return removed


def _signal_home_refresh_from_settings(reason="settings_plex_connected_v1310"):
    try:
        core = _core()
        if core and hasattr(core, "_signal_home_data_refresh"):
            core._signal_home_data_refresh(reason=reason)
            return True
    except Exception:
        pass
    try:
        token = "%d" % int(time.time() * 1000)
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.DataRefreshToken", token)
        win.setProperty("PlexKM.Home.DataRefreshReason", str(reason or "settings_plex_connected_v1310"))
        _log("HOME_DATA_REFRESH_SIGNAL reason=%s token=%s" % (str(reason or ""), token), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _set_server_switch_pending_v1310(value=True, reason=""):
    try:
        win = xbmcgui.Window(10000)
        if value:
            win.setProperty("PlexKM.Settings.ServerSwitchPendingV1310", "1")
            win.setProperty("PlexKM.Settings.ServerSwitchPendingReasonV1310", str(reason or "url_changed"))
            _set_server_switch_pending_home_ui_v1310(
                "Plex 서버 연결 확인 중",
                "라이브러리 정보를 확인합니다",
                reason=reason or "url_changed",
            )
        else:
            win.clearProperty("PlexKM.Settings.ServerSwitchPendingV1310")
            win.clearProperty("PlexKM.Settings.ServerSwitchPendingReasonV1310")
        _log("PKM_SETTINGS_SERVER_SWITCH_PENDING_V1310 value=%s reason=%s" % ("1" if value else "0", str(reason or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _server_switch_pending_v1310():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.Settings.ServerSwitchPendingV1310") == "1"
    except Exception:
        return False


def _set_server_switch_pending_home_ui_v1310(line1="Plex 서버 연결 확인 중", line2="라이브러리 정보를 확인합니다", reason=""):
    """Hide stale Home widgets as soon as the server/token is changed.

    The DB may still contain the previous server until the new server is fully
    validated and synced.  Keep old widgets hidden, but do not draw a large
    blank-screen text overlay; status is shown only through the PKM notice.
    """
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.ServerSwitchPending", "1")
        win.setProperty("PlexKM.Home.ServerSwitchPendingLine1", _display_text_for_kodi(line1 or "Plex 서버 연결 확인 중"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingLine2", _display_text_for_kodi(line2 or "라이브러리 정보를 확인합니다"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingReason", str(reason or "settings_server_switch_pending_v1310"))
        win.setProperty("PlexKM.Home.ServerSwitchPendingAt", str(int(time.time() * 1000)))
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                pkm_notify.pkm_notice_set(
                    "Plex 연결 확인 중",
                    _display_text_for_kodi(line1 or "Plex 서버 연결 확인 중"),
                    "라이브러리 정보를 확인합니다",
                    sticky=True,
                    force_replace=True,
                )
        except Exception:
            pass
        # v1312: do not use Kodi native toast here. The PKM XML overlay is
        # drawn inside the settings dialog so the notice style matches Home.
        _signal_home_refresh_from_settings(reason="settings_server_switch_pending_v1310")
        _log("PKM_SETTINGS_SERVER_SWITCH_NOTICE_ONLY_PENDING_V1310 reason=%s line1=%s" % (str(reason or ""), _display_text_for_kodi(line1 or "")), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_HOME_PENDING_FAILED_V1310 reason=%s err=%s" % (str(reason or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        return False


def _clear_server_switch_pending_home_ui_v1310(reason=""):
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Home.ServerSwitchPending",
            "PlexKM.Home.ServerSwitchPendingLine1",
            "PlexKM.Home.ServerSwitchPendingLine2",
            "PlexKM.Home.ServerSwitchPendingReason",
            "PlexKM.Home.ServerSwitchPendingAt",
        ):
            win.clearProperty(key)
        _log("PKM_SETTINGS_SERVER_SWITCH_HOME_PENDING_CLEAR_V1310 reason=%s" % (str(reason or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _reset_sidebar_order_file_v1310(section_ids):
    try:
        base = ADDON.getAddonInfo("profile")
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        if base and not os.path.isdir(base):
            os.makedirs(base, exist_ok=True)
        path = os.path.join(base, "sidebar_order.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"version": 1, "section_order": [str(x) for x in (section_ids or []) if str(x)]}, f, ensure_ascii=False, indent=2)
        _log("PKM_SETTINGS_SERVER_SWITCH_SIDEBAR_ORDER_RESET_V1310 count=%d path=%s" % (len(section_ids or []), path), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SIDEBAR_ORDER_RESET_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return False


def _clear_server_cache_tables_v1310(core):
    removed = {}
    try:
        conn = core.init_db()
        try:
            for table in (
                "items", "sections", "sync_state",
                "item_people", "item_genres", "item_countries", "item_ratings", "item_studios", "item_recommend_index_state",
                "cine21_matches", "cine21_match_summary"
            ):
                try:
                    cur = conn.execute("DELETE FROM %s" % table)
                    removed[table] = int(getattr(cur, "rowcount", 0) or 0)
                except Exception:
                    removed[table] = -1
            conn.commit()
        finally:
            conn.close()
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_CACHE_CLEAR_FAILED_V1310 main err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        if hasattr(core, "search_db_path"):
            sconn = sqlite3.connect(core.search_db_path(), timeout=8.0)
            try:
                if hasattr(core, "init_search_db"):
                    core.init_search_db(sconn)
                try:
                    sconn.execute("DELETE FROM search_items")
                except Exception:
                    pass
                try:
                    sconn.execute("UPDATE search_index_state SET source_count=0, search_count=0, source_max_synced_at=0, indexed_at=?, last_error='' WHERE id=1", (int(time.time()),))
                except Exception:
                    pass
                sconn.commit()
            finally:
                sconn.close()
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SEARCH_CLEAR_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        _clear_server_switch_side_files_v1310(reason="server_cache_clear_v1310")
    except Exception:
        pass
    _log("PKM_SETTINGS_SERVER_SWITCH_CACHE_CLEAR_V1310 removed=%s" % ",".join(["%s:%s" % (k, removed.get(k)) for k in sorted(removed.keys())]), xbmc.LOGINFO)
    return True


def _write_remote_sections_v1310(core, sections):
    count = 0
    conn = core.init_db()
    try:
        for section in sections or []:
            try:
                if hasattr(core, "upsert_section"):
                    core.upsert_section(conn, section)
                else:
                    conn.execute(
                        "INSERT OR REPLACE INTO sections(section_id,title,section_type,thumb,art,scanned_at,item_count) VALUES(?,?,?,?,?,?,?)",
                        (str(section.get("section_id", "")), section.get("title", ""), section.get("section_type", ""), section.get("thumb", ""), section.get("art", ""), int(section.get("scanned_at", 0) or 0), int(section.get("item_count", 0) or 0))
                    )
                count += 1
            except Exception:
                pass
        conn.commit()
    finally:
        conn.close()
    _log("PKM_SETTINGS_SERVER_SWITCH_SECTIONS_WRITE_V1310 count=%d" % count, xbmc.LOGINFO)
    return count


def _reset_selection_for_server_sections_v1310(core, sections, reason="server_switch_v1310"):
    section_ids = [str(s.get("section_id", "")) for s in (sections or []) if str(s.get("section_id", ""))]
    default_ids = section_ids[:min(3, len(section_ids))]
    try:
        state = core.load_state() if hasattr(core, "load_state") else {}
        if not isinstance(state, dict):
            state = {}
        state["section_order"] = list(section_ids)
        state["section_order_updated_at"] = int(time.time())
        state["selected_sections"] = list(default_ids)
        state["selected_sections_configured"] = True
        state["selected_sections_updated_at"] = int(time.time())
        state["selected_sections_bootstrap_reason"] = str(reason or "server_switch_v1310")
        state["server_switch_reset_v1310_at"] = int(time.time())
        try:
            ident = _current_server_identity_v1310()
            if ident:
                state["plex_server_signature_v1310"] = ident.get("signature", "")
                state["plex_server_url_v1310"] = ident.get("server_url", "")
                state["plex_server_host_v1310"] = ident.get("server_host", "")
                state["plex_server_identity_saved_at_v1310"] = int(time.time())
                state["plex_server_identity_reason_v1310"] = str(reason or "server_switch_v1310")
        except Exception:
            pass
        if hasattr(core, "save_state"):
            core.save_state(state)
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_STATE_SAVE_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    try:
        if hasattr(core, "set_initial_sync_done"):
            core.set_initial_sync_done(False)
    except Exception:
        pass
    try:
        if hasattr(core, "set_last_auto_sync_at"):
            core.set_last_auto_sync_at(0)
    except Exception:
        pass
    _reset_sidebar_order_file_v1310(section_ids)
    _log("PKM_SETTINGS_SERVER_SWITCH_SELECTION_RESET_V1310 sections=%d default_selected=%s" % (len(section_ids), ",".join(default_ids)), xbmc.LOGINFO)
    return default_ids


def _apply_server_switch_reset_v1310(remote_sections, reason="settings_probe_ok_v1310"):
    core = _core()
    if not core:
        _log("PKM_SETTINGS_SERVER_SWITCH_RESET_SKIP_V1310 reason=no_core", xbmc.LOGWARNING)
        return []
    remote_sections = list(remote_sections or [])
    if not remote_sections:
        _log("PKM_SETTINGS_SERVER_SWITCH_RESET_SKIP_V1310 reason=no_sections", xbmc.LOGWARNING)
        return []
    _clear_server_cache_tables_v1310(core)
    _write_remote_sections_v1310(core, remote_sections)
    default_ids = _reset_selection_for_server_sections_v1310(core, remote_sections, reason=reason)
    try:
        if default_ids and hasattr(core, "sync_all_sections"):
            notice_token = ""
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    notice_token = pkm_notify.pkm_notice_set(
                        "PlexKM 업데이트 중",
                        "라이브러리 0/%d 준비 중" % len(default_ids),
                        "라이브러리 싱크 중",
                        sticky=True,
                        force_replace=True,
                    )
                    _log("PKM_SETTINGS_INITIAL_SYNC_NOTICE_SET_V1311 token=%s sections=%s" % (str(notice_token or ""), ",".join(default_ids)), xbmc.LOGINFO)
            except Exception:
                pass
            _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_BEGIN_V1310 sections=%s" % ",".join(default_ids), xbmc.LOGINFO)
            fetched = core.sync_all_sections(show_prompt=False, show_progress=False, mark_auto_sync=True, section_ids=default_ids, progress_title="라이브러리 싱크")
            _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_DONE_V1310 sections=%s fetched=%s" % (",".join(default_ids), str(fetched)), xbmc.LOGINFO)
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    done_token = pkm_notify.pkm_notice_set(
                        "PlexKM 업데이트 완료",
                        "라이브러리 %d개 싱크 완료" % len(default_ids),
                        "홈 위젯 갱신 중",
                        sticky=False,
                        force_replace=True,
                    )
                    if hasattr(pkm_notify, "pkm_notice_clear_later"):
                        pkm_notify.pkm_notice_clear_later(done_token, ms=1800)
            except Exception:
                pass
    except Exception:
        _log("PKM_SETTINGS_SERVER_SWITCH_SYNC_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                pkm_notify.pkm_notice_set("PlexKM 업데이트 실패", "라이브러리 싱크 실패", "Plex 서버 상태를 확인해주세요", sticky=True, force_replace=True)
        except Exception:
            pass
        return []
    return default_ids


def _show_plex_connected_notice_v1310(line2="홈 위젯을 갱신합니다"):
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            notice_token = pkm_notify.pkm_notice_set("Plex 연결됨", "Plex 서버 연결 확인 완료", line2, sticky=False, force_replace=True)
            _log("PKM_SETTINGS_PLEX_CONNECTED_NOTICE_SET_V1310 token=%s line2=%s" % (str(notice_token or ""), _display_text_for_kodi(line2 or "")), xbmc.LOGINFO)
            if hasattr(pkm_notify, "pkm_notice_clear_later"):
                pkm_notify.pkm_notice_clear_later(notice_token, ms=7200)
    except Exception:
        _log("PKM_SETTINGS_PLEX_CONNECTED_NOTICE_SET_FAILED_V1310 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    # v1312: PKM XML overlay only; no Kodi native text-only toast.


def _show_plex_library_probe_failed_v1310(exc, reason="settings_probe_sections_fail_v1310"):
    msg = str(exc or "")
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.PlexOffline", "1")
        win.setProperty("PlexKM.PlexOfflineReason", str(reason or "settings_sections_probe_fail_v1310"))
        win.setProperty("PlexKM.PlexOfflineLine1", "Plex 라이브러리 접근 실패")
        win.setProperty("PlexKM.PlexOfflineLine2", "주소/포트/토큰을 확인해주세요")
        win.setProperty("PlexKM.PlexOfflineAt", str(int(time.time())))
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 라이브러리 접근 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
    except Exception:
        pass
    try:
        _set_server_switch_pending_home_ui_v1310("Plex 라이브러리 접근 실패", "주소/포트/토큰 확인 후 다시 저장해주세요", reason=reason or "settings_sections_probe_fail_v1310")
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 라이브러리 접근 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
            _log("PKM_SETTINGS_PLEX_FAIL_NOTICE_RESTORE_V1312 type=library", xbmc.LOGINFO)
    except Exception:
        pass
    # v1312: PKM XML overlay only; no Kodi native text-only toast.
    _log("PKM_SETTINGS_PLEX_LIBRARY_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), msg), xbmc.LOGWARNING)


def _show_plex_connection_probe_failed_v1310(exc, reason="settings_identity_probe_fail_v1310"):
    msg = str(exc or "")
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.PlexOffline", "1")
        win.setProperty("PlexKM.PlexOfflineReason", str(reason or "settings_identity_probe_fail_v1310"))
        win.setProperty("PlexKM.PlexOfflineLine1", "Plex 서버 연결 실패")
        win.setProperty("PlexKM.PlexOfflineLine2", "주소/포트/토큰을 확인해주세요")
        win.setProperty("PlexKM.PlexOfflineAt", str(int(time.time())))
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 서버 연결 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
    except Exception:
        pass
    try:
        _set_server_switch_pending_home_ui_v1310("Plex 서버 연결 실패", "주소/포트/토큰 확인 후 다시 저장해주세요", reason=reason or "settings_identity_probe_fail_v1310")
    except Exception:
        pass
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set("Plex 연결 실패", "Plex 서버 연결 실패", "주소/포트/토큰을 확인해주세요", sticky=True, force_replace=True)
            _log("PKM_SETTINGS_PLEX_FAIL_NOTICE_RESTORE_V1312 type=identity", xbmc.LOGINFO)
    except Exception:
        pass
    # v1312: PKM XML overlay only; no Kodi native text-only toast.
    _log("PKM_SETTINGS_PLEX_CONNECTION_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), msg), xbmc.LOGWARNING)



def _normalize_plex_server_url_v1313(value):
    """Normalize the user-entered Plex server URL without dropping the port."""
    text = str(value or "").strip()
    if not text:
        return ""
    if "://" not in text:
        text = "http://" + text
    # Keep host:port exactly as entered, but remove trailing slash/path spaces.
    return text.rstrip("/")



def _show_plex_endpoint_error_v1730(line1, line2=""):
    """Show a PKM-owned address/port validation notice without opening Kodi UI."""
    title = "Plex 서버 주소 오류"
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
            pkm_notify.pkm_notice_set(title, str(line1 or ""), str(line2 or ""), sticky=False, force_replace=True)
            return
    except Exception:
        pass
    _log(
        "PKM_NATIVE_NOTIFICATION_SUPPRESSED_V2378R7 heading=%s message=%s"
        % (str(title or ""), str(line1 or "")),
        xbmc.LOGINFO,
    )


def _split_plex_server_endpoint_v1730(value, default_port="32400"):
    """Return (address_without_port, port) for the split inline editor.

    Missing ports are shown as the editable default only.  This helper never
    writes the default back to settings; the user must confirm the split form.
    """
    text = str(value or "").strip().rstrip("/")
    if not text:
        return "", str(default_port or "32400")
    parse_text = text if "://" in text else "http://" + text
    try:
        parsed = urlparse(parse_text)
        host = str(parsed.hostname or "").strip()
        if not host:
            return text, str(default_port or "32400")
        try:
            port = str(parsed.port) if parsed.port is not None else str(default_port or "32400")
        except Exception:
            port = ""
        host_display = ("[" + host + "]") if (":" in host and not host.startswith("[")) else host
        address = "%s://%s" % (str(parsed.scheme or "http").lower(), host_display)
        path = str(parsed.path or "").rstrip("/")
        if path:
            address += path
        return address, port
    except Exception:
        return text, str(default_port or "32400")


def _combine_plex_server_endpoint_v1730(address, port, notify=True):
    """Validate split fields and build one explicit PMS endpoint."""
    raw_address = str(address or "").strip().rstrip("/")
    raw_port = str(port or "").strip()
    if not raw_address:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소를 입력해주세요", "주소 입력칸을 확인해주세요")
        return "", "address"
    if not raw_port:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트가 없습니다", "포트 입력칸을 확인해주세요")
        return "", "port"
    if not raw_port.isdigit():
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트가 올바르지 않습니다", "숫자 포트를 입력해주세요")
        return "", "port"
    port_num = int(raw_port)
    if port_num < 1 or port_num > 65535:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 포트 범위가 올바르지 않습니다", "1부터 65535 사이로 입력해주세요")
        return "", "port"

    parse_text = raw_address if "://" in raw_address else "http://" + raw_address
    try:
        parsed = urlparse(parse_text)
        scheme = str(parsed.scheme or "http").lower()
        if scheme not in ("http", "https"):
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "http:// 또는 https:// 주소를 입력해주세요")
            return "", "address"
        if parsed.username or parsed.password:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "사용자 정보가 없는 서버 주소를 입력해주세요")
            return "", "address"
        try:
            embedded_port = parsed.port
        except Exception:
            embedded_port = -1
        if embedded_port is not None:
            if notify:
                _show_plex_endpoint_error_v1730("포트가 주소 입력칸에 포함되어 있습니다", "포트는 오른쪽 포트 입력칸에 입력해주세요")
            return "", "address"
        host = str(parsed.hostname or "").strip()
        if not host:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "서버 호스트 주소를 확인해주세요")
            return "", "address"
        if parsed.query or parsed.fragment:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "쿼리나 앵커를 제거해주세요")
            return "", "address"
        host_display = ("[" + host + "]") if (":" in host and not host.startswith("[")) else host
        path = str(parsed.path or "").rstrip("/")
        return "%s://%s:%d%s" % (scheme, host_display, port_num, path), ""
    except Exception:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소 형식이 올바르지 않습니다", "주소와 포트를 확인해주세요")
        return "", "address"


def _validate_saved_plex_endpoint_v1730(value, notify=True):
    """Require an explicit valid port before Plex link authentication starts."""
    text = str(value or "").strip().rstrip("/")
    if not text:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소를 먼저 입력해주세요", "서버 주소와 포트를 저장한 후 인증해주세요")
        return False
    parse_text = text if "://" in text else "http://" + text
    try:
        parsed = urlparse(parse_text)
        if not parsed.hostname:
            raise ValueError("missing host")
        port = parsed.port
        if port is None:
            if notify:
                _show_plex_endpoint_error_v1730("Plex 서버 포트가 없습니다", "서버 주소에서 포트를 설정한 후 인증해주세요")
            return False
        if int(port) < 1 or int(port) > 65535:
            raise ValueError("port range")
        if str(parsed.scheme or "").lower() not in ("http", "https"):
            raise ValueError("scheme")
        return True
    except ValueError as exc:
        if "missing host" in str(exc):
            line1, line2 = "Plex 서버 주소가 올바르지 않습니다", "서버 주소를 다시 입력해주세요"
        elif "port range" in str(exc):
            line1, line2 = "Plex 서버 포트 범위가 올바르지 않습니다", "1부터 65535 사이로 입력해주세요"
        elif "scheme" in str(exc):
            line1, line2 = "Plex 서버 주소 형식이 올바르지 않습니다", "http:// 또는 https:// 주소를 입력해주세요"
        else:
            line1, line2 = "Plex 서버 포트가 올바르지 않습니다", "주소와 포트를 다시 입력해주세요"
        if notify:
            _show_plex_endpoint_error_v1730(line1, line2)
        return False
    except Exception:
        if notify:
            _show_plex_endpoint_error_v1730("Plex 서버 주소가 올바르지 않습니다", "주소와 포트를 다시 입력해주세요")
        return False


def _fetch_remote_sections_direct_v1313(reason="settings_probe_sections_v1313"):
    """Probe /library/sections through the same settings Plex client/env used for /identity.

    v1312 called default.py fetch_sections() after /identity.  In settings-dialog
    RunScript mode that path could still use an older/cached server URL and drop
    the :32400 port, producing a false library failure even though the dialog
    displayed the corrected URL.  This direct probe keeps identity and sections
    on the same freshly saved server setting.
    """
    sections = []
    server = _normalize_plex_server_url_v1313(ADDON.getSetting("plex_url") or "")
    try:
        ADDON.setSetting("plex_url", server)
    except Exception:
        pass
    try:
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_V1313 reason=%s server=%s" % (str(reason or ""), server), xbmc.LOGINFO)
        root = pkm_plex_client.plex_request_xml("/library/sections", timeout=20, log_failures=False, env=_settings_plex_client_env())
        now = int(time.time())
        for d in list(root):
            try:
                if getattr(d, "tag", "") != "Directory":
                    continue
                section_type = d.get("type", "")
                if section_type not in ("movie", "show"):
                    continue
                section_updated_at = 0
                try:
                    section_updated_at = int(d.get("updatedAt", "0") or 0)
                except Exception:
                    section_updated_at = 0
                if not section_updated_at:
                    section_updated_at = now
                sections.append({
                    "section_id": d.get("key", ""),
                    "title": d.get("title", ""),
                    "section_type": section_type,
                    "thumb": d.get("thumb", "") or "",
                    "art": d.get("art", "") or "",
                    "scanned_at": section_updated_at,
                    "updated_at": section_updated_at,
                    "item_count": 0,
                })
            except Exception:
                pass
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_OK_V1313 sections=%d server=%s" % (len(sections), server), xbmc.LOGINFO)
        return sections
    except Exception:
        _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_DIRECT_FAIL_V1313 server=%s err=%s" % (server, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        raise

def _probe_plex_after_connection_setting(reason="settings_plex_connection_changed_v1310", server_changed=False):
    """Probe new Plex URL/token and refresh Home without Kodi restart.

    v1310 verifies both /identity and /library/sections.  The old v1306 path
    declared success after /identity only, so a server/proxy that accepted
    identity but refused library access could clear the error notice while Home
    still showed old cached widgets.
    """
    try:
        server = (ADDON.getSetting("plex_url") or "").strip()
        token = (ADDON.getSetting("plex_token") or "").strip()
        if not server or not token:
            _log("PKM_SETTINGS_PLEX_PROBE_SKIP_V1310 reason=%s server=%s token=%s" % (str(reason or ""), "1" if server else "0", "1" if token else "0"), xbmc.LOGINFO)
            return False
    except Exception:
        return False

    pending_server_switch = bool(server_changed or _server_switch_pending_v1310())

    def _worker():
        try:
            if not pkm_plex_client:
                _log("PKM_SETTINGS_PLEX_PROBE_SKIP_V1310 reason=module_missing", xbmc.LOGWARNING)
                return
            _r45_ddns_diagnostic(server, "saved_server_before_identity")
            _log("PKM_SETTINGS_PLEX_PROBE_BEGIN_V1310 reason=%s path=/identity timeout=3.50 server_switch=%s" % (str(reason or ""), "1" if pending_server_switch else "0"), xbmc.LOGINFO)
            try:
                pkm_plex_client.plex_request_xml("/identity", timeout=3.5, log_failures=False, env=_settings_plex_client_env())
            except Exception as identity_exc:
                _r45_ddns_diagnostic(server, "saved_server_identity_failed", error=identity_exc)
                _show_plex_connection_probe_failed_v1310(identity_exc)
                return

            core = _core()
            remote_sections = []
            try:
                _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_BEGIN_V1313 path=/library/sections timeout=20 mode=direct_same_client", xbmc.LOGINFO)
                _r45_ddns_diagnostic(server, "saved_server_identity_ok")
                remote_sections = list(_fetch_remote_sections_direct_v1313(reason=reason or "settings_probe_sections_v1313") or [])
            except Exception as section_exc:
                _show_plex_library_probe_failed_v1310(section_exc)
                return
            if not remote_sections:
                _show_plex_library_probe_failed_v1310("no movie/show sections")
                return
            _log("PKM_SETTINGS_PLEX_SECTIONS_PROBE_OK_V1313 sections=%d" % len(remote_sections), xbmc.LOGINFO)

            _clear_plex_connection_state(reason="settings_probe_ok_v1310")
            default_ids = []
            if pending_server_switch:
                default_ids = _apply_server_switch_reset_v1310(remote_sections, reason="server_switch_v1310")
                if not default_ids:
                    _log("PKM_SETTINGS_PLEX_PROBE_WAIT_SYNC_V1311 reason=%s" % str(reason or ""), xbmc.LOGWARNING)
                    return
                _set_server_switch_pending_v1310(False, reason="probe_ok_reset_done")
                _clear_server_switch_pending_home_ui_v1310(reason="probe_ok_reset_done")
            else:
                _clear_server_switch_pending_home_ui_v1310(reason="probe_ok_no_server_switch")
                _save_current_server_identity_v1310(core, reason="probe_ok_no_server_switch_v1310")
            _show_plex_connected_notice_v1310("라이브러리 %d개 싱크 완료" % len(default_ids) if default_ids else "홈 위젯을 갱신합니다")
            _signal_home_refresh_from_settings(reason="settings_plex_connected_v1310")
            _log("PKM_SETTINGS_PLEX_PROBE_OK_V1313 reason=%s server_switch=%s default_selected=%s" % (str(reason or ""), "1" if pending_server_switch else "0", ",".join(default_ids)), xbmc.LOGINFO)
        except Exception as exc:
            _log("PKM_SETTINGS_PLEX_PROBE_FAIL_V1310 reason=%s err=%s" % (str(reason or ""), str(exc)), xbmc.LOGWARNING)

    try:
        t = threading.Thread(target=_worker, name="PKMSettingsPlexProbeV1310", daemon=True)
        t.daemon = True
        t.start()
        return True
    except Exception:
        return False



class PKMSettingsFlowDialog(xbmcgui.WindowXMLDialog):
    """Single PKM settings dialog with in-place page navigation."""
    LIST_ID = 200
    OK_ID = 300
    HOME_ID = 302
    HOME_SINGLE_ID_V2373 = 303
    INLINE_KEYBOARD_ID = 500
    INLINE_VALUE_ID = 501
    INLINE_MODE_ID = 502
    INLINE_HISTORY_ID = 503
    INLINE_HISTORY_CLEAR_ID = 504
    INLINE_PORT_ID_V1730 = 505
    INLINE_DB_VALUE_ID_V1730 = 506
    INLINE_CONFIRM_ID_V1731 = 507
    INLINE_HISTORY_SETTING_V1713 = "plex_url_history"
    INLINE_DB_PATH_HISTORY_SETTING_V1719 = "plex_db_path_history"
    INLINE_HISTORY_LIMIT_V1713 = 20
    FULL_RESET_PROGRESS_ID_V2164 = 9100

    # v1712: compact address-only keyboard.  Every mode ends with the same
    # native panel mode/actions so no separate "영문 주소 키보드" caption is needed.
    INLINE_ADDRESS_MODE_KEYS_V1712 = ["영문", "한글", "숫자", "기호", "빠른입력"]
    INLINE_ADDRESS_ACTION_KEYS_V1712 = ["←", "→", "삭제", "전체삭제"]
    INLINE_PORT_KEYS_V1730 = list("1234567890") + INLINE_ADDRESS_ACTION_KEYS_V1712
    INLINE_ADDRESS_KEYS = {
        "EN": list("abcdefghijklmnopqrstuvwxyz") + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "KO": [
            "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ", "ㅈ", "ㅊ",
            "ㅋ", "ㅌ", "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ", "ㅔ", "ㅕ",
            "ㅗ", "ㅛ", "ㅜ", "ㅠ", "ㅡ", "ㅣ",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "NUM": list("1234567890") + [".", ":", "/", "-", "_", "@"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "SYM": ["!", "?", "#", "%", "&", "+", "=", "_", "@", "'", '"', ",", ".", ":", "/", "-", "(", ")", "[", "]"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        # v1741: quick tokens occupy four complete visual rows after the two
        # edit actions, then all five mode-switch keys share one dedicated row.
        # This keeps 영문/한글/숫자/기호/빠른입력 grouped instead of splitting
        # them across the token/action rows.
        "DOMAIN": [
            "http://", "https://", "www.", "192.168.0.1", "192.168.",
            "10.0.", "172.16.", "localhost",
            # R258: common DDNS suffixes (5 columns x 5 rows of quick keys)
            ".com", ".net", ".org", ".co.kr", ".iptime.org",
            ".duckdns.org", ".ddns.net", ".synology.me", ".myqnapcloud.com", ".asuscomm.com",
            ".tplinkdns.com", ".hopto.org", ".zapto.org", ".dyndns.org", ".mooo.com",
            ".mywire.org", ".kro.kr",
        ] + INLINE_ADDRESS_ACTION_KEYS_V1712 + INLINE_ADDRESS_MODE_KEYS_V1712,
    }

    # v1719: the same inline keyboard layout is reused for direct Plex DB paths.
    # Only the path quick keys differ; font, geometry, history and navigation stay shared.
    INLINE_DB_PATH_KEYS = {
        "EN": list("abcdefghijklmnopqrstuvwxyz") + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "KO": [
            "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ", "ㅈ", "ㅊ",
            "ㅋ", "ㅌ", "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ", "ㅔ", "ㅕ",
            "ㅗ", "ㅛ", "ㅜ", "ㅠ", "ㅡ", "ㅣ",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "NUM": list("1234567890") + [".", ":", "/", "\\", "-", "_", "@"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        "SYM": ["!", "?", "#", "%", "&", "+", "=", "_", "@", "'", '"', ",", ".", ":", "/", "\\", "-", "(", ")", "[", "]"] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
        # v1741: add one compact Windows root token so the path quick page has
        # fifteen data keys.  The five mode switches then occupy one complete
        # row and the two edit actions remain together below it.
        "DOMAIN": [
            "smb://", "nfs://", "http://", "https://", "file://", "special://",
            "/", "\\", ":", "//", ".db", "Plex Media Server",
            "Plug-in Support", "Databases", "C:\\",
        ] + INLINE_ADDRESS_MODE_KEYS_V1712 + INLINE_ADDRESS_ACTION_KEYS_V1712,
    }

    _INLINE_KO_CONSONANTS_V1712 = set("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
    _INLINE_KO_VOWELS_V1712 = set("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
    _INLINE_CHO_V1712 = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
    _INLINE_JUNG_V1712 = ["ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"]
    _INLINE_JONG_V1712 = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]

    def _inline_is_db_path_v1719(self):
        return str(getattr(self, "_inline_input_kind_v1719", "plex_url") or "plex_url") == "plex_db_path"

    def _inline_history_setting_v1719(self):
        return self.INLINE_DB_PATH_HISTORY_SETTING_V1719 if self._inline_is_db_path_v1719() else self.INLINE_HISTORY_SETTING_V1713

    def _inline_current_keys_v1719(self):
        if (not self._inline_is_db_path_v1719()) and getattr(self, "_inline_active_field_v1730", "address") == "port":
            return list(self.INLINE_PORT_KEYS_V1730)
        key_map = self.INLINE_DB_PATH_KEYS if self._inline_is_db_path_v1719() else self.INLINE_ADDRESS_KEYS
        return key_map.get(self._inline_address_mode_v1711, [])

    def _inline_normalize_value_v1719(self, value):
        value = str(value or "").strip()
        if self._inline_is_db_path_v1719():
            return _plex_db_path_clean_v1700(value)
        return _normalize_plex_server_url_v1313(value)

    def _inline_current_setting_value_v1719(self):
        setting_id = "plex_db_path" if self._inline_is_db_path_v1719() else "plex_url"
        return str(ADDON.getSetting(setting_id) or "")

    def _inline_placeholder_v1719(self):
        return "Plex Server DB 경로 입력" if self._inline_is_db_path_v1719() else "Plex 서버 주소 입력"

    def _inline_history_empty_label_v1719(self):
        return "저장된 경로 없음" if self._inline_is_db_path_v1719() else "저장된 주소 없음"

    def _inline_address_mode_label_v1711(self):
        # v1712: mode is represented by the mode keys at the end of every panel.
        return ""

    def _inline_compose_syllable_v1712(self, cho, jung, jong=""):
        try:
            l = self._INLINE_CHO_V1712.index(cho)
            v = self._INLINE_JUNG_V1712.index(jung)
            t = self._INLINE_JONG_V1712.index(jong or "")
            return chr(0xAC00 + (l * 21 + v) * 28 + t)
        except Exception:
            return (cho or "") + (jung or "") + (jong or "")

    def _inline_compose_tokens_value_v1971(self, tokens):
        out = []
        L = V = T = None

        def commit():
            nonlocal L, V, T
            if L and V:
                out.append(self._inline_compose_syllable_v1712(L, V, T or ""))
            elif L:
                out.append(L)
            elif V:
                out.append(V)
            L = V = T = None

        for token in list(tokens or []):
            ch = token or ""
            if len(ch) != 1:
                commit()
                out.append(ch)
                continue
            if ch in self._INLINE_KO_CONSONANTS_V1712:
                if L is None:
                    L = ch
                elif V is None:
                    out.append(L)
                    L = ch
                elif T is None and ch in self._INLINE_JONG_V1712:
                    T = ch
                else:
                    commit()
                    L = ch
            elif ch in self._INLINE_KO_VOWELS_V1712:
                if L is None:
                    commit()
                    V = ch
                    commit()
                elif V is None:
                    V = ch
                elif T is not None:
                    old_t = T
                    out.append(self._inline_compose_syllable_v1712(L, V, ""))
                    L, V, T = old_t, ch, None
                else:
                    commit()
                    V = ch
                    commit()
            else:
                commit()
                out.append(ch)
        commit()
        return "".join(out)

    def _inline_recompose_tokens_v1712(self):
        self._inline_address_value_v1711 = self._inline_compose_tokens_value_v1971(
            self._inline_address_tokens_v1712
        )
        self._inline_cursor_index_v1971 = max(0, min(
            int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_address_tokens_v1712)) or 0),
            len(self._inline_address_tokens_v1712),
        ))

    def _inline_cursor_render_value_v1971(self):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        left = self._inline_compose_tokens_value_v1971(tokens[:cursor])
        right = self._inline_compose_tokens_value_v1971(tokens[cursor:])
        return left + "│" + right

    def _inline_append_token_v1712(self, token):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        inserted = list(str(token or ""))
        tokens[cursor:cursor] = inserted
        self._inline_address_tokens_v1712 = tokens
        self._inline_cursor_index_v1971 = cursor + len(inserted)
        self._inline_recompose_tokens_v1712()
        _log("PKM_INLINE_CURSOR_INSERT_V1971 cursor=%s length=%s" % (self._inline_cursor_index_v1971, len(tokens)), xbmc.LOGINFO)

    def _inline_delete_token_v1712(self):
        tokens = list(self._inline_address_tokens_v1712 or [])
        cursor = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        if cursor > 0:
            del tokens[cursor - 1]
            cursor -= 1
        self._inline_address_tokens_v1712 = tokens
        self._inline_cursor_index_v1971 = cursor
        self._inline_recompose_tokens_v1712()
        _log("PKM_INLINE_CURSOR_DELETE_V1971 cursor=%s length=%s" % (cursor, len(tokens)), xbmc.LOGINFO)

    def _inline_move_cursor_v1971(self, delta):
        tokens = list(self._inline_address_tokens_v1712 or [])
        old = max(0, min(int(getattr(self, "_inline_cursor_index_v1971", len(tokens)) or 0), len(tokens)))
        new = max(0, min(old + int(delta or 0), len(tokens)))
        self._inline_cursor_index_v1971 = new
        _log("PKM_INLINE_CURSOR_MOVE_V1971 from=%s to=%s length=%s" % (old, new, len(tokens)), xbmc.LOGINFO)

    def _inline_clear_tokens_v1712(self):
        self._inline_address_tokens_v1712 = []
        self._inline_address_value_v1711 = ""
        self._inline_cursor_index_v1971 = 0

    def _inline_commit_active_field_v1730(self):
        if self._inline_is_db_path_v1719():
            return
        field = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
        if field == "port":
            self._inline_server_port_value_v1730 = str(self._inline_address_value_v1711 or "")
            self._inline_server_port_tokens_v1730 = list(self._inline_address_tokens_v1712 or [])
            self._inline_server_port_cursor_v1971 = int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_server_port_tokens_v1730)) or 0)
        else:
            self._inline_server_address_value_v1730 = str(self._inline_address_value_v1711 or "")
            self._inline_server_address_tokens_v1730 = list(self._inline_address_tokens_v1712 or [])
            self._inline_server_address_cursor_v1971 = int(getattr(self, "_inline_cursor_index_v1971", len(self._inline_server_address_tokens_v1730)) or 0)

    def _inline_switch_server_field_v1730(self, field, repopulate=True):
        if self._inline_is_db_path_v1719():
            return
        field = "port" if str(field or "") == "port" else "address"
        current = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
        if field == current:
            try:
                self.setProperty("PlexKM.Dialog.InlineActiveField", field)
            except Exception:
                pass
            return
        self._inline_commit_active_field_v1730()
        self._inline_active_field_v1730 = field
        if field == "port":
            # R97D: the port accepts digits only -> show the number keypad.
            self._inline_address_mode_v1711 = "NUM"
            self._inline_address_value_v1711 = str(getattr(self, "_inline_server_port_value_v1730", "32400") or "")
            self._inline_address_tokens_v1712 = list(getattr(self, "_inline_server_port_tokens_v1730", []) or list(self._inline_address_value_v1711))
            self._inline_cursor_index_v1971 = max(0, min(int(getattr(self, "_inline_server_port_cursor_v1971", len(self._inline_address_tokens_v1712)) or 0), len(self._inline_address_tokens_v1712)))
        else:
            self._inline_address_value_v1711 = str(getattr(self, "_inline_server_address_value_v1730", "") or "")
            self._inline_address_tokens_v1712 = list(getattr(self, "_inline_server_address_tokens_v1730", []) or list(self._inline_address_value_v1711))
            self._inline_cursor_index_v1971 = max(0, min(int(getattr(self, "_inline_server_address_cursor_v1971", len(self._inline_address_tokens_v1712)) or 0), len(self._inline_address_tokens_v1712)))
        try:
            self.setProperty("PlexKM.Dialog.InlineActiveField", field)
        except Exception:
            pass
        if repopulate:
            self._inline_address_populate_v1711(0)
        else:
            self._inline_address_render_v1711()
        _log("PKM_INLINE_SERVER_FIELD_ACTIVE_V1730 field=%s" % field, xbmc.LOGINFO)

    def _inline_address_render_v1711(self):
        try:
            if self._inline_is_db_path_v1719():
                shown = self._inline_cursor_render_value_v1971() if self._inline_address_active_v1711 else (self._inline_address_value_v1711 or self._inline_placeholder_v1719())
                if self._inline_db_value_control_v1730:
                    self._inline_db_value_control_v1730.setLabel(_display_text_for_kodi(shown))
            else:
                field = str(getattr(self, "_inline_active_field_v1730", "address") or "address")
                address = self._inline_cursor_render_value_v1971() if field == "address" else str(getattr(self, "_inline_server_address_value_v1730", "") or "")
                port = self._inline_cursor_render_value_v1971() if field == "port" else str(getattr(self, "_inline_server_port_value_v1730", "32400") or "")
                if self._inline_value_control_v1711:
                    self._inline_value_control_v1711.setLabel(_display_text_for_kodi(address or "Plex 서버 주소 입력"))
                if self._inline_port_control_v1730:
                    
                    # R97D: the field caption above already says "포트".
                    if field != "port" and str(port or "") == "32400":
                        port_label = "32400 (기본)"
                    elif port:
                        port_label = str(port)
                    else:
                        port_label = "입력"
                    self._inline_port_control_v1730.setLabel(_display_text_for_kodi(port_label))
            if self._inline_mode_control_v1711:
                self._inline_mode_control_v1711.setLabel(_display_text_for_kodi(self._inline_address_mode_label_v1711()))
        except Exception:
            pass

    def _inline_address_populate_v1711(self, focus_pos=0):
        if not self._inline_keyboard_v1711:
            return
        try:
            self._inline_keyboard_v1711.reset()
            items = []
            for key in self._inline_current_keys_v1719():
                li = xbmcgui.ListItem(label=_display_text_for_kodi(key))
                li.setProperty("PKMAddressKey", key)
                li.setProperty("PKMAddressMode", self._inline_address_mode_v1711)
                if self._inline_address_mode_v1711 == "DOMAIN" and key in self.INLINE_ADDRESS_MODE_KEYS_V1712:
                    li.setProperty("PKMAddressGroup", "mode")
                elif key in self.INLINE_ADDRESS_ACTION_KEYS_V1712:
                    li.setProperty("PKMAddressGroup", "action")
                else:
                    li.setProperty("PKMAddressGroup", "content")
                items.append(li)
            self._inline_keyboard_v1711.addItems(items)
            if items:
                self._inline_keyboard_v1711.selectItem(max(0, min(int(focus_pos or 0), len(items) - 1)))
            self._inline_address_render_v1711()
        except Exception:
            _log("PKM_INLINE_ADDRESS_POPULATE_FAILED_V1711\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_load_v1713(self):
        raw = (ADDON.getSetting(self._inline_history_setting_v1719()) or "").strip()
        rows = []
        if raw:
            try:
                decoded = json.loads(raw)
                if isinstance(decoded, list):
                    rows = decoded
            except Exception:
                # Compatibility with a possible old newline-separated value.
                rows = raw.splitlines()
        clean = []
        seen = set()
        for value in rows:
            value = str(value or "").strip()
            if not value:
                continue
            normalized = self._inline_normalize_value_v1719(value)
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            clean.append(normalized)
            if len(clean) >= self.INLINE_HISTORY_LIMIT_V1713:
                break
        self._inline_address_history_v1713 = clean
        return list(clean)

    def _inline_history_store_v1713(self):
        clean = list(getattr(self, "_inline_address_history_v1713", []) or [])[:self.INLINE_HISTORY_LIMIT_V1713]
        try:
            ADDON.setSetting(self._inline_history_setting_v1719(), json.dumps(clean, ensure_ascii=False, separators=(",", ":")))
        except Exception:
            _log("PKM_INLINE_ADDRESS_HISTORY_STORE_FAILED_V1713\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_remember_v1713(self, value):
        value = self._inline_normalize_value_v1719(value)
        if not value:
            return
        rows = [x for x in (getattr(self, "_inline_address_history_v1713", []) or []) if x != value]
        rows.insert(0, value)
        self._inline_address_history_v1713 = rows[:self.INLINE_HISTORY_LIMIT_V1713]
        self._inline_history_store_v1713()

    def _inline_history_populate_v1713(self, focus_pos=0):
        if not self._inline_history_control_v1713:
            return
        try:
            self._inline_history_control_v1713.reset()
            items = []
            for value in list(getattr(self, "_inline_address_history_v1713", []) or []):
                _shown = str(value or "")
                if not self._inline_is_db_path_v1719():
                    # 목록 폭에 맞춰 주소 앞의 http:// 와 기본 포트는 생략하고 보여준다 (저장값은 그대로)
                    for _pre in ("http://", "https://"):
                        if _shown.startswith(_pre):
                            _shown = _shown[len(_pre):]
                            break
                    if _shown.endswith(":32400"):
                        _shown = _shown[:-6]
                li = xbmcgui.ListItem(label=_display_text_for_kodi(_shown))
                li.setProperty("PKMAddressHistory", value)
                li.setProperty("PKMAddressHistoryEmpty", "0")
                items.append(li)
            if not items:
                li = xbmcgui.ListItem(label=_display_text_for_kodi(self._inline_history_empty_label_v1719()))
                li.setProperty("PKMAddressHistoryEmpty", "1")
                items.append(li)
            self._inline_history_control_v1713.addItems(items)
            if items:
                self._inline_history_control_v1713.selectItem(max(0, min(int(focus_pos or 0), len(items) - 1)))
        except Exception:
            _log("PKM_INLINE_ADDRESS_HISTORY_POPULATE_FAILED_V1713\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _inline_history_seed_current_v1713(self):
        self._inline_history_load_v1713()
        current = self._inline_normalize_value_v1719(self._inline_current_setting_value_v1719())
        skip_default = (not self._inline_is_db_path_v1719()) and current == "http://127.0.0.1:32400"
        if current and not skip_default and current not in self._inline_address_history_v1713:
            self._inline_address_history_v1713.insert(0, current)
            self._inline_address_history_v1713 = self._inline_address_history_v1713[:self.INLINE_HISTORY_LIMIT_V1713]
            self._inline_history_store_v1713()
        self._inline_history_populate_v1713(0)

    def _inline_history_select_v1713(self):
        if not self._inline_history_control_v1713:
            return
        try:
            item = self._inline_history_control_v1713.getSelectedItem()
            if not item or item.getProperty("PKMAddressHistoryEmpty") == "1":
                return
            value = item.getProperty("PKMAddressHistory") or item.getLabel()
        except Exception:
            return
        value = str(value or "").strip()
        if not value:
            return
        if self._inline_is_db_path_v1719():
            self._inline_address_value_v1711 = value
            self._inline_address_tokens_v1712 = list(value)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        else:
            address, port = _split_plex_server_endpoint_v1730(value, default_port="32400")
            self._inline_server_address_value_v1730 = address
            self._inline_server_port_value_v1730 = port or "32400"
            self._inline_server_address_tokens_v1730 = list(address)
            self._inline_server_port_tokens_v1730 = list(self._inline_server_port_value_v1730)
            self._inline_server_address_cursor_v1971 = len(self._inline_server_address_tokens_v1730)
            self._inline_server_port_cursor_v1971 = len(self._inline_server_port_tokens_v1730)
            self._inline_active_field_v1730 = "address"
            self._inline_address_value_v1711 = address
            self._inline_address_tokens_v1712 = list(address)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
            try:
                self.setProperty("PlexKM.Dialog.InlineActiveField", "address")
            except Exception:
                pass
        self._inline_address_render_v1711()
        # v1731: after loading history, focus the dedicated long 확인 button.
        try:
            self.setFocusId(self.INLINE_CONFIRM_ID_V1731)
        except Exception:
            pass
        _log("PKM_INLINE_ADDRESS_HISTORY_SELECTED_V1713 value=%s" % value, xbmc.LOGINFO)

    def _inline_history_clear_v1713(self):
        self._inline_address_history_v1713 = []
        self._inline_history_store_v1713()
        self._inline_history_populate_v1713(0)
        try:
            self.setFocusId(self.INLINE_CONFIRM_ID_V1731)
        except Exception:
            pass
        _log("PKM_INLINE_ADDRESS_HISTORY_CLEARED_V1731", xbmc.LOGINFO)

    def _open_inline_address_v1711(self, input_kind="plex_url"):
        self._inline_address_active_v1711 = True
        self._inline_input_kind_v1719 = "plex_db_path" if str(input_kind or "") == "plex_db_path" else "plex_url"
        self._inline_restore_list_pos_v1719 = self._current_list_position_v1691()
        current_value = self._inline_current_setting_value_v1719()
        # R97D (mockup S3): server addresses are mostly IP numbers, so the
        # server input opens on the number keypad.  DB paths stay on 영문.
        self._inline_address_mode_v1711 = "EN" if self._inline_input_kind_v1719 == "plex_db_path" else "NUM"
        if self._inline_is_db_path_v1719():
            self._inline_address_value_v1711 = current_value
            self._inline_address_tokens_v1712 = list(self._inline_address_value_v1711)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        else:
            if current_value == "http://127.0.0.1:32400":
                current_value = ""
            address, port = _split_plex_server_endpoint_v1730(current_value, default_port="32400")
            self._inline_server_address_value_v1730 = address
            self._inline_server_port_value_v1730 = port or "32400"
            self._inline_server_address_tokens_v1730 = list(address)
            self._inline_server_port_tokens_v1730 = list(self._inline_server_port_value_v1730)
            self._inline_server_address_cursor_v1971 = len(self._inline_server_address_tokens_v1730)
            self._inline_server_port_cursor_v1971 = len(self._inline_server_port_tokens_v1730)
            self._inline_active_field_v1730 = "address"
            self._inline_address_value_v1711 = address
            self._inline_address_tokens_v1712 = list(address)
            self._inline_cursor_index_v1971 = len(self._inline_address_tokens_v1712)
        self._inline_history_seed_current_v1713()
        try:
            self.setProperty("PlexKM.Dialog.InlineKeyboard", "1")
            if self._inline_is_db_path_v1719():
                self.clearProperty("PlexKM.Dialog.InlineServerSplit")
                self.clearProperty("PlexKM.Dialog.InlineActiveField")
            else:
                self.setProperty("PlexKM.Dialog.InlineServerSplit", "1")
                self.setProperty("PlexKM.Dialog.InlineActiveField", "address")
            self.setProperty("PlexKM.Dialog.Hint", "경로 키 선택 / 확인 / 뒤로" if self._inline_is_db_path_v1719() else "주소와 포트 선택 / 확인 / 뒤로")
            row_label = "원격 DB 경로 직접 입력" if self._inline_is_db_path_v1719() else self._plex_connection_rows_v1703()[0]
            self.setProperty("PlexKM.Dialog.InlineRowLabel", _display_text_for_kodi(row_label))
            self.setProperty("PlexKM.Dialog.InlineHistoryTitle", _display_text_for_kodi("최근 경로" if self._inline_is_db_path_v1719() else "최근 주소"))
            self.setProperty("PlexKM.Dialog.InlineHistoryClear", _display_text_for_kodi("경로 히스토리 삭제" if self._inline_is_db_path_v1719() else "히스토리 삭제"))
        except Exception:
            pass
        self._inline_address_populate_v1711(focus_pos=0)
        try:
            self.setFocusId(self.INLINE_KEYBOARD_ID)
        except Exception:
            pass
        _log("PKM_INLINE_INPUT_OPEN_V1733 single_border_muted_text_visible_divider kind=%s mode=EN length=%d" % (self._inline_input_kind_v1719, len(self._inline_address_value_v1711 or "")), xbmc.LOGINFO)

    def _close_inline_address_v1711(self, restore_focus=True):
        self._inline_address_active_v1711 = False
        try:
            self.clearProperty("PlexKM.Dialog.InlineKeyboard")
            self.clearProperty("PlexKM.Dialog.InlineRowLabel")
            self.clearProperty("PlexKM.Dialog.InlineHistoryTitle")
            self.clearProperty("PlexKM.Dialog.InlineHistoryClear")
            self.clearProperty("PlexKM.Dialog.InlineServerSplit")
            self.clearProperty("PlexKM.Dialog.InlineActiveField")
            self.setProperty("PlexKM.Dialog.Hint", "")
        except Exception:
            pass
        if restore_focus:
            try:
                self._list.selectItem(max(0, int(getattr(self, "_inline_restore_list_pos_v1719", 0) or 0)))
                self.setFocusId(self.LIST_ID)
            except Exception:
                pass
        _log("PKM_INLINE_ADDRESS_CLOSE_V1711", xbmc.LOGINFO)

    def _save_inline_address_v1711(self):
        raw = str(self._inline_address_value_v1711 or "").strip()
        if self._inline_is_db_path_v1719():
            new_value = _plex_db_path_clean_v1700(raw)
            if not new_value:
                return
            if not _validate_plex_db_path_v1700(new_value, notify=True):
                return
            self._inline_history_remember_v1713(new_value)
            self._close_inline_address_v1711(restore_focus=False)
            self._save_plex_db_path_v1700(new_value)
            _log("PKM_INLINE_DB_PATH_SAVED_V1719 path=%s" % new_value, xbmc.LOGINFO)
            return

        self._inline_commit_active_field_v1730()
        address = str(getattr(self, "_inline_server_address_value_v1730", "") or "").strip()
        port = str(getattr(self, "_inline_server_port_value_v1730", "") or "").strip()
        new_value, error_field = _combine_plex_server_endpoint_v1730(address, port, notify=True)
        if not new_value:
            self._inline_switch_server_field_v1730(error_field or "address", repopulate=True)
            try:
                self.setFocusId(self.INLINE_PORT_ID_V1730 if error_field == "port" else self.INLINE_VALUE_ID)
            except Exception:
                pass
            return
        old_value = _normalize_plex_server_url_v1313((ADDON.getSetting("plex_url") or ""))
        changed = new_value != old_value
        # R37: A Plex DDNS address can be reachable outside the LAN while
        # /identity times out on the local LAN (router hairpin NAT).  Keep
        # validating it, but allow explicit saving of a syntactically valid
        # endpoint after a timeout.  This does NOT mark Plex as connected.
        # R252: a DDNS name cannot be verified from inside the LAN and the probe froze the
        # screen for 3.5 s with no feedback. Only verify LAN IPs (typo check), and quickly.
        if changed and _r252_is_private_host(new_value) and not _probe_candidate_plex_url_v1922(new_value, timeout=2.0):
            _log("PKM_DDNS_DEFERRED_IDENTITY_R37 server=%s result=save_unverified "
                 "reason=local_probe_failed external_access_may_work" % new_value, xbmc.LOGWARNING)
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    pkm_notify.pkm_notice_set(
                        "Plex 주소 저장됨",
                        "서버 응답을 확인하지 못했습니다",
                        "주소를 확인해주세요",
                        sticky=False, force_replace=True)
            except Exception:
                pass
        ADDON.setSetting("plex_url", new_value)
        _publish_live_plex_settings_v1922(server=new_value, reason="inline_url_saved_v1922")
        if new_value:
            self._inline_history_remember_v1713(new_value)
        token_ready = bool((ADDON.getSetting("plex_token") or "").strip())
        if changed and token_ready:
            _set_server_switch_pending_v1310(True, reason="inline_url_saved_v1711")
        elif changed:
            _set_server_switch_pending_v1310(False, reason="inline_url_saved_wait_token_v1730")
            _clear_server_switch_pending_home_ui_v1310(reason="inline_url_saved_wait_token_v1730")
        if changed:
            _log("PKM_SETTINGS_PLEX_URL_SAVED_V1730 configured=%s server_changed=1 token_ready=%s server=%s" % (
                "1" if new_value else "0", "1" if token_ready else "0", new_value,
            ), xbmc.LOGINFO)
        self._close_inline_address_v1711(restore_focus=False)
        self._refresh_plex_connection_in_place_v1703(focus_pos=(1 if (changed and not token_ready) else 0))
        if changed and not token_ready:
            try:
                self.setProperty("PlexKM.Dialog.Hint", _display_text_for_kodi("다음: '계정 인증'을 누르세요"))
            except Exception:
                pass
        if changed and token_ready:
            _set_server_switch_pending_home_ui_v1310(
                "Plex 서버 연결 확인 중",
                "라이브러리 정보를 확인합니다",
                reason="settings_inline_connection_changed_v1711",
            )
            _probe_plex_after_connection_setting(reason="settings_inline_plex_url_saved_v1711", server_changed=True)
        elif changed:
            try:
                if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                    pkm_notify.pkm_notice_set(
                        "Plex 서버 주소 저장됨",
                        "'계정 인증'을 누르세요",
                        "Plex 로그인이 필요합니다",
                        sticky=False,
                        force_replace=True,
                    )
            except Exception:
                pass

    def _handle_inline_address_key_v1711(self):
        if not self._inline_keyboard_v1711:
            return
        try:
            item = self._inline_keyboard_v1711.getSelectedItem()
            key = item.getProperty("PKMAddressKey") or item.getLabel()
        except Exception:
            return
        if (not self._inline_is_db_path_v1719()) and getattr(self, "_inline_active_field_v1730", "address") == "port":
            if key not in ("←", "→", "삭제", "전체삭제", "확인") and not str(key or "").isdigit():
                _show_plex_endpoint_error_v1730("포트에는 숫자만 입력할 수 있습니다", "1부터 65535 사이로 입력해주세요")
                return
        mode_map = {"영문": "EN", "한글": "KO", "숫자": "NUM", "기호": "SYM", "빠른입력": "DOMAIN"}
        if key in mode_map:
            self._inline_address_mode_v1711 = mode_map[key]
            self._inline_address_populate_v1711(0)
            return
        if key == "확인":
            self._save_inline_address_v1711()
            return
        if key == "←":
            self._inline_move_cursor_v1971(-1)
        elif key == "→":
            self._inline_move_cursor_v1971(1)
        elif key == "삭제":
            self._inline_delete_token_v1712()
        elif key == "전체삭제":
            self._inline_clear_tokens_v1712()
        else:
            self._inline_append_token_v1712(key)
        self._inline_address_render_v1711()

    def __init__(self, *args, **kwargs):
        self._list = None
        self._page = "root"
        self._items = []
        self._stack = []
        self._multiselect = False
        self._preselect = set()
        self._actionable = None
        self._show_checks = set()
        self._payload = None
        self.result_action = None
        self._initial_page = kwargs.pop("initial_page", "root")
        self._last_click_ms_v1382 = 0
        self._plex_db_browser_root_v1700 = ""
        self._plex_db_browser_path_v1700 = ""
        self._rating_db_browser_root_v2372 = ""
        self._rating_db_browser_path_v2372 = ""
        self._rating_db_expected_v2372 = ""
        self._rating_db_setting_id_v2372 = ""
        self._rating_db_return_page_v2372 = ""
        self._inline_keyboard_v1711 = None
        self._inline_value_control_v1711 = None
        self._inline_mode_control_v1711 = None
        self._inline_port_control_v1730 = None
        self._inline_db_value_control_v1730 = None
        self._inline_history_control_v1713 = None
        self._inline_address_history_v1713 = []
        self._inline_address_active_v1711 = False
        self._inline_address_value_v1711 = ""
        self._inline_address_mode_v1711 = "EN"
        self._inline_address_tokens_v1712 = []
        self._inline_cursor_index_v1971 = 0
        self._inline_server_address_cursor_v1971 = 0
        self._inline_server_port_cursor_v1971 = 5
        self._inline_input_kind_v1719 = "plex_url"
        self._inline_restore_list_pos_v1719 = 0
        self._inline_active_field_v1730 = "address"
        self._inline_server_address_value_v1730 = ""
        self._inline_server_port_value_v1730 = "32400"
        self._inline_server_address_tokens_v1730 = []
        self._inline_server_port_tokens_v1730 = list("32400")
        self._full_reset_progress_control_v2164 = None
        super(PKMSettingsFlowDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Settings.OpeningR331")
        except Exception:
            pass
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        _log("PKM_PATCH_ACTIVE v1971 inline_keyboard_cursor_left_right_middle_edit", xbmc.LOGINFO)
        _log("PKM_PATCH_ACTIVE v2373 rating_db_browser_clean_rows_single_home_align", xbmc.LOGINFO)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            self._list = self.getControl(self.LIST_ID)
            try:
                self._inline_keyboard_v1711 = self.getControl(self.INLINE_KEYBOARD_ID)
                self._inline_value_control_v1711 = self.getControl(self.INLINE_VALUE_ID)
                self._inline_mode_control_v1711 = self.getControl(self.INLINE_MODE_ID)
                self._inline_port_control_v1730 = self.getControl(self.INLINE_PORT_ID_V1730)
                self._inline_db_value_control_v1730 = self.getControl(self.INLINE_DB_VALUE_ID_V1730)
                self._inline_history_control_v1713 = self.getControl(self.INLINE_HISTORY_ID)
                self._full_reset_progress_control_v2164 = self.getControl(self.FULL_RESET_PROGRESS_ID_V2164)
            except Exception:
                self._inline_keyboard_v1711 = None
                self._inline_value_control_v1711 = None
                self._inline_mode_control_v1711 = None
                self._inline_port_control_v1730 = None
                self._inline_db_value_control_v1730 = None
                self._inline_history_control_v1713 = None
                self._full_reset_progress_control_v2164 = None
            self.clearProperty("PlexKM.Dialog.FullResetProgressV2164")
            self.clearProperty("PlexKM.Dialog.FullResetStageV2164")
            self.clearProperty("PlexKM.Dialog.FullResetDetailV2164")
            self.clearProperty("PlexKM.Dialog.FullResetPercentV2164")
            self.clearProperty("PlexKM.Dialog.FullResetCountdownV2167")
            self.clearProperty("PlexKM.Dialog.InlineKeyboard")
            self.clearProperty("PlexKM.Dialog.InlineRowLabel")
            self.clearProperty("PlexKM.Dialog.InlineHistoryTitle")
            self.clearProperty("PlexKM.Dialog.InlineHistoryClear")
            self.clearProperty("PlexKM.Dialog.InlineServerSplit")
            self.clearProperty("PlexKM.Dialog.InlineActiveField")
            self._cat_r97 = 0
            self._conn_status_r97 = ""
            self._r97_init_categories()
            self._r97_refresh_aside_sub()
            if self._initial_page == "plex_connection":
                self._show_plex_connection(push=False)
            else:
                self._show_root(push=False)
            self.setFocusId(self.LIST_ID)
            try:  # R257: setup wizard -> Plex already signed in -> open the library selection
                _w257 = xbmcgui.Window(10000)
                if _w257.getProperty("PlexKM.SetupJumpLibraryR257") == "1":
                    _w257.clearProperty("PlexKM.SetupJumpLibraryR257")
                    self._show_library_selection(push=True, auth_initial=True)
            except Exception:
                _log("PKM_R257_LIBRARY_JUMP_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        except Exception:
            _log("PKM_SETTINGS_FLOW_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            self.close()

    def _make_item(self, label, idx):
        li = xbmcgui.ListItem(label=_display_text_for_kodi(label))
        try:
            self._r97_apply_row_parts(li, label, idx)
        except Exception:
            pass
        li.setProperty("index", str(idx))
        checked = idx in self._preselect
        li.setProperty("checked", "1" if checked else "0")
        show_check = self._multiselect or idx in self._show_checks
        li.setProperty("showcheck", "1" if show_check else "0")
        actionable = self._actionable is None or idx in self._actionable
        li.setProperty("actionable", "1" if actionable else "0")
        return li

    def _current_list_position_v1691(self):
        try:
            return int(self._list.getSelectedPosition()) if self._list else 0
        except Exception:
            return 0

    def _render(self, title, items, page, multiselect=False, preselect=None, payload=None,
                push=True, actionable=None, focus_pos=None, show_checks=None):
        try:
            # v2015: Every in-place PKM page refresh returns to the row that
            # launched the operation.  Capture before reset because resetting
            # the native list otherwise snaps selection to row 0.
            preserve_same_page_focus_v2015 = None
            if (not push) and focus_pos is None and str(page or "") == str(self._page or ""):
                preserve_same_page_focus_v2015 = self._current_list_position_v1691()
            if push:
                saved_actionable = None if self._actionable is None else set(self._actionable)
                self._stack.append((
                    self._page, list(self._items), self._multiselect, set(self._preselect),
                    self._payload, self.getProperty("PlexKM.Dialog.Title"), saved_actionable,
                    self._current_list_position_v1691(), set(self._show_checks),
                ))
            self._page = page
            self._items = [_display_text_for_kodi(x) for x in list(items or [])]
            self._multiselect = bool(multiselect)
            self._preselect = set(int(x) for x in (preselect or []))
            self._actionable = None if actionable is None else set(int(x) for x in actionable)
            self._show_checks = set(int(x) for x in (show_checks or []))
            self._payload = payload
            self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi(title or "PlexKM"))
            self.setProperty("PlexKM.Dialog.Mode", "multi" if self._multiselect else "single")
            self.setProperty("PlexKM.Dialog.SelectAllR261", "1" if str(page or "") == "library_select" else "")
            self.setProperty("PlexKM.Dialog.Hint", "켜기·끄기 후 확인" if self._multiselect else "")
            cat_r97 = self._r97_category_for_page(page)
            if cat_r97 is not None:
                self._r97_mark_category(cat_r97)
            self._list.reset()
            self._list.addItems([self._make_item(label, idx) for idx, label in enumerate(self._items)])
            if not getattr(self, "_r97_keep_aside_focus", False):
                self.setFocusId(self.LIST_ID)
            target = focus_pos
            if target is None and preserve_same_page_focus_v2015 is not None:
                target = preserve_same_page_focus_v2015
            if target is None and self._actionable:
                target = min(self._actionable)
            if target is not None and self._items:
                target = max(0, min(int(target), len(self._items) - 1))
                if self._actionable and target not in self._actionable:
                    target = min(self._actionable)
                self._list.selectItem(target)
            if page == "plex_connection":
                _log("PKM_SETTINGS_ACTIONABLE_ROWS_V1691 page=plex_connection rows=%s focus=%s" % (
                    ",".join(str(x) for x in sorted(self._actionable or [])),
                    self._current_list_position_v1691(),
                ), xbmc.LOGINFO)
        except Exception:
            _log("PKM_SETTINGS_FLOW_RENDER_FAILED page=%s\n%s" % (page, traceback.format_exc()), xbmc.LOGWARNING)

    def _restore(self, state):
        page, items, multiselect, preselect, payload, title, actionable, focus_pos, show_checks = state
        self._page = page
        self._items = list(items or [])
        self._multiselect = bool(multiselect)
        self._preselect = set(preselect or [])
        self._actionable = None if actionable is None else set(actionable)
        self._show_checks = set(show_checks or [])
        self._payload = payload
        self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi(title or "PlexKM"))
        self.setProperty("PlexKM.Dialog.Mode", "multi" if self._multiselect else "single")
        self.setProperty("PlexKM.Dialog.SelectAllR261", "1" if str(page or "") == "library_select" else "")
        self.setProperty("PlexKM.Dialog.Hint", "켜기·끄기 후 확인" if self._multiselect else "")
        self._list.reset()
        self._list.addItems([self._make_item(label, idx) for idx, label in enumerate(self._items)])
        self.setFocusId(self.LIST_ID)
        if self._items:
            focus_pos = max(0, min(int(focus_pos or 0), len(self._items) - 1))
            if self._actionable and focus_pos not in self._actionable:
                focus_pos = min(self._actionable)
            self._list.selectItem(focus_pos)

    def _back(self):
        if self._stack:
            self._restore(self._stack.pop())
        else:
            self.close()

    def _show_root(self, push=True, focus_pos=None):
        # R97D: the old root list (스피너 설정 / 평점 관리 removed) is replaced
        # by the left category pane.  Keep the entry point for callers.
        self._show_category_r97(getattr(self, "_cat_r97", 0), focus_list=True)
        return

    def _show_root_legacy_v1926(self, push=True, focus_pos=None):
        # v1382: Offline/connection-failure settings must open on the fixable
        # connection page first, without offering a network-backed library
        # selection as the first focused row.  This keeps PlexKM설정 responsive.
        if _offline_or_server_switch_pending_v1382():
            self._render("PlexKM", [
                "Plex 서버 연결",
                "스피너 설정",
                "라이브러리 선택/관리",
                "평점 관리",
                "초기화",
            ], "root_offline", push=push, focus_pos=focus_pos)
            _log("PKM_SETTINGS_FLOW_ROOT_OFFLINE_FAST_V1382", xbmc.LOGWARNING)
            return
        # v1926: Library additions are synchronised from the library manager,
        # and later Plex changes are checked automatically at Kodi startup.
        # Keep the root menu limited to distinct user-facing functions.
        self._render("PlexKM", [
            "Plex 서버 연결",
            "스피너 설정",
            "라이브러리 선택/관리",
            "평점 관리",
            "초기화",
        ], "root", push=push, focus_pos=focus_pos)

    # ------------------------------------------------------------------
    # R97D: two-pane settings (mockups S1-S5).  Category list 210 on the
    # left; the existing single/multi page machinery renders on the right.
    # ------------------------------------------------------------------
    CATEGORY_ID_R97 = 210

    def _r97_media(self, name):
        return "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r97s/" + name

    def _r97_categories(self):
        return (
            ("라이브러리", "cat_library_48.png"),  # R333: Plex + Kodi folders in one place
            ("Plex 서버", "cat_server_48.png"),  # R334
            ("내 저장소", "cat_sources_48.png"),  # R334
            ("팁 · 취향", "cat_update_48.png"),  # R315
            ("키 · 백업", "cat_meta_48.png"),  # R332
            ("초기화", "cat_reset_48.png"),
            ("정보", "cat_info_48.png"),
        )

    def _r97_init_categories(self):
        try:
            self._cat_list_r97 = self.getControl(self.CATEGORY_ID_R97)
        except Exception:
            self._cat_list_r97 = None
            return
        items = []
        for idx, (label, icon) in enumerate(self._r97_categories()):
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": self._r97_media(icon)})
            li.setProperty("active", "1" if idx == getattr(self, "_cat_r97", 0) else "0")
            if idx == 1 and self._r260_setup_pending():
                li.setProperty("badge", "1")
            items.append(li)
        self._cat_list_r97.reset()
        self._cat_list_r97.addItems(items)
        try:
            ver = ADDON.getAddonInfo("version") or ""
        except Exception:
            ver = ""
        self.setProperty("PlexKM.Settings.AsideFoot", ("PlexKM  v" + ver) if ver else "PlexKM")

    def _r97_mark_category(self, idx):
        self._cat_r97 = int(idx)
        lst = getattr(self, "_cat_list_r97", None)
        if lst is None:
            return
        try:
            for pos in range(lst.size()):
                lst.getListItem(pos).setProperty("active", "1" if pos == self._cat_r97 else "0")
        except Exception:
            pass

    def _r97_category_for_page(self, page):
        page = str(page or "")
        if page == "library_detail_r335":
            return 0
        if page in ("library_select", "library_hint_r97", "library_unavailable_r97", "sources_r108", "source_detail_r108"):
            return {"kodi": 2, "plex": 1}.get(getattr(self, "_src_scope_r334", "all"), 0)
        if page in ("plex_connection",) or page.startswith("plex_db"):
            return 1
        if page == "storage_r334":
            return 2
        if page == "tips_r315":
            return 3
        if page == "keys_r332":
            return 4
        if page == "reset_menu_r97":
            return 5
        if page == "about_r97":
            return 6
        return None

    def _r97_server_status(self):
        url = (ADDON.getSetting("plex_url") or "").strip()
        token = (ADDON.getSetting("plex_token") or "").strip()
        if not url or not token:
            return "설정 필요"
        try:
            if _offline_or_server_switch_pending_v1382():
                return "연결 확인 필요"
        except Exception:
            pass
        return "연결됨"

    def _r260_setup_pending(self):
        """R260: Plex address+token saved but the first library selection never finished."""
        try:
            if not ((ADDON.getSetting("plex_url") or "").strip() and (ADDON.getSetting("plex_token") or "").strip()):
                return False
            c = _core()
            done = bool(c.initial_setup_completed()) if hasattr(c, "initial_setup_completed") else bool(c.initial_sync_done())
            return not done
        except Exception:
            return False

    def _r97_effective_status(self, short=False):
        status = getattr(self, "_conn_status_r97", "") or self._r97_server_status()
        try:
            no_token = not (ADDON.getSetting("plex_token") or "").strip()
        except Exception:
            no_token = False
        if status == "연결됨" and no_token:
            return "로그인 필요" if short else "서버 응답 · 로그인 필요"
        return status

    def _r97_refresh_aside_sub(self):
        status = self._r97_effective_status(short=True)
        if self._r260_setup_pending():
            status = "라이브러리 선택 필요"
        self.setProperty("PlexKM.Settings.AsideSub", "Plex 서버 · " + status)

    def _show_category_r97(self, idx, focus_list=True, light=False):
        idx = max(0, min(int(idx), len(self._r97_categories()) - 1))
        if self._inline_address_active_v1711:
            return
        self._stack = []
        self._r97_mark_category(idx)
        self._r97_keep_aside_focus = not focus_list
        if idx == 0:
            # R333: one list for every library (Kodi folders and the Plex server);
            # no network access until the Plex row is opened.
            self._show_sources_r108(push=False)
        elif idx == 1:
            self._src_scope_r334 = "plex"
            self._show_plex_connection(push=False, focus_pos=0)
        elif idx == 2:
            self._show_storage_r334(push=False)
        elif idx == 3:
            self._show_tips_r315(push=False)
        elif idx == 4:
            self._show_keys_r332(push=False)
        elif idx == 5:
            self._show_reset_menu_r97(push=False)
        else:
            self._show_about_r97(push=False)
        self._r97_keep_aside_focus = False
        self._r97_refresh_aside_sub()
        if focus_list:
            try:
                self.setFocusId(self.LIST_ID)
            except Exception:
                pass
        _log("PKM_SETTINGS_CATEGORY_R97 idx=%d page=%s" % (idx, self._page), xbmc.LOGINFO)

    # ------------------------------------------------------------------ R108
    def _kodi_row_label_r334(self, src):
        content = src.get("content")
        kind = {"movies": "영화", "tvshows": "드라마·TV", "videos": "영상"}.get(content, "전체")
        raw_path = (src.get("path") or "")
        parts = [x for x in raw_path.replace("\\", "/").split("/") if x and not x.endswith(":")]
        name = parts[-1] if parts else "Kodi 라이브러리"
        net = raw_path.lower().startswith(("smb:", "nfs:", "http:", "https:", "ftp:", "sftp:", "dav:", "davs:"))
        return "%s    %s · %s" % (name, kind, "네트워크" if net else "이 기기")

    def _ago_r335(self, ts):
        try:
            ts = int(ts or 0)
        except Exception:
            ts = 0
        if ts <= 0:
            return ""
        days = (time.strftime("%Y%j", time.localtime()) != time.strftime("%Y%j", time.localtime(ts)))
        if not days:
            return "오늘 " + time.strftime("%H:%M", time.localtime(ts))
        n = int((time.time() - ts) // 86400)
        return "어제" if n <= 1 else "%d일 전" % n

    def _lib_entries_r335(self):
        """Every library PlexKM shows (Plex libraries + folder libraries), hidden ones included."""
        from resources.lib import pkm_sources as ps
        out = []
        try:
            if ps.has_plex() and self._r97_server_status() == "연결됨":
                core = _core()
                selected, _cfg = core.selected_sections_state()
                chosen = set(str(x) for x in selected)
                for sec in core.fetch_sections(refresh=False, selected_only=False, persist=False):
                    sid = str(sec.get("section_id", ""))
                    if sid in chosen and not sid.startswith("k:"):
                        out.append({"sid": sid, "src": "plex", "title": sec.get("title") or sid,
                                    "stype": sec.get("section_type"), "count": int(sec.get("item_count") or 0),
                                    "synced": int(ps.lib_pref(sid, "synced_at", 0) or 0)})
        except Exception:
            _log("PKM_R335_LIB_ENTRIES_PLEX_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if ps.has_kodi():
                from resources.lib import pkm_kodi_source as ks
                for sec in ks.virtual_sections():
                    if str(sec["section_id"]).startswith("k:mv:"):
                        continue   # 뮤직비디오는 아래에서 소스별로 따로 나열
                    out.append({"sid": sec["section_id"], "src": "kodi", "title": sec["title"],
                                "stype": sec.get("section_type"), "count": int(sec.get("item_count") or 0),
                                "synced": int(ps.lib_pref(sec["section_id"], "synced_at", 0) or 0)})
        except Exception:
            _log("PKM_R335_LIB_ENTRIES_KODI_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            for src in ps.kodi_sources():
                if src.get("content") == ps.KODI_CONTENT_VIDEOS:
                    parts = [x for x in (src.get("path") or "").replace("\\", "/").split("/") if x and not x.endswith(":")]
                    out.append({"sid": src.get("id"), "src": "video", "title": src.get("label") or (parts[-1] if parts else "영상"),
                                "stype": "video", "count": 0, "synced": 0, "path": src.get("path") or ""})
        except Exception:
            pass
        try:
            from resources.lib import pkm_musicvideo as _mv
            for src in _mv.sources():
                n, at = _mv.summary(src)
                out.append({"sid": src.get("id"), "src": "musicvideo", "title": src.get("label") or "뮤직비디오",
                            "stype": "musicvideo", "count": n, "synced": at, "path": src.get("path") or ""})
        except Exception:
            _log("PKM_R337_LIB_ENTRIES_MV_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        for e in out:
            e["name"] = ps.lib_pref(e["sid"], "name", "") or e["title"]
            e["hidden"] = bool(ps.lib_pref(e["sid"], "hidden", False))
        return out

    def _lib_origin_r335(self, e):
        from resources.lib import pkm_sources as ps
        if e["src"] == "plex":
            return "Plex"
        if e["src"] in ("video", "musicvideo"):
            _p = (e.get("path") or "").lower()
            return ("" if e["src"] == "musicvideo" else "영상 폴더 · ") + ("네트워크" if _p.startswith(("smb:", "nfs:", "http:", "https:", "ftp:", "sftp:", "dav:", "davs:")) else "이 기기")
        paths = [x.get("path") or "" for x in ps.kodi_sources()
                 if x.get("content") in (("movies",) if e["sid"].endswith("movies") else ("tvshows",))]
        if paths and all(p.lower().startswith(("smb:", "nfs:", "http:", "https:", "ftp:", "sftp:", "dav:", "davs:")) for p in paths):
            return "네트워크"
        return "이 기기"

    def _lib_line_r335(self, e):
        unit = "편" if e.get("stype") == "movie" else "개"
        parts = [self._lib_origin_r335(e)]
        if e.get("count"):
            parts.append("{:,}{}".format(e["count"], unit))
        when = self._ago_r335(e.get("synced")) if e["src"] != "video" else ""
        if when:
            parts.append(when + (" 동기화" if e["src"] == "plex" else " 스캔"))
        if e.get("hidden"):
            parts.append("숨김")
        return "%s    %s" % (e["name"], " · ".join(parts))

    def _sources_rows_r108(self, scope="all"):
        from resources.lib import pkm_sources as ps
        rows, keys = [], []
        if scope != "kodi":
            entries = self._lib_entries_r335()
            self._lib_entries_cache_r335 = {e["sid"]: e for e in entries}
            for e in entries:
                rows.append(self._lib_line_r335(e))
                keys.append(("lib", e["sid"]))
            if ps.has_plex() and self._r97_server_status() != "연결됨":
                rows.append("Plex 서버    " + self._r97_server_status())
                keys.append(("plex", ""))
            if entries:
                rows.append("모두 새로 고침    전체 라이브러리 갱신")
                keys.append(("refreshall", ""))
            rows.append("라이브러리 추가    Plex · 폴더")
            keys.append(("add", ""))
            return rows, keys
        for src in ps.load_sources():
            if src.get("type") == ps.TYPE_KODI:
                rows.append(self._kodi_row_label_r334(src))
                keys.append(("kodi", src.get("id")))
        rows.append("새 파일 찾아 정보 받기    전체 폴더")
        keys.append(("rescan", ""))
        rows.append("정보 언어 · 스크래퍼    영화·드라마 한국어 TMDb")
        keys.append(("scraper", ""))
        return rows, keys

    def _show_sources_r108(self, push=True, focus_pos=None, scope="all"):
        self._src_scope_r334 = scope
        rows, keys = self._sources_rows_r108(scope)
        self._sources_keys_r108 = keys
        if scope == "kodi":
            self._render("내 저장소", rows, "storage_r334", push=push, focus_pos=focus_pos)
        else:
            self._render("라이브러리", rows, "sources_r108", push=push, focus_pos=focus_pos)

    def _show_storage_r334(self, push=True, focus_pos=None):
        self._show_sources_r108(push=push, focus_pos=focus_pos, scope="kodi")

    def _sources_click_r108(self, idx):
        from resources.lib import pkm_sources as ps
        keys = getattr(self, "_sources_keys_r108", []) or []
        if idx < 0 or idx >= len(keys):
            return
        kind, sid = keys[idx]
        if kind == "lib":
            self._show_lib_detail_r335(sid, row=idx)
            return
        if kind == "refreshall":
            self._lib_refresh_all_r335()
            return
        if kind == "plex":
            self._open_plex_libraries_r333()
            return
        if kind == "addfolder":
            self._storage_add_folder_r334(idx)
            return
        if kind == "rescan":
            self._r334_scan_with_feedback(None)
            return
        if kind == "scraper":
            _notify("영화·드라마 정보는 한국어 TMDb로 받습니다")
            return
        if kind == "kodi":
            src = next((x for x in ps.load_sources() if x.get("id") == sid), {}) or {}
            parts = [x for x in (src.get("path") or "").replace("\\", "/").split("/") if x]
            self._render(" › ".join(parts[-2:]) or "Kodi 폴더", [
                "이 폴더만 새 파일 찾기    폴더를 다시 읽어서 새 영화·드라마를 추가합니다",
                "폴더 등록 삭제    파일은 그대로 남습니다",
            ], "source_detail_r108", payload={"sid": sid, "path": src.get("path") or "", "row": idx}, push=True, focus_pos=0)
            return
        self._lib_add_menu_r335(idx)

    def _r334_scan_with_feedback(self, path, stamp=None):
        """Start a Kodi folder scan and report what it found when it ends."""
        from resources.lib import pkm_sources as ps
        try:
            before = ps.kodi_library_counts()
        except Exception:
            before = (0, 0)
        if not ps.kodi_scan(path):
            _notify("지금은 새 파일을 찾을 수 없습니다")
            return
        _notify("새 파일을 찾고 있습니다. 끝나면 알려드릴게요")

        def _watch():
            try:
                started = time.time()
                xbmc.sleep(1500)
                while ps.kodi_scanning() and time.time() - started < 1800:
                    xbmc.sleep(1000)
                after = ps.kodi_library_counts()
                for _sid in (stamp or ()):
                    ps.set_lib_pref(_sid, synced_at=int(time.time()))
                dm = max(0, int(after[0]) - int(before[0]))
                ds = max(0, int(after[1]) - int(before[1]))
                if dm or ds:
                    parts = []
                    if dm:
                        parts.append("영화 %d편" % dm)
                    if ds:
                        parts.append("드라마 %d개" % ds)
                    _notify("새로 찾았습니다: " + " · ".join(parts), ms=5000)
                else:
                    _notify("새로 추가된 파일이 없습니다", ms=4000)
            except Exception:
                _log("PKM_R334_SCAN_WATCH_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        threading.Thread(target=_watch, name="PKMScanWatchR334", daemon=True).start()

    # ------------------------------------------------------------------ R335
    def _show_lib_detail_r335(self, sid, row=0, push=True, focus_pos=0):
        e = (getattr(self, "_lib_entries_cache_r335", {}) or {}).get(sid)
        if e is None:
            e = next((x for x in self._lib_entries_r335() if x["sid"] == sid), None)
        if e is None:
            return
        when = self._ago_r335(e.get("synced"))
        if e["src"] == "musicvideo":
            rows = [
                "지금 새로 스캔    " + ("마지막 " + when if when else "아직 기록 없음"),
                "이름 안내    잘 읽히는 파일 이름",
                "이름 바꾸기    " + e["name"],
                "사이드메뉴에 보이기    " + ("숨김" if e["hidden"] else "보임"),
                "라이브러리 삭제    폴더 등록과 정리 결과만 빠집니다",
            ]
            self._render(e["name"], rows, "library_detail_r335", payload={"sid": sid, "row": row},
                         push=push, focus_pos=focus_pos)
            return
        if e["src"] == "video":
            rows = ["열기    썸네일로 보기", "이름 바꾸기    " + e["name"],
                    "라이브러리 삭제    폴더 등록만 빠집니다"]
            self._render(e["name"], rows, "library_detail_r335", payload={"sid": sid, "row": row},
                         push=push, focus_pos=focus_pos)
            return
        rows = [
            "지금 새로 고침    " + ("마지막 " + when if when else "아직 기록 없음"),
            "이름 바꾸기    " + e["name"],
            "사이드메뉴에 보이기    " + ("숨김" if e["hidden"] else "보임"),
            "라이브러리 삭제    " + ("목록에서만 빠집니다" if e["src"] == "plex" else "이 종류 폴더 등록이 함께 빠집니다"),
        ]
        self._render(e["name"], rows, "library_detail_r335", payload={"sid": sid, "row": row},
                     push=push, focus_pos=focus_pos)

    def _lib_detail_click_r335(self, idx):
        from resources.lib import pkm_sources as ps
        sid = (self._payload or {}).get("sid")
        row = int((self._payload or {}).get("row") or 0)
        e = next((x for x in self._lib_entries_r335() if x["sid"] == sid), None)
        if e is None:
            return
        if e["src"] == "musicvideo":
            from resources.lib import pkm_musicvideo as _mv
            src = next((s for s in _mv.sources() if s.get("id") == sid), None)
            if idx == 0:
                if src is not None and not _mv.scan_source(src):
                    _notify("이미 스캔 중이거나 구성 요소가 없습니다")
            elif idx == 1:
                open_pkm_confirm_dialog(_mv.GUIDE_TITLE, _mv.GUIDE_BODY, yes_label="확인", no_label="취소")
            elif idx == 2:
                self._lib_rename_r335(e, row, 2)
                _mv.bump()
            elif idx == 3:
                ps.set_lib_pref(sid, hidden=(not e["hidden"]))
                _notify("사이드메뉴에서 " + ("숨겼습니다" if not e["hidden"] else "다시 보입니다"))
                _mv.bump()
                self._lib_rerender_r335(sid, row, 3)
            elif idx == 4:
                self._lib_delete_r335(e, row)
            return
        if e["src"] == "video":
            if idx == 0:
                _u_r336 = "plugin://plugin.video.km/?action=videofolder&path=" + __import__("urllib.parse", fromlist=["quote"]).quote(e.get("path", ""), safe="")
                try:
                    self.close()
                except Exception:
                    pass
                xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % _u_r336)
            elif idx == 1:
                self._lib_rename_r335(e, row)
            elif idx == 2:
                self._lib_delete_r335(e, row)
            return
        if idx == 0:
            self._lib_refresh_r335([e])
        elif idx == 1:
            try:
                text = xbmcgui.Dialog().input("라이브러리 이름", e["name"], type=xbmcgui.INPUT_ALPHANUM)
            except Exception:
                text = ""
            text = str(text or "").strip()
            if text and text != e["name"]:
                ps.set_lib_pref(sid, name=("" if text == e["title"] else text))
                _notify("이름을 바꿨습니다")
            self._lib_rerender_r335(sid, row, 1)
        elif idx == 2:
            if not e["hidden"]:
                visible = [x for x in self._lib_entries_r335() if not x["hidden"] and x["src"] not in ("video", "musicvideo")]
                if len(visible) <= 1:
                    _notify("마지막 라이브러리는 숨길 수 없습니다")
                    return
            ps.set_lib_pref(sid, hidden=(not e["hidden"]))
            _notify("사이드메뉴에서 " + ("숨겼습니다" if not e["hidden"] else "다시 보입니다"))
            self._lib_rerender_r335(sid, row, 2)
        elif idx == 3:
            self._lib_delete_r335(e, row)

    def _lib_rename_r335(self, e, row, focus=1):
        from resources.lib import pkm_sources as ps
        try:
            text = xbmcgui.Dialog().input("라이브러리 이름", e["name"], type=xbmcgui.INPUT_ALPHANUM)
        except Exception:
            text = ""
        text = str(text or "").strip()
        if text and text != e["name"]:
            ps.set_lib_pref(e["sid"], name=("" if text == e["title"] else text))
            _notify("이름을 바꿨습니다")
        self._lib_rerender_r335(e["sid"], row, focus)

    def _lib_rerender_r335(self, sid, row, focus):
        """Rebuild the hub (so its line shows the new name/hidden state), then reopen the detail on top."""
        self._stack = []
        self._show_sources_r108(push=False, focus_pos=row, scope="all")
        self._show_lib_detail_r335(sid, row=row, push=True, focus_pos=focus)

    def _lib_delete_r335(self, e, row):
        from resources.lib import pkm_sources as ps
        if e["src"] in ("video", "musicvideo"):
            body = "이 폴더가 PlexKM 목록에서 빠집니다\n폴더의 영상 파일은 그대로 남습니다"
        elif e["src"] == "plex":
            body = "PlexKM 화면과 검색에서 빠집니다\nPlex 서버의 데이터는 그대로 남고, 라이브러리 추가에서 다시 고를 수 있습니다"
        else:
            body = "이 종류의 폴더 등록이 모두 빠지고 PlexKM 화면과 검색에서 사라집니다\n폴더의 파일은 그대로 남습니다"
        ok = open_pkm_confirm_dialog("이 라이브러리를 삭제할까요?", body, yes_label="삭제", no_label="취소", default_focus="no")
        if not ok:
            return
        if e["src"] in ("video", "musicvideo"):
            ps.remove_source(e["sid"], reason="library_delete_r335")
            if e["src"] == "musicvideo":
                try:
                    from resources.lib import pkm_musicvideo as _mv
                    _mv.bump()
                except Exception:
                    pass
        elif e["src"] == "plex":
            core = _core()
            selected, _cfg = core.selected_sections_state()
            core.save_selected_sections([x for x in selected if str(x) != e["sid"] and not str(x).startswith("k:")])
        else:
            content = "movies" if e["sid"].endswith("movies") else "tvshows"
            for src in list(ps.kodi_sources()):
                if src.get("content") == content:
                    ps.remove_source(src.get("id"), reason="library_delete_r335")
            try:
                from resources.lib import pkm_kodi_source as ks
                threading.Thread(target=ks.sync, kwargs={"reason": "library_delete_r335"}, daemon=True).start()
            except Exception:
                pass
        ps.set_lib_pref(e["sid"], name="", hidden=False)
        _notify("라이브러리를 삭제했습니다")
        self._stack = []
        self._show_sources_r108(push=False, focus_pos=max(0, row - 1), scope="all")

    def _lib_refresh_r335(self, entries):
        """Refresh one or more libraries in the background; the result comes as a notice."""
        from resources.lib import pkm_sources as ps
        plex = [e for e in entries if e["src"] == "plex"]
        kodi = [e for e in entries if e["src"] == "kodi"]
        label = entries[0]["name"] if len(entries) == 1 else "전체 라이브러리"
        _notify("%s 새로 고치는 중" % label)

        def _run():
            try:
                core = _core()
                for e in plex:
                    try:
                        core.sync_section(section_id=e["sid"], show_progress=False)
                        ps.set_lib_pref(e["sid"], synced_at=int(time.time()))
                    except Exception:
                        _log("PKM_R335_PLEX_REFRESH_FAILED sid=%s %s" % (e["sid"], traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                if plex and not kodi:
                    _notify("%s 새로 고쳤습니다" % label, ms=4000)
            except Exception:
                _log("PKM_R335_REFRESH_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        if plex:
            threading.Thread(target=_run, name="PKMLibRefreshR335", daemon=True).start()
        if kodi:
            self._r334_scan_with_feedback(None, stamp=[e["sid"] for e in kodi])

    def _lib_refresh_all_r335(self):
        entries = self._lib_entries_r335()
        if not entries:
            _notify("새로 고칠 라이브러리가 없습니다")
            return
        self._lib_refresh_r335(entries)

    def _lib_add_menu_r335(self, idx):
        from resources.lib import pkm_sources as ps
        self._lib_add_idx_r335 = idx
        self._render("라이브러리 추가", [
            "Plex 라이브러리 선택    서버에서 골라 추가",
            "상위 폴더로 추가    영화·드라마 자동 구분",
            "영화 폴더 추가    TMDb 정보 받기",
            "드라마 폴더 추가    TMDb 정보 받기",
            "영상 폴더 추가    개인 영상 · 썸네일로 보기",
            "뮤직비디오 폴더 추가    아티스트·제목 읽어 정리",
            "음악 폴더 추가    준비 중",
        ], "library_add_r335", push=True, focus_pos=0)

    def _lib_add_click_r335(self, idx):
        from resources.lib import pkm_source_wizard_r108 as wiz
        if idx == 0:
            self._open_plex_libraries_r333()
        elif idx in (1, 2, 3, 4, 5):
            wiz.run_wizard(mode={1: "add_auto", 2: "add_movies", 3: "add_tvshows", 4: "add_videos", 5: "add_musicvideos"}[idx])
            self._stack = []
            self._show_sources_r108(push=False, focus_pos=0, scope="all")
        else:
            _notify("아직 준비 중입니다")

    def _storage_add_folder_r334(self, idx):
        from resources.lib import pkm_source_wizard_r108 as wiz
        wiz.run_wizard(mode="add_folder")
        self._show_sources_r108(push=False, focus_pos=idx, scope="kodi")

    def _open_plex_libraries_r333(self):
        """Plex row in the library list: pick which Plex libraries PlexKM shows.
        Not configured yet -> the server page, where address and login are entered."""
        if self._r97_server_status() == "설정 필요":
            self._show_category_r97(1, focus_list=True)
            return
        if not self._show_library_selection(push=True, focus_pos=0):
            self._render("라이브러리", ["라이브러리 목록을 가져오지 못했습니다    서버 연결을 확인하세요"],
                         "library_unavailable_r97", push=True, actionable=[])

    def _source_detail_click_r108(self, idx):
        from resources.lib import pkm_sources as ps
        info = dict(self._payload or {})
        sid, row = info.get("sid"), int(info.get("row") or 0)
        _log("PKM_SOURCES_R108_KODI_ROW_ACTION sid=%s pick=%s" % (sid, idx), xbmc.LOGINFO)
        if idx == 0:
            self._r334_scan_with_feedback(info.get("path") or None)
            return
        if idx == 1:
            ok = open_pkm_confirm_dialog(
                "이 폴더 등록을 삭제할까요?",
                "이 폴더의 작품이 PlexKM 화면과 검색에서 빠집니다\n폴더의 파일은 그대로 남습니다",
                yes_label="삭제", no_label="취소", default_focus="no",
            )
            if not ok:
                return
            ps.remove_source(sid, reason="settings_remove")
            _notify("폴더 등록을 삭제했습니다")
            self._stack = []
            self._show_sources_r108(push=False, focus_pos=max(0, row - 1),
                                    scope=("kodi" if getattr(self, "_src_scope_r334", "all") == "kodi" else "all"))
            return

    def _sources_add_r108(self, idx):
        from resources.lib import pkm_source_wizard_r108 as wiz
        result = wiz.run_wizard(mode="add")
        choice = (result or {}).get("choice")
        _log("PKM_SOURCES_R108_SETTINGS_ADD choice=%s" % (choice or "none"), xbmc.LOGINFO)
        if choice == "plex":
            self._show_category_r97(1, focus_list=True)
        else:
            self._show_sources_r108(push=False, focus_pos=idx)

    # ------------------------------------------------------------------ R120c
    def _show_meta_r120(self, push=True, focus_pos=None):
        from resources.lib import pkm_meta_override_r120 as ovr
        on = ovr.enabled()
        n_items, n_actors = ovr.count()
        self._render("메타데이터", [
            "직접 바꾼 정보 유지    %s" % ("켬 · Plex 정보가 들어와도 그대로" if on else "끔 · Plex가 갱신하면 Plex를 따름"),
            "직접 바꾼 작품 %d개 · 배우 사진 %d명    모두 Plex 원래 정보로" % (n_items, n_actors),
        ], "meta_r120", push=push, focus_pos=focus_pos)

    def _meta_rerender_r334(self, pos):
        if self._page == "plex_connection":
            self._show_plex_connection(push=False, focus_pos=pos + 4)
        else:
            self._show_meta_r120(push=False, focus_pos=pos)

    def _meta_click_r120(self, idx):
        from resources.lib import pkm_meta_override_r120 as ovr
        if idx == 0:
            ovr.set_enabled(not ovr.enabled())
            _notify("직접 바꾼 정보 유지: %s" % ("켬" if ovr.enabled() else "끔"))
            self._meta_rerender_r334(0)
        elif idx == 1:
            n_items, n_actors = ovr.count()
            if not (n_items or n_actors):
                _notify("직접 바꾼 정보가 없습니다")
                return
            ok = open_pkm_confirm_dialog(
                "직접 바꾼 정보를 모두 지울까요?",
                "작품 %d개 · 배우 사진 %d명\n다음 동기화부터 Plex 원래 정보로 돌아갑니다" % (n_items, n_actors),
                yes_label="지우기", no_label="취소")
            if not ok:
                return
            ovr.clear_all()
            _notify("직접 바꾼 정보를 지웠습니다")
            self._meta_rerender_r334(1)

    # ------------------------------------------------------------------ R315
    def _show_tips_r315(self, push=True, focus_pos=None):
        from resources.lib import pkm_tips as pt
        on = pt.enabled()
        n = pt.daily_max()
        self._render("팁 · 취향", [
            "팁 표시    %s" % ("켬 · 가끔 사용 팁을 보여줘요" if on else "끔 · 팁을 보여주지 않아요"),
            "하루 최대 표시    %s" % ("%d번" % n if n else "표시 안 함"),
            "팁 다시 보기    본 팁 기록 초기화",
            "유튜브 로그인 안내 다시 보기    트레일러 페이지 안내 배너",
            "취향 다시 고르기    좋아하는 영화·드라마를 새로 고릅니다",
        ], "tips_r315", push=push, focus_pos=focus_pos)

    def _tips_click_r315(self, idx):
        from resources.lib import pkm_tips as pt
        if idx == 0:
            ADDON.setSetting("pkm_tips_enabled", "false" if pt.enabled() else "true")
            _notify("팁 표시: %s" % ("켬" if pt.enabled() else "끔"))
            self._show_tips_r315(push=False, focus_pos=0)
        elif idx == 1:
            n = (pt.daily_max() + 1) % 6
            ADDON.setSetting("pkm_tips_daily_max", str(n))
            self._show_tips_r315(push=False, focus_pos=1)
        elif idx == 2:
            pt.reset()
            _notify("팁 기록을 초기화했습니다")
            self._show_tips_r315(push=False, focus_pos=2)
        elif idx == 3:
            try:
                pt.login_banner_later(0)
            except Exception:
                pass
            _notify("트레일러 페이지에서 로그인 안내를 다시 보여드려요")
            self._show_tips_r315(push=False, focus_pos=3)
        elif idx == 4:
            try:
                if xbmcvfs.exists("special://home/addons/script.pkm.setup/addon.xml"):
                    xbmc.executebuiltin("RunScript(script.pkm.setup,retaste)")
                else:
                    _notify("PlexKM 설치 도우미가 설치되어 있지 않습니다")
            except Exception:
                pass

    def _show_keys_r332(self, push=True, focus_pos=None):
        rows = ["백업에서 복원    저장해 둔 유튜브 키·로그인 불러오기"]
        try:
            from resources.lib import pkm_youtube_backup as bk
            payload = bk.read()
        except Exception:
            payload = None
        if not payload:
            rows.append("백업 내용    저장된 백업 없음")
        else:
            d = payload.get("data") or {}
            a = d.get("youtube_account_r79.json") or {}
            rows.append("유튜브 API 키    " + ("저장됨" if (d.get("youtube_settings_r79.json") or {}).get("api_key") else "없음"))
            rows.append("유튜브 계정    " + ((a.get("name") or "로그인됨") if a.get("refresh_token") else ("OAuth만 저장됨" if a.get("client_id") else "없음")))
            rows.append("SubDL 키    " + ("저장됨" if (d.get("pkm_subdl_r332") or {}).get("api_key") else "없음"))
            rows.append("마지막 백업    " + str(payload.get("created_text") or "-"))
        rows.append("자동 백업    키를 저장하면 자동으로 백업됩니다")
        self._render("키 · 백업", rows, "keys_r332", push=push, focus_pos=focus_pos)

    def _keys_click_r332(self, idx):
        try:
            from resources.lib import pkm_youtube_backup as bk
        except Exception:
            _notify("백업 기능을 불러오지 못했습니다")
            return
        if idx == 0:
            payload = bk.read()
            if not payload:
                _notify("저장된 백업이 없습니다", ms=3000)
                return
            confirmed = open_pkm_confirm_dialog(
                "백업에서 복원할까요?",
                bk.summary(payload) + "\n현재 유튜브 키와 로그인을 덮어씁니다",
                yes_label="복원",
                no_label="취소",
                default_focus="no",
            )
            if not confirmed:
                return
            ok, msg = bk.restore(payload)
            _notify(msg, ms=3500)
            self._show_keys_r332(push=False, focus_pos=0)
        else:
            self._show_keys_r332(push=False, focus_pos=idx)

    def _show_reset_menu_r97(self, push=True, focus_pos=None):
        self._render("초기화", [
            "화면 캐시 비우기    포스터·화면 준비 캐시만, 설정 유지",
            "취향·팁 초기화    취향 선택과 본 팁 기록",
            "Plex 연결 초기화    서버 주소·토큰 삭제",
            "내 저장소 초기화    폴더 목록만 비움 · 파일은 그대로",
            "유튜브·자막 키 초기화    키와 로그인 정보 삭제",
            "전체 초기화    모든 PlexKM 데이터 삭제",
        ], "reset_menu_r97", push=push, focus_pos=focus_pos)

    def _r334_reset_storage(self):
        from resources.lib import pkm_sources as ps
        srcs = [x for x in ps.load_sources() if x.get("type") == ps.TYPE_KODI]
        if not srcs:
            _notify("등록된 폴더가 없습니다")
            return
        ok = open_pkm_confirm_dialog(
            "내 저장소를 초기화할까요?",
            "등록한 폴더 %d개를 PlexKM에서 뺍니다\n폴더의 파일과 Plex 서버는 그대로 남습니다" % len(srcs),
            yes_label="초기화", no_label="취소", default_focus="no")
        if not ok:
            return
        for src in srcs:
            try:
                ps.remove_source(src.get("id"), reason="settings_reset_storage")
            except Exception:
                _log("PKM_R334_RESET_STORAGE_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        _notify("내 저장소를 초기화했습니다")

    def _r332_reset_taste_tips(self):
        confirmed = open_pkm_confirm_dialog(
            "취향과 팁 기록을 초기화할까요?",
            "고른 취향과 본 팁 기록을 지우고\n취향을 새로 고릅니다",
            yes_label="초기화",
            no_label="취소",
            default_focus="no",
        )
        if not confirmed:
            return
        try:
            from resources.lib import pkm_tips as pt
            pt.reset()
        except Exception:
            _log("PKM_RESET_TIPS_FAILED_R332 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if xbmcvfs.exists("special://home/addons/script.pkm.setup/addon.xml"):
                _notify("팁 기록을 초기화했습니다. 취향을 새로 고릅니다")
                xbmc.executebuiltin("RunScript(script.pkm.setup,retaste)")
            else:
                _notify("팁 기록을 초기화했습니다")
        except Exception:
            pass

    def _r332_reset_youtube_subdl_keys(self):
        confirmed = open_pkm_confirm_dialog(
            "유튜브·자막 키를 초기화할까요?",
            "유튜브 키와 로그인 정보, SubDL 키를 삭제합니다\n다운로드 폴더의 백업 파일은 그대로 남습니다",
            yes_label="초기화",
            no_label="취소",
            default_focus="no",
        )
        if not confirmed:
            return
        removed = 0
        try:
            base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
            for name in ("youtube_settings_r79.json", "youtube_account_r79.json", "youtube_account_subs_r79.json"):
                path = os.path.join(base, name)
                if os.path.exists(path):
                    os.remove(path)
                    removed += 1
        except Exception:
            _log("PKM_RESET_YOUTUBE_FAILED_R332 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            ADDON.setSetting("pkm_subdl_api_key", "")
        except Exception:
            pass
        _log("PKM_RESET_KEYS_R332 youtube_files=%d subdl=1" % removed, xbmc.LOGINFO)
        _notify("유튜브·자막 키를 초기화했습니다", ms=3000)

    def _show_about_r97(self, push=True):
        def _ver(addon_id):
            try:
                return xbmcaddon.Addon(addon_id).getAddonInfo("version") or "-"
            except Exception:
                return "-"
        try:
            kodi = (xbmc.getInfoLabel("System.BuildVersion") or "-").split(" ")[0]
        except Exception:
            kodi = "-"
        url = (ADDON.getSetting("plex_url") or "").strip()
        account = (ADDON.getSetting("plex_account_name") or "").strip()
        rows = [
            "PlexKM 플러그인    v" + _ver("plugin.video.km"),
            "PlexKM 스킨    v" + _ver("skin.plex.km"),
            "Kodi    " + kodi,
            "Plex 서버    " + (short_setting_value(url, 48) if url else "미설정"),
            "Plex 계정    " + (account or ("인증됨" if (ADDON.getSetting("plex_token") or "").strip() else "미인증")),
        ]
        try:
            from resources.lib import pkm_sources as _ps334
            _n334 = len([x for x in _ps334.load_sources() if x.get("type") == _ps334.TYPE_KODI])
            rows.append("내 저장소    " + ("폴더 %d개" % _n334 if _n334 else "등록한 폴더 없음"))
            _libs335 = self._lib_entries_r335()
            if _libs335:
                _hid335 = len([x for x in _libs335 if x["hidden"]])
                rows.append("라이브러리    %d개%s" % (len(_libs335), " · 숨김 %d개" % _hid335 if _hid335 else ""))
        except Exception:
            pass
        self._render("정보", rows, "about_r97", push=push, actionable=[])

    def _r97_clear_screen_cache(self):
        """Delete rebuildable PKM screen caches (prepared rows, poster/thumb caches).

        Settings, DBs, play state, profiles and sort/intro choices are kept."""
        import shutil
        base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
        removed = 0
        if not base or not os.path.isdir(base):
            return 0
        keep_prefix = ("plex_km", "library_sort_index", "settings", "state", "profile", "playstate",
                       "continue_", "tv_episode_sort", "intro_skip_mode", "next_episode_timing", "skip_profile",
                       "youtube_", "search_history", "pkm_video_defaults", "ratings_service")
        cache_files = ("_prepared_cache", "info_actor_rows_cache", "actor_profile_tmdb_cache",
                       "tmdb_episode_plot", "section_scene_cache", "startup_poster_dead")
        cache_dirs = ("episode_thumb_cache", "wall_poster_cache", "actor_bg_", "actor_profile_images", "cast_cache")
        for name in sorted(os.listdir(base)):
            path = os.path.join(base, name)
            low = name.lower()
            try:
                if os.path.isdir(path):
                    if any(low.startswith(p) for p in cache_dirs):
                        shutil.rmtree(path, ignore_errors=True)
                        removed += 1
                elif low.endswith(".json") and not low.startswith(keep_prefix):
                    if any(p in low for p in cache_files):
                        os.remove(path)
                        removed += 1
            except Exception:
                _log("PKM_SCREEN_CACHE_CLEAR_ITEM_FAILED_R97 name=%s" % name, xbmc.LOGWARNING)
        _log("PKM_SCREEN_CACHE_CLEAR_R97 removed=%d base=%s" % (removed, base), xbmc.LOGINFO)
        return removed

    def _r97_reset_plex_connection_flow(self):
        confirmed = open_pkm_confirm_dialog(
            "Plex 연결을 초기화할까요?",
            "저장된 서버 주소와 토큰이 삭제됩니다\n라이브러리와 시청 기록은 그대로 남습니다",
            yes_label="초기화",
            no_label="취소",
            default_focus="no",
        )
        if not confirmed:
            return
        ok = _reset_plex_connection_v1922()
        self._conn_status_r97 = ""
        self._r97_refresh_aside_sub()
        _log("PKM_PLEX_CONNECTION_RESET_R97 ok=%s" % (1 if ok else 0), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        try:
            _notify("Plex 연결 정보를 초기화했습니다" if ok else "Plex 연결 초기화에 실패했습니다",
                    icon=xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, ms=3000)
        except Exception:
            pass

    def _r97_connection_test(self):
        url = (ADDON.getSetting("plex_url") or "").strip()
        if not url:
            self._conn_status_r97 = "설정 필요"
            self._r97_refresh_aside_sub()
            _notify("Plex 서버 주소를 먼저 입력하세요", icon=xbmcgui.NOTIFICATION_WARNING, ms=3000)
            return
        self._conn_status_r97 = "확인 중"
        self._r97_refresh_aside_sub()
        self._refresh_plex_connection_in_place_v1703(focus_pos=2)
        ok = False
        try:
            ok = bool(_probe_candidate_plex_url_v1922(url))
        except Exception:
            ok = False
        self._conn_status_r97 = "연결됨" if ok else "연결 실패"
        self._r97_refresh_aside_sub()
        self._refresh_plex_connection_in_place_v1703(focus_pos=2)
        try:
            _no_tok = not (ADDON.getSetting("plex_token") or "").strip()
        except Exception:
            _no_tok = False
        if ok and _no_tok:
            _notify("서버는 응답합니다. 아직 Plex 로그인이 필요합니다",
                    icon=xbmcgui.NOTIFICATION_WARNING, ms=4000)
        else:
            _notify("Plex 서버에 연결되었습니다" if ok else "Plex 서버에 연결할 수 없습니다",
                    icon=xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, ms=3000)

    def _r97_apply_row_parts(self, li, label, idx):
        import re as _re_r97
        text = _display_text_for_kodi(label)
        value = ""
        if str(self._page or "") == "library_select":
            m = _re_r97.match(r"^(.*?)\s+\((movie|show|artist|photo)\s*/\s*id=[^)]*\)\s*$", text)
            if m:
                text = m.group(1).strip()
                value = {"movie": "영화", "show": "드라마·예능", "artist": "음악", "photo": "사진"}.get(m.group(2), m.group(2))
        else:
            parts = _re_r97.split(r"\s{3,}", text, maxsplit=1)
            if len(parts) == 2:
                text, value = parts[0].strip(), parts[1].strip()
        li.setLabel(text)
        li.setLabel2(value)
        page = str(self._page or "")
        chevron = page in ("plex_connection", "reset_menu_r97", "library_hint_r97", "sources_r108", "storage_r334", "meta_r120", "tips_r315", "keys_r332") and not self._multiselect and idx not in (self._show_checks or set())
        li.setProperty("chevron", "1" if chevron else "0")
        li.setProperty("danger", "1" if (page == "reset_menu_r97" and idx >= 2) else "0")

    def _set_full_reset_progress_v2164(self, percent, stage, detail=""):
        """Publish real reset stage progress on the existing settings WindowXML.

        This is stage-based, not a fake elapsed-time animation.  Long waits keep
        the current stage visible and advance only inside that stage's bounded
        wait budget.
        """
        try:
            pct = max(0, min(100, int(percent)))
        except Exception:
            pct = 0
        stage_text = _display_text_for_kodi(stage or "초기화 진행 중")
        detail_text = _display_text_for_kodi(detail or "")
        try:
            self.setProperty("PlexKM.Dialog.FullResetProgressV2164", "1")
            self.setProperty("PlexKM.Dialog.FullResetStageV2164", stage_text)
            self.setProperty("PlexKM.Dialog.FullResetDetailV2164", detail_text)
            self.setProperty("PlexKM.Dialog.FullResetPercentV2164", str(pct))
            self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi("초기화"))
            self.setProperty("PlexKM.Dialog.Hint", _display_text_for_kodi("Kodi가 다시 시작될 때까지 기다려주세요"))
        except Exception:
            pass
        try:
            ctrl = self._full_reset_progress_control_v2164
            if ctrl is None:
                ctrl = self.getControl(self.FULL_RESET_PROGRESS_ID_V2164)
                self._full_reset_progress_control_v2164 = ctrl
            ctrl.setPercent(pct)
        except Exception:
            pass
        _log("PKM_FULL_RESET_PROGRESS_V2164 percent=%d stage=%s detail=%s" % (
            pct, stage_text.replace(" ", "_"), detail_text.replace(" ", "_")
        ), xbmc.LOGINFO)

    def _run_full_reset_v1997(self):
        # v2007: Reset remains inside the PlexKM settings flow.  Do not arm
        # Home/startup-logo transitions for an operation that only clears data.
        confirmed = open_pkm_confirm_dialog(
            "전체 초기화할까요?",
            "서버 정보·라이브러리 설정·DB·캐시를 모두 삭제하고\n"
            "Kodi가 종료됩니다 · 되돌릴 수 없습니다",
            yes_label="전체 초기화",
            no_label="취소",
            default_focus="no",
        )
        if not confirmed:
            # Keep the existing root menu and focus exactly as-is.
            return

        # v2163: a destructive full reset is now an explicit Kodi process
        # boundary. Do not let the user leave the modal and expose the already-
        # instantiated Home while worker drain/profile purge is still running.
        # The next Kodi process is the only owner allowed to build the clean
        # first-run Home.
        self._full_reset_exit_pending_v2163 = True
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.FullResetExitPendingV2163", "1")
        except Exception:
            pass
        _log("PKM_FULL_RESET_EXIT_POLICY_V2163 action=lock_settings_until_purge_then_quit live_home_handoff=0", xbmc.LOGINFO)
        self._set_full_reset_progress_v2164(5, "초기화 준비 중", "진행 중인 PlexKM 작업을 안전하게 중지합니다.")

        ok = True
        failure_phase_v2165 = ""
        win_reset_v2149 = xbmcgui.Window(10000)
        reset_success_v2150 = False
        base = ADDON.getAddonInfo("profile") or ""
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            pass
        try:
            # v2149: full reset is a real background-work barrier, not just a
            # file purge.  Signal every sync/prewarm worker BEFORE credentials
            # or DB files disappear.  The service/startup sync observes this
            # property and releases sync.lock cooperatively.
            now_ms_v2149 = int(time.time() * 1000)
            reset_token_v2151 = str(now_ms_v2149)
            # v2151: clear previous ACK/request state BEFORE publishing the reset
            # trigger.  Doing this afterward leaves a small race where a fast Home
            # drain can ACK and the settings thread can accidentally erase it.
            for _prop_v2151 in (
                "PlexKM.Home.FullResetWorkersStoppedV2151",
                "PlexKM.Home.FullResetWorkersPendingV2151",
                "PlexKM.Home.FullResetMemoryPurgedV2151",
                "PlexKM.Home.FullResetPurgeRequestV2151",
                "PlexKM.ServiceFullResetStoppedV2151",
            ):
                try:
                    win_reset_v2149.clearProperty(_prop_v2151)
                except Exception:
                    pass
            # v2150: Full reset is a hard lifetime barrier.  Keep both the v2149
            # compatibility property and the new semantic property asserted for
            # the remainder of this Kodi process after a successful reset.  This
            # prevents any surviving daemon/prewarm worker from recreating the DB
            # or cache after the purge.  Window properties naturally disappear on
            # the next Kodi launch.
            win_reset_v2149.setProperty("PlexKM.FullResetInProgressV2149", "1")
            win_reset_v2149.setProperty("PlexKM.FullResetInProgressV2150", "1")
            win_reset_v2149.setProperty("PlexKM.FullResetRequestedAtV2149", str(now_ms_v2149))
            win_reset_v2149.setProperty("PlexKM.FullResetRequestedAtV2150", str(now_ms_v2149))
            win_reset_v2149.setProperty("PlexKM.SettingsQuietUntilMs", str(now_ms_v2149 + 86400000))
            win_reset_v2149.setProperty("PlexKM.Home.BackgroundAbortV2150", "1")
            _log("PKM_FULL_RESET_BARRIER_BEGIN_V2150 profile=%s credentials_cleared=0 hard_stop=1" % (base or ""), xbmc.LOGINFO)
            self._set_full_reset_progress_v2164(12, "홈 작업 종료 중", "현재 화면의 위젯/이미지 작업을 정리합니다.")

            # v2151: V2150 only drained sync.lock/Plex/artwork.  A live Home can
            # still have recommendation/cast/poster workers whose final data-only
            # step is outside those counters.  The live Home owns those threads, so
            # require its explicit stop ACK before credentials or profile files move.
            home_live_v2151 = False
            try:
                home_live_v2151 = win_reset_v2149.getProperty("PlexKM.HomeWindowActive") == "true"
            except Exception:
                home_live_v2151 = False
            home_waited_v2151 = 0
            if home_live_v2151:
                while home_waited_v2151 < 22000:
                    if win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersStoppedV2151") == reset_token_v2151:
                        break
                    xbmc.sleep(25)
                    home_waited_v2151 += 25
                    if home_waited_v2151 % 500 == 0:
                        self._set_full_reset_progress_v2164(12 + min(16, int(home_waited_v2151 * 16 / 22000)), "홈 작업 종료 중", "남아 있는 홈 작업을 기다립니다.")
                home_workers_ok_v2151 = win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersStoppedV2151") == reset_token_v2151
            else:
                home_workers_ok_v2151 = True
            self._set_full_reset_progress_v2164(30, "서비스 작업 종료 중", "PlexKM 서비스와 백그라운드 작업을 정리합니다.")
            try:
                ui_owner_nonblocking_v2165 = win_reset_v2149.getProperty("PlexKM.Service.HomeAutostartUiOwnerV2165") == "1"
            except Exception:
                ui_owner_nonblocking_v2165 = False
            _log("PKM_FULL_RESET_UI_OWNER_CLASS_V2165 name=PlexKMHomeAutostartV984 ui_owner=%d service_drain_blocker=0 reason=WindowXML_lifetime_owner" % (
                1 if ui_owner_nonblocking_v2165 else 0
            ), xbmc.LOGINFO)
            service_running_v2151 = False
            try:
                service_running_v2151 = win_reset_v2149.getProperty("PlexKM.ServiceRunningV2151") == "1"
            except Exception:
                service_running_v2151 = False
            service_waited_v2151 = 0
            if service_running_v2151:
                while service_waited_v2151 < 22000:
                    if win_reset_v2149.getProperty("PlexKM.ServiceFullResetStoppedV2151") == "1":
                        break
                    xbmc.sleep(25)
                    service_waited_v2151 += 25
                    if service_waited_v2151 % 500 == 0:
                        self._set_full_reset_progress_v2164(30 + min(18, int(service_waited_v2151 * 18 / 22000)), "서비스 작업 종료 중", "서비스 종료 응답을 기다립니다.")
                service_workers_ok_v2151 = win_reset_v2149.getProperty("PlexKM.ServiceFullResetStoppedV2151") == "1"
            else:
                service_workers_ok_v2151 = True
            _log("PKM_FULL_RESET_OWNER_DRAIN_V2151 token=%s home_live=%d home_waited_ms=%d home_ok=%d home_pending=%s service_live=%d service_waited_ms=%d service_ok=%d credentials_cleared=0" % (
                reset_token_v2151, 1 if home_live_v2151 else 0, home_waited_v2151, 1 if home_workers_ok_v2151 else 0,
                win_reset_v2149.getProperty("PlexKM.Home.FullResetWorkersPendingV2151") or "-",
                1 if service_running_v2151 else 0, service_waited_v2151, 1 if service_workers_ok_v2151 else 0
            ), xbmc.LOGINFO if (home_workers_ok_v2151 and service_workers_ok_v2151) else xbmc.LOGWARNING)
            if not home_workers_ok_v2151 or not service_workers_ok_v2151:
                failure_phase_v2165 = "worker_drain"
                raise RuntimeError("PKM Home/service data workers did not fully stop before reset purge")
            self._set_full_reset_progress_v2164(50, "백그라운드 작업 확인 중", "Plex 요청과 이미지 작업이 모두 끝났는지 확인합니다.")

            # v2067: a full reset is also a UI/background ownership boundary.
            # Retire every shared busy token before profile files disappear so a
            # stale library/section operation cannot repaint a spinner afterward.
            try:
                from resources.lib import pkm_global_busy
                pkm_global_busy.cancel_all(reason="full_reset_v2150")
            except Exception:
                pass
            try:
                from resources.lib import pkm_artwork_scheduler
                if hasattr(pkm_artwork_scheduler, "request_full_reset_stop_v2150"):
                    pkm_artwork_scheduler.request_full_reset_stop_v2150()
            except Exception:
                pass
            try:
                from resources.lib import pkm_plex_client
                if hasattr(pkm_plex_client, "request_full_reset_stop_v2150"):
                    pkm_plex_client.request_full_reset_stop_v2150()
            except Exception:
                pass

            # Wait while any real sync / Plex HTTP / artwork owner is still in
            # flight.  No new work can enter after the hard reset barrier.
            # not a fixed UI delay.  Normal LAN sync exits in a few checks; the
            # upper bound covers one in-flight 12 s partial metadata request.
            sync_lock_v2149 = os.path.join(base, "sync.lock") if base else ""
            waited_ms_v2149 = 0
            sync_active_v2149 = False
            plex_inflight_v2150 = 0
            artwork_active_v2150 = 0
            artwork_waiting_v2150 = 0
            while waited_ms_v2149 < 22000:
                sync_active_v2149 = bool(sync_lock_v2149 and os.path.exists(sync_lock_v2149))
                try:
                    from resources.lib import pkm_plex_client
                    plex_inflight_v2150 = int(pkm_plex_client.full_reset_inflight_count_v2150()) if hasattr(pkm_plex_client, "full_reset_inflight_count_v2150") else 0
                except Exception:
                    plex_inflight_v2150 = 0
                try:
                    from resources.lib import pkm_artwork_scheduler
                    art_state_v2150 = pkm_artwork_scheduler.stats_snapshot()
                    artwork_active_v2150 = int(art_state_v2150.get("active", 0) or 0)
                    artwork_waiting_v2150 = int(art_state_v2150.get("waiting", 0) or 0)
                    artwork_inflight_v2150 = int(art_state_v2150.get("inflight", 0) or 0)
                except Exception:
                    artwork_active_v2150 = 0
                    artwork_waiting_v2150 = 0
                    artwork_inflight_v2150 = 0
                if not sync_active_v2149 and plex_inflight_v2150 <= 0 and artwork_active_v2150 <= 0 and artwork_waiting_v2150 <= 0 and artwork_inflight_v2150 <= 0:
                    break
                xbmc.sleep(50)
                waited_ms_v2149 += 50
                if waited_ms_v2149 % 500 == 0:
                    self._set_full_reset_progress_v2164(50 + min(20, int(waited_ms_v2149 * 20 / 22000)), "백그라운드 작업 확인 중", "남아 있는 Plex/이미지 작업을 기다립니다.")
            _log("PKM_FULL_RESET_BACKGROUND_DRAIN_V2150 waited_ms=%d sync_lock=%d plex_inflight=%d artwork_active=%d artwork_waiting=%d artwork_inflight=%d credentials_cleared=0" % (
                waited_ms_v2149, 1 if sync_active_v2149 else 0, plex_inflight_v2150,
                artwork_active_v2150, artwork_waiting_v2150, artwork_inflight_v2150
            ), xbmc.LOGINFO if (not sync_active_v2149 and plex_inflight_v2150 <= 0 and artwork_active_v2150 <= 0 and artwork_waiting_v2150 <= 0 and artwork_inflight_v2150 <= 0) else xbmc.LOGWARNING)
            if sync_active_v2149 or plex_inflight_v2150 > 0 or artwork_active_v2150 > 0 or artwork_waiting_v2150 > 0 or artwork_inflight_v2150 > 0:
                failure_phase_v2165 = "background_drain"
                raise RuntimeError("PKM background work did not fully stop before reset purge")

            self._set_full_reset_progress_v2164(72, "설정 초기화 중", "Plex 서버 정보와 라이브러리 설정을 지웁니다.")

            # Clear every user-facing addon setting in all live Addon wrappers
            # only AFTER existing sync owners have retired.
            setting_ids = (
                "plex_url", "plex_token", "plex_account_name", "plex_url_history",
                "chunk_size", "sync_on_open", "auto_sync_on_start",
                "auto_sync_interval_minutes", "auto_sync_show_progress",
                "max_sync_items", "startup_prewarm",
                "art_mode", "spinner_size", "cine21_ratings_db_path",
                "watcha_build_db_path", "debug_log", "perf_log",
            )
            for target in _live_plex_addon_targets_v1922():
                for key in setting_ids:
                    try:
                        target.setSetting(key, "")
                    except Exception:
                        pass
            _publish_live_plex_settings_v1922(server="", token="", account="", reason="full_reset_v1997")

            # Reset in-memory authoritative state before removing persisted files.
            core = _core()
            if core:
                try:
                    if hasattr(core, "set_initial_sync_done"):
                        core.set_initial_sync_done(False)
                    if hasattr(core, "set_initial_setup_completed"):
                        core.set_initial_setup_completed(False)
                    if hasattr(core, "set_last_auto_sync_at"):
                        core.set_last_auto_sync_at(0)
                except Exception:
                    pass

            self._set_full_reset_progress_v2164(82, "데이터 삭제 중", "DB와 캐시 및 저장 데이터를 삭제합니다.")
            deletion_errors_v2149 = []
            if base and os.path.isdir(base):
                # The addon profile is the single PKM persistence/cache root:
                # DB, cast_cache, wall poster viewport cache, episode thumb cache,
                # playstate snapshots and settings are all removed recursively.
                # A transient Windows sharing violation is retried, and final
                # success is decided from REAL survivors rather than one failed
                # os.remove() attempt.
                for root, dirs, files in os.walk(base, topdown=False):
                    for name in files:
                        path = os.path.join(root, name)
                        removed_v2149 = False
                        for _attempt_v2149 in range(12):
                            try:
                                if os.path.exists(path):
                                    try:
                                        os.chmod(path, 0o666)
                                    except Exception:
                                        pass
                                    os.remove(path)
                                removed_v2149 = True
                                break
                            except Exception as exc_v2149:
                                if _attempt_v2149 < 11:
                                    xbmc.sleep(80)
                                else:
                                    deletion_errors_v2149.append((path, str(exc_v2149)))
                        if not removed_v2149 and not os.path.exists(path):
                            removed_v2149 = True
                    for name in dirs:
                        path = os.path.join(root, name)
                        try:
                            os.rmdir(path)
                        except Exception:
                            pass

            # Remove now-empty profile directories including the plugin profile
            # root itself.  Full reset leaves no DB, WAL/SHM, JSON sidecar, cache,
            # lock, temp file, or empty subdirectory behind.
            try:
                if base and os.path.isdir(base):
                    for root_v2150, dirs_v2150, _files_v2150 in os.walk(base, topdown=False):
                        for name_v2150 in dirs_v2150:
                            path_v2150 = os.path.join(root_v2150, name_v2150)
                            try:
                                if os.path.isdir(path_v2150):
                                    os.rmdir(path_v2150)
                            except Exception:
                                pass
                    for _dir_try_v2150 in range(6):
                        try:
                            if os.path.isdir(base):
                                os.rmdir(base)
                            break
                        except Exception:
                            if _dir_try_v2150 < 5:
                                xbmc.sleep(80)
            except Exception as exc_v2150:
                deletion_errors_v2149.append((base or "", str(exc_v2150)))

            self._set_full_reset_progress_v2164(94, "초기화 확인 중", "삭제되지 않은 데이터가 없는지 최종 확인합니다.")
            survivors_v2149 = []
            try:
                if base and os.path.isdir(base):
                    for root_v2149, dirs_v2149, files_v2149 in os.walk(base):
                        for name_v2149 in files_v2149:
                            survivors_v2149.append("FILE:" + os.path.relpath(os.path.join(root_v2149, name_v2149), base))
                        for name_v2149 in dirs_v2149:
                            survivors_v2149.append("DIR:" + os.path.relpath(os.path.join(root_v2149, name_v2149), base))
                    if not survivors_v2149:
                        survivors_v2149.append("DIR:.")
            except Exception as exc_v2149:
                deletion_errors_v2149.append((base or "", str(exc_v2149)))

            ok = not bool(survivors_v2149)
            if not ok:
                failure_phase_v2165 = "profile_purge"
            reset_success_v2150 = bool(ok)
            _log("PKM_FULL_RESET_PROFILE_PURGE_V2150 base=%s survivors=%s transient_delete_errors=%d profile_dir_exists=%d final_ok=%d" % (
                base or "", ",".join(survivors_v2149) if survivors_v2149 else "-",
                len(deletion_errors_v2149), 1 if (base and os.path.isdir(base)) else 0, 1 if ok else 0
            ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            if deletion_errors_v2149:
                _log("PKM_FULL_RESET_DELETE_RETRY_V2149 errors=%s" % " | ".join(
                    "%s:%s" % (os.path.basename(path_v2149), err_v2149)
                    for path_v2149, err_v2149 in deletion_errors_v2149[:8]
                ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            # v2150: Do not recreate sidebar_order.json or signal a Home rebuild
            # after a successful purge.  Either action could recreate profile DB/
            # cache state immediately after deletion.  The hard reset barrier stays
            # latched until Kodi exits; the next process starts clean.
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.FullResetCompletedV2150", "1" if ok else "")
            win.setProperty("PlexKM.Home.ConnectionResetV1970", "1")
            win.setProperty("PlexKM.Home.ConnectionResetAtV1970", str(int(time.time() * 1000)))
            win.clearProperty("PlexKM.Home.PostResetLogoPendingV2008")

            # v2163: do not try to repaint/purge the live Home after persistent
            # state has been deleted. Kodi keeps WindowXML/ListItems and skin
            # textures alive in-process, so a live first-run handoff is not a
            # reliable reset boundary. Keep the current settings modal on top
            # and terminate Kodi after the persistent purge. The next launch
            # creates a fresh Home object from the now-empty profile.
            if ok:
                _log("PKM_FULL_RESET_LIVE_HOME_PURGE_SKIPPED_V2163 token=%s home_live=%d reason=kodi_exit_process_boundary" % (
                    reset_token_v2151, 1 if home_live_v2151 else 0
                ), xbmc.LOGINFO)
                self._set_full_reset_progress_v2164(100, "초기화 완료", "잠시 후 Kodi가 다시 시작됩니다.")
        except Exception:
            ok = False
            if failure_phase_v2165 in ("worker_drain", "background_drain"):
                fail_detail_v2165 = "남은 PlexKM 작업을 종료하지 못했습니다. Kodi를 종료합니다."
            elif failure_phase_v2165 == "profile_purge":
                fail_detail_v2165 = "삭제되지 않은 PlexKM 데이터가 남았습니다. Kodi를 종료합니다."
            else:
                fail_detail_v2165 = "초기화 처리 중 오류가 발생했습니다. Kodi를 종료합니다."
            self._set_full_reset_progress_v2164(100, "초기화 실패", fail_detail_v2165)
            _log("PKM_FULL_RESET_FAILED_V2165 phase=%s err=%s" % (failure_phase_v2165 or "unknown", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

        try:
            # v2150: once the user has explicitly confirmed a destructive full
            # reset, fail closed.  Whether purge succeeds or a locked survivor is
            # detected, NO PKM background work is allowed to resume in this Kodi
            # process.  This prevents a partial/failed reset from regenerating the
            # DB or cache.  Kodi restart creates a fresh process and clears these
            # transient Window properties.
            _log("PKM_FULL_RESET_BARRIER_LATCHED_V2150 ok=%d until=kodi_restart background_resume=0" % (1 if ok and reset_success_v2150 else 0), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        except Exception:
            pass

        # v2163: full reset no longer returns to the already-live Home.
        # Even on a purge failure the hard reset barrier is latched, so keeping
        # this Kodi process alive is the wrong recovery path. On success quit
        # immediately; on failure show one warning, then quit as well.
        if not ok:
            if failure_phase_v2165 in ("worker_drain", "background_drain"):
                failure_message_v2165 = (
                    "일부 PlexKM 작업이 종료되지 않았습니다. Kodi를 종료합니다.\n"
                    "다시 실행한 뒤 초기화를 다시 시도해주세요."
                )
            elif failure_phase_v2165 == "profile_purge":
                failure_message_v2165 = (
                    "일부 PlexKM 데이터를 삭제하지 못했습니다. Kodi를 종료합니다.\n"
                    "다시 실행한 뒤 초기화를 다시 시도해주세요."
                )
            else:
                failure_message_v2165 = (
                    "초기화 처리 중 오류가 발생했습니다. Kodi를 종료합니다.\n"
                    "다시 실행한 뒤 초기화를 다시 시도해주세요."
                )
            open_pkm_message_dialog(
                "초기화 확인",
                failure_message_v2165,
                ok_label="확인",
            )

        self.result_action = "restart_exit"
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.FullResetExitIssuedV2163", "1")
        except Exception:
            pass
        _log("PKM_FULL_RESET_KODI_EXIT_V2163 ok=%d profile_purge_ok=%d settings_close=0 home_reopen=0 live_home_handoff=0 action=Quit" % (
            1 if ok else 0, 1 if reset_success_v2150 else 0
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        try:
            request_kodi_exit_v2171(
                reason="full_reset_complete_v2171" if ok else "full_reset_failure_exit_v2171",
                title="초기화 완료" if ok else "Kodi 종료",
                detail="다시 시작되면 처음 설정부터 이어집니다." if ok else "초기화 처리가 종료되었습니다.",
            )
        except Exception:
            _log("PKM_FULL_RESET_KODI_EXIT_FAILED_V2171 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return

    def _show_external_rating_menu(self, push=True):
        self._render("평점 관리", [
            "평점 서비스 상태",
            "씨네21 평점",
            "왓챠피디아 평점",
        ], "external_rating_menu", push=push)

    def _show_cine21_menu(self, push=True):
        self._render("씨네21 평점", [
            "평점 현황",
            "최근 추가 영화 확인",
            "매칭 테스트",
            "자동 갱신 안내",
        ], "cine21_menu", push=push)

    def _show_watcha_menu(self, push=True):
        self._render("왓챠피디아 평점", [
            "평점 현황",
            "최근 추가 영화 확인",
            "매칭 테스트",
            "자동 갱신 안내",
        ], "watcha_menu", push=push)

    def _show_ratings_service_status_v2374(self):
        try:
            from resources.lib import pkm_ratings_service_bridge
            snap = pkm_ratings_service_bridge.status_snapshot()
            remote = snap.get("remote") or {}
            local = snap.get("local") or {}
            service = snap.get("service") or {}
            dbs = remote.get("databases") or {}
            applied = local.get("applied") or {}

            cine = dbs.get("cine21") or {}
            watcha = dbs.get("watcha") or {}
            service_installed = bool(service.get("installed"))
            service_version = service.get("version") or "-"

            lines = [
                "PKM Ratings Service",
                "",
                "서비스 설치: %s" % (("설치됨 (%s)" % service_version) if service_installed else "설치되지 않음"),
                "씨네21: %s" % ("사용 가능" if cine.get("path") else "대기"),
                "씨네21 적용: %s" % ("완료" if applied.get("cine21") else "대기"),
                "왓챠피디아: %s" % ("사용 가능" if watcha.get("path") else "아직 배포되지 않음"),
                "왓챠피디아 적용: %s" % ("완료" if applied.get("watcha") else "대기"),
                "",
                "DB 경로는 자동 관리됩니다.",
                "사용자가 파일을 선택할 필요가 없습니다.",
            ]
            open_pkm_message_dialog("평점 서비스 상태", "\n".join(lines), ok_label="닫기")
        except Exception:
            open_pkm_message_dialog("평점 서비스 상태", "상태를 읽지 못했습니다.\nKodi 로그를 확인하세요.", ok_label="닫기")

    def _r244_try_lan_switch(self, core):
        """R244: the typed (DDNS) address cannot be reached from inside the LAN.

        Before any "connection failed" UI, find the Plex server on the LAN and
        switch to its internal address (the DDNS stays the main address and is
        used outside the home).  Typing a LAN address needs none of this.
        Returns the library rows when the switch worked, else None.
        """
        public = (ADDON.getSetting("plex_url") or "").strip().rstrip("/")
        if not public or not pkm_plex_client or not hasattr(pkm_plex_client, "discover_lan_plex_servers_r243"):
            return None
        from urllib.parse import urlparse as _urlparse_r244
        import ipaddress as _ipaddress_r244
        parsed = _urlparse_r244(public)
        try:
            if _ipaddress_r244.ip_address(parsed.hostname or "").is_private:
                return None
        except ValueError:
            pass
        if ((ADDON.getSetting("pkm_lan_route_public_r50") or "").rstrip("/") == public
                and (ADDON.getSetting("pkm_lan_route_private_r50") or "").strip()):
            return None
        env = _settings_plex_client_env()
        try:
            pkm_plex_client.probe_server_identity_explicit(public, timeout=1.5, env=env)
            return None
        except Exception:
            pass
        cands = pkm_plex_client.discover_lan_plex_servers_r243(preferred_port=parsed.port or 32400, env=env)
        _log("PKM_R244_LAN_DISCOVERY found=%d" % len(cands), xbmc.LOGINFO)
        for cand in cands[:3]:
            lan_url = cand["url"]
            if lan_url.rstrip("/") == public:
                continue
            label = cand.get("name") or "Plex 서버"
            if not open_pkm_confirm_dialog(
                    "내부 주소로 전환합니다",
                    "같은 네트워크에서 %s (%s)를 찾았습니다.\n"
                    "같은 네트워크에서는 내부 주소로 연결하고, 그 외에는 입력하신 주소를 그대로 사용합니다." % (label, lan_url),
                    yes_label="전환하기", no_label="건너뛰기", default_focus="yes"):
                continue
            ADDON.setSetting("pkm_lan_route_public_r50", public)
            ADDON.setSetting("pkm_lan_route_private_r50", lan_url)
            try:
                _win_r251 = xbmcgui.Window(10000)
                _win_r251.setProperty("PlexKM.Runtime.LanRoutePublicR244", public)
                _win_r251.setProperty("PlexKM.Runtime.LanRoutePrivateR244", lan_url)
            except Exception:
                pass
            try:
                pkm_plex_client._R50_ROUTE_CACHE_R115.clear()
            except Exception:
                pass
            try:
                rows = core._library_selection_rows(live_required=True)
            except Exception:
                rows = (None, [], [])
            if rows and rows[0]:
                _log("PKM_R244_LAN_ROUTE_SAVED sections=%d" % len(rows[0]), xbmc.LOGINFO)
                try:
                    if pkm_notify and hasattr(pkm_notify, "pkm_notice_set"):
                        pkm_notify.pkm_notice_set("내부 주소로 전환했습니다", "같은 네트워크에서는 내부 주소로",
                                                  "그 외에는 기존 주소로", sticky=False, force_replace=True)
                except Exception:
                    pass
                return rows
            ADDON.setSetting("pkm_lan_route_public_r50", "")
            ADDON.setSetting("pkm_lan_route_private_r50", "")
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Runtime.LanRoutePublicR244")
                xbmcgui.Window(10000).clearProperty("PlexKM.Runtime.LanRoutePrivateR244")
            except Exception:
                pass
            try:
                pkm_plex_client._R50_ROUTE_CACHE_R115.clear()
            except Exception:
                pass
            _log("PKM_R244_LAN_ROUTE_ROLLBACK sections_unavailable", xbmc.LOGWARNING)
        return None

    def _show_library_selection(self, push=True, auth_initial=False, focus_pos=None):
        core = _core()
        # v1688: the authenticated first-run chooser is gated by a live
        # /library/sections response using the same PMS request path as the
        # former manual token flow. Cached rows cannot open this dialog.
        _log("PKM_R48_LIBRARY_SELECTION_ENTER auth_initial=%d" % int(bool(auth_initial)), xbmc.LOGINFO)
        if auth_initial:
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.SetupDotR255", "3")
            except Exception:
                pass
        lan_rows_r244 = None
        if auth_initial:
            try:
                lan_rows_r244 = self._r244_try_lan_switch(core)
            except Exception:
                _log("PKM_R244_LAN_SWITCH_ERROR %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        if lan_rows_r244:
            all_sections, labels, preselect = lan_rows_r244
        else:
            all_sections, labels, preselect = core._library_selection_rows(live_required=bool(auth_initial))
        _log("PKM_R48_LIBRARY_SELECTION_RESULT sections=%d" % len(all_sections or []), xbmc.LOGINFO if all_sections else xbmc.LOGWARNING)
        # R47: Authentication can succeed while the selected Plex address is
        # unreachable. Do not silently strand the user on the token row.
        # Allow a deliberate retry without changing the saved credentials.
        if auth_initial and not all_sections:
            try:
                # R113: PKM card instead of Kodi's stock yes/no.
                retry_r47 = open_pkm_confirm_dialog(
                    "Plex 라이브러리 연결 실패",
                    "사용자 인증은 완료됐지만 Plex 서버에서 라이브러리 목록을 받지 못했습니다.\n"
                    "지금 다시 연결하시겠습니까?",
                    yes_label="다시 시도", no_label="주소 확인", default_focus="yes")
            except Exception:
                retry_r47 = False
            _log("PKM_R47_LIBRARY_SECTIONS_RETRY_PROMPT retry=%d" % int(bool(retry_r47)), xbmc.LOGWARNING)
            if retry_r47:
                all_sections, labels, preselect = core._library_selection_rows(live_required=True)
                _log("PKM_R47_LIBRARY_SECTIONS_RETRY_RESULT sections=%d" % len(all_sections or []), xbmc.LOGINFO if all_sections else xbmc.LOGWARNING)
                if not all_sections:
                    try:
                        open_pkm_confirm_dialog("Plex 연결 실패", "라이브러리 목록을 가져오지 못했습니다.\nPlex 서버 주소와 접속 상태를 확인한 뒤 다시 시도하세요.", yes_label="확인", no_label="취소")
                    except Exception:
                        pass
        # R49: DDNS hairpin/NAT-loopback failure recovery.  Allow a verified
        # LAN endpoint without discarding the authenticated Plex account/token.
        # Never silently switch to an unverified server or hardcode a LAN IP.
        if auth_initial and not all_sections:
            try:
                use_lan = open_pkm_confirm_dialog(
                    "DDNS 내부 접속 확인",
                    "외부 DDNS 주소로 라이브러리를 가져오지 못했습니다.\n"
                    "같은 Wi-Fi/LAN의 Plex 내부 주소로 연결해 보시겠습니까?",
                    yes_label="내부 주소 입력", no_label="기존 주소 유지", default_focus="yes")
            except Exception:
                use_lan = False
            if use_lan:
                try:
                    lan_raw = xbmcgui.Dialog().input(
                        "Plex 내부 주소 (IP:포트)", type=xbmcgui.INPUT_ALPHANUM) or ""
                    lan_url = _normalize_plex_server_url_v1313(lan_raw)
                    if lan_url and _validate_saved_plex_endpoint_v1730(lan_url, notify=True):
                        if _probe_candidate_plex_url_v1922(lan_url):
                            previous_url = (ADDON.getSetting("plex_url") or "").strip()
                            ADDON.setSetting("plex_url", lan_url)
                            _publish_live_plex_settings_v1922(
                                server=lan_url, reason="r49_verified_lan_fallback")
                            try:
                                all_sections, labels, preselect = core._library_selection_rows(live_required=True)
                            except Exception:
                                all_sections, labels, preselect = None, [], []
                            if all_sections:
                                # R50: preserve the public DDNS as the authoritative URL.
                                # LAN is an optional, validated same-subnet transport only.
                                ADDON.setSetting("pkm_lan_route_public_r50", previous_url)
                                ADDON.setSetting("pkm_lan_route_private_r50", lan_url)
                                ADDON.setSetting("plex_url", previous_url)
                                _publish_live_plex_settings_v1922(server=previous_url, reason="r50_preserve_ddns")
                                _log("PKM_R50_DDNS_PRESERVED_LAN_ROUTE sections=%d" % len(all_sections), xbmc.LOGINFO)
                            else:
                                ADDON.setSetting("plex_url", previous_url)
                                _publish_live_plex_settings_v1922(
                                    server=previous_url, reason="r49_lan_fallback_rollback")
                                _log("PKM_R49_DDNS_LAN_FALLBACK_ROLLBACK sections_unavailable", xbmc.LOGWARNING)
                        else:
                            _log("PKM_R49_DDNS_LAN_FALLBACK_REJECT identity_failed", xbmc.LOGWARNING)
                except Exception:
                    _log("PKM_R49_DDNS_LAN_FALLBACK_ERROR %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        if not all_sections:
            if auth_initial:
                # The live request has finished.  Never leave the old URL-save
                # "Plex 연결 확인 중" notice sticky forever after auth failure.
                try:
                    if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear_if_title"):
                        pkm_notify.pkm_notice_clear_if_title("Plex 연결 확인 중", force=True)
                except Exception:
                    pass
                _clear_server_switch_pending_home_ui_v1310(reason="token_auth_library_rows_failed_v1726")
                self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_NOT_OPENED_V1726 parent_focus=1", xbmc.LOGWARNING)
            return False
        # v1687: the legacy manual-token bootstrap preselected the first three
        # libraries.  plex.tv/link authentication has a different contract:
        # immediately show the chooser and let the user explicitly choose the
        # initial libraries.  Existing settings-menu visits still preserve the
        # current selection as before.
        self._library_select_auth_initial_v1687 = bool(auth_initial)
        if auth_initial:
            preselect = []
            # A successful live sections response completes the pending
            # URL+token connection check. Clear the sticky status before the
            # chooser is rendered, then keep the chooser's native list focused.
            _clear_plex_connection_state(reason="token_auth_live_sections_v1726")
            _clear_server_switch_pending_home_ui_v1310(reason="token_auth_live_sections_v1726")
            _set_server_switch_pending_v1310(False, reason="token_auth_live_sections_v1726")
            _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_EMPTY_V1726 sections=%d" % len(all_sections), xbmc.LOGINFO)
        self._render("라이브러리", labels, "library_select", multiselect=True, preselect=preselect, payload=all_sections, push=push, focus_pos=focus_pos)
        if auth_initial:
            try:
                notice_token_v2045 = xbmcgui.Window(10000).getProperty("PlexKM.Auth.LibraryChooserNoticeTokenV2045") or ""
                if notice_token_v2045 and pkm_notify:
                    pkm_notify.pkm_notice_clear(expected_token=notice_token_v2045, force=True)
                    xbmcgui.Window(10000).clearProperty("PlexKM.Auth.LibraryChooserNoticeTokenV2045")
                    _log("PKM_LIBRARY_CHOOSER_NOTICE_CLEAR_V2045 token=%s" % notice_token_v2045, xbmc.LOGINFO)
            except Exception:
                pass
        _log("PKM_LIBRARY_SELECTION_RENDERED_V1748 auth_initial=%s focus_pos=%s actual=%s" % (("1" if auth_initial else "0"), str(focus_pos if focus_pos is not None else "default"), self._current_list_position_v1691()), xbmc.LOGINFO)
        return True

    def _show_addon_root(self, push=True):
        # Compatibility entry retained for old stack states. Open the Plex
        # server page directly; the intermediate one-row settings page is gone.
        self._show_plex_connection(push=push)

    def _return_to_plex_connection_v1700(self):
        while self._stack:
            state = self._stack.pop()
            if state and state[0] == "plex_connection":
                break
        self._show_plex_connection(push=False, focus_pos=2)

    def _save_plex_db_path_v1700(self, value):
        value = _plex_db_path_clean_v1700(value)
        if not _validate_plex_db_path_v1700(value, notify=True):
            return False
        ADDON.setSetting("plex_db_path", value)
        _notify("Plex Server DB 경로를 저장했습니다", ms=2400)
        _log("PKM_PLEX_DB_PATH_SAVED_V1700 path=%s" % value, xbmc.LOGINFO)
        self._return_to_plex_connection_v1700()
        return True

    def _show_plex_db_roots_v1700(self, roots, page, title, push=True):
        roots = list(roots or [])
        if not roots:
            _notify("사용 가능한 경로가 없습니다", icon=xbmcgui.NOTIFICATION_WARNING)
            return
        items = ["%s    %s" % (label, short_setting_value(path, 54)) for label, path in roots]
        payload = [{"kind": "root", "name": label, "path": path} for label, path in roots]
        self._render(title, items, page, push=push, payload=payload)

    def _show_plex_db_browser_v1700(self, path, root_path=None, push=True, focus_pos=None):
        path = _plex_db_path_clean_v1700(path)
        root_path = _plex_db_path_clean_v1700(root_path or path)
        try:
            entries = _plex_db_list_directory_v1700(path)
        except Exception:
            _notify("폴더를 열 수 없습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4000)
            _log("PKM_PLEX_DB_BROWSER_LIST_FAIL_V1700 path=%s err=%s" % (path, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return
        parent = _plex_db_parent_v1700(path, root_path)
        rows = []
        payload = []
        if parent:
            rows.append("상위 폴더")
            payload.append({"kind": "parent", "path": parent})
        for entry in entries:
            if entry["kind"] == "dir":
                rows.append("폴더    %s" % entry["name"])
            else:
                rows.append("DB 파일    %s" % entry["name"])
            payload.append(entry)
        if not rows:
            _notify("하위 폴더나 DB 파일이 없습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3600)
            return
        self._plex_db_browser_root_v1700 = root_path
        self._plex_db_browser_path_v1700 = path
        self._render("Plex Server DB 선택", rows, "plex_db_browser_v1700", push=push, focus_pos=focus_pos, payload={"entries": payload, "root": root_path, "path": path})
        self.setProperty("PlexKM.Dialog.Hint", "%s / 선택 / 홈 / 뒤로" % short_setting_value(path, 50))

    def _show_rating_db_browser_v2372(self, path, root_path=None, push=True, focus_pos=None):
        path = _plex_db_path_clean_v1700(path)
        root_path = _plex_db_path_clean_v1700(root_path or path)
        expected = self._rating_db_expected_v2372
        started = time.monotonic()
        try:
            entries = _rating_db_list_directory_v2372(path, expected)
        except Exception:
            _notify("폴더를 열 수 없습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4000)
            _log("PKM_RATING_DB_BROWSER_LIST_FAIL_V2372 path=%s err=%s" % (path, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return
        elapsed_ms = int((time.monotonic() - started) * 1000)
        parent = _plex_db_parent_v1700(path, root_path)
        rows = []
        payload = []
        if parent:
            rows.append("상위 폴더")
            payload.append({"kind": "parent", "path": parent})
        for entry in entries:
            # v2373: The chooser already establishes file/folder context.
            # Repeating `폴더`/`DB 파일` before every name made it read like a
            # debug list.  Show the actual names only, like a real file browser.
            rows.append(str(entry.get("name") or ""))
            payload.append(entry)
        if not rows:
            # Keep the user in the directory instead of bouncing back.  One
            # disabled informational row makes the empty state obvious.
            rows = ["이 폴더에는 %s 파일이 없습니다" % expected]
            payload = [{"kind": "empty", "path": path}]
            actionable = set()
        else:
            actionable = set(range(len(rows)))
        self._rating_db_browser_root_v2372 = root_path
        self._rating_db_browser_path_v2372 = path
        self._render(expected + " 선택", rows, "rating_db_browser_v2372", push=push, focus_pos=focus_pos,
                     payload={"entries": payload, "root": root_path, "path": path}, actionable=actionable)
        self.setProperty("PlexKM.Dialog.Hint", short_setting_value(path, 64))
        _log("PKM_RATING_DB_FOLDER_RENDERED_V2373 path=%s entries=%d elapsed_ms=%d clean_rows=1" % (path, len(entries), elapsed_ms), xbmc.LOGINFO)

    def _return_to_rating_menu_v2372(self):
        target = self._rating_db_return_page_v2372
        while self._stack:
            state = self._stack.pop()
            if state and state[0] == target:
                break
        if target == "cine21_menu":
            self._show_cine21_menu(push=False)
        elif target == "watcha_menu":
            self._show_watcha_menu(push=False)
        else:
            self._show_external_rating_menu(push=False)

    def _select_rating_db_file_v2372(self, path):
        path = _plex_db_path_clean_v1700(path)
        expected = self._rating_db_expected_v2372
        actual = str(path or "").replace("\\", "/").rsplit("/", 1)[-1].lower()
        if not path or actual != expected.lower():
            open_pkm_message_dialog(
                "평점 DB 가져오기",
                "파일명이 올바르지 않습니다.\n\n선택할 파일: %s" % expected,
                ok_label="닫기",
            )
            return False
        if self._rating_db_setting_id_v2372:
            ADDON.setSetting(self._rating_db_setting_id_v2372, path)
        core = _core()
        try:
            if self._rating_db_return_page_v2372 == "cine21_menu":
                if core and hasattr(core, "cine21_import_ratings_db_from_settings"):
                    _log("PKM_SETTINGS_FLOW_CINE21_IMPORT_BEGIN_V2372 path=%s" % path, xbmc.LOGINFO)
                    core.cine21_import_ratings_db_from_settings({"ratings_db": path, "source": "settings_import"})
                    _log("PKM_SETTINGS_FLOW_CINE21_IMPORT_END_V2372", xbmc.LOGINFO)
            elif self._rating_db_return_page_v2372 == "watcha_menu":
                if core and hasattr(core, "watcha_import_build_db_from_settings"):
                    _log("PKM_SETTINGS_FLOW_WATCHA_IMPORT_BEGIN_V2372 path=%s" % path, xbmc.LOGINFO)
                    core.watcha_import_build_db_from_settings({"build_db": path, "source": "settings_import"})
                    _log("PKM_SETTINGS_FLOW_WATCHA_IMPORT_END_V2372", xbmc.LOGINFO)
                else:
                    open_pkm_message_dialog("왓챠피디아 평점", "가져오기 실행 함수를 찾지 못했습니다.\nKodi 로그를 확인하세요.", ok_label="닫기")
        finally:
            self._return_to_rating_menu_v2372()
        return True

    def _show_spinner_settings(self, push=True, focus_pos=None):
        # v1697: fixed Apple-ring style is shown in the header hint, not as a
        # non-actionable list row.  The list therefore contains only the three
        # selectable sizes, so Up from the first size cannot lose visible focus.
        current = pkm_spinner.get_size() if pkm_spinner else (ADDON.getSetting("spinner_size") or "medium")
        size_rows = (
            ("large", "대", 256),
            ("medium", "중", 128),
            ("small", "소", 64),
        )
        rows = []
        current_row = 1
        for row_index, (size, label, pixels) in enumerate(size_rows):
            rows.append("크기  %s (%dpx)" % (label, pixels))
            if size == current:
                current_row = row_index
        target_row = current_row if focus_pos is None else focus_pos
        self._render(
            "스피너 설정",
            rows,
            "spinner_settings",
            push=push,
            focus_pos=target_row,
            preselect=(current_row,),
            show_checks=(0, 1, 2),
        )
        self.setProperty("PlexKM.Dialog.Hint", "Apple 링 스타일 / 선택 / 홈 / 뒤로")
        _log("PKM_SPINNER_SETTINGS_MENU_V1697 style=apple_ring size=%s focus=%s square_row=%s" % (
            current,
            self._current_list_position_v1691(),
            current_row,
        ), xbmc.LOGINFO)

    def _plex_connection_rows_v1703(self):
        token = (ADDON.getSetting("plex_token") or "").strip()
        account = (ADDON.getSetting("plex_account_name") or "").strip()
        auth_label = "인증됨" + ((" · " + account) if account else "") if token else "미인증"
        server_value = (ADDON.getSetting("plex_url") or "").strip()
        if server_value == "http://127.0.0.1:32400":
            ADDON.setSetting("plex_url", "")
            server_value = ""
        status_r97 = self._r97_effective_status()
        rows_r260 = [
            "서버 주소    %s" % (short_setting_value(server_value, 40) if server_value else "주소 입력"),
            "계정 인증    %s" % auth_label,
            "연결 다시 확인    %s" % status_r97,
        ]
        # R334: library choice and the Plex-only metadata switches live on this page.
        rows_r260.append("라이브러리 선택    " + ("먼저 선택해 주세요" if self._r260_setup_pending()
                                               else "Plex에서 가져올 라이브러리"))
        try:
            from resources.lib import pkm_meta_override_r120 as _ovr334
            _n_i334, _n_a334 = _ovr334.count()
            rows_r260.append("직접 바꾼 정보 유지    %s" % ("켬 · Plex가 갱신해도 그대로" if _ovr334.enabled()
                                                        else "끔 · Plex가 갱신하면 Plex를 따름"))
            rows_r260.append("직접 바꾼 정보 지우기    작품 %d개 · 배우 사진 %d명" % (_n_i334, _n_a334))
        except Exception:
            pass
        return rows_r260

    def _show_plex_connection(self, push=True, focus_pos=None):
        # v1699: Kodi-native navigation only.  Every visible row is actionable.
        self._render("Plex 서버", self._plex_connection_rows_v1703(),
                     "plex_connection", push=push, focus_pos=focus_pos)

    def _refresh_plex_connection_in_place_v1703(self, focus_pos=None):
        """Refresh labels without resetting the parent list/window.

        Plex Home selection is a nested modal dialog.  Rebuilding the parent
        list immediately after it closes can leave Kodi focused on the nested
        dialog's 확인/취소 controls.  Keep the same native list control and update
        only its ListItems, then restore the parent's single-page properties.
        """
        rows = [_display_text_for_kodi(x) for x in self._plex_connection_rows_v1703()]
        try:
            if self._list is not None and int(self._list.size()) != len(rows):
                self._show_plex_connection(push=False, focus_pos=focus_pos if focus_pos is not None else 0)
                self._r97_refresh_aside_sub()
                return
        except Exception:
            pass
        self._items = list(rows)
        self._page = "plex_connection"
        self._multiselect = False
        self._preselect = set()
        self._actionable = None
        self._show_checks = set()
        self.setProperty("PlexKM.Dialog.Title", _display_text_for_kodi("서버"))
        self.setProperty("PlexKM.Dialog.Mode", "single")
        self.setProperty("PlexKM.Dialog.SelectAllR261", "")
        self.setProperty("PlexKM.Dialog.Hint", "")
        for pos, label in enumerate(rows):
            try:
                item = self._list.getListItem(pos)
                self._r97_apply_row_parts(item, label, pos)
                item.setProperty("actionable", "1")
                item.setProperty("showcheck", "0")
                item.setProperty("checked", "0")
            except Exception:
                pass
        target = self._current_list_position_v1691() if focus_pos is None else int(focus_pos)
        target = max(0, min(target, max(0, len(rows) - 1)))
        try:
            self._list.selectItem(target)
            self.setFocusId(self.LIST_ID)
        except Exception:
            pass
        _log("PKM_PLEX_CONNECTION_PARENT_FOCUS_RESTORED_V1703 row=%d" % target, xbmc.LOGINFO)

    def _toggle_focused(self):
        pos = int(self._list.getSelectedPosition()) if self._list else -1
        if pos < 0 or pos >= len(self._items):
            return
        if pos in self._preselect:
            self._preselect.remove(pos)
        else:
            self._preselect.add(pos)
        item = self._list.getListItem(pos)
        item.setProperty("checked", "1" if pos in self._preselect else "0")

    def _selected(self):
        try:
            return int(self._list.getSelectedPosition()) if self._list else -1
        except Exception:
            return -1

    def _set_single_checked_row_in_place_v1697(self, selected_idx):
        """Update one-of-N PKM square selection without rebuilding the list."""
        selected_idx = int(selected_idx)
        self._preselect = set([selected_idx])
        for pos in sorted(self._show_checks or []):
            if pos < 0 or pos >= len(self._items):
                continue
            try:
                item = self._list.getListItem(pos)
                item.setProperty("checked", "1" if pos == selected_idx else "0")
            except Exception:
                pass
        try:
            self.setFocusId(self.LIST_ID)
            self._list.selectItem(selected_idx)
        except Exception:
            pass

    def _reload_current(self):
        focus_pos = self._current_list_position_v1691()
        if self._page == "plex_connection":
            self._show_plex_connection(push=False, focus_pos=focus_pos)
        elif self._page == "addon_root":
            self._show_addon_root(push=False)
        elif self._page == "spinner_settings":
            self._show_spinner_settings(push=False)

    def _handle_single(self, idx):
        if idx < 0:
            return
        if self._page == "root":
            # v1926: Distinct root actions only.  Library selection owns the
            # sync of newly added libraries; startup owns later change checks.
            if idx == 0:
                self._show_plex_connection()
            elif idx == 1:
                self._show_spinner_settings()
            elif idx == 2:
                self._show_library_selection()
            elif idx == 3:
                if not _require_plex_server_settings_v1702("external_rating"):
                    return
                self._show_external_rating_menu()
            elif idx == 4:
                self._run_full_reset_v1997()
        elif self._page == "root_offline":
            if idx == 0:
                self._show_plex_connection()
            elif idx == 1:
                self._show_spinner_settings()
            elif idx == 2:
                self._show_library_selection()
            elif idx == 3:
                if not _require_plex_server_settings_v1702("external_rating_offline"):
                    return
                self._show_external_rating_menu()
            elif idx == 4:
                self._run_full_reset_v1997()
        elif self._page == "library_hint_r97":
            self._show_category_r97(0, focus_list=True)
        elif self._page in ("sources_r108", "storage_r334"):
            self._sources_click_r108(idx)
        elif self._page == "source_detail_r108":
            self._source_detail_click_r108(idx)
        elif self._page == "library_detail_r335":
            self._lib_detail_click_r335(idx)
        elif self._page == "library_add_r335":
            self._lib_add_click_r335(idx)
        elif self._page == "meta_r120":
            self._meta_click_r120(idx)
        elif self._page == "tips_r315":
            self._tips_click_r315(idx)
        elif self._page == "keys_r332":
            self._keys_click_r332(idx)
        elif self._page == "reset_menu_r97":
            if idx == 0:
                removed_r332 = self._r97_clear_screen_cache()
                _notify("화면 캐시 %d개 항목을 비웠습니다" % removed_r332, ms=3000)
            elif idx == 1:
                self._r332_reset_taste_tips()
            elif idx == 2:
                self._r97_reset_plex_connection_flow()
            elif idx == 3:
                self._r334_reset_storage()
            elif idx == 4:
                self._r332_reset_youtube_subdl_keys()
            elif idx == 5:
                self._run_full_reset_v1997()
        elif self._page == "external_rating_menu":
            if idx == 0:
                self._show_ratings_service_status_v2374()
                self._show_external_rating_menu(push=False)
            elif idx == 1:
                self._show_cine21_menu()
            elif idx == 2:
                self._show_watcha_menu()
        elif self._page == "cine21_menu":
            core = _core()
            if idx == 0:
                if core and hasattr(core, "cine21_show_match_summary_from_settings"):
                    core.cine21_show_match_summary_from_settings({"source": "settings_summary"})
                self._show_cine21_menu(push=False)
            elif idx == 1:
                if core and hasattr(core, "cine21_show_recent_target_summary_from_settings"):
                    core.cine21_show_recent_target_summary_from_settings({"source": "settings_recent_target"})
                self._show_cine21_menu(push=False)
            elif idx == 2:
                _log("PKM_SETTINGS_FLOW_CINE21_RECENT_MATCH_TEST_CLICK", xbmc.LOGINFO)
                if core and hasattr(core, "cine21_show_recent_match_test_from_settings"):
                    core.cine21_show_recent_match_test_from_settings({"source": "settings_recent_match_test"})
                self._show_cine21_menu(push=False)
            elif idx == 3:
                open_pkm_message_dialog(
                    "씨네21 자동 갱신 안내",
                    "GitHub의 Cine21 Master DB를 PlexKM Ratings Service가 자동으로 내려받습니다.\n\n"
                    "Master에 없는 신규 영화는 기존 PlexKM Cine21 실시간 수집 로직으로 보충됩니다.\n\n"
                    "DB 경로를 직접 선택할 필요가 없습니다.",
                    ok_label="닫기",
                )
                self._show_cine21_menu(push=False)
        elif self._page == "watcha_menu":
            core = _core()
            if idx == 0:
                if core and hasattr(core, "watcha_show_match_summary_from_settings"):
                    core.watcha_show_match_summary_from_settings({"source": "settings_summary"})
                self._show_watcha_menu(push=False)
            elif idx == 1:
                if core and hasattr(core, "watcha_show_recent_target_summary_from_settings"):
                    core.watcha_show_recent_target_summary_from_settings({"source": "settings_recent_target"})
                self._show_watcha_menu(push=False)
            elif idx == 2:
                if core and hasattr(core, "watcha_show_recent_match_test_from_settings"):
                    core.watcha_show_recent_match_test_from_settings({"source": "settings_recent_match_test"})
                self._show_watcha_menu(push=False)
            elif idx == 3:
                open_pkm_message_dialog(
                    "왓챠피디아 자동 갱신 안내",
                    "GitHub의 Watcha Master DB를 PlexKM Ratings Service가 자동으로 내려받습니다.\n\n"
                    "사용자 Plex의 rating_key는 사용하지 않고 제목/원제/연도로 다시 매칭합니다.\n\n"
                    "Master에 없는 작품은 평점이 표시되지 않으며, 중앙 Master가 갱신되면 자동 반영됩니다.",
                    ok_label="닫기",
                )
                self._show_watcha_menu(push=False)
        elif self._page == "addon_root":
            if idx == 0:
                self._show_plex_connection()
        elif self._page == "spinner_settings":
            # v1697: all rows are real size choices.  Update the three list-item
            # properties in place so selection does not flash/recreate the page.
            sizes = ("large", "medium", "small")
            if 0 <= idx < len(sizes):
                size = sizes[idx]
                if pkm_spinner:
                    pkm_spinner.set_size(size, reason="pkm_settings_v1697")
                else:
                    ADDON.setSetting("spinner_size", size)
                self._set_single_checked_row_in_place_v1697(idx)
                _log("PKM_SPINNER_SIZE_SELECTED_V1697 size=%s pixels=%s row=%s inplace=1" % (
                    size,
                    {"small": 64, "medium": 128, "large": 256}.get(size, 128),
                    idx,
                ), xbmc.LOGINFO)
        elif self._page == "rating_db_roots_v2372":
            if not isinstance(self._payload, list) or idx < 0 or idx >= len(self._payload):
                return
            entry = self._payload[idx] or {}
            path = str(entry.get("path") or "")
            if path:
                self._show_rating_db_browser_v2372(path, root_path=path, push=True)
        elif self._page == "rating_db_browser_v2372":
            payload = self._payload if isinstance(self._payload, dict) else {}
            entries = payload.get("entries") or []
            if idx < 0 or idx >= len(entries):
                return
            entry = entries[idx] or {}
            kind = str(entry.get("kind") or "")
            path = str(entry.get("path") or "")
            root_path = str(payload.get("root") or self._rating_db_browser_root_v2372 or "")
            if kind == "parent":
                self._back()
            elif kind == "dir":
                self._show_rating_db_browser_v2372(path, root_path=root_path, push=True)
            elif kind == "file":
                self._select_rating_db_file_v2372(path)
        elif self._page == "plex_db_source_v1700":
            if not isinstance(self._payload, list) or idx < 0 or idx >= len(self._payload):
                return
            action_name = str((self._payload[idx] or {}).get("action") or "")
            if action_name == "local":
                self._show_plex_db_roots_v1700(_local_storage_roots_v1700(), "plex_db_local_roots_v1700", "로컬 / 연결 드라이브")
            elif action_name == "kodi_sources":
                sources = _kodi_file_sources_v1700()
                if not sources:
                    _notify("Kodi에 등록된 네트워크 소스가 없습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4000)
                    return
                self._show_plex_db_roots_v1700(sources, "plex_db_kodi_sources_v1700", "Kodi 네트워크 소스")
            elif action_name == "direct":
                self._open_inline_address_v1711(input_kind="plex_db_path")
                return
            elif action_name == "clear":
                if open_pkm_confirm_dialog("Plex Server DB 경로", "저장된 DB 경로를 지우시겠습니까?", yes_label="지우기", no_label="취소"):
                    ADDON.setSetting("plex_db_path", "")
                    self._return_to_plex_connection_v1700()
        elif self._page in ("plex_db_local_roots_v1700", "plex_db_kodi_sources_v1700"):
            if not isinstance(self._payload, list) or idx < 0 or idx >= len(self._payload):
                return
            entry = self._payload[idx] or {}
            path = str(entry.get("path") or "")
            if path:
                self._show_plex_db_browser_v1700(path, root_path=path, push=True)
        elif self._page == "plex_db_browser_v1700":
            payload = self._payload if isinstance(self._payload, dict) else {}
            entries = payload.get("entries") or []
            if idx < 0 or idx >= len(entries):
                return
            entry = entries[idx] or {}
            kind = str(entry.get("kind") or "")
            path = str(entry.get("path") or "")
            root_path = str(payload.get("root") or self._plex_db_browser_root_v1700 or "")
            if kind == "parent":
                # Native page history owns parent navigation.  Do not rebuild the
                # same directory in Python because that would duplicate a stack
                # frame and require Back twice.
                self._back()
            elif kind == "dir":
                self._show_plex_db_browser_v1700(path, root_path=root_path, push=True)
            elif kind == "file":
                self._save_plex_db_path_v1700(path)
        elif self._page == "plex_connection":
            changed_connection = False
            server_changed = False
            token_authenticated_v1680 = False
            # v1925 native list indices: server input, token auth, reset.
            # Recommendation index maintenance is always enabled through the
            # normal Plex API sync and no external Plex DB path is required.
            if idx == 0:
                self._open_inline_address_v1711()
                return
            elif idx == 1:
                if not _validate_saved_plex_endpoint_v1730(ADDON.getSetting("plex_url") or "", notify=True):
                    self._refresh_plex_connection_in_place_v1703(focus_pos=0)
                    _log("PKM_TOKEN_AUTH_BLOCKED_INVALID_ENDPOINT_V1730", xbmc.LOGWARNING)
                    return
                imported = False
                try:
                    from resources.lib import pkm_token_import
                    imported = bool(pkm_token_import.run_token_import())
                except Exception:
                    _log("PKM_TOKEN_IMPORT_RUN_FAILED_V1672\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                if imported:
                    # v1690: URL and token were written through different live
                    # xbmcaddon.Addon wrappers.  Synchronise those wrappers before
                    # the default.py-owned live sections gate reads them.  This is
                    # still the manual-token flow after acquisition; no cache or
                    # connection-state shortcut is introduced.
                    if not _sync_runtime_plex_auth_settings_v1690(pkm_token_import):
                        imported = False
                        _notify("Plex 인증값을 적용하지 못했습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4200)
                    else:
                        token_authenticated_v1680 = True
                        _log("PKM_TOKEN_AUTH_SAVED_MANUAL_EQUIVALENT_V1686", xbmc.LOGINFO)
            elif idx == 3 and self._page == "plex_connection":
                # R260/R334: 라이브러리 선택 (first run keeps the authenticated chooser)
                self._src_scope_r334 = "plex"
                self._show_library_selection(push=True, auth_initial=bool(self._r260_setup_pending()))
                return
            elif idx in (4, 5) and self._page == "plex_connection":
                self._meta_click_r120(idx - 4)
                return
            elif idx == 2 and self._page == "plex_connection":
                # R97D: row 3 is now "연결 다시 확인"; Plex 연결 초기화 lives
                # in the 초기화 category.
                self._r97_connection_test()
                return
            elif idx == 2:
                confirmed = open_pkm_confirm_dialog(
                    "Plex 연결 초기화",
                    "저장된 Plex 서버 주소와 토큰 정보를 삭제하시겠습니까?",
                    yes_label="초기화",
                    no_label="취소",
                    default_focus="yes",
                )
                if confirmed:
                    # v2050: keep the already visible Plex connection page and
                    # update only its three native ListItem labels.  The reset
                    # itself already clears the live server/token values; this
                    # in-place refresh makes that state visible immediately
                    # without closing/reopening the settings modal or rebuilding
                    # its list control.  Selection remains on the reset row.
                    ok_reset_v2050 = _reset_plex_connection_v1922()
                    if ok_reset_v2050:
                        self._refresh_plex_connection_in_place_v1703(focus_pos=2)
                    _log(
                        "PKM_PLEX_CONNECTION_RESET_LABEL_REFRESH_V2050 "
                        "ok=%s focus=reset_row redraw=in_place home_open=0"
                        % (1 if ok_reset_v2050 else 0),
                        xbmc.LOGINFO if ok_reset_v2050 else xbmc.LOGWARNING,
                    )
                # A cancelled confirmation also returns naturally to the same
                # native row; do not rebuild the parent page in either case.
                return
            if token_authenticated_v1680:
                # v1726: the QR dialog was closed on its owning thread and the
                # Plex Home user dialog has completed. Re-anchor the live parent
                # list first, then render the explicit library chooser.
                self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                xbmc.sleep(120)
                opened_v1726 = self._show_library_selection(push=True, auth_initial=True)
                if opened_v1726:
                    _log("PKM_TOKEN_AUTH_OPEN_LIBRARY_SELECTION_V1726 mode=link_user_then_library focus=list", xbmc.LOGINFO)
                else:
                    self._refresh_plex_connection_in_place_v1703(focus_pos=1)
                return
            self._reload_current()
            if changed_connection:
                if server_changed or _server_switch_pending_v1310():
                    _set_server_switch_pending_home_ui_v1310(
                        "Plex 서버 연결 확인 중",
                        "라이브러리 정보를 확인합니다",
                        reason="settings_connection_changed_v1310",
                    )
                _probe_plex_after_connection_setting(reason="settings_plex_url_or_token_saved_v1310", server_changed=server_changed)

    def onFocus(self, controlId):
        audit_event(self, "onFocus", control_id=controlId)
        try:
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.Sync.HandoffProbeV1747") == "1":
                    _log("PKM_SETTINGS_FOCUS_DURING_SYNC_HANDOFF_V1747 page=%s control=%s" % (
                        str(self._page or ""), controlId
                    ), xbmc.LOGINFO)
            except Exception:
                pass
            if not self._inline_address_active_v1711 or self._inline_is_db_path_v1719():
                return
            if controlId == self.INLINE_VALUE_ID:
                self._inline_switch_server_field_v1730("address", repopulate=True)
            elif controlId == self.INLINE_PORT_ID_V1730:
                self._inline_switch_server_field_v1730("port", repopulate=True)
        except Exception:
            _log("PKM_INLINE_SERVER_FIELD_FOCUS_FAILED_V1730 control=%s" % controlId, xbmc.LOGWARNING)

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if getattr(self, "_full_reset_exit_pending_v2163", False):
            _log("PKM_FULL_RESET_UI_INPUT_BLOCK_V2163 kind=click control=%s" % controlId, xbmc.LOGINFO)
            return
        try:
            # v1382: Some key paths can deliver duplicate clicks while the
            # sidebar is recovering from an offline state.  Ignore same-dialog
            # click bursts so PlexKM설정 does not open the first item twice.
            now_ms = int(time.time() * 1000)
            if controlId in (self.LIST_ID, self.OK_ID, self.HOME_ID, self.HOME_SINGLE_ID_V2373):
                if now_ms - int(getattr(self, "_last_click_ms_v1382", 0) or 0) < 260:
                    _log("PKM_SETTINGS_FLOW_CLICK_DEBOUNCE_V1382 control=%s page=%s" % (controlId, self._page), xbmc.LOGINFO)
                    return
                self._last_click_ms_v1382 = now_ms
            if controlId in (getattr(self, "INLINE_VALUE_ID", -1), getattr(self, "INLINE_PORT_ID_V1730", -1)):
                if self._inline_address_active_v1711 and not self._inline_is_db_path_v1719():
                    self._inline_switch_server_field_v1730("port" if controlId == self.INLINE_PORT_ID_V1730 else "address", repopulate=True)
                    try:
                        self.setFocusId(self.INLINE_KEYBOARD_ID)
                    except Exception:
                        pass
                return
            if controlId == getattr(self, "INLINE_CONFIRM_ID_V1731", -1):
                if self._inline_address_active_v1711:
                    self._save_inline_address_v1711()
                return
            if controlId == getattr(self, "INLINE_HISTORY_ID", -1):
                if self._inline_address_active_v1711:
                    self._inline_history_select_v1713()
                return
            if controlId == getattr(self, "INLINE_HISTORY_CLEAR_ID", -1):
                if self._inline_address_active_v1711:
                    self._inline_history_clear_v1713()
                return
            if controlId == getattr(self, "INLINE_KEYBOARD_ID", -1):
                self._handle_inline_address_key_v1711()
                return
            if controlId == self.CATEGORY_ID_R97:
                try:
                    cat_pos_r97 = int(self._cat_list_r97.getSelectedPosition())
                except Exception:
                    cat_pos_r97 = 0
                self._show_category_r97(cat_pos_r97, focus_list=True)
                return
            if controlId == self.LIST_ID:
                if self._inline_address_active_v1711:
                    return
                if self._multiselect:
                    self._toggle_focused()
                else:
                    self._handle_single(self._selected())
            elif controlId == self.OK_ID:
                if self._page == "library_select":
                    core = _core()
                    chosen = sorted(self._preselect)
                    auth_initial = bool(getattr(self, "_library_select_auth_initial_v1687", False))
                    if auth_initial and not chosen:
                        _log("PKM_TOKEN_AUTH_LIBRARY_SELECTION_REQUIRED_V1687", xbmc.LOGINFO)
                        try:
                            _notify("라이브러리를 1개 이상 선택하세요", icon=xbmcgui.NOTIFICATION_WARNING, ms=3000)
                        except Exception:
                            pass
                        return
                    restore_pos_v1748 = self._current_list_position_v1691()
                    _log("PKM_LIBRARY_SELECTION_FOCUS_CAPTURE_V1748 pos=%s chosen=%s" % (restore_pos_v1748, ",".join(str(x) for x in chosen)), xbmc.LOGINFO)
                    apply_result = core._apply_library_selection(self._payload or [], chosen, force=False, auth_initial=auth_initial)
                    if apply_result:
                        self._library_select_auth_initial_v1687 = False
                        if apply_result == "restart_exit":
                            # v2090: library-add completion owns an exit-only modal.
                            # Do not close settings toward Home and do not request a
                            # live Home refresh while Kodi is terminating.
                            self.result_action = "restart_exit"
                            _log("PKM_LIBRARY_ADD_RESTART_EXIT_V2090 result=restart_exit home_reopen=0", xbmc.LOGINFO)
                            return
                        if auth_initial or apply_result == "open_home":
                            # Completed library sync closes the settings stack and
                            # returns directly to the existing Home window.
                            try:
                                xbmcgui.Window(10000).setProperty("PlexKM.Home.SettingsXmlFocusV2023", "1")
                            except Exception:
                                pass
                            self.result_action = "open_home"
                            if auth_initial:
                                _log("TOKEN_AUTH_OPEN_HOME_AFTER_SYNC_V1688", xbmc.LOGINFO)
                            else:
                                _log("PKM_LIBRARY_SYNC_OPEN_HOME result=open_home", xbmc.LOGINFO)
                            self.close()
                            return
                        self._show_library_selection(push=False, auth_initial=False, focus_pos=restore_pos_v1748)
                        _log("PKM_LIBRARY_SELECTION_FOCUS_RESTORE_V1748 requested=%s actual=%s" % (restore_pos_v1748, self._current_list_position_v1691()), xbmc.LOGINFO)
                elif self._multiselect:
                    self._back()
            elif controlId in (310, 311):
                # R261: 전체 선택 / 전체 해제 on the library chooser
                want = controlId == 310
                self._preselect = set(range(len(self._items))) if want else set()
                for pos in range(len(self._items)):
                    try:
                        self._list.getListItem(pos).setProperty("checked", "1" if want else "0")
                    except Exception:
                        pass
                return
            elif controlId in (self.HOME_ID, self.HOME_SINGLE_ID_V2373):
                # R260: Plex is signed in but no library is chosen yet -> continue there instead of
                # leaving an empty Home behind.
                try:
                    if self._r260_setup_pending() and self._page != "library_select":
                        if self._show_library_selection(push=True, auth_initial=True):
                            return
                except Exception:
                    _log("PKM_R260_HOME_TO_LIBRARY_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                # Home remains alive under the modal. XML performs the only
                # focus handoff when this dialog unloads; no Python focus, timer,
                # retry, or animation guard is used.
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Home.SettingsXmlFocusV2023", "1")
                except Exception:
                    pass
                self.result_action = "open_home"
                _log("PKM_SETTINGS_FLOW_HOME_REQUEST page=%s owner=xml_onunload_9000" % self._page, xbmc.LOGINFO)
                self.close()
        except Exception:
            _log("PKM_SETTINGS_FLOW_CLICK_FAILED page=%s\n%s" % (self._page, traceback.format_exc()), xbmc.LOGWARNING)
            self.close()

    def onAction(self, action):
        if getattr(self, "_full_reset_exit_pending_v2163", False):
            try:
                _log("PKM_FULL_RESET_UI_INPUT_BLOCK_V2163 kind=action action=%s" % action.getId(), xbmc.LOGINFO)
            except Exception:
                pass
            return
        # v1699: Up/Down is intentionally not handled in Python. Kodi owns
        # native list movement through the XML list control.  Python handles
        # only Back-family actions.
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        if not self._inline_address_active_v1711:
            ensure_focus(self, aid, (self.LIST_ID, self.CATEGORY_ID_R97), tag="settings")
        if self._inline_address_active_v1711:
            if aid in (9, 10, 92, 216, 247):
                self._close_inline_address_v1711(restore_focus=True)
            elif aid not in (1, 2, 3, 4, 7, 100):
                _log("PKM_INLINE_ADDRESS_PHYSICAL_KEY_BLOCKED_V1712 action=%s" % aid, xbmc.LOGINFO)
            # While the inline panel is active, every non-navigation action is
            # consumed here so H/P/S and other physical keys cannot open Kodi UI.
            return
        if aid in (9, 10, 92, 216, 247):
            # R97D: Back from a category's first page moves to the category
            # pane; Back from the category pane closes settings.
            try:
                focus_r97 = self.getFocusId()
            except Exception:
                focus_r97 = 0
            if focus_r97 == self.CATEGORY_ID_R97:
                self.close()
                return
            if not self._stack and getattr(self, "_cat_list_r97", None) is not None:
                try:
                    self._cat_list_r97.selectItem(int(getattr(self, "_cat_r97", 0)))
                    self.setFocusId(self.CATEGORY_ID_R97)
                    return
                except Exception:
                    pass
            self._back()
        elif aid in (3, 4) and getattr(self, "_cat_list_r97", None) is not None:
            # Up/Down inside the category pane switches the page live
            # (Kodi already moved the selection; this runs after it).
            try:
                if self.getFocusId() == self.CATEGORY_ID_R97:
                    pos_r97 = int(self._cat_list_r97.getSelectedPosition())
                    if pos_r97 != int(getattr(self, "_cat_r97", 0)):
                        self._show_category_r97(pos_r97, focus_list=False, light=True)
            except Exception:
                pass


def open_pkm_settings_flow_dialog():
    dlg = None
    _t_open_r320 = time.perf_counter()
    try:
        from resources.lib import pkm_mem_r319 as _m320
        _log("SETTINGS_PERF_R320 op=open_begin %s" % _m320.tag(), xbmc.LOGINFO)
    except Exception:
        _m320 = None
    try:
        # R255: setup progress dots (wizard = 1, settings = 2, library selection = 3)
        try:
            _c255 = _core()
            _done255 = bool(_c255.initial_setup_completed()) if hasattr(_c255, "initial_setup_completed") else bool(_c255.initial_sync_done())
            if _done255:
                xbmcgui.Window(10000).clearProperty("PlexKM.SetupDotR255")
            else:
                xbmcgui.Window(10000).setProperty("PlexKM.SetupDotR255", "2")
        except Exception:
            pass
        dlg = PKMSettingsFlowDialog(
            "plexkm_pkm_dialog.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            initial_page="root",
        )
        dlg.doModal()
        return dlg.result_action
    except Exception:
        _log("PKM_SETTINGS_FLOW_OPEN_FAILED fallback_to_root_list\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return None
    finally:
        try:
            _log("SETTINGS_PERF_R320 op=session_end open_ms=%.0f %s" % (
                (time.perf_counter() - _t_open_r320) * 1000.0, _m320.tag() if _m320 else "mem=n/a"), xbmc.LOGINFO)
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.SetupDotR255")
        except Exception:
            pass
        try:
            del dlg
        except Exception:
            pass


def open_pkm_addon_settings_dialog(handle=-1):
    """Compatibility entry for action=addon_settings.

    Keep the v626-safe single-dialog flow instead of opening Kodi's stock
    add-on settings UI or stacked dialogs.
    """
    result = open_pkm_settings_flow_dialog()
    if handle != -1:
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    return result


# ---------------------------------------------------------------------------
# R320: 설정 화면 사용자 조작 구간 시간 로그 (SETTINGS_PERF_R320)
#   창 열기→첫 화면, 카테고리 전환, 페이지 그리기, 클릭 처리, 키 입력 처리,
#   라이브러리 목록/연결 확인 같은 느릴 수 있는 화면. 100ms 이상은 SLOW 표시.
#   (UI 스레드에서 걸린 시간이므로 ms가 곧 화면이 멈춘 시간)
# ---------------------------------------------------------------------------
def _r320_install_settings_perf():
    import functools

    def _mem():
        try:
            from resources.lib import pkm_mem_r319 as _m
            return _m.tag()
        except Exception:
            return "mem=n/a"

    def _desc(name, args):
        try:
            if name == "onClick":
                return "control=%s" % (args[0] if args else "")
            if name == "onAction":
                a = args[0]
                return "action=%s button=%s" % (a.getId(), a.getButtonCode())
            if name == "_show_category_r97":
                return "idx=%s" % (args[0] if args else "")
            if name == "_render":
                return "page=%s rows=%d" % (args[2] if len(args) > 2 else "", len(args[1]) if len(args) > 1 else 0)
        except Exception:
            pass
        return ""

    def _wrap(cls, name, min_log_ms):
        orig = getattr(cls, name, None)
        if orig is None or getattr(orig, "_r320", False):
            return

        @functools.wraps(orig)
        def wrapper(self, *args, **kwargs):
            t0 = time.perf_counter()
            try:
                return orig(self, *args, **kwargs)
            finally:
                ms = (time.perf_counter() - t0) * 1000.0
                if ms >= min_log_ms:
                    try:
                        page = getattr(self, "_page", "")
                        _log("SETTINGS_PERF_R320 op=%s %s page=%s ms=%.1f%s%s" % (
                            name, _desc(name, args), page, ms,
                            " SLOW=1" if ms >= 100.0 else "",
                            (" " + _mem()) if ms >= 100.0 else ""), xbmc.LOGINFO)
                    except Exception:
                        pass
        wrapper._r320 = True
        setattr(cls, name, wrapper)

    cls = PKMSettingsFlowDialog
    # 항상 기록(짧아도): 열기·카테고리·클릭·그리기
    for n in ("onInit", "_show_category_r97", "_render", "onClick"):
        _wrap(cls, n, 0.0)
    # 키 입력은 5ms 이상만(이동마다 찍히면 너무 많음)
    _wrap(cls, "onAction", 5.0)
    # 느릴 수 있는 화면/작업
    for n in ("_show_plex_connection", "_show_library_selection", "_show_sources_r108", "_show_meta_r120",
              "_show_tips_r315", "_show_reset_menu_r97", "_show_about_r97", "_r97_clear_screen_cache",
              "_r97_reset_plex_connection_flow", "_back"):
        _wrap(cls, n, 5.0)


try:
    _r320_install_settings_perf()
except Exception:
    pass
