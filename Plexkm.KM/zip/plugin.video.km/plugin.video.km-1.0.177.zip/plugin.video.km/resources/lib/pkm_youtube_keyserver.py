# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Phone entry for the YouTube Data API key (R79).

While the PKM YouTube settings panel shows "휴대폰으로 입력", a tiny HTTP page
is served on the Shield's LAN address.  The TV shows a QR code for
http://<lan-ip>:<port>/<token>; the phone opens it, pastes the key and taps
저장.  The key is checked with the Data API before it is stored, and the
result is shown on both the phone and the TV.

Only the random token path answers; everything else is 404.  The server
stops when the panel leaves phone mode, when the window closes, or after
IDLE_LIMIT_SEC.
"""

import os
import random
import string
import threading
import time
import traceback

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import parse_qs
except ImportError:  # pragma: no cover - Kodi 18
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import parse_qs

import xbmc

PREFERRED_PORTS = (8738, 8739, 8748, 0)
IDLE_LIMIT_SEC = 15 * 60
KEY_CHARS = set(string.ascii_letters + string.digits + "-_")


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Plex KM] YT KEYSERVER %s" % msg, level)
    except Exception:
        pass


def clean_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    if len(key) < 30 or len(key) > 60 or any(ch not in KEY_CHARS for ch in key):
        return "", "API 키 형식이 아닙니다 (보통 AIza로 시작하는 39자)"
    return key, ""


def mask_key(key):
    key = str(key or "")
    if len(key) <= 12:
        return key
    return key[:6] + "…" + key[-4:]


HEAD = """<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PKM · YouTube API 키</title>
<style>
:root{color-scheme:dark}
body{margin:0;background:#0f0f0f;color:#f1f1f1;font:16px/1.5 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}
main{max-width:520px;margin:0 auto;padding:28px 18px 40px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:20px}
.dot{width:30px;height:21px;border-radius:6px;background:#ff0033;display:inline-flex;align-items:center;justify-content:center}
.dot:after{content:"";border-left:9px solid #fff;border-top:6px solid transparent;border-bottom:6px solid transparent;margin-left:2px}
p{color:#aaa;margin:14px 0}
label{display:block;margin:22px 0 8px;color:#aaa;font-size:14px}
input{box-sizing:border-box;width:100%%;padding:14px;border-radius:12px;border:1px solid #3f3f3f;background:#212121;color:#fff;font:16px ui-monospace,Menlo,monospace}
input:focus{outline:2px solid #3ea6ff;border-color:transparent}
button{margin-top:16px;width:100%%;padding:14px;border:0;border-radius:24px;background:#f1f1f1;color:#0f0f0f;font-weight:700;font-size:16px}
.msg{margin-top:20px;padding:14px;border-radius:12px;background:#212121}
.ok{border-left:4px solid #2ba640}.bad{border-left:4px solid #ff4e45}
ol{color:#aaa;padding-left:20px;font-size:14px}
a{color:#3ea6ff}
h2{font-size:18px;margin:36px 0 6px}h2 small{color:#aaa;font-weight:400;font-size:13px}
.step{display:flex;gap:12px;padding:14px 0;border-top:1px solid #272727}
.step>b{flex:none;width:26px;height:26px;border-radius:13px;background:#272727;display:flex;align-items:center;justify-content:center;font-size:14px}
.step h3{margin:2px 0 8px;font-size:16px}.step p{margin:6px 0 0;font-size:14px}
.go{display:inline-block;padding:8px 14px;border-radius:18px;background:#263850;color:#3ea6ff;text-decoration:none;font-size:14px}
.warn{color:#ffb74d}
.tips{margin-top:18px;padding:4px 16px 8px;border-radius:14px;background:#1e1e1e;border:1px solid #3a3020}.tips h3{color:#ffb74d;font-size:16px;margin:12px 0 4px}.tips p{font-size:14px;margin:10px 0}.tips b{color:#f1f1f1}.foot{font-size:13px}
</style></head><body><main>
"""

PAGE = HEAD + """<div class="brand"><span class="dot"></span>PKM YouTube</div>
<p>YouTube Data API v3 키를 붙여넣고 저장하면 쉴드에 바로 적용됩니다.</p>
%(msg)s
<form method="post" autocomplete="off">
<label for="k">API 키</label>
<input id="k" name="key" placeholder="AIza…" autocapitalize="off" autocorrect="off" spellcheck="false" value="">
<button type="submit">저장</button>
</form>
<h2>API 키 발급 방법 <small>무료 · 약 5분 · 순서대로 따라 하세요</small></h2>
<div class="step"><b>1</b><div><h3>구글 클라우드 콘솔 접속</h3>
<a class="go" href="https://console.cloud.google.com/">콘솔 열기</a>
<p>구글 계정으로 로그인합니다. 처음이면 국가(대한민국)와 약관 동의 후 [동의 및 계속].</p></div></div>
<div class="step"><b>2</b><div><h3>프로젝트 확인</h3>
<p><b>이미 프로젝트가 있으면 그대로 쓰면 됩니다.</b> 휴대폰 화면에는 왼쪽 위 프로젝트 버튼이 없고, <b>시작하기</b> 아래 <b>작업 중인 프로젝트: (이름)</b>이 지금 선택된 프로젝트입니다. (PC는 왼쪽 위 Google Cloud 옆 버튼)</p>
<p>프로젝트가 하나도 없을 때만 아래 버튼 → 이름 PKM → [만들기]. 만든 뒤 작업 중인 프로젝트가 그 이름인지 확인하세요.</p>
<a class="go" href="https://console.cloud.google.com/projectcreate" style="margin-top:10px">새 프로젝트 만들기</a></div></div>
<div class="step"><b>3</b><div><h3>YouTube Data API v3 켜기 <span class="warn">★ 꼭 먼저</span></h3>
<a class="go" href="https://console.cloud.google.com/apis/library/youtube.googleapis.com">YouTube Data API v3 열기</a>
<p>파란 [사용]을 누릅니다. 화면에 <b>상태: 사용 설정됨</b>이 보이면 완료입니다.<br>
이 단계를 건너뛰면 5단계 목록에 YouTube가 나오지 않습니다.</p></div></div>
<div class="step"><b>4</b><div><h3>API 키 만들기</h3>
<a class="go" href="https://console.cloud.google.com/apis/credentials">사용자 인증 정보 열기</a>
<p>위쪽 [+ 사용자 인증 정보 만들기] → <b>[API 키]</b>.<br>
(3단계 화면의 [사용자 인증 정보 만들기] 버튼을 눌렀다면 "어떤 데이터?"에서 <b>공개 데이터</b>를 고르세요.)</p></div></div>
<div class="step"><b>5</b><div><h3>제한 고르고 만들기</h3>
<p><b>API 제한사항 선택</b> → 필터에 youtube 입력 → <b>YouTube Data API v3</b> 체크 → [확인].<br>
아래 <b>애플리케이션 유형(웹사이트·IP·Android·iOS)은 아무것도 고르지 마세요.</b> 고르면 쉴드에서 동작하지 않습니다.<br>
→ [만들기]</p></div></div>
<div class="step"><b>6</b><div><h3>복사해서 이 페이지 위쪽에 붙여넣기</h3>
<p>키 오른쪽 <b>복사 아이콘</b>을 누르세요. 화면에는 키가 일부만 보이지만 39자 전체가 복사됩니다. 맨 위 입력칸에 붙여넣고 [저장] → TV에 "저장했습니다"가 뜨면 끝.</p></div></div>
<div class="tips"><h3>헤매기 쉬운 곳</h3>
<p><b>제한 목록에 YouTube가 없어요</b><br>→ 3단계 [사용]을 아직 안 한 것입니다. 켜고 다시 만들기를 누르세요.</p>
<p><b>"동의 화면 구성"이 나와요</b><br>→ OAuth 쪽으로 잘못 들어간 것입니다. API 키에는 필요 없습니다. 닫고 [API 키]를 고르거나 "공개 데이터"를 선택하세요.</p>
<p><b>"서비스 계정 필요" 파란 안내가 있어요</b><br>→ Gemini·Agent API용 안내라 무시하면 됩니다.</p>
<p><b>"프로덕션에서 사용하기 전에 이 키를 제한" 경고 / 7일마다 만료?</b><br>→ 보안 권고일 뿐입니다. API 키는 만료되지 않습니다. 7일 만료는 OAuth 동의 화면을 "테스트"로 둔 로그인 토큰 이야기라 지금과 상관없습니다. 5단계에서 제한을 걸었다면 끝, 안 걸었다면 [Restrict key]에서 API 제한만 YouTube Data API v3로 걸어 두세요.</p>
</div>
<p class="foot">무료 할당량 하루 10,000 단위로 PKM 사용에는 충분하고 결제 정보 등록은 필요 없습니다. 키는 다른 사람과 공유하지 마세요.</p>
</main></body></html>"""

OAUTH_PAGE = HEAD.replace("YouTube API 키</title>", "YouTube 계정 연결</title>") + """<div class="brand"><span class="dot"></span>PKM YouTube · 계정 연결</div>
<p>내 구독 채널을 PKM에 가져오기 위한 OAuth 클라이언트를 입력합니다. API 키와는 별개이며, 같은 프로젝트에 만들면 됩니다.</p>
%(msg)s
<form method="post" autocomplete="off">
<label for="c">클라이언트 ID</label>
<input id="c" name="client_id" placeholder="….apps.googleusercontent.com" autocapitalize="off" autocorrect="off" spellcheck="false" value="">
<label for="s">클라이언트 보안 비밀번호</label>
<input id="s" name="client_secret" placeholder="GOCSPX-…" autocapitalize="off" autocorrect="off" spellcheck="false" value="">
<button type="submit">저장하고 TV에서 로그인 시작</button>
</form>
<h2>OAuth 클라이언트 만들기 <small>약 5분 · API 키 만든 프로젝트 그대로</small></h2>
<div class="step"><b>1</b><div><h3>YouTube Data API v3 켜져 있는지 확인</h3>
<a class="go" href="https://console.cloud.google.com/apis/library/youtube.googleapis.com">YouTube Data API v3 열기</a>
<p><b>상태: 사용 설정됨</b>이면 그대로 다음으로. (API 키를 만들 때 이미 켰다면 완료)</p></div></div>
<div class="step"><b>2</b><div><h3>동의 화면(브랜딩) 만들기</h3>
<a class="go" href="https://console.cloud.google.com/auth/overview">Google 인증 플랫폼 열기</a>
<p>[시작하기] → 앱 이름 <b>PKM</b>, 사용자 지원 이메일(내 메일) → 대상 <b>외부</b> → 연락처 이메일 → 정책 동의 → [만들기].<br>
이미 만들어져 있으면 건너뛰세요. 로고·도메인 등은 비워 둬도 됩니다.</p></div></div>
<div class="step"><b>3</b><div><h3>게시 상태를 "프로덕션"으로 <span class="warn">★ 7일 만료 방지</span></h3>
<a class="go" href="https://console.cloud.google.com/auth/audience">대상(Audience) 열기</a>
<p>게시 상태가 <b>테스트</b>면 [앱 게시] → [확인]을 눌러 <b>프로덕션 단계</b>로 바꿉니다.<br>
테스트로 두면 로그인이 <b>7일마다 풀립니다.</b> 개인용이라 구글 심사는 필요 없습니다("인증 필요" 안내가 떠도 그대로 두면 됩니다).</p></div></div>
<div class="step"><b>4</b><div><h3>클라이언트 만들기</h3>
<a class="go" href="https://console.cloud.google.com/auth/clients">클라이언트 열기</a>
<p>[+ 클라이언트 만들기] → 애플리케이션 유형 <b>TV 및 입력 제한 기기</b> → 이름 PKM → [만들기].<br>
<span class="warn">웹 애플리케이션·Android·데스크톱이 아니라 꼭 "TV 및 입력 제한 기기"</span></p></div></div>
<div class="step"><b>5</b><div><h3>ID와 보안 비밀번호 복사 → 위에 붙여넣기</h3>
<p>만들어진 창에서 <b>클라이언트 ID</b>와 <b>클라이언트 보안 비밀번호</b>를 각각 복사해 위 두 칸에 붙여넣고 저장합니다.<br>
<span class="warn">보안 비밀번호는 이 창을 닫으면 다시 볼 수 없습니다.</span> 놓쳤다면 클라이언트를 열어 [보안 비밀번호 추가]로 새로 만드세요.</p></div></div>
<div class="step"><b>6</b><div><h3>TV에 뜬 코드로 로그인</h3>
<a class="go" href="https://www.google.com/device">google.com/device 열기</a>
<p>저장하면 TV에 <b>코드</b>가 뜹니다. 위 버튼(또는 TV의 QR)으로 열어 코드 입력 → 구글 계정 선택.<br>
<b>"Google에서 확인하지 않은 앱"</b>이 나오면 [고급] → <b>[PKM(으)로 이동(안전하지 않음)]</b> → [계속]/[허용].<br>
TV에 "연결됨 · 구독 채널 N개"가 뜨면 끝.</p></div></div>
<div class="tips"><h3>헤매기 쉬운 곳</h3>
<p><b>"확인되지 않은 앱" / "안전하지 않음" 경고</b><br>→ 내가 만든 내 앱이라 정상입니다. [고급]을 눌러야 이동 버튼이 보입니다.</p>
<p><b>"액세스 차단됨: 앱이 테스트 중…" (403 access_denied)</b><br>→ 3단계 게시 상태가 테스트입니다. 프로덕션으로 바꾸거나, 대상 → 테스트 사용자에 내 메일을 추가하세요.</p>
<p><b>TV에 "클라이언트가 맞지 않습니다"</b><br>→ 클라이언트 유형이 TV 및 입력 제한 기기가 아닙니다. 새로 만드세요.</p>
<p><b>데이터 액세스(범위) 화면</b><br>→ 따로 추가하지 않아도 됩니다. PKM은 읽기 전용(youtube.readonly)만 요청합니다.</p>
<p><b>일주일 뒤 연결이 풀렸어요</b><br>→ 게시 상태가 테스트였던 것입니다. 프로덕션으로 바꾼 뒤 PKM에서 다시 연결하세요.</p>
</div>
<p class="foot">PKM은 구독 목록과 채널 이름만 읽습니다(읽기 전용). 구독 해지·댓글 등 계정 변경은 하지 않습니다. 연결 해제는 PKM 설정에서 할 수 있습니다.</p>
</main></body></html>"""




class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class KeyServer(object):
    """on_key(key) -> (ok, message); called from the HTTP thread."""

    def __init__(self, on_key, on_event=None, kind="apikey"):
        self.on_key = on_key
        self.kind = kind
        self.on_event = on_event or (lambda kind, text: None)
        self.token = "".join(random.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(6))
        self.ip = ""
        self.port = 0
        self.url = ""
        self.httpd = None
        self.thread = None
        self.last_hit = time.time()
        self._stop = threading.Event()

    def page(self):
        return OAUTH_PAGE if self.kind == "oauth" else PAGE

    # -------------------------------------------------------------- start / stop

    def start(self):
        from resources.lib.pkm_token_import import _local_ip
        self.ip = _local_ip()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                return

            def _ok_path(self):
                return self.path.split("?", 1)[0].rstrip("/") == "/" + owner.token

            def _send(self, code, body):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if not self._ok_path():
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                owner.on_event("open", "휴대폰에서 페이지를 열었습니다")
                self._send(200, owner.page() % {"msg": ""})

            def do_POST(self):
                if not self._ok_path():
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                try:
                    size = min(int(self.headers.get("Content-Length") or 0), 4096)
                    raw = self.rfile.read(size).decode("utf-8", "replace")
                    form = dict((k, (v or [""])[0]) for k, v in parse_qs(raw).items())
                except Exception:
                    form = {}
                if owner.kind == "oauth":
                    from resources.lib.pkm_youtube_account import clean_client
                    cid, sec, err = clean_client(form.get("client_id"), form.get("client_secret"))
                    key = (cid, sec)
                else:
                    key, err = clean_key(form.get("key"))
                if err:
                    ok, msg = False, err
                else:
                    owner.on_event("checking", "휴대폰에서 받은 값을 확인하는 중…")
                    try:
                        ok, msg = owner.on_key(key)
                    except Exception:
                        _log("ON_KEY_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                        ok, msg = False, "저장 중 오류가 발생했습니다"
                if not ok:
                    owner.on_event("error", msg)
                box = '<div class="msg %s">%s</div>' % ("ok" if ok else "bad",
                                                       (msg + " · TV 화면을 확인하세요") if ok else msg)
                self._send(200, owner.page() % {"msg": box})

        last_err = None
        for port in PREFERRED_PORTS:
            try:
                self.httpd = _Server(("0.0.0.0", port), Handler)
                break
            except Exception as exc:
                last_err = exc
                self.httpd = None
        if self.httpd is None:
            _log("BIND_FAILED err=%s" % last_err, xbmc.LOGWARNING)
            return False
        self.port = self.httpd.server_address[1]
        self.url = "http://%s:%d/%s" % (self.ip, self.port, self.token)
        self.thread = threading.Thread(target=self._serve, name="PKMYTKeyServer")
        self.thread.daemon = True
        self.thread.start()
        _log("STARTED ip=%s port=%d" % (self.ip, self.port))
        return True

    def _serve(self):
        httpd = self.httpd
        try:
            httpd.timeout = 1.0
            while not self._stop.is_set():
                httpd.handle_request()
                if time.time() - self.last_hit > IDLE_LIMIT_SEC:
                    _log("IDLE_STOP")
                    self.on_event("idle", "시간이 지나 휴대폰 입력을 멈췄습니다. 다시 선택하세요")
                    break
        except Exception:
            _log("SERVE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        finally:
            try:
                httpd.server_close()
            except Exception:
                pass

    def stop(self):
        self._stop.set()
        _log("STOP")

    @property
    def running(self):
        return bool(self.thread and self.thread.is_alive() and not self._stop.is_set())


def write_qr(text, path):
    try:
        from resources.lib.pkm_token_import import _write_qr_png
        if os.path.exists(path):
            os.remove(path)
        return _write_qr_png(text, path, scale=10, border=3)
    except Exception:
        _log("QR_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False
