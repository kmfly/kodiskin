# -*- coding: utf-8 -*-
"""R61: long-press Back exits Kodi from any screen.

Bound by the PKM keymap (<global> ... mod="longpress").  A short Back keeps
its normal per-window behaviour.

R74: long-press first shows the same PKM 종료/취소 confirm as Home Back
(plexkm_pkm_confirm_dialog.xml, default focus 종료).  Only 종료 continues:
a playing video is stopped so the PKM service can save the resume position,
then the shared PKM 3-2-1 exit countdown runs (pkm_kodi_exit_v2171) while the
confirm stays underneath, so the previous screen never shows for a frame.
취소 / Back closes the confirm and leaves everything as it was.
"""
from __future__ import absolute_import, unicode_literals

import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _source():
    for arg in sys.argv[1:]:
        text = str(arg or "")
        if text.startswith("source="):
            return text.split("=", 1)[1]
    return "unknown"


_CONFIRM_XML_R74 = "plexkm_pkm_confirm_dialog.xml"
_CONFIRM_KEYS_R74 = (
    "PlexKM.Confirm.Title", "PlexKM.Confirm.Message", "PlexKM.Confirm.Yes", "PlexKM.Confirm.No",
    "PlexKM.Confirm.Icon1", "PlexKM.Confirm.Icon2", "PlexKM.Confirm.HasIcons",
    "PlexKM.Confirm.HasCine21Rows", "PlexKM.Confirm.BackdropColor", "PlexKM.Confirm.PanelBgColor",
    "PlexKM.Confirm.FadeOverlayColor", "PlexKM.Confirm.AppQuittingCoverColor",
)
_ACTIVE_PROP_R74 = "PlexKM.LongpressExit.ConfirmActiveR74"


def _argb_r74(value, default="FF111214"):
    try:
        text = str(value or "").strip().upper().replace("#", "")
        if len(text) == 6:
            text = "FF" + text
        if len(text) != 8:
            return default
        int(text, 16)
        return text
    except Exception:
        return default


def _set_confirm_props_r74(win):
    """Same text and colours as the Home Back exit confirm."""
    for key in _CONFIRM_KEYS_R74:
        win.clearProperty(key)
    win.setProperty("PlexKM.Confirm.Title", "PKM 종료")
    win.setProperty("PlexKM.Confirm.Message",
                    "Kodi를 종료하시겠습니까?\nPKM도 함께 닫힙니다\n취소하면 현재 화면으로 돌아갑니다")
    win.setProperty("PlexKM.Confirm.Yes", "종료")
    win.setProperty("PlexKM.Confirm.No", "취소")
    base = _argb_r74(win.getProperty("PlexKM.Info.DynamicBgColor")
                     or win.getProperty("PlexKM.Home.DynamicBgColor") or "FF111214")
    rgb = base[-6:]
    win.setProperty("PlexKM.Confirm.BackdropColor", "FF" + rgb)
    win.setProperty("PlexKM.Confirm.PanelBgColor", "F2050607" if rgb == "111214" else ("F2" + rgb))
    win.setProperty("PlexKM.Confirm.FadeOverlayColor", "FF" + rgb)
    win.setProperty("PlexKM.Confirm.AppQuittingCoverColor", "FF" + rgb)


def _clear_confirm_props_r74(win):
    for key in _CONFIRM_KEYS_R74:
        try:
            win.clearProperty(key)
        except Exception:
            pass


def _stop_playback_then_exit_r74(source):
    player = xbmc.Player()
    try:
        playing = bool(player.isPlaying())
    except Exception:
        playing = False
    if playing:
        try:
            player.stop()
        except Exception:
            pass
        monitor = xbmc.Monitor()
        deadline = time.time() + 4.0
        while time.time() < deadline:
            try:
                if not player.isPlaying():
                    break
            except Exception:
                break
            if monitor.waitForAbort(0.1):
                return
        # Give the PKM service time to write the local resume sidecar and
        # push the stopped timeline to Plex.
        monitor.waitForAbort(0.8)
        _log("LONGPRESS_EXIT_PLAYBACK_STOPPED_R61 source=%s" % source)
    try:
        import pkm_kodi_exit_v2171
        pkm_kodi_exit_v2171.request_kodi_exit_v2171(
            reason="longpress_back_r61_%s" % source, title="Kodi 종료", detail="")
    except Exception as exc:
        _log("LONGPRESS_EXIT_COUNTDOWN_FAILED_R61 err=%s action=Quit" % exc, xbmc.LOGWARNING)
        xbmc.executebuiltin("Quit")


class _LongpressExitConfirmR74(xbmcgui.WindowXMLDialog):
    YES_ID = 300
    NO_ID = 301

    def __init__(self, *args, **kwargs):
        self.result = False
        self.source = "unknown"
        self.worker = None
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onClick(self, controlId):
        if controlId == self.YES_ID:
            if self.worker is not None:
                return
            self.result = True
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.App.Quitting", "1")
            except Exception:
                pass
            _log("LONGPRESS_EXIT_CONFIRM_YES_R74 source=%s confirm_stays_open=1" % self.source)
            # Keep this opaque confirm open underneath the countdown until Kodi
            # quits (same hand-off as the Home confirm, v2187).
            self.worker = threading.Thread(target=_stop_playback_then_exit_r74, args=(self.source,),
                                           name="PKMLongpressExitR74")
            self.worker.start()
        elif controlId == self.NO_ID:
            _log("LONGPRESS_EXIT_CONFIRM_NO_R74 source=%s" % self.source)
            self.close()

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = 0
        if self.worker is None and aid in (9, 10, 92, 216, 247):
            _log("LONGPRESS_EXIT_CONFIRM_BACK_R74 source=%s action=%s" % (self.source, aid))
            self.close()


def main():
    source = _source()
    win = xbmcgui.Window(10000)
    if win.getProperty("PlexKM.KodiExit.CountdownActiveV2171") == "1":
        _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=countdown_active" % source)
        return
    if win.getProperty(_ACTIVE_PROP_R74) == "1":
        _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=confirm_active_r74" % source)
        return
    try:
        if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
            _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=virtual_keyboard" % source)
            return
        if xbmc.getCondVisibility("Window.IsVisible(%s)" % _CONFIRM_XML_R74):
            # Home Back confirm (or another PKM confirm) is already asking.
            _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=confirm_visible" % source)
            return
    except Exception:
        pass
    _log("LONGPRESS_EXIT_BEGIN_R61 source=%s confirm=r74" % source)
    dlg = None
    try:
        win.setProperty(_ACTIVE_PROP_R74, "1")
        _set_confirm_props_r74(win)
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        dlg = _LongpressExitConfirmR74(_CONFIRM_XML_R74, addon_path, "Default", "1080i")
        dlg.source = source
        dlg.doModal()
        worker = dlg.worker
        if worker is not None:
            # Normally Kodi quits while the countdown runs; keep the script
            # alive until then so the worker is not cut off.
            worker.join(15.0)
    except Exception as exc:
        _log("LONGPRESS_EXIT_CONFIRM_FAILED_R74 err=%s action=no_exit" % exc, xbmc.LOGWARNING)
    finally:
        try:
            win.clearProperty(_ACTIVE_PROP_R74)
        except Exception:
            pass
        if dlg is None or not getattr(dlg, "result", False):
            _clear_confirm_props_r74(win)
        try:
            del dlg
        except Exception:
            pass


if __name__ == "__main__":
    main()
