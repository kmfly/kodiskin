# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM media-version identity helpers.

v2088 test scope:
- Movie copies in any *selected* Plex movie library may form one playback-version set.
- Identity is conservative: strong external identity first, otherwise exact title/year
  with a tight duration/original-title guard.
- The Info surface remains the canonical item; only the playback target changes.

This module performs no Kodi GUI work.
"""

import json
import re
import unicodedata

_NON_ALNUM_RE = re.compile(r"[^0-9a-z]+", re.IGNORECASE)
_TMDB_PATTERNS = (
    re.compile(r"(?:tmdb|themoviedb)\s*[:/._-]*\s*(\d{1,12})", re.IGNORECASE),
    re.compile(r"com\.plexapp\.agents\.themoviedb://(\d{1,12})", re.IGNORECASE),
)


def _text(value):
    return str(value or "").strip()


def normalize_title(value):
    """Stable, locale-tolerant exact-title key. Deliberately not fuzzy."""
    try:
        s = unicodedata.normalize("NFKC", _text(value)).casefold()
    except Exception:
        s = _text(value).lower()
    # Keep Hangul/other unicode letters by removing only spaces/punctuation using isalnum.
    return "".join(ch for ch in s if ch.isalnum())


def raw_dict(raw_json):
    try:
        if isinstance(raw_json, dict):
            return raw_json
        node = json.loads(raw_json or "{}")
        return node if isinstance(node, dict) else {}
    except Exception:
        return {}


def raw_guid(raw_json):
    return _text(raw_dict(raw_json).get("guid"))


def tmdb_id(raw_json):
    text = raw_guid(raw_json)
    if not text:
        return ""
    for pat in _TMDB_PATTERNS:
        m = pat.search(text)
        if m:
            return _text(m.group(1))
    return ""


def resolution_label(raw_json):
    """Return one user-facing resolution class: 720p/1080p/2160p or ''."""
    data = raw_dict(raw_json)
    res = _text(data.get("videoResolution") or data.get("resolution")).lower()
    try:
        width = int(float(data.get("width") or 0))
    except Exception:
        width = 0
    try:
        height = int(float(data.get("height") or 0))
    except Exception:
        height = 0
    if res in ("4k", "uhd", "2160", "2160p") or "2160" in res or width >= 3000 or height >= 2000:
        return "2160p"
    if "1080" in res or height >= 1000 or width >= 1800:
        return "1080p"
    if "720" in res or height >= 700 or width >= 1200:
        return "720p"
    return ""


def _tv_episode_identity_reason(source_episode, candidate_episode):
    """Return a conservative logical-episode match reason.

    v2115: Plex may represent an alternate encode as a different season node
    inside the same show.  Exact Plex episode GUID remains strongest, but a
    different GUID is no longer an automatic reject when both episodes resolve
    to the same *logical* season from Plex season metadata and have the same
    episode number.  No filesystem/folder naming convention is used.
    """
    src_rk = _text((source_episode or {}).get("rating_key"))
    cand_rk = _text((candidate_episode or {}).get("rating_key"))
    if src_rk and cand_rk and src_rk == cand_rk:
        return "SELF", 120

    src_guid = raw_guid((source_episode or {}).get("raw_json"))
    cand_guid = raw_guid((candidate_episode or {}).get("raw_json"))
    if src_guid and cand_guid and src_guid == cand_guid:
        return "EPISODE_PLEX_GUID", 110

    try:
        src_episode_no = int(float((source_episode or {}).get("episode") or 0))
        cand_episode_no = int(float((candidate_episode or {}).get("episode") or 0))
        src_physical_season = int(float((source_episode or {}).get("season") or 0))
        cand_physical_season = int(float((candidate_episode or {}).get("season") or 0))
        src_logical_season = int(float((source_episode or {}).get("_canonical_season_v2115") or src_physical_season or 0))
        cand_logical_season = int(float((candidate_episode or {}).get("_canonical_season_v2115") or cand_physical_season or 0))
    except Exception:
        return "", 0

    if src_episode_no <= 0 or src_episode_no != cand_episode_no:
        return "", 0

    if src_logical_season > 0 and src_logical_season == cand_logical_season:
        src_title = normalize_title((source_episode or {}).get("title"))
        cand_title = normalize_title((candidate_episode or {}).get("title"))
        src_original = normalize_title((source_episode or {}).get("original_title"))
        cand_original = normalize_title((candidate_episode or {}).get("original_title"))
        if src_title and cand_title and src_title == cand_title:
            return "EPISODE_LOGICAL_SEASON_TITLE", 105
        if src_original and cand_original and src_original == cand_original:
            return "EPISODE_LOGICAL_SEASON_ORIGINAL", 102
        src_duration = _tv_duration_seconds((source_episode or {}).get("duration"))
        cand_duration = _tv_duration_seconds((candidate_episode or {}).get("duration"))
        if src_duration and cand_duration and abs(src_duration - cand_duration) <= 600:
            return "EPISODE_LOGICAL_SEASON_DURATION", 95

    # Traditional Plex layout fallback: exact physical season + episode.  This
    # remains useful when parent season metadata has not been cached yet.
    if src_physical_season == cand_physical_season and src_physical_season > 0:
        if src_guid and cand_guid and src_guid != cand_guid:
            src_title = normalize_title((source_episode or {}).get("title"))
            cand_title = normalize_title((candidate_episode or {}).get("title"))
            if not src_title or not cand_title or src_title != cand_title:
                return "", 0
        return "EPISODE_COORD", 80
    return "", 0


def _tv_duration_seconds(value):
    """Normalize TV episode duration to seconds.

    Plex/library rows may carry milliseconds while older local rows may already
    be seconds.  v2099 compared the raw values against a 600-second guard, which
    could reject two otherwise identical episode remuxes for a sub-second or
    one-second runtime difference.
    """
    try:
        value = max(0.0, float(value or 0))
    except Exception:
        return 0
    if value > 100000.0:
        value /= 1000.0
    return int(round(value))


_SEASON_TITLE_PATTERNS_V2115 = (
    re.compile(r"시즌\s*0*(\d{1,3})(?!\d)", re.IGNORECASE),
    re.compile(r"\bseason\s*0*(\d{1,3})(?!\d)", re.IGNORECASE),
    re.compile(r"\bs\s*0*(\d{1,3})(?!\d)", re.IGNORECASE),
)


def _tv_parse_canonical_season_from_text_v2115(value):
    """Extract the logical season number from Plex metadata text, not paths.

    Examples: '시즌 2', '시즌 2 4K', 'Season 2 UHD' -> 2.  This intentionally
    does not implement private numeric folder conventions such as 102->2.
    """
    text = _text(value)
    if not text:
        return 0
    for pattern in _SEASON_TITLE_PATTERNS_V2115:
        match = pattern.search(text)
        if match:
            try:
                return int(match.group(1))
            except Exception:
                return 0
    return 0


def _tv_logical_season_index_v2122(value):
    """Return PKM's canonical logical season index.

    PKM already exposes 101..199 as the duplicate-4K season namespace
    (101 -> season 1 4K, 102 -> season 2 4K) in ``pkm_info_data``.  Media-version
    identity must use the same contract.  Keeping physical 102 as logical 102
    made the 4K episode impossible to match with the normal season-2 episode
    whenever Plex episode raw_json did not carry a parent season title.
    """
    try:
        season = int(float(value or 0))
    except Exception:
        return 0
    if 101 <= season <= 199:
        return season - 100
    return season if season > 0 else 0


def _tv_episode_canonical_season_v2115(conn, episode):
    """Resolve the logical season from Plex season metadata.

    Version files may live in a separate Plex season node (for example an UHD
    season node) whose numeric index differs from the logical season.  Prefer
    parent season title/metadata; when Plex does not cache a parent season row,
    apply PKM's existing 100-series 4K season contract instead of treating 102
    as a different logical season from 2.
    """
    episode = episode or {}
    raw = raw_dict(episode.get("raw_json"))
    for key in ("parentTitle", "parent_title", "seasonTitle", "season_title"):
        parsed = _tv_parse_canonical_season_from_text_v2115(raw.get(key))
        logical = _tv_logical_season_index_v2122(parsed)
        if logical > 0:
            reason = "EPISODE_RAW_%s" % key
            if logical != parsed:
                reason += "_4K_ALIAS_V2122"
            return logical, reason

    parent_key = _text(episode.get("parent_rating_key"))
    if parent_key and conn is not None:
        try:
            row = conn.execute(
                "SELECT title, raw_json FROM items WHERE rating_key=? AND plex_type='season' LIMIT 1",
                (parent_key,),
            ).fetchone()
        except Exception:
            row = None
        if row:
            season_title = _text(row[0])
            parsed = _tv_parse_canonical_season_from_text_v2115(season_title)
            logical = _tv_logical_season_index_v2122(parsed)
            if logical > 0:
                return logical, "SEASON_TITLE_4K_ALIAS_V2122" if logical != parsed else "SEASON_TITLE"
            season_raw = raw_dict(row[1])
            for key in ("title", "parentTitle", "parent_title"):
                parsed = _tv_parse_canonical_season_from_text_v2115(season_raw.get(key))
                logical = _tv_logical_season_index_v2122(parsed)
                if logical > 0:
                    reason = "SEASON_RAW_%s" % key
                    if logical != parsed:
                        reason += "_4K_ALIAS_V2122"
                    return logical, reason

    try:
        physical = int(float(episode.get("season") or 0))
    except Exception:
        physical = 0
    logical = _tv_logical_season_index_v2122(physical)
    if logical > 0 and logical != physical:
        return logical, "SEASON_INDEX_4K_ALIAS_V2122"
    return logical, "SEASON_INDEX" if logical > 0 else ""


def _cine21_identity_map(conn, rating_keys):
    keys = [_text(x) for x in (rating_keys or []) if _text(x)]
    if not keys:
        return {}
    out = {}
    try:
        ph = ",".join(["?"] * len(keys))
        rows = conn.execute(
            "SELECT rating_key, cine21_movie_id, match_status FROM cine21_matches WHERE rating_key IN (%s)" % ph,
            keys,
        ).fetchall()
        for rk, movie_id, status in rows or []:
            if _text(status).upper() == "MATCHED" and _text(movie_id):
                out[_text(rk)] = _text(movie_id)
    except Exception:
        # Cine21 is an optional strong identity; absence must not break version lookup.
        pass
    return out


def _identity_reason(source, candidate, cine21_map):
    """Return (reason, strength, duration_delta) or ('', 0, delta).

    False-positive avoidance is more important than recall here. Title-only fuzzy
    matching is intentionally forbidden.
    """
    src_year = _text(source.get("year"))
    cand_year = _text(candidate.get("year"))
    if not src_year or not cand_year or src_year != cand_year:
        return "", 0, 999999

    src_rk = _text(source.get("rating_key"))
    cand_rk = _text(candidate.get("rating_key"))
    src_tmdb = tmdb_id(source.get("raw_json"))
    cand_tmdb = tmdb_id(candidate.get("raw_json"))
    if src_tmdb and cand_tmdb:
        if src_tmdb == cand_tmdb:
            return "TMDB", 100, 0
        return "", 0, 999999

    src_guid = raw_guid(source.get("raw_json"))
    cand_guid = raw_guid(candidate.get("raw_json"))
    if src_guid and cand_guid and src_guid == cand_guid:
        return "PLEX_GUID", 95, 0

    src_c21 = _text(cine21_map.get(src_rk))
    cand_c21 = _text(cine21_map.get(cand_rk))
    if src_c21 and cand_c21:
        if src_c21 == cand_c21:
            return "CINE21", 90, 0
        return "", 0, 999999

    st = normalize_title(source.get("title"))
    ct = normalize_title(candidate.get("title"))
    so = normalize_title(source.get("original_title"))
    co = normalize_title(candidate.get("original_title"))
    if not st or not ct or st != ct:
        return "", 0, 999999

    # When both originals exist, disagreement is a hard reject. This blocks many
    # same-localized-title collisions before duration is considered.
    if so and co and so != co:
        return "", 0, 999999

    try:
        sd = max(0, int(float(source.get("duration") or 0)))
    except Exception:
        sd = 0
    try:
        cd = max(0, int(float(candidate.get("duration") or 0)))
    except Exception:
        cd = 0
    if not sd or not cd:
        # Without a strong external id, a missing duration is too ambiguous.
        return "", 0, 999999
    delta = abs(sd - cd)

    # Exact original title on both sides is stronger, but still bound the runtime.
    if so and co and so == co:
        if delta <= 300:  # five minutes covers normal remux/container variance, not cuts.
            return "TITLE_ORIGINAL_YEAR_DURATION", 70, delta
        return "", 0, delta

    # Localized-title fallback is deliberately much tighter.
    if delta <= 120:
        return "TITLE_YEAR_DURATION", 60, delta
    return "", 0, delta


def _preferred_resolution_order(label):
    # User policy: normal HD is the default when present; 4K is opt-in.
    return {"1080p": 0, "720p": 1, "2160p": 2}.get(_text(label), 99)


def find_movie_versions(conn, source_rating_key, selected_section_ids):
    """Return conservative playback versions for one movie across selected libs.

    Result:
      {
        'source': {...},
        'versions': [{'resolution','rating_key','section_id','part_key',...}],
        'default_resolution': '1080p',
      }
    """
    rk = _text(source_rating_key)
    selected = []
    seen = set()
    for sid in selected_section_ids or []:
        s = _text(sid)
        if s and s not in seen:
            selected.append(s); seen.add(s)
    if not rk or not selected:
        return {"source": {}, "versions": [], "default_resolution": ""}

    source_row = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file "
        "FROM items WHERE rating_key=? AND plex_type='movie' LIMIT 1",
        (rk,),
    ).fetchone()
    if not source_row:
        return {"source": {}, "versions": [], "default_resolution": ""}
    cols = ("rating_key","section_id","title","original_title","year","duration","part_key","raw_json","media_file")
    source = dict(zip(cols, source_row))
    if _text(source.get("section_id")) not in set(selected):
        return {"source": source, "versions": [], "default_resolution": ""}
    year = _text(source.get("year"))
    if not year:
        return {"source": source, "versions": [], "default_resolution": ""}

    ph = ",".join(["?"] * len(selected))
    rows = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file "
        "FROM items WHERE plex_type='movie' AND CAST(COALESCE(year,'') AS TEXT)=? "
        "AND section_id IN (%s)" % ph,
        [year] + selected,
    ).fetchall()
    candidates = [dict(zip(cols, row)) for row in (rows or [])]
    cine21 = _cine21_identity_map(conn, [_text(x.get("rating_key")) for x in candidates])

    accepted = []
    for cand in candidates:
        cand_rk = _text(cand.get("rating_key"))
        res = resolution_label(cand.get("raw_json"))
        if not cand_rk or not _text(cand.get("part_key")) or not res:
            continue
        if cand_rk == rk:
            reason, strength, delta = "SELF", 110, 0
        else:
            reason, strength, delta = _identity_reason(source, cand, cine21)
            if not reason:
                continue
        item = dict(cand)
        item.update({"resolution": res, "match_reason": reason, "match_strength": strength, "duration_delta": delta})
        accepted.append(item)

    # One playback target per resolution. Prefer the current item, then stronger
    # identity, then the closest runtime. Never use sidebar/current-section priority.
    by_res = {}
    for item in accepted:
        res = item["resolution"]
        rank = (
            0 if _text(item.get("rating_key")) == rk else 1,
            -int(item.get("match_strength") or 0),
            int(item.get("duration_delta") or 999999),
            _text(item.get("rating_key")),
        )
        prev = by_res.get(res)
        if prev is None or rank < prev[0]:
            by_res[res] = (rank, item)
    versions = [v[1] for v in by_res.values()]
    versions.sort(key=lambda x: (_preferred_resolution_order(x.get("resolution")), x.get("resolution") or ""))

    # v2094: the initial playback target must be the copy from the library that
    # opened this Info surface.  4K is no longer globally opt-in when the user
    # entered the movie from a UHD library; likewise an HD-library item starts HD.
    # The preferred-resolution order remains only a conservative fallback when
    # the source row has no usable resolution metadata.
    source_resolution = resolution_label(source.get("raw_json"))
    if source_resolution and source_resolution in by_res:
        default_resolution = source_resolution
    else:
        default_resolution = versions[0]["resolution"] if versions else ""
    return {"source": source, "versions": versions, "default_resolution": default_resolution}


def find_movie_copy_candidates(conn, source_rating_key, selected_section_ids):
    """Return every conservative same-movie copy in the selected libraries.

    v2100 keeps this deliberately separate from ``find_movie_versions``.  The
    quick resolution button still needs one representative target per
    720p/1080p/2160p class, while the media-version popup must retain same-
    resolution copies (for example two 1080p remuxes with different audio).
    Concrete Plex Media/Part rows are expanded later from these accepted copies.
    """
    rk = _text(source_rating_key)
    selected = []
    seen = set()
    for sid in selected_section_ids or []:
        value = _text(sid)
        if value and value not in seen:
            selected.append(value)
            seen.add(value)
    if not rk or not selected:
        return {"source": {}, "copies": []}

    cols = ("rating_key", "section_id", "title", "original_title", "year", "duration", "part_key", "raw_json", "media_file")
    source_row = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file "
        "FROM items WHERE rating_key=? AND plex_type='movie' LIMIT 1",
        (rk,),
    ).fetchone()
    if not source_row:
        return {"source": {}, "copies": []}
    source = dict(zip(cols, source_row))
    if _text(source.get("section_id")) not in set(selected):
        return {"source": source, "copies": []}
    year = _text(source.get("year"))
    if not year:
        return {"source": source, "copies": []}

    ph = ",".join(["?"] * len(selected))
    rows = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file "
        "FROM items WHERE plex_type='movie' AND CAST(COALESCE(year,'') AS TEXT)=? "
        "AND section_id IN (%s)" % ph,
        [year] + selected,
    ).fetchall()
    candidates = [dict(zip(cols, row)) for row in (rows or [])]
    cine21 = _cine21_identity_map(conn, [_text(x.get("rating_key")) for x in candidates])

    accepted = []
    for cand in candidates:
        cand_rk = _text(cand.get("rating_key"))
        if not cand_rk:
            continue
        if cand_rk == rk:
            reason, strength, delta = "SELF", 110, 0
        else:
            reason, strength, delta = _identity_reason(source, cand, cine21)
            if not reason:
                continue
        item = dict(cand)
        item.update({
            "resolution": resolution_label(cand.get("raw_json")),
            "match_reason": reason,
            "match_strength": int(strength or 0),
            "duration_delta": int(delta or 0),
        })
        accepted.append(item)

    accepted.sort(key=lambda item: (
        0 if _text(item.get("rating_key")) == rk else 1,
        _preferred_resolution_order(item.get("resolution")),
        -int(item.get("match_strength") or 0),
        int(item.get("duration_delta") or 0),
        _text(item.get("section_id")),
        _text(item.get("rating_key")),
    ))
    return {"source": source, "copies": accepted}

# v2099: TV episode playback-version lookup across all selected TV libraries.
# A TV version is never matched by episode title alone.  We first identify the
# same show, then require the same season number + episode number, and finally
# choose one concrete playback target per resolution.
def _tv_show_identity_reason(source_show, candidate_show):
    src_rk = _text(source_show.get("rating_key"))
    cand_rk = _text(candidate_show.get("rating_key"))
    if src_rk and cand_rk and src_rk == cand_rk:
        return "SELF_SHOW", 110

    src_tmdb = tmdb_id(source_show.get("raw_json"))
    cand_tmdb = tmdb_id(candidate_show.get("raw_json"))
    if src_tmdb and cand_tmdb:
        if src_tmdb == cand_tmdb:
            return "SHOW_TMDB", 100
        return "", 0

    src_guid = raw_guid(source_show.get("raw_json"))
    cand_guid = raw_guid(candidate_show.get("raw_json"))
    if src_guid and cand_guid:
        if src_guid == cand_guid:
            return "SHOW_PLEX_GUID", 95
        return "", 0

    st = normalize_title(source_show.get("title"))
    ct = normalize_title(candidate_show.get("title"))
    if not st or not ct or st != ct:
        return "", 0

    so = normalize_title(source_show.get("original_title"))
    co = normalize_title(candidate_show.get("original_title"))
    if so and co and so != co:
        return "", 0

    # Title fallback is intentionally conservative.  Strong GUID/TMDB identity
    # above may survive a bad year tag, but title-only matching requires the show
    # year to agree on both copies.
    sy = _text(source_show.get("year"))
    cy = _text(candidate_show.get("year"))
    if not sy or not cy or sy != cy:
        return "", 0
    if so and co and so == co:
        return "SHOW_TITLE_ORIGINAL_YEAR", 75
    return "SHOW_TITLE_YEAR", 65


def _tv_matched_show_keys(conn, source_episode, selected, show_cache=None):
    source_show_key = _text(source_episode.get("grandparent_rating_key"))
    if source_show_key:
        cache_owner = source_show_key
    else:
        cache_owner = "fallback:%s:s%s:e%s" % (
            normalize_title(source_episode.get("show_title")),
            _text(source_episode.get("season")), _text(source_episode.get("episode")),
        )
    cache_key = (cache_owner, tuple(selected))
    if show_cache is not None and cache_key in show_cache:
        return dict(show_cache.get(cache_key) or {})

    matched = {}
    show_cols = ("rating_key", "section_id", "title", "original_title", "year", "raw_json")
    source_show = None
    if source_show_key:
        row = conn.execute(
            "SELECT rating_key, section_id, title, original_title, year, raw_json "
            "FROM items WHERE rating_key=? AND plex_type='show' LIMIT 1",
            (source_show_key,),
        ).fetchone()
        if row:
            source_show = dict(zip(show_cols, row))

    if source_show:
        ph = ",".join(["?"] * len(selected))
        rows = conn.execute(
            "SELECT rating_key, section_id, title, original_title, year, raw_json "
            "FROM items WHERE plex_type='show' AND section_id IN (%s)" % ph,
            selected,
        ).fetchall()
        for row in rows or []:
            cand = dict(zip(show_cols, row))
            reason, strength = _tv_show_identity_reason(source_show, cand)
            if reason:
                matched[_text(cand.get("rating_key"))] = (reason, strength)

    # Robust local fallback for databases where a candidate library's show
    # parent row has not yet been cached.  It still requires exact normalized
    # show title plus the exact season/episode pair.  Never use this fallback to
    # override a real candidate show row that failed identity matching.
    src_show_title = normalize_title(source_episode.get("show_title"))
    if src_show_title:
        ph = ",".join(["?"] * len(selected))
        rows = conn.execute(
            "SELECT DISTINCT grandparent_rating_key, show_title, season, raw_json FROM items "
            "WHERE plex_type='episode' AND section_id IN (%s) "
            "AND CAST(COALESCE(episode,0) AS INTEGER)=?" % ph,
            selected + [int(source_episode.get("episode") or 0)],
        ).fetchall()
        for gp, show_title, candidate_season, candidate_raw in rows or []:
            gp = _text(gp)
            if not gp or gp in matched or normalize_title(show_title) != src_show_title:
                continue
            src_ep_guid = raw_guid(source_episode.get("raw_json"))
            cand_ep_guid = raw_guid(candidate_raw)
            if src_ep_guid and cand_ep_guid:
                if src_ep_guid != cand_ep_guid:
                    continue
            else:
                try:
                    source_logical_season_v2122 = _tv_logical_season_index_v2122(source_episode.get("season"))
                    candidate_logical_season_v2122 = _tv_logical_season_index_v2122(candidate_season)
                    if source_logical_season_v2122 <= 0 or source_logical_season_v2122 != candidate_logical_season_v2122:
                        continue
                except Exception:
                    continue
            candidate_show_exists = False
            try:
                candidate_show_exists = bool(conn.execute(
                    "SELECT 1 FROM items WHERE rating_key=? AND plex_type='show' LIMIT 1",
                    (gp,),
                ).fetchone())
            except Exception:
                candidate_show_exists = False
            if source_show is not None and candidate_show_exists:
                continue
            matched[gp] = ("SHOW_TITLE_EPISODE_COORD", 50)

    if source_show_key and source_show_key not in matched:
        matched[source_show_key] = ("SELF_SHOW", 110)
    if show_cache is not None:
        show_cache[cache_key] = dict(matched)
    return matched


def find_tv_episode_versions(conn, source_rating_key, selected_section_ids, show_cache=None):
    """Return playback versions for one TV episode across selected libraries.

    Identity graph:
      same show -> same Plex episode identity (GUID), with exact season/episode fallback -> concrete media.

    The source/current-library episode always defines the initial/default
    resolution.  One target per 720p/1080p/2160p class is returned.
    """
    rk = _text(source_rating_key)
    selected = []
    seen = set()
    for sid in selected_section_ids or []:
        s = _text(sid)
        if s and s not in seen:
            selected.append(s)
            seen.add(s)
    if not rk or not selected:
        return {"source": {}, "versions": [], "default_resolution": ""}

    cols = (
        "rating_key", "section_id", "title", "original_title", "year", "duration",
        "part_key", "raw_json", "media_file", "show_title", "season", "episode",
        "parent_rating_key", "grandparent_rating_key",
    )
    row = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file, "
        "show_title, season, episode, parent_rating_key, grandparent_rating_key "
        "FROM items WHERE rating_key=? AND plex_type='episode' LIMIT 1",
        (rk,),
    ).fetchone()
    if not row:
        return {"source": {}, "versions": [], "default_resolution": ""}
    source = dict(zip(cols, row))
    if _text(source.get("section_id")) not in set(selected):
        return {"source": source, "versions": [], "default_resolution": ""}
    source_canonical_v2115, source_canonical_reason_v2115 = _tv_episode_canonical_season_v2115(conn, source)
    source["_canonical_season_v2115"] = source_canonical_v2115
    source["_canonical_season_reason_v2115"] = source_canonical_reason_v2115

    try:
        season_no = int(source.get("season") or 0)
        episode_no = int(source.get("episode") or 0)
    except Exception:
        return {"source": source, "versions": [], "default_resolution": ""}

    matched_shows = _tv_matched_show_keys(conn, source, selected, show_cache=show_cache)
    show_keys = [k for k in matched_shows.keys() if _text(k)]
    candidates = []
    if show_keys:
        ph_sec = ",".join(["?"] * len(selected))
        ph_show = ",".join(["?"] * len(show_keys))
        rows = conn.execute(
            "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file, "
            "show_title, season, episode, parent_rating_key, grandparent_rating_key "
            "FROM items WHERE plex_type='episode' AND section_id IN (%s) "
            "AND grandparent_rating_key IN (%s) "
            "AND CAST(COALESCE(episode,0) AS INTEGER)=?" % (ph_sec, ph_show),
            selected + show_keys + [episode_no],
        ).fetchall()
        candidates = [dict(zip(cols, r)) for r in (rows or [])]
        for candidate in candidates:
            canonical_v2115, canonical_reason_v2115 = _tv_episode_canonical_season_v2115(conn, candidate)
            candidate["_canonical_season_v2115"] = canonical_v2115
            candidate["_canonical_season_reason_v2115"] = canonical_reason_v2115

    # Source must remain selectable even if its parent-show relation is incomplete.
    if not any(_text(x.get("rating_key")) == rk for x in candidates):
        candidates.append(source)

    accepted = []
    src_duration = _tv_duration_seconds(source.get("duration"))
    for cand in candidates:
        cand_rk = _text(cand.get("rating_key"))
        part_key = _text(cand.get("part_key"))
        res = resolution_label(cand.get("raw_json"))
        if not cand_rk or not part_key or res not in ("720p", "1080p", "2160p"):
            continue
        if cand_rk == rk:
            reason, strength = "SELF", 120
        else:
            show_key = _text(cand.get("grandparent_rating_key"))
            show_reason, show_strength = matched_shows.get(show_key, ("", 0))
            if not show_reason:
                continue
            episode_reason, episode_strength = _tv_episode_identity_reason(source, cand)
            if not episode_reason:
                continue
            reason = "%s+%s" % (show_reason, episode_reason)
            strength = min(int(show_strength or 0), int(episode_strength or 0))
        cand_duration = _tv_duration_seconds(cand.get("duration"))
        delta = abs(src_duration - cand_duration) if src_duration and cand_duration else 0
        # Exact show/season/episode is already strong.  This last guard catches
        # pathological numbering collisions without rejecting harmless remux cuts.
        if cand_rk != rk and src_duration and cand_duration and delta > 600:
            continue
        item = dict(cand)
        item.update({
            "resolution": res,
            "match_reason": reason,
            "match_strength": int(strength or 0),
            "duration_delta": delta,
        })
        accepted.append(item)

    by_res = {}
    for item in accepted:
        res = item.get("resolution")
        rank = (
            0 if _text(item.get("rating_key")) == rk else 1,
            -int(item.get("match_strength") or 0),
            int(item.get("duration_delta") or 0),
            _text(item.get("rating_key")),
        )
        prev = by_res.get(res)
        if prev is None or rank < prev[0]:
            by_res[res] = (rank, item)
    versions = [v[1] for v in by_res.values()]
    versions.sort(key=lambda x: (_preferred_resolution_order(x.get("resolution")), x.get("resolution") or ""))

    source_resolution = resolution_label(source.get("raw_json"))
    if source_resolution and source_resolution in by_res:
        default_resolution = source_resolution
    else:
        default_resolution = versions[0]["resolution"] if versions else ""
    return {"source": source, "versions": versions, "default_resolution": default_resolution}

def find_tv_episode_copy_candidates(conn, source_rating_key, selected_section_ids, show_cache=None):
    """Return every conservative same-episode copy across selected TV libraries.

    v2112 detailed media-version lookup keeps the v2099 TV identity contract:
    same show -> same Plex episode identity (GUID), with exact season/episode fallback.  Unlike
    ``find_tv_episode_versions`` it does not collapse same-resolution copies,
    because their concrete Plex Media/Part rows may have different video/audio
    codec combinations.
    """
    rk = _text(source_rating_key)
    selected = []
    seen = set()
    for sid in selected_section_ids or []:
        value = _text(sid)
        if value and value not in seen:
            selected.append(value)
            seen.add(value)
    if not rk or not selected:
        return {"source": {}, "copies": []}

    cols = (
        "rating_key", "section_id", "title", "original_title", "year", "duration",
        "part_key", "raw_json", "media_file", "show_title", "season", "episode",
        "parent_rating_key", "grandparent_rating_key",
    )
    row = conn.execute(
        "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file, "
        "show_title, season, episode, parent_rating_key, grandparent_rating_key "
        "FROM items WHERE rating_key=? AND plex_type='episode' LIMIT 1",
        (rk,),
    ).fetchone()
    if not row:
        return {"source": {}, "copies": []}
    source = dict(zip(cols, row))
    if _text(source.get("section_id")) not in set(selected):
        return {"source": source, "copies": []}
    source_canonical_v2115, source_canonical_reason_v2115 = _tv_episode_canonical_season_v2115(conn, source)
    source["_canonical_season_v2115"] = source_canonical_v2115
    source["_canonical_season_reason_v2115"] = source_canonical_reason_v2115

    try:
        season_no = int(source.get("season") or 0)
        episode_no = int(source.get("episode") or 0)
    except Exception:
        return {"source": source, "copies": []}

    matched_shows = _tv_matched_show_keys(conn, source, selected, show_cache=show_cache)
    show_keys = [key for key in matched_shows.keys() if _text(key)]
    candidates = []
    if show_keys:
        ph_sec = ",".join(["?"] * len(selected))
        ph_show = ",".join(["?"] * len(show_keys))
        rows = conn.execute(
            "SELECT rating_key, section_id, title, original_title, year, duration, part_key, raw_json, media_file, "
            "show_title, season, episode, parent_rating_key, grandparent_rating_key "
            "FROM items WHERE plex_type='episode' AND section_id IN (%s) "
            "AND grandparent_rating_key IN (%s) "
            "AND CAST(COALESCE(episode,0) AS INTEGER)=?" % (ph_sec, ph_show),
            selected + show_keys + [episode_no],
        ).fetchall()
        candidates = [dict(zip(cols, candidate)) for candidate in (rows or [])]
        for candidate in candidates:
            canonical_v2115, canonical_reason_v2115 = _tv_episode_canonical_season_v2115(conn, candidate)
            candidate["_canonical_season_v2115"] = canonical_v2115
            candidate["_canonical_season_reason_v2115"] = canonical_reason_v2115

    if not any(_text(item.get("rating_key")) == rk for item in candidates):
        candidates.append(source)

    src_duration = _tv_duration_seconds(source.get("duration"))

    accepted = []
    for cand in candidates:
        cand_rk = _text(cand.get("rating_key"))
        part_key = _text(cand.get("part_key"))
        if not cand_rk or not part_key:
            continue
        if cand_rk == rk:
            reason, strength = "SELF", 120
        else:
            show_key = _text(cand.get("grandparent_rating_key"))
            show_reason, show_strength = matched_shows.get(show_key, ("", 0))
            if not show_reason:
                continue
            episode_reason, episode_strength = _tv_episode_identity_reason(source, cand)
            if not episode_reason:
                continue
            reason = "%s+%s" % (show_reason, episode_reason)
            strength = min(int(show_strength or 0), int(episode_strength or 0))
        cand_duration = _tv_duration_seconds(cand.get("duration"))
        delta = abs(src_duration - cand_duration) if src_duration and cand_duration else 0
        if cand_rk != rk and src_duration and cand_duration and delta > 600:
            continue
        item = dict(cand)
        item.update({
            "resolution": resolution_label(cand.get("raw_json")),
            "match_reason": reason,
            "match_strength": int(strength or 0),
            "duration_delta": delta,
        })
        accepted.append(item)

    accepted.sort(key=lambda item: (
        0 if _text(item.get("rating_key")) == rk else 1,
        _preferred_resolution_order(item.get("resolution")),
        -int(item.get("match_strength") or 0),
        int(item.get("duration_delta") or 0),
        _text(item.get("section_id")),
        _text(item.get("rating_key")),
    ))
    return {"source": source, "copies": accepted}
