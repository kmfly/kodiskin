# -*- coding: utf-8 -*-
"""R138: retry helper for short-lived SQLite "database is locked" errors.

Start-up runs several writers against the same plex_km.db (pre-Home play-state
pull, library partial sync, ...).  A writer that hits a locked database used to
give up at once and the caller fell back to a full membership re-scan, which
cost tens of seconds on the Shield.  The lock is normally released within a few
seconds, so wait for it instead.
"""
from __future__ import absolute_import, unicode_literals

import sqlite3
import time

import xbmc


def is_locked_error(exc):
    try:
        if not isinstance(exc, sqlite3.OperationalError):
            return False
        text = str(exc).lower()
        return "locked" in text or "busy" in text
    except Exception:
        return False


def call_with_lock_retry(func, conn=None, max_wait_s=30.0, step_s=0.5,
                         abort_cb=None, label="", log_fn=None):
    """Run ``func()``; on "database is locked" wait and retry.

    ``conn`` (optional) is committed before each retry so that a stale read
    snapshot cannot keep returning SQLITE_BUSY_SNAPSHOT.  The last error is
    re-raised once ``max_wait_s`` has elapsed or ``abort_cb()`` is true.
    """
    t0 = time.time()
    attempt = 0
    while True:
        try:
            return func()
        except sqlite3.OperationalError as exc:
            if not is_locked_error(exc):
                raise
            attempt += 1
            waited = time.time() - t0
            aborted = False
            try:
                aborted = bool(abort_cb()) if abort_cb else False
            except Exception:
                aborted = False
            if aborted or waited >= float(max_wait_s):
                if log_fn:
                    try:
                        log_fn("R138_DB_LOCK_GIVE_UP label=%s attempts=%d waited_ms=%d aborted=%d" % (
                            label, attempt, int(waited * 1000), 1 if aborted else 0), xbmc.LOGWARNING)
                    except Exception:
                        pass
                raise
            if conn is not None:
                try:
                    conn.commit()
                except Exception:
                    pass
            if attempt == 1 and log_fn:
                try:
                    log_fn("R138_DB_LOCK_RETRY label=%s waited_ms=%d" % (label, int(waited * 1000)), xbmc.LOGINFO)
                except Exception:
                    pass
            time.sleep(min(float(step_s) * attempt, 2.0))
