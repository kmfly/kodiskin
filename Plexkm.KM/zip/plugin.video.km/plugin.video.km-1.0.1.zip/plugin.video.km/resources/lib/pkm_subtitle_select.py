# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import shutil
import traceback
import time
import threading
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcaddon
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

try:
    from resources.lib import pkm_plex_client
except Exception:
    try:
        import pkm_plex_client
    except Exception:
        pkm_plex_client = None

try:
    from resources.lib import pkm_subtitle_font
except Exception:
    try:
        import pkm_subtitle_font
    except Exception:
        pkm_subtitle_font = None

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_subtitle_select.xml"

# v1243: One simple subtitle popup only.
# Keep a single focus target/list for any subtitle count:
# - simple list: 5008
# - hidden settings chip: 5028
SIMPLE_LIST_IDS = {
    "single_narrow": 5008,
}
SETTING_LIST_IDS = {
    "single_narrow": 5028,
}
SIMPLE_LIST_ID = 5008
SETTING_LIST_ID = 5028
ADV_LIST_ID = 5010
ADV_LIST_IDS = {"size": 5010, "style": 5012, "position": 5014, "font": 5016, "sync": 5018}
ADV_TAB_CONTROL_IDS = {5100: "size", 5101: "style", 5102: "position", 5103: "font", 5104: "sync"}
SUBTITLE_SELECT_PATCH_VERSION = "v1267"
TAB_IDS = {"size": 5201, "style": 5202, "position": 5203, "font": 5204, "sync": 5205}
ADV_TABS = ["size", "style", "position", "sync", "font"]
ADV_TAB_LABELS = {"size":"크기", "style":"스타일", "position":"위치", "font":"폰트", "sync":"싱크"}

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_SELECT_ITEM = 7

# Kodi Omega uses subtitles.marginvertical as a percentage setting (0.00 ~ 50.00),
# not as a pixel value.  Old PKM values such as 70/140/230 were rejected by
# Settings.SetSettingValue with Invalid params and the fallback SubtitleShift
# action only opened Kodi's temporary native slider.
POSITION_STEPS = [
    ("very_bottom", "매우 아래", 1.00),
    ("bottom", "하단", 4.95),
    ("up1", "조금 위", 8.00),
    ("up2", "더 위", 12.00),
    ("middle", "중간", 18.00),
    ("upper_middle", "중간 위", 28.00),
    ("top", "상단", 40.00),
]

# Kodi real subtitle renderer uses Kodi subtitle-font files by filename.
# PKM reuses the bundled UI font as the real-subtitle default,
# then registers/copies it into Kodi's subtitle font search folder at runtime.
PKM_SUBTITLE_FONT_FILENAME = "NotoSansKR-Medium.ttf"
PKM_CINEMA_FONT_FILENAME = "a시네마M.ttf"
# The bundled/source filename remains the user-provided Korean filename.
# Kodi/libass can accept the setting value over JSON-RPC but fail to bind
# the real subtitle renderer on some Windows builds when the setting value
# itself contains Hangul.  Keep the UI label as "시네마 폰트" and use an
# internal ASCII copy only for Kodi's real subtitle renderer.
PKM_CINEMA_FONT_RENDERER_FILENAME = "aCinemaM.ttf"
# a시네마M.ttf internal names: family=KoreanCNMM, postscript=KoreanCNM-M.
# Use the internal family for the real Kodi/libass renderer, not the alias filename.
PKM_CINEMA_FONT_RENDERER_SETTING = "KoreanCNMM"
PKM_CINEMA_FONT_POSTSCRIPT_NAME = "KoreanCNM-M"
PKM_CINEMA_FONT_RENDERER_ALIASES = (PKM_CINEMA_FONT_RENDERER_FILENAME, "KoreanCNMM.ttf", "KoreanCNM-M.ttf")
PKM_CINEMA_FONT_ESCAPED_FILENAME = "a#Uc2dc#Ub124#Ub9c8M.ttf"
PKM_SKIN_ID = "skin.plex.km"
KODI_SYSTEM_SUBTITLE_FONT = "Arial.ttf"  # legacy only; Korean glyphs commonly fallback and looked identical to Noto.

LANGUAGE_KO = {
    'aa': '아파르어', 'aar': '아파르어', 'ab': '압하지야어', 'abk': '압하지야어',
    'ae': '아베스타어', 'af': '아프리칸스어', 'afr': '아프리칸스어', 'ak': '아칸어',
    'aka': '아칸어', 'alb': '알바니아어', 'am': '암하라어', 'amh': '암하라어',
    'an': '아라곤어', 'ar': '아랍어', 'ara': '아랍어', 'arabic': '아랍어',
    'arg': '아라곤어', 'arm': '아르메니아어', 'as': '아삼어', 'asm': '아삼어',
    'av': '아바르어', 'ava': '아바르어', 'ave': '아베스타어', 'ay': '아이마라어',
    'aym': '아이마라어', 'az': '아제르바이잔어', 'aze': '아제르바이잔어', 'ba': '바시키르어',
    'bak': '바시키르어', 'bam': '밤바라어', 'baq': '바스크어', 'be': '벨라루스어',
    'bel': '벨라루스어', 'ben': '벵골어', 'bg': '불가리아어', 'bh': '비하르어',
    'bi': '비슬라마어', 'bih': '비하르어', 'bis': '비슬라마어', 'bm': '밤바라어',
    'bn': '벵골어', 'bo': '티베트어', 'bod': '티베트어', 'bos': '보스니아어',
    'br': '브르타뉴어', 'bre': '브르타뉴어', 'bs': '보스니아어', 'bul': '불가리아어',
    'bur': '버마어', 'ca': '카탈루냐어', 'cantonese': '광둥어', 'cat': '카탈루냐어',
    'ce': '체첸어', 'ces': '체코어', 'ch': '차모로어', 'cha': '차모로어',
    'che': '체첸어', 'chi': '중국어', 'chichewa': '치체와어', 'chinese': '중국어',
    'chs': '중국어(간체)', 'cht': '중국어(번체)', 'chu': '교회 슬라브어', 'chv': '추바시어',
    'cmn': '중국어', 'co': '코르시카어', 'cor': '콘월어', 'cos': '코르시카어',
    'cr': '크리어', 'cre': '크리어', 'cs': '체코어', 'cu': '교회 슬라브어',
    'cv': '추바시어', 'cy': '웨일스어', 'cym': '웨일스어', 'cze': '체코어',
    'da': '덴마크어', 'dan': '덴마크어', 'de': '독일어', 'deu': '독일어',
    'div': '디베히어', 'dut': '네덜란드어', 'dv': '디베히어', 'dz': '종카어',
    'dzo': '종카어', 'ee': '에웨어', 'el': '그리스어', 'ell': '그리스어',
    'en': '영어', 'eng': '영어', 'english': '영어', 'eo': '에스페란토어',
    'epo': '에스페란토어', 'es': '스페인어', 'es-la': '스페인어(라틴아메리카)', 'es-mx': '스페인어(멕시코)',
    'est': '에스토니아어', 'et': '에스토니아어', 'eu': '바스크어', 'eus': '바스크어',
    'ewe': '에웨어', 'fa': '페르시아어', 'fao': '페로어', 'fas': '페르시아어',
    'ff': '풀라어', 'fi': '핀란드어', 'fij': '피지어', 'fil': '필리핀어',
    'fin': '핀란드어', 'fj': '피지어', 'fo': '페로어', 'fr': '프랑스어',
    'fra': '프랑스어', 'fre': '프랑스어', 'french': '프랑스어', 'fry': '서프리지아어',
    'ful': '풀라어', 'fy': '서프리지아어', 'ga': '아일랜드어', 'gd': '스코틀랜드 게일어',
    'geo': '조지아어', 'ger': '독일어', 'german': '독일어', 'gl': '갈리시아어',
    'gla': '스코틀랜드 게일어', 'gle': '아일랜드어', 'glg': '갈리시아어', 'glv': '맨어',
    'gn': '과라니어', 'gre': '그리스어', 'grn': '과라니어', 'gu': '구자라트어',
    'guj': '구자라트어', 'gv': '맨어', 'ha': '하우사어', 'hat': '아이티 크리올어',
    'hau': '하우사어', 'he': '히브리어', 'heb': '히브리어', 'her': '헤레로어',
    'hi': '힌디어', 'hin': '힌디어', 'hmo': '히리 모투어', 'ho': '히리 모투어',
    'hr': '크로아티아어', 'hrv': '크로아티아어', 'ht': '아이티 크리올어', 'hu': '헝가리어',
    'hun': '헝가리어', 'hy': '아르메니아어', 'hye': '아르메니아어', 'hz': '헤레로어',
    'ia': '인테르링구아', 'ibo': '이그보어', 'ice': '아이슬란드어', 'id': '인도네시아어',
    'ido': '이도어', 'ie': '인테르링구에', 'ig': '이그보어', 'ii': '쓰촨 이어',
    'iii': '쓰촨 이어', 'ik': '이누피아크어', 'iku': '이누이트어', 'ile': '인테르링구에',
    'ina': '인테르링구아', 'ind': '인도네시아어', 'io': '이도어', 'ipk': '이누피아크어',
    'is': '아이슬란드어', 'isl': '아이슬란드어', 'it': '이탈리아어', 'ita': '이탈리아어',
    'italian': '이탈리아어', 'iu': '이누이트어', 'ja': '일본어', 'japanese': '일본어',
    'jav': '자바어', 'jp': '일본어', 'jpn': '일본어', 'jv': '자바어',
    'ka': '조지아어', 'kal': '그린란드어', 'kan': '칸나다어', 'kas': '카슈미르어',
    'kat': '조지아어', 'kau': '카누리어', 'kaz': '카자흐어', 'kg': '콩고어',
    'khm': '크메르어', 'ki': '키쿠유어', 'kik': '키쿠유어', 'kin': '르완다어',
    'kir': '키르기스어', 'kj': '콰냐마어', 'kk': '카자흐어', 'kl': '그린란드어',
    'km': '크메르어', 'kn': '칸나다어', 'ko': '한국어', 'kom': '코미어',
    'kon': '콩고어', 'kor': '한국어', 'korean': '한국어', 'kr': '한국어',
    'ks': '카슈미르어', 'ku': '쿠르드어', 'kua': '콰냐마어', 'kur': '쿠르드어',
    'kv': '코미어', 'kw': '콘월어', 'ky': '키르기스어', 'la': '라틴어',
    'lao': '라오어', 'lat': '라틴어', 'lav': '라트비아어', 'lb': '룩셈부르크어',
    'lg': '간다어', 'li': '림뷔르흐어', 'lim': '림뷔르흐어', 'lin': '링갈라어',
    'lit': '리투아니아어', 'ln': '링갈라어', 'lo': '라오어', 'lt': '리투아니아어',
    'ltz': '룩셈부르크어', 'lu': '루바카탕가어', 'lub': '루바카탕가어', 'lug': '간다어',
    'lv': '라트비아어', 'mac': '마케도니아어', 'mah': '마셜어', 'mal': '말라얄람어',
    'mao': '마오리어', 'mar': '마라티어', 'may': '말레이어', 'mg': '말라가시어',
    'mh': '마셜어', 'mi': '마오리어', 'mk': '마케도니아어', 'mkd': '마케도니아어',
    'ml': '말라얄람어', 'mlg': '말라가시어', 'mlt': '몰타어', 'mn': '몽골어',
    'mon': '몽골어', 'mr': '마라티어', 'mri': '마오리어', 'ms': '말레이어',
    'msa': '말레이어', 'mt': '몰타어', 'mul': '다중 언어', 'multiple': '다중 언어',
    'my': '버마어', 'mya': '버마어', 'na': '나우루어', 'nau': '나우루어',
    'nav': '나바호어', 'nb': '노르웨이어(보크몰)', 'nd': '북은데벨레어', 'nde': '북은데벨레어',
    'ndo': '은동가어', 'ne': '네팔어', 'nep': '네팔어', 'ng': '은동가어',
    'nl': '네덜란드어', 'nld': '네덜란드어', 'nn': '노르웨이어(니노르스크)', 'nno': '노르웨이어(니노르스크)',
    'no': '노르웨이어', 'nob': '노르웨이어(보크몰)', 'none': '무언어', 'nor': '노르웨이어',
    'nso': '북소토어', 'nv': '나바호어', 'ny': '치체와어', 'nya': '치체와어',
    'oc': '오크어', 'oci': '오크어', 'oj': '오지브와어', 'oji': '오지브와어',
    'om': '오로모어', 'or': '오리야어', 'ori': '오리야어', 'orm': '오로모어',
    'ory': '오리야어', 'os': '오세트어', 'oss': '오세트어', 'pa': '펀자브어',
    'pan': '펀자브어', 'pb': '포르투갈어(브라질)', 'per': '페르시아어', 'pi': '팔리어',
    'pl': '폴란드어', 'pli': '팔리어', 'pob': '포르투갈어(브라질)', 'pol': '폴란드어',
    'por': '포르투갈어', 'portuguese': '포르투갈어', 'ps': '파슈토어', 'pt': '포르투갈어',
    'pt-br': '포르투갈어(브라질)', 'pus': '파슈토어', 'qu': '케추아어', 'que': '케추아어',
    'rm': '로만슈어', 'rn': '룬디어', 'ro': '루마니아어', 'roh': '로만슈어',
    'ron': '루마니아어', 'ru': '러시아어', 'rum': '루마니아어', 'run': '룬디어',
    'rus': '러시아어', 'russian': '러시아어', 'rw': '르완다어', 'sa': '산스크리트어',
    'sag': '상고어', 'san': '산스크리트어', 'sc': '사르데냐어', 'sd': '신디어',
    'se': '북사미어', 'sg': '상고어', 'si': '싱할라어', 'sin': '싱할라어',
    'sk': '슬로바키아어', 'sl': '슬로베니아어', 'slk': '슬로바키아어', 'slo': '슬로바키아어',
    'slv': '슬로베니아어', 'sm': '사모아어', 'sme': '북사미어', 'smo': '사모아어',
    'sn': '쇼나어', 'sna': '쇼나어', 'snd': '신디어', 'so': '소말리어',
    'som': '소말리어', 'sot': '남소토어', 'spa': '스페인어', 'spanish': '스페인어',
    'sq': '알바니아어', 'sqi': '알바니아어', 'sr': '세르비아어', 'srd': '사르데냐어',
    'srp': '세르비아어', 'ss': '스와티어', 'ssw': '스와티어', 'st': '남소토어',
    'su': '순다어', 'sun': '순다어', 'sv': '스웨덴어', 'sw': '스와힐리어',
    'swa': '스와힐리어', 'swe': '스웨덴어', 'ta': '타밀어', 'tah': '타히티어',
    'tam': '타밀어', 'tat': '타타르어', 'te': '텔루구어', 'tel': '텔루구어',
    'tg': '타지크어', 'tgk': '타지크어', 'tgl': '타갈로그어', 'th': '태국어',
    'tha': '태국어', 'ti': '티그리냐어', 'tib': '티베트어', 'tir': '티그리냐어',
    'tk': '투르크멘어', 'tl': '타갈로그어', 'tn': '츠와나어', 'to': '통가어',
    'ton': '통가어', 'tr': '튀르키예어', 'ts': '총가어', 'tsn': '츠와나어',
    'tso': '총가어', 'tt': '타타르어', 'tuk': '투르크멘어', 'tur': '튀르키예어',
    'turkish': '튀르키예어', 'tw': '트위어', 'twi': '트위어', 'ty': '타히티어',
    'ug': '위구르어', 'uig': '위구르어', 'uk': '우크라이나어', 'ukr': '우크라이나어',
    'und': '언어 미지정', 'unknown': '언어 미지정', 'ur': '우르두어', 'urd': '우르두어',
    'uz': '우즈베크어', 'uzb': '우즈베크어', 've': '벤다어', 'ven': '벤다어',
    'vi': '베트남어', 'vie': '베트남어', 'vietnamese': '베트남어', 'vo': '볼라퓌크어',
    'vol': '볼라퓌크어', 'wa': '왈롱어', 'wel': '웨일스어', 'wln': '왈롱어',
    'wo': '월로프어', 'wol': '월로프어', 'xh': '코사어', 'xho': '코사어',
    'yi': '이디시어', 'yid': '이디시어', 'yo': '요루바어', 'yor': '요루바어',
    'yue': '광둥어', 'za': '좡어', 'zh': '중국어', 'zh-cn': '중국어(간체)',
    'zh-hans': '중국어(간체)', 'zh-hant': '중국어(번체)', 'zh-hk': '중국어(번체)', 'zh-mo': '중국어(번체)',
    'zh-sg': '중국어(간체)', 'zh-tw': '중국어(번체)', 'zha': '좡어', 'zho': '중국어',
    'zu': '줄루어', 'zul': '줄루어', 'zxx': '무언어',
}
TAG_KO = {"forced":"강제", "force":"강제", "sdh":"청각장애인용", "cc":"청각장애인용", "sign":"표지판", "songs":"노래", "commentary":"코멘터리", "default":"기본", "full":"전체", "normal":"일반"}

# v1115 root-cause isolation:
# - Do not mix internal subtitle stream selection with appearance renderer changes.
# - Kodi 21.3 on the user's build rejects subtitles_fontsize_invalid_old_height_setting_removed over JSON-RPC
#   (Invalid params), so size is sample/state only until the correct native
#   settings path is proven from Settings.GetSettings in the user's runtime.
# v1116 limited test scope:
# - Internal subtitle selection stays on the stable v1110 JSON-RPC single path.
# - Size now uses Kodi's real subtitle size setting id: subtitles.fontsize.
#   Kodi settings.xml defines subtitles.fontsize as an integer in pixels
#   (default 42, min 12, max 74, step 2).  Do not use the old invalid
#   subtitles_fontsize_invalid_old_height_setting_removed id.  v1121 restores the small option after the root cause was identified as
#   an option-list select/focus handling bug, not a renderer limitation.
#   Keep direct ACTION_SELECT handling so the top row is selectable.
SIZE_OPTIONS = [
    ("small", "작게", {"subtitles.fontsize": 34}),
    ("normal", "보통", {"subtitles.fontsize": 42}),
    ("large", "크게", {"subtitles.fontsize": 54}),
    ("xlarge", "아주 크게", {"subtitles.fontsize": 66}),
]
STYLE_OPTIONS = [
    # v1138: 기본 must be a real full reset, not only a partial style label.
    # Include the background fields too so returning from "흰색 + 반투명 배경"
    # clears leftover bg opacity/color state.
    ("default", "기본", {"subtitles.style":0, "subtitles.colorpick":"FFFFFFFF", "subtitles.bordercolorpick":"FF000000", "subtitles.bordersize":25, "subtitles.backgroundtype":0, "subtitles.bgcolorpick":"FF000000", "subtitles.bgopacity":0}),
    ("white_outline", "흰색 + 검정 테두리", {"subtitles.style":0, "subtitles.colorpick":"FFFFFFFF", "subtitles.bordercolorpick":"FF000000", "subtitles.bordersize":30, "subtitles.backgroundtype":0}),
    ("yellow_outline", "노란색 + 검정 테두리", {"subtitles.style":0, "subtitles.colorpick":"FFFFFF00", "subtitles.bordercolorpick":"FF000000", "subtitles.bordersize":30, "subtitles.backgroundtype":0}),
    ("white_bg", "흰색 + 반투명 배경", {"subtitles.style":0, "subtitles.colorpick":"FFFFFFFF", "subtitles.bordercolorpick":"FF000000", "subtitles.bordersize":10, "subtitles.backgroundtype":2, "subtitles.bgcolorpick":"FF000000", "subtitles.bgopacity":45}),
    ("bold_outline", "굵게 + 검정 테두리", {"subtitles.style":1, "subtitles.colorpick":"FFFFFFFF", "subtitles.bordercolorpick":"FF000000", "subtitles.bordersize":30, "subtitles.backgroundtype":0}),
]
POSITION_OPTIONS = [
    ("bottom", "하단", {"subtitles.align": 0, "subtitles.marginvertical": 4.95}),
    ("up1", "조금 위", {"subtitles.align": 0, "subtitles.marginvertical": 8.00}),
    ("middle", "중간", {"subtitles.align": 0, "subtitles.marginvertical": 18.00}),
    ("top", "상단", {"subtitles.align": 0, "subtitles.marginvertical": 40.00}),
]
FONT_OPTIONS = [
    ("default", "PKM 기본 폰트", {"subtitles.fontname":PKM_SUBTITLE_FONT_FILENAME, "subtitles.overridefonts":True}),
    # v1182: default uses the same bundled font as PKM UI.
    # Keep only visually meaningful choices: PKM 기본 폰트 / 시네마 폰트.
    ("cinema", "시네마 폰트", {"subtitles.fontname":PKM_CINEMA_FONT_RENDERER_SETTING, "subtitles.overridefonts":True}),
]


def _log(msg, level=xbmc.LOGINFO):
    try: xbmc.log("[%s][subtitle_select] %s" % (ADDON_ID, msg), level)
    except Exception: pass


def _addon_path():
    try: return xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
    except Exception: return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _skin_path():
    try:
        return xbmcaddon.Addon(PKM_SKIN_ID).getAddonInfo("path")
    except Exception:
        try:
            return _translate_path("special://home/addons/%s" % PKM_SKIN_ID)
        except Exception:
            return ""


def _translate_path(path):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        return xbmc.translatePath(path)
    except Exception:
        return path


def _kodi_font_dirs():
    dirs = []
    for sp in ("special://home/media/Fonts", "special://home/media/fonts"):
        try:
            path = _translate_path(sp)
            if path and path not in dirs:
                dirs.append(path)
        except Exception:
            pass
    return dirs


def _font_source_candidates():
    candidates = []

    # 1) Bundled PKM UI font source: plugin.video.km/resources/skins/Default/fonts/NotoSansKR-Medium.ttf
    try:
        skin_path = _skin_path()
        if skin_path:
            candidates.append(("skin", os.path.join(skin_path, "fonts", PKM_SUBTITLE_FONT_FILENAME)))
    except Exception:
        pass

    # 2) If the font was already registered into Kodi's subtitle font folder, reuse it.
    for d in _kodi_font_dirs():
        candidates.append(("kodi_font_folder", os.path.join(d, PKM_SUBTITLE_FONT_FILENAME)))

    # 3) Manual fallback near plugin addon_data, for emergency testing only.
    try:
        candidates.append(("addon_data", os.path.join(_translate_path("special://profile/addon_data/%s" % ADDON_ID), PKM_SUBTITLE_FONT_FILENAME)))
    except Exception:
        pass

    out = []
    seen = set()
    for kind, c in candidates:
        if not c:
            continue
        try:
            key = os.path.normcase(os.path.abspath(c))
        except Exception:
            key = c
        if key in seen:
            continue
        seen.add(key)
        out.append((kind, c))
    return out


def _ensure_pkm_subtitle_font_installed():
    """Check PKM subtitle font registration without copying during popup open.

    v1094: font registration is moved to plugin service startup.  The subtitle
    dialog only verifies/logs the status and avoids file copy/settings churn while
    VideoPlayer subtitle streams are being opened.
    """
    try:
        if pkm_subtitle_font:
            state = pkm_subtitle_font.register_pkm_subtitle_font(reason="subtitle_popup_check", allow_copy=False, apply_setting=False)
            return PKM_SUBTITLE_FONT_FILENAME if state.get("ok") else ""
    except Exception:
        _log("subtitle_font_popup_check_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    return ""



def _vfs_exists(path):
    try:
        if xbmcvfs and xbmcvfs.exists(path):
            return True
    except Exception:
        pass
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _vfs_mkdirs(path):
    try:
        if xbmcvfs and xbmcvfs.mkdirs(path):
            return True
    except Exception:
        pass
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
        return True
    except Exception:
        return False


def _vfs_copy(src, dst):
    try:
        if xbmcvfs and xbmcvfs.copy(src, dst):
            return True
    except Exception:
        pass
    try:
        shutil.copyfile(src, dst)
        return True
    except Exception:
        return False


def _cinema_font_source_candidates():
    candidates = []
    for d in _kodi_font_dirs():
        candidates.append(("kodi_font_folder", os.path.join(d, PKM_CINEMA_FONT_FILENAME)))
    try:
        skin_path = _skin_path()
        if skin_path:
            # v1404: the single bundled cinema source is kept in the skin folder
            # with an ASCII filename to avoid ZIP/extract filename encoding issues.
            candidates.append(("skin_renderer_ascii", os.path.join(skin_path, "fonts", PKM_CINEMA_FONT_RENDERER_FILENAME)))
            candidates.append(("skin", os.path.join(skin_path, "fonts", PKM_CINEMA_FONT_FILENAME)))
            # Fallback for older test zips that accidentally stored the Korean filename
            # as Kodi-style #U escape text. Do not expose this name to the UI.
            candidates.append(("skin_escaped_legacy", os.path.join(skin_path, "fonts", PKM_CINEMA_FONT_ESCAPED_FILENAME)))
    except Exception:
        pass
    base = _addon_path()
    candidates.extend([
        ("addon_skin", os.path.join(base, "resources", "skins", "Default", "fonts", PKM_CINEMA_FONT_FILENAME)),
        ("addon_skin_escaped_legacy", os.path.join(base, "resources", "skins", "Default", "fonts", PKM_CINEMA_FONT_ESCAPED_FILENAME)),
        ("addon_fonts", os.path.join(base, "resources", "fonts", PKM_CINEMA_FONT_FILENAME)),
    ])
    out = []
    seen = set()
    for kind, c in candidates:
        if not c:
            continue
        try:
            key = os.path.normcase(os.path.abspath(c))
        except Exception:
            key = c
        if key in seen:
            continue
        seen.add(key)
        out.append((kind, c))
    return out


def _ensure_cinema_subtitle_font_installed():
    """Register the bundled cinema subtitle font under Kodi's real font folder.

    The UI label remains simply '시네마 폰트'.  The source/bundled file keeps
    the real filename a시네마M.ttf.  For Kodi's real subtitle renderer only,
    install an internal ASCII copy aCinemaM.ttf because libass/fontconfig paths
    on the user's Windows runtime can accept a Hangul setting value but still
    keep rendering with the previous/fallback font.
    """
    try:
        dst_dirs = _kodi_font_dirs()
        dst_dir = dst_dirs[0] if dst_dirs else _translate_path("special://home/media/Fonts")
        dst = os.path.join(dst_dir, PKM_CINEMA_FONT_RENDERER_FILENAME)
        original_dst = os.path.join(dst_dir, PKM_CINEMA_FONT_FILENAME)
        if _vfs_exists(dst):
            # Ensure v1178 installs get the internal-name aliases too.
            for alias_name in PKM_CINEMA_FONT_RENDERER_ALIASES:
                alias_dst = os.path.join(dst_dir, alias_name)
                try:
                    if not _vfs_exists(alias_dst):
                        _vfs_copy(dst, alias_dst)
                except Exception:
                    pass
            return PKM_CINEMA_FONT_RENDERER_SETTING
        src = ""
        kind = "missing"
        for k, cand in _cinema_font_source_candidates():
            if _vfs_exists(cand):
                src = cand
                kind = k
                break
        if not src:
            searched = "|".join(["%s:%s" % (k, c) for k, c in _cinema_font_source_candidates()])
            _log("subtitle_font_cinema_missing filename=%s renderer_filename=%s dst=%s searched=%s" % (PKM_CINEMA_FONT_FILENAME, PKM_CINEMA_FONT_RENDERER_FILENAME, dst, searched), xbmc.LOGWARNING)
            return ""
        if not _vfs_mkdirs(dst_dir):
            _log("subtitle_font_cinema_mkdir_failed dst_dir=%s src=%s" % (dst_dir, src), xbmc.LOGWARNING)
            return ""
        copied = _vfs_copy(src, dst)
        # Also leave the original Korean filename in Kodi/media/Fonts for the
        # normal Kodi font list, but do not use it as the renderer setting.
        original_copied = False
        try:
            if not _vfs_exists(original_dst):
                original_copied = _vfs_copy(src, original_dst)
        except Exception:
            original_copied = False
        alias_results = []
        try:
            src_size = os.path.getsize(src)
        except Exception:
            src_size = -1
        for alias_name in PKM_CINEMA_FONT_RENDERER_ALIASES:
            alias_dst = os.path.join(dst_dir, alias_name)
            try:
                alias_exists = _vfs_exists(alias_dst)
                alias_size = os.path.getsize(alias_dst) if alias_exists else -1
                need_alias = (not alias_exists) or (src_size >= 0 and alias_size != src_size)
                alias_copied = _vfs_copy(src, alias_dst) if need_alias else False
                alias_results.append("%s:%s:%s" % (alias_name, "1" if _vfs_exists(alias_dst) else "0", "1" if alias_copied else "0"))
            except Exception:
                alias_results.append("%s:0:0" % alias_name)
        exists_after = _vfs_exists(dst)
        original_exists = _vfs_exists(original_dst)
        _log("subtitle_font_cinema_register source_filename=%s renderer_filename=%s renderer_setting=%s postscript=%s source_kind=%s source=%s renderer_dst=%s copied=%s exists=%s original_dst=%s original_copied=%s original_exists=%s aliases=%s" % (PKM_CINEMA_FONT_FILENAME, PKM_CINEMA_FONT_RENDERER_FILENAME, PKM_CINEMA_FONT_RENDERER_SETTING, PKM_CINEMA_FONT_POSTSCRIPT_NAME, kind, src, dst, "1" if copied else "0", "1" if exists_after else "0", original_dst, "1" if original_copied else "0", "1" if original_exists else "0", ",".join(alias_results)), xbmc.LOGINFO if exists_after else xbmc.LOGWARNING)
        return PKM_CINEMA_FONT_RENDERER_SETTING if exists_after else ""
    except Exception:
        _log("subtitle_font_cinema_register_failed filename=%s\n%s" % (PKM_CINEMA_FONT_FILENAME, traceback.format_exc()), xbmc.LOGWARNING)
        return ""


def _addon(): return xbmcaddon.Addon(ADDON_ID)


def _get_setting(key, default=""):
    try:
        v = _addon().getSetting(key)
        return v if v != "" else default
    except Exception:
        return default


def _set_setting(key, value):
    try: _addon().setSetting(key, str(value))
    except Exception: pass




def _fontsize_to_size_key(value):
    """Map Kodi's effective subtitles.fontsize to the nearest PKM size key.

    v1117: the sample overlay must represent the current real movie subtitle
    size, not a stale addon setting.  This is intentionally read-only; it never
    touches the active subtitle stream.
    """
    try:
        f = int(round(float(value)))
    except Exception:
        return _get_setting("pkm_subtitle_size", "normal") or "normal"
    best_key = "normal"
    best_dist = 9999
    for key, label, settings in SIZE_OPTIONS:
        try:
            target = int(settings.get("subtitles.fontsize"))
        except Exception:
            continue
        dist = abs(target - f)
        if dist < best_dist:
            best_key = key
            best_dist = dist
    return best_key


def _sync_size_setting_from_kodi(reason=""):
    """Keep PKM sample size aligned to Kodi's real subtitle renderer size."""
    try:
        effective = _get_kodi_setting_value("subtitles.fontsize")
        key = _fontsize_to_size_key(effective)
        old = _get_setting("pkm_subtitle_size", "normal")
        if key and key != old:
            _set_setting("pkm_subtitle_size", key)
        _log("subtitle_fontsize_sample_sync reason=%s effective=%s key=%s old=%s" % (reason, effective, key, old))
        return key
    except Exception:
        _log("subtitle_fontsize_sample_sync_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
        return _get_setting("pkm_subtitle_size", "normal") or "normal"

def _jsonrpc(method, params=None):
    payload = {"jsonrpc":"2.0", "id":1, "method":method}
    if params is not None: payload["params"] = params
    try: return json.loads(xbmc.executeJSONRPC(json.dumps(payload)) or "{}")
    except Exception:
        _log("jsonrpc_failed method=%s\n%s" % (method, traceback.format_exc()), xbmc.LOGWARNING)
        return {}


def _get_kodi_setting_value(setting_id):
    try:
        res = _jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
        if "result" in res and isinstance(res.get("result"), dict):
            return res.get("result", {}).get("value")
    except Exception:
        pass
    return None


def _setting_value_equal(current, requested):
    try:
        if isinstance(current, bool) or isinstance(requested, bool):
            return bool(current) == bool(requested)
        if isinstance(current, (int, float)) or isinstance(requested, (int, float)):
            return float(current) == float(requested)
    except Exception:
        pass
    return str(current) == str(requested)


def _apply_settings(settings):
    ok_any = False
    for sid, val in (settings or {}).items():
        if sid in ("subtitles.font", "subtitles.fontname"):
            if val == PKM_SUBTITLE_FONT_FILENAME:
                installed = _ensure_pkm_subtitle_font_installed()
                if not installed:
                    _log("subtitle_font_setting_deferred id=%s value=%s reason=font_not_registered_at_popup" % (sid, val), xbmc.LOGWARNING)
                    continue
                val = installed
            elif val in (PKM_CINEMA_FONT_FILENAME, PKM_CINEMA_FONT_RENDERER_FILENAME, PKM_CINEMA_FONT_RENDERER_SETTING, PKM_CINEMA_FONT_POSTSCRIPT_NAME):
                installed = _ensure_cinema_subtitle_font_installed()
                if not installed:
                    _log("subtitle_font_setting_deferred id=%s value=%s reason=cinema_font_not_registered" % (sid, val), xbmc.LOGWARNING)
                    continue
                val = installed
        current = _get_kodi_setting_value(sid)
        if _setting_value_equal(current, val):
            ok_any = True
            _log("setting_apply_skip id=%s value=%s current=%s reason=already_effective" % (sid, val, current))
            if sid in ("subtitles.font", "subtitles.fontname"):
                _log("subtitle_real_font_effective setting=%s requested=%s effective=%s ok=1 skipped=1" % (sid, val, current))
            continue
        res = _jsonrpc("Settings.SetSettingValue", {"setting": sid, "value": val})
        ok = "error" not in res
        # Some Kodi 21 builds expose the subtitle-size setting but reject it over
        # JSON-RPC depending on the current player/renderer state.  Do not fail
        # the dialog; log the rejected setting clearly so the sample overlay can
        # still be validated against the user's real subtitle size.
        if sid == "subtitles.fontsize":
            effective_size = _get_kodi_setting_value(sid)
            _log("subtitle_real_size_apply id=%s requested=%s ok=%s effective=%s result=%s" % (sid, val, "1" if ok else "0", effective_size, res), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        ok_any = ok_any or ok
        _log("setting_apply id=%s value=%s ok=%s result=%s" % (sid, val, "1" if ok else "0", res), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        if sid in ("subtitles.font", "subtitles.fontname"):
            effective_font = _get_kodi_setting_value(sid)
            _log("subtitle_real_font_effective setting=%s requested=%s effective=%s ok=%s" % (sid, val, effective_font, "1" if ok else "0"), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok_any


def _normalize_font_key(font_key):
    key = str(font_key or "default")
    if key in ("", "pkm", "system", "ibm"):
        return "default"
    if key == "cinema":
        return "cinema"
    return "default"


def _font_exists(font_key):
    font_key = _normalize_font_key(font_key)
    if font_key == "default":
        return bool(_ensure_pkm_subtitle_font_installed())
    if font_key != "cinema":
        return True
    return bool(_ensure_cinema_subtitle_font_installed())


def _token_to_korean(token):
    raw = str(token or "").strip().replace("_", "-")
    key = re.sub(r"[^a-z0-9-]+", "", raw.lower())
    if not key: return ""
    if key in LANGUAGE_KO: return LANGUAGE_KO[key]
    if "-" in key and key.split("-", 1)[0] in LANGUAGE_KO: return LANGUAGE_KO[key.split("-", 1)[0]]
    if key in TAG_KO: return TAG_KO[key]
    return raw


def _fields(stream):
    if isinstance(stream, dict):
        return str(stream.get("language") or stream.get("lang") or ""), str(stream.get("name") or stream.get("title") or stream.get("label") or ""), str(stream.get("codec") or "")
    return str(stream or "").strip(), "", ""


def _stream_codec_label(stream):
    """Return a compact display codec similar to Plex's subtitle rows.

    Plex shows the language plus technical subtitle type.  PKM keeps that model
    but makes source explicit because Kodi native streams and Plex sidecar
    streams are merged in one list.
    """
    try:
        if isinstance(stream, dict):
            codec = str(stream.get("codec") or stream.get("format") or stream.get("type") or "").strip()
        else:
            codec = ""
    except Exception:
        codec = ""
    if not codec:
        try:
            blob = _stream_text_blob(stream).lower()
            for token, label in (("vobsub", "VOBSUB"), ("pgs", "PGS"), ("subrip", "SRT"), ("srt", "SRT"), ("smi", "SMI"), ("sami", "SMI"), ("ass", "ASS"), ("ssa", "SSA")):
                if token in blob:
                    return label
        except Exception:
            pass
        return ""
    c = codec.lower().replace("subtitle", "").strip()
    mapping = {
        "subrip": "SRT",
        "srt": "SRT",
        "smi": "SMI",
        "sami": "SMI",
        "ssa": "SSA",
        "ass": "ASS",
        "vobsub": "VOBSUB",
        "dvd_subtitle": "VOBSUB",
        "pgs": "PGS",
        "hdmv_pgs_subtitle": "PGS",
        "webvtt": "WEBVTT",
        "vtt": "WEBVTT",
        "mov_text": "TX3G",
        "tx3g": "TX3G",
    }
    return mapping.get(c, c.upper())


def _stream_text_blob(stream):
    try:
        if isinstance(stream, dict):
            vals = []
            for k in ("language", "lang", "name", "title", "label", "codec", "source"):
                v = stream.get(k)
                if v is not None:
                    vals.append(str(v))
            return " ".join(vals)
    except Exception:
        pass
    return str(stream or "")


def _looks_like_kodi_external_shadow(stream):
    """Detect Kodi rows created by loading a sidecar/external subtitle URL.

    After Player.setSubtitles(url), Kodi can add a temporary row such as
    '16561620 (외부자막)' to the native subtitle list.  PKM already lists the
    same Plex sidecar as '한국어 (외부 SRT)', so keeping the Kodi shadow row makes
    the popup confusing and selecting muxed rows can jump to the wrong stream.
    """
    blob = _stream_text_blob(stream).lower()
    return ("외부자막" in blob) or ("external subtitle" in blob) or ("external subtitles" in blob)


def _is_external_stream(stream):
    try:
        if isinstance(stream, dict):
            if stream.get("pkm_external_url"):
                return True
            if str(stream.get("source") or "") == "plex_external":
                return True
            # Kodi JSON-RPC / Python builds may expose external subtitle metadata
            # with slightly different field names.  Treat these as external only
            # when explicitly marked, otherwise keep muxed streams as internal.
            for key in ("isexternal", "external", "isExternal"):
                if str(stream.get(key) or "").lower() in ("1", "true", "yes"):
                    return True
            if _looks_like_kodi_external_shadow(stream):
                return True
    except Exception:
        pass
    return False


def _stream_source_label(stream):
    codec = _stream_codec_label(stream)
    source = "외부" if _is_external_stream(stream) else "내장"
    return ("%s %s" % (source, codec)).strip() if codec else source


def _stream_actual_index(stream, fallback):
    try:
        if isinstance(stream, dict):
            for k in ("pkm_index", "index", "id"):
                v = stream.get(k)
                if v is not None and str(v) != "":
                    return int(v)
    except Exception:
        pass
    try: return int(fallback)
    except Exception: return fallback


def _stream_debug_label(stream, idx):
    lang, name, codec = _fields(stream)
    try: actual = _stream_actual_index(stream, idx)
    except Exception: actual = idx
    return "%s:%s/%s/%s" % (actual, lang, name, codec)


def _is_korean(stream):
    lang, name, codec = _fields(stream)
    v = (lang + " " + name).lower()
    return ("kor" in v) or ("korean" in v) or ("한국" in v) or (lang.lower() == "ko") or (_token_to_korean(lang) == "한국어")


def _label(stream, idx, used):
    lang, name, codec = _fields(stream)
    label = _token_to_korean(lang)
    extra = []
    if name:
        for part in re.split(r"[\s,/|()\[\]._-]+", name):
            ko = _token_to_korean(part)
            if ko and ko != label and ko != part and ko not in extra:
                extra.append(ko)
        if not label:
            maybe = _token_to_korean(name)
            label = maybe if maybe != name else name
    if not label:
        label = "자막 %d" % (idx + 1)
    if extra:
        label = "%s (%s)" % (label, ", ".join(extra[:2]))

    source_label = _stream_source_label(stream)
    if source_label:
        label = "%s (%s)" % (label, source_label)

    base = label
    n = used.get(base, 0) + 1
    used[base] = n
    return "%s %d" % (base, n) if n > 1 else base


def _streams_python():
    try: streams = xbmc.Player().getAvailableSubtitleStreams()
    except Exception: streams = []
    try:
        out = []
        for i, st in enumerate(list(streams or [])):
            if isinstance(st, dict):
                d = dict(st)
                d.setdefault("pkm_index", i)
                out.append(d)
            else:
                out.append({"language": str(st or ""), "name": "", "codec": "", "pkm_index": i, "source": "python"})
        return out
    except Exception:
        return []


def _streams_jsonrpc():
    out = []
    try:
        res = _jsonrpc("Player.GetProperties", {"playerid": 1, "properties": ["subtitles", "currentsubtitle"]})
        subs = (((res or {}).get("result") or {}).get("subtitles") or [])
        for i, st in enumerate(subs):
            if not isinstance(st, dict):
                continue
            d = dict(st)
            # Kodi JSON-RPC subtitle entries often provide an index. Preserve it
            # because setSubtitleStream() must receive Kodi's actual index, not
            # the visual row position.
            d.setdefault("pkm_index", d.get("index", i))
            d.setdefault("source", "jsonrpc")
            out.append(d)
    except Exception:
        _log("subtitle_streams_jsonrpc_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    return out


def _plex_now_rating_key():
    try:
        win = xbmcgui.Window(10000)
        for key in ("PlexKM.NowPlaying.RatingKey", "PlexKM.InfoPlaybackRatingKey", "PlexKM.Info.RatingKey"):
            v = win.getProperty(key)
            if v:
                return str(v)
    except Exception:
        pass
    return ""


def _plex_now_part_key():
    try:
        win = xbmcgui.Window(10000)
        for key in ("PlexKM.NowPlaying.PartKey", "PlexKM.Info.PartKey"):
            v = win.getProperty(key)
            if v:
                return str(v)
    except Exception:
        pass
    return ""


def _stream_external_url(stream):
    try:
        if isinstance(stream, dict):
            return str(stream.get("pkm_external_url") or "")
    except Exception:
        pass
    return ""


def _streams_plex_external():
    """Fetch Plex sidecar/external subtitle streams that Kodi does not expose.

    Direct part playback can expose only muxed streams to Kodi. Plex HTPC,
    however, lists Plex metadata streams such as external SRT/VOBSUB.  Import
    Plex streamType=3 entries with a `key` so PKM can call Player.setSubtitles()
    with the actual Plex subtitle URL.
    """
    out = []
    rating_key = _plex_now_rating_key()
    part_key = _plex_now_part_key()
    if not rating_key or pkm_plex_client is None:
        return out
    try:
        root = pkm_plex_client.plex_request_xml('/library/metadata/%s' % rating_key, timeout=5, env=None)
        part_nodes = list(root.findall('.//Part'))
        chosen_parts = []
        if part_key:
            for part in part_nodes:
                if (part.get('key') or '') == part_key:
                    chosen_parts.append(part)
        if not chosen_parts:
            chosen_parts = part_nodes
        seq = 0
        for part in chosen_parts:
            for st in part.findall('.//Stream'):
                if str(st.get('streamType') or '') != '3':
                    continue
                key = st.get('key') or ''
                if not key:
                    continue
                url = pkm_plex_client.plex_url(key, include_token=True, env=None)
                d = {
                    'language': st.get('languageCode') or st.get('language') or '',
                    'name': st.get('title') or st.get('displayTitle') or st.get('extendedDisplayTitle') or '',
                    'codec': st.get('codec') or '',
                    'pkm_index': 100000 + seq,
                    'source': 'plex_external',
                    'pkm_external_url': url,
                    'pkm_stream_id': st.get('id') or '',
                    'pkm_part_key': part.get('key') or '',
                }
                out.append(d)
                seq += 1
        try:
            preview = ';'.join([_stream_debug_label(x, i) for i, x in enumerate(out[:8])])
            _log('subtitle_streams_plex_probe rating_key=%s part_match=%s plex_external=%d plex_ko=%s preview=%s' % (
                rating_key, '1' if part_key else '0', len(out), '1' if any(_is_korean(x) for x in out) else '0', preview))
        except Exception:
            pass
    except Exception:
        _log('subtitle_streams_plex_probe_failed rating_key=%s\n%s' % (rating_key, traceback.format_exc()), xbmc.LOGWARNING)
    return out


def _streams():
    py_streams = _streams_python()
    rpc_streams = _streams_jsonrpc()
    plex_ext = _streams_plex_external()
    py_ko = any(_is_korean(x) for x in py_streams)
    rpc_ko = any(_is_korean(x) for x in rpc_streams)
    plex_ko = any(_is_korean(x) for x in plex_ext)
    chosen = py_streams
    source = "python"
    # Root cause guard: after Kodi subtitle settings are touched, the Python
    # getAvailableSubtitleStreams() path can return a reduced list in this build
    # (user log: 36 streams with Korean before, 17 English-only after v1077).
    # Prefer JSON-RPC if it exposes a fuller list or restores Korean entries.
    if rpc_streams and (len(rpc_streams) > len(py_streams) or (rpc_ko and not py_ko)):
        chosen = rpc_streams
        source = "jsonrpc"
    # v1097 policy: external subtitles are the primary rows, then Kodi/muxed
    # internal subtitles.  This matches the requested Plex-like behavior:
    # if a Korean external SRT/SMI exists it should be selected before any
    # internal stream; if no external Korean exists, fall back to internal Korean.
    if plex_ext:
        urls = set()
        merged = []
        shadow_skip = 0
        for x in plex_ext:
            u = _stream_external_url(x)
            if not u or u in urls:
                continue
            urls.add(u)
            merged.append(x)
        for x in list(chosen or []):
            # When a Plex external subtitle is already loaded through setSubtitles(),
            # Kodi exposes an extra native-looking row like '16561620 (외부자막)'.
            # It is a duplicate shadow of the Plex external URL, not a real muxed
            # internal track.  Hide it so only '한국어 (외부 SRT)' remains.
            if _looks_like_kodi_external_shadow(x):
                shadow_skip += 1
                continue
            merged.append(x)
        if shadow_skip:
            _log("subtitle_streams_kodi_external_shadow_filtered count=%d reason=plex_external_present" % shadow_skip)
        chosen = merged
        source = "plex+" + source
    try:
        preview = ";".join([_stream_debug_label(x, i) for i, x in enumerate(chosen[:10])])
        _log("subtitle_streams_probe python=%d python_ko=%s jsonrpc=%d jsonrpc_ko=%s plex_external=%d plex_ko=%s chosen=%s chosen_count=%d preview=%s" % (
            len(py_streams), "1" if py_ko else "0", len(rpc_streams), "1" if rpc_ko else "0",
            len(plex_ext), "1" if plex_ko else "0", source, len(chosen), preview))
    except Exception:
        pass
    return chosen


def _current_idx():
    try: return int(xbmc.Player().getSubtitleStream())
    except Exception: return -1


def _subs_visible():
    try: return bool(xbmc.getCondVisibility("VideoPlayer.SubtitlesEnabled"))
    except Exception:
        try: return bool(xbmc.Player().getSubtitles())
        except Exception: return False



def _jsonrpc_current_subtitle_index():
    try:
        res = _jsonrpc("Player.GetProperties", {"playerid": 1, "properties": ["currentsubtitle"]})
        cur = (((res or {}).get("result") or {}).get("currentsubtitle") or {})
        if isinstance(cur, dict):
            v = cur.get("index")
            if v is not None and str(v) != "":
                return int(v)
    except Exception:
        pass
    return -1


def _resync_internal_subtitle_renderer(idx, label=""):
    """v1110: intentionally do not seek/FF after internal subtitle selection."""
    _log("internal_subtitle_renderer_resync_skip index=%s label=%s method=disabled_no_seek reason=v1110_eof_guard" % (idx, label))
    return 0


def _set_internal_subtitle_stream(idx, label=""):
    """Select a real Kodi/muxed subtitle stream without double reopening streams.

    Use JSON-RPC as the primary path and only fall back to Python
    setSubtitleStream() if JSON-RPC does not report the requested stream.
    Do not seek; v1109 showed EOF after the old stream switch + seek path.
    """
    idx = int(idx)
    py_ok = 0
    rpc_ok = 0
    fallback_py = 0
    before_py = _current_idx()
    before_rpc = _jsonrpc_current_subtitle_index()
    try:
        res = _jsonrpc("Player.SetSubtitle", {"playerid": 1, "subtitle": idx, "enable": True})
        rpc_ok = 1 if (res and not res.get("error")) else 0
        if not rpc_ok:
            _log("internal_subtitle_apply_jsonrpc_error index=%s label=%s result=%s" % (idx, label, str(res)[:240]), xbmc.LOGWARNING)
    except Exception:
        _log("internal_subtitle_apply_jsonrpc_failed index=%s label=%s\n%s" % (idx, label, traceback.format_exc()), xbmc.LOGWARNING)
    try:
        xbmc.Player().showSubtitles(True)
    except Exception:
        pass
    xbmc.sleep(260)
    mid_py = _current_idx()
    mid_rpc = _jsonrpc_current_subtitle_index()
    if not ((mid_py == idx) or (mid_rpc == idx) or rpc_ok):
        try:
            xbmc.Player().setSubtitleStream(idx)
            py_ok = 1
            fallback_py = 1
            try:
                xbmc.Player().showSubtitles(True)
            except Exception:
                pass
            xbmc.sleep(180)
        except Exception:
            _log("internal_subtitle_apply_python_failed index=%s label=%s\n%s" % (idx, label, traceback.format_exc()), xbmc.LOGWARNING)
    after_py = _current_idx()
    after_rpc = _jsonrpc_current_subtitle_index()
    visible = _subs_visible()
    ok = (after_py == idx) or (after_rpc == idx) or (py_ok or rpc_ok)
    resync = _resync_internal_subtitle_renderer(idx, label=label) if ok else 0
    _log("internal_subtitle_apply index=%d label=%s before_py=%s before_rpc=%s mid_py=%s mid_rpc=%s after_py=%s after_rpc=%s visible=%s py_ok=%s rpc_ok=%s fallback_py=%s resync=%s ok=%s method=jsonrpc_primary_no_seek" % (idx, label, before_py, before_rpc, mid_py, mid_rpc, after_py, after_rpc, "1" if visible else "0", py_ok, rpc_ok, fallback_py, resync, "1" if ok else "0"))
    return ok, after_py, after_rpc, visible


class PKMSubtitleSelectWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.streams = []
        self.current_index = -1
        self.subs_visible = False
        self.mode = "simple"
        self.current_tab = "size"
        self.focus_tab = "size"
        self.advanced_row_count = 0
        self.simple_layout = "single_narrow"
        self.simple_list_id = SIMPLE_LIST_ID
        self.setting_list_id = SETTING_LIST_ID
        self.position_step = self._current_position_step()
        self.position_step_before_adjust = self.position_step
        self.subtitle_sync_ms = self._current_subtitle_sync_ms()
        self.subtitle_sync_before_adjust = self.subtitle_sync_ms
        self._pkm_paused_for_settings = False
        self._position_adjust_enter_ms = 0
        self._position_adjust_ignore_select_until_ms = 0
        self._sync_adjust_enter_ms = 0
        self._sync_adjust_ignore_select_until_ms = 0
        self._sync_adjust_input_seen = False
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        self._sync_adjust_active_flash_ms = 140
        self._sync_adjust_fast_flash_ms = 200
        self._sync_flash_token = 0
        # v1121: direct advanced-list select guard.  Kodi can emit both
        # ACTION_SELECT and a delayed onClick for the same list row.
        self._ignore_next_advanced_click_until_ms = 0
        self._last_direct_select_value = ""
        self._manual_subtitle_select = False
        self._external_default_apply_token = 0
        self._pending_external_default_url = ""
        self._pending_external_default_label = ""
        self.current_external_url = ""
        self.current_external_label = ""
        self.manual_internal_index = -1
        self.manual_internal_label = ""
        try:
            win = xbmcgui.Window(10000)
            self.current_external_url = win.getProperty("PlexKM.CurrentSubtitle.Url") or win.getProperty("PlexKM.PendingSubtitle.Url") or ""
            self.current_external_label = win.getProperty("PlexKM.CurrentSubtitle.Label") or win.getProperty("PlexKM.PendingSubtitle.Label") or ""
            if (win.getProperty("PlexKM.CurrentSubtitle.Source") or "") == "internal":
                try:
                    self.manual_internal_index = int(win.getProperty("PlexKM.CurrentSubtitle.Index") or "-1")
                except Exception:
                    self.manual_internal_index = -1
                self.manual_internal_label = win.getProperty("PlexKM.CurrentSubtitle.Label") or ""
        except Exception:
            pass
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        try:
            _log("subtitle_select_patch active=%s clean_single_simple_popup_5008 scope=remove_ibm_near_duplicate_font_option_v1181 cinema_font_internal_family_renderer_name_v1179 cinema_font_renderer_ascii_alias_v1178 cinema_font_immediate_preview_reload_notice_v1177 font_sample_skin_fontset_v1176 font_renderer_refresh_v1173 font_select_enabled_v1172 single_subtitle_panel_v1171 size_style_position_sync_xml_navigation_strict playback_rollback=v1144_discarded_restore_v1143_method internal_select_api=jsonrpc_primary_no_double internal_renderer_resync=disabled_no_seek size_setting_id=subtitles.fontsize size_real_apply=1 size_options=small,normal,large,xlarge small_restored=1 style_tab_restore=1 style_options=default,white_outline,yellow_outline,white_bg,bold_outline style_apply=settings_only style_default_top_row_boundary_fix=1 style_default_full_reset=1 position_tab_restore=1 position_setting_id=subtitles.marginvertical position_apply=settings_only no_native_shift=1 action_select_direct=0 advanced_onclick_enabled=1 xml_onclick_only=1 base=v1143_sync_keep_v1144_playback_discard language_overlay_restore=1 advanced_tabs=size,style,position,sync,font sync_tab_restore=1 sync_menu=adjust,current,reset sync_adjust_overlay=xml_static_card_chevron_no_native_osd_value_font_alias sync_step_fine_ms=10 sync_step_coarse_ms=100 sync_range_ms=5000 sync_real_apply=settings_subtitles_delay_first_native_fallback sync_enter_debounce_ms=800 sync_first_select_guard=1 sync_action_trace=1 sync_ui_master=v1168_chevron_no_kodi_native_osd_value_font_alias tab_highlight_control_focus_only=1 advanced_no_wrap=1 option_list_manual_updown=0 kodi_xml_navigation_only=1 python_navigation=0 python_boundary_only=0 python_navigation_code_removed=1 tab_button_white_box_fix=1 tab_button_texture=transparent position_guide_font=font45 position_guide_color=FFFFB300 position_guide_bigger=1 per_tab_list_controls=1 sample_skin_font_alias=1 sample_regular_font_only=1 sample_uniform_scale_ratio=1 sample_fixed_above_progress=1 sample_fixed_center_y=720 sample_group_top=610 sample_label_height=220 sample_font_map=font45_zoom105,font45_zoom130,font45_zoom167,font45_zoom204 sample_outline_offset_all=1 font_tab_enabled=1 font_after_sync=1 font_option_apply_enabled=1 cinema_font_select=1 font_renderer_reapply=external_internal_visible_keep no_subtitles_height=1" % SUBTITLE_SELECT_PATCH_VERSION)
            # v1121: small is restored.  Do not normalize it to normal; the
            # previous failure was caused by stale advanced-list select handling.
            self.streams = _streams()
            if not self.streams:
                self.close(); return
            self.current_index = _current_idx()
            self.subs_visible = _subs_visible()
            # v1211: Kodi Player().getSubtitleStream() can return -1 while JSON-RPC
            # still reports the active muxed subtitle.  Use the JSON-RPC value for
            # the popup check mark only; do not touch the player on dialog open.
            if self.current_index < 0 and self.subs_visible:
                try:
                    rpc_current = _jsonrpc_current_subtitle_index()
                    if rpc_current >= 0:
                        self.current_index = rpc_current
                        _log("subtitle_current_index_rpc_fallback index=%s reason=dialog_open_visual_check" % rpc_current)
                except Exception:
                    pass
            # v1101: after selecting an internal subtitle while a Plex external
            # sidecar had previously been loaded, Kodi can report current_index=-1
            # even though it opened the internal subtitle stream.  Preserve the
            # explicit manual internal selection stored by PKM so the list focus
            # and checkbox do not jump back to Korean external.
            if self.current_index < 0 and self.manual_internal_index >= 0:
                self.current_index = self.manual_internal_index
                self.subs_visible = True
                _log("manual_internal_restore_oninit index=%s label=%s" % (self.manual_internal_index, self.manual_internal_label))
            # v1115: do not touch subtitle appearance/position when opening the dialog.
            # Root cause from v1114 log: internal stream selection, libass reopen,
            # Settings.SetSettingValue, focus recovery, and sample updates were mixed
            # in one WindowXML lifecycle.  Keep popup open/init read-only except for
            # the explicit Korean default policy.
            _log("subtitle_appearance_defaults_skip reason=dialog_open_rootcause_isolation")
            self._apply_korean_default()
            _log("position_saved_apply_skip reason=dialog_open_rootcause_isolation")
            self._compute_simple_layout()
            _sync_size_setting_from_kodi(reason="dialog_open_v1117")
            self._sync_window_properties()
            self._populate_simple()
            self._safe_focus_simple(reason="oninit_after_populate")
            # v1108 rollback/root fix: do not call Player.setSubtitles() just
            # because the subtitle popup opened.  Logs from discarded v1107 show
            # that applying the pending Plex external sidecar during onInit can
            # close/reopen subtitle stream 3 and make VideoPlayer hit EOF, which
            # returns to the info screen immediately.  Keep the Korean external
            # row visually selected via current_external_url, but only touch the
            # player when the user explicitly selects a subtitle row.
            if getattr(self, "_pending_external_default_url", ""):
                _log("subtitle_external_default_apply_skip reason=dialog_open_no_autoload_crash_guard label=%s" % (getattr(self, "_pending_external_default_label", "") or ""))
        except Exception:
            _log("onInit_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            self.close()

    def _apply_saved_subtitle_appearance_defaults(self, reason=""):
        """Apply real Kodi subtitle renderer font/style defaults.

        PKM guide text uses skin XML labels, but real movie subtitles use Kodi's
        subtitle renderer.  This keeps the real renderer on the PKM font and
        prevents bold from being the implicit default.  Bold is only enabled by
        the explicit style option.
        """
        try:
            raw_font_key = _get_setting("pkm_subtitle_font", "default") or "default"
            font_key = _normalize_font_key(raw_font_key)
            if font_key != raw_font_key:
                _set_setting("pkm_subtitle_font", font_key)
                _log("subtitle_font_legacy_key_normalized old=%s new=%s reason=%s" % (raw_font_key, font_key, reason))
            font_settings = {}
            for key, label, settings in FONT_OPTIONS:
                if key == font_key:
                    font_settings = dict(settings or {})
                    break
            if font_key == "cinema" and not _font_exists("cinema"):
                font_settings = {"subtitles.fontname": PKM_SUBTITLE_FONT_FILENAME, "subtitles.overridefonts": True}
                _set_setting("pkm_subtitle_font", "default")
                _log("subtitle_font_default_fallback reason=cinema_missing to=pkm")
            if not font_settings:
                font_settings = {"subtitles.fontname": PKM_SUBTITLE_FONT_FILENAME, "subtitles.overridefonts": True}
            _apply_settings(font_settings)

            style_key = _get_setting("pkm_subtitle_style", "default") or "default"
            style_settings = None
            for key, label, settings in STYLE_OPTIONS:
                if key == style_key:
                    style_settings = dict(settings or {})
                    break
            if style_settings is None:
                style_key = "default"
                _set_setting("pkm_subtitle_style", style_key)
                for key, label, settings in STYLE_OPTIONS:
                    if key == style_key:
                        style_settings = dict(settings or {})
                        break
            if style_settings is not None:
                _apply_settings(style_settings)
            _log("subtitle_appearance_defaults_applied reason=%s font=%s style=%s fontstyle=%s" % (reason, font_key, style_key, str((style_settings or {}).get("subtitles.style", 0))))
        except Exception:
            _log("subtitle_appearance_defaults_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)

    def close(self):
        self._resume_after_settings_if_needed()
        try:
            win = xbmcgui.Window(10000)
            for k in ("Advanced", "SampleVisible", "SampleSize", "SampleStyle", "SamplePosition", "SampleFont", "ActiveTab", "PositionAdjust", "PositionStep", "PositionLabel", "PositionGuideText", "SyncAdjust", "SyncMs", "SyncLabel", "SyncValue", "SyncDir", "SyncLeftActive", "SyncRightActive", "SyncLeftFastActive", "SyncRightFastActive"):
                win.clearProperty("PlexKM.Subtitle.%s" % k)
        except Exception:
            pass
        xbmcgui.WindowXMLDialog.close(self)

    def _apply_korean_default(self):
        """Apply PKM's default subtitle policy.

        Policy from v1079:
        - If a Korean subtitle exists, Korean is the default and is selected.
        - If no Korean subtitle exists, subtitles are OFF by default.

        This is intentionally independent from Kodi/Plex's currently selected
        stream because many files expose English or forced subtitle tracks first.
        Users can still manually select any listed non-Korean subtitle after the
        popup opens; this routine only defines the initial/default state.
        """
        try:
            win = xbmcgui.Window(10000)
            if (win.getProperty("PlexKM.CurrentSubtitle.Manual") or "") == "1":
                src = win.getProperty("PlexKM.CurrentSubtitle.Source") or ""
                lbl = win.getProperty("PlexKM.CurrentSubtitle.Label") or ""
                _log("subtitle_default_policy_skip reason=manual_selection source=%s label=%s" % (src, lbl))
                return
        except Exception:
            pass

        k = -1
        k_stream = None
        for idx, stream in enumerate(self.streams or []):
            if _is_korean(stream):
                k = _stream_actual_index(stream, idx)
                k_stream = stream
                break
        try:
            if k_stream is not None:
                ext_url = _stream_external_url(k_stream)
                if ext_url:
                    self.current_index = -1
                    self.subs_visible = True
                    self._pending_external_default_url = ext_url
                    self._pending_external_default_label = _label(k_stream, 0, {}) or ""
                    self.current_external_url = ext_url
                    _log("subtitle_default_policy pending=korean_external url=1 label=%s" % (self._pending_external_default_label or ""))
                elif k >= 0:
                    # v1115 root-cause isolation: do not auto-select an internal
                    # subtitle when the popup opens.  Internal stream switching is
                    # only allowed after an explicit user row selection.
                    _log("subtitle_default_policy_skip_internal_no_autoload index=%d reason=rootcause_isolation" % k)
                return

            # v1115: do not turn subtitles off just because no Korean row exists
            # when the dialog opens.  Popup open must be read-only for VideoPlayer.
            _log("subtitle_default_policy_skip_off reason=no_korean_rootcause_isolation streams=%d" % len(self.streams or []))
        except Exception:
            _log("subtitle_default_policy_failed korean_index=%s external=%s\n%s" % (k, "1" if _stream_external_url(k_stream or {}) else "0", traceback.format_exc()), xbmc.LOGWARNING)

    def _focus_list_position(self, control_id, position, reason=""):
        """Focus first, then restore the requested row so Kodi cannot jump to row 0."""
        try:
            ctrl = self.getControl(int(control_id))
            size = int(ctrl.size())
            if size <= 0:
                return -1
            pos = max(0, min(size - 1, int(position)))
            self.setFocus(ctrl)
            ctrl.selectItem(pos)
            _log("subtitle_focus_row_restore control=%s pos=%s reason=%s" % (control_id, pos, reason))
            return pos
        except Exception:
            _log("subtitle_focus_row_restore_failed control=%s pos=%s reason=%s\n%s" % (control_id, position, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _find_row_position(self, control_id, row_type="", value="", fallback=0):
        try:
            ctrl = self.getControl(int(control_id))
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if row_type and (item.getProperty("row_type") or "") != str(row_type):
                    continue
                if value != "" and (item.getProperty("value") or "") != str(value):
                    continue
                return pos
        except Exception:
            pass
        return int(fallback)

    def _focus_matching_row(self, control_id, row_type="", value="", fallback=0, reason=""):
        return self._focus_list_position(control_id, self._find_row_position(control_id, row_type, value, fallback), reason=reason)

    def _update_selected_rows_in_place(self, control_id, row_type, value, reason=""):
        """Update only ListItem properties so the focused popup never repaints."""
        try:
            ctrl = self.getControl(int(control_id))
            target = str(value)
            matched_pos = -1
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if (item.getProperty("row_type") or "") != str(row_type):
                    continue
                selected = (item.getProperty("value") or "") == target
                item.setProperty("selected", "1" if selected else "0")
                if selected:
                    matched_pos = pos
            _log("subtitle_selection_update_in_place control=%s type=%s value=%s pos=%s reason=%s" % (control_id, row_type, target, matched_pos, reason))
            return matched_pos
        except Exception:
            _log("subtitle_selection_update_in_place_failed control=%s type=%s value=%s reason=%s\n%s" % (control_id, row_type, value, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _update_adjust_info_in_place(self, kind, reason=""):
        try:
            ctrl = self.getControl(self._advanced_list_id())
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                row_type = item.getProperty("row_type") or ""
                if kind == "position" and row_type == "position_info":
                    item.setLabel("현재 위치: %s" % self._position_label())
                    item.setProperty("value", str(self.position_step))
                    break
                if kind == "sync" and row_type == "sync_info":
                    item.setLabel("현재: %s" % self._subtitle_sync_label())
                    item.setProperty("value", str(self.subtitle_sync_ms))
                    break
            _log("subtitle_adjust_info_update_in_place kind=%s reason=%s" % (kind, reason))
        except Exception:
            _log("subtitle_adjust_info_update_in_place_failed kind=%s reason=%s\n%s" % (kind, reason, traceback.format_exc()), xbmc.LOGWARNING)

    def _safe_focus_simple(self, reason=""):
        """Focus only the currently visible simple list.

        Kodi logged "Control 5000 ... can't focus" when XML loaded before
        SimpleLayout was populated.  Anchor focus to the computed list only after
        rows were added, and never force-focus hidden fallback controls.
        """
        try:
            ctrl = self.getControl(self.simple_list_id)
            try:
                if ctrl.size() <= 0:
                    _log("simple_focus_skip reason=%s control=%s rows=0" % (reason, self.simple_list_id), xbmc.LOGWARNING)
                    return False
            except Exception:
                pass
            pos = int(getattr(self, "_simple_selected_pos", 0) or 0)
            self._focus_list_position(self.simple_list_id, pos, reason="simple_%s" % reason)
            _log("simple_focus_set reason=%s control=%s pos=%s" % (reason, self.simple_list_id, pos))
            return True
        except Exception:
            _log("simple_focus_failed reason=%s control=%s\n%s" % (reason, self.simple_list_id, traceback.format_exc()), xbmc.LOGWARNING)
            return False

    def _apply_pending_external_default(self, reason=""):
        """Apply pending Plex external Korean subtitle on the dialog thread.

        v1093 used a background thread to delay Player.setSubtitles().  Player
        calls from a helper thread are risky on Kodi/Android and can contribute
        to crashes.  v1096 keeps the short delay and setSubtitles() on the
        WindowXML Python callback thread after list population/focus is stable.
        """
        url = getattr(self, "_pending_external_default_url", "") or ""
        label = getattr(self, "_pending_external_default_label", "") or ""
        if not url:
            return False
        if getattr(self, "_manual_subtitle_select", False):
            _log("subtitle_external_default_apply_skip reason=manual_override stage=%s" % reason)
            return False
        try:
            xbmc.sleep(280)
            if not xbmc.Player().isPlaying():
                _log("subtitle_external_default_apply_skip reason=not_playing stage=%s" % reason)
                return False
            xbmc.Player().setSubtitles(url)
            xbmc.sleep(80)
            xbmc.Player().showSubtitles(True)
            self.current_index = -1
            self.current_external_url = url
            self.current_external_label = label or ""
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.CurrentSubtitle.Source", "external")
                win.setProperty("PlexKM.CurrentSubtitle.Url", url)
                win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
            except Exception:
                pass
            self.subs_visible = True
            self._pending_external_default_url = ""
            self._pending_external_default_label = ""
            _log("subtitle_external_default_apply_mainthread reason=%s label=%s url=1 visible=1" % (reason, label))
            return True
        except Exception:
            _log("subtitle_external_default_apply_mainthread_failed reason=%s label=%s\n%s" % (reason, label, traceback.format_exc()), xbmc.LOGWARNING)
            return False

    def _schedule_external_subtitle_apply(self, url, label, reason=""):
        # Compatibility wrapper for older call sites; do not spawn background threads.
        self._pending_external_default_url = url or ""
        self._pending_external_default_label = label or ""
        return self._apply_pending_external_default(reason=reason or "compat")

    def _compute_simple_layout(self):
        # v1243: No duplicate simple subtitle popup layouts.
        # One fixed popup/list is used for all cases:
        # - one subtitle: keep empty area
        # - many subtitles: scroll in the same list
        try:
            labels = ["끄기"]
            used = {}
            for idx, stream in enumerate(self.streams or []):
                labels.append(_label(stream, idx, used))
            row_count = len(labels)
            max_len = max([len(str(x or "")) for x in labels] + [0])
        except Exception:
            row_count = 0
            max_len = 0
        self.simple_layout = "single_narrow"
        self.simple_list_id = SIMPLE_LIST_ID
        self.setting_list_id = SETTING_LIST_ID
        try:
            self.setProperty("PlexKM.Subtitle.SimpleLayout", self.simple_layout)
            self.setProperty("PlexKM.Subtitle.SimpleRows", str(row_count))
            self.setProperty("PlexKM.Subtitle.SimpleMaxLabel", str(max_len))
        except Exception:
            pass
        _log("simple_layout_fixed_single_popup layout=single_narrow list=5008 setting_chip=5028 rows=%d max_label=%d" % (row_count, max_len))

    def _current_position_step(self):
        raw = _get_setting("pkm_subtitle_position_step", "1")
        try:
            step = int(raw)
        except Exception:
            mapping = {"very_bottom":0, "bottom":1, "up1":2, "up2":3, "middle":4, "upper_middle":5, "top":6}
            step = mapping.get(_get_setting("pkm_subtitle_position", "bottom"), 1)
        step = max(0, min(len(POSITION_STEPS) - 1, step))
        return step

    def _position_label(self, step=None):
        try:
            idx = self.position_step if step is None else int(step)
        except Exception:
            idx = 1
        idx = max(0, min(len(POSITION_STEPS) - 1, idx))
        return POSITION_STEPS[idx][1]

    def _position_step_from_value(self, value):
        key = str(value or "")
        for idx, (pos_key, _label, _margin) in enumerate(POSITION_STEPS):
            if pos_key == key:
                return idx
        for idx, (pos_key, _label, _settings) in enumerate(POSITION_OPTIONS):
            if pos_key == key:
                mapping = {"bottom": 1, "up1": 2, "middle": 4, "top": 6}
                return mapping.get(pos_key, idx)
        try:
            return max(0, min(len(POSITION_STEPS) - 1, int(value)))
        except Exception:
            return self._current_position_step()

    def _current_subtitle_sync_ms(self):
        # Prefer Kodi's native subtitle-delay setting if the runtime exposes it.
        # Keep the addon setting as a fallback so reset/cancel can still restore
        # the last PKM value on builds that do not expose the setting.
        for sid in ("subtitles.delay", "videoscreen.subtitledelay"):
            val = _get_kodi_setting_value(sid)
            if val is None:
                continue
            try:
                ms = int(round(float(val) * 1000.0))
                return max(-5000, min(5000, ms))
            except Exception:
                pass
        raw = _get_setting("pkm_subtitle_sync_ms", "0")
        try:
            ms = int(float(raw))
        except Exception:
            ms = 0
        return max(-5000, min(5000, ms))

    def _subtitle_sync_label(self, ms=None):
        try:
            value = self.subtitle_sync_ms if ms is None else int(ms)
        except Exception:
            value = 0
        sec = abs(value) / 1000.0
        if value < 0:
            return "음성보다 자막이 빠르게 %.2f초 (%dms)" % (sec, value)
        if value > 0:
            return "음성보다 자막이 느리게 %.2f초 (+%dms)" % (sec, value)
        return "자막 싱크 기준 0.00초 (0ms)"

    def _subtitle_sync_short_value(self, ms=None):
        try:
            value = self.subtitle_sync_ms if ms is None else int(ms)
        except Exception:
            value = 0
        if value == 0:
            return "0.00초"
        sign = "+" if value > 0 else "-"
        return "%s%.2f초" % (sign, abs(value) / 1000.0)

    def _sync_direction_hint(self):
        """v1314: Same transient arrow state model as audio sync overlay."""
        if self.mode != "sync_adjust":
            return ""
        active = str(getattr(self, "_sync_overlay_focus_hint", "") or "")
        return active if active in ("left", "right", "left_fast", "right_fast") else ""

    def _apply_subtitle_sync_exact_setting(self, target_ms, reason=""):
        seconds = round(float(target_ms) / 1000.0, 3)
        last_error = ""
        for sid in ("subtitles.delay", "videoscreen.subtitledelay"):
            current = _get_kodi_setting_value(sid)
            if current is None:
                continue
            try:
                res = _jsonrpc("Settings.SetSettingValue", {"setting": sid, "value": seconds})
                ok = "error" not in res
                effective = _get_kodi_setting_value(sid)
                _log("subtitle_sync_exact_setting_apply id=%s requested_sec=%.3f target_ms=%d ok=%s effective=%s reason=%s result=%s" % (sid, seconds, int(target_ms), "1" if ok else "0", effective, reason, res), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
                if ok:
                    return True, sid, int(round(float(effective if effective is not None else seconds) * 1000.0))
                last_error = str(res)
            except Exception:
                last_error = traceback.format_exc()
                _log("subtitle_sync_exact_setting_failed id=%s target_ms=%d reason=%s\n%s" % (sid, int(target_ms), reason, last_error), xbmc.LOGWARNING)
        _log("subtitle_sync_exact_setting_unavailable target_ms=%d reason=%s last_error=%s" % (int(target_ms), reason, last_error), xbmc.LOGWARNING)
        return False, "", None

    def _subtitle_delay_action(self, action_name):
        ok = False
        try:
            res = _jsonrpc("Input.ExecuteAction", {"action": action_name})
            ok = "error" not in res
        except Exception:
            ok = False
        if not ok:
            try:
                xbmc.executebuiltin("Action(%s)" % action_name)
                ok = True
            except Exception:
                ok = False
        _log("subtitle_delay_action action=%s ok=%s" % (action_name, "1" if ok else "0"))
        return ok

    def _flash_sync_arrow(self, direction):
        if direction not in ("left", "right", "left_fast", "right_fast"):
            return
        try:
            self._sync_flash_token = int(getattr(self, "_sync_flash_token", 0) or 0) + 1
            token = self._sync_flash_token
        except Exception:
            token = 0
        self._sync_overlay_focus_hint = direction
        self._sync_window_properties()
        try:
            if direction in ("left_fast", "right_fast"):
                flash_ms = int(getattr(self, "_sync_adjust_fast_flash_ms", 200) or 200)
            else:
                flash_ms = int(getattr(self, "_sync_adjust_active_flash_ms", 140) or 140)
        except Exception:
            flash_ms = 140

        def _clear_later():
            try:
                if token and int(getattr(self, "_sync_flash_token", 0) or 0) != token:
                    return
                self._sync_overlay_focus_hint = ""
                self._sync_window_properties()
            except Exception:
                pass

        try:
            t = threading.Timer(max(0.05, flash_ms / 1000.0), _clear_later)
            t.daemon = True
            t.start()
        except Exception:
            try:
                xbmc.sleep(flash_ms)
            except Exception:
                pass
            _clear_later()

    def _shift_subtitle_sync(self, delta_ms, persist=False, reason=""):
        try:
            delta_ms = int(delta_ms)
        except Exception:
            delta_ms = 0
        if delta_ms == 0:
            self._sync_window_properties()
            return
        old = int(self.subtitle_sync_ms)
        target = max(-5000, min(5000, old + delta_ms))
        actual_delta = target - old
        if actual_delta == 0:
            self._sync_window_properties()
            return

        exact_ok, method, effective_ms = self._apply_subtitle_sync_exact_setting(target, reason=reason or ("persist" if persist else "preview"))
        if exact_ok:
            new = max(-5000, min(5000, int(effective_ms if effective_ms is not None else target)))
            apply_method = method or "subtitles.delay"
        else:
            # v1168: Do not call Kodi native SubtitleDelay actions inside PKM
            # sync-adjust mode. Native actions open Kodi's top subtitle sync OSD
            # when Up/Down is pressed. Keep this screen XML-only and update the
            # preview value unless Kodi exposes an exact delay setting above.
            new = target
            apply_method = "display_preview_no_native_osd"
            _log("subtitle_sync_shift_display_preview_no_native old=%d target=%d delta=%d reason=%s" % (old, target, actual_delta, reason or ""), xbmc.LOGWARNING)

        self.subtitle_sync_ms = new
        if persist:
            _set_setting("pkm_subtitle_sync_ms", str(new))
        self._sync_window_properties()
        _log("subtitle_sync_shifted old=%d new=%d target=%d requested_delta=%d persist=%s method=%s label=%s" % (old, new, target, actual_delta, "1" if persist else "0", apply_method, self._subtitle_sync_label()))

    def _apply_position_setting_direct(self, step, reason=""):
        """Apply subtitle vertical position through Kodi persistent settings only.

        v1133 restores *position only* on top of the v1132 stable language/size
        rollback.  Do not use native subtitle shift actions and do not seek/reopen the
        player.  The only renderer path allowed here is Kodi settings:
        subtitles.align + subtitles.marginvertical.
        """
        try:
            step = max(0, min(len(POSITION_STEPS) - 1, int(step)))
        except Exception:
            step = 1
        key, label, margin = POSITION_STEPS[step]
        settings = {"subtitles.align": 0, "subtitles.marginvertical": float(margin)}
        ok = _apply_settings(settings)
        eff_align = _get_kodi_setting_value("subtitles.align")
        eff_margin = _get_kodi_setting_value("subtitles.marginvertical")
        _log("position_kodi_setting_apply step=%d key=%s label=%s margin=%.2f ok=%s effective_align=%s effective_margin=%s reason=%s settings_only=1 no_native_shift=1 no_seek=1" % (
            step, key, label, float(margin), "1" if ok else "0", eff_align, eff_margin, reason
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        return ok

    def _playing_file_key(self):
        try:
            key = xbmc.Player().getPlayingFile() or ""
        except Exception:
            key = ""
        return key

    def _native_position_state(self, default=None):
        """Return the subtitle position step that PKM believes Kodi renderer currently has.

        Kodi subtitle shift is a player-local native action, not a stable JSON
        Settings value.  Track it per playing file so we can compute deltas from
        the real already-applied step instead of from the saved setting alone.
        """
        if default is None:
            default = 1
        try:
            default = int(default)
        except Exception:
            default = 1
        default = max(0, min(len(POSITION_STEPS) - 1, default))
        try:
            win = xbmcgui.Window(10000)
            cur_file = self._playing_file_key()
            prop_file = win.getProperty("PlexKM.Subtitle.NativeFile") or ""
            prop_step = win.getProperty("PlexKM.Subtitle.NativeStep") or ""
            if cur_file and prop_file == cur_file and prop_step != "":
                return max(0, min(len(POSITION_STEPS) - 1, int(prop_step)))
        except Exception:
            pass
        return default

    def _set_native_position_state(self, step, reason=""):
        try:
            step = max(0, min(len(POSITION_STEPS) - 1, int(step)))
        except Exception:
            step = 1
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.Subtitle.NativeFile", self._playing_file_key())
            win.setProperty("PlexKM.Subtitle.NativeStep", str(step))
            _log("position_native_state_set step=%d key=%s reason=%s" % (step, POSITION_STEPS[step][0], reason))
        except Exception:
            _log("position_native_state_set_failed step=%s reason=%s\n%s" % (step, reason, traceback.format_exc()), xbmc.LOGWARNING)

    def _ensure_saved_position_applied_to_player(self, reason=""):
        """Apply the saved PKM subtitle position through Kodi's persistent settings.

        Do not call native subtitle shift actions here. Those actions are for Kodi's
        native temporary adjustment OSD and can show a transient slider with 0;
        they are not the reliable persistence path for PKM.
        """
        try:
            saved = self._current_position_step()
            ok = self._apply_position_setting_direct(saved, reason="saved_apply_%s" % reason)
            if ok:
                self._set_native_position_state(saved, reason="saved_apply_%s" % reason)
            _log("position_saved_apply_done saved=%d ok=%s reason=%s" % (saved, "1" if ok else "0", reason))
            return ok
        except Exception:
            _log("position_saved_apply_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
            return False

    def _subtitle_position_action(self, direction, count=1, reason=""):
        """v1115: disabled to avoid native OSD/renderer mixing."""
        _log("position_native_shift_skip direction=%s count=%s reason=%s rootcause_isolation=1" % (direction, count, reason), xbmc.LOGWARNING)
        return False

    def _apply_position_delta_to_kodi(self, old_step, new_step, reason=""):
        """v1115: no Kodi native position action from this dialog."""
        _log("position_native_delta_skip old=%s new=%s reason=%s rootcause_isolation=1" % (old_step, new_step, reason), xbmc.LOGWARNING)
        return False

    def _sample_position_key(self):
        # XML sample controls exist only for bottom / up1 / middle / top.
        # Map the finer live-adjust steps to those visible sample groups so
        # the sample subtitle does not disappear while moving between steps.
        try:
            idx = int(self.position_step)
        except Exception:
            idx = self._current_position_step()
        key = POSITION_STEPS[max(0, min(len(POSITION_STEPS) - 1, idx))][0]
        if key in ("very_bottom", "bottom"):
            return "bottom"
        if key in ("up1", "up2"):
            return "up1"
        if key in ("middle", "upper_middle"):
            return "middle"
        return "top"

    def _sync_window_properties(self):
        adv = "1" if self.mode in ("advanced", "position_adjust", "sync_adjust") else "0"
        # v1081: In position_adjust mode keep the old style/sample overlay disabled,
        # but show a dedicated centered position guide label from XML.  Relying only
        # on Kodi's real subtitle renderer is not enough because the current video
        # frame may have no active subtitle cue, or subtitles may be temporarily off.
        # The guide label is independent and always visible while still applying the
        # real Kodi margin setting on every Up/Down move.
        sample = "1" if (self.mode == "advanced" and self.current_tab not in ("position", "sync")) else "0"
        sample_position = _get_setting("pkm_subtitle_position", "bottom")
        sync_dir = self._sync_direction_hint() if self.mode == "sync_adjust" else ""
        props = {
            "Advanced": adv,
            "SampleVisible": sample,
            "SampleSize": _get_setting("pkm_subtitle_size", "normal"),
            "SampleStyle": _get_setting("pkm_subtitle_style", "default"),
            "SamplePosition": sample_position,
            "SampleFont": _normalize_font_key(_get_setting("pkm_subtitle_font", "default")),
            "ActiveTab": self.current_tab,
            "FocusTab": self.current_tab,
            "PositionAdjust": "1" if self.mode == "position_adjust" else "0",
            "PositionStep": str(self.position_step),
            "PositionLabel": self._position_label(),
            "PositionGuideText": "자막 위치 조정입니다",
            "SyncAdjust": "1" if self.mode == "sync_adjust" else "0",
            "SyncMs": str(self.subtitle_sync_ms),
            "SyncLabel": self._subtitle_sync_label(),
            "SyncValue": self._subtitle_sync_short_value(),
            "SyncDir": sync_dir,
            "SyncLeftActive": "1" if sync_dir == "left" else "0",
            "SyncRightActive": "1" if sync_dir == "right" else "0",
            "SyncLeftFastActive": "1" if sync_dir == "left_fast" else "0",
            "SyncRightFastActive": "1" if sync_dir == "right_fast" else "0",
        }
        for scope in (self, xbmcgui.Window(10000)):
            try:
                for k, v in props.items():
                    scope.setProperty("PlexKM.Subtitle.%s" % k, str(v or ""))
            except Exception:
                pass
        self._log_position_guide_state(reason="properties")


    def _set_sample_font_preview_property(self, value, reason=""):
        """Force the XML sample label group to switch immediately.

        The right-side preview text is not Kodi's subtitle renderer; it is a
        WindowXML label group controlled by PlexKM.Subtitle.SampleFont.  Set the
        property before any renderer refresh/repopulation work so selecting
        '시네마 폰트' changes the sample on the same screen.
        """
        v = str(value or "default")
        try:
            self.setProperty("PlexKM.Subtitle.SampleFont", v)
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Subtitle.SampleFont", v)
        except Exception:
            pass
        _log("subtitle_sample_font_preview_set value=%s reason=%s xml_label_control=1" % (v, reason))

    def _maybe_prompt_fontxml_reload(self, value, reason=""):
        """Offer a skin reload only for the new cinema preview Font.xml alias.

        Real subtitle font changes are applied through Kodi settings plus a
        subtitle-track refresh and do not require a Kodi restart.  The only case
        that can need a reload is the newly added XML font name used by the
        sample label after installing this patch over an already running Kodi.
        """
        if str(value or "") != "cinema":
            return False
        flag_key = "pkm_subtitle_fontxml_reload_notice_v1177"
        try:
            if (_get_setting(flag_key, "") or "") == "shown":
                return False
        except Exception:
            pass
        try:
            _set_setting(flag_key, "shown")
        except Exception:
            pass
        try:
            yes = xbmcgui.Dialog().yesno(
                "PKM 자막 폰트",
                "패치 직후 시네마 폰트 샘플이 바로 바뀌지 않으면 스킨 새로고침이 필요합니다.",
                "Kodi 재시작은 아닙니다. 지금 스킨을 새로고침할까요?",
                "",
                nolabel="나중에",
                yeslabel="새로고침"
            )
            _log("subtitle_fontxml_reload_prompt value=%s yes=%s reason=%s restart=0 reloadskin=1" % (value, "1" if yes else "0", reason))
            if yes:
                try:
                    self.close()
                except Exception:
                    pass
                xbmc.executebuiltin("ReloadSkin()")
                return True
        except Exception:
            _log("subtitle_fontxml_reload_prompt_failed value=%s reason=%s\n%s" % (value, reason, traceback.format_exc()), xbmc.LOGWARNING)
        return False


    def _position_guide_top_for_step(self, step):
        step = max(0, min(len(POSITION_STEPS) - 1, int(step)))
        key, label, margin = POSITION_STEPS[step]
        try:
            margin = float(margin)
        except Exception:
            margin = 4.95
        # v1083: do not use OSD-safe coordinates.  The guide must model Kodi's
        # actual manual subtitle renderer position.  Kodi stores vertical margin
        # as a percentage, so derive the y coordinate from the same margin value
        # that is sent to subtitles.marginvertical.  The OSD may overlap the
        # lowest positions, but moving the guide above the OSD is a visual trick
        # and no longer reflects the real subtitle location.
        skin_h = 1080.0
        guide_h = 92.0
        bottom_anchor = 1035.0
        # v1088: Kodi's manual subtitle margin is a percentage setting, but it
        # does not translate to the full 760px XML travel range that v1086 used.
        # The log shows Kodi accepted margin=40.00 while the XML guide was sent
        # to top=335; visually that over-shoots the real subtitle renderer more
        # and more as the position goes upward.  Use a renderer-calibrated travel
        # range of 500px, so guide movement follows the real renderer slope.
        travel = 500.0
        top = int(round(bottom_anchor - guide_h - ((margin / 50.0) * travel)))
        if top < 120:
            top = 120
        if top > 950:
            top = 950
        return top

    def _log_position_guide_state(self, reason="sync"):
        if self.mode != "position_adjust":
            return
        try:
            step = max(0, min(len(POSITION_STEPS) - 1, int(self.position_step)))
        except Exception:
            step = 0
        key, label, margin = POSITION_STEPS[step]
        top = self._position_guide_top_for_step(step)
        _log("position_guide_state step=%d key=%s label=%s margin=%.2f top=%d xml_mode=step_visible reason=%s" % (step, key, label, float(margin), top, reason))

    def _now_ms(self):
        try:
            return int(time.time() * 1000)
        except Exception:
            return 0

    def _refresh_tabs(self):
        # The XML expresses active tab state with Window.Property(PlexKM.Subtitle.ActiveTab).
        # Earlier code tried to update non-existent tab control ids 5201~5205, which
        # produced noisy "Non-Existent Control" exceptions and obscured the real
        # position-adjust event order in the log.  Do not touch missing controls.
        return

    def _add(self, ctrl, label, row_type, value="", selected=False):
        item = xbmcgui.ListItem(label)
        item.setProperty("row_type", row_type)
        item.setProperty("value", str(value))
        if selected: item.setProperty("selected", "1")
        ctrl.addItem(item)

    def _manual_internal_from_window(self):
        try:
            win = xbmcgui.Window(10000)
            if (win.getProperty("PlexKM.CurrentSubtitle.Source") or "") != "internal":
                return -1, ""
            idx = int(win.getProperty("PlexKM.CurrentSubtitle.Index") or "-1")
            return idx, (win.getProperty("PlexKM.CurrentSubtitle.Label") or "")
        except Exception:
            return -1, ""

    def _active_subtitle_source(self):
        try:
            win = xbmcgui.Window(10000)
            src = win.getProperty("PlexKM.CurrentSubtitle.Source") or ""
            if src:
                return src
        except Exception:
            pass
        try:
            if getattr(self, "manual_internal_index", -1) >= 0:
                return "internal"
            if getattr(self, "current_external_url", ""):
                return "external"
        except Exception:
            pass
        return "unknown"

    def _populate_simple_settings_button(self):
        # v1070: settings is opened by Right key from the language list.
        # The old inline side chip is no longer populated.
        try:
            ctrl = self.getControl(self.setting_list_id)
            try: ctrl.reset()
            except Exception: pass
        except Exception:
            pass

    def _populate_simple(self):
        self._compute_simple_layout()
        ctrl = self.getControl(self.simple_list_id)
        try: ctrl.reset()
        except Exception: pass

        # v1025: language list and global subtitle settings are separated.
        # "자막 설정" is an inline side chip reached from the language row by Right.
        self._add(ctrl, "끄기", "subtitle", "-1", selected=not self.subs_visible)

        used = {}
        selected_pos = 0
        korean_pos = -1
        manual_internal_idx, manual_internal_label = self._manual_internal_from_window()
        if manual_internal_idx >= 0 and self.current_index < 0:
            self.current_index = manual_internal_idx
        for idx, stream in enumerate(self.streams):
            row_pos = idx + 1
            actual_idx = _stream_actual_index(stream, idx)
            is_korean = _is_korean(stream)
            if is_korean and korean_pos < 0:
                korean_pos = row_pos
            ext_url = _stream_external_url(stream)
            if ext_url:
                # If the user manually selected an internal stream, never let a
                # stale current_external_url make the Korean external row appear
                # selected again.
                selected = bool(self.subs_visible and manual_internal_idx < 0 and ext_url == (getattr(self, "current_external_url", "") or getattr(self, "_pending_external_default_url", "") or ""))
            else:
                selected = bool(self.subs_visible and (actual_idx == self.current_index or (manual_internal_idx >= 0 and actual_idx == manual_internal_idx)))
            if selected:
                selected_pos = row_pos
            value = ("plex_external::" + ext_url) if ext_url else str(actual_idx)
            self._add(ctrl, _label(stream, idx, used), "subtitle", value, selected=selected)

        self._populate_simple_settings_button()

        # Root fix v1102: Korean fallback/highlight is allowed only during initial
        # default policy.  Once the user manually selects a row, the UI must stay
        # on the selected row and must not jump back to Korean external.
        manual_mode = False
        try:
            manual_mode = (xbmcgui.Window(10000).getProperty("PlexKM.CurrentSubtitle.Manual") or "") == "1"
        except Exception:
            manual_mode = False
        visual_default_checked = False
        if selected_pos == 0 and korean_pos >= 0 and manual_internal_idx < 0 and not manual_mode:
            selected_pos = korean_pos
            # v1277: Korean subtitle is the default row whenever available,
            # external first then internal, regardless of Kodi's initial visible flag.
            try:
                ctrl.getListItem(0).setProperty("selected", "0")
            except Exception:
                pass
            try:
                ctrl.getListItem(korean_pos).setProperty("selected", "1")
                visual_default_checked = True
            except Exception:
                pass
        self._simple_selected_pos = selected_pos
        try: ctrl.selectItem(selected_pos)
        except Exception: pass
        _log("simple_rows_added streams=%d language_rows=%d selected_pos=%d korean_pos=%d manual_internal_idx=%d manual_mode=%s visual_default_checked=%s fixed_settings_button=1 labels=source_codec" % (len(self.streams), len(self.streams) + 1, selected_pos, korean_pos, manual_internal_idx, "1" if manual_mode else "0", "1" if visual_default_checked else "0"))

    def _advanced_list_id(self, tab=None):
        tab = tab or getattr(self, "current_tab", "size")
        try:
            return int(ADV_LIST_IDS.get(tab, ADV_LIST_ID))
        except Exception:
            return ADV_LIST_ID

    def _advanced_list_ids(self):
        try:
            return set(int(v) for v in ADV_LIST_IDS.values())
        except Exception:
            return set([ADV_LIST_ID])

    def _populate_advanced(self, keep_focus=True):
        # v1135: option-list focus and tab-header focus must be visually separate.
        # Populating or repopulating rows always means the real focus returns to
        # the option list, so keep the tab highlight OFF until the user presses Up
        # from the first option row.
        self.focus_tab = self.current_tab if self.current_tab in ADV_TABS else ADV_TABS[0]
        self._sync_window_properties()
        self._refresh_tabs()
        ctrl = self.getControl(self._advanced_list_id())
        try: ctrl.reset()
        except Exception: pass
        pos = 0
        if self.current_tab == "size": pos = self._populate_options(ctrl, "size", SIZE_OPTIONS, _get_setting("pkm_subtitle_size", "normal"))
        elif self.current_tab == "style": pos = self._populate_options(ctrl, "style", STYLE_OPTIONS, _get_setting("pkm_subtitle_style", "default"))
        elif self.current_tab == "position": pos = self._populate_position_tab(ctrl)
        elif self.current_tab == "font": pos = self._populate_options(ctrl, "font", FONT_OPTIONS, _normalize_font_key(_get_setting("pkm_subtitle_font", "default")))
        elif self.current_tab == "sync": pos = self._populate_sync_tab(ctrl)
        try: ctrl.selectItem(pos)
        except Exception: pass
        try:
            if self.current_tab == "size": self.advanced_row_count = len(SIZE_OPTIONS)
            elif self.current_tab == "position": self.advanced_row_count = 3
            elif self.current_tab == "style": self.advanced_row_count = len(STYLE_OPTIONS)
            elif self.current_tab == "font": self.advanced_row_count = len(FONT_OPTIONS)
            elif self.current_tab == "sync": self.advanced_row_count = 3
            else: self.advanced_row_count = 0
        except Exception:
            self.advanced_row_count = 0
        # v1138: remember the selected row at populate time. Kodi can move the
        # focused row before WindowXML.onAction sees the key. Without this, an Up
        # from row 1 to row 0 is mistaken as "Up from first row" and jumps to the
        # tab header, making the first style option (기본) impossible to select.
        self._advanced_last_tab = self.current_tab
        self._advanced_last_pos = pos
        _log("advanced_options_populated tab=%s selected_pos=%s row_count=%s current_size=%s options=%s no_wrap=1 xml_navigation_only=1" % (self.current_tab, pos, self.advanced_row_count, _get_setting("pkm_subtitle_size", "normal"), ",".join([o[0] for o in SIZE_OPTIONS]) if self.current_tab == "size" else ""))
        # v1071: After applying a Kodi subtitle setting, focus could remain on a
        # hidden/stale control while the advanced panel is still visible.  Keep
        # focus anchored to the real option list so Up/Down/Select keep working.
        if keep_focus:
            self._focus_list_position(self._advanced_list_id(), pos, reason="subtitle_advanced_populate_selected_row")

    def _populate_options(self, ctrl, row_type, options, current):
        pos = 0
        for idx, (key, label, settings) in enumerate(options):
            if row_type == "font" and key == "cinema" and not _font_exists("cinema"):
                label = label + " (파일 필요)"
            selected = key == current
            if selected: pos = idx
            self._add(ctrl, label, row_type, key, selected=selected)
        return pos

    def _populate_position_tab(self, ctrl):
        self.position_step = self._current_position_step()
        self._add(ctrl, "위치 조정 시작", "position_adjust", "start", selected=True)
        self._add(ctrl, "현재 위치: %s" % self._position_label(), "position_info", str(self.position_step), selected=False)
        self._add(ctrl, "기본값으로 복귀", "position_reset", "reset", selected=False)
        return 0

    def _populate_sync_tab(self, ctrl):
        self.subtitle_sync_ms = self._current_subtitle_sync_ms()
        self._sync_window_properties()
        self._add(ctrl, "싱크 조정 시작", "sync_adjust", "start", selected=True)
        self._add(ctrl, "현재: %s" % self._subtitle_sync_label(), "sync_info", str(self.subtitle_sync_ms), selected=False)
        self._add(ctrl, "기본값으로 복귀", "sync_reset", "0", selected=False)
        return 0

    def _set_position_step_preview(self, step, reason=""):
        step = max(0, min(len(POSITION_STEPS) - 1, int(step)))
        key, label, margin = POSITION_STEPS[step]
        self.position_step = step
        # v1080 root fix: make the adjustment preview and final playback use the
        # same Kodi renderer path.  Earlier PKM moved only an XML sample overlay,
        # then saved Kodi's subtitles.marginvertical separately.  That can never
        # be pixel-perfect because Kodi renders real subtitles with its own font,
        # line-height, video viewport and alignment math.  Apply Kodi settings on
        # every preview step, so what the user sees while adjusting is exactly the
        # real subtitle position that will remain after saving.
        kodi_apply = self._apply_position_setting_direct(step, reason="preview_%s" % (reason or "move"))
        if kodi_apply:
            self._set_native_position_state(step, reason="preview_%s" % (reason or "move"))
        self._sync_window_properties()
        _log("position_live_preview_step step=%d key=%s label=%s margin=%.2f kodi_apply=%s guide_overlay=1 sample_overlay=0 reason=%s" % (step, key, label, float(margin), "1" if kodi_apply else "0", reason))

    def _apply_position_step(self, step, persist=False, reason="", old_step=None):
        step = max(0, min(len(POSITION_STEPS) - 1, int(step)))
        key, label, margin = POSITION_STEPS[step]
        self.position_step = step
        _set_setting("pkm_subtitle_position", key)
        kodi_apply = False
        prev_step = self._native_position_state(default=self.position_step if old_step is None else old_step)
        if persist:
            _set_setting("pkm_subtitle_position_step", str(step))
            kodi_apply = self._apply_position_setting_direct(step, reason=reason or "persist")
            if kodi_apply:
                self._set_native_position_state(step, reason=reason or "persist")
        self._sync_window_properties()
        _log("position_step_saved step=%d key=%s label=%s margin=%.2f persist=%s kodi_apply=%s old_step=%s reason=%s native_tracked=%s" % (
            step, key, label, float(margin), "1" if persist else "0", "1" if kodi_apply else "0", str(prev_step), reason, self._native_position_state(default=step)))

    def _selected_advanced_pos(self):
        try:
            return int(self.getControl(self._advanced_list_id()).getSelectedPosition())
        except Exception:
            return 0

    # v1140: Advanced-menu navigation is Kodi XML only.
    # All legacy Python tab-focus movement helpers were removed on purpose.

    def _player_speed(self):
        try:
            res = _jsonrpc("Player.GetProperties", {"playerid": 1, "properties": ["speed"]})
            return int(((res or {}).get("result") or {}).get("speed", 0))
        except Exception:
            return 0

    def _is_player_paused(self):
        try:
            return bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            return self._player_speed() == 0

    def _pause_for_settings(self):
        # v1103: Do not force-pause during subtitle language/settings UI.
        # The real subtitle renderer needs live playback so the user can confirm
        # the selected internal/external subtitle while a cue is spoken.
        try:
            _log("settings_pause_skip reason=live_subtitle_preview paused=%s" % ("1" if self._is_player_paused() else "0"))
        except Exception:
            pass
        self._pkm_paused_for_settings = False

    def _ensure_paused_for_settings(self, reason=""):
        # v1103: no pause reassert.  Keep the current player state untouched.
        try:
            _log("settings_pause_reassert_skip reason=%s mode=%s paused=%s" % (reason, self.mode, "1" if self._is_player_paused() else "0"))
        except Exception:
            pass

    def _resume_after_settings_if_needed(self):
        # v1103: since we no longer pause for settings, there is nothing to resume.
        self._pkm_paused_for_settings = False

    def _play_for_sync_adjust(self, reason=""):
        # Sync adjustment is the one mode where playback must be running.
        try:
            if xbmc.Player().isPlayingVideo() and self._is_player_paused():
                xbmc.Player().pause()
                xbmc.sleep(80)
                _log("sync_adjust_play applied=1 reason=%s paused=%s" % (reason, "1" if self._is_player_paused() else "0"))
            else:
                _log("sync_adjust_play applied=0 reason=%s paused=%s" % (reason, "1" if self._is_player_paused() else "0"))
        except Exception:
            _log("sync_adjust_play_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)

    def _enter_advanced(self):
        self.mode = "advanced"
        self.current_tab = "size"
        self.focus_tab = self.current_tab
        self._sync_window_properties()
        self._populate_advanced()
        try: self.setFocusId(self._advanced_list_id())
        except Exception: pass
        _log("advanced_opened tab=size pause_hold=0 live_preview=1")

    def _back_to_simple(self):
        # Do not resume here. If the user entered subtitle settings, playback must
        # remain paused until the whole subtitle selection window is closed.
        self.mode = "simple"
        self._sync_window_properties()
        self._populate_simple()
        self._safe_focus_simple(reason="simple_repopulate")
        _log("advanced_closed_to_simple")

    def _ensure_real_subtitle_visible(self):
        # kept for possible future use; current v1029 position adjustment returns
        # to the PKM sample subtitle preview flow requested by the user.
        try:
            if self.streams:
                if self.current_index < 0 or self.current_index >= len(self.streams):
                    k = -1
                    for idx, stream in enumerate(self.streams):
                        if _is_korean(stream):
                            k = idx; break
                    if k < 0:
                        k = 0
                    xbmc.Player().setSubtitleStream(k)
                    self.current_index = k
                xbmc.Player().showSubtitles(True)
                self.subs_visible = True
                _log("real_subtitle_visible_for_position index=%d" % self.current_index)
        except Exception:
            _log("real_subtitle_visible_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _enter_position_adjust(self):
        saved_step = self._current_position_step()
        self._ensure_saved_position_applied_to_player("enter_position_adjust")
        self.position_step_before_adjust = self._native_position_state(default=saved_step)
        self.position_step = self.position_step_before_adjust
        self.mode = "position_adjust"
        self.current_tab = "position"
        now = self._now_ms()
        self._position_adjust_enter_ms = now
        self._position_adjust_ignore_select_until_ms = now + 450
        self._set_position_step_preview(self.position_step, reason="enter")
        self._sync_window_properties()
        _log("position_adjust_opened mode=position_adjust live_renderer_preview=1 sample_overlay=0 step=%d sample_position=%s saved_step=%d native_step=%d ignore_select_until_ms=%d" % (self.position_step, self._sample_position_key(), saved_step, self.position_step_before_adjust, self._position_adjust_ignore_select_until_ms))

    def _exit_position_adjust(self, save=False):
        if save:
            self._apply_position_step(self.position_step, persist=True, reason="save", old_step=self.position_step_before_adjust)
            _log("position_adjust_saved step=%d old_step=%d" % (self.position_step, self.position_step_before_adjust))
        else:
            # Revert the live Kodi renderer preview as well as PKM state.
            self._apply_position_setting_direct(self.position_step_before_adjust, reason="cancel_revert_live")
            self._set_native_position_state(self.position_step_before_adjust, reason="cancel_revert_live")
            self._apply_position_step(self.position_step_before_adjust, persist=False, reason="cancel_revert")
            self.position_step = self.position_step_before_adjust
            _log("position_adjust_cancelled revert_step=%d" % self.position_step)
        self._position_adjust_ignore_select_until_ms = 0
        self.mode = "advanced"
        self.current_tab = "position"
        self._populate_advanced()
        try: self.setFocusId(self._advanced_list_id())
        except Exception: pass

    def _enter_sync_adjust(self):
        self.subtitle_sync_before_adjust = self._current_subtitle_sync_ms()
        self.subtitle_sync_ms = self.subtitle_sync_before_adjust
        self.mode = "sync_adjust"
        self.current_tab = "sync"
        # v1152: the Enter/Select that clicks "싱크 조정 시작" is delivered once
        # more to the new sync-adjust mode a few milliseconds later.  That stale
        # ACTION_SELECT_ITEM immediately saved and closed the overlay.  Keep
        # movement ownership unchanged (Kodi XML for menus; Python only inside
        # adjust mode) and ignore only that stale first select.
        now = self._now_ms()
        self._sync_adjust_enter_ms = now
        self._sync_adjust_ignore_select_until_ms = now + 800
        self._sync_adjust_input_seen = False
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        self._play_for_sync_adjust("enter_sync_adjust")
        self._sync_window_properties()
        _log("subtitle_sync_adjust_opened ms=%d play_exception=1 ignore_select_until_ms=%d first_select_guard=1" % (self.subtitle_sync_ms, self._sync_adjust_ignore_select_until_ms))

    def _exit_sync_adjust(self, save=False):
        self._sync_adjust_ignore_select_until_ms = 0
        self._sync_adjust_input_seen = False
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        if save:
            _set_setting("pkm_subtitle_sync_ms", str(self.subtitle_sync_ms))
            _log("subtitle_sync_adjust_saved ms=%d label=%s" % (self.subtitle_sync_ms, self._subtitle_sync_label()))
        else:
            delta = int(self.subtitle_sync_before_adjust) - int(self.subtitle_sync_ms)
            if delta:
                self._shift_subtitle_sync(delta, persist=False, reason="cancel_revert")
            self.subtitle_sync_ms = self.subtitle_sync_before_adjust
            _set_setting("pkm_subtitle_sync_ms", str(self.subtitle_sync_ms))
            _log("subtitle_sync_adjust_cancelled revert_ms=%d" % self.subtitle_sync_ms)
        self.mode = "advanced"
        self.current_tab = "sync"
        self._sync_window_properties()
        self._populate_advanced()
        try: self.setFocusId(self._advanced_list_id())
        except Exception: pass

    def _selected_simple_type(self):
        try:
            item = self.getControl(self.simple_list_id).getSelectedItem()
            return item.getProperty("row_type") or ""
        except Exception:
            return ""

    # v1140: Do not handle advanced-menu Up/Down/Left/Right in Python.
    # Kodi XML <onup>/<ondown>/<onleft>/<onright> is the single movement owner.

    def onAction(self, action):
        try: aid = action.getId()
        except Exception: aid = 0

        if self.mode == "sync_adjust":
            now = self._now_ms()
            try:
                elapsed = now - int(self._sync_adjust_enter_ms or 0) if now and self._sync_adjust_enter_ms else -1
            except Exception:
                elapsed = -1
            _log("subtitle_sync_adjust_action aid=%s ms=%d elapsed_ms=%d input_seen=%s guard_until=%d" % (aid, self.subtitle_sync_ms, elapsed, 1 if self._sync_adjust_input_seen else 0, self._sync_adjust_ignore_select_until_ms))
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                self._exit_sync_adjust(save=True); return
            if aid == ACTION_MOVE_RIGHT:
                self._sync_adjust_input_seen = True
                self._shift_subtitle_sync(-10, persist=False, reason="right_faster_10ms")
                self._flash_sync_arrow("right_fast"); return
            if aid == ACTION_MOVE_LEFT:
                self._sync_adjust_input_seen = True
                self._shift_subtitle_sync(10, persist=False, reason="left_slower_10ms")
                self._flash_sync_arrow("left_fast"); return
            if aid == ACTION_MOVE_UP:
                self._sync_adjust_input_seen = True
                self._shift_subtitle_sync(-100, persist=False, reason="up_faster_100ms")
                self._flash_sync_arrow("right_fast"); return
            if aid == ACTION_MOVE_DOWN:
                self._sync_adjust_input_seen = True
                self._shift_subtitle_sync(100, persist=False, reason="down_slower_100ms")
                self._flash_sync_arrow("left_fast"); return
            if aid == ACTION_SELECT_ITEM:
                if (not self._sync_adjust_input_seen) and now and self._sync_adjust_ignore_select_until_ms and now < self._sync_adjust_ignore_select_until_ms:
                    _log("subtitle_sync_adjust_select_ignored reason=enter_debounce elapsed_ms=%d ms=%d" % (elapsed, self.subtitle_sync_ms))
                    return
                self._exit_sync_adjust(save=True); return
            return

        if self.mode == "position_adjust":
            _log("position_adjust_action aid=%s step=%d sample_position=%s" % (aid, self.position_step, self._sample_position_key()))
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                self._exit_position_adjust(save=False); return
            if aid == ACTION_MOVE_UP:
                self._set_position_step_preview(self.position_step + 1, reason="move_up"); return
            if aid == ACTION_MOVE_DOWN:
                self._set_position_step_preview(self.position_step - 1, reason="move_down"); return
            if aid == ACTION_SELECT_ITEM:
                now = self._now_ms()
                if now and self._position_adjust_ignore_select_until_ms and now < self._position_adjust_ignore_select_until_ms:
                    _log("position_adjust_select_ignored reason=enter_debounce elapsed_ms=%d step=%d" % (now - self._position_adjust_enter_ms, self.position_step))
                    return
                self._exit_position_adjust(save=True); return
            return

        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            if self.mode == "advanced":
                self._back_to_simple(); return
            self.close(); return

        # v1070: In the simple subtitle popup, the bottom hint says
        # "방향키 오른쪽  자막설정" and Right opens settings directly.
        # The previous inline side chip is hidden to avoid the mid-line artifact.
        if self.mode == "simple" and aid == ACTION_MOVE_LEFT:
            # v1313: Do not close the popup with Left. Closing is Back-only.
            # If the detail-settings arrow has focus, Left only returns focus to
            # the subtitle list. Otherwise keep the current popup open.
            focus_id = 0
            try:
                focus_id = int(self.getFocusId())
            except Exception:
                focus_id = 0
            if focus_id == 5028:
                try:
                    self.setFocusId(self.simple_list_id)
                except Exception:
                    pass
            _log("simple_left_keep_open_back_only focus_id=%s" % focus_id)
            return

        if self.mode == "simple" and aid == ACTION_MOVE_RIGHT:
            # v1255: Right moves focus to the visible arrow button first.
            # Selecting the arrow opens the subtitle detail settings via onClick(5028).
            try:
                self.setFocusId(self.setting_list_id)
            except Exception:
                pass
            return

        # v1140: In advanced subtitle settings, movement is handled by Kodi XML only.
        # Python handles no advanced Up/Down/Left/Right navigation.

    def onClick(self, control_id):
        cid = int(control_id)
        # Root cause fix for position save: while the full-screen position
        # adjust overlay is active, Kodi can still emit onClick for the hidden
        # advanced list underneath.  That stale click selected "기본값으로 복귀"
        # and reset step=1 before ACTION_SELECT saved, so the chosen position was
        # lost.  In adjust modes, all clicks are handled only by onAction.
        if self.mode in ("position_adjust", "sync_adjust"):
            _log("adjust_mode_click_ignored mode=%s cid=%s step=%s" % (self.mode, cid, getattr(self, "position_step", "")))
            return
        valid_simple_ids = set(SIMPLE_LIST_IDS.values())
        valid_setting_ids = set(SETTING_LIST_IDS.values())
        if cid not in valid_simple_ids and cid not in valid_setting_ids and cid not in self._advanced_list_ids() and cid not in ADV_TAB_CONTROL_IDS: return
        if self.mode == "advanced" and cid in ADV_TAB_CONTROL_IDS:
            old = self.current_tab
            self.current_tab = ADV_TAB_CONTROL_IDS.get(cid, self.current_tab)
            self.focus_tab = self.current_tab
            self._populate_advanced(keep_focus=True)
            _log("advanced_tab_xml_click_commit old=%s new=%s cid=%s label=%s xml_navigation_only=1" % (old, self.current_tab, cid, ADV_TAB_LABELS.get(self.current_tab, self.current_tab)))
            return

        if self.mode == "advanced" and cid in self._advanced_list_ids():
            # v1134: When the tab header is active, Kodi may still emit a stale
            # onClick from the underlying option list before ACTION_SELECT commits
            # the tab.  Ignore list clicks in tab-focus mode.  Otherwise pressing
            # Enter on the "위치" tab applies the previous "작게" size row and
            # then the commit falls back to the size tab.
            # v1123: Advanced option rows are applied only by Kodi XML/onClick.
            # ACTION_SELECT is now pass-through only, so this is the one and only
            # apply path for size rows.  This restores the behavior that was stable
            # before the direct-select experiment.
            try:
                pos = self._selected_advanced_pos()
            except Exception:
                pos = -1
            try:
                item = self.getControl(self._advanced_list_id()).getSelectedItem()
            except Exception:
                item = None
            if not item:
                _log("advanced_onclick_empty cid=%s pos=%s tab=%s reason=v1123_xml_onclick_only" % (cid, pos, self.current_tab), xbmc.LOGWARNING)
                return
            typ = item.getProperty("row_type") or ""
            val = item.getProperty("value") or ""
            _log("advanced_onclick_select typ=%s value=%s pos=%s tab=%s reason=v1123_xml_onclick_only" % (typ, val, pos, self.current_tab))
            if typ == "position_adjust":
                self._enter_position_adjust(); return
            if typ == "position_reset":
                old_native = self._native_position_state(default=self.position_step)
                self.position_step = 1
                self._apply_position_step(1, persist=True, reason="reset", old_step=old_native)
                self._update_adjust_info_in_place("position", reason="position_reset_no_rebuild")
                return
            if typ == "sync_adjust":
                self._enter_sync_adjust(); return
            if typ == "sync_reset":
                delta = 0 - int(self.subtitle_sync_ms)
                if delta:
                    self._shift_subtitle_sync(delta, persist=True, reason="sync_reset")
                else:
                    _set_setting("pkm_subtitle_sync_ms", "0")
                    self._sync_window_properties()
                self.subtitle_sync_ms = 0
                self._update_adjust_info_in_place("sync", reason="sync_reset_no_rebuild")
                return
            if typ in ("size", "style", "position", "font", "sync"):
                self._select_option(typ, val)
                self._update_selected_rows_in_place(
                    self._advanced_list_id(), typ, val, reason="subtitle_option_apply_no_rebuild_%s" % typ
                )
                return
            _log("advanced_onclick_select_ignored typ=%s value=%s pos=%s tab=%s reason=v1123_xml_onclick_only" % (typ, val, pos, self.current_tab))
            return
        if cid in valid_setting_ids:
            self._enter_advanced(); return
        try: item = self.getControl(cid).getSelectedItem()
        except Exception: item = None
        if not item: return
        typ = item.getProperty("row_type") or ""
        val = item.getProperty("value") or ""
        if typ == "more":
            self._enter_advanced()
        elif typ == "subtitle":
            # Apply directly and mutate only the existing row checkmarks.  A full
            # reset/rebuild made the entire menu visibly shake after Enter.
            selected_label = item.getLabel()
            self._select_subtitle(val, selected_label)
            try:
                selected_pos = self._update_selected_rows_in_place(
                    self.simple_list_id, "subtitle", val, reason="subtitle_apply_no_rebuild"
                )
                if selected_pos < 0:
                    selected_pos = int(self.getControl(self.simple_list_id).getSelectedPosition())
                self._simple_selected_pos = selected_pos
                _log("simple_keep_open_after_select_no_rebuild label=%s value=%s pos=%s current_index=%s visible=%s" % (selected_label, val, selected_pos, self.current_index, "1" if self.subs_visible else "0"))
            except Exception:
                _log("simple_keep_open_after_select_failed label=%s value=%s\n%s" % (selected_label, val, traceback.format_exc()), xbmc.LOGWARNING)
        elif typ == "position_adjust":
            _log("position_adjust_click_enter row_value=%s focus=%s" % (val, cid))
            self._enter_position_adjust()
        elif typ == "position_reset":
            old_native = self._native_position_state(default=self.position_step)
            self.position_step = 1
            self._apply_position_step(1, persist=True, reason="reset", old_step=old_native)
            self._update_adjust_info_in_place("position", reason="position_reset_fallback_no_rebuild")
        elif typ == "sync_adjust":
            self._enter_sync_adjust()
        elif typ == "sync_reset":
            delta = 0 - int(self.subtitle_sync_ms)
            if delta:
                self._shift_subtitle_sync(delta, persist=True, reason="sync_reset")
            else:
                _set_setting("pkm_subtitle_sync_ms", "0")
                self._sync_window_properties()
            self.subtitle_sync_ms = 0
            self._update_adjust_info_in_place("sync", reason="sync_reset_fallback_no_rebuild")
        elif typ in ("size", "style", "position", "font", "sync"):
            self._select_option(typ, val)
            self._update_selected_rows_in_place(
                self._advanced_list_id(), typ, val, reason="subtitle_option_fallback_no_rebuild_%s" % typ
            )

    def _select_subtitle(self, value, label):
        self._manual_subtitle_select = True
        raw = str(value or "")
        is_external = raw.startswith("plex_external::")
        try: idx = int(raw or "-1") if not is_external else -2
        except Exception: idx = -1
        try:
            win = xbmcgui.Window(10000)
            if is_external:
                url = raw.split("::", 1)[1]
                xbmc.Player().setSubtitles(url)
                xbmc.Player().showSubtitles(True)
                self.current_index = -1
                self.manual_internal_index = -1
                self.manual_internal_label = ""
                self.current_external_url = url
                self.current_external_label = label or ""
                self.subs_visible = True
                try:
                    win.setProperty("PlexKM.CurrentSubtitle.Source", "external")
                    win.setProperty("PlexKM.CurrentSubtitle.Url", url)
                    win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                    win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                    win.clearProperty("PlexKM.PendingSubtitle.Url")
                    win.clearProperty("PlexKM.PendingSubtitle.Label")
                    win.clearProperty("PlexKM.PendingSubtitle.Source")
                except Exception:
                    pass
                _log("selected subtitle external=1 label=%s streams=%d visible=1" % (label, len(self.streams or [])))
            elif idx < 0:
                xbmc.Player().showSubtitles(False)
                self.current_index = -1
                self.manual_internal_index = -1
                self.manual_internal_label = ""
                self.current_external_url = ""
                self.current_external_label = ""
                self.subs_visible = False
                try:
                    win.setProperty("PlexKM.CurrentSubtitle.Source", "off")
                    win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                    win.clearProperty("PlexKM.CurrentSubtitle.Url")
                    win.clearProperty("PlexKM.CurrentSubtitle.Label")
                    win.clearProperty("PlexKM.PendingSubtitle.Url")
                    win.clearProperty("PlexKM.PendingSubtitle.Label")
                    win.clearProperty("PlexKM.PendingSubtitle.Source")
                except Exception:
                    pass
                _log("selected off visible=0")
            else:
                # Internal/muxed subtitle selection.  Apply the selected Kodi
                # stream directly.  Do not turn subtitles off first and do not
                # depend on a later fallback guard; the selected stream itself is
                # the source of truth.
                ok, verify_before_visible, verify_idx, verify_visible = _set_internal_subtitle_stream(idx, label or "")
                self.current_index = idx
                self.manual_internal_index = idx
                self.manual_internal_label = label or ""
                self.current_external_url = ""
                self.current_external_label = ""
                self._pending_external_default_url = ""
                self._pending_external_default_label = ""
                self.subs_visible = True
                try:
                    win.setProperty("PlexKM.CurrentSubtitle.Source", "internal")
                    win.setProperty("PlexKM.CurrentSubtitle.Index", str(idx))
                    win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                    win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                    win.clearProperty("PlexKM.CurrentSubtitle.Url")
                    win.clearProperty("PlexKM.PendingSubtitle.Url")
                    win.clearProperty("PlexKM.PendingSubtitle.Label")
                    win.clearProperty("PlexKM.PendingSubtitle.Source")
                except Exception:
                    pass
                _log("selected subtitle internal=1 index=%d label=%s streams=%d verify_before_visible=%s verify_index=%s visible=%s keep_open=1 root_apply=1" % (idx, label, len(self.streams or []), verify_before_visible, verify_idx, "1" if self.subs_visible else "0"))
        except Exception:
            _log("select_subtitle_failed raw=%s label=%s\n%s" % (raw[:120], label, traceback.format_exc()), xbmc.LOGERROR)

    def _font_refresh_url(self, url, value=""):
        """Return a cache-busted URL only when it is safe for HTTP subtitle streams."""
        try:
            raw = str(url or "")
            if not raw.lower().startswith(("http://", "https://")):
                return raw
            sep = "&" if "?" in raw else "?"
            return raw + sep + "pkm_font_refresh=" + str(int(time.time() * 1000)) + "_" + str(value or "font")
        except Exception:
            return url

    def _refresh_active_subtitle_after_font_apply(self, value="", reason=""):
        """v1173: make the chosen font visible on the actual subtitle renderer.

        Changing subtitles.fontname through Settings.SetSettingValue is not
        enough on this Kodi/libass path; the active subtitle track may keep the
        renderer that was created before the setting changed.  Refresh only the
        currently active subtitle source and keep subtitles visible.  Do not
        seek and do not touch playback URL/handoff.
        """
        try:
            player = xbmc.Player()
            if not player.isPlayingVideo():
                _log("subtitle_font_renderer_refresh_skip value=%s reason=%s state=not_playing" % (value, reason), xbmc.LOGWARNING)
                return False
        except Exception:
            _log("subtitle_font_renderer_refresh_skip value=%s reason=%s state=player_check_failed" % (value, reason), xbmc.LOGWARNING)
            return False

        try:
            win = xbmcgui.Window(10000)
        except Exception:
            win = None

        source = ""
        url = ""
        label = ""
        idx = -1
        try:
            if win:
                source = win.getProperty("PlexKM.CurrentSubtitle.Source") or ""
                url = win.getProperty("PlexKM.CurrentSubtitle.Url") or ""
                label = win.getProperty("PlexKM.CurrentSubtitle.Label") or ""
                try:
                    idx = int(win.getProperty("PlexKM.CurrentSubtitle.Index") or "-1")
                except Exception:
                    idx = -1
        except Exception:
            pass

        if not url:
            url = getattr(self, "current_external_url", "") or ""
        if not label:
            label = getattr(self, "current_external_label", "") or getattr(self, "manual_internal_label", "") or ""
        if idx < 0:
            try:
                if getattr(self, "manual_internal_index", -1) >= 0:
                    idx = int(self.manual_internal_index)
                elif getattr(self, "current_index", -1) >= 0:
                    idx = int(self.current_index)
                else:
                    idx = _current_idx()
            except Exception:
                idx = -1

        before_visible = _subs_visible()
        before_py = _current_idx()
        before_rpc = _jsonrpc_current_subtitle_index()

        try:
            if url and (source in ("", "external") or str(url).startswith(("http://", "https://", "special://", "smb://", "nfs://", "file://"))):
                # v1175: Kodi/libass may keep the previous external subtitle renderer
                # when only the same subtitle URL is set again.  Hide the subtitle,
                # re-open an HTTP subtitle URL with a harmless cache-buster, then
                # show it again.  Local/special paths are left untouched.
                refresh_url = self._font_refresh_url(url, value=value)
                cache_busted = (str(refresh_url) != str(url))
                try:
                    xbmc.Player().showSubtitles(False)
                except Exception:
                    pass
                xbmc.sleep(90)
                xbmc.Player().setSubtitles(refresh_url)
                xbmc.sleep(180)
                xbmc.Player().showSubtitles(True)
                xbmc.sleep(160)
                self.current_index = -1
                self.manual_internal_index = -1
                self.current_external_url = url
                self.current_external_label = label or ""
                self.subs_visible = True
                try:
                    if win:
                        win.setProperty("PlexKM.CurrentSubtitle.Source", "external")
                        win.setProperty("PlexKM.CurrentSubtitle.Url", url)
                        win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                        win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                except Exception:
                    pass
                _log("subtitle_font_renderer_refresh source=external value=%s ok=1 visible_before=%s visible_after=%s label=%s url=1 cache_bust=%s hide_reopen=1 reason=%s" % (value, "1" if before_visible else "0", "1" if _subs_visible() else "0", label or "", "1" if cache_busted else "0", reason))
                return True

            if idx >= 0:
                ok, after_py, after_rpc, visible = _set_internal_subtitle_stream(idx, label or "")
                try:
                    xbmc.Player().showSubtitles(True)
                except Exception:
                    pass
                self.current_index = idx
                self.manual_internal_index = idx
                self.manual_internal_label = label or ""
                self.current_external_url = ""
                self.current_external_label = ""
                self.subs_visible = True
                try:
                    if win:
                        win.setProperty("PlexKM.CurrentSubtitle.Source", "internal")
                        win.setProperty("PlexKM.CurrentSubtitle.Index", str(idx))
                        win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                        win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                        win.clearProperty("PlexKM.CurrentSubtitle.Url")
                except Exception:
                    pass
                _log("subtitle_font_renderer_refresh source=internal value=%s ok=%s index=%s before_py=%s before_rpc=%s after_py=%s after_rpc=%s visible_before=%s visible_after=%s reason=%s" % (value, "1" if ok else "0", idx, before_py, before_rpc, after_py, after_rpc, "1" if before_visible else "0", "1" if _subs_visible() else "0", reason))
                return bool(ok)

            if before_visible:
                try:
                    xbmc.Player().showSubtitles(True)
                except Exception:
                    pass
                self.subs_visible = True
                _log("subtitle_font_renderer_refresh source=visible_only value=%s ok=1 before_py=%s before_rpc=%s reason=%s" % (value, before_py, before_rpc, reason))
                return True

            _log("subtitle_font_renderer_refresh_skip value=%s reason=%s source=%s visible=0 index=%s url=%s" % (value, reason, source or "", idx, "1" if url else "0"), xbmc.LOGWARNING)
            return False
        except Exception:
            _log("subtitle_font_renderer_refresh_failed value=%s source=%s index=%s url=%s reason=%s\n%s" % (value, source or "", idx, "1" if url else "0", reason, traceback.format_exc()), xbmc.LOGERROR)
            return False

    def _select_option(self, typ, value):
        # v1172: font is now an enabled advanced option.  v1171 exposed the
        # font tab in XML but left the old v1145 scope guard here, so selecting
        # legacy font keys or "시네마 폰트" were immediately rejected before the
        # font-apply branch below could run.
        if typ not in ("size", "style", "position", "sync", "font"):
            _log("subtitle_option_disabled typ=%s value=%s reason=unknown_option_type" % (typ, value), xbmc.LOGWARNING)
            return

        if typ == "size":
            setting_key = "pkm_subtitle_size"
            settings = {}
            for key, label, sopt in SIZE_OPTIONS:
                if key == value:
                    settings = dict(sopt or {})
                    break
            _set_setting(setting_key, value)
            # v1402: size changes must not write size keys into the SampleFont property.
            self._sync_window_properties()
            active_source = self._active_subtitle_source()
            _log("subtitle_option_state_update typ=size value=%s active_source=%s real_settings=%s sample_size=%s size_setting_id=subtitles.fontsize" % (value, active_source, settings, _get_setting("pkm_subtitle_size", "normal")))

            if settings:
                ok = _apply_settings(settings)
                effective = _get_kodi_setting_value("subtitles.fontsize")
                effective_key = _fontsize_to_size_key(effective)
                if effective_key != value:
                    _set_setting(setting_key, effective_key)
                _log("subtitle_fontsize_apply_done value=%s requested=%s effective=%s effective_key=%s ok_any=%s active_source=%s no_stream_touch=1" % (value, settings.get("subtitles.fontsize"), effective, effective_key, "1" if ok else "0", active_source), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            else:
                _log("subtitle_fontsize_apply_skip value=%s reason=no_size_settings" % value, xbmc.LOGWARNING)
            self._sync_window_properties()
            _log("option_selected_no_rebuild typ=size value=%s focus=%s" % (value, self._advanced_list_id()))
            return


        if typ == "style":
            setting_key = "pkm_subtitle_style"
            settings = {}
            for key, label, sopt in STYLE_OPTIONS:
                if key == value:
                    settings = dict(sopt or {})
                    break
            _set_setting(setting_key, value)
            active_source = self._active_subtitle_source()
            if value == "default":
                _log("subtitle_style_default_full_reset begin settings=%s first_row_selectable=1" % settings)
            _log("subtitle_style_state_update typ=style value=%s active_source=%s real_settings=%s sample_style=%s settings_only=1 no_stream_touch=1" % (value, active_source, settings, _get_setting("pkm_subtitle_style", "default")))
            if settings:
                ok = _apply_settings(settings)
                _log("subtitle_style_apply_done value=%s ok_any=%s active_source=%s no_stream_touch=1" % (value, "1" if ok else "0", active_source), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
            else:
                _log("subtitle_style_apply_skip value=%s reason=no_style_settings" % value, xbmc.LOGWARNING)
            self._sync_window_properties()
            _log("option_selected_no_rebuild typ=style value=%s focus=%s" % (value, self._advanced_list_id()))
            return

        if typ == "position":
            old_native = self._native_position_state(default=self.position_step)
            step = self._position_step_from_value(value)
            self._apply_position_step(step, persist=True, reason="option_select", old_step=old_native)
            self._update_adjust_info_in_place("position", reason="position_option_select_no_rebuild")
            _log("subtitle_position_apply_done value=%s step=%d label=%s old_step=%s focus=%s settings_only=1 no_list_rebuild=1" % (value, step, self._position_label(step), old_native, self._advanced_list_id()))
            return

        if typ == "font":
            setting_key = "pkm_subtitle_font"
            settings = {}
            for key, label, sopt in FONT_OPTIONS:
                if key == value:
                    settings = dict(sopt or {})
                    break
            _set_setting(setting_key, value)
            # v1402: the sample text is a WindowXML label, not Kodi's real subtitle renderer.
            # Switch the XML sample font immediately when the font row is selected.
            self._set_sample_font_preview_property(value, reason="font_option_select_pre_apply_v1402")
            active_source = self._active_subtitle_source()
            if value == "cinema" and not _font_exists("cinema"):
                _log("subtitle_font_cinema_file_not_found value=%s source_filename=%s renderer_filename=%s renderer_setting=%s path=special://home/media/Fonts/%s apply_anyway=1" % (value, PKM_CINEMA_FONT_FILENAME, PKM_CINEMA_FONT_RENDERER_FILENAME, PKM_CINEMA_FONT_RENDERER_SETTING, PKM_CINEMA_FONT_RENDERER_FILENAME), xbmc.LOGWARNING)
            if settings:
                ok = _apply_settings(settings)
                effective_font = _get_kodi_setting_value("subtitles.fontname")
                refresh_ok = self._refresh_active_subtitle_after_font_apply(value=value, reason="font_option_select")
                _log("subtitle_font_apply_done value=%s settings=%s effective=%s ok_any=%s active_source=%s renderer_refresh=%s immediate=1 stream_visible_keep=1" % (value, settings, effective_font, "1" if ok else "0", active_source, "1" if refresh_ok else "0"), xbmc.LOGINFO if (ok and refresh_ok) else xbmc.LOGWARNING)
            else:
                _log("subtitle_font_apply_skip value=%s reason=no_font_settings" % value, xbmc.LOGWARNING)
            self._sync_window_properties()
            self._maybe_prompt_fontxml_reload(value, reason="font_option_select_post_apply")
            _log("option_selected_no_rebuild typ=font value=%s focus=%s" % (value, self._advanced_list_id()))
            return

def open_subtitle_select():
    try:
        if not xbmc.Player().isPlayingVideo(): return False
        if not _streams(): return False
        win = PKMSubtitleSelectWindow(XML_NAME, _addon_path(), "Default", "1080i")
        win.doModal(); del win
        return True
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
