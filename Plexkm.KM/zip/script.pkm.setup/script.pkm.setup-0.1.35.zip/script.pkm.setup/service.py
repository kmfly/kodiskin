# -*- coding: utf-8 -*-
"""PlexKM 설치 도우미 자동 실행 (0.1.31).

저장소에서 설치되면 Kodi가 이 서비스를 바로 시작한다.  처음 한 번만 도우미 화면을
열고, 이후에는 열지 않는다(다시 하려면 애드온에서 직접 실행).
이미 설정이 끝난 환경(PlexKM 동기화 완료 / 취향 저장됨)에서는 열지 않는다.
"""
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
_PATH = ADDON.getAddonInfo("path")
if _PATH not in sys.path:
    sys.path.insert(0, _PATH)
PKM_ID = "plugin.video.km"


def _log(msg):
    xbmc.log("[script.pkm.setup] " + msg, xbmc.LOGINFO)


def _profile(addon_id):
    return xbmcvfs.translatePath("special://profile/addon_data/%s/" % addon_id)


def _own_profile():
    p = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


def _already_launched():
    return os.path.exists(os.path.join(_own_profile(), "autolaunch.json"))


def _mark_launched():
    try:
        with open(os.path.join(_own_profile(), "autolaunch.json"), "w", encoding="utf-8") as f:
            json.dump({"launched": 1}, f)
    except Exception:
        pass


def _setup_already_done():
    try:
        if os.path.exists(os.path.join(_profile(PKM_ID), "pkm_taste.json")):
            return True
        with open(os.path.join(_profile(PKM_ID), "state.json"), "r", encoding="utf-8") as f:
            st = json.load(f)
        return bool(st.get("initial_setup_completed_v2562") or st.get("initial_sync_done"))
    except Exception:
        return False


def main():
    mon = xbmc.Monitor()
    # 도우미가 비정상 종료돼 알림 설정이 꺼진 채 남았으면 되돌린다.
    try:
        if not xbmcgui_open():
            from resources.lib import notify_mute
            notify_mute.restore()
    except Exception:
        pass
    if _already_launched() or _setup_already_done():
        return
    # 설치 완료 알림·진행창이 닫히고 화면이 안정될 때까지 기다린다.
    if mon.waitForAbort(4.0):
        return
    for _ in range(60):  # 최대 약 30초: 팝업·재생이 끝날 때까지
        if mon.abortRequested():
            return
        busy = (xbmc.getCondVisibility("Window.IsVisible(yesnodialog)")
                or xbmc.getCondVisibility("Window.IsVisible(progressdialog)")
                or xbmc.getCondVisibility("Window.IsVisible(busydialog)")
                or xbmc.getCondVisibility("Window.IsVisible(busydialognocancel)")
                or xbmc.getCondVisibility("Window.IsVisible(addoninformation)")
                or xbmc.getCondVisibility("Window.IsVisible(addonsettings)")
                or xbmc.getCondVisibility("Player.HasMedia"))
        if not busy:
            break
        if mon.waitForAbort(0.5):
            return
    if xbmcgui_open():
        return
    _mark_launched()
    _log("자동 실행: 설치 도우미 열기")
    xbmc.executebuiltin("RunScript(script.pkm.setup)")


def xbmcgui_open():
    try:
        import xbmcgui
        return bool(xbmcgui.Window(10000).getProperty("PlexKM.SetupHelperOpen"))
    except Exception:
        return False


if __name__ == "__main__":
    main()
