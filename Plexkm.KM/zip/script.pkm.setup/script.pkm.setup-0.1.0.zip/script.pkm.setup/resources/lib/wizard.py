# -*- coding: utf-8 -*-
"""PKM 설치 도우미 - 6 pages: 시작 / 구성 설치 / 선택 키 / 서버·라이브러리 / 취향 / 완료."""
import json
import os
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import posters
from resources.lib.taste_data import CATEGORIES

ADDON = xbmcaddon.Addon()
PKM_ID = "plugin.video.km"
SKIN_ID = "skin.plex.km"
ACTION_BACK = (9, 10, 92, 216, 247, 257, 275)
ACTION_UP = 3

STEPS = ["시작", "구성 설치", "선택 키 입력", "서버·라이브러리", "취향 선택", "완료"]
TITLES = [
    ("PKM 설치 도우미", "몇 가지 정보만 입력하면 나머지는 자동으로 설치하고 설정합니다."),
    ("필요한 구성을 설치합니다", "필요한 애드온을 차례로 설치합니다. 확인 창이 나오면 '예'를 눌러 주세요."),
    ("선택 키를 입력합니다", "없으면 건너뛰어도 됩니다. 나중에 PKM 설정에서 입력할 수 있습니다."),
    ("서버와 라이브러리를 설정합니다", "Plex 연결, 사용자, 라이브러리 선택과 동기화는 PKM이 이어서 안내합니다."),
    ("좋아하는 영화와 드라마를 골라 주세요", "고른 작품으로 홈 화면에 내 취향 추천 위젯을 만듭니다. 나중에 다시 고를 수 있습니다."),
    ("설치가 끝났습니다", "PKM 스킨으로 전환하면 바로 사용할 수 있습니다."),
]
NEXT = ["시작하기", "다음", "다음", "다음", "취향 저장", "PKM 스킨으로 전환"]

INSTALLS = [
    (PKM_ID, "PKM 플러그인 (평점·배우 서비스, TMDb Helper 포함)", True),
    (SKIN_ID, "PKM 스킨", True),
    ("plugin.video.youtube", "YouTube 애드온 (선택)", False),
]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[PKM SETUP] %s" % msg, level)


def pkm_profile():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/" % PKM_ID)


def pkm_setup_completed():
    try:
        with open(os.path.join(pkm_profile(), "state.json"), "r", encoding="utf-8") as f:
            st = json.load(f)
        return bool(st.get("initial_setup_completed_v2562") or st.get("initial_sync_done"))
    except Exception:
        return False


def save_taste(picks):
    """Stored where PKM can read it: <pkm profile>/pkm_taste.json (picks = titles)."""
    path = os.path.join(pkm_profile(), "pkm_taste.json")
    try:
        if not os.path.isdir(pkm_profile()):
            os.makedirs(pkm_profile())
        out = []
        for cname, kind, films in CATEGORIES:
            for title, year in films:
                if title in picks:
                    out.append({"title": title, "year": year, "kind": kind, "category": cname,
                                "poster": posters.cached(title, year)})
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"v": 1, "ts": int(time.time()), "picks": out}, f, ensure_ascii=False, indent=1)
        log("taste saved n=%d" % len(out))
        return True
    except Exception:
        log("taste save failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False


def load_taste():
    try:
        with open(os.path.join(pkm_profile(), "pkm_taste.json"), "r", encoding="utf-8") as f:
            return set(p["title"] for p in json.load(f).get("picks", []))
    except Exception:
        return set()


class SetupWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(SetupWindow, self).__init__(*args, **kwargs)
        self.step = 1
        self.cat = 0
        self.picks = load_taste()
        self.install_items = {}
        self.installing = False
        self.install_done = False
        self.handoff_started = False
        self.finish_switch = False
        self._stop = False

    # ---------- lifecycle
    def onInit(self):
        self.refresh_steps()
        self.fill_categories()
        self.goto(self.step)

    def refresh_steps(self):
        lst = self.getControl(200)
        lst.reset()
        for i, name in enumerate(STEPS, 1):
            it = xbmcgui.ListItem(name)
            it.setProperty("num", str(i))
            it.setProperty("cur", "1" if i == self.step else "")
            it.setProperty("done", "1" if i < self.step else "")
            lst.addItem(it)

    def goto(self, n):
        self.step = max(1, min(6, n))
        s = self.step
        self.setProperty("step", str(s))
        self.setProperty("counter", "%d / 6 단계" % s)
        self.setProperty("title", TITLES[s - 1][0])
        self.setProperty("sub", TITLES[s - 1][1])
        self.setProperty("nextlabel", NEXT[s - 1])
        self.setProperty("canback", "1" if s > 1 else "")
        self.setProperty("canskip", "1" if s in (3, 5) else "")
        self.setProperty("skiplabel", "나중에 하기" if s == 3 else "건너뛰기")
        self.refresh_steps()
        if s == 2:
            self.start_install()
        elif s == 3:
            self.setProperty("keysnote", "YouTube 키는 설치 후 PKM 유튜브 화면에서 안내에 따라 입력합니다.")
        elif s == 4:
            self.update_handoff()
        elif s == 5:
            self.fill_films()
            threading.Thread(target=self.poster_worker).start()
            self.update_picked()
        self.focus_main()

    def focus_main(self):
        try:
            self.setFocusId(self.main_focus_id() if self.step in (3, 4, 5) else 102)
        except Exception:
            pass

    def main_focus_id(self):
        return {3: 310, 4: 320, 5: 410}.get(self.step, 102)

    # ---------- actions
    def onAction(self, action):
        aid = action.getId()
        if aid in ACTION_BACK:
            if self.step > 1:
                self.goto(self.step - 1)
            else:
                self.close()
            return
        if aid == ACTION_UP and self.getFocusId() in (100, 101, 102):
            try:
                self.setFocusId(self.main_focus_id())
            except Exception:
                pass

    def onClick(self, cid):
        try:
            if cid == 102:
                self.on_next()
            elif cid == 100:
                self.goto(self.step - 1)
            elif cid == 101:
                self.goto(self.step + 1)
            elif cid == 310:
                xbmc.executebuiltin("RunPlugin(plugin://%s/?action=subdl_key_qr)" % PKM_ID)
            elif cid == 311:
                xbmcgui.Dialog().ok("YouTube API 키", "YouTube API 키는 PKM 설치 후 사이드 메뉴의 유튜브 화면에서[CR]안내에 따라 휴대폰으로 입력할 수 있습니다.")
            elif cid == 320:
                self.start_handoff()
            elif cid == 400:
                pass
            elif cid == 410:
                self.toggle_film()
        except Exception:
            log("click failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def on_next(self):
        s = self.step
        if s == 2 and not self.install_done:
            if not xbmcgui.Dialog().yesno("PKM 설치 도우미", "설치가 아직 끝나지 않았습니다.[CR]그래도 다음으로 갈까요?"):
                return
        if s == 4 and not pkm_setup_completed():
            if not xbmcgui.Dialog().yesno("PKM 설치 도우미", "서버·라이브러리 설정이 끝나지 않았습니다.[CR]나중에 PKM에서 설정할 수 있습니다. 다음으로 갈까요?"):
                return
        if s == 5:
            save_taste(self.picks)
        if s == 6:
            self.switch_skin()
            return
        self.goto(s + 1)

    # ---------- step 2: install
    def start_install(self):
        lst = self.getControl(300)
        lst.reset()
        self.install_items = {}
        for aid, label, _req in INSTALLS:
            it = xbmcgui.ListItem(label)
            has = xbmc.getCondVisibility("System.HasAddon(%s)" % aid)
            it.setProperty("st", "done" if has else "wait")
            it.setLabel2("설치됨" if has else "대기")
            lst.addItem(it)
            self.install_items[aid] = it
        if self.installing:
            return
        self.install_done = all(xbmc.getCondVisibility("System.HasAddon(%s)" % a) for a, _l, r in INSTALLS if r)
        if self.install_done:
            self.setProperty("sub", "필요한 구성이 이미 설치되어 있습니다. 다음으로 이동하세요.")
            return
        self.installing = True
        threading.Thread(target=self.install_worker).start()

    def _mark(self, aid, st, text):
        it = self.install_items.get(aid)
        if it is not None:
            it.setProperty("st", st)
            it.setLabel2(text)

    def install_worker(self):
        mon = xbmc.Monitor()
        ok_all = True
        try:
            for aid, _label, required in INSTALLS:
                if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                    self._mark(aid, "done", "설치됨")
                    continue
                self._mark(aid, "now", "설치 중")
                xbmc.executebuiltin("InstallAddon(%s)" % aid)
                t0 = time.time()
                while time.time() - t0 < 300 and not self._stop and not mon.abortRequested():
                    if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                        break
                    mon.waitForAbort(1.0)
                if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                    self._mark(aid, "done", "설치됨")
                else:
                    self._mark(aid, "fail" if required else "wait", "실패" if required else "건너뜀")
                    if required:
                        ok_all = False
                if self._stop:
                    return
        finally:
            self.installing = False
        self.install_done = ok_all
        if ok_all and not self._stop and self.step == 2:
            self.setProperty("sub", "설치가 끝났습니다. 다음으로 이동하세요.")
            try:
                self.setFocusId(102)
            except Exception:
                pass
        elif not ok_all:
            self.setProperty("sub", "일부 설치에 실패했습니다. 저장소 등록과 '알 수 없는 출처' 설정을 확인한 뒤 이전/다음으로 다시 시도하세요.")

    # ---------- step 4: hand-off to PKM's own first-run flow
    def update_handoff(self):
        if pkm_setup_completed():
            self.setProperty("handoff", "설정 완료됨 (다시 열려면 확인)")
            self.setProperty("handnote", "서버 연결과 라이브러리 설정이 이미 끝났습니다. 다음으로 이동하세요.")
        else:
            self.setProperty("handoff", "PKM 서버·라이브러리 설정 시작")
            self.setProperty("handnote", "버튼을 누르면 PKM이 Plex 주소 입력, 계정 인증, 사용자와 라이브러리 선택, 동기화를 차례로 안내합니다.[CR]끝나면 이 화면으로 돌아와 [B]다음[/B]을 누르세요.")

    def start_handoff(self):
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % PKM_ID):
            xbmcgui.Dialog().ok("PKM 설치 도우미", "PKM 플러그인이 아직 설치되지 않았습니다.[CR]이전 단계에서 설치를 먼저 끝내 주세요.")
            return
        xbmc.executebuiltin("RunPlugin(plugin://%s/?action=pkm_settings)" % PKM_ID)
        threading.Thread(target=self.handoff_watch).start()

    def handoff_watch(self):
        mon = xbmc.Monitor()
        t0 = time.time()
        while time.time() - t0 < 3600 and not self._stop and not mon.abortRequested():
            if pkm_setup_completed():
                if self.step == 4:
                    self.update_handoff()
                return
            mon.waitForAbort(2.0)

    # ---------- step 5: taste
    def fill_categories(self):
        lst = self.getControl(400)
        lst.reset()
        for cname, _k, films in CATEGORIES:
            n = sum(1 for t, _y in films if t in self.picks)
            it = xbmcgui.ListItem(cname)
            it.setLabel2(str(n) if n else "")
            lst.addItem(it)

    def fill_films(self):
        pan = self.getControl(410)
        pan.reset()
        cname, kind, films = CATEGORIES[self.cat]
        for title, year in films:
            it = xbmcgui.ListItem(title)
            p = posters.cached(title, year)
            if p:
                it.setArt({"thumb": p})
            it.setProperty("sel", "1" if title in self.picks else "")
            it.setProperty("year", str(year))
            pan.addItem(it)

    def poster_worker(self):
        cname, kind, films = CATEGORIES[self.cat]
        cat = self.cat
        for title, year in films:
            if self._stop or cat != self.cat or self.step != 5:
                return
            if not posters.cached(title, year):
                posters.fetch(title, year, kind)
        if cat == self.cat and self.step == 5:
            self.refresh_posters()

    def refresh_posters(self):
        try:
            pan = self.getControl(410)
            _c, _k, films = CATEGORIES[self.cat]
            for i, (title, year) in enumerate(films):
                p = posters.cached(title, year)
                if p and i < pan.size():
                    pan.getListItem(i).setArt({"thumb": p})
        except Exception:
            pass

    def onFocus(self, cid):
        pass

    def toggle_film(self):
        pan = self.getControl(410)
        pos = pan.getSelectedPosition()
        _c, _k, films = CATEGORIES[self.cat]
        if pos < 0 or pos >= len(films):
            return
        title = films[pos][0]
        if title in self.picks:
            self.picks.discard(title)
        else:
            self.picks.add(title)
        pan.getListItem(pos).setProperty("sel", "1" if title in self.picks else "")
        cl = self.getControl(400)
        n = sum(1 for t, _y in films if t in self.picks)
        cl.getListItem(self.cat).setLabel2(str(n) if n else "")
        self.update_picked()

    def update_picked(self):
        n = len(self.picks)
        self.setProperty("picked", "%d개 선택됨%s" % (n, "" if n >= 5 else " · 5개 이상 고르면 추천이 더 정확해집니다"))

    def onAction_cat_poll(self):
        pass

    # ---------- step 6
    def switch_skin(self):
        self._stop = True
        try:
            self.close()
        except Exception:
            pass
        xbmc.sleep(300)
        try:
            xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                                            "params": {"setting": "lookandfeel.skin", "value": SKIN_ID}}))
        except Exception:
            log("skin switch failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


class _CatWatcher(object):
    """Category list has no click side effect; follow focus to fill the film panel."""

    def __init__(self, win):
        self.win = win

    def run(self):
        mon = xbmc.Monitor()
        last = -1
        while not self.win._stop and not mon.abortRequested():
            try:
                if self.win.step == 5 and self.win.getFocusId() in (400, 410):
                    pos = self.win.getControl(400).getSelectedPosition()
                    if pos >= 0 and pos != self.win.cat:
                        self.win.cat = pos
                        self.win.fill_films()
                        threading.Thread(target=self.win.poster_worker).start()
            except Exception:
                pass
            mon.waitForAbort(0.12)


def run():
    path = ADDON.getAddonInfo("path")
    win = SetupWindow("pkm_setup.xml", path, "Default", "1080i")
    watcher = _CatWatcher(win)
    th = threading.Thread(target=watcher.run)
    th.daemon = True
    th.start()
    win.doModal()
    win._stop = True
    del win
