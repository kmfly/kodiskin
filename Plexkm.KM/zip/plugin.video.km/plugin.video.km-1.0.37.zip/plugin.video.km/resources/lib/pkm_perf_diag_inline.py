# -*- coding: utf-8 -*-
# PKM UHD3 PERF DIAG V5 EXTENDED
# Lightweight in-process diagnostics for PKM/UHD3 tuning.

from __future__ import absolute_import, unicode_literals

import collections
import os
import re
import sys
import threading
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

MARKER = "PKM_UHD3_PERF_DIAG_V5_EXTENDED"
POLL_SEC = 0.20
ACTIVITY_SAMPLE_SEC = 1.00
CONTENT_SAMPLE_SEC = 0.40
SETTLE_SEC = 0.65
BURST_GAP_SEC = 0.80

_started = False
_start_lock = threading.Lock()
_stop_event = threading.Event()


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (MARKER, msg), level)
    except Exception:
        pass


def _label(name, default="-"):
    try:
        value = xbmc.getInfoLabel(name)
        value = str(value or "").replace("\r", " ").replace("\n", " ").strip()
        return value if value else default
    except Exception:
        return default


def _prop(win, name, default=""):
    try:
        value = win.getProperty(name)
        return str(value or default)
    except Exception:
        return default


def _short(value, limit=54):
    text = str(value or "-")
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)] + "..."


def _set(win, name, value):
    try:
        win.setProperty(name, str(value))
    except Exception:
        pass


def _bool_prop(win, name):
    return _prop(win, name, "").lower() in ("1", "true", "yes", "on")


def _cond(expr):
    try:
        return bool(xbmc.getCondVisibility(expr))
    except Exception:
        return False


def _num(text, default=None):
    try:
        m = re.search(r"[-+]?\d+(?:\.\d+)?", str(text or ""))
        return float(m.group(0)) if m else default
    except Exception:
        return default


def _fmt_ms(value):
    if value is None:
        return "-"
    try:
        return "%.0f" % float(value)
    except Exception:
        return "-"


def _state(win):
    wall_opening = _bool_prop(win, "PlexKM.WindowWallOpening")
    wall_active = _bool_prop(win, "PlexKM.WindowWallActive")
    home_opening = _bool_prop(win, "PlexKM.HomeWindowOpening")
    home_active = _bool_prop(win, "PlexKM.HomeWindowActive")
    startup_ready = _prop(win, "PlexKM.Home.StartupReadyV1619", "")
    if wall_active:
        return "WALL ACTIVE"
    if wall_opening:
        return "WALL OPENING"
    if home_active and startup_ready == "1":
        return "HOME READY"
    if home_active:
        return "HOME LOADING"
    if home_opening:
        return "HOME OPENING"
    return "PKM STARTUP"


def _translate(path):
    try:
        if xbmcvfs is not None and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
        return xbmc.translatePath(path)
    except Exception:
        return path


def _discover_home_containers():
    """Best-effort discovery only. Limited to a few list/panel IDs to keep cost low."""
    ids = []
    candidates = [
        "special://skin/xml/Home.xml",
        "special://home/addons/skin.plex.km/xml/Home.xml",
    ]
    for raw in candidates:
        path = _translate(raw)
        if not path or not os.path.isfile(path):
            continue
        try:
            root = ET.parse(path).getroot()
            for ctl in root.iter("control"):
                typ = str(ctl.attrib.get("type", "")).lower()
                cid = str(ctl.attrib.get("id", "")).strip()
                if typ not in ("list", "panel", "fixedlist", "wraplist"):
                    continue
                if not cid.isdigit() or cid == "9000":
                    continue
                n = int(cid)
                # PKM uses high IDs heavily; prefer those and avoid core/utility controls.
                if n < 1000:
                    continue
                if cid not in ids:
                    ids.append(cid)
                if len(ids) >= 8:
                    break
        except Exception as exc:
            _log("HOME_CONTAINER_DISCOVERY_FAILED %s" % exc, xbmc.LOGWARNING)
        if ids:
            break
    return ids


def _content_signature(container_ids):
    if not container_ids:
        return ""
    parts = []
    for cid in container_ids:
        # Current label + number of items is cheap enough at 0.4 s cadence and detects most row swaps.
        lbl = _label("Container(%s).ListItem.Label" % cid, "")
        num = _label("Container(%s).NumItems" % cid, "")
        pos = _label("Container(%s).CurrentItem" % cid, "")
        if lbl or num or pos:
            parts.append("%s:%s:%s:%s" % (cid, num, pos, lbl[:24]))
    return "|".join(parts)


def _thread_activity(diag_thread_id=None):
    """Sample thread names + shallow Python stacks. Read-only and once per second."""
    counts = {"bg": 0, "plex": 0, "sql": 0, "warm": 0, "sync": 0}
    hot = []
    try:
        threads = list(threading.enumerate())
        counts["bg"] = max(0, len(threads) - 1)  # exclude current diagnostic worker below if possible
        frames = sys._current_frames() if hasattr(sys, "_current_frames") else {}
        for th in threads:
            ident = getattr(th, "ident", None)
            if ident == diag_thread_id:
                counts["bg"] = max(0, counts["bg"] - 1)
                continue
            name = str(getattr(th, "name", "") or "thread")
            bits = [name.lower()]
            top_fn = ""
            frame = frames.get(ident)
            depth = 0
            while frame is not None and depth < 10:
                try:
                    fn = str(frame.f_code.co_name or "")
                    file_name = str(frame.f_code.co_filename or "")
                    if not top_fn and fn not in ("wait", "waitForAbort", "sleep", "_bootstrap", "_bootstrap_inner"):
                        top_fn = fn
                    bits.append(fn.lower())
                    bits.append(os.path.basename(file_name).lower())
                except Exception:
                    pass
                frame = getattr(frame, "f_back", None)
                depth += 1
            hay = " ".join(bits)
            if any(k in hay for k in ("plex", "request", "urllib", "http", "network", "fetch", "tmdb")):
                counts["plex"] += 1
            if any(k in hay for k in ("sqlite", "database", "db_", "query", "index", "authority")):
                counts["sql"] += 1
            if any(k in hay for k in ("prewarm", "warm", "thumb", "image", "artwork", "cache", "season", "snapshot")):
                counts["warm"] += 1
            if any(k in hay for k in ("sync", "refresh", "repair", "rebuild")):
                counts["sync"] += 1
            if top_fn and len(hot) < 3:
                hot.append("%s:%s" % (_short(name, 16), _short(top_fn, 20)))
    except Exception as exc:
        return counts, "activity_err:%s" % type(exc).__name__
    return counts, " | ".join(hot) if hot else "-"


def _diag_worker():
    monitor = xbmc.Monitor()
    win = xbmcgui.Window(10000)
    diag_tid = threading.current_thread().ident
    t0 = time.monotonic()
    last_tick = t0
    max_lag_ms = 0.0
    last_cost_ms = 0.0
    max_cost_ms = 0.0

    fps_hist = collections.deque(maxlen=max(10, int(10.0 / POLL_SEC)))
    cpu_hist = collections.deque(maxlen=max(10, int(10.0 / POLL_SEC)))
    fps_session_min = None
    cpu_session_max = None

    last_window_id = ""
    last_window_name = ""
    last_control_id = ""
    last_sidebar_index = ""
    last_sidebar_label = ""
    last_wall_state = ""
    last_home_state = ""
    last_state = ""
    last_event = "START extended inline diagnostic"
    last_event_at = t0

    # Sidebar timing / burst metrics. This starts when Kodi reports the new focused item.
    sidebar_change_at = None
    sidebar_prev_change_at = None
    sidebar_settle_ms = None
    sidebar_burst = 0
    sidebar_burst_max = 0
    sidebar_last_gap_ms = None
    sidebar_content_first_ms = None
    sidebar_content_last_ms = None
    sidebar_pending = False

    # Startup / wall transition timings.
    home_ready_ms = None
    wall_open_at = None
    wall_open_ms = None
    state_enter_at = t0

    # Best-effort content change tracking.
    container_ids = _discover_home_containers()
    last_content_sig = ""
    last_content_sample = 0.0

    # Thread activity, sampled slowly.
    last_activity_sample = 0.0
    activity = {"bg": 0, "plex": 0, "sql": 0, "warm": 0, "sync": 0}
    hot = "-"

    _set(win, "PlexKM.Diag.Active", "1")
    _set(win, "PlexKM.Diag.Version", "V5 EXTENDED")
    _set(win, "PlexKM.Diag.Event", last_event)
    _set(win, "PlexKM.Diag.TrackContainers", ",".join(container_ids) if container_ids else "-")
    _log("START poll_ms=%d track_containers=%s" % (int(POLL_SEC * 1000), ",".join(container_ids) if container_ids else "none"))

    try:
        while not monitor.abortRequested() and not _stop_event.is_set():
            started = time.monotonic()
            elapsed_ms = max(0.0, (started - last_tick) * 1000.0)
            last_tick = started
            lag_ms = max(0.0, elapsed_ms - (POLL_SEC * 1000.0))
            max_lag_ms = max(max_lag_ms, lag_ms)

            # Lightweight runtime metrics.
            fps = _num(_label("System.FPS", ""), None)
            cpu = _num(_label("System.CPUUsage", ""), None)
            if fps is not None:
                fps_hist.append((started, fps))
                fps_session_min = fps if fps_session_min is None else min(fps_session_min, fps)
            if cpu is not None:
                cpu_hist.append((started, cpu))
                cpu_session_max = cpu if cpu_session_max is None else max(cpu_session_max, cpu)
            while fps_hist and started - fps_hist[0][0] > 2.2:
                fps_hist.popleft()
            while cpu_hist and started - cpu_hist[0][0] > 2.2:
                cpu_hist.popleft()
            fps_low2 = min((v for _, v in fps_hist), default=None)
            cpu_max2 = max((v for _, v in cpu_hist), default=None)

            try:
                window_id = str(xbmcgui.getCurrentWindowId())
            except Exception:
                window_id = _label("System.CurrentWindowId", "-")
            window_name = _label("System.CurrentWindow", "-")
            control_id = _label("System.CurrentControlID", "-")
            control_name = _label("System.CurrentControl", "-")

            sidebar_index = _label("Container(9000).CurrentItem", "-")
            sidebar_label = _label("Container(9000).ListItem.Label", "-")
            if sidebar_label in ("", "-"):
                sidebar_label = _prop(win, "PlexKM.SidebarOverlayLabel", "-")
            if sidebar_index in ("", "-"):
                sidebar_index = _prop(win, "PlexKM.SidebarOverlayIndex", "-")

            state = _state(win)
            wall_opening = _bool_prop(win, "PlexKM.WindowWallOpening")
            wall_active = _bool_prop(win, "PlexKM.WindowWallActive")
            wall_state = "%s/%s" % ("1" if wall_opening else "0", "1" if wall_active else "0")
            home_ready = _prop(win, "PlexKM.Home.StartupReadyV1619", "-") == "1"
            home_state = "%s/%s/%s" % (
                "1" if _bool_prop(win, "PlexKM.HomeWindowOpening") else "0",
                "1" if _bool_prop(win, "PlexKM.HomeWindowActive") else "0",
                "1" if home_ready else "0",
            )

            # Busy indicator is independent from the skin's custom spinner.
            gui_busy = (
                _cond("Window.IsActive(busydialog)") or
                _cond("Window.IsActive(busydialognocancel)") or
                _cond("Window.IsVisible(busydialog)") or
                _cond("Window.IsVisible(busydialognocancel)")
            )

            # Home ready time from diagnostic/service start.
            if home_ready and home_ready_ms is None:
                home_ready_ms = (started - t0) * 1000.0
                _log("HOME_READY_MS %.0f" % home_ready_ms)

            # Wall opening -> active time.
            if wall_opening and wall_open_at is None:
                wall_open_at = started
                wall_open_ms = None
            if wall_active and wall_open_at is not None and wall_open_ms is None:
                wall_open_ms = (started - wall_open_at) * 1000.0
                _log("WALL_OPEN_MS %.0f" % wall_open_ms)
            if not wall_opening and not wall_active and last_wall_state == "0/1":
                wall_open_at = None

            # Event detection. Sidebar item change is our earliest reliable in-Kodi focus signal.
            event = None
            sidebar_changed = bool(last_sidebar_label) and (
                sidebar_index != last_sidebar_index or sidebar_label != last_sidebar_label
            )
            if sidebar_changed:
                sidebar_prev_change_at = sidebar_change_at
                sidebar_change_at = started
                sidebar_pending = True
                sidebar_settle_ms = None
                sidebar_content_first_ms = None
                sidebar_content_last_ms = None
                if sidebar_prev_change_at is not None:
                    gap = started - sidebar_prev_change_at
                    sidebar_last_gap_ms = gap * 1000.0
                    if gap <= BURST_GAP_SEC:
                        sidebar_burst += 1
                    else:
                        sidebar_burst = 1
                else:
                    sidebar_burst = 1
                sidebar_burst_max = max(sidebar_burst_max, sidebar_burst)
                event = "SIDEBAR %s %s" % (sidebar_index, _short(sidebar_label, 30))
            elif last_window_id and (window_id != last_window_id or window_name != last_window_name):
                event = "WINDOW %s/%s -> %s/%s" % (
                    last_window_id, _short(last_window_name, 18),
                    window_id, _short(window_name, 18),
                )
            elif last_wall_state and wall_state != last_wall_state:
                event = "WALL opening/active %s -> %s" % (last_wall_state, wall_state)
            elif last_home_state and home_state != last_home_state:
                event = "HOME opening/active/ready %s -> %s" % (last_home_state, home_state)
            elif last_control_id and control_id != last_control_id:
                event = "FOCUS CTRL %s -> %s" % (last_control_id, control_id)

            if state != last_state:
                state_enter_at = started
                last_state = state

            if event:
                last_event = event
                last_event_at = started
                _log("EVENT %s" % event)

            # Content signature is sampled at a slower cadence. It gives a best-effort
            # FOCUS->CONTENT timing without modifying PKM data paths.
            if started - last_content_sample >= CONTENT_SAMPLE_SEC:
                last_content_sample = started
                sig = _content_signature(container_ids)
                if sig and sig != last_content_sig:
                    if sidebar_pending and sidebar_change_at is not None:
                        age_ms = (started - sidebar_change_at) * 1000.0
                        if sidebar_content_first_ms is None:
                            sidebar_content_first_ms = age_ms
                        sidebar_content_last_ms = age_ms
                    last_content_sig = sig

            # A sidebar move is considered quiet/stable after no further sidebar focus
            # changes for SETTLE_SEC. If content containers changed later, include that tail.
            if sidebar_pending and sidebar_change_at is not None:
                focus_quiet_age = started - sidebar_change_at
                content_tail_sec = 0.0
                if sidebar_content_last_ms is not None:
                    content_tail_sec = sidebar_content_last_ms / 1000.0
                if focus_quiet_age >= max(SETTLE_SEC, content_tail_sec + SETTLE_SEC):
                    sidebar_settle_ms = focus_quiet_age * 1000.0
                    sidebar_pending = False
                    _log(
                        "SIDEBAR_SETTLE_MS %.0f burst=%d content_first=%s content_last=%s" % (
                            sidebar_settle_ms, sidebar_burst,
                            _fmt_ms(sidebar_content_first_ms), _fmt_ms(sidebar_content_last_ms),
                        )
                    )

            # Low-rate Python activity sampler.
            if started - last_activity_sample >= ACTIVITY_SAMPLE_SEC:
                last_activity_sample = started
                activity, hot = _thread_activity(diag_tid)

            # Publish properties consumed directly by skin XML.
            _set(win, "PlexKM.Diag.State", state)
            _set(win, "PlexKM.Diag.StateAge", "%.1fs" % max(0.0, started - state_enter_at))
            _set(win, "PlexKM.Diag.Event", _short(last_event, 78))
            _set(win, "PlexKM.Diag.EventAge", "%.1fs" % max(0.0, started - last_event_at))
            _set(win, "PlexKM.Diag.HeartbeatLagMs", "%.0f" % lag_ms)
            _set(win, "PlexKM.Diag.HeartbeatMaxMs", "%.0f" % max_lag_ms)
            _set(win, "PlexKM.Diag.CostMs", "%.1f" % last_cost_ms)
            _set(win, "PlexKM.Diag.CostMaxMs", "%.1f" % max_cost_ms)
            _set(win, "PlexKM.Diag.Threads", str(threading.active_count()))
            _set(win, "PlexKM.Diag.WindowId", window_id)
            _set(win, "PlexKM.Diag.Window", _short(window_name, 34))
            _set(win, "PlexKM.Diag.ControlId", control_id)
            _set(win, "PlexKM.Diag.Control", _short(control_name, 34))
            _set(win, "PlexKM.Diag.SidebarIndex", sidebar_index)
            _set(win, "PlexKM.Diag.SidebarLabel", _short(sidebar_label, 34))
            _set(win, "PlexKM.Diag.WallState", wall_state)
            _set(win, "PlexKM.Diag.HomeState", home_state)
            _set(win, "PlexKM.Diag.GuiBusy", "ON" if gui_busy else "OFF")

            _set(win, "PlexKM.Diag.FpsLow2", "%.1f" % fps_low2 if fps_low2 is not None else "-")
            _set(win, "PlexKM.Diag.FpsMin", "%.1f" % fps_session_min if fps_session_min is not None else "-")
            _set(win, "PlexKM.Diag.CpuMax2", "%.0f%%" % cpu_max2 if cpu_max2 is not None else "-")
            _set(win, "PlexKM.Diag.CpuMax", "%.0f%%" % cpu_session_max if cpu_session_max is not None else "-")

            _set(win, "PlexKM.Diag.SidebarSettleMs", _fmt_ms(sidebar_settle_ms))
            _set(win, "PlexKM.Diag.SidebarBurst", str(sidebar_burst))
            _set(win, "PlexKM.Diag.SidebarBurstMax", str(sidebar_burst_max))
            _set(win, "PlexKM.Diag.SidebarGapMs", _fmt_ms(sidebar_last_gap_ms))
            _set(win, "PlexKM.Diag.SidebarContentFirstMs", _fmt_ms(sidebar_content_first_ms))
            _set(win, "PlexKM.Diag.SidebarContentLastMs", _fmt_ms(sidebar_content_last_ms))
            _set(win, "PlexKM.Diag.SidebarPending", "1" if sidebar_pending else "0")

            _set(win, "PlexKM.Diag.HomeReadyMs", _fmt_ms(home_ready_ms))
            _set(win, "PlexKM.Diag.WallOpenMs", _fmt_ms(wall_open_ms))
            _set(win, "PlexKM.Diag.Uptime", "%.1fs" % max(0.0, started - t0))

            _set(win, "PlexKM.Diag.BgThreads", str(activity.get("bg", 0)))
            _set(win, "PlexKM.Diag.PlexThreads", str(activity.get("plex", 0)))
            _set(win, "PlexKM.Diag.SqlThreads", str(activity.get("sql", 0)))
            _set(win, "PlexKM.Diag.WarmThreads", str(activity.get("warm", 0)))
            _set(win, "PlexKM.Diag.SyncThreads", str(activity.get("sync", 0)))
            _set(win, "PlexKM.Diag.Hot", _short(hot, 88))

            last_window_id = window_id
            last_window_name = window_name
            last_control_id = control_id
            last_sidebar_index = sidebar_index
            last_sidebar_label = sidebar_label
            last_wall_state = wall_state
            last_home_state = home_state

            last_cost_ms = max(0.0, (time.monotonic() - started) * 1000.0)
            max_cost_ms = max(max_cost_ms, last_cost_ms)
            _set(win, "PlexKM.Diag.CostMs", "%.1f" % last_cost_ms)
            _set(win, "PlexKM.Diag.CostMaxMs", "%.1f" % max_cost_ms)

            if monitor.waitForAbort(POLL_SEC):
                break
    except Exception as exc:
        _log("WORKER_FAILED %s: %s" % (type(exc).__name__, exc), xbmc.LOGERROR)
    finally:
        _set(win, "PlexKM.Diag.Active", "0")
        _log("STOP max_lag_ms=%.0f max_diag_cost_ms=%.1f" % (max_lag_ms, max_cost_ms))


def start():
    global _started
    with _start_lock:
        if _started:
            return True
        _started = True
        t = threading.Thread(target=_diag_worker, name="PKMUHD3PerfDiagV5Extended")
        t.daemon = True
        t.start()
        return True


def stop():
    try:
        _stop_event.set()
    except Exception:
        pass
