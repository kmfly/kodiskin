# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import shutil
import traceback

import xbmc
import xbmcaddon
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

ADDON_ID = "plugin.video.km"
PKM_SKIN_ID = "skin.plex.km"
PKM_SUBTITLE_FONT_FILENAME = "NotoSansKR-Medium.ttf"
PKM_CINEMA_FONT_FILENAME = "a시네마M.ttf"
# Internal ASCII copy used only for the actual Kodi/libass subtitle renderer.
# UI still shows "시네마 폰트" and the bundled/source file remains a시네마M.ttf.
PKM_CINEMA_FONT_RENDERER_FILENAME = "aCinemaM.ttf"
# Actual internal family/PostScript names inside a시네마M.ttf.  Kodi's setting accepts
# arbitrary strings, but libass/fontconfig resolves the renderer by the font's
# internal family name, not by a made-up copied filename.  Keep ASCII aliases in
# media/Fonts for discovery, and use the internal family name as the setting.
PKM_CINEMA_FONT_RENDERER_SETTING = "KoreanCNMM"
PKM_CINEMA_FONT_POSTSCRIPT_NAME = "KoreanCNM-M"
PKM_CINEMA_FONT_RENDERER_ALIASES = (PKM_CINEMA_FONT_RENDERER_FILENAME, "KoreanCNMM.ttf", "KoreanCNM-M.ttf")
PKM_CINEMA_FONT_ESCAPED_FILENAME = "a#Uc2dc#Ub124#Ub9c8M.ttf"
KODI_SYSTEM_SUBTITLE_FONT = "Arial.ttf"


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][subtitle_font] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def translate_path(path):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        return xbmc.translatePath(path)
    except Exception:
        return path


def skin_path():
    try:
        return xbmcaddon.Addon(PKM_SKIN_ID).getAddonInfo("path")
    except Exception:
        try:
            return translate_path("special://home/addons/%s" % PKM_SKIN_ID)
        except Exception:
            return ""


def kodi_font_dirs():
    dirs = []
    # Kodi's real subtitle renderer font folder is under Kodi data folder media/Fonts.
    # Keep both cases for Windows/Android filesystem tolerance.
    for sp in ("special://home/media/Fonts", "special://home/media/fonts"):
        try:
            p = translate_path(sp)
            if p and p not in dirs:
                dirs.append(p)
        except Exception:
            pass
    return dirs


def source_candidates():
    out = []
    try:
        sp = skin_path()
        if sp:
            out.append(("skin", os.path.join(sp, "fonts", PKM_SUBTITLE_FONT_FILENAME)))
    except Exception:
        pass
    for d in kodi_font_dirs():
        out.append(("kodi_font_folder", os.path.join(d, PKM_SUBTITLE_FONT_FILENAME)))
    try:
        out.append(("addon_data", os.path.join(translate_path("special://profile/addon_data/%s" % ADDON_ID), PKM_SUBTITLE_FONT_FILENAME)))
    except Exception:
        pass

    dedup = []
    seen = set()
    for kind, path in out:
        if not path:
            continue
        try:
            key = os.path.normcase(os.path.abspath(path))
        except Exception:
            key = path
        if key in seen:
            continue
        seen.add(key)
        dedup.append((kind, path))
    return dedup


def _jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(payload)) or "{}")
    except Exception:
        _log("jsonrpc_failed method=%s\n%s" % (method, traceback.format_exc()), xbmc.LOGWARNING)
        return {}


def get_kodi_setting_value(setting_id):
    try:
        res = _jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
        if "result" in res and isinstance(res.get("result"), dict):
            return res.get("result", {}).get("value")
    except Exception:
        pass
    return None


def _setting_value_equal(current, requested):
    try:
        if isinstance(current, bool) or isinstance(requested, bool):
            return bool(current) == bool(requested)
        if isinstance(current, (int, float)) or isinstance(requested, (int, float)):
            return float(current) == float(requested)
    except Exception:
        pass
    return str(current) == str(requested)


def set_kodi_setting(setting_id, value, reason=""):
    current = get_kodi_setting_value(setting_id)
    if _setting_value_equal(current, value):
        _log("subtitle_font_setting_skip id=%s value=%s current=%s reason=%s" % (setting_id, value, current, reason))
        return True
    res = _jsonrpc("Settings.SetSettingValue", {"setting": setting_id, "value": value})
    ok = "error" not in res
    _log("subtitle_font_setting_apply id=%s value=%s ok=%s result=%s reason=%s" % (setting_id, value, "1" if ok else "0", res, reason), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok




def _vfs_exists(path):
    try:
        if xbmcvfs and xbmcvfs.exists(path):
            return True
    except Exception:
        pass
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _vfs_mkdirs(path):
    try:
        if xbmcvfs and xbmcvfs.mkdirs(path):
            return True
    except Exception:
        pass
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
        return True
    except Exception:
        return False


def _vfs_copy(src, dst):
    try:
        if xbmcvfs and xbmcvfs.copy(src, dst):
            return True
    except Exception:
        pass
    try:
        shutil.copyfile(src, dst)
        return True
    except Exception:
        return False

def source_candidates_for(filename):
    out = []
    try:
        sp = skin_path()
        if sp:
            if filename == PKM_CINEMA_FONT_FILENAME:
                # v1404: single cinema source lives in the skin folder using the
                # ASCII renderer filename, then gets copied/aliased for Kodi's real renderer.
                out.append(("skin_renderer_ascii", os.path.join(sp, "fonts", PKM_CINEMA_FONT_RENDERER_FILENAME)))
            out.append(("skin", os.path.join(sp, "fonts", filename)))
            if filename == PKM_CINEMA_FONT_FILENAME:
                out.append(("skin_escaped_legacy", os.path.join(sp, "fonts", PKM_CINEMA_FONT_ESCAPED_FILENAME)))
    except Exception:
        pass
    try:
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        if addon_path:
            out.append(("addon_skin", os.path.join(addon_path, "resources", "skins", "Default", "fonts", filename)))
            out.append(("addon_fonts", os.path.join(addon_path, "resources", "fonts", filename)))
    except Exception:
        pass
    for d in kodi_font_dirs():
        out.append(("kodi_font_folder", os.path.join(d, filename)))
    try:
        out.append(("addon_data", os.path.join(translate_path("special://profile/addon_data/%s" % ADDON_ID), filename)))
    except Exception:
        pass
    dedup = []
    seen = set()
    for kind, path in out:
        if not path:
            continue
        try:
            key = os.path.normcase(os.path.abspath(path))
        except Exception:
            key = path
        if key in seen:
            continue
        seen.add(key)
        dedup.append((kind, path))
    return dedup


def register_subtitle_font_file(filename, reason="", allow_copy=True, renderer_filename=None):
    dst_dirs = kodi_font_dirs()
    dst_dir = dst_dirs[0] if dst_dirs else translate_path("special://home/media/Fonts")
    target_filename = renderer_filename or filename
    dst = os.path.join(dst_dir, target_filename)
    original_dst = os.path.join(dst_dir, filename)
    candidates = source_candidates_for(filename)
    src = ""
    kind = "missing"
    try:
        for k, cand in candidates:
            try:
                if os.path.exists(cand) and os.path.isfile(cand):
                    src = cand
                    kind = k
                    break
            except Exception:
                pass
        if not src:
            searched = "|".join(["%s:%s" % (k, c) for k, c in candidates])
            _log("subtitle_font_register_missing filename=%s renderer_filename=%s dst=%s searched=%s reason=%s" % (filename, target_filename, dst, searched, reason), xbmc.LOGWARNING)
            return {"ok": False, "filename": target_filename, "source_filename": filename, "src": "", "dst": dst, "copied": False, "exists": os.path.exists(dst), "reason": reason}
        copied = False
        if allow_copy:
            mkdir_ok = _vfs_mkdirs(dst_dir)
            try:
                same_path = os.path.normcase(os.path.abspath(src)) == os.path.normcase(os.path.abspath(dst))
            except Exception:
                same_path = False
            try:
                dst_exists = _vfs_exists(dst)
                src_size = os.path.getsize(src)
                dst_size = os.path.getsize(dst) if dst_exists else -1
            except Exception:
                dst_exists = _vfs_exists(dst)
                src_size = -1
                dst_size = -2
            need_copy = bool((not same_path) and ((not dst_exists) or (src_size >= 0 and dst_size != src_size)))
            if need_copy and mkdir_ok:
                copied = bool(_vfs_copy(src, dst))
            elif need_copy and not mkdir_ok:
                _log("subtitle_font_register_mkdir_failed dst_dir=%s filename=%s reason=%s" % (dst_dir, filename, reason), xbmc.LOGWARNING)
        original_copied = False
        if allow_copy and renderer_filename and filename != target_filename:
            try:
                if not _vfs_exists(original_dst):
                    original_copied = bool(_vfs_copy(src, original_dst))
            except Exception:
                original_copied = False
        alias_results = []
        if allow_copy and filename == PKM_CINEMA_FONT_FILENAME:
            for alias_name in PKM_CINEMA_FONT_RENDERER_ALIASES:
                alias_dst = os.path.join(dst_dir, alias_name)
                try:
                    alias_exists = _vfs_exists(alias_dst)
                    alias_size = os.path.getsize(alias_dst) if alias_exists else -1
                    need_alias = (not alias_exists) or (src_size >= 0 and alias_size != src_size)
                    alias_copied = bool(_vfs_copy(src, alias_dst)) if need_alias else False
                    alias_results.append("%s:%s:%s" % (alias_name, "1" if _vfs_exists(alias_dst) else "0", "1" if alias_copied else "0"))
                except Exception:
                    alias_results.append("%s:0:0" % alias_name)
        exists_after = _vfs_exists(dst)
        original_exists = _vfs_exists(original_dst)
        try:
            size_after = os.path.getsize(dst) if exists_after else -1
        except Exception:
            size_after = -1
        _log("subtitle_font_register source_filename=%s renderer_filename=%s renderer_setting=%s source_kind=%s source=%s renderer_dst=%s copied=%s exists=%s size=%s original_dst=%s original_copied=%s original_exists=%s aliases=%s allow_copy=%s vfs=1 reason=%s" % (filename, target_filename, PKM_CINEMA_FONT_RENDERER_SETTING if filename == PKM_CINEMA_FONT_FILENAME else target_filename, kind, src, dst, "1" if copied else "0", "1" if exists_after else "0", size_after, original_dst, "1" if original_copied else "0", "1" if original_exists else "0", ",".join(alias_results) if 'alias_results' in locals() else "", "1" if allow_copy else "0", reason), xbmc.LOGINFO if exists_after else xbmc.LOGWARNING)
        return {"ok": bool(exists_after), "filename": target_filename, "source_filename": filename, "src": src, "dst": dst, "copied": copied, "exists": exists_after, "original_dst": original_dst, "original_exists": original_exists, "reason": reason}
    except Exception:
        _log("subtitle_font_register_failed filename=%s src=%s dst=%s reason=%s\n%s" % (filename, src, dst, reason, traceback.format_exc()), xbmc.LOGWARNING)
        return {"ok": False, "filename": filename, "src": src, "dst": dst, "copied": False, "exists": False, "reason": reason}


def register_saved_subtitle_font(reason="", allow_copy=True, apply_setting=True):
    """Register bundled subtitle fonts and apply the user's saved choice.

    v1178 registers the cinema source file plus an ASCII renderer alias.
    v1177 registers both PKM default and cinema fonts during service startup.
    This avoids the first cinema-font selection adding a brand-new file while
    the subtitle renderer is already active.  Changing the font selection still
    uses Kodi settings and a subtitle-track refresh; no Kodi restart is required
    for the selection itself.
    """
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        font_key = addon.getSetting("pkm_subtitle_font") or "default"
    except Exception:
        font_key = "default"
    if font_key in ("", "pkm"):
        font_key = "default"

    default_state = register_subtitle_font_file(PKM_SUBTITLE_FONT_FILENAME, reason=reason + "_default", allow_copy=allow_copy)
    cinema_state = register_subtitle_font_file(PKM_CINEMA_FONT_FILENAME, reason=reason + "_cinema", allow_copy=allow_copy, renderer_filename=PKM_CINEMA_FONT_RENDERER_FILENAME)
    _log("subtitle_font_register_all_done default_ok=%s cinema_ok=%s allow_copy=%s reason=%s" % (
        "1" if default_state.get("ok") else "0",
        "1" if cinema_state.get("ok") else "0",
        "1" if allow_copy else "0",
        reason,
    ), xbmc.LOGINFO if default_state.get("ok") else xbmc.LOGWARNING)

    if font_key in ("system", "ibm"):
        # v1182: old system/ibm saved values are normalized to the PKM default font.
        # The default font reuses the bundled PKM UI font instead of carrying
        # a separate subtitle-only font file.
        font_key = "default"
        filename = PKM_SUBTITLE_FONT_FILENAME
        state = dict(default_state)
    elif font_key == "cinema":
        filename = PKM_CINEMA_FONT_RENDERER_SETTING
        state = dict(cinema_state)
        if not state.get("ok"):
            filename = PKM_SUBTITLE_FONT_FILENAME
            state = dict(default_state)
            font_key = "default"
    else:
        font_key = "default"
        filename = PKM_SUBTITLE_FONT_FILENAME
        state = dict(default_state)

    if apply_setting and state.get("ok"):
        ok1 = set_kodi_setting("subtitles.fontname", filename, reason=reason)
        ok2 = set_kodi_setting("subtitles.overridefonts", True, reason=reason)
        # Kodi 21.3 rejects the old extra ASS override setting with Invalid params on the user's runtime.
        # Do not write that non-existent setting; the proven renderer path is fontname + overridefonts.
        effective = get_kodi_setting_value("subtitles.fontname")
        ok_eff = (str(effective) == filename)
        _log("subtitle_saved_font_effective key=%s setting=subtitles.fontname requested=%s effective=%s ok=%s apply_setting=1 reason=%s" % (font_key, filename, effective, "1" if ok_eff else "0", reason), xbmc.LOGINFO if ok_eff else xbmc.LOGWARNING)
        state.update({"ok": bool(ok1 and ok2 and ok_eff), "effective": effective, "saved_key": font_key})
    else:
        state.update({"saved_key": font_key})
    return state


def register_pkm_subtitle_font(reason="", allow_copy=True, apply_setting=False):
    """Make the PKM bundled subtitle font available to Kodi's real subtitle renderer.

    Intended lifecycle:
      * plugin.video.km service startup: allow_copy=True, apply_setting=True
      * subtitle popup: allow_copy=False, apply_setting=False (status/log only)

    Source font must be bundled by the final install package at:
      plugin.video.km/resources/skins/Default/fonts/NotoSansKR-Medium.ttf

    Kodi's real subtitle renderer selects fonts from:
      special://home/media/Fonts/NotoSansKR-Medium.ttf
    """
    dst_dirs = kodi_font_dirs()
    dst_dir = dst_dirs[0] if dst_dirs else translate_path("special://home/media/Fonts")
    dst = os.path.join(dst_dir, PKM_SUBTITLE_FONT_FILENAME)
    candidates = source_candidates()
    src = ""
    kind = "missing"
    try:
        for k, cand in candidates:
            try:
                if os.path.exists(cand) and os.path.isfile(cand):
                    src = cand
                    kind = k
                    break
            except Exception:
                pass
        if not src:
            searched = "|".join(["%s:%s" % (k, c) for k, c in candidates])
            _log("subtitle_font_register_missing filename=%s required_skin_path=special://home/addons/%s/fonts/%s dst=%s searched=%s reason=%s" % (PKM_SUBTITLE_FONT_FILENAME, PKM_SKIN_ID, PKM_SUBTITLE_FONT_FILENAME, dst, searched, reason), xbmc.LOGWARNING)
            return {"ok": False, "filename": PKM_SUBTITLE_FONT_FILENAME, "src": "", "dst": dst, "copied": False, "exists": os.path.exists(dst), "reason": reason}

        copied = False
        if allow_copy:
            mkdir_ok = _vfs_mkdirs(dst_dir)
            try:
                same_path = os.path.normcase(os.path.abspath(src)) == os.path.normcase(os.path.abspath(dst))
            except Exception:
                same_path = False
            try:
                dst_exists = _vfs_exists(dst)
                src_size = os.path.getsize(src)
                dst_size = os.path.getsize(dst) if dst_exists else -1
            except Exception:
                dst_exists = _vfs_exists(dst)
                src_size = -1
                dst_size = -2
            need_copy = bool((not same_path) and ((not dst_exists) or (src_size >= 0 and dst_size != src_size)))
            if need_copy and mkdir_ok:
                copied = bool(_vfs_copy(src, dst))
            elif need_copy and not mkdir_ok:
                _log("subtitle_font_register_mkdir_failed dst_dir=%s reason=%s" % (dst_dir, reason), xbmc.LOGWARNING)
        exists_after = _vfs_exists(dst)
        try:
            size_after = os.path.getsize(dst) if exists_after else -1
        except Exception:
            size_after = -1
        _log("subtitle_font_register filename=%s source_kind=%s source=%s dst=%s copied=%s exists=%s size=%s allow_copy=%s vfs=1 reason=%s" % (PKM_SUBTITLE_FONT_FILENAME, kind, src, dst, "1" if copied else "0", "1" if exists_after else "0", size_after, "1" if allow_copy else "0", reason), xbmc.LOGINFO if exists_after else xbmc.LOGWARNING)

        if apply_setting and exists_after:
            ok1 = set_kodi_setting("subtitles.fontname", PKM_SUBTITLE_FONT_FILENAME, reason=reason)
            ok2 = set_kodi_setting("subtitles.overridefonts", True, reason=reason)
            effective = get_kodi_setting_value("subtitles.fontname")
            ok_eff = (str(effective) == PKM_SUBTITLE_FONT_FILENAME)
            _log("subtitle_real_font_effective setting=subtitles.fontname requested=%s effective=%s ok=%s apply_setting=1 reason=%s" % (PKM_SUBTITLE_FONT_FILENAME, effective, "1" if ok_eff else "0", reason), xbmc.LOGINFO if ok_eff else xbmc.LOGWARNING)
            return {"ok": bool(ok1 and ok2 and ok_eff), "filename": PKM_SUBTITLE_FONT_FILENAME, "src": src, "dst": dst, "copied": copied, "exists": exists_after, "effective": effective, "reason": reason}
        return {"ok": bool(exists_after), "filename": PKM_SUBTITLE_FONT_FILENAME, "src": src, "dst": dst, "copied": copied, "exists": exists_after, "reason": reason}
    except Exception:
        _log("subtitle_font_register_failed filename=%s src=%s dst=%s reason=%s\n%s" % (PKM_SUBTITLE_FONT_FILENAME, src, dst, reason, traceback.format_exc()), xbmc.LOGWARNING)
        return {"ok": False, "filename": PKM_SUBTITLE_FONT_FILENAME, "src": src, "dst": dst, "copied": False, "exists": False, "reason": reason}


def pkm_subtitle_font_ready():
    for k, cand in source_candidates():
        try:
            if os.path.exists(cand) and os.path.isfile(cand):
                return True
        except Exception:
            pass
    return False
