# -*- coding: utf-8 -*-
"""PKM sync/progress WindowXMLDialog helpers.

This module is split from ``default.py`` to keep modal progress UI isolated
from plugin routing, cache/sync logic, and Home Window startup flow.

Rules for this module:
- do not import ``default.py``;
- do not control Home/Section focus/navigation;
- expose only small progress-dialog compatible helpers used by sync code.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor
from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171

import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass



def _window_stack_text_v1747():
    base_id = -1
    dialog_id = -1
    try:
        base_id = int(xbmcgui.getCurrentWindowId())
    except Exception:
        pass
    try:
        dialog_id = int(xbmcgui.getCurrentWindowDialogId())
    except Exception:
        pass
    visible = []
    for wid in (13030, 13031, 13032):
        try:
            value = 1 if xbmc.getCondVisibility("Window.IsVisible(%d)" % wid) else 0
        except Exception:
            value = -1
        visible.append("%d=%s" % (wid, value))
    return "base=%s dialog=%s visible=%s" % (base_id, dialog_id, ",".join(visible))


def _display_text_for_kodi(value):
    """Normalize Plex library title separators for Kodi WindowXML text rendering."""
    text = str(value or "")
    try:
        table = {
            ord("\u007C"): "|",
            ord("\u00A6"): "|",
            ord("\u01C0"): "|",
            ord("\u2016"): "|",
            ord("\u2223"): "|",
            ord("\u2225"): "|",
            ord("\u23AA"): "|",
            ord("\u23D0"): "|",
            ord("\u2502"): "|",
            ord("\u2503"): "|",
            ord("\u2758"): "|",
            ord("\u2759"): "|",
            ord("\u275A"): "|",
            ord("\u3163"): "|",
            ord("\u4E28"): "|",
            ord("\uFF5C"): "|",
            ord("\uFFE8"): "|",
        }
        return text.translate(table)
    except Exception:
        return text


class PKMSyncProgressDialog(xbmcgui.WindowXMLDialog):
    """PKM-styled async sync progress dialog."""
    CANCEL_ID = 300
    PROGRESS_ID = 20

    def __init__(self, *args, **kwargs):
        self.heading = kwargs.pop("heading", ADDON_NAME)
        self.message = kwargs.pop("message", "")
        self.percent = int(kwargs.pop("percent", 0) or 0)
        # v1927: Android must keep WindowXMLDialog.doModal() on the caller
        # thread.  The library scan runs on a worker, while the caller-owned
        # modal remains the only GUI owner.  Windows keeps the established
        # helper-modal path.
        self._caller_modal_v1927 = bool(kwargs.pop("caller_modal_v1927", False))
        self._caller_create_ready_v1927 = threading.Event()
        # v1928: Android caller-modal GUI ownership is explicit.  Worker
        # threads may publish only global Window properties and may request a
        # close through Kodi's application messenger; they never touch the
        # WindowXML instance or its controls directly.
        self._caller_owner_ident_v1928 = None
        self._caller_close_requested_v1928 = False
        self._canceled = False
        self._shown = False
        self._closed = False
        self._progress_control = None
        self._modal_thread = None
        self._init_event = threading.Event()
        self._completed = False
        self._confirmed = False
        self._confirm_event = threading.Event()
        self._exit_on_confirm = False
        self._completion_button_label = "확인"
        self._completion_action_hint = "확인 후 홈으로 이동"
        super(PKMSyncProgressDialog, self).__init__(*args, **kwargs)

    def _split_message(self, message):
        parts = [x for x in _display_text_for_kodi(message).split("\n")]
        return (parts[0] if len(parts) > 0 else "", parts[1] if len(parts) > 1 else "", parts[2] if len(parts) > 2 else "")

    def _apply_props(self):
        try:
            line1, line2, line3 = self._split_message(self.message)
            percent_text = str(max(0, min(100, int(self.percent))))
            # Pre-seed and update the Home-window properties used by the XML.
            # This avoids a blank black dialog frame while WindowXMLDialog onInit
            # catches up after a modal transition.
            try:
                gwin = xbmcgui.Window(10000)
                gwin.setProperty("PlexKM.Sync.Title", _display_text_for_kodi(self.heading or ADDON_NAME))
                gwin.setProperty("PlexKM.Sync.Line1", line1)
                gwin.setProperty("PlexKM.Sync.Line2", line2)
                gwin.setProperty("PlexKM.Sync.Line3", line3)
                gwin.setProperty("PlexKM.Sync.Percent", percent_text)
                gwin.setProperty("PlexKM.Sync.ActionHint", self._completion_action_hint if self._completed else "취소로 중단")
                gwin.setProperty("PlexKM.Sync.ButtonLabel", self._completion_button_label if self._completed else "취소")
                gwin.setProperty("PlexKM.Sync.Completed", "1" if self._completed else "")
            except Exception:
                pass
            owner_thread_v1928 = bool(
                not self._caller_modal_v1927
                or (
                    self._caller_owner_ident_v1928 is not None
                    and threading.current_thread().ident == self._caller_owner_ident_v1928
                )
            )
            if owner_thread_v1928:
                self.setProperty("PlexKM.Sync.Title", _display_text_for_kodi(self.heading or ADDON_NAME))
                self.setProperty("PlexKM.Sync.Line1", line1)
                self.setProperty("PlexKM.Sync.Line2", line2)
                self.setProperty("PlexKM.Sync.Line3", line3)
                self.setProperty("PlexKM.Sync.Percent", percent_text)
                self.setProperty("PlexKM.Sync.ActionHint", self._completion_action_hint if self._completed else "취소로 중단")
                self.setProperty("PlexKM.Sync.ButtonLabel", self._completion_button_label if self._completed else "취소")
                self.setProperty("PlexKM.Sync.Completed", "1" if self._completed else "")
        except Exception:
            pass
        # On Android caller-modal the progress bar is bound directly to the
        # global Percent property in XML.  Only the owner thread may touch GUI
        # controls; Windows keeps the established explicit setPercent path.
        try:
            if self._caller_modal_v1927:
                return
            if not self._shown or not self._init_event.is_set():
                return
            if self._progress_control is None:
                self._progress_control = self.getControl(self.PROGRESS_ID)
            self._progress_control.setPercent(max(0, min(100, int(self.percent))))
        except Exception:
            pass

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        _log("PKM_SYNC_PROGRESS_ONINIT_V1747 %s shown=%d" % (_window_stack_text_v1747(), 1 if self._shown else 0))
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            _log("PKM_SYNC_HANDOFF_COVER_CLEAR_V1747 source=progress_oninit")
        except Exception:
            pass
        try:
            self._progress_control = self.getControl(self.PROGRESS_ID)
        except Exception:
            self._progress_control = None
        self._apply_props()
        _log("PKM_SYNC_PROGRESS_XML_FOCUS_OWNER_V1969 defaultcontrol=300 python_focus_write=0")
        try:
            self._init_event.set()
        except Exception:
            pass

    def _modal_runner(self):
        _log("PKM_SYNC_PROGRESS_MODAL_BEGIN_V1747 %s" % _window_stack_text_v1747())
        try:
            self.doModal()
        except Exception:
            _log("PKM_SYNC_PROGRESS_MODAL_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        finally:
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            _log("PKM_SYNC_PROGRESS_MODAL_END_V1747 %s" % _window_stack_text_v1747())
            self._closed = True
            try:
                self._init_event.set()
            except Exception:
                pass

    def create(self, heading, message=""):
        self.heading = _display_text_for_kodi(heading or ADDON_NAME)
        self.message = _display_text_for_kodi(message or "")
        self.percent = 0
        self._canceled = False
        self._closed = False
        self._completed = False
        self._confirmed = False
        try:
            self._confirm_event.clear()
        except Exception:
            pass
        self._apply_props()
        _log("PKM_SYNC_PROGRESS_CREATE_BEGIN_V1747 %s shown=%d heading=%s" % (
            _window_stack_text_v1747(), 1 if self._shown else 0,
            str(self.heading or "").replace(" ", "_")
        ))
        if self._caller_modal_v1927:
            # The Android wrapper opens doModal() on this same caller thread
            # after the sync worker has started.  create() only publishes the
            # initial properties and marks the modal ready to be opened.
            try:
                self._caller_create_ready_v1927.set()
            except Exception:
                pass
            _log("PKM_SYNC_PROGRESS_CREATE_CALLER_MODAL_V1927 helper_windowxml_thread=0 %s" % _window_stack_text_v1747())
        elif not self._shown:
            try:
                self._shown = True
                self._modal_thread = threading.Thread(target=self._modal_runner, name="PlexKMSyncProgress", daemon=True)
                self._modal_thread.start()
                _log("PKM_SYNC_PROGRESS_CREATE_ASYNC_V1747 wait_oninit_ms=0 %s" % _window_stack_text_v1747())
            except Exception:
                _log("PKM_SYNC_PROGRESS_SHOW_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        self._apply_props()

    def show_caller_modal_v1927(self):
        """Open the Android PKM progress modal on its owning caller thread.

        The sync worker may publish properties before onInit; Window(10000)
        properties preserve those values until the XML is visible.
        """
        if not self._caller_modal_v1927:
            return False
        try:
            self._caller_create_ready_v1927.wait(1.5)
        except Exception:
            pass
        if self._closed or (self._caller_close_requested_v1928 and not self._completed):
            return False
        self._caller_owner_ident_v1928 = threading.current_thread().ident
        self._shown = True
        _log("PKM_SYNC_PROGRESS_CALLER_MODAL_BEGIN_V1927 owner_thread=%s helper_windowxml_thread=0" % threading.current_thread().name)
        self._modal_runner()
        _log("PKM_SYNC_PROGRESS_CALLER_MODAL_END_V1927 owner_thread=%s" % threading.current_thread().name)
        return True

    def close(self):
        """Close the live PKM progress modal without waiting for user input.

        v2067 removes the numeric-dialog-only close path. The worker may finish
        while the caller thread owns doModal(); closing the live WindowXMLDialog
        object posts the close through Kodi and lets that caller return normally.
        No timer, Enter key, or delayed retry is part of the completion protocol.
        """
        if self._caller_modal_v1927:
            owner_ident = self._caller_owner_ident_v1928
            if owner_ident is None or threading.current_thread().ident != owner_ident:
                self._caller_close_requested_v1928 = True
                if self._shown and not self._closed:
                    try:
                        result = super(PKMSyncProgressDialog, self).close()
                        _log("PKM_SYNC_PROGRESS_DIRECT_CLOSE_V2067 owner_thread=0 shown=1")
                        return result
                    except Exception:
                        _log("PKM_SYNC_PROGRESS_DIRECT_CLOSE_FAILED_V2067\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                        try:
                            xbmc.executebuiltin("Dialog.Close(13032,true)")
                            _log("PKM_SYNC_PROGRESS_CLOSE_FALLBACK_V2067 dialog=13032")
                        except Exception:
                            _log("PKM_SYNC_PROGRESS_CLOSE_FALLBACK_FAILED_V2067\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                return None
        try:
            return super(PKMSyncProgressDialog, self).close()
        except Exception:
            return None

    def update(self, percent, message=""):
        self.percent = int(percent or 0)
        if message is not None:
            self.message = _display_text_for_kodi(message)
        self._apply_props()
        try:
            xbmc.sleep(1)
        except Exception:
            pass

    def iscanceled(self):
        return bool(self._canceled)

    def close_and_wait_v1740(self, timeout=2.0):
        """Close the non-interactive progress modal and wait for its owner thread.

        The active sync progress window is intentionally displayed by a helper
        thread so the synchronous library scan can keep updating it.  That
        helper-thread modal must be fully gone before an interactive completion
        dialog is opened on the caller thread.
        """
        try:
            self.close()
        except Exception:
            pass
        self._closed = True
        thread = self._modal_thread
        if thread is not None and thread is not threading.current_thread():
            try:
                thread.join(max(0.0, float(timeout or 0.0)))
            except Exception:
                pass
        alive = bool(thread is not None and thread.is_alive())
        _log("PKM_SYNC_PROGRESS_CLOSE_FOR_COMPLETION_V1740 modal_thread_alive=%d" % (1 if alive else 0))
        return not alive

    def complete_and_wait(self, heading, message="", exit_on_confirm=False, button_label="확인", action_hint="확인 후 홈으로 이동"):
        """Keep the existing progress dialog open as the completion screen.

        The sync worker returns only after the user explicitly presses 확인.
        This prevents Home from being exposed while the first-run transaction is
        still finalising its recommendation index and runtime settings.
        """
        self.heading = _display_text_for_kodi(heading or ADDON_NAME)
        self.message = _display_text_for_kodi(message or "")
        self.percent = 100
        self._completed = True
        self._exit_on_confirm = bool(exit_on_confirm)
        self._completion_button_label = _display_text_for_kodi(button_label or ("종료" if self._exit_on_confirm else "확인"))
        self._completion_action_hint = "" if self._exit_on_confirm else _display_text_for_kodi(action_hint or "확인 후 홈으로 이동")
        self._canceled = False
        self._confirmed = False
        try:
            self._confirm_event.clear()
        except Exception:
            pass
        self._apply_props()
        try:
            if self._shown and self._init_event.is_set() and not self._caller_modal_v1927:
                self.setFocusId(self.CANCEL_ID)
                # Re-apply once after Kodi has consumed the completion property
                # change.  This keeps the single button focused on Windows where
                # the progress control previously retained keyboard ownership.
                xbmc.sleep(20)
                self.setFocusId(self.CANCEL_ID)
            # Android caller-modal focus remains on the same single button set
            # by onInit.  The worker never writes GUI focus across threads.
        except Exception:
            pass
        _log("PKM_SYNC_COMPLETION_WAIT_BEGIN_V1739 focus=300")

        monitor = xbmc.Monitor()
        while not self._confirm_event.wait(0.10):
            if monitor.abortRequested() or self._closed:
                break
        return bool(self._confirmed)

    def _confirm_completion_v1739(self, source="", action_id=None):
        """Confirm the completed initial sync from click, keyboard, or remote OK.

        Some Kodi/Windows combinations deliver Enter/OK to WindowXMLDialog as
        onAction(ACTION_SELECT_ITEM) without calling onClick() for the focused
        transparent button.  Treat every select/enter action as the one visible
        completion button while completion mode is active.
        """
        if not self._completed:
            return False
        self._confirmed = True
        try:
            self._confirm_event.set()
        except Exception:
            pass
        try:
            focus_id = self.getFocusId()
        except Exception:
            focus_id = -1
        _log("PKM_SYNC_COMPLETION_CONFIRM_V1739 source=%s action=%s focus=%s" % (
            source or "unknown", "" if action_id is None else action_id, focus_id
        ))
        if self._exit_on_confirm:
            _log("PKM_INITIAL_SYNC_EXIT_REQUEST_V2048 source=%s action=%s" % (source or "unknown", "" if action_id is None else action_id), xbmc.LOGINFO)
            request_kodi_exit_v2171(
                reason="sync_completion_exit_v2171",
                title="Kodi 종료",
                detail="변경 사항을 적용하려면 Kodi를 다시 실행해주세요.",
            )
            return True
        try:
            self.close()
        except Exception:
            pass
        return True

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.CANCEL_ID:
            if self._completed:
                self._confirm_completion_v1739(source="onclick", action_id=controlId)
                return
            self._canceled = True
            try:
                self.close()
            except Exception:
                pass

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        # ACTION_SELECT_ITEM=7, PLAYER_PLAY=79, MOUSE_LEFT_CLICK=100, ENTER=135.
        # In completion mode there is exactly one actionable control, so these
        # are all equivalent to pressing the highlighted 확인 button.
        if self._completed and aid in (7, 79, 100, 135):
            self._confirm_completion_v1739(source="onaction", action_id=aid)
            return
        if aid in (9, 10, 92, 216, 247):
            if self._completed:
                # Completion requires explicit 확인; Back must not expose Home
                # before the initial setup transaction has been acknowledged.
                return
            self._canceled = True
            try:
                self.close()
            except Exception:
                pass

class PKMSyncCompletionDialog(xbmcgui.WindowXMLDialog):
    """Interactive completion dialog owned by the current plugin thread.

    Kodi WindowXMLDialog input callbacks are only reliable when ``doModal()`` is
    invoked by the caller that owns the dialog flow.  The active progress window
    is non-interactive and may run on a helper thread, but this completion window
    is opened only after the progress modal has closed and is always modal on the
    current settings/plugin thread.
    """
    CONFIRM_ID = 300
    PROGRESS_ID = 20

    def __init__(self, *args, **kwargs):
        self.heading = _display_text_for_kodi(kwargs.pop("heading", ADDON_NAME))
        self.message = _display_text_for_kodi(kwargs.pop("message", ""))
        self.confirmed = False
        self.exit_on_confirm = bool(kwargs.pop("exit_on_confirm", False))
        self.button_label = _display_text_for_kodi(kwargs.pop("button_label", "종료" if self.exit_on_confirm else "확인"))
        self.action_hint = "" if self.exit_on_confirm else _display_text_for_kodi(kwargs.pop("action_hint", "확인 후 홈으로 이동"))
        self._ready = threading.Event()
        super(PKMSyncCompletionDialog, self).__init__(*args, **kwargs)

    def _split_message(self):
        parts = [x for x in _display_text_for_kodi(self.message).split("\n")]
        return (
            parts[0] if len(parts) > 0 else "",
            parts[1] if len(parts) > 1 else "",
            parts[2] if len(parts) > 2 else "",
        )

    def _apply_props(self):
        line1, line2, line3 = self._split_message()
        values = {
            "PlexKM.Sync.Title": self.heading or ADDON_NAME,
            "PlexKM.Sync.Line1": line1,
            "PlexKM.Sync.Line2": line2,
            "PlexKM.Sync.Line3": line3,
            "PlexKM.Sync.Percent": "100",
            "PlexKM.Sync.ActionHint": self.action_hint,
            "PlexKM.Sync.ButtonLabel": self.button_label,
            "PlexKM.Sync.Completed": "1",
        }
        try:
            gwin = xbmcgui.Window(10000)
            for key, value in values.items():
                gwin.setProperty(key, _display_text_for_kodi(value))
        except Exception:
            pass
        try:
            for key, value in values.items():
                self.setProperty(key, _display_text_for_kodi(value))
        except Exception:
            pass

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        self._apply_props()
        # v1741 root fix: the completion window is a fresh WindowXMLDialog, so
        # its progress control starts at Kodi's default value even though the
        # text property already says 100%.  Set the actual ControlProgress to
        # 100 on this dialog's GUI callback instead of relying on the previous
        # worker-owned progress window state.
        progress_percent = -1
        try:
            progress = self.getControl(self.PROGRESS_ID)
            progress.setPercent(100)
            progress_percent = 100
        except Exception:
            _log("PKM_SYNC_COMPLETION_PROGRESS_SET_FAILED_V1741\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        _log("PKM_SYNC_COMPLETION_XML_FOCUS_OWNER_V1969 defaultcontrol=300 python_focus_write=0")
        try:
            self._ready.set()
        except Exception:
            pass
        _log(
            "PKM_SYNC_COMPLETION_MODAL_READY_V1741 focus=%s progress_percent=%s owner_thread=%s"
            % (
                self.getFocusId() if hasattr(self, "getFocusId") else -1,
                progress_percent,
                threading.current_thread().name,
            )
        )

    def _confirm(self, source, action_id=None):
        self.confirmed = True
        try:
            focus_id = self.getFocusId()
        except Exception:
            focus_id = -1
        _log(
            "PKM_SYNC_COMPLETION_CONFIRM_V1740 source=%s action=%s focus=%s owner_thread=%s"
            % (
                source or "unknown",
                "" if action_id is None else action_id,
                focus_id,
                threading.current_thread().name,
            )
        )
        if self.exit_on_confirm:
            _log("PKM_INITIAL_SYNC_EXIT_REQUEST_V2171 source=%s action=%s" % (source or "unknown", "" if action_id is None else action_id), xbmc.LOGINFO)
            request_kodi_exit_v2171(
                reason="sync_completion_modal_exit_v2171",
                title="Kodi 종료",
                detail="변경 사항을 적용하려면 Kodi를 다시 실행해주세요.",
            )
            return
        try:
            self.close()
        except Exception:
            pass

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if int(controlId) == self.CONFIRM_ID:
            self._confirm("onclick", controlId)

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        # Standard Kodi select/enter actions.  Mouse activation is normally
        # delivered through onClick(), but action 100 is accepted as well.
        if aid in (7, 79, 100, 135):
            self._confirm("onaction", aid)
            return
        if aid in (9, 10, 92, 216, 247):
            # Initial setup completion is transactional; acknowledge it with the
            # single visible button rather than dismissing the final state.
            return

    def show_modal_v1740(self):
        _log(
            "PKM_SYNC_COMPLETION_MODAL_BEGIN_V1740 owner_thread=%s helper_thread=0"
            % threading.current_thread().name
        )
        self._apply_props()
        self.doModal()
        _log(
            "PKM_SYNC_COMPLETION_MODAL_END_V1740 confirmed=%d owner_thread=%s"
            % (1 if self.confirmed else 0, threading.current_thread().name)
        )
        return bool(self.confirmed)


def create_pkm_sync_completion(heading, message="", exit_on_confirm=False, button_label="확인", action_hint="확인 후 홈으로 이동"):
    return PKMSyncCompletionDialog(
        "plexkm_sync_progress.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "1080i",
        heading=heading or ADDON_NAME,
        message=message or "",
        exit_on_confirm=exit_on_confirm,
        button_label=button_label,
        action_hint=action_hint,
    )



def create_pkm_sync_progress(caller_modal_v1927=False):
    # v1965: PKM WindowXMLDialog is the sole progress UI on every platform.
    # A construction error is fatal for that visible sync request; it must not
    # be hidden by silently switching to Kodi's native DialogProgress.
    try:
        progress = PKMSyncProgressDialog(
            "plexkm_sync_progress.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "1080i",
            heading=ADDON_NAME,
            caller_modal_v1927=bool(caller_modal_v1927),
        )
        _log(
            "PKM_SYNC_PROGRESS_CREATE_UNIFIED_V1965 platform_android=%d "
            "caller_modal=%d dialog=PKMSyncProgressDialog native_fallback=0"
            % (
                1 if xbmc.getCondVisibility("System.Platform.Android") else 0,
                1 if caller_modal_v1927 else 0,
            ),
            xbmc.LOGINFO,
        )
        return progress
    except Exception as exc:
        detail = traceback.format_exc()
        _log(
            "PKM_SYNC_DIALOG_FATAL_V1965 platform_android=%d "
            "caller_modal_requested=%d xml=plexkm_sync_progress.xml "
            "native_fallback=0 sync_started=0 exception=%s\n%s"
            % (
                1 if xbmc.getCondVisibility("System.Platform.Android") else 0,
                1 if caller_modal_v1927 else 0,
                exc,
                detail,
            ),
            xbmc.LOGERROR,
        )
        raise RuntimeError("PKM sync progress dialog could not be created")


def progress_create(progress, heading, message=""):
    heading = _display_text_for_kodi(heading)
    message = _display_text_for_kodi(message)
    try:
        progress.create(heading, message)
    except TypeError:
        progress.create(heading)
        try:
            if message:
                progress.update(0, message)
        except Exception:
            pass


def progress_update(progress, percent, message=""):
    if progress is None:
        return
    message = _display_text_for_kodi(message)
    try:
        progress.update(int(percent), message)
    except TypeError:
        try:
            progress.update(int(percent))
        except Exception:
            pass


def progress_complete_and_wait(progress, heading, message="", exit_on_confirm=False, button_label="확인", action_hint="확인 후 홈으로 이동"):
    """Close the worker-owned progress window, then confirm on caller thread.

    v1740 root fix: the old implementation waited for input on the same
    WindowXMLDialog whose ``doModal()`` was running in a daemon thread.  Kodi
    painted that window but did not dispatch its onClick/onAction callbacks.
    The interactive completion screen is now a fresh modal dialog opened
    synchronously on the current settings/plugin thread.
    """
    heading = _display_text_for_kodi(heading or ADDON_NAME)
    message = _display_text_for_kodi(message or "")

    try:
        if progress is not None and bool(getattr(progress, "_caller_modal_v1927", False)):
            # v1928: Android keeps the same caller-owned PKM modal visible and
            # changes its single button from 취소 to 확인.  The worker waits on an
            # event while input remains owned by the caller thread.
            return bool(progress.complete_and_wait(heading, message, exit_on_confirm=exit_on_confirm, button_label=button_label, action_hint=action_hint))
        if progress is not None:
            close_wait = getattr(progress, "close_and_wait_v1740", None)
            if callable(close_wait):
                if not close_wait(timeout=2.5):
                    _log("PKM_SYNC_PROGRESS_CLOSE_TIMEOUT_V1740", xbmc.LOGWARNING)
            else:
                try:
                    progress.close()
                except Exception:
                    pass
                try:
                    xbmc.sleep(80)
                except Exception:
                    pass

        dialog = create_pkm_sync_completion(heading, message, exit_on_confirm=exit_on_confirm, button_label=button_label, action_hint=action_hint)
        return bool(dialog.show_modal_v1740())
    except Exception:
        _log("PKM_SYNC_COMPLETION_MODAL_FAILED_V1740\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        try:
            xbmcgui.Dialog().ok(heading, message)
            return True
        except Exception:
            return False
