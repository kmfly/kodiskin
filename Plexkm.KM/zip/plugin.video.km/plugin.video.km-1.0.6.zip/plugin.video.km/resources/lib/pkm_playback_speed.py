# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import re
import sys
import xbmc
import xbmcgui

WIN = xbmcgui.Window(10000)

def _log(msg):
    try:
        xbmc.log('[PKM][PlaybackSpeed] %s' % msg, xbmc.LOGINFO)
    except Exception:
        pass

def _set_props(key, label):
    try:
        WIN.setProperty('PKM.PlaybackSpeedKey', key)
        WIN.setProperty('PKM.PlaybackSpeedLabel', label)
    except Exception:
        pass

def _wait(ms=140):
    xbmc.sleep(ms)

def _play_if_paused():
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin('PlayerControl(Play)')
        _wait(220)

def _speed_value():
    raw = xbmc.getInfoLabel('Player.PlaySpeed') or ''
    m = re.search(r'-?\d+(?:\.\d+)?', raw.replace(',', '.'))
    if not m:
        return 1.0, raw
    try:
        return float(m.group(0)), raw
    except Exception:
        return 1.0, raw

def _tempo(target):
    target = float(target)
    _play_if_paused()
    # Return from FF/REW if needed. Do not blindly toggle play when already playing.
    cur, raw = _speed_value()
    if cur <= 0.01 or abs(cur) >= 2.0:
        xbmc.executebuiltin('PlayerControl(Play)')
        _wait(220)
    for _ in range(24):
        cur, raw = _speed_value()
        if abs(cur - target) <= 0.04:
            _log('tempo reached target=%s raw=%s' % (target, raw))
            return
        xbmc.executebuiltin('PlayerControl(TempoUp)' if cur < target else 'PlayerControl(TempoDown)')
        _wait(160)
    cur, raw = _speed_value()
    _log('tempo final target=%s cur=%s raw=%s' % (target, cur, raw))

def _ff(n):
    n = int(n)
    _play_if_paused()
    for _ in range({2:1, 4:2, 8:3, 16:4, 32:5}.get(n,1)):
        xbmc.executebuiltin('PlayerControl(Forward)')
        _wait(160)
    _log('ff target=%s raw=%s' % (n, _speed_value()[1]))

def _rew(n):
    n = int(n)
    _play_if_paused()
    for _ in range({2:1, 4:2, 8:3, 16:4, 32:5}.get(n,1)):
        xbmc.executebuiltin('PlayerControl(Rewind)')
        _wait(160)
    _log('rew target=%s raw=%s' % (n, _speed_value()[1]))

def main():
    arg = (sys.argv[1] if len(sys.argv) > 1 else '1').strip().lower()
    try:
        if arg.startswith('ff'):
            n = arg.replace('ff','') or '2'
            _set_props('ff'+n, '▶▶ X' + n)
            _ff(n)
        elif arg.startswith('rew'):
            n = arg.replace('rew','') or '2'
            _set_props('rew'+n, '◀◀ X' + n)
            _rew(n)
        else:
            v = arg.replace('x','')
            key = '1' if v in ('1','1.0') else v
            _set_props(key, '▷ X' + ('1' if key == '1' else key))
            _tempo(float(v))
    except Exception as exc:
        _log('error arg=%s exc=%r' % (arg, exc))

if __name__ == '__main__':
    main()
