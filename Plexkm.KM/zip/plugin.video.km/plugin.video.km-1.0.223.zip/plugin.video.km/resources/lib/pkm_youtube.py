# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM YouTube data layer (R79).

Two environments, chosen automatically:

* no API key (default): InnerTube (the endpoints youtube.com itself uses) for
  search, channel pages and topic hubs, channel RSS as a fallback.
* API key set (YouTube Data API v3): real KR "most popular" chart and its
  categories, official search, channel uploads.  Any API failure (quota,
  invalid key, network) falls back to the no-key path for that request.

Subscriptions are owned by PKM (addon_data json); nothing touches the Google
account.  Playback is handed to the YouTube app on Android (Shield).
"""

import json
import os
import re
import threading
import time
import traceback

try:
    from urllib.request import Request, urlopen
    from urllib.parse import quote, urlencode
    from urllib.error import HTTPError
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen, HTTPError  # type: ignore
    from urllib import quote, urlencode  # type: ignore

import xbmc

try:
    import xbmcvfs
except Exception:  # pragma: no cover
    xbmcvfs = None

try:
    import xbmcaddon
except Exception:  # pragma: no cover
    xbmcaddon = None

LOG_TAG = "[plugin.video.km]"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36")
IT_BASE = "https://www.youtube.com/youtubei/v1/"
IT_CLIENT_VERSION_DEFAULT = "2.20251020.01.00"
API_BASE = "https://www.googleapis.com/youtube/v3/"
HL = "ko"
GL = "KR"
TIMEOUT = 12.0

ROW_TTL_SEC = 20 * 60
CHANNEL_TTL_SEC = 20 * 60
SEARCH_TTL_SEC = 10 * 60
SUB_FEED_MAX = 40
CHANNEL_ROW_MAX = 30

# Data API categories shown as extra "popular" rows in key mode.
API_POPULAR_CATEGORIES = (
    ("10", "인기 음악"),
    ("20", "인기 게임"),
    ("17", "인기 스포츠"),
    ("24", "인기 엔터테인먼트"),
    ("25", "인기 뉴스"),
)

# No-key hubs.  YouTube removed the Trending page, so these are the closest
# key-free popular sources that are already localised for KR.
TOPIC_SPORTS = "UCEgdi0XIXXZ-qJOFPf4JSKw"
TOPIC_MUSIC = "UC-9-kyTW8ZkZNDHQJ6FgpwQ"
CHANNEL_VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
SEARCH_PARAMS_TODAY = "EgIIAg%3D%3D"

_lock = threading.RLock()
_client_version = [None]


def log(msg, level=None):
    try:
        xbmc.log("%s YOUTUBE_R79 %s" % (LOG_TAG, msg), xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


# ---------------------------------------------------------------- storage

def _data_dir():
    path = ""
    try:
        if xbmcaddon is not None:
            prof = xbmcaddon.Addon("plugin.video.km").getAddonInfo("profile")
            if xbmcvfs is not None:
                path = xbmcvfs.translatePath(prof)
            else:
                path = xbmc.translatePath(prof)
    except Exception:
        path = ""
    if not path:
        path = os.path.join(os.path.expanduser("~"), ".pkm_youtube")
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        pass
    return path


def _json_path(name):
    return os.path.join(_data_dir(), name)


def _load_json(name, default):
    try:
        with open(_json_path(name), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


_RESTORING = [False]
_BACKUP_FILES = ("youtube_settings_r79.json", "youtube_subs_r79.json",
                 "youtube_account_r79.json", "youtube_account_subs_r79.json")


def _backup_after_save(name):
    if name not in _BACKUP_FILES or _RESTORING[0]:
        return
    try:
        from resources.lib import pkm_youtube_backup
        pkm_youtube_backup.schedule(name)
    except Exception:
        pass


def _save_json(name, value):
    ok = _save_json_raw(name, value)
    if ok:
        _backup_after_save(name)
    return ok


def _save_json_raw(name, value):
    path = _json_path(name)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(value, fh, ensure_ascii=False)
        try:
            os.replace(tmp, path)
        except Exception:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
        return True
    except Exception:
        log("SAVE_FAILED name=%s err=%s" % (name, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
        return False


SETTINGS_FILE = "youtube_settings_r79.json"
SUBS_FILE = "youtube_subs_r79.json"
CACHE_FILE = "youtube_cache_r79.json"


def get_api_key():
    with _lock:
        return str(_load_json(SETTINGS_FILE, {}).get("api_key") or "").strip()


def set_api_key(key):
    with _lock:
        data = _load_json(SETTINGS_FILE, {})
        key = str(key or "").strip()
        if key:
            data["api_key"] = key
        else:
            data.pop("api_key", None)
        data["api_key_bad_until"] = 0
        _save_json(SETTINGS_FILE, data)
        cache_clear()
    log("API_KEY_SET present=%d" % (1 if key else 0))


def _api_key_usable():
    with _lock:
        data = _load_json(SETTINGS_FILE, {})
    key = str(data.get("api_key") or "").strip()
    if not key:
        return ""
    if float(data.get("api_key_bad_until") or 0) > time.time():
        return ""
    return key


def _api_key_mark_bad(reason, seconds):
    with _lock:
        data = _load_json(SETTINGS_FILE, {})
        data["api_key_bad_until"] = time.time() + seconds
        data["api_key_bad_reason"] = reason
        _save_json(SETTINGS_FILE, data)
    log("API_KEY_SUSPEND reason=%s seconds=%d" % (reason, seconds), xbmc.LOGWARNING)


def _account():
    try:
        from resources.lib import pkm_youtube_account
        return pkm_youtube_account
    except Exception:
        return None


def _api_usable():
    """True when Data API calls can be made: an API key, or a linked account
    (Bearer token; no key needed)."""
    if _api_key_usable():
        return True
    with _lock:
        bad = float(_load_json(SETTINGS_FILE, {}).get("api_key_bad_until") or 0) > time.time()
    acc = _account()
    return bool(acc and not bad and acc.is_linked())


def api_mode():
    """'api' when a usable key or account exists, else 'innertube'."""
    return "api" if _api_usable() else "innertube"


SEARCH_HISTORY_MAX = 12


def search_history():
    with _lock:
        return [q for q in (_load_json(SETTINGS_FILE, {}).get("search_history") or []) if q]


def add_search_history(query):
    query = str(query or "").strip()
    if len(query) < 2:
        return
    with _lock:
        data = _load_json(SETTINGS_FILE, {})
        hist = [q for q in (data.get("search_history") or []) if q and q != query]
        data["search_history"] = ([query] + hist)[:SEARCH_HISTORY_MAX]
        _save_json(SETTINGS_FILE, data)


def _local_subs():
    with _lock:
        subs = _load_json(SUBS_FILE, [])
    return [s for s in subs if isinstance(s, dict) and s.get("id")]


def list_subs():
    """PKM local subscriptions + the linked account's subscriptions (deduped,
    local first)."""
    subs = _local_subs()
    acc = _account()
    if acc is not None:
        try:
            seen = set(s["id"] for s in subs)
            for s in acc.account_subs():
                if s["id"] not in seen:
                    seen.add(s["id"])
                    subs.append(s)
        except Exception:
            log("ACCOUNT_SUBS_READ_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return subs


def is_subscribed(channel_id):
    cid = str(channel_id or "")
    return any(s.get("id") == cid for s in list_subs())


def is_account_sub(channel_id):
    cid = str(channel_id or "")
    if any(s.get("id") == cid for s in _local_subs()):
        return False
    return any(s.get("id") == cid and s.get("account") for s in list_subs())


def subscribe(channel):
    cid = str((channel or {}).get("id") or "")
    if not cid:
        return False
    with _lock:
        subs = _local_subs()
        if any(s.get("id") == cid for s in subs):
            return True
        subs.append({
            "id": cid,
            "title": str(channel.get("title") or ""),
            "thumb": small_avatar(channel.get("thumb") or ""),
            "added": int(time.time()),
        })
        _save_json(SUBS_FILE, subs)
        mark_rows_stale("all", "subs")
    log("SUBSCRIBE channel=%s title=%s" % (cid, channel.get("title") or ""))
    return True


def unsubscribe(channel_id):
    cid = str(channel_id or "")
    with _lock:
        subs = [s for s in _local_subs() if s.get("id") != cid]
        _save_json(SUBS_FILE, subs)
        mark_rows_stale("all", "subs")
    log("UNSUBSCRIBE channel=%s" % cid)
    return True


_cache_mem = [None]


def _cache_all():
    if _cache_mem[0] is None:
        _cache_mem[0] = _load_json(CACHE_FILE, {})
        if not isinstance(_cache_mem[0], dict):
            _cache_mem[0] = {}
    return _cache_mem[0]


def cache_get(key, max_age=None):
    with _lock:
        ent = _cache_all().get(key)
    if not isinstance(ent, dict):
        return None
    if max_age is not None and (time.time() - float(ent.get("t") or 0)) > max_age:
        return None
    return ent.get("v")


def cache_age(key):
    with _lock:
        ent = _cache_all().get(key)
    if not isinstance(ent, dict):
        return None
    return time.time() - float(ent.get("t") or 0)


def cache_put(key, value):
    with _lock:
        data = _cache_all()
        data[key] = {"t": time.time(), "v": value}
        # keep the file small: newest 60 entries
        if len(data) > 60:
            for k, _ in sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[:len(data) - 60]:
                data.pop(k, None)
        _save_json(CACHE_FILE, data)


def cache_drop(key):
    with _lock:
        if _cache_all().pop(key, None) is not None:
            _save_json(CACHE_FILE, _cache_all())


def cache_mark_stale(key):
    """Keep the value (instant paint) but force the next refresh."""
    with _lock:
        ent = _cache_all().get(key)
        if isinstance(ent, dict):
            ent["t"] = 0
            _save_json(CACHE_FILE, _cache_all())


def cache_clear():
    with _lock:
        _cache_mem[0] = {}
        _save_json(CACHE_FILE, {})


# ---------------------------------------------------------------- http

def _http(url, data=None, headers=None, timeout=TIMEOUT):
    hdrs = {"User-Agent": UA, "Accept-Language": "ko-KR,ko;q=0.9"}
    if headers:
        hdrs.update(headers)
    body = None
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    req = Request(url, data=body, headers=hdrs)
    resp = urlopen(req, timeout=timeout)
    try:
        return resp.read().decode("utf-8", "replace")
    finally:
        try:
            resp.close()
        except Exception:
            pass


def _client_ver():
    if _client_version[0]:
        return _client_version[0]
    cached = cache_get("it_client_version", 24 * 3600)
    _client_version[0] = cached or IT_CLIENT_VERSION_DEFAULT
    return _client_version[0]


def _refresh_client_version():
    try:
        html = _http("https://www.youtube.com/?hl=ko&gl=KR", timeout=10.0)
        m = re.search(r'"INNERTUBE_CLIENT_VERSION":"([0-9.]+)"', html) or \
            re.search(r'"clientVersion":"(2\.[0-9.]+)"', html)
        if m:
            _client_version[0] = m.group(1)
            cache_put("it_client_version", m.group(1))
            log("IT_CLIENT_VERSION_REFRESH version=%s" % m.group(1))
            return True
    except Exception:
        log("IT_CLIENT_VERSION_REFRESH_FAILED err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return False


def _it(endpoint, body):
    t0 = time.time()
    for attempt in (1, 2):
        payload = {"context": {"client": {
            "clientName": "WEB", "clientVersion": _client_ver(),
            "hl": HL, "gl": GL, "timeZone": "Asia/Seoul",
        }}}
        payload.update(body)
        try:
            text = _http(IT_BASE + endpoint + "?prettyPrint=false", data=payload)
            log("IT_OK endpoint=%s ms=%d bytes=%d" % (endpoint, int((time.time() - t0) * 1000), len(text)))
            return json.loads(text)
        except HTTPError as exc:
            log("IT_HTTP_ERROR endpoint=%s code=%s attempt=%d" % (endpoint, getattr(exc, "code", "?"), attempt), xbmc.LOGWARNING)
            if attempt == 1 and getattr(exc, "code", 0) in (400, 403) and _refresh_client_version():
                continue
            raise
    return {}


def _api(path, params):
    key = _api_key_usable()
    q = dict(params)
    hdrs = None
    if key:
        q["key"] = key
    else:
        acc = _account()
        tok = acc.bearer() if (acc is not None and _api_usable()) else ""
        if not tok:
            raise RuntimeError("no_api_key")
        hdrs = {"Authorization": "Bearer " + tok}
    url = API_BASE + path + "?" + urlencode(q)
    t0 = time.time()
    try:
        text = _http(url, headers=hdrs)
        log("API_OK path=%s ms=%d" % (path, int((time.time() - t0) * 1000)))
        return json.loads(text)
    except HTTPError as exc:
        code = getattr(exc, "code", 0)
        reason = ""
        try:
            err = json.loads(exc.read().decode("utf-8", "replace"))
            reason = str(((err.get("error") or {}).get("errors") or [{}])[0].get("reason") or "")
        except Exception:
            pass
        log("API_HTTP_ERROR path=%s code=%s reason=%s" % (path, code, reason), xbmc.LOGWARNING)
        if reason in ("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded"):
            _api_key_mark_bad(reason, 3 * 3600)
        elif reason in ("keyInvalid", "accessNotConfigured", "forbidden") or code in (400, 403) and reason.startswith("key"):
            _api_key_mark_bad(reason or str(code), 6 * 3600)
        raise


def test_api_key(key):
    """Return (ok, message) for a key the user just typed."""
    try:
        url = API_BASE + "videos?" + urlencode({
            "part": "id", "chart": "mostPopular", "regionCode": GL, "maxResults": 1, "key": key})
        _http(url)
        return True, "API 키가 확인되었습니다"
    except HTTPError as exc:
        reason = ""
        try:
            err = json.loads(exc.read().decode("utf-8", "replace"))
            reason = str(((err.get("error") or {}).get("errors") or [{}])[0].get("reason") or "")
        except Exception:
            pass
        return False, "API 키 확인 실패 (%s)" % (reason or getattr(exc, "code", "오류"))
    except Exception as exc:
        return False, "API 키 확인 실패 (%s)" % exc.__class__.__name__


# ---------------------------------------------------------------- parsing

def _txt(node):
    if not node:
        return ""
    if isinstance(node, str):
        return node
    if "simpleText" in node:
        return str(node.get("simpleText") or "")
    if "content" in node:
        return str(node.get("content") or "")
    return "".join(str(r.get("text") or "") for r in node.get("runs", []) or [])


def _best_thumb(thumbs):
    try:
        ordered = sorted(thumbs or [], key=lambda t: int(t.get("width") or 0), reverse=True)
        if not ordered:
            return ""
        # PKM_PATCH_YT_THUMB: YT Music auto-playlist mosaics (i*.ytimg.com/s_p/...)
        # advertise a maxresdefault size that 404s on the CDN, leaving blank cards.
        # Its sqp/rs signature is size-specific, so the filename can't be rewritten;
        # instead prefer the next smaller listed size, which carries its own valid
        # signature. Only the maxres s_p mosaic is skipped, and only when an
        # alternative exists — every other thumbnail keeps the largest size.
        def _is_dead_mosaic(url):
            return "/s_p/" in url and "maxresdefault" in url
        best = next((t for t in ordered if not _is_dead_mosaic(str(t.get("url") or ""))), ordered[0])
        url = str(best.get("url") or "")
        if url.startswith("//"):
            url = "https:" + url
        return small_avatar(url)
    except Exception:
        return ""


def small_avatar(url):
    """Channel avatars come as 900px; a 216px card needs far less."""
    return re.sub(r"=s(\d{3,4})-c-k", "=s288-c-k", str(url or ""))


def video_thumb(vid):
    return "https://i.ytimg.com/vi/%s/hq720.jpg" % vid


def video_thumb_fallback(vid):
    return "https://i.ytimg.com/vi/%s/mqdefault.jpg" % vid


def video_backdrop(vid):
    return "https://i.ytimg.com/vi/%s/maxresdefault.jpg" % vid


_AGE_UNITS = (
    ("초", 1), ("분", 60), ("시간", 3600), ("일", 86400), ("주", 7 * 86400),
    ("개월", 30 * 86400), ("달", 30 * 86400), ("년", 365 * 86400),
)


def age_seconds(published_text):
    """'3일 전' -> seconds.  Unknown -> large."""
    s = str(published_text or "")
    m = re.search(r"(\d+)\s*(초|분|시간|일|주|개월|달|년)", s)
    if not m:
        return 10 ** 9
    n = int(m.group(1))
    for unit, sec in _AGE_UNITS:
        if m.group(2) == unit:
            return n * sec
    return 10 ** 9


def _iso_age(iso):
    try:
        t = time.mktime(time.strptime(iso[:19], "%Y-%m-%dT%H:%M:%S")) - time.timezone
        return max(0, time.time() - t)
    except Exception:
        return 10 ** 9


def age_label(sec):
    sec = int(sec or 0)
    if sec >= 10 ** 9:
        return ""
    for unit, size in (("년", 365 * 86400), ("개월", 30 * 86400), ("주", 7 * 86400),
                       ("일", 86400), ("시간", 3600), ("분", 60)):
        if sec >= size:
            return "%d%s 전" % (sec // size, unit)
    return "방금 전"


def _views_label(n):
    try:
        n = int(n)
    except Exception:
        return ""
    if n >= 100000000:
        return "조회수 %.1f억회" % (n / 100000000.0)
    if n >= 10000:
        v = n / 10000.0
        return "조회수 %s만회" % (("%.1f" % v).rstrip("0").rstrip(".") if v < 10 else "%d" % v)
    if n >= 1000:
        return "조회수 %.1f천회" % (n / 1000.0)
    return "조회수 %d회" % n


def _iso_duration(d):
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", str(d or ""))
    if not m:
        return ""
    days, h, mi, s = [int(x or 0) for x in m.groups()]
    h += days * 24
    if h:
        return "%d:%02d:%02d" % (h, mi, s)
    if mi or s:
        return "%d:%02d" % (mi, s)
    return ""


def _video(vid, title, channel="", channel_id="", duration="", views="", published="",
           live=False, thumb=""):
    return {
        "kind": "video", "id": vid, "title": title, "channel": channel,
        "channel_id": channel_id, "duration": duration, "views": views,
        "published": published, "age": age_seconds(published), "live": bool(live),
        "thumb": thumb or video_thumb(vid),
    }


def _from_video_renderer(v):
    vid = v.get("videoId")
    if not vid:
        return None
    owner = (v.get("ownerText") or v.get("longBylineText") or v.get("shortBylineText") or {})
    channel_id = ""
    try:
        channel_id = owner["runs"][0]["navigationEndpoint"]["browseEndpoint"]["browseId"]
    except Exception:
        pass
    live = False
    for b in v.get("badges", []) or []:
        st = str(((b.get("metadataBadgeRenderer") or {}).get("style")) or "")
        if "LIVE" in st:
            live = True
    duration = _txt(v.get("lengthText"))
    if not duration:
        for ov in v.get("thumbnailOverlays", []) or []:
            ts = ov.get("thumbnailOverlayTimeStatusRenderer")
            if ts:
                duration = _txt(ts.get("text"))
                if str(ts.get("style") or "") == "LIVE":
                    live = True
    return _video(
        vid, _txt(v.get("title")), _txt(owner).split(" 및 ")[0], channel_id, duration,
        _txt(v.get("shortViewCountText")) or _txt(v.get("viewCountText")),
        _txt(v.get("publishedTimeText")).replace("스트리밍 시간: ", ""), live,
    )


def _from_lockup(lk, channel_title="", channel_id=""):
    ctype = str(lk.get("contentType") or "")
    cid = str(lk.get("contentId") or "")
    meta = ((lk.get("metadata") or {}).get("lockupMetadataViewModel") or {})
    title = _txt(meta.get("title"))
    rows = (((meta.get("metadata") or {}).get("contentMetadataViewModel") or {}).get("metadataRows") or [])
    parts = []
    for r in rows:
        parts.append([_txt(p.get("text")) for p in r.get("metadataParts", []) or []])
    img = ((lk.get("contentImage") or {}).get("thumbnailViewModel")
           or ((lk.get("contentImage") or {}).get("collectionThumbnailViewModel") or {}).get("primaryThumbnail", {}).get("thumbnailViewModel")
           or {})
    duration = ""
    live = False
    for ov in img.get("overlays", []) or []:
        for b in ((ov.get("thumbnailBottomOverlayViewModel") or {}).get("badges") or []):
            bv = b.get("thumbnailBadgeViewModel") or {}
            duration = str(bv.get("text") or duration)
            if "LIVE" in str(bv.get("badgeStyle") or ""):
                live = True
        ob = ov.get("thumbnailOverlayBadgeViewModel")
        if ob:
            for b in ob.get("thumbnailBadges", []) or []:
                bv = b.get("thumbnailBadgeViewModel") or {}
                duration = str(bv.get("text") or duration)
    thumb = _best_thumb(((img.get("image") or {}).get("sources")) or [])
    if ctype == "LOCKUP_CONTENT_TYPE_VIDEO" and cid:
        channel = channel_title
        views = published = ""
        flat = [x for row in parts for x in row]
        for x in flat:
            if x.startswith("조회수") or x.endswith("시청 중"):
                views = x
            elif "전" in x and re.search(r"\d", x):
                published = x.replace("스트리밍 시간: ", "")
        if not channel and parts and parts[0]:
            first = parts[0][0]
            if not first.startswith("조회수"):
                channel = first.split(" 및 ")[0]
        return _video(cid, title, channel, channel_id, duration, views, published, live,
                      video_thumb(cid))
    if ctype in ("LOCKUP_CONTENT_TYPE_PLAYLIST", "LOCKUP_CONTENT_TYPE_STATION", "LOCKUP_CONTENT_TYPE_PODCAST") and cid:
        return {
            "kind": "playlist", "id": cid, "title": title,
            "channel": (parts[0][0] if parts and parts[0] else channel_title),
            "channel_id": channel_id, "duration": duration or "재생목록", "views": "",
            "published": "", "age": 10 ** 9, "live": False, "thumb": thumb,
        }
    return None


def _from_channel_renderer(c):
    cid = c.get("channelId")
    if not cid:
        return None
    return {
        "kind": "channel", "id": cid, "title": _txt(c.get("title")),
        "channel": _txt(c.get("title")), "channel_id": cid,
        "thumb": _best_thumb((c.get("thumbnail") or {}).get("thumbnails")),
        "views": _txt(c.get("videoCountText")) or _txt(c.get("subscriberCountText")),
        "duration": "", "published": "", "age": 10 ** 9, "live": False,
    }


_WALK_SKIP = frozenset((
    "reelShelfRenderer", "shortsLockupViewModel", "reelItemRenderer",
    "hotkeyDialogRenderer", "topbar", "header", "frameworkUpdates",
))


def _walk_items(node, out, seen, channel_title="", channel_id=""):
    if isinstance(node, dict):
        for key in ("videoRenderer", "gridVideoRenderer", "compactVideoRenderer"):
            if key in node:
                it = _from_video_renderer(node[key])
                if it:
                    if channel_title and not it["channel"]:
                        it["channel"] = channel_title
                    if channel_id and not it["channel_id"]:
                        it["channel_id"] = channel_id
                    if it["id"] not in seen:
                        seen.add(it["id"])
                        out.append(it)
                return
        if "lockupViewModel" in node:
            it = _from_lockup(node["lockupViewModel"], channel_title, channel_id)
            if it and it["id"] not in seen:
                seen.add(it["id"])
                out.append(it)
            return
        if "channelRenderer" in node:
            it = _from_channel_renderer(node["channelRenderer"])
            if it and it["id"] not in seen:
                seen.add(it["id"])
                out.append(it)
            return
        for key, v in node.items():
            if key in _WALK_SKIP:
                continue
            _walk_items(v, out, seen, channel_title, channel_id)
    elif isinstance(node, list):
        for v in node:
            _walk_items(v, out, seen, channel_title, channel_id)


def _continuation(node):
    found = []

    def walk(o):
        if found:
            return
        if isinstance(o, dict):
            ci = o.get("continuationItemRenderer")
            if ci:
                try:
                    found.append(ci["continuationEndpoint"]["continuationCommand"]["token"])
                    return
                except Exception:
                    pass
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(node)
    return found[0] if found else ""


# Scripts the PKM font (Noto Sans KR) cannot draw: Hebrew/Arabic .. Myanmar.
_UNSUPPORTED_SCRIPT = re.compile("[\u0590-\u08ff\u0900-\u0dff\u0e00-\u0fff\u1000-\u109f]")


def _title_ok(it):
    return not _UNSUPPORTED_SCRIPT.search(it.get("title") or "")


def _shorts_filter(items):
    """Drop Shorts and titles the skin font would render as boxes."""
    return [it for it in items
            if not (it.get("kind") == "video" and _is_short_duration(it.get("duration")))
            and _title_ok(it)]


def _is_short_duration(d):
    m = re.match(r"^(\d+):(\d\d)$", str(d or ""))
    return bool(m and int(m.group(1)) == 0 and int(m.group(2)) <= 60)


# ---------------------------------------------------------------- InnerTube

def it_search(query, continuation=""):
    body = {"continuation": continuation} if continuation else {"query": query}
    d = _it("search", body)
    out = []
    _walk_items(d, out, set())
    videos = [x for x in out if x["kind"] in ("video", "playlist")]
    channels = [x for x in out if x["kind"] == "channel"]
    return {"videos": _shorts_filter(videos), "channels": channels, "continuation": _continuation(d)}


def it_search_today(query):
    d = _it("search", {"query": query, "params": SEARCH_PARAMS_TODAY.replace("%3D", "=")})
    out = []
    _walk_items(d, out, set())
    return _shorts_filter([x for x in out if x["kind"] == "video"])


def _channel_header(d):
    meta = {}

    def walk(o):
        if meta:
            return
        if isinstance(o, dict):
            if "channelMetadataRenderer" in o:
                m = o["channelMetadataRenderer"]
                meta.update({
                    "id": m.get("externalId") or "",
                    "title": m.get("title") or "",
                    "thumb": _best_thumb((m.get("avatar") or {}).get("thumbnails")),
                    "description": m.get("description") or "",
                })
                return
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(d)
    return meta


def it_channel(channel_id, continuation=""):
    if continuation:
        d = _it("browse", {"continuation": continuation})
        header = {}
    else:
        d = _it("browse", {"browseId": channel_id, "params": CHANNEL_VIDEOS_PARAMS})
        header = _channel_header(d)
    out = []
    _walk_items(d, out, set(), header.get("title", ""), channel_id)
    vids = [x for x in out if x["kind"] == "video"]
    for v in vids:
        v["channel_id"] = channel_id
        if header.get("title"):
            v["channel"] = header["title"]
    return {"channel": header, "videos": vids, "continuation": _continuation(d)}


def it_topic(browse_id):
    d = _it("browse", {"browseId": browse_id})
    out = []
    _walk_items(d, out, set())
    return _shorts_filter([x for x in out if x["kind"] in ("video", "playlist")])


def rss_channel(channel_id):
    text = _http("https://www.youtube.com/feeds/videos.xml?channel_id=" + quote(channel_id), timeout=8.0)
    title_m = re.search(r"<title>([^<]*)</title>", text)
    ch_title = _unescape(title_m.group(1)) if title_m else ""
    vids = []
    for ent in re.findall(r"<entry>(.*?)</entry>", text, re.S):
        vid = re.search(r"<yt:videoId>([^<]+)</yt:videoId>", ent)
        if not vid:
            continue
        if "/shorts/" in ent:
            continue
        t = re.search(r"<title>([^<]*)</title>", ent)
        pub = re.search(r"<published>([^<]+)</published>", ent)
        views = re.search(r'views="(\d+)"', ent)
        age = _iso_age(pub.group(1)) if pub else 10 ** 9
        v = _video(vid.group(1), _unescape(t.group(1)) if t else "", ch_title, channel_id, "",
                   _views_label(views.group(1)) if views else "", age_label(age))
        v["age"] = age
        vids.append(v)
    return {"channel": {"id": channel_id, "title": ch_title, "thumb": ""}, "videos": vids, "continuation": ""}


def _unescape(s):
    return (str(s).replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", '"').replace("&#39;", "'"))


# ---------------------------------------------------------------- Data API

def _api_videos_by_ids(ids):
    out = []
    for i in range(0, len(ids), 50):
        chunk = ids[i:i + 50]
        d = _api("videos", {"part": "snippet,contentDetails,statistics", "id": ",".join(chunk), "hl": HL})
        out.extend(_api_video_items(d))
    return out


def _api_video_items(d):
    out = []
    for it in d.get("items", []) or []:
        vid = it.get("id")
        if isinstance(vid, dict):
            vid = vid.get("videoId")
        if not vid:
            continue
        sn = it.get("snippet") or {}
        loc = sn.get("localized") or {}
        age = _iso_age(sn.get("publishedAt") or "")
        live = str(sn.get("liveBroadcastContent") or "") == "live"
        v = _video(
            vid, loc.get("title") or sn.get("title") or "", sn.get("channelTitle") or "",
            sn.get("channelId") or "", "LIVE" if live else _iso_duration((it.get("contentDetails") or {}).get("duration")),
            _views_label((it.get("statistics") or {}).get("viewCount")), age_label(age), live,
        )
        v["age"] = age
        out.append(v)
    return out


def api_most_popular(category_id=None, max_results=30):
    params = {"part": "snippet,contentDetails,statistics", "chart": "mostPopular",
              "regionCode": GL, "maxResults": max_results, "hl": HL}
    if category_id:
        params["videoCategoryId"] = category_id
    return _shorts_filter(_api_video_items(_api("videos", params)))


def api_search(query, max_results=30):
    d = _api("search", {"part": "snippet", "q": query, "type": "video,channel", "maxResults": max_results,
                        "regionCode": GL, "relevanceLanguage": HL})
    vid_ids = []
    channels = []
    for it in d.get("items", []) or []:
        idn = it.get("id") or {}
        sn = it.get("snippet") or {}
        if idn.get("kind") == "youtube#video" and idn.get("videoId"):
            vid_ids.append(idn["videoId"])
        elif idn.get("kind") == "youtube#channel" and idn.get("channelId"):
            channels.append({
                "kind": "channel", "id": idn["channelId"], "title": sn.get("title") or "",
                "channel": sn.get("title") or "", "channel_id": idn["channelId"],
                "thumb": ((sn.get("thumbnails") or {}).get("high") or {}).get("url") or "",
                "views": "", "duration": "", "published": "", "age": 10 ** 9, "live": False,
            })
    videos = _api_videos_by_ids(vid_ids) if vid_ids else []
    order = dict((v, i) for i, v in enumerate(vid_ids))
    videos.sort(key=lambda v: order.get(v["id"], 999))
    return {"videos": _shorts_filter(videos), "channels": channels, "continuation": ""}


def api_channel(channel_id, max_results=CHANNEL_ROW_MAX):
    d = _api("channels", {"part": "snippet,contentDetails", "id": channel_id, "hl": HL})
    items = d.get("items") or []
    if not items:
        raise RuntimeError("channel_not_found")
    ch = items[0]
    sn = ch.get("snippet") or {}
    uploads = ((ch.get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
    header = {
        "id": channel_id, "title": (sn.get("localized") or {}).get("title") or sn.get("title") or "",
        "thumb": ((sn.get("thumbnails") or {}).get("high") or {}).get("url") or "",
        "description": sn.get("description") or "",
    }
    ids = []
    if uploads:
        pl = _api("playlistItems", {"part": "contentDetails", "playlistId": uploads, "maxResults": max_results})
        ids = [(x.get("contentDetails") or {}).get("videoId") for x in pl.get("items", []) or []]
        ids = [x for x in ids if x]
    videos = _shorts_filter(_api_videos_by_ids(ids)) if ids else []
    return {"channel": header, "videos": videos, "continuation": ""}


# ---------------------------------------------------------------- facade

def search(query, continuation=""):
    query = str(query or "").strip()
    if not query and not continuation:
        return {"videos": [], "channels": [], "continuation": ""}
    key = "search:%s" % query
    if not continuation:
        cached = cache_get(key, SEARCH_TTL_SEC)
        if cached:
            return cached
    res = None
    if not continuation and _api_usable():
        try:
            res = api_search(query)
            res["source"] = "api"
        except Exception:
            res = None
    if res is None:
        res = it_search(query, continuation)
        res["source"] = "innertube"
    if not continuation:
        cache_put(key, res)
    log("SEARCH query=%s source=%s videos=%d channels=%d" % (
        query, res.get("source"), len(res.get("videos") or []), len(res.get("channels") or [])))
    return res


def channel(channel_id, continuation="", force=False):
    key = "channel:%s" % channel_id
    if not continuation and not force:
        cached = cache_get(key, CHANNEL_TTL_SEC)
        if cached:
            return cached
    res = None
    if not continuation and _api_usable():
        try:
            res = api_channel(channel_id)
            res["source"] = "api"
        except Exception:
            res = None
    if res is None:
        try:
            res = it_channel(channel_id, continuation)
            res["source"] = "innertube"
        except Exception:
            if continuation:
                raise
            log("CHANNEL_IT_FAILED channel=%s err=%s" % (channel_id, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
            res = rss_channel(channel_id)
            res["source"] = "rss"
    if not continuation:
        cache_put(key, res)
    return res


def cached_channel(channel_id):
    return cache_get("channel:%s" % channel_id)


# ---------------------------------------------------------------- chips (R79b)

CHIPS = (
    ("all", "전체"), ("subs", "구독"), ("news", "뉴스"), ("music", "음악"),
    ("sports", "스포츠"), ("game", "게임"), ("live", "라이브"),
)

# InnerTube search filters
SP_TODAY = "EgIIAg=="          # upload date: today
SP_VIEWS_TODAY = "CAMSAggC"    # today, sorted by views
SP_VIEWS_WEEK = "CAMSAggD"     # this week, sorted by views
SP_LIVE = "CAMSAkAB"           # live now, sorted by viewers

_R_NEWS_TODAY = ("news_today", "오늘의 뉴스", ("search", "뉴스", SP_TODAY))
_R_NEWS_LIVE = ("news_live", "뉴스 라이브", ("search", "뉴스", SP_LIVE))
_R_ECON = ("econ_today", "경제 뉴스", ("search", "경제 뉴스", SP_TODAY))
_R_MUSIC_HUB = ("music_hub", "인기 음악 모음", ("topic", TOPIC_MUSIC))
_R_MV_WEEK = ("mv_week", "이번 주 뮤직비디오", ("search", "뮤직비디오", SP_VIEWS_WEEK))
_R_MUSIC_LIVE = ("music_live", "음악 라이브", ("search", "음악", SP_LIVE))
_R_SPORTS_HUB = ("sports_hub", "스포츠 인기", ("topic", TOPIC_SPORTS))
_R_HIGHLIGHT = ("highlight_today", "오늘의 하이라이트", ("search", "하이라이트", SP_VIEWS_TODAY))
_R_SPORTS_LIVE = ("sports_live", "스포츠 라이브", ("search", "스포츠 중계", SP_LIVE))
_R_GAME_TODAY = ("game_today", "오늘의 게임", ("search", "게임", SP_TODAY))
_R_GAME_LIVE = ("game_live", "게임 라이브", ("search", "게임 방송", SP_LIVE))

CHIP_ROWS = {
    "all": (_R_NEWS_TODAY, _R_SPORTS_HUB, _R_MUSIC_HUB),
    "news": (_R_NEWS_TODAY, _R_NEWS_LIVE, _R_ECON),
    "music": (_R_MUSIC_HUB, _R_MV_WEEK, _R_MUSIC_LIVE),
    "sports": (_R_SPORTS_HUB, _R_HIGHLIGHT, _R_SPORTS_LIVE),
    "game": (_R_GAME_TODAY, _R_GAME_LIVE),
    "live": (_R_NEWS_LIVE, _R_SPORTS_LIVE, _R_MUSIC_LIVE, _R_GAME_LIVE),
    "subs": (),
}

# With an API key each chip leads with the real KR chart for its category.
CHIP_API_CHART = {
    "all": (None, "인기 급상승"),
    "news": ("25", "인기 뉴스"),
    "music": ("10", "인기 음악"),
    "sports": ("17", "인기 스포츠"),
    "game": ("20", "인기 게임"),
}

ROW_MAX = 30


def it_search_filtered(query, params):
    d = _it("search", {"query": query, "params": params})
    out = []
    _walk_items(d, out, set())
    return _shorts_filter([x for x in out if x["kind"] == "video"])


def _fetch_spec(spec):
    kind = spec[0]
    if kind == "search":
        return it_search_filtered(spec[1], spec[2])
    if kind == "topic":
        return it_topic(spec[1])
    if kind == "chart":
        return api_most_popular(spec[1])
    return []


def _parallel(jobs, workers=4, progress=None):
    """jobs: list of (key, fn).  Returns {key: result or None}."""
    results = {}
    pending = list(jobs)
    done = [0]
    lock = threading.Lock()

    def worker():
        while True:
            with lock:
                if not pending:
                    return
                key, fn = pending.pop(0)
            try:
                res = fn()
            except Exception:
                log("JOB_FAILED key=%s err=%s" % (key, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
                res = None
            with lock:
                results[key] = res
                done[0] += 1
                n = done[0]
            if progress:
                try:
                    progress(n, len(jobs))
                except Exception:
                    pass

    threads = [threading.Thread(target=worker, name="PKMYouTubeJobR79") for _ in range(min(workers, len(jobs)))]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(60)
    return results


def _subs_parts(progress=None):
    """(avatar_row, new_videos_row, per_channel_rows) for the subscription list."""
    subs = list_subs()
    if not subs:
        return None, None, []
    if len(subs) <= SUBS_RICH_MAX:
        fetched = _parallel([(s["id"], (lambda cid=s["id"]: channel(cid))) for s in subs], progress=progress)
    else:
        # account subscriptions can be hundreds of channels: the free RSS feed
        # (15 newest uploads) keeps the API quota and the wait small.
        fetched = _parallel([(s["id"], (lambda cid=s["id"]: rss_cached(cid))) for s in subs[:SUBS_FEED_CHANNELS]],
                            workers=8, progress=progress)
    avatars = []
    feed = []
    per_channel = []
    changed = False
    for s in subs:
        ch = fetched.get(s["id"]) or cached_channel(s["id"]) or {"videos": [], "channel": {}}
        vids = list(ch.get("videos") or [])
        hdr = ch.get("channel") or {}
        if hdr.get("thumb") and not s.get("thumb"):
            s["thumb"] = small_avatar(hdr["thumb"])
            changed = True
        if hdr.get("title") and not s.get("title"):
            s["title"] = hdr["title"]
            changed = True
        newest = min([v.get("age", 10 ** 9) for v in vids] or [10 ** 9])
        avatars.append({
            "kind": "channel", "id": s["id"], "title": s.get("title") or "",
            "channel": s.get("title") or "", "channel_id": s["id"], "thumb": small_avatar(s.get("thumb") or ""),
            "views": "", "duration": "", "published": "", "age": newest, "live": False,
            "new": newest < 86400,
        })
        feed.extend(vids[:15])
        if vids and len(per_channel) < 400:
            per_channel.append({"key": "ch:%s" % s["id"], "title": s.get("title") or hdr.get("title") or "채널",
                                "items": vids[:CHANNEL_ROW_MAX], "channel_id": s["id"]})
    if changed:
        local_ids = set(x["id"] for x in _local_subs())
        with _lock:
            _save_json(SUBS_FILE, [x for x in subs if x["id"] in local_ids])
    avatars.sort(key=lambda a: a["age"])          # channels with new uploads first
    feed.sort(key=lambda v: v.get("age", 10 ** 9))
    per_channel.sort(key=lambda r: min([v.get("age", 10 ** 9) for v in r["items"]] or [10 ** 9]))
    per_channel = per_channel[:SUBS_CHANNEL_ROWS]
    avatar_row = {"key": "subs", "title": "구독 채널", "items": avatars, "avatars": True}
    feed_row = {"key": "sub_feed", "title": "구독 채널 새 영상", "items": feed[:SUB_FEED_MAX]} if feed else None
    return avatar_row, feed_row, per_channel


SUBS_RICH_MAX = 15          # up to this many subs: full channel pages (durations)
SUBS_FEED_CHANNELS = 300    # RSS feed fetch cap for very large lists
SUBS_CHANNEL_ROWS = 9       # per-channel rows (UI has 12 row slots)


_rss_mem = {}


def rss_cached(channel_id):
    """RSS feed with an in-memory cache only (the json cache keeps 60 entries;
    hundreds of feeds would evict the chip rows).  The built rows themselves
    are cached, so the next open still paints instantly."""
    ent = _rss_mem.get(channel_id)
    if ent and time.time() - ent[0] < CHANNEL_TTL_SEC:
        return ent[1]
    res = rss_channel(channel_id)
    _rss_mem[channel_id] = (time.time(), res)
    return res


def cached_rows(chip):
    return cache_get("rows:%s" % chip)


def rows_stale(chip):
    age = cache_age("rows:%s" % chip)
    return age is None or age > ROW_TTL_SEC


def mark_rows_stale(*chips):
    for chip in chips:
        cache_mark_stale("rows:%s" % chip)


def build_rows(chip, progress=None):
    """Rows for one chip; cached for an instant next paint."""
    t0 = time.time()
    rows = []
    mode = "api" if _api_usable() else "innertube"
    if chip == "subs":
        avatar_row, feed_row, per_channel = _subs_parts(progress)
        rows = [r for r in (avatar_row, feed_row) if r] + per_channel
    else:
        specs = list(CHIP_ROWS.get(chip) or ())
        chart = CHIP_API_CHART.get(chip)
        if chart and mode == "api":
            specs.insert(0, ("chart_%s" % (chart[0] or "all"), chart[1], ("chart", chart[0])))
        jobs = [(key, (lambda spec=spec: _fetch_spec(spec))) for key, title, spec in specs]
        feed_row = None
        if chip == "all" and list_subs():
            jobs.append(("__subs__", lambda: _subs_parts()))
        res = _parallel(jobs, progress=progress)
        if chip == "all" and res.get("__subs__"):
            feed_row = res["__subs__"][1]
        if feed_row:
            rows.append(feed_row)
        for key, title, spec in specs:
            items = res.get(key) or []
            if not items and spec[0] == "chart":
                mode = "innertube"     # key failed; the rest of the chip still shows
            if items:
                rows.append({"key": key, "title": title, "items": items[:ROW_MAX]})
    result = {"rows": rows, "mode": mode, "built": int(time.time()), "chip": chip}
    cache_put("rows:%s" % chip, result)
    log("ROWS_BUILD chip=%s mode=%s rows=%d ms=%d" % (chip, mode, len(rows), int((time.time() - t0) * 1000)))
    return result


# ---------------------------------------------------------------- playback

YT_ANDROID_TV = "com.google.android.youtube.tv"
YT_ANDROID = "com.google.android.youtube"


def _is_android():
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        return False


def plays_externally():
    """True when play() hands the video to another Android app (Shield)."""
    return _is_android()


def adb_pair_r121():
    """Called when the YouTube screen opens (Android only)."""
    if not _is_android():
        return
    try:
        from resources.lib import pkm_adb_local_r121 as adb
    except Exception:
        return

    def prompt():
        try:
            from resources.lib import pkm_notify
            pkm_notify.pkm_show_notice("디버깅 허용이 필요합니다",
                                       "TV 화면의 창에서 '항상 허용'을 체크하고 확인을 누르세요", "", ms=15000)
        except Exception:
            pass

    adb.prepare_async()
    adb.pair_async(on_prompt=prompt)


def _adb_play_async_r121(url, fallback_cmd):
    """R121: open YouTube through the device's own adb (am start --ez
    finish_on_ended true) so the first BACK returns to PKM.  Runs in a
    thread (the very first time Android asks "Allow debugging?" and we wait
    for the answer); any failure falls back to the plain Kodi builtin.
    -> False when adb is switched off (caller launches directly)."""
    try:
        from resources.lib import pkm_adb_local_r121 as adb
    except Exception:
        return False
    if not adb.enabled() or not adb.is_ready():
        return False

    def prompt():
        try:
            from resources.lib import pkm_notify
            pkm_notify.pkm_show_notice("디버깅 허용이 필요합니다",
                                       "TV 화면의 창에서 '항상 허용'을 체크하고 확인을 누르세요", "", ms=15000)
        except Exception:
            pass

    def worker():
        t0 = time.time()
        ok, why = adb.start_view(YT_ANDROID_TV, url, {"finish_on_ended": True})
        log("PLAY_ADB_R121 ok=%d ms=%d why=%s" % (1 if ok else 0, int((time.time() - t0) * 1000), why))
        if not ok:
            xbmc.executebuiltin(fallback_cmd)

    th = threading.Thread(target=worker, name="pkm_yt_adb_play_r121")
    th.daemon = True
    th.start()
    return True


def play(item):
    kind = str((item or {}).get("kind") or "video")
    iid = str((item or {}).get("id") or "")
    if not iid:
        return False
    if kind == "playlist":
        url = "https://www.youtube.com/playlist?list=%s" % iid
    else:
        url = "https://www.youtube.com/watch?v=%s" % iid
    if _is_android():
        # Shield ships the Android TV YouTube app; Kodi cannot tell whether an
        # activity started, so there is a single target.
        # R121: finish_on_ended makes the YouTube TV app treat this as a
        # one-shot launch from another app: the first BACK (or the video end)
        # finishes it and Kodi comes back, instead of YouTube home -> account
        # picker -> Kodi.  Kodi v20+ extras = JSON list (6th argument).
        # NOTE: Kodi 21 (Omega) logs 'Intent extras data type (boolean) not
        # implemented' and drops it; the type exists in later Kodi releases.
        extras = '[{\\"key\\":\\"finish_on_ended\\",\\"type\\":\\"boolean\\",\\"value\\":true}]'
        cmd = 'StartAndroidActivity("%s","android.intent.action.VIEW","","%s","","%s")' % (YT_ANDROID_TV, url, extras)
        log("PLAY_ANDROID pkg=%s kind=%s id=%s finish_on_ended=1" % (YT_ANDROID_TV, kind, iid))
        if _adb_play_async_r121(url, cmd):
            return True
        xbmc.executebuiltin(cmd)
        return True
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        if kind == "playlist":
            target = "plugin://plugin.video.youtube/play/?playlist_id=%s&order=default" % iid
        else:
            target = "plugin://plugin.video.youtube/play/?video_id=%s" % iid
        log("PLAY_KODI_ADDON kind=%s id=%s" % (kind, iid))
        xbmc.executebuiltin("PlayMedia(%s)" % target)
        return True
    log("PLAY_UNSUPPORTED kind=%s id=%s url=%s" % (kind, iid, url), xbmc.LOGWARNING)
    return False
