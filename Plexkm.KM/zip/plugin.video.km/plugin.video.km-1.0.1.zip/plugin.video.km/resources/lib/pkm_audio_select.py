# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import traceback
import time
import threading

import xbmc
import xbmcgui
import xbmcaddon

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_audio_select.xml"

# v1244: One basic audio popup only.
# The default audio button shows only tracks included in the playing file.
# System/audio-output settings are not mixed into this track selector.
AUDIO_LIST_IDS = {"single": 6000}
SETTING_LIST_IDS = {}
AUDIO_LIST_ID = 6000
SETTING_LIST_ID = 0
AUDIO_SETTINGS_ARROW_ID = 6028
ADV_LIST_ID = 6010
ADV_LIST_IDS = {"sync": 6010, "volume": 6012, "info": 6014}
ADV_TAB_CONTROL_IDS = {6201: "sync", 6202: "volume", 6203: "info"}
TAB_IDS = {"sync": 6201, "volume": 6202, "info": 6203}
ADV_TABS = ["sync", "volume", "info"]

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_SELECT_ITEM = 7

LANGUAGE_KO = {
    "kor":"한국어", "ko":"한국어", "korean":"한국어", "kr":"한국어",
    "eng":"영어", "en":"영어", "english":"영어",
    "jpn":"일본어", "ja":"일본어", "jp":"일본어", "japanese":"일본어",
    "chi":"중국어", "zho":"중국어", "zh":"중국어", "chs":"중국어(간체)", "cht":"중국어(번체)", "cmn":"중국어", "yue":"광둥어",
    "spa":"스페인어", "es":"스페인어", "spanish":"스페인어",
    "fre":"프랑스어", "fra":"프랑스어", "fr":"프랑스어", "french":"프랑스어",
    "ger":"독일어", "deu":"독일어", "de":"독일어", "german":"독일어",
    "ita":"이탈리아어", "it":"이탈리아어", "italian":"이탈리아어",
    "por":"포르투갈어", "pt":"포르투갈어", "rus":"러시아어", "ru":"러시아어",
    "commentary":"코멘터리", "director":"감독 코멘터리",
}
CHANNEL_KO = {
    "1":"1.0", "2":"2.0", "3":"3.0", "4":"4.0", "5":"5.0", "6":"5.1", "7":"6.1", "8":"7.1",
}
SYNC_OPTIONS = [
    ("start", "오디오 싱크 조정 시작"),
    ("current", "현재 값"),
    ("reset", "기본값으로 복귀"),
]
VOLUME_OPTIONS = [
    ("0", "기본"),
    ("2", "+2 dB"),
    ("4", "+4 dB"),
    ("6", "+6 dB"),
    ("8", "+8 dB"),
]


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][audio_select] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _addon_path():
    try:
        return xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
    except Exception:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def _get_setting(key, default=""):
    try:
        v = _addon().getSetting(key)
        return v if v != "" else default
    except Exception:
        return default


def _set_setting(key, value):
    try:
        _addon().setSetting(key, str(value))
    except Exception:
        pass


def _jsonrpc(method, params=None):
    payload = {"jsonrpc":"2.0", "id":1, "method":method}
    if params is not None:
        payload["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(payload)) or "{}")
    except Exception:
        _log("jsonrpc_failed method=%s\n%s" % (method, traceback.format_exc()), xbmc.LOGWARNING)
        return {}


def _get_kodi_setting_value(setting_id):
    try:
        res = _jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
        if "error" in res:
            return None
        return (res.get("result") or {}).get("value")
    except Exception:
        return None


def _apply_setting_candidates(candidates, value, tag="setting_candidate"):
    ok_any = False
    for sid in candidates:
        res = _jsonrpc("Settings.SetSettingValue", {"setting": sid, "value": value})
        ok = "error" not in res
        ok_any = ok_any or ok
        # v1280: failures must be visible in normal Kodi logs while debugging
        # audio delay/volume.  DEBUG logs were hidden and made it look like the
        # setting had been applied even when Kodi rejected the id.
        _log("%s id=%s value=%s ok=%s result=%s" % (tag, sid, value, "1" if ok else "0", res), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok_any


def _input_action(action_name, tag="input_action"):
    ok = False
    try:
        res = _jsonrpc("Input.ExecuteAction", {"action": action_name})
        ok = "error" not in res
        _log("%s method=jsonrpc action=%s ok=%s result=%s" % (tag, action_name, "1" if ok else "0", res), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    except Exception:
        ok = False
    if not ok:
        try:
            xbmc.executebuiltin("Action(%s)" % action_name)
            ok = True
            _log("%s method=builtin action=%s ok=1" % (tag, action_name))
        except Exception:
            ok = False
            _log("%s method=builtin action=%s ok=0" % (tag, action_name), xbmc.LOGWARNING)
    return ok


def _close_sliderdialog(tag=""):
    # v1284: Kodi native audio-delay action opens DialogSlider.xml
    # (window name: sliderdialog). The PKM XML already hides it visually, but
    # the dialog window can still remain active and take key input after
    # returning from audio-sync adjust mode. Close the named Kodi dialog only;
    # never close all dialogs, because that would close the PKM popup itself.
    closed = 0
    for delay_ms in (0, 15, 35):
        try:
            if delay_ms:
                xbmc.sleep(delay_ms)
            xbmc.executebuiltin("Dialog.Close(sliderdialog,true)")
            closed += 1
        except Exception:
            pass
    _log("audio_native_sliderdialog_close tag=%s attempts=%d" % (tag or "", closed))
    return closed > 0


def _token_to_korean(token):
    raw = str(token or "").strip().replace("_", "-")
    key = re.sub(r"[^a-z0-9-]+", "", raw.lower())
    if not key:
        return ""
    if key in LANGUAGE_KO:
        return LANGUAGE_KO[key]
    if "-" in key and key.split("-", 1)[0] in LANGUAGE_KO:
        return LANGUAGE_KO[key.split("-", 1)[0]]
    return raw


def _active_video_player_id():
    res = _jsonrpc("Player.GetActivePlayers")
    try:
        for item in res.get("result") or []:
            if item.get("type") == "video":
                return int(item.get("playerid"))
    except Exception:
        pass
    return -1


def _jsonrpc_audio_snapshot():
    # v1269: Prefer Kodi JSON-RPC player properties for audio stream metadata.
    # xbmc.Player().getAvailableAudioStreams() can expose odd strings such as
    # language/name="AC3 5.1(side)" and separate channels="3", which caused
    # misleading UI like "AC3 3.0ch". JSON-RPC usually exposes codec/channels
    # as structured current playback properties.
    pid = _active_video_player_id()
    if pid < 0:
        return [], -1
    res = _jsonrpc("Player.GetProperties", {
        "playerid": pid,
        "properties": ["audiostreams", "currentaudiostream"]
    })
    result = res.get("result") or {}
    streams = result.get("audiostreams") or []
    current = result.get("currentaudiostream") or {}
    out = []
    try:
        for i, s in enumerate(streams):
            if not isinstance(s, dict):
                continue
            item = dict(s)
            item.setdefault("index", i)
            item["info_source"] = "jsonrpc"
            out.append(item)
    except Exception:
        out = []
    cur_idx = -1
    try:
        if isinstance(current, dict) and current.get("index") not in ("", None):
            cur_idx = int(current.get("index"))
    except Exception:
        cur_idx = -1
    if cur_idx < 0 and len(out) == 1:
        cur_idx = 0
    if not out and isinstance(current, dict) and (current.get("codec") or current.get("channels")):
        item = dict(current)
        item.setdefault("index", 0)
        item["info_source"] = "jsonrpc_current"
        out = [item]
        cur_idx = 0
    return out, cur_idx


def _stream_debug_preview(streams):
    parts = []
    try:
        for i, s in enumerate(streams or []):
            if isinstance(s, dict):
                parts.append("%s:src=%s idx=%s codec=%s channels=%s raw=%s lang=%s name=%s title=%s" % (
                    i,
                    s.get("info_source", ""),
                    s.get("index", ""),
                    s.get("codec", ""),
                    s.get("channels", ""),
                    s.get("raw_technical_name", ""),
                    s.get("language", ""),
                    s.get("name", ""),
                    s.get("title", ""),
                ))
            else:
                parts.append("%s:raw=%s" % (i, str(s)[:120]))
    except Exception:
        pass
    return " | ".join(parts)[:900]


def _native_streams_for_hints():
    try:
        streams = xbmc.Player().getAvailableAudioStreams()
    except Exception:
        streams = []
    try:
        return list(streams or [])
    except Exception:
        return []


def _technical_hint_from_stream(stream):
    candidates = []
    if isinstance(stream, dict):
        for k in ("raw_technical_name", "language", "lang", "name", "title", "Language", "Name", "Title"):
            v = stream.get(k)
            if v not in ("", None):
                candidates.append(str(v).strip())
    else:
        candidates.append(str(stream or "").strip())
    for raw in candidates:
        if raw and _looks_like_technical_audio_name(raw):
            return raw
    return ""


def _merge_native_audio_hints(json_streams, native_streams):
    # v1270: JSON-RPC is still the primary structured source, but Kodi's native
    # stream list can contain the demuxer display label, e.g. "AC3 5.1(side)".
    # When JSON-RPC gives codec=AC3/channels=3 but the native technical label
    # says AC3 5.1(side), keep JSON fields but attach raw_technical_name so the
    # UI can render the actual stream label instead of the misleading 3.0ch.
    if not json_streams or not native_streams:
        return json_streams
    merged = []
    for i, item in enumerate(json_streams):
        new_item = dict(item) if isinstance(item, dict) else item
        if isinstance(new_item, dict) and i < len(native_streams):
            hint = _technical_hint_from_stream(native_streams[i])
            if hint:
                new_item["raw_technical_name"] = hint
                new_item["native_hint_source"] = "python_stream"
        merged.append(new_item)
    return merged


def _extract_channel_layout_from_tech_name(raw):
    # v1272 root fix:
    # Do not read the digit in codec names such as AC3/EAC3 as a channel count.
    # Bad old path: re.search("(\\d(?:\\.\\d)?)", "AC3 5.1(side)") -> "3" -> 3.0ch.
    # Correct path: pick a standalone channel layout token, preferably with a dot.
    text = re.sub(r"\s*\([^)]*\)", "", str(raw or "")).strip()
    if not text:
        return ""

    decimal_candidates = re.findall(r"(?<![A-Za-z0-9])([0-9](?:\.[0-9]))(?![A-Za-z0-9])", text)
    if decimal_candidates:
        return decimal_candidates[-1]

    # Fallback for labels like "AC3 6 channels"; still avoid the "3" in AC3.
    channel_words = re.search(r"(?<![A-Za-z0-9])([1-8])\s*(?:ch|channels?|채널)\b", text, re.I)
    if channel_words:
        return CHANNEL_KO.get(channel_words.group(1), channel_words.group(1))

    numeric_candidates = re.findall(r"(?<![A-Za-z0-9])([1-8])(?![A-Za-z0-9])", text)
    if numeric_candidates:
        return CHANNEL_KO.get(numeric_candidates[-1], numeric_candidates[-1])

    return ""


def _raw_tech_codec_channels(raw, fallback_codec="", fallback_channels=""):
    raw = str(raw or "").strip()
    if not raw:
        return _normalize_codec(fallback_codec), _normalize_channels(fallback_channels)
    raw_codec = ""
    low = raw.lower()
    for c in ("truehd", "dts-hd-ma", "dtshd_ma", "dtshd-ma", "dts-hd-hra", "dtshd_hra", "dtshd-hra", "dts-hd", "dtshd", "dts", "eac3", "e-ac-3", "ac3", "ac-3", "aac", "flac", "mp3", "opus", "pcm"):
        if c in low:
            raw_codec = c
            break
    raw_channels = _extract_channel_layout_from_tech_name(raw)
    return _normalize_codec(raw_codec or fallback_codec), _normalize_channels(raw_channels or fallback_channels)


def _effective_audio_codec_channels(stream):
    # v1273: no hardcoding, no movie-specific condition.
    # Root rule:
    #   - Use Kodi structured channel count first when it exists.
    #     JSON-RPC gave channels=6 for this file, and CHANNEL_KO maps 6 -> 5.1.
    #   - raw_technical_name is used as a secondary hint, mainly to clean labels
    #     like "AC3 5.1(side)" and to fill missing codec/channel fields.
    # This prevents the codec digit in "AC3" from ever becoming the channel count.
    lang, name, codec, channels = _audio_fields(stream)

    structured_codec = _normalize_codec(codec)
    structured_channels = _normalize_channels(channels)

    raw_candidates = []
    if isinstance(stream, dict):
        raw_candidates.append(str(stream.get("raw_technical_name") or "").strip())
    raw_candidates.extend([str(name or "").strip(), str(lang or "").strip()])

    raw_codec = ""
    raw_channels = ""
    raw_source = ""
    for raw in raw_candidates:
        if raw and _looks_like_technical_audio_name(raw):
            raw_codec, raw_channels = _raw_tech_codec_channels(raw, "", "")
            raw_source = raw
            break

    final_codec = structured_codec or raw_codec
    final_channels = structured_channels or raw_channels

    if structured_codec or structured_channels:
        source = "jsonrpc_fields"
        if raw_source:
            source = "jsonrpc_fields+raw_hint"
    elif raw_source:
        source = "raw_technical_name"
    else:
        source = "unknown"

    return final_codec, final_channels, source, raw_source

def _streams():
    streams, cur_idx = _jsonrpc_audio_snapshot()
    native = _native_streams_for_hints()
    if streams:
        streams = _merge_native_audio_hints(streams, native)
        _log("audio_streams_probe source=jsonrpc+native_hint count=%d current_index=%s preview=%s" % (
            len(streams), cur_idx, _stream_debug_preview(streams)
        ))
        return streams
    fallback = native
    _log("audio_streams_probe source=python_fallback count=%d current_index=%s preview=%s" % (
        len(fallback), _current_idx_native(), _stream_debug_preview(fallback)
    ))
    return fallback


def _current_idx_native():
    try:
        return int(xbmc.Player().getAudioStream())
    except Exception:
        return -1


def _current_idx():
    streams, cur_idx = _jsonrpc_audio_snapshot()
    if cur_idx >= 0:
        return cur_idx
    return _current_idx_native()


def _field(stream, keys, default=""):
    if isinstance(stream, dict):
        for k in keys:
            if k in stream and stream.get(k) not in ("", None):
                return stream.get(k)
    return default


def _parse_text_stream(stream):
    raw = str(stream or "").strip()
    parts = [x.strip() for x in re.split(r"\s*[-/|,]\s*", raw) if x.strip()]
    lang = parts[0] if parts else raw
    codec = ""
    channels = ""
    lower = raw.lower()
    for c in ("truehd", "dts-hd", "dts", "ac3", "eac3", "aac", "flac", "mp3", "opus", "pcm"):
        if c in lower:
            codec = c.upper().replace("EAC3", "EAC3").replace("TRUEHD", "TrueHD").replace("DTS-HD", "DTS-HD")
            break
    m = re.search(r"(\d(?:\.\d)?)\s*(?:ch|channels?)?", lower)
    if m:
        ch = m.group(1)
        channels = ch if "." in ch else CHANNEL_KO.get(ch, ch)
    return lang, raw, codec, channels


def _normalize_codec(codec):
    c = str(codec or "").strip()
    if not c:
        return ""
    low = c.lower().replace("_", "-").replace(" ", "-")
    if low in ("ac-3", "ac3", "dolbydigital", "dolby-digital"):
        return "AC3"
    if low in ("e-ac-3", "eac3", "dd+", "dolbydigitalplus", "dolby-digital-plus"):
        return "EAC3"
    if low in ("truehd", "dolbytruehd", "dolby-truehd"):
        return "TrueHD"
    if low in ("dts-hd-ma", "dtshd-ma", "dts-hdma", "dtshdma", "dtsma", "dts-ma"):
        return "DTS-HD MA"
    if low in ("dts-hd-hra", "dtshd-hra", "dts-hdhra", "dtshdhra"):
        return "DTS-HD HRA"
    if low in ("dts-hd", "dtshd"):
        return "DTS-HD"
    if low == "dts":
        return "DTS"
    if low == "aac":
        return "AAC"
    if low == "flac":
        return "FLAC"
    if low == "pcm":
        return "PCM"
    if low == "opus":
        return "OPUS"
    if low == "mp3":
        return "MP3"
    return c.upper()


def _normalize_channels(channels):
    c = str(channels or "").strip()
    if not c:
        return ""
    # Hide technical FFmpeg/Kodi layouts such as 5.1(side), 5.1(back), etc.
    c = re.sub(r"\s*\([^)]*\)", "", c).strip()
    if c in CHANNEL_KO:
        return CHANNEL_KO[c]
    m = re.search(r"(\d(?:\.\d)?)", c)
    if m:
        v = m.group(1)
        return CHANNEL_KO.get(v, v)
    return c


def _codec_channel_text(codec, channels):
    codec = _normalize_codec(codec)
    channels = _normalize_channels(channels)
    parts = []
    if codec:
        parts.append(codec)
    if channels:
        parts.append(channels)
    return " ".join(parts).strip()


def _looks_like_technical_audio_name(value):
    v = str(value or "").lower()
    return bool(re.search(r"\b(ac3|eac3|aac|dts|truehd|flac|pcm|opus|mp3)\b", v) or re.search(r"\d\.\d", v))



def _audio_fields(stream):
    if isinstance(stream, dict):
        lang = str(_field(stream, ("language", "lang", "Language"), ""))
        name = str(_field(stream, ("name", "title", "Name", "Title"), ""))
        codec = str(_field(stream, ("codec", "Codec", "format", "Format"), ""))
        channels = str(_field(stream, ("channels", "Channels", "channel", "Channel"), ""))
        if channels and channels in CHANNEL_KO:
            channels = CHANNEL_KO[channels]
        return lang, name, codec, channels
    return _parse_text_stream(stream)


def _clean_audio_text(text):
    return re.sub(r"\s*\([^)]*\)", "", str(text or "")).strip()


def _channel_user_text(channels):
    ch = _normalize_channels(channels)
    if not ch:
        return ""
    # v1268: show channel layout in standard audio notation.
    # Example: AC3 + 3 channels -> AC3 3.0ch, not "AC3 3.0채널".
    return "%sch" % ch


def _codec_channel_user_text(codec, channels):
    c = _normalize_codec(codec)
    ch = _channel_user_text(channels)
    return " ".join([x for x in (c, ch) if x]).strip()


def _audio_label_detail(stream, idx, used):
    lang, name, codec, channels = _audio_fields(stream)
    eff_codec, eff_channels, eff_source, eff_raw = _effective_audio_codec_channels(stream)

    tech = _codec_channel_user_text(eff_codec, eff_channels)
    lang_label = _token_to_korean(lang)
    name_label = _clean_audio_text(name)

    if lang_label and not _looks_like_technical_audio_name(lang_label):
        label = ("%s  %s" % (lang_label, tech)).strip() if tech else lang_label
    elif name_label and not _looks_like_technical_audio_name(name_label):
        label = ("%s  %s" % (name_label, tech)).strip() if tech else name_label
    else:
        label = tech or ("오디오 트랙 %d" % (idx + 1))

    name_l = str(name or "").lower()
    if "commentary" in name_l or "commentary" in str(lang).lower() or "코멘터리" in name_l:
        if "코멘터리" not in label:
            label = "%s 코멘터리" % label

    base = label
    n = used.get(base, 0) + 1
    used[base] = n
    if n > 1:
        label = "%s %d" % (base, n)
    return label, ""

class PKMAudioSelectWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.streams = []
        self.current_index = -1
        self.mode = "simple"
        self.current_tab = "sync"
        self.simple_layout = "single"
        self.audio_list_id = AUDIO_LIST_ID
        self.setting_list_id = SETTING_LIST_ID
        self.audio_sync_ms = self._current_audio_sync_ms()
        self.audio_sync_before_adjust = self.audio_sync_ms
        self._sync_adjust_enter_ms = 0
        self._sync_adjust_ignore_select_until_ms = 0
        self._sync_adjust_input_seen = False
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        # v1286: audio-delay actions re-enter onAction() as native ids 54/55.
        # Guard our logical sync step so key repeats cannot start a second
        # 100ms/10ms shift while the first native-action batch is still running.
        self._sync_shift_busy = False
        self._sync_adjust_last_action_id = 0
        self._sync_adjust_last_action_ms = 0
        self._sync_adjust_repeat_block_ms = 80
        self._sync_adjust_fast_repeat_block_ms = 80
        self._sync_adjust_active_flash_ms = 140
        self._sync_adjust_fast_flash_ms = 200
        self._sync_flash_token = 0
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        try:
            # v1282: volampup/volampdown are Kodi-native, but their stock
            # DialogVolumeBar must not be visible over the PKM audio popup.
            # The skin DialogVolumeBar.xml checks this global property.
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.Audio.SuppressVolumeBar", "1")
                win.setProperty("PlexKM.Audio.SuppressNativeOsd", "1")
            except Exception:
                pass
            self.streams = _streams()
            if not self.streams:
                self.close()
                return
            self.current_index = _current_idx()
            self._compute_layout()
            self._sync_window_properties()
            self._populate_simple()
            self._focus_list_position(self.audio_list_id, getattr(self, "_simple_selected_pos", 0), reason="audio_oninit_selected_row")
        except Exception:
            _log("onInit_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            self.close()

    def close(self):
        try:
            win = xbmcgui.Window(10000)
            for k in ("Advanced", "ActiveTab", "SimpleLayout", "SyncAdjust", "SyncMs", "SyncLabel", "SyncValue", "SyncDir", "SyncLeftActive", "SyncRightActive", "SyncLeftFastActive", "SyncRightFastActive", "SuppressVolumeBar", "SuppressNativeOsd"):
                win.clearProperty("PlexKM.Audio.%s" % k)
        except Exception:
            pass
        xbmcgui.WindowXMLDialog.close(self)

    def _compute_layout(self):
        rows = len(self.streams or [])
        self.simple_layout = "single"
        self.audio_list_id = AUDIO_LIST_ID
        self.setting_list_id = SETTING_LIST_ID
        try:
            self.setProperty("PlexKM.Audio.SimpleLayout", self.simple_layout)
        except Exception:
            pass
        _log("audio_layout_single_track_only layout=single rows=%d" % rows)


    def _current_audio_sync_ms(self):
        raw = _get_setting("pkm_audio_sync_ms", "0")
        try:
            ms = int(float(raw))
        except Exception:
            ms = 0
        return max(-5000, min(5000, ms))

    def _audio_sync_label(self, ms=None):
        try:
            value = self.audio_sync_ms if ms is None else int(ms)
        except Exception:
            value = 0
        sec = abs(value) / 1000.0
        if value < 0:
            return "오디오가 영상보다 빠르게 %.2f초 (%dms)" % (sec, value)
        if value > 0:
            return "오디오가 영상보다 느리게 %.2f초 (+%dms)" % (sec, value)
        return "오디오 싱크 기준 0.00초 (0ms)"

    def _audio_sync_short_value(self, ms=None):
        try:
            value = self.audio_sync_ms if ms is None else int(ms)
        except Exception:
            value = 0
        if value == 0:
            return "0.00초"
        sign = "+" if value > 0 else "-"
        return "%s%.2f초" % (sign, abs(value) / 1000.0)

    def _sync_direction_hint(self):
        if self.mode != "sync_adjust":
            return ""
        active = str(getattr(self, "_sync_overlay_focus_hint", "") or "")
        return active if active in ("left", "right", "left_fast", "right_fast") else ""

    def _audio_delay_action(self, action_name, close_slider=True):
        ok = _input_action(action_name, tag="audio_delay_action")
        if close_slider:
            _close_sliderdialog(tag="audio_delay_%s" % action_name)
        return ok

    def _now_ms(self):
        try:
            return int(time.time() * 1000)
        except Exception:
            return 0

    def _is_blocked_sync_repeat(self, aid, now):
        if aid not in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            return False
        try:
            last_id = int(getattr(self, "_sync_adjust_last_action_id", 0) or 0)
            last_ms = int(getattr(self, "_sync_adjust_last_action_ms", 0) or 0)
            if aid in (ACTION_MOVE_UP, ACTION_MOVE_DOWN):
                block_ms = int(getattr(self, "_sync_adjust_fast_repeat_block_ms", 80) or 80)
            else:
                block_ms = int(getattr(self, "_sync_adjust_repeat_block_ms", 80) or 80)
        except Exception:
            last_id, last_ms, block_ms = 0, 0, 80
        if last_id == aid and last_ms > 0 and now > 0 and (now - last_ms) < block_ms:
            self._sync_adjust_last_action_ms = now
            _log("audio_sync_adjust_action_ignored reason=repeat_block aid=%s elapsed_ms=%d block_ms=%d" % (aid, now - last_ms, block_ms))
            return True
        self._sync_adjust_last_action_id = aid
        self._sync_adjust_last_action_ms = now
        return False

    def _flash_sync_arrow(self, direction):
        if direction not in ("left", "right", "left_fast", "right_fast"):
            return
        try:
            self._sync_flash_token = int(getattr(self, "_sync_flash_token", 0) or 0) + 1
            token = self._sync_flash_token
        except Exception:
            token = 0
        self._sync_overlay_focus_hint = direction
        self._sync_window_properties()
        try:
            if direction in ("left_fast", "right_fast"):
                flash_ms = int(getattr(self, "_sync_adjust_fast_flash_ms", 200) or 200)
            else:
                flash_ms = int(getattr(self, "_sync_adjust_active_flash_ms", 140) or 140)
        except Exception:
            flash_ms = 140

        def _clear_later():
            try:
                if token and int(getattr(self, "_sync_flash_token", 0) or 0) != token:
                    return
                self._sync_overlay_focus_hint = ""
                self._sync_window_properties()
            except Exception:
                pass

        try:
            t = threading.Timer(max(0.05, flash_ms / 1000.0), _clear_later)
            t.daemon = True
            t.start()
        except Exception:
            try:
                xbmc.sleep(flash_ms)
            except Exception:
                pass
            _clear_later()

    def _shift_audio_sync(self, delta_ms, persist=False, reason=""):
        try:
            delta_ms = int(delta_ms)
        except Exception:
            delta_ms = 0
        if delta_ms == 0:
            self._sync_window_properties()
            return

        # v1286: Kodi's native audiodelayplus/minus action opens DialogSlider
        # and also re-enters this dialog as action ids 54/55.  When UP/DOWN
        # emits ten native steps, repeated remote/keyboard events could start
        # nested _shift_audio_sync() calls before self.audio_sync_ms was updated.
        # That made the visible value bounce around 0 while the real Kodi delay
        # kept accumulating.  Lock the shift and update the logical value first.
        if getattr(self, "_sync_shift_busy", False):
            _log("audio_sync_shift_ignored reason=busy delta=%s current=%s request=%s" % (delta_ms, self.audio_sync_ms, reason or ""))
            return

        old = int(self.audio_sync_ms)
        target = max(-5000, min(5000, old + delta_ms))
        actual_delta = target - old
        if actual_delta == 0:
            self._sync_window_properties()
            return

        steps_10 = max(1, int(round(abs(actual_delta) / 10.0)))
        action_name = "audiodelayminus" if actual_delta < 0 else "audiodelayplus"
        ok_count = 0
        self._sync_shift_busy = True
        try:
            self.audio_sync_ms = target
            self._sync_window_properties()
            for _ in range(steps_10):
                if self._audio_delay_action(action_name, close_slider=False):
                    ok_count += 1
        finally:
            self._sync_shift_busy = False

        if persist:
            _set_setting("pkm_audio_sync_ms", str(target))
        _close_sliderdialog(tag="audio_sync_shift_after")
        self._sync_window_properties()
        _log("audio_sync_shifted old=%d new=%d delta=%d persist=%s action=%s ok_steps=%d/%d reason=%s label=%s guarded=1" % (old, target, actual_delta, "1" if persist else "0", action_name, ok_count, steps_10, reason or "", self._audio_sync_label()))

    def _sync_window_properties(self):
        sync_dir = self._sync_direction_hint() if self.mode == "sync_adjust" else ""
        props = {
            "Advanced": "1" if self.mode in ("advanced", "sync_adjust") else "0",
            "ActiveTab": self.current_tab,
            "SimpleLayout": self.simple_layout,
            "SyncAdjust": "1" if self.mode == "sync_adjust" else "0",
            "SyncMs": str(self.audio_sync_ms),
            "SyncLabel": self._audio_sync_label(),
            "SyncValue": self._audio_sync_short_value(),
            "SyncDir": sync_dir,
            "SyncLeftActive": "1" if sync_dir == "left" else "0",
            "SyncRightActive": "1" if sync_dir == "right" else "0",
            "SyncLeftFastActive": "1" if sync_dir == "left_fast" else "0",
            "SyncRightFastActive": "1" if sync_dir == "right_fast" else "0",
        }
        for scope in (self, xbmcgui.Window(10000)):
            try:
                for k, v in props.items():
                    scope.setProperty("PlexKM.Audio.%s" % k, str(v or ""))
            except Exception:
                pass

    def _refresh_tabs(self):
        # v1249: Same as subtitle settings.
        # Do not rewrite tab labels from Python. Kodi XML owns focus movement and
        # visual focus color through <focusedcolor>. Python color markup overrides
        # focusedcolor, so the tab focus looked like it was not moving.
        return

    def _advanced_list_id(self):
        return ADV_LIST_IDS.get(self.current_tab, ADV_LIST_ID)

    def _advanced_list_ids(self):
        return set(ADV_LIST_IDS.values())

    def _focus_active_tab(self, tab=None, reason=""):
        """Keep the advanced top menu as a real focus target.

        v1633: Audio advanced settings now open on the top tab row, matching
        the video-settings navigation model.  Tab selection no longer jumps
        immediately into the option list; Down enters the selected tab list.
        """
        target_tab = str(tab or self.current_tab or "sync")
        control_id = TAB_IDS.get(target_tab, TAB_IDS["sync"])
        try:
            self.setFocusId(int(control_id))
            _log("audio_top_tab_focus tab=%s control=%s reason=%s" % (target_tab, control_id, reason))
            return control_id
        except Exception:
            _log("audio_top_tab_focus_failed tab=%s control=%s reason=%s\n%s" % (
                target_tab, control_id, reason, traceback.format_exc()
            ), xbmc.LOGWARNING)
            return -1

    def _focus_list_position(self, control_id, position, reason=""):
        """Focus first, then restore the selected row to prevent a row-0 jump."""
        try:
            ctrl = self.getControl(int(control_id))
            size = int(ctrl.size())
            if size <= 0:
                return -1
            pos = max(0, min(size - 1, int(position)))
            self.setFocusId(int(control_id))
            ctrl.selectItem(pos)
            _log("audio_focus_row_restore control=%s pos=%s reason=%s" % (control_id, pos, reason))
            return pos
        except Exception:
            _log("audio_focus_row_restore_failed control=%s pos=%s reason=%s\n%s" % (control_id, position, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _find_row_position(self, control_id, row_type="", value="", fallback=0):
        try:
            ctrl = self.getControl(int(control_id))
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if row_type and (item.getProperty("row_type") or "") != str(row_type):
                    continue
                if value != "" and (item.getProperty("value") or "") != str(value):
                    continue
                return pos
        except Exception:
            pass
        return int(fallback)

    def _focus_matching_row(self, control_id, row_type="", value="", fallback=0, reason=""):
        return self._focus_list_position(control_id, self._find_row_position(control_id, row_type, value, fallback), reason=reason)

    def _update_selected_rows_in_place(self, control_id, row_type, value, reason=""):
        """Change only the selected properties; never reset the focused list."""
        try:
            ctrl = self.getControl(int(control_id))
            target = str(value)
            matched_pos = -1
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if (item.getProperty("row_type") or "") != str(row_type):
                    continue
                selected = (item.getProperty("value") or "") == target
                item.setProperty("selected", "1" if selected else "0")
                if selected:
                    matched_pos = pos
            _log("audio_selection_update_in_place control=%s type=%s value=%s pos=%s reason=%s" % (control_id, row_type, target, matched_pos, reason))
            return matched_pos
        except Exception:
            _log("audio_selection_update_in_place_failed control=%s type=%s value=%s reason=%s\n%s" % (control_id, row_type, value, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _update_audio_sync_info_in_place(self, reason=""):
        try:
            ctrl = self.getControl(self._advanced_list_id())
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if (item.getProperty("row_type") or "") == "sync_info":
                    item.setProperty("value", str(self.audio_sync_ms))
                    item.setProperty("detail", self._audio_sync_short_value())
                    break
            _log("audio_sync_info_update_in_place ms=%s reason=%s" % (self.audio_sync_ms, reason))
        except Exception:
            _log("audio_sync_info_update_in_place_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)

    def _add(self, ctrl, label, row_type, value="", selected=False, detail=""):
        item = xbmcgui.ListItem(label)
        item.setProperty("row_type", row_type)
        item.setProperty("value", str(value))
        item.setProperty("detail", str(detail or ""))
        if selected:
            item.setProperty("selected", "1")
        ctrl.addItem(item)

    def _populate_settings_button(self):
        # v1244: Default audio popup is track selection only.
        return

    def _populate_simple(self):
        self._compute_layout()
        self._sync_window_properties()
        ctrl = self.getControl(self.audio_list_id)
        try:
            ctrl.reset()
        except Exception:
            pass
        used = {}
        selected_pos = 0
        for idx, stream in enumerate(self.streams):
            label, detail = _audio_label_detail(stream, idx, used)
            stream_index = idx
            try:
                if isinstance(stream, dict) and stream.get("index") not in ("", None):
                    stream_index = int(stream.get("index"))
            except Exception:
                stream_index = idx
            selected = idx == self.current_index or stream_index == self.current_index
            if selected:
                selected_pos = idx
            self._add(ctrl, label, "audio", str(idx), selected=selected, detail=detail)
        self._simple_selected_pos = selected_pos
        try:
            ctrl.selectItem(selected_pos)
        except Exception:
            pass
        try:
            selected_stream = self.streams[selected_pos] if self.streams else ""
            eff_codec, eff_channels, eff_source, eff_raw = _effective_audio_codec_channels(selected_stream)
            _log("audio_simple_render effective_source=%s selected_pos=%d codec=%s channels=%s raw_hint=%s label=%s" % (
                eff_source, selected_pos, eff_codec, _channel_user_text(eff_channels), eff_raw, _codec_channel_user_text(eff_codec, eff_channels)
            ))
        except Exception:
            pass
        _log("audio_rows_added streams=%d selected_pos=%d" % (len(self.streams), selected_pos))

    def _populate_advanced(self, keep_focus=True):
        self._sync_window_properties()
        self._refresh_tabs()
        # v1248: Same owner model as subtitle settings.
        # Kodi XML owns Up/Down/Left/Right movement. Python only populates the
        # active tab list and commits tab/list clicks.
        for lid in self._advanced_list_ids():
            try:
                self.getControl(lid).reset()
            except Exception:
                pass
        ctrl = self.getControl(self._advanced_list_id())
        if self.current_tab == "sync":
            self.audio_sync_ms = self._current_audio_sync_ms()
            pos = self._populate_sync_tab(ctrl)
        elif self.current_tab == "volume":
            cur = _get_setting("pkm_audio_volume_boost_db", "0")
            pos = self._populate_options(ctrl, "volume", VOLUME_OPTIONS, cur)
        else:
            pos = self._populate_info(ctrl)
        try:
            ctrl.selectItem(pos)
        except Exception:
            pass
        if keep_focus:
            self._focus_list_position(self._advanced_list_id(), pos, reason="audio_advanced_populate_selected_row")
        return pos

    def _populate_sync_tab(self, ctrl):
        self._add(ctrl, "오디오 싱크 조정 시작", "sync_adjust", "start", selected=True)
        # v1283: avoid long row text/ellipsis.  The full wording belongs to
        # the sync-adjust overlay; the menu row only shows concise state.
        self._add(ctrl, "현재 싱크", "sync_info", str(self.audio_sync_ms), selected=False, detail=self._audio_sync_short_value())
        self._add(ctrl, "기본값으로 복귀", "sync_reset", "0", selected=False)
        return 0

    def _populate_options(self, ctrl, row_type, options, current):
        pos = 0
        for idx, (key, label) in enumerate(options):
            selected = str(key) == str(current)
            if selected:
                pos = idx
            self._add(ctrl, label, row_type, key, selected=selected)
        return pos

    def _populate_info(self, ctrl):
        pos = 0
        for i, s in enumerate(self.streams or []):
            stream_index = i
            try:
                if isinstance(s, dict) and s.get("index") not in ("", None):
                    stream_index = int(s.get("index"))
            except Exception:
                stream_index = i
            if i == self.current_index or stream_index == self.current_index:
                pos = i
                break

        stream = self.streams[pos] if self.streams else ""
        label, detail = _audio_label_detail(stream, pos, {})
        lang, name, codec, channels = _audio_fields(stream)
        eff_codec, eff_channels, eff_source, eff_raw = _effective_audio_codec_channels(stream)

        codec_text = eff_codec
        channel_text = _channel_user_text(eff_channels)
        current_text = _codec_channel_user_text(eff_codec, eff_channels) or label

        self._add(ctrl, "현재 트랙", "info", "", False, current_text or "-")

        lang_text = _token_to_korean(lang)
        if lang_text and not _looks_like_technical_audio_name(lang_text):
            self._add(ctrl, "언어", "info", "", False, _clean_audio_text(lang_text))

        if codec_text:
            self._add(ctrl, "코덱", "info", "", False, codec_text)
        if channel_text:
            self._add(ctrl, "채널", "info", "", False, channel_text)

        name_text = _clean_audio_text(name)
        if name_text and not _looks_like_technical_audio_name(name_text) and name_text != label:
            self._add(ctrl, "이름", "info", "", False, name_text)

        source = ""
        try:
            source = stream.get("info_source", "") if isinstance(stream, dict) else "python"
        except Exception:
            source = ""
        _log("audio_info_render source=%s effective_source=%s current_index=%s stream_pos=%s codec=%s channels=%s raw_hint=%s label=%s raw=%s" % (
            source, eff_source, self.current_index, pos, codec_text, channel_text, eff_raw, label, str(stream)[:500]
        ))
        return 0

    def _move_tab(self, delta):
        # v1248: Do not call this from directional actions.
        # Directional movement belongs to Kodi XML navigation only.
        if self.mode != "advanced":
            return
        idx = ADV_TABS.index(self.current_tab) if self.current_tab in ADV_TABS else 0
        self.current_tab = ADV_TABS[(idx + delta) % len(ADV_TABS)]
        self._populate_advanced(keep_focus=True)

    def _enter_advanced(self):
        _close_sliderdialog(tag="audio_enter_advanced_before_menu")
        self.mode = "advanced"
        self.current_tab = "sync"
        self._sync_window_properties()
        pos = self._populate_advanced(keep_focus=False)
        # v1634: Advanced audio settings open on the option row.  The top tab
        # row is reached naturally with one Up press; Enter is never required
        # for tab navigation.
        self._focus_list_position(self._advanced_list_id(), pos, reason="audio_advanced_open_first_option")
        _close_sliderdialog(tag="audio_enter_advanced_after_menu")
        _log("audio_advanced_opened tab=sync focus=option_list up_to_tabs=1 tab_enter_required=0 down_once=1")

    def _back_to_simple(self):
        self.mode = "simple"
        self._sync_window_properties()
        try:
            _log("audio_parser_selfcheck ac3_5_1_side=%s ac3_2_0=%s eac3_5_1=%s" % (
                _raw_tech_codec_channels("AC3 5.1(side)")[1],
                _raw_tech_codec_channels("AC3 2.0")[1],
                _raw_tech_codec_channels("EAC3 5.1")[1],
            ))
        except Exception:
            pass
        self._populate_simple()
        self._focus_list_position(self.audio_list_id, getattr(self, "_simple_selected_pos", 0), reason="audio_back_to_simple_selected_row")
        _log("audio_advanced_closed_to_simple")

    def _enter_sync_adjust(self):
        self.audio_sync_before_adjust = self._current_audio_sync_ms()
        self.audio_sync_ms = self.audio_sync_before_adjust
        self.mode = "sync_adjust"
        self.current_tab = "sync"
        now = self._now_ms()
        self._sync_adjust_enter_ms = now
        self._sync_adjust_ignore_select_until_ms = now + 800
        self._sync_adjust_input_seen = False
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        self._sync_adjust_last_action_id = 0
        self._sync_adjust_last_action_ms = 0
        self._sync_window_properties()
        _close_sliderdialog(tag="audio_sync_adjust_open")
        _log("audio_sync_adjust_opened ms=%d ignore_select_until_ms=%d first_select_guard=1 inline_arrows=1" % (self.audio_sync_ms, self._sync_adjust_ignore_select_until_ms))

    def _exit_sync_adjust(self, save=False):
        # v1292: Enter and Back both save the adjusted value and close the compact overlay.
        # Native audio-delay re-entry is still guarded while each shift is applying.
        self._sync_adjust_ignore_select_until_ms = 0
        self._sync_adjust_input_seen = False
        self._sync_adjust_last_dir = ""
        self._sync_adjust_last_action_id = 0
        self._sync_adjust_last_action_ms = 0
        if save:
            _close_sliderdialog(tag="audio_sync_confirm_before_save")
            self._sync_window_properties()
            _set_setting("pkm_audio_sync_ms", str(self.audio_sync_ms))
            _log("audio_sync_adjust_saved ms=%d label=%s current_sync_updated=1" % (self.audio_sync_ms, self._audio_sync_label()))
        else:
            delta = int(self.audio_sync_before_adjust) - int(self.audio_sync_ms)
            if delta:
                self._shift_audio_sync(delta, persist=False, reason="cancel_revert")
            self.audio_sync_ms = self.audio_sync_before_adjust
            _set_setting("pkm_audio_sync_ms", str(self.audio_sync_ms))
            _log("audio_sync_adjust_cancelled revert_ms=%d current_sync_restored=1" % self.audio_sync_ms)
        _close_sliderdialog(tag="audio_sync_exit_before_menu")
        self.mode = "advanced"
        self.current_tab = "sync"
        self._sync_overlay_focus_hint = ""
        self._sync_adjust_last_dir = ""
        self._sync_window_properties()
        pos = self._populate_advanced(keep_focus=False)
        self._focus_list_position(self._advanced_list_id(), pos, reason="audio_sync_exit_to_option_list")
        _close_sliderdialog(tag="audio_sync_exit_after_menu")

    def _activate_tab_from_focus(self, control_id):
        """Activate an advanced tab as soon as directional focus reaches it.

        v1634 removes the Enter-to-commit step from the top row.  Kodi XML
        remains the sole directional-navigation owner; Python only swaps the
        visible list after Kodi reports the new focused tab.
        """
        try:
            cid = int(control_id)
        except Exception:
            return False
        if self.mode != "advanced" or cid not in ADV_TAB_CONTROL_IDS:
            return False
        target = ADV_TAB_CONTROL_IDS.get(cid, self.current_tab)
        old = self.current_tab
        if target != old:
            self.current_tab = target
            self._populate_advanced(keep_focus=False)
            _log("audio_advanced_tab_focus_activate old=%s new=%s cid=%s enter_required=0 down_once=1" % (old, target, cid))
        else:
            _log("audio_advanced_tab_focus_keep tab=%s cid=%s enter_required=0 down_once=1" % (target, cid))
        return True

    def onFocus(self, control_id):
        # Directional focus itself selects the top tab.  No setFocusId() call
        # is made here, so one Down press can immediately enter the visible list.
        if self._activate_tab_from_focus(control_id):
            return
        try:
            cid = int(control_id)
        except Exception:
            cid = 0
        if self.mode == "advanced" and cid in self._advanced_list_ids():
            tab = next((name for name, lid in ADV_LIST_IDS.items() if int(lid) == cid), self.current_tab)
            try:
                pos = int(self.getControl(cid).getSelectedPosition())
            except Exception:
                pos = -1
            _log("audio_advanced_list_focus tab=%s control=%s pos=%s source=top_down_once" % (tab, cid, pos))


    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = 0

        if self.mode == "sync_adjust":
            now = self._now_ms()
            try:
                elapsed = now - int(self._sync_adjust_enter_ms or 0) if now and self._sync_adjust_enter_ms else -1
            except Exception:
                elapsed = -1
            _log("audio_sync_adjust_action aid=%s ms=%d elapsed_ms=%d input_seen=%s guard_until=%d busy=%s" % (aid, self.audio_sync_ms, elapsed, 1 if self._sync_adjust_input_seen else 0, self._sync_adjust_ignore_select_until_ms, 1 if getattr(self, "_sync_shift_busy", False) else 0))
            if getattr(self, "_sync_shift_busy", False):
                if aid in (54, 55):
                    _close_sliderdialog(tag="audio_sync_residual_slider_key_busy")
                    return
                if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_SELECT_ITEM):
                    _log("audio_sync_adjust_action_ignored reason=shift_busy aid=%s ms=%d" % (aid, self.audio_sync_ms))
                    return
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                _log("audio_sync_adjust_back_save ms=%d label=%s" % (self.audio_sync_ms, self._audio_sync_label()))
                self._exit_sync_adjust(save=True)
                return
            if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN):
                if self._is_blocked_sync_repeat(aid, now):
                    return
            if aid == ACTION_MOVE_RIGHT:
                self._sync_adjust_input_seen = True
                self._shift_audio_sync(-10, persist=False, reason="right_faster_10ms")
                self._flash_sync_arrow("right_fast")
                return
            if aid == ACTION_MOVE_LEFT:
                self._sync_adjust_input_seen = True
                self._shift_audio_sync(10, persist=False, reason="left_slower_10ms")
                self._flash_sync_arrow("left_fast")
                return
            if aid == ACTION_MOVE_UP:
                self._sync_adjust_input_seen = True
                self._shift_audio_sync(-100, persist=False, reason="up_faster_100ms")
                self._flash_sync_arrow("right_fast")
                return
            if aid == ACTION_MOVE_DOWN:
                self._sync_adjust_input_seen = True
                self._shift_audio_sync(100, persist=False, reason="down_slower_100ms")
                self._flash_sync_arrow("left_fast")
                return
            if aid == ACTION_SELECT_ITEM:
                if (not self._sync_adjust_input_seen) and now and self._sync_adjust_ignore_select_until_ms and now < self._sync_adjust_ignore_select_until_ms:
                    _log("audio_sync_adjust_select_ignored reason=enter_debounce elapsed_ms=%d ms=%d" % (elapsed, self.audio_sync_ms))
                    return
                _close_sliderdialog(tag="audio_sync_select_save")
                _log("audio_sync_adjust_select_save ms=%d label=%s" % (self.audio_sync_ms, self._audio_sync_label()))
                self._exit_sync_adjust(save=True)
                return
            if aid in (54, 55):
                _close_sliderdialog(tag="audio_sync_residual_slider_key")
                return
            return

        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            if self.mode == "advanced":
                self._back_to_simple()
                return
            self.close()
            return

        if self.mode == "simple" and aid == ACTION_MOVE_RIGHT:
            # v1264: Right moves focus to the visible arrow button first.
            # Selecting the arrow opens the audio detail settings.
            try:
                self.setFocusId(AUDIO_SETTINGS_ARROW_ID)
            except Exception:
                pass
            return

        # v1248: In advanced audio settings, do not handle
        # Up/Down/Left/Right in Python. Kodi XML <onup>/<ondown>/<onleft>/<onright>
        # is the single movement owner, identical to subtitle settings.

    def onClick(self, control_id):
        cid = int(control_id)
        valid_audio_ids = set(AUDIO_LIST_IDS.values())
        valid_setting_ids = set(SETTING_LIST_IDS.values())
        if cid not in valid_audio_ids and cid not in valid_setting_ids and cid not in self._advanced_list_ids() and cid not in ADV_TAB_CONTROL_IDS and cid != AUDIO_SETTINGS_ARROW_ID:
            return
        if cid == AUDIO_SETTINGS_ARROW_ID:
            self._enter_advanced()
            return
        if cid in valid_setting_ids:
            return
        if self.mode == "advanced" and cid in ADV_TAB_CONTROL_IDS:
            # v1634: Enter on a tab is intentionally a no-op.  Left/Right focus
            # already activates the tab via onFocus(), and Down enters its list.
            target = ADV_TAB_CONTROL_IDS.get(cid, self.current_tab)
            if target != self.current_tab:
                # Defensive fallback for devices that emit click without a prior
                # focus callback; still keep focus on the tab and do not enter list.
                self.current_tab = target
                self._populate_advanced(keep_focus=False)
            _log("audio_advanced_tab_enter_ignored tab=%s cid=%s navigation=focus_only down_once=1" % (self.current_tab, cid))
            return
        try:
            ctrl = self.getControl(cid)
            clicked_pos = int(ctrl.getSelectedPosition())
            item = ctrl.getSelectedItem()
        except Exception:
            clicked_pos = 0
            item = None
        if not item:
            return
        typ = item.getProperty("row_type") or ""
        val = item.getProperty("value") or ""
        if typ == "more":
            self._enter_advanced()
        elif typ == "audio":
            self._select_audio(val, item.getLabel())
            # Selection markers are updated on the existing rows. Rebuilding the
            # focused list caused the whole popup to repaint and visibly shake.
            self._update_selected_rows_in_place(
                self.audio_list_id, "audio", val, reason="audio_track_apply_no_rebuild"
            )
            self._simple_selected_pos = clicked_pos
            _log("audio_select_keep_open_after_select_no_rebuild index=%s pos=%s" % (val, clicked_pos))
        elif typ == "sync":
            self._select_sync(val)
            self._update_selected_rows_in_place(
                self._advanced_list_id(), typ, val, reason="audio_sync_apply_no_rebuild"
            )
        elif typ == "sync_adjust":
            self._enter_sync_adjust()
        elif typ == "sync_reset":
            delta = 0 - int(self.audio_sync_ms)
            if delta:
                self._shift_audio_sync(delta, persist=True, reason="reset")
            else:
                _set_setting("pkm_audio_sync_ms", "0")
                self._sync_window_properties()
            self.audio_sync_ms = 0
            self._update_audio_sync_info_in_place(reason="audio_sync_reset_no_rebuild")
        elif typ == "volume":
            effective_value = self._select_volume(val)
            self._update_selected_rows_in_place(
                self._advanced_list_id(), typ, effective_value, reason="audio_volume_apply_no_rebuild"
            )

    def _select_audio(self, value, label):
        try:
            idx = int(value or "0")
            if idx == int(self.current_index):
                # v1633: selecting the already-active track must be a no-op.
                # Kodi otherwise closes/reopens the audio decoder, which can
                # produce a video-buffer timeout and visible playback stall.
                _log("audio_select_skip_same_current index=%d label=%s decoder_restart=0" % (idx, label))
                return False
            xbmc.Player().setAudioStream(idx)
            self.current_index = idx
            _log("selected audio index=%d label=%s decoder_restart=1" % (idx, label))
            return True
        except Exception:
            _log("select_audio_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            return False

    def _select_sync(self, value):
        _set_setting("pkm_audio_sync_ms", value)
        try:
            delay = float(value) / 1000.0
        except Exception:
            delay = 0.0
        ok = _apply_setting_candidates(("videoplayer.audiodelay", "videoscreen.audiodelay", "audiooutput.audiodelay"), delay, tag="audio_sync_setting_candidate")
        self.audio_sync_ms = int(float(value or 0))
        self._sync_window_properties()
        self._update_audio_sync_info_in_place(reason="audio_sync_select_no_rebuild")
        _log("audio_sync_selected ms=%s seconds=%s setting_ok=%s no_list_rebuild=1" % (value, delay, "1" if ok else "0"))

    def _volume_amp_action(self, action_name):
        # v1281: Use Kodi's native playback action exactly.
        # Action IDs are volampup/volampdown. Kodi handles passthrough,
        # clamp range, DynamicRangeCompression, and its own slider/toast.
        return _input_action(action_name, tag="audio_volume_amp_action_native")

    def _apply_volume_amplification_actions(self, old_amp, new_amp):
        try:
            old_i = int(float(old_amp))
        except Exception:
            old_i = 0
        try:
            new_i = int(float(new_amp))
        except Exception:
            new_i = 0
        delta = new_i - old_i
        if delta == 0:
            return True, 0, 0, "none"
        action_name = "volampup" if delta > 0 else "volampdown"
        # Kodi source changes volume amplification by 1.0 dB per action.
        # Our menu values are dB values, so apply one native action per dB.
        steps = abs(delta)
        ok_count = 0
        for _ in range(steps):
            if self._volume_amp_action(action_name):
                ok_count += 1
        return ok_count == steps, ok_count, steps, action_name

    def _select_volume(self, value):
        old_value = _get_setting("pkm_audio_volume_boost_db", "0")
        action_ok, ok_steps, total_steps, action_name = self._apply_volume_amplification_actions(old_value, value)
        if action_ok:
            _set_setting("pkm_audio_volume_boost_db", value)
        else:
            # Keep UI state honest if Kodi rejects native volamp actions
            # for passthrough or platform reasons.
            value = old_value
        _log("audio_volume_boost_selected_native db=%s old=%s action=%s action_ok=%s steps=%d/%d pure_kodi_action=1 no_list_rebuild=1" % (
            value, old_value, action_name, "1" if action_ok else "0", ok_steps, total_steps
        ))
        return str(value)


def open_audio_select():
    try:
        if not xbmc.Player().isPlayingVideo():
            return False
        if not _streams():
            return False
        win = PKMAudioSelectWindow(XML_NAME, _addon_path(), "Default", "1080i")
        win.doModal()
        del win
        return True
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
