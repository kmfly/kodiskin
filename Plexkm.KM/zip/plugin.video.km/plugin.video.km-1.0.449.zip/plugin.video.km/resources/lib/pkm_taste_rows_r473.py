# -*- coding: utf-8 -*-
"""R473: rows for the sidebar "내 취향" screen.

Input  : <profile>/pkm_taste.json (picks made in the setup helper) + the
         bundled resources/data/taste_meta_r473.json (genres / countries of
         every candidate title) + the local library DB.
Output : [(row_title, [rating_key, ...]), ...]  -- the caller turns keys into
         cards (same path as the favorites screen).

No picks -> random rows (high rating, unwatched), titled as random picks.
All DB reads are local SQLite; nothing here touches the network.
"""
import json
import os
import random
import time

import xbmc
import xbmcvfs

ROW_WANT = 12
ROW_MIN = 5

_META = None

# TMDb Korean genre -> Plex genre tags we may see in item_genres.
_GENRE_ALIASES = {
    "모험": ("모험", "어드벤처", "Adventure", "액션 & 어드벤처"),
    "SF": ("SF", "Sci-Fi", "Science Fiction", "공상과학", "SF & 판타지"),
    "액션": ("액션", "Action", "액션 & 어드벤처"),
    "코미디": ("코미디", "Comedy"),
    "드라마": ("드라마", "Drama"),
    "범죄": ("범죄", "Crime"),
    "스릴러": ("스릴러", "Thriller"),
    "미스터리": ("미스터리", "Mystery"),
    "로맨스": ("로맨스", "Romance", "멜로"),
    "판타지": ("판타지", "Fantasy", "SF & 판타지"),
    "애니메이션": ("애니메이션", "Animation"),
    "가족": ("가족", "Family"),
    "전쟁": ("전쟁", "War"),
    "역사": ("역사", "History"),
    "음악": ("음악", "Music"),
    "공포": ("공포", "Horror"),
    "다큐멘터리": ("다큐멘터리", "Documentary", "다큐"),
    "서부": ("서부", "Western"),
    "리얼리티": ("리얼리티", "Reality", "예능"),
    "토크": ("토크", "Talk"),
}
# Library country tags are only "한국" / "외국" (plus a few English names), so
# every non-Korean code maps to the "외국" tag; finer country hints for shows
# come from the library (section) names, see _section_hint().
_FOREIGN_TAGS = ("외국", "United States", "United Kingdom", "Japan", "China", "France", "Germany", "Canada", "Australia")
_COUNTRY_TAGS = {
    "KR": ("한국", "대한민국", "South Korea", "Korea"),
}
_SECTION_HINTS = {
    "KR": ("국내", "방영", "한국", "K-", "케이"),
    "US": ("미드", "미국"),
    "JP": ("일드", "일본"),
    "CN": ("중드", "중국"),
    "HK": ("중드", "중국"),
    "TW": ("중드", "중국"),
    "GB": ("영드", "영국"),
}
_MUSIC_GENRES = ("댄스", "발라드", "알앤비/어반", "힙합", "록", "트로트", "인디", "포크", "OST", "K-POP", "팝", "R&B")
# Used when a pick has no bundled meta: (genres, countries) by setup category.
_CATEGORY_DEFAULTS = {
    "SF·히어로": (["SF", "액션"], ["US"]),
    "한국 영화 대표작": (["드라마"], ["KR"]),
    "한국 영화 모음": (["드라마"], ["KR"]),
    "독립·작품성": (["드라마"], []),
    "음악 영화": (["음악", "드라마"], []),
    "전쟁 영화": (["전쟁", "드라마"], []),
    "범죄·스릴러": (["범죄", "스릴러"], []),
    "한국 드라마": (["드라마"], ["KR"]),
    "과거 한국 드라마": (["드라마"], ["KR"]),
    "미국 드라마": (["드라마"], ["US"]),
    "해외 드라마 모음": (["드라마"], []),
    "예능": (["리얼리티"], ["KR"]),
    "고전 명작 영화": (["드라마"], []),
    "90~2000년대 영화": (["드라마"], []),
    "일본 드라마": (["드라마"], ["JP"]),
    "다큐멘터리": (["다큐멘터리"], []),
    "중국 드라마": (["드라마"], ["CN"]),
    "중국·홍콩 영화": (["드라마", "액션"], ["CN", "HK"]),
    "애니메이션 영화": (["애니메이션"], ["JP"]),
    "애니메이션 시리즈": (["애니메이션"], ["JP"]),
}
# Row definition per setup category: (kind, countries, genre-filter or None)
_CATEGORY_ROWS = {
    "한국 영화 대표작": ("movie", ["KR"], None),
    "한국 영화 모음": ("movie", ["KR"], None),
    "한국 드라마": ("show", ["KR"], None),
    "과거 한국 드라마": ("show", ["KR"], None),
    "미국 드라마": ("show", ["US"], None),
    "일본 드라마": ("show", ["JP"], None),
    "중국 드라마": ("show", ["CN", "HK", "TW"], None),
    "중국·홍콩 영화": ("movie", ["CN", "HK", "TW"], None),
    "예능": ("show", ["KR"], ["리얼리티", "토크", "코미디"]),
    "다큐멘터리": (None, [], ["다큐멘터리"]),
    "애니메이션 영화": ("movie", [], ["애니메이션"]),
    "애니메이션 시리즈": ("show", [], ["애니메이션"]),
    "전쟁 영화": ("movie", [], ["전쟁"]),
    "음악 영화": ("movie", [], ["음악"]),
    "범죄·스릴러": ("movie", [], ["범죄", "스릴러"]),
    "SF·히어로": ("movie", [], ["SF"]),
    "고전 명작 영화": ("movie", [], None, {"years": (1900, 1989)}),
    "90~2000년대 영화": ("movie", [], None, {"years": (1990, 2009)}),
    "해외 드라마 모음": ("show", [], None, {"not_countries": ["KR"]}),
}


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] TASTE_ROWS_R473 %s" % msg, level)
    except Exception:
        pass


def _meta():
    global _META
    if _META is None:
        try:
            path = os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.video.km/"),
                                "resources", "data", "taste_meta_r473.json")
            with open(path, "r", encoding="utf-8") as f:
                _META = json.load(f)
        except Exception:
            _META = {}
    return _META


def taste_path():
    return os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "pkm_taste.json")


def load_picks():
    """-> list of pick dicts (empty = nothing chosen / random mode)."""
    try:
        with open(taste_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return [p for p in (data.get("picks") or []) if p.get("title")]
    except Exception:
        return []


def signature():
    """Changes when the saved taste changes."""
    try:
        st = os.stat(taste_path())
        return "%d:%d" % (int(st.st_mtime), int(st.st_size))
    except Exception:
        return "none"


def _pick_meta(p):
    m = _meta().get("%s|%s" % (p.get("title"), p.get("year")))
    if m:
        return list(m.get("g") or []), list(m.get("c") or [])
    g, c = _CATEGORY_DEFAULTS.get(p.get("category"), ([], []))
    return list(g), list(c)


def build_profile(picks):
    """Genre / country weights and per-category pick counts."""
    genres, countries, cats = {}, {}, {}
    kinds = {"movie": 0, "show": 0}
    for p in picks:
        g, c = _pick_meta(p)
        for x in g:
            genres[x] = genres.get(x, 0) + 1
        for x in c:
            countries[x] = countries.get(x, 0) + 1
        cat = p.get("category") or ""
        cats.setdefault(cat, []).append(p)
        kinds["movie" if p.get("kind") == "movie" else "show"] += 1
    return {"genres": genres, "countries": countries, "cats": cats, "kinds": kinds, "n": len(picks)}


def _expand_genres(names):
    out = []
    for n in names:
        out.extend(_GENRE_ALIASES.get(n, (n,)))
    return out


def _expand_countries(codes):
    out = []
    for c in codes:
        out.extend(_COUNTRY_TAGS.get(c, _FOREIGN_TAGS))
    return list(dict.fromkeys(out))


def _section_hint(codes, titles):
    """Section ids whose library name hints at one of the country codes."""
    hints = []
    for c in codes:
        hints.extend(_SECTION_HINTS.get(c, ()))
    out = []
    for sid, title in (titles or {}).items():
        t = str(title or "")
        if "KR" in codes and any(x in t for x in ("외국", "해외")):
            continue  # e.g. "방영 | 외국" is foreign material aired in Korea
        if any(h in t for h in hints):
            out.append(str(sid))
    return out


def _types(kind):
    return ("movie",) if kind == "movie" else (("show",) if kind == "show" else ("movie", "show"))


def _candidates(conn, kind, sections, countries=None, genres=None, unwatched=True, pool=600, not_countries=None, years=None, exclude_genres=None):
    """[(rating_key, title, plex_type, score, genre set)] random sample."""
    types = _types(kind)
    args = list(types)
    where = " WHERE i.plex_type IN (%s) " % ",".join("?" * len(types))
    if sections:
        where += " AND i.section_id IN (%s) " % ",".join("?" * len(sections))
        args.extend(str(s) for s in sections)
    if unwatched:
        where += " AND COALESCE(i.view_count,0)=0 "
    if countries:
        tags = _expand_countries(countries)
        where += (" AND EXISTS (SELECT 1 FROM item_countries c WHERE c.rating_key=i.rating_key AND c.country IN (%s)) "
                  % ",".join("?" * len(tags)))
        args.extend(tags)
    if exclude_genres:
        tags = _expand_genres(exclude_genres)
        where += (" AND NOT EXISTS (SELECT 1 FROM item_genres xg WHERE xg.rating_key=i.rating_key AND xg.genre IN (%s)) "
                  % ",".join("?" * len(tags)))
        args.extend(tags)
    if years:
        where += " AND COALESCE(i.year,0) BETWEEN ? AND ? "
        args.extend([int(years[0]), int(years[1])])
    if not_countries:
        tags = _expand_countries(not_countries)
        where += (" AND NOT EXISTS (SELECT 1 FROM item_countries c WHERE c.rating_key=i.rating_key AND c.country IN (%s)) "
                  % ",".join("?" * len(tags)))
        args.extend(tags)
    if genres:
        tags = _expand_genres(genres)
        where += (" AND EXISTS (SELECT 1 FROM item_genres g WHERE g.rating_key=i.rating_key AND g.genre IN (%s)) "
                  % ",".join("?" * len(tags)))
        args.extend(tags)
    sql = ("SELECT i.rating_key, i.title, i.plex_type, COALESCE(r.score,0), "
           "(SELECT group_concat(g2.genre,'|') FROM item_genres g2 WHERE g2.rating_key=i.rating_key) "
           "FROM items i LEFT JOIN item_ratings r ON r.rating_key=i.rating_key %s "
           "ORDER BY RANDOM() LIMIT ?") % where
    args.append(int(pool))
    try:
        rows = conn.execute(sql, args).fetchall()
    except Exception as exc:
        _log("candidates fail %s" % exc, xbmc.LOGWARNING)
        return []
    return [(str(r[0]), r[1], r[2], float(r[3] or 0), set((r[4] or "").split("|")) - {""}) for r in rows]


def _weight_for(genre_tags, weights):
    """Sum of the profile weights of the genres this title carries."""
    w = 0.0
    for name, val in weights.items():
        if genre_tags & set(_GENRE_ALIASES.get(name, (name,))):
            w += val
    return w


def _ranked(cands, weights, used, want=ROW_WANT, min_score=6.0):
    scored = []
    for rk, title, ptype, score, gset in cands:
        if rk in used:
            continue
        w = _weight_for(gset, weights) if weights else 0.0
        if min_score and score and score < min_score:
            continue
        # genre match dominates, rating nudges, jitter keeps the row fresh
        scored.append((w * 2.0 + (score or 6.0) * 0.4 + random.random() * 1.2, rk))
    scored.sort(reverse=True)
    return [rk for _s, rk in scored[:want]]


def match_picks(conn, picks, sections):
    """Picks that exist in the library -> rating keys (title + year +-1)."""
    if not picks:
        return []
    titles = list({p["title"] for p in picks})
    found = {}
    for i in range(0, len(titles), 300):
        chunk = titles[i:i + 300]
        args = list(chunk)
        sec = ""
        if sections:
            sec = " AND section_id IN (%s)" % ",".join("?" * len(sections))
            args.extend(str(s) for s in sections)
        try:
            for rk, title, year, ptype in conn.execute(
                    "SELECT rating_key,title,year,plex_type FROM items WHERE title IN (%s) "
                    "AND plex_type IN ('movie','show')%s" % (",".join("?" * len(chunk)), sec), args):
                found.setdefault(title, []).append((str(rk), int(year or 0), ptype))
        except Exception as exc:
            _log("match fail %s" % exc, xbmc.LOGWARNING)
    out = []
    for p in picks:
        want_type = "movie" if p.get("kind") == "movie" else "show"
        for rk, year, ptype in found.get(p["title"], []):
            if ptype != want_type:
                continue
            if abs(year - int(p.get("year") or 0)) <= 1 or not year:
                if rk not in out:
                    out.append(rk)
                break
    return out


def _scope(kind, countries, not_countries, sections, titles):
    """Resolve country filters for this library.

    Movies: the DB has item_countries ("한국" / "외국").  Shows have no country
    rows, so the library (section) names decide: 국내/방영 = Korean, 미드 = US,
    일드 = Japanese, 해외 = foreign.  If no library name matches, the country
    filter is dropped rather than returning an empty row."""
    if kind != "show":
        return sections, countries, not_countries
    secs = list(sections or [])
    if countries:
        hit = [x for x in _section_hint(countries, titles) if not secs or x in secs]
        if hit:
            return hit, None, None
        return secs, None, None
    if not_countries:
        bad = set(_section_hint(not_countries, titles)) if "KR" in not_countries else set()
        if "KR" in not_countries:
            bad = set(x for x in _section_hint(["KR"], titles))
        keep = [x for x in secs if x not in bad]
        return (keep or secs), None, None
    return secs, None, None


def build_rows(conn, sections=None, titles=None):
    """-> (mode, [(row_title, [rating_key, ...]), ...]); mode 'taste' | 'random'.
    titles = {section_id: library name} (used to tell Korean / foreign shows)."""
    picks = load_picks()
    rows = []
    used = set()
    t0 = time.time()

    def add(title, keys, minimum=ROW_MIN):
        keys = [k for k in keys if k not in used]
        if len(keys) >= minimum:
            for k in keys:
                used.add(k)
            rows.append((title, keys))

    def fetch(kind, countries=None, not_countries=None, genres=None, years=None, anim=False):
        secs, c, nc = _scope(kind, countries, not_countries, sections, titles)
        excl = list(_MUSIC_GENRES) + ([] if anim else ["애니메이션"])
        return _candidates(conn, kind, secs, countries=c, not_countries=nc, genres=genres,
                           years=years, exclude_genres=excl)

    if not picks:
        for title, kind, countries, foreign in (
                ("한국 영화 랜덤 추천", "movie", ["KR"], False),
                ("외국 영화 랜덤 추천", "movie", None, True),
                ("한국 드라마 랜덤 추천", "show", ["KR"], False),
                ("외국 드라마 랜덤 추천", "show", None, True)):
            cands = fetch(kind, countries=countries, not_countries=["KR"] if foreign else None)
            add(title, _ranked(cands, None, used, min_score=7.0))
        _log("mode=random rows=%d ms=%d" % (len(rows), int((time.time() - t0) * 1000)))
        return "random", rows

    prof = build_profile(picks)
    anim_pref = prof["genres"].get("애니메이션", 0) >= 2
    have = match_picks(conn, picks, sections)
    if have:
        add("내가 고른 작품", have[:ROW_WANT * 2], minimum=1)
        used.update(have)  # picked titles never repeat in the other rows
    for title, kind in (("내 취향 영화", "movie"), ("내 취향 드라마", "show")):
        add(title, _ranked(fetch(kind, genres=list(prof["genres"].keys()), anim=anim_pref), prof["genres"], used))
    # one row per most-picked setup category: up to 2 movie + 2 drama categories
    order = sorted(prof["cats"].items(), key=lambda kv: -len(kv[1]))
    left = {"movie": 2, "show": 2}
    for cat, plist in order:
        spec = _CATEGORY_ROWS.get(cat)
        if not spec:
            continue
        kind, countries, gfilter = spec[:3]
        extra = dict(spec[3]) if len(spec) > 3 else {}
        bucket = "show" if kind == "show" else "movie"
        if left[bucket] <= 0:
            continue
        g_weights = {}
        for p in plist:
            for x in _pick_meta(p)[0]:
                g_weights[x] = g_weights.get(x, 0) + 1
        anim = bool(gfilter and "애니메이션" in gfilter) or anim_pref
        cands = fetch(kind, countries=countries or None, not_countries=extra.pop("not_countries", None),
                      genres=gfilter, years=extra.pop("years", None), anim=anim)
        keys = _ranked(cands, g_weights, used)
        before = len(rows)
        add("'%s' 취향" % cat, keys)
        if len(rows) > before:
            left[bucket] -= 1
    _log("mode=taste picks=%d matched=%d rows=%d ms=%d" % (len(picks), len(have), len(rows), int((time.time() - t0) * 1000)))
    return "taste", rows
