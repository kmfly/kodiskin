# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import os
import sys
import time
import traceback
import importlib
import threading

import xbmc
import xbmcgui

from resources.lib.pkm_video_info import apply_video_info
from resources.lib import pkm_global_busy

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_SELECT_ITEM = 7
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4

QUERY_LABEL_ID = 2100
MODE_LABEL_ID = 2101
KEYBOARD_ID = 3000
RESULTS_ID = 4000
EMPTY_LABEL_ID = 4100


_KODI_DISPLAY_TRANSLATE = {
    ord("\u23D0"): "|",
}

def _display_text_for_kodi(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def _load_core_module():
    try:
        mod = sys.modules.get("__main__")
        if mod is not None and hasattr(mod, "query_search_index"):
            return mod
    except Exception:
        pass
    try:
        addon_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        if addon_dir and addon_dir not in sys.path:
            sys.path.insert(0, addon_dir)
    except Exception:
        pass
    try:
        mod = sys.modules.get("default")
        if mod is not None and hasattr(mod, "query_search_index"):
            return mod
    except Exception:
        pass
    return importlib.import_module("default")


class PlexKMSearchWindow(xbmcgui.WindowXMLDialog):
    """Plex HTPC-like local DB search window.

    Search uses the separate PKM search DB only. It never calls Plex /search while
    the user is typing, so Korean chosung search stays instant after the local
    sync/index is ready.
    """

    MODES = ("KO", "EN", "NUM", "SYM")

    KEYS = {
        "KO": [
            "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ",
            "ㅅ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ",
            "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ",
            "ㅔ", "ㅕ", "ㅗ", "ㅛ", "ㅜ", "ㅠ",
            "ㅡ", "ㅣ", "입력", "Space", "Del", "Clear",
            "영문", "숫자", "기호"
        ],
        "EN": list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["입력", "Space", "Del", "Clear", "한글", "숫자", "기호"],
        "NUM": list("1234567890") + ["-", ".", ":", "/", "(", ")", "입력", "Space", "Del", "Clear", "한글", "영문", "기호"],
        "SYM": ["!", "?", "@", "#", "%", "&", "+", "=", "_", "'", '"', ",", ".", ":", "/", "-", "(", ")", "[", "]", "입력", "Space", "Del", "Clear", "한글", "영문", "숫자"],
    }

    def __init__(self, *args, **kwargs):
        self.query = ""
        self._query_tokens = []
        self.mode = "KO"
        self.last_search = ""
        self.last_search_ms = 0
        self.results = []
        self._opening_info = False
        self._last_keyboard_pos = 0
        self._last_result_pos = 0
        self._last_cross_focus_ms = 0
        self._last_cross_from = ""
        self._last_cross_to = ""
        self._scene_busy_lock_v2482 = threading.RLock()
        self._scene_busy_seq_v2482 = 0
        self._scene_busy_gates_v2482 = {}
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.SearchWindow.Active", "1")
            xbmcgui.Window(10000).clearProperty("PlexKM.SearchWindow.Opening")
        except Exception:
            pass
        # v1883: this legacy dialog must never rebuild or refresh the shared
        # search DB while the user is entering a query. Sync/upsert owns index
        # maintenance; the dialog reads the last complete index only.
        self._set_status("")
        _log("SEARCH_DIALOG_INDEX_REFRESH_DEFER_V1883 mode=existing_index")
        self._populate_keyboard()
        # Search is opened only by OK/Enter from the sidebar.  Do not touch the
        # Home sidebar focus chain here; just make the search window itself start
        # from the first keyboard key.
        try:
            kctrl = self.getControl(KEYBOARD_ID)
            if kctrl.size() > 0:
                kctrl.selectItem(0)
            self.setFocusId(KEYBOARD_ID)
            self._last_keyboard_pos = 0
        except Exception:
            pass
        self._refresh_query_label()
        self._set_empty("한글 키보드는 완성형으로 조합됩니다. 초성 검색은 ㄱㅅㅊ처럼 자음만 입력하세요.")
        _log("opened focus=keyboard_first")

    def close(self):
        try:
            with self._scene_busy_lock_v2482:
                for rec in list(self._scene_busy_gates_v2482.values()):
                    if isinstance(rec, dict):
                        rec["active"] = False
                self._scene_busy_gates_v2482.clear()
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.SearchWindow.Active")
        except Exception:
            pass
        xbmcgui.WindowXMLDialog.close(self)

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        try:
            aid = action.getId()
        except Exception:
            aid = 0
        # v1884: the modal XML normally consumes every action. This is the
        # construction-gap fallback before the dialog's native focus owner is ready.
        try:
            if pkm_global_busy.should_block_action(aid):
                _log("GLOBAL_BUSY_ACTION_BLOCK_V1885 window=legacy_search action=%s reason=%s focus=%s" % (
                    aid, pkm_global_busy.current_reason(), self.getFocusId()
                ))
                return
        except Exception:
            pass
        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.close()
            return
        if aid == ACTION_MOVE_LEFT:
            # The search window is modal and separate from Home, so XML cannot
            # focus sidebar 9000 directly.  Keep normal keyboard navigation in
            # XML, but let LEFT on the first keyboard key close the search window
            # and return to Home.  This does not move Home/sidebar focus.
            try:
                if self.getFocusId() == KEYBOARD_ID and self.getControl(KEYBOARD_ID).getSelectedPosition() == 0:
                    _log("KEYBOARD_FIRST_LEFT_CLOSE")
                    self.close()
                    return
            except Exception:
                pass
        # Directional navigation is otherwise handled by Kodi XML only.
        # Python only supplies keyboard/results items and handles clicks.

    def onClick(self, control_id):
        audit_event(self, "onClick", control_id=control_id)
        try:
            if pkm_global_busy.is_visible():
                _log("GLOBAL_BUSY_CLICK_BLOCK_V1885 window=legacy_search control=%s reason=%s" % (
                    control_id, pkm_global_busy.current_reason()
                ))
                return
        except Exception:
            pass
        if control_id == KEYBOARD_ID:
            self._handle_key_click()
            return
        if control_id == RESULTS_ID:
            self._open_selected_result_info()
            return

    def _set_status(self, text):
        try:
            self.getControl(MODE_LABEL_ID).setLabel(text or "")
        except Exception:
            pass

    def _set_empty(self, text):
        try:
            self.getControl(EMPTY_LABEL_ID).setLabel(text or "")
        except Exception:
            pass

    def _refresh_query_label(self):
        display = self.query if self.query else "검색"
        try:
            self.getControl(QUERY_LABEL_ID).setLabel(display)
        except Exception:
            pass
        self._set_status("%s 키보드" % ({"KO": "한글", "EN": "영문", "NUM": "숫자", "SYM": "기호"}.get(self.mode, self.mode)))

    def _populate_keyboard(self):
        ctrl = self.getControl(KEYBOARD_ID)
        ctrl.reset()
        for key in self.KEYS.get(self.mode, []):
            li = xbmcgui.ListItem(label=key)
            li.setProperty("SearchKey", key)
            li.setProperty("SearchMode", self.mode)
            ctrl.addItem(li)

    def _handle_key_click(self):
        try:
            li = self.getControl(KEYBOARD_ID).getSelectedItem()
            key = li.getProperty("SearchKey") or li.getLabel()
        except Exception:
            return
        if key in ("한글",):
            self.mode = "KO"
            self._populate_keyboard()
            self._refresh_query_label()
            return
        if key in ("영문",):
            self.mode = "EN"
            self._populate_keyboard()
            self._refresh_query_label()
            return
        if key == "숫자":
            self.mode = "NUM"
            self._populate_keyboard()
            self._refresh_query_label()
            return
        if key == "기호":
            self.mode = "SYM"
            self._populate_keyboard()
            self._refresh_query_label()
            return
        if key == "입력":
            self._open_full_text_input()
            return
        if key == "Space":
            self._append_query_token(" ")
        elif key == "Del":
            self._delete_query_token()
        elif key == "Clear":
            self._clear_query_tokens()
        else:
            self._append_query_token(key)
        self._refresh_query_label()
        self._run_search_debounced(force=True)

    _KO_CONSONANTS = set("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
    _KO_VOWELS = set("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
    _CHO = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
    _JUNG = ["ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"]
    _JONG = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]

    def _append_query_token(self, token):
        self._query_tokens.append(token)
        self._recompose_query_from_tokens()

    def _delete_query_token(self):
        if self._query_tokens:
            self._query_tokens.pop()
            self._recompose_query_from_tokens()
        else:
            self.query = self.query[:-1]

    def _clear_query_tokens(self):
        self._query_tokens = []
        self.query = ""

    def _compose_syllable(self, cho, jung, jong=""):
        try:
            l = self._CHO.index(cho)
            v = self._JUNG.index(jung)
            t = self._JONG.index(jong or "")
            return chr(0xAC00 + (l * 21 + v) * 28 + t)
        except Exception:
            return (cho or "") + (jung or "") + (jong or "")

    def _recompose_query_from_tokens(self):
        out = []
        L = None
        V = None
        T = None

        def commit():
            nonlocal L, V, T
            if L and V:
                out.append(self._compose_syllable(L, V, T or ""))
            elif L:
                out.append(L)
            elif V:
                out.append(V)
            L = V = T = None

        for token in self._query_tokens:
            ch = token or ""
            if len(ch) != 1:
                commit()
                out.append(ch)
                continue
            if ch in self._KO_CONSONANTS:
                if L is None:
                    L = ch
                elif V is None:
                    # Consonants only remain as compatibility jamo, so ㄱㅅㅊ is
                    # preserved for pure chosung search instead of becoming text.
                    out.append(L)
                    L = ch
                elif T is None and ch in self._JONG:
                    T = ch
                else:
                    commit()
                    L = ch
            elif ch in self._KO_VOWELS:
                if L is None:
                    commit()
                    V = ch
                    commit()
                elif V is None:
                    V = ch
                elif T is not None:
                    # Previous consonant was not a final consonant; it starts the
                    # next syllable.  ㄱ ㅣ ㅅ ㅐ becomes 기새, not 깃ㅐ.
                    old_t = T
                    out.append(self._compose_syllable(L, V, ""))
                    L, V, T = old_t, ch, None
                else:
                    commit()
                    V = ch
                    commit()
            else:
                commit()
                out.append(ch)
        commit()
        self.query = "".join(out)

    def _open_full_text_input(self):
        """Legacy PKM search keeps input inside the PKM keyboard."""
        try:
            self.setFocusId(self.KEYBOARD_ID)
            _log("SEARCH_WINDOW_STOCK_KEYBOARD_BLOCKED_V2452 owner=pkm_search_keyboard")
        except Exception:
            _log("search_inline_focus_failed_v2452\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _scene_busy_arm_v2482(self, reason="", threshold_ms=1000):
        try:
            with self._scene_busy_lock_v2482:
                self._scene_busy_seq_v2482 += 1
                token = "legacysearch2482:%d:%d" % (self._scene_busy_seq_v2482, int(time.time()*1000))
                self._scene_busy_gates_v2482[token] = {"active": True, "busy": "", "started": int(time.time()*1000)}
            def _worker():
                mon = xbmc.Monitor()
                if mon.waitForAbort(max(0, int(threshold_ms))/1000.0):
                    return
                busy = ""
                with self._scene_busy_lock_v2482:
                    rec = self._scene_busy_gates_v2482.get(token)
                    if not isinstance(rec, dict) or not rec.get("active"):
                        return
                    try:
                        busy = pkm_global_busy.begin(
                            reason="legacy_scene_v2482:%s" % (reason or ""),
                            scope="legacy_search", owner="query", replace_scope=True
                        )
                    except Exception:
                        busy = ""
                    if busy:
                        rec["busy"] = busy
                        try:
                            pkm_global_busy.promote(busy, reason="legacy_search_1000ms_v2482")
                        except Exception:
                            pass
                if busy:
                    _log("LEGACY_SEARCH_SPINNER_PROMOTE_V2482 threshold_ms=1000 reason=%s" % (reason or ""))
            threading.Thread(target=_worker, name="PKMLegacySearchSpinner1000V2482", daemon=True).start()
            return token
        except Exception:
            return ""

    def _scene_busy_finish_v2482(self, token, reason=""):
        token = str(token or "")
        if not token:
            return
        busy = ""
        try:
            with self._scene_busy_lock_v2482:
                rec = self._scene_busy_gates_v2482.pop(token, None)
                if isinstance(rec, dict):
                    rec["active"] = False
                    busy = str(rec.get("busy") or "")
            if busy:
                pkm_global_busy.end(busy, reason="legacy_scene_done_v2482:%s" % (reason or ""))
        except Exception:
            pass

    def _run_search_debounced(self, force=False):
        now = int(time.time() * 1000)
        if not force and now - self.last_search_ms < 80:
            return
        self.last_search_ms = now
        q = self.query.strip()
        if not q:
            self.results = []
            try:
                self.getControl(RESULTS_ID).reset()
            except Exception:
                pass
            self._set_empty("한글 키보드는 완성형으로 조합됩니다. 초성 검색은 ㄱㅅㅊ처럼 자음만 입력하세요.")
            return
        _busy_token_v1883 = ""
        try:
            _busy_token_v1883 = self._scene_busy_arm_v2482(reason="legacy_search_query:%s" % q, threshold_ms=1000)
            rows = _ensure_core().query_search_index(q, limit=80)
            self.results = rows or []
            self._populate_results(self.results)
            if self.results:
                self._set_empty("%d개 결과" % len(self.results))
            else:
                self._set_empty("검색 결과 없음")
        except Exception:
            self.results = []
            self._set_empty("검색 실패 - kodi.log 확인")
            _log("query_failed query=%s\n%s" % (q, traceback.format_exc()), xbmc.LOGERROR)
        finally:
            try:
                self._scene_busy_finish_v2482(_busy_token_v1883, reason="legacy_search_query_done")
            except Exception:
                pass

    def _row_to_listitem(self, row):
        row = tuple(row or ())
        # Stable wall-light tuple shape from default.py query_search_index.
        rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = row[:21]
        parent_rating_key = row[21] if len(row) > 21 else ""
        grandparent_rating_key = row[22] if len(row) > 22 else ""
        section_title = _display_text_for_kodi(row[23] if len(row) > 23 else "")
        if part_key and plex_type in ("movie", "episode"):
            url = _ensure_core().build_plugin_url({"action": "play", "rating_key": rating_key, "part_key": part_key})
        elif plex_type == "show":
            url = _ensure_core().build_plugin_url({"action": "show", "rating_key": rating_key, "section_id": section_id})
        else:
            url = _ensure_core().build_plugin_url({"action": "noop"})
        li = xbmcgui.ListItem(label=title or "", path=url)
        try:
            li.setPath(url)
        except Exception:
            pass
        display_thumb = thumb
        li.setArt({"poster": display_thumb or "", "thumb": display_thumb or "", "icon": display_thumb or "", "fanart": art or ""})
        mediatype = kodi_type or ("tvshow" if plex_type == "show" else plex_type or "video")
        apply_video_info(li, {
            "title": title or "",
            "sorttitle": sort_title or title or "",
            "originaltitle": original_title or "",
            "year": int(year or 0),
            "plot": summary or "",
            "duration": int(duration or 0),
            "mediatype": mediatype,
        })
        props = {
            "RatingKey": rating_key, "SectionId": section_id, "Type": plex_type, "KodiType": mediatype,
            "Title": title, "OriginalTitle": original_title, "SortTitle": sort_title, "Year": year,
            "Summary": summary, "SummaryDisplay": summary, "Duration": duration, "AddedAt": added_at, "UpdatedAt": updated_at,
            "Thumb": display_thumb, "Art": art, "PartKey": part_key, "ViewCount": view_count,
            "ShowTitle": show_title, "Season": season, "Episode": episode,
            "ParentRatingKey": parent_rating_key, "GrandparentRatingKey": grandparent_rating_key,
            "PlayUrl": url if part_key and plex_type in ("movie", "episode") else "",
            "ShowUrl": url if plex_type == "show" else "",
            "SectionTitle": _display_text_for_kodi(section_title),
        }
        try:
            props.update(getattr(_ensure_core(), "pkm_common_progress_props", lambda *a, **k: {})(rating_key, plex_type, grandparent_rating_key, view_count, 0, duration, 0) or {})
        except Exception:
            pass
        for k, v in props.items():
            try:
                li.setProperty("PlexKM.%s" % k, str(v or ""))
            except Exception:
                pass
        if part_key and plex_type in ("movie", "episode"):
            li.setProperty("IsPlayable", "true")
        return li

    def _populate_results(self, rows):
        ctrl = self.getControl(RESULTS_ID)
        prev_pos = 0
        try:
            prev_pos = max(0, ctrl.getSelectedPosition())
        except Exception:
            prev_pos = max(0, int(self._last_result_pos or 0))
        ctrl.reset()
        for row in rows or []:
            ctrl.addItem(self._row_to_listitem(row))
        try:
            if ctrl.size() > 0:
                self._last_result_pos = min(prev_pos, ctrl.size() - 1)
                ctrl.selectItem(self._last_result_pos)
            else:
                self._last_result_pos = 0
        except Exception:
            pass

    def _publish_info_properties_basic(self, li):
        win = xbmcgui.Window(10000)
        keys = ["RatingKey", "SectionId", "Type", "KodiType", "Title", "OriginalTitle", "Summary", "SummaryDisplay", "Year", "Duration", "Thumb", "Art", "PartKey", "PlayUrl", "ShowUrl", "ShowTitle", "Season", "Episode", "AddedAt", "UpdatedAt"]
        for key in keys:
            try:
                win.setProperty("PlexKM.Info.%s" % key, li.getProperty("PlexKM.%s" % key) or "")
            except Exception:
                pass
        try:
            win.setProperty("PlexKM.Info.PlayButtonLabel", "재생")
            win.setProperty("PlexKM.Info.InfoLoadedRatingKey", li.getProperty("PlexKM.RatingKey") or "")
            for idx in range(1, 9):
                for prefix in ("PlexKM.Info.Cast", "PlexKM.Info.DisplayCast"):
                    for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                        win.clearProperty("%s%d.%s" % (prefix, idx, subkey))
        except Exception:
            pass

    def _open_selected_result_info(self):
        # The removed modal Info XML is not used by the current Home flow.
        # Current search lives inside HomeWindow and opens the inline overlay.
        _log("SEARCH_INFO_SKIPPED reason=legacy_standalone_search", xbmc.LOGINFO)
