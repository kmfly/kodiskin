# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM V2600 low-overhead UHD diagnostics.

Design rules:
- NEVER write logs or read /proc from a remote-key callback.
- note_input()/event() are memory-only producers.
- one sleeping diagnostic thread drains events and emits a 1 second sample.
- no network, SQLite, image decode, screenshot, Kodi control traversal, or polling
  faster than 1 second is performed by this module.
"""

from collections import deque
import gc
import os
import threading
import time

try:
    import xbmc
    import xbmcgui
except Exception:
    xbmc = None
    xbmcgui = None

try:
    from resources.lib import pkm_artwork_scheduler
except Exception:
    pkm_artwork_scheduler = None

_LOCK = threading.RLock()
_WAKE = threading.Event()
_STARTED = False
_STOP = False
_EVENTS = deque(maxlen=96)
_EVENT_DROPPED = 0
_LAST_LOG_MS = 0
_LAST_PERIODIC_MS = 0
_CPU = {"proc": None, "wall": None}
_INPUT = {
    "count": 0,
    "burst": 0,
    "max_burst": 0,
    "last_ms": 0,
    "min_gap": 999999,
    "max_gap": 0,
    "last_action": -1,
    "last_focus": -1,
    "surface": "",
}


def _now_ms():
    return int(time.monotonic() * 1000.0)


def _android():
    try:
        return bool(xbmc and xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        return False


def _read_text(path, limit=65536):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            return fh.read(limit)
    except Exception:
        return ""


def _proc_status():
    out = {"rss_mb": -1, "vms_mb": -1, "proc_threads": -1}
    txt = _read_text("/proc/self/status")
    for line in txt.splitlines():
        if line.startswith("VmRSS:"):
            try:
                out["rss_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
        elif line.startswith("VmSize:"):
            try:
                out["vms_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
        elif line.startswith("Threads:"):
            try:
                out["proc_threads"] = int(line.split()[1])
            except Exception:
                pass
    return out


def _meminfo():
    out = {"mem_avail_mb": -1, "mem_free_mb": -1, "mem_total_mb": -1, "cached_mb": -1}
    txt = _read_text("/proc/meminfo")
    for line in txt.splitlines():
        if line.startswith("MemAvailable:"):
            try:
                out["mem_avail_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
        elif line.startswith("MemFree:"):
            try:
                out["mem_free_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
        elif line.startswith("MemTotal:"):
            try:
                out["mem_total_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
        elif line.startswith("Cached:"):
            try:
                out["cached_mb"] = int(line.split()[1]) // 1024
            except Exception:
                pass
    return out


def _proc_io():
    out = {"read_mb": -1, "write_mb": -1, "rchar_mb": -1, "wchar_mb": -1}
    txt = _read_text("/proc/self/io", 4096)
    vals = {}
    for line in txt.splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        try:
            vals[k.strip()] = int(v.strip())
        except Exception:
            pass
    div = 1024.0 * 1024.0
    try:
        out["read_mb"] = round(float(vals.get("read_bytes", -1)) / div, 1) if vals.get("read_bytes", -1) >= 0 else -1
        out["write_mb"] = round(float(vals.get("write_bytes", -1)) / div, 1) if vals.get("write_bytes", -1) >= 0 else -1
        out["rchar_mb"] = round(float(vals.get("rchar", -1)) / div, 1) if vals.get("rchar", -1) >= 0 else -1
        out["wchar_mb"] = round(float(vals.get("wchar", -1)) / div, 1) if vals.get("wchar", -1) >= 0 else -1
    except Exception:
        pass
    return out


def _fd_count():
    try:
        return len(os.listdir("/proc/self/fd"))
    except Exception:
        return -1


def _loadavg():
    try:
        return float((_read_text("/proc/loadavg", 256).split() or ["-1"])[0])
    except Exception:
        return -1.0


def _proc_cpu_pct():
    """Process CPU as percent of one core, so >100 is possible."""
    try:
        stat = _read_text("/proc/self/stat", 4096).split()
        ticks = int(stat[13]) + int(stat[14])
        now = time.monotonic()
        clk = float(os.sysconf("SC_CLK_TCK"))
        prev_ticks = _CPU.get("proc")
        prev_wall = _CPU.get("wall")
        _CPU["proc"] = ticks
        _CPU["wall"] = now
        if prev_ticks is None or prev_wall is None or now <= prev_wall:
            return -1.0
        return max(0.0, ((ticks - prev_ticks) / clk) / (now - prev_wall) * 100.0)
    except Exception:
        return -1.0


def _thread_info():
    out = {
        "py_threads": -1,
        "pkm_threads": -1,
        "netlike": 0,
        "dblike": 0,
        "actor": 0,
        "art": 0,
        "library": 0,
        "names": "-",
    }
    try:
        threads = list(threading.enumerate())
        selected = []
        all_names = []
        for t in threads:
            n = str(getattr(t, "name", "") or "")
            all_names.append(n)
            low = n.lower()
            if n.startswith(("PlexKM", "Actor", "PKM", "ThreadPoolExecutor")):
                selected.append(n)
            if any(x in low for x in ("plex", "http", "net", "request", "sync")):
                out["netlike"] += 1
            if any(x in low for x in ("sql", "sqlite", "db", "index")):
                out["dblike"] += 1
            if "actor" in low or "person" in low:
                out["actor"] += 1
            if "art" in low or "poster" in low or "image" in low:
                out["art"] += 1
            if "library" in low or "wall" in low:
                out["library"] += 1
        seen = set()
        compact = []
        for n in selected:
            if n in seen:
                continue
            seen.add(n)
            compact.append(n[:56])
            if len(compact) >= 18:
                break
        out["py_threads"] = len(threads)
        out["pkm_threads"] = len(selected)
        out["names"] = ",".join(compact) or "-"
    except Exception:
        pass
    return out


def _window_props():
    out = {
        "home_ready": "0",
        "sidebar": "0",
        "rapid": "0",
        "nav_hot": "0",
        "playback": "0",
        "section": "",
        "surface": "",
        "actor": "0",
    }
    if xbmcgui is None:
        return out
    try:
        w = xbmcgui.Window(10000)
        out["home_ready"] = "1" if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1" else "0"
        out["sidebar"] = "1" if w.getProperty("PlexKM.Sidebar.Browsing") == "1" else "0"
        out["rapid"] = "1" if w.getProperty("PlexKM.WallRapidScrollV2581") == "1" else "0"
        try:
            until = int(float(w.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
            out["nav_hot"] = "1" if until > int(time.time() * 1000) else "0"
        except Exception:
            pass
        out["playback"] = "1" if (
            w.getProperty("PlexKM.Playback.PriorityV2118") == "1"
            or w.getProperty("PlexKM.Playback.OpeningActive") == "1"
            or w.getProperty("PlexKM.MainPlaybackStarting") == "1"
        ) else "0"
        out["section"] = w.getProperty("PlexKM.Window.SectionId") or w.getProperty("PlexKM.ActiveSectionId") or ""
        out["surface"] = (
            "actor" if w.getProperty("PlexKM.ActorProfile.Active") == "1" else
            "info" if w.getProperty("PlexKM.Info.InlineActive") == "1" else
            "library" if w.getProperty("PlexKM.Window.IsSectionWall") == "1" else
            "home"
        )
        out["actor"] = "1" if w.getProperty("PlexKM.ActorProfile.Active") == "1" else "0"
    except Exception:
        pass
    return out


def _art_stats():
    base = {"active": -1, "waiting": -1, "inflight": -1, "limit": -1, "cancelled": -1, "failed": -1, "peak": -1}
    try:
        if pkm_artwork_scheduler is not None and hasattr(pkm_artwork_scheduler, "stats_snapshot"):
            st = pkm_artwork_scheduler.stats_snapshot() or {}
            mapping = {"peak": "peak_active"}
            for key in list(base):
                source = mapping.get(key, key)
                if source in st:
                    base[key] = int(st.get(source) or 0)
    except Exception:
        pass
    return base


def note_input(action_id, focus_id=-1, surface=""):
    """Remote-key hot path: counters only, no log/proc/window I/O."""
    try:
        now = _now_ms()
        with _LOCK:
            prev = int(_INPUT.get("last_ms") or 0)
            gap = now - prev if prev > 0 else 999999
            if prev > 0:
                _INPUT["min_gap"] = min(int(_INPUT.get("min_gap") or 999999), max(0, gap))
                _INPUT["max_gap"] = max(int(_INPUT.get("max_gap") or 0), max(0, gap))
            if prev > 0 and gap <= 280:
                _INPUT["burst"] = int(_INPUT.get("burst") or 0) + 1
            else:
                _INPUT["burst"] = 1
            _INPUT["max_burst"] = max(int(_INPUT.get("max_burst") or 0), int(_INPUT["burst"]))
            _INPUT["count"] = int(_INPUT.get("count") or 0) + 1
            _INPUT["last_ms"] = now
            _INPUT["last_action"] = int(action_id or 0)
            _INPUT["last_focus"] = int(focus_id or -1)
            if surface:
                _INPUT["surface"] = str(surface)[:32]
    except Exception:
        pass


def event(name, extra=""):
    """Queue an event without logging from the GUI/input path."""
    global _EVENT_DROPPED
    try:
        rec = (_now_ms(), str(name or "EVENT")[:48], str(extra or "").replace("\n", " ")[:900])
        with _LOCK:
            if len(_EVENTS) >= _EVENTS.maxlen:
                _EVENT_DROPPED += 1
            _EVENTS.append(rec)
        _WAKE.set()
        return True
    except Exception:
        return False


def _input_snapshot(reset=True):
    with _LOCK:
        data = dict(_INPUT)
        if reset:
            _INPUT["count"] = 0
            # Preserve the current burst so a burst crossing a sample boundary is
            # not artificially reset, but clear the reported peak for the window.
            _INPUT["max_burst"] = int(_INPUT.get("burst") or 0)
            _INPUT["min_gap"] = 999999
            _INPUT["max_gap"] = 0
        return data


def _drain_events(limit=24):
    global _EVENT_DROPPED
    out = []
    dropped = 0
    with _LOCK:
        while _EVENTS and len(out) < int(limit):
            out.append(_EVENTS.popleft())
        dropped = int(_EVENT_DROPPED or 0)
        _EVENT_DROPPED = 0
        if not _EVENTS:
            _WAKE.clear()
    return out, dropped


def snapshot(event_name, extra="", force=True, event_queued_ms=0, sampler_gap_ms=-1, dropped=0):
    """Emit one comprehensive diagnostic line from the diagnostic thread."""
    global _LAST_LOG_MS
    try:
        if xbmc is None:
            return False
        now = _now_ms()
        if not force and now - int(_LAST_LOG_MS or 0) < 900:
            return False
        prev_log = int(_LAST_LOG_MS or 0)
        _LAST_LOG_MS = now
        is_android = _android()
        ps = _proc_status() if is_android else {"rss_mb": -1, "vms_mb": -1, "proc_threads": -1}
        mi = _meminfo() if is_android else {"mem_avail_mb": -1, "mem_free_mb": -1, "mem_total_mb": -1, "cached_mb": -1}
        io = _proc_io() if is_android else {"read_mb": -1, "write_mb": -1, "rchar_mb": -1, "wchar_mb": -1}
        th = _thread_info()
        art = _art_stats()
        win = _window_props()
        inp = _input_snapshot(reset=True)
        cpu = _proc_cpu_pct() if is_android else -1.0
        try:
            gc0, gc1, gc2 = gc.get_count()
        except Exception:
            gc0, gc1, gc2 = (-1, -1, -1)
        age = now - int(inp.get("last_ms") or 0) if int(inp.get("last_ms") or 0) > 0 else -1
        queued_age = now - int(event_queued_ms or 0) if int(event_queued_ms or 0) > 0 else 0
        log_gap = now - prev_log if prev_log > 0 else -1
        line = (
            "[PKM_UHD_DIAG_V2600] event=%s android=%d queued_age_ms=%d sampler_gap_ms=%d log_gap_ms=%d dropped=%d "
            "rss_mb=%s vms_mb=%s mem_avail_mb=%s mem_free_mb=%s mem_total_mb=%s cached_mb=%s "
            "cpu_pct=%.1f load1=%.2f fd=%s io_read_mb=%s io_write_mb=%s io_rchar_mb=%s io_wchar_mb=%s "
            "py_threads=%s proc_threads=%s pkm_threads=%s thread_net=%s thread_db=%s thread_actor=%s thread_art=%s thread_library=%s "
            "art_active=%s art_wait=%s art_inflight=%s art_limit=%s art_peak=%s art_failed=%s art_cancelled=%s "
            "home_ready=%s surface=%s section=%s sidebar=%s rapid=%s nav_hot=%s playback=%s actor=%s "
            "input_window=%s burst_max=%s last_action=%s last_focus=%s input_age_ms=%s min_gap_ms=%s max_gap_ms=%s "
            "gc=%s/%s/%s thread_names=%s extra=%s"
        ) % (
            str(event_name or "sample")[:48], 1 if is_android else 0, queued_age, int(sampler_gap_ms), log_gap, int(dropped or 0),
            ps.get("rss_mb"), ps.get("vms_mb"), mi.get("mem_avail_mb"), mi.get("mem_free_mb"), mi.get("mem_total_mb"), mi.get("cached_mb"),
            cpu, _loadavg() if is_android else -1.0, _fd_count() if is_android else -1,
            io.get("read_mb"), io.get("write_mb"), io.get("rchar_mb"), io.get("wchar_mb"),
            th.get("py_threads"), ps.get("proc_threads"), th.get("pkm_threads"), th.get("netlike"), th.get("dblike"), th.get("actor"), th.get("art"), th.get("library"),
            art.get("active"), art.get("waiting"), art.get("inflight"), art.get("limit"), art.get("peak"), art.get("failed"), art.get("cancelled"),
            win.get("home_ready"), win.get("surface"), win.get("section") or "-", win.get("sidebar"), win.get("rapid"), win.get("nav_hot"), win.get("playback"), win.get("actor"),
            inp.get("count"), inp.get("max_burst"), inp.get("last_action"), inp.get("last_focus"), age,
            (-1 if int(inp.get("min_gap") or 999999) >= 999999 else int(inp.get("min_gap") or 0)), int(inp.get("max_gap") or 0),
            gc0, gc1, gc2, th.get("names"), str(extra or "")[:900]
        )
        xbmc.log(line, xbmc.LOGINFO)
        return True
    except Exception as exc:
        try:
            xbmc.log("[PKM_UHD_DIAG_V2600] snapshot_failed event=%s err=%s" % (event_name, exc), xbmc.LOGWARNING)
        except Exception:
            pass
        return False


def start_sampler(interval_sec=1.0):
    """Start one event-drain worker; Android also emits a 1 second sample."""
    global _STARTED, _STOP, _LAST_PERIODIC_MS
    if xbmc is None:
        return False
    with _LOCK:
        if _STARTED:
            return True
        _STARTED = True
        _STOP = False
    is_android = _android()
    interval_sec = max(1.0, float(interval_sec or 1.0))
    interval_ms = int(interval_sec * 1000.0)
    _LAST_PERIODIC_MS = _now_ms()

    def _worker():
        global _LAST_PERIODIC_MS
        snapshot(
            "START" if is_android else "START_DESKTOP",
            "sampler_ms=%d old_200ms_android=0 event_queue=1 gui_hotpath_io=0" % interval_ms,
            force=True,
        )
        monitor = None
        try:
            monitor = xbmc.Monitor()
        except Exception:
            monitor = None
        last_loop = _now_ms()
        while True:
            with _LOCK:
                if _STOP:
                    break
            # Wake quickly for a queued milestone, otherwise sleep until the next
            # 1 s sample. Event logging stays on this thread, never on GUI/input.
            _WAKE.wait(interval_sec if is_android else 5.0)
            now = _now_ms()
            loop_gap = max(0, now - last_loop)
            last_loop = now
            events, dropped = _drain_events(limit=24)
            for idx, rec in enumerate(events):
                queued_ms, name, extra = rec
                snapshot(
                    name,
                    extra=extra,
                    force=True,
                    event_queued_ms=queued_ms,
                    sampler_gap_ms=loop_gap,
                    dropped=(dropped if idx == 0 else 0),
                )
            if is_android and now - int(_LAST_PERIODIC_MS or 0) >= interval_ms:
                periodic_gap = now - int(_LAST_PERIODIC_MS or now)
                _LAST_PERIODIC_MS = now
                snapshot(
                    "SAMPLE",
                    "poller=event_plus_1s gui_hotpath_io=0",
                    force=True,
                    sampler_gap_ms=periodic_gap,
                )
            try:
                if monitor is not None and monitor.abortRequested():
                    break
            except Exception:
                pass
        snapshot("STOP", "sampler_exit=1", force=True)

    t = threading.Thread(target=_worker, name="PKMUHDDiagV2600", daemon=True)
    t.start()
    return True


def stop_sampler():
    global _STOP
    with _LOCK:
        _STOP = True
    _WAKE.set()
