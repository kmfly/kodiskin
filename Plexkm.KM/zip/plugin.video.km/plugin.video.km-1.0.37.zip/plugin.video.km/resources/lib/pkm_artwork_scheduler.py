# -*- coding: utf-8 -*-
"""Shared bounded artwork download scheduler for PKM.

The scheduler is intentionally platform-neutral and owns only network transfer
coordination. Kodi GUI objects are never passed into this module.

Properties:
- one shared three-transfer budget for PKM-managed artwork
- priority-aware admission (foreground, visible, ahead, background)
- same-URL in-flight request coalescing
- bounded reads with cancellation checks
- short negative cache for 404/timeouts/errors
- low-priority pause/abort when playback starts
- all slots/events are released from finally blocks
"""
from __future__ import absolute_import, unicode_literals

import heapq
import itertools
import socket
import threading
import time

from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

try:
    import xbmc
    import xbmcgui
except Exception:  # pragma: no cover - import exists in Kodi runtime
    xbmc = None
    xbmcgui = None

# PKM_PATCH_ACTIVE v2600 uhd_android_single_art_lane_always
# U+ UHD-class Android boxes are input/GUI constrained.  Even when the user is
# not actively holding a key, a second decode/download lane can overlap the next
# remote action.  Keep Android on one PKM-managed artwork transfer at all times;
# desktop keeps the existing two-lane budget.
try:
    _ANDROID_V2600 = bool(xbmc and xbmc.getCondVisibility("System.Platform.Android"))
except Exception:
    _ANDROID_V2600 = False
MAX_ACTIVE_DOWNLOADS = 1 if _ANDROID_V2600 else 2
PRIORITY_FOREGROUND = 0
PRIORITY_VISIBLE = 10
PRIORITY_AHEAD = 20
PRIORITY_BACKGROUND = 30

# PKM_PATCH_ACTIVE v2581 uhd3_artwork_two_lane_budget
# UHD3 measurements showed that three simultaneous Plex poster transfers plus
# SQLite/list rebinding could starve Kodi's GUI/input thread. Two transfers keep
# visible artwork progressing while leaving CPU/memory/network headroom for
# remote-key navigation.

_NEGATIVE_TTL_404 = 120.0
_NEGATIVE_TTL_TIMEOUT = 15.0
_NEGATIVE_TTL_ERROR = 20.0
_WAIT_SLICE_SEC = 0.05
_READ_CHUNK = 64 * 1024

_condition = threading.Condition(threading.RLock())
_wait_heap = []
_wait_seq = itertools.count()
_active = 0
_inflight = {}
_negative = {}
_stats = {
    "submitted": 0,
    "owners": 0,
    "coalesced_waiters": 0,
    "cache_negative_hits": 0,
    "completed": 0,
    "failed": 0,
    "cancelled": 0,
    "peak_active": 0,
}


class ArtworkCancelled(Exception):
    pass


class ArtworkNegativeCache(Exception):
    pass


class _Flight(object):
    __slots__ = (
        "event", "data", "error", "status", "started", "tag",
        "priority", "ticket", "consumers", "allow_during_playback",
    )

    def __init__(self, tag="", priority=PRIORITY_VISIBLE, pause_when_playing=False):
        self.event = threading.Event()
        self.data = None
        self.error = None
        self.status = 0
        self.started = time.time()
        self.tag = str(tag or "")
        self.priority = int(priority or 0)
        self.ticket = None
        self.consumers = 1
        self.allow_during_playback = not bool(pause_when_playing)


def _log(message, level=None):
    try:
        if xbmc is None:
            return
        xbmc.log("[plugin.video.km] %s" % str(message), level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _now():
    return time.time()


def _full_reset_active_v2150():
    try:
        if xbmcgui is None:
            return False
        win = xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.FullResetInProgressV2150") == "1"
            or win.getProperty("PlexKM.FullResetInProgressV2149") == "1"
        )
    except Exception:
        return False


def request_full_reset_stop_v2150():
    """Cancel queued/coalesced artwork work at the full-reset boundary."""
    try:
        with _condition:
            for ticket in _wait_heap:
                try:
                    ticket[2] = True
                except Exception:
                    pass
            _negative.clear()
            _condition.notify_all()
        _log("ARTWORK_FULL_RESET_STOP_V2150 waiting_cancelled=1")
        return True
    except Exception:
        return False


def _safe_cancelled(cancel_check=None, pause_check=None, pause_when_playing=False):
    if _full_reset_active_v2150():
        return True
    try:
        if callable(cancel_check) and cancel_check():
            return True
    except Exception:
        return True
    if pause_when_playing:
        try:
            if callable(pause_check) and pause_check():
                return True
        except Exception:
            pass
    return False


def _purge_negative_locked(now):
    stale = [key for key, value in _negative.items() if float(value[0] or 0.0) <= now]
    for key in stale:
        _negative.pop(key, None)


def _negative_reason_locked(key, now):
    _purge_negative_locked(now)
    value = _negative.get(key)
    if not value:
        return ""
    return str(value[1] or "negative")


def _set_negative(key, reason, ttl):
    try:
        with _condition:
            _negative[str(key)] = (_now() + max(1.0, float(ttl or 1.0)), str(reason or "error"))
    except Exception:
        pass


def _ticket_acquire(priority, cancel_check=None, pause_check=None, pause_when_playing=False, flight=None):
    global _active
    ticket = [int(priority or 0), next(_wait_seq), False]
    with _condition:
        if flight is not None:
            flight.ticket = ticket
        heapq.heappush(_wait_heap, ticket)
        while True:
            while _wait_heap and bool(_wait_heap[0][2]):
                heapq.heappop(_wait_heap)
            if _safe_cancelled(cancel_check, pause_check, pause_when_playing):
                ticket[2] = True
                _condition.notify_all()
                raise ArtworkCancelled("cancelled_before_slot")
            # PKM_PATCH_ACTIVE v2582 uhd3_wall_rapid_single_art_lane
            # While Library rapid-scroll is active, leave one full lane of CPU/
            # network headroom for Kodi input/container work.  Outside the burst
            # retain the normal two-transfer shared budget.
            effective_limit_v2582 = MAX_ACTIVE_DOWNLOADS
            try:
                if xbmcgui is not None:
                    win_v2595 = xbmcgui.Window(10000)
                    rapid_v2595 = win_v2595.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                    sidebar_v2595 = win_v2595.getProperty("PlexKM.Sidebar.Browsing") == "1"
                    nav_until_v2595 = int(float(win_v2595.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
                    nav_hot_v2595 = bool(nav_until_v2595 and int(time.time() * 1000) < nav_until_v2595)
                    # PKM_PATCH_ACTIVE v2595 uhd_navigation_single_art_lane
                    # One artwork transfer is enough while the user is navigating;
                    # the second lane belongs to Kodi input/container/decode work.
                    if rapid_v2595 or sidebar_v2595 or nav_hot_v2595:
                        effective_limit_v2582 = 1
            except Exception:
                effective_limit_v2582 = MAX_ACTIVE_DOWNLOADS
            if _active < effective_limit_v2582 and _wait_heap and _wait_heap[0] is ticket:
                heapq.heappop(_wait_heap)
                _active += 1
                _stats["peak_active"] = max(int(_stats.get("peak_active", 0)), int(_active))
                return ticket
            _condition.wait(_WAIT_SLICE_SEC)


def _ticket_release():
    global _active
    with _condition:
        _active = max(0, int(_active) - 1)
        _condition.notify_all()


def _wait_for_flight(flight, timeout, cancel_check=None, pause_check=None, pause_when_playing=False):
    deadline = _now() + max(0.5, float(timeout or 0.0) + 1.0)
    try:
        while not flight.event.wait(_WAIT_SLICE_SEC):
            if _safe_cancelled(cancel_check, pause_check, pause_when_playing):
                raise ArtworkCancelled("cancelled_waiting_for_duplicate")
            if _now() >= deadline:
                raise TimeoutError("coalesced_artwork_wait_timeout")
        if flight.error is not None:
            raise flight.error
        return flight.data or b""
    finally:
        with _condition:
            flight.consumers = max(1, int(flight.consumers or 1) - 1)
            _condition.notify_all()


def fetch_bytes(url, timeout=3.0, max_bytes=8 * 1024 * 1024, headers=None,
                priority=PRIORITY_VISIBLE, tag="", cancel_check=None,
                pause_check=None, pause_when_playing=False):
    """Return one bounded artwork response body.

    The same URL is transferred once even when several PKM worker pools request
    it concurrently. Waiters receive the owner's immutable bytes result.
    """
    if _full_reset_active_v2150():
        raise ArtworkCancelled("full_reset_v2150")
    key = str(url or "").strip()
    if not key:
        return b""
    if not key.lower().startswith(("http://", "https://")):
        return b""
    byte_limit = max(1024, int(max_bytes or 0))
    timeout_value = max(0.25, float(timeout or 0.0))

    with _condition:
        _stats["submitted"] += 1
        reason = _negative_reason_locked(key, _now())
        if reason:
            _stats["cache_negative_hits"] += 1
            raise ArtworkNegativeCache(reason)
        flight = _inflight.get(key)
        if flight is not None:
            _stats["coalesced_waiters"] += 1
            flight.consumers = int(flight.consumers or 1) + 1
            flight.allow_during_playback = bool(flight.allow_during_playback or not bool(pause_when_playing))
            new_priority = int(priority or 0)
            if new_priority < int(flight.priority or 0):
                flight.priority = new_priority
                if flight.ticket is not None and not bool(flight.ticket[2]):
                    flight.ticket[0] = new_priority
                    heapq.heapify(_wait_heap)
                    _condition.notify_all()
            owner = False
        else:
            flight = _Flight(tag=tag, priority=priority, pause_when_playing=pause_when_playing)
            _inflight[key] = flight
            _stats["owners"] += 1
            owner = True

    if not owner:
        return _wait_for_flight(
            flight, timeout_value, cancel_check=cancel_check,
            pause_check=pause_check, pause_when_playing=pause_when_playing,
        )

    def _owner_cancelled():
        try:
            requested = bool(callable(cancel_check) and cancel_check())
        except Exception:
            requested = True
        if not requested:
            return False
        with _condition:
            # A later visible consumer may still need a transfer started by a
            # stale/background owner. Keep it alive until that consumer leaves.
            return int(flight.consumers or 1) <= 1

    def _owner_playback_active():
        with _condition:
            if bool(flight.allow_during_playback):
                return False
        try:
            return bool(callable(pause_check) and pause_check())
        except Exception:
            return False

    acquired = False
    response = None
    try:
        _ticket_acquire(
            flight.priority, cancel_check=_owner_cancelled,
            pause_check=_owner_playback_active, pause_when_playing=True,
            flight=flight,
        )
        acquired = True
        if _safe_cancelled(_owner_cancelled, _owner_playback_active, True):
            raise ArtworkCancelled("cancelled_before_open")

        request = Request(key, headers=dict(headers or {}))
        response = urlopen(request, timeout=timeout_value)
        status = int(getattr(response, "status", 0) or getattr(response, "code", 0) or 200)
        flight.status = status
        data = bytearray()
        while True:
            if _safe_cancelled(_owner_cancelled, _owner_playback_active, True):
                raise ArtworkCancelled("cancelled_during_read")
            remaining = byte_limit + 1 - len(data)
            if remaining <= 0:
                break
            chunk = response.read(min(_READ_CHUNK, remaining))
            if not chunk:
                break
            data.extend(chunk)
        if len(data) > byte_limit:
            raise ValueError("artwork_response_too_large")
        if _full_reset_active_v2150():
            raise ArtworkCancelled("full_reset_v2150_after_read")
        flight.data = bytes(data)
        _stats["completed"] += 1
        return flight.data
    except HTTPError as exc:
        flight.error = exc
        _stats["failed"] += 1
        code = int(getattr(exc, "code", 0) or 0)
        if code == 404:
            _set_negative(key, "http_404", _NEGATIVE_TTL_404)
        elif code >= 400:
            _set_negative(key, "http_%d" % code, _NEGATIVE_TTL_ERROR)
        raise
    except (socket.timeout, TimeoutError) as exc:
        flight.error = exc
        _stats["failed"] += 1
        _set_negative(key, "timeout", _NEGATIVE_TTL_TIMEOUT)
        raise
    except ArtworkCancelled as exc:
        flight.error = exc
        _stats["cancelled"] += 1
        raise
    except URLError as exc:
        flight.error = exc
        _stats["failed"] += 1
        reason = getattr(exc, "reason", None)
        if isinstance(reason, socket.timeout):
            _set_negative(key, "timeout", _NEGATIVE_TTL_TIMEOUT)
        else:
            _set_negative(key, "url_error", _NEGATIVE_TTL_ERROR)
        raise
    except Exception as exc:
        flight.error = exc
        _stats["failed"] += 1
        _set_negative(key, "error", _NEGATIVE_TTL_ERROR)
        raise
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass
        if acquired:
            _ticket_release()
        with _condition:
            _inflight.pop(key, None)
            flight.event.set()
            _condition.notify_all()


def stats_snapshot():
    with _condition:
        result = dict(_stats)
        result.update({
            "active": int(_active),
            "waiting": sum(1 for ticket in _wait_heap if not bool(ticket[2])),
            "inflight": len(_inflight),
            "negative": len(_negative),
            "limit": MAX_ACTIVE_DOWNLOADS,
        })
        return result


def log_stats(reason=""):
    data = stats_snapshot()
    _log(
        "ARTWORK_SCHEDULER_STATS_V1937 reason=%s limit=%d active=%d waiting=%d inflight=%d "
        "submitted=%d owners=%d coalesced=%d completed=%d failed=%d cancelled=%d negative_hits=%d peak=%d" % (
            str(reason or ""), data["limit"], data["active"], data["waiting"], data["inflight"],
            data["submitted"], data["owners"], data["coalesced_waiters"], data["completed"],
            data["failed"], data["cancelled"], data["cache_negative_hits"], data["peak_active"],
        )
    )
