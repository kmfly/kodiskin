# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Backup / restore of the PKM YouTube settings (R79).

What is saved (one JSON file):
  * API key and search history            (youtube_settings_r79.json)
  * PKM local subscriptions               (youtube_subs_r79.json)
  * OAuth client + account login token    (youtube_account_r79.json)
  * account subscription list             (youtube_account_subs_r79.json)

Where: outside Kodi's add-on data so it survives an add-on removal or a
Kodi data wipe --
  Android: /storage/emulated/0/Download/PKM/pkm_youtube_backup.json
  others : ~/Downloads/PKM (or special://home/pkm_backup)
The previous file is kept as *.prev.json.  pkm_youtube._save_json() calls
schedule() after every settings change (debounced), so the backup is always
current.  The phone page can also download / upload the same file.
"""

import json
import os
import threading
import time
import traceback

import xbmc

from resources.lib import pkm_youtube as yt

BACKUP_NAME = "pkm_youtube_backup.json"
FORMAT = "pkm-youtube-backup"
VERSION = 1
FILES = ("youtube_settings_r79.json", "youtube_subs_r79.json",
         "youtube_account_r79.json", "youtube_account_subs_r79.json")
SKIP_KEYS = {"youtube_settings_r79.json": ("api_key_bad_until", "api_key_bad_reason"),
             "youtube_account_r79.json": ("access_token", "expires_at")}
DEBOUNCE_SEC = 2.0
# R83c: this install has adopted the backup file (restored it, wrote it, or
# already holds the same API key / account).  Until then the automatic backup
# must not overwrite a previous install's backup (fresh install -> the first
# settings change used to replace it with an almost empty one).
LINK_NAME = "youtube_backup_link_r83.json"
_S = "youtube_settings_r79.json"
_A = "youtube_account_r79.json"

_timer = [None]
_lock = threading.Lock()


def _log(msg, level=xbmc.LOGINFO):
    yt.log("BACKUP " + msg, level)


def _candidate_dirs():
    out = []
    if yt._is_android():
        for base in ("/storage/emulated/0/Download", "/sdcard/Download"):
            out.append(os.path.join(base, "PKM"))
    else:
        home = os.path.expanduser("~")
        for sub in ("Downloads", "Download"):
            if os.path.isdir(os.path.join(home, sub)):
                out.append(os.path.join(home, sub, "PKM"))
    try:
        import xbmcvfs
        out.append(xbmcvfs.translatePath("special://home/pkm_backup"))
    except Exception:
        pass
    return out


def backup_dir(create=False):
    for d in _candidate_dirs():
        try:
            if os.path.isdir(d) and os.access(d, os.W_OK):
                return d
            if create:
                os.makedirs(d)
                return d
        except Exception:
            continue
    return ""


def planned_path():
    """Where the next backup will be written (for display)."""
    d = backup_dir() or (_candidate_dirs() or [""])[0]
    return os.path.join(d, BACKUP_NAME) if d else ""


def backup_path():
    for d in _candidate_dirs():
        p = os.path.join(d, BACKUP_NAME)
        try:
            if os.path.exists(p):
                return p
        except Exception:
            continue
    d = backup_dir()
    return os.path.join(d, BACKUP_NAME) if d else ""


def collect():
    data = {}
    for name in FILES:
        val = yt._load_json(name, None)
        if val is None:
            continue
        if isinstance(val, dict):
            val = dict((k, v) for k, v in val.items() if k not in SKIP_KEYS.get(name, ()))
        data[name] = val
    try:
        import xbmcaddon
        k = (xbmcaddon.Addon("plugin.video.km").getSetting("pkm_subdl_api_key") or "").strip()
        if k:
            data["pkm_subdl_r332"] = {"api_key": k}
    except Exception:
        pass
    return {"format": FORMAT, "version": VERSION, "created": int(time.time()),
            "created_text": time.strftime("%Y-%m-%d %H:%M"), "data": data}


def is_meaningful(payload):
    d = (payload or {}).get("data") or {}
    s = d.get("youtube_settings_r79.json") or {}
    a = d.get("youtube_account_r79.json") or {}
    return bool(s.get("api_key") or a.get("client_id") or d.get("youtube_subs_r79.json")
                or (d.get("pkm_subdl_r332") or {}).get("api_key"))


def _data_digest(d):
    import hashlib
    return hashlib.sha1(json.dumps(d or {}, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _same_lineage(bk, cur):
    bd = (bk or {}).get("data") or {}
    cd = (cur or {}).get("data") or {}
    bkey = (bd.get(_S) or {}).get("api_key")
    if bkey and bkey == (cd.get(_S) or {}).get("api_key"):
        return True
    ba = bd.get(_A) or {}
    ca = cd.get(_A) or {}
    for k in ("refresh_token", "client_id"):
        if ba.get(k) and ba.get(k) == ca.get(k):
            return True
    return _data_digest(bd) == _data_digest(cd)


def mark_linked(reason=""):
    try:
        yt._save_json_raw(LINK_NAME, {"at": int(time.time()), "reason": reason})
    except Exception:
        pass


def is_linked():
    """False only on an install that has not restored / adopted an existing,
    meaningful backup yet (= restore pending, automatic backup paused)."""
    try:
        if yt._load_json(LINK_NAME, None):
            return True
        bk = read()
        if not bk or not is_meaningful(bk):
            return True
        if _same_lineage(bk, collect()):
            mark_linked("same_lineage")
            return True
        return False
    except Exception:
        return True


def write_now(reason=""):
    if reason not in ("manual", "after_restore", "fresh_start") and not is_linked():
        _log("SKIP_UNLINKED_R83C reason=%s (previous backup not restored yet)" % reason)
        return False, "이전 백업을 아직 복원하지 않아 자동 백업을 멈췄습니다"
    payload = collect()
    if not is_meaningful(payload):
        return False, "백업할 설정이 없습니다"
    d = backup_dir(create=True)
    if not d:
        _log("NO_DIR", xbmc.LOGWARNING)
        return False, "백업 폴더를 만들 수 없습니다"
    path = os.path.join(d, BACKUP_NAME)
    try:
        with _lock:
            if os.path.exists(path):
                try:
                    os.replace(path, path.replace(".json", ".prev.json"))
                except Exception:
                    pass
            tmp = path + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(payload, fh, ensure_ascii=False, indent=1)
                os.replace(tmp, path)
            except Exception:
                # R332: a file made by another app/user cannot be replaced (Android scoped
                # storage); write it in place instead so the backup is still kept.
                with open(path, "w", encoding="utf-8") as fh:
                    json.dump(payload, fh, ensure_ascii=False, indent=1)
                try:
                    os.remove(tmp)
                except Exception:
                    pass
        _log("WRITE ok reason=%s path=%s" % (reason, path))
        mark_linked(reason or "write")
        return True, path
    except Exception:
        _log("WRITE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False, "백업 파일을 쓰지 못했습니다"


def schedule(reason=""):
    """Debounced auto backup after a settings change."""
    try:
        if _timer[0] is not None:
            _timer[0].cancel()
        t = threading.Timer(DEBOUNCE_SEC, lambda: write_now(reason or "auto"))
        t.daemon = True
        _timer[0] = t
        t.start()
    except Exception:
        pass


def parse(text):
    try:
        payload = json.loads(text)
    except Exception:
        return None, "백업 파일 형식이 아닙니다"
    if not isinstance(payload, dict) or payload.get("format") != FORMAT or not isinstance(payload.get("data"), dict):
        return None, "PlexKM 유튜브 백업 파일이 아닙니다"
    return payload, ""


def read():
    path = backup_path()
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            payload, err = parse(fh.read())
        return payload
    except Exception:
        return None


def summary(payload):
    if not payload:
        return ""
    d = payload.get("data") or {}
    s = d.get("youtube_settings_r79.json") or {}
    a = d.get("youtube_account_r79.json") or {}
    parts = []
    if s.get("api_key"):
        parts.append("API 키")
    if a.get("refresh_token"):
        parts.append("계정 로그인%s" % ((" (%s)" % a.get("name")) if a.get("name") else ""))
    elif a.get("client_id"):
        parts.append("OAuth 클라이언트")
    if (d.get("pkm_subdl_r332") or {}).get("api_key"):
        parts.append("SubDL 키")
    n = len(d.get("youtube_subs_r79.json") or [])
    if n:
        parts.append("PlexKM 구독 %d" % n)
    m = len(d.get("youtube_account_subs_r79.json") or [])
    if m:
        parts.append("계정 구독 %d" % m)
    return " · ".join(parts) or "빈 백업"


def restore(payload):
    """Write the backed-up files back.  -> (ok, message)."""
    d = (payload or {}).get("data") or {}
    if not d:
        return False, "복원할 내용이 없습니다"
    try:
        yt._RESTORING[0] = True
        for name in FILES:
            if name in d:
                yt._save_json(name, d[name])
        yt.cache_clear()
        sk = ((d.get("pkm_subdl_r332") or {}).get("api_key") or "").strip()
        if sk:
            try:
                import xbmcaddon
                xbmcaddon.Addon("plugin.video.km").setSetting("pkm_subdl_api_key", sk)
            except Exception:
                pass
    finally:
        yt._RESTORING[0] = False
    _log("RESTORED %s" % summary(payload))
    mark_linked("restore")
    write_now("after_restore")
    return True, "복원했습니다 · %s" % summary(payload)


def auto_restore_if_missing():
    """Fresh profile (after a reset / data clear / reinstall) with a backup outside Kodi:
    bring the keys back by themselves.  Never overwrites a key that already exists."""
    try:
        cur = yt._load_json("youtube_settings_r79.json", None) or {}
        acc = yt._load_json("youtube_account_r79.json", None) or {}
        if (cur.get("api_key") or "").strip() or acc.get("client_id"):
            _log("AUTO_RESTORE_R332 skip=key_exists")
            return False
        payload = read()
        if not payload:
            bp = backup_path()
            _log("AUTO_RESTORE_R332 skip=no_backup path=%s" % bp)
            try:
                if bp and os.path.exists(bp):
                    # The file is there but Kodi may not read it: Android reset the
                    # "all files access" permission together with the app data.
                    with open(bp, "rb") as fh:
                        fh.read(1)
            except Exception:
                try:
                    from resources.lib import pkm_notify
                    pkm_notify.pkm_show_notice("PlexKM", "키 백업을 불러오려면 Kodi에", "모든 파일 접근을 허용해주세요", ms=8000)
                    _log("AUTO_RESTORE_R332 permission_notice_shown")
                except Exception:
                    pass
            return False
        if not is_meaningful(payload):
            _log("AUTO_RESTORE_R332 skip=empty_backup")
            return False
        ok, msg = restore(payload)
        _log("AUTO_RESTORE_R332 ok=%s %s" % (1 if ok else 0, msg))
        return bool(ok)
    except Exception as exc:
        _log("AUTO_RESTORE_R332 failed %s %s" % (exc, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        return False
