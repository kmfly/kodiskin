# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import os
import sys
import traceback
import xbmc

ADDON_ID = "plugin.video.km"


def _ensure_addon_root():
    """RunScript(lib/file.py) does not guarantee the addon root is on sys.path."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        addon_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
        if addon_root and addon_root not in sys.path:
            sys.path.insert(0, addon_root)
        return addon_root
    except Exception:
        return ""


def main():
    try:
        _ensure_addon_root()
        page = "root"
        for arg in sys.argv[1:]:
            if str(arg).startswith("page="):
                page = str(arg).split("=", 1)[1] or "root"
        try:
            from resources.lib import pkm_osd_menu
            if pkm_osd_menu.open_osd_menu(page):
                return
        except Exception:
            xbmc.log("[%s][osd_menu] FALLBACK_TO_R89 %s" % (ADDON_ID, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
        from resources.lib import pkm_osd_settings
        pkm_osd_settings.open_osd_settings()
    except Exception:
        xbmc.log("[%s][osd_settings] ENTRY_FAILED %s" % (ADDON_ID, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)


if __name__ == "__main__":
    main()
