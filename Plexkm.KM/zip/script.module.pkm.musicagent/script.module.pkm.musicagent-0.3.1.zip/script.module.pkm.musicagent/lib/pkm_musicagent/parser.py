# -*- coding: utf-8 -*-
"""PlexKM 뮤직비디오 에이전트 (1단계: 이름 읽기와 색인).

폴더/파일 이름에서 항목(뮤직비디오, 음악방송 무대, 콘서트, 공연 DVD)을 만들고,
폴더 안 info.json(TMDb)과 show.yaml(제목·포스터)이 있으면 그대로 읽는다.
화면과 외부 조회는 이 색인 위에서 동작한다. Kodi 없이도 import 된다(시험용).
"""
import json
import re
import unicodedata

VIDEO_EXT = ("mp4", "mkv", "avi", "ts", "tp", "webm", "mov", "m2ts", "wmv", "mpg", "mpeg", "iso")
DISC_DIRS = ("VIDEO_TS", "BDMV")
EXTRA_DIRS = ("featurettes", "behind the scenes", "interview", "extras", "trailers", "jacket_p")

KIND_MV = "mv"
KIND_BROADCAST = "broadcast"
KIND_CONCERT = "concert"
KIND_DISC = "disc"
KIND_OTHER = "other"

_NOISE = [
    r"\(\s*\d{3,4}p\s*\)", r"\bofficial\s+music\s+video\b", r"\bmusic\s+video\b",
    r"\bofficial\s+m/?v\b", r"\bM_V\b", r"\bMV\b", r"\[MV\]", r"\bofficial\b",
]
_VERSION_TAGS = (
    ("live", r"\(\s*live[^)]*\)|\.\(live\)|\blive\b"),
    ("audio", r"\(\s*audio\s*\)"),
    ("remaster", r"\([^)]*remaster[^)]*\)"),
    ("hq", r"\(\s*hq\s*\)"),
    ("alt", r"\([^)]*(alternate|alt\.?|single|e\.p\.)\s*version[^)]*\)"),
)


def norm_key(text):
    """비교용 키: 소문자, 기호·공백 제거."""
    t = unicodedata.normalize("NFKC", str(text or "")).lower()
    return re.sub(r"[^0-9a-z가-힣ぁ-んァ-ン一-龥]+", "", t)


def is_video(name):
    return name.rsplit(".", 1)[-1].lower() in VIDEO_EXT if "." in name else False


def strip_ext(name):
    return re.sub(r"\.[A-Za-z0-9]{2,4}$", "", name)


# ----------------------------------------------------------------- 폴더 종류
def folder_kind(top_name):
    n = top_name.lower()
    if "음악방송" in n:
        return KIND_BROADCAST
    if "공연" in n and "dvd" in n:
        return KIND_DISC
    if "콘서트" in n:
        return KIND_CONCERT
    if re.search(r"(^|\W)mv(\W|$)|뮤비|뮤직비디오", n):
        return KIND_MV
    return KIND_OTHER


def suggest_kind(folder_name):
    """폴더 이름 키워드로 종류를 '추천'만 한다(설치 도우미의 기본 선택값). 확정은 사용자가 한다."""
    return folder_kind(folder_name)


def make_kind_resolver(kinds=None, default_kind=None):
    """kinds: {'소스 안 상대 폴더 경로': 종류}. 사용자가 지정한 값이 우선, 가장 긴 앞부분 일치.
    지정이 없는 경로만 폴더 이름 키워드 추천값을 쓴다. 빈 문자열('')은 소스 전체."""
    pairs = sorted(((k.strip("/"), v) for k, v in (kinds or {}).items()), key=lambda kv: -len(kv[0]))

    def resolve(parts):
        rel = "/".join(parts[:-1])
        for k, v in pairs:
            if k == "" or rel == k or rel.startswith(k + "/"):
                return v
        k = folder_kind(parts[0])
        return default_kind if (k == KIND_OTHER and default_kind) else k
    return resolve


# ------------------------------------------------------------------ .nfo
def read_nfo(text):
    """Kodi <musicvideo> .nfo -> dict(artist, title, album, year, plot, genre). 없으면 {}"""
    if not text or "<musicvideo" not in text:
        return {}

    def tag(n):
        m = re.search(r"<%s>(.*?)</%s>" % (n, n), text, flags=re.S | re.I)
        return re.sub(r"\s+", " ", m.group(1)).strip() if m else ""
    year = tag("year") or tag("premiered")[:4]
    out = {"artist": tag("artist"), "title": tag("title"), "album": tag("album"),
           "year": int(year) if year.isdigit() else 0, "plot": tag("plot"),
           "genre": [g.strip() for g in re.findall(r"<genre>(.*?)</genre>", text, flags=re.S | re.I) if g.strip()]}
    return {k: v for k, v in out.items() if v}


# ------------------------------------------------------- 이름 규칙 템플릿
def compile_template(tpl):
    """'{artist} - {title}' 같은 규칙을 정규식으로. {artist}/{title}/{year}/{album} 사용, 나머지는 글자 그대로."""
    if not tpl or "{" not in tpl:
        return None
    out, pos = "", 0
    for m in re.finditer(r"\{(artist|title|year|album)\}", tpl):
        out += re.escape(tpl[pos:m.start()]) + "(?P<%s>.+?)" % m.group(1)
        pos = m.end()
    out += re.escape(tpl[pos:])
    try:
        return re.compile("^" + out.replace(r"\ ", r"\s*") + "$")
    except re.error:
        return None


def parse_with_template(rx, name):
    m = rx.match(strip_ext(name).strip()) if rx else None
    if not m or not m.groupdict().get("title"):
        return None
    d = {k: v.strip() for k, v in m.groupdict().items() if v}
    if "year" in d:
        d["year"] = int(d["year"]) if d["year"].isdigit() else 0
    return d


_IMG_EXT = ("jpg", "jpeg", "png", "webp")
_IMG_ROLE = (("poster", "poster"), ("thumb", "thumb"), ("fanart", "fanart"), ("landscape", "fanart"))


def find_images(video_path, pathset):
    """같은 이름 + -poster/-thumb/-fanart 이미지, 또는 같은 이름 .jpg 를 찾는다. -> {role: 경로}"""
    base = strip_ext(video_path)
    found = {}
    for ext in _IMG_EXT:
        if base + "." + ext in pathset:
            found.setdefault("thumb", base + "." + ext)
        for suf, role in _IMG_ROLE:
            if base + "-" + suf + "." + ext in pathset:
                found[role] = base + "-" + suf + "." + ext
    return found


# ------------------------------------------------------------- 뮤직비디오 이름
def _clean_mv(name):
    n = strip_ext(name)
    tags = []
    for tag, pat in _VERSION_TAGS:
        if re.search(pat, n, flags=re.I):
            tags.append(tag)
    for p in _NOISE:
        n = re.sub(p, " ", n, flags=re.I)
    # '[EXID | (이엑스아이디)] 곡' -> 'EXID(이엑스아이디) - 곡'
    m = re.match(r"^\s*\[\s*([^\]|]+?)\s*\|\s*([^\]]*?)\s*\]\s*(.+)$", n)
    if m:
        n = "%s%s - %s" % (m.group(1), re.sub(r"^\(|\)$", "", m.group(2)).join("()") if m.group(2).strip("() ") else "", m.group(3))
    n = re.sub(r"\[\s*\]", " ", n)                           # 빈 대괄호
    n = re.sub(r"[\"\u201c\u201d\u2018\u2019]", " ", n)           # 제목을 감싼 따옴표
    n = re.sub(r"\(\s*(?:HD|FHD|UHD|4K)?\s*\)", " ", n, flags=re.I)  # '(HD )', '( )'
    n = re.sub(r"(?<!\S)(?:멀티캠|직캠|풀캠|뮤직비디오|뮤비)(?!\S)", " ", n)
    return re.sub(r"\s+", " ", n).strip(" -–_"), tags


def _split_artist_title(n):
    for sep in (" - ", " – ", "- ", " -"):
        if sep in n:
            a, b = n.split(sep, 1)
            if a.strip() and b.strip():
                return a.strip(), b.strip()
    m = re.match(r"^(.+?\))\s*_\s*(.+)$", n)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    m = re.match(r"^(.+?)\s+_\s+(.+)$", n)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    m = re.match(r"^(.+?[가-힣])_(.+)$", n)       # 'SISTAR 씨스타_SHAKE IT'
    if m and " " in m.group(1):
        return m.group(1).strip(), m.group(2).strip()
    m = re.match(r"^(.+?)-(.+)$", n)   # Fire Inc & The Sorels-Tonight ...
    if m and re.search(r"[A-Za-z가-힣]", m.group(1)) and len(m.group(1)) > 2 and (" " in n or m.group(1).endswith(")")):
        return m.group(1).strip(), m.group(2).strip()
    return None


def parse_mv_name(name, folder_artist="", artists=None):
    """-> dict(artist, title, tags, ok, how)"""
    n, tags = _clean_mv(name)
    r = _split_artist_title(n)
    if r:
        return {"artist": r[0], "title": r[1], "tags": tags, "ok": True, "how": "split"}
    if artists:
        hit = match_artist_prefix(n, artists)
        if hit:
            rest = n[len(hit):].strip(" -–_")
            if rest:
                return {"artist": hit, "title": rest, "tags": tags, "ok": True, "how": "known_artist"}
    if folder_artist:
        return {"artist": folder_artist, "title": n, "tags": tags, "ok": True, "how": "folder"}
    return {"artist": "", "title": n, "tags": tags, "ok": False, "how": "none"}


def match_artist_prefix(text, artists):
    """artists: 이름 집합. 가장 긴 앞부분 일치(대소문자·기호 무시) -> 원문 앞부분."""
    best = ""
    tk = norm_key(text)
    for a in artists:
        ak = norm_key(a)
        if len(ak) >= 2 and tk.startswith(ak) and len(ak) > len(norm_key(best)):
            # 원문에서 같은 길이만큼 잘라 낸다
            cut, acc = 0, ""
            for i, ch in enumerate(text):
                if norm_key(ch):
                    acc += norm_key(ch)
                cut = i + 1
                if len(acc) >= len(ak):
                    break
            cand = text[:cut].rstrip()
            if norm_key(cand) == ak:
                best = cand
    return best


# --------------------------------------------------------------- 음악방송 이름
_TECH = re.compile(
    r"^(\d{3,4}[pi]|\d{3,4}x\d{3,4}|\d+fps|[hx]\.?26[45]|hevc|avc|av1|vp9|aac\d*(\.\d)?|ac3|eac3|e-ac-3|dts(-hd)?(\.?ma)?|flac|mp3|ddp?\d(\.\d)?|"
    r"web-?dl|webrip|web|blu-?ray|bdrip|brrip|hdtv|remux|dvdrip|uhd|hdr\d*|sdr|4k|2160p|10bit|multi|mvc)(-[^\s.]+)?$",
    re.I)
# 언어별 '무대가 아닌 영상' 단어. 필요하면 설정에서 늘린다.
CLIP_WORDS = {
    "ko": ("인터뷰", "엔딩", "오프닝", "토크", "수상", "컴백", "스페셜", "후보"),
    "en": ("interview", "ending", "opening", "vcr", "behind", "talk", "special", "teaser"),
    "ja": ("インタビュー", "エンディング", "オープニング"),
}
_CLIP_WORDS = tuple(w for ws in CLIP_WORDS.values() for w in ws) + ("vcr", "cut")


def _is_tech(tok):
    return bool(_TECH.match(tok.strip()))


def strip_tech_tail(tokens):
    """뒤쪽의 해상도·코덱·소스 표기와 마지막 릴리스 그룹 이름을 떼어 낸다."""
    t = list(tokens)
    changed = True
    while t and changed:
        changed = False
        if _is_tech(t[-1]):
            t.pop(); changed = True
        elif len(t) > 1 and " " not in t[-1] and len(t[-1]) <= 14 and _is_tech(t[-2]) and re.match(r"^[A-Za-z0-9가-힣_\-]+$", t[-1]):
            t.pop(); changed = True
    return t


_DATE_RES = (
    (re.compile(r"(?<!\d)(\d{4})[-./](\d{2})[-./](\d{2})(?!\d)"), lambda g: "%s-%s-%s" % g),
    (re.compile(r"(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)"), lambda g: "%s-%s-%s" % g),
    (re.compile(r"(?<!\d)(\d{2})(\d{2})(\d{2})(?!\d)"), lambda g: "20%s-%s-%s" % g),
)


def find_date(text):
    """이름 속 날짜(YYYY-MM-DD, YYYYMMDD, YYMMDD) -> 'YYYY-MM-DD' 또는 ''."""
    for rx, fmt in _DATE_RES:
        m = rx.search(text or "")
        if m:
            mo, dd = int(m.group(2)), int(m.group(3))
            if 1 <= mo <= 12 and 1 <= dd <= 31:
                return fmt(m.groups())
    return ""


def _tokens(name):
    """-> (style, tokens). 점으로 구분된 이름은 조각 단위, 아니면 공백 단위."""
    n = strip_ext(name)
    if re.match(r"^\s*\d{6,8}\s*\.", n) or n.count(".") >= 3:
        segs = [x.strip() for x in n.split(".") if x.strip()]
        return "dot", strip_tech_tail(segs)
    return "space", strip_tech_tail([x for x in n.split() if x])


def parse_broadcast_group(folder_name, file_names):
    """같은 폴더(한 회차)의 파일들을 함께 읽는다. 파일들이 공통으로 가진 앞부분(날짜·방송사·프로그램)을
    떼고 남은 부분을 '무대 이름'으로 본다. 프로그램 이름을 미리 알 필요가 없다."""
    parsed = {fn: _tokens(fn) for fn in file_names}
    prefix = {}
    for style in ("dot", "space"):
        group = [t for (st, t) in parsed.values() if st == style]
        n = 0
        if len(group) >= 2:
            while all(len(t) > n + 1 for t in group) and len({norm_key(t[n]) for t in group}) == 1:
                n += 1
        prefix[style] = n
    out = {}
    fdate = find_date(folder_name)
    fm = re.match(r"^\s*\d{6,8}\s+(\S+)\s+(.+)$", folder_name)
    for fn, (style, toks) in parsed.items():
        n = prefix[style]
        if n == 0:   # 공통 앞부분을 알 수 없을 때: 날짜 조각까지만 뗀다
            while n < len(toks) - 1 and (find_date(toks[n]) or n == 0 and not re.search(r"[가-힣A-Za-z]", toks[n])):
                n += 1
            if style == "dot":
                n = max(n, len(toks) - 1)
        clip = " ".join(toks[n:]).strip()
        item = {"date": find_date(fn) or fdate, "broadcaster": fm.group(1) if fm else "", "show": fm.group(2) if fm else "",
                "artist": "", "title": clip, "clip": clip, "ok": False}
        for sep in (" - ", " – "):
            if sep in clip:
                x, y = clip.split(sep, 1)
                item["artist"], item["title"], item["ok"] = x.strip(), y.strip(), True
                break
        item["is_clip"] = any(w in clip.lower() for w in _CLIP_WORDS)
        out[fn] = item
    return out


def parse_broadcast(folder_name, file_name):
    return parse_broadcast_group(folder_name, [file_name])[file_name]



_GENERIC_HEAD = ("전 출연진", "전출연진", "오프닝", "엔딩", "vcr", "1위", "후보", "수상", "인터뷰", "스페셜", "토크")


def vote_artists(strings, min_count=2, ratio=0.8):
    """공백 없이 이어진 '아티스트 곡' 문자열들에서, 여러 곡이 공유하는 앞부분을 아티스트로 본다.
    -> {문자열: 아티스트}"""
    toks = {s: s.split() for s in strings}
    cnt = {}
    for t in toks.values():
        for i in range(1, min(4, len(t)) + 1):
            k = norm_key(" ".join(t[:i]))
            cnt[k] = cnt.get(k, 0) + 1
    out = {}
    for s_, t in toks.items():
        if len(t) < 2:
            continue
        first = cnt.get(norm_key(t[0]), 0)
        best = 0
        for i in range(1, min(4, len(t) - 1) + 1):
            c = cnt.get(norm_key(" ".join(t[:i])), 0)
            if c >= min_count and c >= ratio * first:
                best = i
        if best:
            name = " ".join(t[:best])
            if len(name) < 2 or name.lower() in _GENERIC_HEAD or any(name.lower().startswith(g) for g in _GENERIC_HEAD):
                continue
            out[s_] = name
    return out


def _yymmdd(s):
    yy, mm, dd = s[:2], s[2:4], s[4:6]
    return "20%s-%s-%s" % (yy, mm, dd)


def split_known_artist(clip, artists):
    hit = match_artist_prefix(clip, artists)
    if hit:
        rest = clip[len(hit):].strip(" -–_.")
        if rest:
            return hit, rest
    return "", clip


# ------------------------------------------------------------------ 폴더 이름
def parse_folder_title(name):
    """콘서트/공연 폴더: 제목, 연도, TMDb 번호, 태그."""
    tmdb = ""
    m = re.search(r"\{tmdb-(\d+)\}", name, flags=re.I)
    if m:
        tmdb = m.group(1)
    else:
        m = re.search(r"\{MT(\d+)\}", name)
        if m:
            tmdb = m.group(1)
    t = re.sub(r"\{[^}]*\}", " ", name)
    year = ""
    m = re.search(r"\((19\d{2}|20\d{2})\)", t)
    if m:
        year = m.group(1)
    tags = re.findall(r"\[([^\]]+)\]", t)
    t = re.sub(r"\[[^\]]*\]", " ", t)
    t = re.sub(r"\((19\d{2}|20\d{2})\)", " ", t)
    return {"title": re.sub(r"\s+", " ", t).strip(), "year": year, "tmdb_id": tmdb, "tags": tags}


def read_info_json(text):
    """info.json(TMDb) -> 화면용 필드. 깨진 파일이면 {}."""
    try:
        d = json.loads(text)
    except Exception:
        return {}
    ids = {k: v for k, v in (d.get("code_list") or []) if v}
    posters = [a.get("value") for a in d.get("art") or [] if a.get("aspect") == "poster" and a.get("value")]
    fan = [a.get("value") for a in d.get("art") or [] if a.get("aspect") == "landscape" and a.get("value")]
    return {
        "title": d.get("title") or "", "originaltitle": d.get("originaltitle") or "",
        "year": str(d.get("year") or ""), "plot": d.get("plot") or "",
        "genre": list(d.get("genre") or []), "runtime": d.get("runtime") or 0,
        "premiered": d.get("premiered") or "", "tmdb_id": str(ids.get("tmdb_id") or ""),
        "poster": d.get("main_poster") or (posters[0] if posters else ""),
        "fanart": d.get("main_art") or (fan[0] if fan else ""),
        "actors": [a.get("name") for a in d.get("actor") or [] if a.get("name")],
    }


def read_show_yaml(text):
    """show.yaml(title, posters 등 한 줄짜리 key: value)만 읽는다."""
    out = {}
    for line in str(text or "").splitlines():
        m = re.match(r'^\s*([A-Za-z_]+)\s*:\s*"?(.*?)"?\s*$', line)
        if m:
            out[m.group(1).lower()] = m.group(2)
    return {"title": out.get("title", ""), "poster": out.get("posters") or out.get("poster", ""),
            "fanart": out.get("fanart") or out.get("background", "")}


# ------------------------------------------------------------------ 색인 만들기
def build_index(paths, texts=None, kinds=None, template=None, default_kind=None):
    """paths: 루트 기준 상대경로 목록('MV/BTS/Dope.mp4' ...). texts: {경로: 내용}(info.json, show.yaml).
    kinds: {폴더 경로: 종류} 사용자 지정(없으면 이름 키워드 추천). template: '{artist} - {title}' 같은 이름 규칙.
    같은 이름 .nfo(texts에 있으면)와 같은 이름 이미지(paths에 있으면)를 우선 사용한다.
    -> {'items': [...], 'stats': {...}}"""
    texts = texts or {}
    kind_of = make_kind_resolver(kinds, default_kind)
    rx = compile_template(template)
    paths = [p.strip("/") for p in paths if p.strip()]
    pathset = set(paths)
    folders_with_show = {}
    for p, t in texts.items():
        if p.endswith("show.yaml"):
            folders_with_show[p.rsplit("/", 1)[0]] = read_show_yaml(t)

    # 1차: 아티스트 이름 모으기(곡 이름 분리에 성공한 뮤직비디오에서)
    artists = set()
    for p in paths:
        parts = p.split("/")
        if kind_of(parts) == KIND_MV and is_video(parts[-1]):
            r = _split_artist_title(_clean_mv(parts[-1])[0])
            if r and 1 < len(r[0]) <= 40:
                artists.add(r[0])
    items = []
    seen_concert = set()

    for p in paths:
        parts = p.split("/")
        kind = kind_of(parts)
        name = parts[-1]
        if not is_video(name):
            continue
        parent = "/".join(parts[:-1])
        if kind == KIND_MV:
            fa = ""
            sy = folders_with_show.get(parent)
            if sy and sy.get("title"):
                fa = sy["title"]
            elif len(parts) > 2 and not re.search(r"MV|뮤비|모음", parts[-2], flags=re.I):
                fa = parts[-2]
            nfo = read_nfo(texts.get(strip_ext(p) + ".nfo", ""))
            tp = parse_with_template(rx, name)
            if nfo.get("artist") and nfo.get("title"):
                r = {"artist": nfo["artist"], "title": nfo["title"], "tags": _clean_mv(name)[1], "ok": True, "how": "nfo"}
            elif tp and tp.get("artist"):
                r = {"artist": tp["artist"], "title": tp["title"], "tags": _clean_mv(name)[1], "ok": True, "how": "template"}
            else:
                r = parse_mv_name(name, fa, artists)
            key = norm_key(r["artist"]) + "|" + norm_key(r["title"])
            it = {"kind": KIND_MV, "path": p, "artist": r["artist"], "title": r["title"], "tags": r["tags"],
                  "ok": r["ok"], "how": r["how"], "key": key, "poster": (sy or {}).get("poster", "")}
            for k in ("year", "album", "plot", "genre"):
                v = nfo.get(k) or ((tp or {}).get(k) if r["how"] == "template" else None)
                if v:
                    it[k] = v
            imgs = find_images(p, pathset)
            if imgs:
                it["images"] = imgs
            items.append(it)
        elif kind == KIND_BROADCAST and len(parts) >= 3:
            continue
        elif kind in (KIND_CONCERT, KIND_DISC, KIND_OTHER):
            # 콘서트: 영상이 들어 있는 가장 가까운 '제목 폴더'를 한 항목으로 본다
            if any(d.lower() in EXTRA_DIRS for d in parts[1:-1]):
                continue
            title_idx = _title_folder_index(parts, kind)
            fpath = "/".join(parts[:title_idx + 1])
            if fpath in seen_concert:
                for it in items:
                    if it.get("folder") == fpath:
                        it["files"] += 1
                continue
            seen_concert.add(fpath)
            ft = parse_folder_title(parts[title_idx])
            info = read_info_json(texts.get(fpath + "/info.json", ""))
            items.append({"kind": kind, "folder": fpath, "path": p, "files": 1,
                          "title": info.get("title") or ft["title"], "year": info.get("year") or ft["year"],
                          "tmdb_id": info.get("tmdb_id") or ft["tmdb_id"], "has_info": bool(info),
                          "poster": info.get("poster", ""), "fanart": info.get("fanart", ""),
                          "plot": info.get("plot", ""), "genre": info.get("genre", []),
                          "runtime": info.get("runtime", 0), "ok": True})
    groups = {}
    for p in paths:
        parts = p.split("/")
        if kind_of(parts) == KIND_BROADCAST and len(parts) >= 3 and is_video(parts[-1]):
            groups.setdefault("/".join(parts[:-1]), []).append(parts[-1])
    for folder, names in groups.items():
        res = parse_broadcast_group(folder.split("/")[-1], names)
        for nm in names:
            b = res[nm]
            items.append({"kind": KIND_BROADCAST, "path": folder + "/" + nm, "date": b["date"],
                          "broadcaster": b["broadcaster"], "show": b["show"], "artist": b["artist"],
                          "title": b["title"], "clip": bool(b.get("is_clip")), "ok": b["ok"] or bool(b["title"])})
    _vote_pass(items)
    return {"items": items, "stats": _stats(items)}


def _vote_pass(items):
    """아티스트-곡 구분 기호가 없는 이름들을 여러 곡이 공유하는 앞부분으로 나눈다."""
    bc = [it for it in items if it["kind"] == KIND_BROADCAST and not it["artist"]]
    v = vote_artists(list({it["title"] for it in bc}), 2)
    for it in bc:
        a = v.get(it["title"])
        if a:
            rest = it["title"][len(a):].strip(" -–_.+")
            it["artist"], it["title"] = a, rest or it["title"]
        if not it["artist"] and not it.get("clip"):
            tk = it["title"].split()
            if len(tk) >= 2 and not re.search(r"[+]", tk[0]):
                it["artist"], it["title"], it["artist_guess"] = tk[0], " ".join(tk[1:]), True
        it["ok"] = bool(it["artist"] or it.get("clip") or it["title"])
    mv = [it for it in items if it["kind"] == KIND_MV and not it["ok"]]
    v = vote_artists(list({it["title"] for it in mv}), 3)
    for it in mv:
        a = v.get(it["title"])
        if a:
            rest = re.sub(r"^[\s\-–_]+", "", it["title"][len(a):])
            if rest:
                it["artist"], it["title"], it["ok"], it["how"] = a, rest, True, "vote"
                it["key"] = norm_key(it["artist"]) + "|" + norm_key(it["title"])


def _title_folder_index(parts, kind):
    """파일 경로에서 '작품 폴더' 위치. 콘서트/국내/제목/파일 -> 제목, 공연 DVD/DVD/제목/VIDEO_TS/x -> 제목."""
    top = parts[0]
    for i in range(1, len(parts) - 1):
        seg = parts[i]
        if seg in ("국내", "외국", "DVD", "Blu-ray", "ISO") or seg.upper() in DISC_DIRS:
            continue
        if seg.upper() in DISC_DIRS or seg.lower() in EXTRA_DIRS:
            return max(1, i - 1)
        return i
    return len(parts) - 2 if len(parts) > 2 else 0


def _stats(items):
    st = {}
    for it in items:
        k = it["kind"]
        s = st.setdefault(k, {"total": 0, "ok": 0})
        s["total"] += 1
        if it.get("ok"):
            s["ok"] += 1
    return st


def dedupe_mv(items):
    """같은 곡이 여러 폴더에 있으면 한 항목으로 묶는다(정규화한 아티스트+제목)."""
    groups = {}
    for it in items:
        if it["kind"] != KIND_MV or not it.get("ok"):
            continue
        groups.setdefault(it["key"], []).append(it)
    return {k: v for k, v in groups.items() if len(v) > 1}


# ----------------------------------------------- 음악 재생 연계용 이름 키
def _split_trailing_paren(text):
    """'(여자)아이들((G)I-DLE)' -> ('(여자)아이들', '(G)I-DLE'). 끝의 짝 맞는 괄호 하나만 떼어 낸다."""
    t = text.strip()
    if not t.endswith(")"):
        return t, ""
    depth = 0
    for i in range(len(t) - 1, -1, -1):
        if t[i] == ")":
            depth += 1
        elif t[i] == "(":
            depth -= 1
            if depth == 0:
                inner = t[i + 1:-1].strip()
                before = t[:i].strip()
                return (before, inner) if before and inner else (t, "")
    return t, ""


def name_variants(name):
    """'한글(English)' 형태는 둘 다 이름으로 본다."""
    out = []
    before, inner = _split_trailing_paren(name or "")
    for v in (name, before, inner):
        k = norm_key(v)
        if k and k not in out:
            out.append(k)
    return out


_TITLE_JUNK = (
    r"\(?\s*(feat|ft|featuring)\.?[^)]*\)?", r"\([^)]*(remaster|version|ver\.?|edit|mix|live|audio|hq|mv|m/v)[^)]*\)",
    r"\[[^\]]*\]", r"\bm/?v\b",
)


def title_variants(title):
    t = title or ""
    core = t
    for p in _TITLE_JUNK:
        core = re.sub(p, " ", core, flags=re.I)
    out = []
    for v in [t, core] + list(_split_trailing_paren(core)):
        k = norm_key(v)
        if k and k not in out:
            out.append(k)
    return out


def match_keys(artist, title):
    """뮤직비디오 항목이나 음악 파일 태그 하나가 가질 수 있는 모든 '아티스트|제목' 키."""
    keys = []
    for a in name_variants(artist):
        for t in title_variants(title):
            k = a + "|" + t
            if k not in keys:
                keys.append(k)
    return keys


def link_index(items):
    """색인의 뮤직비디오 항목들에서 키 -> 항목 위치 목록을 만든다."""
    idx = {}
    for n, it in enumerate(items):
        if it.get("kind") in (KIND_MV, KIND_BROADCAST) and it.get("artist") and it.get("title"):
            for k in match_keys(it["artist"], it["title"]):
                idx.setdefault(k, []).append(n)
    return idx


def find_for_track(idx, items, artist, title):
    """음악 태그(artist, title)에 맞는 영상 항목들. 없으면 빈 목록."""
    seen, out = set(), []
    for k in match_keys(artist, title):
        for n in idx.get(k, []):
            if n not in seen:
                seen.add(n)
                out.append(items[n])
    return out
