# -*- coding: utf-8 -*-
"""Fail-open watchdog for PKM's one-shot WindowXML startup owner.

The *independent Kodi built-in timer* in the skin remains the absolute deadline.
This watchdog improves early failure handling; it cannot disable the skin timer.
"""
import threading
import time
import xbmc
import xbmcgui


def start_watchdog(monitor, home_thread, logger):
    def log(message, level=xbmc.LOGINFO):
        try:
            logger("[plugin.video.km] " + message, level)
        except Exception:
            pass

    def run():
        started = time.monotonic()
        modal_since = None
        log("STARTUP_GUARD_R2_ARM soft_timeout_s=75 native_deadline_s=90")
        while not monitor.abortRequested():
            if monitor.waitForAbort(0.40):
                return
            try:
                w = xbmcgui.Window(10000)
                if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    # Prevent a stale 90s alarm from overlaying a later reset.
                    for alarm in ("PKM_R2_RecoveryArm", "PKM_R2_ReleaseSplash", "PKM_R2_FocusNative", "PKM_R2_RecoveryFocus"):
                        try:
                            xbmc.executebuiltin("CancelAlarm(%s,silent)" % alarm)
                        except Exception:
                            pass
                    log("STARTUP_GUARD_R2_DISARM reason=home_ready elapsed_ms=%d" %
                        int((time.monotonic() - started) * 1000))
                    return
                if w.getProperty("PlexKM.Startup.RecoveryArmedR2") == "1":
                    log("STARTUP_GUARD_R2_DISARM reason=native_guard_triggered")
                    return
                if w.getProperty("PlexKM.FullResetInProgressV2150") == "1":
                    return
                try:
                    if xbmc.Player().isPlayingVideo():
                        return
                except Exception:
                    pass
                elapsed = time.monotonic() - started
                # A user-visible setup dialog is not an infinite *logo* screen.
                # It may stay open for interaction, but is NOT trusted forever:
                # the native timer still exposes escape controls after 90 sec.
                try:
                    modal = bool(xbmc.getCondVisibility("System.HasModalDialog") or
                                 xbmc.getCondVisibility("Window.IsActive(addonsettings)"))
                except Exception:
                    modal = False
                if modal:
                    if modal_since is None:
                        modal_since = time.monotonic()
                    if elapsed < 75.0:
                        continue
                else:
                    modal_since = None

                worker_dead = not home_thread.is_alive()
                if not (elapsed >= 75.0 or (worker_dead and elapsed >= 8.0)):
                    continue
                # R79: timeout and UI-worker exit are diagnostic, not proof of
                # corrupt data or a requirement to repeat initial setup.
                # Never arm the destructive-looking recovery surface for these.
                reason = "worker_ended" if worker_dead else "home_not_ready"
                log("STARTUP_GUARD_R79_DIAGNOSTIC reason=%s elapsed_ms=%d recovery=SUPPRESSED" %
                    (reason, int(elapsed * 1000)), xbmc.LOGWARNING)
                return
            except Exception as exc:
                log("STARTUP_GUARD_R2_POLL_FAIL %s" % exc, xbmc.LOGWARNING)

    thread = threading.Thread(target=run, name="PKMStartupWatchdogR2", daemon=True)
    thread.start()
    return thread


# ---------------------------------------------------------------------------
# R69: last-resort startup reveal.
#
# R79 cancelled the native 90 s skin alarm and made the R2 guard diagnostic
# only, so the only remaining escape from the logo was V2700 inside the Home
# WindowXML.  That watchdog cannot help when Home never reaches its gate
# (exception in onInit, owner thread stuck before doModal, dead worker).
# This service-side thread only clears the splash properties; it never resets
# libraries, deletes data or shows the recovery surface.
# ---------------------------------------------------------------------------
_R69_REVEAL_PROPS = (
    "PlexKM.SkinStartupSplash", "PlexKM.Home.StartupGateV1619",
    "PlexKM.Startup.SlowGuardTokenV2365", "PlexKM.Startup.SlowVisibleV2365",
    "PlexKM.Startup.SlowTextV2365", "PlexKM.Startup.SlowPhaseV2365",
    "PlexKM.Startup.SlowArmAtMsV2493", "PlexKM.Startup.PrepareTextV2492",
    "PlexKM.Startup.PreparePhaseV2492", "PlexKM.Startup.ProblemActiveV2535",
    "PlexKM.Startup.ProblemTextV2535", "PlexKM.Startup.FinalVisualTailV2516",
    "PlexKM.Startup.FinalVisualTailArmMsV2516", "PlexKM.Startup.R73HomeOverlay",
    "PlexKM.Startup.R73HomeOverlayProgress", "PlexKM.Startup.InitialPrepareActiveCumulative",
    "PlexKM.Startup.InitialPrepareMessageCumulative",
)
_R69_ACTIVE_LIMIT_S = 90.0        # counted only while nothing legitimate is running
_R69_PROGRESS_CAP_S = 25 * 60.0   # visible-progress phases may pause it, but not forever
_R69_UPDATE_PHASES = ("available", "prompt", "install_addon", "finalizing")


def start_last_resort_reveal_r69(monitor, logger):
    def log(message, level=xbmc.LOGINFO):
        try:
            logger("[plugin.video.km] " + message, level)
        except Exception:
            pass

    def paused_reason(w):
        try:
            if xbmc.Player().isPlayingVideo():
                return "playing"
        except Exception:
            pass
        try:
            if (xbmc.getCondVisibility("Window.IsActive(addonsettings)")
                    or xbmc.getCondVisibility("System.HasModalDialog")):
                return "modal"
        except Exception:
            pass
        if (w.getProperty("PlexKM.Startup.UpdatePhaseV2375") or "") in _R69_UPDATE_PHASES:
            return "update"
        if w.getProperty("PlexKM.Startup.InitialComposeR57") == "1":
            return "progress:initial_compose"
        if w.getProperty("PlexKM.Startup.R22IndexBuilding") == "1":
            return "progress:index"
        if w.getProperty("PlexKM.Startup.R59LocalSeed") == "1":
            return "progress:local_seed"
        if (w.getProperty("PlexKM.Startup.R20SyncSectionTitle") or "").strip():
            return "progress:library_sync"
        return ""

    def reveal(active_s, total_s, last_pause):
        w = xbmcgui.Window(10000)
        try:
            win_id = int(xbmcgui.getCurrentWindowId())
        except Exception:
            win_id = -1
        log("STARTUP_LAST_RESORT_REVEAL_R69 active_s=%d total_s=%d last_pause=%s window_id=%s "
            "home_opening=%s home_active=%s action=release_splash data_reset=0" % (
                int(active_s), int(total_s), last_pause or "-", win_id,
                w.getProperty("PlexKM.HomeWindowOpening") or "0",
                w.getProperty("PlexKM.HomeWindowActive") or "0"), xbmc.LOGERROR)
        targets = [w]
        if win_id == 13000:
            try:
                targets.append(xbmcgui.Window(13000))
            except Exception:
                pass
        for target in targets:
            for key in _R69_REVEAL_PROPS:
                try:
                    target.clearProperty(key)
                except Exception:
                    pass
            try:
                target.setProperty("PlexKM.Home.FullSceneComposedV1643", "1")
                target.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                target.setProperty("PlexKM.Home.StartupReadyV1619", "1")
            except Exception:
                pass
        try:
            w.setProperty("PlexKM.Home.StartupFallbackV1841", "last_resort_r69")
        except Exception:
            pass
        try:
            if win_id == 13000:
                xbmc.executebuiltin("SetFocus(9000)")
        except Exception:
            pass

    def run():
        started = time.monotonic()
        last = started
        active = 0.0
        last_pause = ""
        log("STARTUP_LAST_RESORT_ARM_R69 active_limit_s=%d progress_cap_s=%d" % (
            int(_R69_ACTIVE_LIMIT_S), int(_R69_PROGRESS_CAP_S)))
        while not monitor.abortRequested():
            if monitor.waitForAbort(0.5):
                return
            now = time.monotonic()
            step = now - last
            last = now
            try:
                w = xbmcgui.Window(10000)
                if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    log("STARTUP_LAST_RESORT_DISARM_R69 reason=home_ready total_ms=%d" % int((now - started) * 1000))
                    return
                if (w.getProperty("PlexKM.FullResetInProgressV2150") == "1"
                        or w.getProperty("PlexKM.FullResetInProgressV2149") == "1"):
                    log("STARTUP_LAST_RESORT_DISARM_R69 reason=full_reset")
                    return
                reason = paused_reason(w)
                if reason != last_pause:
                    if reason:
                        log("STARTUP_LAST_RESORT_PAUSE_R69 reason=%s active_s=%d" % (reason, int(active)))
                    last_pause = reason or last_pause
                total = now - started
                if not reason:
                    active += step
                elif reason.startswith("progress:") and total >= _R69_PROGRESS_CAP_S:
                    active = max(active, _R69_ACTIVE_LIMIT_S)
                if active >= _R69_ACTIVE_LIMIT_S:
                    reveal(active, total, reason or last_pause)
                    return
            except Exception as exc:
                log("STARTUP_LAST_RESORT_POLL_FAIL_R69 %s" % exc, xbmc.LOGWARNING)

    thread = threading.Thread(target=run, name="PKMStartupLastResortR69", daemon=True)
    thread.start()
    return thread
