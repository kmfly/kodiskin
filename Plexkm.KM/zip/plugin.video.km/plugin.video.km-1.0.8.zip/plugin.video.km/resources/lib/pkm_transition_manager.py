# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui


_PREFIX = "PlexKM.Info.Transition"


def _win():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return None


def _set_prop(owner, key, value):
    try:
        if owner is not None:
            owner.setProperty(key, value)
    except Exception:
        pass
    try:
        w = _win()
        if w is not None:
            w.setProperty(key, value)
    except Exception:
        pass


def _clear_prop(owner, key):
    try:
        if owner is not None:
            owner.clearProperty(key)
    except Exception:
        pass
    try:
        w = _win()
        if w is not None:
            w.clearProperty(key)
    except Exception:
        pass


def _global_prop(key):
    try:
        w = _win()
        return (w.getProperty(key) if w is not None else "") or ""
    except Exception:
        return ""


def _clear_global_prop(key):
    """Clear a global transition property without retaining WindowXML.

    Delayed transition workers can outlive the PlexKM WindowXML instance that
    started them.  They must therefore never call owner.clearProperty().
    """
    try:
        w = _win()
        if w is not None:
            w.clearProperty(key)
    except Exception:
        pass


def _transition_matches(token="", rating_key=""):
    current_token = _global_prop(_PREFIX + ".Token")
    current_key = _global_prop("PlexKM.Info.RatingKey")
    if token and current_token and current_token != token:
        return False
    if rating_key and current_key and current_key != rating_key:
        return False
    return True


def _entry_swap_ready_v2123():
    """True only after the new reused-Info title is complete and owns top focus.

    v2190 actor-work swaps no longer require EntryResetHide before reveal.  The
    old reversible v2079 scroll is visually cancelled by equal/opposite XML
    compensation while it retires in the background.  Normal reused-Info paths
    keep the established hidden-reset gate unchanged.
    """
    if _global_prop("PlexKM.Info.EntrySwapV2087") != "1":
        return True
    target = _global_prop("PlexKM.Info.EntryTargetRatingKeyV2123")
    current = _global_prop("PlexKM.Info.RatingKey")
    reset_ready = (
        _global_prop("PlexKM.Info.EntryResetHideV2123") == "1"
        or _global_prop("PlexKM.Info.ActorPrecomposeV2185") == "1"
    )
    return (
        _global_prop("PlexKM.Info.EntryTargetReadyV2123") == "1"
        and _global_prop("PlexKM.Info.EntryTargetFocusReadyV2123") == "1"
        and reset_ready
        and (not target or not current or target == current)
    )


def _schedule_actor_scroll_compensation_cleanup_v2190(token="", rating_key=""):
    """Retire actor-work EntrySwap only after the XML compensation reaches zero.

    The target Info is already visible at its final Y position while the old
    reversible v2079 transform and the equal/opposite v2190 compensation both
    run for 420ms.  When both reach zero, clearing the transition properties is
    visually inert.  Token/rating checks prevent an older cleanup worker from
    touching a newer Info transaction.
    """
    marker_key = _PREFIX + ".ActorCompCleanupV2190"
    marker = token or rating_key or str(int(time.time() * 1000))
    try:
        if _global_prop(marker_key) == marker:
            return
        w = _win()
        if w is not None:
            w.setProperty(marker_key, marker)
    except Exception:
        pass

    def _worker():
        try:
            monitor = xbmc.Monitor()
            if monitor.waitForAbort(0.48):
                return
            if not _transition_matches(token, rating_key):
                return
            if _global_prop(marker_key) != marker:
                return
            for prop in (
                "PlexKM.Info.EntrySwapV2087",
                "PlexKM.Info.EntrySwapStartMsV2152",
                "PlexKM.Info.ReentrantSwapV2083",
                "PlexKM.Info.ReentrantScrollResetV2086",
                "PlexKM.Info.DirectSwapV2086",
                "PlexKM.Info.ChildFreshEntryV2123",
                "PlexKM.Info.EntryTargetRatingKeyV2123",
                "PlexKM.Info.EntryTargetReadyV2123",
                "PlexKM.Info.EntryTargetFocusReadyV2123",
                "PlexKM.Info.EntryResetHideV2123",
                "PlexKM.Info.ActorPrecomposeV2185",
                "PlexKM.Info.ActorSourceFocusV2190",
                "PlexKM.Info.ActorSourceHadSeasonCardsV2306",
            ):
                _clear_global_prop(prop)
            _clear_global_prop(marker_key)
            try:
                xbmc.log("[plugin.video.km] INFO_ACTOR_SCROLL_COMPENSATION_CLEANUP_V2190 rating_key=%s token=%s wait_ms=480 position_delta_px=0" % (
                    rating_key or "", token or ""
                ), xbmc.LOGINFO)
            except Exception:
                pass
        except Exception:
            return

    threading.Thread(target=_worker, name="PlexKMActorScrollCompV2190", daemon=True).start()


def _release_entry_swap_fade_only_v2153(monitor, token="", rating_key="", barrier=""):
    """Retire the reused-Info scroll transform entirely behind the fade cover.

    The v2079 vertical navigation animations are legitimate inside one Info page.
    For Info -> Info scene replacement, however, their previous transform must
    never be allowed to reverse on-screen.  v2153 keeps the animation-owner group
    fully hidden, clears the swap conditions, gives Kodi two render frames to
    rebuild it at the child's top position, then re-enables the owner while the
    full-screen transition cover is still opaque.  Normal paths keep the original
    two-frame reset. v2185 actor-work precompose waits only the REMAINING portion
    of the existing 420ms reversible XML scroll so no position animation is
    exposed after the child is revealed.
    """
    _reset_owner_prop_v2153 = "PlexKM.Info.SceneFadeResetOwnerV2153"
    _owner_v2153 = _global_prop(_reset_owner_prop_v2153)
    _this_owner_v2153 = token or rating_key or "1"

    # The normal release worker and the 700ms failsafe can wake together on a
    # slow target. Only one may manipulate the hidden animation owner. A second
    # watcher waits for that same-token reset transaction to finish instead of
    # releasing Cover in the middle of the two hidden render boundaries.
    if _owner_v2153:
        if _owner_v2153 != _this_owner_v2153:
            return False
        while _global_prop(_reset_owner_prop_v2153) == _this_owner_v2153:
            if monitor.waitForAbort(0.01):
                return False
            if not _transition_matches(token, rating_key):
                return False
        return True

    if _global_prop("PlexKM.Info.EntrySwapV2087") != "1":
        return True
    try:
        _win().setProperty(_reset_owner_prop_v2153, _this_owner_v2153)
    except Exception:
        return False
    try:
        xbmc.log("[plugin.video.km] INFO_SCENE_FADE_RESET_BEGIN_V2153 rating_key=%s token=%s barrier=%s reset_hide=%s" % (
            rating_key or "", token or "", barrier or "",
            _global_prop("PlexKM.Info.EntryResetHideV2123") or "0"
        ), xbmc.LOGINFO)
    except Exception:
        pass

    # v2190: actor-work child Info no longer waits behind a fanart-only cover
    # for the 420ms reversible v2079 scroll to return to zero.  Skin XML applies
    # an equal/opposite compensation transform from the recorded source row, so
    # the complete TARGET page can be revealed immediately at native Y=0 while
    # the old transform retires invisibly.  Keep EntrySwap/ActorPrecompose alive
    # until both animations have reached zero, then clear them asynchronously.
    if _global_prop("PlexKM.Info.ActorPrecomposeV2185") == "1":
        try:
            _schedule_actor_scroll_compensation_cleanup_v2190(token, rating_key)
            xbmc.log("[plugin.video.km] INFO_ACTOR_ATOMIC_REVEAL_V2191 rating_key=%s token=%s barrier=%s source_focus=%s cover_wait_ms=0 compensation_ms=420 target_full_page=1 target_fanart_precover=0 geometry=home_700_0_1220_680" % (
                rating_key or "", token or "", barrier or "",
                _global_prop("PlexKM.Info.ActorSourceFocusV2190") or "0"
            ), xbmc.LOGINFO)
        except Exception:
            pass
        if _global_prop(_reset_owner_prop_v2153) == _this_owner_v2153:
            _clear_global_prop(_reset_owner_prop_v2153)
        return True

    # Phase 1: remove all conditions that can own/reverse the old transform, but
    # KEEP EntryResetHide asserted so the animation-owner group cannot paint.
    for _entry_prop in (
        "PlexKM.Info.EntrySwapV2087",
        "PlexKM.Info.EntrySwapStartMsV2152",
        "PlexKM.Info.ReentrantSwapV2083",
        "PlexKM.Info.ReentrantScrollResetV2086",
        "PlexKM.Info.DirectSwapV2086",
        "PlexKM.Info.ChildFreshEntryV2123",
        "PlexKM.Info.EntryTargetRatingKeyV2123",
        "PlexKM.Info.EntryTargetReadyV2123",
        "PlexKM.Info.EntryTargetFocusReadyV2123",
    ):
        _clear_global_prop(_entry_prop)

    # Two render frames are sufficient for a hidden control to retire the old
    # conditional animation state. This is a render-boundary settle, not an
    # animation-duration wait.
    if monitor.waitForAbort(0.04):
        return False
    if not _transition_matches(token, rating_key):
        return False

    # Phase 2: re-enable the body at its native top state, still behind Cover.
    _clear_global_prop("PlexKM.Info.EntryResetHideV2123")
    try:
        xbmc.log("[plugin.video.km] INFO_SCENE_FADE_REBIND_HIDDEN_V2153 rating_key=%s token=%s barrier=%s wait_ms=40" % (
            rating_key or "", token or "", barrier or ""
        ), xbmc.LOGINFO)
    except Exception:
        pass
    if monitor.waitForAbort(0.04):
        return False
    if not _transition_matches(token, rating_key):
        return False
    try:
        xbmc.log("[plugin.video.km] INFO_SCENE_FADE_RELEASE_V2153 rating_key=%s token=%s barrier=%s mode=opacity_only position_delta_px=0 animation_wait_ms=0 hidden_reset_ms=80" % (
            rating_key or "", token or "", barrier or ""
        ), xbmc.LOGINFO)
    except Exception:
        pass
    if _global_prop(_reset_owner_prop_v2153) == _this_owner_v2153:
        _clear_global_prop(_reset_owner_prop_v2153)
    return True


def _transition_target_ready():
    """Return True only when the complete inline Info target can be revealed."""
    if _global_prop("PlexKM.Info.InlineActive") != "1":
        return False
    if _global_prop("PlexKM.Info.IsTV") != "1":
        return True
    return (
        _global_prop("PlexKM.Info.TVRowsReady") == "1"
        or _global_prop("PlexKM.Info.TVRowsEmpty") == "1"
    )


def begin_info_transition(owner, rating_key="", mode="info", cover=True):
    """Start a PKM Info readiness transaction.

    Cover is a logical publish gate, not a painted blank layer. The previous
    completed Home/Info surface stays visible until the target is complete; the
    shared delayed busy broker supplies the only foreground wait spinner.
    """
    token = "%s:%s:%d" % (rating_key or "", mode or "info", int(time.time() * 1000))
    _set_prop(owner, _PREFIX + ".Token", token)
    _set_prop(owner, _PREFIX + ".RatingKey", rating_key or "")
    _set_prop(owner, _PREFIX + ".Mode", mode or "info")
    # v1841: Active marks one composed Info transaction.  cover=False keeps the
    # previous Home/Info screen visible during local preparation; the caller
    # enables Cover only for the final property/control swap.
    _set_prop(owner, _PREFIX + ".Active", "1")

    # v2157: the physical sidebar is rendered by Home outside the Info body.
    # Latch the SOURCE Info tint before target staging can replace
    # PlexKM.Info.DynamicBgSideOpaqueColor.  The small sidebar cover in skin XML
    # keeps this source tint during the hidden A/B swap and fades it away only
    # when the target Info surface is released.  This prevents the left rail from
    # changing color one render transaction earlier than fanart/body.
    source_side_v2157 = (
        _global_prop("PlexKM.Info.DynamicBgSideOpaqueColor")
        or _global_prop("PlexKM.Home.DynamicBgSideOpaqueColor")
        or "FF222324"
    )
    _set_prop(owner, _PREFIX + ".SourceSideColorV2157", source_side_v2157)

    # v2186: do NOT latch the source fanart for actor-work precompose.
    # The source Info remains fully visible only during the preparation/spinner
    # phase.  The final transition surface must use the already-staged TARGET
    # fanart/tint so the child title can never appear over the parent's artwork.
    # Target art is latched later by activate_info_transition_cover(), after the
    # inactive A/B bank has been fully staged.
    _clear_prop(owner, _PREFIX + ".TargetFanartV2186")
    _clear_prop(owner, _PREFIX + ".TargetSideColorV2186")

    try:
        xbmc.log("[plugin.video.km] INFO_SIDEBAR_TINT_LATCH_V2157 rating_key=%s token=%s source=%s cover=%d" % (
            rating_key or "", token or "", source_side_v2157, 1 if cover else 0
        ), xbmc.LOGINFO)
    except Exception:
        pass

    if cover:
        _set_prop(owner, _PREFIX + ".Cover", "1")
    else:
        _clear_prop(owner, _PREFIX + ".Cover")
    return token


def activate_info_transition_cover(owner, token=""):
    """Arm the compatibility publish gate for an atomic Info swap.

    XML does not paint an opaque cover in v1883. The property temporarily keeps
    the target Info overlay hidden while the previous completed surface remains.
    """
    try:
        current_token = _global_prop(_PREFIX + ".Token")
        if token and current_token and current_token != token:
            return False
        if token:
            _set_prop(owner, _PREFIX + ".Token", token)
        _set_prop(owner, _PREFIX + ".Active", "1")

        # v2186: actor-work target preparation has already staged fanart/tint in
        # the inactive universal A/B bank by the time this FINAL cover is armed.
        # Latch that TARGET visual now, before Cover becomes visible.  The cover
        # therefore changes directly from the completed parent Info to the child
        # artwork, and the child metadata is revealed only after the old vertical
        # transform has retired.  No source-fanart hold remains in this path.
        if _global_prop("PlexKM.Info.ActorPrecomposeV2185") == "1":
            pending_bank_v2186 = (_global_prop("PlexKM.Info.ArtPendingBankV2136") or "").upper()
            if pending_bank_v2186 == "B":
                target_fanart_v2186 = _global_prop("PlexKM.Info.ArtBankBV2136")
            elif pending_bank_v2186 == "A":
                target_fanart_v2186 = _global_prop("PlexKM.Info.ArtBankAV2136")
            else:
                target_fanart_v2186 = _global_prop("PlexKM.Info.ArtPendingUrlV2136") or ""
            target_side_v2186 = ""
            if pending_bank_v2186 in ("A", "B"):
                target_side_v2186 = _global_prop("PlexKM.Info.DynamicBgBank%sColorV2140" % pending_bank_v2186)
            target_side_v2186 = target_side_v2186 or _global_prop("PlexKM.Info.DynamicBgSideOpaqueColor") or "FF222324"
            _set_prop(owner, _PREFIX + ".TargetFanartV2186", target_fanart_v2186 or "")
            _set_prop(owner, _PREFIX + ".TargetSideColorV2186", target_side_v2186 or "FF222324")
            try:
                xbmc.log("[plugin.video.km] INFO_TARGET_FANART_LATCH_V2186 token=%s bank=%s fanart=%d tint=%s actor_precompose=1" % (
                    token or "", pending_bank_v2186 or "-", 1 if target_fanart_v2186 else 0, target_side_v2186 or ""
                ), xbmc.LOGINFO)
            except Exception:
                pass
        else:
            _clear_prop(owner, _PREFIX + ".TargetFanartV2186")
            _clear_prop(owner, _PREFIX + ".TargetSideColorV2186")

        _set_prop(owner, _PREFIX + ".Cover", "1")
        return True
    except Exception:
        return False


def commit_info_transition_gate(owner, token="", rating_key=""):
    """Commit target data without exposing a reused Info transform.

    v2158 fixes the actor-work Info -> Info scene order.  A reused Info page is
    still carrying the source page's focus-driven v2079 vertical transform when
    this function is called.  Clearing Cover here used to expose the target page
    before focus=5001 and the hidden EntrySwap reset had completed; Kodi could
    therefore paint the target while that old transform was returning to zero,
    which looks like the new Info drops from the top.

    For SAME-SURFACE Info -> Info only, keep Cover owned here.  The caller then
    publishes InlineActive (already 1 on this path), moves native focus to the
    target entry control, marks EntryTargetFocusReadyV2123, and the existing
    finish worker retires EntrySwap/vertical animation state entirely behind the
    cover.  Only after two hidden render boundaries is Cover released, so the
    target page can enter by opacity alone at its final Y=0 position.

    Fresh Home/Library/Search -> Info keeps the established direct commit and
    clears Cover here because there is no reused Info scroll transform to retire.
    """
    try:
        if not _transition_matches(token, rating_key):
            return False
        win = _win()
        same_surface_v2158 = bool(
            win.getProperty("PlexKM.Info.EntrySwapV2087") == "1"
            or win.getProperty("PlexKM.Info.ChildFreshEntryV2123") == "1"
        )
        if same_surface_v2158:
            try:
                xbmc.log(
                    "[plugin.video.km] INFO_SCENE_GATE_HOLD_V2158 "
                    "rating_key=%s token=%s cover=1 reason=await_target_top_bind "
                    "entry_swap=%s focus_ready=%s" % (
                        rating_key or "", token or "",
                        win.getProperty("PlexKM.Info.EntrySwapV2087") or "0",
                        win.getProperty("PlexKM.Info.EntryTargetFocusReadyV2123") or "0",
                    ),
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
            return True
        _clear_prop(owner, _PREFIX + ".Cover")
        return True
    except Exception:
        return False


def finish_info_transition(owner, token="", rating_key="", delay_ms=80):
    """Release the logical transition gate after the target is complete.

    This never blocks the Kodi UI thread.  Token/rating_key checks prevent a late
    release from an older Info open from exposing a newer screen too early.
    """
    def _worker():
        try:
            monitor = xbmc.Monitor()
            wait_s = max(0, int(delay_ms or 0)) / 1000.0
            if wait_s > 0 and monitor.waitForAbort(wait_s):
                return

            # v1883: callers compose TV A/B rows first, synchronously clear the
            # logical gate, and then publish InlineActive. This worker only retires
            # the transaction marker after the complete target is visible.
            while not monitor.abortRequested():
                if not _transition_matches(token, rating_key):
                    return
                cover_now = _global_prop(_PREFIX + ".Cover")
                active_now = _global_prop(_PREFIX + ".Active")
                if cover_now != "1" and active_now != "1":
                    return
                if _transition_target_ready():
                    # v2159: a reused Info surface can still expose the parent's
                    # InlineActive/TVRowsReady values. Do not release its hidden
                    # scroll owner until the child is composed and Kodi owns the
                    # universal scene-entry top anchor (5001). TV content rails are
                    # deliberately excluded from the release dependency because
                    # those controls live inside the very scroll state being reset.
                    if not _entry_swap_ready_v2123():
                        if monitor.waitForAbort(0.025):
                            return
                        continue
                    # Give Kodi two frames to bind the final properties and
                    # inactive TV buffer before starting the XML reveal.
                    if monitor.waitForAbort(0.04):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    if not _transition_target_ready():
                        continue
                    # v2087: same-Window Info -> different-title swaps keep the
                    # v2079 scroll owner hidden through this existing two-frame
                    # target-bind boundary. Release only here, never in onFocus,
                    # so the old completed slide transform cannot be rendered on
                    # the child title. This reuses the established transition
                    # barrier and does not create a second timer/focus owner.
                    if _global_prop("PlexKM.Info.EntrySwapV2087") == "1":
                        if not _release_entry_swap_fade_only_v2153(
                                monitor, token, rating_key, barrier="two_frame_target_bind"):
                            return
                    try:
                        xbmc.log("[plugin.video.km] INFO_SCENE_TARGET_TOP_BOUND_V2158 rating_key=%s token=%s barrier=two_frame_target_bind focus_ready=%s entry_swap=%s reset_hide=%s next=opacity_fade_release" % (
                            rating_key or "", token or "",
                            _global_prop("PlexKM.Info.EntryTargetFocusReadyV2123") or "cleared_after_hidden_reset",
                            _global_prop("PlexKM.Info.EntrySwapV2087") or "0",
                            _global_prop("PlexKM.Info.EntryResetHideV2123") or "0"
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    _clear_global_prop(_PREFIX + ".Cover")
                    try:
                        xbmc.log("[plugin.video.km] INFO_SCENE_OPACITY_RELEASE_V2158 rating_key=%s token=%s mode=target_already_top position_delta_px=0" % (
                            rating_key or "", token or ""
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    try:
                        xbmc.log("[plugin.video.km] INFO_SIDEBAR_TINT_RELEASE_V2157 rating_key=%s token=%s target=%s mode=source_overlay_fade_to_target" % (
                            rating_key or "", token or "",
                            _global_prop("PlexKM.Info.DynamicBgSideOpaqueColor") or ""
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    # The active marker outlives the 140/160ms skin reveal.
                    if monitor.waitForAbort(0.22):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    _clear_global_prop(_PREFIX + ".Active")
                    return
                if monitor.waitForAbort(0.025):
                    return
        except Exception:
            # A delayed worker must not dereference the originating WindowXML;
            # cancellation or the property-aware failsafe owns recovery.
            return

    threading.Thread(target=_worker, name="PlexKMInfoTransitionRelease", daemon=True).start()



def schedule_transition_failsafe(owner, token="", rating_key="", max_ms=700):
    """Wake a secondary release watcher if the normal path takes too long.

    The watchdog never treats elapsed time as proof that a TV/episode target is
    complete.  It releases only after the same Ready/Empty condition as the
    normal worker, preventing a timeout from exposing a half-built Info shell.
    """
    def _worker():
        try:
            monitor = xbmc.Monitor()
            wait_s = max(0, int(max_ms or 0)) / 1000.0
            if wait_s > 0 and monitor.waitForAbort(wait_s):
                return

            # v1841: max_ms is a watchdog wake-up, not permission to reveal a
            # half-built TV page.  If preparation is still valid, continue to
            # wait for the same Ready/Empty contract as the normal release.
            deferred_logged = False
            while not monitor.abortRequested():
                if not _transition_matches(token, rating_key):
                    return
                cover_now = _global_prop(_PREFIX + ".Cover")
                active_now = _global_prop(_PREFIX + ".Active")
                if cover_now != "1" and active_now != "1":
                    return
                if _transition_target_ready():
                    if not _entry_swap_ready_v2123():
                        if monitor.waitForAbort(0.025):
                            return
                        continue
                    # v2087 failsafe parity: honor the same render-boundary
                    # release contract as the normal transition worker.
                    if monitor.waitForAbort(0.04):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    if not _transition_target_ready():
                        continue
                    if _global_prop("PlexKM.Info.EntrySwapV2087") == "1":
                        if not _release_entry_swap_fade_only_v2153(
                                monitor, token, rating_key, barrier="failsafe_two_frame_target_bind"):
                            return
                    try:
                        xbmc.log("[plugin.video.km] INFO_SCENE_TARGET_TOP_BOUND_V2158 rating_key=%s token=%s barrier=failsafe_two_frame_target_bind focus_ready=%s entry_swap=%s reset_hide=%s next=opacity_fade_release" % (
                            rating_key or "", token or "",
                            _global_prop("PlexKM.Info.EntryTargetFocusReadyV2123") or "cleared_after_hidden_reset",
                            _global_prop("PlexKM.Info.EntrySwapV2087") or "0",
                            _global_prop("PlexKM.Info.EntryResetHideV2123") or "0"
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    _clear_global_prop(_PREFIX + ".Cover")
                    try:
                        xbmc.log("[plugin.video.km] INFO_SCENE_OPACITY_RELEASE_V2158 rating_key=%s token=%s mode=target_already_top position_delta_px=0 source=failsafe" % (
                            rating_key or "", token or ""
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    try:
                        xbmc.log("[plugin.video.km] INFO_SIDEBAR_TINT_RELEASE_V2157 rating_key=%s token=%s target=%s mode=failsafe_source_overlay_fade_to_target" % (
                            rating_key or "", token or "",
                            _global_prop("PlexKM.Info.DynamicBgSideOpaqueColor") or ""
                        ), xbmc.LOGINFO)
                    except Exception:
                        pass
                    if monitor.waitForAbort(0.22):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    _clear_global_prop(_PREFIX + ".Active")
                    try:
                        xbmc.log("[plugin.video.km] INFO_TRANSITION_FAILSAFE_RELEASE_V1841 rating_key=%s wake_ms=%s ready=1" % (rating_key or "", max_ms), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return
                if not deferred_logged:
                    deferred_logged = True
                    try:
                        xbmc.log("[plugin.video.km] INFO_TRANSITION_FAILSAFE_DEFER_V1841 rating_key=%s wake_ms=%s reason=target_not_ready" % (rating_key or "", max_ms), xbmc.LOGINFO)
                    except Exception:
                        pass
                if monitor.waitForAbort(0.10):
                    return
        except Exception:
            return

    threading.Thread(target=_worker, name="PlexKMInfoTransitionFailsafe", daemon=True).start()


def cancel_info_transition(owner):
    for suffix in (".Cover", ".Active", ".Token", ".RatingKey", ".Mode", ".SourceSideColorV2157", ".TargetFanartV2186", ".TargetSideColorV2186"):
        _clear_prop(owner, _PREFIX + suffix)
    # v2087: never strand the reused Info body in top-lock state after an
    # aborted/failed transition. EntrySwapV2087 is intentionally global-only.
    for _entry_prop in (
        "PlexKM.Info.EntrySwapV2087",
        "PlexKM.Info.EntrySwapStartMsV2152",
        "PlexKM.Info.SceneFadeResetOwnerV2153",
        "PlexKM.Info.ReentrantSwapV2083",
        "PlexKM.Info.ReentrantScrollResetV2086",
        "PlexKM.Info.DirectSwapV2086",
        "PlexKM.Info.ChildFreshEntryV2123",
        "PlexKM.Info.EntryTargetRatingKeyV2123",
        "PlexKM.Info.EntryTargetReadyV2123",
        "PlexKM.Info.EntryTargetFocusReadyV2123",
        "PlexKM.Info.EntryResetHideV2123",
        "PlexKM.Info.ActorPrecomposeV2185",
        "PlexKM.Info.ActorSourceFocusV2190",
        "PlexKM.Info.ActorSourceHadSeasonCardsV2306",
        "PlexKM.Info.Transition.ActorCompCleanupV2190",
    ):
        _clear_global_prop(_entry_prop)
