# -*- coding: utf-8 -*-
"""PKM home window part (R73): 인포 페이지(영화/공통).

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartInfoR73
    def _info_prepared_cache_load_v2467(self):
        cache = getattr(self, "_info_prepared_cache_v2467", None)
        if isinstance(cache, dict):
            return cache
        cache = {}
        path = self._derived_cache_path_v2467("info_prepared_cache_v2468.json")
        try:
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                if isinstance(payload, dict):
                    cache = dict(payload.get("entries") or {})
        except Exception:
            cache = {}
        self._info_prepared_cache_v2467 = cache
        return cache

    def _info_prepared_item_match_v2510(self, li, rec):
        """Cheap current-item identity proof for Info content reuse.

        The focused Home/section ListItem was built from the current synchronized
        local item row.  If its ratingKey/section/type/UpdatedAt are identical to
        the prepared record, the cached *content* metadata belongs to this exact
        item.  This check intentionally says nothing about presentation/rating
        tables or whole-show TV rails.
        """
        try:
            if li is None or not isinstance(rec, dict):
                return False
            props = rec.get("props") if isinstance(rec.get("props"), dict) else {}
            rk_now = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            rk_old = str(props.get("RatingKey") or "").strip()
            sid_now = str(li.getProperty("PlexKM.SectionId") or "").strip()
            sid_old = str(props.get("SectionId") or rec.get("section_id") or "").strip()
            type_now = str(li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "").strip().lower()
            type_old = str(props.get("Type") or props.get("KodiType") or "").strip().lower()
            updated_now = str(li.getProperty("PlexKM.UpdatedAt") or "").strip()
            updated_old = str(props.get("UpdatedAt") or "").strip()
            if not rk_now or rk_now != rk_old or not sid_now or sid_now != sid_old:
                return False
            if type_now and type_old and type_now != type_old:
                # KodiType tvshow vs Plex type show is the one normal alias.
                aliases = {("show", "tvshow"), ("tvshow", "show")}
                if (type_now, type_old) not in aliases:
                    return False
            # Fail closed when UpdatedAt is missing.  Added/title equality alone is
            # not a sufficient authority signal for metadata changes.
            return bool(updated_now and updated_old and updated_now == updated_old)
        except Exception:
            return False

    def _info_apply_prepared_content_v2510(self, li, rec, reason="", allow_tv_payload=False):
        """Apply prepared content without stale presentation/playstate overwrite."""
        try:
            if li is None or not isinstance(rec, dict):
                return False
            props = rec.get("props") if isinstance(rec.get("props"), dict) else {}
            rk = str(li.getProperty("PlexKM.RatingKey") or props.get("RatingKey") or "").strip()
            if not rk:
                return False
            # These values are owned by the current Home/playstate/presentation
            # snapshot and can change independently of Plex content authority.
            volatile = {
                "Rating", "MetaLine", "ViewOffset", "ResumeDurationMs",
                "PlayButtonLabel",
            }
            for key, value in props.items():
                key = str(key)
                if key in volatile:
                    continue
                try:
                    li.setProperty("PlexKM.%s" % key, str(value or ""))
                except Exception:
                    pass
            try:
                li.setProperty("PlexKM.InfoLoaded", "1")
                li.setProperty("PlexKM.InfoLoadedRatingKey", rk)
                # Re-derive the volatile action label from the current item state.
                current_offset = li.getProperty("PlexKM.ViewOffset") or ""
                current_resume = li.getProperty("PlexKM.ResumeDurationMs") or ""
                current_duration = li.getProperty("PlexKM.Duration") or ""
                li.setProperty(
                    "PlexKM.PlayButtonLabel",
                    self._play_button_label(current_offset, current_duration, current_resume)
                )
            except Exception:
                pass
            art = rec.get("art") if isinstance(rec.get("art"), dict) else {}
            if art:
                fill_art = {}
                for art_key, art_value in art.items():
                    try:
                        if not str(li.getArt(str(art_key)) or "").strip() and str(art_value or "").strip():
                            fill_art[str(art_key)] = str(art_value or "")
                    except Exception:
                        pass
                if fill_art:
                    try:
                        li.setArt(fill_art)
                    except Exception:
                        pass
            self._info_prepared_tv_payload_v2510 = None
            if allow_tv_payload:
                payload = rec.get("tv_payload_v2510") if isinstance(rec.get("tv_payload_v2510"), dict) else None
                if payload:
                    prk = str(payload.get("rating_key") or "").strip()
                    psid = str(payload.get("section_id") or "").strip()
                    if prk == rk and psid == str(li.getProperty("PlexKM.SectionId") or "").strip():
                        self._info_prepared_tv_payload_v2510 = dict(payload)
            _log("INFO_PREPARED_CONTENT_APPLY_V2510 rating_key=%s reason=%s tv_payload=%d presentation_overwrite=0 playstate_overwrite=0" % (
                rk, reason or "", 1 if isinstance(getattr(self, "_info_prepared_tv_payload_v2510", None), dict) else 0
            ))
            return True
        except Exception:
            return False

    def _info_try_home_meta_memory_v2510(self, li, reason=""):
        """Consume already-enriched Home metadata before opening plex_km.db."""
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            cached = getattr(self, "_home_meta_enrich_cache", {}).get(rk)
            if not isinstance(cached, dict) or not self._meta_props_useful(cached):
                return False
            ok = bool(self._apply_cached_info_to_li(
                li, reason="home_memory_v2510_%s" % (reason or "info"), update_visual=False
            ))
            if not ok:
                return False
            ptype = str(li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "").lower()
            complete = bool(self._li_info_complete_for_inline(li))
            if ptype == "movie":
                complete = complete and (not self._li_movie_detail_missing_for_info(li))
            art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
            if complete and art_ready:
                _log("INFO_HOME_META_MEMORY_HIT_V2510 rating_key=%s type=%s local_db=0 reason=%s" % (
                    rk, ptype or "item", reason or ""
                ))
                return True
            return False
        except Exception:
            return False

    def _info_prepared_cache_apply_v2467(self, li):
        try:
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            rec = self._info_prepared_cache_load_v2467().get(rk)
            if not isinstance(rec, dict):
                return False
            if int(rec.get("fingerprint_version") or 0) != 2468:
                self._info_prepared_cache_v2467.pop(rk, None)
                return False
            if max(0.0, time.time() - float(rec.get("ts") or 0.0)) > 2592000.0:
                self._info_prepared_cache_v2467.pop(rk, None)
                return False
            model_v2507 = str(rec.get("authority_model") or "")
            if model_v2507 != "content_section_v2489":
                # v2507 invariant: never resurrect the expensive legacy global
                # authority scan on a click. Old entries remain one-time rejects.
                sid_v2507 = self._persistent_entry_section_id_v2489(rec, entry_key="info:%s" % rk)
                self._info_prepared_cache_v2467.pop(rk, None)
                _log("INFO_PREPARED_CACHE_LEGACY_FAST_REJECT_V2507 rating_key=%s section=%s old_model=%s global_scan=0 rebuild=local" % (
                    rk, sid_v2507 or "unknown", model_v2507 or "legacy"
                ))
                return False

            # v2510: prepared Info metadata is content data. Do not compute the
            # global presentation fingerprint here. Current Home rating/playstate
            # values are explicitly preserved by the content apply helper.
            item_match_v2510 = self._info_prepared_item_match_v2510(li, rec)
            tv_payload_v2510 = rec.get("tv_payload_v2510") if isinstance(rec.get("tv_payload_v2510"), dict) else None
            section_ok_v2510 = False
            content_reason_v2510 = "item_updatedat"

            # A TV payload spans many items, so that multi-item data still needs
            # full section authority. Content-only item reuse needs no DB query
            # when the current item's UpdatedAt identity is exact.
            if item_match_v2510 and not tv_payload_v2510:
                section_ok_v2510 = False
            else:
                try:
                    section_ok_v2510, content_reason_v2510 = self._persistent_entry_content_match_v2487(
                        rec, entry_key="info:%s" % rk
                    )
                except Exception:
                    section_ok_v2510, content_reason_v2510 = False, "section_check_failed"

            if not item_match_v2510 and not section_ok_v2510:
                self._info_prepared_cache_v2467.pop(rk, None)
                self._info_prepared_tv_payload_v2510 = None
                _log("INFO_PREPARED_CACHE_REJECT_V2510 rating_key=%s reason=content_authority_changed detail=%s presentation_scan=0" % (
                    rk, content_reason_v2510
                ))
                return False

            allow_tv_payload_v2510 = bool(section_ok_v2510 and tv_payload_v2510)
            applied_v2510 = self._info_apply_prepared_content_v2510(
                li, rec,
                reason=("item_updatedat" if item_match_v2510 else "section_authority"),
                allow_tv_payload=allow_tv_payload_v2510,
            )
            if not applied_v2510:
                return False
            # R120c: cached cast photos follow the user's actor-photo picks.
            try:
                for _i_r120 in range(1, 13):
                    _nm_r120 = li.getProperty("PlexKM.Cast%d.Name" % _i_r120)
                    if not _nm_r120:
                        continue
                    _ov_r120 = pkm_meta_override_r120.actor_photo(_nm_r120)
                    if _ov_r120:
                        li.setProperty("PlexKM.Cast%d.Thumb" % _i_r120, _ov_r120)
                        li.setProperty("PlexKM.Cast%d.OriginalThumb" % _i_r120, _ov_r120)
                        li.setProperty("PlexKM.Cast%d.LocalThumb" % _i_r120, "")
            except Exception:
                pass
            _log("INFO_PREPARED_CACHE_HIT_V2510 rating_key=%s item_match=%d section_match=%d presentation_scan=0 presentation_overwrite=0 tv_payload=%d spinner=0" % (
                rk, 1 if item_match_v2510 else 0, 1 if section_ok_v2510 else 0,
                1 if allow_tv_payload_v2510 else 0
            ))
            return True
        except Exception:
            return False

    def _info_prepared_cache_snapshot_v2506(self, li):
        """Capture Info cache payload on the GUI thread without DB/disk authority work."""
        try:
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return None
            keys = [
                "RatingKey","SectionId","Type","KodiType","InfoLoadedRatingKey","Title","TitleDisplay",
                "EpisodeTitle","OriginalTitle","Summary","SummaryDisplay","Summary3","Year","Duration",
                "DurationText","ViewOffset","ResumeDurationMs","PlayButtonLabel","Genre","Director","Writer",
                "Cast","Studio","Rating","ContentRating","Tagline","Premiered","MetaLine","MetaLineBaseV2313",
                "PartKey","PlayUrl","ShowUrl","ShowTitle","Season","Episode","ParentRatingKey",
                "GrandparentRatingKey","AddedAt","UpdatedAt","Art","Thumb","PosterFallbackArt"
            ]
            props = {key: str(li.getProperty("PlexKM.%s" % key) or "") for key in keys}
            for idx in range(1, 9):
                for sub in ("Name","Role","Thumb","OriginalThumb","LocalThumb","ThumbSource","SourceRatingKey"):
                    key = "Cast%d.%s" % (idx, sub)
                    props[key] = str(li.getProperty("PlexKM.%s" % key) or "")
            art = {}
            for art_key in ("poster","thumb","icon","fanart"):
                try:
                    value = li.getArt(art_key) or ""
                    if value:
                        art[art_key] = value
                except Exception:
                    pass
            tv_payload_v2510 = None
            try:
                ptype_v2510 = str(props.get("Type") or props.get("KodiType") or "").strip().lower()
                if ptype_v2510 in ("show", "tv", "tvshow", "season", "episode"):
                    rows_v2510 = list(getattr(self, "_info_tv_rows", []) or [])
                    if rows_v2510:
                        show_key_v2510 = (
                            rk if ptype_v2510 in ("show", "tv", "tvshow")
                            else str(props.get("GrandparentRatingKey") or "").strip()
                        )
                        tv_payload_v2510 = {
                            "rating_key": rk,
                            "section_id": str(props.get("SectionId") or "").strip(),
                            "show_key": show_key_v2510,
                            "rows": self._json_safe_v2467(rows_v2510),
                            "seasons": self._json_safe_v2467(list(getattr(self, "_info_tv_seasons", []) or [])),
                            "season_cards": self._json_safe_v2467(list(getattr(self, "_info_tv_season_cards", []) or [])),
                            "selected_season": str(getattr(self, "_info_tv_selected_season", "") or ""),
                            "refresh_payload": self._json_safe_v2467(dict(getattr(self, "_info_tv_season_refresh_payload_v1883", {}) or {})),
                        }
            except Exception:
                tv_payload_v2510 = None
            return {
                "rk": rk, "section_id": str(props.get("SectionId") or "").strip(),
                "ts": time.time(), "props": props, "art": art,
                "tv_payload_v2510": tv_payload_v2510,
            }
        except Exception:
            return None

    def _info_prepared_cache_store_snapshot_v2506(self, snapshot):
        """Worker-only V2506 persist path; never reads Kodi ListItem/control state."""
        started = time.time()
        rk = str((snapshot or {}).get("rk") or "").strip()
        if not rk:
            return False
        try:
            lock = getattr(self, "_info_prepared_store_lock_v2506", None)
            if lock is None:
                lock = threading.RLock()
                self._info_prepared_store_lock_v2506 = lock
            with lock:
                sid_v2507 = str((snapshot or {}).get("section_id") or ((snapshot or {}).get("props") or {}).get("SectionId") or "").strip()
                fp = self._persistent_section_authority_fingerprint_v2489(sid_v2507)
                if not sid_v2507 or not fp:
                    return False
                presentation_fp = str(self._persistent_presentation_fingerprint_v2487() or "")
                cache = self._info_prepared_cache_load_v2467()
                cache[rk] = {
                    "ts": float((snapshot or {}).get("ts") or time.time()),
                    "authority_model": "content_section_v2489",
                    "authority_fp": fp,
                    "section_id": sid_v2507,
                    "presentation_fp_v2487": presentation_fp,
                    "fingerprint_version": 2468,
                    "props": dict((snapshot or {}).get("props") or {}),
                    "art": dict((snapshot or {}).get("art") or {}),
                    "tv_payload_v2510": dict((snapshot or {}).get("tv_payload_v2510") or {}) if isinstance((snapshot or {}).get("tv_payload_v2510"), dict) else None,
                }
                if len(cache) > 512:
                    ordered = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0))
                    for old_key, _ in ordered[:-512]:
                        cache.pop(old_key, None)
                path = self._derived_cache_path_v2467("info_prepared_cache_v2468.json")
                tmp = path + ".tmp.v2507.%s" % threading.get_ident()
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump({"version": 2468, "entries": cache}, f, ensure_ascii=False, separators=(",", ":"))
                os.replace(tmp, path)
            _log("INFO_PREPARED_CACHE_STORE_ASYNC_V2510 rating_key=%s section=%s elapsed_ms=%d authority=section_content presentation_saved_compat=1 gui_block=0 global_scan=0 tv_payload=%d" % (
                rk, sid_v2507, int((time.time() - started) * 1000.0),
                1 if isinstance((snapshot or {}).get("tv_payload_v2510"), dict) and (snapshot or {}).get("tv_payload_v2510") else 0
            ))
            return True
        except Exception:
            _log("INFO_PREPARED_CACHE_STORE_ASYNC_FAILED_V2507 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_prepared_cache_store_async_v2506(self, snapshot):
        try:
            if not snapshot or not str(snapshot.get("rk") or "").strip():
                return False
            self._info_prepared_store_seq_v2506 = int(getattr(self, "_info_prepared_store_seq_v2506", 0) or 0) + 1
            seq = self._info_prepared_store_seq_v2506
            rk = str(snapshot.get("rk") or "")
            t = _PKMHomeThreadV2151(
                target=self._info_prepared_cache_store_snapshot_v2506,
                args=(snapshot,),
                name="PKMInfoPersistV2506-%d" % seq,
                daemon=True,
            )
            t.start()
            _log("INFO_PREPARED_CACHE_STORE_QUEUE_V2506 rating_key=%s seq=%d foreground_io=0" % (rk, seq))
            return True
        except Exception:
            return False

    def _info_first_scene_prime_arm_v2513(self, reason=""):
        """V2514 rollback: never make native Info group 5599 visible while Home owns the scene."""
        try:
            win = xbmcgui.Window(10000)
            for key in (
                "PlexKM.Info.ScenePrimeV2513",
                "PlexKM.Info.FirstScenePrimeArmedV2513",
            ):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
                try:
                    self.clearProperty(key)
                except Exception:
                    pass
            _log("INFO_FIRST_SCENE_PRIME_DISABLED_V2514 reason=%s native_group=5599 visible_prime=0 home_owner_preserved=1" % (reason or ""))
        except Exception:
            pass
        return False

    def _info_first_scene_prime_consume_v2513(self, rating_key="", reason=""):
        # V2514: renderer-visible priming is removed. Keep the old call harmless for
        # cumulative compatibility and clear any stale process-local ScenePrime flag.
        try:
            win = xbmcgui.Window(10000)
            win.clearProperty("PlexKM.Info.ScenePrimeV2513")
            self.clearProperty("PlexKM.Info.ScenePrimeV2513")
        except Exception:
            pass
        return False

    def _schedule_info_asset_prewarm(self, reason=""):
        """Disable background Info/cast prewarm from wall focus.

        v248 crash-stop rule:
        Kodi was terminating while fast wall/menu movement was still running
        background INFO_PREWARM/cast-cache workers.  Those workers can continue
        to set ListItem properties and save actor circle images after the wall is
        reset/rebuilt.  Do not start any focus-time prewarm; Info click will do
        the required work on demand.
        """
        try:
            self._info_prewarm_token += 1
            _log("INFO_PREWARM_DISABLED reason=%s" % reason)
        except Exception:
            pass
        return

    def _info_sidebar_hold_arm_v2387(self, reason=""):
        """Keep the current inline Info scene visible while sidebar only owns focus.

        Kodi XML remains the sole directional-focus owner.  This state records the
        menu position at LEFT-entry and never calls setFocusId/selectItem/setPosition.
        """
        try:
            if not (self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
                return False
            try:
                pos = int(self.getControl(MENU_ID).getSelectedPosition())
            except Exception:
                pos = int(getattr(self, "active_menu_index", -1) or -1)
            hold = getattr(self, "_info_sidebar_hold_v2387", None)
            if not isinstance(hold, dict) or int(hold.get("origin_pos", -999)) != pos:
                hold = {
                    "origin_pos": int(pos),
                    "armed_ms": int(self._now_ms()),
                    "reason": str(reason or ""),
                }
                self._info_sidebar_hold_v2387 = hold
            self._info_set_property_all("PlexKM.Info.SidebarOpen", "1")
            self._info_set_property_all("PlexKM.Info.SidebarHoldV2387", "1")
            _log("INFO_SIDEBAR_HOLD_ARM_V2387 menu_pos=%s reason=%s right_scene=info content_mutation=0 python_focus_write=0" % (
                pos, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_SIDEBAR_HOLD_ARM_FAILED_V2387 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_sidebar_hold_active_v2387(self):
        try:
            hold = getattr(self, "_info_sidebar_hold_v2387", None)
            if not isinstance(hold, dict) or not hold:
                return False
            return bool(
                self.getProperty("PlexKM.Info.InlineActive") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
            )
        except Exception:
            return False

    def _info_sidebar_hold_release_v2387(self, reason="", clear_info=True):
        """Retire the temporary Info/sidebar hold without steering focus.

        V2387 normally released after a destination render. V2404 also calls this
        immediately on a real sidebar selection change so stale Info can never be
        drawn over the next Home/Section target.
        """
        hold = getattr(self, "_info_sidebar_hold_v2387", None)
        try:
            origin_pos = int(hold.get("origin_pos", -1)) if isinstance(hold, dict) else -1
            elapsed = max(0, int(self._now_ms()) - int(hold.get("armed_ms", self._now_ms()))) if isinstance(hold, dict) else 0
        except Exception:
            origin_pos, elapsed = -1, 0
        self._info_sidebar_hold_v2387 = None
        try:
            self._info_clear_property_all("PlexKM.Info.SidebarHoldV2387")
        except Exception:
            pass
        if clear_info:
            try:
                target_v2479 = "home" if str(reason or "").startswith("home_ready_") else self._pkm_surface_mode_v2479()
                # _pkm_surface_mode sees Actor/Info first; derive the already
                # committed base target from mode properties in that case.
                if target_v2479 in ("actor_profile", "info"):
                    win_v2479 = xbmcgui.Window(10000)
                    if self.getProperty("PlexKM.Window.IsSectionWall") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionWall") == "1":
                        target_v2479 = "section_library"
                    elif self.getProperty("PlexKM.Window.IsSectionCategory") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionCategory") == "1":
                        target_v2479 = "section_category"
                    elif self.getProperty("PlexKM.Window.IsSectionRecommend") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionRecommend") == "1":
                        target_v2479 = "section_recommend"
                    else:
                        target_v2479 = "home"
                if self._actor_profile_is_active_v2454():
                    self._pkm_overlay_retire_for_target_v2479(target_v2479, reason="info_sidebar_release:%s" % (reason or ""))
                elif self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                    token_v2479 = self._pkm_swap_settle_v2479("info", target_v2479, reason="info_sidebar_target_ready:%s" % (reason or ""), wait_ms=16)
                    self._clear_inline_info(reason="info_sidebar_hold_release_v2479:%s" % (reason or ""))
                    self._pkm_swap_finish_v2479(token_v2479, "info", target_v2479, reason="info_sidebar_release:%s" % (reason or ""))
            except Exception:
                pass
        _release_scene_v2404 = "destination_target_first_v2479"
        _log("INFO_SIDEBAR_HOLD_RELEASE_V2387 origin_pos=%s elapsed_ms=%s reason=%s clear_info=%d right_scene=%s python_focus_write=0" % (
            origin_pos, elapsed, reason or "", 1 if clear_info else 0, _release_scene_v2404
        ))
        return True

    def _info_hold_busy_until_cover_release_v2185(self, busy_token, transition_token, rating_key):
        """Keep the already-visible Info spinner until the atomic cover releases.

        This worker owns only the global busy token. It never touches focus,
        controls, or directional navigation. Actor-work precompose can therefore
        show one continuous wait indicator from poster click through the hidden
        scroll-settle boundary, then remove it exactly as the prepared target is
        revealed.
        """
        busy_token = str(busy_token or "")
        transition_token = str(transition_token or "")
        rating_key = str(rating_key or "")
        if not busy_token:
            return False

        def _worker():
            monitor = xbmc.Monitor()
            deadline = time.monotonic() + 5.0
            try:
                while not monitor.abortRequested() and time.monotonic() < deadline:
                    win = xbmcgui.Window(10000)
                    current_transition = win.getProperty("PlexKM.Info.Transition.Token") or ""
                    cover = win.getProperty("PlexKM.Info.Transition.Cover") or "0"
                    current_rating = win.getProperty("PlexKM.Info.RatingKey") or ""
                    if transition_token and current_transition and current_transition != transition_token:
                        break
                    if rating_key and current_rating and current_rating != rating_key:
                        break
                    if cover != "1":
                        break
                    if monitor.waitForAbort(0.025):
                        return
            finally:
                try:
                    self._scene_busy_finish_v2482(busy_token, reason="actor_info_cover_released_v2185")
                    _log("INFO_ACTOR_PRECOMPOSE_SPINNER_END_V2185 rating_key=%s transition=%s cover=0" % (
                        rating_key, transition_token
                    ))
                except Exception:
                    pass

        _PKMHomeThreadV2151(
            target=_worker, name="PlexKMInfoBusyReleaseV2185", daemon=True
        ).start()
        return True

    def _li_info_complete_for_inline(self, li):
        try:
            if li is None:
                return False
            rk = li.getProperty("PlexKM.RatingKey") or ""
            loaded_key = li.getProperty("PlexKM.InfoLoadedRatingKey") or li.getProperty("PlexKM.Cast1.SourceRatingKey") or ""
            if not rk or loaded_key != rk:
                return False
            props = {
                "PlexType": li.getProperty("PlexKM.Type") or "",
                "Title": li.getProperty("PlexKM.Title") or "",
                "ShowTitle": li.getProperty("PlexKM.ShowTitle") or "",
                "EpisodeTitle": li.getProperty("PlexKM.EpisodeTitle") or "",
                "Season": li.getProperty("PlexKM.Season") or "",
                "Episode": li.getProperty("PlexKM.Episode") or "",
                "Summary": li.getProperty("PlexKM.Summary") or "",
                "Duration": li.getProperty("PlexKM.Duration") or "",
                "DurationText": li.getProperty("PlexKM.DurationText") or "",
                "Genre": li.getProperty("PlexKM.Genre") or "",
                "Director": li.getProperty("PlexKM.Director") or "",
                "ContentRating": li.getProperty("PlexKM.ContentRating") or "",
                "Rating": li.getProperty("PlexKM.Rating") or "",
                "Premiered": li.getProperty("PlexKM.Premiered") or "",
                "MetaLine": li.getProperty("PlexKM.MetaLine") or "",
                "CastSlots": [li.getProperty("PlexKM.Cast%d.Name" % i) for i in range(1, 9) if li.getProperty("PlexKM.Cast%d.Name" % i)],
            }
            return self._meta_props_useful(props)
        except Exception:
            return False

    def _li_movie_detail_missing_for_info(self, li):
        """True when a movie Info snapshot has only title/summary/rating but no Plex people/details.

        v1326: New/recent items can pass the startup latest-key check while
        item_people/item_genres are still empty.  In that state InfoLoaded=1
        made the background refresh skip the direct Plex metadata repair, so
        the screen opened with no cast row and no detail enrichment even though
        Plex itself had the data.
        """
        try:
            if li is None:
                return False
            plex_type = (li.getProperty("PlexKM.Type") or "").lower()
            kodi_type = (li.getProperty("PlexKM.KodiType") or "").lower()
            if plex_type != "movie" and kodi_type != "movie":
                return False
            has_people_or_detail = bool(
                li.getProperty("PlexKM.Genre") or
                li.getProperty("PlexKM.Director") or
                li.getProperty("PlexKM.Cast1.Name")
            )
            return not has_people_or_detail
        except Exception:
            return False

    def _info_media_popup_bg_color_v2209(self, alpha="F2"):
        """Return the popup fill color derived from the current Info fanart tint."""
        try:
            base = self._normalize_argb_color(
                xbmcgui.Window(10000).getProperty("PlexKM.Info.DynamicBgColor")
                or self.getProperty("PlexKM.Info.DynamicBgColor")
                or getattr(self, "_info_bg_display_color_v2140", "")
                or xbmcgui.Window(10000).getProperty("PlexKM.Home.DynamicBgColor")
                or getattr(self, "_home_bg_display_color", "")
                or getattr(self, "_home_bg_default", "FF111214")
            ) or getattr(self, "_home_bg_default", "FF111214")
            rgb = base[-6:].upper()
            alpha = str(alpha or "F2").strip().upper().replace("#", "")
            if len(alpha) == 8:
                alpha = alpha[:2]
            if len(alpha) != 2:
                alpha = "F2"
            int(alpha, 16)
            return alpha + rgb
        except Exception:
            return "F2111214"

    def _info_publish_media_popup_bg_color_v2209(self, reason=""):
        try:
            color = self._info_media_popup_bg_color_v2209()
            self._info_set_property_all("PlexKM.Info.MediaVersionPopupBgColor", color)
            self._info_set_property_all("PlexKM.Info.TVMediaVersionPopupBgColor", color)
            _log("INFO_MEDIA_VERSION_POPUP_BG_V2209 color=%s reason=%s" % (color, reason or ""))
            return color
        except Exception:
            return ""

    def _close_home_trailer_busy_dialogs(self, token, rating_key="", duration_ms=6500):
        """Suppress Kodi's global busy dialog only during trailer preview attach.

        The captured video showed the flicker is not the Home fanart layer; it is
        Kodi's busy dialog/spinner flashing while plugin.video.youtube and
        inputstream.adaptive resolve and buffer the first frames.  The Home
        videowindow is already covered by fanart, but the global busy dialog is
        drawn above the window.  Keep closing only the busy dialogs while the
        preview player is attaching, then stop the guard immediately.
        """
        try:
            start_ms = self._now_ms()
            close_count = 0
            _log("TRAILER_PREVIEW_BUSY_GUARD_START rating_key=%s duration_ms=%d" % (rating_key or "", duration_ms))
            while self._now_ms() - start_ms < int(duration_ms):
                if xbmc.Monitor().abortRequested():
                    break
                try:
                    if token != int(self._home_trailer_token):
                        break
                except Exception:
                    break
                try:
                    xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                    xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
                    close_count += 1
                except Exception:
                    pass
                try:
                    # Once the fanart cover has been released and video is visible,
                    # leave normal Kodi dialogs alone.
                    win = xbmcgui.Window(10000)
                    if (win.getProperty("PlexKM.Home.TrailerActive") == "1" and
                            win.getProperty("PlexKM.Home.TrailerFadeHold") != "1" and
                            win.getProperty("PlexKM.Home.TrailerPreparing") != "1"):
                        break
                except Exception:
                    pass
                xbmc.sleep(70)
            _log("TRAILER_PREVIEW_BUSY_GUARD_DONE rating_key=%s elapsed_ms=%d close_count=%d" % (
                rating_key or "", self._now_ms() - start_ms, close_count))
        except Exception:
            pass

    def _request_home_trailer_stop_async(self, reason="", rating_key=""):
        """Request preview player stop without blocking the Kodi focus path.

        Direct xbmc.Player().stop() can wait on inputstream.adaptive/YouTube
        network shutdown. In logs this blocked the next focus/meta update for
        ~20 seconds. PlayerControl(Stop) is queued through Kodi and returns
        immediately.

        v318: when focus changes while plugin.video.youtube is still resolving,
        PlayerControl(Stop) can run before VideoPlayer::OpenFile and therefore
        does nothing.  The delayed YouTube play then opens a player anyway and
        leaves subsequent previews stuck at player_busy.  Keep a short non-blocking
        cancel guard alive and repeatedly issue PlayerControl(Stop) until the
        queued preview launch is definitely gone.
        """
        try:
            if self._home_trailer_stop_in_progress:
                _log("TRAILER_PREVIEW_STOP_SKIP reason=%s rating_key=%s state=in_progress" % (reason or "", rating_key or ""))
                return
            self._home_trailer_stop_in_progress = True
            self._home_trailer_last_stop_ms = self._now_ms()
            try:
                self._home_trailer_cancel_until_ms = self._now_ms() + 6500
            except Exception:
                pass
            _log("TRAILER_PREVIEW_STOP_REQUEST reason=%s rating_key=%s mode=async_builtin_guard" % (reason or "", rating_key or ""))
            try:
                xbmc.executebuiltin("PlayerControl(Stop)")
            except Exception:
                pass

            def _watcher():
                try:
                    start_ms = self._now_ms()
                    stop_count = 0
                    # Keep this guard long enough to catch the delayed
                    # VideoPlayer::OpenFile that can occur after focus already moved.
                    while self._now_ms() - start_ms < 6500:
                        if xbmc.Monitor().abortRequested():
                            break
                        try:
                            # Do not block.  This closes an already-open preview and
                            # also cancels pending plugin player handoff once it appears.
                            xbmc.executebuiltin("PlayerControl(Stop)")
                            stop_count += 1
                        except Exception:
                            pass
                        try:
                            # After a short grace period, if no video is playing and
                            # no new preview preparation is visible, the stale launch
                            # was cancelled.  Do not hold the guard for the whole 6.5s.
                            if self._now_ms() - start_ms > 1800 and not xbmc.Player().isPlayingVideo():
                                win = xbmcgui.Window(10000)
                                if (win.getProperty("PlexKM.Home.TrailerPreparing") != "1" and
                                        win.getProperty("PlexKM.Home.TrailerActive") != "1"):
                                    break
                        except Exception:
                            if self._now_ms() - start_ms > 1800:
                                break
                        xbmc.sleep(180)
                    elapsed = self._now_ms() - start_ms
                    _log("TRAILER_PREVIEW_STOP_DONE reason=%s rating_key=%s elapsed_ms=%d stop_count=%d" % (reason or "", rating_key or "", elapsed, stop_count))
                except Exception:
                    pass
                try:
                    self._home_trailer_stop_in_progress = False
                    self._home_trailer_last_stop_ms = self._now_ms()
                    self._home_trailer_cancel_until_ms = 0
                except Exception:
                    pass

            t = _PKMHomeThreadV2151(target=_watcher, daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            try:
                self._home_trailer_stop_in_progress = False
                self._home_trailer_cancel_until_ms = 0
            except Exception:
                pass

    def _clear_home_trailer_preview(self, reason="", stop_player=True):
        """Cancel the delayed Home trailer preview and clear trailer UI state.

        stop_player=True is used only for preview videos we started ourselves.
        Normal movie playback is protected by _main_playback_requested and by the
        PlexKM.MainPlaybackStarting window property.
        """
        try:
            self._home_trailer_token += 1
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            win.clearProperty("PlexKM.Home.TrailerActive")
            win.clearProperty("PlexKM.Home.TrailerPreparing")
            win.clearProperty("PlexKM.Home.TrailerFadeHold")
            win.clearProperty("PlexKM.Home.TrailerRatingKey")
            win.clearProperty("PlexKM.Home.TrailerUrl")
            try:
                self.clearProperty("PlexKM.Home.TrailerActive")
                self.clearProperty("PlexKM.Home.TrailerPreparing")
                self.clearProperty("PlexKM.Home.TrailerFadeHold")
                self.clearProperty("PlexKM.Home.TrailerRatingKey")
                self.clearProperty("PlexKM.Home.TrailerUrl")
            except Exception:
                pass
        except Exception:
            pass
        try:
            should_stop = bool(stop_player and self._home_trailer_playing and not self._main_playback_requested)
            try:
                should_stop = should_stop and xbmcgui.Window(10000).getProperty("PlexKM.MainPlaybackStarting") != "1"
            except Exception:
                pass
            # v312: also send an async stop while a trailer is still starting.
            # During YouTube/inputstream startup xbmc.Player().isPlayingVideo() can
            # remain false for 1~2s; if focus moves in that window and we skip Stop,
            # the delayed playback can still surface later and cause flashes/stalls.
            if should_stop:
                self._request_home_trailer_stop_async(reason=reason, rating_key=self._home_trailer_rating_key)
        except Exception:
            pass
        self._home_trailer_playing = False
        self._home_trailer_rating_key = ""
        self._home_trailer_url = ""

    def _clean_home_trailer_title(self, title):
        try:
            text = str(title or "").strip()
            text = re.sub(r"\[[^\]]+\]", " ", text)
            text = re.sub(r"\{[^\}]+\}", " ", text)
            text = re.sub(r"\([0-9]{4}\)", " ", text)
            text = re.sub(r"\s+", " ", text)
            return text.strip()
        except Exception:
            return str(title or "").strip()

    def _find_youtube_home_trailer_url(self, title, year="", rating_key=""):
        """Return a plugin.video.youtube playable URL for the first search result.

        This is used only when Plex has no Extras/Trailer.  It avoids opening a
        YouTube directory/search window, so Home preview can still render inside
        the fanart videowindow.
        """
        if not HOME_TRAILER_ENABLE_YOUTUBE_FALLBACK:
            return ""
        try:
            if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
                _log("TRAILER_PREVIEW_YOUTUBE_SKIP reason=addon_missing rating_key=%s" % rating_key)
                return ""
        except Exception:
            pass
        clean_title = self._clean_home_trailer_title(title)
        if not clean_title:
            return ""
        try:
            query = "%s %s official trailer" % (clean_title, str(year or "").strip())
            query = re.sub(r"\s+", " ", query).strip()
            search_url = "https://www.youtube.com/results?" + urlencode({"search_query": query})
            _log("TRAILER_PREVIEW_YOUTUBE_SEARCH rating_key=%s query=%s" % (rating_key, _short_log_value(query, 120)))
            req = Request(search_url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
            })
            html = urlopen(req, timeout=8).read().decode("utf-8", "ignore")
            video_ids = re.findall(r'"videoId"\s*:\s*"([A-Za-z0-9_-]{11})"', html)
            seen = set()
            for video_id in video_ids:
                if video_id in seen:
                    continue
                seen.add(video_id)
                url = "plugin://plugin.video.youtube/play/?video_id=%s" % video_id
                _log("TRAILER_PREVIEW_YOUTUBE_HIT rating_key=%s video_id=%s query=%s" % (rating_key, video_id, _short_log_value(query, 120)))
                return url
            _log("TRAILER_PREVIEW_YOUTUBE_NONE rating_key=%s query=%s" % (rating_key, _short_log_value(query, 120)))
            return ""
        except Exception:
            _log("TRAILER_PREVIEW_YOUTUBE_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return ""

    def _find_home_trailer_url(self, rating_key, title="", year=""):
        """Return a playable trailer URL. Plex Extras first, YouTube addon fallback second."""
        rating_key = str(rating_key or "").strip()
        if not rating_key:
            return ""
        cache_key = "%s|%s|%s" % (rating_key, title or "", year or "")
        try:
            cached = self._home_trailer_lookup_cache.get(cache_key)
            if cached is not None:
                return cached
        except Exception:
            pass

        result_url = ""
        try:
            c = _ensure_core()
            roots = []
            try:
                roots.append(c.plex_request_xml(
                    "/library/metadata/%s" % rating_key,
                    params={"includeExtras": "1", "includeRelated": "1"},
                    timeout=8,
                ))
            except Exception:
                _log("TRAILER_PREVIEW_PLEX_META_FAILED rating_key=%s" % rating_key, xbmc.LOGWARNING)
            # Some PMS versions expose extras more reliably through this child endpoint.
            try:
                roots.append(c.plex_request_xml(
                    "/library/metadata/%s/extras" % rating_key,
                    timeout=8,
                ))
            except Exception:
                pass

            candidates = []
            for root in roots:
                if root is None:
                    continue
                for node in root.findall(".//Video"):
                    attrs = node.attrib
                    text = " ".join([
                        attrs.get("type", ""), attrs.get("extraType", ""),
                        attrs.get("subtype", ""), attrs.get("title", ""),
                        attrs.get("summary", ""),
                    ]).lower()
                    if ("trailer" in text or "예고" in text or attrs.get("extraType") == "1" or
                            attrs.get("type") == "trailer" or attrs.get("subtype") == "trailer"):
                        candidates.append(node)
                if not candidates:
                    for extras in root.findall(".//Extras"):
                        candidates.extend(extras.findall(".//Video"))

            for node in candidates:
                for part in node.findall(".//Part"):
                    part_key = part.attrib.get("key") or ""
                    if part_key:
                        result_url = c.plex_url(part_key, include_token=True)
                        _log("TRAILER_PREVIEW_PLEX_HIT rating_key=%s part=%s" % (rating_key, _short_log_value(part_key, 120)))
                        break
                if result_url:
                    break
                # Some PMS responses expose only an extra Video key first.
                video_key = node.attrib.get("key") or ""
                if video_key:
                    try:
                        detail_root = c.plex_request_xml(video_key, timeout=8)
                        for detail in detail_root.findall(".//Part"):
                            part_key = detail.attrib.get("key") or ""
                            if part_key:
                                result_url = c.plex_url(part_key, include_token=True)
                                _log("TRAILER_PREVIEW_PLEX_DETAIL_HIT rating_key=%s key=%s part=%s" % (rating_key, video_key, _short_log_value(part_key, 120)))
                                break
                    except Exception:
                        _log("TRAILER_PREVIEW_DETAIL_FAILED rating_key=%s key=%s" % (rating_key, video_key), xbmc.LOGWARNING)
                if result_url:
                    break

            if not result_url:
                _log("TRAILER_PREVIEW_PLEX_NONE rating_key=%s candidates=%d" % (rating_key, len(candidates)))
                result_url = self._find_youtube_home_trailer_url(title, year=year, rating_key=rating_key)

            try:
                self._home_trailer_lookup_cache[cache_key] = result_url or ""
                if len(self._home_trailer_lookup_cache) > 120:
                    self._home_trailer_lookup_cache.clear()
            except Exception:
                pass
            return result_url or ""
        except Exception:
            _log("TRAILER_PREVIEW_LOOKUP_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return ""

    def _schedule_home_trailer_preview(self, li=None, reason=""):
        """Start a Home fanart-area trailer preview after 3s of stable focus."""
        try:
            if HOME_TRAILER_TEMP_DISABLED:
                # v1243: block all automatic PKM Home trailer playback for now.
                # Keep fanart/metadata static and clear any stale trailer window/player state.
                self._clear_home_trailer_preview(reason=(reason or "") + ":temporarily_disabled_v1243", stop_player=True)
                _log("TRAILER_PREVIEW_SKIP reason=temporarily_disabled_v1243 request_reason=%s" % (reason or ""))
                return
            if li is None:
                li = self._focused_wall_item()
            if li is None:
                self._clear_home_trailer_preview(reason=(reason or "") + ":no_item", stop_player=True)
                return
            plex_type = li.getProperty("PlexKM.Type") or ""
            rating_key = li.getProperty("PlexKM.RatingKey") or ""
            title = li.getProperty("PlexKM.Title") or li.getLabel() or ""
            year = li.getProperty("PlexKM.Year") or ""
            if plex_type != "movie" or not rating_key:
                self._clear_home_trailer_preview(reason=(reason or "") + ":not_movie", stop_player=True)
                return

            self._clear_home_trailer_preview(reason=(reason or "") + ":reschedule", stop_player=True)
            self._home_trailer_token += 1
            token = int(self._home_trailer_token)

            def _worker():
                try:
                    xbmc.sleep(int(HOME_TRAILER_FOCUS_DELAY_MS))
                    if token != int(self._home_trailer_token):
                        return
                    if xbmc.Monitor().abortRequested():
                        return
                    try:
                        fid = self._safe_focus_id()
                    except Exception:
                        fid = -1
                    if not (fid == WALL_ID or self._is_home_row_control(fid)):
                        return
                    focused = self._focused_wall_item()
                    focused_key = focused.getProperty("PlexKM.RatingKey") if focused else ""
                    focused_type = focused.getProperty("PlexKM.Type") if focused else ""
                    self._li_release_r118(focused)  # R118c: worker never drops a card ref
                    focused = None
                    if focused_key != rating_key or focused_type != "movie":
                        return
                    # v311: if a previous preview is still being stopped, do not start
                    # a new YouTube/inputstream preview on top of it. This keeps focus
                    # movement responsive and avoids cascading player shutdown delays.
                    for _wait_i in range(50):
                        if token != int(self._home_trailer_token):
                            return
                        if not getattr(self, "_home_trailer_stop_in_progress", False):
                            break
                        xbmc.sleep(100)
                    if getattr(self, "_home_trailer_stop_in_progress", False):
                        _log("TRAILER_PREVIEW_SKIP reason=stop_in_progress rating_key=%s" % rating_key)
                        return
                    try:
                        if xbmc.Player().isPlayingVideo() and not self._home_trailer_playing:
                            # v318: a cancelled preview may still open after focus moved
                            # because YouTube/inputstream handoff is delayed.  Do not
                            # leave future previews permanently skipped; request a
                            # non-blocking stop and retry on the next stable focus.
                            _log("TRAILER_PREVIEW_SKIP reason=player_busy_stop_stale rating_key=%s" % rating_key)
                            self._request_home_trailer_stop_async(reason="player_busy_stale", rating_key=rating_key)
                            return
                    except Exception:
                        pass
                    url = self._find_home_trailer_url(rating_key, title=title, year=year)
                    if token != int(self._home_trailer_token):
                        return
                    if not url:
                        _log("TRAILER_PREVIEW_NONE rating_key=%s title=%s" % (rating_key, _short_log_value(title, 100)))
                        return
                    item = xbmcgui.ListItem(label=(title or "Trailer"))
                    try:
                        item.setProperty("IsPlayable", "true")
                        item.setProperty("PlexKM.HomeTrailerPreview", "1")
                        item.setProperty("PlexKM.RatingKey", str(rating_key or ""))
                    except Exception:
                        pass
                    # v313: bring up the hidden Home videowindow surface behind the
                    # still-visible fanart before starting YouTube/inputstream. Kodi
                    # otherwise has to attach the video surface at the same moment the
                    # fanart is hidden, which causes several black/white flashes.
                    try:
                        win = xbmcgui.Window(10000)
                        win.setProperty("PlexKM.Home.TrailerPreparing", "1")
                        win.clearProperty("PlexKM.Home.TrailerActive")
                        win.clearProperty("PlexKM.Home.TrailerFadeHold")
                        try:
                            self.setProperty("PlexKM.Home.TrailerPreparing", "1")
                            self.clearProperty("PlexKM.Home.TrailerActive")
                            self.clearProperty("PlexKM.Home.TrailerFadeHold")
                        except Exception:
                            pass
                    except Exception:
                        pass
                    _log("TRAILER_PREVIEW_PREPARE_SURFACE rating_key=%s fanart=keep" % rating_key)
                    self._home_trailer_rating_key = rating_key
                    self._home_trailer_url = url
                    self._home_trailer_playing = True
                    try:
                        bg = _PKMHomeThreadV2151(target=self._close_home_trailer_busy_dialogs, args=(token, rating_key, 6500), daemon=True)
                        bg.daemon = True
                        bg.start()
                    except Exception:
                        pass
                    _log("TRAILER_PREVIEW_PLAY_REQUEST rating_key=%s title=%s delay_ms=%d mode=windowed publish=after_playing busy_guard=1" % (rating_key, _short_log_value(title, 100), HOME_TRAILER_FOCUS_DELAY_MS))
                    try:
                        # v309: windowed=True keeps playback bound to Home videowindow
                        # instead of opening VideoFullScreen.xml.
                        # Trailer-only path. NATIVE PLAYBACK LOCK v1454:
                        # do not copy this xbmc.Player().play() usage to
                        # movie/episode Info playback. Main playback must use
                        # PlayMedia(plugin://...action=play...) + setResolvedUrl.
                        xbmc.Player().play(url, item, windowed=True)
                        _log("TRAILER_PREVIEW_WINDOWED_PLAY_REQUEST rating_key=%s api=keyword" % rating_key)
                    except TypeError:
                        try:
                            # Trailer-only fallback. NATIVE PLAYBACK LOCK v1454:
                            # never use this for movie/episode playback.
                            xbmc.Player().play(url, item, True)
                            _log("TRAILER_PREVIEW_WINDOWED_PLAY_REQUEST rating_key=%s api=positional" % rating_key)
                        except Exception:
                            raise

                    started = False
                    start_wait_ms = self._now_ms()
                    for _start_i in range(90):
                        if token != int(self._home_trailer_token):
                            _log("TRAILER_PREVIEW_START_CANCELLED rating_key=%s stage=before_visible" % rating_key)
                            self._request_home_trailer_stop_async(reason="start_cancelled_before_visible", rating_key=rating_key)
                            return
                        if xbmc.Monitor().abortRequested():
                            self._request_home_trailer_stop_async(reason="abort_before_visible", rating_key=rating_key)
                            return
                        try:
                            if xbmc.Player().isPlayingVideo():
                                started = True
                                break
                        except Exception:
                            pass
                        xbmc.sleep(100)
                    if not started:
                        self._home_trailer_playing = False
                        _log("TRAILER_PREVIEW_START_TIMEOUT rating_key=%s elapsed_ms=%d" % (rating_key, self._now_ms() - start_wait_ms), xbmc.LOGWARNING)
                        self._request_home_trailer_stop_async(reason="start_timeout", rating_key=rating_key)
                        return

                    if token != int(self._home_trailer_token):
                        _log("TRAILER_PREVIEW_START_CANCELLED rating_key=%s stage=after_playing_before_visible" % rating_key)
                        self._request_home_trailer_stop_async(reason="start_cancelled_after_playing", rating_key=rating_key)
                        return

                    # Even after isPlayingVideo() becomes true, the first decoded
                    # frames can still be black while DXVA/inputstream settles. Keep
                    # fanart above the already-prepared videowindow for a short overlap,
                    # then fade the fanart out. This removes the visible pre-play flicker.
                    xbmc.sleep(220)
                    try:
                        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
                    except Exception:
                        pass
                    if token != int(self._home_trailer_token):
                        _log("TRAILER_PREVIEW_START_CANCELLED rating_key=%s stage=after_ready_hold" % rating_key)
                        self._request_home_trailer_stop_async(reason="start_cancelled_after_ready_hold", rating_key=rating_key)
                        return
                    win = xbmcgui.Window(10000)
                    win.setProperty("PlexKM.Home.TrailerActive", "1")
                    win.setProperty("PlexKM.Home.TrailerPreparing", "1")
                    win.setProperty("PlexKM.Home.TrailerFadeHold", "1")
                    win.setProperty("PlexKM.Home.TrailerRatingKey", str(rating_key or ""))
                    win.setProperty("PlexKM.Home.TrailerUrl", url)
                    try:
                        self.setProperty("PlexKM.Home.TrailerActive", "1")
                        self.setProperty("PlexKM.Home.TrailerPreparing", "1")
                        self.setProperty("PlexKM.Home.TrailerFadeHold", "1")
                        self.setProperty("PlexKM.Home.TrailerRatingKey", str(rating_key or ""))
                        self.setProperty("PlexKM.Home.TrailerUrl", url)
                    except Exception:
                        pass
                    _log("TRAILER_PREVIEW_VISIBLE rating_key=%s startup_ms=%d transition=fanart_quick_crossfade" % (rating_key, self._now_ms() - start_wait_ms))

                    def _release_fanart_cover(expected_token, expected_key):
                        try:
                            xbmc.sleep(180)
                            if expected_token != int(self._home_trailer_token):
                                return
                            win2 = xbmcgui.Window(10000)
                            if win2.getProperty("PlexKM.Home.TrailerRatingKey") != str(expected_key or ""):
                                return
                            win2.clearProperty("PlexKM.Home.TrailerFadeHold")
                            win2.clearProperty("PlexKM.Home.TrailerPreparing")
                            try:
                                self.clearProperty("PlexKM.Home.TrailerFadeHold")
                                self.clearProperty("PlexKM.Home.TrailerPreparing")
                            except Exception:
                                pass
                            _log("TRAILER_PREVIEW_FANART_RELEASE rating_key=%s" % expected_key)
                        except Exception:
                            pass

                    try:
                        rt = _PKMHomeThreadV2151(target=_release_fanart_cover, args=(token, rating_key), daemon=True)
                        rt.daemon = True
                        rt.start()
                    except Exception:
                        pass
                    self._restore_home_trailer_preview_window(token, rating_key)
                except Exception:
                    _log("TRAILER_PREVIEW_WORKER_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            _log("TRAILER_PREVIEW_SCHEDULE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)


    def _restore_home_trailer_preview_window(self, token, rating_key):
        """Keep Home visible so the playing preview renders in the Home videowindow.

        v309: playback is requested with windowed=True.  This guard remains only
        as a safety net for add-ons/players that still force fullscreenvideo.
        If fullscreen appears, use Back, not FullScreen toggle: Back returns to
        the previous WindowXML while playback continues, so the Home videowindow
        can own the video surface.
        """
        try:
            saw_playing = False
            for _i in range(60):
                if token != int(self._home_trailer_token):
                    return
                if xbmc.Monitor().abortRequested():
                    return
                xbmc.sleep(120)
                try:
                    if not xbmc.Player().isPlayingVideo():
                        continue
                    saw_playing = True
                except Exception:
                    continue
                try:
                    if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                        xbmc.executebuiltin("Action(Back)")
                        xbmc.sleep(180)
                        if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                            xbmc.executebuiltin("Dialog.Close(fullscreenvideo,true)")
                            xbmc.sleep(80)
                        _log("TRAILER_PREVIEW_WINDOW_RESTORE rating_key=%s method=back_from_fullscreen" % rating_key)
                        continue
                    try:
                        active_id = xbmcgui.getCurrentWindowId()
                    except Exception:
                        active_id = -1
                    _log("TRAILER_PREVIEW_WINDOW_OK rating_key=%s active_window=%s" % (rating_key, active_id))
                    return
                except Exception:
                    pass
            if saw_playing:
                _log("TRAILER_PREVIEW_WINDOW_GUARD_TIMEOUT rating_key=%s" % rating_key, xbmc.LOGWARNING)
        except Exception:
            _log("TRAILER_PREVIEW_WINDOW_RESTORE_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _format_cine21_rating_value(self, value):
        try:
            if value is None:
                return ""
            s = str(value).strip()
            if not s:
                return ""
            f = float(s)
            if f <= 0:
                return ""
            # Cine21 values are usually one or two decimals. Keep compact for the Home meta row.
            return ("%.2f" % f).rstrip("0").rstrip(".")
        except Exception:
            return ""

    def _info_watcha_point_props_v2627(self, rating_key, title="", original_title="", year=""):
        """Exact current-item Watcha lookup for Info first paint.

        Never bulk-load the full watcha_ratings table on a click.  Reuse an
        already-populated cache first, then perform one bounded local SQLite point
        lookup by rating_key with exact title/year fallback.  No network is used.
        """
        empty = {"Rating": "", "Count": "", "Display": ""}
        started = time.time()
        try:
            rk = str(rating_key or "").strip()
            t = str(title or "").strip()
            ot = str(original_title or "").strip()
            y = str(year or "").strip()
            cached = self._home_watcha_cache_only_v2386(rk, title=t, original_title=ot, year=y)
            if isinstance(cached, dict) and (cached.get("Rating") or cached.get("Display")):
                _log("INFO_WATCHA_POINT_V2627 rating_key=%s source=cache elapsed_ms=%.1f" % (rk, (time.time()-started)*1000.0))
                return cached
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return empty
            conn = _pkm_ro_connect(dbp, timeout=0.35)
            try:
                if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='watcha_ratings' LIMIT 1").fetchone():
                    return empty
                rr = None
                if rk:
                    rr = conn.execute(
                        "SELECT watcha_rating,watcha_count FROM watcha_ratings WHERE rating_key=? AND watcha_rating IS NOT NULL ORDER BY COALESCE(updated_at,'') DESC LIMIT 1",
                        (rk,)
                    ).fetchone()
                if rr is None and y and (t or ot):
                    names = [x for x in (t, ot) if x]
                    if names:
                        clauses = []
                        args = [y]
                        for name in names:
                            clauses.append("(title=? COLLATE NOCASE OR original_title=? COLLATE NOCASE OR watcha_title=? COLLATE NOCASE)")
                            args.extend([name, name, name])
                        rr = conn.execute(
                            "SELECT watcha_rating,watcha_count FROM watcha_ratings WHERE CAST(COALESCE(year,'') AS TEXT)=? AND watcha_rating IS NOT NULL AND (" + " OR ".join(clauses) + ") ORDER BY COALESCE(updated_at,'') DESC LIMIT 1",
                            tuple(args)
                        ).fetchone()
            finally:
                conn.close()
            if not rr:
                _log("INFO_WATCHA_POINT_V2627 rating_key=%s source=miss elapsed_ms=%.1f" % (rk, (time.time()-started)*1000.0))
                return empty
            rating = self._format_watcha_rating_value(rr[0] if len(rr)>0 else "")
            count = self._format_watcha_count_value(rr[1] if len(rr)>1 else "")
            display = "%s(%s)" % (rating, count) if rating and count else rating
            result = {"Rating": rating, "Count": count, "Display": display}
            _log("INFO_WATCHA_POINT_V2627 rating_key=%s source=sqlite rating=%s elapsed_ms=%.1f" % (rk, rating or "-", (time.time()-started)*1000.0))
            return result
        except Exception:
            _log("INFO_WATCHA_POINT_V2627 rating_key=%s source=error elapsed_ms=%.1f" % (str(rating_key or ""), (time.time()-started)*1000.0), xbmc.LOGWARNING)
            return empty

    def _home_cine21_rating_props(self, rating_key, title="", original_title="", year=""):
        """Return local Cine21 score strings for the focused Home/Info item.

        DB-only lookup. v928 also allows an exact title/year fallback so the same
        movie can show the same Cine21 score even when Plex exposes it with a
        different rating_key in Continue Watching vs Home/recent rows.
        """
        try:
            rk = str(rating_key or "").strip()
            title = str(title or "").strip()
            original_title = str(original_title or "").strip()
            year = str(year or "").strip()
            if not rk and not title:
                return {"CriticRating": "", "AudienceRating": ""}
            cache_key = "|".join((rk, title, original_title, year))
            cache = getattr(self, "_home_cine21_cache", {}) or {}
            result = {"CriticRating": "", "AudienceRating": ""}
            _cine21_start = time.time()
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                # Do not let an empty no-db result become a long-lived stale cache.
                self._home_cine21_db_mtime = None
                try:
                    _log("CINE21_TIMING source=no_db rating_key=%s db=%s elapsed=%.1fms" % (rk, dbp or "", (time.time() - _cine21_start) * 1000.0), xbmc.LOGWARNING)
                except Exception:
                    pass
                return result
            try:
                db_mtime = os.path.getmtime(dbp)
            except Exception:
                db_mtime = 0
            try:
                last_mtime = getattr(self, "_home_cine21_db_mtime", None)
                if last_mtime is None or float(last_mtime) != float(db_mtime):
                    cache = {}
                    self._home_cine21_cache = cache
                    self._home_cine21_db_mtime = db_mtime
            except Exception:
                cache = {}
                self._home_cine21_cache = cache
                self._home_cine21_db_mtime = db_mtime
            # v929: only trust memory cache after checking DB mtime.  v928 returned
            # stale empty memory values for same-title/different-rating_key rows
            # such as Home recommend/library 마이클 while Continue already had a
            # fresh MATCHED row in cine21_matches.
            if cache_key in cache:
                cached_result = cache.get(cache_key) or {"CriticRating": "", "AudienceRating": ""}
                # v939: never let an empty Cine21 memory entry block a real DB lookup.
                # Empty results can be created before cine21_ratings.db import/match finishes;
                # after the DB is populated, existing movies must immediately read DB values.
                if cached_result.get("CriticRating") or cached_result.get("AudienceRating"):
                    try:
                        _log("CINE21_TIMING source=memory_after_mtime rating_key=%s title=%s critic=%s audience=%s elapsed=%.1fms" % (
                            rk, _short_log_value(title, 60), cached_result.get("CriticRating", ""), cached_result.get("AudienceRating", ""), (time.time() - _cine21_start) * 1000.0
                        ))
                    except Exception:
                        pass
                    return cached_result
                try:
                    cache.pop(cache_key, None)
                except Exception:
                    pass
            row = None
            source = "none"
            try:
                _cine21_sql_start = time.time()
                conn = _pkm_ro_connect(dbp, timeout=5.0)
                try:
                    if rk:
                        row = conn.execute(
                            """
                            SELECT critic_rating, audience_rating, match_status, pkm_quality_status, rating_key
                            FROM cine21_matches
                            WHERE rating_key=?
                            LIMIT 1
                            """,
                            (rk,),
                        ).fetchone()
                        if row:
                            source = "rating_key"
                            # v930: a direct rating_key row can exist with empty Cine21
                            # scores (e.g. duplicate Plex key for the same movie).
                            # Do not stop there; fall through to exact title/year
                            # fallback so Home, section widgets, and Info all reuse
                            # the populated MATCHED row for the same movie.
                            _direct_critic = self._format_cine21_rating_value(row[0])
                            _direct_audience = self._format_cine21_rating_value(row[1])
                            _direct_status = str(row[2] or "").strip()
                            _direct_quality = str(row[3] or "").strip()
                            if not (_direct_status == "MATCHED" and _direct_quality in ("", "PKM_METADATA_OK") and (_direct_critic or _direct_audience)):
                                row = None
                                source = "rating_key_empty"
                    if not row and title and year:
                        row = conn.execute(
                            """
                            SELECT critic_rating, audience_rating, match_status, pkm_quality_status, rating_key
                            FROM cine21_matches
                            WHERE match_status='MATCHED'
                              AND COALESCE(pkm_quality_status,'') IN ('', 'PKM_METADATA_OK')
                              AND CAST(COALESCE(pkm_year,'') AS TEXT)=?
                              AND (pkm_title=? OR pkm_original_title=? OR cine21_title=? OR pkm_title=? OR pkm_original_title=?)
                              AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
                            ORDER BY updated_at DESC
                            LIMIT 1
                            """,
                            (year, title, title, title, original_title, original_title),
                        ).fetchone()
                        if row:
                            source = "title_year"
                finally:
                    conn.close()
            except Exception:
                row = None
                try:
                    _log("CINE21_TIMING source=db_error rating_key=%s elapsed=%.1fms" % (rk, (time.time() - _cine21_start) * 1000.0), xbmc.LOGWARNING)
                except Exception:
                    pass
            if row:
                status = str(row[2] or "").strip()
                quality = str(row[3] or "").strip()
                if status == "MATCHED" and quality in ("", "PKM_METADATA_OK"):
                    result = {
                        "CriticRating": self._format_cine21_rating_value(row[0]),
                        "AudienceRating": self._format_cine21_rating_value(row[1]),
                    }
            if len(cache) > 600:
                try:
                    cache.clear()
                except Exception:
                    cache = {}
            # v939: cache only positive Cine21 values.  A DB miss/empty row must not
            # hide newly imported or newly matched Cine21 rows later in the same run.
            if result.get("CriticRating") or result.get("AudienceRating"):
                cache[cache_key] = result
            else:
                try:
                    cache.pop(cache_key, None)
                except Exception:
                    pass
            self._home_cine21_cache = cache
            try:
                _log("CINE21_TIMING source=db/%s rating_key=%s matched_key=%s row=%s critic=%s audience=%s total_elapsed=%.1fms sql_elapsed=%.1fms" % (
                    source, rk, str(row[4] if row else ""), "1" if row else "0", result.get("CriticRating", ""), result.get("AudienceRating", ""),
                    (time.time() - _cine21_start) * 1000.0, (time.time() - _cine21_sql_start) * 1000.0 if '_cine21_sql_start' in locals() else -1.0
                ))
            except Exception:
                pass
            return result
        except Exception:
            try:
                _log("CINE21_TIMING source=exception rating_key=%s err=%s" % (str(rating_key or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return {"CriticRating": "", "AudienceRating": ""}

    def _home_cine21_preload_props(self, rating_key, title="", original_title="", year=""):
        """Return Cine21 ratings from a DB-only bulk preload cache.

        v943: visible Home/section row ListItems should already carry Cine21
        properties before the row becomes focusable/visible.  This function
        loads positive cine21_matches rows once per plex_km.db mtime into small
        in-memory maps and then answers by rating_key or title/year without
        additional SQL per focus move.  It never crawls the web.
        """
        try:
            rk = str(rating_key or "").strip()
            t = str(title or "").strip()
            ot = str(original_title or "").strip()
            y = str(year or "").strip()
            if not rk and not t:
                return {"CriticRating": "", "AudienceRating": ""}
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return {"CriticRating": "", "AudienceRating": ""}
            try:
                db_mtime = os.path.getmtime(dbp)
            except Exception:
                db_mtime = 0
            cache = getattr(self, "_home_cine21_preload_cache", None)
            cache_mtime = getattr(self, "_home_cine21_preload_cache_mtime", None)
            cache_loaded_at = float(getattr(self, "_home_cine21_preload_cache_loaded_at", 0.0) or 0.0)
            cache_age = time.time() - cache_loaded_at if cache_loaded_at > 0 else 999999.0
            # v944: DB mtime can change repeatedly during startup sync/Cine21 duplicate
            # propagation.  Do not reload the full 8k+ Cine21 map for every visible
            # ListItem while the panel is being built; that was visible as repeated
            # 60~200ms UI-thread pauses in the log.  Keep the current bulk cache for a
            # short stability window and refresh it later, not between poster builds.
            need_reload = (not isinstance(cache, dict)) or cache_mtime is None or not cache
            if (not need_reload) and float(cache_mtime) != float(db_mtime) and cache_age >= 30.0:
                need_reload = True
            if need_reload:
                started = time.time()
                by_rk = {}
                by_ty = {}
                row_count = 0
                conn = _pkm_ro_connect(dbp, timeout=5.0)
                try:
                    rows = conn.execute("""
                        SELECT rating_key, pkm_title, pkm_original_title, cine21_title, pkm_year,
                               critic_rating, audience_rating, updated_at
                        FROM cine21_matches
                        WHERE match_status='MATCHED'
                          AND COALESCE(pkm_quality_status,'') IN ('', 'PKM_METADATA_OK')
                          AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
                        ORDER BY COALESCE(updated_at, 0) DESC
                    """).fetchall()
                finally:
                    conn.close()
                for rr in rows:
                    critic = self._format_cine21_rating_value(rr[5] if len(rr) > 5 else "")
                    audience = self._format_cine21_rating_value(rr[6] if len(rr) > 6 else "")
                    if not (critic or audience):
                        continue
                    result = {"CriticRating": critic, "AudienceRating": audience}
                    key = str(rr[0] or "").strip()
                    if key and key not in by_rk:
                        by_rk[key] = result
                    yy = str(rr[4] or "").strip()
                    if yy:
                        for name in (rr[1] if len(rr) > 1 else "", rr[2] if len(rr) > 2 else "", rr[3] if len(rr) > 3 else ""):
                            name_s = str(name or "").strip()
                            if name_s:
                                ty = (name_s, yy)
                                if ty not in by_ty:
                                    by_ty[ty] = result
                    row_count += 1
                cache = {"by_rk": by_rk, "by_ty": by_ty}
                self._home_cine21_preload_cache = cache
                self._home_cine21_preload_cache_mtime = db_mtime
                self._home_cine21_preload_cache_loaded_at = time.time()
                try:
                    _log("CINE21_PRELOAD source=db_bulk rows=%d by_rk=%d by_title_year=%d elapsed=%.1fms" % (
                        row_count, len(by_rk), len(by_ty), (time.time() - started) * 1000.0
                    ))
                except Exception:
                    pass
            by_rk = cache.get("by_rk", {}) if isinstance(cache, dict) else {}
            by_ty = cache.get("by_ty", {}) if isinstance(cache, dict) else {}
            if rk and rk in by_rk:
                return by_rk.get(rk) or {"CriticRating": "", "AudienceRating": ""}
            if y:
                for name in (t, ot):
                    name_s = str(name or "").strip()
                    if name_s:
                        res = by_ty.get((name_s, y))
                        if res:
                            return res
            return {"CriticRating": "", "AudienceRating": ""}
        except Exception:
            try:
                _log("CINE21_PRELOAD source=db_error rating_key=%s err=%s" % (str(rating_key or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return {"CriticRating": "", "AudienceRating": ""}

    def _home_cine21_bar_display(self, cine21_props=None):
        """Return only Cine21 score text; the XML supplies the existing logo image."""
        try:
            cine21_props = cine21_props if isinstance(cine21_props, dict) else {}

            def _clean(value):
                text = str(value or "").strip()
                return "" if text in ("...", "…", "-", "--") else text

            bits = []
            critic = _clean(cine21_props.get("CriticRating"))
            audience = _clean(cine21_props.get("AudienceRating"))
            # v1592: keep labels neutral and render only the numeric scores in gold.
            def _gold_score(value):
                return "[COLOR FFD4AF37]%s[/COLOR]" % value

            if critic:
                bits.extend(("전문가", _gold_score(critic)))
            if audience:
                bits.extend(("관객", _gold_score(audience)))
            return "  ".join(bits)
        except Exception:
            return ""

    def _home_visible_cine21_rating_props(self, rating_key, title="", original_title="", year=""):
        try:
            result = {"CriticRating": "", "AudienceRating": ""}
            cache = getattr(self, "_home_visible_cine21_rating_cache", None)
            if not isinstance(cache, dict):
                return result
            by_rk = cache.get("by_rk", {}) or {}
            by_ty = cache.get("by_ty", {}) or {}
            rk = str(rating_key or "").strip()
            if rk and rk in by_rk:
                return by_rk.get(rk) or result
            y = str(year or "").strip()
            if y:
                for name in (title, original_title):
                    name_s = str(name or "").strip()
                    if not name_s:
                        continue
                    res = by_ty.get((name_s, y))
                    if res:
                        return res
            return result
        except Exception:
            return {"CriticRating": "", "AudienceRating": ""}

    def _home_cine21_cache_only_v2386(self, rating_key, title="", original_title="", year=""):
        empty = {"CriticRating": "", "AudienceRating": ""}
        try:
            rk = str(rating_key or "").strip()
            t = str(title or "").strip()
            ot = str(original_title or "").strip()
            y = str(year or "").strip()
            result = self._home_visible_cine21_rating_props(rk, title=t, original_title=ot, year=y)
            if result.get("CriticRating") or result.get("AudienceRating"):
                return result
            cache = getattr(self, "_home_cine21_preload_cache", None)
            if isinstance(cache, dict):
                by_rk = cache.get("by_rk", {}) or {}
                by_ty = cache.get("by_ty", {}) or {}
                if rk and rk in by_rk:
                    return by_rk.get(rk) or empty
                if y:
                    for name in (t, ot):
                        if name and (name, y) in by_ty:
                            return by_ty.get((name, y)) or empty
            # Positive exact-result memo only. Do not inspect DB mtime here.
            exact_cache = getattr(self, "_home_cine21_cache", None)
            if isinstance(exact_cache, dict):
                exact = exact_cache.get("|".join((rk, t, ot, y)))
                if isinstance(exact, dict) and (exact.get("CriticRating") or exact.get("AudienceRating")):
                    return exact
        except Exception:
            pass
        return empty

    def _uhd_kpi_proxy_v2605(self):
        """V2613: reduced U+/Android runtime policy.

        Desktop diagnostics are reference/measurement only and MUST NOT change
        functional behavior.  An explicit developer-only runtime proxy can still
        be enabled with PlexKM.Diag.EnableRuntimeProxyV2613=1, but diagnostics do
        not set it automatically.
        """
        try:
            if self._is_android_v2591():
                return True
            win = xbmcgui.Window(10000)
            return win.getProperty("PlexKM.Diag.EnableRuntimeProxyV2613") == "1"
        except Exception:
            return False

    def _uhd3_foreground_isolation_active_v2591(self):
        """Data/render decoration guard only; never consumes or delays user input."""
        try:
            if not self._is_android_v2591():
                return False
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Home.StartupReadyV1619") != "1":
                return True
            if win.getProperty("PlexKM.Sidebar.Browsing") == "1":
                return True
            if win.getProperty("PlexKM.WallRapidScrollV2581") == "1":
                return True
            until_epoch = int(float(win.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
            if until_epoch and int(time.time() * 1000) < until_epoch:
                return True
        except Exception:
            return False
        return False

    def _save_inline_info_playback_return_state(self, li):
        """Save the current inline Info item before playback starts.

        v583: Kodi may call onInit again after VideoPlayer closes.  The standard
        Home bootstrap then rebuilds rows and clears PlexKM.Info.InlineActive.
        Keeping a small property snapshot lets us reconstruct the same inline
        episode page instead of falling back to skin/Home or a blank Home state.
        """
        try:
            if not li:
                return
            win = xbmcgui.Window(10000)
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            win.setProperty("PlexKM.Playback.ReturnInline.Pending", "1")
            win.setProperty("PlexKM.Playback.ReturnInline.SavedAt", str(now_ms))
            mapping = {
                "Type": "Type", "RatingKey": "RatingKey", "SectionId": "SectionId", "PartKey": "PartKey",
                "PlayUrl": "PlayUrl", "ParentRatingKey": "ParentRatingKey", "GrandparentRatingKey": "GrandparentRatingKey",
                "Season": "Season", "Episode": "Episode", "Title": "Title", "ShowTitle": "ShowTitle",
                "Thumb": "Thumb", "Art": "Art", "Summary": "Summary", "SummaryDisplay": "SummaryDisplay",
                "Year": "Year", "Duration": "Duration", "DurationText": "DurationText", "ViewOffset": "ViewOffset",
                "PlayButtonLabel": "PlayButtonLabel", "RemainingText": "RemainingText", "RemainingIcon": "RemainingIcon",
            }
            for dst, src in mapping.items():
                val = ""
                try:
                    val = li.getProperty("PlexKM.%s" % src) or win.getProperty("PlexKM.Info.%s" % src) or ""
                except Exception:
                    val = ""
                if dst == "Title" and not val:
                    try:
                        val = li.getLabel() or ""
                    except Exception:
                        val = ""
                try:
                    win.setProperty("PlexKM.Playback.ReturnInline.%s" % dst, str(val or ""))
                except Exception:
                    pass
            try:
                # R38: remember the Info tint shown before playback so the return
                # restores exactly that colour instead of re-probing the fanart
                # (Shield Info is grey by policy; the probe turned it brown 350 ms
                # after the return and leaked that tint into Home -> visible blink).
                win.setProperty("PlexKM.Playback.ReturnInline.InfoBgColorR38", str(
                    win.getProperty("PlexKM.Info.DynamicBgColor") or getattr(self, "_info_bg_display_color_v2140", "") or ""
                ))
            except Exception:
                pass
            try:
                win.setProperty("PlexKM.Playback.ReturnInline.OriginFocusId", str(getattr(self, "_inline_info_origin_focus_id", "") or ""))
                win.setProperty("PlexKM.Playback.ReturnInline.OriginPos", str(getattr(self, "_inline_info_origin_pos", "") or ""))
                win.setProperty("PlexKM.Playback.ReturnInline.OriginRatingKey", str(getattr(self, "_inline_info_origin_rating_key", "") or ""))
            except Exception:
                pass
            _log("INLINE_PLAYBACK_RETURN_SAVE rating_key=%s type=%s section=%s show=%s" % (
                win.getProperty("PlexKM.Playback.ReturnInline.RatingKey"),
                win.getProperty("PlexKM.Playback.ReturnInline.Type"),
                win.getProperty("PlexKM.Playback.ReturnInline.SectionId"),
                win.getProperty("PlexKM.Playback.ReturnInline.GrandparentRatingKey"),
            ))
        except Exception:
            _log("INLINE_PLAYBACK_RETURN_SAVE_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _clear_inline_info_playback_return_state(self, reason=""):
        try:
            win = xbmcgui.Window(10000)
            for key in self._inline_playback_return_keys():
                try:
                    win.clearProperty("PlexKM.Playback.ReturnInline.%s" % key)
                except Exception:
                    pass
            try:
                win.clearProperty("PlexKM.Playback.BackStopRequested")
            except Exception:
                pass
            _log("INLINE_PLAYBACK_RETURN_CLEAR reason=%s" % (reason or ""))
        except Exception:
            pass

    def _restore_inline_info_after_playback_return(self, reason=""):
        """Restore the saved Info page after native playback without a blank TV shell.

        v1884 routes this path through the same global busy broker and composes the
        inactive TV A/B rail before publishing InlineActive. The prior completed
        Home/Info surface therefore remains visible until the return target is ready.
        """
        _busy_token_v1884 = ""
        _transition_token_v1884 = ""
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Playback.ReturnInline.Pending") != "1":
                return False
            try:
                back_stop_requested = win.getProperty("PlexKM.Playback.BackStopRequested") == "1"
            except Exception:
                back_stop_requested = False
            try:
                is_playing_video = bool(xbmc.Player().isPlayingVideo())
            except Exception:
                is_playing_video = False
            try:
                has_video = bool(xbmc.getCondVisibility("Player.HasVideo"))
            except Exception:
                has_video = False
            if is_playing_video or (has_video and not back_stop_requested):
                _log("INLINE_PLAYBACK_RETURN_RESTORE_SKIP reason=video_active trigger=%s playing=%s has_video=%s back_stop=%s" % (reason or "", "1" if is_playing_video else "0", "1" if has_video else "0", "1" if back_stop_requested else "0"))
                return False
            saved_at = _safe_int(win.getProperty("PlexKM.Playback.ReturnInline.SavedAt"), 0)
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            if saved_at and (now_ms - saved_at) > 6 * 60 * 60 * 1000:
                self._clear_inline_info_playback_return_state(reason="expired")
                return False

            rating_key = win.getProperty("PlexKM.Playback.ReturnInline.RatingKey") or ""
            plex_type = win.getProperty("PlexKM.Playback.ReturnInline.Type") or ""
            section_id = win.getProperty("PlexKM.Playback.ReturnInline.SectionId") or ""
            show_key = win.getProperty("PlexKM.Playback.ReturnInline.GrandparentRatingKey") or win.getProperty("PlexKM.Playback.ReturnInline.ParentRatingKey") or ""
            _log("INLINE_PLAYBACK_RETURN_RESTORE_BEGIN reason=%s rating_key=%s type=%s section=%s show=%s" % (reason or "", rating_key, plex_type, section_id, show_key))
            try:
                _bg_r38 = self._normalize_argb_color(win.getProperty("PlexKM.Playback.ReturnInline.InfoBgColorR38") or "")
                self._playback_return_bg_r38 = (str(rating_key or ""), _bg_r38) if (rating_key and _bg_r38) else None
            except Exception:
                self._playback_return_bg_r38 = None
            try:
                win.clearProperty("PlexKM.Playback.ReturnInfoReadyV1939")
            except Exception:
                pass
            if not rating_key:
                self._clear_inline_info_playback_return_state(reason="missing_rating_key")
                return False
            # v2482: playback -> PKM Info is a scene return, so it follows the
            # same meaningful 1000ms rule as every other PKM page transition.
            # The previous completed PKM surface remains visible; fast restores
            # stay ring-free, while a genuinely slow restore may show feedback.
            _busy_token_v1884 = self._scene_busy_arm_v2482(
                reason="playback_return_info:%s" % (rating_key or ""),
                scope="playback_return_info", owner=rating_key or "",
                replace_scope=True, threshold_ms=1000,
            )
            _log("PLAYBACK_RETURN_INFO_SPINNER_POLICY_V2482 rating_key=%s type=%s previous_surface=1 transition_atomic=1 threshold_ms=1000" % (
                rating_key, plex_type or "item"
            ))

            li = None
            rows = []
            if plex_type == "episode" and section_id and show_key:
                try:
                    rows = list(_ensure_core().query_episodes_for_show(section_id, show_key) or [])
                except Exception:
                    rows = []
                if not rows:
                    # v2380: playback-return is a zero-network restore path.
                    # The saved Info snapshot below is authoritative enough to
                    # restore the page immediately; never block Stop/Back on
                    # Plex allLeaves.
                    _log("INLINE_PLAYBACK_RETURN_LOCAL_ROWS_MISS_V2380 rating_key=%s show=%s section=%s action=snapshot_restore network=0" % (
                        rating_key, show_key, section_id
                    ), xbmc.LOGINFO)
                for row in rows:
                    try:
                        if str(tuple(row)[0]) == str(rating_key):
                            li = self._info_tv_row_to_li(row)
                            break
                    except Exception:
                        pass

            if li is None:
                title = win.getProperty("PlexKM.Playback.ReturnInline.Title") or win.getProperty("PlexKM.Playback.ReturnInline.ShowTitle") or ""
                li = xbmcgui.ListItem(label=title)
                for key in ["Type", "RatingKey", "SectionId", "PartKey", "PlayUrl", "ParentRatingKey", "GrandparentRatingKey", "Season", "Episode", "Title", "ShowTitle", "Thumb", "Art", "Summary", "SummaryDisplay", "Year", "Duration", "DurationText", "ViewOffset", "ResumeDurationMs", "PlayButtonLabel", "RemainingText", "RemainingIcon"]:
                    try:
                        li.setProperty("PlexKM.%s" % key, win.getProperty("PlexKM.Playback.ReturnInline.%s" % key) or "")
                    except Exception:
                        pass
                try:
                    art = win.getProperty("PlexKM.Playback.ReturnInline.Art") or ""
                    thumb = win.getProperty("PlexKM.Playback.ReturnInline.Thumb") or ""
                    li.setArt({"thumb": thumb, "icon": thumb, "fanart": art})
                except Exception:
                    pass

            # v1938: playback stop writes the authoritative local resume sidecar
            # before this WindowXML restore runs.  Merge that fresh position into the
            # reconstructed ListItem so the returned Info page immediately shows
            # 이어서 재생 instead of reusing the pre-playback snapshot (usually 0).
            try:
                _states_v1938 = getattr(_ensure_core(), "_read_local_resume_states", lambda: {})() or {}
                _resume_v1938 = _states_v1938.get(str(rating_key)) or {}
                _time_v1938 = _safe_int(_resume_v1938.get("time"), 0)
                _duration_v1938 = _safe_int(_resume_v1938.get("duration"), 0)
                _ui_offset_v1938 = self._resume_offset_ms_for_ui(
                    _time_v1938,
                    li.getProperty("PlexKM.Duration") or _duration_v1938,
                    _duration_v1938,
                )
                if _ui_offset_v1938 > 0:
                    li.setProperty("PlexKM.ViewOffset", str(_time_v1938))
                    li.setProperty("PlexKM.ResumeDurationMs", str(_duration_v1938))
                    li.setProperty("PlexKM.PlayButtonLabel", "이어서 재생")
                    _remaining_text_v1938, _remaining_icon_v1938 = self._remaining_time_props(
                        _duration_v1938, _time_v1938
                    )
                    li.setProperty("PlexKM.RemainingText", _remaining_text_v1938 or "")
                    li.setProperty("PlexKM.RemainingIcon", _remaining_icon_v1938 or "")
                    _log("PLAYBACK_RETURN_LOCAL_RESUME_MERGE_V1938 rating_key=%s time=%d duration=%d label=이어서 재생 source=playstate_resume" % (
                        rating_key, _time_v1938, _duration_v1938
                    ))
                else:
                    _log("PLAYBACK_RETURN_LOCAL_RESUME_MERGE_SKIP_V1938 rating_key=%s time=%d duration=%d reason=not_resumable" % (
                        rating_key, _time_v1938, _duration_v1938
                    ))
            except Exception:
                _log("PLAYBACK_RETURN_LOCAL_RESUME_MERGE_FAILED_V1938 rating_key=%s err=%s" % (
                    rating_key, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

            try:
                self._inline_info_origin_focus_id = _safe_int(win.getProperty("PlexKM.Playback.ReturnInline.OriginFocusId"), getattr(self, "_inline_info_origin_focus_id", 0) or 0)
                self._inline_info_origin_pos = _safe_int(win.getProperty("PlexKM.Playback.ReturnInline.OriginPos"), getattr(self, "_inline_info_origin_pos", -1) or -1)
                self._inline_info_origin_rating_key = win.getProperty("PlexKM.Playback.ReturnInline.OriginRatingKey") or rating_key
            except Exception:
                pass

            actual_type = (li.getProperty("PlexKM.Type") or plex_type or "").lower()
            kodi_type = (li.getProperty("PlexKM.KodiType") or "").lower()
            is_tv_v1884 = actual_type in ("show", "season", "episode", "tv") or kodi_type in ("tvshow", "episode")
            try:
                _transition_token_v1884 = pkm_transition_manager.begin_info_transition(
                    self, rating_key, mode="playback_return_v1884", cover=False
                )
                pkm_transition_manager.activate_info_transition_cover(
                    self, _transition_token_v1884
                )
            except Exception:
                _transition_token_v1884 = ""

            self._publish_info_window_properties(li, populate_movie_widgets=False)
            _log("PLAYBACK_RETURN_ACTOR_WIDGET_SYNC_SKIP_V2383 rating_key=%s reason=preserve_existing_or_defer_no_gui_block" % rating_key)
            try:
                self._info_clear_property_all("PlexKM.Info.CastReady")
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
            except Exception:
                pass
            try:
                self._prepare_info_cast_cached_thumbs_fast(li)
            except Exception:
                pass

            if is_tv_v1884:
                try:
                    self._info_tv_defer_focus = True
                    self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                    self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                except Exception:
                    pass
                tv_ok_v1884 = self._prepare_info_tv_rows(
                    li, preserve_previous_surface=True, allow_network=False
                )
                if tv_ok_v1884 is False:
                    raise RuntimeError("playback return TV rows prepare failed")
                _log("INLINE_PLAYBACK_RETURN_TV_ATOMIC_READY_V1884 rating_key=%s rows=%d previous_surface=1" % (
                    rating_key, len(getattr(self, "_info_tv_rows", []) or [])
                ))

            # Target properties and inactive TV rail are complete. Release the
            # logical gate while the prior completed screen is still underneath,
            # then publish the Info overlay once.
            try:
                pkm_transition_manager.commit_info_transition_gate(
                    self, _transition_token_v1884, rating_key
                )
            except Exception:
                pass
            self.setProperty("PlexKM.Info.InlineActive", "1")
            win.setProperty("PlexKM.Info.InlineActive", "1")
            try:
                self._info_set_property_all("PlexKM.Info.CastReady", "1")
            except Exception:
                pass
            try:
                if is_tv_v1884:
                    self._info_tv_defer_focus = False
                    mode_v1884 = self._info_tv_current_mode_or_fallback() or "episodes"
                    if mode_v1884 == "episodes":
                        # v2095: returning from native playback with Back must land
                        # on the primary episode play/resume action, not on the episode
                        # rail or the hidden bootstrap control. This is a single
                        # synchronous handoff after the restored Info surface is ready;
                        # there is no timer, retry loop, refresh, or metadata rebuild.
                        # R99 D1: drama Info has no big play button; return to the episode card.
                        focus_v2095 = int(self._info_tv_active_episode_control_id())
                        self.setFocusId(focus_v2095)
                        self._last_focus_id = focus_v2095
                        focus_after_v2095 = self._safe_focus_id()
                        if focus_after_v2095 != focus_v2095:
                            self.setFocus(self.getControl(focus_v2095))
                            focus_after_v2095 = self._safe_focus_id()
                        _log("PLAYBACK_RETURN_PRIMARY_PLAY_FOCUS_V2095 type=episode target=%d actual=%d mode=%s reason=%s" % (
                            focus_v2095, focus_after_v2095, mode_v1884, reason or ""
                        ))
                    else:
                        focus_v1884 = self._info_tv_active_episode_control_id() if mode_v1884 != "seasons" else 5711
                        self._info_tv_focus_panel(focus_v1884, reason="playback_return_atomic_v1884")
                else:
                    # v2095: XML onload can be followed by Kodi's bootstrap default
                    # control 100 during WindowXML re-entry. Own the final movie focus
                    # here, after InlineActive/content/cast are committed and before
                    # the return cover is released, so the visible Info page always
                    # reappears with the primary play/resume action focused.
                    focus_v2095 = 5001
                    self.setFocusId(focus_v2095)
                    self._last_focus_id = focus_v2095
                    focus_after_v2095 = self._safe_focus_id()
                    if focus_after_v2095 != focus_v2095:
                        self.setFocus(self.getControl(focus_v2095))
                        focus_after_v2095 = self._safe_focus_id()
                    _log("PLAYBACK_RETURN_PRIMARY_PLAY_FOCUS_V2095 type=movie target=%d actual=%d reason=%s" % (
                        focus_v2095, focus_after_v2095, reason or ""
                    ))
            except Exception:
                _log("PLAYBACK_RETURN_PRIMARY_PLAY_FOCUS_FAILED_V2095 type=%s reason=%s err=%s" % (
                    "tv" if is_tv_v1884 else "movie", reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            try:
                pkm_transition_manager.finish_info_transition(
                    self, _transition_token_v1884, rating_key, delay_ms=0
                )
            except Exception:
                pass
            # v1939: the return-fade worker owns the black overlay. Signal only
            # after InlineActive, content, cast readiness and target focus exist.
            try:
                win.setProperty("PlexKM.Playback.ReturnInfoReadyV1939", "1")
                _log("PLAYBACK_RETURN_INFO_READY_V1939 rating_key=%s type=%s inline_active=1 focus_target=%s" % (
                    rating_key, actual_type or "item", "tv" if is_tv_v1884 else "5001"
                ))
            except Exception:
                pass
            try:
                self._scene_busy_finish_v2482(_busy_token_v1884, reason="playback_return_info_visible")
                _busy_token_v1884 = ""
            except Exception:
                pass
            self._inline_info_diag_log(phase="playback_return_restore", reason=reason or "")
            self._clear_inline_info_playback_return_state(reason="restored")
            self._playback_return_bg_r38 = None
            _log("INLINE_PLAYBACK_RETURN_RESTORE_DONE_V1884 reason=%s rating_key=%s type=%s rows=%d atomic=1" % (
                reason or "", rating_key, actual_type, len(getattr(self, "_info_tv_rows", []) or []) if is_tv_v1884 else len(rows or [])
            ))
            return True
        except Exception:
            try:
                # Release the top-layer overlay on the fallback Home path too.
                xbmcgui.Window(10000).setProperty("PlexKM.Playback.ReturnInfoReadyV1939", "1")
                _log("PLAYBACK_RETURN_INFO_READY_FALLBACK_V1939 reason=restore_failed")
            except Exception:
                pass
            try:
                pkm_transition_manager.cancel_info_transition(self)
            except Exception:
                pass
            try:
                # Returning False lets onInit rebuild the completed Home scene.
                # Clear a possibly stale/partially republished Info flag first so
                # no empty TV overlay can survive into that fallback.
                self._info_clear_property_all("PlexKM.Info.InlineActive")
                self._info_tv_defer_focus = False
            except Exception:
                pass
            _log("INLINE_PLAYBACK_RETURN_RESTORE_FAILED_V1884 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False
        finally:
            try:
                if _busy_token_v1884:
                    self._scene_busy_finish_v2482(_busy_token_v1884, reason="playback_return_finally")
            except Exception:
                pass

    def _info_property_targets(self):
        """Return property scopes used by inline Info.

        Kodi renders this WindowXMLDialog as custom window 13000.  Some XML
        conditions resolve Window(10000).Property reliably, while focus/layout
        conditions inside the custom window can resolve Window(13000).Property
        sooner.  Keep both scopes in sync, plus self for current-window access.

        R86: every Info property write used to construct two xbmcgui.Window
        objects and then write three scopes, although self IS window 13000
        (5 GUI-lock round trips per property; Info open writes hundreds, which
        starved the render thread: ~10 fps for 0.5 s on the Shield).  The
        scopes are now resolved once per window instance and self is dropped
        when it is verified to be the same window as Window(13000).
        """
        cached = getattr(self, "_info_prop_targets_r86", None)
        if cached:
            return cached
        targets = []
        w13000 = None
        try:
            targets.append(xbmcgui.Window(10000))
        except Exception:
            pass
        try:
            w13000 = xbmcgui.Window(13000)
            targets.append(w13000)
        except Exception:
            w13000 = None
        same = False
        verified = False
        if w13000 is not None:
            try:
                probe = "r86_%d_%d" % (id(self), int(time.time() * 1000))
                self.setProperty("PlexKM.Info.ScopeProbeR86", probe)
                same = (w13000.getProperty("PlexKM.Info.ScopeProbeR86") == probe)
                self.clearProperty("PlexKM.Info.ScopeProbeR86")
                verified = True
            except Exception:
                verified = False
        if not same:
            targets.append(self)
        if verified and targets:
            self._info_prop_targets_r86 = targets
            _log("INFO_PROPERTY_TARGETS_R86 scopes=%d self_is_13000=%d" % (len(targets), 1 if same else 0))
        return targets

    def _info_set_property_all(self, name, value):
        for target in self._info_property_targets():
            try:
                target.setProperty(name, str(value or ""))
            except Exception:
                pass

    def _info_clear_property_all(self, name):
        for target in self._info_property_targets():
            try:
                target.clearProperty(name)
            except Exception:
                pass

    def _info_dynamic_bg_props_v2140(self, color):
        color = self._normalize_argb_color(color) or self._home_bg_default
        rgb = color[-6:].upper()
        return {
            "PlexKM.Info.DynamicBgColor": "FF" + rgb,
            "PlexKM.Info.DynamicBgFanartFadeColor": "99" + rgb,
            "PlexKM.Info.DynamicBgRailColor": "B8" + rgb,
            "PlexKM.Info.DynamicBgSideColor": "D8" + rgb,
            "PlexKM.Info.DynamicBgSideOpaqueColor": "FF" + rgb,
            "PlexKM.Info.DynamicBgSideSoftColor": "55" + rgb,
            # v2437: Info synopsis uses the exact same dynamic-tint card policy as Home.
            "PlexKM.Info.SummaryBoxColor": "68" + rgb,
        }

    def _info_dynamic_bg_apply_v2140(self, color, reason=""):
        try:
            props = self._info_dynamic_bg_props_v2140(color)
            for k, v in props.items():
                self._info_set_property_all(k, v)
            self._info_bg_display_color_v2140 = props.get("PlexKM.Info.DynamicBgColor", self._home_bg_default)
            _log("INFO_DYNAMIC_BG_APPLY_V2140 reason=%s color=%s owner=info" % (
                reason or "", self._info_bg_display_color_v2140
            ))
            return props
        except Exception:
            return {}

    def _info_dynamic_bg_lerp_v2161(self, color, rating_key="", bank="", reason="", steps=8, sleep_ms=35):
        """Apply a late exact Info tint as one atomic visual color owner.

        The Info body and physical Home sidebar both bind the same
        PlexKM.Info.DynamicBg* properties. A late fanart-color probe must never
        recolor one surface independently or jump after the target fanart is
        already visible. Interpolate the shared property family together and
        cancel immediately if another Info title becomes current.
        """
        try:
            target = self._normalize_argb_color(color) or self._home_bg_default
            start = self._normalize_argb_color(
                xbmcgui.Window(10000).getProperty("PlexKM.Info.DynamicBgColor")
                or self._info_bg_display_color_v2140
                or self._home_bg_default
            ) or self._home_bg_default
            if start == target:
                return self._info_dynamic_bg_apply_v2140(target, reason="v2161_same_%s" % (reason or ""))

            def _rgb(c):
                return tuple(int(c[i:i+2], 16) for i in (2, 4, 6))
            sr, sg, sb = _rgb(start)
            tr, tg, tb = _rgb(target)
            count = max(1, int(steps or 1))
            monitor = xbmc.Monitor()
            for idx in range(1, count + 1):
                if rating_key:
                    win = xbmcgui.Window(10000)
                    current_rk = str(win.getProperty("PlexKM.Info.ArtCurrentRatingKeyV2136") or "").strip()
                    active_bank = str(win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "").upper()
                    if current_rk != str(rating_key) or (bank and active_bank != str(bank).upper()):
                        _log("INFO_DYNAMIC_BG_LERP_CANCEL_V2161 rating_key=%s bank=%s current=%s active=%s reason=owner_changed" % (
                            rating_key or "", bank or "", current_rk, active_bank
                        ))
                        return {}
                t = float(idx) / float(count)
                rr = int(round(sr + (tr - sr) * t))
                gg = int(round(sg + (tg - sg) * t))
                bb = int(round(sb + (tb - sb) * t))
                step_color = "FF%02X%02X%02X" % (rr, gg, bb)
                props = self._info_dynamic_bg_props_v2140(step_color)
                for k, v in props.items():
                    self._info_set_property_all(k, v)
                self._info_bg_display_color_v2140 = props.get("PlexKM.Info.DynamicBgColor", step_color)
                if idx < count and monitor.waitForAbort(max(0.0, float(sleep_ms) / 1000.0)):
                    return props
            _log("INFO_DYNAMIC_BG_LERP_DONE_V2161 rating_key=%s bank=%s from=%s to=%s steps=%d sleep_ms=%d reason=%s sidebar_body_same_owner=1" % (
                rating_key or "", bank or "", start, target, count, int(sleep_ms or 0), reason or ""
            ))
            return self._info_dynamic_bg_props_v2140(target)
        except Exception:
            _log("INFO_DYNAMIC_BG_LERP_FAILED_V2161 rating_key=%s bank=%s reason=%s err=%s" % (
                rating_key or "", bank or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return {}

    def _info_dynamic_bg_seed_v2140(self, inline_active=False, reason=""):
        """Ensure the fade cover has a valid Info-owned base before it appears."""
        try:
            win = xbmcgui.Window(10000)
            if inline_active:
                seed = (
                    win.getProperty("PlexKM.Info.DynamicBgColor")
                    or self._info_bg_display_color_v2140
                    or win.getProperty("PlexKM.Home.DynamicBgColor")
                    or self._home_bg_display_color
                    or self._home_bg_default
                )
                source = "current_info"
            else:
                seed = (
                    win.getProperty("PlexKM.Home.DynamicBgColor")
                    or self._home_bg_display_color
                    or self._home_bg_default
                )
                source = "home_surface"
            self._info_dynamic_bg_apply_v2140(seed, reason="seed_%s_%s" % (source, reason or ""))
            _log("INFO_DYNAMIC_BG_SEED_V2140 source=%s color=%s inline_active=%d" % (
                source, self._normalize_argb_color(seed) or self._home_bg_default, 1 if inline_active else 0
            ))
        except Exception:
            pass

    def _info_dynamic_bg_stage_v2140(self, li, reason=""):
        """Stage the target Info tint in the same inactive bank as its fanart.

        Cached tints commit immediately under the v2137 fade cover.  A new
        fanart sample is fetched only by one latest-only background worker using
        the existing tiny artwork sampler; Info reveal never blocks on it.
        """
        try:
            if li is None:
                return False
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            bank = (win.getProperty("PlexKM.Info.ArtPendingBankV2136") or win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if bank not in ("A", "B"):
                bank = "A"
            art = self._info_art_target_url_v2136(li)
            art_key = self._home_fanart_display_url(art) if art else ""
            current = (
                win.getProperty("PlexKM.Info.DynamicBgColor")
                or self._info_bg_display_color_v2140
                or win.getProperty("PlexKM.Home.DynamicBgColor")
                or self._home_bg_display_color
                or self._home_bg_default
            )
            color = self._home_bg_color_cache.get(self._fanart_color_cache_key_v2218(art_key)) if art_key else ""
            exact = bool(color)
            _pb_bg_r38 = getattr(self, "_playback_return_bg_r38", None)
            if isinstance(_pb_bg_r38, tuple) and len(_pb_bg_r38) == 2 and _pb_bg_r38[0] == rk and _pb_bg_r38[1]:
                # R38: playback return keeps the pre-playback tint; no probe/lerp.
                color = _pb_bg_r38[1]
                exact = True
                _log("INFO_DYNAMIC_BG_PLAYBACK_RETURN_KEEP_R38 rating_key=%s color=%s probe=0" % (rk, color))
            if not color:
                color = current
            color = self._normalize_argb_color(color) or self._home_bg_default
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sColorV2140" % bank, color)
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % bank, rk)
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sExactV2140" % bank, "1" if exact else "")
            _log("INFO_DYNAMIC_BG_STAGE_V2140 rating_key=%s bank=%s source=%s color=%s art=%d reason=%s" % (
                rk, bank, "cache" if exact else ("preserve_no_art" if not art_key else "pending_probe"),
                color, 1 if art_key else 0, reason or ""
            ))
            if exact or not art_key:
                return True

            with self._info_bg_probe_lock_v2140:
                self._info_bg_probe_pending_v2140 = (rk, bank, art_key, str(reason or ""))
                if self._info_bg_probe_worker_running_v2140:
                    return True
                self._info_bg_probe_worker_running_v2140 = True

            def _worker():
                try:
                    while True:
                        with self._info_bg_probe_lock_v2140:
                            pending = self._info_bg_probe_pending_v2140
                            self._info_bg_probe_pending_v2140 = None
                        if not pending:
                            break
                        p_rk, p_bank, p_art, p_reason = pending
                        cache_key_v2218 = self._fanart_color_cache_key_v2218(p_art)
                        color2 = self._home_bg_color_cache.get(cache_key_v2218) or self._detect_fanart_background_color(p_art)
                        if not color2:
                            _log("INFO_DYNAMIC_BG_PROBE_PRESERVE_V2140 rating_key=%s bank=%s reason=%s" % (
                                p_rk, p_bank, p_reason or ""
                            ), xbmc.LOGWARNING)
                        else:
                            color2 = self._normalize_argb_color(color2) or self._home_bg_default
                            self._home_bg_color_cache[cache_key_v2218] = color2
                            win2 = xbmcgui.Window(10000)
                            bank_rk = str(win2.getProperty("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % p_bank) or "").strip()
                            if bank_rk == p_rk:
                                self._info_set_property_all("PlexKM.Info.DynamicBgBank%sColorV2140" % p_bank, color2)
                                self._info_set_property_all("PlexKM.Info.DynamicBgBank%sExactV2140" % p_bank, "1")
                            active_bank = (win2.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
                            current_rk = str(win2.getProperty("PlexKM.Info.ArtCurrentRatingKeyV2136") or "").strip()
                            if active_bank == p_bank and current_rk == p_rk:
                                _cover_v2161 = win2.getProperty("PlexKM.Info.Transition.Cover") or "0"
                                if _cover_v2161 == "1":
                                    # v2161: target is still hidden. Commit the exact
                                    # tint immediately behind the SOURCE-only cover;
                                    # no visible layer can recolor early.
                                    self._info_dynamic_bg_apply_v2140(color2, reason="late_exact_hidden_v2161_%s" % (p_reason or ""))
                                    _mode_v2161 = "hidden_direct"
                                else:
                                    # If the sampler genuinely finishes after reveal,
                                    # body + physical sidebar must change as one color
                                    # owner. Never let the left rail jump later on its
                                    # own; interpolate the shared Info property family.
                                    self._info_dynamic_bg_lerp_v2161(
                                        color2, rating_key=p_rk, bank=p_bank,
                                        reason="late_exact_visible_%s" % (p_reason or ""),
                                        steps=8, sleep_ms=35,
                                    )
                                    _mode_v2161 = "visible_unified_lerp"
                                _log("INFO_DYNAMIC_BG_LATE_COMMIT_V2161 rating_key=%s bank=%s color=%s cover=%s mode=%s sidebar_body_same_owner=1" % (
                                    p_rk, p_bank, color2, _cover_v2161, _mode_v2161
                                ))
                            else:
                                _log("INFO_DYNAMIC_BG_PROBE_READY_V2140 rating_key=%s bank=%s color=%s active=%s current=%s" % (
                                    p_rk, p_bank, color2, active_bank, current_rk
                                ))
                        with self._info_bg_probe_lock_v2140:
                            if self._info_bg_probe_pending_v2140 is None:
                                break
                except Exception:
                    _log("INFO_DYNAMIC_BG_PROBE_FAILED_V2140 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                finally:
                    restart = False
                    with self._info_bg_probe_lock_v2140:
                        self._info_bg_probe_worker_running_v2140 = False
                        restart = self._info_bg_probe_pending_v2140 is not None
                    if restart and not self._closing_event_v1841.is_set():
                        try:
                            pending_now = self._info_bg_probe_pending_v2140
                            if pending_now:
                                p_rk, p_bank, p_art, p_reason = pending_now
                                # Restart through the current Info item only if it
                                # still owns this ratingKey; otherwise leave the
                                # newer _show_info stage to arm its own worker.
                                win3 = xbmcgui.Window(10000)
                                if str(win3.getProperty("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % p_bank) or "") == p_rk:
                                    self._info_bg_probe_worker_running_v2140 = True
                                    t2 = _PKMHomeThreadV2151(target=_worker, daemon=True)
                                    t2.daemon = True
                                    t2.start()
                        except Exception:
                            pass

            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
            return True
        except Exception:
            _log("INFO_DYNAMIC_BG_STAGE_FAILED_V2140 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_dynamic_bg_stage_exact_v2332(self, li, reason=""):
        """Resolve the target Info tint before the page can own a visible frame.

        PKM v2332 full-page policy forbids a late visible tint correction.  The
        target fanart is already staged in the inactive art bank; sample its
        background color synchronously while the completed source page remains
        visible.  A failed/absent sample is also finalized to the current safe
        fallback so no background worker can recolor the active page later.
        """
        try:
            if li is None:
                return False
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            bank = (win.getProperty("PlexKM.Info.ArtPendingBankV2136") or win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if bank not in ("A", "B"):
                bank = "A"
            art = self._info_art_target_url_v2136(li)
            art_key = self._home_fanart_display_url(art) if art else ""
            current = (
                win.getProperty("PlexKM.Info.DynamicBgColor")
                or self._info_bg_display_color_v2140
                or win.getProperty("PlexKM.Home.DynamicBgColor")
                or self._home_bg_display_color
                or self._home_bg_default
            )
            t0 = self._now_ms()
            color = self._home_bg_color_cache.get(self._fanart_color_cache_key_v2218(art_key)) if art_key else ""
            source = "cache" if color else ""
            if not color and art_key:
                # v2380: Info first paint must never wait on HTTP/image sampling.
                # Home/stable-focus prewarm may already have populated the cache;
                # otherwise freeze this page to the current safe tint.
                source = "cache_miss_no_probe_v2380"
            if not color:
                color = current
                source = "resolved_fallback"
            color = self._normalize_argb_color(color) or self._home_bg_default
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sColorV2140" % bank, color)
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % bank, rk)
            # Even a true no-art/sample-failure case is final for this page load.
            # Exact here means 'resolved before visible', not 'sample succeeded'.
            self._info_set_property_all("PlexKM.Info.DynamicBgBank%sExactV2140" % bank, "1")
            # Retire any queued same-rating probe so it cannot recolor after reveal.
            try:
                with self._info_bg_probe_lock_v2140:
                    pending = getattr(self, "_info_bg_probe_pending_v2140", None)
                    if pending and str(pending[0] or "") == rk:
                        self._info_bg_probe_pending_v2140 = None
            except Exception:
                pass
            _log("INFO_DYNAMIC_BG_EXACT_READY_V2332 rating_key=%s bank=%s color=%s source=%s art=%d elapsed_ms=%d before_visible=1 late_commit=0" % (
                rk, bank, color, source, 1 if art_key else 0, self._now_ms() - t0
            ))
            return True
        except Exception:
            _log("INFO_DYNAMIC_BG_EXACT_READY_FAILED_V2332 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_dynamic_bg_commit_v2140(self, li, reason=""):
        try:
            if li is None:
                return ""
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            bank = (win.getProperty("PlexKM.Info.ArtPendingBankV2136") or win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if bank not in ("A", "B"):
                bank = "A"
            bank_rk = str(win.getProperty("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % bank) or "").strip()
            if bank_rk != rk:
                self._info_dynamic_bg_stage_v2140(li, reason="commit_restage_%s" % (reason or ""))
                bank_rk = str(win.getProperty("PlexKM.Info.DynamicBgBank%sRatingKeyV2140" % bank) or "").strip()
            color = (
                win.getProperty("PlexKM.Info.DynamicBgBank%sColorV2140" % bank)
                or win.getProperty("PlexKM.Info.DynamicBgColor")
                or win.getProperty("PlexKM.Home.DynamicBgColor")
                or self._home_bg_default
            )
            exact = win.getProperty("PlexKM.Info.DynamicBgBank%sExactV2140" % bank) == "1"
            self._info_dynamic_bg_apply_v2140(color, reason="commit_%s" % (reason or ""))
            _log("INFO_DYNAMIC_BG_COMMIT_V2140 rating_key=%s bank=%s color=%s exact=%d fanart_same_transaction=1" % (
                rk, bank, self._normalize_argb_color(color) or self._home_bg_default, 1 if exact else 0
            ))
            return bank
        except Exception:
            _log("INFO_DYNAMIC_BG_COMMIT_FAILED_V2140 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return ""

    def _info_entry_home_art_v2194(self, li):
        """Return the exact fanart texture that was visible on Home for this Info target.

        v2194: the Home XML renders Window.Property(PlexKM.Home.DisplayFanart) from
        the live Home window.  Do not infer ownership from the artwork URL's
        /library/metadata/<key>/ segment because canonical/duplicate movie rows may
        intentionally display fanart whose URL belongs to a sibling ratingKey.
        Ownership is instead validated with PlexKM.Home.RatingKey, then the exact
        already-rendered DisplayFanart string is reused without changing geometry.
        """
        try:
            if li is None:
                return ""
            target_rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not target_rk:
                return ""
            li_art = str(li.getProperty("PlexKM.Info.EntryHomeFanartV2194") or "").strip()
            li_rk = str(li.getProperty("PlexKM.Info.EntryHomeRatingKeyV2194") or "").strip()
            if li_art and li_rk == target_rk:
                return li_art
            win = xbmcgui.Window(10000)
            held_rk = str(win.getProperty("PlexKM.Info.EntryHomeRatingKeyV2194") or "").strip()
            held_art = str(win.getProperty("PlexKM.Info.EntryHomeFanartV2194") or "").strip()
            if held_art and held_rk == target_rk:
                return held_art
        except Exception:
            pass
        return ""

    def _info_art_target_url_v2136(self, li):
        """Return the canonical fanart URL for the target Info item.

        v2136 keeps visual A/B ownership independent of where Info was opened
        from.  Actor-work child items still obey the v2132 rule that forbids
        Home fanart as a fallback for a different title.
        """
        try:
            if li is None:
                return ""
            child_atomic = li.getProperty("PlexKM.Info.ChildAtomicV2132") == "1"
            entry_home_art_v2194 = self._info_entry_home_art_v2194(li)
            raw = (
                entry_home_art_v2194 or
                li.getProperty("PlexKM.Art") or
                li.getArt("fanart") or
                ("" if child_atomic else self._home_fanart_if_owned_r65(li))
            )
            return _pkm_info_image_url(raw, width=1920, height=1080) if raw else ""
        except Exception:
            return ""

    def _info_art_preload_v2136(self, li, reason=""):
        """Warm a possible next Info fanart without changing visible ownership.

        This is universal for PKM Info candidates; it is not an actor-work
        special case.  Kodi loads the exact target URL through one off-screen
        image control.  No HTTP probe, Python image decode, focus write or wait
        is introduced.
        """
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            art = self._info_art_target_url_v2136(li)
            if not rk or not art:
                return False
            self._info_set_property_all("PlexKM.Info.ArtPreloadRatingKeyV2136", rk)
            self._info_set_property_all("PlexKM.Info.ArtPreloadUrlV2136", art)
            _log("INFO_ART_PRELOAD_V2136 rating_key=%s reason=%s visible_change=0 network_probe=0 focus_write=0" % (
                rk, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_ART_PRELOAD_FAILED_V2136 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_art_stage_v2136(self, li, reason=""):
        """Compose target fanart in the inactive universal Info A/B bank.

        The active bank is never changed here, so the currently visible Info
        remains the visual owner until the common atomic commit.
        """
        try:
            if li is None:
                return False
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            art = self._info_art_target_url_v2136(li)
            if not rk:
                return False
            active = (win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if active not in ("A", "B"):
                active = "A"
            current_rk = str(win.getProperty("PlexKM.Info.ArtCurrentRatingKeyV2136") or "").strip()
            inline_active = (
                self.getProperty("PlexKM.Info.InlineActive") == "1" or
                win.getProperty("PlexKM.Info.InlineActive") == "1"
            )
            fresh = not inline_active or not current_rk
            target = active if (fresh or current_rk == rk) else ("B" if active == "A" else "A")
            preload_rk = str(win.getProperty("PlexKM.Info.ArtPreloadRatingKeyV2136") or "").strip()
            preload_url = str(win.getProperty("PlexKM.Info.ArtPreloadUrlV2136") or "").strip()
            preload_hit = bool(art and preload_rk == rk and preload_url == art)
            self._info_set_property_all("PlexKM.Info.ArtBank%sV2136" % target, art)
            self._info_set_property_all("PlexKM.Info.ArtPendingBankV2136", target)
            self._info_set_property_all("PlexKM.Info.ArtPendingRatingKeyV2136", rk)
            self._info_set_property_all("PlexKM.Info.ArtPendingUrlV2136", art)
            if art:
                self._info_set_property_all("PlexKM.Info.ArtPreloadRatingKeyV2136", rk)
                self._info_set_property_all("PlexKM.Info.ArtPreloadUrlV2136", art)
            _log("INFO_ART_AB_STAGE_V2136 rating_key=%s current=%s active=%s target=%s fresh=%d preload_hit=%d art=%d reason=%s visible_change=0" % (
                rk, current_rk, active, target, 1 if fresh else 0, 1 if preload_hit else 0, 1 if art else 0, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_ART_AB_STAGE_FAILED_V2136 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_art_commit_v2136(self, li, reason=""):
        """Flip universal Info fanart ownership only after target composition.

        Both fanart banks stay allocated, but v2137 no longer slides them. The
        target bank becomes active while the universal fade cover is opaque; XML
        then fades the complete target page in. The single property flip is shared
        by movie/show/episode and every PKM Info entry source.
        """
        try:
            if li is None:
                return ""
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            pending_rk = str(win.getProperty("PlexKM.Info.ArtPendingRatingKeyV2136") or "").strip()
            target = (win.getProperty("PlexKM.Info.ArtPendingBankV2136") or "").upper()
            active = (win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if active not in ("A", "B"):
                active = "A"
            if target not in ("A", "B") or pending_rk != rk:
                self._info_art_stage_v2136(li, reason="commit_restage_%s" % (reason or ""))
                pending_rk = str(win.getProperty("PlexKM.Info.ArtPendingRatingKeyV2136") or "").strip()
                target = (win.getProperty("PlexKM.Info.ArtPendingBankV2136") or active).upper()
            current_rk = str(win.getProperty("PlexKM.Info.ArtCurrentRatingKeyV2136") or "").strip()
            swap = bool(current_rk and rk and current_rk != rk and target != active)
            self._info_set_property_all("PlexKM.Info.ArtActiveBankV2136", target)
            self._info_set_property_all("PlexKM.Info.ArtCurrentRatingKeyV2136", rk)
            self._info_set_property_all("PlexKM.Info.ArtSwapActiveV2136", "1" if swap else "")
            self._info_clear_property_all("PlexKM.Info.ArtPendingBankV2136")
            self._info_clear_property_all("PlexKM.Info.ArtPendingRatingKeyV2136")
            self._info_clear_property_all("PlexKM.Info.ArtPendingUrlV2136")
            self._info_clear_property_all("PlexKM.Info.ArtPreloadRatingKeyV2136")
            self._info_clear_property_all("PlexKM.Info.ArtPreloadUrlV2136")
            _log("INFO_ART_AB_COMMIT_V2136 rating_key=%s from=%s to=%s swap=%d mode=universal_all_info reason=%s metadata_same_commit=1 focus_write=0" % (
                rk, active, target, 1 if swap else 0, reason or ""
            ))
            return target
        except Exception:
            _log("INFO_ART_AB_COMMIT_FAILED_V2136 rating_key=%s err=%s" % (
                str(li.getProperty("PlexKM.RatingKey") or "") if li is not None else "",
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return ""

    def _info_art_sync_active_v2136(self, li, art, reason=""):
        """Keep later same-title art repairs on the already-active bank."""
        try:
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li is not None else ""
            current_rk = str(win.getProperty("PlexKM.Info.ArtCurrentRatingKeyV2136") or "").strip()
            pending_rk = str(win.getProperty("PlexKM.Info.ArtPendingRatingKeyV2136") or "").strip()
            if pending_rk and pending_rk == rk and current_rk != rk:
                return False
            active = (win.getProperty("PlexKM.Info.ArtActiveBankV2136") or "A").upper()
            if active not in ("A", "B"):
                active = "A"
            if not current_rk:
                self._info_set_property_all("PlexKM.Info.ArtActiveBankV2136", active)
                self._info_set_property_all("PlexKM.Info.ArtCurrentRatingKeyV2136", rk)
            if not current_rk or current_rk == rk:
                self._info_set_property_all("PlexKM.Info.ArtBank%sV2136" % active, str(art or ""))
                # v2140: same-title background artwork repair must move the Info
                # tint owner with the repaired fanart as well.  This is still
                # background/nonblocking; cached colors apply immediately and an
                # uncached tiny sample updates only if this title remains active.
                try:
                    if current_rk == rk and rk:
                        self._info_dynamic_bg_stage_v2140(li, reason="same_title_art_sync_%s" % (reason or ""))
                        self._info_dynamic_bg_commit_v2140(li, reason="same_title_art_sync_%s" % (reason or ""))
                except Exception:
                    pass
                return True
            return False
        except Exception:
            return False

    def _inline_info_focus_target_v1886(self):
        """Return the currently visible native focus target for inline Info.

        TV episode Info uses a true A/B rail: 5712 is buffer A and 5713 is
        buffer B. Any recovery path must resolve TVActiveBuffer at the moment
        focus is requested; hard-coding 5712 can target the hidden panel and
        make Kodi fall back to the Home sidebar control.
        """
        try:
            mode = self._info_tv_current_mode_or_fallback()
        except Exception:
            mode = ""
        if mode == "episodes":
            return self._info_tv_active_episode_control_id()
        if mode == "seasons":
            return 5711
        try:
            win_home = xbmcgui.Window(10000)
            win_xml = xbmcgui.Window(13000)
            is_tv = (
                self.getProperty("PlexKM.Info.IsTV") == "1"
                or win_home.getProperty("PlexKM.Info.IsTV") == "1"
                or win_xml.getProperty("PlexKM.Info.IsTV") == "1"
            )
            if is_tv:
                return 5711
        except Exception:
            pass
        return 5001

    def _info_mark_entry_target_focus_ready_v2123(self, control_id=0, reason=""):
        """Confirm fresh-child top focus without steering directional navigation.

        EntrySwapV2087 keeps the reused Info body visually transparent while the
        child is composed, but the controls remain focusable.  Once Kodi really
        owns the child entry control, briefly hide only the animation-owner group
        so its completed v2079 slide transforms reset while hidden focus is kept.
        The transition manager owns the two-frame release; this helper never moves
        focus and never handles a direction key.
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Info.EntrySwapV2087") != "1":
                return False
            cid = int(control_id or 0)
            is_tv = (
                self.getProperty("PlexKM.Info.IsTV") == "1"
                or win.getProperty("PlexKM.Info.IsTV") == "1"
            )
            # v2343: target focus readiness must be proven by a control that is
            # actually visible on the target page. Movie keeps 5001. TV episode
            # mode uses its visible primary action control 5721; season mode may
            # use the published season panel. Keeping hidden movie control 5001
            # as the TV owner produced a logically focused but visually unfocused
            # page until the user pressed DOWN.
            allowed = (5721, 5711, 5712, 5713) if is_tv else (5001,)
            if cid not in allowed:
                return False
            actual = int(self._safe_focus_id() or 0)
            if actual != cid:
                return False
            target = win.getProperty("PlexKM.Info.EntryTargetRatingKeyV2123") or ""
            current = win.getProperty("PlexKM.Info.RatingKey") or ""
            if target and current and target != current:
                return False
            win.setProperty("PlexKM.Info.EntryTargetFocusReadyV2123", "1")
            if win.getProperty("PlexKM.Info.ActorPrecomposeV2185") == "1":
                # v2190: keep the target body renderable.  The old v2079 reverse
                # transform is cancelled by equal/opposite XML compensation, so
                # hiding 55961 (EntryResetHide) would recreate the fanart-only
                # interval the atomic reveal is intended to remove.
                win.clearProperty("PlexKM.Info.EntryResetHideV2123")
                _log("INFO_ENTRY_TARGET_FOCUS_READY_V2190 focus=%s is_tv=%d rating_key=%s reset_hide=0 compensation=1 source_focus=%s reason=%s python_focus_write=0" % (
                    cid, 1 if is_tv else 0, current or target or "",
                    win.getProperty("PlexKM.Info.ActorSourceFocusV2190") or "0", reason or ""
                ))
            else:
                win.setProperty("PlexKM.Info.EntryResetHideV2123", "1")
                _log("INFO_ENTRY_TARGET_FOCUS_READY_V2123 focus=%s is_tv=%d rating_key=%s reset_hide=1 reason=%s python_focus_write=0" % (
                    cid, 1 if is_tv else 0, current or target or "", reason or ""
                ))
            return True
        except Exception:
            return False

    def _info_movie_media_variant_clear_v2100(self, reason=""):
        """Clear only the detailed movie Media/Part selection state."""
        try:
            self._info_movie_media_override_v2100 = None
            self._info_movie_media_cache_v2100 = {}
            try:
                with self._info_movie_media_prewarm_lock_v2106:
                    self._info_movie_media_prewarm_generation_v2106 += 1
                    self._info_movie_media_prewarm_inflight_v2106.clear()
            except Exception:
                pass
            self._info_movie_media_popup_rows_v2104 = []
            self._info_movie_media_popup_origin_v2104 = 0
            for key in (
                "PlexKM.Info.MediaVersionAvailable", "PlexKM.Info.MediaVersionSelectedKey",
                "PlexKM.Info.MediaVersionHDR", "PlexKM.Info.MediaVersionAudioStreamIndex",
                "PlexKM.Info.MediaVersionVideo", "PlexKM.Info.MediaVersionAudio",
                "PlexKM.Info.MediaVersionCount", "PlexKM.Info.MediaVersionPopupOpen",
                "PlexKM.Info.MediaVersionPopupBgColor", "PlexKM.Info.TVMediaVersionPopupBgColor",
            ):
                self._info_clear_property_all(key)
            _log("INFO_MOVIE_MEDIA_VERSION_CLEAR_V2100 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _info_movie_media_resolution_v2100(self, media_attrs, video_attrs=None):
        try:
            attrs = dict(media_attrs or {})
            for k, v in dict(video_attrs or {}).items():
                attrs.setdefault(k, v)
            res = str(attrs.get("videoResolution") or attrs.get("resolution") or "").strip().lower()
            width = _safe_int(attrs.get("width"), 0)
            height = _safe_int(attrs.get("height"), 0)
            if res in ("8k", "4320", "4320p") or "4320" in res or width >= 7000 or height >= 4000:
                return "4320p"
            if res in ("4k", "uhd", "2160", "2160p") or "2160" in res or width >= 3000 or height >= 2000:
                return "2160p"
            if "1440" in res or (height >= 1300 and height < 2000):
                return "1440p"
            if "1080" in res or width >= 1800 or height >= 1000:
                return "1080p"
            if "720" in res or width >= 1200 or height >= 700:
                return "720p"
            if "576" in res or height >= 540:
                return "576p"
            if "480" in res or height >= 430:
                return "480p"
            if "360" in res or height >= 330:
                return "360p"
            if res:
                return res if res.endswith("p") else (res + "p" if res.isdigit() else res)
        except Exception:
            pass
        return ""

    def _info_movie_video_codec_v2100(self, media_attrs, video_attrs=None):
        """Normalize Plex/FFmpeg codec names to stable Kodi-facing labels."""
        try:
            codec = str((video_attrs or {}).get("codec") or (media_attrs or {}).get("videoCodec") or "").strip().lower()
            compact = codec.replace("_", "").replace("-", "").replace(".", "")
            mapping = {
                "hevc": "HEVC", "h265": "HEVC", "hev1": "HEVC", "hvc1": "HEVC",
                "avc": "H.264", "h264": "H.264", "avc1": "H.264",
                "av1": "AV1", "av01": "AV1",
                "vp9": "VP9", "vp09": "VP9", "vp8": "VP8", "vp08": "VP8",
                "mpeg1video": "MPEG-1", "mpeg1": "MPEG-1",
                "mpeg2video": "MPEG-2", "mpeg2": "MPEG-2",
                "mpeg4": "MPEG-4", "mp4v": "MPEG-4", "xvid": "MPEG-4", "divx": "MPEG-4",
                "vc1": "VC-1", "wvc1": "VC-1",
                "wmv2": "WMV2", "wmv3": "WMV3",
                "theora": "Theora", "h263": "H.263", "rv10": "RealVideo", "rv20": "RealVideo",
                "rv30": "RealVideo", "rv40": "RealVideo", "mjpeg": "MJPEG",
            }
            return mapping.get(compact, codec.upper() if codec else "")
        except Exception:
            return ""

    def _info_media_hdr_label_v2114(self, media_attrs, video_attrs=None):
        """Return explicit Plex dynamic-range identity without guessing from codec."""
        try:
            attrs = dict(media_attrs or {})
            attrs.update(dict(video_attrs or {}))
            # Plex versions expose dynamic range through several fields.  Inspect
            # both keys and trusted generated values so DOVI profile attributes are
            # recognized even when the friendly displayTitle is absent.
            trusted_keys = (
                "dynamicRange", "videoDynamicRange", "hdr", "hdrType", "hdrFormat",
                "displayTitle", "extendedDisplayTitle", "profile", "videoProfile",
                "colorTrc", "colorTransfer", "colorPrimaries", "colorSpace",
                "DOVIProfile", "DOVIBLCompatID", "dolbyVisionProfile",
            )
            blob = " ".join(str(attrs.get(k) or "") for k in trusted_keys if str(attrs.get(k) or "").strip()).lower()
            keys_blob = " ".join(str(k).lower() for k, v in attrs.items() if str(v or "").strip())
            all_blob = blob + " " + keys_blob
            if any(tok in all_blob for tok in ("dolby vision", "dolbyvision", "dovi")):
                return "Dolby Vision"
            if any(tok in all_blob for tok in ("hdr10+", "hdr10plus", "hdr10 plus")):
                return "HDR10+"
            if any(tok in all_blob for tok in ("hlg", "arib-std-b67", "arib std b67")):
                return "HLG"
            if any(tok in all_blob for tok in ("hdr10", "smpte2084", "smpte st 2084", "st2084")):
                return "HDR10"
            dyn = str(attrs.get("dynamicRange") or attrs.get("videoDynamicRange") or attrs.get("hdrType") or "").strip().lower()
            if dyn in ("hdr", "pq"):
                return "HDR"
            if dyn == "sdr":
                return "SDR"
        except Exception:
            pass
        return ""

    def _info_movie_audio_signature_v2114(self, media_attrs, audio_attrs=None):
        """Return normalized codec / Atmos / channel fields for one Plex audio stream."""
        try:
            attrs = dict(media_attrs or {})
            attrs.update(dict(audio_attrs or {}))
            codec = str(attrs.get("codec") or attrs.get("audioCodec") or "").strip().lower()
            compact = codec.replace("_", "").replace("-", "").replace(".", "")
            trusted_text = " ".join(str(attrs.get(k) or "") for k in (
                "displayTitle", "extendedDisplayTitle", "profile", "audioProfile",
                "format", "formatAdditionalFeatures"
            )).lower()
            explicit_atmos = ("atmos" in trusted_text or "joc" in trusted_text)

            if compact in ("dca", "dts"):
                if any(x in trusted_text for x in ("dts-hd ma", "dts hd ma", "master audio")) or str(attrs.get("profile") or "").strip().lower() == "ma":
                    codec_label = "DTS-HD MA"
                elif any(x in trusted_text for x in ("dts-hd hra", "dts hd hra", "high resolution audio", "high resolution")):
                    codec_label = "DTS-HD HRA"
                elif "dts-hd" in trusted_text or "dts hd" in trusted_text:
                    codec_label = "DTS-HD"
                else:
                    codec_label = "DTS"
            elif compact in ("truehd", "mlp"):
                codec_label = "TrueHD"
            elif compact in ("eac3", "ec3"):
                codec_label = "EAC3"
            elif compact in ("ac3", "ac3fixed"):
                codec_label = "AC3"
            elif compact in ("aaclatm", "latm"):
                codec_label = "AAC-LATM"
            else:
                mapping = {
                    "aac": "AAC", "flac": "FLAC", "alac": "ALAC", "opus": "Opus",
                    "vorbis": "Vorbis", "mp3": "MP3", "mp2": "MP2", "mp1": "MP1",
                    "pcm": "PCM", "lpcm": "LPCM", "pcmbluray": "LPCM",
                    "wmapro": "WMA Pro", "wmav1": "WMA", "wmav2": "WMA", "wma": "WMA",
                    "ape": "APE", "wavpack": "WavPack", "wv": "WavPack",
                    "aiff": "AIFF", "wav": "WAV",
                }
                codec_label = mapping.get(compact, codec.upper() if codec else "")

            channels = _safe_int(attrs.get("channels") or attrs.get("audioChannels"), 0)
            ch_map = {1: "1.0", 2: "2.0", 3: "2.1", 4: "3.1", 5: "4.1", 6: "5.1", 7: "6.1", 8: "7.1"}
            channel_label = ch_map.get(channels, ("%dch" % channels) if channels > 0 else "")
            label = " ".join(x for x in (codec_label, "Atmos" if explicit_atmos else "", channel_label) if x).strip()
            return {
                "codec": codec_label,
                "atmos": bool(explicit_atmos),
                "channels": int(channels or 0),
                "channel_label": channel_label,
                "label": label,
            }
        except Exception:
            return {"codec": "", "atmos": False, "channels": 0, "channel_label": "", "label": ""}

    def _info_movie_media_combo_key_v2103(self, row):
        """v2114 semantic identity: resolution + video + HDR + audio + Atmos + channels."""
        try:
            resolution = " ".join(str((row or {}).get("resolution") or "").strip().lower().split())
            video = " ".join(str((row or {}).get("video_codec") or "").strip().upper().split())
            hdr = " ".join(str((row or {}).get("hdr_type") or "").strip().upper().split()) or "UNKNOWN"
            audio = " ".join(str((row or {}).get("audio_codec") or "").strip().upper().split())
            atmos = "ATMOS" if bool((row or {}).get("audio_atmos")) else "NOATMOS"
            channels = str((row or {}).get("audio_channels") or 0)
            return "%s|%s|%s|%s|%s|%s" % (resolution, video, hdr, audio, atmos, channels)
        except Exception:
            return ""

    def _info_movie_expand_media_copy_v2100(self, copy_entry, core_mod):
        """Expand one accepted movie/episode copy into Plex Part + audio-stream variants.

        v2114 intentionally enumerates every audio Stream for each playable Part.
        The physical folder/file layout is irrelevant; Plex Media/Part/Stream
        metadata is the source of truth.
        """
        rows = []
        rk = str((copy_entry or {}).get("rating_key") or "").strip()
        if not rk:
            return rows
        try:
            root = None
            cache_hit_v2209 = False
            try:
                with self._info_media_metadata_cache_lock_v2209:
                    root = self._info_media_metadata_cache_v2209.get(rk)
                cache_hit_v2209 = root is not None
            except Exception:
                root = None
                cache_hit_v2209 = False
            if cache_hit_v2209:
                _log("INFO_MEDIA_VERSION_METADATA_CACHE_HIT_V2209 rk=%s" % rk)
            else:
                timeout_v2209 = max(0.50, float(getattr(self, "_info_media_variant_timeout_v2209", 1.60) or 1.60))
                root = core_mod.plex_request_xml(
                    "/library/metadata/%s" % rk,
                    params={"includeMedia": "1"}, timeout=timeout_v2209,
                )
                try:
                    with self._info_media_metadata_cache_lock_v2209:
                        self._info_media_metadata_cache_v2209[rk] = root
                except Exception:
                    pass
                _log("INFO_MEDIA_VERSION_METADATA_FETCH_V2209 rk=%s timeout=%.2f cache_store=1" % (rk, timeout_v2209))
        except Exception:
            root = None
            _log("INFO_MEDIA_VERSION_METADATA_FAILED_V2209 rk=%s timeout=%.2f fallback=local" % (
                rk, max(0.50, float(getattr(self, "_info_media_variant_timeout_v2209", 1.60) or 1.60))
            ), xbmc.LOGWARNING)

        try:
            video_node = None
            if root is not None:
                for node in root.findall(".//Video"):
                    if str(node.get("ratingKey") or "") == rk:
                        video_node = node
                        break
                if video_node is None:
                    video_node = root.find(".//Video")
            media_nodes = list(video_node.findall("./Media")) if video_node is not None else []
            seen_variants = set()
            for media_index, media in enumerate(media_nodes):
                ma = dict(media.attrib or {})
                parts = list(media.findall("./Part"))
                for part_index, part in enumerate(parts):
                    pa = dict(part.attrib or {})
                    part_key = str(pa.get("key") or "").strip()
                    if not part_key:
                        continue
                    streams = list(part.findall("./Stream"))
                    video_streams = [st for st in streams if str(st.get("streamType") or "") == "1"]
                    audio_streams = [st for st in streams if str(st.get("streamType") or "") == "2"]
                    video_stream = next((st for st in video_streams if str(st.get("selected") or "") == "1"), video_streams[0] if video_streams else None)
                    va = dict(video_stream.attrib or {}) if video_stream is not None else {}
                    resolution = self._info_movie_media_resolution_v2100(ma, va) or str(copy_entry.get("resolution") or "")
                    video_codec = self._info_movie_video_codec_v2100(ma, va)
                    hdr_type = self._info_media_hdr_label_v2114(ma, va)
                    file_path = str(pa.get("file") or copy_entry.get("media_file") or "").strip()
                    basename = os.path.basename(file_path.replace("\\", "/")) if file_path else ""

                    # No audio stream metadata is still a valid playable Part.
                    audio_candidates = list(audio_streams) if audio_streams else [None]
                    for audio_index, audio_stream in enumerate(audio_candidates):
                        aa = dict(audio_stream.attrib or {}) if audio_stream is not None else {}
                        sig = self._info_movie_audio_signature_v2114(ma, aa)
                        audio_label = str(sig.get("label") or "")
                        stream_id = str(aa.get("id") or "").strip()
                        audio_key = stream_id or str(audio_index)
                        unique = "%s|%s|a:%s" % (rk, part_key, audio_key)
                        if unique in seen_variants:
                            continue
                        seen_variants.add(unique)
                        preferred_rank = 0 if str(aa.get("selected") or "") == "1" else (1 if str(aa.get("default") or "") == "1" else 2)
                        main = " ".join(x for x in ((resolution or "?").upper(), video_codec or "VIDEO", hdr_type if hdr_type and hdr_type != "SDR" else "") if x).strip()
                        rows.append({
                            "variant_key": unique,
                            "rating_key": rk,
                            "section_id": str(copy_entry.get("section_id") or ""),
                            "part_key": part_key,
                            "resolution": resolution,
                            "video_codec": video_codec,
                            "hdr_type": hdr_type,
                            "audio_codec": str(sig.get("codec") or ""),
                            "audio_atmos": bool(sig.get("atmos")),
                            "audio_channels": int(sig.get("channels") or 0),
                            "audio_channel_label": str(sig.get("channel_label") or ""),
                            "audio_label": audio_label,
                            "audio_stream_id": stream_id,
                            "audio_stream_index": int(audio_index),
                            "audio_preferred_rank": int(preferred_rank),
                            "media_index": str(media_index),
                            "part_index": str(part_index),
                            "match_reason": str(copy_entry.get("match_reason") or ""),
                            "main_label": main,
                            "sub_label": audio_label or "오디오 정보 없음",
                            "source_label": basename,
                            "basename": basename,
                        })
        except Exception:
            _log("INFO_MEDIA_VERSION_PARSE_FAILED_V2114 rk=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        if not rows:
            part_key = str((copy_entry or {}).get("part_key") or "").strip()
            if part_key:
                _log("INFO_MEDIA_VERSION_LOCAL_FALLBACK_V2209 rk=%s part=%s reason=metadata_missing_or_budget" % (rk, part_key))
                res = str((copy_entry or {}).get("resolution") or "")
                raw = pkm_media_versions.raw_dict((copy_entry or {}).get("raw_json"))
                video_codec = self._info_movie_video_codec_v2100(raw, {})
                hdr_type = self._info_media_hdr_label_v2114(raw, {})
                sig = self._info_movie_audio_signature_v2114(raw, {})
                audio_label = str(sig.get("label") or "")
                basename = os.path.basename(str((copy_entry or {}).get("media_file") or "").replace("\\", "/"))
                rows.append({
                    "variant_key": "%s|%s|a:default" % (rk, part_key),
                    "rating_key": rk,
                    "section_id": str(copy_entry.get("section_id") or ""),
                    "part_key": part_key,
                    "resolution": res,
                    "video_codec": video_codec,
                    "hdr_type": hdr_type,
                    "audio_codec": str(sig.get("codec") or ""),
                    "audio_atmos": bool(sig.get("atmos")),
                    "audio_channels": int(sig.get("channels") or 0),
                    "audio_channel_label": str(sig.get("channel_label") or ""),
                    "audio_label": audio_label,
                    "audio_stream_id": "",
                    "audio_stream_index": -1,
                    "audio_preferred_rank": 0,
                    "match_reason": str(copy_entry.get("match_reason") or ""),
                    "main_label": " ".join(x for x in ((res or "?").upper(), video_codec or "VIDEO", hdr_type if hdr_type and hdr_type != "SDR" else "") if x).strip(),
                    "sub_label": audio_label or "오디오 정보 없음",
                    "source_label": basename,
                    "basename": basename,
                })
        return rows

    def _info_movie_build_media_variants_v2106(self, source_rk, source_part="", reason="", expected_generation=None, publish_props=True):
        """Build exact movie Media/Part codec combinations for one Info owner.

        This helper is safe for the v2106 background prewarm lane: it performs
        DB/Plex work without reading the currently focused ListItem.  GUI
        properties are only published when explicitly requested and the same
        movie is still the active Info owner.
        """
        source_rk = str(source_rk or "").strip()
        source_part = str(source_part or "").strip()
        if not source_rk:
            return []
        started = time.monotonic()
        try:
            core_mod = _ensure_core()
            selected, configured = core_mod.selected_sections_state()
            selected = [str(x) for x in (selected or []) if str(x)] if configured else []
            if not selected:
                return []
            conn = _pkm_ro_connect(self._profile_db_path(), timeout=2.0)
            try:
                result = pkm_media_versions.find_movie_copy_candidates(conn, source_rk, selected)
            finally:
                conn.close()
            copies = list((result or {}).get("copies") or [])

            # v2106: these independent Plex metadata requests are the entire cold
            # first-click cost in v2105.  Run the small accepted-copy set in
            # parallel during post-Info prewarm so the popup itself only binds
            # cached rows.  Cap at four workers to avoid a request storm.
            rows = []
            if len(copies) > 1:
                workers = max(1, min(2 if self._is_android_v2591() else 4, len(copies)))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    futures = [executor.submit(self._info_movie_expand_media_copy_v2100, copy_entry, core_mod) for copy_entry in copies]
                    for future in futures:
                        try:
                            rows.extend(list(future.result() or []))
                        except Exception:
                            pass
            else:
                for copy_entry in copies:
                    rows.extend(self._info_movie_expand_media_copy_v2100(copy_entry, core_mod))

            exact_rows = []
            seen_exact = set()
            for row in rows:
                key = str(row.get("variant_key") or "")
                if not key or key in seen_exact:
                    continue
                seen_exact.add(key)
                exact_rows.append(row)

            grouped = {}
            group_order = []
            for row in exact_rows:
                combo_key = self._info_movie_media_combo_key_v2103(row)
                if not combo_key:
                    continue
                variant_key = str(row.get("variant_key") or "")
                if combo_key not in grouped:
                    rep = dict(row)
                    rep["combo_key"] = combo_key
                    rep["member_variant_keys"] = [variant_key] if variant_key else []
                    rep["member_count"] = 1
                    grouped[combo_key] = rep
                    group_order.append(combo_key)
                else:
                    rep = grouped[combo_key]
                    members = list(rep.get("member_variant_keys") or [])
                    if variant_key and variant_key not in members:
                        members.append(variant_key)
                    rep["member_variant_keys"] = members
                    rep["member_count"] = len(members)
                    current_is_source = (str(rep.get("rating_key") or "") == source_rk and str(rep.get("part_key") or "") == source_part)
                    candidate_is_source = (str(row.get("rating_key") or "") == source_rk and str(row.get("part_key") or "") == source_part)
                    current_audio_rank = int(rep.get("audio_preferred_rank") if rep.get("audio_preferred_rank") is not None else 9)
                    candidate_audio_rank = int(row.get("audio_preferred_rank") if row.get("audio_preferred_rank") is not None else 9)
                    if candidate_is_source and (not current_is_source or candidate_audio_rank < current_audio_rank):
                        keep_members = rep.get("member_variant_keys") or []
                        keep_count = rep.get("member_count") or len(keep_members)
                        rep = dict(row)
                        rep["combo_key"] = combo_key
                        rep["member_variant_keys"] = list(keep_members)
                        rep["member_count"] = keep_count
                        grouped[combo_key] = rep

            rows = [grouped[k] for k in group_order]
            rank = {"2160p": 0, "1080p": 1, "720p": 2, "480p": 3}
            rows.sort(key=lambda row: (
                rank.get(str(row.get("resolution") or "").lower(), 9),
                str(row.get("video_codec") or ""), str(row.get("hdr_type") or ""),
                str(row.get("audio_codec") or ""), int(row.get("audio_atmos") or 0),
                int(row.get("audio_channels") or 0), int(row.get("audio_preferred_rank") if row.get("audio_preferred_rank") is not None else 9),
                str(row.get("section_id") or ""), str(row.get("rating_key") or ""),
                str(row.get("part_key") or ""),
            ))

            # A stale post-Info worker must never resurrect a cache after Info was
            # closed/reset.  The synchronous click path passes no generation and
            # therefore always commits its own result.
            if expected_generation is not None:
                try:
                    with self._info_movie_media_prewarm_lock_v2106:
                        if int(expected_generation) != int(self._info_movie_media_prewarm_generation_v2106):
                            _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_STALE_V2106 source_rk=%s expected=%s current=%s reason=%s" % (
                                source_rk, expected_generation, self._info_movie_media_prewarm_generation_v2106, reason or ""
                            ))
                            return []
                except Exception:
                    return []

            try:
                with self._info_movie_media_prewarm_lock_v2106:
                    cache = dict(getattr(self, "_info_movie_media_cache_v2100", {}) or {})
                    cache[source_rk] = [dict(x) for x in rows]
                    self._info_movie_media_cache_v2100 = cache
            except Exception:
                self._info_movie_media_cache_v2100 = {source_rk: [dict(x) for x in rows]}

            if publish_props:
                try:
                    current_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "").strip()
                    if current_rk == source_rk:
                        self._info_set_property_all("PlexKM.Info.MediaVersionAvailable", "1" if rows else "")
                        self._info_set_property_all("PlexKM.Info.MediaVersionCount", str(len(rows)) if rows else "")
                except Exception:
                    pass
            elapsed_ms = int((time.monotonic() - started) * 1000.0)
            _log("INFO_MOVIE_MEDIA_VERSION_DISCOVER_V2106 source_rk=%s copies=%d codec_variants=%d selected_scope=%s elapsed_ms=%d reason=%s" % (
                source_rk, len(copies), len(rows), ",".join(selected), elapsed_ms, reason or ""
            ))
            return [dict(x) for x in rows]
        except Exception:
            _log("INFO_MOVIE_MEDIA_VERSION_DISCOVER_FAILED_V2106 source_rk=%s reason=%s err=%s" % (
                source_rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return []

    def _info_movie_schedule_media_prewarm_v2106(self, li, reason=""):
        """Warm movie Media/Part codec rows immediately after Info publication."""
        try:
            if not li or str(li.getProperty("PlexKM.Type") or "").strip().lower() != "movie":
                return False
            source_rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            source_part = str(li.getProperty("PlexKM.PartKey") or "").strip()
            if not source_rk:
                return False
            try:
                cache = getattr(self, "_info_movie_media_cache_v2100", {}) or {}
                if source_rk in cache:
                    _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_HIT_V2106 source_rk=%s rows=%d reason=%s" % (
                        source_rk, len(cache.get(source_rk) or []), reason or ""
                    ))
                    return True
            except Exception:
                pass
            with self._info_movie_media_prewarm_lock_v2106:
                if source_rk in self._info_movie_media_prewarm_inflight_v2106:
                    return True
                generation = int(self._info_movie_media_prewarm_generation_v2106)
                self._info_movie_media_prewarm_inflight_v2106.add(source_rk)

            def _worker():
                t0 = time.monotonic()
                try:
                    # Let the Info frame paint first.  This is deliberately tiny:
                    # network work starts almost immediately but never blocks the
                    # visible Info publish call.
                    xbmc.Monitor().waitForAbort(0.03)
                    if _pkm_playback_active_v1411():
                        return
                    rows = self._info_movie_build_media_variants_v2106(
                        source_rk, source_part=source_part, reason="prewarm_%s" % (reason or "info"),
                        expected_generation=generation, publish_props=False,
                    )
                    elapsed_ms = int((time.monotonic() - t0) * 1000.0)
                    _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_DONE_V2106 source_rk=%s rows=%d elapsed_ms=%d reason=%s" % (
                        source_rk, len(rows), elapsed_ms, reason or ""
                    ))
                except Exception:
                    _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_FAILED_V2106 source_rk=%s reason=%s err=%s" % (
                        source_rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    try:
                        with self._info_movie_media_prewarm_lock_v2106:
                            self._info_movie_media_prewarm_inflight_v2106.discard(source_rk)
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_worker, name="PKMMovieMediaPrewarmV2106", daemon=True).start()
            _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_START_V2106 source_rk=%s generation=%s reason=%s" % (
                source_rk, generation, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_MOVIE_MEDIA_VERSION_PREWARM_START_FAILED_V2106 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_movie_media_variants_v2100(self, reason=""):
        li = getattr(self, "_inline_info_item", None) or self._focused_wall_item()
        if not li:
            return []
        source_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or li.getProperty("PlexKM.RatingKey") or "").strip()
        source_part = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.PartKey") or li.getProperty("PlexKM.PartKey") or "").strip()
        if not source_rk:
            return []
        try:
            cache = getattr(self, "_info_movie_media_cache_v2100", {}) or {}
            if source_rk in cache:
                rows = [dict(x) for x in (cache.get(source_rk) or [])]
                _log("INFO_MOVIE_MEDIA_VERSION_CACHE_HIT_V2106 source_rk=%s rows=%d reason=%s" % (
                    source_rk, len(rows), reason or ""
                ))
                return rows
        except Exception:
            pass
        # Fallback only for an unusually fast click that beats the post-Info
        # worker.  Normal v2106 popup opens never reach this network path.
        _log("INFO_MOVIE_MEDIA_VERSION_CACHE_MISS_V2106 source_rk=%s reason=%s" % (source_rk, reason or ""))
        return self._info_movie_build_media_variants_v2106(
            source_rk, source_part=source_part, reason="click_fallback_%s" % (reason or "open"),
            expected_generation=None, publish_props=True,
        )

    def _info_movie_apply_media_variant_v2100(self, entry, reason=""):
        if not isinstance(entry, dict):
            return False
        try:
            source_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "").strip()
            part_key = str(entry.get("part_key") or "").strip()
            rating_key = str(entry.get("rating_key") or "").strip()
            if not source_rk or not part_key or not rating_key:
                return False
            selected = dict(entry)
            selected["owner_rating_key"] = source_rk
            self._info_movie_media_override_v2100 = selected
            resolution = str(selected.get("resolution") or "").strip().lower()
            if resolution:
                self._info_set_property_all("PlexKM.Info.VersionLabel", resolution)
                self._info_set_property_all("PlexKM.Info.VersionIconLabel", resolution.upper())
            self._info_set_property_all("PlexKM.Info.VersionRatingKey", rating_key)
            self._info_set_property_all("PlexKM.Info.VersionSectionId", str(selected.get("section_id") or ""))
            self._info_set_property_all("PlexKM.Info.VersionPartKey", part_key)
            self._info_set_property_all("PlexKM.Info.VersionMatchReason", str(selected.get("match_reason") or "MEDIA_VARIANT"))
            self._info_set_property_all("PlexKM.Info.MediaVersionSelectedKey", str(selected.get("variant_key") or "%s|%s" % (rating_key, part_key)))
            self._info_set_property_all("PlexKM.Info.MediaVersionVideo", str(selected.get("main_label") or ""))
            self._info_set_property_all("PlexKM.Info.MediaVersionAudio", str(selected.get("audio_label") or ""))
            self._info_set_property_all("PlexKM.Info.MediaVersionHDR", str(selected.get("hdr_type") or ""))
            self._info_set_property_all("PlexKM.Info.MediaVersionAudioStreamIndex", str(selected.get("audio_stream_index") if selected.get("audio_stream_index") is not None else ""))
            # Keep the quick-resolution cycle's index synchronized when this
            # detailed row corresponds to one of its representative targets.
            versions = list(getattr(self, "_info_movie_versions_v2088", []) or [])
            for idx, version in enumerate(versions):
                if (str(version.get("rating_key") or "") == rating_key and
                        str(version.get("resolution") or "").lower() == resolution):
                    self._info_movie_version_index_v2088 = idx
                    break
            _log("INFO_MOVIE_MEDIA_VERSION_SELECT_V2100 info_rk=%s target_rk=%s part=%s resolution=%s video=%s audio=%s no_refresh=1 reason=%s" % (
                source_rk, rating_key, part_key, resolution, selected.get("video_codec") or "",
                selected.get("audio_label") or "", reason or ""
            ))
            return True
        except Exception:
            _log("INFO_MOVIE_MEDIA_VERSION_SELECT_FAILED_V2100 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_movie_close_media_versions_v2104(self, restore_focus=True, reason=""):
        """Close only the inline codec popup; leave the Info surface untouched."""
        try:
            self._info_clear_property_all("PlexKM.Info.MediaVersionPopupOpen")
            origin = int(getattr(self, "_info_movie_media_popup_origin_v2104", 0) or 0)
            self._info_movie_media_popup_rows_v2104 = []
            if restore_focus and origin in (5008, 5009):
                try:
                    self.setFocusId(origin)
                except Exception:
                    pass
            _log("INFO_MOVIE_MEDIA_VERSION_INLINE_CLOSE_V2104 reason=%s focus=%s" % (reason or "", origin))
            return True
        except Exception:
            return False

    def _info_movie_select_media_version_inline_v2104(self, reason=""):
        """Apply the focused codec combination from the inline Home list."""
        try:
            rows = list(getattr(self, "_info_movie_media_popup_rows_v2104", []) or [])
            ctrl = self.getControl(7410)
            pos = int(ctrl.getSelectedPosition())
            if not (0 <= pos < len(rows)):
                return False
            chosen = dict(rows[pos])
            ok = self._info_movie_apply_media_variant_v2100(chosen, reason="inline_select_v2104")
            self._info_movie_close_media_versions_v2104(restore_focus=True, reason=reason or "select")
            return bool(ok)
        except Exception:
            _log("INFO_MOVIE_MEDIA_VERSION_INLINE_SELECT_FAILED_V2104 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            self._info_movie_close_media_versions_v2104(restore_focus=True, reason="select_failed")
            return False

    def _info_movie_open_media_versions_v2100(self, control_id=0, reason=""):
        """Open the movie codec-combination list inline inside the existing Info window."""
        try:
            # Toggle off if the same action is clicked again.
            if self.getProperty("PlexKM.Info.MediaVersionPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.MediaVersionPopupOpen") == "1":
                return self._info_movie_close_media_versions_v2104(restore_focus=True, reason="toggle")

            rows = self._info_movie_media_variants_v2100(reason=reason or "open")
            if not rows:
                self._show_pkm_notice("Plex KM", "미디어 버전 정보를 찾지 못했습니다", "", ms=2200)
                return False
            # v2106 prewarm itself does not touch GUI properties from its worker
            # thread. Publish the already-known count here on the GUI click path.
            self._info_set_property_all("PlexKM.Info.MediaVersionAvailable", "1")
            self._info_set_property_all("PlexKM.Info.MediaVersionCount", str(len(rows)))
            self._info_publish_media_popup_bg_color_v2209(reason="movie_open_%s" % (reason or "open"))
            source_rk = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "").strip()
            override = getattr(self, "_info_movie_media_override_v2100", None)
            if isinstance(override, dict) and str(override.get("owner_rating_key") or "") == source_rk:
                selected_key = str(override.get("variant_key") or "%s|%s" % (
                    override.get("rating_key") or "", override.get("part_key") or ""
                ))
            else:
                selected_version = self._info_movie_selected_version_v2088(info_rating_key=source_rk)
                if selected_version:
                    selected_key = "%s|%s" % (selected_version.get("rating_key") or "", selected_version.get("part_key") or "")
                else:
                    selected_key = "%s|%s" % (
                        source_rk, xbmcgui.Window(10000).getProperty("PlexKM.Info.PartKey") or ""
                    )

            if selected_key and "|a:" not in selected_key:
                base = selected_key + "|a:"
                matches = [r for r in rows if any(str(v or "").startswith(base) for v in (r.get("member_variant_keys") or [r.get("variant_key")]))]
                if matches:
                    matches.sort(key=lambda r: int(r.get("audio_preferred_rank") if r.get("audio_preferred_rank") is not None else 9))
                    selected_key = str(matches[0].get("variant_key") or selected_key)
            ctrl = self.getControl(7410)
            ctrl.reset()
            items = []
            selected_pos = 0
            for pos, row in enumerate(rows):
                resolution = str(row.get("resolution") or "").strip().upper()
                video_codec = str(row.get("video_codec") or "").strip()
                hdr_type = str(row.get("hdr_type") or "").strip()
                audio_label = str(row.get("audio_label") or "").strip()
                hdr_display = "" if hdr_type.upper() in ("", "SDR") else hdr_type
                display_label = " ".join(x for x in (resolution, video_codec, hdr_display, audio_label) if x).strip()
                li = xbmcgui.ListItem(label=display_label or "미디어 버전")
                row_key = str(row.get("variant_key") or "")
                members = [str(x or "") for x in (row.get("member_variant_keys") or []) if str(x or "")]
                is_selected = bool(selected_key and (row_key == selected_key or selected_key in members))
                li.setProperty("selected", "1" if is_selected else "")
                li.setProperty("variant_key", row_key)
                if is_selected:
                    selected_pos = pos
                items.append(li)
            ctrl.addItems(items)
            self._info_movie_media_popup_rows_v2104 = [dict(x) for x in rows]
            self._info_movie_media_popup_origin_v2104 = int(control_id or (5009 if str(xbmcgui.Window(10000).getProperty("PlexKM.Info.PlayButtonLabel") or "") == "이어서 재생" else 5008))
            self._info_set_property_all("PlexKM.Info.MediaVersionPopupOpen", "1")
            self.setFocusId(7410)
            ctrl.selectItem(max(0, min(len(items) - 1, selected_pos)))
            _log("INFO_MOVIE_MEDIA_VERSION_INLINE_OPEN_V2104 source_rk=%s codec_variants=%s selected_pos=%s origin=%s no_modal=1 no_dim=1 reason=%s" % (
                source_rk, len(rows), selected_pos, self._info_movie_media_popup_origin_v2104, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_MOVIE_MEDIA_VERSION_INLINE_OPEN_FAILED_V2104 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            try:
                self._info_clear_property_all("PlexKM.Info.MediaVersionPopupOpen")
                if int(control_id or 0) in (5008, 5009):
                    self.setFocusId(int(control_id))
            except Exception:
                pass
            return False

    def _info_movie_clear_versions_v2088(self, reason=""):
        """Clear movie playback-version state without touching the Info identity."""
        try:
            self._info_movie_media_variant_clear_v2100(reason="version_clear_%s" % (reason or ""))
        except Exception:
            pass
        try:
            self._info_movie_versions_v2088 = []
            self._info_movie_version_index_v2088 = -1
            self._info_movie_version_owner_key_v2088 = ""
            for key in (
                "PlexKM.Info.VersionAvailable", "PlexKM.Info.VersionMultiple",
                "PlexKM.Info.VersionLabel", "PlexKM.Info.VersionIconLabel", "PlexKM.Info.VersionCount",
                "PlexKM.Info.VersionRatingKey", "PlexKM.Info.VersionSectionId",
                "PlexKM.Info.VersionPartKey", "PlexKM.Info.VersionMatchReason",
                "PlexKM.Info.VersionHas720", "PlexKM.Info.VersionHas1080",
                "PlexKM.Info.VersionHas2160", "PlexKM.Info.VersionMenuOpen",
                "PlexKM.Info.VersionFirstFrameProvisionalVNext",
            ):
                self._info_clear_property_all(key)
            _log("INFO_MOVIE_VERSION_CLEAR_V2088 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _info_movie_resolution_first_frame_vnext(self, li, reason=""):
        """Publish the source movie's round resolution icon with no DB/network.

        The multi-version selector remains locked until the selected-libraries
        identity query returns. A missing source resolution is NOT guessed.
        """
        rk = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li else ""
        if not rk or str(li.getProperty("PlexKM.Type") or "").strip().lower() != "movie":
            return False
        # Raw metadata belongs to this exact rating key, not a same-title copy.
        resolution = str(li.getProperty("PlexKM.SourceResolutionFirstVNext") or "").strip().lower()
        source = "source_raw"
        if resolution not in ("720p", "1080p", "2160p"):
            if li.getProperty("PlexKM.Is4K") == "1":
                resolution = "2160p"
                source = "source_4k_flag"
            else:
                resolution = ""
        if not resolution:
            # PKM_INFO_RESOLUTION_POINT_LOOKUP_R34: actor-work / search tiles are
            # built without raw media values, so the round resolution icon used
            # to wait ~1.3 s for the post-visible version query while the other
            # action icons were already shown.  Read THIS rating key's own row
            # (primary-key point select, read-only) - never a sibling copy.
            t0_r34 = time.monotonic()
            try:
                dbp_r34 = self._profile_db_path()
                if dbp_r34 and os.path.exists(dbp_r34):
                    conn_r34 = _pkm_ro_connect(dbp_r34, timeout=0.5)
                    try:
                        row_r34 = conn_r34.execute(
                            "SELECT raw_json FROM items WHERE rating_key=? AND plex_type='movie' LIMIT 1", (rk,)
                        ).fetchone()
                    finally:
                        try:
                            conn_r34.close()
                        except Exception:
                            pass
                    raw_r34 = pkm_library_sort.sort_raw_values(row_r34[0]) if row_r34 and row_r34[0] else {}
                    res_r34 = str(raw_r34.get("resolution") or "").strip().lower()
                    height_r34 = _safe_int(raw_r34.get("height"), 0)
                    if res_r34 in ("4k", "uhd", "2160", "2160p") or "2160" in res_r34 or height_r34 >= 2000:
                        resolution = "2160p"
                    elif "1080" in res_r34 or height_r34 >= 1000:
                        resolution = "1080p"
                    elif "720" in res_r34 or height_r34 >= 700:
                        resolution = "720p"
                    if resolution:
                        source = "local_db_point_r34"
            except Exception as exc_r34:
                _log("INFO_RESOLUTION_POINT_LOOKUP_FAILED_R34 rating_key=%s err=%s" % (rk, exc_r34), xbmc.LOGWARNING)
                resolution = ""
            _log("INFO_RESOLUTION_POINT_LOOKUP_R34 rating_key=%s resolution=%s elapsed_ms=%.1f" % (
                rk, resolution or "-", (time.monotonic() - t0_r34) * 1000.0))
        if not resolution:
            _log("INFO_RESOLUTION_FIRSTFRAME_VNEXT rating_key=%s ready=0 reason=source_resolution_unknown db=1 net=0" % rk)
            return False
        # The caller has cleared any previous title's properties and group state.
        # The icon is dimmed/display-only until the asynchronous identity query
        # verifies all playable copies across the selected Plex libraries.
        self._info_set_property_all("PlexKM.Info.VersionAvailable", "1")
        self._info_set_property_all("PlexKM.Info.VersionLabel", resolution)
        self._info_set_property_all("PlexKM.Info.VersionIconLabel", resolution.upper())
        self._info_set_property_all("PlexKM.Info.VersionRatingKey", rk)
        self._info_set_property_all("PlexKM.Info.VersionSectionId", li.getProperty("PlexKM.SectionId") or "")
        self._info_set_property_all("PlexKM.Info.VersionPartKey", li.getProperty("PlexKM.PartKey") or "")
        self._info_set_property_all("PlexKM.Info.VersionMatchReason", "SOURCE_PROVISIONAL_VNEXT")
        self._info_set_property_all("PlexKM.Info.VersionFirstFrameProvisionalVNext", "1")
        _log("INFO_RESOLUTION_FIRSTFRAME_VNEXT rating_key=%s ready=1 resolution=%s source=%s icon=visible provisional=1 group_verified=0 gui_db=0 net=0 reason=%s" % (
            rk, resolution, source, reason or ""))
        return True

    def _info_movie_precompute_versions_v2185(self, li, reason=""):
        """Query movie version data without publishing any visible Info state.

        Actor-work Info chaining keeps the current Info page visible while the
        target is prepared.  The older v2088 helper also writes PlexKM.Info.*
        properties, so calling it during that stage would mutate the visible
        parent.  This helper performs only the selected-library/SQLite lookup and
        stores the result for the final atomic publish.
        """
        try:
            plex_type = str(li.getProperty("PlexKM.Type") or "").strip().lower() if li else ""
            rating_key = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li else ""
            if plex_type != "movie" or not rating_key:
                return None
            # V2602 UHD: movie resolution grouping is not a first-frame
            # prerequisite. On Android, never enter selected-section/SQLite work
            # from this pre-visible helper; the post-visible worker owns it.
            if self._uhd_kpi_proxy_v2605():
                self._info_movie_precomputed_versions_v2185 = None
                _log("INFO_MOVIE_VERSION_PREVISIBLE_DEFER_V2605 rating_key=%s reason=%s foreground_sql=0 postvisible=1 proxy=%d" % (
                    rating_key, reason or "", 0 if self._is_android_v2591() else 1
                ))
                return None
            core_mod = _ensure_core()
            selected, configured = core_mod.selected_sections_state()
            selected = [str(x) for x in (selected or []) if str(x)] if configured else []
            # v2508: consume the settled-focus plain-data result when it matches
            # the current selected-library scope.  TTL is intentionally short;
            # stale/missing data simply falls through to the established query.
            try:
                with self._info_focus_prewarm_lock_v2508:
                    focus_rec_v2508 = dict(self._info_focus_prewarm_cache_v2508.get(rating_key) or {})
                focus_versions_v2508 = focus_rec_v2508.get("versions")
                age_v2508 = max(0.0, time.time() - float(focus_rec_v2508.get("ts") or 0.0))
                if (age_v2508 <= 15.0 and isinstance(focus_versions_v2508, dict)
                        and list(focus_versions_v2508.get("selected") or []) == list(selected)):
                    payload = {
                        "rating_key": rating_key,
                        "selected": list(selected),
                        "versions": list(focus_versions_v2508.get("versions") or []),
                        "default_resolution": str(focus_versions_v2508.get("default_resolution") or "").strip(),
                    }
                    self._info_movie_precomputed_versions_v2185 = payload
                    _log("INFO_MOVIE_VERSION_FOCUS_PREWARM_HIT_V2508 rating_key=%s selected_scope=%s versions=%d age_ms=%d gui_db_query=0 reason=%s" % (
                        rating_key, ",".join(selected), len(payload.get("versions") or []), int(age_v2508 * 1000.0), reason or ""
                    ))
                    return payload
            except Exception:
                pass
            # V2617 replacement: if stable-focus prewarm missed, do not open SQLite
            # on the Info click path. The current movie remains fully playable from
            # its existing ListItem; multi-version grouping is completed immediately
            # after the first interactive frame. Actor behavior is intentionally
            # unchanged in this replacement patch.
            if not self._is_android_v2591():
                self._info_movie_precomputed_versions_v2185 = None
                _log("INFO_MOVIE_VERSION_PREVISIBLE_DEFER_V2617 rating_key=%s reason=%s foreground_sql=0 postvisible=1 pc_reference=1" % (
                    rating_key, reason or ""
                ))
                return None
            versions = []
            default_resolution = ""
            if selected:
                try:
                    if xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") != "1":
                        self._kpi_info_pre_sql_v2605 = 1
                except Exception:
                    pass
                dbp = self._profile_db_path()
                _query_t0_v2515 = self._now_ms()
                conn = _pkm_ro_connect(dbp, timeout=2.0)
                try:
                    result = pkm_media_versions.find_movie_versions(conn, rating_key, selected)
                finally:
                    conn.close()
                versions = list((result or {}).get("versions") or [])
                default_resolution = str((result or {}).get("default_resolution") or "").strip()
                versions = [v for v in versions if str(v.get("resolution") or "") in ("720p", "1080p", "2160p")]
                _log("INFO_MOVIE_VERSION_QUERY_V2515 rating_key=%s selected_sections=%d elapsed_ms=%d indexed_year_predicate=1 foreground=1" % (
                    rating_key, len(selected), self._now_ms() - _query_t0_v2515
                ))
            payload = {
                "rating_key": rating_key,
                "selected": list(selected),
                "versions": list(versions),
                "default_resolution": default_resolution,
            }
            self._info_movie_precomputed_versions_v2185 = payload
            _log("INFO_MOVIE_VERSION_PRECOMPOSE_V2185 rating_key=%s selected_scope=%s versions=%d default=%s visible_mutation=0 reason=%s" % (
                rating_key, ",".join(selected), len(versions), default_resolution or "", reason or ""
            ))
            return payload
        except Exception:
            self._info_movie_precomputed_versions_v2185 = None
            _log("INFO_MOVIE_VERSION_PRECOMPOSE_FAILED_V2185 rating_key=%s reason=%s err=%s" % (
                str(li.getProperty("PlexKM.RatingKey") or "") if li else "", reason or "",
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return None

    def _info_movie_schedule_versions_postvisible_v2602(self, li, reason=""):
        """Android/U+ and V2605 desktop proxy resolution grouping after first frame."""
        try:
            if li is None:
                return False
            if str(li.getProperty("PlexKM.Type") or "").strip().lower() != "movie":
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            # A detached prewarm payload may already have been consumed without SQL.
            if str(getattr(self, "_info_movie_version_owner_key_v2088", "") or "") == rk:
                _log("INFO_MOVIE_VERSION_POSTVISIBLE_SKIP_V2602 rating_key=%s reason=already_ready" % rk)
                return True
            token = int(getattr(self, "_info_movie_versions_postvisible_token_v2602", 0) or 0) + 1
            self._info_movie_versions_postvisible_token_v2602 = token
            dbp = self._profile_db_path()
            self._info_movie_versions_postvisible_pending_v2602 = {
                "token": token, "rating_key": rk, "state": "waiting",
                "started_ms": self._now_ms(), "reason": str(reason or ""),
            }
            _delay_v2617 = 0.650 if self._is_android_v2591() else 0.120
            _log("INFO_MOVIE_VERSION_POSTVISIBLE_ARM_V2617 rating_key=%s token=%d first_frame_visible=1 foreground_sql=0 delay_ms=%d" % (
                rk, token, int(_delay_v2617 * 1000.0)
            ))

            def _worker_v2602():
                t0 = self._now_ms()
                try:
                    if self._closing_event_v1841.wait(_delay_v2617):
                        return
                    rec = getattr(self, "_info_movie_versions_postvisible_pending_v2602", None)
                    if not isinstance(rec, dict) or int(rec.get("token") or 0) != token:
                        return
                    try:
                        win = xbmcgui.Window(10000)
                        active_rk = str(win.getProperty("PlexKM.Info.RatingKey") or "").strip()
                        inline = (win.getProperty("PlexKM.Info.InlineActive") == "1")
                    except Exception:
                        active_rk = rk
                        inline = True
                    if not inline or active_rk != rk:
                        self._info_movie_versions_postvisible_pending_v2602 = None
                        _log("INFO_MOVIE_VERSION_POSTVISIBLE_STALE_DROP_V2602 rating_key=%s active=%s inline=%d query=0" % (
                            rk, active_rk, 1 if inline else 0
                        ))
                        return
                    # Actor page has priority. Do not start a hidden parent-Info DB
                    # query while the user is already interacting with ActorProfile.
                    try:
                        actor_active = (xbmcgui.Window(10000).getProperty("PlexKM.ActorProfile.Active") == "1")
                    except Exception:
                        actor_active = False
                    if actor_active:
                        self._info_movie_versions_postvisible_pending_v2602 = None
                        _log("INFO_MOVIE_VERSION_POSTVISIBLE_ACTOR_SUPPRESS_V2602 rating_key=%s token=%d query=0" % (rk, token))
                        return
                    core_mod = _ensure_core()
                    selected, configured = core_mod.selected_sections_state()
                    selected = [str(x) for x in (selected or []) if str(x)] if configured else []
                    versions = []
                    default_resolution = ""
                    query_t0 = self._now_ms()
                    if selected:
                        conn = _pkm_ro_connect(dbp, timeout=2.0)
                        try:
                            result = pkm_media_versions.find_movie_versions(conn, rk, selected)
                        finally:
                            conn.close()
                        versions = list((result or {}).get("versions") or [])
                        default_resolution = str((result or {}).get("default_resolution") or "").strip()
                        versions = [v for v in versions if str(v.get("resolution") or "") in ("720p", "1080p", "2160p")]
                    query_ms = self._now_ms() - query_t0
                    rec = getattr(self, "_info_movie_versions_postvisible_pending_v2602", None)
                    if not isinstance(rec, dict) or int(rec.get("token") or 0) != token:
                        return
                    rec["state"] = "ready"
                    rec["payload"] = {
                        "rating_key": rk, "selected": list(selected),
                        "versions": list(versions), "default_resolution": default_resolution,
                    }
                    rec["query_ms"] = query_ms
                    rec["elapsed_ms"] = self._now_ms() - t0
                    _log("INFO_MOVIE_VERSION_QUERY_POSTVISIBLE_V2602 rating_key=%s selected_sections=%d versions=%d query_ms=%d elapsed_ms=%d foreground=0" % (
                        rk, len(selected), len(versions), query_ms, rec["elapsed_ms"]
                    ))
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    rec = getattr(self, "_info_movie_versions_postvisible_pending_v2602", None)
                    if isinstance(rec, dict) and int(rec.get("token") or 0) == token:
                        rec["state"] = "failed"
                    _log("INFO_MOVIE_VERSION_QUERY_POSTVISIBLE_FAILED_V2602 rating_key=%s token=%d err=%s" % (
                        rk, token, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                    try:
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_worker_v2602, name="PKMInfoMovieVersionV2602", daemon=True).start()
            return True
        except Exception:
            _log("INFO_MOVIE_VERSION_POSTVISIBLE_ARM_FAILED_V2602 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_movie_versions_postvisible_commit_v2602(self):
        """GUI-thread commit for V2602 deferred movie resolution grouping."""
        try:
            rec = getattr(self, "_info_movie_versions_postvisible_pending_v2602", None)
            if not isinstance(rec, dict) or rec.get("state") not in ("ready", "failed"):
                return False
            rk = str(rec.get("rating_key") or "")
            active = str(self.getProperty("PlexKM.Info.RatingKey") or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "")
            if not rk or active != rk:
                self._info_movie_versions_postvisible_pending_v2602 = None
                _log("INFO_MOVIE_VERSION_POSTVISIBLE_COMMIT_STALE_V2602 rating_key=%s active=%s" % (rk, active))
                return False
            if rec.get("state") != "ready":
                self._info_movie_versions_postvisible_pending_v2602 = None
                _log("INFO_MOVIE_VERSION_POSTVISIBLE_COMMIT_V2602 rating_key=%s result=failed properties=unchanged" % rk)
                return False
            li = getattr(self, "_inline_info_item", None)
            if li is None or str(li.getProperty("PlexKM.RatingKey") or "") != rk:
                self._info_movie_versions_postvisible_pending_v2602 = None
                return False
            payload = dict(rec.get("payload") or {})
            self._info_movie_precomputed_versions_v2185 = payload
            t0 = self._now_ms()
            self._info_movie_prepare_versions_v2088(li, reason="postvisible_commit_v2602")
            bind_ms = self._now_ms() - t0
            self._info_movie_versions_postvisible_pending_v2602 = None
            _log("INFO_RESOLUTION_GROUP_VERIFIED_VNEXT rating_key=%s versions=%d query_ms=%d bind_ms=%d provisional_cleared=1 gpu_texture_ready=unknown" % (
                rk, len(payload.get("versions") or []), int(rec.get("query_ms") or 0), bind_ms
            ))
            _log("INFO_MOVIE_VERSION_POSTVISIBLE_COMMIT_V2602 rating_key=%s versions=%d query_ms=%d bind_ms=%d visible_already=1 focus_write=0" % (
                rk, len(payload.get("versions") or []), int(rec.get("query_ms") or 0), bind_ms
            ))
            return True
        except Exception:
            _log("INFO_MOVIE_VERSION_POSTVISIBLE_COMMIT_FAILED_V2602 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_movie_prepare_versions_v2088(self, li, reason=""):
        """Build one movie-version group from all PKM-selected movie libraries.

        v2088 deliberately does not key this lookup to the current sidebar section.
        The selected-library set is the only scope boundary.  The visible Info item
        remains canonical; selecting a version only changes the playback target.
        """
        try:
            plex_type = str(li.getProperty("PlexKM.Type") or "").strip().lower() if li else ""
            rating_key = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li else ""
            if plex_type != "movie" or not rating_key:
                self._info_movie_clear_versions_v2088(reason="non_movie_%s" % (reason or ""))
                return []
            # v2100: movie media-version action is always available for a playable
            # movie. Detailed Media/Part discovery stays lazy until the user opens
            # the popup, so Info opening does not gain a new Plex network wait.
            if str(li.getProperty("PlexKM.PartKey") or "").strip():
                self._info_set_property_all("PlexKM.Info.MediaVersionAvailable", "1")
            _precomputed_v2185 = getattr(self, "_info_movie_precomputed_versions_v2185", None)
            if isinstance(_precomputed_v2185, dict) and str(_precomputed_v2185.get("rating_key") or "") == rating_key:
                selected = [str(x) for x in (_precomputed_v2185.get("selected") or []) if str(x)]
                versions = list(_precomputed_v2185.get("versions") or [])
                default_resolution = str(_precomputed_v2185.get("default_resolution") or "").strip()
                self._info_movie_precomputed_versions_v2185 = None
                _log("INFO_MOVIE_VERSION_PRECOMPOSE_REUSE_V2185 rating_key=%s selected_scope=%s versions=%d reason=%s visible_query=0" % (
                    rating_key, ",".join(selected), len(versions), reason or ""
                ))
            else:
                if self._uhd_kpi_proxy_v2605() or not self._is_android_v2591():
                    # V2617: no platform performs movie-version SQLite on the pre-visible click path.
                    # this method before InlineActive. If no detached result is
                    # already available, leave the version action empty for the
                    # first frame instead of doing foreground SQLite.
                    self._info_movie_versions_v2088 = []
                    self._info_movie_version_index_v2088 = -1
                    self._info_movie_version_owner_key_v2088 = ""
                    for _v2602_key in (
                        "PlexKM.Info.VersionAvailable", "PlexKM.Info.VersionMultiple",
                        "PlexKM.Info.VersionLabel", "PlexKM.Info.VersionIconLabel",
                        "PlexKM.Info.VersionCount", "PlexKM.Info.VersionRatingKey",
                        "PlexKM.Info.VersionSectionId", "PlexKM.Info.VersionPartKey",
                        "PlexKM.Info.VersionMatchReason", "PlexKM.Info.VersionHas720",
                        "PlexKM.Info.VersionHas1080", "PlexKM.Info.VersionHas2160",
                        "PlexKM.Info.VersionMenuOpen",
                    ):
                        self._info_clear_property_all(_v2602_key)
                    _source_badge_first_vnext = self._info_movie_resolution_first_frame_vnext(
                        li, reason="previsible_%s" % (reason or ""))
                    _log("INFO_MOVIE_VERSION_PUBLISH_DEFER_V2617 rating_key=%s reason=%s foreground_sql=0 first_frame=1 proxy=%d source_badge=%d" % (
                        rating_key, reason or "", 0 if self._is_android_v2591() else 1,
                        1 if _source_badge_first_vnext else 0
                    ))
                    return []
                core_mod = _ensure_core()
                selected, configured = core_mod.selected_sections_state()
                selected = [str(x) for x in (selected or []) if str(x)] if configured else []
                versions = []
                default_resolution = ""
                if selected:
                    try:
                        if xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") != "1":
                            self._kpi_info_pre_sql_v2605 = 1
                    except Exception:
                        pass
                    dbp = self._profile_db_path()
                    conn = _pkm_ro_connect(dbp, timeout=2.0)
                    try:
                        result = pkm_media_versions.find_movie_versions(conn, rating_key, selected)
                    finally:
                        conn.close()
                    versions = list((result or {}).get("versions") or [])
                    default_resolution = str((result or {}).get("default_resolution") or "").strip()
            if not selected:
                self._info_movie_clear_versions_v2088(reason="no_selected_sections")
                return []
            # A same-Info background republish must not undo the user's explicit
            # 1080p/2160p selection. Preserve the current label only when the
            # version owner is the same canonical Info item.
            previous_resolution_v2088 = ""
            try:
                if str(getattr(self, "_info_movie_version_owner_key_v2088", "") or "") == rating_key:
                    previous_resolution_v2088 = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.VersionLabel") or "").strip()
            except Exception:
                previous_resolution_v2088 = ""
            # Keep only the explicitly supported selector classes.
            versions = [v for v in versions if str(v.get("resolution") or "") in ("720p", "1080p", "2160p")]
            if previous_resolution_v2088 and any(str(v.get("resolution") or "") == previous_resolution_v2088 for v in versions):
                default_resolution = previous_resolution_v2088
            self._info_clear_property_all("PlexKM.Info.VersionFirstFrameProvisionalVNext")
            self._info_movie_versions_v2088 = versions
            self._info_movie_version_owner_key_v2088 = rating_key
            selected_idx = -1
            if versions:
                # R108: with a Plex and a Kodi copy of the same resolution, start
                # on the copy this Info was opened from.
                for idx, entry in enumerate(versions):
                    if (str(entry.get("resolution") or "") == default_resolution
                            and str(entry.get("rating_key") or "") == str(rating_key)):
                        selected_idx = idx
                        break
                for idx, entry in enumerate(versions):
                    if selected_idx >= 0:
                        break
                    if str(entry.get("resolution") or "") == default_resolution:
                        selected_idx = idx
                        break
                if selected_idx < 0:
                    selected_idx = 0
            self._info_movie_version_index_v2088 = selected_idx

            # v2094: one round action at the end of the movie action row always
            # displays the current playback target (720P/1080P/2160P).  The first
            # target is the resolution of the source/current-library item.  When
            # more than one real version exists, Enter only swaps the target
            # properties in place: no Info rebuild, wall refresh, spinner, or focus
            # handoff. A single-version icon is display-only/gray in XML.
            self._info_clear_property_all("PlexKM.Info.VersionMenuOpen")
            for _res_v2089, _prop_v2089 in (("720p", "PlexKM.Info.VersionHas720"), ("1080p", "PlexKM.Info.VersionHas1080"), ("2160p", "PlexKM.Info.VersionHas2160")):
                if any(str(v.get("resolution") or "") == _res_v2089 for v in versions):
                    self._info_set_property_all(_prop_v2089, "1")
                else:
                    self._info_clear_property_all(_prop_v2089)
            if not versions:
                self._info_clear_property_all("PlexKM.Info.VersionAvailable")
                self._info_clear_property_all("PlexKM.Info.VersionMultiple")
                self._info_clear_property_all("PlexKM.Info.VersionCount")
                return versions

            self._info_set_property_all("PlexKM.Info.VersionAvailable", "1")
            self._info_set_property_all("PlexKM.Info.VersionCount", str(len(versions)))
            if len(versions) >= 2:
                self._info_set_property_all("PlexKM.Info.VersionMultiple", "1")
            else:
                self._info_clear_property_all("PlexKM.Info.VersionMultiple")
            self._info_movie_publish_selected_version_v2088(reason="prepare_%s" % (reason or ""))
            if len(versions) < 2:
                only = versions[0]
                _log("INFO_MOVIE_VERSION_SINGLE_V2089 info_rk=%s section=%s resolution=%s selected_scope=%s icon=visible cycle=disabled reason=%s" % (
                    rating_key, only.get("section_id") or "", only.get("resolution") or "",
                    ",".join(selected), reason or ""
                ))
                return versions
            parts = []
            for entry in versions:
                parts.append("%s:rk%s@s%s[%s,d%s]" % (
                    entry.get("resolution") or "?", entry.get("rating_key") or "?",
                    entry.get("section_id") or "?", entry.get("match_reason") or "?",
                    entry.get("duration_delta") if entry.get("duration_delta") is not None else "?",
                ))
            _log("INFO_MOVIE_VERSION_GROUP_V2088 info_rk=%s selected_scope=%s default=%s versions=%s sidebar_independent=1" % (
                rating_key, ",".join(selected), default_resolution or "", "|".join(parts)
            ))
            return versions
        except Exception:
            self._info_movie_clear_versions_v2088(reason="prepare_failed")
            _log("INFO_MOVIE_VERSION_PREPARE_FAILED_V2088 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return []

    def _info_movie_publish_selected_version_v2088(self, reason=""):
        try:
            versions = list(getattr(self, "_info_movie_versions_v2088", []) or [])
            idx = int(getattr(self, "_info_movie_version_index_v2088", -1))
            if not versions or idx < 0 or idx >= len(versions):
                return None
            entry = versions[idx]
            _resolution_v2093 = str(entry.get("resolution") or "")
            self._info_set_property_all("PlexKM.Info.VersionLabel", _resolution_v2093)
            self._info_set_property_all("PlexKM.Info.VersionIconLabel", _resolution_v2093.upper())
            # R108: name the source only when the same resolution exists in both.
            _is_kodi_r108 = str(entry.get("rating_key") or "").startswith("k:")
            _twin_r108 = any(str(v.get("resolution") or "") == _resolution_v2093
                             and str(v.get("rating_key") or "").startswith("k:") != _is_kodi_r108 for v in versions)
            self._info_set_property_all("PlexKM.Info.VersionSourceR108", ("Kodi" if _is_kodi_r108 else "Plex") if _twin_r108 else "")
            self._info_set_property_all("PlexKM.Info.VersionRatingKey", str(entry.get("rating_key") or ""))
            self._info_set_property_all("PlexKM.Info.VersionSectionId", str(entry.get("section_id") or ""))
            self._info_set_property_all("PlexKM.Info.VersionPartKey", str(entry.get("part_key") or ""))
            self._info_set_property_all("PlexKM.Info.VersionMatchReason", str(entry.get("match_reason") or ""))
            _log("INFO_MOVIE_VERSION_SELECTED_V2088 reason=%s index=%d resolution=%s target_rk=%s target_section=%s match=%s" % (
                reason or "", idx, entry.get("resolution") or "", entry.get("rating_key") or "",
                entry.get("section_id") or "", entry.get("match_reason") or ""
            ))
            self._info_version_playstate_r108(entry, reason=reason)
            return entry
        except Exception:
            return None

    def _info_version_playstate_r108(self, entry, reason=""):
        """R108: a Plex <-> Kodi-library version switch shows that copy's own
        progress (remaining time, 이어서 재생/재생, watched pill).

        Same-source switches (Plex 1080p <-> 2160p) keep the historical
        behaviour.  Switching back to the Info title restores its state.
        """
        try:
            win = xbmcgui.Window(10000)
            info_rk = str(win.getProperty("PlexKM.Info.RatingKey") or "").strip()
            target_rk = str((entry or {}).get("rating_key") or "").strip()
            if not info_rk or not target_rk:
                return
            keys = ("PlexKM.Info.ViewOffset", "PlexKM.Info.Duration", "PlexKM.Info.RemainingText",
                    "PlexKM.Info.RemainingIcon", "PlexKM.Info.PlayButtonLabel", "PlexKM.Info.IsWatchedR60",
                    "PlexKM.Info.DurationText", "PlexKM.Info.MetaLineBaseV2313")
            saved = getattr(self, "_info_version_saved_state_r108", None)
            if saved is not None and saved.get("rk") != info_rk:
                saved = None
            if target_rk == info_rk:
                if saved:
                    for k in keys:
                        self._info_set_property_all(k, saved["props"].get(k, ""))
                    _log("INFO_VERSION_PLAYSTATE_RESTORE_R108 rating_key=%s" % info_rk)
                    self._info_version_saved_state_r108 = None
                    self._info_version_pill_refocus_r108()
                return
            if info_rk.startswith("k:") == target_rk.startswith("k:"):
                return
            if saved is None:
                self._info_version_saved_state_r108 = {"rk": info_rk, "props": dict((k, win.getProperty(k) or "") for k in keys)}
            view_offset, duration, watched = 0, 0, ""
            conn = None
            try:
                c = _ensure_core()
                conn = c.init_db()
                row = conn.execute("SELECT duration, view_count, raw_json FROM items WHERE rating_key=?", (target_rk,)).fetchone()
                if row:
                    duration = _safe_int(row[0], 0)
                    watched = "1" if _safe_int(row[1], 0) > 0 else ""
                    try:
                        view_offset = _safe_int((json.loads(row[2] or "{}") or {}).get("viewOffset"), 0)
                    except Exception:
                        view_offset = 0
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
            remaining_text, remaining_icon = self._remaining_time_props(str(duration or ""), str(view_offset or ""))
            self._info_set_property_all("PlexKM.Info.ViewOffset", str(view_offset or ""))
            self._info_set_property_all("PlexKM.Info.Duration", str(duration or ""))
            self._info_set_property_all("PlexKM.Info.RemainingText", remaining_text if view_offset else "")
            self._info_set_property_all("PlexKM.Info.RemainingIcon", remaining_icon if view_offset else "")
            self._info_set_property_all("PlexKM.Info.PlayButtonLabel", self._play_button_label(view_offset, duration, duration))
            self._info_set_property_all("PlexKM.Info.IsWatchedR60", watched)
            # Runtime label follows the selected copy as well.
            dur_text = self._duration_text(duration) if duration else ""
            if dur_text:
                self._info_set_property_all("PlexKM.Info.DurationText", dur_text)
                try:
                    self._info_set_property_all("PlexKM.Info.MetaLineBaseV2313", self._home_meta_line_base_v2291(
                        win.getProperty("PlexKM.Info.Type") or "movie", "", "",
                        win.getProperty("PlexKM.Info.Year") or "", dur_text))
                except Exception:
                    pass
            _log("INFO_VERSION_PLAYSTATE_R108 info_rk=%s target_rk=%s offset=%s duration=%s watched=%s reason=%s" % (
                info_rk, target_rk, view_offset, duration, watched or "0", reason or ""))
            self._info_version_pill_refocus_r108()
        except Exception:
            _log("INFO_VERSION_PLAYSTATE_R108_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _info_version_pill_refocus_r108(self):
        """The pill exists twice (5006 resume layout / 5005 play layout); a
        play-state change hides the focused one, so hand focus to its twin."""
        try:
            fid = int(self.getFocusId() or 0)
        except Exception:
            fid = 0
        if fid not in (5005, 5006):
            return
        resume = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.PlayButtonLabel") or "") == "이어서 재생"
        target = 5006 if resume else 5005
        if target == fid:
            return

        def _apply():
            # Kodi re-homes focus (to 100) on the render after the twin hides;
            # set it after that frame and verify.
            for attempt in range(6):
                xbmc.sleep(60)
                try:
                    cur = int(self.getFocusId() or 0)
                except Exception:
                    cur = 0
                if cur == target and attempt >= 1:
                    break
                if cur not in (100, 5005, 5006):
                    break
                try:
                    self.setFocusId(target)
                except Exception:
                    pass
            _log("INFO_VERSION_PILL_REFOCUS_R108 from=%s to=%s attempts=%s" % (fid, target, attempt + 1))

        threading.Thread(target=_apply, name="PKMPillRefocusR108").start()

    def _info_movie_cycle_version_v2094(self, reason=""):
        """Advance the movie playback target on the single resolution icon.

        Fixed display order is 720P -> 1080P -> 2160P, skipping resolutions
        that do not exist for this title. The selected version is published
        immediately, so the icon itself is the persistent current-version UI.
        """
        try:
            # v2100: a quick-resolution change intentionally leaves detailed
            # Media/Part mode and returns to that resolution's representative
            # playback target.
            self._info_movie_media_override_v2100 = None
            self._info_clear_property_all("PlexKM.Info.MediaVersionSelectedKey")
            self._info_clear_property_all("PlexKM.Info.MediaVersionVideo")
            self._info_clear_property_all("PlexKM.Info.MediaVersionAudio")
            versions = list(getattr(self, "_info_movie_versions_v2088", []) or [])
            if not versions:
                return False
            current = str(xbmcgui.Window(10000).getProperty("PlexKM.Info.VersionLabel") or "").strip()
            # R108: cycle keys are (resolution, source); Plex before Kodi.
            by_resolution = {}
            for idx, entry in enumerate(versions):
                resolution = str(entry.get("resolution") or "").strip()
                src_r108 = "kodi" if str(entry.get("rating_key") or "").startswith("k:") else "plex"
                key_r108 = "%s|%s" % (resolution, src_r108)
                if resolution in ("720p", "1080p", "2160p") and key_r108 not in by_resolution:
                    by_resolution[key_r108] = (idx, entry)
            ordered = ["%s|%s" % (res, src) for res in ("720p", "1080p", "2160p") for src in ("plex", "kodi")
                       if "%s|%s" % (res, src) in by_resolution]
            try:
                cur_idx_r108 = int(getattr(self, "_info_movie_version_index_v2088", -1))
                cur_entry_r108 = versions[cur_idx_r108] if 0 <= cur_idx_r108 < len(versions) else {}
                current = "%s|%s" % (str(cur_entry_r108.get("resolution") or current),
                                     "kodi" if str(cur_entry_r108.get("rating_key") or "").startswith("k:") else "plex")
            except Exception:
                pass
            if not ordered:
                return False
            if len(ordered) == 1:
                idx, selected = by_resolution[ordered[0]]
                self._info_movie_version_index_v2088 = idx
                self._info_movie_publish_selected_version_v2088(reason="icon_single_v2094")
                _log("INFO_MOVIE_VERSION_ICON_SINGLE_V2094 resolution=%s target_rk=%s target_section=%s reason=%s" % (
                    ordered[0], selected.get("rating_key") or "", selected.get("section_id") or "", reason or ""
                ))
                return True
            try:
                current_pos = ordered.index(current)
            except ValueError:
                current_pos = -1
            next_resolution = ordered[(current_pos + 1) % len(ordered)]
            idx, selected = by_resolution[next_resolution]
            old = current
            self._info_movie_version_index_v2088 = idx
            published = self._info_movie_publish_selected_version_v2088(reason="icon_cycle_v2094")
            _log("INFO_MOVIE_VERSION_ICON_CYCLE_V2094 from=%s to=%s target_rk=%s target_section=%s available=%s no_refresh=1 reason=%s" % (
                old, next_resolution, (published or selected).get("rating_key") or "",
                (published or selected).get("section_id") or "", ",".join(ordered), reason or ""
            ))
            return True
        except Exception:
            _log("INFO_MOVIE_VERSION_ICON_CYCLE_FAILED_V2094 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_movie_selected_version_v2088(self, info_rating_key=""):
        try:
            owner = str(getattr(self, "_info_movie_version_owner_key_v2088", "") or "")
            if info_rating_key and owner and owner != str(info_rating_key):
                return None
            versions = list(getattr(self, "_info_movie_versions_v2088", []) or [])
            idx = int(getattr(self, "_info_movie_version_index_v2088", -1))
            if len(versions) >= 2 and 0 <= idx < len(versions):
                return versions[idx]
        except Exception:
            pass
        return None

    def _info_movie_play(self, mode="play"):
        """Run one of the four movie action-row commands without rebuilding Info."""
        li = getattr(self, "_inline_info_item", None) or self._focused_wall_item()
        if not li:
            return
        try:
            self._arm_playback_priority_v2118(
                li.getProperty("PlexKM.RatingKey") or "", reason="movie_play_click"
            )
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            info_rating_key = win.getProperty("PlexKM.Info.RatingKey") or li.getProperty("PlexKM.RatingKey") or ""
            rating_key = info_rating_key
            part_key = win.getProperty("PlexKM.Info.PartKey") or li.getProperty("PlexKM.PartKey") or ""
            selected_version_v2088 = self._info_movie_selected_version_v2088(info_rating_key=info_rating_key)
            selected_audio_stream_index_v2114 = ""
            media_override_v2100 = getattr(self, "_info_movie_media_override_v2100", None)
            if isinstance(media_override_v2100, dict) and str(media_override_v2100.get("owner_rating_key") or "") == str(info_rating_key):
                rating_key = str(media_override_v2100.get("rating_key") or rating_key)
                part_key = str(media_override_v2100.get("part_key") or part_key)
                selected_audio_stream_index_v2114 = media_override_v2100.get("audio_stream_index", "")
                _log("INFO_MOVIE_MEDIA_VERSION_PLAY_TARGET_V2100 info_rk=%s target_rk=%s target_section=%s part=%s resolution=%s video=%s audio=%s" % (
                    info_rating_key, rating_key, media_override_v2100.get("section_id") or "", part_key,
                    media_override_v2100.get("resolution") or "", media_override_v2100.get("video_codec") or "",
                    media_override_v2100.get("audio_label") or ""
                ))
            elif selected_version_v2088:
                rating_key = str(selected_version_v2088.get("rating_key") or rating_key)
                part_key = str(selected_version_v2088.get("part_key") or part_key)
                _log("INFO_MOVIE_VERSION_PLAY_TARGET_V2088 info_rk=%s target_rk=%s target_section=%s resolution=%s match=%s" % (
                    info_rating_key, rating_key, selected_version_v2088.get("section_id") or "",
                    selected_version_v2088.get("resolution") or "", selected_version_v2088.get("match_reason") or ""
                ))
            view_offset = win.getProperty("PlexKM.Info.ViewOffset") or li.getProperty("PlexKM.ViewOffset") or ""
            duration_raw = win.getProperty("PlexKM.Info.Duration") or li.getProperty("PlexKM.Duration") or ""
            resume_duration_ms = win.getProperty("PlexKM.Info.ResumeDurationMs") or li.getProperty("PlexKM.ResumeDurationMs") or ""
            safe_resume_ms = self._resume_offset_ms_for_ui(view_offset, duration_raw, resume_duration_ms)
            mode = str(mode or "play").lower()
            effective_mode = "resume" if mode == "resume" and safe_resume_ms > 0 else "start"
            _native_resume_duration_ms = resume_duration_ms or duration_raw or ""
            play_url = _pkm_play_url(rating_key, part_key, mode=effective_mode, view_offset=str(safe_resume_ms), duration_ms=_native_resume_duration_ms, audio_stream_index=selected_audio_stream_index_v2114) if part_key else _pkm_no_resume_url(win.getProperty("PlexKM.Info.PlayUrl") or li.getProperty("PlexKM.PlayUrl") or "")
            if not play_url:
                self._clear_playback_priority_v2118(reason="movie_play_no_url")
                _log("INLINE_INFO_MOVIE_PLAY_SKIPPED reason=no_url mode=%s rating_key=%s" % (mode, rating_key), xbmc.LOGWARNING)
                return
            win.setProperty("PlexKM.InfoPlaybackRequested", "1")
            win.setProperty("PlexKM.InfoPlaybackRatingKey", rating_key)
            win.setProperty("PlexKM.InfoPlaybackUrl", play_url)
            win.setProperty("PlexKM.InfoDirectPlaybackStarting", "1")
            self._handle_info_playback_request(li)
            _log("INLINE_INFO_MOVIE_PLAY rating_key=%s info_rating_key=%s mode=%s effective=%s offset=%s safe_offset=%s" % (rating_key, info_rating_key, mode, effective_mode, view_offset, safe_resume_ms))
        except Exception:
            self._clear_playback_priority_v2118(reason="movie_play_exception")
            _log("INLINE_INFO_MOVIE_PLAY_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _info_movie_watched_db_r60(self, rating_key):
        """PKM_WATCHED_TOGGLE_R60: read-only primary-key lookup of view_count.

        Returns "1" / "" or None when the local DB cannot answer.
        """
        rk = str(rating_key or "").strip()
        if not rk:
            return None
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return None
            conn = _pkm_ro_connect(dbp, timeout=0.5)
            try:
                row = conn.execute(
                    "SELECT view_count FROM items WHERE rating_key=? LIMIT 1", (rk,)
                ).fetchone()
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            if not row:
                return None
            return "1" if _safe_int(row[0], 0) > 0 else ""
        except Exception as exc:
            _log("INFO_WATCHED_DB_LOOKUP_FAILED_R60 rating_key=%s err=%s" % (rk, exc), xbmc.LOGWARNING)
            return None

    def _info_publish_watched_state_r60(self, li, win=None, reason=""):
        """Publish PlexKM.Info.IsWatchedR60 so the movie action pill can show
        "시청함으로 표시" or "미시청으로 표시". TV uses the episode rail item."""
        try:
            win = win or xbmcgui.Window(10000)
            if not li:
                win.setProperty("PlexKM.Info.IsWatchedR60", "")
                return
            rk = str(win.getProperty("PlexKM.Info.RatingKey") or li.getProperty("PlexKM.RatingKey") or "").strip()
            watched = "1" if str(li.getProperty("PlexKM.IsWatched") or "") == "1" else ""
            source = "listitem"
            if not watched and str(li.getProperty("PlexKM.Type") or "").strip().lower() == "movie":
                db_watched = self._info_movie_watched_db_r60(rk)
                if db_watched is not None:
                    watched = db_watched
                    source = "db"
            win.setProperty("PlexKM.Info.IsWatchedR60", watched)
            _log("INFO_WATCHED_STATE_R60 rating_key=%s watched=%s source=%s reason=%s" % (
                rk, watched or "0", source, reason or ""))
        except Exception:
            pass

    def _watched_toggle_local_resume_drop_r60(self, rating_key):
        """Drop this item's local resume sidecar so Continue does not resurrect it."""
        try:
            core = _ensure_core()
            read_fn = getattr(core, "_read_local_resume_states", None)
            write_fn = getattr(core, "_write_local_resume_states", None)
            if not (read_fn and write_fn):
                return False
            data = read_fn() or {}
            if str(rating_key) in data:
                data.pop(str(rating_key), None)
                write_fn(data)
                return True
        except Exception:
            pass
        return False

    def _watched_toggle_after_r60(self, rating_key, watched, reason=""):
        """Background: refresh this item's DB row from Plex (no Home rebuild)."""
        def _run():
            try:
                _ensure_core().refresh_item_state_from_plex(rating_key, reason=reason)
            except Exception:
                pass
        try:
            threading.Thread(target=_run, name="PKMWatchedToggleR60").start()
        except Exception:
            _run()

    def _info_movie_mark_watched(self):
        """PKM_WATCHED_TOGGLE_R60: watched -> unscrobble, otherwise scrobble."""
        li = getattr(self, "_inline_info_item", None) or self._focused_wall_item()
        if not li:
            return
        win = xbmcgui.Window(10000)
        rating_key = win.getProperty("PlexKM.Info.RatingKey") or li.getProperty("PlexKM.RatingKey") or ""
        if not rating_key:
            _log("INLINE_INFO_MOVIE_MARK_WATCHED_SKIPPED reason=no_rating_key", xbmc.LOGWARNING)
            return
        currently_watched = str(win.getProperty("PlexKM.Info.IsWatchedR60") or "") == "1"
        try:
            if currently_watched:
                ok = bool(_ensure_core().plex_unscrobble(rating_key, reason="inline_movie_unwatch_r60"))
            else:
                ok = bool(_ensure_core().plex_scrobble(rating_key, reason="inline_movie_action"))
            if ok:
                new_watched = "" if currently_watched else "1"
                try:
                    li.setProperty("PlexKM.IsWatched", new_watched)
                    li.setProperty("PlexKM.ViewCount", "1" if new_watched else "0")
                    li.setProperty("PlexKM.ViewOffset", "")
                    li.setProperty("PlexKM.RemainingText", "")
                    li.setProperty("PlexKM.ResumePercent", "")
                    win.setProperty("PlexKM.Info.ViewOffset", "")
                    win.setProperty("PlexKM.Info.RemainingText", "")
                    win.setProperty("PlexKM.Info.PlayButtonLabel", "재생")
                    win.setProperty("PlexKM.Info.IsWatchedR60", new_watched)
                except Exception:
                    pass
                self._watched_toggle_local_resume_drop_r60(rating_key)
                self._watched_toggle_after_r60(
                    rating_key, new_watched,
                    reason="inline_movie_mark_watched" if new_watched else "inline_movie_mark_unwatched_r60")
                try:
                    self._show_pkm_notice("Plex KM", "시청함으로 표시했습니다" if new_watched else "미시청으로 표시했습니다", "", ms=1800)
                except Exception:
                    pass
                _log("INLINE_INFO_MOVIE_WATCHED_TOGGLE_R60 rating_key=%s watched=%s" % (rating_key, new_watched or "0"))
            else:
                self._show_pkm_notice("Plex KM", "미시청 표시 실패" if currently_watched else "시청함 표시 실패", "Plex 상태를 확인해주세요", ms=2500)
                _log("INLINE_INFO_MOVIE_WATCHED_TOGGLE_FAILED_R60 rating_key=%s to_watched=%s" % (
                    rating_key, "0" if currently_watched else "1"), xbmc.LOGWARNING)
        except Exception:
            _log("INLINE_INFO_MOVIE_MARK_WATCHED_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _inline_info_history_push_v2085(self, child_li=None, source_control=0):
        """Save the current Info surface before actor-work -> child Info.

        The actor-work rows are rebuilt for the child Info.  A numeric position
        alone is therefore not a durable Back target: position N can represent a
        different title after the rebuild.  v2085 stores the detached parent Info
        item and the selected actor-work RatingKey, so Back can rebuild the parent
        surface before restoring the exact poster focus.
        """
        try:
            if getattr(self, "_inline_info_history_restore_v2085", False):
                return False
            if source_control not in INFO_ACTOR_WORK_ROW_IDS_V2082:
                return False
            try:
                _active = (
                    self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
                )
            except Exception:
                _active = False
            if not _active:
                return False
            parent_li = getattr(self, "_inline_info_item", None)
            if parent_li is None:
                return False
            parent_snapshot = self._detach_info_actor_work_item_v2082(
                parent_li, source_control=0
            )
            if parent_snapshot is None:
                _log("INLINE_INFO_HISTORY_PUSH_SKIP_V2085 reason=parent_detach_failed source_control=%s" % source_control, xbmc.LOGWARNING)
                return False
            try:
                ctrl = self.getControl(source_control)
                return_pos = int(ctrl.getSelectedPosition())
            except Exception:
                ctrl = None
                return_pos = -1
            return_key = ""
            try:
                if child_li is not None:
                    return_key = child_li.getProperty("PlexKM.RatingKey") or ""
            except Exception:
                return_key = ""
            if not return_key and ctrl is not None:
                try:
                    selected = ctrl.getSelectedItem()
                    if selected is not None:
                        return_key = selected.getProperty("PlexKM.RatingKey") or ""
                except Exception:
                    pass
            # v2312 root fix: NEVER snapshot the live Info tint here.  The dynamic
            # fanart sampler/late unified lerp can still be finishing when an
            # actor-work child is activated, so DynamicBgSideOpaqueColor at PUSH
            # time is not an authoritative parent color.  Capturing it created the
            # intermittent old-fanart blue/green rail seen during Back.  Save only
            # geometry state here; the sidebar color is latched from the PARENT'S
            # committed target bank at the final publish boundary.
            try:
                _hist_win_v2310 = xbmcgui.Window(10000)
                _parent_had_season_cards_v2310 = (
                    _hist_win_v2310.getProperty("PlexKM.Info.HasSeasonCards") == "1"
                )
            except Exception:
                _parent_had_season_cards_v2310 = False
            _parent_sidebar_color_v2310 = ""
            frame = {
                "parent_li": parent_snapshot,
                "parent_rating_key": parent_snapshot.getProperty("PlexKM.RatingKey") or "",
                "origin_focus": int(getattr(self, "_inline_info_origin_focus_id", 0) or 0),
                "origin_pos": int(getattr(self, "_inline_info_origin_pos", -1) or -1),
                "origin_key": getattr(self, "_inline_info_origin_rating_key", "") or "",
                "return_focus": int(source_control or 0),
                "return_pos": int(return_pos),
                "return_key": return_key or "",
                "parent_sidebar_color_v2310": _parent_sidebar_color_v2310 or "",
                "parent_had_season_cards_v2310": 1 if _parent_had_season_cards_v2310 else 0,
            }
            # v2152: do not build a breadcrumb chain. Each actor-work child
            # replaces the saved frame with only its immediate parent. This means
            # A -> B -> C -> D, Back restores C once; it can never unwind C -> B -> A.
            stack = [frame]
            self._inline_info_history_v2085 = stack
            self._inline_info_chain_exit_after_back_v2152 = False
            _log("INLINE_INFO_HISTORY_PUSH_V2152 depth=1 policy=one_previous_only parent=%s return_focus=%s return_pos=%s return_key=%s" % (
                frame["parent_rating_key"], frame["return_focus"],
                frame["return_pos"], frame["return_key"]
            ))
            return True
        except Exception:
            _log("INLINE_INFO_HISTORY_PUSH_FAILED_V2085 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _inline_info_history_clear_visual_restore_v2310(self, marker="", reason=""):
        """Clear only primitive Window properties used by the v2310 Back visual pin."""
        try:
            win = xbmcgui.Window(10000)
            current = win.getProperty("PlexKM.Info.HistoryBackMarkerV2310") or ""
            if marker and current and current != marker:
                return False
            for name in (
                "PlexKM.Info.HistoryBackActiveV2310",
                "PlexKM.Info.HistoryBackLayoutReadyV2310",
                "PlexKM.Info.HistoryBackPrimeV2310",
                "PlexKM.Info.HistoryBackReturnFocusV2310",
                "PlexKM.Info.HistoryBackHadSeasonCardsV2310",
                "PlexKM.Info.HistoryBackSidebarColorV2310",
                "PlexKM.Info.HistoryBackMarkerV2310",
            ):
                win.clearProperty(name)
            _log("INFO_HISTORY_VISUAL_PIN_CLEAR_V2310 marker=%s reason=%s native_objects=0" % (
                marker or current or "", reason or ""
            ))
            return True
        except Exception:
            return False

    def _inline_info_history_schedule_visual_cleanup_v2310(self, marker, parent_key=""):
        """Release static/prime compensation after Kodi's normal 420 ms focus animation settles."""
        if not marker:
            return False
        try:
            def _worker():
                try:
                    if xbmc.Monitor().waitForAbort(0.56):
                        return
                    self._inline_info_history_clear_visual_restore_v2310(
                        marker=marker, reason="focus_animation_settled"
                    )
                    _log("INFO_HISTORY_EXACT_POSITION_SETTLED_V2310 parent=%s marker=%s wait_ms=560" % (
                        parent_key or "", marker
                    ))
                except Exception:
                    pass
            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
            return True
        except Exception:
            return False

    def _inline_info_history_pop_restore_v2085(self, reason="back"):
        """Restore parent Info first, then focus the exact actor-work poster."""
        stack = getattr(self, "_inline_info_history_v2085", None)
        if not isinstance(stack, list) or not stack:
            return False
        frame = stack.pop()
        parent_li = frame.get("parent_li")
        if parent_li is None:
            _log("INLINE_INFO_HISTORY_POP_FAILED_V2085 reason=no_parent_item depth=%d" % len(stack), xbmc.LOGWARNING)
            return False
        return_focus = int(frame.get("return_focus", 0) or 0)
        return_pos = int(frame.get("return_pos", -1) or -1)
        return_key = frame.get("return_key", "") or ""
        parent_key = frame.get("parent_rating_key", "") or ""
        _history_marker_v2310 = "%s:%d" % (parent_key or "parent", self._now_ms())
        try:
            # v2310: provide the XML with the parent's exact destination geometry
            # and sidebar tint BEFORE the safe rebuild.  LayoutReady stays false
            # here, so the still-visible child is not moved or recolored.
            _hist_win_v2310 = xbmcgui.Window(10000)
            _hist_win_v2310.setProperty("PlexKM.Info.HistoryBackActiveV2310", "1")
            _hist_win_v2310.clearProperty("PlexKM.Info.HistoryBackLayoutReadyV2310")
            _hist_win_v2310.clearProperty("PlexKM.Info.HistoryBackPrimeV2310")
            _hist_win_v2310.setProperty("PlexKM.Info.HistoryBackReturnFocusV2310", str(return_focus or 0))
            _hist_win_v2310.setProperty(
                "PlexKM.Info.HistoryBackHadSeasonCardsV2310",
                "1" if int(frame.get("parent_had_season_cards_v2310", 0) or 0) else "0"
            )
            # v2312: color is intentionally EMPTY while the child remains visible.
            # It will be written only after _info_dynamic_bg_commit_v2140() has
            # committed the parent's target bank, then LayoutReady is published
            # LAST.  This turns color+ready into one render-frame transaction.
            _hist_win_v2310.clearProperty("PlexKM.Info.HistoryBackSidebarColorV2310")
            _hist_win_v2310.setProperty("PlexKM.Info.HistoryBackMarkerV2310", _history_marker_v2310)
            _log("INFO_HISTORY_VISUAL_PIN_ARM_V2312 parent=%s focus=%s had_seasons=%d sidebar=deferred_to_target_commit marker=%s child_unchanged=1" % (
                parent_key, return_focus,
                1 if int(frame.get("parent_had_season_cards_v2310", 0) or 0) else 0,
                _history_marker_v2310
            ))
            # Do not clear InlineActive here.  Actor-work controls exist only on
            # the parent Info surface; clearing first would make Kodi focus a
            # hidden control, which is exactly the v2084 failure mode.
            self._inline_info_history_restore_v2085 = True
            self._show_info(li=parent_li)
        except Exception:
            self._inline_info_history_clear_visual_restore_v2310(
                marker=_history_marker_v2310, reason="parent_restore_failed"
            )
            _log("INLINE_INFO_HISTORY_PARENT_RESTORE_FAILED_V2085 parent=%s err=%s" % (
                parent_key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False
        finally:
            self._inline_info_history_restore_v2085 = False

        # _show_info() necessarily sees the child entry control while rebuilding
        # the parent and would otherwise overwrite the real top-level Back origin.
        # Restore that owner state from the history frame before handing focus back.
        self._inline_info_origin_focus_id = int(frame.get("origin_focus", 0) or 0)
        self._inline_info_origin_pos = int(frame.get("origin_pos", -1) or -1)
        self._inline_info_origin_rating_key = frame.get("origin_key", "") or ""

        target = -1
        exact = False
        actual_key = ""
        try:
            ctrl = self.getControl(return_focus)
            size = int(ctrl.size())
            if size > 0:
                if return_key:
                    for idx in range(size):
                        item = ctrl.getListItem(idx)
                        if item is not None and (item.getProperty("PlexKM.RatingKey") or "") == return_key:
                            target = idx
                            exact = True
                            break
                if target < 0:
                    target = min(max(0, return_pos if return_pos >= 0 else 0), size - 1)
                # v2310: the parent is already statically pre-positioned by XML.
                # Prime an equal/opposite 420 ms transform BEFORE Kodi takes focus,
                # cancelling the normal v2079 focus animation frame-for-frame.
                # Kodi still owns focus and all directional navigation.
                try:
                    _hist_win_v2310 = xbmcgui.Window(10000)
                    _hist_win_v2310.setProperty("PlexKM.Info.HistoryBackPrimeV2310", "1")
                except Exception:
                    pass
                ctrl.selectItem(target)
                self.setFocusId(return_focus)
                # One native ownership handoff only: no sleep, retry timer, or
                # second SetFocus.  Selection identity is established first.
                try:
                    selected = ctrl.getSelectedItem()
                    if selected is not None:
                        actual_key = selected.getProperty("PlexKM.RatingKey") or ""
                        if return_key and actual_key == return_key:
                            exact = True
                except Exception:
                    pass
                self._last_focus_id = return_focus
                try:
                    if self._is_home_row_control(return_focus):
                        row_idx = self._home_row_index_for_control(return_focus)
                        if row_idx >= 0:
                            self._home_active_row = row_idx
                            self._home_row_memory[row_idx] = target
                            self._last_wall_pos = target
                except Exception:
                    pass
                # History restore is a completed navigation transaction; allow
                # an immediate user action on the restored poster.
                self._last_info_activate_ms = 0
                self._inline_info_chain_exit_after_back_v2152 = True
                _log("INLINE_INFO_HISTORY_POP_V2152 reason=%s depth=%d parent=%s focus=%s pos=%s return_key=%s selected_key=%s exact=%d next_back=exit_confirm inline_active=%s" % (
                    reason or "back", len(stack), parent_key, return_focus, target,
                    return_key, actual_key, 1 if exact else 0,
                    self.getProperty("PlexKM.Info.InlineActive") or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") or "0"
                ))
                self._inline_info_history_schedule_visual_cleanup_v2310(
                    _history_marker_v2310, parent_key=parent_key
                )
                _log("INFO_HISTORY_EXACT_POSITION_COMMIT_V2310 parent=%s focus=%s pos=%s exact=%d static_plus_prime=1 sidebar_pin=1" % (
                    parent_key, return_focus, target, 1 if exact else 0
                ))
                return True
        except Exception:
            _log("INLINE_INFO_HISTORY_FOCUS_RESTORE_FAILED_V2085 parent=%s focus=%s pos=%s return_key=%s err=%s" % (
                parent_key, return_focus, return_pos, return_key,
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        # Parent Info is already restored.  If the actor row unexpectedly has no
        # items, keep a visible valid Info focus rather than falling to control 100.
        self._inline_info_history_clear_visual_restore_v2310(
            marker=_history_marker_v2310, reason="actor_row_fallback"
        )
        try:
            fallback = self._inline_info_focus_target_v1886()
            if fallback in (5711, 5712, 5713):
                self._info_tv_focus_panel(fallback, reason="history_fallback_v2085")
            else:
                self.setFocusId(fallback)
            self._last_focus_id = fallback
            self._inline_info_chain_exit_after_back_v2152 = True
            _log("INLINE_INFO_HISTORY_POP_FALLBACK_V2152 parent=%s requested_focus=%s fallback=%s return_key=%s next_back=exit_confirm" % (
                parent_key, return_focus, fallback, return_key
            ), xbmc.LOGWARNING)
            return True
        except Exception:
            return False

    def _remember_inline_info_origin(self, li=None):
        """Remember the Home/section poster that opened inline Info.

        This is used only for Back/close restore.  Directional movement inside
        episode panels remains Kodi XML/fixedlist native.
        """
        # v2454: a work selected from Actor Profile replaces that profile with
        # ordinary existing Info. Preserve the original Home/section origin so
        # Back from the work behaves exactly like standard Info and never returns
        # to the discarded actor page/list control.
        if getattr(self, "_actor_profile_work_open_v2454", False):
            _log("ACTOR_PROFILE_WORK_ORIGIN_PRESERVE_V2454 focus=%s pos=%s rating_key=%s" % (
                getattr(self, "_inline_info_origin_focus_id", 0),
                getattr(self, "_inline_info_origin_pos", -1),
                getattr(self, "_inline_info_origin_rating_key", "") or ""
            ))
            return
        try:
            fid = self._safe_focus_id()
            self._inline_info_origin_focus_id = int(fid or 0)
            self._inline_info_origin_rating_key = ""
            if li is not None:
                try:
                    self._inline_info_origin_rating_key = li.getProperty("PlexKM.RatingKey") or ""
                except Exception:
                    self._inline_info_origin_rating_key = ""
            pos = -1
            try:
                if fid == WALL_ID:
                    pos = self._wall_selected_position()
                elif self._is_home_row_control(fid):
                    pos = self._home_row_selected_position(control_id=fid)
                elif fid in SEARCH_RESULT_IDS:
                    try:
                        pos = self.getControl(fid).getSelectedPosition()
                    except Exception:
                        pos = 0
            except Exception:
                pos = -1
            self._inline_info_origin_pos = int(pos if pos is not None else -1)
            _log("INLINE_INFO_ORIGIN_SET focus=%s pos=%s rating_key=%s" % (
                self._inline_info_origin_focus_id, self._inline_info_origin_pos, self._inline_info_origin_rating_key or ""))
        except Exception:
            _log("INLINE_INFO_ORIGIN_SET_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _restore_inline_info_origin_focus(self, reason=""):
        """Return from inline Info to the poster/widget that opened it.

        Home rows are restored as rows, not as the legacy wall, so
        Home -> Continue Watching drama -> episode Info -> Back lands back on
        the same Continue Watching poster.
        """
        try:
            fid = int(getattr(self, "_inline_info_origin_focus_id", 0) or 0)
            pos = int(getattr(self, "_inline_info_origin_pos", -1) or -1)
            rating_key = getattr(self, "_inline_info_origin_rating_key", "") or getattr(self, "_last_info_rating_key", "") or ""

            def _select_by_rating_or_pos(control, fallback_pos):
                target = max(0, fallback_pos if fallback_pos >= 0 else 0)
                try:
                    size = int(control.size())
                except Exception:
                    size = 0
                if size <= 0:
                    return -1
                if rating_key:
                    try:
                        for i in range(size):
                            item = control.getListItem(i)
                            if item and (item.getProperty("PlexKM.RatingKey") or "") == rating_key:
                                target = i
                                break
                    except Exception:
                        pass
                target = min(max(0, target), max(0, size - 1))
                try:
                    control.selectItem(target)
                except Exception:
                    pass
                return target

            if fid in SEARCH_RESULT_IDS:
                try:
                    # Search was intentionally kept alive under Info. Restore
                    # the exact result control/item instead of falling through
                    # to the Home sidebar fallback.
                    if not getattr(self, "_search_inline_active", False):
                        self._search_inline_active = True
                    self.setProperty("PlexKM.Search.InlineActive", "1")
                    xbmcgui.Window(10000).setProperty("PlexKM.Search.InlineActive", "1")
                    ctrl = self.getControl(fid)
                    target = _select_by_rating_or_pos(ctrl, pos)
                    if target >= 0:
                        self.setFocusId(fid)
                        try:
                            ctrl.selectItem(target)
                        except Exception:
                            pass
                        self._last_focus_id = fid
                        _log("INLINE_INFO_BACK_RETURN_SEARCH_V1773 reason=%s focus=%s pos=%s rating_key=%s query=%s" % (
                            reason or "", fid, target, rating_key or "",
                            _short_log_value(getattr(self, "_search_query", "") or "", 80),
                        ))
                        return True
                except Exception:
                    _log("INLINE_INFO_BACK_RETURN_SEARCH_FAILED_V1773 reason=%s err=%s" % (
                        reason or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

            if fid and (fid == WALL_ID or self._is_home_row_control(fid)):
                try:
                    ctrl = self.getControl(fid)
                    if fid == WALL_ID and self._library_wall_is_native_owner_v2070():
                        target = int(ctrl.getSelectedPosition())
                    else:
                        target = _select_by_rating_or_pos(ctrl, pos)
                    if target >= 0:
                        if self._is_home_row_control(fid):
                            try:
                                row_idx = self._home_row_index_for_control(fid)
                                if row_idx >= 0:
                                    self._home_active_row = row_idx
                                    self._home_row_memory[row_idx] = target
                                    self._last_wall_pos = target
                                    self._remember_row_reentry_focus(fid, reason="inline_info_back")
                                    self._apply_dynamic_row_anchor_scroll(fid, reason="inline_info_back")
                            except Exception:
                                pass
                        else:
                            self._last_wall_pos = target
                        self.setFocusId(fid)
                        xbmc.sleep(60)
                        try:
                            if not (fid == WALL_ID and self._library_wall_is_native_owner_v2070()):
                                ctrl.selectItem(target)
                            self.setFocusId(fid)
                        except Exception:
                            pass
                        self._last_focus_id = fid
                        _log("INLINE_INFO_BACK_RETURN_ORIGIN reason=%s focus=%s pos=%s rating_key=%s" % (reason or "", fid, target, rating_key or ""))
                        return True
                except Exception:
                    pass

            # Safe fallback: keep Home visible and move to the real sidebar.
            try:
                self._focus_menu_control_v1993(reason="direct_menu_handoff_v1993")
                self._last_focus_id = MENU_ID
                _log("INLINE_INFO_BACK_RETURN_MENU_FALLBACK reason=%s focus=%s pos=%s rating_key=%s" % (reason or "", fid, pos, rating_key or ""))
                return True
            except Exception:
                pass
        except Exception:
            _log("INLINE_INFO_BACK_RETURN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return False

    def _close_inline_info_to_previous_step(self, reason="back"):
        """R61: single-flight wrapper.

        The close path reaches xbmc.sleep() (swap settle), and Kodi delivers
        queued WindowXML callbacks from inside that sleep.  Every extra Back
        press re-entered this method and started another complete Home build
        (with a Plex onDeck request) underneath the previous one: on SHIELD
        19 nested builds held Info on screen for ~31 s.  A Back that arrives
        while a close is already running is consumed here.
        """
        if getattr(self, "_info_back_closing_r61", False):
            _log("INFO_BACK_REENTRY_DROP_R61 reason=%s" % (reason or "back"))
            return True
        self._info_back_closing_r61 = True
        try:
            return self._close_inline_info_to_previous_step_impl_r61(reason=reason)
        finally:
            self._info_back_closing_r61 = False
            try:
                self._favorites_apply_dirty_on_home_r119(reason="info_back")
            except Exception:
                pass

    def _close_inline_info_to_previous_step_impl_r61(self, reason="back"):
        """Close one Info navigation step and restore its exact owner."""
        try:
            # v2085: actor-work -> Info is nested.  Back must restore the parent
            # Info surface and its selected actor-work poster; clearing InlineInfo
            # first would hide that row and leave Kodi focused on a dead control.
            if getattr(self, "_inline_info_history_v2085", None):
                restored = self._inline_info_history_pop_restore_v2085(reason=reason or "back")
                _log("INLINE_INFO_BACK_HISTORY_V2085 reason=%s restored=%s depth=%d" % (
                    reason or "back", "1" if restored else "0",
                    len(getattr(self, "_inline_info_history_v2085", []) or [])
                ))
                if restored:
                    return True
            rating_key = getattr(self, "_inline_info_origin_rating_key", "") or getattr(self, "_last_info_rating_key", "") or ""
            fid_v2479 = int(getattr(self, "_inline_info_origin_focus_id", 0) or 0)
            if fid_v2479 in SEARCH_RESULT_IDS:
                target_surface_v2479 = "search"
            elif fid_v2479 == WALL_ID:
                target_surface_v2479 = "section_library"
            elif self._is_home_row_control(fid_v2479):
                target_surface_v2479 = "home"
            else:
                target_surface_v2479 = self._pkm_surface_mode_v2479()
                if target_surface_v2479 == "info":
                    # Under Info, the base mode properties remain authoritative.
                    win_v2479 = xbmcgui.Window(10000)
                    if self.getProperty("PlexKM.Window.IsSectionRecommend") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionRecommend") == "1":
                        target_surface_v2479 = "section_recommend"
                    elif self.getProperty("PlexKM.Window.IsSectionWall") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionWall") == "1":
                        target_surface_v2479 = "section_library"
                    elif self.getProperty("PlexKM.Window.IsSectionCategory") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionCategory") == "1":
                        target_surface_v2479 = "section_category"
                    else:
                        target_surface_v2479 = "home"
            # v2575: while Info still covers the source, refresh only the surface
            # being revealed.  The synchronous local stop sidecar is already ready,
            # so this is network-free and prevents a resumed poster from remaining
            # under "최근 추가됨" with no progress bar.
            try:
                self._playstate_refresh_visible_surface_v2575(
                    target_surface_v2479, reason="info_back_precommit:%s" % (reason or "back")
                )
            except Exception:
                pass
            info_back_swap_v2479 = self._pkm_swap_settle_v2479(
                "info", target_surface_v2479, reason="info_back_origin_preserved:%s" % (reason or "back"), wait_ms=16
            )
            self._clear_inline_info(reason=reason or "back")
            self._pkm_swap_finish_v2479(
                info_back_swap_v2479, "info", target_surface_v2479, reason="info_back_visible_commit:%s" % (reason or "back")
            )
            restored = self._restore_inline_info_origin_focus(reason=reason or "back")
            _log("INLINE_INFO_BACK_CLOSE_V2479 reason=%s restored=%s rating_key=%s target=%s source_held_until_commit=1" % (reason or "back", "1" if restored else "0", rating_key or "", target_surface_v2479))
            return True
        except Exception:
            _log("INLINE_INFO_BACK_CLOSE_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return False

    def _inline_info_diag_log(self, phase="", reason="", action_id=None):
        """v512 diagnostic-only logging for inline Info/include movement.

        This must never steer focus or change UI state.  It only snapshots the
        current Kodi/XML state so Info overlay movement problems can be compared
        against Home row/downscroll state in kodi.log.
        """
        try:
            try:
                fid = self._safe_focus_id()
            except Exception:
                fid = -1
            try:
                focus_state = self._home_row_state_for_log(fid)
            except Exception:
                focus_state = "unavailable"
            try:
                home_stack = self._stack_geom_for_log(HOME_ROW_ANCHOR_SCOPE)
            except Exception:
                home_stack = "unavailable"
            try:
                section_stack = self._stack_geom_for_log(SECTION_ROW_ANCHOR_SCOPE)
            except Exception:
                section_stack = "unavailable"
            try:
                win10000 = xbmcgui.Window(10000)
                active_win = win10000.getProperty("PlexKM.Info.InlineActive")
                sidebar_win = win10000.getProperty("PlexKM.Info.SidebarOpen")
                rating_key = win10000.getProperty("PlexKM.Info.RatingKey")
                title = win10000.getProperty("PlexKM.Info.Title")
                is_tv = win10000.getProperty("PlexKM.Info.IsTV")
                tv_mode = win10000.getProperty("PlexKM.Info.TVMode")
            except Exception:
                active_win = sidebar_win = rating_key = title = is_tv = tv_mode = ""
            _log(
                "INLINE_INFO_DIAG phase=%s reason=%s aid=%s "
                "active_self=%s active_win=%s sidebar_self=%s sidebar_win=%s "
                "focus=%s focus_state=[%s] active_section=%s home_active_row=%s "
                "wall_pos=%s tracked_pos=%s logical_pos=%s "
                "origin_focus=%s origin_pos=%s origin_key=%s "
                "rating_key=%s is_tv=%s tv_mode=%s title=%s "
                "home_stack=[%s] section_stack=[%s]" % (
                    phase or "",
                    reason or "",
                    "" if action_id is None else action_id,
                    self.getProperty("PlexKM.Info.InlineActive"),
                    active_win,
                    self.getProperty("PlexKM.Info.SidebarOpen"),
                    sidebar_win,
                    fid,
                    focus_state,
                    getattr(self, "active_section_id", ""),
                    getattr(self, "_home_active_row", ""),
                    self._wall_selected_position(),
                    getattr(self, "_wall_tracked_pos", ""),
                    getattr(self, "_logical_wall_pos", ""),
                    getattr(self, "_inline_info_origin_focus_id", ""),
                    getattr(self, "_inline_info_origin_pos", ""),
                    getattr(self, "_inline_info_origin_rating_key", ""),
                    rating_key,
                    is_tv,
                    tv_mode,
                    _short_log_value(title, 80),
                    home_stack,
                    section_stack,
                )
            )
        except Exception:
            try:
                _log("INLINE_INFO_DIAG_FAILED phase=%s reason=%s err=%s" % (phase or "", reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass

    def _clear_inline_info(self, reason=""):
        try:
            self._info_clear_property_all("PlexKM.Info.VersionMenuOpen")
        except Exception:
            pass
        try:
            # v584: menu_changed can fire while playback is still active/starting
            # because Kodi re-enters PKM Home under VideoFullScreen.  That is not
            # a real user menu change; preserving inline Info is required for Back.
            try:
                if str(reason or "").startswith("menu_changed") and self._is_pkm_playback_handoff_active():
                    _log("INLINE_INFO_CLEAR_SKIP reason=%s guard=playback_handoff_active" % (reason or ""))
                    return
            except Exception:
                pass
            self._inline_info_diag_log(phase="clear_begin", reason=reason or "")
            # v2481: an actor focus-intent worker is valid only while its parent
            # Info page still owns the scene. Retire any pending intent before
            # clearing Info so no background Helper transaction survives a real
            # scene exit.
            try:
                self._actor_profile_prewarm_token_v2481 = int(getattr(self, "_actor_profile_prewarm_token_v2481", 0) or 0) + 1
                self._actor_profile_prewarm_actor_v2481 = ""
                self._actor_profile_prewarm_source_rk_v2481 = ""
            except Exception:
                pass
            try:
                self._info_tv_media_clear_v2112(reason="inline_info_close_%s" % (reason or ""))
                self._info_tv_clear_selected_version_state_v2123(reason="inline_info_close_%s" % (reason or ""))
            except Exception:
                pass
            try:
                self._info_movie_clear_versions_v2088(reason="inline_info_close_%s" % (reason or ""))
            except Exception:
                pass
            self._info_clear_property_all("PlexKM.Info.InlineActive")
            self._info_clear_property_all("PlexKM.Info.SidebarOpen")
            self._info_clear_property_all("PlexKM.Info.SidebarHoldV2387")
            self._info_sidebar_hold_v2387 = None
            self._info_clear_property_all("PlexKM.Info.ReentrantSwapV2083")
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapV2087")
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapStartMsV2152")
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
            self._info_clear_property_all("PlexKM.Info.ReentrantScrollResetV2086")
            self._info_clear_property_all("PlexKM.Info.DirectSwapV2086")
            for _ab_key_v2136 in (
                "PlexKM.Info.ArtBankAV2136",
                "PlexKM.Info.ArtBankBV2136",
                "PlexKM.Info.ArtActiveBankV2136",
                "PlexKM.Info.ArtCurrentRatingKeyV2136",
                "PlexKM.Info.ArtPendingBankV2136",
                "PlexKM.Info.ArtPendingRatingKeyV2136",
                "PlexKM.Info.ArtPendingUrlV2136",
                "PlexKM.Info.ArtPreloadRatingKeyV2136",
                "PlexKM.Info.ArtPreloadUrlV2136",
                "PlexKM.Info.ArtSwapActiveV2136",
            ):
                self._info_clear_property_all(_ab_key_v2136)
            try:
                pkm_transition_manager.cancel_info_transition(self)
            except Exception:
                pass
            for tv_key in ("IsTV", "IsShow", "IsEpisode", "TVShowTitle", "TVSectionTitle", "TVEpisodeHint", "TVMode", "TVBackMode", "TVModeSeasons", "TVModeEpisodes", "TVRowsReady", "TVRowsEmpty", "HasSeasonTabs", "HasSeasonCards"):
                self._info_clear_property_all("PlexKM.Info.%s" % tv_key)
            try:
                self._info_tv_defer_focus = False
            except Exception:
                pass
            try:
                self._info_widget_rebuild_pending_v2082 = None
                self._info_widget_rebuild_committing_v2082 = False
                self._info_reentrant_open_in_progress_v2082 = False
            except Exception:
                pass
            self._inline_info_item = None
            # A real Info close owns the complete nested stack. History Back does
            # not call _clear_inline_info(), so this cannot erase a parent frame
            # during a normal nested pop.
            try:
                if not getattr(self, "_inline_info_history_restore_v2085", False):
                    depth_v2085 = len(getattr(self, "_inline_info_history_v2085", []) or [])
                    self._inline_info_history_v2085 = []
                    self._inline_info_chain_exit_after_back_v2152 = False
                    if depth_v2085:
                        _log("INLINE_INFO_HISTORY_CLEAR_V2152 reason=%s depth=%d exit_latch=0" % (reason or "", depth_v2085))
            except Exception:
                pass
            # Keep origin values until Back restore completes; explicit non-back
            # opens will overwrite them via _remember_inline_info_origin().
            _log("INLINE_INFO_CLEAR reason=%s" % (reason or ""))
            try:
                # A normal user close/back means the saved post-playback return
                # target is no longer current.  Do not clear it for playback_start,
                # and do not clear it for the synthetic menu_changed that Kodi can
                # emit while fullscreen video is active during native playback.
                _reason_text = str(reason or "")
                _keep_return_state = _reason_text.startswith("playback")
                try:
                    _win = xbmcgui.Window(10000)
                    _pending_inline_return = _win.getProperty("PlexKM.Playback.ReturnInline.Pending") == "1"
                    _video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                    if _reason_text.startswith("menu_changed") and _pending_inline_return and _video_active:
                        _keep_return_state = True
                        _log("INLINE_PLAYBACK_RETURN_CLEAR_SKIP reason=%s guard=video_active_menu_changed" % (_reason_text or ""))
                except Exception:
                    pass
                if not _keep_return_state:
                    self._clear_inline_info_playback_return_state(reason="inline_clear_%s" % (reason or ""))
            except Exception:
                pass
            self._inline_info_diag_log(phase="clear_done", reason=reason or "")
        except Exception:
            pass

    def _show_info(self, li=None):
        """v429: show Info as an inline right-side mode inside HomeWindow.

        This deliberately does not touch Home/Library row/downscroll XML.
        The existing PKM sidebar remains the only sidebar; the right-side Info
        group is drawn over the widget area and slides when the real sidebar
        receives focus.
        """
        now_ms = self._now_ms()
        _info_open_start_ms = now_ms
        _info_global_busy_token_v1883 = ""
        self._kpi_info_pre_sql_v2605 = 0
        self._kpi_info_pre_net_v2605 = 0
        _history_restore_v2085 = bool(getattr(self, "_inline_info_history_restore_v2085", False))
        if (self._info_dialog_active or (now_ms - self._last_info_activate_ms) < 700) and not _history_restore_v2085:
            _log("INLINE_INFO_SKIPPED reason=duplicate_guard elapsed_ms=%d" % (now_ms - self._last_info_activate_ms))
            return
        # PKM_INFO_SAME_TITLE_RETIRED_CLICK_R34: a second ENTER on a tile of a
        # surface that is already gone (e.g. actor works 6500 under the new
        # actor-work Info) re-opened the SAME title and re-pushed history.
        if not _history_restore_v2085 and li is not None:
            try:
                _rk_r34 = str(li.getProperty("PlexKM.RatingKey") or "")
                _cur_rk_r34 = str(self.getProperty("PlexKM.Info.RatingKey")
                                  or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "")
                _inline_r34 = (self.getProperty("PlexKM.Info.InlineActive") == "1"
                               or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1")
                _fid_r34 = self._safe_focus_id()
                if _rk_r34 and _inline_r34 and _rk_r34 == _cur_rk_r34 and self._focus_on_retired_surface_r34(_fid_r34):
                    _log("INLINE_INFO_SKIPPED_R34 reason=same_title_from_retired_surface rating_key=%s focus=%s" % (_rk_r34, _fid_r34))
                    try:
                        self._recover_lost_focus_on_key_r155(ACTION_SELECT_ITEM)
                    except Exception:
                        pass
                    return
            except Exception:
                pass
        _info_actor_work_reentrant_v2082, _info_inline_was_active_v2087, _info_item_source_v1772, _info_origin_focus_v2082, li = self._show_info_step1(li, now_ms)
        if _info_actor_work_reentrant_v2082 and li is not None:
            _native_actor_work_li_v2082 = li
            li = self._detach_info_actor_work_item_v2082(
                _native_actor_work_li_v2082, source_control=_info_origin_focus_v2082
            )
            # v2132: carry child-transaction ownership on the detached ListItem so
            # both initial publish and the later background refresh know that Home
            # fanart is not a valid fallback for this different-title Info target.
            try:
                li.setProperty("PlexKM.Info.ChildAtomicV2132", "1")
            except Exception:
                pass
            _info_item_source_v1772 = "actor_work_detached_v2082"
            try:
                del _native_actor_work_li_v2082
            except Exception:
                pass
        _info_persistent_hit_v2467 = False
        if li is not None:
            _info_cache_apply_t0_v2513 = self._now_ms()
            try:
                _info_persistent_hit_v2467 = bool(self._info_prepared_cache_apply_v2467(li))
            except Exception:
                _info_persistent_hit_v2467 = False
            try:
                _log("INFO_PREPARED_CACHE_CLICK_TIMING_V2513 rating_key=%s hit=%d elapsed_ms=%d memory_loaded=%d file_io_expected=0" % (
                    str(li.getProperty("PlexKM.RatingKey") or ""),
                    1 if _info_persistent_hit_v2467 else 0,
                    max(0, self._now_ms() - _info_cache_apply_t0_v2513),
                    1 if isinstance(getattr(self, "_info_prepared_cache_v2467", None), dict) else 0
                ))
            except Exception:
                pass
            # v2380R1: this marker is scoped to one Info-open transaction.  A
            # timed-out Plex repair must be allowed to retry on a later open,
            # while still preventing a duplicate cast request in this same open.
            try:
                li.setProperty("PlexKM.InfoPlexDirectRepairAttemptedRatingKey", "")
            except Exception:
                pass
        if not li:
            self._info_dialog_active = False
            try:
                self._info_reentrant_open_in_progress_v2082 = False
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapV2087")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapStartMsV2152")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
                self._info_clear_property_all("PlexKM.Info.ReentrantSwapV2083")
                self._info_clear_property_all("PlexKM.Info.ReentrantScrollResetV2086")
                self._info_clear_property_all("PlexKM.Info.DirectSwapV2086")
            except Exception:
                pass
            _log("INLINE_INFO_OPEN_ABORT_V1772 reason=no_item source=%s" % _info_item_source_v1772, xbmc.LOGWARNING)
            return
        # v2194: preserve V2191 geometry exactly.  For a fresh Home -> Info entry,
        # capture the *current Home window* visual owner, not Window(10000) first.
        # Home itself renders self/Window(13000).DisplayFanart, and canonical movie
        # duplicates can legitimately use an art URL containing a different sibling
        # ratingKey.  Validate with Home.RatingKey instead of parsing the art URL,
        # then reuse the exact displayed texture string in Info A/B and fallback.
        try:
            _target_rk_v2194 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            _home_rk_v2194 = str(
                self.getProperty("PlexKM.Home.RatingKey")
                or xbmcgui.Window(13000).getProperty("PlexKM.Home.RatingKey")
                or xbmcgui.Window(10000).getProperty("PlexKM.Home.RatingKey")
                or ""
            ).strip()
            _home_art_v2194 = str(
                self.getProperty("PlexKM.Home.DisplayFanart")
                or xbmcgui.Window(13000).getProperty("PlexKM.Home.DisplayFanart")
                or xbmcgui.Window(10000).getProperty("PlexKM.Home.DisplayFanart")
                or ""
            ).strip()
            # R115: Home shows a 1360x765 hero transcode.  Movie Info uses the
            # same 1360x765 box, so the exact texture is reused; TV Info paints
            # the art full-screen (1920x1080), so give it the original instead
            # of upscaling the Home transcode.
            try:
                if str(li.getProperty("PlexKM.Type") or "").strip().lower() in ("episode", "show", "season"):
                    _raw_r115 = str(
                        self.getProperty("PlexKM.Home.DisplayFanartRaw")
                        or xbmcgui.Window(10000).getProperty("PlexKM.Home.DisplayFanartRaw")
                        or ""
                    ).strip()
                    if _raw_r115:
                        _home_art_v2194 = str(self._home_fanart_display_url(_raw_r115) or _home_art_v2194)
            except Exception:
                pass
            _fresh_home_match_v2194 = bool(
                not _info_inline_was_active_v2087
                and _target_rk_v2194
                and _home_rk_v2194 == _target_rk_v2194
                and _home_art_v2194
            )
            _win_v2194 = xbmcgui.Window(10000)
            if _fresh_home_match_v2194:
                li.setProperty("PlexKM.Info.EntryHomeFanartV2194", _home_art_v2194)
                li.setProperty("PlexKM.Info.EntryHomeRatingKeyV2194", _target_rk_v2194)
                _win_v2194.setProperty("PlexKM.Info.EntryHomeFanartV2194", _home_art_v2194)
                _win_v2194.setProperty("PlexKM.Info.EntryHomeRatingKeyV2194", _target_rk_v2194)
                _log("INFO_FANART_HOME_VISUAL_CAPTURE_V2194 target=%s home_rating_key=%s source=current_home_window exact_visible_texture=1 xml_home_x=700 xml_info_x=700 size=1220x680" % (
                    _target_rk_v2194, _home_rk_v2194
                ))
            else:
                try:
                    li.setProperty("PlexKM.Info.EntryHomeFanartV2194", "")
                    li.setProperty("PlexKM.Info.EntryHomeRatingKeyV2194", "")
                except Exception:
                    pass
                # Never let a stale Home capture override a different fresh target.
                if not _info_inline_was_active_v2087:
                    _win_v2194.clearProperty("PlexKM.Info.EntryHomeFanartV2194")
                    _win_v2194.clearProperty("PlexKM.Info.EntryHomeRatingKeyV2194")
                _log("INFO_FANART_HOME_VISUAL_CAPTURE_SKIP_V2194 target=%s home_rating_key=%s inline_active=%d art=%d" % (
                    _target_rk_v2194, _home_rk_v2194, 1 if _info_inline_was_active_v2087 else 0, 1 if _home_art_v2194 else 0
                ))
        except Exception:
            _log("INFO_FANART_HOME_VISUAL_CAPTURE_FAILED_V2194 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            _info_target_key_v2087 = li.getProperty("PlexKM.RatingKey") or ""
            _info_current_key_v2087 = (
                xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey")
                or getattr(self, "_last_info_rating_key", "")
                or ""
            )
            _info_same_surface_new_title_v2087 = bool(
                _info_inline_was_active_v2087
                and not _history_restore_v2085
                and _info_target_key_v2087
                and _info_target_key_v2087 != _info_current_key_v2087
            )
            # v2136: visual A/B ownership is universal. History Back is also a
            # different-title Info swap even though v2087 intentionally skips its
            # forward-only scroll-reset arm. Keep this separate from focus policy.
            _info_visual_ab_swap_v2136 = bool(
                _info_inline_was_active_v2087
                and _info_target_key_v2087
                and _info_target_key_v2087 != _info_current_key_v2087
            )
            _info_defer_cover_arm_v2143 = False
            # v2144: for every first/fresh Info entry (Home widget, section
            # recommendation, library wall, category, search), the source surface
            # remains visible for the entire synchronous target preparation.
            # Target Info properties/native controls are not visible while
            # InlineActive=0, so there is no reason to paint the v2137 solid
            # transition cover early. The shared delayed busy spinner, when needed,
            # therefore renders on the actual source posters/fanart. Once the target
            # is complete, InlineActive publishes it directly with the existing
            # short Info fade-in. No blank/tinted intermediate screen.
            _info_source_surface_hold_v2144 = bool(not _info_inline_was_active_v2087)
            if _info_same_surface_new_title_v2087:
                # v2332 PKM common page policy: every same-surface different-title
                # Info transition keeps the COMPLETE source page visible for the
                # entire target preparation interval.  Do not arm EntrySwap/Cover
                # before metadata, artwork, exact tint, cast, versions and visible
                # rows have been resolved.  The final GUI-thread publish below is
                # one no-blank atomic owner switch.
                _info_defer_cover_arm_v2143 = True
                _log("INFO_FULL_PAGE_SOURCE_HOLD_V2332 from=%s to=%s source_focus=%s source=%s previous_page_visible=1 cover=0 spinner_policy=global_info_delay prepare_before_visible=1" % (
                    _info_current_key_v2087, _info_target_key_v2087, _info_origin_focus_v2082, _info_item_source_v1772
                ))
            else:
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapV2087")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapStartMsV2152")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
                _log("INFO_ENTRY_PIPELINE_ARM_V2087 from=%s to=%s source_focus=%s source=%s mode=fresh_or_same_title top_lock=0" % (
                    _info_current_key_v2087, _info_target_key_v2087, _info_origin_focus_v2082, _info_item_source_v1772
                ))
        except Exception:
            _info_same_surface_new_title_v2087 = False
            _info_visual_ab_swap_v2136 = False
            _info_defer_cover_arm_v2143 = False
            _info_source_surface_hold_v2144 = bool(not _info_inline_was_active_v2087)
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapV2087")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapStartMsV2152")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
            except Exception:
                pass
        _log("INLINE_INFO_ITEM_SOURCE_V1772 source=%s rating_key=%s title=%s" % (
            _info_item_source_v1772,
            li.getProperty("PlexKM.RatingKey") or "",
            _short_log_value(li.getLabel() or "", 120),
        ))
        # v2332: Search is governed by the same full-page readiness contract.
        # Its local result ListItem remains the fast seed, but any metadata/cast
        # needed by the visible Info page is finalized before reveal; there is no
        # current-page background fill after the target becomes visible.
        _info_global_busy_token_v1883, _search_info_fast_path_v1773 = self._show_info_step2(_history_restore_v2085, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_origin_focus_v2082, _info_persistent_hit_v2467, li)
        try:
            # R105: sidebar scroll hold belongs to the previous Info page.
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.ScrollHoldR105")
        except Exception:
            pass
        try:
            _log("INLINE_INFO_OPEN rating_key=%s label=%s type=%s" % (
                li.getProperty("PlexKM.RatingKey"),
                _short_log_value(li.getLabel(), 120),
                li.getProperty("PlexKM.Type"),
            ))
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.Info.TimingOpenStartMs", str(_info_open_start_ms))
                _log("INFO_TIMING phase=open_begin rating_key=%s elapsed=%dms" % (li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms))
            except Exception:
                pass
            try:
                _transition_token = pkm_transition_manager.begin_info_transition(
                    self, li.getProperty("PlexKM.RatingKey") or "", mode="inline_info", cover=False
                )
                # v2140: the cover is Info-owned. Seed it from the currently
                # visible Home/Info surface before the first fade frame so an old
                # Home tint can never become the target Info's permanent color.
                self._info_dynamic_bg_seed_v2140(
                    inline_active=_info_inline_was_active_v2087, reason="before_cover"
                )
                # v2144: source-surface entries (Home/recommend/library/category/
                # search) keep that completed source visible until the target Info
                # is fully prepared. Actor-work child Info keeps the v2143 parent-
                # hold path. Only remaining same-surface Info swaps that cannot be
                # staged safely use the older v2137 cover during mutation.
                if _history_restore_v2085:
                    # v2309: do not reuse the new-Info visual cover for Back.
                    # The child Info is already a complete safe surface; leave it
                    # visible until the normal parent atomic commit finishes.
                    _log("INFO_HISTORY_SOURCE_HOLD_V2309 rating_key=%s token=%s cover=0 spinner=0 child_surface_visible=1" % (
                        li.getProperty("PlexKM.RatingKey") or "", _transition_token
                    ))
                elif _info_defer_cover_arm_v2143:
                    _log("INFO_PREPARE_BEHIND_PREVIOUS_V2143 rating_key=%s token=%s cover=0 previous_info_visible=1 spinner_surface=previous_info" % (
                        li.getProperty("PlexKM.RatingKey") or "", _transition_token
                    ))
                elif _info_source_surface_hold_v2144:
                    # v2144: fresh/source-surface Info opens never switch to the
                    # solid Info transition base while data is still being prepared.
                    # Home/recommend/library/search remain fully visible; if the
                    # 1.2 s Info busy threshold is crossed the spinner is drawn on
                    # that source surface. The completed Info is published only at
                    # the final InlineActive commit below.
                    _log("INFO_SOURCE_SURFACE_HOLD_V2144 rating_key=%s token=%s cover=0 inline_active=0 spinner_surface=source source_focus=%s source=%s" % (
                        li.getProperty("PlexKM.RatingKey") or "", _transition_token,
                        _info_origin_focus_v2082, _info_item_source_v1772
                    ))
                else:
                    # v2332: same-title reuse is not a page transition and never
                    # needs a painted transition surface.  Keep the current complete
                    # Info visible while its detached values are revalidated.
                    try:
                        xbmcgui.Window(10000).clearProperty("PlexKM.Info.Transition.Cover")
                        self.clearProperty("PlexKM.Info.Transition.Cover")
                    except Exception:
                        pass
                    _log("INFO_SAME_TITLE_SOURCE_HOLD_V2332 rating_key=%s token=%s cover=0 previous_page_visible=1 blank_surface=0" % (
                        li.getProperty("PlexKM.RatingKey") or "", _transition_token
                    ))
                _log("INFO_TRANSITION phase=prepare_begin rating_key=%s token=%s mode=double_buffer" % (li.getProperty("PlexKM.RatingKey") or "", _transition_token))
            except Exception:
                _transition_token = ""
            self._inline_info_diag_log(phase="open_begin", reason="before_publish")
            # v2142: actor-work containers are persistent native controls. After a
            # previous Info closes they can still contain the old title's 6210/6220
            # items while InlineActive is already 0. If the next Movie Info is
            # revealed before those stale containers are rebuilt, the v2129
            # "더보기" visibility expression sees the old NumItems for a few frames
            # and flashes a cue that the new title does not actually have.
            #
            # For every normal Info entry, clear stale actor-work containers while
            # the v2137 fade cover still owns the visual surface, before InlineActive
            # can expose the target. The actor-work reentrant path is intentionally
            # excluded because its focused 6210/6220 native ControlList must stay
            # alive until Kodi hands focus to the child Info (v2082/v2123 contract).
            try:
                if _history_restore_v2085:
                    # v2309: these are the controls the parent rebuild will
                    # repopulate.  Clearing them now exposes the blank gap that
                    # made Back look like a new page load.  Do not retain/reuse
                    # native ListItem objects; only defer the destructive clear.
                    _log("INFO_HISTORY_STALE_WIDGET_CLEAR_SKIP_V2309 rating_key=%s reason=keep_child_surface_until_parent_commit" % (li.getProperty("PlexKM.RatingKey") or ""))
                elif not _info_actor_work_reentrant_v2082:
                    _stale_widget_sizes_v2142 = []
                    for _cid_v2142 in tuple(INFO_MOVIE_WIDGET_ROW_IDS) + tuple(INFO_TV_ACTOR_WIDGET_ROW_IDS):
                        _stale_widget_sizes_v2142.append(self._info_movie_widget_size(_cid_v2142))
                    self._info_movie_widget_clear()
                    _log("INFO_PREVISIBLE_STALE_WIDGET_CLEAR_V2142 rating_key=%s source_focus=%s inline_was_active=%d sizes_before=%s cover=%d source_hold_v2144=%d native_focus_write=0" % (
                        li.getProperty("PlexKM.RatingKey") or "", _info_origin_focus_v2082,
                        1 if _info_inline_was_active_v2087 else 0,
                        ",".join(str(x) for x in _stale_widget_sizes_v2142),
                        0 if _info_source_surface_hold_v2144 else 1,
                        1 if _info_source_surface_hold_v2144 else 0
                    ))
                else:
                    _log("INFO_PREVISIBLE_STALE_WIDGET_CLEAR_SKIP_V2142 rating_key=%s source_focus=%s reason=actor_work_native_focus_owner" % (
                        li.getProperty("PlexKM.RatingKey") or "", _info_origin_focus_v2082
                    ))
            except Exception:
                _log("INFO_PREVISIBLE_STALE_WIDGET_CLEAR_FAILED_V2142 rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            # v855: Movies keep the v852 fast first paint, but TV/show/episode
            # Info must not expose a half-built screen.  The Home ListItem for a
            # TV row can initially contain only episode-level metadata; publish
            # the local DB snapshot first so title/type/summary are final before
            # the inline group becomes visible.  This is local DB only and never
            # mutates the Home poster/fanart.
            _initial_plex_type = (li.getProperty("PlexKM.Type") or "").lower()
            _initial_kodi_type = (li.getProperty("PlexKM.KodiType") or "").lower()
            _initial_is_tv = _initial_plex_type in ("show", "season", "episode", "tv") or _initial_kodi_type in ("tvshow", "episode")
            # V2626 user-perceived Info transaction: start after the exact target is known.
            _info_v2626_media = "tv" if _initial_is_tv else "movie"
            _info_v2626_cache = "warm" if _info_persistent_hit_v2467 else "cold"
            _info_v2626_source = str(_info_item_source_v1772 or "focused_wall") + ":focus=" + str(_info_origin_focus_v2082)
            try:
                _info_kpi_win_v2626 = xbmcgui.Window(10000)
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoEntryMedia", _info_v2626_media)
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoEntryCache", _info_v2626_cache)
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoEntrySource", _info_v2626_source)
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoEntryRatingKey", str(li.getProperty("PlexKM.RatingKey") or ""))
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoEntryStamp", str(self._now_ms()))
                _log("INFO_ENTRY_BEGIN_V2626 rating_key=%s media=%s cache=%s source=%s pre_sql=0 pre_net=0" % (
                    li.getProperty("PlexKM.RatingKey") or "", _info_v2626_media, _info_v2626_cache, _info_v2626_source
                ))
            except Exception:
                pass
            self._show_info_step3(_history_restore_v2085, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_open_start_ms, _initial_is_tv, li)
            # v2136: prepare the next fanart in the inactive bank before any
            # visible ownership change. This path is shared by movie/show/episode,
            # Home/recommend/library/search and nested/Back Info entry.
            try:
                self._info_art_stage_v2136(li, reason="after_full_snapshot_before_visible_v2332")
                self._info_dynamic_bg_stage_exact_v2332(li, reason="full_page_before_visible_v2332")
            except Exception:
                pass
            # v2383: keep the expensive actor/related-work DB scan completely
            # out of the first-paint critical path.  Movie version metadata remains
            # precomputed because it is bounded/local; actor rows start only after
            # InlineActive has been published.
            try:
                if not _initial_is_tv:
                    # v2515: the stable-focus worker is advisory.  Once Enter is
                    # pressed, invalidate its token before the authoritative
                    # foreground version lookup.  An already-running worker has
                    # a SQLite progress handler and exits instead of contending.
                    try:
                        self._cast_focus_idle_token_v1642 = int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0) + 1
                        _log("INFO_FOCUS_DATA_PREWARM_CANCEL_ON_CLICK_V2515 rating_key=%s token=%d foreground_priority=1" % (
                            li.getProperty("PlexKM.RatingKey") or "", int(self._cast_focus_idle_token_v1642)
                        ))
                    except Exception:
                        pass
                    self._info_movie_precompute_versions_v2185(li, reason="full_page_before_visible_v2332")
            except Exception:
                pass
            try:
                self._info_widget_rows_precomputed_v2332 = None
                _log("INFO_ACTOR_WIDGETS_PREVISIBLE_ARM_V2429 rating_key=%s is_tv=%d reason=complete_page_required" % (
                    li.getProperty("PlexKM.RatingKey") or "", 1 if _initial_is_tv else 0
                ))
            except Exception:
                pass
            try:
                if _info_defer_cover_arm_v2143:
                    _log("INFO_PREPARE_TARGET_STAGED_V2143 from=%s to=%s cover=0 previous_info_visible=1 target_art_staged=1" % (
                        _info_current_key_v2087, _info_target_key_v2087
                    ))
                elif _info_source_surface_hold_v2144:
                    _log("INFO_SOURCE_TARGET_STAGED_V2144 from=%s to=%s cover=0 inline_active=0 source_surface_visible=1 target_art_staged=1" % (
                        _info_current_key_v2087, _info_target_key_v2087
                    ))
                else:
                    # v2137: the cover was already armed at open_begin, before the
                    # target ListItem is published. Keep it opaque while cast/TV rows
                    # and inactive fanart bank are composed. This removes the v2136
                    # interval where new metadata could be drawn over old fanart.
                    _log("INFO_FADE_TRANSACTION_HOLD_V2137 from=%s to=%s cover=1 target_staged=1" % (
                        _info_current_key_v2087, _info_target_key_v2087
                    ))
            except Exception:
                pass
            self._show_info_step4(_info_actor_work_reentrant_v2082, _info_defer_cover_arm_v2143, _info_open_start_ms, _info_origin_focus_v2082, _initial_is_tv, _search_info_fast_path_v1773, li)

            # v2429: actor works are part of the complete Info page. Build the
            # related-work snapshot now, after the final cast-source repair, while
            # Home/Section/parent Info is still the visible owner. A cold authority
            # path may take time; that wait belongs before Info, never as late pop-in.
            try:
                if self._uhd_kpi_proxy_v2605():
                    # R67: Reuse only a matching already-prepared focus snapshot.
                    # Never run a cold SQLite query on the Android Info click path.
                    _rk_r67 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                    _hint_r67 = str(li.getProperty("PlexKM.Cast1.Name") or "")
                    _genre_r67 = str(li.getProperty("PlexKM.Genre") or "")
                    _focus_r67 = {}
                    try:
                        with self._info_focus_prewarm_lock_v2508:
                            _focus_r67 = dict(self._info_focus_prewarm_cache_v2508.get(_rk_r67) or {})
                    except Exception:
                        _focus_r67 = {}
                    _age_r67 = max(0.0, time.time() - float(_focus_r67.get("ts") or 0.0))
                    if (_age_r67 <= 15.0 and "widget_rows" in _focus_r67
                            and str(_focus_r67.get("actor_hint") or "") == _hint_r67
                            and str(_focus_r67.get("genre_hint") or "") == _genre_r67):
                        _actor_rows_v2429 = list(_focus_r67.get("widget_rows") or [])
                        self._info_widget_rows_precomputed_v2332 = {
                            "rating_key": _rk_r67, "is_tv": bool(_initial_is_tv),
                            "rows": list(_actor_rows_v2429),
                            "actor_hint": _hint_r67, "genre_hint": _genre_r67,
                        }
                        _log("R67_INFO_WIDGET_PREVISIBLE_CACHE_HIT rating_key=%s rows=%d db_query=0" % (
                            _rk_r67, len(_actor_rows_v2429)))
                    else:
                        self._info_widget_rows_precomputed_v2332 = None
                        _actor_rows_v2429 = []
                        _log("R67_INFO_WIDGET_CACHE_MISS rating_key=%s action=keep_existing_postvisible" % _rk_r67)
                else:
                    _actor_rows_t0_v2429 = self._now_ms()
                    _actor_rows_v2429 = self._info_stage_actor_widget_rows_v2332(
                        li, is_tv=_initial_is_tv, reason="full_page_before_visible_v2429"
                    ) or []
                    _log("INFO_ACTOR_WIDGETS_PREVISIBLE_READY_V2429 rating_key=%s is_tv=%d rows=%d elapsed_ms=%d visible_mutation=0" % (
                        li.getProperty("PlexKM.RatingKey") or "",
                        1 if _initial_is_tv else 0,
                        len(_actor_rows_v2429),
                        self._now_ms() - _actor_rows_t0_v2429
                    ))
            except Exception:
                self._info_widget_rows_precomputed_v2332 = None
                _log("INFO_ACTOR_WIDGETS_PREVISIBLE_FAILED_V2429 rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "",
                    traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

            # v2143: the expensive first-paint cast-circle work can be completed
            # against the detached target ListItem without touching any visible
            # Info properties or native panels.  This is the key to keeping the
            # parent Info visible (and, when needed, the spinner over that parent)
            # instead of showing a blank transition surface for the whole wait.
            if _info_defer_cover_arm_v2143:
                try:
                    _stage_cast_t0_v2143 = self._now_ms()
                    _cast_download_v2601 = False  # V2616: never block Info staging on portrait downloads
                    if _cast_download_v2601:
                        self._kpi_info_pre_net_v2605 = 1
                    self._prepare_info_cast_display_snapshot(li, stage_only=True, allow_download=_cast_download_v2601)
                    if not _cast_download_v2601:
                        _log("INFO_CAST_STAGE_LOCAL_ONLY_V2601 rating_key=%s network_wait=0 placeholders_allowed=1" % (
                            li.getProperty("PlexKM.RatingKey") or ""
                        ))
                    _log("INFO_ACTOR_CHILD_CAST_STAGE_V2143 rating_key=%s elapsed_ms=%d visible_mutation=0 previous_info_visible=1" % (
                        li.getProperty("PlexKM.RatingKey") or "", self._now_ms() - _stage_cast_t0_v2143
                    ))
                except Exception:
                    _log("INFO_ACTOR_CHILD_CAST_STAGE_FAILED_V2143 rating_key=%s err=%s" % (
                        li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                # v2185: movie version grouping used to run inside
                # _publish_info_window_properties after Cover was already active.
                # Precompute the SQLite result now without publishing a single
                # PlexKM.Info.* property; the final publisher consumes it in place.
                if not _initial_is_tv:
                    try:
                        _pre_v2332 = getattr(self, "_info_movie_precomputed_versions_v2185", None)
                        if not (isinstance(_pre_v2332, dict) and str(_pre_v2332.get("rating_key") or "") == str(li.getProperty("PlexKM.RatingKey") or "")):
                            self._info_movie_precompute_versions_v2185(
                                li, reason="full_page_atomic_boundary_fallback_v2332"
                            )
                        _log("INFO_MOVIE_VERSION_STAGE_READY_V2332 rating_key=%s previous_info_visible=1 cover=0 visible_mutation=0" % (
                            li.getProperty("PlexKM.RatingKey") or ""
                        ))
                    except Exception:
                        _log("INFO_MOVIE_VERSION_STAGE_READY_FAILED_V2332 rating_key=%s err=%s" % (
                            li.getProperty("PlexKM.RatingKey") or "",
                            traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)

                # v2160: TV row composition used to hide the parent before its
                # slow episode-still preparation.  The 2026-08-12 trace showed
                # INFO_ACTOR_CHILD_LATE_COVER at 20:57:15.279 followed by a
                # 3.645s TV-row prepare, producing a bare tint + spinner screen.
                # Pre-stage the only network-sensitive TV scene assets now while
                # the completed parent Info is still the visible surface.  This
                # helper is UI-free; no shared Info properties/native controls are
                # mutated and Cover/EntrySwap remain off.
                if _initial_is_tv:
                    try:
                        _tv_scene_stage_t0_v2160 = self._now_ms()
                        if self._uhd_kpi_proxy_v2605():
                            _log("INFO_TV_PRESTAGE_NETWORK_SKIP_V2605 rating_key=%s previous_info_visible=1 episode_thumb_wait=0 allleaves_before_visible=0 proxy=%d" % (
                                li.getProperty("PlexKM.RatingKey") or "", 0 if self._is_android_v2591() else 1
                            ))
                        else:
                            self._info_tv_prestage_scene_assets_v2160(li, max_wait_ms=700)
                        _log("INFO_ACTOR_CHILD_TV_PRESTAGE_DONE_V2160 rating_key=%s previous_info_visible=1 cover=0 entry_swap=0 elapsed_ms=%d" % (
                            li.getProperty("PlexKM.RatingKey") or "", self._now_ms() - _tv_scene_stage_t0_v2160
                        ))
                    except Exception:
                        _log("INFO_ACTOR_CHILD_TV_PRESTAGE_FAILED_V2160 rating_key=%s previous_info_visible=1 cover=0 err=%s" % (
                            li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                try:
                    # Final mutation boundary: from here the target properties and
                    # native controls may change, so atomically hide/reset the old
                    # animation owner and start the short fade cover only now.
                    # v2160 guarantees that blocking TV thumbnail work has already
                    # happened on the still-visible parent before this boundary.
                    xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
                    # v2185: timestamp the exact instant the old v2079 scroll
                    # condition is disabled. The release worker waits only the
                    # REMAINING part of its 420ms reversible animation, so target
                    # publishing time is counted instead of adding a fixed delay.
                    xbmcgui.Window(10000).setProperty("PlexKM.Info.EntrySwapStartMsV2152", str(self._now_ms()))
                    xbmcgui.Window(10000).setProperty("PlexKM.Info.EntrySwapV2087", "1")
                    xbmcgui.Window(10000).setProperty("PlexKM.Info.ChildFreshEntryV2123", "1")
                    xbmcgui.Window(10000).setProperty("PlexKM.Info.EntryTargetRatingKeyV2123", _info_target_key_v2087)
                    xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntryTargetReadyV2123")
                    xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntryTargetFocusReadyV2123")
                    xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntryResetHideV2123")
                    self._info_set_property_all("PlexKM.Info.ReentrantSwapV2083", "1")
                    self._info_set_property_all("PlexKM.Info.ReentrantScrollResetV2086", "1")
                    self._info_set_property_all("PlexKM.Info.DirectSwapV2086", "1")
                    # v2332: universal no-blank final owner switch.  Reuse the
                    # v2190 compensation mode for every same-surface Info swap so
                    # EntrySwap suppresses the source scroll animation without
                    # requiring a painted full-screen color cover.  Cover stays 0;
                    # the GUI-thread callback publishes the complete target before
                    # Kodi can render the next frame.
                    _win_atomic_v2332 = xbmcgui.Window(10000)
                    _win_atomic_v2332.setProperty("PlexKM.Info.ActorPrecomposeV2185", "1")
                    _win_atomic_v2332.setProperty("PlexKM.Info.ActorSourceFocusV2190", str(_info_origin_focus_v2082 or 0))
                    _win_atomic_v2332.setProperty(
                        "PlexKM.Info.ActorSourceHadSeasonCardsV2306",
                        "1" if _win_atomic_v2332.getProperty("PlexKM.Info.HasSeasonCards") == "1" else "0"
                    )
                    _win_atomic_v2332.clearProperty("PlexKM.Info.Transition.Cover")
                    try:
                        self.clearProperty("PlexKM.Info.Transition.Cover")
                    except Exception:
                        pass
                    self._reset_info_cast_panel(reason="full_page_atomic_publish_v2332_%s" % (li.getProperty("PlexKM.RatingKey") or ""))
                    _log("INFO_FULL_PAGE_ATOMIC_BOUNDARY_V2332 from=%s to=%s token=%s cover=0 previous_page_held_until_commit=1 target_data_prepared=1 blank_surface=0" % (
                        _info_current_key_v2087, _info_target_key_v2087, _transition_token
                    ))
                except Exception:
                    _log("INFO_ACTOR_CHILD_LATE_COVER_FAILED_V2143 rating_key=%s err=%s" % (
                        li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            # v2511: latch the currently visible Home hero display before the
            # target Info properties replace it. Identity must match exactly.
            _entry_home_visual_v2511 = self._info_home_visual_continuity_v2511(
                li, reason="before_publish"
            )
            _publish_start_ms = self._now_ms()
            # v2429: consume the pre-visible snapshot and bind actor-work native
            # rows before InlineActive/atomic release.
            _info_widgets_before_visible_v2601 = not self._uhd_kpi_proxy_v2605()
            self._publish_info_window_properties(li, populate_movie_widgets=_info_widgets_before_visible_v2601)
            if not _info_widgets_before_visible_v2601:
                _log("INFO_PUBLISH_NATIVE_FIRST_V2605 rating_key=%s actor_widgets=deferred cast_network=0 tv_network=0" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            try:
                _log("INFO_TIMING phase=publish_done rating_key=%s elapsed=%dms step=%dms summary=%s cast1=%s cine21=%s/%s" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms, self._now_ms() - _publish_start_ms,
                    "1" if xbmcgui.Window(10000).getProperty("PlexKM.Info.SummaryDisplay") else "0",
                    _short_log_value(xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name") or xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast1.Name"), 80),
                    xbmcgui.Window(10000).getProperty("PlexKM.Info.Cine21CriticRating"),
                    xbmcgui.Window(10000).getProperty("PlexKM.Info.Cine21AudienceRating")
                ))
            except Exception:
                pass
            try:
                self._info_clear_property_all("PlexKM.Info.CastReady")
            except Exception:
                pass

            # v917: cast must be in the 6100 panel before the Info group is revealed.
            # In v916 the panel was populated ~40ms after inline_visible, so the first
            # paint could show an empty Credits row until focus/down forced a refresh.
            # v1214: final pre-visible guard.  If earlier local DB/cache work still
            # left cast names without real thumbs, force the selected item directly
            # from Plex now; do not render placeholder avatars as a completed rail.
            _cast_fast_start_ms = self._now_ms()
            # v1332: Movie Credits must be prepared before the Info overlay is revealed.
            # The uploaded Enola Holmes 3 log shows Plex already returns Role/thumb
            # values, but the old path revealed the Info shell first, then the
            # background worker downloaded/cropped actor images.  That produced
            # visible grey avatars/remote-image pop-in and transient oval/morphing.
            # Do one bounded active-item metadata repair only when local cache is
            # incomplete, then create local circular PNGs in parallel before first paint.
            self._show_info_step5(_initial_is_tv, _search_info_fast_path_v1773, li)
            try:
                _cast1_now = xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name") or xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast1.Name") or ""
                _cast_atomic_pending_now_v2629 = (
                    self.getProperty("PlexKM.Info.CastAtomicPendingV2629") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.CastAtomicPendingV2629") == "1"
                )
                if _cast1_now and not _cast_atomic_pending_now_v2629:
                    self._info_set_property_all("PlexKM.Info.CastReady", "1")
                    self.setProperty("PlexKM.Info.CastReady", "1")
                else:
                    self._info_clear_property_all("PlexKM.Info.CastReady")
                    self.clearProperty("PlexKM.Info.CastReady")
                _log("INFO_TIMING phase=cast_before_visible_done rating_key=%s elapsed=%dms step=%dms display_cast1=%s ready=%s" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms, self._now_ms() - _cast_fast_start_ms,
                    _short_log_value(_cast1_now, 80), "1" if _cast1_now else "0"
                ))
            except Exception:
                pass

            # v1883 root fix: TV Info is composed before InlineActive is published.
            # Home therefore remains the completed visible surface during local DB
            # work or the cold Plex episode fallback.  The global busy broker alone
            # adds a spinner after its common delay; no blank cover or TV mask exists.
            _tv_prepare_failed = False
            if _initial_is_tv:
                try:
                    self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                    self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                    self._info_clear_property_all("PlexKM.Info.TVEpisodeHint")
                    self._info_tv_defer_focus = True
                except Exception:
                    pass
                _previous_info_surface_v1884 = (
                    self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
                )
                try:
                    _tv_prepare_start_ms = self._now_ms()
                    # v2609: a TV Info rail is a first-frame requirement again.
                    # Focus prewarm normally supplies rows with zero click I/O. On
                    # a genuine cold miss, source-hold permits one bounded allLeaves
                    # fetch before reveal instead of showing a loading shell and
                    # visibly inserting episodes later.
                    _tv_network_before_visible_v2601 = True
                    if _tv_network_before_visible_v2601 and not self._uhd_kpi_proxy_v2605():
                        self._kpi_info_pre_net_v2605 = 1
                    if self._prepare_info_tv_rows(
                            li, preserve_previous_surface=_previous_info_surface_v1884,
                            allow_network=True) is False:
                        _tv_prepare_failed = True
                    _tv_rows_now_v2609 = len(getattr(self, "_info_tv_rows", []) or [])
                    self._info_clear_property_all("PlexKM.Info.TVEpisodeHint")
                    _log("INFO_TV_FIRST_FRAME_ATOMIC_V2609 rating_key=%s rows=%d allleaves_cold_allowed=1 loading_shell=0 postvisible_insert=0 source_hold=1" % (
                        li.getProperty("PlexKM.RatingKey") or "", _tv_rows_now_v2609
                    ))
                    _tv_prepare_step_ms = self._now_ms() - _tv_prepare_start_ms
                    _log("INFO_TIMING phase=tv_rows_prepare_%s rating_key=%s step=%dms policy=local_first_plex_fallback_1500ms_cap_v2380 previous_surface=1" % (
                        "slow" if _tv_prepare_step_ms > 300 else "done",
                        li.getProperty("PlexKM.RatingKey") or "", _tv_prepare_step_ms
                    ), xbmc.LOGWARNING if _tv_prepare_step_ms > 300 else xbmc.LOGINFO)
                except Exception:
                    _tv_prepare_failed = True
                    try:
                        self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                        self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                        self._info_set_property_all("PlexKM.Info.TVRowsFailedV1841", "1")
                        pkm_transition_manager.cancel_info_transition(self)
                        # A Python exception escaping _prepare_info_tv_rows means
                        # its transactional restore could not complete.  Do not
                        # claim the old Info surface is safe; expose the completed
                        # Home surface and restore its native origin focus.
                        self._info_clear_property_all("PlexKM.Info.InlineActive")
                        self._restore_inline_info_origin_focus(reason="tv_prepare_call_failed_v1884")
                        _log("INLINE_INFO_TV_PREPARE_CALL_FAILURE_HOME_FALLBACK_V1884 previous_surface=%d" % (
                            1 if _previous_info_surface_v1884 else 0
                        ))
                    except Exception:
                        pass
                    _log("INLINE_INFO_TV_PREPARE_CALL_FAILED_V1884 err=%s" % (
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                if _tv_prepare_failed:
                    try:
                        self._info_tv_defer_focus = False
                    except Exception:
                        pass
                    try:
                        pkm_transition_manager.cancel_info_transition(self)
                    except Exception:
                        pass
                    try:
                        self._info_clear_property_all("PlexKM.Info.ReentrantScrollResetV2086")
                        self._info_clear_property_all("PlexKM.Info.ReentrantSwapV2083")
                        self._info_clear_property_all("PlexKM.Info.DirectSwapV2086")
                    except Exception:
                        pass
                    try:
                        self._scene_busy_finish_v2482(_info_global_busy_token_v1883, reason="tv_info_prepare_failed")
                        _info_global_busy_token_v1883 = ""
                    except Exception:
                        pass
                    _log("INLINE_INFO_TV_PREPARE_TERMINAL_V1883 rating_key=%s action=previous_surface_preserved" % (
                        li.getProperty("PlexKM.RatingKey") or ""
                    ), xbmc.LOGERROR)
                    return

            # v2383: related-work rows are not a visibility prerequisite.  The
            # target Info surface is allowed to publish now; data-only preparation
            # is scheduled after the visible boundary and native controls are bound
            # only later at the established safe cast-row focus milestone.
            try:
                _ac_names_v2609, _ac_real_v2609 = self._li_cast_thumb_stats_for_info(li)
                _ac_lead_v2609 = min(3, int(_ac_names_v2609 or 0))
                _ac_tv_rows_v2609 = len(getattr(self, "_info_tv_rows", []) or []) if _initial_is_tv else -1
                _ac_complete_v2609 = (
                    (int(_ac_real_v2609 or 0) >= _ac_lead_v2609)
                    and ((not _initial_is_tv) or _ac_tv_rows_v2609 > 0)
                )
                self._info_set_property_all("PlexKM.Info.AtomicCompleteV2609", "1" if _ac_complete_v2609 else "")
                _log("INFO_ATOMIC_COMPLETE_V2609 rating_key=%s elapsed_ms=%d cast_names=%d cast_real=%d cast_lead_required=%d tv=%d tv_rows=%d complete=%d" % (
                    li.getProperty("PlexKM.RatingKey") or "", self._now_ms() - _info_open_start_ms,
                    int(_ac_names_v2609 or 0), int(_ac_real_v2609 or 0), _ac_lead_v2609,
                    1 if _initial_is_tv else 0, _ac_tv_rows_v2609, 1 if _ac_complete_v2609 else 0
                ))
            except Exception:
                pass

            try:
                _log("INFO_VISIBLE_WIDGETS_DEFER_V2383 rating_key=%s is_tv=%d source_focus=%s before_visible=0" % (
                    li.getProperty("PlexKM.RatingKey") or "", 1 if _initial_is_tv else 0, _info_origin_focus_v2082
                ))
            except Exception:
                pass

            # v2086: keep the actual v2079 animation-owner group hidden/reset
            # across the end of this synchronous onClick callback.  Releasing it
            # here would set-and-clear the reset flag before Kodi gets a render /
            # focus-processing boundary, so the completed parent-row slide state
            # could survive and reverse on the child Info.  v2123 keeps the
            # body focusable-but-transparent until native child entry focus is
            # confirmed, then the transition manager owns the hidden-reset/reveal.

            # v2123: a reused Info surface is not a completed child merely because
            # the parent's InlineActive/TVRowsReady properties were already true.
            # Mark the NEW title ready only here, after its metadata and TV rail
            # preparation is complete.  Transition release additionally waits for
            # native focus to reach the child's normal top-entry control.
            if _info_same_surface_new_title_v2087:
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Info.EntryTargetReadyV2123", "1")
                    _log("INFO_ENTRY_TARGET_READY_V2123 rating_key=%s is_tv=%d source_focus=%s" % (
                        li.getProperty("PlexKM.RatingKey") or "", 1 if _initial_is_tv else 0, _info_origin_focus_v2082
                    ))
                except Exception:
                    pass

            # v2137: all target metadata/cast/TV rows are now composed. Flip the
            # prepared universal fanart bank while the fade cover is still opaque.
            # The existing gate commit below then clears Cover; XML fades that cover
            # away to reveal the fully composed target. No slide and no Python wait.
            #
            # v2312 ROOT FIX for history Back sidebar mismatch:
            #   1) commit the PARENT target tint/fanart first,
            #   2) read the exact committed sidebar color from that same property family,
            #   3) publish HistoryBackSidebarColor,
            #   4) publish LayoutReady LAST.
            # Kodi evaluates these properties at the next render boundary, so body,
            # fanart and the physical sidebar can only appear with one target color.
            # This removes the old timing race where LayoutReady became visible
            # before the parent color was authoritative (or used a stale PUSH-time
            # color from the child/source surface).
            _history_target_bank_v2312 = ""
            self._show_info_step6(_entry_home_visual_v2511, _history_restore_v2085, _history_target_bank_v2312, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_origin_focus_v2082, _info_same_surface_new_title_v2087, _info_source_surface_hold_v2144, _initial_is_tv, _search_info_fast_path_v1773, _transition_token, li)
            # v2506: capture the immutable prepared target now, but do not compute
            # the content-authority fingerprint or write JSON before reveal. On
            # large libraries that synchronous fingerprint can exceed one second.
            # Reveal is therefore first; persistence continues on a registered
            # worker that never touches the Kodi ListItem/control objects.
            self._show_info_step7(_history_restore_v2085, _info_open_start_ms, _info_origin_focus_v2082, _info_same_surface_new_title_v2087, _info_v2626_cache, _info_v2626_media, _info_v2626_source, _initial_is_tv, _transition_token, li)
            # V2602 UHD: movie 720/1080/2160 grouping is also decoration.
            # The first frame is already interactive here, so local SQLite can
            # run off-thread without extending Info click latency.
            self._show_info_step8(_info_origin_focus_v2082, _initial_is_tv, li)
            if not _initial_is_tv:
                try:
                    if _info_actor_work_reentrant_v2082 and _info_global_busy_token_v1883:
                        self._info_hold_busy_until_cover_release_v2185(
                            _info_global_busy_token_v1883, _transition_token,
                            li.getProperty("PlexKM.RatingKey") or ""
                        )
                        _info_global_busy_token_v1883 = ""
                    else:
                        self._scene_busy_finish_v2482(_info_global_busy_token_v1883, reason="movie_info_visible")
                        _info_global_busy_token_v1883 = ""
                except Exception:
                    pass
            try:
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
            except Exception:
                pass
            _cast_wait_start_ms = self._now_ms()
            _cast_waited_ms = self._wait_for_active_cast_prewarm(
                li, li.getProperty("PlexKM.RatingKey") or "", max_wait_ms=0
            )
            try:
                _log("INFO_TIMING phase=cast_wait_done rating_key=%s elapsed=%dms step=%dms waited=%sms" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                    self._now_ms() - _cast_wait_start_ms, _cast_waited_ms
                ))
            except Exception:
                pass
            try:
                _log("CAST_PANEL_OPEN_FAST_SKIP reason=already_before_visible rating_key=%s cast1=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "",
                    _short_log_value(xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name"), 80)
                ))
            except Exception:
                pass

            if _initial_is_tv:
                try:
                    _tv_mode_ready = self._info_tv_current_mode_or_fallback()
                    if _tv_mode_ready in ("episodes", "seasons"):
                        self._info_tv_set_mode(
                            _tv_mode_ready, back_mode=self.getProperty("PlexKM.Info.TVBackMode") or ""
                        )
                    _tv_rows_empty = (
                        self.getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                        or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                    )
                    self._info_tv_defer_focus = False
                    if _history_restore_v2085:
                        _log("INFO_HISTORY_INTERMEDIATE_FOCUS_SKIP_V2344 rating_key=%s type=tv mode=%s keep_child_focus_until_exact_parent_focus=1" % (
                            li.getProperty("PlexKM.RatingKey") or "", _tv_mode_ready or ""
                        ))
                    elif not _tv_rows_empty:
                        # TV_INFO_EPISODE_FOCUS_OWNER_R20B:
                        # The earlier handoff was intentionally deferred while the
                        # inactive A/B bank published. At the real visible boundary
                        # explicitly focus the selected episode rail. A non-empty
                        # TV rail never substitutes the Play button.
                        _tv_visible_focus_r20b = int(self._info_tv_active_episode_control_id())
                        _tv_visible_focus_ok_r20b = self._info_tv_focus_panel(
                            _tv_visible_focus_r20b, reason="tv_rows_visible_atomic_r20b"
                        )
                        if _tv_visible_focus_ok_r20b:
                            self._last_focus_id = _tv_visible_focus_r20b
                        if not _tv_visible_focus_ok_r20b and _tv_visible_focus_r20b in (5712, 5713):
                            self._pkm_tv_focus_pending_vnext = {
                                "rating_key": str(li.getProperty("PlexKM.RatingKey") or ""),
                                "control": _tv_visible_focus_r20b, "attempts": 0,
                                "key_seq": int(getattr(self, "_pkm_user_key_seq_r78", 0) or 0),
                            }
                            self._pkm_tv_focus_retry_ping_vnext(delay_ms=75)
                            _log("INFO_TV_FOCUS_RETRY_QUEUED_VNEXT rating_key=%s target=%d" % (
                                li.getProperty("PlexKM.RatingKey") or "", _tv_visible_focus_r20b))
                        _log("INLINE_INFO_TV_VISIBLE_FOCUS_SET_R20B rating_key=%s mode=%s rows=%d target=%s actual=%s ok=%d episode_owner=1 same_surface=%d" % (
                            li.getProperty("PlexKM.RatingKey") or "", _tv_mode_ready or "",
                            len(getattr(self, "_info_tv_rows", []) or []),
                            _tv_visible_focus_r20b, self._safe_focus_id(),
                            1 if _tv_visible_focus_ok_r20b else 0,
                            1 if _info_same_surface_new_title_v2087 else 0
                        ))
                    else:
                        self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                        _log("INLINE_INFO_TV_FOCUS_SKIP reason=rows_empty rating_key=%s" % (
                            li.getProperty("PlexKM.RatingKey") or ""
                        ))
                except Exception:
                    try:
                        self._info_tv_defer_focus = False
                    except Exception:
                        pass
                    _log("INLINE_INFO_TV_ROWS_READY_FOCUS_FAILED_V1883 err=%s" % (
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                try:
                    _log("INFO_TIMING phase=tv_rows_visible_atomic_v1883 rating_key=%s elapsed=%dms rows=%d" % (
                        li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                        len(getattr(self, "_info_tv_rows", []) or [])
                    ))
                except Exception:
                    pass
                try:
                    if _info_actor_work_reentrant_v2082 and _info_global_busy_token_v1883:
                        self._info_hold_busy_until_cover_release_v2185(
                            _info_global_busy_token_v1883, _transition_token,
                            li.getProperty("PlexKM.RatingKey") or ""
                        )
                        _info_global_busy_token_v1883 = ""
                    else:
                        self._scene_busy_finish_v2482(_info_global_busy_token_v1883, reason="tv_info_atomic_visible")
                        _info_global_busy_token_v1883 = ""
                except Exception:
                    pass
                try:
                    self._schedule_info_tv_season_art_refresh_v1883()
                except Exception:
                    pass
            try:
                _cast1_now = xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name") or xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast1.Name") or ""
                if _cast1_now:
                    self._info_set_property_all("PlexKM.Info.CastReady", "1")
                    self.setProperty("PlexKM.Info.CastReady", "1")
                else:
                    self._info_clear_property_all("PlexKM.Info.CastReady")
                    self.clearProperty("PlexKM.Info.CastReady")
                _log("INFO_TIMING phase=cast_ready_property_set rating_key=%s elapsed=%dms display_cast1=%s ready=%s" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                    _short_log_value(_cast1_now, 80), "1" if _cast1_now else "0"
                ))
            except Exception:
                pass
            if not _initial_is_tv:
                try:
                    _log("INFO_TRANSITION phase=release_already_scheduled_movie rating_key=%s" % (li.getProperty("PlexKM.RatingKey") or ""))
                except Exception:
                    pass
            # v2383: reentrant source ownership is released after the target is
            # visible.  Related-work data may continue in the background, but the
            # visible top page remains frozen; only the still-offscreen actor-work
            # ControlLists may be bound later at native cast-row focus.
            try:
                if _info_actor_work_reentrant_v2082:
                    self._info_reentrant_open_in_progress_v2082 = False
                _log("INFO_POSTVISIBLE_WIDGET_POLICY_V2383 rating_key=%s actor_rows=background_data_then_safe_offscreen_bind visible_top_frozen=1" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            except Exception:
                pass
            # v1366: delayed movie focus block removed. Focus is already applied
            # immediately after InlineActive is set above.
        except Exception:
            _log("INLINE_INFO_OPEN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            try:
                self._scene_busy_finish_v2482(_info_global_busy_token_v1883, reason="info_open_failed")
                _info_global_busy_token_v1883 = ""
            except Exception:
                pass
            try:
                pkm_transition_manager.cancel_info_transition(self)
            except Exception:
                pass
            self._clear_inline_info(reason="open_failed")
            self._restore_wall_focus_after_info(rating_key=li.getProperty("PlexKM.RatingKey") or "")
        finally:
            try:
                if _info_global_busy_token_v1883:
                    self._scene_busy_finish_v2482(_info_global_busy_token_v1883, reason="info_open_finally")
            except Exception:
                pass
            try:
                if str(getattr(self, "_info_global_busy_token_v2145", "") or "") == str(_info_global_busy_token_v1883 or "") or not _info_global_busy_token_v1883:
                    self._info_global_busy_token_v2145 = ""
            except Exception:
                pass
            try:
                self._info_reentrant_open_in_progress_v2082 = False
            except Exception:
                pass
            self._info_dialog_active = False

    def _show_info_step1(self, li, now_ms):
        """Step 1 of _show_info (R76 split, moved verbatim)."""
        self._last_info_activate_ms = now_ms
        self._info_dialog_active = True
        try:
            self._info_tv_defer_focus = False
        except Exception:
            pass
        self._clear_home_trailer_preview(reason="open_inline_info", stop_player=True)
        try:
            _info_origin_focus_v2082 = int(self._safe_focus_id())
        except Exception:
            _info_origin_focus_v2082 = -1
        try:
            _info_inline_was_active_v2087 = (
                self.getProperty("PlexKM.Info.InlineActive") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
            )
        except Exception:
            _info_inline_was_active_v2087 = False
        _info_actor_work_reentrant_v2082 = bool(
            _info_inline_was_active_v2087
            and li is None
            and _info_origin_focus_v2082 in INFO_ACTOR_WORK_ROW_IDS_V2082
        )
        try:
            self._info_reentrant_open_in_progress_v2082 = bool(_info_actor_work_reentrant_v2082)
        except Exception:
            pass
        # v2087: one entry contract for every NEW title Info.  Home -> Info starts
        # with InlineActive=0 and needs no reset.  Info -> another title keeps the
        # same WindowXML, so the previous v2079 scroll transform must be retired
        # before the target body is published.  EntrySwapV2087 is global-only on
        # purpose: pkm_transition_manager releases it after its existing two-frame
        # target-bind barrier, avoiding another Python timer/focus retry owner.
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapV2087")
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.EntrySwapStartMsV2152")
            xbmcgui.Window(10000).clearProperty("PlexKM.Info.SceneFadeResetOwnerV2153")
            for _entry_key_v2123 in (
                "PlexKM.Info.ChildFreshEntryV2123",
                "PlexKM.Info.EntryTargetRatingKeyV2123",
                "PlexKM.Info.EntryTargetReadyV2123",
                "PlexKM.Info.EntryTargetFocusReadyV2123",
                "PlexKM.Info.EntryResetHideV2123",
                "PlexKM.Info.ActorPrecomposeV2185",
                "PlexKM.Info.ActorSourceFocusV2190",
                "PlexKM.Info.ActorSourceHadSeasonCardsV2306",
            ):
                xbmcgui.Window(10000).clearProperty(_entry_key_v2123)
            self._info_clear_property_all("PlexKM.Info.ReentrantSwapV2083")
            self._info_clear_property_all("PlexKM.Info.ReentrantScrollResetV2086")
            self._info_clear_property_all("PlexKM.Info.DirectSwapV2086")
        except Exception:
            pass

        # v1772: preserve an explicitly supplied ListItem. Search results live in
        # controls 4200/4000, not in the Home/section wall controls inspected by
        # _focused_wall_item(). v1771 successfully received the click and selected
        # rating key, but _show_info() immediately discarded that item here and
        # returned before INLINE_INFO_OPEN. Only resolve from the focused Home wall
        # when the caller did not provide an item.
        _info_item_source_v1772 = "caller" if li is not None else "focused_wall"
        if li is None:
            li = self._focused_wall_item()
        return _info_actor_work_reentrant_v2082, _info_inline_was_active_v2087, _info_item_source_v1772, _info_origin_focus_v2082, li

    def _show_info_step2(self, _history_restore_v2085, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_origin_focus_v2082, _info_persistent_hit_v2467, li):
        """Step 2 of _show_info (R76 split, moved verbatim). Logs: INLINE_SEARCH_INFO_FAST_PATH_V1773, HOME_INFO_SEARCH_PREWARM_PURGE_V1785, INFO_SPINNER_POLICY_RESTORE_V2710, INFO_HISTORY_BUSY_POLICY_V2505."""
        _info_origin_focus_v1773 = self._safe_focus_id()
        _search_info_fast_path_v1773 = (
            _info_item_source_v1772 == "caller"
            and _info_origin_focus_v1773 in SEARCH_RESULT_IDS
        )
        _log("INLINE_SEARCH_INFO_FAST_PATH_V1773 enabled=%s focus=%s rating_key=%s" % (
            "1" if _search_info_fast_path_v1773 else "0",
            _info_origin_focus_v1773,
            li.getProperty("PlexKM.RatingKey") or "",
        ))
        # v1785: Search prewarm must never delay normal Home/section Info.
        # Invalidate and purge queued Search-only jobs before entering a non-search
        # Info page.  The established Home Info code path itself is unchanged.
        if not _search_info_fast_path_v1773:
            try:
                self._search_cast_prewarm_token_v1781 = "home-info-cancel:%d" % self._now_ms()
                with self._info_cast_prewarm_lock:
                    _q = list(getattr(self, "_info_cast_prewarm_queue", []) or [])
                    self._info_cast_prewarm_queue = [
                        _x for _x in _q
                        if not str((_x or {}).get("reason") or "").startswith("search_")
                    ]
                _log("HOME_INFO_SEARCH_PREWARM_PURGE_V1785 rating_key=%s" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            except Exception:
                pass
        try:
            li.setProperty("PlexKM.Info.SearchOriginV1777", "1" if _search_info_fast_path_v1773 else "0")
        except Exception:
            pass
        try:
            _busy_type_v1883 = (li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "item").lower()
            # V2710: restore the central V2482/V2492 scene-transition policy.
            # Info must not override the global 1000ms grace period.  The source
            # surface remains visible during the grace interval; sub-second
            # transitions complete by atomic reveal without a spinner flash.
            _info_global_busy_token_v1883 = self._scene_busy_arm_v2482(
                reason="info_open:%s:%s" % (_busy_type_v1883, li.getProperty("PlexKM.RatingKey") or ""),
                scope="info", owner=li.getProperty("PlexKM.RatingKey") or "",
                replace_scope=True, threshold_ms=1000,
            )
            _log("INFO_SPINNER_POLICY_RESTORE_V2710 rating_key=%s type=%s threshold_ms=1000 central_policy=V2482_V2492 source_hold=1 short_wait_spinner=0 fast_reveal_cancels=1" % (
                li.getProperty("PlexKM.RatingKey") or "", _busy_type_v1883
            ))
            if _history_restore_v2085:
                _log("INFO_HISTORY_BUSY_POLICY_V2505 rating_key=%s spinner_threshold_ms=750 safe_rebuild=1 source_surface_hold=1" % (li.getProperty("PlexKM.RatingKey") or ""))
            elif _info_persistent_hit_v2467:
                _log("INFO_PREPARED_CACHE_FAST_PATH_V2505 rating_key=%s spinner_threshold_ms=750 prepared=1 source_surface_hold=1 slow_fallback=1" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            # v2482: no helper is allowed to promote this token early.  The
            # centralized delayed gate owns the only scene-spinner reveal point.
            self._info_global_busy_token_v2145 = _info_global_busy_token_v1883
            # v2185: actor-work tail chaining deliberately shows the spinner from
            # the click itself while the CURRENT completed Info remains visible.
            # Target metadata/art/cast/version data is staged first; the visual
            # swap is not armed until that precompose phase has finished.
            if _info_actor_work_reentrant_v2082:
                _win_v2190 = xbmcgui.Window(10000)
                _win_v2190.setProperty("PlexKM.Info.ActorPrecomposeV2185", "1")
                _win_v2190.setProperty("PlexKM.Info.ActorSourceFocusV2190", str(_info_origin_focus_v2082 or 0))
                _win_v2190.setProperty(
                    "PlexKM.Info.ActorSourceHadSeasonCardsV2306",
                    "1" if _win_v2190.getProperty("PlexKM.Info.HasSeasonCards") == "1" else "0"
                )
                # v2505: actor-work entry follows the same 750ms Info feedback
                # policy while keeping the completed parent Info visible.
                _log("INFO_ACTOR_PRECOMPOSE_SPINNER_POLICY_V2505 rating_key=%s source_focus=%s previous_info_visible=1 immediate=0 global_info_delay_ms=%d final_reveal=full_page" % (
                    li.getProperty("PlexKM.RatingKey") or "", _info_origin_focus_v2082,
                    750
                ))
            else:
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.ActorPrecomposeV2185")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.ActorSourceFocusV2190")
                xbmcgui.Window(10000).clearProperty("PlexKM.Info.ActorSourceHadSeasonCardsV2306")
        except Exception:
            _info_global_busy_token_v1883 = ""
            try:
                self._info_global_busy_token_v2145 = ""
            except Exception:
                pass
        try:
            self._remember_focus_position()
            # Snapshot the parent before child Info overwrites _inline_info_item
            # or the top-level origin.  Only the actor-work reentrant path pushes.
            if _info_actor_work_reentrant_v2082 and not _history_restore_v2085:
                self._inline_info_history_push_v2085(
                    child_li=li, source_control=_info_origin_focus_v2082
                )
            self._remember_inline_info_origin(li)
            self._last_info_rating_key = li.getProperty("PlexKM.RatingKey") or ""
            self._inline_info_item = li
        except Exception:
            pass
        return _info_global_busy_token_v1883, _search_info_fast_path_v1773

    def _show_info_step3(self, _history_restore_v2085, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_open_start_ms, _initial_is_tv, li):
        """Step 3 of _show_info (R76 split, moved verbatim). Logs: CAST_PANEL_RESET_SKIP_V2309, CAST_PANEL_RESET_DEFER_V2083, INFO_LOCAL_DB_SKIP_V2510, INFO_TV_FULL_PAGE_META_READY_V2332."""
        try:
            if _history_restore_v2085:
                _log("CAST_PANEL_RESET_SKIP_V2309 rating_key=%s reason=history_back_keep_child_surface_until_parent_commit" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            elif _info_actor_work_reentrant_v2082:
                _log("CAST_PANEL_RESET_DEFER_V2083 rating_key=%s reason=preserve_previous_info_until_cover" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            else:
                self._reset_info_cast_panel(reason="open_%s" % (li.getProperty("PlexKM.RatingKey") or ""))
        except Exception:
            pass

        if _initial_is_tv:
            try:
                _db_start_ms = self._now_ms()
                _tv_complete_before = self._li_info_complete_for_inline(li)
                _tv_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                _db_ok = bool(_tv_complete_before and _tv_art_ready)
                _db_source_v2510 = "prepared_cache" if _db_ok else ""
                if (not _db_ok) and _info_item_source_v1772 == "focused_wall":
                    _db_ok = bool(self._info_try_home_meta_memory_v2510(li, reason="tv_before_publish"))
                    _tv_complete_before = self._li_info_complete_for_inline(li)
                    _tv_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    if _db_ok:
                        _db_source_v2510 = "home_meta_memory"
                if not _db_ok:
                    _db_ok = self._apply_local_db_info_to_li(li, reason="tv_before_publish", update_visual=False)
                    _tv_complete_before = self._li_info_complete_for_inline(li)
                    _tv_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    _db_source_v2510 = "local_db"
                else:
                    _log("INFO_LOCAL_DB_SKIP_V2510 rating_key=%s type=tv source=%s elapsed_ms=%d complete=%d art=%d" % (
                        li.getProperty("PlexKM.RatingKey") or "", _db_source_v2510 or "prepared",
                        self._now_ms() - _db_start_ms, 1 if _tv_complete_before else 0, 1 if _tv_art_ready else 0
                    ))
                _tv_needs_repair = (not _tv_complete_before) or (not _tv_art_ready)
                if _tv_needs_repair:
                    # v2332: visible-page data may not be repaired after reveal.
                    # Resolve sparse TV metadata now while the previous completed
                    # page remains visible.  The shared Info busy broker keeps its
                    # centralized spinner policy; a slow Plex fallback therefore
                    # shows the ring over the source page, never over a half page.
                    _repair_t0_v2332 = self._now_ms()
                    try:
                        li.setProperty("PlexKM.InfoPlexDirectRepairAttemptedRatingKey", li.getProperty("PlexKM.RatingKey") or "")
                    except Exception:
                        pass
                    _repair_ok_v2332 = self._apply_plex_metadata_repair_to_li(
                        li, reason="tv_full_page_before_visible_v2332",
                        update_visual=False, timeout=1.5
                    )
                    _tv_complete_before = self._li_info_complete_for_inline(li)
                    _tv_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    _log("INFO_TV_FULL_PAGE_META_READY_V2332 rating_key=%s season=%s episode=%s show_key=%s repair=%d complete=%d art=%d elapsed_ms=%d visible_mutation=0" % (
                        li.getProperty("PlexKM.RatingKey") or "",
                        li.getProperty("PlexKM.Season") or "",
                        li.getProperty("PlexKM.Episode") or "",
                        li.getProperty("PlexKM.GrandparentRatingKey") or "",
                        1 if _repair_ok_v2332 else 0, 1 if _tv_complete_before else 0,
                        1 if _tv_art_ready else 0, self._now_ms() - _repair_t0_v2332
                    ))
                _log("INFO_TIMING phase=tv_local_db_before_publish rating_key=%s elapsed=%dms step=%dms ok=%s complete=%s art=%s cast_thumb_ready=%s" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                    self._now_ms() - _db_start_ms, "1" if _db_ok else "0",
                    "1" if _tv_complete_before else "0",
                    "1" if _tv_art_ready else "0",
                    "1" if self._li_cast_thumb_ready_for_info(li) else "0"
                ))
            except Exception:
                _log("INFO_TIMING phase=tv_local_db_before_publish_failed rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey"), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        else:
            try:
                _db_start_ms = self._now_ms()
                _movie_complete_before = self._li_info_complete_for_inline(li)
                _movie_detail_missing = self._li_movie_detail_missing_for_info(li)
                _movie_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                _db_ok = bool(_movie_complete_before and (not _movie_detail_missing) and _movie_art_ready)
                _db_source_v2510 = "prepared_cache" if _db_ok else ""
                if (not _db_ok) and _info_item_source_v1772 == "focused_wall":
                    _db_ok = bool(self._info_try_home_meta_memory_v2510(li, reason="movie_before_publish"))
                    _movie_complete_before = self._li_info_complete_for_inline(li)
                    _movie_detail_missing = self._li_movie_detail_missing_for_info(li)
                    _movie_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    if _db_ok:
                        _db_source_v2510 = "home_meta_memory"
                if not _db_ok:
                    _db_ok = self._apply_local_db_info_to_li(li, reason="movie_before_publish", update_visual=False)
                    _movie_complete_before = self._li_info_complete_for_inline(li)
                    _movie_detail_missing = self._li_movie_detail_missing_for_info(li)
                    _movie_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    _db_source_v2510 = "local_db"
                else:
                    _log("INFO_LOCAL_DB_SKIP_V2510 rating_key=%s type=movie source=%s elapsed_ms=%d complete=%d detail_missing=%d art=%d" % (
                        li.getProperty("PlexKM.RatingKey") or "", _db_source_v2510 or "prepared",
                        self._now_ms() - _db_start_ms, 1 if _movie_complete_before else 0,
                        1 if _movie_detail_missing else 0, 1 if _movie_art_ready else 0
                    ))
                _movie_needs_repair = _movie_detail_missing or (not _movie_complete_before) or (not _movie_art_ready)
                if _movie_needs_repair:
                    # v2332 PKM full-page rule: metadata that can affect the
                    # visible target is resolved before the page owns a frame.
                    # The source page remains intact; the shared delayed spinner
                    # is the only wait UI for a genuinely slow repair.
                    _repair_t0_v2332 = self._now_ms()
                    try:
                        li.setProperty("PlexKM.InfoPlexDirectRepairAttemptedRatingKey", li.getProperty("PlexKM.RatingKey") or "")
                    except Exception:
                        pass
                    _repair_ok_v2332 = self._apply_plex_metadata_repair_to_li(
                        li, reason="movie_full_page_before_visible_v2332",
                        update_visual=False, timeout=1.5
                    )
                    _movie_complete_before = self._li_info_complete_for_inline(li)
                    _movie_detail_missing = self._li_movie_detail_missing_for_info(li)
                    _movie_art_ready = bool(li.getProperty("PlexKM.Art") or li.getArt("fanart"))
                    _log("INFO_MOVIE_FULL_PAGE_META_READY_V2332 rating_key=%s repair=%d complete=%d detail_missing=%d art=%d elapsed_ms=%d visible_mutation=0" % (
                        li.getProperty("PlexKM.RatingKey") or "",
                        1 if _repair_ok_v2332 else 0, 1 if _movie_complete_before else 0,
                        1 if _movie_detail_missing else 0, 1 if _movie_art_ready else 0,
                        self._now_ms() - _repair_t0_v2332
                    ))
                _log("INFO_TIMING phase=movie_local_db_before_publish rating_key=%s elapsed=%dms step=%dms ok=%s complete=%s detail_missing=%s art=%s cast1=%s cast_thumb_ready=%s" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                    self._now_ms() - _db_start_ms, "1" if _db_ok else "0",
                    "1" if _movie_complete_before else "0",
                    "1" if _movie_detail_missing else "0",
                    "1" if _movie_art_ready else "0",
                    _short_log_value(li.getProperty("PlexKM.Cast1.Name"), 80),
                    "1" if self._li_cast_thumb_ready_for_info(li) else "0"
                ))
            except Exception:
                _log("INFO_TIMING phase=movie_local_db_before_publish_failed rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey"), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            _log("INFO_TIMING phase=fast_initial_publish rating_key=%s elapsed=%dms" % (
                li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms
            ))

    def _show_info_step4(self, _info_actor_work_reentrant_v2082, _info_defer_cover_arm_v2143, _info_open_start_ms, _info_origin_focus_v2082, _initial_is_tv, _search_info_fast_path_v1773, li):
        """Step 4 of _show_info (R76 split, moved verbatim). Logs: INFO_REENTRANT_PARENT_HOLD_V2143, INFO_REENTRANT_SWAP_COMPAT_V2087, INFO_REENTRANT_SWAP_COMPAT_FAILED_V2087, INFO_CAST_LOCAL_ONLY_BEFORE_PUBLISH_FAILED_V1338."""
        if _info_actor_work_reentrant_v2082:
            try:
                if _info_defer_cover_arm_v2143:
                    # v2143: do not clear the visible parent's cast panel while
                    # the target is still being staged behind it.  The panel is
                    # reset atomically at the late Cover/EntrySwap boundary below.
                    _log("INFO_REENTRANT_PARENT_HOLD_V2143 rating_key=%s old_focus=%s is_tv=%d entry_lock=0 action=keep_parent_cast_until_final_publish" % (
                        li.getProperty("PlexKM.RatingKey") or "", _info_origin_focus_v2082, 1 if _initial_is_tv else 0
                    ))
                else:
                    # v2087: the common EntrySwap lock was armed before any target
                    # metadata mutation. Actor-work keeps only its cast-list lifetime
                    # protection here; it no longer owns a second visual transition.
                    self._reset_info_cast_panel(reason="open_reentrant_after_cover_v2087_%s" % (li.getProperty("PlexKM.RatingKey") or ""))
                    _log("INFO_REENTRANT_SWAP_COMPAT_V2087 rating_key=%s old_focus=%s is_tv=%d entry_lock=%s action=cast_lifetime_only" % (
                        li.getProperty("PlexKM.RatingKey") or "", _info_origin_focus_v2082, 1 if _initial_is_tv else 0,
                        xbmcgui.Window(10000).getProperty("PlexKM.Info.EntrySwapV2087") or "0"
                    ))
            except Exception:
                _log("INFO_REENTRANT_SWAP_COMPAT_FAILED_V2087 rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        try:
            self._apply_info_cast_prewarm_cache_to_li(li, reason="before_info_publish_v1336")
        except Exception:
            pass
        # v1338: Info click path must not start or wait for cast downloads.
        # Cast cache is a prewarm cache: Home/section/wall rendered items are
        # prepared right after row paint, and Info only reads already prepared
        # local PNG paths.  No click-time gate and no after-visible pop-in.
        try:
            _rk_gate_v1338 = li.getProperty("PlexKM.RatingKey") or ""
            _applied_v1338 = self._apply_info_cast_prewarm_cache_to_li(li, reason="before_info_publish_local_only_v1338")
            _log("INFO_TIMING phase=cast_local_only_before_publish_v1338 rating_key=%s elapsed=%dms applied=%s ready=%s" % (
                _rk_gate_v1338, self._now_ms() - _info_open_start_ms, _applied_v1338,
                "1" if self._li_cast_thumb_ready_for_info(li) else "0"
            ))
        except Exception:
            _log("INFO_CAST_LOCAL_ONLY_BEFORE_PUBLISH_FAILED_V1338 rating_key=%s err=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        # v1334 root fix: before any Info properties are published, make the
        # active ListItem use one cast source policy for movies, shows, and
        # episodes.  If the local DB says cast=0 while Plex Role/thumb data
        # exists, direct Plex metadata repairs the ListItem first; the later
        # snapshot then builds stable local circular images from that data.
        try:
            _cast_source_start_ms = self._now_ms()
            # v1739: actor photos are a first-paint requirement.  Local DB
            # remains the fast path; only when names/thumbs are incomplete do
            # one bounded active-item Plex metadata repair before reveal.
            # v1774: Search fast-open must skip only actor-image download/crop,
            # not the lightweight Plex metadata fetch that supplies cast names.
            # v1773 disabled network here entirely. When the local DB was briefly
            # locked, the first Info open published zero cast names; the second
            # open worked only because the DB lock had cleared. Keep the immediate
            # shell and bounded metadata repair, while the expensive circular PNG
            # preparation remains skipped below for search-origin Info.
            _child_local_only_v2132 = bool(_info_actor_work_reentrant_v2082)
            _cast_reason_v2132 = (
                "actor_work_child_required_cast_v2146" if _child_local_only_v2132
                else ("search_required_cast_v2146" if _search_info_fast_path_v1773 else "before_first_publish_required_cast_v2146")
            )
            _info_cast_network_v2601 = not self._uhd_kpi_proxy_v2605()
            self._ensure_info_plex_cast_source_before_publish(
                li,
                reason=_cast_reason_v2132,
                timeout=(0.0 if not _info_cast_network_v2601 else 1.5),
                allow_network=_info_cast_network_v2601,
            )
            if not _info_cast_network_v2601:
                _log("INFO_CAST_SOURCE_LOCAL_ONLY_V2605 rating_key=%s names=%d real=%d network_before_visible=0" % (
                    li.getProperty("PlexKM.RatingKey") or "",
                    self._li_cast_thumb_stats_for_info(li)[0],
                    self._li_cast_thumb_stats_for_info(li)[1],
                ))
            if _child_local_only_v2132:
                _log("INFO_ACTOR_CHILD_PREVISIBLE_CAST_REQUIRED_V2146 rating_key=%s local_names=%d local_real=%d source_surface_held=1" % (
                    li.getProperty("PlexKM.RatingKey") or "",
                    self._li_cast_thumb_stats_for_info(li)[0],
                    self._li_cast_thumb_stats_for_info(li)[1],
                ))
            _log("INFO_TIMING phase=cast_source_before_publish_done_v1333 rating_key=%s elapsed=%dms step=%dms names=%d real=%d" % (
                li.getProperty("PlexKM.RatingKey") or "",
                self._now_ms() - _info_open_start_ms,
                self._now_ms() - _cast_source_start_ms,
                self._li_cast_thumb_stats_for_info(li)[0],
                self._li_cast_thumb_stats_for_info(li)[1],
            ))
            # V2616 desktop reference: as soon as cast identity is authoritative,
            # give slot 1 actor metadata a background head start.  This overlaps
            # the rest of Info composition but never blocks Info reveal.
            if not self._uhd_kpi_proxy_v2605():
                _v2616_actor0 = str(li.getProperty("PlexKM.Cast1.Name") or "").strip()
                _v2616_actor0_thumb = str(li.getProperty("PlexKM.Cast1.OriginalThumb") or li.getProperty("PlexKM.Cast1.Thumb") or "").strip()
                if _v2616_actor0:
                    _v2616_actor0_arm = self._schedule_actor_profile_item_prewarm_v2481(
                        _v2616_actor0, source_rk=str(li.getProperty("PlexKM.RatingKey") or "").strip(),
                        fallback_thumb=_v2616_actor0_thumb, reason="info_cast_identity_ready_v2616", settle_ms_v2526=0
                    )
                    _log("ACTOR_PROFILE_INFO_IDENTITY_PREWARM_V2616 actor=%s source=%s armed=%d previsible_background=1 info_wait=0" % (
                        _short_log_value(_v2616_actor0,80), li.getProperty("PlexKM.RatingKey") or "", 1 if _v2616_actor0_arm else 0
                    ))
        except Exception:
            _log("INFO_CAST_UNIFIED_BEFORE_PUBLISH_FAILED_V1333 rating_key=%s err=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        # v2146: stable-focus prewarm remains useful before the click, but the
        # click path itself no longer queues a second background copy of the
        # same actor work.  The selected Info snapshot below owns any still
        # missing portraits synchronously while the source surface is held.
        try:
            _cast_gate_rk_v2146 = li.getProperty("PlexKM.RatingKey") or ""
            _cast_gate_applied_v2146 = self._apply_info_cast_prewarm_cache_to_li(
                li, reason="info_click_cached_apply_v2146"
            )
            _log("INFO_CAST_CLICK_CACHE_APPLY_V2146 rating_key=%s applied=%s local=%d action=first_paint_snapshot_owns_missing_portraits" % (
                _cast_gate_rk_v2146, _cast_gate_applied_v2146, self._count_cached_cast_locals_for_item(li)
            ))
        except Exception:
            _log("INFO_CAST_CLICK_CACHE_APPLY_FAILED_V2146 rating_key=%s err=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _show_info_step5(self, _initial_is_tv, _search_info_fast_path_v1773, li):
        """Step 5 of _show_info (R76 split, moved verbatim). Logs: INFO_CAST_PREVISIBLE_SNAPSHOT_BEGIN_V1739, INFO_CAST_ATOMIC_METADATA_GATE_V2609, INFO_CAST_PC_REMOTE_NO_LEAD_WAIT_V2616, INFO_CAST_FIRST_FRAME_ATOMIC_V2609."""
        try:
            _pre_names, _pre_real = self._li_cast_thumb_stats_for_info(li)
        except Exception:
            _pre_names, _pre_real = (0, 0)
        # v2145: do not reveal Info and fill actor photos later, but also do
        # not block the page on remote portrait transfer. Resolve the first
        # paint once from existing local circles or stable placeholders;
        # background prewarm is cache-only for the next visit.
        try:
            _log("INFO_CAST_PREVISIBLE_SNAPSHOT_BEGIN_V1739 rating_key=%s type=%s names=%d real=%d action=local_circles_before_reveal" % (
                li.getProperty("PlexKM.RatingKey") or "",
                li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "",
                _pre_names, _pre_real
            ))
        except Exception:
            pass
        # v2145: every Info origin, including Search, resolves the visible
        # cast rail to already-local circles or stable placeholders before
        # reveal. No current-page actor download/pop-in is allowed.
        _cast_final_download_v2601 = False  # V2616: direct Role URL / cached local, no click-time download gate
        if _cast_final_download_v2601:
            self._kpi_info_pre_net_v2605 = 1
        else:
            # v2609: join an already-running focus prime briefly while the
            # source surface is still visible, then perform only a bounded
            # Role-metadata request if the lead portraits are still unknown.
            _rk_cast_v2609 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            self._info_atomic_asset_join_v2609(_rk_cast_v2609, want_tv=_initial_is_tv, budget_ms=80)
            try:
                self._apply_info_cast_remote_prime_v2608(li, reason="previsible_join_v2609")
                _n_v2609, _r_v2609 = self._li_cast_thumb_stats_for_info(li)
            except Exception:
                _n_v2609, _r_v2609 = (0, 0)
            _need_v2609 = min(3, int(_n_v2609 or 0))
            if _need_v2609 > 0 and int(_r_v2609 or 0) < _need_v2609:
                _cast_data_v2609 = {
                    "rating_key": _rk_cast_v2609,
                    "type": str(li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or ""),
                    "parent_rating_key": str(li.getProperty("PlexKM.ParentRatingKey") or ""),
                    "grandparent_rating_key": str(li.getProperty("PlexKM.GrandparentRatingKey") or ""),
                    "section_id": str(li.getProperty("PlexKM.SectionId") or ""),
                }
                _prime_t0_v2609 = self._now_ms()
                _remote_v2609 = self._info_cast_remote_prime_v2608(
                    _cast_data_v2609, reason="info_atomic_previsible_v2609", timeout=0.12
                )
                self._apply_info_cast_remote_prime_v2608(li, reason="info_atomic_previsible_v2609")
                # Start the 3-lead local texture prime now as a safety net;
                # do not wait beyond the global 80ms join budget.
                if int((_remote_v2609 or {}).get("ready") or 0) > 0:
                    _lead_ev_v2609 = threading.Event()
                    with self._info_atomic_asset_lock_v2609:
                        self._info_cast_lead_events_v2609[_rk_cast_v2609] = _lead_ev_v2609
                    _PKMHomeThreadV2151(
                        target=lambda: self._info_cast_lead_texture_prime_v2609(
                            _rk_cast_v2609, dict(_remote_v2609), _lead_ev_v2609, reason="fast_click_v2609"
                        ),
                        name="PKMInfoCastLeadClickV2609", daemon=True
                    ).start()
                    # Give the three small w185 lead portraits one short chance
                    # to become local while the source surface is still held.
                    # This is the cold fast-click path only; normal focus prewarm
                    # has already finished before the click.
                    if self._uhd_kpi_proxy_v2605():
                        _lead_ev_v2609.wait(0.09)
                    else:
                        _log("INFO_CAST_PC_REMOTE_NO_LEAD_WAIT_V2616 rating_key=%s wait_ms=0 direct_role_url=1" % _rk_cast_v2609)
                    self._apply_info_cast_remote_prime_v2608(li, reason="fast_click_lead_join_v2609")
                _log("INFO_CAST_ATOMIC_METADATA_GATE_V2609 rating_key=%s request_ms=%d bounded_ms=120 lead_required=%d" % (
                    _rk_cast_v2609, self._now_ms() - _prime_t0_v2609, _need_v2609
                ))
        self._prepare_info_cast_display_snapshot(li, allow_download=_cast_final_download_v2601)
        if not _cast_final_download_v2601:
            try:
                _fn_v2609, _fr_v2609 = self._li_cast_thumb_stats_for_info(li)
            except Exception:
                _fn_v2609, _fr_v2609 = (0, 0)
            _fn_local, _fr_local, _fp_remote, _fm_missing, _fu_unknown = self._info_cast_atomic_stats_v2629(li)
            _assets_complete = bool(_fn_local > 0 and (_fr_local + _fm_missing) >= _fn_local and not (_fp_remote or _fu_unknown))
            _log("INFO_CAST_FIRST_FRAME_ATOMIC_V2609 rating_key=%s names=%d real=%d lead_required=%d metadata_ready_before_reveal=%d local_download_gate=0 assets_ready=%d actual_local=%d remote_pending=%d unknown=%d gpu_texture_ready=unknown" % (
                li.getProperty("PlexKM.RatingKey") or "", int(_fn_v2609 or 0), int(_fr_v2609 or 0),
                min(3, int(_fn_v2609 or 0)), 1 if int(_fr_v2609 or 0) >= min(3, int(_fn_v2609 or 0)) else 0,
                1 if _assets_complete else 0, _fr_local, _fp_remote, _fu_unknown
            ))
        if _search_info_fast_path_v1773:
            _log("INFO_SEARCH_CAST_SNAPSHOT_LOCAL_ONLY_V2145 rating_key=%s network_wait=0" % (
                li.getProperty("PlexKM.RatingKey") or ""
            ))
        if _initial_is_tv:
            _log("INFO_TV_CAST_MOVIE_PARITY_V2066 rating_key=%s action=local_circle_or_placeholder_snapshot_before_reveal" % (
                li.getProperty("PlexKM.RatingKey") or ""
            ))
        try:
            _cast_atomic_ready_v2629 = self._info_cast_atomic_panel_gate_v2629(li, reason="before_visible")
            if _cast_atomic_ready_v2629:
                _fast_panel_count = self._populate_info_cast_panel(cast_items=None, reason="before_visible_v2629_atomic_ready")
            else:
                _fast_panel_count = 0
            _log("CAST_PANEL_BEFORE_VISIBLE rating_key=%s panel=%s cast1=%s atomic_ready_v2629=%d" % (
                li.getProperty("PlexKM.RatingKey") or "", _fast_panel_count,
                _short_log_value(xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name"), 80),
                1 if _cast_atomic_ready_v2629 else 0
            ))
        except Exception:
            _log("CAST_PANEL_BEFORE_VISIBLE_FAILED rating_key=%s err=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _show_info_step6(self, _entry_home_visual_v2511, _history_restore_v2085, _history_target_bank_v2312, _info_actor_work_reentrant_v2082, _info_item_source_v1772, _info_origin_focus_v2082, _info_same_surface_new_title_v2087, _info_source_surface_hold_v2144, _initial_is_tv, _search_info_fast_path_v1773, _transition_token, li):
        """Step 6 of _show_info (R76 split, moved verbatim). Logs: INFO_HISTORY_LAYOUT_READY_V2312, INFO_SOURCE_READY_DIRECT_COMMIT_V2144, INFO_TRANSITION_GATE_COMMIT_V1883, INFO_WIDGET_REBUILD_REQUEST_FAILED_V2082."""
        try:
            _history_target_bank_v2312 = self._info_dynamic_bg_commit_v2140(
                li, reason="target_complete_before_inline_commit"
            ) or ""
            self._info_art_commit_v2136(li, reason="target_complete_before_inline_commit")
        except Exception:
            pass
        # v2511: dynamic Info tint commit above may recompute the same target
        # hue.  For a Home-origin exact-ratingKey entry, force the synopsis
        # card to the exact color that was already on screen for the ownership
        # switch.  Only the card color is latched; Info background/fanart remain
        # under their existing v2140/v2136 owners.
        try:
            self._info_home_visual_continuity_commit_v2511(
                matched=bool(_entry_home_visual_v2511),
                reason="after_target_tint_before_inline"
            )
        except Exception:
            pass
        if _history_restore_v2085:
            try:
                _hist_win_ready_v2310 = xbmcgui.Window(10000)
                if _hist_win_ready_v2310.getProperty("PlexKM.Info.HistoryBackActiveV2310") == "1":
                    _committed_sidebar_v2312 = (
                        _hist_win_ready_v2310.getProperty("PlexKM.Info.DynamicBgSideOpaqueColor")
                        or _hist_win_ready_v2310.getProperty("PlexKM.Info.DynamicBgColor")
                        or self._home_bg_default
                    )
                    _committed_sidebar_v2312 = self._normalize_argb_color(
                        _committed_sidebar_v2312
                    ) or self._home_bg_default
                    _hist_win_ready_v2310.setProperty(
                        "PlexKM.Info.HistoryBackSidebarColorV2310",
                        _committed_sidebar_v2312
                    )
                    # LayoutReady MUST be the last write in this transaction.
                    _hist_win_ready_v2310.setProperty(
                        "PlexKM.Info.HistoryBackLayoutReadyV2310", "1"
                    )
                    _log("INFO_HISTORY_LAYOUT_READY_V2312 rating_key=%s focus=%s had_seasons=%s sidebar=%s bank=%s stage=after_target_color_art_commit ready_last=1 stale_push_color=0" % (
                        li.getProperty("PlexKM.RatingKey") or "",
                        _hist_win_ready_v2310.getProperty("PlexKM.Info.HistoryBackReturnFocusV2310") or "0",
                        _hist_win_ready_v2310.getProperty("PlexKM.Info.HistoryBackHadSeasonCardsV2310") or "0",
                        _committed_sidebar_v2312,
                        _history_target_bank_v2312 or ""
                    ))
            except Exception:
                pass

        # v2445: fresh/source entries reach this point with Cover still 0.
        # The source posters/fanart therefore remain fully visible throughout
        # preparation (and under any delayed spinner). InlineActive below is
        # the single visual ownership switch. XML 5599 now reveals at 100%
        # opacity in the same render boundary (Visible time=0), so no 0->100
        # opacity ramp can expose a brightness/blank frame between Home and Info.
        try:
            if _info_source_surface_hold_v2144:
                _log("INFO_SOURCE_READY_DIRECT_COMMIT_V2144 rating_key=%s token=%s cover=0 target_complete=1 spinner_surface_was_source=1 next=atomic_swap_v2445" % (
                    li.getProperty("PlexKM.RatingKey") or "", _transition_token
                ))
        except Exception:
            pass

        # Clear the logical gate while Home is still visible, then publish
        # InlineActive.  This ordering makes the surface swap atomic instead
        # of briefly hiding both the old and new surfaces.
        try:
            _gate_ok_v1883 = pkm_transition_manager.commit_info_transition_gate(
                self, _transition_token, li.getProperty("PlexKM.RatingKey") or ""
            )
            _gate_cover_after_v2158 = xbmcgui.Window(10000).getProperty("PlexKM.Info.Transition.Cover") or "0"
            _log("INFO_TRANSITION_GATE_COMMIT_V1883 rating_key=%s ok=%d previous_surface=1 cover_after=%s v2158_same_surface_hold=%d" % (
                li.getProperty("PlexKM.RatingKey") or "", 1 if _gate_ok_v1883 else 0,
                _gate_cover_after_v2158,
                1 if (_info_same_surface_new_title_v2087 and _gate_cover_after_v2158 == "1") else 0
            ))
        except Exception:
            pass
        if _info_actor_work_reentrant_v2082:
            try:
                self._info_widget_rebuild_request_v2082(
                    li.getProperty("PlexKM.RatingKey") or "",
                    actor_hint=li.getProperty("PlexKM.Cast1.Name") or xbmcgui.Window(10000).getProperty("PlexKM.Info.DisplayCast1.Name") or xbmcgui.Window(10000).getProperty("PlexKM.Info.Cast1.Name") or "",
                    genre_hint=li.getProperty("PlexKM.Genre") or xbmcgui.Window(10000).getProperty("PlexKM.Info.Genre") or "",
                    source_control=_info_origin_focus_v2082,
                    is_tv=_initial_is_tv,
                    reason="actor_work_info_reentry_before_focus_v2083",
                )
            except Exception:
                _log("INFO_WIDGET_REBUILD_REQUEST_FAILED_V2082 rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | "),
                ), xbmc.LOGWARNING)

        # v2437: Search keeps its result surface alive underneath Info so Back can
        # restore the query.  Do not, however, inherit Search's expanded-sidebar
        # geometry into the first Info frame: that reserves a blank 410px lane.
        # Collapse visual geometry before InlineActive is published; no focus write.
        if _search_info_fast_path_v1773:
            try:
                self._set_sidebar_expanded_state(False, reason="search_info_previsible_v2437")
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
                _log("SEARCH_INFO_SIDEBAR_PREVISIBLE_COLLAPSE_V2437 rating_key=%s expanded=0 focus_write=0" % (
                    li.getProperty("PlexKM.RatingKey") or ""
                ))
            except Exception:
                _log("SEARCH_INFO_SIDEBAR_PREVISIBLE_COLLAPSE_FAILED_V2437 rating_key=%s err=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        # v2518 ROOT FIX: the first Home -> Info handoff can occur before
        # PlexKM.Sidebar.Expanded has ever been written. Home historically treats
        # an empty value as its boot-time expanded state, but the first Info frame
        # must inherit the CURRENT content geometry (collapsed). V2517 made the
        # collapsed X static, yet its XML still interpreted an empty property as
        # expanded. That exposed +329px for the first rendered Info frame, then
        # _sync_sidebar_state_from_focus() wrote 0 after focus moved to 5001 and
        # Kodi visibly reversed the 150ms slide. Canonicalize content-origin
        # geometry BEFORE InlineActive is published. Do not move focus.
        try:
            _v2518_focus = self._safe_focus_id()
            _v2518_self_before = self.getProperty("PlexKM.Sidebar.Expanded") or "<empty>"
            _v2518_win_before = xbmcgui.Window(10000).getProperty("PlexKM.Sidebar.Expanded") or "<empty>"
            if _v2518_focus not in (SEARCH_FIXED_ID, MENU_ID):
                self._info_set_property_all("PlexKM.Sidebar.Expanded", "0")
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
                _v2518_mode = "content_collapsed"
            else:
                _v2518_mode = "sidebar_focus_preserved"
            _log("INFO_PREVISIBLE_SIDEBAR_CANONICAL_V2518 rating_key=%s focus=%s self_before=%s win_before=%s self_after=%s win_after=%s mode=%s inline_before=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", _v2518_focus,
                _v2518_self_before, _v2518_win_before,
                self.getProperty("PlexKM.Sidebar.Expanded") or "<empty>",
                xbmcgui.Window(10000).getProperty("PlexKM.Sidebar.Expanded") or "<empty>",
                _v2518_mode, self.getProperty("PlexKM.Info.InlineActive") or "0"
            ))
        except Exception:
            _log("INFO_PREVISIBLE_SIDEBAR_CANONICAL_FAILED_V2518 rating_key=%s err=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        if _info_source_surface_hold_v2144:
            try:
                _log("INFO_ENTRY_ATOMIC_SWAP_V2445 rating_key=%s source=%s cover=%s target_complete=1 visible_fade_ms=0 home_held_until_commit=1" % (
                    li.getProperty("PlexKM.RatingKey") or "", _info_item_source_v1772,
                    xbmcgui.Window(10000).getProperty("PlexKM.Info.Transition.Cover") or "0"
                ))
            except Exception:
                pass

    def _show_info_step7(self, _history_restore_v2085, _info_open_start_ms, _info_origin_focus_v2082, _info_same_surface_new_title_v2087, _info_v2626_cache, _info_v2626_media, _info_v2626_source, _initial_is_tv, _transition_token, li):
        """Step 7 of _show_info (R76 split, moved verbatim). Logs: INFO_ENTRY_REQUIRED_READY_V2626, INFO_VISIBLE, INFO_ENTRY_VISIBLE_V2626, ACTOR_PROFILE_INFO_FIRST_PREWARM_FAILED_V2616."""
        try:
            _info_persist_snapshot_v2506 = self._info_prepared_cache_snapshot_v2506(li)
        except Exception:
            _info_persist_snapshot_v2506 = None
        try:
            _info_required_ready_ms_v2626 = max(0, self._now_ms() - _info_open_start_ms)
            _info_kpi_win_v2626 = xbmcgui.Window(10000)
            _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoRequiredReadyMs", str(int(_info_required_ready_ms_v2626)))
            _log("INFO_ENTRY_REQUIRED_READY_V2626 rating_key=%s media=%s cache=%s elapsed_ms=%d pre_sql=%d pre_net=%d target_complete=1" % (
                li.getProperty("PlexKM.RatingKey") or "", _info_v2626_media, _info_v2626_cache, int(_info_required_ready_ms_v2626),
                int(getattr(self, "_kpi_info_pre_sql_v2605", 0) or 0), int(getattr(self, "_kpi_info_pre_net_v2605", 0) or 0)
            ))
        except Exception:
            pass
        self.setProperty("PlexKM.Info.InlineActive", "1")
        xbmcgui.Window(10000).setProperty("PlexKM.Info.InlineActive", "1")
        # v2514: V2513 renderer-visible priming is disabled. This compatibility
        # call only clears any stale ScenePrime property; Info visibility is
        # controlled exclusively by InlineActive again.
        try:
            self._info_first_scene_prime_consume_v2513(
                li.getProperty("PlexKM.RatingKey") or "", reason="first_real_info_commit"
            )
        except Exception:
            pass
        try:
            _log("INFO_TIMING phase=inline_visible rating_key=%s elapsed=%dms mode=%s" % (
                li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                "tv_atomic_ready_v1883" if _initial_is_tv else "movie_fast"
            ))
            _info_visible_ms_v2604 = self._now_ms() - _info_open_start_ms
            # R86: remember when Info became visible so GUI-thread post-visible
            # commits (versions / cast fill / widget rebuild) wait for the
            # fade-in (~300ms) to finish instead of stuttering it.
            self._info_visible_stamp_r86 = self._now_ms()
            try:
                _kpi_win_v2604 = xbmcgui.Window(10000)
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoVisibleMs", str(int(_info_visible_ms_v2604)))
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoType", "tv" if _initial_is_tv else "movie")
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoPreSql", str(int(getattr(self, "_kpi_info_pre_sql_v2605", 0) or 0)))
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoPreNet", str(int(getattr(self, "_kpi_info_pre_net_v2605", 0) or 0)))
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoProxy", "1" if self._uhd_kpi_proxy_v2605() else "0")
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoStamp", str(self._now_ms()))
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoEntryVisibleMs", str(int(_info_visible_ms_v2604)))
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoEntryMedia", _info_v2626_media)
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoEntryCache", _info_v2626_cache)
                _kpi_win_v2604.setProperty("PlexKM.KPI.InfoEntrySource", _info_v2626_source)
                _log("INFO_ENTRY_VISIBLE_V2626 rating_key=%s media=%s cache=%s source=%s visible_ms=%d pre_sql=%d pre_net=%d" % (
                    li.getProperty("PlexKM.RatingKey") or "", _info_v2626_media, _info_v2626_cache, _info_v2626_source, int(_info_visible_ms_v2604),
                    int(getattr(self, "_kpi_info_pre_sql_v2605", 0) or 0), int(getattr(self, "_kpi_info_pre_net_v2605", 0) or 0)
                ))
            except Exception:
                pass
            try:
                pkm_uhd_diag_v2600.event(
                    "INFO_VISIBLE", extra="rk=%s visible_ms=%d type=%s widgets_pre=0 cast_net_pre=0 tv_net_pre=0" % (
                        li.getProperty("PlexKM.RatingKey") or "", _info_visible_ms_v2604,
                        "tv" if _initial_is_tv else "movie"
                    )
                )
            except Exception:
                pass
        except Exception:
            pass
        try:
            self._info_prepared_cache_store_async_v2506(_info_persist_snapshot_v2506)
        except Exception:
            pass
        self._inline_info_diag_log(phase="open_visible", reason="inline_active_atomic_commit_v1883")

        # V2616 PC reference: start the first visible cast actor's metadata runway
        # as soon as Info owns the screen.  This is not part of Info visibility
        # and never runs on Android/U+.  A later focus/click on the same actor
        # dedupes onto this worker, giving the common slot-1 actor 1-3 seconds
        # of useful runway while the user reads the Info page.
        try:
            if not self._uhd_kpi_proxy_v2605():
                _v2616_win = xbmcgui.Window(10000)
                _v2616_actor = str(_v2616_win.getProperty("PlexKM.Info.DisplayCast1.Name") or _v2616_win.getProperty("PlexKM.Info.Cast1.Name") or "").strip()
                _v2616_thumb = str(_v2616_win.getProperty("PlexKM.Info.Cast1.OriginalThumb") or _v2616_win.getProperty("PlexKM.Info.DisplayCast1.Thumb") or _v2616_win.getProperty("PlexKM.Info.Cast1.Thumb") or "").strip()
                if _v2616_actor:
                    _v2616_armed = self._schedule_actor_profile_item_prewarm_v2481(
                        _v2616_actor, source_rk=str(li.getProperty("PlexKM.RatingKey") or "").strip(),
                        fallback_thumb=_v2616_thumb, reason="info_first_actor_visible_v2616", settle_ms_v2526=0
                    )
                    _log("ACTOR_PROFILE_INFO_FIRST_PREWARM_V2616 actor=%s source=%s armed=%d visible_already=1 desktop_reference=1" % (
                        _short_log_value(_v2616_actor,80), li.getProperty("PlexKM.RatingKey") or "", 1 if _v2616_armed else 0
                    ))
        except Exception:
            _log("ACTOR_PROFILE_INFO_FIRST_PREWARM_FAILED_V2616 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        # v2406: TV-only entry focus moves to the selected episode rail.
        # The selected row is already the active resume / first unwatched /
        # first episode target prepared above. Movie entry focus stays 5001.
        # History Back remains excluded so exact parent focus is restored.
        try:
            if _initial_is_tv and not _history_restore_v2085:
                _tv_entry_focus_v2406 = int(self._info_tv_active_episode_control_id())
                _tv_rows_empty_v2406 = (
                    self.getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                )
                if _tv_rows_empty_v2406:
                    _tv_entry_focus_v2406 = 5724  # R99 D1: 5721 is hidden
                if _tv_entry_focus_v2406 in (5712, 5713):
                    _tv_focus_ok_v2409 = self._info_tv_focus_panel(
                        _tv_entry_focus_v2406, reason="tv_entry_visible_owner_v2409"
                    )
                    if not _tv_focus_ok_v2409:
                        # TV_INFO_EPISODE_FOCUS_OWNER_R20B:
                        # Atomic publish intentionally defers focus. Never turn
                        # that temporary state into a play-button 5721 fallback.
                        _log("INFO_TV_ENTRY_FOCUS_DEFER_R20B rating_key=%s target=%s defer=%d action=keep_episode_target_no_play_fallback" % (
                            li.getProperty("PlexKM.RatingKey") or "",
                            _tv_entry_focus_v2406,
                            1 if getattr(self, "_info_tv_defer_focus", False) else 0
                        ))
                    else:
                        self._last_focus_id = _tv_entry_focus_v2406
                        self._info_mark_entry_target_focus_ready_v2123(
                            _tv_entry_focus_v2406, reason="tv_episode_visible_owner_r20b"
                        )
                else:
                    self.setFocusId(_tv_entry_focus_v2406)
                    self._last_focus_id = _tv_entry_focus_v2406
                    self._info_mark_entry_target_focus_ready_v2123(
                        _tv_entry_focus_v2406, reason="tv_episode_visible_owner_r20b"
                    )
                _log("INFO_ENTRY_FOCUS_INTENT_R20B rating_key=%s is_tv=1 target=%s actual=%s deferred=%d source_focus=%s same_surface=%d history=0" % (
                    li.getProperty("PlexKM.RatingKey") or "", _tv_entry_focus_v2406,
                    self._safe_focus_id(), 1 if getattr(self, "_info_tv_defer_focus", False) else 0,
                    _info_origin_focus_v2082, 1 if _info_same_surface_new_title_v2087 else 0
                ))
                _log("INFO_TIMING phase=focus_intent rating_key=%s elapsed=%dms target=%s actual=%s r20b_episode_owner=1" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms,
                    _tv_entry_focus_v2406, self._safe_focus_id()
                ))
                self._inline_info_diag_log(phase="open_focus_immediate", reason="tv_episode_visible_owner_v2406")
            elif not _initial_is_tv and not _history_restore_v2085:
                self.setFocusId(5001)
                self._last_focus_id = 5001
                self._info_mark_entry_target_focus_ready_v2123(
                    5001, reason="movie_focus_immediate_v2123"
                )
                _log("INFO_TIMING phase=focus_immediate rating_key=%s elapsed=%dms focus=5001" % (
                    li.getProperty("PlexKM.RatingKey"), self._now_ms() - _info_open_start_ms
                ))
                self._inline_info_diag_log(phase="open_focus_immediate", reason="movie_focus_5001_no_delay")
            elif _history_restore_v2085:
                _log("INFO_HISTORY_INTERMEDIATE_FOCUS_SKIP_V2344 rating_key=%s type=%s keep_child_focus_until_exact_parent_focus=1" % (
                    li.getProperty("PlexKM.RatingKey") or "", "tv" if _initial_is_tv else "movie"
                ))
        except Exception:
            _log("INLINE_INFO_FOCUS_ENTRY_IMMEDIATE_FAILED err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            self._inline_info_diag_log(phase="open_focus_failed", reason="entry_focus_immediate_exception")
        try:
            if not _history_restore_v2085:
                _info_interactive_ms_v2626 = max(0, self._now_ms() - _info_open_start_ms)
                _info_kpi_win_v2626 = xbmcgui.Window(10000)
                _info_kpi_win_v2626.setProperty("PlexKM.KPI.InfoInteractiveMs", str(int(_info_interactive_ms_v2626)))
                _log("INFO_ENTRY_INTERACTIVE_V2626 rating_key=%s media=%s cache=%s interactive_ms=%d focus=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", _info_v2626_media, _info_v2626_cache, int(_info_interactive_ms_v2626), self._safe_focus_id()
                ))
        except Exception:
            pass
        try:
            pkm_transition_manager.finish_info_transition(
                self, _transition_token, li.getProperty("PlexKM.RatingKey") or "", delay_ms=0
            )
            _log("INFO_TRANSITION phase=atomic_release_v1883 rating_key=%s delay_ms=0 target_ready=1" % (
                li.getProperty("PlexKM.RatingKey") or ""
            ))
        except Exception:
            pass

    def _show_info_step8(self, _info_origin_focus_v2082, _initial_is_tv, li):
        """Step 8 of _show_info (R76 split, moved verbatim). Logs: INFO_ACTOR_WIDGETS_POSTVISIBLE_ARM_V2605, INFO_ACTOR_WIDGETS_POSTVISIBLE_SKIP_V2429, INFO_CAST_LATE_REPAIR_ARM_R9."""
        try:
            if not _initial_is_tv:
                self._info_movie_schedule_versions_postvisible_v2602(
                    li, reason="info_visible_v2617"
                )
        except Exception:
            pass

        # V2601 UHD native-first: related actor-work rows are decoration, not
        # an Info visibility prerequisite. Build them only after the first
        # interactive frame on Android; desktop keeps the established path.
        try:
            _r67_ready = isinstance(getattr(self, "_info_widget_rows_precomputed_v2332", None), dict) and str(self._info_widget_rows_precomputed_v2332.get("rating_key") or "") == str(li.getProperty("PlexKM.RatingKey") or "")
            if self._uhd_kpi_proxy_v2605() and not _r67_ready:
                self._info_schedule_actor_widget_rows_postvisible_v2383(
                    li, is_tv=_initial_is_tv, source_control=_info_origin_focus_v2082,
                    reason="uhd_info_visible_v2601"
                )
                _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_ARM_V2605 rating_key=%s is_tv=%d visible_already=1" % (
                    li.getProperty("PlexKM.RatingKey") or "", 1 if _initial_is_tv else 0
                ))
            else:
                _log("INFO_ACTOR_WIDGETS_POSTVISIBLE_SKIP_V2429 rating_key=%s is_tv=%d reason=previsible_complete" % (
                    li.getProperty("PlexKM.RatingKey") or "", 1 if _initial_is_tv else 0
                ))
        except Exception:
            pass
        # v2607: first-frame still never waits for cast. Stable-focus prewarm
        # normally makes portraits immediate; truly fast clicks are guaranteed
        # a post-visible fallback arm below so available Plex portraits still
        # arrive late instead of remaining placeholders.
        # v2606: the U+/proxy first frame intentionally never waits for cast
        # portrait network/crop work. Immediately after visibility, prepare
        # only the active title in the background and late-fill the existing
        # cast ListItems in place on the GUI ping. This restores every Plex
        # portrait that exists without adding one millisecond to InfoVisibleMs.
        try:
            _cast_pending_v2629 = (
                self.getProperty("PlexKM.Info.CastAtomicPendingV2629") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.CastAtomicPendingV2629") == "1"
            )
            # INFO_CAST_PLEX_LATE_REPAIR_R9:
            # V2635 deliberately reveals Info without waiting for portrait
            # network I/O and clears the old Pending flag. Recompute the real
            # portrait state after visibility so remote/unknown Plex actors
            # still enter the existing background late-fill path.
            if not _cast_pending_v2629:
                _ln_r9, _ll_r9, _lr_r9, _lm_r9, _lu_r9 = self._info_cast_atomic_stats_v2629(li)
                _cast_pending_v2629 = bool((_lr_r9 + _lu_r9) > 0)
                if _cast_pending_v2629:
                    self._info_set_property_all("PlexKM.Info.CastAtomicPendingV2629", "1")
                    self._info_set_property_all("PlexKM.Info.CastAtomicPendingV2630", "1")
                    _log("INFO_CAST_LATE_REPAIR_ARM_R9 rating_key=%s names=%d local=%d remote_pending=%d confirmed_missing=%d unknown=%d" % (
                        li.getProperty("PlexKM.RatingKey") or "", _ln_r9, _ll_r9, _lr_r9, _lm_r9, _lu_r9
                    ))
            if _cast_pending_v2629:
                _armed_r118 = self._info_schedule_cast_late_fill_v2606(
                    li, reason="info_visible_atomic_cast_r9"
                )
                if not _armed_r118:
                    _saved_r118 = getattr(self, "_info_cast_r15_li_r118", None)
                    _rk_r118 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                    if (isinstance(_saved_r118, tuple) and _saved_r118[1] is not None
                            and _saved_r118[0] == _rk_r118):
                        _armed2_r118 = self._info_schedule_cast_late_fill_v2606(
                            _saved_r118[1], reason="info_visible_cast_r15_item_r118")
                        _log("INFO_CAST_LATE_FILL_R15_ITEM_R118 rating_key=%s armed=%s" % (_rk_r118, _armed2_r118))
                        if not _armed2_r118:
                            self._info_cast_force_local_commit_r118(_saved_r118[1], _rk_r118, reason="r15_prefetch_done")
            self._info_cast_r15_li_r118 = None
        except Exception:
            pass

    def _info_cache_dir(self):
        try:
            base = core.xbmcvfs.translatePath(core.ADDON.getAddonInfo("profile"))
        except Exception:
            try:
                base = core.ADDON.getAddonInfo("profile")
            except Exception:
                base = "special://profile/addon_data/plugin.video.km/"
        path = os.path.join(base, "cast_cache")
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
        except Exception:
            pass
        return path

    def _info_atomic_asset_join_v2609(self, rating_key, want_tv=False, budget_ms=80):
        """Briefly join an already-running focus prime while source stays visible."""
        rk = str(rating_key or "").strip()
        if not rk or int(budget_ms or 0) <= 0:
            return 0
        t0 = self._now_ms()
        try:
            with self._info_atomic_asset_lock_v2609:
                cast_event = (getattr(self, "_info_cast_lead_events_v2609", {}) or {}).get(rk)
                tv_event = (getattr(self, "_info_tv_prewarm_events_v2609", {}) or {}).get(rk) if want_tv else None
            deadline = time.time() + (float(budget_ms) / 1000.0)
            for ev in (cast_event, tv_event):
                if ev is None or ev.is_set():
                    continue
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                ev.wait(remaining)
            waited = self._now_ms() - t0
            _log("INFO_ATOMIC_ASSET_JOIN_V2609 rating_key=%s tv=%d waited_ms=%d budget_ms=%d" % (rk, 1 if want_tv else 0, waited, int(budget_ms)))
            return waited
        except Exception:
            return self._now_ms() - t0

    def _info_focus_movie_data_prewarm_v2508(self, data_v2508, token_v2508):
        """Precompute bounded movie-Info SQLite data for a settled focus.

        Worker contract: ``data_v2508`` is an immutable plain dict captured on
        the GUI thread.  This helper creates no xbmcgui objects and never mutates
        visible controls.  Results are advisory and keyed by ratingKey, so a
        focus move can safely drop them without affecting Info correctness.
        """
        rk = str((data_v2508 or {}).get("rating_key") or "").strip()
        ptype = str((data_v2508 or {}).get("type") or "").strip().lower()
        if not rk or ptype != "movie":
            return False
        t0 = self._now_ms()
        actor_hint = str((data_v2508 or {}).get("actor_hint") or "")
        genre_hint = str((data_v2508 or {}).get("genre_hint") or "")
        versions_payload = None
        rows_payload = None
        versions_ms = -1
        rows_ms = -1
        try:
            tv = self._now_ms()
            core_mod = _ensure_core()
            selected, configured = core_mod.selected_sections_state()
            selected = [str(x) for x in (selected or []) if str(x)] if configured else []
            versions = []
            default_resolution = ""
            if selected:
                conn = sqlite3.connect(self._profile_db_path(), timeout=2.0)
                try:
                    # v2515: if the user clicks while this advisory focus
                    # prewarm is scanning, the real Info foreground owns the DB.
                    # SQLite's progress handler aborts this read promptly instead
                    # of letting two identical movie-version scans compete.
                    try:
                        conn.set_progress_handler(
                            lambda: 1 if token_v2508 != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0) else 0,
                            1000,
                        )
                    except Exception:
                        pass
                    try:
                        result = pkm_media_versions.find_movie_versions(conn, rk, selected)
                    except sqlite3.OperationalError as exc_v2515:
                        if "interrupt" in str(exc_v2515).lower():
                            _log("INFO_FOCUS_VERSION_PREWARM_CANCELLED_V2515 rating_key=%s reason=info_click_or_focus_move foreground_priority=1" % rk)
                            return False
                        raise
                finally:
                    try:
                        conn.set_progress_handler(None, 0)
                    except Exception:
                        pass
                    conn.close()
                versions = list((result or {}).get("versions") or [])
                default_resolution = str((result or {}).get("default_resolution") or "").strip()
                versions = [v for v in versions if str(v.get("resolution") or "") in ("720p", "1080p", "2160p")]
            versions_payload = {
                "rating_key": rk, "selected": list(selected),
                "versions": list(versions), "default_resolution": default_resolution,
            }
            versions_ms = self._now_ms() - tv
            if token_v2508 != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                _log("INFO_FOCUS_DATA_PREWARM_DROP_V2508 rating_key=%s stage=after_versions reason=focus_moved elapsed_ms=%d" % (rk, self._now_ms() - t0))
                return False
            with self._info_focus_prewarm_lock_v2508:
                cache = self._info_focus_prewarm_cache_v2508
                rec = dict(cache.get(rk) or {})
                rec.update({"ts": time.time(), "versions": versions_payload, "actor_hint": actor_hint, "genre_hint": genre_hint})
                cache[rk] = rec
        except Exception:
            _log("INFO_FOCUS_VERSION_PREWARM_FAILED_V2508 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        try:
            tr = self._now_ms()
            rows_payload = self._info_movie_cine21_widget_rows(
                rk, limit=12, actor_hint=actor_hint, genre_hint=genre_hint
            ) or []
            rows_ms = self._now_ms() - tr
            if token_v2508 != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                _log("INFO_FOCUS_DATA_PREWARM_DROP_V2508 rating_key=%s stage=after_actor_rows reason=focus_moved elapsed_ms=%d" % (rk, self._now_ms() - t0))
                return False
            with self._info_focus_prewarm_lock_v2508:
                cache = self._info_focus_prewarm_cache_v2508
                rec = dict(cache.get(rk) or {})
                rec.update({
                    "ts": time.time(), "widget_rows": list(rows_payload),
                    "actor_hint": actor_hint, "genre_hint": genre_hint,
                })
                cache[rk] = rec
                if len(cache) > 16:
                    ordered = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0.0))
                    for old_rk, _ in ordered[:-16]:
                        cache.pop(old_rk, None)
            _log("INFO_FOCUS_DATA_PREWARM_READY_V2508 rating_key=%s versions=%d actor_rows=%d versions_ms=%d rows_ms=%d total_ms=%d gui_mutation=0" % (
                rk, len((versions_payload or {}).get("versions") or []), len(rows_payload or []),
                versions_ms, rows_ms, self._now_ms() - t0
            ))
            return True
        except Exception:
            _log("INFO_FOCUS_ACTOR_ROWS_PREWARM_FAILED_V2508 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return bool(versions_payload)

    # PKM_INFO_CLICK_PREWARM_AND_NAME_FASTPATH
    def _info_click_db_preload_worker(self, rating_key, focus_token):
        """Warm only the same local DB snapshot used by the existing Info click.

        Never access Kodi GUI controls or ListItems. The stored DB cache obeys
        its existing plex_km.db mtime invalidation and 600-entry memory bound.
        """
        rk = str(rating_key or "").strip()
        started = self._now_ms()
        try:
            if not rk or int(focus_token) != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                return
            result = self._load_info_cache_from_local_db(rk, reason="focus_before_info_click")
            _log("INFO_CLICK_DB_PREWARM_DONE key=%s hit=%d elapsed_ms=%d gui_listitem_access=0" % (
                rk, 1 if result else 0, max(0, self._now_ms() - started)))
        except Exception:
            _log("INFO_CLICK_DB_PREWARM_FAILED key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        finally:
            try:
                lock = getattr(self, "_info_click_prime_lock", None)
                if lock is not None:
                    with lock:
                        running = getattr(self, "_info_click_prime_keys", set())
                        running.discard(rk)
            except Exception:
                pass

    def _info_click_db_preload_start(self, rating_key, focus_token):
        """One DB prime per key, at most two outstanding, never on GUI."""
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return False
            lock = getattr(self, "_info_click_prime_lock", None)
            if lock is None:
                lock = threading.Lock()
                self._info_click_prime_lock = lock
                self._info_click_prime_keys = set()
            with lock:
                running = getattr(self, "_info_click_prime_keys", set())
                if rk in running or len(running) >= 2:
                    return False
                cache = getattr(self, "_info_local_db_cache", {}) or {}
                if rk in cache and cache.get(rk):
                    return False
                running.add(rk)
            try:
                _PKMHomeThreadV2151(target=lambda: self._info_click_db_preload_worker(rk, focus_token),
                                    name="PKMInfoClickDBPrime", daemon=True).start()
                return True
            except Exception:
                with lock:
                    running.discard(rk)
                return False
        except Exception:
            return False

    def _info_click_cached_ko_name(self, actor_name, prepared=""):
        """GUI-safe display label. Never issue Actor Master SQLite from Info publish.

        The background focus and cast-localize workers populate the same actor
        name cache used by the existing authoritative lookup. Cached Korean
        names remain first; a cold miss retains the Plex label until prepared.
        """
        if prepared:
            return str(prepared)
        name = str(actor_name or "").strip()
        if not name:
            return name
        try:
            key = "|" + unicodedata.normalize("NFKC", name).strip().casefold()
            cache = getattr(self, "_actor_master_name_cache_v2701", None) or {}
            return str(cache.get(key) or name)
        except Exception:
            return name

    def _handle_info_playback_request(self, li):
        """Start playback only after DialogVideoInfo has closed.

        Hard rule for v099:
        - Do not call PlayMedia while DialogVideoInfo is open.
        - Do not leave WindowXML Home above the player.
        - Close UI first, then start PlayMedia, then force fullscreenvideo.

        This removes the recurring symptom where audio/video starts behind the
        information dialog and appears only after pressing Back.
        """
        win = xbmcgui.Window(10000)
        rating_key = li.getProperty("PlexKM.RatingKey") or ""
        plex_type = li.getProperty("PlexKM.Type") or ""
        try:
            self._arm_playback_priority_v2118(rating_key, reason="handle_info_playback")
        except Exception:
            pass
        play_url = ""
        try:
            play_url = _pkm_no_resume_url(win.getProperty("PlexKM.InfoPlaybackUrl") or li.getProperty("PlexKM.PlayUrl") or "")
        except Exception:
            play_url = _pkm_no_resume_url(li.getProperty("PlexKM.PlayUrl") or "")
        try:
            if not play_url:
                part_key = li.getProperty("PlexKM.PartKey") or ""
                if part_key and plex_type in ("movie", "episode"):
                    play_url = _pkm_play_url(rating_key, part_key, mode="start")
        except Exception:
            pass

        # Request was consumed. Clear the info-dialog spinner properties now
        # because the info dialog is already closed at this point.
        try:
            win.clearProperty("PlexKM.InfoPlaybackRequested")
            win.clearProperty("PlexKM.InfoPlaybackRatingKey")
            win.clearProperty("PlexKM.InfoPlaybackUrl")
            win.clearProperty("PlexKM.InfoDirectPlaybackStarting")
        except Exception:
            pass

        if not play_url:
            self._clear_playback_priority_v2118(reason="info_playback_no_url")
            self._main_playback_requested = False
            self._playback_opening = False
            try:
                win.clearProperty("PlexKM.MainPlaybackStarting")
                win.clearProperty("PlexKM.MainPlaybackRatingKey")
                win.clearProperty("PlexKM.Playback.HidePKMUI")
                win.clearProperty("PlexKM.Playback.HideSkinHome")
            except Exception:
                pass
            _log("INFO_PLAYBACK_NO_URL rating_key=%s type=%s" % (rating_key, plex_type), xbmc.LOGWARNING)
            try:
                self._show_pkm_notice("Plex KM", "재생 경로가 없습니다", "Plex 항목 정보를 확인해주세요", ms=3000)
            except Exception:
                pass
            self._restore_wall_focus_after_info(rating_key=rating_key)
            return

        overlay = self._handle_info_playback_request_step1(li, play_url, plex_type, rating_key, win)
        try:
            # v582: Kodi-native handoff while PKM Home is a normal WindowXML.
            # The root problem was not PlayMedia or the Plex URL. PKM Home was
            # implemented as WindowXMLDialog, which stays in Kodi's active modal
            # dialog stack. Kodi then refuses fullscreenvideo, or skin Home is
            # exposed if we close PKM. Home is now WindowXML, so keep PKM alive
            # underneath Kodi's native fullscreen player and do not reopen Home.
            try:
                xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            except Exception:
                pass

            # v1085: only force no-resume for explicit start playback. Resume
            # URLs already carry resume_offset and must not be converted to
            # start=0; that was the root cause of Continue items starting from
            # the beginning while logs still showed a valid offset.
            try:
                import urllib.parse as _pkm_urlparse
                _p = _pkm_urlparse.urlparse(play_url)
                _q = _pkm_urlparse.parse_qs(_p.query or "")
                _resume_ms = int(float((_q.get("resume_offset") or ["0"])[0] or 0))
                _resume_duration_ms = int(float((_q.get("resume_duration_ms") or ["0"])[0] or 0))
            except Exception:
                _resume_ms = 0
                _resume_duration_ms = 0
            play_url_effective = play_url if _resume_ms > 0 else _pkm_no_resume_url(play_url)
            offset_sec = max(0, int(_resume_ms // 1000))
            resume_total_sec = max(0, int(_resume_duration_ms // 1000))

            # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
            # v1367 fast-direct/Python-player playback is permanently disabled.
            # Info playback must go through Kodi's native plugin resolver path:
            #   PlayMedia(plugin://plugin.video.km/?action=play...)
            #   -> default.py action=play
            #   -> pkm_playback.play_item()
            #   -> xbmcplugin.setResolvedUrl()
            # Do NOT re-enable direct http file.mkv playback here.
            # Do NOT call xbmc.Player().play() for movies/episodes here.
            # The only allowed URL for Info playback at this point is the
            # plugin:// action=play URL in play_url_effective.
            direct_url = ""
            direct_used = False
            play_target_url = play_url_effective
            try:
                win.setProperty("PlexKM.InfoPlayback.FastDirect", "0")
                win.setProperty("PlexKM.InfoPlayback.NativeLockV1454", "1")
            except Exception:
                pass

            # Metadata below is only for PKM skin OSD properties. It must not be
            # used to start playback with xbmc.Player().play(). Kodi's resolver
            # remains the single source of playback handoff.
            play_title = ""
            play_original_title = ""
            play_year = ""
            play_plot = ""
            play_duration_sec = 0
            play_mediatype = "episode" if plex_type == "episode" else "movie"
            try:
                play_title = (
                    win.getProperty("PlexKM.Info.TitleDisplay") or
                    win.getProperty("PlexKM.Info.Title") or
                    li.getProperty("PlexKM.TitleDisplay") or
                    li.getProperty("PlexKM.Title") or
                    li.getLabel() or
                    ""
                )
                play_original_title = (
                    win.getProperty("PlexKM.Info.OriginalTitle") or
                    li.getProperty("PlexKM.OriginalTitle") or
                    play_title or
                    ""
                )
                play_year = win.getProperty("PlexKM.Info.Year") or li.getProperty("PlexKM.Year") or ""
                play_plot = win.getProperty("PlexKM.Info.Summary") or li.getProperty("PlexKM.Summary") or ""
                _dur_raw = win.getProperty("PlexKM.Info.Duration") or li.getProperty("PlexKM.Duration") or "0"
                _dur_val = int(float(_dur_raw or 0))
                # Plex duration is normally milliseconds in this add-on.
                play_duration_sec = int(_dur_val / 1000) if _dur_val > 100000 else int(_dur_val)
            except Exception:
                play_title = play_title or li.getLabel() or ""
                play_original_title = play_original_title or play_title
                play_year = play_year or ""
                play_plot = play_plot or ""
                play_duration_sec = int(play_duration_sec or 0)

            # v1369: Plex-style player OSD owner properties.
            # Direct playback uses a Plex file URL ending in /file.mkv; some Kodi
            # OSD labels can still fall back to Player.Title.  Store the exact
            # Plex-style title/meta text for the skin so the OSD shows only:
            # movie title + "year • runtime".
            try:
                def _pkm_runtime_ko(_sec):
                    try:
                        _sec = max(0, int(float(_sec or 0)))
                    except Exception:
                        _sec = 0
                    _mins = int(_sec // 60)
                    if _mins <= 0:
                        return ""
                    _h = int(_mins // 60)
                    _m = int(_mins % 60)
                    if _h > 0 and _m > 0:
                        return "%d시간 %d분" % (_h, _m)
                    if _h > 0:
                        return "%d시간" % _h
                    return "%d분" % _m
                _osd_title = str(play_title or "").strip()
                _osd_runtime = _pkm_runtime_ko(play_duration_sec)
                _osd_year = str(play_year or "").strip()
                _osd_meta_parts = []
                if _osd_year:
                    _osd_meta_parts.append(_osd_year)
                if _osd_runtime:
                    _osd_meta_parts.append(_osd_runtime)
                win.setProperty("PlexKM.Player.Title", _osd_title)
                win.setProperty("PlexKM.Player.Meta", " • ".join(_osd_meta_parts))
                win.setProperty("PlexKM.Player.Year", _osd_year)
                win.setProperty("PlexKM.Player.Runtime", _osd_runtime)
                # R80: the resolver (pkm_playback) fills the episode prefix from the DB.
                win.clearProperty("PlexKM.Player.EpPrefix")
            except Exception:
                pass

            pli = xbmcgui.ListItem(label=(play_title or ""), path=play_target_url)
            try:
                pli.setProperty("IsPlayable", "true")
                pli.setProperty("PlexKM.RatingKey", str(rating_key or ""))
                pli.setProperty("PlexKM.PartKey", str((locals().get('part_key_fast') or li.getProperty("PlexKM.PartKey") or "")))
                pli.setProperty("PlexKM.PlayTitle", str(play_title or ""))
                pli.setProperty("StartOffset", str(offset_sec))
                pli.setProperty("startoffset", str(offset_sec))
                pli.setProperty("resumetime", "%.6f" % float(offset_sec))
                pli.setProperty("ResumeTime", "%.6f" % float(offset_sec))
                pli.setProperty("totaltime", "%.6f" % float(resume_total_sec or play_duration_sec or 0))
                pli.setProperty("TotalTime", "%.6f" % float(resume_total_sec or play_duration_sec or 0))
                try:
                    info = {
                        "title": play_title or "",
                        "sorttitle": play_title or "",
                        "originaltitle": play_original_title or play_title or "",
                        "plot": play_plot or "",
                        "duration": int(play_duration_sec or 0),
                        "mediatype": play_mediatype,
                    }
                    if str(play_year or "").isdigit():
                        info["year"] = int(play_year)
                    apply_video_info(pli, info)
                except Exception:
                    pass
                try:
                    art = {}
                    _thumb = win.getProperty("PlexKM.Info.Thumb") or li.getProperty("PlexKM.Thumb") or li.getArt("poster") or li.getArt("thumb") or ""
                    _fanart = win.getProperty("PlexKM.Info.Art") or li.getProperty("PlexKM.Art") or li.getArt("fanart") or ""
                    if _thumb:
                        art["thumb"] = _thumb
                        art["poster"] = _thumb
                    if _fanart:
                        art["fanart"] = _fanart
                    if art:
                        pli.setArt(art)
                except Exception:
                    pass
                tag = pli.getVideoInfoTag()
                if tag is not None:
                    try:
                        if hasattr(tag, "setResumePoint"):
                            tag.setResumePoint(float(offset_sec), float(resume_total_sec or play_duration_sec or 0))
                    except Exception:
                        pass
            except Exception:
                pass
            # v1450: playback gets network priority. Stop Home cast-prewarm/search
            # work before handing the Plex file URL to Kodi.
            try:
                self._cancel_info_cast_prewarm_for_playback_v1450(reason="before_player_play")
            except Exception:
                pass
            # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
            # This is the only allowed Info playback start path.
            # Do not use xbmc.Player().play() from Python here.  That API starts
            # VideoPlayer from the Python thread and produced the Info-screen ->
            # delayed fullscreen -> stalled-frame sequence on Plex HTTP streams.
            # Hand Kodi the normal plugin resolver URL via PlayMedia(), so
            # default.py/pkm_playback resolves the Plex file with setResolvedUrl
            # exactly like Kodi-native plugin playback.
            try:
                play_target_url = play_url_effective
                direct_used = False
                win.setProperty("PlexKM.InfoPlayback.FastDirect", "0")
            except Exception:
                play_target_url = play_url_effective
                direct_used = False

            # v1415/v1453: Kodi may spend several seconds in OpenFile/Demuxer/codec
            # before Caching/Seeking becomes visible.  Arm a display-only spinner
            # across Home/Fullscreen until service.py clears it on AV/player events.
            self._arm_native_opening_spinner_v1415(rating_key, source="info_playmedia_native_v1454_locked")
            # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
            # PlayMedia must receive the plugin:// action=play URL, never a
            # direct Plex http file.mkv URL.
            xbmc.executebuiltin("PlayMedia(%s,%s)" % (play_target_url, "resume" if offset_sec > 0 else "noresume"))
            _log("INFO_PLAYBACK_SENT_PLAYMEDIA_NATIVE_LOCKED_V1454_V1547 rating_key=%s type=%s mode=%s offset_sec=%s direct=0 url_kind=plugin python_player_play=0 resolver_gate=pre_avstarted title=%s" % (
                rating_key, plex_type,
                "plugin_resolver_resume" if offset_sec > 0 else "plugin_resolver_noresume",
                offset_sec, _short_log_value(play_title, 80)))
            try:
                _log("PKM_NATIVE_RESUME_HANDOFF_V1553 rating_key=%s offset_sec=%s total_sec=%s url_duration_ms=%s auto_seek=0" % (
                    rating_key, offset_sec, int(resume_total_sec or play_duration_sec or 0), int(_resume_duration_ms or 0)))
            except Exception:
                pass

            # External subtitle probing is kept out of the blocking path.  If a
            # Plex external Korean subtitle exists, set PendingSubtitle shortly
            # after playback starts; otherwise service.py will fall back to the
            # internal Korean stream as before.
            # v1454: fast-direct subtitle probe removed from Info playback path.
            # Subtitles are applied by the native resolver path in pkm_playback.py
            # during setResolvedUrl.  Keep this area empty to prevent reintroducing
            # a direct/Python-owned playback branch.
            self._playback_opening = False
            self._main_playback_requested = False
            return
        except Exception:
            self._close_playback_loading_overlay(overlay)
            self._clear_playback_priority_v2118(reason="info_playback_front_failed")
            self._playback_opening = False
            self._main_playback_requested = False
            try:
                win.clearProperty("PlexKM.MainPlaybackStarting")
                win.clearProperty("PlexKM.MainPlaybackRatingKey")
                win.clearProperty("PlexKM.Playback.HidePKMUI")
                win.clearProperty("PlexKM.Playback.HideSkinHome")
            except Exception:
                pass
            _log("INFO_PLAYBACK_FRONT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            try:
                self._show_pkm_notice("Plex KM", "재생 시작 중 오류가 발생했습니다", "kodi.log를 확인해주세요", ms=3500)
            except Exception:
                pass

    def _handle_info_playback_request_step1(self, li, play_url, plex_type, rating_key, win):
        """Step 1 of _handle_info_playback_request (R76 split, moved verbatim). Logs: PLAYBACK_ATTEMPT_BEGIN_V1545, PLAYBACK_ATTEMPT_STATE_RESET_FAILED_V1545, INLINE_PLAYBACK_RETURN_SAVE_CALL_FAILED, INFO_PLAYBACK_KODI_NATIVE_START."""
        self._main_playback_requested = True
        self._playback_opening = True
        try:
            # v606: Do not reopen/rebuild PKM after playback.  Keep the current
            # WindowXML/inline Info underneath Kodi's native player and only mark
            # that the next Back arriving at this WindowXML may be the leaked
            # fullscreen-video Back used to stop playback.
            win.setProperty("PlexKM.NativePlayback.SuppressNextInlineBack", "1")
            self.setProperty("PlexKM.NativePlayback.SuppressNextInlineBack", "1")
        except Exception:
            pass
        # v1545: every playback attempt starts from a clean per-session state.
        # After the first Stop, BackStopRequested remains set until explicitly
        # cleared.  Leaving it set makes the second session observably different
        # and suppresses service/pre-read paths that interpret it as a stop in
        # progress.  Clear only transient playback-stop/opening state here.
        try:
            _stale_back_stop = win.getProperty("PlexKM.Playback.BackStopRequested") == "1"
            for _key in (
                "PlexKM.Playback.BackStopRequested",
                "PlexKM.Playback.ReturnFade",
                "PlexKM.Playback.ReturnFade.Stopping",
                "PlexKM.Playback.ReturnFade.SuppressPreread",
                "PlexKM.Playback.ReturnFade.DialogActive",
                "PlexKM.Playback.ReturnFade.HomeCoverReady",
                "PlexKM.Playback.ReturnInfoReadyV1939",
            ):
                try:
                    win.clearProperty(_key)
                except Exception:
                    pass
            try:
                _attempt_seq = int(win.getProperty("PlexKM.Playback.AttemptSeqV1545") or "0") + 1
            except Exception:
                _attempt_seq = 1
            win.setProperty("PlexKM.Playback.AttemptSeqV1545", str(_attempt_seq))
            win.setProperty("PlexKM.Playback.ActiveAttemptSeqV1545", str(_attempt_seq))
            try:
                _thread = threading.current_thread()
                _thread_name = getattr(_thread, "name", "") or ""
                _thread_id = getattr(_thread, "ident", "") or ""
            except Exception:
                _thread_name = ""
                _thread_id = ""
            _log("PLAYBACK_ATTEMPT_BEGIN_V1545 seq=%s rating_key=%s type=%s stale_back_stop_cleared=%s poststop_refresh_deferred=%s thread=%s thread_id=%s focus=%s" % (
                _attempt_seq, rating_key, plex_type,
                "1" if _stale_back_stop else "0",
                win.getProperty("PlexKM.Playback.PostStopRefreshDeferredV1545") or "0",
                _thread_name, _thread_id, self._safe_focus_id()
            ))
        except Exception:
            _attempt_seq = 0
            _log("PLAYBACK_ATTEMPT_STATE_RESET_FAILED_V1545 rating_key=%s err=%s" % (
                rating_key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        try:
            self._save_inline_info_playback_return_state(li)
        except Exception:
            _log("INLINE_PLAYBACK_RETURN_SAVE_CALL_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        _log("INFO_PLAYBACK_KODI_NATIVE_START rating_key=%s type=%s attempt_seq=%s url=%s" % (rating_key, plex_type, _attempt_seq, play_url))

        overlay = None
        return overlay


    def _return_to_home_after_info(self):
        # DialogVideoInfo is modal; this runs after the user closes it.
        # v090: do NOT force Home/sidebar focus. Keep the same wall item focused.
        # Previous code selected menu position 0 and rebuilt/restored the Home wall,
        # which made focus jump back to the left sidebar after every info dialog.
        try:
            self._suspend_refresh_until_ms = self._now_ms() + 700

            wall = self.getControl(WALL_ID)
            menu = self.getControl(MENU_ID)

            # Keep current sidebar section selected, but do not focus it.
            try:
                if menu.size() > 0 and self.active_menu_index >= 0:
                    menu.selectItem(min(max(0, self.active_menu_index), menu.size() - 1))
            except Exception:
                pass

            if wall.size() > 0:
                if self._library_wall_is_native_owner_v2070():
                    target_pos = max(0, int(wall.getSelectedPosition()))
                    target_rating_key = self._last_info_rating_key or ""
                else:
                    target_pos = min(max(0, self._last_wall_pos), wall.size() - 1)
                    target_rating_key = self._last_info_rating_key or ""
                    if target_rating_key:
                        try:
                            for i in range(wall.size()):
                                item = wall.getListItem(i)
                                if item and item.getProperty("PlexKM.RatingKey") == target_rating_key:
                                    target_pos = i
                                    break
                        except Exception:
                            pass
                    wall.selectItem(target_pos)
                self.setFocusId(WALL_ID)
                # Kodi may finish processing the DialogVideoInfo close one tick
                # later. Re-assert the wall focus after a short delay so Back is
                # a single-step return and the focused movie remains selected.
                xbmc.sleep(80)
                try:
                    if not self._library_wall_is_native_owner_v2070():
                        wall.selectItem(target_pos)
                    self.setFocusId(WALL_ID)
                except Exception:
                    pass
                self._last_focus_id = WALL_ID
                self._last_wall_pos = target_pos
                _log("INFO_RETURN_WALL section=%s pos=%d rating_key=%s" % (
                    self.active_section_id, target_pos, target_rating_key
                ))
                return

            # Fallback only if the wall is unexpectedly empty.
            if menu.size() > 0:
                target_menu = min(max(0, self.active_menu_index), menu.size() - 1) if self.active_menu_index >= 0 else 0
                menu.selectItem(target_menu)
                self._log_menu_transition("info_return_menu_fallback", self._safe_focus_id(), "target_menu=%d empty_wall=1" % target_menu)
                self._focus_menu_control_v1993(reason="direct_menu_handoff_v1993")
                self._last_focus_id = MENU_ID
                self._last_menu_pos = target_menu
                _log("INFO_RETURN_MENU_FALLBACK pos=%d reason=empty_wall" % target_menu)
        except Exception:
            _log("INFO_RETURN_WALL_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

    def _restore_wall_focus_after_info(self, rating_key=""):
        """Return from DialogVideoInfo to the Plex KM Home wall in one Back press."""
        try:
            if rating_key:
                self._last_info_rating_key = str(rating_key or "")
            # Close any transient Kodi dialogs that may remain above WindowXML.
            try:
                xbmc.executebuiltin("Dialog.Close(busydialog,true)")
                xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            except Exception:
                pass
            self._return_to_home_after_info()
            _log("INFO_BACK_RETURN_HOME_DONE rating_key=%s" % (rating_key or self._last_info_rating_key or ""))
        except Exception:
            _log("INFO_BACK_RETURN_HOME_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)


    def _ensure_info_local_db_indexes(self, conn):
        """v2678: never build large SQLite indexes on the Info click/GUI thread.

        Existing indexes are detected cheaply. Missing indexes are created once in
        a daemon worker; the current cold Info open falls back to the already-bound
        ListItem/Plex repair instead of blocking for multi-second CREATE INDEX.
        """
        try:
            if getattr(self, "_info_local_db_indexes_ready", False):
                return True
            required = {
                "idx_pkm_info_items_rating_key",
                "idx_pkm_info_people_rating_type_order",
                "idx_pkm_info_people_type_name",
                "idx_pkm_info_people_type_tag",
                "idx_pkm_info_genres_rating_key",
            }
            try:
                names = {str(r[1]) for r in conn.execute("PRAGMA index_list('item_people')").fetchall()}
                names |= {str(r[1]) for r in conn.execute("PRAGMA index_list('item_genres')").fetchall()}
                names |= {str(r[1]) for r in conn.execute("PRAGMA index_list('items')").fetchall()}
            except Exception:
                names = set()
            if required.issubset(names):
                self._info_local_db_indexes_ready = True
                return True
            if getattr(self, "_info_local_db_index_worker_v2678", None) is not None:
                return False
            dbp = self._profile_db_path()
            def _worker_v2678():
                t0 = time.time()
                try:
                    # Let the first interactive frame and immediate DOWN navigation win.
                    time.sleep(2.0)
                    c = sqlite3.connect(dbp, timeout=30.0)
                    try:
                        c.execute("CREATE INDEX IF NOT EXISTS idx_pkm_info_items_rating_key ON items(rating_key)")
                        c.execute("CREATE INDEX IF NOT EXISTS idx_pkm_info_people_rating_type_order ON item_people(rating_key, person_type, sort_order)")
                        c.execute("CREATE INDEX IF NOT EXISTS idx_pkm_info_people_type_name ON item_people(person_type, person_name)")
                        c.execute("CREATE INDEX IF NOT EXISTS idx_pkm_info_people_type_tag ON item_people(person_type, tag_id)")
                        c.execute("CREATE INDEX IF NOT EXISTS idx_pkm_info_genres_rating_key ON item_genres(rating_key)")
                        c.commit()
                    finally:
                        c.close()
                    self._info_local_db_indexes_ready = True
                    _log("INFO_DB_INDEX_BACKGROUND_READY_V2678 elapsed=%.1fms gui_block=0" % ((time.time()-t0)*1000.0))
                except Exception:
                    _log("INFO_DB_INDEX_BACKGROUND_FAILED_V2678 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                finally:
                    self._info_local_db_index_worker_v2678 = None
            th = threading.Thread(target=_worker_v2678, name="PKMInfoIndexV2678", daemon=True)
            self._info_local_db_index_worker_v2678 = th
            th.start()
            _log("INFO_DB_INDEX_DEFER_V2678 action=background_build current_info_scan=skip")
            return False
        except Exception:
            _log("INFO_DB_INDEX_CHECK_FAILED_V2678 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _load_info_cache_from_local_db(self, rating_key, reason=""):
        """Build Info metadata directly from plex_km.db without any Plex/network call.

        This is the first-paint fallback for items whose widget ListItem has only
        light metadata.  The sync DB already owns Plex people/role rows, so Info
        must not wait for /library/metadata when item_people has cast data.
        """
        start = time.time()
        rk = str(rating_key or "").strip()
        if not rk:
            return None
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                _log("INFO_DB_FALLBACK miss reason=no_db rating_key=%s db=%s source=%s elapsed=%.1fms" % (
                    rk, dbp or "", reason or "", (time.time() - start) * 1000.0
                ), xbmc.LOGWARNING)
                return None
            try:
                mtime = os.path.getmtime(dbp)
            except Exception:
                mtime = 0
            cache = getattr(self, "_info_local_db_cache", None)
            cache_mtime = getattr(self, "_info_local_db_cache_mtime", None)
            if not isinstance(cache, dict) or cache_mtime != mtime:
                cache = {}
                self._info_local_db_cache = cache
                self._info_local_db_cache_mtime = mtime
            if rk in cache:
                cached = cache.get(rk)
                _log("INFO_DB_FALLBACK hit=memory rating_key=%s cast=%d source=%s elapsed=%.1fms" % (
                    rk, len((cached or {}).get("CastSlots") or []) if cached else 0, reason or "", (time.time() - start) * 1000.0
                ))
                return cached

            conn = sqlite3.connect(dbp, timeout=5.0)
            try:
                conn.row_factory = sqlite3.Row
                # v2677: the helper existed but was never called. On a large sync DB
                # this made sparse/cold movies (observed: 비광) spend ~5.3s scanning
                # item_people/item_genres before first Info paint. Build the exact
                # lookup indexes once per window before the first cold lookup.
                if not self._ensure_info_local_db_indexes(conn):
                    _log("INFO_DB_FALLBACK skip=unindexed_v2678 rating_key=%s source=%s gui_scan=0" % (rk, reason or ""))
                    return None
                row = conn.execute("""
                    SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title,
                           year, summary, duration, added_at, updated_at, thumb, art, part_key,
                           view_count, last_viewed_at, parent_rating_key, grandparent_rating_key,
                           show_title, season, episode, raw_json
                    FROM items
                    WHERE rating_key=?
                    LIMIT 1
                """, (rk,)).fetchone()
                if not row:
                    cache[rk] = None
                    _log("INFO_DB_FALLBACK miss reason=no_item rating_key=%s source=%s elapsed=%.1fms" % (
                        rk, reason or "", (time.time() - start) * 1000.0
                    ), xbmc.LOGWARNING)
                    return None

                raw = {}
                raw_text = row["raw_json"] or ""
                if raw_text:
                    try:
                        raw = json.loads(raw_text)
                    except Exception:
                        raw = {}

                def raw_get(*names):
                    for name in names:
                        try:
                            value = raw.get(name)
                        except Exception:
                            value = None
                        if value not in (None, ""):
                            return value
                    return ""

                genres = []
                try:
                    for gr in conn.execute("""
                        SELECT genre FROM item_genres
                        WHERE rating_key=?
                        ORDER BY rowid
                        LIMIT 12
                    """, (rk,)).fetchall():
                        g = str(gr[0] or "").strip()
                        if g and g not in genres:
                            genres.append(g)
                except Exception:
                    pass
                if not genres:
                    try:
                        for gr in raw.get("Genre") or raw.get("genre") or []:
                            g = str((gr or {}).get("tag") or (gr or {}).get("title") or (gr or {}).get("name") or "").strip()
                            if g and g not in genres:
                                genres.append(g)
                    except Exception:
                        pass

                directors = []
                try:
                    for dr in conn.execute("""
                        SELECT person_name FROM item_people
                        WHERE rating_key=? AND +person_type='director'
                        ORDER BY sort_order ASC, person_name COLLATE NOCASE
                        LIMIT 8
                    """, (rk,)).fetchall():
                        name = str(dr[0] or "").strip()
                        if name and name not in directors:
                            directors.append(name)
                except Exception:
                    pass
                if not directors:
                    try:
                        for dr in raw.get("Director") or raw.get("director") or []:
                            name = str((dr or {}).get("tag") or (dr or {}).get("title") or (dr or {}).get("name") or "").strip()
                            if name and name not in directors:
                                directors.append(name)
                    except Exception:
                        pass

                actor_rows = []
                try:
                    actor_rows = conn.execute("""
                        SELECT person_name, role, person_thumb, sort_order
                        FROM item_people
                        WHERE rating_key=? AND person_type='actor'
                        ORDER BY sort_order ASC, person_name COLLATE NOCASE
                        LIMIT 40
                    """, (rk,)).fetchall()
                except Exception:
                    actor_rows = []

                actors = []
                seen_actor_names = set()
                for ar in actor_rows:
                    name = str(ar[0] or "").strip()
                    if not name or name in seen_actor_names:
                        continue
                    seen_actor_names.add(name)
                    actors.append({
                        "Name": name,
                        "Role": str(ar[1] or "").strip(),
                        "Thumb": pkm_meta_override_r120.actor_photo(name) or _clean_external_image_url(ar[2] or ""),  # R120c
                    })
                if not actors:
                    try:
                        for ar in raw.get("Role") or raw.get("role") or raw.get("Cast") or raw.get("cast") or []:
                            name = str((ar or {}).get("tag") or (ar or {}).get("title") or (ar or {}).get("name") or "").strip()
                            if not name or name in seen_actor_names:
                                continue
                            seen_actor_names.add(name)
                            actors.append({
                                "Name": name,
                                "Role": str((ar or {}).get("role") or "").strip(),
                                "Thumb": _clean_external_image_url((ar or {}).get("thumb") or (ar or {}).get("thumbUrl") or ""),
                            })
                            if len(actors) >= 40:
                                break
                    except Exception:
                        pass

                duration_raw = row["duration"] or raw_get("duration") or ""
                view_offset = raw_get("viewOffset", "view_offset") or ""
                duration_text = self._duration_text(duration_raw)
                play_button_label = self._play_button_label(view_offset, duration_raw, "")
                content_rating = pkm_info_data.localize_content_rating(raw_get("contentRating", "content_rating", "mpaa") or "")
                rating = raw_get("rating", "audienceRating", "userRating") or ""
                premiered = raw_get("originallyAvailableAt", "originally_available_at", "premiered") or ""
                art = _clean_external_image_url(row["art"] or raw_get("art"))
                thumb = _clean_external_image_url(row["thumb"] or raw_get("thumb"))
                summary = row["summary"] or raw_get("summary", "plot") or ""
                title = row["title"] or raw_get("title") or ""
                plex_type = row["plex_type"] or raw_get("type") or ""
                kodi_type = row["kodi_type"] or ("tvshow" if plex_type == "show" else plex_type or "video")
                year = row["year"] or raw_get("year") or ""
                show_title_result = row["show_title"] or raw_get("grandparentTitle", "showTitle") or ""
                episode_title_result = ""
                if plex_type == "episode":
                    episode_title_result = pkm_info_data.normalize_episode_title(title, row["episode"] or raw_get("index"))
                    show_key = str(row["grandparent_rating_key"] or raw_get("grandparentRatingKey", "grandparent_rating_key") or "").strip()
                    show_raw = {}
                    show_row = None
                    if show_key:
                        try:
                            show_row = conn.execute("""
                                SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title,
                                       year, summary, duration, added_at, updated_at, thumb, art, part_key,
                                       view_count, last_viewed_at, parent_rating_key, grandparent_rating_key,
                                       show_title, season, episode, raw_json
                                FROM items
                                WHERE rating_key=?
                                LIMIT 1
                            """, (show_key,)).fetchone()
                        except Exception:
                            show_row = None
                    if show_row is not None:
                        try:
                            if show_row["raw_json"]:
                                show_raw = json.loads(show_row["raw_json"] or "{}")
                        except Exception:
                            show_raw = {}

                    def show_raw_get(*names):
                        for name in names:
                            try:
                                value = show_raw.get(name)
                            except Exception:
                                value = None
                            if value not in (None, ""):
                                return value
                        return ""

                    show_title_db = ""
                    if show_row is not None:
                        show_title_db = show_row["title"] or show_raw_get("title") or ""
                    show_title_result = show_title_result or show_title_db
                    if show_title_result:
                        title = show_title_result

                    show_genres = []
                    if show_key:
                        try:
                            for gr in conn.execute("""
                                SELECT genre FROM item_genres
                                WHERE rating_key=?
                                ORDER BY rowid
                                LIMIT 12
                            """, (show_key,)).fetchall():
                                g = str(gr[0] or "").strip()
                                if g and g not in show_genres:
                                    show_genres.append(g)
                        except Exception:
                            pass
                    if not show_genres:
                        try:
                            for gr in show_raw.get("Genre") or show_raw.get("genre") or []:
                                g = str((gr or {}).get("tag") or (gr or {}).get("title") or (gr or {}).get("name") or "").strip()
                                if g and g not in show_genres:
                                    show_genres.append(g)
                        except Exception:
                            pass
                    if not genres and show_genres:
                        genres = show_genres

                    show_directors = []
                    if show_key:
                        try:
                            for dr in conn.execute("""
                                SELECT person_name FROM item_people
                                WHERE rating_key=? AND +person_type='director'
                                ORDER BY sort_order ASC, person_name COLLATE NOCASE
                                LIMIT 8
                            """, (show_key,)).fetchall():
                                name = str(dr[0] or "").strip()
                                if name and name not in show_directors:
                                    show_directors.append(name)
                        except Exception:
                            pass
                    if not show_directors:
                        try:
                            for dr in show_raw.get("Director") or show_raw.get("director") or []:
                                name = str((dr or {}).get("tag") or (dr or {}).get("title") or (dr or {}).get("name") or "").strip()
                                if name and name not in show_directors:
                                    show_directors.append(name)
                        except Exception:
                            pass
                    if not directors and show_directors:
                        directors = show_directors

                    show_actors = []
                    show_seen_actor_names = set()
                    if show_key:
                        try:
                            show_actor_rows = conn.execute("""
                                SELECT person_name, role, person_thumb, sort_order
                                FROM item_people
                                WHERE rating_key=? AND person_type='actor'
                                ORDER BY sort_order ASC, person_name COLLATE NOCASE
                                LIMIT 40
                            """, (show_key,)).fetchall()
                        except Exception:
                            show_actor_rows = []
                        for ar in show_actor_rows:
                            name = str(ar[0] or "").strip()
                            if not name or name in show_seen_actor_names:
                                continue
                            show_seen_actor_names.add(name)
                            show_actors.append({
                                "Name": name,
                                "Role": str(ar[1] or "").strip(),
                                "Thumb": pkm_meta_override_r120.actor_photo(name) or _clean_external_image_url(ar[2] or ""),  # R120c
                            })
                    if not show_actors:
                        try:
                            for ar in show_raw.get("Role") or show_raw.get("role") or show_raw.get("Cast") or show_raw.get("cast") or []:
                                name = str((ar or {}).get("tag") or (ar or {}).get("title") or (ar or {}).get("name") or "").strip()
                                if not name or name in show_seen_actor_names:
                                    continue
                                show_seen_actor_names.add(name)
                                show_actors.append({
                                    "Name": name,
                                    "Role": str((ar or {}).get("role") or "").strip(),
                                    "Thumb": _clean_external_image_url((ar or {}).get("thumb") or (ar or {}).get("thumbUrl") or ""),
                                })
                                if len(show_actors) >= 40:
                                    break
                        except Exception:
                            pass
                    if not actors and show_actors:
                        actors = show_actors
                    if show_row is not None:
                        if not content_rating:
                            content_rating = pkm_info_data.localize_content_rating(show_raw_get("contentRating", "content_rating", "mpaa") or "")
                        if not premiered:
                            premiered = show_raw_get("originallyAvailableAt", "originally_available_at", "premiered") or ""
                        if not rating:
                            rating = show_raw_get("rating", "audienceRating", "userRating") or ""
                        if not year:
                            year = show_row["year"] or show_raw_get("year") or ""
                        show_art = _clean_external_image_url(show_row["art"] or show_raw_get("art"))
                        show_thumb = _clean_external_image_url(show_row["thumb"] or show_raw_get("thumb"))
                        if show_art:
                            art = show_art
                        if show_thumb:
                            thumb = show_thumb
                        if not summary:
                            summary = show_row["summary"] or show_raw_get("summary", "plot") or ""
                    _log("INFO_DB_EPISODE_SHOW_MERGE episode_key=%s show_key=%s title=%s summary=%s genre=%s director=%s cast=%d source=%s" % (
                        rk,
                        show_key,
                        _short_log_value(title, 80),
                        "1" if summary else "0",
                        "1" if genres else "0",
                        "1" if directors else "0",
                        len(actors[:8]),
                        reason or "",
                    ))
                result = {
                    "Title": title,
                    "TitleDisplay": self._title_display_text(title),
                    "EpisodeTitle": episode_title_result,
                    "OriginalTitle": row["original_title"] or raw_get("originalTitle") or "",
                    "SortTitle": row["sort_title"] or title,
                    "Summary": summary,
                    "Year": year,
                    "Premiered": premiered,
                    "Duration": duration_raw,
                    "DurationText": duration_text,
                    "ViewOffset": view_offset,
                    "PlayButtonLabel": play_button_label,
                    "Genre": ", ".join(genres),
                    "Director": ", ".join(directors),
                    "Writer": "",
                    "Cast": " / ".join([a.get("Name") or "" for a in actors if a.get("Name")]),
                    "CastSlots": actors[:8],
                    "ContentRating": content_rating,
                    "Rating": rating,
                    "Poster": thumb,
                    "Fanart": art,
                    "KodiType": kodi_type,
                    "PlexType": plex_type,
                    "SectionId": row["section_id"] or "",
                    "PartKey": row["part_key"] or "",
                    "ShowTitle": show_title_result or row["show_title"] or "",
                    "Season": row["season"] or "",
                    "Episode": row["episode"] or "",
                    "ParentRatingKey": row["parent_rating_key"] or "",
                    "GrandparentRatingKey": row["grandparent_rating_key"] or "",
                    "MetaLine": self._home_meta_line(plex_type, show_title_result or title, row["season"] or "", row["episode"] or "", year, duration_text, content_rating, rating, row["added_at"] or premiered or ""),
                    "AddedAt": row["added_at"] or "",
                    "UpdatedAt": row["updated_at"] or "",
                }
                if len(cache) > 600:
                    try:
                        cache.clear()
                    except Exception:
                        cache = {}
                cache[rk] = result
                self._info_local_db_cache = cache
                _db_cast_names, _db_cast_real = self._cast_slots_thumb_stats(actors[:8])
                _log("INFO_DB_FALLBACK hit=db rating_key=%s title=%s summary=%s genre=%s director=%s cast=%d cast_real=%d cast1=%s cast1_thumb=%s source=%s elapsed=%.1fms" % (
                    rk,
                    _short_log_value(title, 80),
                    "1" if summary else "0",
                    "1" if genres else "0",
                    "1" if directors else "0",
                    len(actors[:8]),
                    _db_cast_real,
                    _short_log_value(actors[0].get("Name") if actors else "", 80),
                    _short_log_value(actors[0].get("Thumb") if actors else ""),
                    reason or "",
                    (time.time() - start) * 1000.0,
                ))
                return result
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        except Exception:
            _log("INFO_DB_FALLBACK failed rating_key=%s source=%s err=%s" % (
                rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return None

    def _apply_local_db_info_to_li(self, li, reason="", update_visual=True):
        try:
            if li is None:
                return False
            rk = li.getProperty("PlexKM.RatingKey") or ""
            if not rk:
                return False
            cached = self._load_info_cache_from_local_db(rk, reason=reason)
            if not cached:
                return False
            memory_cache = getattr(self, "_home_meta_enrich_cache", None)
            if not isinstance(memory_cache, dict):
                memory_cache = {}
                self._home_meta_enrich_cache = memory_cache
            current = memory_cache.get(rk) or {}
            cached_slots = (cached or {}).get("CastSlots") or []
            current_slots = (current or {}).get("CastSlots") or []
            cached_names, cached_real = self._cast_slots_thumb_stats(cached_slots)
            current_names, current_real = self._cast_slots_thumb_stats(current_slots)

            if not current or not (current.get("CastSlots") or current.get("Genre") or current.get("Director")):
                memory_cache[rk] = cached
            else:
                merged = dict(cached)
                merged.update(current)
                # v1215: never let a transient Home/meta cache with actor names
                # but empty/placeholder thumbs overwrite DB-backed person_thumb.
                # This is the exact race seen when Info is opened while startup
                # sync is still touching Home caches: text metadata is valid, but
                # cast artwork regresses to grey placeholders.
                if cached_names > 0 and cached_real > current_real:
                    merged["CastSlots"] = cached_slots
                    merged["Cast"] = cached.get("Cast") or current.get("Cast") or ""
                    _log("INFO_DB_CAST_PRIORITY rating_key=%s source=%s cached_names=%d cached_real=%d current_names=%d current_real=%d action=use_db_cast" % (
                        rk, reason or "", cached_names, cached_real, current_names, current_real
                    ), xbmc.LOGWARNING)
                elif not current.get("CastSlots") and cached.get("CastSlots"):
                    merged["CastSlots"] = cached.get("CastSlots")
                    merged["Cast"] = cached.get("Cast") or current.get("Cast") or ""
                memory_cache[rk] = merged
            ok = self._apply_cached_info_to_li(li, reason="local_db_%s" % (reason or ""), update_visual=update_visual)
            _log("INFO_DB_FALLBACK apply rating_key=%s ok=%s cast1=%s source=%s" % (
                rk, "1" if ok else "0", _short_log_value(li.getProperty("PlexKM.Cast1.Name"), 80), reason or ""
            ))
            return ok
        except Exception:
            _log("INFO_DB_FALLBACK apply_failed source=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _apply_cached_info_to_li(self, li, reason="", update_visual=True):
        """Use Home focus/enrich cache for DialogVideoInfo without another PMS call.

        update_visual=False is used by background focus prewarm.  In that mode
        we intentionally avoid visual InfoTag/cast/art mutation because those
        calls can make Kodi re-render poster cells while the user is moving focus.
        The PlexKM.* properties are still prepared so opening Info remains fast.
        """
        try:
            rating_key = li.getProperty("PlexKM.RatingKey") or ""
            cached = self._home_meta_enrich_cache.get(rating_key) if rating_key else None
            if not cached:
                _log("CAST_TRACE reuse_skip reason=no_home_cache rating_key=%s source=%s" % (rating_key, reason), xbmc.LOGWARNING)
                return False
            if not self._meta_props_useful(cached):
                # Cast/summary-only cache is not enough for the Info page.  Keep
                # retrying until episode+show metadata is complete.
                _log("CAST_TRACE reuse_skip reason=sparse_home_cache rating_key=%s source=%s" % (rating_key, reason), xbmc.LOGWARNING)
                return False

            plex_type = li.getProperty("PlexKM.Type") or ""
            kodi_type = li.getProperty("PlexKM.KodiType") or ("tvshow" if plex_type in ("show", "season") else plex_type or "video")
            title = cached.get("Title") or li.getProperty("PlexKM.Title") or li.getLabel() or ""
            episode_title = cached.get("EpisodeTitle") or li.getProperty("PlexKM.EpisodeTitle") or ""
            show_title = cached.get("ShowTitle") or li.getProperty("PlexKM.ShowTitle") or ""
            if plex_type in ("episode", "season") and show_title:
                if plex_type == "season" or not title or title == episode_title:
                    title = show_title
            summary = cached.get("Summary") or li.getProperty("PlexKM.Summary") or ""
            # v2511: the inline Info synopsis occupies the exact same 740x156 / 716px
            # text surface as Home.  Use the Home width-aware three-line formatter
            # so the atomic Home->Info ownership switch cannot change wrapping.
            summary_display = self._home_summary_display_text_v2179(summary)
            year = _safe_int(cached.get("Year") or li.getProperty("PlexKM.Year"), 0)
            duration_text = cached.get("DurationText") or ""
            view_offset = cached.get("ViewOffset") or li.getProperty("PlexKM.ViewOffset") or ""
            play_button_label = ""
            duration = _safe_int(li.getProperty("PlexKM.Duration"), 0)
            if not duration and duration_text:
                try:
                    if "시간" in duration_text:
                        import re
                        nums = [int(x) for x in re.findall(r"\d+", duration_text)]
                        if len(nums) >= 2:
                            duration = nums[0] * 3600 + nums[1] * 60
                        elif nums:
                            duration = nums[0] * 60
                    elif "분" in duration_text:
                        import re
                        nums = [int(x) for x in re.findall(r"\d+", duration_text)]
                        duration = (nums[0] * 60) if nums else 0
                except Exception:
                    duration = 0
            play_button_label = self._play_button_label(view_offset, duration, li.getProperty("PlexKM.ResumeDurationMs") or cached.get("ResumeDurationMs") or "")
            genre = self._listitem_genre_fallback(li, cached.get("Genre") or li.getProperty("PlexKM.Genre") or "")
            director = cached.get("Director") or li.getProperty("PlexKM.Director") or ""
            writer = li.getProperty("PlexKM.Writer") or ""
            content_rating = cached.get("ContentRating") or li.getProperty("PlexKM.ContentRating") or ""
            rating = cached.get("Rating") or li.getProperty("PlexKM.Rating") or ""
            premiered = cached.get("Premiered") or li.getProperty("PlexKM.Premiered") or ""
            meta_line = cached.get("MetaLine") or li.getProperty("PlexKM.MetaLine") or ""
            cast_line = cached.get("Cast") or li.getProperty("PlexKM.Cast") or ""
            thumb = cached.get("Poster") or li.getProperty("PlexKM.Thumb") or li.getArt("poster") or li.getArt("thumb") or ""
            # v229: never let an episode metadata still replace the show poster in
            # Continue Watching/Home.  The initial row already stores the desired
            # show poster in PlexKM.Thumb; keep using it when cached metadata is
            # applied to the visual ListItem.
            if plex_type in ("episode", "season"):
                show_poster = li.getProperty("PlexKM.Thumb") or self._episode_show_poster_from_key(li.getProperty("PlexKM.GrandparentRatingKey") or "")
                if show_poster:
                    if thumb and thumb != show_poster:
                        _log("EPISODE_POSTER_LOCK keep_show_poster rating_key=%s old=%s new=%s source=%s" % (rating_key, _short_log_value(thumb), _short_log_value(show_poster), reason))
                    thumb = show_poster
            art = cached.get("Fanart") or li.getProperty("PlexKM.Art") or li.getArt("fanart") or ""
            cast_slots = cached.get("CastSlots") or []
            kodi_cast = _kodi_cast_from_slots(cast_slots)

            info = {
                "title": title,
                "sorttitle": li.getProperty("PlexKM.SortTitle") or title,
                "originaltitle": li.getProperty("PlexKM.OriginalTitle") or "",
                "plot": summary,
                "year": year,
                "duration": duration,
                "genre": genre,
                "director": director,
                "writer": writer,
                "mpaa": content_rating,
                "rating": float(rating) if rating else 0.0,
                "mediatype": kodi_type,
                "cast": [c.get("name", "") for c in kodi_cast],
                "castandrole": [(c.get("name", ""), c.get("role", "")) for c in kodi_cast],
            }
            season_value = cached.get("Season") or li.getProperty("PlexKM.Season") or ""
            episode_value = cached.get("Episode") or li.getProperty("PlexKM.Episode") or ""
            if plex_type in ("episode", "season"):
                info.update({
                    "tvshowtitle": show_title or li.getProperty("PlexKM.ShowTitle") or title or "",
                    "season": _safe_int(season_value, 0),
                })
                if plex_type == "episode":
                    info["episode"] = _safe_int(episode_value, 0)
            if update_visual:
                apply_video_info(li, info, cast=kodi_cast)
                try:
                    li.setArt({"poster": thumb or "", "thumb": thumb or "", "icon": thumb or "", "fanart": art or ""})
                except Exception:
                    pass

            remaining_text, remaining_icon = self._remaining_time_props(li.getProperty("PlexKM.Duration") or duration, view_offset)
            props = {
                "InfoLoaded": "1", "InfoLoadedRatingKey": rating_key, "KodiType": kodi_type, "Type": plex_type, "Title": title,
                "TitleDisplay": self._title_display_text(title), "EpisodeTitle": episode_title, "ShowTitle": show_title,
                "Season": season_value, "Episode": episode_value,
                "ParentRatingKey": cached.get("ParentRatingKey") or li.getProperty("PlexKM.ParentRatingKey") or "",
                "GrandparentRatingKey": cached.get("GrandparentRatingKey") or li.getProperty("PlexKM.GrandparentRatingKey") or "",
                "Summary": summary,
                "SummaryDisplay": summary_display,
                "Year": year, "Duration": li.getProperty("PlexKM.Duration") or duration, "DurationText": duration_text,
                "ViewOffset": view_offset, "RemainingText": remaining_text, "RemainingIcon": remaining_icon, "PlayButtonLabel": play_button_label,
                "Premiered": premiered, "MetaLine": meta_line,
                # v2313: Home/Info share the exact visual metadata-row structure.
                # Keep certification separate so XML can use the same 10px item gaps as Home.
                "MetaLineBaseV2313": self._home_meta_line_base_v2291(plex_type, season_value, episode_value, year, duration_text),
                "Genre": genre, "Director": director, "Writer": writer, "Cast": cast_line,
                "ContentRating": content_rating, "Rating": rating, "Thumb": thumb, "Art": art,
            }
            for k, v in props.items():
                li.setProperty("PlexKM.%s" % k, str(v or ""))
            for idx in range(1, 9):
                slot = cast_slots[idx - 1] if idx <= len(cast_slots) else {}
                clean_thumb = _clean_external_image_url(slot.get("Thumb") or "")
                li.setProperty("PlexKM.Cast%d.Name" % idx, str(slot.get("Name") or ""))
                li.setProperty("PlexKM.Cast%d.Role" % idx, str(slot.get("Role") or ""))
                li.setProperty("PlexKM.Cast%d.Thumb" % idx, clean_thumb)
                # v204: ListItem objects/properties can survive focus/info reuse.
                # Clear per-slot cache metadata whenever fresh cast data is copied
                # from the current ratingKey, otherwise a previous movie's local
                # circular cache can be incorrectly reused for this slot.
                li.setProperty("PlexKM.Cast%d.OriginalThumb" % idx, clean_thumb)
                li.setProperty("PlexKM.Cast%d.LocalThumb" % idx, "")
                li.setProperty("PlexKM.Cast%d.ThumbSource" % idx, "")
                li.setProperty("PlexKM.Cast%d.SourceRatingKey" % idx, rating_key)
                _log("CAST_TRACE reuse_property_set slot=%d name=%s role=%s thumb=%s" % (
                    idx,
                    _short_log_value(slot.get("Name") or "", 80),
                    _short_log_value(slot.get("Role") or "", 80),
                    _short_log_value(slot.get("Thumb") or ""),
                ))
            _log("CAST_TRACE reuse_done rating_key=%s cast_count=%d reason=%s" % (rating_key, len(cast_slots), reason))
            return True
        except Exception:
            _log("CAST_TRACE reuse_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return False

    # v2332: _enrich_item_for_info() remains removed.  Visible-page repair now
    # happens in the synchronous PREPARE stage while the completed source page
    # stays on screen.  _refresh_info_properties_after_open() is legacy-only and
    # is not scheduled by the active Info open path.

    def _info_schedule_rating_stack_postvisible_v2678(self, rk, title="", original_title="", year="", item_rating=""):
        """v2678: ratings are decoration on weak Android; never block Info reveal."""
        try:
            token = int(getattr(self, "_info_rating_async_token_v2678", 0) or 0) + 1
            self._info_rating_async_token_v2678 = token
            def _worker():
                t0 = time.time()
                try:
                    # Protect the action-bar -> cast-row animation window.
                    time.sleep(1.4)
                    if token != int(getattr(self, "_info_rating_async_token_v2678", 0) or 0):
                        return
                    cine = self._home_cine21_rating_props(rk, title=title, original_title=original_title, year=year)
                    watcha = self._info_watcha_point_props_v2627(rk, title=title, original_title=original_title, year=year)
                    imdb = self._home_imdb_rating_value(item_rating or self._home_db_imdb_rating_point_v2630(rk))
                    if token != int(getattr(self, "_info_rating_async_token_v2678", 0) or 0):
                        return
                    win = xbmcgui.Window(10000)
                    if str(win.getProperty("PlexKM.Info.RatingKey") or "") != str(rk or ""):
                        return
                    critic = cine.get("CriticRating", "") or ""
                    audience = cine.get("AudienceRating", "") or ""
                    self._info_set_property_all("PlexKM.Info.Cine21CriticRating", critic)
                    self._info_set_property_all("PlexKM.Info.Cine21AudienceRating", audience)
                    self._info_set_property_all("PlexKM.Info.Cine21BarDisplay", self._home_cine21_bar_display(cine))
                    self._info_set_property_all("PlexKM.Info.WatchaRating", watcha.get("Rating", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaCount", watcha.get("Count", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaDisplay", watcha.get("Display", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaBarDisplay", self._home_watcha_bar_display(watcha))
                    self._info_set_property_all("PlexKM.Info.ImdbRating", imdb)
                    _log("INFO_RATING_STACK_POSTVISIBLE_V2678 rating_key=%s elapsed_ms=%d gui_entry_block=0" % (rk, int((time.time()-t0)*1000)))
                except Exception:
                    _log("INFO_RATING_STACK_POSTVISIBLE_FAILED_V2678 rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            threading.Thread(target=_worker, name="PKMInfoRatingsV2678-%s" % rk, daemon=True).start()
            return True
        except Exception:
            return False

    def _info_widget_rebuild_request_v2082(self, rating_key, actor_hint="", genre_hint="", source_control=0, is_tv=False, reason=""):
        """Queue one reentrant actor-work rebuild without touching native controls.

        v2083 stages the native bind at the target cast row (6100 movie / 6110
        TV).  At that focus milestone the old actor-work row no longer owns
        native focus and the target actor-work posters are still below the
        viewport.  No elapsed-time heuristic participates in the decision.
        """
        rk = str(rating_key or "").strip()
        if not rk:
            return False
        target_focus = 6110 if bool(is_tv) else 6100
        self._info_widget_rebuild_pending_v2082 = {
            "rating_key": rk,
            "actor_hint": str(actor_hint or ""),
            "genre_hint": str(genre_hint or ""),
            "source_control": int(source_control or 0),
            "target_focus": int(target_focus),
            "is_tv": bool(is_tv),
            "reason": str(reason or ""),
        }
        _log("INFO_WIDGET_REBUILD_REQUEST_V2083 rating_key=%s source_control=%s target_focus=%s is_tv=%d reason=%s native_mutation=0" % (
            rk, source_control or 0, target_focus, 1 if is_tv else 0, reason or ""
        ))
        return True

    def _info_widget_rebuild_try_commit_v2082(self, focus_id=None, reason=""):
        """Commit a queued actor-work rebuild only after focus leaves its source rows.

        There is deliberately no timer/sleep and no Python focus correction here.
        Kodi/XML owns focus.  This function merely waits for an observed safe
        focus owner before resetting/rebinding the related-work ControlLists.
        """
        pending = getattr(self, "_info_widget_rebuild_pending_v2082", None)
        if not isinstance(pending, dict) or not pending.get("rating_key"):
            return False
        if getattr(self, "_info_widget_rebuild_committing_v2082", False):
            return False
        if getattr(self, "_info_reentrant_open_in_progress_v2082", False):
            return False
        rk = str(pending.get("rating_key") or "")
        try:
            active = (
                self.getProperty("PlexKM.Info.RatingKey")
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey")
                or xbmcgui.Window(13000).getProperty("PlexKM.Info.RatingKey")
                or ""
            )
        except Exception:
            active = ""
        if active and active != rk:
            self._info_widget_rebuild_pending_v2082 = None
            _log("INFO_WIDGET_REBUILD_STALE_DROP_V2082 requested=%s active=%s reason=%s" % (
                rk, active, reason or ""
            ))
            return False
        try:
            inline_active = (
                self.getProperty("PlexKM.Info.InlineActive") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
            )
        except Exception:
            inline_active = False
        if not inline_active:
            return False
        try:
            fid = int(self._safe_focus_id() if focus_id is None else focus_id)
        except Exception:
            fid = -1
        target_focus = int(pending.get("target_focus") or (6110 if pending.get("is_tv") else 6100))
        # R100b: an incremental bind that already started must be allowed to
        # finish wherever focus went.  Remaining chunks only append to the row
        # in progress or fill rows that are still empty (not focusable), so no
        # focused list is reset.  Before this, moving focus off the cast row
        # mid-bind froze the related-work rows at 1 poster on Shield.
        if fid != target_focus and self._r88_rebuild_in_progress(rk):
            _log("INFO_WIDGET_REBUILD_CONTINUE_ANY_FOCUS_R100 rating_key=%s focus=%s target_focus=%s reason=%s" % (
                rk, fid, target_focus, reason or ""))
        elif fid != target_focus and 5000 <= fid < 6200:
            # R105: focus is in the Info top area (play buttons / episodes /
            # cast), i.e. above the actor-work rows, so binding those rows
            # cannot move it.  Before, the rows stayed empty until the user
            # reached the cast row (샤먼: data ready at +2.7 s, shown at +9 s).
            sig_r105 = "%s:%s:early" % (rk, fid)
            if getattr(self, "_info_widget_rebuild_last_defer_sig_v2082", "") != sig_r105:
                self._info_widget_rebuild_last_defer_sig_v2082 = sig_r105
                _log("INFO_WIDGET_REBUILD_EARLY_BIND_R105 rating_key=%s focus=%s target_focus=%s reason=%s" % (
                    rk, fid, target_focus, reason or ""))
        elif fid != target_focus:
            sig = "%s:%s:%s" % (rk, fid, target_focus)
            if getattr(self, "_info_widget_rebuild_last_defer_sig_v2082", "") != sig:
                self._info_widget_rebuild_last_defer_sig_v2082 = sig
                _log("INFO_WIDGET_REBUILD_WAIT_STAGE_V2083 rating_key=%s focus=%s target_focus=%s source_control=%s reason=%s native_mutation=0" % (
                    rk, fid, target_focus, pending.get("source_control") or 0, reason or ""
                ))
            return False
        # v2383: never execute the 2-4s actor DB scan on the GUI thread.  The
        # post-visible worker must have produced a matching data snapshot first.
        stage_v2383 = getattr(self, "_info_widget_rows_precomputed_v2332", None)
        if not (isinstance(stage_v2383, dict) and str(stage_v2383.get("rating_key") or "") == rk):
            sig_v2383 = "%s:%s:data" % (rk, fid)
            if getattr(self, "_info_widget_rebuild_last_data_wait_sig_v2383", "") != sig_v2383:
                self._info_widget_rebuild_last_data_wait_sig_v2383 = sig_v2383
                _log("INFO_WIDGET_REBUILD_WAIT_DATA_V2383 rating_key=%s focus=%s target_focus=%s reason=%s gui_block=0" % (
                    rk, fid, target_focus, reason or ""
                ))
            return False
        self._info_widget_rebuild_last_data_wait_sig_v2383 = ""
        try:
            self._info_widget_rebuild_committing_v2082 = True
            self._info_widget_rebuild_last_defer_sig_v2082 = ""
            _log("INFO_WIDGET_REBUILD_COMMIT_BEGIN_V2083 rating_key=%s safe_focus=%s target_focus=%s source_control=%s reason=%s visibility=offscreen" % (
                rk, fid, target_focus, pending.get("source_control") or 0, reason or ""
            ))
            _budget_r88 = self._r88_rebuild_budget_ms()
            if _budget_r88 > 0:
                _done_r88, count = self._info_movie_populate_incremental_r88(
                    rk, reason="reentrant_offscreen_commit_v2083:%s" % (reason or "cast_focus"),
                    actor_hint=pending.get("actor_hint") or "",
                    genre_hint=pending.get("genre_hint") or "",
                    budget_ms=_budget_r88,
                )
                if not _done_r88:
                    # R88: more chunks to bind; keep the request and come back
                    # in a later GUI callback instead of blocking this one.
                    self._r88_schedule_rebuild_ping()
                    return False
            else:
                count = self._info_movie_populate_cine21_widgets(
                    rk, reason="reentrant_offscreen_commit_v2083:%s" % (reason or "cast_focus"),
                    actor_hint=pending.get("actor_hint") or "",
                    genre_hint=pending.get("genre_hint") or "",
                )
            _bind_state_v2603 = getattr(self, "_info_actor_widgets_complete_v2603", None)
            _bind_complete_v2603 = bool(
                isinstance(_bind_state_v2603, dict)
                and str(_bind_state_v2603.get("rating_key") or "") == rk
                and bool(_bind_state_v2603.get("complete"))
            )
            if _bind_complete_v2603:
                self._info_widget_rebuild_pending_v2082 = None
            else:
                # Keep the request alive. A later Kodi/XML focus event or Android
                # commit ping retries the same staged rows instead of freezing a
                # one-row native bind as final.
                try:
                    pending["retry_v2603"] = int(pending.get("retry_v2603") or 0) + 1
                except Exception:
                    pending["retry_v2603"] = 1
                self._info_widget_rebuild_pending_v2082 = pending
                _log("INFO_WIDGET_REBUILD_PARTIAL_RETRY_V2603 rating_key=%s safe_focus=%s expected_rows=%s rendered_rows=%s retry=%s staged_rows_retained=1" % (
                    rk, fid,
                    (_bind_state_v2603 or {}).get("expected_rows") if isinstance(_bind_state_v2603, dict) else "",
                    (_bind_state_v2603 or {}).get("rendered_rows") if isinstance(_bind_state_v2603, dict) else "",
                    pending.get("retry_v2603") or 0
                ))
                if self._is_android_v2591() and int(pending.get("retry_v2603") or 0) <= 2:
                    try:
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    except Exception:
                        pass
            _log("INFO_WIDGET_REBUILD_COMMIT_DONE_V2603 rating_key=%s safe_focus=%s target_focus=%s items=%s complete=%d focus_write=0 visibility=offscreen" % (
                rk, fid, target_focus, count, 1 if _bind_complete_v2603 else 0
            ))
            return bool(_bind_complete_v2603)
        except Exception:
            _log("INFO_WIDGET_REBUILD_COMMIT_FAILED_V2083 rating_key=%s focus=%s err=%s" % (
                rk, fid, traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGWARNING)
            return False
        finally:
            self._info_widget_rebuild_committing_v2082 = False

    def _info_movie_widget_clear(self):
        try:
            self._info_movie_widgets_rating_key = ""
            # v2398: the movie More cue follows an explicit renderer-owned state.
            # Container(...).NumItems is not reliable while the Info body is being
            # atomically composed/offscreen, so clear the published state together
            # with the native actor-work controls.
            try:
                self._info_set_property_all("PlexKM.Info.HasMovieActorWorks", "0")
            except Exception:
                pass
            for _widget_ids_v2066 in (INFO_MOVIE_WIDGET_ROW_IDS, INFO_TV_ACTOR_WIDGET_ROW_IDS):
                for idx, cid in enumerate(_widget_ids_v2066):
                    try:
                        self.getControl(cid).reset()
                    except Exception:
                        pass
                    try:
                        self._info_set_property_all("PlexKM.Info.MovieWidget.Row%d.Title" % idx, "")
                    except Exception:
                        pass
        except Exception:
            pass

    def _info_movie_row_tuple_from_db_row(self, row):
        try:
            return (
                row["rating_key"], row["section_id"], row["plex_type"], row["kodi_type"], row["title"],
                row["original_title"], row["sort_title"], row["year"], row["summary"], row["duration"],
                row["added_at"], row["updated_at"], row["thumb"], row["art"], row["media_file"], row["part_key"],
                row["view_count"], row["last_viewed_at"], row["show_title"], row["season"], row["episode"],
                row["parent_rating_key"], row["grandparent_rating_key"]
            )
        except Exception:
            return tuple(row or ())

    def _info_movie_cine21_widget_rows(self, rating_key, limit=24, actor_hint="", genre_hint=""):
        """Build up to three lead-actor works rows for movie and TV Info.

        v2138 policy (keeps v1966 ordering intent):
        - Read the first three actors by Plex/item_people sort_order.
        - Each actor gets one row of other movie/TV-show works, rating-first.
        - Rating-qualified works stay first, but they no longer suppress the rest of
          the actor's available works. Fill the remaining row capacity from the
          non-qualified candidates in the existing DB ranking order.
        - Candidate discovery/ranking is local DB-only; v2350 prefers direct Plex
          metadata validation and requires a real poster.  A transient metadata
          timeout may use the recent v2349 pre-Home server membership proof instead
          of erasing all actor rows.  Proven stale/deleted/no-poster candidates are
          still omitted.
        """
        t0 = time.time()
        result = []
        rk = str(rating_key or "").strip()
        if not rk:
            return result

        dbp = self._profile_db_path()
        if not dbp or not os.path.exists(dbp):
            _log("INFO_ACTOR_WIDGETS_SKIP_V1966 reason=no_db rating_key=%s db=%s" % (rk, dbp or ""), xbmc.LOGWARNING)
            return result

        # v2358: keep the v2332 contract -- the Info page is still published only
        # after every actor-work row is ready -- but stop paying the same work on
        # every episode/restart.  TV episode/season pages share the show-level actor
        # source, so cache by that canonical source key rather than by the selected
        # episode ratingKey.  Persist the fully composed, authority-filtered rows to
        # disk and bind them only while the startup server-authority proof fingerprint
        # is unchanged.  This makes a cache hit complete (not progressive) and safe
        # across Kodi restarts; any Plex section/local-membership drift invalidates it.
        _actor_source_cache_key_v2358, _authority_fp_v2358, _page_key_v2351, _restore_actor_rows_v2358 = self._info_movie_cine21_widget_rows_step1(dbp, limit, rk)
        try:
            _page_cache_v2351 = getattr(self, "_info_actor_widget_page_cache_v2351", None)
            if not isinstance(_page_cache_v2351, dict):
                _page_cache_v2351 = {}
                self._info_actor_widget_page_cache_v2351 = _page_cache_v2351
            _page_entry_v2351 = _page_cache_v2351.get(_page_key_v2351)
            if isinstance(_page_entry_v2351, dict) and "rows" in _page_entry_v2351:
                _page_age_v2351 = max(0.0, time.time() - float(_page_entry_v2351.get("ts") or 0.0))
                if (
                    _page_age_v2351 <= 21600.0
                    and _authority_fp_v2358
                    and str(_page_entry_v2351.get("authority_fp") or "") == _authority_fp_v2358
                ):
                    _cached_rows_v2351 = _restore_actor_rows_v2358(_page_entry_v2351.get("rows") or [])
                    _log("INFO_ACTOR_WIDGETS_PAGE_CACHE_HIT_V2358 rating_key=%s source_key=%s rows=%d age_ms=%d complete_before_visible=1 db_query=0 plex_probe=0" % (
                        rk, _actor_source_cache_key_v2358, len(_cached_rows_v2351), int(_page_age_v2351 * 1000.0)
                    ))
                    return _cached_rows_v2351
                _page_cache_v2351.pop(_page_key_v2351, None)
        except Exception:
            _page_cache_v2351 = {}

        _persistent_path_v2358 = os.path.join(os.path.dirname(dbp), "info_actor_rows_cache_v2358_r97.json")  # R97: rows now carry work_rating (평점순); old cache had none
        try:
            _persistent_cache_v2358 = getattr(self, "_info_actor_widget_persistent_cache_v2358", None)
            if not isinstance(_persistent_cache_v2358, dict):
                _persistent_cache_v2358 = {}
                if os.path.exists(_persistent_path_v2358):
                    with open(_persistent_path_v2358, "r", encoding="utf-8") as _f_v2358:
                        _loaded_v2358 = json.load(_f_v2358)
                    if isinstance(_loaded_v2358, dict):
                        _persistent_cache_v2358 = dict(_loaded_v2358.get("entries") or {})
                self._info_actor_widget_persistent_cache_v2358 = _persistent_cache_v2358
            _persist_entry_v2358 = _persistent_cache_v2358.get(_page_key_v2351)
            if isinstance(_persist_entry_v2358, dict) and "rows" in _persist_entry_v2358:
                _persist_age_v2358 = max(0.0, time.time() - float(_persist_entry_v2358.get("ts") or 0.0))
                if (
                    _persist_age_v2358 <= 604800.0
                    and _authority_fp_v2358
                    and str(_persist_entry_v2358.get("authority_fp") or "") == _authority_fp_v2358
                ):
                    _cached_rows_v2358 = _restore_actor_rows_v2358(_persist_entry_v2358.get("rows") or [])
                    _page_cache_v2351[_page_key_v2351] = {
                        "ts": time.time(), "rows": list(_cached_rows_v2358), "authority_fp": _authority_fp_v2358
                    }
                    _log("INFO_ACTOR_WIDGETS_PERSISTENT_CACHE_HIT_V2358 rating_key=%s source_key=%s rows=%d age_s=%d complete_before_visible=1 db_query=0 plex_probe=0" % (
                        rk, _actor_source_cache_key_v2358, len(_cached_rows_v2358), int(_persist_age_v2358)
                    ))
                    return _cached_rows_v2358
                _persistent_cache_v2358.pop(_page_key_v2351, None)
        except Exception:
            _persistent_cache_v2358 = {}

        def _f(v):
            try:
                return float(v or 0)
            except Exception:
                return 0.0

        def _quality_pass(row):
            imdb = max(_f(row["imdb_rating"]), _f(row["imdb_score"]), _f(row["imdb_audience"]), _f(row["imdb_user"]))
            return imdb >= 7.0 or _f(row["critic_rating"]) >= 6.0 or _f(row["audience_rating"]) >= 6.0

        # v2431: library sync/recommend-index construction is the authority boundary
        # for actor-work discovery.  item_people is populated together with items and
        # item_recommend_index_state, and startup/sync reconciliation removes Plex
        # ghosts.  Re-probing /library/metadata/<ratingKey> for every candidate here
        # duplicates work already completed by sync and is the source of multi-second
        # Info delays.  Info therefore trusts the synchronized local row and only
        # requires the stored real poster; there is zero Plex I/O in this path.
        _authority_call_state_v2350 = {"prehome_fallback_mode": False}

        def _actor_work_authority_v2350(row):
            rating_key_v2350 = str(row["rating_key"] or "").strip()
            expected_type_v2350 = str(row["plex_type"] or "").strip().lower()
            if not rating_key_v2350 or expected_type_v2350 not in ("movie", "show"):
                return None, "invalid_identity"
            thumb_v2350 = str(row["thumb"] or "").strip()
            art_v2350 = str(row["art"] or "").strip()
            if not thumb_v2350:
                return None, "no_poster"
            return {
                "thumb": thumb_v2350,
                "art": art_v2350,
                "source": "local_index_v2431",
            }, "ok_local_index_v2431"

        try:
            conn = sqlite3.connect(dbp, timeout=5.0)
            conn.row_factory = sqlite3.Row
            try:
                cur = conn.cursor()
                current = cur.execute("SELECT title, year, plex_type, parent_rating_key, grandparent_rating_key FROM items WHERE rating_key=? LIMIT 1", (rk,)).fetchone()
                actor_source_rk = rk
                if current:
                    _ptype_actor_v2066 = str(current["plex_type"] or "").strip().lower()
                    if _ptype_actor_v2066 == "episode":
                        actor_source_rk = str(current["grandparent_rating_key"] or current["parent_rating_key"] or rk).strip() or rk
                    elif _ptype_actor_v2066 == "season":
                        actor_source_rk = str(current["parent_rating_key"] or rk).strip() or rk
                current_source = cur.execute("SELECT title, year FROM items WHERE rating_key=? LIMIT 1", (actor_source_rk,)).fetchone()
                current_title = str((current_source["title"] if current_source else (current["title"] if current else "")) or "").strip()
                current_year = int((current_source["year"] if current_source else (current["year"] if current else 0)) or 0)

                # v2333: actor-work identity must not depend on the display language.
                # Plex can store the same person as Korean in one item/library and
                # English in another.  The old p.person_name=? lookup therefore
                # made actor-work rows appear to depend on whether the current
                # actor label happened to be Korean.  Keep the displayed label,
                # but resolve works by a small local identity component using
                # Plex Role tag_id + Role thumb + known aliases.  No network call
                # is made by the identity expansion itself.  v2342 performs the
                # separate authoritative candidate gate later, still before the
                # v2332 full-page READY-before-VISIBLE commit.
                actor_rows = cur.execute("""
                    SELECT person_name, IFNULL(tag_id,'') AS tag_id, IFNULL(person_thumb,'') AS person_thumb,
                           MIN(IFNULL(sort_order,999)) AS first_order
                    FROM item_people
                    WHERE rating_key=? AND person_type='actor' AND IFNULL(person_name,'')<>''
                    GROUP BY person_name, tag_id, person_thumb
                    ORDER BY first_order ASC, person_name COLLATE NOCASE
                    LIMIT 3
                """, (actor_source_rk,)).fetchall()
                actors = []
                for _ar_v2333 in actor_rows or []:
                    _name_v2333 = str(_ar_v2333["person_name"] or "").strip()
                    if not _name_v2333:
                        continue
                    actors.append({
                        "name": _name_v2333,
                        "tag_id": str(_ar_v2333["tag_id"] or "").strip(),
                        "thumb": str(_ar_v2333["person_thumb"] or "").strip(),
                    })
                _log("INFO_ACTOR_WIDGET_SOURCE_V2066 rating_key=%s actor_source=%s source_type=%s actors=%d" % (
                    rk, actor_source_rk, str((current["plex_type"] if current else "") or ""), len(actors)
                ))
                if not actors and actor_hint:
                    _hint_v2333 = str(actor_hint).strip()
                    if _hint_v2333:
                        actors = [{"name": _hint_v2333, "tag_id": "", "thumb": ""}]

                # v2432: item_people is already the synchronized actor/work index.
                # Do not rebuild an actor identity component inside Info.  The old
                # v2333 path expanded name/tag/thumb twice and then issued one large
                # OR query, which defeated the dedicated item_people indexes on a
                # large library.  Use exact indexed selectors instead.  Prefer the
                # Plex Role tag id; supplement by exact display name only when the
                # tag does not provide enough candidates, and use the stored Role
                # thumb only as a final alias bridge.  Every selector is a separate
                # equality predicate, so SQLite can use the existing type+tag/name/
                # thumb indexes without a multi-column OR scan.
                def _actor_exact_rows_v2432(field_v2432, value_v2432, query_limit_v2432):
                    value_v2432 = str(value_v2432 or "").strip()
                    if not value_v2432:
                        return []
                    if field_v2432 not in ("tag_id", "person_name", "person_thumb"):
                        return []
                    sql_v2432 = """
                        SELECT i.rating_key, i.section_id, i.plex_type, i.kodi_type, i.title, i.original_title, i.sort_title,
                               i.year, i.summary, i.duration, i.added_at, i.updated_at, i.thumb, i.art, i.media_file,
                               i.part_key, i.view_count, i.last_viewed_at, i.show_title, i.season, i.episode,
                               i.parent_rating_key, i.grandparent_rating_key,
                               cm.critic_rating, cm.audience_rating,
                               ir.rating AS imdb_rating, ir.audience_rating AS imdb_audience,
                               ir.user_rating AS imdb_user, ir.score AS imdb_score
                        FROM item_people p
                        JOIN items i ON i.rating_key=p.rating_key
                        LEFT JOIN cine21_matches cm ON cm.rating_key=i.rating_key
                          AND IFNULL(cm.match_status,'') IN ('MATCHED','CINE21_OK','OK')
                        LEFT JOIN item_ratings ir ON ir.rating_key=i.rating_key
                        WHERE p.person_type='actor' AND p.""" + field_v2432 + """=?
                          AND i.plex_type IN ('movie','show') AND i.rating_key<>?
                        GROUP BY i.rating_key
                        ORDER BY MAX(IFNULL(ir.rating,0),IFNULL(ir.score,0),IFNULL(cm.critic_rating,0),IFNULL(cm.audience_rating,0)) DESC,
                                 IFNULL(i.year,0) DESC, i.title COLLATE NOCASE
                        LIMIT ?
                    """
                    return cur.execute(sql_v2432, (value_v2432, actor_source_rk, int(query_limit_v2432))).fetchall()

                try:
                    _thumb_index_ready_v2432 = bool(cur.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='index' AND name IN ('idx_item_people_type_thumb','idx_pkm_info_people_type_thumb') LIMIT 1"
                    ).fetchone())
                except Exception:
                    _thumb_index_ready_v2432 = False

                def _actor_candidate_rows_v2432(actor_meta_v2432, query_limit_v2432):
                    actor_name_v2432 = str(actor_meta_v2432.get("name") or "").strip()
                    tag_id_v2432 = str(actor_meta_v2432.get("tag_id") or "").strip()
                    thumb_v2432 = str(actor_meta_v2432.get("thumb") or "").strip()
                    merged_v2432 = []
                    seen_v2432 = set()
                    selectors_v2432 = []

                    def _append_v2432(field_v2432, value_v2432):
                        if not str(value_v2432 or "").strip():
                            return 0
                        rows_v2432 = _actor_exact_rows_v2432(field_v2432, value_v2432, query_limit_v2432)
                        selectors_v2432.append("%s:%d" % (field_v2432, len(rows_v2432 or [])))
                        added_v2432 = 0
                        for row_v2432 in rows_v2432 or []:
                            key_v2432 = str(row_v2432["rating_key"] or "").strip()
                            if not key_v2432 or key_v2432 in seen_v2432:
                                continue
                            seen_v2432.add(key_v2432)
                            merged_v2432.append(row_v2432)
                            added_v2432 += 1
                        return added_v2432

                    # The common path is one exact tag lookup.  Supplement only when
                    # needed to fill/rank a complete 12-item row.
                    if tag_id_v2432:
                        _append_v2432("tag_id", tag_id_v2432)
                    if len(merged_v2432) < max(int(limit) * 2, 24):
                        _append_v2432("person_name", actor_name_v2432)
                    if thumb_v2432 and len(merged_v2432) < max(int(limit) * 2, 24):
                        if _thumb_index_ready_v2432:
                            _append_v2432("person_thumb", thumb_v2432)
                        else:
                            selectors_v2432.append("person_thumb:skip_no_index")

                    # Each exact query is already rating/year ordered.  Re-sort the
                    # small merged set so supplementary alias rows compete fairly.
                    def _score_v2432(row_v2432):
                        vals_v2432 = []
                        for key_v2432 in ("imdb_rating", "imdb_score", "critic_rating", "audience_rating"):
                            try:
                                vals_v2432.append(float(row_v2432[key_v2432] or 0))
                            except Exception:
                                vals_v2432.append(0.0)
                        try:
                            year_v2432 = int(row_v2432["year"] or 0)
                        except Exception:
                            year_v2432 = 0
                        return (max(vals_v2432 or [0.0]), year_v2432, str(row_v2432["title"] or "").casefold())
                    merged_v2432.sort(key=_score_v2432, reverse=True)
                    return merged_v2432[:int(query_limit_v2432)], selectors_v2432

                # V2630: actor-work duplicate identity must never cold-build the
                # 20k+ canonical movie dictionary on the Info critical path.  The
                # candidate row already contains the fields needed for a stable
                # work-family signature.  Title/original-title + year collapse Plex
                # duplicate library copies, while a coarse duration band keeps
                # materially different same-title/year cuts separate without DB I/O.
                def _actor_work_norm_v2397(value):
                    try:
                        return " ".join(str(value or "").strip().casefold().split())
                    except Exception:
                        return str(value or "").strip().lower()

                def _actor_work_identity_v2397(row_v2397):
                    try:
                        row_key_v2397 = str(row_v2397["rating_key"] or "").strip()
                        ptype_v2397 = str(row_v2397["plex_type"] or "").strip().lower()
                        title_v2397 = _actor_work_norm_v2397(row_v2397["title"])
                        original_v2397 = _actor_work_norm_v2397(row_v2397["original_title"])
                        year_v2397 = str(row_v2397["year"] or "").strip()
                        duration_v2397 = _safe_int(row_v2397["duration"], 0)
                        names_v2397 = sorted(set(x for x in (title_v2397, original_v2397) if x))
                        if ptype_v2397 == "movie" and year_v2397 and names_v2397:
                            duration_band_v2630 = int((max(0, duration_v2397) + 449) // 900) if duration_v2397 > 0 else 0
                            return ("movie_family_v2630", tuple(names_v2397), year_v2397, duration_band_v2630)
                        if ptype_v2397 == "show" and names_v2397 and year_v2397:
                            return ("show_title_year", names_v2397[0], year_v2397)
                        return (ptype_v2397 or "item", row_key_v2397 or (names_v2397[0] if names_v2397 else ""), year_v2397)
                    except Exception:
                        try:
                            return ("item", str(row_v2397["rating_key"] or "").strip())
                        except Exception:
                            return ("item", str(id(row_v2397)))

                self._info_movie_cine21_widget_rows_step2(_actor_candidate_rows_v2432, _actor_work_authority_v2350, _actor_work_identity_v2397, _quality_pass, actors, current_title, current_year, limit, result, rk)
                _log("INFO_ACTOR_WIDGETS_BUILD_V1966 rating_key=%s actors=%d rows=%d items=%d elapsed=%.1fms" % (
                    rk, len(actors[:3]), len(set(x.get("row_id") for x in result)), len(result), (time.time()-t0)*1000.0
                ))
                _log("INFO_ACTOR_WIDGETS_FASTPATH_V2630 rating_key=%s canonical_full_bulk=0 family=row_signature_v2630 network=0" % rk)
            finally:
                conn.close()
            try:
                if isinstance(_page_cache_v2351, dict):
                    _cache_rows_v2358 = [dict(x) for x in list(result or [])]
                    _page_cache_v2351[_page_key_v2351] = {
                        "ts": time.time(),
                        "rows": _cache_rows_v2358,
                        "authority_fp": _authority_fp_v2358,
                    }
                    if len(_page_cache_v2351) > 64:
                        _oldest_key_v2351 = min(
                            _page_cache_v2351,
                            key=lambda k: float((_page_cache_v2351.get(k) or {}).get("ts") or 0.0)
                        )
                        if _oldest_key_v2351 != _page_key_v2351:
                            _page_cache_v2351.pop(_oldest_key_v2351, None)
                    _log("INFO_ACTOR_WIDGETS_PAGE_CACHE_STORE_V2358 rating_key=%s source_key=%s rows=%d authority_fp=%s complete_before_visible=1" % (
                        rk, _actor_source_cache_key_v2358, len(result or []), str(_authority_fp_v2358 or "")[:10]
                    ))

                    # Persist the final rows so a Kodi restart or another episode of
                    # the same show does not rebuild them.  The authority fingerprint
                    # makes the file a derived cache only; Plex/local membership
                    # changes make the entry unusable before it can reach the UI.
                    if _authority_fp_v2358 and isinstance(_persistent_cache_v2358, dict):
                        _persistent_cache_v2358[_page_key_v2351] = {
                            "ts": time.time(),
                            "rows": _cache_rows_v2358,
                            "authority_fp": _authority_fp_v2358,
                            "source_key": _actor_source_cache_key_v2358,
                        }
                        while len(_persistent_cache_v2358) > 96:
                            _oldest_persist_v2358 = min(
                                _persistent_cache_v2358,
                                key=lambda k: float((_persistent_cache_v2358.get(k) or {}).get("ts") or 0.0)
                            )
                            if _oldest_persist_v2358 == _page_key_v2351 and len(_persistent_cache_v2358) <= 96:
                                break
                            _persistent_cache_v2358.pop(_oldest_persist_v2358, None)
                        # R117: write on the cache worker; the actor-work rows used
                        # to wait ~0.2 s on SHIELD for this file before their cards
                        # were built.  Same {"version":1,"entries":...} layout.
                        _pkm_write_cache_json_async_r116(
                            _persistent_path_v2358, _persistent_cache_v2358,
                            tag="info_actor_widgets:%s" % rk, version=1)
                        _log("INFO_ACTOR_WIDGETS_PERSISTENT_CACHE_STORE_V2358 rating_key=%s source_key=%s rows=%d file=1" % (
                            rk, _actor_source_cache_key_v2358, len(result or [])
                        ))
            except Exception:
                _log("INFO_ACTOR_WIDGETS_CACHE_STORE_FAILED_V2358 rating_key=%s err=%s" % (
                    rk, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            return result
        except Exception:
            _log("INFO_ACTOR_WIDGETS_BUILD_FAILED_V1966 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return result

    def _info_movie_cine21_widget_rows_step1(self, dbp, limit, rk):
        """Step 1 of _info_movie_cine21_widget_rows (R76 split, moved verbatim)."""
        _actor_source_cache_key_v2358 = rk
        try:
            _conn_key_v2358 = sqlite3.connect(dbp, timeout=2.0)
            try:
                _cur_key_v2358 = _conn_key_v2358.cursor()
                _src_row_v2358 = _cur_key_v2358.execute(
                    "SELECT plex_type,parent_rating_key,grandparent_rating_key FROM items WHERE rating_key=? LIMIT 1",
                    (rk,)
                ).fetchone()
                if _src_row_v2358:
                    _src_type_v2358 = str(_src_row_v2358[0] or "").strip().lower()
                    if _src_type_v2358 == "episode":
                        _actor_source_cache_key_v2358 = str(_src_row_v2358[2] or _src_row_v2358[1] or rk).strip() or rk
                    elif _src_type_v2358 == "season":
                        _actor_source_cache_key_v2358 = str(_src_row_v2358[1] or rk).strip() or rk
            finally:
                _conn_key_v2358.close()
        except Exception:
            _actor_source_cache_key_v2358 = rk

        def _restore_actor_rows_v2358(rows_v2358):
            restored_v2358 = []
            for entry_v2358 in list(rows_v2358 or []):
                if not isinstance(entry_v2358, dict):
                    continue
                d_v2358 = dict(entry_v2358)
                if isinstance(d_v2358.get("row"), list):
                    d_v2358["row"] = tuple(d_v2358.get("row") or [])
                restored_v2358.append(d_v2358)
            return restored_v2358

        def _authority_fingerprint_v2358():
            # v2431: actor-work rows are derived from the recommendation index that
            # library sync already built in plex_km.db.  The Info page must not need
            # a fresh server-authority proof just to reuse those rows.  Fingerprint
            # the local recommendation-index state instead; a real library/index
            # rebuild changes this value and naturally invalidates the derived cache.
            try:
                fp_conn_v2431 = sqlite3.connect(dbp, timeout=2.0)
                try:
                    fp_rows_v2431 = fp_conn_v2431.execute(
                        "SELECT section_id,source,indexed_at,item_count,people_count,genre_count,country_count,rating_count "
                        "FROM item_recommend_index_state ORDER BY section_id"
                    ).fetchall()
                    parts_v2431 = [
                        "%s|%s|%s|%s|%s|%s|%s|%s" % tuple(str(v or "") for v in row_v2431)
                        for row_v2431 in (fp_rows_v2431 or [])
                    ]
                    if not parts_v2431:
                        items_v2431 = fp_conn_v2431.execute(
                            "SELECT COUNT(*),COALESCE(MAX(updated_at),0) FROM items"
                        ).fetchone() or (0, 0)
                        people_v2431 = fp_conn_v2431.execute(
                            "SELECT COUNT(*),COALESCE(MAX(indexed_at),0) FROM item_people"
                        ).fetchone() or (0, 0)
                        parts_v2431 = [
                            "fallback|items=%s|max_updated=%s|people=%s|max_indexed=%s" % (
                                str(items_v2431[0] or 0), str(items_v2431[1] or 0),
                                str(people_v2431[0] or 0), str(people_v2431[1] or 0),
                            )
                        ]
                    return hashlib.sha1("\n".join(parts_v2431).encode("utf-8", "replace")).hexdigest()
                finally:
                    fp_conn_v2431.close()
            except Exception:
                return ""

        _authority_fp_v2358 = _authority_fingerprint_v2358()
        # v2397: actor-work composition changed (duplicate Plex library versions collapse).
        # Namespace the cache key so pre-V2397 persistent/page rows cannot reintroduce duplicates.
        # V2603: invalidate legacy actor-row snapshots once. A partial one-row
        # snapshot could previously remain valid for a week and be treated as a
        # complete three-actor result. Keep the same local-authority fingerprint,
        # but move actor rows to a new composition namespace.
        _page_key_v2351 = "v2603_three_actor_rows:%s:%d" % (_actor_source_cache_key_v2358, int(limit or 0))
        return _actor_source_cache_key_v2358, _authority_fp_v2358, _page_key_v2351, _restore_actor_rows_v2358

    def _info_movie_cine21_widget_rows_step2(self, _actor_candidate_rows_v2432, _actor_work_authority_v2350, _actor_work_identity_v2397, _quality_pass, actors, current_title, current_year, limit, result, rk):
        """Step 2 of _info_movie_cine21_widget_rows (R76 split, moved verbatim). Logs: INFO_ACTOR_LOOKUP_V2432, INFO_ACTOR_WIDGET_ROW_V2432, INFO_ACTOR_WIDGET_FILL_V2432, INFO_ACTOR_WORK_DUP_DROP_V2397."""
        def _work_rating_v2700(rrow):
            # Reuse the ratings already on the candidate row (no extra DB/network).
            # Priority imdb-like -> critic/audience; skip out-of-scale (e.g. 0-100) values.
            for _k in ("imdb_rating", "imdb_score", "imdb_audience", "imdb_user", "critic_rating", "audience_rating"):
                try:
                    _v = float(rrow[_k] or 0)
                except Exception:
                    _v = 0.0
                if 0 < _v <= 10:
                    return _v, ("%.1f" % _v)
            return 0.0, ""
        for actor_index, actor_meta in enumerate(actors[:3]):
            actor_name = str(actor_meta.get("name") or "").strip()
            _query_limit_v2432 = max(int(limit) * 6, 80)
            raw, _selectors_v2432 = _actor_candidate_rows_v2432(actor_meta, _query_limit_v2432)
            _log("INFO_ACTOR_LOOKUP_V2432 rating_key=%s actor_index=%d actor=%s selectors=%s raw=%d expand_rounds=0 or_scan=0 network=0 authority=sync_db" % (
                rk, actor_index, _short_log_value(actor_name, 80),
                ",".join(_selectors_v2432 or []) or "none", len(raw or [])
            ))
            candidates = []
            for r in raw:
                try:
                    if current_title and str(r["title"] or "").strip() == current_title and int(r["year"] or 0) == current_year:
                        continue
                except Exception:
                    pass
                candidates.append(r)
            preferred = [r for r in candidates if _quality_pass(r)]
            preferred_keys = set(str(r["rating_key"] or "") for r in preferred)
            nonpreferred = [r for r in candidates if str(r["rating_key"] or "") not in preferred_keys]
            # v2350: keep the established rating-first order, but scan beyond
            # the first 12 DB rows when necessary so stale/no-poster entries
            # are removed without leaving an avoidable hole in the row.
            shown = []
            invalid_v2350 = 0
            no_poster_v2350 = 0
            probe_failed_v2350 = 0
            validated_network_v2350 = 0
            prehome_fallback_v2350 = 0
            local_index_v2431 = 0
            duplicate_v2397 = 0
            shown_work_keys_v2397 = set()
            for r in (preferred + nonpreferred):
                # Resolve the work family before local acceptance.  Once one healthy
                # synchronized member with a poster has been accepted, later duplicate
                # library copies can be discarded without any network request.  If the
                # first copy has no poster, the next copy can still be accepted.
                work_key_v2397 = _actor_work_identity_v2397(r)
                if work_key_v2397 in shown_work_keys_v2397:
                    duplicate_v2397 += 1
                    _log("INFO_ACTOR_WORK_DUP_DROP_V2397 parent=%s actor=%s rating_key=%s title=%s year=%s identity=%s visible=0 authority_probe=0" % (
                        rk, _short_log_value(actor_name, 80), str(r["rating_key"] or ""),
                        _short_log_value(str(r["title"] or ""), 120), str(r["year"] or ""),
                        _short_log_value(str(work_key_v2397), 180)
                    ))
                    continue
                authority_v2350, authority_reason_v2350 = _actor_work_authority_v2350(r)
                if authority_v2350 is None:
                    invalid_v2350 += 1
                    if authority_reason_v2350 == "no_poster":
                        no_poster_v2350 += 1
                    if authority_reason_v2350 == "authority_probe_failed":
                        probe_failed_v2350 += 1
                    _log("INFO_ACTOR_WORK_DROP_V2350 parent=%s actor=%s rating_key=%s title=%s reason=%s visible=0" % (
                        rk, _short_log_value(actor_name, 80), str(r["rating_key"] or ""),
                        _short_log_value(str(r["title"] or ""), 120), authority_reason_v2350
                    ))
                    continue
                source_v2350 = str(authority_v2350.get("source") or "")
                if source_v2350 == "local_index_v2431":
                    local_index_v2431 += 1
                elif source_v2350 == "plex":
                    validated_network_v2350 += 1
                elif source_v2350 == "prehome_proof_v2349":
                    prehome_fallback_v2350 += 1
                row_tuple_v2350 = list(self._info_movie_row_tuple_from_db_row(r))
                while len(row_tuple_v2350) < 23:
                    row_tuple_v2350.append("")
                # Direct Plex metadata owns first-paint art when available.
                # On a transient probe failure only a recent v2349 server
                # membership proof may supply the stored poster/art.
                row_tuple_v2350[12] = authority_v2350.get("thumb") or row_tuple_v2350[12]
                if authority_v2350.get("art"):
                    row_tuple_v2350[13] = authority_v2350.get("art")
                shown.append((tuple(row_tuple_v2350),) + _work_rating_v2700(r))
                shown_work_keys_v2397.add(work_key_v2397)
                if len(shown) >= int(limit):
                    break
            row_id = "info_actor_%d_works_v1966" % actor_index
            row_title = "%s 출연작" % actor_name
            # 평점순: sort the selected works by rating desc (unrated last) for display.
            for _rt_v2700, _rf_v2700, _rs_v2700 in sorted(shown, key=lambda _x: _x[1], reverse=True):
                result.append({
                    "row": _rt_v2700,
                    "row_title": row_title,
                    "row_type": "info_actor_works_v1966",
                    "row_id": row_id,
                    "work_rating": _rs_v2700,
                })
            _log("INFO_ACTOR_WIDGET_ROW_V2432 rating_key=%s actor_index=%d actor=%s raw=%d preferred=%d shown=%d duplicate_drop=%d dropped=%d no_poster=%d local_index=%d plex_probe=%d startup_proof=%d authority=sync_db" % (
                rk, actor_index, _short_log_value(actor_name, 80), len(raw or []), len(preferred), len(shown), duplicate_v2397,
                invalid_v2350, no_poster_v2350, local_index_v2431, validated_network_v2350, prehome_fallback_v2350
            ))
            _log("INFO_ACTOR_WIDGET_FILL_V2432 rating_key=%s actor_index=%d actor=%s candidates=%d preferred_first=%d shown=%d limit=%d source=plex_km_db_local_index plex_probe=0 poster_required=1" % (
                rk, actor_index, _short_log_value(actor_name, 80), len(candidates), len(preferred), len(shown), int(limit)
            ))

    def _info_movie_widget_size(self, control_id):
        try:
            return int(self.getControl(int(control_id)).size())
        except Exception:
            return 0

    def _r88_rebuild_budget_ms(self):
        """R88: per-ping time budget (ms) for the incremental widget rebuild.

        Window property PlexKM.Info.R88RebuildBudgetMs overrides (default 45,
        0 restores the old single-shot rebuild).
        """
        try:
            raw = xbmcgui.Window(10000).getProperty("PlexKM.Info.R88RebuildBudgetMs")
            return int(raw) if str(raw or "").strip() != "" else 45
        except Exception:
            return 45

    def _r88_rebuild_in_progress(self, rk=None):
        st = getattr(self, "_info_widget_incr_r88", None)
        if not isinstance(st, dict):
            return False
        return rk is None or str(st.get("rk") or "") == str(rk or "")

    def _r88_schedule_rebuild_ping(self, gap_ms=40):
        """Re-ping once so the next chunk runs in a later GUI callback."""
        try:
            if getattr(self, "_info_widget_reping_r88", False):
                return
            self._info_widget_reping_r88 = True

            def _go():
                self._info_widget_reping_r88 = False
                try:
                    if self._closing_event_v1841.is_set():
                        return
                except Exception:
                    pass
                try:
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            t = threading.Timer(max(0.01, gap_ms / 1000.0), _go)
            t.daemon = True
            t.start()
        except Exception:
            self._info_widget_reping_r88 = False

    def _info_movie_populate_incremental_r88(self, rating_key, reason="", actor_hint="", genre_hint="", budget_ms=45):
        """R88: bind staged actor-work rows a few items per GUI callback.

        Returns (done, items).  Uses the staged data snapshot only (no DB).
        The old single-shot function built ~20ms per item (up to ~800ms in one
        GUI callback); this builds items until budget_ms is spent, adds them to
        the native list, and returns so Kodi can draw frames in between.
        """
        rk0 = str(rating_key or "").strip()
        st = getattr(self, "_info_widget_incr_r88", None)
        if isinstance(st, dict) and str(st.get("rk") or "") != rk0:
            st = None
            self._info_widget_incr_r88 = None
        if st is None:
            stage = getattr(self, "_info_widget_rows_precomputed_v2332", None)
            if getattr(self, "_info_movie_widgets_rating_key", "") == rk0 or not (
                isinstance(stage, dict) and str(stage.get("rating_key") or "") == rk0
            ):
                # Already rendered (reuse path) or no staged data: old behaviour.
                n = self._info_movie_populate_cine21_widgets(
                    rating_key, reason=reason, actor_hint=actor_hint, genre_hint=genre_hint)
                return True, n
            is_tv = (
                self.getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(13000).getProperty("PlexKM.Info.IsTV") == "1"
            )
            ids = list(INFO_TV_ACTOR_WIDGET_ROW_IDS if is_tv else INFO_MOVIE_WIDGET_ROW_IDS)
            self._info_movie_widget_clear()
            grouped = []
            current = []
            current_id = None
            for entry in list(stage.get("rows") or []):
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            grouped = grouped[:len(ids)]
            st = {
                "rk": rk0, "ids": ids, "grouped": grouped, "is_tv": bool(is_tv),
                "expected": min(len(grouped), len(ids)),
                "row": 0, "item": 0, "row_started": False, "ctrl": None,
                "rendered_rows": 0, "rendered_items": 0, "chunks": 0,
                "t0": self._now_ms(),
            }
            self._info_widget_incr_r88 = st
            _log("INFO_WIDGET_INCR_START_R88 rating_key=%s rows=%d budget_ms=%d reason=%s" % (
                rk0, st["expected"], int(budget_ms), reason or ""))

        t_start = self._now_ms()
        grouped = st["grouped"]
        ids = st["ids"]
        while st["row"] < len(grouped):
            entries = grouped[st["row"]]
            if not st["row_started"]:
                try:
                    ctrl = self.getControl(ids[st["row"]])
                    ctrl.reset()
                except Exception:
                    st["row"] += 1
                    st["item"] = 0
                    continue
                st["ctrl"] = ctrl
                st["row_started"] = True
                title0 = entries[0].get("row_title", "") if entries else ""
                try:
                    self._info_set_property_all("PlexKM.Info.MovieWidget.Row%d.Title" % st["row"], title0 or "")
                except Exception:
                    pass
            ctrl = st["ctrl"]
            chunk = []
            out_of_budget = False
            while st["item"] < len(entries):
                entry = entries[st["item"]]
                item_idx = st["item"]
                st["item"] += 1
                try:
                    li = None
                    # R105: ListItem prebuilt by the post-visible worker.
                    if entry.get("_li_r105") is not None and int(entry.get("_li_index_r105", -1)) == item_idx:
                        li = entry.pop("_li_r105", None)
                    if li is not None:
                        pass
                    elif str(entry.get("row_type") or "") == "info_actor_works_v1966":
                        li = self._info_actor_work_li_from_row_v2509(
                            entry.get("row"), row_title=_display_library_title(entry.get("row_title", "")),
                            row_first=(item_idx == 0), row_id=entry.get("row_id", ""), row_start=0, row_index=item_idx,
                            work_rating=entry.get("work_rating", "")
                        )
                    else:
                        li = self._li_from_row(
                            entry.get("row"), row_title=_display_library_title(entry.get("row_title", "")), row_type=entry.get("row_type", ""),
                            row_first=(item_idx == 0), row_id=entry.get("row_id", ""), row_start=0, row_index=item_idx
                        )
                    if li is not None:
                        chunk.append(li)
                except Exception:
                    pass
                if (self._now_ms() - t_start) >= int(budget_ms) and st["item"] < len(entries):
                    out_of_budget = True
                    break
            if chunk:
                try:
                    ctrl.addItems(chunk)
                except Exception:
                    for li_x in chunk:
                        try:
                            ctrl.addItem(li_x)
                        except Exception:
                            pass
                st["rendered_items"] += len(chunk)
                st["chunks"] += 1
            if out_of_budget:
                _log("INFO_WIDGET_CHUNK_R88 rating_key=%s row=%d items_done=%d/%d chunk_ms=%d" % (
                    rk0, st["row"], st["item"], len(entries), self._now_ms() - t_start))
                return False, st["rendered_items"]
            # row finished
            try:
                if ctrl.size() > 0:
                    try:
                        # R100b: never yank a row the user is already browsing.
                        if int(self._safe_focus_id()) != int(ids[st["row"]]):
                            ctrl.selectItem(0)
                    except Exception:
                        pass
                    st["rendered_rows"] += 1
            except Exception:
                pass
            st["row"] += 1
            st["item"] = 0
            st["row_started"] = False
            st["ctrl"] = None
            if (self._now_ms() - t_start) >= int(budget_ms) and st["row"] < len(grouped):
                _log("INFO_WIDGET_CHUNK_R88 rating_key=%s row_done=%d chunk_ms=%d" % (
                    rk0, st["row"] - 1, self._now_ms() - t_start))
                return False, st["rendered_items"]

        # all rows bound: same bookkeeping as the single-shot function
        try:
            expected = int(st["expected"])
            rendered_rows = int(st["rendered_rows"])
            rendered_items = int(st["rendered_items"])
            complete = bool(expected == 0 or rendered_rows >= expected)
            self._info_actor_widgets_complete_v2603 = {
                "rating_key": rk0, "expected_rows": expected, "rendered_rows": rendered_rows,
                "items": rendered_items, "complete": complete,
            }
            if rendered_items > 0 and complete:
                self._info_movie_widgets_rating_key = rk0
            elif not complete:
                self._info_movie_widgets_rating_key = ""
            if complete:
                self._info_widget_rows_precomputed_v2332 = None
            self._info_set_property_all(
                "PlexKM.Info.HasMovieActorWorks",
                "1" if (not st["is_tv"] and rendered_items > 0) else "0"
            )
            _log("INFO_ACTOR_WIDGETS_BIND_COMPLETE_V2603 rating_key=%s expected_rows=%d rendered_rows=%d items=%d complete=%d staged_rows_retained=%d" % (
                rk0, expected, rendered_rows, rendered_items, 1 if complete else 0, 0 if complete else 1))
            _log("INFO_WIDGET_INCR_DONE_R88 rating_key=%s chunks=%d items=%d total_ms=%d" % (
                rk0, st["chunks"], rendered_items, self._now_ms() - int(st["t0"])))
        except Exception:
            pass
        self._info_widget_incr_r88 = None
        return True, int(rendered_items)

    def _info_movie_populate_cine21_widgets(self, rating_key, reason="", actor_hint="", genre_hint=""):
        try:
            rk0 = str(rating_key or "").strip()
            _is_tv_widgets_v2066 = (
                self.getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
                or xbmcgui.Window(13000).getProperty("PlexKM.Info.IsTV") == "1"
            )
            _target_widget_ids_v2066 = INFO_TV_ACTOR_WIDGET_ROW_IDS if _is_tv_widgets_v2066 else INFO_MOVIE_WIDGET_ROW_IDS
            if rk0 and getattr(self, "_info_movie_widgets_rating_key", "") == rk0:
                _sizes_v2066 = [self._info_movie_widget_size(_cid) for _cid in _target_widget_ids_v2066]
                _complete_v2603 = getattr(self, "_info_actor_widgets_complete_v2603", None)
                _expected_rows_v2603 = 0
                if isinstance(_complete_v2603, dict) and str(_complete_v2603.get("rating_key") or "") == rk0:
                    try:
                        _expected_rows_v2603 = int(_complete_v2603.get("expected_rows") or 0)
                    except Exception:
                        _expected_rows_v2603 = 0
                _native_rows_v2603 = sum(1 for _sz_v2603 in _sizes_v2066 if int(_sz_v2603 or 0) > 0)
                # V2603: one populated native list is not proof that a three-row
                # actor-work commit completed. V2602 used any(sizes), so a transient
                # first-row-only bind could permanently suppress rows 2/3. Reuse is
                # allowed only when the renderer recorded and reached its full row
                # count for this exact title.
                if any(_sizes_v2066) and _expected_rows_v2603 > 0 and _native_rows_v2603 >= _expected_rows_v2603:
                    try:
                        self._info_set_property_all(
                            "PlexKM.Info.HasMovieActorWorks",
                            "1" if (not _is_tv_widgets_v2066 and any(_sizes_v2066)) else "0"
                        )
                    except Exception:
                        pass
                    _log("INFO_MOVIE_MORE_STATE_V2398 reason=reuse rating_key=%s is_tv=%d sizes=%s has=%d" % (
                        rk0, 1 if _is_tv_widgets_v2066 else 0,
                        ",".join(str(x) for x in _sizes_v2066),
                        1 if (not _is_tv_widgets_v2066 and any(_sizes_v2066)) else 0
                    ))
                    _log("INFO_ACTOR_WIDGETS_RENDER_SKIP_V2603 reason=%s rating_key=%s is_tv=%d controls=%s sizes=%s expected_rows=%d native_rows=%d complete=1" % (
                        reason or "", rk0, 1 if _is_tv_widgets_v2066 else 0,
                        ",".join(str(x) for x in _target_widget_ids_v2066),
                        ",".join(str(x) for x in _sizes_v2066), _expected_rows_v2603, _native_rows_v2603
                    ))
                    return sum(_sizes_v2066)
                if any(_sizes_v2066):
                    _log("INFO_ACTOR_WIDGETS_PARTIAL_REUSE_REJECT_V2603 reason=%s rating_key=%s sizes=%s expected_rows=%d native_rows=%d rerender=1" % (
                        reason or "", rk0, ",".join(str(x) for x in _sizes_v2066),
                        _expected_rows_v2603, _native_rows_v2603
                    ))
            _log("INFO_MOVIE_WIDGETS_RENDER_START reason=%s rating_key=%s actor_hint=%s genre_hint=%s" % (
                reason or "", rating_key or "", _short_log_value(actor_hint or "", 80), _short_log_value(genre_hint or "", 120)
            ))
            self._info_movie_widget_clear()
            info_row_limit_v1931 = 12
            _stage_v2332 = getattr(self, "_info_widget_rows_precomputed_v2332", None)
            _stage_used_v2603 = False
            if isinstance(_stage_v2332, dict) and str(_stage_v2332.get("rating_key") or "") == rk0:
                rows_cache = list(_stage_v2332.get("rows") or [])
                _stage_used_v2603 = True
                _log("INFO_WIDGET_ROWS_REUSE_V2332 rating_key=%s rows=%d reason=%s db_query=0" % (
                    rk0, len(rows_cache), reason or ""
                ))
            else:
                rows_cache = self._info_movie_cine21_widget_rows(
                    rating_key, limit=info_row_limit_v1931, actor_hint=actor_hint, genre_hint=genre_hint
                )
            if _is_android_platform_v1931():
                _log("ANDROID_INFO_WIDGET_LIMIT_V1937 rating_key=%s per_row=%d max_items=%d" % (
                    str(rating_key or ""), info_row_limit_v1931, info_row_limit_v1931 * len(_target_widget_ids_v2066)
                ))
            grouped = []
            current = []
            current_id = None
            for entry in rows_cache or []:
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            _expected_rows_v2603 = min(len(grouped), len(_target_widget_ids_v2066))
            rendered_rows = 0
            rendered_items = 0
            for row_idx, entries in enumerate(grouped[:len(_target_widget_ids_v2066)]):
                cid = _target_widget_ids_v2066[row_idx]
                try:
                    ctrl = self.getControl(cid)
                    ctrl.reset()
                except Exception:
                    continue
                title0 = entries[0].get("row_title", "") if entries else ""
                try:
                    self._info_set_property_all("PlexKM.Info.MovieWidget.Row%d.Title" % row_idx, title0 or "")
                except Exception:
                    pass
                _row_items_v2509 = []
                _row_build_t0_v2509 = self._now_ms()
                for item_idx, entry in enumerate(entries):
                    try:
                        if str(entry.get("row_type") or "") == "info_actor_works_v1966":
                            li = self._info_actor_work_li_from_row_v2509(
                                entry.get("row"), row_title=_display_library_title(entry.get("row_title", "")),
                                row_first=(item_idx == 0), row_id=entry.get("row_id", ""), row_start=0, row_index=item_idx,
                                work_rating=entry.get("work_rating", "")
                            )
                        else:
                            li = self._li_from_row(
                                entry.get("row"), row_title=_display_library_title(entry.get("row_title", "")), row_type=entry.get("row_type", ""),
                                row_first=(item_idx == 0), row_id=entry.get("row_id", ""), row_start=0, row_index=item_idx
                            )
                        if li is not None:
                            _row_items_v2509.append(li)
                    except Exception:
                        pass
                if _row_items_v2509:
                    try:
                        ctrl.addItems(_row_items_v2509)
                    except Exception:
                        # Fail-safe compatibility fallback only; normal Kodi 21.3
                        # path is one native label-bind per row.
                        for _li_v2509 in _row_items_v2509:
                            try:
                                ctrl.addItem(_li_v2509)
                            except Exception:
                                pass
                    rendered_items += len(_row_items_v2509)
                    _log("INFO_ACTOR_WORK_BATCH_BIND_V2509 rating_key=%s control=%s items=%d build_bind_ms=%d additems=1 per_item_rating_sql=0" % (
                        rk0, cid, len(_row_items_v2509), self._now_ms() - _row_build_t0_v2509
                    ))
                if ctrl.size() > 0:
                    try:
                        ctrl.selectItem(0)
                    except Exception:
                        pass
                    rendered_rows += 1
            try:
                _complete_bind_v2603 = bool(_expected_rows_v2603 == 0 or rendered_rows >= _expected_rows_v2603)
                self._info_actor_widgets_complete_v2603 = {
                    "rating_key": rk0,
                    "expected_rows": int(_expected_rows_v2603),
                    "rendered_rows": int(rendered_rows),
                    "items": int(rendered_items),
                    "complete": bool(_complete_bind_v2603),
                }
                if rendered_items > 0 and _complete_bind_v2603:
                    self._info_movie_widgets_rating_key = str(rating_key or "").strip()
                elif not _complete_bind_v2603:
                    self._info_movie_widgets_rating_key = ""
                if _stage_used_v2603 and _complete_bind_v2603:
                    self._info_widget_rows_precomputed_v2332 = None
                _log("INFO_ACTOR_WIDGETS_BIND_COMPLETE_V2603 rating_key=%s expected_rows=%d rendered_rows=%d items=%d complete=%d staged_rows_retained=%d" % (
                    rk0, _expected_rows_v2603, rendered_rows, rendered_items,
                    1 if _complete_bind_v2603 else 0,
                    1 if (_stage_used_v2603 and not _complete_bind_v2603) else 0
                ))
                # v2398: publish after the native lists are actually populated.
                # This makes the More cue deterministic even during atomic/offscreen
                # list composition and supports all three movie actor-work rows.
                self._info_set_property_all(
                    "PlexKM.Info.HasMovieActorWorks",
                    "1" if (not _is_tv_widgets_v2066 and rendered_items > 0) else "0"
                )
                _log("INFO_MOVIE_MORE_STATE_V2398 reason=render rating_key=%s is_tv=%d rows=%d items=%d has=%d" % (
                    str(rating_key or ""), 1 if _is_tv_widgets_v2066 else 0,
                    rendered_rows, rendered_items,
                    1 if (not _is_tv_widgets_v2066 and rendered_items > 0) else 0
                ))
                _log("INFO_ACTOR_WIDGETS_RENDER_V2066 reason=%s rating_key=%s is_tv=%d controls=%s rows=%d items=%d" % (reason or "", rating_key or "", 1 if _is_tv_widgets_v2066 else 0, ",".join(str(x) for x in _target_widget_ids_v2066), rendered_rows, rendered_items))
            except Exception:
                pass
            return rendered_items
        except Exception:
            try:
                _log("INFO_MOVIE_WIDGETS_RENDER_FAILED reason=%s rating_key=%s err=%s" % (reason or "", rating_key or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return 0

    def _info_home_visual_continuity_v2511(self, li, reason=""):
        """Latch the exact visible Home hero presentation for a seamless Info entry.

        v2512 extends the v2511 synopsis-only continuity contract to the complete
        Home-visible common hero block. This is display-only state and is allowed
        only when the currently visible Home ratingKey exactly equals the Info
        target. Raw authority/playstate/DB/artwork identity is never replaced.
        """
        try:
            if li is None:
                return False
            win = xbmcgui.Window(10000)
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            home_rk = str(win.getProperty("PlexKM.Home.RatingKey") or "").strip()
            same = bool(rk and home_rk and rk == home_rk and win.getProperty("PlexKM.Info.InlineActive") != "1")
            summary = li.getProperty("PlexKM.Summary") or ""
            if same:
                # v2512: use the exact text already painted on Home for every
                # common hero field. These are presentation properties only.
                display_pairs = (
                    ("PlexKM.Home.TitleDisplay", "PlexKM.TitleDisplay"),
                    ("PlexKM.Home.MetaLineBaseV2291", "PlexKM.MetaLineBaseV2313"),
                    ("PlexKM.Home.ContentRating", "PlexKM.ContentRating"),
                    ("PlexKM.Home.RemainingText", "PlexKM.RemainingText"),
                    ("PlexKM.Home.RemainingIcon", "PlexKM.RemainingIcon"),
                    ("PlexKM.Home.GenreLine", "PlexKM.GenreLine"),
                    ("PlexKM.Home.Cine21BarDisplay", "PlexKM.Cine21BarDisplay"),
                    ("PlexKM.Home.WatchaBarDisplay", "PlexKM.WatchaBarDisplay"),
                    ("PlexKM.Home.ImdbRating", "PlexKM.ImdbRating"),
                    ("PlexKM.Home.EpisodeTitle", "PlexKM.EpisodeTitle"),
                )
                for src_name, dst_name in display_pairs:
                    try:
                        v = win.getProperty(src_name) or ""
                        if v:
                            li.setProperty(dst_name, v)
                    except Exception:
                        pass

                home_summary = win.getProperty("PlexKM.Home.SummaryDisplay") or ""
                if home_summary:
                    li.setProperty("PlexKM.SummaryDisplay", home_summary)
                elif summary:
                    li.setProperty("PlexKM.SummaryDisplay", self._home_summary_display_text_v2179(summary))

                home_box = win.getProperty("PlexKM.Home.SummaryBoxColor") or ""
                if home_box:
                    self._info_set_property_all("PlexKM.Info.EntryHomeSummaryBoxColorV2511", home_box)
                else:
                    self._info_clear_property_all("PlexKM.Info.EntryHomeSummaryBoxColorV2511")

                # Home may still be in its intentional slow tint transition when
                # Enter is pressed immediately. Do not snap Info to a different RGB.
                home_bg = (
                    win.getProperty("PlexKM.Home.DynamicBgColor")
                    or self.getProperty("PlexKM.Home.DynamicBgColor")
                    or ""
                )
                if home_bg:
                    self._info_set_property_all("PlexKM.Info.EntryHomeDynamicBgColorV2512", home_bg)
                else:
                    self._info_clear_property_all("PlexKM.Info.EntryHomeDynamicBgColorV2512")

                home_tv_rating = (
                    win.getProperty("PlexKM.Home.TmdbRating")
                    or win.getProperty("PlexKM.Home.Rating")
                    or ""
                )
                if home_tv_rating:
                    self._info_set_property_all("PlexKM.Info.EntryHomeTVRatingV2512", home_tv_rating)
                else:
                    self._info_clear_property_all("PlexKM.Info.EntryHomeTVRatingV2512")

                self._info_set_property_all("PlexKM.Info.EntryHomeVisualParityV2511", "1")
                self._info_set_property_all("PlexKM.Info.EntryHomeVisualHoldV2512", "1")
                _log("INFO_HOME_VISUAL_LATCH_V2512 rating_key=%s matched=1 summary_chars=%d box_color=%s home_bg=%s tv_rating=%s reason=%s" % (
                    rk, len(li.getProperty("PlexKM.SummaryDisplay") or ""), home_box or "-",
                    home_bg or "-", home_tv_rating or "-", reason or ""
                ))
                return True

            if summary:
                li.setProperty("PlexKM.SummaryDisplay", self._home_summary_display_text_v2179(summary))
            for name in (
                "PlexKM.Info.EntryHomeVisualParityV2511",
                "PlexKM.Info.EntryHomeSummaryBoxColorV2511",
                "PlexKM.Info.EntryHomeDynamicBgColorV2512",
                "PlexKM.Info.EntryHomeTVRatingV2512",
                "PlexKM.Info.EntryHomeVisualHoldV2512",
            ):
                self._info_clear_property_all(name)
            _log("INFO_HOME_VISUAL_LATCH_V2512 rating_key=%s matched=0 home_rating_key=%s reason=%s" % (
                rk, home_rk, reason or ""
            ))
            return False
        except Exception:
            _log("INFO_HOME_VISUAL_LATCH_FAILED_V2512 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_home_visual_continuity_commit_v2511(self, matched=False, reason=""):
        """Commit the exact currently-visible Home tint/card to the first Info frame."""
        try:
            if not matched:
                return False
            win = xbmcgui.Window(10000)
            target_before = (
                win.getProperty("PlexKM.Info.DynamicBgColor")
                or self.getProperty("PlexKM.Info.DynamicBgColor")
                or ""
            )
            home_bg = (
                win.getProperty("PlexKM.Info.EntryHomeDynamicBgColorV2512")
                or win.getProperty("PlexKM.Home.DynamicBgColor")
                or ""
            )
            if home_bg:
                self._info_dynamic_bg_apply_v2140(
                    home_bg, reason="home_entry_visual_hold_v2512"
                )

            color = (
                win.getProperty("PlexKM.Info.EntryHomeSummaryBoxColorV2511")
                or win.getProperty("PlexKM.Home.SummaryBoxColor")
                or ""
            )
            if color:
                self._info_set_property_all("PlexKM.Info.SummaryBoxColor", color)

            _log("INFO_HOME_VISUAL_COMMIT_V2512 summary_box_color=%s home_bg=%s target_before=%s reason=%s atomic=1" % (
                color or "-", home_bg or "-", target_before or "-", reason or ""
            ))
            return bool(color or home_bg)
        except Exception:
            return False

    def _publish_info_window_properties(self, li, populate_movie_widgets=True, preserve_visible_state=False):
        win = xbmcgui.Window(10000)
        _publish_t0 = time.time()
        _log("CAST_TRACE publish_start rating_key=%s title=%s cast1=%s" % (
            li.getProperty("PlexKM.RatingKey"),
            _short_log_value(li.getProperty("PlexKM.Title") or li.getLabel(), 120),
            _short_log_value(li.getProperty("PlexKM.Cast1.Name"), 80),
        ))
        try:
            current_publish_key = li.getProperty("PlexKM.RatingKey") or ""
            prev_info_key = self.getProperty("PlexKM.Info.RatingKey") or win.getProperty("PlexKM.Info.RatingKey") or xbmcgui.Window(13000).getProperty("PlexKM.Info.RatingKey") or ""
            preserve_tv_state = bool(current_publish_key and prev_info_key and current_publish_key == prev_info_key)
            # v1333: when background republishing the same active Info item, keep
            # the already frozen DisplayCast local-circle snapshot until the new
            # snapshot is ready.  Clearing it for the same ratingKey caused a
            # visible empty/placeholder pulse even after cast had been repaired.
            preserve_display_cast_state = bool(preserve_tv_state and win.getProperty("PlexKM.Info.DisplayCast1.Name"))
            prev_tv_mode = self._info_tv_current_mode_or_fallback() if preserve_tv_state else ""
            prev_tv_back_mode = (self.getProperty("PlexKM.Info.TVBackMode") or win.getProperty("PlexKM.Info.TVBackMode") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVBackMode") or "") if preserve_tv_state else ""
            prev_tv_section_title = _display_library_title((self.getProperty("PlexKM.Info.TVSectionTitle") or win.getProperty("PlexKM.Info.TVSectionTitle") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVSectionTitle") or "") if preserve_tv_state else "")
            prev_tv_hint = (self.getProperty("PlexKM.Info.TVEpisodeHint") or win.getProperty("PlexKM.Info.TVEpisodeHint") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVEpisodeHint") or "") if preserve_tv_state else ""
            if preserve_visible_state and preserve_tv_state:
                _log("INFO_VISIBLE_STATE_FREEZE_V2083 rating_key=%s tv_mode=%s action=keep_tv_identity_during_background_refresh" % (
                    current_publish_key, prev_tv_mode or ""
                ))
            else:
                for tv_key in ("IsTV", "IsShow", "IsEpisode", "TVShowTitle", "TVSectionTitle", "TVEpisodeHint", "TVMode", "TVBackMode", "TVModeSeasons", "TVModeEpisodes"):
                    self._info_clear_property_all("PlexKM.Info.%s" % tv_key)
            # v442: keep the TV/show/episode mode stable across the immediate
            # INFO_REFRESH_AFTER_OPEN republish.  In v441 the first publish +
            # _prepare_info_tv_rows() set IsTV, but the background refresh called
            # this publisher again and cleared IsTV, so the XML fell back to the
            # movie/Credits layout almost instantly.
            plex_type_for_tv = (li.getProperty("PlexKM.Type") or "").lower()
            kodi_type_for_tv = (li.getProperty("PlexKM.KodiType") or "").lower()
            is_tv_info = plex_type_for_tv in ("show", "episode", "tv") or kodi_type_for_tv in ("tvshow", "episode")
            if is_tv_info:
                self._info_set_property_all("PlexKM.Info.IsTV", "1")
                is_show_info = "1" if plex_type_for_tv in ("show", "tv") or kodi_type_for_tv == "tvshow" else ""
                is_episode_info = "1" if plex_type_for_tv == "episode" or kodi_type_for_tv == "episode" else ""
                self._info_set_property_all("PlexKM.Info.IsShow", is_show_info)
                self._info_set_property_all("PlexKM.Info.IsEpisode", is_episode_info)
                if prev_tv_mode in ("episodes", "seasons"):
                    self._info_tv_set_mode(prev_tv_mode, back_mode=prev_tv_back_mode)
                if prev_tv_section_title:
                    self._info_set_property_all("PlexKM.Info.TVSectionTitle", _display_library_title(prev_tv_section_title))
                elif prev_tv_mode == "seasons":
                    self._info_set_property_all("PlexKM.Info.TVSectionTitle", "시즌")
                else:
                    self._info_set_property_all("PlexKM.Info.TVSectionTitle", "에피소드")
                if prev_tv_hint:
                    self._info_set_property_all("PlexKM.Info.TVEpisodeHint", prev_tv_hint)
        except Exception:
            pass
        # v2511: every Info entry path must have the same display-title string used
        # by Home before XML evaluates the atomic target.  Lightweight actor-work
        # and sparse callers may carry Title without a prebuilt TitleDisplay.
        try:
            if not li.getProperty("PlexKM.TitleDisplay"):
                _title_v2511 = li.getProperty("PlexKM.Title") or li.getLabel() or ""
                li.setProperty("PlexKM.TitleDisplay", self._title_display_text(_title_v2511))
        except Exception:
            pass
        # v2132: Art/Thumb are intentionally excluded from this generic raw-property
        # copy. Some actor-work ListItems carry a Plex /art URL without the token;
        # publishing that raw value first makes Kodi issue an anonymous request (401)
        # before the normalized artwork block below replaces it. Artwork now has one
        # owner and is committed only after token normalization/fallback resolution.
        keys = ["RatingKey", "SectionId", "Type", "KodiType", "InfoLoadedRatingKey", "Title", "TitleDisplay", "EpisodeTitle", "OriginalTitle", "Summary", "SummaryDisplay", "Year", "Duration", "DurationText", "ViewOffset", "ResumeDurationMs", "PlayButtonLabel", "Genre", "Director", "Writer", "Cast", "Studio", "Rating", "ContentRating", "Tagline", "Premiered", "MetaLine", "MetaLineBaseV2313", "PartKey", "PlayUrl", "ShowUrl", "ShowTitle", "Season", "Episode", "ParentRatingKey", "GrandparentRatingKey", "AddedAt", "UpdatedAt"]
        for key in keys:
            try:
                # v1040: publish the visible Info fields to all scopes used by
                # the inline WindowXML.  The previous main loop wrote only to
                # Window(10000), so the Python log showed metadata while the
                # first on-screen TV episode labels could still read empty
                # self/current-window properties.
                self._info_set_property_all("PlexKM.Info.%s" % key, li.getProperty("PlexKM.%s" % key) or "")
            except Exception:
                pass
        try:
            # v2088: movie playback versions are resolved across every PKM-selected
            # movie library, never only the sidebar section that opened Info.
            if str(li.getProperty("PlexKM.Type") or "").strip().lower() == "movie":
                self._info_movie_prepare_versions_v2088(li, reason="publish_info")
                # V2602 UHD: do not start detailed Media/Part network discovery
                # during the Info handoff. Desktop retains automatic prewarm;
                # Android resolves it lazily from the explicit media-version click.
                if self._uhd_kpi_proxy_v2605():
                    _log("INFO_MOVIE_MEDIA_PREWARM_DEFER_V2605 rating_key=%s automatic=0 network_before_visible=0 trigger=button proxy=%d" % (
                        li.getProperty("PlexKM.RatingKey") or "", 0 if self._is_android_v2591() else 1
                    ))
                else:
                    self._info_movie_schedule_media_prewarm_v2106(li, reason="publish_info")
            else:
                self._info_movie_clear_versions_v2088(reason="publish_non_movie")
        except Exception:
            _log("INFO_MOVIE_VERSION_PUBLISH_HOOK_FAILED_V2088 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            # v1809: the episode rail may publish a compact ListItem while Home
            # and section cards use the fully enriched common ListItem.  Fill the
            # visible Info row from the same local metadata index before XML
            # evaluates Year / ContentRating / Genre.  This makes one title show
            # the same metadata in Home, recommendation, library and episode Info.
            _rk_v1809 = li.getProperty("PlexKM.RatingKey") or ""
            _ptype_v1809 = (li.getProperty("PlexKM.Type") or plex_type_for_tv or "").lower()
            _parent_v1809 = li.getProperty("PlexKM.ParentRatingKey") or ""
            _grand_v1809 = li.getProperty("PlexKM.GrandparentRatingKey") or ""
            _year_v1809 = (li.getProperty("PlexKM.Year") or win.getProperty("PlexKM.Info.Year") or "").strip()
            if not _year_v1809:
                _year_v1809 = self._home_db_year_value_v1809(_rk_v1809, _parent_v1809, _grand_v1809, _ptype_v1809)
            _rating_v1809 = (li.getProperty("PlexKM.ContentRating") or win.getProperty("PlexKM.Info.ContentRating") or "").strip()
            if not _rating_v1809:
                _rating_v1809 = self._home_db_content_rating_value_v1804(_rk_v1809, _parent_v1809, _grand_v1809, _ptype_v1809)
            _genre_v1809 = (li.getProperty("PlexKM.Genre") or win.getProperty("PlexKM.Info.Genre") or "").strip()
            if not _genre_v1809:
                _genre_v1809 = self._home_db_genre_value_v1801(_rk_v1809, _parent_v1809, _grand_v1809, _ptype_v1809, section_id=li.getProperty("PlexKM.SectionId") or "", show_title=li.getProperty("PlexKM.ShowTitle") or "")
            if _year_v1809:
                li.setProperty("PlexKM.Year", _year_v1809); self._info_set_property_all("PlexKM.Info.Year", _year_v1809)
            if _rating_v1809:
                li.setProperty("PlexKM.ContentRating", _rating_v1809); self._info_set_property_all("PlexKM.Info.ContentRating", _rating_v1809)
            if _genre_v1809:
                li.setProperty("PlexKM.Genre", _genre_v1809); self._info_set_property_all("PlexKM.Info.Genre", _genre_v1809)
            _log("INFO_HOME_META_PARITY_V1809 rating_key=%s type=%s year=%s rating=%s genre=%s" % (
                _rk_v1809, _ptype_v1809 or "unknown", _year_v1809 or "-", _rating_v1809 or "-", _short_log_value(_genre_v1809, 100) or "-"
            ))
        except Exception:
            _log("INFO_HOME_META_PARITY_FAILED_V1809 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            # v1639: Info and Home share one localized genre source. Keep the raw
            # Plex genre property for data consumers, and publish a display-only
            # Korean line for the auto-collapsing movie metadata list.
            _info_genre_raw = li.getProperty("PlexKM.Genre") or win.getProperty("PlexKM.Info.Genre") or ""
            self._info_set_property_all("PlexKM.Info.GenreLine", self._genre_display_text(_info_genre_raw))
            # v1810: always rebuild the visible Info MetaLine after enrichment.
            # The compact episode rail previously supplied an already non-empty
            # line (season/episode + duration + rating), which prevented v1809
            # from adding year and the inherited age rating.
            _info_meta_line = self._home_meta_line(
                li.getProperty("PlexKM.Type") or "movie",
                li.getProperty("PlexKM.ShowTitle") or "",
                li.getProperty("PlexKM.Season") or "",
                li.getProperty("PlexKM.Episode") or "",
                li.getProperty("PlexKM.Year") or "",
                li.getProperty("PlexKM.DurationText") or "",
                li.getProperty("PlexKM.ContentRating") or "",
                li.getProperty("PlexKM.Rating") or "",
                li.getProperty("PlexKM.AddedAt") or "",
            )
            self._info_set_property_all("PlexKM.Info.MetaLine", _info_meta_line)
            # v2313: refresh the Home-parity base row after enrichment as well.
            _info_meta_base_v2313 = self._home_meta_line_base_v2291(
                li.getProperty("PlexKM.Type") or "movie",
                li.getProperty("PlexKM.Season") or "",
                li.getProperty("PlexKM.Episode") or "",
                li.getProperty("PlexKM.Year") or "",
                li.getProperty("PlexKM.DurationText") or "",
            )
            li.setProperty("PlexKM.MetaLineBaseV2313", _info_meta_base_v2313)
            self._info_set_property_all("PlexKM.Info.MetaLineBaseV2313", _info_meta_base_v2313)
            _log("INFO_HOME_GEOMETRY_META_PARITY_V2313 rating_key=%s base=%s" % (
                li.getProperty("PlexKM.RatingKey") or "", _short_log_value(_info_meta_base_v2313, 120)
            ))
            _log("INFO_EPISODE_CANONICAL_META_ROW_V1810 rating_key=%s meta=%s genre=%s" % (
                li.getProperty("PlexKM.RatingKey") or "",
                _short_log_value(_info_meta_line, 160),
                _short_log_value(_info_genre_raw, 100)
            ))
        except Exception:
            self._info_clear_property_all("PlexKM.Info.GenreLine")
        try:
            # v1567: TV episode identity is field-based, not dependent on the
            # item that first opened Info. Keep the show title fixed while the
            # focused episode title and numeric identity follow the active rail.
            if plex_type_for_tv == "episode" or kodi_type_for_tv == "episode":
                show_title = str(li.getProperty("PlexKM.ShowTitle") or "").strip()
                raw_episode_title = str(li.getProperty("PlexKM.EpisodeTitle") or "").strip()
                raw_title = str(li.getProperty("PlexKM.Title") or li.getLabel() or "").strip()
                if not raw_episode_title and raw_title and raw_title != show_title:
                    raw_episode_title = raw_title
                episode_title = pkm_info_data.normalize_episode_title(
                    raw_episode_title, li.getProperty("PlexKM.Episode") or ""
                )
                if show_title:
                    self._info_set_property_all("PlexKM.Info.TVShowTitle", show_title)
                    self._info_set_property_all("PlexKM.Info.Title", show_title)
                    self._info_set_property_all("PlexKM.Info.TitleDisplay", self._title_display_text(show_title))
                if episode_title:
                    self._info_set_property_all("PlexKM.Info.EpisodeTitle", episode_title)
                _log("INFO_TV_IDENTITY_V1567 rating_key=%s show=%s episode_title=%s identity=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "",
                    _short_log_value(show_title, 80),
                    _short_log_value(episode_title, 100),
                    _short_log_value(pkm_info_data.episode_identity_text(
                        li.getProperty("PlexKM.Season") or "",
                        li.getProperty("PlexKM.Episode") or ""
                    ), 80),
                ))
            elif is_tv_info:
                show_title = str(li.getProperty("PlexKM.Title") or li.getLabel() or "").strip()
                if show_title:
                    self._info_set_property_all("PlexKM.Info.TVShowTitle", show_title)
        except Exception:
            _log("INFO_TV_IDENTITY_V1567_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        self._publish_info_window_properties_step1(li, preserve_visible_state, win)
        for idx in range(1, 9):
            # Clear all per-slot cast properties first. Otherwise a movie/episode
            # with fewer cast entries can inherit stale names/thumbs from the
            # previously opened info window.
            for prefix in ("PlexKM.Info.Cast", "PlexKM.Info.DisplayCast"):
                if prefix == "PlexKM.Info.DisplayCast" and preserve_display_cast_state:
                    continue
                for subkey in ("Name", "Role", "Thumb", "OriginalThumb", "LocalThumb", "ThumbSource", "SourceRatingKey"):
                    try:
                        self._info_clear_property_all("%s%d.%s" % (prefix, idx, subkey))
                    except Exception:
                        pass
            for subkey in ("Name", "Role", "Thumb"):
                try:
                    value = li.getProperty("PlexKM.Cast%d.%s" % (idx, subkey)) or ""
                    if subkey == "Thumb":
                        value = _clean_external_image_url(value)
                        _slot_name = li.getProperty("PlexKM.Cast%d.Name" % idx) or ""
                        _local_thumb = li.getProperty("PlexKM.Cast%d.LocalThumb" % idx) or ""
                        if _local_thumb:
                            value = _local_thumb
                        elif _slot_name and (not value or self._is_cast_placeholder_thumb(value)):
                            # V2636: a real Plex/current-work/global-reuse HTTP thumb is
                            # valid first-frame data. Kodi owns HTTP texture/cache loading.
                            # Placeholder is only for an actually missing portrait.
                            value = self._cast_placeholder_thumb()
                    self._info_set_property_all(
                        "PlexKM.Info.Cast%d.%s" % (idx, subkey),
                        value
                    )
                except Exception:
                    pass
            try:
                _log("CAST_TRACE publish_cast slot=%d name=%s role=%s thumb=%s" % (
                    idx,
                    _short_log_value(win.getProperty("PlexKM.Info.Cast%d.Name" % idx), 80),
                    _short_log_value(win.getProperty("PlexKM.Info.Cast%d.Role" % idx), 80),
                    _short_log_value(win.getProperty("PlexKM.Info.Cast%d.Thumb" % idx)),
                ))
            except Exception:
                pass
        self._publish_info_window_properties_step2(_publish_t0, li, populate_movie_widgets, win)

    def _publish_info_window_properties_step1(self, li, preserve_visible_state, win):
        """Step 1 of _publish_info_window_properties (R76 split, moved verbatim). Logs: INFO_VISIBLE_ART_FREEZE_V2083, INFO_FANART_PUBLISH_V1331."""
        try:
            _info_thumb_raw = (
                li.getProperty("PlexKM.Thumb") or
                li.getArt("poster") or
                li.getArt("thumb") or
                ""
            )
            _info_thumb = _pkm_info_image_url(_info_thumb_raw, width=720, height=1080) if _info_thumb_raw else ""
            _current_info_thumb_v2083 = win.getProperty("PlexKM.Info.Thumb") or ""
            if _info_thumb:
                if preserve_visible_state and _current_info_thumb_v2083:
                    _log("INFO_VISIBLE_ART_FREEZE_V2083 rating_key=%s kind=thumb action=keep_existing background_candidate=%s" % (
                        li.getProperty("PlexKM.RatingKey") or "", "same" if _current_info_thumb_v2083 == _info_thumb else "different"
                    ))
                else:
                    self._info_set_property_all("PlexKM.Info.Thumb", _info_thumb)
            elif not preserve_visible_state:
                self._info_clear_property_all("PlexKM.Info.Thumb")
        except Exception:
            pass
        try:
            _child_atomic_art_v2132 = li.getProperty("PlexKM.Info.ChildAtomicV2132") == "1"
            _entry_home_art_v2194 = self._info_entry_home_art_v2194(li)
            _info_art_raw = (
                _entry_home_art_v2194 or
                li.getProperty("PlexKM.Art") or
                li.getArt("fanart") or
                ("" if _child_atomic_art_v2132 else self._home_fanart_if_owned_r65(li))
            )
            _info_art = _pkm_info_image_url(_info_art_raw, width=1920, height=1080) if _info_art_raw else ""
            _current_info_art_v2083 = win.getProperty("PlexKM.Info.Art") or ""
            _art_frozen_v2083 = bool(preserve_visible_state and _current_info_art_v2083)
            if _info_art and not _art_frozen_v2083:
                self._info_set_property_all("PlexKM.Info.Art", _info_art)
            elif _info_art and _art_frozen_v2083:
                _log("INFO_VISIBLE_ART_FREEZE_V2083 rating_key=%s kind=fanart action=keep_existing background_candidate=%s" % (
                    li.getProperty("PlexKM.RatingKey") or "", "same" if _current_info_art_v2083 == _info_art else "different"
                ))
            elif not preserve_visible_state:
                self._info_clear_property_all("PlexKM.Info.Art")
            _log("INFO_FANART_PUBLISH_V1331 rating_key=%s art=%s tokenized=%s source=%s frozen=%d" % (
                li.getProperty("PlexKM.RatingKey") or "",
                "1" if _info_art else "0",
                "1" if ("x-plex-token=" in str(_info_art or "").lower()) else "0",
                "li_or_home_safe" if _info_art else "empty", 1 if _art_frozen_v2083 else 0
            ))
            # v2136: once the universal A/B transaction has committed,
            # later same-title background art repairs update only the active bank.
            # During a pending different-title swap this is intentionally a no-op.
            try:
                self._info_art_sync_active_v2136(li, _info_art, reason="publish_info_properties")
            except Exception:
                pass
        except Exception:
            pass
        try:
            if not win.getProperty("PlexKM.Info.SummaryDisplay"):
                win.setProperty("PlexKM.Info.SummaryDisplay", self._summary_display_text(win.getProperty("PlexKM.Info.Summary")))
            view_offset = win.getProperty("PlexKM.Info.ViewOffset") or li.getProperty("PlexKM.ViewOffset") or ""
            duration_raw = win.getProperty("PlexKM.Info.Duration") or li.getProperty("PlexKM.Duration") or ""
            remaining_text, remaining_icon = self._remaining_time_props(duration_raw, view_offset)
            win.setProperty("PlexKM.Info.RemainingText", remaining_text)
            win.setProperty("PlexKM.Info.RemainingIcon", remaining_icon)
            if not win.getProperty("PlexKM.Info.PlayButtonLabel"):
                win.setProperty("PlexKM.Info.PlayButtonLabel", self._play_button_label(view_offset, duration_raw, li.getProperty("PlexKM.ResumeDurationMs") or ""))
        except Exception:
            pass
        self._info_publish_watched_state_r60(li, win, reason="publish_full")

    def _publish_info_window_properties_step2(self, _publish_t0, li, populate_movie_widgets, win):
        """Step 2 of _publish_info_window_properties (R76 split, moved verbatim). Logs: CAST_TRACE, INFO_PROPERTY_SCOPE_SYNC, INFO_RATING_STACK_DEFER_V2678, INFO_RATING_STACK_V1639_FAILED."""
        try:
            _log("CAST_TRACE publish_done cast_line=%s" % _short_log_value(win.getProperty("PlexKM.Info.Cast")))
        except Exception:
            pass
        try:
            _w13000 = xbmcgui.Window(13000)
            _log("INFO_PROPERTY_SCOPE_SYNC rating_key=%s w100_title=%s w13000_title=%s self_title=%s w100_meta=%s w13000_meta=%s self_meta=%s" % (
                li.getProperty("PlexKM.RatingKey") or "",
                _short_log_value(win.getProperty("PlexKM.Info.Title"), 80),
                _short_log_value(_w13000.getProperty("PlexKM.Info.Title"), 80),
                _short_log_value(self.getProperty("PlexKM.Info.Title"), 80),
                _short_log_value(win.getProperty("PlexKM.Info.MetaLine"), 80),
                _short_log_value(_w13000.getProperty("PlexKM.Info.MetaLine"), 80),
                _short_log_value(self.getProperty("PlexKM.Info.MetaLine"), 80),
            ))
        except Exception:
            pass
        try:
            rk = li.getProperty("PlexKM.RatingKey")
            pk = li.getProperty("PlexKM.PartKey")
            sid = li.getProperty("PlexKM.SectionId")
            ptype = li.getProperty("PlexKM.Type")
            if pk and ptype in ("movie", "episode") and not win.getProperty("PlexKM.Info.PlayUrl"):
                win.setProperty("PlexKM.Info.PlayUrl", _pkm_play_url(rk, pk, mode="start"))
            if ptype == "show" and rk and sid and not win.getProperty("PlexKM.Info.ShowUrl"):
                win.setProperty("PlexKM.Info.ShowUrl", core.build_plugin_url({"action": "show", "rating_key": rk, "section_id": sid}))
            try:
                if ptype == "movie" and self._uhd_kpi_proxy_v2605():
                    _title = li.getProperty("PlexKM.Title") or ""
                    _original_title = li.getProperty("PlexKM.OriginalTitle") or ""
                    _year = li.getProperty("PlexKM.Year") or ""
                    self._info_schedule_rating_stack_postvisible_v2678(rk, _title, _original_title, _year, li.getProperty("PlexKM.Rating") or "")
                    _log("INFO_RATING_STACK_DEFER_V2678 rating_key=%s first_frame_sql=0" % (rk or ""))
                elif ptype == "movie":
                    _rating_publish_t0 = time.time()
                    _title = li.getProperty("PlexKM.Title") or ""
                    _original_title = li.getProperty("PlexKM.OriginalTitle") or ""
                    _year = li.getProperty("PlexKM.Year") or ""
                    _cine21_props = self._home_cine21_rating_props(
                        rk, title=_title, original_title=_original_title, year=_year
                    )
                    _watcha_props = self._info_watcha_point_props_v2627(
                        rk, title=_title, original_title=_original_title, year=_year
                    )
                    # Prefer the same ListItem score already used by Home. A local DB
                    # fallback keeps IMDb independent when the active item was opened
                    # from a sparse search or related row.
                    _imdb_value = self._home_imdb_rating_value(
                        li.getProperty("PlexKM.Rating") or
                        win.getProperty("PlexKM.Info.Rating") or
                        self._home_db_imdb_rating_point_v2630(rk)
                    )
                    _cine21_critic = _cine21_props.get("CriticRating", "") or ""
                    _cine21_audience = _cine21_props.get("AudienceRating", "") or ""
                    self._info_set_property_all("PlexKM.Info.Cine21CriticRating", _cine21_critic)
                    self._info_set_property_all("PlexKM.Info.Cine21AudienceRating", _cine21_audience)
                    self._info_set_property_all("PlexKM.Info.Cine21BarDisplay", self._home_cine21_bar_display(_cine21_props))
                    self._info_set_property_all("PlexKM.Info.WatchaRating", _watcha_props.get("Rating", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaCount", _watcha_props.get("Count", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaDisplay", _watcha_props.get("Display", "") or "")
                    self._info_set_property_all("PlexKM.Info.WatchaBarDisplay", self._home_watcha_bar_display(_watcha_props))
                    self._info_set_property_all("PlexKM.Info.ImdbRating", _imdb_value)
                    _log("INFO_RATING_STACK_V1639 rating_key=%s cine21=%s/%s watcha=%s imdb=%s genre=%s step=%.1fms" % (
                        rk, _cine21_critic, _cine21_audience,
                        _watcha_props.get("Rating", "") or "", _imdb_value,
                        win.getProperty("PlexKM.Info.GenreLine") or "",
                        (time.time() - _rating_publish_t0) * 1000.0
                    ))
                else:
                    for _rating_prop in (
                        "Cine21CriticRating", "Cine21AudienceRating", "Cine21BarDisplay",
                        "WatchaRating", "WatchaCount", "WatchaDisplay", "WatchaBarDisplay",
                        "ImdbRating",
                    ):
                        self._info_clear_property_all("PlexKM.Info.%s" % _rating_prop)
            except Exception:
                _log("INFO_RATING_STACK_V1639_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            try:
                if ptype in ("movie", "show", "season", "episode") and populate_movie_widgets:
                    _actor_hint = (
                        li.getProperty("PlexKM.Cast1.Name") or
                        win.getProperty("PlexKM.Info.DisplayCast1.Name") or
                        win.getProperty("PlexKM.Info.Cast1.Name") or ""
                    )
                    _genre_hint = li.getProperty("PlexKM.Genre") or win.getProperty("PlexKM.Info.Genre") or ""
                    self._info_movie_populate_cine21_widgets(rk, reason="publish_info", actor_hint=_actor_hint, genre_hint=_genre_hint)
                elif ptype not in ("movie", "show", "season", "episode"):
                    self._info_movie_widget_clear()
                else:
                    _log("INFO_MOVIE_WIDGETS_DEFER rating_key=%s reason=publisher_defers_to_postvisible_worker_v2383" % (rk or ""))
            except Exception:
                _log("INFO_MOVIE_WIDGETS_PUBLISH_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            # v2512: all normal enrichment/rating work above may legitimately
            # compute fresher raw data, but a same-ratingKey Home -> Info ownership
            # switch must paint the exact display strings already visible on Home.
            # Reapply presentation-only values LAST, immediately before reveal.
            try:
                if win.getProperty("PlexKM.Info.EntryHomeVisualHoldV2512") == "1":
                    _home_display_pairs_v2512 = (
                        ("PlexKM.Home.TitleDisplay", "PlexKM.Info.TitleDisplay"),
                        ("PlexKM.Home.MetaLineBaseV2291", "PlexKM.Info.MetaLineBaseV2313"),
                        ("PlexKM.Home.ContentRating", "PlexKM.Info.ContentRating"),
                        ("PlexKM.Home.RemainingText", "PlexKM.Info.RemainingText"),
                        ("PlexKM.Home.RemainingIcon", "PlexKM.Info.RemainingIcon"),
                        ("PlexKM.Home.GenreLine", "PlexKM.Info.GenreLine"),
                        ("PlexKM.Home.Cine21BarDisplay", "PlexKM.Info.Cine21BarDisplay"),
                        ("PlexKM.Home.WatchaBarDisplay", "PlexKM.Info.WatchaBarDisplay"),
                        ("PlexKM.Home.ImdbRating", "PlexKM.Info.ImdbRating"),
                        ("PlexKM.Home.EpisodeTitle", "PlexKM.Info.EpisodeTitle"),
                        ("PlexKM.Home.SummaryDisplay", "PlexKM.Info.SummaryDisplay"),
                    )
                    _reapplied_v2512 = 0
                    for _src_v2512, _dst_v2512 in _home_display_pairs_v2512:
                        _v_v2512 = win.getProperty(_src_v2512) or ""
                        if _v_v2512:
                            self._info_set_property_all(_dst_v2512, _v_v2512)
                            _reapplied_v2512 += 1
                    _log("INFO_HOME_DISPLAY_REAPPLY_V2512 rating_key=%s fields=%d meta=%s genre=%s cine21=%s tv_rating=%s" % (
                        rk or "", _reapplied_v2512,
                        _short_log_value(win.getProperty("PlexKM.Info.MetaLineBaseV2313"), 100),
                        _short_log_value(win.getProperty("PlexKM.Info.GenreLine"), 100),
                        _short_log_value(win.getProperty("PlexKM.Info.Cine21BarDisplay"), 80),
                        win.getProperty("PlexKM.Info.EntryHomeTVRatingV2512") or "-"
                    ))
            except Exception:
                _log("INFO_HOME_DISPLAY_REAPPLY_FAILED_V2512 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            try:
                self._tmdb_fill_info_apply_r41(reason="publish_info")
            except Exception:
                pass
            try:
                _display_ready = 0
                _raw_cast = 0
                for _idx in range(1, 9):
                    if win.getProperty("PlexKM.Info.DisplayCast%d.Name" % _idx):
                        _display_ready += 1
                    if win.getProperty("PlexKM.Info.Cast%d.Name" % _idx):
                        _raw_cast += 1
                _log("INFO_TIMING phase=publish_end rating_key=%s total=%.1fms raw_cast=%d display_cast=%d summary=%s genre=%s director=%s rating=%s cine21=%s/%s" % (
                    rk, (time.time() - _publish_t0) * 1000.0, _raw_cast, _display_ready,
                    "1" if win.getProperty("PlexKM.Info.SummaryDisplay") else "0",
                    "1" if win.getProperty("PlexKM.Info.Genre") else "0",
                    "1" if win.getProperty("PlexKM.Info.Director") else "0",
                    win.getProperty("PlexKM.Info.Rating"),
                    win.getProperty("PlexKM.Info.Cine21CriticRating"),
                    win.getProperty("PlexKM.Info.Cine21AudienceRating")
                ))
            except Exception:
                pass
        except Exception:
            pass
