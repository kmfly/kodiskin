# -*- coding: utf-8 -*-
"""Single PKM-owned Kodi exit countdown (v2171).

Every explicit Kodi Quit path owned by PKM routes through this module so a
remote/keyboard OK never appears to do nothing before the process disappears.

v2172: after the visible 3-2-1 sequence, render the final "Kodi가 종료됩니다."
frame and dispatch Quit immediately.  Do not hold the Python caller for an
extra shutdown-cover interval; Kodi owns teardown from that point.
"""
from __future__ import absolute_import, unicode_literals

import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_kodi_exit_countdown_v2171.xml"
ACTIVE_PROP = "PlexKM.KodiExit.CountdownActiveV2171"
TITLE_PROP = "PlexKM.KodiExit.TitleV2171"
DETAIL_PROP = "PlexKM.KodiExit.DetailV2171"
LINE_PROP = "PlexKM.KodiExit.LineV2171"
COUNT_PROP = "PlexKM.KodiExit.CountV2171"
REASON_PROP = "PlexKM.KodiExit.ReasonV2171"
BACKDROP_COLOR_PROP = "PlexKM.KodiExit.BackdropColorV2212"
PANEL_BG_COLOR_PROP = "PlexKM.KodiExit.PanelBgColorV2212"

_LOCK = threading.Lock()
_DIALOG_HOLD = None


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _normalize_argb_color_v2212(value, default="FF111214"):
    try:
        text = str(value or "").strip().upper().replace("#", "")
        if len(text) == 6:
            text = "FF" + text
        if len(text) != 8:
            return str(default or "FF111214")
        int(text, 16)
        return text
    except Exception:
        return str(default or "FF111214")


def _fanart_tint_props_v2212():
    try:
        win = xbmcgui.Window(10000)
        base = (
            win.getProperty("PlexKM.Info.DynamicBgColor")
            or win.getProperty("PlexKM.Home.DynamicBgColor")
            or win.getProperty("PlexKM.Confirm.FadeOverlayColor")
            or "FF111214"
        )
        base = _normalize_argb_color_v2212(base, default="FF111214")
        rgb = base[-6:].upper()
        panel = "F2" + rgb
        return {
            BACKDROP_COLOR_PROP: "FF" + rgb,
            PANEL_BG_COLOR_PROP: panel,
        }
    except Exception:
        return {
            BACKDROP_COLOR_PROP: "FF111214",
            PANEL_BG_COLOR_PROP: "F2111214",
        }


def _set_props(title, detail, line, count, reason):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(ACTIVE_PROP, "1")
        win.setProperty(TITLE_PROP, str(title or "Kodi 종료"))
        win.setProperty(DETAIL_PROP, str(detail or ""))
        win.setProperty(LINE_PROP, str(line or ""))
        win.setProperty(COUNT_PROP, "" if count is None else str(count))
        win.setProperty(REASON_PROP, str(reason or "unknown"))
        for _k_v2212, _v_v2212 in (_fanart_tint_props_v2212() or {}).items():
            try:
                win.setProperty(_k_v2212, str(_v_v2212 or ""))
            except Exception:
                pass
    except Exception:
        pass


def _is_active():
    try:
        return xbmcgui.Window(10000).getProperty(ACTIVE_PROP) == "1"
    except Exception:
        return False


class PKMKodiExitCountdownDialogV2171(xbmcgui.WindowXMLDialog):
    def onAction(self, action):
        # The exit decision was already explicitly made before this surface.
        # Do not let Back/Enter dismiss or accelerate the fixed 3-2-1 sequence.
        return

    def onClick(self, controlId):
        return


def request_kodi_exit_v2171(reason="", title="Kodi 종료", detail="", monitor=None):
    """Show 3-2-1 immediately, then dispatch Kodi Quit exactly once."""
    global _DIALOG_HOLD

    with _LOCK:
        if _is_active():
            _log("PKM_KODI_EXIT_COUNTDOWN_DUPLICATE_V2171 reason=%s action=ignored" % (reason or "unknown"))
            return False
        _set_props(title, detail, "3초 뒤에 Kodi가 종료됩니다.", 3, reason)
        _log("PKM_KODI_EXIT_FANART_TINT_V2212 reason=%s" % (reason or "unknown"))

    try:
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        dlg = PKMKodiExitCountdownDialogV2171(XML_NAME, addon_path, "Default", "1080i")
        _DIALOG_HOLD = dlg
        dlg.show()
        # Let the first rendered frame bind properties before starting the first second.
        if monitor is not None:
            if monitor.waitForAbort(0.12):
                return False
        else:
            xbmc.sleep(120)

        for count in (3, 2, 1):
            _set_props(title, detail, "%d초 뒤에 Kodi가 종료됩니다." % count, count, reason)
            _log("PKM_KODI_EXIT_COUNTDOWN_V2171 reason=%s second=%d" % (reason or "unknown", count))
            if monitor is not None:
                if monitor.waitForAbort(1.0):
                    return False
            else:
                xbmc.sleep(1000)

        _set_props(title, detail, "Kodi가 종료됩니다.", None, reason)
        _log("PKM_KODI_EXIT_DISPATCH_V2171 reason=%s action=Quit" % (reason or "unknown"))
        if monitor is not None:
            monitor.waitForAbort(0.12)
        else:
            xbmc.sleep(120)
        xbmc.executebuiltin("Quit")
        # v2172: no artificial post-Quit hold.  Kodi starts its own teardown
        # immediately; keeping this caller alive made the final surface appear
        # frozen for roughly five seconds even though Quit was already accepted.
        _log("PKM_KODI_EXIT_POST_HOLD_REMOVED_V2172 reason=%s" % (reason or "unknown"))
        return True
    except Exception as exc:
        _log("PKM_KODI_EXIT_COUNTDOWN_FAILED_V2171 reason=%s err=%s" % (reason or "unknown", exc), xbmc.LOGERROR)
        # A broken countdown must not trap the user in a non-exitable Kodi.
        # Preserve roughly the requested delay even in the emergency fallback.
        try:
            for count in (3, 2, 1):
                _set_props(title, detail, "%d초 뒤에 Kodi가 종료됩니다." % count, count, reason)
                xbmc.sleep(1000)
            _set_props(title, detail, "Kodi가 종료됩니다.", None, reason)
            xbmc.sleep(120)
        except Exception:
            pass
        try:
            xbmc.executebuiltin("Quit")
        except Exception:
            pass
        return False


def _main():
    reason = "skin_shutdown_menu"
    if len(sys.argv) > 1 and str(sys.argv[1] or "").strip():
        reason = str(sys.argv[1]).strip()
    request_kodi_exit_v2171(reason=reason, title="Kodi 종료", detail="")


if __name__ == "__main__":
    _main()
