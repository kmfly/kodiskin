# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import time
import unicodedata
import re

TIMER_ICON_PATTERN = "special://home/addons/plugin.video.plex_km/resources/skins/Default/media/progress/timer/timer_%03d.png"


def duration_text(duration):
    try:
        d = int(duration or 0)
        if d > 10000:
            minutes = int(round(d / 60000.0))
        else:
            minutes = int(round(d / 60.0)) if d > 300 else d
        if minutes <= 0:
            return ""
        h = minutes // 60
        m = minutes % 60
        if h and m:
            return "%d시간 %d분" % (h, m)
        if h:
            return "%d시간" % h
        return "%d분" % m
    except Exception:
        return ""


def remaining_time_props(duration_raw, view_offset_raw):
    try:
        duration = int(float(duration_raw or 0))
        offset = int(float(view_offset_raw or 0))
        if duration <= 0 or offset <= 0:
            return "", ""

        # Plex duration can arrive as milliseconds, while some local/cache
        # rows store seconds. Plex viewOffset is normally milliseconds.
        duration_ms = duration * 1000 if duration < 10000 else duration
        if offset < 10000 and duration_ms > 100000 and (offset * 1000) <= int(duration_ms * 1.05):
            offset_ms = offset * 1000
        else:
            offset_ms = offset

        if duration_ms <= 0 or offset_ms <= 0 or offset_ms >= duration_ms:
            return "", ""

        remaining_ms = max(0, duration_ms - offset_ms)
        remaining_min = int(round(remaining_ms / 60000.0))
        if remaining_min <= 0:
            return "", ""

        h = remaining_min // 60
        m = remaining_min % 60
        if h and m:
            text = "남은시간 %d시간 %d분" % (h, m)
        elif h:
            text = "남은시간 %d시간" % h
        else:
            text = "남은시간 %d분" % m

        # The timer icon's yellow arc represents watched/progress time,
        # while the text intentionally shows remaining time.
        watched_ms = max(0, min(offset_ms, duration_ms))
        pct = int(round((float(watched_ms) / float(duration_ms)) * 100.0 / 5.0) * 5)
        pct = max(0, min(100, pct))
        icon = TIMER_ICON_PATTERN % pct
        return text, icon
    except Exception:
        return "", ""


def summary_display_text(text, limit=150):
    try:
        value = " ".join((text or "").replace("\r", " ").replace("\n", " ").split())
        if not value:
            return ""
        if len(value) <= limit:
            return value
        cut = value[:limit].rstrip()
        pos = cut.rfind(" ")
        if pos >= int(limit * 0.65):
            cut = cut[:pos].rstrip()
        return cut.rstrip(" .,;:·/") + "..."
    except Exception:
        return text or ""


def _display_units(value):
    total = 0
    for ch in value:
        total += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return total


def title_display_text(text, limit_units=51):
    try:
        value = " ".join((text or "").replace("\r", " ").replace("\n", " ").split())
        if not value:
            return ""
        if _display_units(value) <= limit_units:
            return value

        target = max(1, limit_units - 3)
        cut = ""
        for ch in value:
            if _display_units(cut + ch) > target:
                break
            cut += ch
        cut = cut.rstrip()
        pos = cut.rfind(" ")
        if pos >= int(len(cut) * 0.65):
            cut = cut[:pos].rstrip()
        return cut.rstrip(" .,;:·/") + "..."
    except Exception:
        return text or ""


def _unique_csv_text(text):
    value = (text or "").replace(" / ", ", ").replace("/", ", ")
    parts = []
    for part in value.split(","):
        item = part.strip()
        if item and item not in parts:
            parts.append(item)
    return ", ".join(parts) if parts else " ".join((text or "").split())


# Home/Info genre labels should remain Korean even when Plex returns the
# provider's English genre names.  Translate only complete comma-separated
# genre tokens so titles or already-localized Korean text are never altered.
_GENRE_KO = {
    "action": "액션",
    "adventure": "모험",
    "animation": "애니메이션",
    "anime": "애니메이션",
    "biography": "전기",
    "children": "어린이",
    "comedy": "코미디",
    "crime": "범죄",
    "documentary": "다큐멘터리",
    "drama": "드라마",
    "family": "가족",
    "fantasy": "판타지",
    "film-noir": "필름 누아르",
    "film noir": "필름 누아르",
    "game show": "게임쇼",
    "history": "역사",
    "horror": "공포",
    "kids": "어린이",
    "music": "음악",
    "musical": "뮤지컬",
    "mystery": "미스터리",
    "news": "뉴스",
    "reality": "리얼리티",
    "romance": "로맨스",
    "sci-fi": "SF",
    "science fiction": "SF",
    "short": "단편",
    "sport": "스포츠",
    "sports": "스포츠",
    "talk": "토크",
    "talk show": "토크쇼",
    "thriller": "스릴러",
    "tv movie": "TV 영화",
    "war": "전쟁",
    "western": "서부극",
}


def _localized_genre_text(text):
    value = (text or "").replace(" / ", ", ").replace("/", ", ")
    result = []
    for raw in value.split(","):
        item = raw.strip()
        if not item:
            continue
        localized = _GENRE_KO.get(item.casefold(), item)
        if localized not in result:
            result.append(localized)
    return ", ".join(result) if result else " ".join((text or "").split())


def genre_display_text(text, limit=62):
    try:
        value = _localized_genre_text(text)
        if len(value) <= limit:
            return value
        cut = value[:limit].rstrip()
        pos = cut.rfind(",")
        if pos >= int(limit * 0.55):
            cut = cut[:pos].rstrip()
        return cut.rstrip(" ,/") + "..."
    except Exception:
        return text or ""


def person_list_display_text(text, limit=72):
    try:
        value = _unique_csv_text(text)
        if len(value) <= limit:
            return value
        cut = value[:limit].rstrip()
        pos = cut.rfind(",")
        if pos >= int(limit * 0.45):
            cut = cut[:pos].rstrip()
        return cut.rstrip(" ,/") + "..."
    except Exception:
        return text or ""


def text_needs_open_sans(text):
    # Kept the same semantic used by plexkm_home_window._text_has_cyrillic:
    # text requires the wide foreign/CJK-safe director font.
    try:
        value = str(text or "")
        for ch in value:
            code = ord(ch)
            if (0x0400 <= code <= 0x04FF) or (0x0500 <= code <= 0x052F) or (0x2DE0 <= code <= 0x2DFF) or (0xA640 <= code <= 0xA69F):
                return True
            if (0x3040 <= code <= 0x30FF) or (0x3400 <= code <= 0x4DBF) or (0x4E00 <= code <= 0x9FFF) or (0xF900 <= code <= 0xFAFF):
                return True
    except Exception:
        pass
    return False


# v1571: Plex contentRating full-audit normalization with age-only adult labels.
#
# The user's server contained 282 distinct raw values across movies, shows and
# episodes.  Plex may expose a domestic Korean string, a country-prefixed
# certification (sg/M18, us/PG-13, de/16), or a provider placeholder (-, -1,
# NR).  Keep the presentation Korean-only and preserve meaningful ages instead
# of leaking the raw country/code string into the Info metadata line.
_CONTENT_RATING_EXACT_V1569 = {
    # Existing PKM/plain values.
    "kr/all": "전체", "kr/0": "전체", "all": "전체", "0": "전체",
    "전체관람가": "전체", "모든연령시청가": "전체", "연소자관람가": "전체",
    "청불": "19세", "청소년관람불가": "19세",
    "kr/7": "7세", "7": "7세", "kr/12": "12세", "12": "12세",
    "kr/15": "15세", "15": "15세", "kr/18": "18세", "18": "18세",
    "kr/19": "19세", "19": "19세",
    "g": "전체", "pg": "12세", "pg-13": "15세", "pg13": "15세",
    "r": "17세", "nc-17": "17세", "nc17": "17세",
    "tv-y": "전체", "tv-y7": "7세", "tv-g": "전체",
    "tv-pg": "12세", "tv-14": "15세", "tv-ma": "17세",
    "u": "전체", "12a": "12세", "r18": "18세",

    # Korean provider variants observed in the full audit.
    "kr/전체관람가": "전체", "kr/연소자관람가": "전체",
    "kr/청소년관람불가": "19세", "kr/limited": "19세",
    "kr/r": "19세", "kr/kr/r": "19세", "kr/kr/12": "12세",

    # United States.
    "us/g": "전체", "us/pg": "보호자 지도", "us/pg-13": "13세",
    "us/pg13": "13세", "us/r": "17세", "us/nc-17": "17세",
    "us/nc17": "17세", "us/tv-y": "전체", "us/tv-y7": "7세",
    "us/tv-g": "전체", "us/tv-pg": "보호자 지도",
    "us/tv-14": "14세", "us/tv-ma": "17세",

    # Singapore.
    "sg/g": "전체", "sg/pg": "보호자 지도", "sg/pg13": "13세",
    "sg/pg-13": "13세", "sg/nc16": "16세", "sg/m18": "18세",
    "sg/r21": "21세",

    # United Kingdom.
    "gb/u": "전체", "uk/u": "전체", "gb/pg": "보호자 지도",
    "uk/pg": "보호자 지도", "gb/12": "12세", "uk/12": "12세",
    "gb/12a": "12세", "uk/12a": "12세", "gb/15": "15세",
    "uk/15": "15세", "gb/18": "18세", "uk/18": "18세",
    "gb/r18": "18세", "uk/r18": "18세",

    # Japan.
    "jp/g": "전체", "jp/pg": "보호자 지도", "jp/pg12": "12세",
    "jp/pg-12": "12세", "jp/r15+": "15세", "jp/r15": "15세",
    "jp/r-15": "15세", "jp/r18+": "18세", "jp/r18": "18세",
    "jp/r-18": "18세", "jp/r-17+": "17세", "jp/r": "18세",
    "jp/all": "전체", "jp/0": "전체", "jp/ma": "18세",

    # Australia.
    "au/g": "전체", "au/pg": "보호자 지도", "au/m": "15세 권장",
    "au/ma15+": "15세", "au/ma15": "15세", "au/r18+": "18세",
    "au/r18": "18세", "au/x18+": "18세", "au/x18": "18세",

    # Germany / France / Canada.
    "de/0": "전체", "de/6": "6세", "de/12": "12세",
    "de/16": "16세", "de/18": "18세", "de/fsk0": "전체",
    "de/fsk6": "6세", "de/fsk12": "12세", "de/fsk16": "16세",
    "de/fsk18": "18세",
    "fr/u": "전체", "fr/tp": "전체", "fr/touspublics": "전체",
    "fr/10": "10세", "fr/12": "12세", "fr/16": "16세",
    "fr/18": "18세",
    "ca/g": "전체", "ca/pg": "보호자 지도", "ca/14a": "14세",
    "ca/18a": "18세", "ca/r": "18세", "ca/a": "18세",

    # Hong Kong / India.
    "hk/i": "전체", "hk/ii": "12세", "hk/iia": "12세",
    "hk/iib": "15세", "hk/iii": "18세", "hk/r": "18세",
    "hk/ma": "18세", "hk/pg": "보호자 지도", "cn/iib": "15세",
    "in/u": "전체", "in/ua": "보호자 지도", "in/u/a13+": "13세",
    "in/u/a16+": "16세", "in/a": "18세",

    # Italy / Netherlands / Brazil / Portugal.
    "it/t": "전체", "it/vm14": "14세", "it/vm18": "18세",
    "nl/al": "전체", "br/l": "전체",
    "pt/m/12": "12세", "pt/m/14": "14세", "pt/m/16": "16세",
    "pt/elivre": "전체", "pt/e12": "12세", "pt/e14": "14세",

    # Nordic / Central European symbols.
    "dk/a": "전체", "cz/u": "전체", "fi/s": "전체",
    "fi/k-7": "7세", "fi/k-12": "12세", "fi/k-16": "16세",
    "fi/pg": "보호자 지도", "gr/κ": "전체", "gr/k": "전체",
    "gr/κ-12": "12세", "gr/κ-15": "15세", "gr/κ-18": "18세",
    "gr/pg": "보호자 지도", "hu/kn": "전체",
    "ie/pg": "보호자 지도", "ie/15a": "15세",
    "no/a": "전체", "se/btl": "전체", "se/från7år": "7세",

    # Mexico / Malaysia / New Zealand / Philippines.
    "mx/aa": "전체", "mx/a": "전체", "mx/b": "12세",
    "mx/b-15": "15세", "mx/b15": "15세", "mx/c": "18세",
    "my/p13": "13세", "my/18pl": "18세", "nz/pg": "보호자 지도",
    "nz/m": "16세", "ph/g": "전체", "ph/pg": "보호자 지도",

    # Spain / Belgium / Indonesia / Ukraine.
    "es/apta": "전체", "es/a": "전체", "es/ai": "전체",
    "es/pg": "보호자 지도", "es/r": "18세", "be/kt": "전체",
    "id/su": "전체", "id/r": "13세", "ua/za": "전체",

    # Taiwan / Thailand / Vietnam.
    "tw/普遍級": "전체", "tw/保護級": "보호자 지도", "tw/護6": "6세",
    "tw/輔12": "12세", "tw/輔12級": "12세", "tw/輔15級": "15세",
    "tw/輔導級": "15세", "tw/限制級": "18세", "tw/gp": "전체",
    "th/g": "전체", "th/pg": "보호자 지도", "th/ท": "전체",
    "vn/c16": "16세", "vn/k+": "보호자 지도",

    # Other observed symbolic values.
    "eg/r": "18세",
}

_CONTENT_RATING_EMPTY_V1569 = {
    "-", "--", "-1", "48",
    "nr", "n/r", "unrated", "notrated", "notrated.", "n/a", "na",
    "none", "unknown", "imdb",
    "us/nr", "jp/nr", "hk/n/a", "hk/nr", "mn/unrated", "nl/nr",
    "no/nr", "se/nr", "th/nr", "tw/nr", "jp/imdb",
    # Exempt/ambiguous source markers are safer hidden than shown as an
    # apparent age certification.
    "au/e", "jp/mild",
}


def _normalize_content_rating_key_v1569(value):
    try:
        text = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
    except Exception:
        text = str(value or "").strip().lower()
    return re.sub(r"\s+", "", text)


def localize_content_rating(value):
    raw = str(value or "").strip()
    if not raw:
        return ""

    low = _normalize_content_rating_key_v1569(raw)
    if low in _CONTENT_RATING_EXACT_V1569:
        return _CONTENT_RATING_EXACT_V1569[low]
    if low in _CONTENT_RATING_EMPTY_V1569:
        return ""

    # Any country-prefixed NR/N-A/Unrated variant is metadata absence, not a
    # certification.  Do not expose it and do not let it be mistaken for age.
    if re.search(r"/(?:nr|n/?a|unrated|notrated|none|unknown)$", low):
        return ""

    # Normalize repeated `kr/` prefixes and Korean provider text variants.
    kr_tail = low
    while kr_tail.startswith("kr/"):
        kr_tail = kr_tail[3:]
    if kr_tail in ("all", "0", "전체", "전체관람가", "모든연령시청가", "연소자관람가"):
        return "전체"
    if "청소년관람불가" in kr_tail or kr_tail in ("r", "limited"):
        return "19세"

    match = re.search(r"(?<!\d)(\d{1,2})세(?:이상)?(?:시청가|관람가)?$", kr_tail)
    if match:
        age = int(match.group(1))
        return "%d세" % age

    # Bare Korean/provider numeric values stay numeric, including 18 and 19.
    # Invalid values such as -1 and 48 were removed above.
    if kr_tail.isdigit():
        age = int(kr_tail)
        if age == 0:
            return "전체"
        if age in (7, 12, 15):
            return "%d세" % age
        if age in (18, 19):
            return "%d세" % age
        return ""

    # Most remaining foreign systems encode the actual minimum age at the end
    # (ru/16+, fi/K-16, pt/M/12, tw/輔12級, vn/C16).  Preserve that age and remove
    # the country/code prefix.
    match = re.search(r"(?<!\d)(0|[1-9]|1\d|2[01])(?:\+|세|급|år)?$", low)
    if match:
        age = int(match.group(1))
        return "전체" if age == 0 else "%d세" % age

    # A future Korean label can remain visible, but an unknown foreign code is
    # intentionally hidden so raw English/country codes never leak back into
    # the Info line.  It can be added to the exact table after another audit.
    if re.search(r"[가-힣]", raw) and not re.search(r"[A-Za-z]", raw):
        return raw
    return ""

def rating_display_text(content_rating, rating):
    value = localize_content_rating(content_rating)
    if value:
        return value
    value = str(rating or "").strip()
    if not value:
        return ""
    try:
        f = float(value)
        return ("%.1f" % f).rstrip("0").rstrip(".")
    except Exception:
        return value


def date_display_text(value):
    value = str(value or "").strip()
    if not value:
        return ""
    try:
        # Plex addedAt/updatedAt are epoch seconds. Keep this local and cheap.
        if value.isdigit():
            ts = int(value)
            if ts > 0:
                months = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                tm = time.localtime(ts)
                return "%s %d, %04d" % (months[tm.tm_mon - 1], tm.tm_mday, tm.tm_year)
    except Exception:
        pass
    try:
        # already a YYYY-MM-DD style date
        parts = value.split("T", 1)[0].split("-")
        if len(parts) == 3 and len(parts[0]) == 4:
            months = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
            y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
            if 1 <= m <= 12:
                return "%s %d, %04d" % (months[m - 1], d, y)
    except Exception:
        pass
    return value


def season_display_text(season):
    """Return the shared PKM season text without the leading '시즌 '.

    PKM libraries use 100-series season indexes for duplicate 4K seasons:
    1 -> 1, 101 -> 1 4K. Episode numbers are never normalized this way.
    """
    try:
        s = int(season or 0)
        if 101 <= s <= 199:
            return "%d 4K" % (s - 100)
        if s > 0:
            return str(s)
    except Exception:
        pass
    return ""


def episode_identity_text(season, episode):
    """Shared Korean season/episode identity for Home and TV Info."""
    try:
        s = int(season or 0)
    except Exception:
        s = 0
    try:
        e = int(episode or 0)
    except Exception:
        e = 0
    season_text = season_display_text(s)
    if season_text and e > 0:
        return "시즌 %s 에피소드 %d" % (season_text, e)
    if season_text:
        return "시즌 %s" % season_text
    if e > 0:
        return "에피소드 %d" % e
    return ""


def episode_code_text(season, episode):
    return episode_identity_text(season, episode)


def home_episode_code_text(season, episode):
    return episode_identity_text(season, episode)


def episode_fallback_title(episode):
    try:
        ep = int(episode or 0)
        if ep > 0:
            return "에피소드 %d" % ep
    except Exception:
        pass
    return ""


def normalize_episode_title(title, episode=""):
    """Normalize only generic episode placeholders; preserve real Plex titles."""
    text = str(title or "").strip()
    if text:
        try:
            match = re.match(r"^Episode\s*(\d+)\s*$", text, flags=re.IGNORECASE)
            if match:
                return "에피소드 %d" % int(match.group(1))
            match = re.match(r"^에피소드\s*(\d+)\s*$", text)
            if match:
                return "에피소드 %d" % int(match.group(1))
        except Exception:
            pass
        return text
    return episode_fallback_title(episode)


def home_titles_for_meta(plex_type, title, show_title, episode):
    title = str(title or "").strip()
    show_title = str(show_title or "").strip()
    if plex_type == "episode":
        hero_title = show_title or title
        episode_title = title if title and title != hero_title else ""
        episode_title = normalize_episode_title(episode_title, episode)
        return hero_title, episode_title
    return title, ""


def home_meta_line(plex_type, show_title, season, episode, year, duration, content_rating, rating, added_at=""):
    # IMDb/Plex scores have their own rating row. This position is for the
    # certification only, so an unavailable contentRating must not briefly
    # appear as a numeric score such as 6.2.
    rating_text = localize_content_rating(content_rating)
    meta_parts = []
    if plex_type == "episode":
        # v1241: match Plex HTPC Home: S1 E1 / year / duration.
        # Do not show the full premiered/added date on the Home hero line.
        for v in (home_episode_code_text(season, episode), year, duration, rating_text):
            if v:
                meta_parts.append(str(v))
    else:
        for v in (year, duration, rating_text):
            if v:
                meta_parts.append(str(v))
    return "   ".join(meta_parts)
