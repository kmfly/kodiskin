"""
plexkm 로딩바 프레임 생성기 v3 (p-first)
- 입력 이미지의 2048x1152 캔버스/로고 크기/좌표를 변경하지 않음
- 첫 프레임은 p만 골드
- 이후 p 오른쪽부터 m 끝까지 smoothstep으로 채움
- 120 frames, 20ms/frame = 2.4s
"""
from pathlib import Path
from PIL import Image
import numpy as np
from scipy import ndimage

FRAME_COUNT = 120
GOLD = np.array([229.0, 160.0, 13.0], dtype=np.float32)
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "plexkm_white_v4.png"
OUT_DIR = ROOT / "plexkm_loading_v3_pfirst_frames"

src = Image.open(SRC).convert("RGBA")
arr = np.array(src)
lum = (0.2126 * arr[:, :, 0].astype(np.float32) +
       0.7152 * arr[:, :, 1].astype(np.float32) +
       0.0722 * arr[:, :, 2].astype(np.float32))
logo_mask = lum > 2.0
labels, count = ndimage.label(logo_mask)
components = []
for idx, s in enumerate(ndimage.find_objects(labels), 1):
    if s is None:
        continue
    ys, xs = s
    area = int((labels[s] == idx).sum())
    if area >= 20:
        components.append((xs.start, xs.stop - 1, area))
components.sort(key=lambda item: item[0])
p_right = components[0][1]
logo_right = int(np.where(logo_mask)[1].max())
xgrid = np.arange(arr.shape[1])[None, :]
OUT_DIR.mkdir(parents=True, exist_ok=True)

for i in range(FRAME_COUNT):
    t = i / (FRAME_COUNT - 1)
    ease = t * t * (3.0 - 2.0 * t)
    fill_x = int(round(p_right + (logo_right - p_right) * ease))
    out = arr.copy()
    fill = logo_mask & (xgrid <= fill_x)
    scale = (lum[fill] / 255.0)[:, None]
    out[fill, :3] = np.clip(GOLD[None, :] * scale, 0, 255).astype(np.uint8)
    Image.fromarray(out, "RGBA").save(OUT_DIR / f"frame_{i:03d}.png", optimize=True)

print(f"generated {FRAME_COUNT} frames: p_right={p_right}, logo_right={logo_right}, size={src.size}")
