# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Phone entry for the YouTube Data API key (R79).

While the PKM YouTube settings panel shows "휴대폰으로 입력", a tiny HTTP page
is served on the Android device's LAN address.  The TV shows a QR code for
http://<lan-ip>:<port>/<token>; the phone opens it, pastes the key and taps
저장.  The key is checked with the Data API before it is stored, and the
result is shown on both the phone and the TV.

Only the random token path answers; everything else is 404.  The server
stops when the panel leaves phone mode, when the window closes, or after
IDLE_LIMIT_SEC.
"""

import os
import random
import string
import threading
import time
import traceback

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import parse_qs
except ImportError:  # pragma: no cover - Kodi 18
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import parse_qs

import xbmc

PREFERRED_PORTS = (8738, 8739, 8748, 0)
IDLE_LIMIT_SEC = 15 * 60
KEY_CHARS = set(string.ascii_letters + string.digits + "-_")


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Plex KM] YT KEYSERVER %s" % msg, level)
    except Exception:
        pass


def clean_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    if len(key) < 30 or len(key) > 60 or any(ch not in KEY_CHARS for ch in key):
        return "", "API 키 형식이 아닙니다 (보통 AIza로 시작하는 39자)"
    return key, ""


def mask_key(key):
    key = str(key or "")
    if len(key) <= 12:
        return key
    return key[:6] + "…" + key[-4:]


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class KeyServer(object):
    """on_key(key) -> (ok, message); called from the HTTP thread."""

    def __init__(self, on_key, on_event=None, kind="apikey"):
        self.on_key = on_key
        self.kind = kind
        self.on_event = on_event or (lambda kind, text: None)
        self.token = "".join(random.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(6))
        self.ip = ""
        self.port = 0
        self.url = ""
        self.httpd = None
        self.thread = None
        self.last_hit = time.time()
        self._stop = threading.Event()

    def page(self, msg_html=""):
        from resources.lib import pkm_youtube_guide_pages as guide
        kw = {}
        if self.kind == "backup":
            from resources.lib import pkm_youtube_backup as bk
            cur = bk.collect()
            if bk.is_meaningful(cur):
                kw = {"summary": bk.summary(cur), "created": "기기 백업: %s" % (bk.backup_path() or "없음")}
        html = guide.build(self.kind, msg_html, **kw)
        base = "/" + self.token + "/"
        return (html.replace("href='site/", "href='" + base + "site/")
                    .replace("href='backup.json'", "href='" + base + "backup.json'"))

    # -------------------------------------------------------------- start / stop

    def start(self):
        from resources.lib.pkm_token_import import _local_ip
        self.ip = _local_ip()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                return

            def _route(self):
                path = self.path.split("?", 1)[0].rstrip("/")
                base = "/" + owner.token
                if path == base:
                    return "page"
                if path.startswith(base + "/"):
                    return path[len(base) + 1:]
                return None

            def _ok_path(self):
                return self._route() == "page"

            def _send(self, code, body, ctype="text/html; charset=utf-8", filename=""):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                if filename:
                    self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                route = self._route()
                if route is None:
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                if route == "site/index.html" and owner.kind == "perm":
                    from resources.lib.pkm_youtube_guide_pages import SITE_INDEX
                    self._send(200, SITE_INDEX, "text/html; charset=utf-8", "index.html")
                    return
                if route == "site/privacy.html" and owner.kind == "perm":
                    from resources.lib.pkm_youtube_guide_pages import SITE_PRIVACY
                    self._send(200, SITE_PRIVACY, "text/html; charset=utf-8", "privacy.html")
                    return
                if route == "backup.json" and owner.kind == "backup":
                    import json as _json
                    from resources.lib import pkm_youtube_backup as bk
                    owner.on_event("open", "휴대폰으로 백업 파일을 보냈습니다")
                    self._send(200, _json.dumps(bk.collect(), ensure_ascii=False, indent=1),
                               "application/json; charset=utf-8", "pkm_youtube_backup.json")
                    return
                if route != "page":
                    self._send(404, "not found")
                    return
                owner.on_event("open", "휴대폰에서 페이지를 열었습니다")
                self._send(200, owner.page())

            def do_POST(self):
                if not self._ok_path():
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                try:
                    size = min(int(self.headers.get("Content-Length") or 0), 4 * 1024 * 1024)
                    raw = self.rfile.read(size).decode("utf-8", "replace")
                    form = dict((k, (v or [""])[0]) for k, v in parse_qs(raw).items())
                except Exception:
                    form = {}
                if owner.kind == "oauth":
                    from resources.lib.pkm_youtube_account import clean_client
                    cid, sec, err = clean_client(form.get("client_id"), form.get("client_secret"))
                    key = (cid, sec)
                elif owner.kind == "backup":
                    from resources.lib import pkm_youtube_backup as bk
                    key, err = bk.parse(form.get("backup") or "")
                elif owner.kind == "perm":
                    key, err = None, "이 페이지는 입력이 없습니다"
                else:
                    key, err = clean_key(form.get("key"))
                if err:
                    ok, msg = False, err
                else:
                    owner.on_event("checking", "휴대폰에서 받은 값을 확인하는 중…")
                    try:
                        ok, msg = owner.on_key(key)
                    except Exception:
                        _log("ON_KEY_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                        ok, msg = False, "저장 중 오류가 발생했습니다"
                if not ok:
                    owner.on_event("error", msg)
                box = '<div class="msg %s">%s</div>' % ("ok" if ok else "bad",
                                                       (msg + " · TV 화면을 확인하세요") if ok else msg)
                self._send(200, owner.page(box))

        last_err = None
        for port in PREFERRED_PORTS:
            try:
                self.httpd = _Server(("0.0.0.0", port), Handler)
                break
            except Exception as exc:
                last_err = exc
                self.httpd = None
        if self.httpd is None:
            _log("BIND_FAILED err=%s" % last_err, xbmc.LOGWARNING)
            return False
        self.port = self.httpd.server_address[1]
        self.url = "http://%s:%d/%s" % (self.ip, self.port, self.token)
        self.thread = threading.Thread(target=self._serve, name="PKMYTKeyServer")
        self.thread.daemon = True
        self.thread.start()
        _log("STARTED ip=%s port=%d" % (self.ip, self.port))
        return True

    def _serve(self):
        httpd = self.httpd
        try:
            httpd.timeout = 1.0
            while not self._stop.is_set():
                httpd.handle_request()
                if time.time() - self.last_hit > IDLE_LIMIT_SEC:
                    _log("IDLE_STOP")
                    self.on_event("idle", "시간이 지나 휴대폰 입력을 멈췄습니다. 다시 선택하세요")
                    break
        except Exception:
            _log("SERVE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        finally:
            try:
                httpd.server_close()
            except Exception:
                pass

    def stop(self):
        self._stop.set()
        _log("STOP")

    @property
    def running(self):
        return bool(self.thread and self.thread.is_alive() and not self._stop.is_set())


def write_qr(text, path):
    try:
        from resources.lib.pkm_token_import import _write_qr_png
        if os.path.exists(path):
            os.remove(path)
        return _write_qr_png(text, path, scale=10, border=3)
    except Exception:
        _log("QR_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False
