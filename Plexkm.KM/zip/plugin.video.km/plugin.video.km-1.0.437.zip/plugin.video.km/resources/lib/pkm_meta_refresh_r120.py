# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""R120: fill in missing metadata for ONE movie/show through its agent.

User-triggered only (card menu).  Runs entirely on a worker thread: it never
touches a ListItem; the caller applies the returned item to the card.

Plex item  -> ask the Plex server's agent, but NEVER apply a guess:
              plex_candidates() searches with title + year (GET .../matches) and
              changes nothing; the user picks the right one in a list; only then
              plex_apply() fixes the match (PUT .../match, or .../refresh when the
              pick is the current match), polls the item and rewrites just that
              row.  No pick / cancel = the item stays exactly as it was.
Kodi item  -> VideoLibrary.RefreshMovie / RefreshTVShow (the configured
              scraper), poll, then pkm_kodi_source.sync_one().

refresh() returns {"ok", "code", "message", "item", "filled", "action"}.
"""

import re
import sqlite3
import threading
import time
import traceback
try:
    from urllib.parse import quote
except Exception:  # pragma: no cover
    from urllib import quote

try:
    import xbmc
except Exception:  # unit tests run outside Kodi
    xbmc = None

COOLDOWN_SEC = 30
MAX_CANDIDATES = 6
POLL_INTERVAL = 2.0
POLL_TIMEOUT = 30.0
SETTLE_SEC = 3.0
_FIELDS = ("title", "year", "summary", "thumb")

_lock = threading.Lock()
_last = {}        # rating_key -> monotonic time of the last request
_running = set()  # rating keys with a request in flight


def _log(msg, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log("[plugin.video.km] META_REFRESH_R120 %s" % msg, xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


# ------------------------------------------------------------------ cooldown
def begin(rating_key):
    """-> (True, 0) and marks the item busy, or (False, seconds_left)."""
    rk = str(rating_key)
    now = time.time()
    with _lock:
        if rk in _running:
            return False, COOLDOWN_SEC
        left = COOLDOWN_SEC - (now - _last.get(rk, 0.0))
        if left > 0:
            return False, int(left) + 1
        _running.add(rk)
        _last[rk] = now
        return True, 0


def end(rating_key):
    with _lock:
        _running.discard(str(rating_key))
        _last[str(rating_key)] = time.time()


# ------------------------------------------------------------------ helpers
def _norm(text):
    return re.sub(r"[\W_]+", "", str(text or "").lower(), flags=re.U)


def _int(value):
    try:
        return int(float(value or 0))
    except Exception:
        return 0


def _snapshot(item):
    return tuple(str(item.get(k) or "") for k in _FIELDS)


def _filled(before, after):
    """Fields that were empty (or, for the title, different) and now have a value."""
    out = []
    for key in _FIELDS:
        b, a = str(before.get(key) or ""), str(after.get(key) or "")
        if key == "year":
            b, a = ("" if _int(b) <= 0 else b), ("" if _int(a) <= 0 else a)
        if a and a != b and (key == "title" or not b):
            out.append(key)
    return out


def _fail(code, message):
    return {"ok": False, "code": code, "message": message, "item": None, "filled": [], "action": ""}


def _classify(exc):
    text = str(exc)
    if "HTTP error 401" in text or "HTTP error 403" in text:
        return _fail("auth", "Plex 편집 권한이 없습니다")
    if "HTTP error 404" in text:
        return _fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다")
    if "connection error" in text or "timed out" in text or "request failed" in text:
        return _fail("network", "Plex 서버에 연결하지 못했습니다")
    return _fail("error", "메타 갱신에 실패했습니다")


def _row(conn, rating_key):
    r = conn.execute("SELECT rating_key, section_id, plex_type, title, year, summary, thumb, raw_json, original_title "
                     "FROM items WHERE rating_key=?", (str(rating_key),)).fetchone()
    if not r:
        return None
    guid = ""
    try:
        import json
        guid = str((json.loads(r[7] or "{}")).get("guid") or "")
    except Exception:
        pass
    return {"rating_key": r[0], "section_id": str(r[1] or ""), "plex_type": r[2], "title": r[3] or "",
            "year": r[4] or 0, "summary": r[5] or "", "thumb": r[6] or "", "guid": guid,
            "original_title": r[8] or ""}


# ------------------------------------------------------------------ Plex
def needs_match(guid, summary="", thumb=""):
    """An item the agent never matched: local guid, no agent, or nothing filled in."""
    g = str(guid or "").lower()
    if not g or g.startswith("local://") or "agents.none" in g:
        return True
    return not str(summary or "").strip() and not str(thumb or "").strip()


def pick_match(results, title, year):
    """results: [{"guid","name","year","score"}] -> the one safe candidate or None.

    Safe = same title (ignoring case/spaces/punctuation) AND same year.  When
    several qualify, the highest agent score wins.  Anything looser is left
    to the user (Plex's own Fix Match), never applied automatically.
    """
    want_t, want_y = _norm(title), _int(year)
    if not want_t or want_y <= 0:
        return None
    best = None
    for r in results or []:
        if _norm(r.get("name")) != want_t or _int(r.get("year")) != want_y or not r.get("guid"):
            continue
        if best is None or _int(r.get("score")) > _int(best.get("score")):
            best = r
    return best


def _plex_node(core, rating_key):
    root = core.plex_request_xml("/library/metadata/%s" % rating_key, params={"skipRefresh": 1},
                                 timeout=10, log_failures=False, bypass_cache=True)
    for child in list(root):
        if child.tag in ("Video", "Directory"):
            return child
    return None


def _plex_agent(core, section_id, plex_type="", guid=""):
    """The section's metadata agent.  /library/sections lists it per Directory
    (the single-section response does not); fall back to the new Plex agent
    for the item's type when the item already carries a plex:// guid."""
    try:
        root = core.plex_request_xml("/library/sections", timeout=8, log_failures=False)
        for child in list(root):
            if str(child.get("key") or "") == str(section_id) and child.get("agent"):
                return child.get("agent")
    except Exception:
        pass
    if str(guid or "").startswith("plex://"):
        return {"movie": "tv.plex.agents.movie", "show": "tv.plex.agents.series"}.get(str(plex_type), "")
    return ""


def _param_variants(agent):
    """Parameter sets for GET .../matches, most specific first.  Plex answers an
    unsuitable language/agent combination with an EMPTY list (not an error), so
    the next looser variant is tried before giving up."""
    out = []
    if agent:
        out.append({"agent": agent, "language": "ko-KR"})
        out.append({"agent": agent})
    out.append({"language": "ko-KR"})
    out.append({})
    return out


_TMDB_IN_PATH = re.compile(r"[\{\[]\s*tmdb(?:id)?\s*[-=]\s*(\d{1,12})\s*[\}\]]", re.I)
_GENERIC_FOLDERS = set(_n for _n in (
    "영화", "더빙", "자막", "외화", "국내", "한국", "해외", "애니", "애니메이션", "다큐", "미분류", "기타", "최신", "신작",
    "movie", "movies", "film", "films", "video", "videos", "dubbed", "sub", "subs", "etc", "new", "download", "downloads",
    "gdrive", "rclone", "volume1", "mnt", "media", "data") for _n in [re.sub(r"[\W_]+", "", _n.lower(), flags=re.U)])
_PLACEHOLDER_RE = re.compile(r"^[A-Za-z]{0,4}[\s_\-]?\d{5,}$", re.U)
_NOISE_RE = re.compile(
    r"\b(2160p|1080[pi]|720p|480p|4k|uhd|hdr10?\+?|dv|x26[45]|h\.?26[45]|hevc|avc|bluray|blu-ray|bdrip|brrip|"
    r"web-?dl|webrip|hdrip|dvdrip|remux|aac\d*|ac3|eac3|dts(-hd)?|atmos|ddp?\d*|10bit|nf|amzn|dsnp|kor|korsub)\b.*$",
    re.I | re.U)


def _is_placeholder(title):
    """MT1641962-style codes: the scanner had nothing better than a file/ID code."""
    return bool(_PLACEHOLDER_RE.match(str(title or "").strip()))


def _real_year(value):
    y = _int(value)
    return y if 1920 <= y <= 2100 else 0     # 1900 / 0 = "unknown", never search with it


def _clean_release_name(text):
    """'Alexander.2004.1080p.BluRay.x264-GRP' / '알렉산더 (2004) [1080p]' -> ('알렉산더', 2004)."""
    t = str(text or "")
    t = re.sub(r"\{[^}]*\}", " ", t)                                   # {tmdb-123} {imdb-tt1}
    year = 0
    m = re.search(r"[\(\[\.\s_\-]((?:19|20)\d{2})[\)\]\.\s_\-]", " " + t + " ")
    if m:
        year = int(m.group(1))
    t = re.sub(r"\[[^\]]*\]", " ", t)                                  # [1080p] [GRP]
    t = re.sub(r"\(\s*(?:19|20)\d{2}\s*\)", " ", t)                    # (2004)
    t = re.sub(r"[._]+", " ", t)
    t = _NOISE_RE.sub("", t)
    if year:
        t = re.sub(r"\s*\b%d\b.*$" % year, "", t)                      # cut at the year token
    t = re.sub(r"\s*-\s*[A-Za-z0-9]+$", "", t) if re.search(r"\s-\s*[A-Za-z0-9]+$", t) and not re.search(r"[가-힣]", t) and len(t.split()) > 2 else t
    t = re.sub(r"\s+", " ", t).strip(" -_.")
    return t, year


def file_title_variants(file_path):
    """(name, year) pairs taken from the media file name and its folder, best first.

    The Plex title is sometimes just a code (MT1641962) while the real name only
    lives in the file or folder name -- search with that instead."""
    path = str(file_path or "").replace("\\", "/").strip()
    if not path:
        return []
    parts = [x for x in path.split("/") if x]
    if not parts:
        return []
    stem = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", parts[-1])
    out, seen = [], set()

    def _add(raw):
        name, year = _clean_release_name(raw)
        # "MT1641962 - Real Title": the code is noise, keep only the real title
        name = re.sub(r"^[A-Za-z]{0,4}\d{5,}\s*[-_.\s]+\s*", "", name).strip()
        key = _norm(name)
        if len(key) >= 2 and key not in seen and not _is_placeholder(name):
            seen.add(key)
            out.append((name, year))

    # Folders that name the movie ("제목 (2026) {tmdb-N}") are the cleanest (Korean) source;
    # generic folders ("영화", "더빙", "마") carry neither a year nor an id and are skipped.
    for folder in reversed(parts[-4:-1]):
        if _TMDB_IN_PATH.search(folder) or re.search(r"[\(\[](?:19|20)\d{2}[\)\]]", folder):
            _add(folder)
    _add(stem)
    if not out and len(parts) > 1 and _norm(parts[-2]) not in _GENERIC_FOLDERS:
        _add(parts[-2])                     # the file is only a code: the movie folder may carry the name
    return out


def file_tmdb_id(file_path):
    """{tmdb-N} / [tmdbid-N] in the path (Plex/Jellyfin naming) -> 'N' or ''."""
    m = _TMDB_IN_PATH.search(str(file_path or ""))
    return m.group(1) if m else ""


def _title_variants(title, original_title, year, file_path=""):
    """(title, year) pairs to search, best first, without duplicates.

    A placeholder title (MT1641962) or an unknown year (1900) is not searchable:
    the file/folder name goes first and the year is dropped."""
    t = str(title or "").strip()
    y = _real_year(year)
    files = file_title_variants(file_path)
    base = re.sub(r"\s*[\(\[]\s*(19|20)\d{2}\s*[\)\]]\s*$", "", t)           # "제목 (2019)"
    base = re.sub(r"\s*(시즌|season)\s*\d+\s*$", "", base, flags=re.I | re.U)      # "제목 시즌 2"
    head = re.split(r"\s*[:：\-–]\s*", base, maxsplit=1)[0] if re.search(r"[:：]", base) else ""
    orig = str(original_title or "").strip()
    cands = []
    file_cands = []
    for name, fy in files:
        file_cands.append((name, fy or y))
        if fy or y:
            file_cands.append((name, 0))
    if _is_placeholder(t):
        cands.extend(file_cands)
    else:
        cands.extend([(t, y), (t, 0), (base, y), (head, y), (orig, y), (orig, 0)])
        cands.extend(file_cands)                                        # last resort for normal titles
    seen, out = set(), []
    for name, yy in cands:
        if _is_placeholder(name):
            continue
        key = (_norm(name), yy)
        if name and key not in seen:
            seen.add(key)
            out.append((name, yy))
    return out


def _plex_matches_once(core, rating_key, title, year, variant):
    params = {"manual": 1, "title": title}
    if _int(year) > 0:
        params["year"] = _int(year)
    params.update(variant)
    root = core.plex_request_xml("/library/metadata/%s/matches" % rating_key, params=params,
                                 timeout=20, log_failures=False, bypass_cache=True)
    res = [{"guid": n.get("guid", ""), "name": n.get("name", ""), "year": n.get("year", ""), "score": n.get("score", "0")}
           for n in list(root) if n.tag == "SearchResult"]
    _log("MATCH_TRY rating_key=%s title=%r year=%s variant=%s results=%d root=%s children=%s" % (
        rating_key, title, params.get("year", "-"), ",".join(sorted(variant)) or "bare", len(res),
        getattr(root, "tag", ""), ",".join(sorted(set(n.tag for n in list(root)))) or "-"))
    return res


def _plex_matches(core, rating_key, title, year, agent, original_title="", file_path=""):
    """Try title/parameter variants until the agent returns candidates."""
    variants = _param_variants(agent)
    for name, yy in _title_variants(title, original_title, year, file_path):
        for v in variants:
            res = _plex_matches_once(core, rating_key, name, yy, v)
            if res:
                return res
    return []


# ------------------------------------------------------------------ TMDB (primary)
_TMDB_PROPS = ["title", "originaltitle", "year", "plot", "art", "thumbnail", "uniqueid"]
_TMDB_PREFIX = "tmdb:"


def _tmdb_poster(item):
    art = item.get("art") or {}
    url = ""
    if isinstance(art, dict):
        url = art.get("poster") or art.get("thumb") or ""
    url = url or item.get("thumbnail") or ""
    url = str(url or "")
    return url if url.startswith("http") else ""


def _tmdb_fanart(item):
    art = item.get("art") or {}
    url = str((art.get("fanart") if isinstance(art, dict) else "") or item.get("fanart") or "")
    return url if url.startswith("http") else ""


_DETAIL_PROPS = ["title", "originaltitle", "year", "plot", "art", "cast", "genre", "director",
                 "rating", "mpaa", "runtime", "premiered", "studio", "country", "uniqueid"]


def _image_url(value):
    """TMDb Helper hands images back as Kodi image:// wrappers or plain URLs."""
    v = str(value or "")
    if v.startswith("image://"):
        try:
            from urllib.parse import unquote
        except Exception:  # pragma: no cover
            from urllib import unquote
        v = unquote(v[len("image://"):]).rstrip("/")
    return v if v.startswith("http") else ""


def tmdb_details(dir_fn, plex_type, tmdb_id):
    """R120: full TMDB record (poster, fanart, cast with photos, genres,
    directors) for the picked candidate.  {} when TMDb Helper has nothing."""
    tmdb_type = "tv" if str(plex_type) == "show" else "movie"
    out = {}
    try:
        items, _lang = dir_fn("plugin://plugin.video.themoviedb.helper/?info=details&tmdb_type=%s&tmdb_id=%s"
                              % (tmdb_type, tmdb_id), _DETAIL_PROPS, 41121)
    except Exception as exc:
        _log("TMDB_DETAILS tmdb=%s error=%s" % (tmdb_id, exc))
        items = []
    det = None
    for it in items or []:
        if str(((it.get("uniqueid") or {}).get("tmdb")) or "") == str(tmdb_id) or det is None:
            det = it
    if det:
        art = det.get("art") or {}
        out["thumb"] = _image_url(art.get("poster") or art.get("thumb") or det.get("thumbnail"))
        out["art"] = _image_url(art.get("fanart") or det.get("fanart"))
        out["summary"] = str(det.get("plot") or "")
        out["genres"] = [str(g) for g in (det.get("genre") or []) if str(g or "").strip()]
        out["directors"] = [str(d) for d in (det.get("director") or []) if str(d or "").strip()]
        cast = []
        for c in sorted(det.get("cast") or [], key=lambda c: _int(c.get("order"))):
            name = str(c.get("name") or "").strip()
            if name:
                cast.append({"name": name, "role": str(c.get("role") or ""), "thumb": _image_url(c.get("thumbnail"))})
        out["cast"] = cast
    if not out.get("cast"):
        try:
            people, _lang = dir_fn("plugin://plugin.video.themoviedb.helper/?info=cast&tmdb_type=%s&tmdb_id=%s"
                                   % (tmdb_type, tmdb_id), ["art", "thumbnail"], 41122)
        except Exception:
            people = []
        cast = []
        for p in people or []:
            name = str(p.get("label") or "").strip()
            if not name:
                continue
            art = p.get("art") or {}
            cast.append({"name": name, "role": str(p.get("label2") or ""),
                         "thumb": _image_url(art.get("thumb") or art.get("poster") or p.get("thumbnail"))})
        out["cast"] = cast
    _log("TMDB_DETAILS tmdb=%s type=%s poster=%d fanart=%d cast=%d genres=%d directors=%d" % (
        tmdb_id, tmdb_type, 1 if out.get("thumb") else 0, 1 if out.get("art") else 0,
        len(out.get("cast") or []), len(out.get("genres") or []), len(out.get("directors") or [])))
    return out


def _tmdb_search_once(dir_fn, tmdb_type, title, year):
    directory = "plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=%s&query=%s" % (
        tmdb_type, quote(str(title or ""), safe=""))
    if _int(year) > 0:
        directory += "&year=%d" % _int(year)
    try:
        items, lang = dir_fn(directory, _TMDB_PROPS, 41120)
    except Exception as exc:
        _log("TMDB_TRY title=%r year=%s type=%s error=%s" % (title, year or "-", tmdb_type, exc))
        return []
    res = []
    for it in items or []:
        tid = str(((it.get("uniqueid") or {}).get("tmdb")) or "")
        if not tid or not it.get("title"):
            continue
        res.append({"guid": _TMDB_PREFIX + tid, "tmdb_id": tid, "name": str(it.get("title") or ""),
                    "original_title": str(it.get("originaltitle") or ""), "year": _int(it.get("year")) or "",
                    "summary": str(it.get("plot") or ""), "thumb": _tmdb_poster(it),
                    "fanart": _tmdb_fanart(it), "score": "0"})
    _log("TMDB_TRY title=%r year=%s type=%s lang=%s results=%d" % (title, year or "-", tmdb_type, lang, len(res)))
    return res


def _tmdb_by_id(dir_fn, tmdb_type, tid):
    """The record the file path names ({tmdb-N}): exact, no title guessing."""
    try:
        items, _lang = dir_fn("plugin://plugin.video.themoviedb.helper/?info=details&tmdb_type=%s&tmdb_id=%s"
                              % (tmdb_type, tid), _TMDB_PROPS, 41123)
    except Exception as exc:
        _log("TMDB_BY_ID tmdb=%s error=%s" % (tid, exc))
        return None
    for it in items or []:
        if it.get("title") and (str(((it.get("uniqueid") or {}).get("tmdb")) or "") in ("", str(tid))):
            _log("TMDB_BY_ID tmdb=%s title=%r year=%s" % (tid, it.get("title"), it.get("year")))
            return {"guid": _TMDB_PREFIX + str(tid), "tmdb_id": str(tid), "name": str(it.get("title") or ""),
                    "original_title": str(it.get("originaltitle") or ""), "year": _int(it.get("year")) or "",
                    "summary": str(it.get("plot") or ""), "thumb": _tmdb_poster(it),
                    "fanart": _tmdb_fanart(it), "score": "100"}
    _log("TMDB_BY_ID tmdb=%s results=0" % tid)
    return None


def tmdb_matches(dir_fn, plex_type, title, original_title, year, file_path=""):
    """TMDB candidates through TMDb Helper (Korean).  Same title/year variants as the agent search.
    A {tmdb-N} in the file path is looked up directly and listed first."""
    tmdb_type = "tv" if str(plex_type) == "show" else "movie"
    by_id = None
    tid = file_tmdb_id(file_path)
    if tid:
        by_id = _tmdb_by_id(dir_fn, tmdb_type, tid)
    found = []
    for name, yy in _title_variants(title, original_title, year, file_path):
        found = _tmdb_search_once(dir_fn, tmdb_type, name, yy)
        if found:
            break
    if by_id:
        found = [by_id] + [c for c in found if c.get("tmdb_id") != by_id["tmdb_id"]]
    return found


def _tmdb_apply(core, row, candidate, dir_fn=None):
    """Local-only: write the chosen TMDB record into plex_km.db for this one row.

    R120b: not only title/year/plot/poster -- also the fanart, the cast (with
    photos), directors and genres, so the card, the Home/section hero and the
    Info page all change together."""
    rk = str(row["rating_key"])
    det = {}
    if dir_fn is not None and candidate.get("tmdb_id"):
        det = tmdb_details(dir_fn, row.get("plex_type"), candidate.get("tmdb_id"))
    conn = core.init_db()
    try:
        cur = _row(conn, rk)
        if not cur:
            return _fail("not_found", "항목을 찾지 못했습니다")
        before = dict(cur)
        art_before = str((conn.execute("SELECT art FROM items WHERE rating_key=?", (rk,)).fetchone() or [""])[0] or "")
        before["art"] = art_before
        item = dict(cur)
        item["title"] = candidate.get("name") or cur["title"]
        item["year"] = _int(candidate.get("year")) or cur["year"]
        item["summary"] = det.get("summary") or candidate.get("summary") or cur["summary"]
        item["thumb"] = det.get("thumb") or candidate.get("thumb") or cur["thumb"]
        item["art"] = det.get("art") or candidate.get("fanart") or art_before
        item["original_title"] = candidate.get("original_title") or cur.get("original_title") or ""
        item["tmdb_id"] = str(candidate.get("tmdb_id") or "")
        conn.execute("UPDATE items SET title=?, year=?, summary=?, thumb=?, art=?, original_title=? WHERE rating_key=?",
                     (item["title"], _int(item["year"]), item["summary"], item["thumb"], item["art"],
                      item["original_title"], rk))
        now = int(time.time())
        sid = str(cur.get("section_id") or "")
        cast = list(det.get("cast") or [])
        directors = list(det.get("directors") or [])
        if cast:
            conn.execute("DELETE FROM item_people WHERE rating_key=? AND person_type='actor'", (rk,))
            for i, c in enumerate(cast[:40]):
                conn.execute("INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                             "person_thumb, tag_id, sort_order, source, indexed_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                             (rk, sid, "actor", c["name"], c.get("role") or "", c.get("thumb") or "", "", i, "tmdb_r120", now))
        if directors:
            conn.execute("DELETE FROM item_people WHERE rating_key=? AND person_type='director'", (rk,))
            for i, d in enumerate(directors[:8]):
                conn.execute("INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                             "person_thumb, tag_id, sort_order, source, indexed_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                             (rk, sid, "director", d, "", "", "", i, "tmdb_r120", now))
        genres = list(det.get("genres") or [])
        if genres:
            conn.execute("DELETE FROM item_genres WHERE rating_key=?", (rk,))
            for g in genres[:12]:
                conn.execute("INSERT OR REPLACE INTO item_genres(rating_key, section_id, genre, tag_id, source, indexed_at) "
                             "VALUES (?,?,?,?,?,?)", (rk, sid, _genre_ko_r143(g), "", "tmdb_r120", now))
        conn.commit()
        item["cast_count"] = len(cast)
        upd = (conn.execute("SELECT updated_at FROM items WHERE rating_key=?", (rk,)).fetchone() or [""])[0]
    finally:
        conn.close()
    try:  # R120c: remember the pick so Plex writes cannot undo it
        from resources.lib import pkm_meta_override_r120 as _ovr
        _ovr.set_item(rk, {
            "title": item["title"], "year": _int(item["year"]), "summary": item["summary"],
            "original_title": item["original_title"], "thumb": item["thumb"], "art": item["art"],
            "cast": cast[:40], "directors": directors[:8], "genres": genres[:12],
            "tmdb_id": item["tmdb_id"], "plex_updated_at": str(upd or "")})
    except Exception:
        _log("OVERRIDE_STORE_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
    try:
        sc = sqlite3.connect(core.search_db_path(), timeout=5.0)
        try:
            core.upsert_search_index_item(sc, item, section_title="")
            sc.commit()
        finally:
            sc.close()
    except Exception:
        pass
    filled = _filled(before, item)
    if item.get("art") and item.get("art") != before.get("art"):
        filled.append("art")
    if item.get("thumb") and item.get("thumb") != before.get("thumb") and "thumb" not in filled:
        filled.append("thumb")
    if item.get("cast_count"):
        filled.append("cast")
    _log("TMDB_APPLY rating_key=%s tmdb=%s filled=%s" % (rk, candidate.get("tmdb_id"), ",".join(filled)))
    return {"ok": True, "code": "updated" if filled else "unchanged", "action": "tmdb", "item": item, "filled": filled,
            "message": ("TMDB 메타를 적용했습니다 · " + _label(filled)) if filled else "TMDB 메타가 이미 같은 값입니다"}


def _media_file(core, rating_key, node=None):
    """Full media path of the item: the Plex node's first Part, else the cached row."""
    try:
        if node is not None:
            part = node.find(".//Part")
            if part is not None and part.get("file"):
                return str(part.get("file"))
    except Exception:
        pass
    try:
        conn = core.init_db()
        try:
            r = conn.execute("SELECT media_file FROM items WHERE rating_key=?", (str(rating_key),)).fetchone()
        finally:
            conn.close()
        return str((r or [""])[0] or "")
    except Exception:
        return ""


def plex_candidates(core, rating_key, dir_fn=None):
    """Search the item's agent with its title and year.  Applies NOTHING.

    -> {"ok", "row", "guid", "candidates": [...], "message"}; each candidate is
    {"guid","name","year","score","exact","current"} (best first, at most MAX_CANDIDATES).
    The caller shows them and only plex_apply() changes anything, after the user picked one.
    """
    try:
        conn = core.init_db()
        try:
            row = _row(conn, rating_key)
        finally:
            conn.close()
        if not row:
            return dict(_fail("not_found", "항목을 찾지 못했습니다"), candidates=[], row=None, guid="")
        node = _plex_node(core, rating_key)
        if node is None:
            return dict(_fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다"), candidates=[], row=row, guid="")
        guid = node.get("guid") or ""
        title = row["title"] or node.get("title") or ""
        year = row["year"] or node.get("year")
        file_path = _media_file(core, rating_key, node)
        if _is_placeholder(title) or file_path:
            _log("FILE_NAME_SEARCH rating_key=%s title=%r placeholder=%d file=%r variants=%s" % (
                rating_key, title, 1 if _is_placeholder(title) else 0, file_path,
                [v[0] for v in file_title_variants(file_path)]))
        raw = []
        if dir_fn is not None:  # TMDB is the primary source
            raw = tmdb_matches(dir_fn, row.get("plex_type"), title, row.get("original_title"), year, file_path)
        if not raw:  # the Plex agent is only an optional fallback
            agent = _plex_agent(core, row["section_id"], row.get("plex_type"), guid)
            _log("CANDIDATE_SEARCH rating_key=%s title=%r year=%s agent=%s" % (rating_key, title, year, agent or "-"))
            try:
                raw = _plex_matches(core, rating_key, title, year, agent, row.get("original_title"), file_path)
            except Exception:
                _log("AGENT_FALLBACK_FAILED rating_key=%s" % rating_key)
                raw = []
        safe = pick_match(raw, title, year)
        out = []
        for r in raw:
            if not r.get("guid"):
                continue
            c = dict(r)
            c["exact"] = _norm(r.get("name")) == _norm(title) and _int(r.get("year")) == _int(year) > 0
            c["current"] = r["guid"] == guid
            out.append(c)
        out.sort(key=lambda c: (not c["exact"], -_int(c.get("score"))))
        out = out[:MAX_CANDIDATES]
        _log("CANDIDATES rating_key=%s found=%d shown=%d exact=%s" % (rating_key, len(raw), len(out), "1" if safe else "0"))
        return {"ok": True, "code": "candidates" if out else "no_candidates", "row": row, "guid": guid,
                "candidates": out, "message": "" if out else "TMDB·에이전트 모두 후보를 찾지 못했습니다"}
    except Exception as exc:
        _log("CANDIDATES_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace("\n", " | ")))
        return dict(_classify(exc), candidates=[], row=None, guid="")


def plex_apply(core, row, candidate, base_guid="", sleep=time.sleep, clock=time.time, dir_fn=None):
    """The user confirmed ``candidate``: fix the match (or just refresh when it is the
    current match), wait for the server, rewrite only this item's row."""
    rk, sid = row["rating_key"], row["section_id"]
    section_type = row["plex_type"]
    if str(candidate.get("guid") or "").startswith(_TMDB_PREFIX):
        try:
            return _tmdb_apply(core, row, candidate, dir_fn=dir_fn)
        except Exception as exc:
            _log("TMDB_APPLY_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
            return _fail("error", "메타 갱신에 실패했습니다")
    try:
        node = _plex_node(core, rk)
        if node is None:
            return _fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다")
        base = core.extract_item(node, sid, section_type)
        base_sig = _snapshot(base) + (node.get("guid") or "", node.get("updatedAt") or "")
        if candidate["guid"] == (node.get("guid") or base_guid):
            action = "refresh"
            core.plex_request("/library/metadata/%s/refresh" % rk, params={"force": 1}, timeout=20, method="PUT")
        else:
            action = "match"
            core.plex_request("/library/metadata/%s/match" % rk,
                              params={"guid": candidate["guid"], "name": candidate["name"], "year": candidate["year"]},
                              timeout=20, method="PUT")
        deadline = clock() + POLL_TIMEOUT
        item, changed_at = None, None
        while clock() < deadline:
            sleep(POLL_INTERVAL)
            node = _plex_node(core, rk)
            if node is None:
                continue
            cur = core.extract_item(node, sid, section_type)
            sig = _snapshot(cur) + (node.get("guid") or "", node.get("updatedAt") or "")
            if sig != base_sig:
                item = cur
                if changed_at is None:
                    changed_at = clock()
                elif clock() - changed_at >= SETTLE_SEC:
                    break
            elif changed_at is not None:
                break
        if item is None:
            return {"ok": True, "code": "unchanged", "action": action, "item": None, "filled": [],
                    "message": "갱신 요청을 보냈지만 변화가 없습니다"}
        _store_plex(core, row, item)
        filled = _filled(base, item)
        return {"ok": True, "code": "updated" if filled else "unchanged", "action": action, "item": item,
                "filled": filled,
                "message": ("메타를 갱신했습니다 · " + _label(filled)) if filled else "메타가 갱신됐지만 빈 항목은 그대로입니다"}
    except Exception as exc:
        _log("PLEX_APPLY_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
        return _classify(exc)


def has_override(core, rating_key):
    """R120b: True when a TMDB pick was applied locally (so it can be undone)."""
    try:
        conn = core.init_db()
        try:
            n = conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=? AND source='tmdb_r120'",
                             (str(rating_key),)).fetchone()[0]
            g = conn.execute("SELECT COUNT(*) FROM item_genres WHERE rating_key=? AND source='tmdb_r120'",
                             (str(rating_key),)).fetchone()[0]
            art = str((conn.execute("SELECT art FROM items WHERE rating_key=?", (str(rating_key),)).fetchone() or [""])[0] or "")
        finally:
            conn.close()
        try:
            from resources.lib import pkm_meta_override_r120 as _ovr
            if _ovr.get_item(rating_key):
                return True
        except Exception:
            pass
        return bool(n or g) or (art.startswith("http") and "/library/metadata/" not in art)
    except Exception:
        return False


def plex_restore(core, rating_key):
    """R120b: undo a local TMDB pick -- rewrite the row from the Plex server's
    own record and drop the TMDB cast/genres (Plex roles come back on the
    next Info open / sync)."""
    rk = str(rating_key)
    try:
        conn = core.init_db()
        try:
            row = _row(conn, rk)
        finally:
            conn.close()
        if not row:
            return _fail("not_found", "항목을 찾지 못했습니다")
        node = _plex_node(core, rk)
        if node is None:
            return _fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다")
        item = core.extract_item(node, row["section_id"], row["plex_type"])
        try:  # R120c: drop the pick first, or the store below would re-apply it
            from resources.lib import pkm_meta_override_r120 as _ovr
            _ovr.clear_item(rk)
        except Exception:
            pass
        _store_plex(core, row, item)
        conn = core.init_db()
        try:
            conn.execute("DELETE FROM item_people WHERE rating_key=? AND source='tmdb_r120'", (rk,))
            conn.execute("DELETE FROM item_genres WHERE rating_key=? AND source='tmdb_r120'", (rk,))
            conn.commit()
        finally:
            conn.close()
        _log("PLEX_RESTORE rating_key=%s title=%r" % (rk, item.get("title")))
        out = dict(item)
        out["tmdb_id"] = ""
        return {"ok": True, "code": "restored", "action": "restore", "item": out, "filled": [],
                "message": "Plex 원래 정보로 되돌렸습니다"}
    except Exception as exc:
        _log("PLEX_RESTORE_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
        return _classify(exc)


def _store_plex(core, row, item):
    conn = core.init_db()
    try:
        core.upsert_item(conn, item)
        conn.commit()
    finally:
        conn.close()
    try:  # search index follows the (possibly new) title
        sc = sqlite3.connect(core.search_db_path(), timeout=5.0)
        try:
            core.upsert_search_index_item(sc, item, section_title="")
            sc.commit()
        finally:
            sc.close()
    except Exception:
        pass


# ------------------------------------------------------------------ Kodi
def _kodi_signature(item):
    return _snapshot(item)


def _kodi_refresh(rating_key, sleep=time.sleep, clock=time.time, src=None):
    if src is None:
        from resources.lib import pkm_kodi_source as src
    kind, num = src.kodi_id(rating_key)
    if kind == "movie":
        method, idkey = "VideoLibrary.RefreshMovie", "movieid"
    elif kind == "show":
        method, idkey = "VideoLibrary.RefreshTVShow", "tvshowid"
    else:
        return _fail("unsupported", "이 항목은 새로고침할 수 없습니다")
    try:
        before = _kodi_read(src, kind, num)
        if before is None:
            return _fail("not_found", "Kodi 라이브러리에서 항목을 찾지 못했습니다")
        if src._jsonrpc(method, {idkey: num, "ignorenfo": False}) is None:
            return _fail("kodi_unavailable", "Kodi 스크레이퍼 새로고침을 시작하지 못했습니다")
        deadline = clock() + POLL_TIMEOUT
        item, changed_at = None, None
        while clock() < deadline:
            sleep(POLL_INTERVAL)
            cur = _kodi_read(src, kind, num)
            if cur is None:
                continue
            if _kodi_signature(cur) != _kodi_signature(before):
                item = cur
                if changed_at is None:
                    changed_at = clock()
                elif clock() - changed_at >= SETTLE_SEC:
                    break
            elif changed_at is not None:
                break
        if item is None:
            return {"ok": True, "code": "unchanged", "action": "refresh", "item": None, "filled": [],
                    "message": "새로 받은 메타가 없습니다 (Kodi 스크레이퍼 설정을 확인하세요)"}
        stored = src.sync_one(rating_key) or item
        filled = _filled(before, stored)
        return {"ok": True, "code": "updated" if filled else "unchanged", "action": "refresh", "item": stored,
                "filled": filled,
                "message": ("메타를 갱신했습니다 · " + _label(filled)) if filled else "메타가 갱신됐지만 빈 항목은 그대로입니다"}
    except Exception:
        _log("KODI_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace("\n", " | ")))
        return _fail("error", "메타 갱신에 실패했습니다")


def _kodi_read(src, kind, num):
    if kind == "movie":
        res = src._jsonrpc("VideoLibrary.GetMovieDetails", {"movieid": num, "properties": src.MOVIE_PROPS}) or {}
        det, build = res.get("moviedetails"), src._movie_rows
    else:
        res = src._jsonrpc("VideoLibrary.GetTVShowDetails", {"tvshowid": num, "properties": src.SHOW_PROPS}) or {}
        det, build = res.get("tvshowdetails"), src._show_rows
    return build(det)[0] if det else None


# ------------------------------------------------------------------ entry
_LABELS = {"title": "제목", "year": "연도", "summary": "줄거리", "thumb": "포스터", "art": "배경", "cast": "출연진"}


def _label(fields):
    return "·".join(_LABELS.get(f, f) for f in fields)


def refresh(core, rating_key):
    """Kodi worker entry (scraper refresh).  Plex items go through plex_candidates()
    + plex_apply() so the user confirms the match first."""
    rk = str(rating_key)
    try:
        res = _kodi_refresh(rk) if rk.startswith("k:") else _fail("unsupported", "이 항목은 후보 확인이 필요합니다")
    except Exception:
        _log("FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
        res = _fail("error", "메타 갱신에 실패했습니다")
    _log("DONE rating_key=%s code=%s action=%s filled=%s" % (rk, res.get("code"), res.get("action"), ",".join(res.get("filled") or [])))
    return res


def _genre_ko_r143(name):
    # R143: store one Korean spelling per genre (Drama/드라마 used to be two genres)
    try:
        from resources.lib import pkm_info_data as _pid
        return _pid.genre_ko(name)
    except Exception:
        return name
