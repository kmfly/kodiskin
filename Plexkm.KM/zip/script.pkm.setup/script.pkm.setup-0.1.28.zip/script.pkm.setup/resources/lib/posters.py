# -*- coding: utf-8 -*-
"""Poster download (once) into the add-on profile. Needs a TMDb API key.

Key sources, in order: this add-on's `tmdb_api_key` setting, then a
`tmdb_api_key` string found in TMDb Helper's settings. Without a key the
wizard simply shows title tiles."""
import hashlib
import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

try:
    from urllib.parse import quote
    from urllib.request import Request, urlopen
except Exception:  # pragma: no cover
    from urllib import quote
    from urllib2 import Request, urlopen

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
POSTER_DIR = os.path.join(PROFILE, "posters")


def _log(msg):
    xbmc.log("[PKM SETUP] %s" % msg, xbmc.LOGINFO)


def _key():
    k = (ADDON.getSetting("tmdb_api_key") or "").strip()
    if k:
        return k
    for aid in ("plugin.video.themoviedb.helper",):
        try:
            a = xbmcaddon.Addon(aid)
            for sid in ("tmdb_apikey", "tmdb_api_key", "api_key"):
                v = (a.getSetting(sid) or "").strip()
                if len(v) == 32:
                    return v
        except Exception:
            pass
    return ""


def poster_path(title, year):
    h = hashlib.md5(("%s|%s" % (title, year)).encode("utf-8")).hexdigest()
    return os.path.join(POSTER_DIR, h + ".jpg")


BUNDLED_DIR = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "posters")


def cached(title, year):
    """Bundled poster first (no key / no network needed), then the download cache."""
    name = os.path.basename(poster_path(title, year))
    b = os.path.join(BUNDLED_DIR, name)
    if os.path.exists(b) and os.path.getsize(b) > 1000:
        return b
    p = poster_path(title, year)
    return p if os.path.exists(p) and os.path.getsize(p) > 1000 else ""


def _get(url, timeout=10):
    req = Request(url, headers={"User-Agent": "PKM-Setup"})
    return urlopen(req, timeout=timeout).read()


def fetch(title, year, kind):
    """Return local poster path or '' (never raises)."""
    got = cached(title, year)
    if got:
        return got
    key = _key()
    if not key:
        return ""
    try:
        if not os.path.isdir(POSTER_DIR):
            os.makedirs(POSTER_DIR)
        endpoint = "movie" if kind == "movie" else "tv"
        yparam = "year" if kind == "movie" else "first_air_date_year"
        url = "https://api.themoviedb.org/3/search/%s?api_key=%s&language=ko-KR&query=%s&%s=%s" % (
            endpoint, key, quote(title), yparam, year)
        data = json.loads(_get(url).decode("utf-8"))
        res = [r for r in data.get("results", []) if r.get("poster_path")]
        if not res:
            return ""
        img = _get("https://image.tmdb.org/t/p/w342" + res[0]["poster_path"], timeout=15)
        with open(poster_path(title, year), "wb") as f:
            f.write(img)
        return poster_path(title, year)
    except Exception as exc:
        _log("poster fail %s: %s" % (title, exc))
        return ""
