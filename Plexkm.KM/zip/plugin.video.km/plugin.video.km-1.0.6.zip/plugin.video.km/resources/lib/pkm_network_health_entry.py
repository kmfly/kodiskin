# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import os
import sys
import xbmc

ADDON_ID = "plugin.video.km"


def _ensure_addon_root_v2127():
    """RunScript(lib/file.py) does not guarantee the addon root is on sys.path."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        addon_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
        if addon_root and addon_root not in sys.path:
            sys.path.insert(0, addon_root)
        return addon_root
    except Exception:
        return ""


def main():
    try:
        addon_root = _ensure_addon_root_v2127()
        from resources.lib import pkm_network_health
        ok = bool(pkm_network_health.toggle_panel())
        xbmc.log(
            "[%s][network_health] NETWORK_HEALTH_PANEL_DISPATCH_V2127 ok=%s addon_root=%s"
            % (ADDON_ID, "1" if ok else "0", addon_root),
            xbmc.LOGINFO if ok else xbmc.LOGWARNING,
        )
    except Exception as exc:
        try:
            xbmc.log(
                "[%s][network_health] NETWORK_HEALTH_PANEL_FAILED_V2127 err=%s" % (ADDON_ID, exc),
                xbmc.LOGWARNING,
            )
        except Exception:
            pass


if __name__ == "__main__":
    main()
