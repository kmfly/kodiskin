# -*- coding: utf-8 -*-
"""PKM library selection flow split from default.py.

This module is intentionally data/settings-flow only. It must not import
``default.py`` or Home WindowXML modules. The caller supplies every project
callback through an env dictionary so importing this module cannot trigger a
second default.py instance or change Home/Section startup order.
"""
from __future__ import absolute_import, unicode_literals

import traceback
import os
import json
import time

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None


def _call(env, name, *args, **kwargs):
    fn = env.get(name)
    if not callable(fn):
        raise RuntimeError("missing library selection callback: %s" % name)
    return fn(*args, **kwargs)


def _log(env, message, level=xbmc.LOGINFO):
    fn = env.get("log")
    try:
        if callable(fn):
            fn(message, level)
            return
    except Exception:
        pass
    xbmc.log("[plugin.video.km] %s" % message, level)


def _notify(env, message, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    fn = env.get("notify")
    heading = env.get("addon_name") or "Plex KM"
    try:
        if callable(fn):
            fn(message, icon=icon, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(heading, message, "", ms=ms):
            return
    except Exception:
        pass
    _log(env, "PKM_NATIVE_NOTIFICATION_SUPPRESSED heading=%s message=%s" % (str(heading or ""), str(message or "")), xbmc.LOGINFO)



def _offline_or_server_switch_pending():
    """v1382: settings/library list must not block on Plex HTTP while offline."""
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.PlexOffline") == "1":
            return True
        if win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
            return True
    except Exception:
        pass
    return False

def _display_library_title(value):
    """Display Plex library titles with pipe-like separators rendered safely.

    Do not delete separators and do not replace them with hyphens/spaces.
    Only vertical-line lookalike code points are normalized to ASCII '|'
    for the settings-list display so Kodi does not show missing-glyph boxes.
    """
    text = str(value or "")
    try:
        table = {
            ord("\u2223"): "|",  # DIVIDES
            ord("\u2758"): "|",  # LIGHT VERTICAL BAR
            ord("\u2759"): "|",  # MEDIUM VERTICAL BAR
            ord("\u275A"): "|",  # HEAVY VERTICAL BAR
            ord("\uFFE8"): "|",  # HALFWIDTH FORMS LIGHT VERTICAL
            ord("\uFF5C"): "|",  # FULLWIDTH VERTICAL LINE
            ord("\u2502"): "|",  # BOX DRAWINGS LIGHT VERTICAL
            ord("\u2503"): "|",  # BOX DRAWINGS HEAVY VERTICAL
            ord("\u23AA"): "|",  # CURLY BRACKET EXTENSION
            ord("\u23D0"): "|",  # VERTICAL LINE EXTENSION
            ord("\u2016"): "|",  # DOUBLE VERTICAL LINE
            ord("\u01C0"): "|",  # LATIN LETTER DENTAL CLICK
            ord("\u00A6"): "|",  # BROKEN BAR
            ord("\u4E28"): "|",  # CJK UNIFIED IDEOGRAPH vertical stroke
            ord("\u3163"): "|",  # HANGUL LETTER I
        }
        text = text.translate(table)
    except Exception:
        pass
    return text


def library_selection_rows(env, live_required=False):
    """Build labels/preselect rows for the PKM library checkbox dialog."""
    try:
        if not _call(env, "clean_server_url") or not _call(env, "plex_token"):
            _notify(env, "Plex 서버 설정이 먼저 필요합니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
            return None, [], []
        # v1382: When Plex is already known offline or server-switch-pending,
        # never issue /library/sections from the settings dialog.  The old
        # refresh=True path used a long Plex timeout and made PKM 설정 feel
        # frozen exactly when the user needed to fix the connection.
        # v1688: plex.tv/link authentication may open the initial chooser only
        # after the newly saved token has successfully reached the configured PMS.
        # Never satisfy that gate from cached sections or a stale PlexOffline flag.
        offline_fast = _offline_or_server_switch_pending() and not bool(live_required)
        if offline_fast:
            _log(env, "LIBRARY_SELECTION_ROWS_OFFLINE_FAST_CACHE reason=v1382_no_live_refresh", xbmc.LOGWARNING)
        if live_required:
            _log(env, "TOKEN_AUTH_PMS_SECTIONS_LIVE_BEGIN_V1688", xbmc.LOGINFO)
        sections = _call(env, "fetch_sections", refresh=True if live_required else (False if offline_fast else True), selected_only=False)
        all_sections = _call(env, "apply_section_order", sections, save_merged=not offline_fast)
        if live_required:
            _log(env, "TOKEN_AUTH_PMS_SECTIONS_LIVE_OK_V1688 count=%d" % len(all_sections or []), xbmc.LOGINFO)
        if not all_sections:
            if live_required:
                _notify(env, "Plex 라이브러리를 확인하지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4200)
            elif offline_fast:
                _show_notice(env, "Plex 오프라인", "Plex 서버에 연결할 수 없습니다", "연결 설정에서 주소를 수정해주세요", ms=3200)
            else:
                _notify(env, "Plex 라이브러리를 찾지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
            return None, [], []
        selected, configured = _call(env, "selected_sections_state")
        selected_set = set(selected if configured else [])
        labels = []
        preselect = []
        for i, section in enumerate(all_sections):
            sid = str(section.get("section_id", ""))
            title = _display_library_title(section.get("title", "") or sid)
            stype = section.get("section_type", "")
            labels.append("%s  (%s / id=%s)" % (title, stype, sid))
            if sid in selected_set:
                preselect.append(i)
        return all_sections, labels, preselect
    except Exception:
        _log(env, "LIBRARY_SELECTION_ROWS_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        _notify(env, "라이브러리 목록을 만들지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
        return None, [], []


def _section_names(all_sections, ids):
    idset = set(str(x) for x in (ids or []) if str(x))
    names = []
    for section in all_sections or []:
        sid = str(section.get("section_id", ""))
        if sid in idset:
            names.append(_display_library_title(section.get("title", "") or sid))
    return names


def _show_notice(env, title, line1="", line2="", ms=3000):
    fn = env.get("show_notice")
    try:
        if callable(fn):
            fn(title, line1, line2, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(title or (env.get("addon_name") or "Plex KM"), line1, line2, ms=ms):
            return
    except Exception:
        pass
    _notify(env, "%s %s" % (line1 or "", line2 or ""), icon=xbmcgui.NOTIFICATION_INFO, ms=ms)


def _open_message(env, title, message, ok_label="확인"):
    fn = env.get("open_message")
    try:
        if callable(fn):
            return fn(title, message, ok_label=ok_label)
    except Exception:
        pass
    _show_notice(env, title, message, "", ms=3200)
    return True




def _library_add_restart_marker_path_v2091():
    try:
        return xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.km/library_add_restart_v2091.json"
        )
    except Exception:
        return ""


def _write_library_add_restart_marker_v2091(env, added, added_names):
    """Persist only the next-start boundary, never live-Home UI state."""
    path = _library_add_restart_marker_path_v2091()
    if not path:
        return False
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = {
            "created_at_ms": int(time.time() * 1000),
            "sections": [str(x) for x in (added or []) if str(x)],
            "names": [str(x) for x in (added_names or []) if str(x)],
            "policy": "next_start_loading_before_home_v2091",
        }
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, sort_keys=True)
        os.replace(tmp, path)
        _log(env, "LIBRARY_ADD_RESTART_MARKER_WRITE_V2091 path=%s sections=%s" % (
            path, ",".join(payload.get("sections") or [])
        ), xbmc.LOGINFO)
        return True
    except Exception:
        _log(env, "LIBRARY_ADD_RESTART_MARKER_WRITE_FAILED_V2091 err=%s" % (
            traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return False

def _set_library_add_restart_pending_v2090(active, reason=""):
    """Own the library-add boundary until the current Kodi process exits.

    Added libraries can invalidate Home recommendation/canonical/widget state on a
    large scale.  V2090 never exposes that rebuild over an interactive Home
    surface.  The flag is process-local (Window(10000)) and naturally disappears
    on the next Kodi start.
    """
    try:
        win = xbmcgui.Window(10000)
        if active:
            win.setProperty("PlexKM.LibraryAdd.RestartRequiredV2090", "1")
            win.setProperty("PlexKM.LibraryAdd.RestartReasonV2090", str(reason or "library_added"))
        else:
            win.clearProperty("PlexKM.LibraryAdd.RestartRequiredV2090")
            win.clearProperty("PlexKM.LibraryAdd.RestartReasonV2090")
    except Exception:
        pass


def _library_add_exit_for_restart_v2090(env, added, added_names):
    """Finish an added-library transaction without ever reopening live Home.

    Reuse the established v2048 single completion window.  Its 종료 action
    dispatches Kodi Quit while the completion surface still owns the screen, so
    there is no Home+spinner interval and no selectable-but-unusable widget
    surface between the sync and process shutdown.
    """
    try:
        win = xbmcgui.Window(10000)
        # v1754 live-Home application is explicitly disabled for add in v2090.
        win.clearProperty("PlexKM.Home.LibraryApplyBusyV1754")
        win.clearProperty("PlexKM.Home.LibraryApplyTextV1754")
        # Any sync dirty signal already emitted during the transaction belongs to
        # the next startup now; do not let the current Home consume it.
        win.clearProperty("PlexKM.Home.SyncRefreshPendingV1554")
        win.clearProperty("PlexKM.Home.SyncRefreshPendingTokenV1554")
        win.clearProperty("PlexKM.Home.SyncRefreshPendingReasonV1554")
        win.clearProperty("PlexKM.PlexUpdate.Dirty")
    except Exception:
        pass
    added_line = ", ".join((added_names or [])[:2]) if added_names else ", ".join((added or [])[:2])
    message = "라이브러리 싱크가 완료되었습니다."
    if added_line:
        message += "\n추가: %s" % added_line
    message += "\n\n추가된 라이브러리를 PKM에 반영하려면 KODI를 재시작해야 합니다."
    message += "\n아래 [KODI 종료]를 누른 후 KODI를 다시 실행해주세요."
    marker_ok_v2091 = _write_library_add_restart_marker_v2091(env, added, added_names)
    _log(env, "LIBRARY_ADD_RESTART_BOUNDARY_V2091 sections=%s live_home_apply=0 spinner=0 interactive_home=0 next_start_loading_apply=1 marker=%d" % (
        ",".join(added or []), 1 if marker_ok_v2091 else 0
    ), xbmc.LOGINFO)
    _log(env, "LIBRARY_ADD_RESTART_NOTICE_V2092 title=KODI_restart_required button=KODI_exit explicit_restart_instruction=1", xbmc.LOGINFO)
    fn = env.get("progress_complete_and_wait")
    if callable(fn):
        return bool(fn(None, "KODI 재시작 필요", message, exit_on_confirm=True, button_label="KODI 종료", action_hint=""))
    # Fallback is intentionally still exit-only; never reopen Home after add.
    _open_message(env, "KODI 재시작 필요", message, ok_label="KODI 종료")
    try:
        request_kodi_exit_v2171(
            reason="library_add_restart_fallback_v2171",
            title="Kodi 종료",
            detail="추가된 라이브러리를 적용하려면 Kodi를 다시 실행해주세요.",
        )
        return True
    except Exception:
        _log(env, "LIBRARY_ADD_RESTART_QUIT_FAILED_V2171\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False


def apply_library_selection(env, all_sections, chosen, force=False, auth_initial=False):
    """Persist selected library ids and run selection/sync side effects.

    v637 root-cause fix: unselecting a library must not delete its local cache.
    The selected_sections state is the source of truth for visibility; cached
    rows stay available so re-enabling a large library can use the fast verifier
    instead of rebuilding tens of thousands of rows from scratch.
    """
    all_sections = list(all_sections or [])
    new_ids = [str(all_sections[int(i)].get("section_id", "")) for i in (chosen or []) if 0 <= int(i) < len(all_sections)]
    if auth_initial:
        if not new_ids:
            _log(env, "TOKEN_AUTH_LIBRARY_SELECTION_REQUIRED_V1688", xbmc.LOGINFO)
            _notify(env, "라이브러리를 1개 이상 선택하세요", icon=xbmcgui.NOTIFICATION_WARNING, ms=3000)
            return False
        # v1985 transactional activation: a checkbox selection is only pending.
        # It must not become Home-visible until every selected section completes.
        previous_ids_v1985, previous_configured_v1985 = _call(env, "selected_sections_state")
        previous_ids_v1985 = [str(x) for x in (previous_ids_v1985 or []) if str(x)]
        previous_done_v1985 = bool(_call(env, "initial_sync_done"))
        _call(env, "save_selected_sections", new_ids)
        _call(env, "set_initial_sync_done", False)
        _log(env, "LIBRARY_SELECTION_PENDING_V1985 selected=%s previous=%s active=0" % (
            ",".join(new_ids), ",".join(previous_ids_v1985)
        ), xbmc.LOGINFO)
        try:
            sync_result_v1985 = _call(
                env,
                "sync_all_sections",
                show_prompt=False,
                show_progress=True,
                mark_auto_sync=True,
                section_ids=new_ids,
                progress_title="라이브러리 싱크",
                completion_confirm=True,
            )
        except Exception:
            sync_result_v1985 = 0
            _log(env, "TOKEN_AUTH_INITIAL_SYNC_FAILED_V1985\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        if not sync_result_v1985 or not bool(_call(env, "initial_sync_done")):
            # Cancel/failure discards the pending choice atomically. Partial DB rows
            # may remain as reusable cache, but they are never selection authority.
            _call(env, "save_selected_sections", previous_ids_v1985)
            _call(env, "set_initial_sync_done", previous_done_v1985)
            try:
                w_v1985 = xbmcgui.Window(10000)
                w_v1985.clearProperty("PlexKM.Home.SettingsRequired")
                w_v1985.clearProperty("PlexKM.StartupSettingsIncomplete")
                w_v1985.clearProperty("PlexKM.InitialSetupReadyV1736")
            except Exception:
                pass
            _call(env, "signal_home_data_refresh", reason="initial_sync_cancel_rollback_v1985")
            _log(env, "LIBRARY_SELECTION_PENDING_ROLLBACK_V1985 reason=cancel_or_failure pending=%s restored=%s restored_done=%d" % (
                ",".join(new_ids), ",".join(previous_ids_v1985), 1 if previous_done_v1985 else 0
            ), xbmc.LOGWARNING)
            _notify(env, "라이브러리 싱크가 완료되지 않았습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4200)
            return False
        _log(env, "LIBRARY_SELECTION_ACTIVE_COMMIT_V1985 selected=%s initial_sync_done=1" % ",".join(new_ids), xbmc.LOGINFO)
        # v2048: successful initial sync is applied on the next manual Kodi start.
        # Do not publish or rebuild Home in the current process.
        _log(env, "TOKEN_AUTH_INITIAL_HOME_REFRESH_SKIP_V2048 reason=manual_restart_required selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        _log(env, "TOKEN_AUTH_INITIAL_FLOW_COMPLETE_V1688 selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        return True
    if not new_ids:
        ok = _call(
            env,
            "open_confirm",
            env.get("addon_name") or "Plex KM",
            "선택된 라이브러리가 없습니다.\nPKM 홈/검색/싱크 대상이 비게 됩니다.\n그대로 저장할까요?",
            yes_label="저장",
            no_label="취소",
        )
        if not ok:
            return False
    # v1819: the checkbox page is only a proposed selection until any newly
    # added libraries pass the follow-up Sync/Later decision.  Keep the prior
    # committed selection so choosing "Later" cannot leave an unsynced library
    # checked on the next visit.
    old_selected_v1819, old_configured_v1819 = _call(env, "selected_sections_state")
    old_selected_v1819 = [str(x) for x in (old_selected_v1819 or []) if str(x)]
    old_initial_done_v1985 = bool(_call(env, "initial_sync_done"))
    added, removed = _call(env, "save_selected_sections", new_ids)
    _log(env, "LIBRARY_SELECTION_CACHE_RETAIN selected=%s added=%s removed=%s" % (",".join(new_ids), ",".join(added), ",".join(removed)), xbmc.LOGINFO)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    if added:
        added_names = _section_names(all_sections, added)
        # v2090: library addition is a restart-boundary transaction.  Arm the
        # process-local gate before any verify/full-sync can emit Home dirty
        # signals, so the live Home window never starts a large rebuild.
        _set_library_add_restart_pending_v2090(True, reason="library_added_sync")
        _log(env, "LIBRARY_ADD_RESTART_PENDING_V2091 sections=%s home_runtime_rebuild=blocked spinner_long_work_forbidden=1" % ",".join(added), xbmc.LOGINFO)
        # v1982: a newly checked library is a new explicit activation.
        # Existing rows in the content DB are not proof that this selection
        # transaction completed a sync.  Every newly added section therefore
        # follows the visible full-sync path; DB rows are only reusable data
        # inside that sync, never a reason to skip its progress UI.
        cached_added = []
        uncached_added = list(added)
        prearmed_v1747 = {"progress": None}
        _log(env, "LIBRARY_SELECTION_SYNC_CLASSIFY_V1747 added=%s cached=%s uncached=%s" % (
            ",".join(added), ",".join(cached_added), ",".join(uncached_added)
        ), xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_EXPLICIT_FULL_SYNC_V1982 added=%s db_completion_inference=0 visible_progress_required=1" % ",".join(added), xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_RESELECT_MERGE_SYNC_V1983 added=%s plex_full_scan=1 db_reuse_compare=1 add_update_prune=1" % ",".join(added), xbmc.LOGINFO)

        def _prepare_added_sync_v1747():
            # v1747: cached verification also opens the progress window.  Prearm
            # it while the confirmation dialog is still visible so the in-place
            # library selection page can never become the top frame.
            progress = _call(
                env,
                "prearm_sync_progress",
                "라이브러리 싱크",
                "준비 중",
            )
            if progress is None:
                _log(env, "LIBRARY_SELECTION_SYNC_PREARM_FAILED_V1747 added=%s cached=%s uncached=%s" % (
                    ",".join(added), ",".join(cached_added), ",".join(uncached_added)
                ), xbmc.LOGWARNING)
                return False
            prearmed_v1747["progress"] = progress
            _log(env, "LIBRARY_SELECTION_SYNC_PREARM_READY_V1747 added=%s cached=%s uncached=%s" % (
                ",".join(added), ",".join(cached_added), ",".join(uncached_added)
            ), xbmc.LOGINFO)
            return True

        ok = force or _call(
            env,
            "open_confirm",
            env.get("addon_name") or "Plex KM",
            "선택한 라이브러리를 싱크합니다.\n계속할까요?",
            yes_label="싱크",
            no_label="나중에",
            yes_prepare=_prepare_added_sync_v1747,
            default_focus="yes",
        )
        if not ok:
            # v1819: "Later" means do not activate the newly added libraries.
            # Preserve deliberate removals from this edit, but restore every
            # newly added id to unchecked.  A library becomes checked only after
            # the user accepts the sync/verification path.
            added_set_v1819 = set(str(x) for x in (added or []) if str(x))
            committed_ids_v1819 = [str(x) for x in new_ids if str(x) not in added_set_v1819]
            _call(env, "save_selected_sections", committed_ids_v1819)
            try:
                xbmc.executebuiltin("Container.Refresh")
            except Exception:
                pass
            _set_library_add_restart_pending_v2090(False, reason="sync_later_rollback")
            _log(env, "LIBRARY_SELECTION_ADDED_ROLLBACK_V1819 reason=sync_later added=%s committed=%s previous=%s" % (
                ",".join(added), ",".join(committed_ids_v1819), ",".join(old_selected_v1819)
            ), xbmc.LOGINFO)
            return True
        if ok:
            # v1754: keep the library-selection page fully covered from the
            # progress handoff through the completion modal.  The modal must
            # appear as the next visible state after sync, never after a flash
            # of the selection page.
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
            except Exception:
                pass
            _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=added", xbmc.LOGINFO)
            progress_v1747 = prearmed_v1747.get("progress")
            if uncached_added:
                _call(env, "set_initial_sync_done", False)
                _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=uncached_full progress_reused=%d sections=%s" % (
                    1 if progress_v1747 is not None else 0, ",".join(uncached_added)
                ), xbmc.LOGINFO)
                sync_result_v1985 = _call(
                    env,
                    "sync_all_sections",
                    show_prompt=False,
                    show_progress=True,
                    mark_auto_sync=True,
                    section_ids=uncached_added,
                    progress_title="라이브러리 싱크",
                    precreated_progress=progress_v1747,
                )
                if not sync_result_v1985 or not bool(_call(env, "initial_sync_done")):
                    # v1995: cancel/failure is not a completed settings operation.
                    # Roll back the proposed selection, keep Home activation closed,
                    # and return control to the library-selection page.  The user may
                    # leave through that page's explicit Home button only.
                    _call(env, "save_selected_sections", old_selected_v1819)
                    _call(env, "set_initial_sync_done", False)
                    _call(env, "signal_home_data_refresh", reason="added_sync_cancel_stay_library_select_v1995")
                    try:
                        xbmcgui.Window(10000).clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
                    except Exception:
                        pass
                    _set_library_add_restart_pending_v2090(False, reason="cancel_or_failure")
                    _log(env, "LIBRARY_SELECTION_ADDED_ROLLBACK_V1995 reason=cancel_or_failure added=%s restored=%s initial_sync_done=0 destination=library_select" % (
                        ",".join(added), ",".join(old_selected_v1819)
                    ), xbmc.LOGWARNING)
                    return True
                # The full-sync path owns and closes the prearmed window.  Any
                # already-cached sections are verified quietly in the same
                # transaction to avoid opening a second progress dialog.
                if cached_added:
                    _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=cached_verify_quiet_after_full sections=%s" % ",".join(cached_added), xbmc.LOGINFO)
                    _call(env, "verify_selected_library_cache", precreated_progress=None, show_progress=False)
            elif cached_added:
                _call(env, "set_initial_sync_done", True)
                _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=cached_verify progress_reused=%d sections=%s" % (
                    1 if progress_v1747 is not None else 0, ",".join(cached_added)
                ), xbmc.LOGINFO)
                _call(env, "verify_selected_library_cache", precreated_progress=progress_v1747, show_progress=True)
            # v2090: completed library ADD never returns to the already-running
            # Home window.  Large recommendation/canonical/widget invalidation is
            # a startup job; exposing Home while that work runs creates a
            # spinner-covered but non-actionable surface.  Reuse the established
            # v2048 single 종료 completion window and apply on the next start.
            _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V2091 action=added sections=%s mode=exit_for_restart" % ",".join(added), xbmc.LOGINFO)
            confirmed_v2090 = _library_add_exit_for_restart_v2090(env, added, added_names)
            _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V2091 action=added sections=%s confirmed=%d next_start_loading_apply=1" % (
                ",".join(added), 1 if confirmed_v2090 else 0
            ), xbmc.LOGINFO)
            return "restart_exit"
    elif removed:
        _call(env, "set_initial_sync_done", True)
        removed_names = _section_names(all_sections, removed)
        removed_line_v1753 = ", ".join(removed_names[:2]) if removed_names else ", ".join(removed[:2])
        msg = "라이브러리 해제가 완료되었습니다.\n캐시는 유지되어 재추가가 빠릅니다."
        if removed_line_v1753:
            msg += "\n제거: %s" % removed_line_v1753
        msg += "\n확인을 누르면 홈으로 이동합니다."
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
        except Exception:
            pass
        _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=removed", xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V1753 action=removed sections=%s" % ",".join(removed), xbmc.LOGINFO)
        _open_message(env, "PKM 라이브러리 완료", msg, ok_label="확인")
        _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V1753 action=removed sections=%s" % ",".join(removed), xbmc.LOGINFO)
        try:
            _w_v1754 = xbmcgui.Window(10000)
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyBusyV1754", "1")
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyTextV1754", "라이브러리 반영 중 (10%)")
            _w_v1754.clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
        except Exception:
            pass
        _log(env, "LIBRARY_HOME_APPLY_SPINNER_ARM_V1754 action=removed", xbmc.LOGINFO)
        _call(env, "signal_home_data_refresh", reason="library_removed")
        _log(env, "LIBRARY_SELECTION_REMOVE_COMPLETE_OPEN_HOME_V1753 removed=%s" % ",".join(removed), xbmc.LOGINFO)
        return "open_home"
    elif force:
        _call(env, "sync_all_sections", show_prompt=False, show_progress=True, mark_auto_sync=True, section_ids=new_ids, progress_title="라이브러리 싱크")
        selected_names_v1753 = _section_names(all_sections, new_ids)
        selected_line_v1753 = ", ".join(selected_names_v1753[:2]) if selected_names_v1753 else ", ".join(new_ids[:2])
        msg_v1753 = "라이브러리 싱크가 완료되었습니다."
        if selected_line_v1753:
            msg_v1753 += "\n대상: %s" % selected_line_v1753
        msg_v1753 += "\n확인을 누르면 홈으로 이동합니다."
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
        except Exception:
            pass
        _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=resync", xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V1753 action=resync sections=%s" % ",".join(new_ids), xbmc.LOGINFO)
        _open_message(env, "PKM 라이브러리 완료", msg_v1753, ok_label="확인")
        _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V1753 action=resync sections=%s" % ",".join(new_ids), xbmc.LOGINFO)
        try:
            _w_v1754 = xbmcgui.Window(10000)
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyBusyV1754", "1")
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyTextV1754", "라이브러리 반영 중 (10%)")
            _w_v1754.clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
        except Exception:
            pass
        _log(env, "LIBRARY_HOME_APPLY_SPINNER_ARM_V1754 action=resync", xbmc.LOGINFO)
        _call(env, "signal_home_data_refresh", reason="library_selected_resync")
        _log(env, "LIBRARY_SELECTION_RESYNC_COMPLETE_OPEN_HOME_V1753 selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        return "open_home"
    else:
        _open_message(env, "PKM 라이브러리 선택", "변경된 라이브러리가 없습니다.", ok_label="확인")
    return True


def choose_libraries_dialog(env, force=False):
    all_sections, labels, preselect = library_selection_rows(env)
    if not all_sections:
        return False
    chosen = _call(env, "open_list", "PKM 라이브러리 선택", labels, multiselect=True, preselect=preselect)
    if chosen is None:
        _log(env, "LIBRARY_SELECTION_CANCEL", xbmc.LOGINFO)
        return False
    return apply_library_selection(env, all_sections, chosen, force=force)
