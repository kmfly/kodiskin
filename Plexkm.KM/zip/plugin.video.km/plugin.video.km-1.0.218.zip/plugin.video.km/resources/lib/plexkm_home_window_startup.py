# -*- coding: utf-8 -*-
"""PKM home window part (R73): 시작/스플래시/초기 화면 구성.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartStartupR73
    def _r71_prepare_progress(self, percent, phase):
        """Display actual completed startup stages, not time-based fake percentages."""
        try:
            dlg = getattr(self, '_r69_prepare_dialog', None)
            if dlg is not None:
                # R115: obsolete Home preparation progress bar removed
                _log('R71_PREP_PROGRESS percent=%d phase=%s' % (percent, phase))
        except Exception as exc:
            _log('R71_PREP_PROGRESS_FAILED err=%s' % exc, xbmc.LOGWARNING)

    def _start_startup_gate_v1619(self, reason=""):
        """Keep the whole PKM surface behind one spinner until Home is complete.

        XML defaults the gate to visible while the global Ready property is empty,
        so no partial sidebar/hero/widget paint can escape before onInit runs.
        The Ready property survives WindowXML re-entry after playback but is reset
        naturally when Kodi restarts.
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                _log("STARTUP_ATOMIC_GATE_REUSE_V1619 reason=%s ready=1" % (reason or ""))
                return
            token = str(int(time.time() * 1000))
            self._startup_gate_started_ms_v2495 = int(time.time() * 1000)
            try:
                win.setProperty("PlexKM.Startup.GateStartedAtMsV2495", str(self._startup_gate_started_ms_v2495))
            except Exception:
                pass
            _startup_progress_reset_v1904(reason="startup_gate_begin:%s" % (reason or ""))
            self._startup_gate_token_v1619 = token
            self._startup_gate_release_running_v1619 = False
            self._startup_scene_composed_event_v1841.clear()
            self._startup_ready_event_v1841.clear()
            self._startup_native_prebuild_done_v2492 = False
            self._startup_native_prebuild_stats_v2492 = {}
            self._startup_texture_prewarm_done_v2492 = False
            self._startup_texture_prewarm_stats_v2492 = {}
            # V2535: established launches publish only the authoritative current Home
            # before warming non-visible section destinations. First bootstrap keeps
            # the historical full-destination contract.
            self._startup_established_current_home_only_v2535 = False
            self._startup_deferred_destination_repair_v2535 = False
            self._startup_new_content_sections_v2535 = set()
            self._startup_removed_content_sections_v2535 = set()
            self._home_runtime_snapshot_index_v2499_cache = None
            self._home_runtime_snapshot_index_v2499_stats = {}
            self._home_runtime_progress_map_v2499 = {}
            self._home_startup_fastpath_stats_v2499 = {}
            try:
                for _k_v2492 in (
                    "PlexKM.Startup.PrepareTextV2492", "PlexKM.Startup.PreparePhaseV2492",
                    "PlexKM.Startup.NewContentAddedV2535", "PlexKM.Startup.NewContentSectionsV2535",
                    "PlexKM.Startup.ProblemActiveV2535", "PlexKM.Startup.ProblemTextV2535",
                ):
                    win.clearProperty(_k_v2492)
            except Exception:
                pass
            self._startup_texture_candidates_snapshot_v1841 = ()
            for target in (self, win):
                try:
                    target.setProperty("PlexKM.Home.StartupGateV1619", "1")
                    target.setProperty("PlexKM.Home.StartupGateTokenV1619", token)
                    target.setProperty("PlexKM.SkinStartupSplash", "1")
                    target.clearProperty("PlexKM.Home.StartupReadyV1619")
                    target.clearProperty("PlexKM.Home.FullSceneComposedV1643")
                    target.clearProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643")
                except Exception:
                    pass
            _log("STARTUP_ATOMIC_GATE_BEGIN_V1619 reason=%s token=%s mode=user_4k_splash_until_full_current_home" % (
                reason or "", token
            ))

            # v1644: no fixed-time reveal.  The splash is released only by the
            # completed Plex snapshot + Home + all-sidebar scene state barrier.
            # V2700: ...except that no single failed proof (404 poster, stuck
            # handshake, stalled prepare worker) may keep the user behind the
            # splash forever.  See _startup_hard_ceiling_watchdog_v2700.
            self._arm_startup_hard_ceiling_v2700(token)
            self._startup_hard_ceiling_armed_r69 = token
        except Exception:
            _log("STARTUP_ATOMIC_GATE_BEGIN_FAILED_V1619 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            # R69: a failed gate begin must still be covered by the V2700 ceiling;
            # otherwise the splash it already raised has no owner that lowers it.
            try:
                token_r69 = str(getattr(self, "_startup_gate_token_v1619", "") or "")
                if getattr(self, "_startup_hard_ceiling_armed_r69", None) != token_r69:
                    self._startup_hard_ceiling_armed_r69 = token_r69
                    self._arm_startup_hard_ceiling_v2700(token_r69)
                    _log("STARTUP_HARD_CEILING_ARM_AFTER_FAIL_R69 token=%s" % (token_r69 or "-"), xbmc.LOGWARNING)
            except Exception:
                pass

    def _arm_startup_hard_ceiling_v2700(self, token):
        """V2700: last-resort watchdog, independent of every other startup proof.

        Normal startup releases the splash through the verified atomic reveal.
        If that has not happened HARD_MS after the gate began (any cause: poster
        404, stuck logo handshake, stalled prepare worker, exception in a
        worker), reveal whatever Home currently is instead of hanging forever.
        Late content keeps filling in through the normal post-home repair paths.
        """
        generation = int(self._lifecycle_generation_v1841)
        _log("STARTUP_HARD_CEILING_ARMED_V2700 token=%s soft_s=25 hard_s=60 prepare_soft_s=180 prepare_hard_s=300 failsoft_texture_stall=3s" % token)

        def _watchdog():
            started = time.time()
            soft_s, hard_s = 25.0, 60.0
            try:
                while self._worker_alive_v1841(generation):
                    if token != (self._startup_gate_token_v1619 or ""):
                        return
                    win = xbmcgui.Window(10000)
                    if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                        return
                    waited = time.time() - started
                    populated = False
                    try:
                        menu = self.getControl(9000)
                        populated = bool(menu is not None and int(menu.size()) > 0)
                    except Exception:
                        populated = False
                    # A genuine first bootstrap / content-change prepare legitimately
                    # takes long (it reports its own progress); give it more room.
                    if bool(getattr(self, "_startup_prepare_required_v2477", False)):
                        soft_s, hard_s = 180.0, 300.0
                    else:
                        soft_s, hard_s = 25.0, 60.0
                    if (populated and waited >= soft_s) or waited >= hard_s:
                        self._startup_hard_reveal_v2700(token, int(waited * 1000), populated)
                        return
                    if self._closing_event_v1841.wait(0.5):
                        return
            except Exception:
                _log("STARTUP_HARD_CEILING_WATCHDOG_FAILED_V2700 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            _PKMHomeThreadV2151(target=_watchdog, name="PlexKMStartupHardCeilingV2700", daemon=True).start()
        except Exception:
            pass

    def _startup_hard_reveal_v2700(self, token, waited_ms, populated):
        win = xbmcgui.Window(10000)
        _log("STARTUP_HARD_CEILING_REVEAL_V2700 waited_ms=%d menu_populated=%d token=%s action=force_release_splash" % (
            int(waited_ms), 1 if populated else 0, token), xbmc.LOGERROR)
        try:
            self._startup_scene_composed_event_v1841.set()
            for target in (self, win):
                try:
                    target.setProperty("PlexKM.Home.FullSceneComposedV1643", "1")
                    target.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                except Exception:
                    pass
            for key in (
                "PlexKM.Startup.SlowGuardTokenV2365", "PlexKM.Startup.SlowVisibleV2365",
                "PlexKM.Startup.SlowTextV2365", "PlexKM.Startup.SlowPhaseV2365",
                "PlexKM.Startup.SlowArmAtMsV2493", "PlexKM.Startup.PrepareTextV2492",
                "PlexKM.Startup.PreparePhaseV2492", "PlexKM.Startup.ProblemActiveV2535",
                "PlexKM.Startup.ProblemTextV2535", "PlexKM.Startup.FinalVisualTailV2516",
                "PlexKM.Startup.FinalVisualTailArmMsV2516", "PlexKM.Startup.R73HomeOverlay",
                "PlexKM.Startup.R73HomeOverlayProgress", "PlexKM.Startup.InitialPrepareActiveCumulative",
                "PlexKM.Startup.InitialPrepareMessageCumulative", "PlexKM.Home.StartupGateV1619",
                "PlexKM.SkinStartupSplash",
            ):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
            win.setProperty("PlexKM.Home.StartupReadyV1619", "1")
            win.setProperty("PlexKM.Home.StartupFallbackV1841", "hard_ceiling_v2700")
            try:
                self.clearProperty("PlexKM.Home.StartupGateV1619")
                self.clearProperty("PlexKM.SkinStartupSplash")
                self.setProperty("PlexKM.Home.StartupReadyV1619", "1")
            except Exception:
                pass
            try:
                _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.set()
            except Exception:
                pass
            self._startup_ready_event_v1841.set()
            self._startup_gate_release_running_v1619 = False
            try:
                self._last_action_ms = _pkm_speed_ms()
                self._start_post_startup_background_v1643(reason="hard_ceiling_v2700")
            except Exception:
                pass
            try:
                if self.getFocusId() not in (9000,):
                    self.setFocusId(9000)
            except Exception:
                pass
        except Exception:
            _log("STARTUP_HARD_REVEAL_FAILED_V2700 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _startup_full_compose_required_v1643(self):
        try:
            return xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") != "1"
        except Exception:
            return True

    def _startup_texture_cache_wiped_r57(self):
        """R57: True when poster caches look wiped (Kodi Thumbnails/Textures13 or
        the PKM poster cache), so the next start rebuilds posters under the
        initial-compose overlay instead of filling them in on a visible Home.
        Normal cache churn (Kodi trimming old textures) never reaches these
        thresholds."""
        reason_r57 = ""
        try:
            try:
                db_path = xbmcvfs.translatePath("special://database/Textures13.db")
            except Exception:
                db_path = ""
            if not db_path or not os.path.exists(db_path):
                reason_r57 = "textures_db_missing"
            else:
                rows = []
                try:
                    conn = _pkm_ro_connect(db_path, timeout=0.2)
                    try:
                        rows = conn.execute(
                            "SELECT cachedurl FROM texture WHERE url LIKE 'http%' ORDER BY id DESC LIMIT 40"
                        ).fetchall()
                    finally:
                        conn.close()
                except Exception:
                    rows = None
                if rows is not None:
                    if len(rows) < 20:
                        reason_r57 = "textures_db_nearly_empty:%d" % len(rows)
                    else:
                        missing = 0
                        for (cachedurl,) in rows:
                            cachedurl = str(cachedurl or "").strip()
                            try:
                                path = xbmcvfs.translatePath("special://thumbnails/" + cachedurl.replace("\\", "/")) if cachedurl else ""
                            except Exception:
                                path = ""
                            if not path or not os.path.exists(path):
                                missing += 1
                        if missing * 2 > len(rows):
                            reason_r57 = "thumbnail_files_missing:%d/%d" % (missing, len(rows))
            if not reason_r57:
                cache_dir = str(getattr(self, "_wall_poster_cache_dir_v1644", "") or "")
                if cache_dir:
                    count = 0
                    try:
                        if os.path.isdir(cache_dir):
                            for _name in os.listdir(cache_dir):
                                count += 1
                                if count >= 20:
                                    break
                    except Exception:
                        count = 20
                    if count < 20:
                        reason_r57 = "pkm_poster_cache_empty:%d" % count
        except Exception:
            reason_r57 = ""
        if reason_r57:
            _log("STARTUP_R57_CACHE_WIPED reason=%s action=initial_compose_overlay" % reason_r57)
        return bool(reason_r57)

    def _mark_startup_full_scene_composed_v1643(self, reason=""):
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                try:
                    target.setProperty("PlexKM.Home.FullSceneComposedV1643", "1")
                    target.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                except Exception:
                    pass
            try:
                self._startup_texture_candidates_snapshot_v1841 = tuple(
                    self._home_startup_texture_candidates_v1619(max_rows=2, max_items=7)
                )
                _log('R125_STARTUP_TEXTURE_PROOF candidates=%d' % len(self._startup_texture_candidates_snapshot_v1841))
            except Exception:
                self._startup_texture_candidates_snapshot_v1841 = ()
            self._startup_full_scene_composed_at_ms_v2534 = int(time.time() * 1000.0)
            _log("STARTUP_CURRENT_HOME_FULL_COMPOSED_V1643 reason=%s rows=%d controls=%d" % (
                reason or "", len(self._home_rows_cache or []), len(self._home_visible_row_controls or [])
            ))
            try:
                _gate_v2534 = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
                _elapsed_v2534 = max(0, int(self._startup_full_scene_composed_at_ms_v2534) - _gate_v2534) if _gate_v2534 > 0 else -1
                _log("STARTUP_PHASE_TIMING_V2534 phase=home_compose_complete elapsed_from_gate_ms=%d cause=%s prepare_required=%d" % (
                    _elapsed_v2534, str(getattr(self, "_startup_prepare_cause_v2487", "") or "unknown"),
                    1 if getattr(self, "_startup_prepare_required_v2477", False) else 0
                ))
            except Exception:
                pass

            # v2492: Home is released only when the selected persistent snapshot
            # set is complete. After the one-time bootstrap this is selective: the
            # worker skips every unchanged/ready section and repairs only missing or
            # changed Recommendation/Library destinations under the startup cover.
            if bool(getattr(self, "_startup_prepare_required_v2477", False)):
                _log("STARTUP_HOME_RELEASE_HOLD_V2492 reason=%s cause=%s selective_snapshot_repair=1 unchanged_reuse=1 post_reveal_repair=0" % (
                    reason or "", str(getattr(self, "_startup_prepare_cause_v2487", "") or "unknown")
                ))
                cause_r57 = str(getattr(self, "_startup_prepare_cause_v2487", "") or "")
                if cause_r57 in _R57_INITIAL_COMPOSE_CAUSES:
                    # R57: the logo no longer waits for every destination snapshot
                    # and poster.  Home is released at 100% under an opaque
                    # "초기 화면 구성" overlay that shows real poster progress.
                    self._initial_compose_r57_begin(cause=cause_r57, reason=reason or "home_composed")
                    self._start_startup_prepare_v2477(reason=reason or "home_composed")
                    self._startup_scene_composed_event_v1841.set()
                    _log("STARTUP_R57_INITIAL_COMPOSE_RELEASE cause=%s reason=%s logo_hold=0 overlay=1" % (cause_r57, reason or ""))
                    return
                self._start_startup_prepare_v2477(reason=reason or "home_composed")
                return

            established_home_only_v2535 = bool(getattr(self, "_startup_established_current_home_only_v2535", False))
            if bool(getattr(self, "sections", None)) and (
                    not bool(getattr(self, "_startup_native_prebuild_done_v2492", False))
                    or not bool(getattr(self, "_startup_texture_prewarm_done_v2492", False))) and not established_home_only_v2535:
                self._startup_scene_composed_event_v1841.clear()
                self._startup_force_slow_notice_if_due_v2494("포스터 이미지를 준비 중입니다", "startup_texture_prewarm")
                _log("STARTUP_HOME_RELEASE_HOLD_V2495 reason=%s native=%d texture_prewarm=%d action=keep_splash_no_sidebar_cold" % (
                    reason or "",
                    1 if getattr(self, "_startup_native_prebuild_done_v2492", False) else 0,
                    1 if getattr(self, "_startup_texture_prewarm_done_v2492", False) else 0
                ), xbmc.LOGERROR)
                self._startup_acceptance_log_v2494r3(
                    result="FAIL", stage="destination_prepare", reason="all_destination_native_or_texture_incomplete",
                    wait_ms=-1, final=0
                )
                return
            if established_home_only_v2535:
                _log("STARTUP_CURRENT_HOME_GATE_V2535 reason=%s native=%d all_destination_texture=%d current_home_texture_gate=required offscreen_destination_gate=deferred" % (
                    reason or "",
                    1 if getattr(self, "_startup_native_prebuild_done_v2492", False) else 0,
                    1 if getattr(self, "_startup_texture_prewarm_done_v2492", False) else 0
                ))
            self._startup_scene_composed_event_v1841.set()
            _startup_progress_v1845(88, reason="home_full_scene_composed")
            total_v2477, rec_v2477, lib_v2477, _ = self._startup_prepare_readiness_v2477()
            complete_v2477 = bool(total_v2477 > 0 and rec_v2477 == total_v2477 and lib_v2477 == total_v2477)
            if complete_v2477:
                self._post_reveal_all_sections_prewarm_done_v1649 = True
                self._post_reveal_library_data_warm_done_v2472 = True
                self._auto_snapshot_done_v2476 = True
                _log("STARTUP_ALL_DESTINATIONS_READY_V2492 sections=%d recommend_ready=%d library_ready=%d native_prebuild=%d post_reveal_snapshot_repair=0" % (
                    total_v2477, rec_v2477, lib_v2477, 1 if getattr(self, "_startup_native_prebuild_done_v2492", False) else 0
                ))
            else:
                if established_home_only_v2535:
                    # V2535: do not expose stale destination caches. They remain
                    # invalid and are rebuilt after Home; if the user enters one
                    # before the repair completes, the normal live DB path owns it.
                    self._startup_deferred_destination_repair_v2535 = True
                    _log("STARTUP_DESTINATION_INVARIANT_DEFER_V2535 sections=%d recommend_ready=%d library_ready=%d current_home_release=allowed stale_destination_publish=0 repair=post_home" % (
                        total_v2477, rec_v2477, lib_v2477
                    ))
                else:
                    # First bootstrap still keeps the historical full-destination
                    # fail-closed contract.
                    self._startup_scene_composed_event_v1841.clear()
                    self._startup_prepare_required_v2477 = True
                    _log("STARTUP_DESTINATION_INVARIANT_BLOCK_V2492 sections=%d recommend_ready=%d library_ready=%d action=keep_splash_selective_repair" % (
                        total_v2477, rec_v2477, lib_v2477
                    ), xbmc.LOGERROR)
                    self._start_startup_prepare_v2477(reason=reason or "home_composed_invariant_repair")
                    return
        except Exception:
            self._startup_scene_composed_event_v1841.set()
            _log("STARTUP_CURRENT_HOME_FULL_COMPOSE_MARK_FAILED_V1643 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _home_startup_texture_candidates_v1619(self, max_rows=2, max_items=7):
        candidates = []
        held_r118 = []  # R118c: card refs taken here are released on the GUI thread
        try:
            for cid in HOME_ROW_IDS[:max(1, int(max_rows or 2))]:
                try:
                    ctrl = self.getControl(cid)
                    count = min(max(0, int(ctrl.size())), max(1, int(max_items or 7)))
                except Exception:
                    continue
                for idx in range(count):
                    li = None
                    try:
                        li = ctrl.getListItem(idx)
                        held_r118.append(li)
                        # v2491: a verified item-level missing-poster placeholder is
                        # already render-safe. Do not make an intentionally missing
                        # image block the whole section texture gate.
                        if str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1":
                            continue
                        sources_v2498 = list(self._poster_authority_sources_v2498(li) or [])
                        primary = str(sources_v2498[0] if sources_v2498 else "").strip()
                        fallback = str(sources_v2498[1] if len(sources_v2498) > 1 else "").strip()
                        if primary or fallback:
                            candidates.append((primary, fallback))
                    except Exception:
                        pass
            try:
                fanart = str(self.getProperty("PlexKM.Home.DisplayFanart") or "").strip()
                if fanart:
                    candidates.append((fanart, ""))
            except Exception:
                pass
        except Exception:
            pass
        li = None
        self._li_release_r118(held_r118)
        return candidates

    def _texture_pair_ready_flags_v2493(self, candidates):
        """Return readiness for many poster pairs using one Textures DB scan.

        V2492 reopened Textures13.db once per sidebar destination (44 times in
        the reported 22-library startup) even when every poster was already
        cached.  That made a no-change restart spend ~15 seconds doing proof
        work.  V2493 batches all remote URLs and performs one DB connection.
        """
        pairs = list(candidates or [])
        if not pairs:
            return []
        remote_values = []
        remote_seen = set()
        local_ready = set()
        for primary, fallback in pairs:
            for value in (primary, fallback):
                value = str(value or "").strip()
                if not value:
                    continue
                if value.startswith(("http://", "https://")):
                    if value not in remote_seen:
                        remote_seen.add(value)
                        remote_values.append(value)
                else:
                    try:
                        translated = xbmcvfs.translatePath(value)
                    except Exception:
                        translated = value
                    try:
                        if translated and (xbmcvfs.exists(translated) or os.path.exists(translated)):
                            local_ready.add(value)
                    except Exception:
                        pass
        cached_ready = set()
        if remote_values:
            try:
                db_path = xbmcvfs.translatePath("special://database/Textures13.db")
            except Exception:
                db_path = ""
            if db_path and os.path.exists(db_path):
                try:
                    conn = _pkm_ro_connect(db_path, timeout=0.2)
                    try:
                        step = 300
                        for start in range(0, len(remote_values), step):
                            chunk = remote_values[start:start + step]
                            marks = ",".join("?" for _ in chunk)
                            query = "SELECT url,cachedurl FROM texture WHERE url IN (%s)" % marks
                            for url, cachedurl in conn.execute(query, tuple(chunk)).fetchall():
                                cachedurl = str(cachedurl or "").strip()
                                if not cachedurl:
                                    continue
                                try:
                                    thumb_path = xbmcvfs.translatePath(
                                        "special://thumbnails/" + cachedurl.replace("\\", "/")
                                    )
                                except Exception:
                                    thumb_path = ""
                                try:
                                    if thumb_path and os.path.exists(thumb_path) and os.path.getsize(thumb_path) > 0:
                                        cached_ready.add(str(url or ""))
                                except Exception:
                                    pass
                    finally:
                        conn.close()
                except Exception:
                    pass
        flags = []
        for primary, fallback in pairs:
            vals = [str(primary or "").strip(), str(fallback or "").strip()]
            vals = [v for v in vals if v]
            flags.append(bool((not vals) or any(v in local_ready or v in cached_ready for v in vals)))
        return flags

    def _startup_texture_failsoft_v2700(self, candidates, stalled_ms=0, waited_ms=0):
        """V2700: bounded fail-soft for the Home atomic reveal texture proof.

        The established/local-first startup path (V2583) skips the V2530 poster
        prewarm, so a first-row poster that Plex answers with 404 (freshly added
        item without thumb yet, deleted item still in the persisted render cache,
        stale thumb timestamp) was never marked missing.  The reveal worker then
        waited forever for a Textures13 entry that can never exist and the splash
        never released.  After the texture count has stalled, mark every still
        unresolved first-row poster as a session-only missing card (same card as
        V2530; nothing persistent is written) and drop unresolved candidates
        (e.g. fanart) from the proof so Home can be revealed.
        """
        kept = []
        try:
            pairs = list(candidates or [])
            flags = self._texture_pair_ready_flags_v2493(pairs) if pairs else []
            marked = 0
            for row_id in HOME_ROW_IDS[:2]:
                try:
                    ctrl = self.getControl(row_id)
                    count = min(max(0, int(ctrl.size())), 7)
                except Exception:
                    continue
                for idx in range(count):
                    try:
                        li = ctrl.getListItem(idx)
                        if str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1":
                            continue
                        sources = list(self._poster_authority_sources_v2498(li) or [])
                        if not sources:
                            continue
                        pair = (str(sources[0]).strip(), str(sources[1] if len(sources) > 1 else "").strip())
                        if self._texture_pair_ready_flags_v2493([pair])[0]:
                            continue
                        rec = {"li": li, "rating_key": str(li.getProperty("PlexKM.RatingKey") or "")}
                        if self._startup_mark_transient_missing_poster_v2530(rec, reason="reveal_stall_v2700"):
                            marked += 1
                    except Exception:
                        pass
            fresh = list(self._home_startup_texture_candidates_v1619(max_rows=2, max_items=7))
            fresh_flags = self._texture_pair_ready_flags_v2493(fresh) if fresh else []
            dropped = 0
            for pair, ok in zip(fresh, fresh_flags):
                if ok:
                    kept.append(pair)
                else:
                    dropped += 1
                    _log("STARTUP_TEXTURE_FAILSOFT_DROP_V2700 url=%s" % re.sub(r"X-Plex-Token=[^&\s]+", "X-Plex-Token=***", str(pair[0] or pair[1] or "-"))[:200], xbmc.LOGWARNING)
            _log("STARTUP_TEXTURE_FAILSOFT_V2700 marked_missing=%d dropped_from_proof=%d kept=%d stalled_ms=%d waited_ms=%d action=release_home retry_next_rebuild=1 persistent_negative=0" % (
                marked, dropped, len(kept), int(stalled_ms), int(waited_ms)
            ), xbmc.LOGERROR)
        except Exception:
            _log("STARTUP_TEXTURE_FAILSOFT_FAILED_V2700 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return tuple(candidates or ())
        return tuple(kept)

    def _r70_http_status(self, url, timeout=1.5):
        try:
            resp = urlopen(Request(url, headers={"Accept": "*/*"}), timeout=timeout)
            try:
                return int(getattr(resp, "status", 0) or resp.getcode() or 0), resp
            except Exception:
                return 0, resp
        except Exception as exc:
            code = getattr(exc, "code", None)
            return (int(code) if code else -1), None

    def _r70_fresh_thumb_url(self, stale_url):
        """Ask Plex for the item's current thumb path (new timestamp)."""
        m = self._R70_THUMB_RE.match(str(stale_url or ""))
        if not m:
            return ""
        base, rk, kind, query = m.group(1), m.group(2), m.group(3), (m.group(4) or "")
        status, resp = self._r70_http_status("%s/library/metadata/%s%s" % (base, rk, query), timeout=2.0)
        if status != 200 or resp is None:
            return ""
        try:
            root = ET.fromstring(resp.read(2 * 1024 * 1024))
        except Exception:
            return ""
        finally:
            try:
                resp.close()
            except Exception:
                pass
        path = ""
        for node in root.iter():
            if str(node.get("ratingKey") or "") == rk and node.get(kind):
                path = str(node.get(kind) or "")
                break
        if not path.startswith("/"):
            return ""
        fresh = base + path + query
        if fresh == stale_url:
            return ""
        return fresh

    def _r70_rebind_poster(self, old_url, new_url):
        """Point every Home card that uses old_url at new_url (session + DB).

        R84: only the two startup-proof rows are rebound inline; the other rows
        and the DB row follow on a worker.  The old inline version walked every
        Home card (~214) and ran "UPDATE items ... WHERE thumb=?" (no index ->
        full scan of the 1 GB DB): 11.5 s on the Shield before Home appeared."""
        keys = ("PlexKM.PosterAuthorityV2498", "PlexKM.WallPosterRemoteV1644",
                "PlexKM.Thumb", "PlexKM.OriginalThumbV1877")

        def _rebind_rows(row_ids):
            n = 0
            for cid in row_ids:
                try:
                    ctrl = self.getControl(cid)
                    count = int(ctrl.size())
                except Exception:
                    continue
                for idx in range(count):
                    li = None
                    try:
                        li = ctrl.getListItem(idx)
                        hit = False
                        for key in keys:
                            if str(li.getProperty(key) or "").strip() == old_url:
                                li.setProperty(key, new_url)
                                hit = True
                        art = {}
                        for name in ("poster", "thumb"):
                            if str(li.getArt(name) or "").strip() == old_url:
                                art[name] = new_url
                        if art:
                            li.setArt(art)
                            hit = True
                        if hit:
                            n += 1
                    except Exception:
                        pass
                    # R118c: on-screen card reference -> released on the GUI thread
                    self._li_release_r118(li)
                    li = None
            return n

        rebound = _rebind_rows(HOME_ROW_IDS[:2])
        rk_r84 = ""
        try:
            m_r84 = self._R70_THUMB_RE.match(str(old_url or ""))
            rk_r84 = m_r84.group(2) if m_r84 else ""
        except Exception:
            rk_r84 = ""

        def _rest_r84():
            t0 = time.time()
            later = _rebind_rows(HOME_ROW_IDS[2:])
            db_rows = -1
            try:
                conn = sqlite3.connect(_ensure_core().db_path(), timeout=5.0)
                try:
                    if rk_r84:
                        cur = conn.execute("UPDATE items SET thumb=? WHERE rating_key=? AND thumb=?",
                                           (new_url, rk_r84, old_url))
                    else:
                        cur = conn.execute("UPDATE items SET thumb=? WHERE thumb=?", (new_url, old_url))
                    conn.commit()
                    db_rows = int(cur.rowcount or 0)
                finally:
                    conn.close()
            except Exception as exc:
                _log("STARTUP_STALE_POSTER_DB_UPDATE_FAILED_R70 err=%s" % exc, xbmc.LOGWARNING)
            _log("STARTUP_STALE_POSTER_REBIND_BG_R84 rk=%s cards=%d db_rows=%d ms=%d" % (
                rk_r84 or "-", later, db_rows, int((time.time() - t0) * 1000)))

        try:
            threading.Thread(target=_rest_r84, name="PKMStalePosterR84", daemon=True).start()
        except Exception:
            pass
        return rebound, -2

    def _r71_dead_path(self):
        try:
            return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/startup_poster_dead_r71.json")
        except Exception:
            return ""

    def _r71_dead_load(self):
        cache = getattr(self, "_r71_dead_cache", None)
        if cache is not None:
            return cache
        cache = {}
        try:
            path = self._r71_dead_path()
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as fh:
                    raw = json.load(fh) or {}
                now = time.time()
                cache = {str(k): float(v) for k, v in raw.items()
                         if now - float(v or 0) < self._R71_DEAD_TTL_S}
        except Exception:
            cache = {}
        self._r71_dead_cache = cache
        return cache

    def _r71_dead_store(self, urls):
        try:
            cache = dict(self._r71_dead_load())
            now = time.time()
            for url in urls:
                cache[str(url)] = now
            self._r71_dead_cache = cache
            path = self._r71_dead_path()
            if path:
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(cache, fh)
                os.replace(tmp, path)
        except Exception as exc:
            _log("STARTUP_POSTER_DEAD_STORE_FAILED_R71 err=%s" % exc, xbmc.LOGWARNING)

    def _r71_known_dead_pending(self, candidates):
        """R71: a first-row poster Plex had no image for on a recent start.
        Resolve it at once instead of after the 0.8 s probe delay."""
        try:
            cache = self._r71_dead_load()
            if not cache:
                return False
            for primary, fallback in (candidates or ()):
                if str(primary or fallback or "").strip() in cache:
                    return True
        except Exception:
            pass
        return False

    def _startup_stale_poster_probe_r70(self, candidates):
        """R70: resolve never-ready first-row posters before the V2700 fail-soft.

        Unresolved Plex thumbs are fetched once in parallel.  404/410 means the
        stored URL is stale: the current path is read from Plex metadata and the
        cards (and items.thumb) are rebound to it; if Plex has no poster the card
        becomes the session missing card at once.  Anything else (slow, timeout,
        200) is left to the normal wait.
        """
        started = _pkm_speed_ms()
        pairs = list(candidates or ())
        try:
            flags = self._texture_pair_ready_flags_v2493(pairs)
        except Exception:
            return tuple(pairs)
        targets = []
        for (primary, fallback), ok in zip(pairs, flags):
            url = str(primary or fallback or "").strip()
            if not ok and self._R70_THUMB_RE.match(url):
                targets.append(url)
        targets = list(dict.fromkeys(targets))[:16]
        if not targets:
            return tuple(pairs)
        statuses = {}
        known_dead_r71 = set(u for u in targets if u in self._r71_dead_load())
        for url in known_dead_r71:
            statuses[url] = 404
        fetch_targets_r71 = [u for u in targets if u not in known_dead_r71]
        try:
            with ThreadPoolExecutor(max_workers=max(1, min(6, len(fetch_targets_r71)))) as pool:
                futures = {pool.submit(self._r70_http_status, url, 1.5): url for url in fetch_targets_r71}
                for fut in as_completed(futures, timeout=3.0):
                    url = futures[fut]
                    try:
                        status, resp = fut.result()
                        if resp is not None:
                            try:
                                resp.close()
                            except Exception:
                                pass
                        statuses[url] = status
                    except Exception:
                        statuses[url] = -1
        except Exception:
            pass
        replace = {}
        dead = set()
        for url, status in statuses.items():
            if status not in (404, 410):
                continue
            fresh = ""
            m_r70 = self._R70_THUMB_RE.match(url)
            if m_r70 and m_r70.group(3) == "art":
                # Background art only gates the reveal; drop it from the proof.
                dead.add(url)
                continue
            if url in known_dead_r71:
                dead.add(url)
                continue
            try:
                fresh = self._r70_fresh_thumb_url(url)
            except Exception:
                fresh = ""
            if fresh:
                rebound, db_rows = self._r70_rebind_poster(url, fresh)
                replace[url] = fresh
                _log("STARTUP_STALE_POSTER_REBOUND_R70 old=%s new=%s cards=%d db_rows=%d" % (
                    re.sub(r"X-Plex-Token=[^&\s]+", "X-Plex-Token=***", url)[:160],
                    re.sub(r"X-Plex-Token=[^&\s]+", "X-Plex-Token=***", fresh)[:160],
                    rebound, db_rows), xbmc.LOGWARNING)
            else:
                dead.add(url)
        new_dead_r71 = [u for u in dead if u not in known_dead_r71 and "/thumb" in u]
        if new_dead_r71:
            self._r71_dead_store(new_dead_r71)
        if dead:
            for cid in HOME_ROW_IDS[:2]:
                try:
                    ctrl = self.getControl(cid)
                    count = min(max(0, int(ctrl.size())), 7)
                except Exception:
                    continue
                for idx in range(count):
                    try:
                        li = ctrl.getListItem(idx)
                        srcs = list(self._poster_authority_sources_v2498(li) or [])
                        if srcs and str(srcs[0]).strip() in dead:
                            self._startup_mark_transient_missing_poster_v2530(
                                {"li": li, "rating_key": str(li.getProperty("PlexKM.RatingKey") or "")},
                                reason="stale_404_no_poster_r70")
                    except Exception:
                        pass
        out = []
        for primary, fallback in pairs:
            key = str(primary or fallback or "").strip()
            if key in dead:
                continue
            if key in replace:
                out.append((replace[key], ""))
            else:
                out.append((primary, fallback))
        _log("STARTUP_STALE_POSTER_PROBE_R70 unresolved=%d probed=%d known_dead_r71=%d stale=%d rebound=%d no_poster=%d elapsed_ms=%d" % (
            len(targets), len(statuses), len(known_dead_r71), sum(1 for s in statuses.values() if s in (404, 410)),
            len(replace), len(dead), _pkm_speed_ms() - started))
        return tuple(out)

    def _texture_pairs_ready_v1619(self, candidates):
        """A poster pair is ready when either primary or fallback has a real file."""
        pairs = list(candidates or [])
        if not pairs:
            return 0, 0
        flags = self._texture_pair_ready_flags_v2493(pairs)
        return sum(1 for flag in flags if flag), len(pairs)

    def _schedule_startup_atomic_release_v1619(self, reason=""):
        """Release the spinner only after the completed Home scene has settled."""
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                return
            if self._startup_gate_release_running_v1619:
                return
            token = self._startup_gate_token_v1619 or win.getProperty("PlexKM.Home.StartupGateTokenV1619")
            if not token:
                self._start_startup_gate_v1619(reason="late_release_arm:%s" % (reason or ""))
                token = self._startup_gate_token_v1619
            self._startup_gate_release_running_v1619 = True
            generation_v1841 = int(self._lifecycle_generation_v1841)
            try:
                initial_candidates_v1841 = tuple(
                    self._home_startup_texture_candidates_v1619(max_rows=2, max_items=7)
                )
            except Exception:
                initial_candidates_v1841 = ()

            def _worker():
                started = int(time.time() * 1000)
                ready_since = 0
                ready = 0
                candidates = initial_candidates_v1841
                total = len(candidates)
                timed_out = False
                timeout_reason_v1841 = ""
                texture_wait_started_v1841 = 0
                compose_stall_logged_v1841 = False
                best_ready_v2700 = -1
                last_progress_ms_v2700 = 0
                failsoft_done_v2700 = False
                stale_probe_done_r70 = False
                try:
                    while self._worker_alive_v1841(generation_v1841):
                        if token != (self._startup_gate_token_v1619 or ""):
                            return
                        now_ms = int(time.time() * 1000)
                        elapsed = now_ms - started
                        full_composed_v1643 = bool(self._startup_scene_composed_event_v1841.is_set())
                        if full_composed_v1643 and not texture_wait_started_v1841:
                            texture_wait_started_v1841 = now_ms
                            candidates = tuple(
                                getattr(self, "_startup_texture_candidates_snapshot_v1841", ()) or
                                initial_candidates_v1841
                            )
                            total = len(candidates)
                        if full_composed_v1643:
                            ready, total = self._texture_pairs_ready_v1619(candidates)
                            if total > 0:
                                _startup_progress_v1845(90 + min(9, int((ready * 9) / total)), reason="startup_textures_%d_of_%d" % (ready, total))
                            else:
                                _startup_progress_v1845(99, reason="startup_no_texture_wait")
                            # R70: a poster Plex answers with 404 (stale thumb timestamp
                            # after a metadata refresh) can never become ready.  Ask
                            # Plex once after 0.8 s instead of waiting 5 s for V2700.
                            if (not stale_probe_done_r70 and total > 0 and ready < total
                                    and ((now_ms - texture_wait_started_v1841) >= 800
                                         or self._r71_known_dead_pending(candidates))):
                                stale_probe_done_r70 = True
                                candidates = self._startup_stale_poster_probe_r70(candidates)
                                ready, total = self._texture_pairs_ready_v1619(candidates)
                            # V2700: bounded fail-soft. Only when the ready count has
                            # stopped improving (3s) after >=5s of waiting; a slow but
                            # progressing download never triggers it.
                            if ready > best_ready_v2700:
                                best_ready_v2700 = ready
                                last_progress_ms_v2700 = now_ms
                            elif not last_progress_ms_v2700:
                                last_progress_ms_v2700 = now_ms
                            # R84: 5 s / 3 s -> 2.5 s / 1.5 s.  Home is already
                            # composed; one dead poster must not hold the reveal.
                            if (not failsoft_done_v2700 and total > 0 and ready < total
                                    and (now_ms - texture_wait_started_v1841) >= 2500
                                    and (now_ms - last_progress_ms_v2700) >= 1500):
                                failsoft_done_v2700 = True
                                candidates = self._startup_texture_failsoft_v2700(
                                    candidates,
                                    stalled_ms=now_ms - last_progress_ms_v2700,
                                    waited_ms=now_ms - texture_wait_started_v1841,
                                )
                                ready, total = self._texture_pairs_ready_v1619(candidates)
                        # v1647: reveal depends only on the locally composed Home
                        # and the first two visible poster rows. Plex synchronization
                        # and all-sidebar scene construction are next-start work.
                        all_ready = bool(
                            full_composed_v1643
                            and ((total == 0) or (ready >= total))
                        )
                        # An established Home with real poster rows cannot
                        # pass by accidentally supplying an empty texture proof.
                        if (all_ready and total == 0 and not failsoft_done_v2700
                                and getattr(self, '_home_rows_cache', None)
                                and not (win.getProperty('PlexKM.StartupSettingsIncomplete') == '1'
                                         or win.getProperty('PlexKM.Home.SettingsRequired') == '1')):
                            candidates = tuple(self._home_startup_texture_candidates_v1619(max_rows=2, max_items=7))
                            total = len(candidates)
                            if total:
                                ready, total = self._texture_pairs_ready_v1619(candidates)
                                all_ready = ready >= total
                        if full_composed_v1643 and bool(getattr(self, "_initial_compose_r57_active", False)):
                            # R57: the opaque initial-compose overlay hides Home until
                            # the posters are ready; the logo itself need not wait.
                            all_ready = True
                        if all_ready and not ready_since:
                            _log('R126_HOME_CONTENT_READY wait_ms=%d texture_ready=%d texture_total=%d composed=%d' % (
                                elapsed, ready, total, 1 if full_composed_v1643 else 0))
                        if all_ready:
                            if not ready_since:
                                ready_since = now_ms
                        else:
                            ready_since = 0
                        stable_ms = (now_ms - ready_since) if ready_since else 0
                        # Under the opaque spinner Kodi continues rendering the full
                        # Home scene. Require both file readiness and a real render
                        # settle period so the reveal cannot expose plates filling in.
                        if elapsed >= 120 and all_ready and stable_ms >= 160:
                            break
                        # v2052: no elapsed-time escape is allowed here. The logo
                        # remains until every initial visible texture candidate is
                        # actually available. A slow texture must slow/hold progress,
                        # never reveal an incomplete Home surface.
                        # Never interpret elapsed time as a completed Home scene.
                        # If compose stalls, retain the opaque logo/spinner and
                        # publish a diagnostic state. Revealing here exposed a
                        # genuinely incomplete/blank Home, which violates the
                        # startup atomicity contract.
                        if (not full_composed_v1643 and elapsed >= 12000
                                and not compose_stall_logged_v1841):
                            compose_stall_logged_v1841 = True
                            win.setProperty("PlexKM.Home.StartupComposeStalledV1841", "1")
                            win.setProperty("PlexKM.Home.StartupComposeStalledAtV1841", str(now_ms))
                            _log("STARTUP_ATOMIC_COMPOSE_STALLED_V1841 reason=%s token=%s wait_ms=%d action=keep_splash_no_partial_reveal" % (
                                reason or "", token, elapsed
                            ), xbmc.LOGERROR)
                        # R115: 0.12 s polling added up to ~250 ms after content-ready.
                        if self._closing_event_v1841.wait(0.03):
                            return
                    if (not self._worker_alive_v1841(generation_v1841)
                            or token != (self._startup_gate_token_v1619 or "")):
                        return
                    # v2378R8: Home is actually ready now, but the visual loading
                    # sequence must also finish before the cover is released.
                    # Set the real target to 100 and wait for the image worker's
                    # frame-119 event. This is a state handshake, not a timeout.
                    _ready_fast_logo_v2500 = bool(
                        str(getattr(self, "_startup_prepare_cause_v2487", "") or "") == "ready"
                    )
                    # V2516: real startup work is complete at this point. Keep
                    # the opaque logo up just long enough to visibly finish its yellow
                    # fill; do not classify this purely visual tail as slow loading.
                    _final_tail_arm_ms_v2516 = int(time.time() * 1000)
                    win.setProperty("PlexKM.Startup.FinalVisualTailV2516", "1")
                    win.setProperty("PlexKM.Startup.FinalVisualTailArmMsV2516", str(_final_tail_arm_ms_v2516))
                    _startup_progress_v1845(
                        100,
                        reason=("startup_visual_ready_verified_v2500_ready_fast" if _ready_fast_logo_v2500 else "startup_visual_ready_verified_v2052"),
                        force=True,
                    )
                    try:
                        _fast_visual_v2583 = bool(
                            win.getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                            and bool(getattr(self, "_startup_established_current_home_only_v2535", False))
                        )
                    except Exception:
                        _fast_visual_v2583 = False
                    if _fast_visual_v2583:
                        # V2696: never forge the final-frame handshake.  V2583 used
                        # to set the event while the visible animation was still at
                        # ~60-70%, which let Home reveal before the yellow fill
                        # reached frame 119.  Keep the fast-ready path, but let the
                        # animation worker reach the real final frame naturally.
                        _log("UHD3_STARTUP_FINAL_VISUAL_REAL100_V2696 established=1 forced_event=0 wait_real_frame119=1")
                    _log(
                        "STARTUP_LOGO_FINAL_SMOOTH_ARM_V2516 "
                        "display=%s target=100 fast_ready=%d slow_visible=%d real_work_complete=1"
                        % (
                            win.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0",
                            1 if _ready_fast_logo_v2500 else 0,
                            1 if win.getProperty("PlexKM.Startup.SlowVisibleV2365") == "1" else 0,
                        )
                    )
                    _log(
                        "STARTUP_LOGO_FINAL_FILL_BEGIN_V2378R8 "
                        "display=%s target=100 timer=0"
                        % (
                            win.getProperty("PlexKM.Startup.DisplayProgressV1891")
                            or "0"
                        )
                    )
                    while self._worker_alive_v1841(generation_v1841):
                        if token != (self._startup_gate_token_v1619 or ""):
                            return
                        # R81: R80's logo runs in service.py. Its completion
                        # property must be observed here directly; waiting only
                        # for the legacy Python progress event can deadlock.
                        if (win.getProperty('PlexKM.Startup.LinearLogoCompleteR80') == '1'
                            and win.getProperty('PlexKM.Startup.DisplayFrameV1904') == '239'):
                            _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.set()
                            _log("STARTUP_R81_LINEAR_HANDSHAKE complete=1 source=service_clock")
                            break
                        if _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.wait(0.025):
                            if (not win.getProperty("PlexKM.Startup.LinearLogoToken")
                                    or win.getProperty("PlexKM.Startup.LinearLogoCompleteR80") == "1"):
                                break
                    if (
                        not self._worker_alive_v1841(generation_v1841)
                        or token != (self._startup_gate_token_v1619 or "")
                    ):
                        return
                    try:
                        _linear_started = float(win.getProperty('PlexKM.Startup.LinearLogoStart') or '0')
                        while _linear_started > 0 and time.monotonic() - _linear_started < 4.0:
                            if self._closing_event_v1841.wait(0.025):
                                return
                    except (TypeError, ValueError):
                        pass
                    # R118: the single service frame clock already runs from PKM
                    # startup. The native WindowXML no longer starts its own
                    # animation, so a second onInit-based four-second wait would
                    # incorrectly delay Home after the shared frame reaches 119.
                    _log("R118_SHARED_LOGO_FRAME_COMPLETE source=service_clock frame=239")
                    # R124: the same cover gate is used by normal and initial Home.
                    if not self._r124_wait_native_cover_final(
                            lambda: (not self._worker_alive_v1841(generation_v1841)
                                     or token != (self._startup_gate_token_v1619 or "")),
                            'configured_home'):
                        return
                    # V2516: setImage(frame_239) and the event happen in the same
                    # worker tick. Give Kodi two+ render intervals before removing
                    # the splash so the fully yellow logo is actually visible.
                    _final_frame_hold_ms_v2516 = 40
                    if self._closing_event_v1841.wait(_final_frame_hold_ms_v2516 / 1000.0):
                        return
                    if (
                        not self._worker_alive_v1841(generation_v1841)
                        or token != (self._startup_gate_token_v1619 or "")
                    ):
                        return
                    _log("STARTUP_LOGO_FINAL_FRAME_VISIBLE_HOLD_V2516 display=%s hold_ms=%d final_frame=239" % (
                        win.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0",
                        _final_frame_hold_ms_v2516,
                    ))
                    _log(
                        "STARTUP_LOGO_REAL_PROGRESS_COMPLETE_V2378R8 "
                        "dynamic=1 final_frame=239 visual_handshake=1 "
                        "display=%s total_ms=%d"
                        % (
                            win.getProperty("PlexKM.Startup.DisplayProgressV1891")
                            or "0",
                            int(time.time() * 1000) - started,
                        )
                    )
                    _slow_seen_before_clear_v2494r3 = 1 if win.getProperty("PlexKM.Startup.SlowVisibleV2365") == "1" else 0
                    _slow_text_before_clear_v2494r3 = str(win.getProperty("PlexKM.Startup.SlowTextV2365") or "").strip()
                    try:
                        _slow_arm_before_clear_v2494r3 = int(float(str(win.getProperty("PlexKM.Startup.SlowArmAtMsV2493") or "0")))
                    except Exception:
                        _slow_arm_before_clear_v2494r3 = 0
                    _startup_elapsed_before_clear_v2494r3 = (
                        max(0, int(time.time() * 1000) - _slow_arm_before_clear_v2494r3)
                        if _slow_arm_before_clear_v2494r3 > 0 else -1
                    )
                    for _slow_key_v2365 in (
                        "PlexKM.Startup.SlowGuardTokenV2365",
                        "PlexKM.Startup.SlowVisibleV2365",
                        "PlexKM.Startup.SlowTextV2365",
                        "PlexKM.Startup.SlowPhaseV2365",
                        "PlexKM.Startup.SlowArmAtMsV2493",
                        "PlexKM.Startup.PrepareTextV2492",
                        "PlexKM.Startup.PreparePhaseV2492",
                    ):
                        try:
                            win.clearProperty(_slow_key_v2365)
                        except Exception:
                            pass
                    _log("STARTUP_SLOW_NOTICE_CLEAR_V2365 reason=atomic_reveal")
                    # R109: no hidden ControlImage / texture-DB polling before Home.
                    # Kodi's normal visible widget controls own poster loading.
                    _log("R109_FIRST_WIDGET_PRELOAD_REMOVED mode=normal_kodi_widget_render")

                    win.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    win.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                    win.clearProperty("PlexKM.Home.StartupGateV1619")
                    win.clearProperty("PlexKM.Startup.FinalVisualTailV2516")
                    win.clearProperty("PlexKM.Startup.FinalVisualTailArmMsV2516")
                    _log('R126_HOME_ATOMIC_REVEAL wait_ms=%d texture_ready=%d texture_total=%d' % (
                        int(time.time() * 1000) - started, ready, total))
                    win.clearProperty("PlexKM.SkinStartupSplash")
                    # R116: remove obsolete post-Home R73/R76 preparation screen AND
                    # its 48-item Info/actor snapshot warm-up. On-demand Info/actor
                    # caches remain available via their normal read paths.
                    win.clearProperty("PlexKM.Startup.R73HomeOverlay")
                    win.clearProperty("PlexKM.Startup.R73HomeOverlayProgress")
                    _log("R116_POST_HOME_PREPARATION_REMOVED overlay=0 info_actor_warm=0")
                    win.clearProperty("PlexKM.Startup.InitialPrepareActiveCumulative")
                    win.clearProperty("PlexKM.Startup.InitialPrepareMessageCumulative")
                    win.clearProperty("PlexKM.Home.StartupComposeStalledV1841")
                    win.clearProperty("PlexKM.Home.StartupComposeStalledAtV1841")
                    if timeout_reason_v1841:
                        win.setProperty("PlexKM.Home.StartupFallbackV1841", timeout_reason_v1841)
                    else:
                        win.clearProperty("PlexKM.Home.StartupFallbackV1841")
                    self._startup_ready_event_v1841.set()
                    # v1645: the reveal event, not Plex sync completion, owns
                    # background Cine21 scheduling. It cannot extend spinner time.
                    try:
                        if self._worker_alive_v1841(generation_v1841):
                            self._last_action_ms = _pkm_speed_ms()
                            self._start_post_startup_background_v1643(reason="atomic_reveal_v1645")
                    except Exception:
                        _log("CINE21_POST_REVEAL_ARM_FAILED_V1645 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                    # V2626: all 12 Movie + 12 TV sort keys use a persistent materialized
                    # sort index. Build it only after Home is visible so startup KPI is never
                    # extended by raw_json parsing or TV episode aggregation.
                    try:
                        _sort_sections_v2626 = [str((sec or {}).get("section_id") or "").strip() for sec in (getattr(self, "sections", []) or [])]
                        _sort_sections_v2626 = [sid for sid in _sort_sections_v2626 if sid]
                        # V2696 UHD3: do not launch a multi-thousand-row sort-index
                        # build in the same seconds in which the user starts moving
                        # through the sidebar.  The cold query path already falls
                        # back safely and can priority-build the requested section.
                        # Home-wide prewarm starts only after a short interaction-free
                        # tail; this removes startup/sidebar CPU competition without
                        # changing any Home XML/layout or grouplist navigation.
                        _sort_sections_copy_v2696 = list(_sort_sections_v2626)
                        def _deferred_sort_prewarm_v2696():
                            mon_v2696 = xbmc.Monitor()
                            deadline_v2696 = time.time() + 8.0
                            while time.time() < deadline_v2696:
                                if mon_v2696.waitForAbort(0.25):
                                    return
                            try:
                                win_v2696 = xbmcgui.Window(10000)
                                # If navigation is active, give it another quiet window.
                                for _ in range(20):
                                    now_v2696 = int(time.time() * 1000)
                                    nav_until_v2696 = int(float(win_v2696.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
                                    sidebar_v2696 = win_v2696.getProperty("PlexKM.Sidebar.Browsing") == "1"
                                    wall_v2696 = win_v2696.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                                    if (not sidebar_v2696) and (not wall_v2696) and nav_until_v2696 <= now_v2696:
                                        break
                                    if mon_v2696.waitForAbort(0.25):
                                        return
                                pkm_sort_index_v2626.prewarm_async(_sort_sections_copy_v2696, reason="home_idle_deferred_v2696")
                                _log("SORT_INDEX_HOME_PREWARM_START_V2696 sections=%d delay_ms>=8000 foreground_wait=0" % len(_sort_sections_copy_v2696))
                            except Exception:
                                _log("SORT_INDEX_HOME_PREWARM_DEFER_FAILED_V2696 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                        if self._is_android_v2591():
                            _log("SORT_INDEX_HOME_PREWARM_SUPPRESSED_U3 sections=%d reason=android_input_first_manual_sort_fallback" % len(_sort_sections_v2626))
                        else:
                            _PKMHomeThreadV2151(target=_deferred_sort_prewarm_v2696, name="PKMSortHomeIdleV2696", daemon=True).start()
                            _log("SORT_INDEX_HOME_PREWARM_DEFER_V2696 sections=%d delay_ms=8000 input_priority=1" % len(_sort_sections_v2626))
                    except Exception:
                        _log("SORT_INDEX_HOME_PREWARM_FAILED_V2626 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                    elapsed = int(time.time() * 1000) - started
                    stable_ms = max(0, int(time.time() * 1000) - ready_since) if ready_since else 0
                    self._presentation_fp_prewarm_r23(delay_ms=1200, reason="home_release")
                    _log("STARTUP_ATOMIC_GATE_RELEASE_V1619 reason=%s token=%s ready=%d total=%d wait_ms=%d stable_ms=%d timeout=%d timeout_reason=%s whole_scene=1 plex_snapshot=local_prepared all_sidebar=prepared_snapshot_v2492 texture_prewarm=%d v1841=1" % (
                        reason or "", token, ready, total, elapsed, stable_ms,
                        1 if timed_out else 0, timeout_reason_v1841 or "-",
                        1 if getattr(self, "_startup_texture_prewarm_done_v2492", False) else 0
                    ))
                    self._startup_acceptance_log_v2494r3(
                        result="AUTO", stage="home_release", reason="",
                        wait_ms=(_startup_elapsed_before_clear_v2494r3 if _startup_elapsed_before_clear_v2494r3 >= 0 else elapsed),
                        slow_seen_override=_slow_seen_before_clear_v2494r3,
                        slow_text_override=_slow_text_before_clear_v2494r3,
                        texture_ready=ready, texture_total=total, final=1
                    )
                except Exception:
                    _log("STARTUP_ATOMIC_GATE_RELEASE_FAILED_V1619 reason=%s err=%s" % (
                        reason or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                    self._startup_acceptance_log_v2494r3(
                        result="FAIL", stage="atomic_release_exception",
                        reason="atomic_release_exception", wait_ms=int(time.time() * 1000) - started, final=1
                    )
                finally:
                    self._startup_gate_release_running_v1619 = False

            _PKMHomeThreadV2151(target=_worker, name="PlexKMStartupAtomicRevealV1619", daemon=True).start()
        except Exception:
            self._startup_gate_release_running_v1619 = False
            _log("STARTUP_ATOMIC_GATE_SCHEDULE_FAILED_V1619 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            self._startup_acceptance_log_v2494r3(
                result="FAIL", stage="atomic_release_schedule",
                reason="atomic_release_schedule_exception", wait_ms=-1, final=1
            )

    def _r124_wait_native_cover_final(self, cancelled, reason):
        """Keep the completed native frame visible through the GUI handoff.

        R125 service guarantees the full native animation pass before WindowXML
        opens; therefore an additional onInit timer is redundant. The splash
        still stays up until actual Home composition and texture checks pass.
        """
        start = float(getattr(self, '_r121_native_logo_start', 0.0) or 0.0)
        if not start:
            _log('R124_NATIVE_GATE_MISSING_START reason=%s action=hold' % reason, xbmc.LOGERROR)
            return False
        while time.monotonic() - start < 0.0:
            if cancelled():
                return False
            if self._closing_event_v1841.wait(0.025):
                return False
        win = xbmcgui.Window(10000)
        win.setProperty('PlexKM.Startup.NativeFinalHoldR124', '1')
        _log('R124_FINAL_FRAME_HOLD reason=%s elapsed_ms=%d' % (
            reason, int((time.monotonic()-start)*1000)))
        if self._closing_event_v1841.wait(0.03):
            return False
        if cancelled():
            return False
        return True

    def _force_startup_gate_release_v1619(self, reason=""):
        """Route non-widget startup surfaces through the same verified reveal gate."""
        try:
            release_reason = str(reason or "")
            menu = self.getControl(9000)
            menu_size = int(menu.size()) if menu is not None else 0
            menu_visible = bool(menu.isVisible()) if menu is not None else False
            if menu_size <= 0 or not menu_visible:
                _log("STARTUP_NONWIDGET_SURFACE_NOT_READY_V2052 reason=%s menu_size=%d visible=%d action=keep_splash" % (
                    release_reason, menu_size, 1 if menu_visible else 0
                ), xbmc.LOGERROR)
                return

            # v2558: first-run/settings-required is already the complete target
            # scene. sections=0 must never enter V2492 snapshot/texture readiness.
            win_v2558 = xbmcgui.Window(10000)
            initial_surface_v2558 = bool(
                win_v2558.getProperty("PlexKM.StartupSettingsIncomplete") == "1"
                or win_v2558.getProperty("PlexKM.Home.SettingsRequired") == "1"
                or release_reason.startswith("startup_empty_home_ready_v1975_")
            )
            if initial_surface_v2558:
                win_v2558.setProperty("PlexKM.Startup.InitialSurfaceV2558", "1")
                self._startup_prepare_required_v2477 = False
                self._startup_native_prebuild_done_v2492 = True
                self._startup_texture_prewarm_done_v2492 = True

                # The initial PKM surface itself is complete now. Do NOT enter
                # section snapshot/texture readiness when sections=0.
                self._startup_scene_composed_event_v1841.set()
                for target_v2558 in (self, win_v2558):
                    try:
                        target_v2558.setProperty("PlexKM.Home.FullSceneComposedV1643", "1")
                        target_v2558.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                    except Exception:
                        pass

                # Clear only real-work/slow-notice state. The splash and startup
                # gate intentionally remain until the yellow logo reaches frame 119.
                for key_v2558 in (
                    "PlexKM.Startup.SlowGuardTokenV2365",
                    "PlexKM.Startup.SlowVisibleV2365",
                    "PlexKM.Startup.SlowTextV2365",
                    "PlexKM.Startup.SlowPhaseV2365",
                    "PlexKM.Startup.SlowArmAtMsV2493",
                    "PlexKM.Startup.PrepareTextV2492",
                    "PlexKM.Startup.PreparePhaseV2492",
                    "PlexKM.Startup.ProblemActiveV2535",
                    "PlexKM.Startup.ProblemTextV2535",
                ):
                    try:
                        win_v2558.clearProperty(key_v2558)
                    except Exception:
                        pass

                # Avoid duplicate finalizers if the settings-required route asks
                # for release again while the logo is finishing.
                if win_v2558.getProperty("PlexKM.Startup.InitialFinalizingV2558R3") == "1":
                    _log("STARTUP_INITIAL_LOGO_FINALIZER_REUSE_V2558R3 action=keep_current_tail")
                    return

                win_v2558.setProperty("PlexKM.Startup.InitialFinalizingV2558R3", "1")
                win_v2558.setProperty("PlexKM.Startup.FinalVisualTailV2516", "1")
                win_v2558.setProperty("PlexKM.Startup.FinalVisualTailArmMsV2516", str(int(time.time() * 1000)))
                self._startup_gate_release_running_v1619 = True

                # Fresh-install initial surface is a verified visual-ready state.
                # Use a dedicated exact-allowlist reason so 100 is not clamped to 99.
                try:
                    _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.clear()
                    win_v2558.clearProperty("PlexKM.Startup.FinalFrameReadyV2378R8")
                except Exception:
                    pass
                _startup_progress_v1845(
                    100,
                    reason="startup_visual_ready_verified_v2558r3_initial_fast",
                    force=True,
                )
                _log(
                    "STARTUP_INITIAL_LOGO_FINAL_FILL_ARM_V2558R3 "
                    "display=%s target=100 sections=0 scene_ready=1 splash_hold=1"
                    % (win_v2558.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0")
                )

                def _finish_initial_surface_logo_v2558r3():
                    forced_final_v2558r3 = False
                    try:
                        # Normal path: the existing 120-frame worker traverses the
                        # remaining yellow frames with V2516 fast-final cadence.
                        deadline_v2558r3 = time.time() + 6.0  # allow four-second linear logo to finish
                        while not self._closing_event_v1841.is_set():
                            if _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.wait(0.01):
                                if (not win_v2558.getProperty('PlexKM.Startup.LinearLogoToken')
                                    or (win_v2558.getProperty('PlexKM.Startup.LinearLogoCompleteR80') == '1'
                                        and win_v2558.getProperty('PlexKM.Startup.DisplayFrameV1904') == '239')):
                                    break
                            if (time.time() >= deadline_v2558r3
                                    and not win_v2558.getProperty('PlexKM.Startup.LinearLogoToken')):
                                # Fail-safe: never leave first install stuck behind
                                # the splash. Publish frame 119 explicitly, still
                                # hold it visibly, then reveal.
                                forced_final_v2558r3 = True
                                _startup_progress_publish_display_v1891(
                                    100.0,
                                    reason="startup_visual_ready_verified_v2558r3_initial_fast_forced",
                                )
                                break

                        if self._closing_event_v1841.is_set():
                            return

                        try:
                            _linear_started = float(win_v2558.getProperty('PlexKM.Startup.LinearLogoStart') or '0')
                            while _linear_started > 0 and time.monotonic() - _linear_started < 4.0:
                                if self._closing_event_v1841.wait(0.025):
                                    return
                        except (TypeError, ValueError):
                            pass
                        # R124: initial/settings Home uses the identical cover gate.
                        if not self._r124_wait_native_cover_final(
                                lambda: self._closing_event_v1841.is_set(),
                                'initial_settings'):
                            return
                        # Same visual contract as V2516: frame 119 must actually
                        # be visible for two+ render intervals before cover removal.
                        final_hold_ms_v2558r3 = 40
                        if self._closing_event_v1841.wait(final_hold_ms_v2558r3 / 1000.0):
                            return

                        _log(
                            "STARTUP_INITIAL_LOGO_FINAL_FRAME_VISIBLE_HOLD_V2558R3 "
                            "display=%s hold_ms=%d final_frame=239 forced=%d"
                            % (
                                win_v2558.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0",
                                final_hold_ms_v2558r3,
                                1 if forced_final_v2558r3 else 0,
                            )
                        )

                        for target_v2558r3 in (self, win_v2558):
                            try:
                                target_v2558r3.setProperty("PlexKM.Home.FullSceneComposedV1643", "1")
                                target_v2558r3.setProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643", "1")
                                target_v2558r3.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                                target_v2558r3.clearProperty("PlexKM.Home.StartupGateV1619")
                                target_v2558r3.clearProperty("PlexKM.SkinStartupSplash")
                            except Exception:
                                pass

                        win_v2558.clearProperty("PlexKM.Startup.FinalVisualTailV2516")
                        win_v2558.clearProperty("PlexKM.Startup.FinalVisualTailArmMsV2516")
                        win_v2558.clearProperty("PlexKM.Startup.InitialFinalizingV2558R3")
                        self._startup_ready_event_v1841.set()
                        self._startup_gate_release_running_v1619 = False

                        _log(
                            "STARTUP_INITIAL_SURFACE_RELEASE_CONFIRMED_V2558R3 "
                            "settings_required=1 sections=0 startup_ready=1 "
                            "logo_progress=100 final_frame=239 full_yellow_visible=1"
                        )
                    except Exception:
                        self._startup_gate_release_running_v1619 = False
                        try:
                            win_v2558.clearProperty("PlexKM.Startup.InitialFinalizingV2558R3")
                        except Exception:
                            pass
                        _log(
                            "STARTUP_INITIAL_LOGO_FINALIZER_FAILED_V2558R3 err=%s"
                            % traceback.format_exc().replace(chr(10), " | "),
                            xbmc.LOGWARNING,
                        )

                _PKMHomeThreadV2151(
                    target=_finish_initial_surface_logo_v2558r3,
                    name="PKMInitialLogoFinalFillV2558R3",
                    daemon=True,
                ).start()

                _log(
                    "STARTUP_INITIAL_SURFACE_DIRECT_RELEASE_V2558 "
                    "reason=%s menu_size=%d sections=0 snapshot_wait=0 "
                    "texture_wait=0 slow_text=0 visual_tail=v2558r3"
                    % (release_reason, menu_size)
                )
                return
            self._mark_startup_full_scene_composed_v1643(reason="nonwidget_visual_ready_v2052_%s" % release_reason)
            _log("STARTUP_NONWIDGET_SURFACE_VERIFIED_V2052 reason=%s menu_size=%d visible=1 action=normal_gate" % (
                release_reason, menu_size
            ))
            self._schedule_startup_atomic_release_v1619(reason="nonwidget_visual_ready_v2052_%s" % release_reason)
        except Exception:
            self._startup_gate_release_running_v1619 = False
            _log("STARTUP_NONWIDGET_SURFACE_VERIFY_FAILED_V2052 reason=%s err=%s" % (
                str(reason or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _section_scene_snapshot_safe_v1620(self, snapshot):
        """Keep only immutable hero values for fast sidebar re-entry."""
        if not isinstance(snapshot, dict):
            return None
        try:
            return {
                "props": dict(snapshot.get("props") or {}),
                "fanart": str(snapshot.get("fanart") or ""),
                "hero_title": str(snapshot.get("hero_title") or ""),
                "li": None,
                "rating_verified_exact": bool(snapshot.get("rating_verified_exact")),
            }
        except Exception:
            return None

    def _persistent_authority_quick_signature_v2473(self, dbp):
        """V2487 cheap *content-only* revalidation key.

        DB mtime/size and rating tables are intentionally excluded. Cine21/Watcha
        rematches and item_ratings writes may touch plex_km.db without changing
        the Plex library. Those writes must not force a content fingerprint scan
        or make startup claim that the library changed.
        """
        try:
            payload = []
            conn = sqlite3.connect(dbp, timeout=1.5)
            try:
                try:
                    rows = conn.execute(
                        "SELECT section_id,item_count,people_count,genre_count,country_count "
                        "FROM item_recommend_index_state ORDER BY section_id"
                    ).fetchall()
                    for row in rows or []:
                        payload.append("idx=" + ":".join(str(v or "") for v in row))
                except Exception:
                    pass
                try:
                    rows = self._items_section_stats_fast_r115(conn)
                    for row in rows or []:
                        payload.append("items=" + ":".join(str(v or "") for v in row))
                except Exception:
                    pass
            finally:
                conn.close()
            quick = hashlib.sha1("\n".join(payload).encode("utf-8", "replace")).hexdigest() if payload else ""
            if quick:
                _log("PERSISTENT_CONTENT_QUICK_SIG_V2487 sig=%s db_mtime=0 db_size=0 ratings=0" % quick[:12])
            return quick
        except Exception:
            return ""

    def _persistent_authority_stamp_load_v2473(self):
        try:
            path = self._derived_cache_path_v2467("authority_stamp_v2487_content.json")
            if not path or not os.path.exists(path):
                return {}
            with open(path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if not isinstance(obj, dict) or int(obj.get("version") or 0) != 2487:
                return {}
            return obj
        except Exception:
            return {}

    def _persistent_authority_stamp_store_v2473(self, quick_sig, db_fp):
        try:
            if not quick_sig or not db_fp:
                return False
            path = self._derived_cache_path_v2467("authority_stamp_v2487_content.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"version":2487,"model":"content_v2487","quick_sig":quick_sig,"db_fp":db_fp,"ts":time.time()}, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            return True
        except Exception:
            return False

    def _render_snapshot_props_v2473(self):
        return (
            "RatingKey","SectionId","Type","KodiType","Title","OriginalTitle","SortTitle","Year","Summary","Duration",
            "AddedAt","UpdatedAt","Thumb","EpisodeThumb","Art","PartKey","ViewCount","IsWatched","Genre","ContentRating",
            "Rating","Cine21CriticRating","Cine21AudienceRating","WatchaRating","WatchaCount","WatchaDisplay","ShowTitle","Season",
            "Episode","ParentRatingKey","GrandparentRatingKey","ViewOffset","ResumeDurationMs","ResumeUpdatedAt","ResumeSource",
            "ResumePercent","ResumeProgressComposite350x10","ResumeProgressComposite370x10","PosterFallbackArt","PosterFallbackArtActive",
            "PosterFallbackChecked","PosterFallbackRoleV2498","PosterAuthorityV2498","PosterLocalSourceV2498","WallPosterRemoteV1644","WallPosterDisplayV1644","IsSeasonFolderV1870","SeasonFolderLabel","PlayUrl",
            "ShowUrl","OpenEpisodeInfo","WallTitleLine1","WallTitleFull","WallYearLine","WallSortLine","WallMetaLine","Is4K",
            "HomeRowTitle","HomeLayout","HomeRowId","HomeRowStart","HomeRowIndex","DebugGlobalPos","HomeRowFirst","HomeRowType",
            "ActorWorkPosterSourceV2130","ActorWorkPosterCanonicalFallbackV2130"
        )

    def _render_snapshot_from_li_v2473(self, li):
        try:
            if not li:
                return None
            props = {}
            for key in self._render_snapshot_props_v2473():
                try:
                    value = str(li.getProperty("PlexKM.%s" % key) or "")
                    if value:
                        props[key] = value
                except Exception:
                    pass
            art = {}
            for key in ("poster", "thumb", "icon", "fanart"):
                try:
                    value = str(li.getArt(key) or "")
                    if value:
                        art[key] = value
                except Exception:
                    pass
            try:
                label = str(li.getLabel() or "")
            except Exception:
                label = str(props.get("Title") or "")
            return {"label":label,"props":props,"art":art}
        except Exception:
            return None

    def _render_snapshot_from_row_v2476(self, row, row_title="", row_type="", row_first=False, row_id="", row_start=-1, row_index=-1):
        """Compute the exact persisted display snapshot without a Kodi ListItem."""
        try:
            proxy = self._li_from_row(
                row, row_title=row_title, row_type=row_type, row_first=row_first,
                row_id=row_id, row_start=row_start, row_index=row_index,
                _snapshot_only_v2476=True,
            )
            return self._render_snapshot_from_li_v2473(proxy) if proxy else None
        except Exception:
            return None

    def _section_render_snapshots_from_rows_v2476(self, rows_cache):
        try:
            rows = list(rows_cache or [])
            if not rows:
                return []
            snaps = []
            group_start = 0
            current_id = None
            row_index = 0
            for entry in rows:
                if not isinstance(entry, dict):
                    return []
                rid = str(entry.get("row_id") or entry.get("row_title") or "row")
                if current_id is None or rid != current_id:
                    current_id = rid
                    group_start = len(snaps)
                    row_index = 0
                snap = self._render_snapshot_from_row_v2476(
                    entry.get("row"),
                    row_title=_display_library_title(entry.get("row_title", "")),
                    row_type=entry.get("row_type", ""),
                    row_first=(row_index == 0),
                    row_id=entry.get("row_id", ""),
                    row_start=group_start, row_index=row_index,
                )
                if not snap:
                    return []
                snaps.append(snap)
                row_index += 1
            return snaps if len(snaps) == len(rows) else []
        except Exception:
            return []

    def _library_render_snapshots_from_rows_v2476(self, rows_cache):
        try:
            rows = list(rows_cache or [])
            snaps = []
            for entry in rows:
                raw = entry.get("row") if isinstance(entry, dict) else entry
                snap = self._render_snapshot_from_row_v2476(raw)
                if not snap:
                    return []
                snaps.append(snap)
            return snaps if len(snaps) == len(rows) else []
        except Exception:
            return []

    def _ensure_recommend_persistent_snapshot_v2476(self, cache_key, title, rows_cache, reason=""):
        key = str(cache_key or "")
        rows = list(rows_cache or [])
        if not key.startswith("recommend:") or not rows:
            return False
        try:
            existing = list(getattr(self, "_section_render_snapshots_v2473", {}).get(key) or [])
            if len(existing) == len(rows):
                return True
            snaps = self._section_render_snapshots_from_rows_v2476(rows)
            if len(snaps) != len(rows):
                _log("SECTION_AUTO_SNAPSHOT_FAILED_V2476 key=%s rows=%d reason=%s" % (key, len(rows), reason or ""), xbmc.LOGWARNING)
                return False
            scene = (getattr(self, "_section_scene_cache_v1620", {}) or {}).get(key) or {}
            rec = (self._section_persistent_cache_load_v2467() or {}).get(key) or {}
            meta = (scene.get("meta") if isinstance(scene, dict) else None) or (rec.get("meta") if isinstance(rec, dict) else None) or {"props":{},"fanart":"","hero_title":"","rating_verified_exact":False}
            count_text = (scene.get("count") if isinstance(scene, dict) else "") or (rec.get("count") if isinstance(rec, dict) else "") or "추천"
            self._section_render_snapshots_v2473[key] = list(snaps)
            ok = self._section_persistent_scene_store_v2467(
                key, title, count_text, rows, meta, render_snapshots_v2473=snaps
            )
            if ok:
                _log("SECTION_AUTO_SNAPSHOT_STORE_V2476 key=%s rows=%d native_listitems=0 manual_visit=0 reason=%s" % (key, len(rows), reason or ""))
            return bool(ok)
        except Exception:
            _log("SECTION_AUTO_SNAPSHOT_FAILED_V2476 key=%s reason=%s err=%s" % (key, reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _rearm_auto_persistent_snapshots_v2476(self, reason=""):
        """Re-run auto snapshot workers after a real authority/section invalidation."""
        try:
            # v2487: a real dirty/content invalidation retires only the cached
            # process-local fingerprints. The next resolver recomputes content
            # from synchronized local DB and presentation independently.
            self._persistent_authority_db_fp_v2468 = ""
            self._persistent_plex_items_fp_v2487 = ""
            self._persistent_section_authority_map_v2489 = None
            self._persistent_section_items_stats_v2489 = None
            self._persistent_presentation_fp_v2487 = ""
            _log("PERSISTENT_AUTHORITY_RUNTIME_INVALIDATE_V2487 reason=%s content=1 presentation=1" % (reason or ""))
            _log("PERSISTENT_SECTION_AUTHORITY_RUNTIME_INVALIDATE_V2489 reason=%s section_map=cleared" % (reason or ""))
            self._post_reveal_all_sections_prewarm_done_v1649 = False
            self._post_reveal_library_data_warm_done_v2472 = False
            self._auto_snapshot_done_v2476 = False
            # v2490: section/library invalidation is not a new installation.
            # Keep the last completed authority baseline so the next launch can
            # identify exactly which section changed.  Deleting this state made
            # V2489 mislabel an ordinary restart as first_bootstrap and destroyed
            # the selective-rebuild proof.
            _log("STARTUP_PREPARED_STATE_PRESERVE_V2490 reason=%s first_bootstrap_marker_unchanged=1 authority_baseline_unchanged=1" % (reason or ""))
            ready = xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") == "1"
            _log("AUTO_SNAPSHOT_REARM_V2476 reason=%s home_ready=%d" % (reason or "", 1 if ready else 0))
            if ready:
                # V2570: never launch speculative full-section/library snapshot repair
                # on a visible Home.  Keep the entry invalid; the requested destination
                # can use its normal foreground local-DB path, and the next startup will
                # rebuild it under the opaque cover.
                _log("UHD3_HOME_QUIET_RUNTIME_REARM_SUPPRESSED_V2570 reason=%s action=next_start_or_foreground_local" % (reason or ""))
            return True
        except Exception:
            return False

    def _startup_prepare_state_load_v2477(self):
        try:
            path = self._derived_cache_path_v2467("startup_prepared_state_v2477.json")
            if not path or not os.path.exists(path):
                return {}
            with open(path, "r", encoding="utf-8") as fh:
                obj = json.load(fh)
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}

    def _startup_prepare_selected_signature_v2477(self):
        try:
            ids = []
            for sec in list(getattr(self, "sections", []) or []):
                if not isinstance(sec, dict):
                    continue
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                if sid:
                    ids.append(sid)
            return hashlib.sha1("|".join(ids).encode("utf-8", "replace")).hexdigest(), ids
        except Exception:
            return "", []

    def _startup_prepare_state_store_v2477(self, authority_fp, rec_ready, lib_ready, section_ids):
        try:
            sig, _ids = self._startup_prepare_selected_signature_v2477()
            path = self._derived_cache_path_v2467("startup_prepared_state_v2477.json")
            tmp = path + ".tmp"
            section_fp_v2489, section_stats_v2489 = self._persistent_section_authority_state_v2489()
            selected_ids_v2489 = [str(x or "").strip() for x in list(section_ids or _ids) if str(x or "").strip()]
            payload = {
                "version": 2477,
                "authority_model": "content_section_v2489",
                "authority_fp": str(authority_fp or self._persistent_selected_section_authority_combined_v2489(selected_ids_v2489) or ""),
                "section_authority_v2489": {sid:str((section_fp_v2489 or {}).get(sid) or "") for sid in selected_ids_v2489},
                "section_items_stats_v2489": {sid:dict((section_stats_v2489 or {}).get(sid) or {}) for sid in selected_ids_v2489},
                "plex_items_fp_v2487": str(self._persistent_plex_items_fingerprint_v2487() or ""),
                "presentation_fp_v2487": str(self._persistent_presentation_fingerprint_v2487() or ""),
                "selected_sig": str(sig or ""),
                "section_ids": list(section_ids or _ids),
                "recommend_ready": int(rec_ready or 0),
                "library_ready": int(lib_ready or 0),
                "completed": True,
                "ts": time.time(),
            }
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            return True
        except Exception:
            return False

    def _startup_snapshot_bootstrap_marker_load_v2490(self):
        """Durable proof that the one expensive all-section snapshot bootstrap ran.

        Unlike startup_prepared_state_v2477.json this marker is never invalidated
        by ordinary content/section changes.  It is installation/profile lifecycle
        state, not a cache-authority stamp.
        """
        try:
            path = self._derived_cache_path_v2467("snapshot_bootstrap_complete_v2490.json")
            if not path or not os.path.exists(path):
                return {}
            with open(path, "r", encoding="utf-8") as fh:
                obj = json.load(fh)
            return obj if isinstance(obj, dict) and bool(obj.get("completed")) else {}
        except Exception:
            return {}

    def _startup_snapshot_bootstrap_marker_store_v2490(self, reason=""):
        try:
            path = self._derived_cache_path_v2467("snapshot_bootstrap_complete_v2490.json")
            if not path:
                return False
            tmp = path + ".tmp"
            sig, ids = self._startup_prepare_selected_signature_v2477()
            payload = {
                "version": 2490,
                "completed": True,
                "selected_sig_at_completion": str(sig or ""),
                "section_count_at_completion": len(list(ids or [])),
                "ts": time.time(),
                "reason": str(reason or ""),
            }
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            _log("STARTUP_SNAPSHOT_BOOTSTRAP_MARK_V2490 completed=1 sections=%d reason=%s" % (
                len(list(ids or [])), reason or ""
            ))
            return True
        except Exception:
            _log("STARTUP_SNAPSHOT_BOOTSTRAP_MARK_FAILED_V2490 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    # PKM_CUMULATIVE_CORRECTED_GATE_AND_MARKER
    def _startup_initial_prepare_verified_cumulative(self):
        """Trust only a completed proof for the CURRENT selected sections.

        Do not interpret a boolean left by a previous install/selection as
        proof that current first-viewports, native banks and textures exist.
        Unknown/empty section identity is never success.
        """
        try:
            current_sig, current_ids = self._startup_prepare_selected_signature_v2477()
            current_ids = [str(s or '').strip() for s in current_ids if str(s or '').strip()]
            if not current_sig or not current_ids or len(set(current_ids)) != len(current_ids):
                return False
            path = self._derived_cache_path_v2467('initial_preparation_verified.json')
            with open(path, 'r', encoding='utf-8') as fh:
                value = json.load(fh)
            valid = bool(
                isinstance(value, dict)
                and value.get('completed') is True
                and str(value.get('selected_sig') or '') == current_sig
                and int(value.get('section_count') or 0) == len(current_ids)
                and value.get('proof_scope') == 'native_destinations_textures_all_rows_plex_portraits_local_bind_r66'
                and value.get('actor_photos_verified') is True
                and int(value.get('actor_photo_failed', -1)) == 0
                and int(value.get('actor_widget_rows', -1)) == int(value.get('actor_expected_rows', -2))
                and int(value.get('actor_local_bound', -1)) == int(value.get('actor_binding_expected', -2))
            )
            if not valid:
                _log('INITIAL_PREPARATION_PROOF_REJECTED reason=section_identity_mismatch current_sections=%d' % len(current_ids))
            elif not getattr(self, '_pkm_postlog_initial_proof_logged', False):
                self._pkm_postlog_initial_proof_logged = True
                _log('INITIAL_PREPARATION_PROOF_REUSED selected=%d rebootstrap=0' % len(current_ids))
            return valid
        except Exception:
            return False

    def _startup_initial_prepare_mark_cumulative(self, reason=''):
        # Called only after complete snapshots, native GUI and textures.
        try:
            path = self._derived_cache_path_v2467('initial_preparation_verified.json')
            tmp = path + '.tmp'
            sig, ids = self._startup_prepare_selected_signature_v2477()
            # R65: never issue a success marker for missing/failed portrait downloads.
            cast_stats = getattr(self, '_startup_actor_portraits_stats_r63', {}) or {}
            portrait_ok = bool(cast_stats.get('coverage_ok') and int(cast_stats.get('failed', -1)) == 0)
            if not portrait_ok or not sig or not ids:
                _log('R65_PROOF_HELD portraits_ok=%d rows=%s expected=%s failed=%s' % (
                    1 if portrait_ok else 0, cast_stats.get('widget_rows'),
                    cast_stats.get('expected_rows'), cast_stats.get('failed')), xbmc.LOGWARNING)
                return False
            payload = {'completed': True, 'selected_sig': sig,
                       'section_count': len(ids), 'reason': str(reason or ''),
                       'proof_scope': 'native_destinations_textures_all_rows_plex_portraits_local_bind_r66',
                       'actor_photos_verified': True,
                       'actor_photo_failed': int(cast_stats.get('failed') or 0),
                       'actor_widget_rows': int(cast_stats.get('widget_rows') or 0),
                       'actor_expected_rows': int(cast_stats.get('expected_rows') or 0),
                       'actor_profiles_verified': False,
                       'actor_local_bound': int(cast_stats.get('local_bound') or 0),
                       'actor_binding_expected': int(cast_stats.get('binding_expected') or 0),
                       'ts': time.time()}
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
            os.replace(tmp, path)
            return True
        except Exception:
            _log('INITIAL_PREPARATION_VERIFIED_MARK_FAILED err=%s' % (
                traceback.format_exc().replace(chr(10), ' | ')), xbmc.LOGERROR)
            return False

    def _startup_snapshot_bootstrap_done_v2490(self, state=None, complete_now=False):
        return bool(self._startup_initial_prepare_verified_cumulative())

    def _startup_force_slow_notice_if_due_v2494(self, text="", phase=""):
        """V2535 delayed startup notice whitelist.

        At 3 seconds only genuine new-content addition or PKM update text is
        allowed.  All other maintenance/rebuild/poster/presentation reasons stay
        silent.  At 6 seconds, any still-blocked established startup becomes an
        explicit problem state instead of inventing a library-change explanation.
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                return False
            if (win.getProperty("PlexKM.StartupSettingsIncomplete") == "1"
                    or win.getProperty("PlexKM.Startup.InitialSurfaceV2558") == "1"
                    or win.getProperty("PlexKM.Home.SettingsRequired") == "1"):
                _log("STARTUP_NOTICE_SUPPRESS_V2558 reason=initial_setup_surface owner=home")
                return False
            if win.getProperty("PlexKM.Startup.FinalVisualTailV2516") == "1":
                return False

            raw_arm = str(win.getProperty("PlexKM.Startup.SlowArmAtMsV2493") or "").strip()
            try:
                arm_ms = int(float(raw_arm)) if raw_arm else 0
            except Exception:
                arm_ms = 0
            gate_ms = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
            starts = [x for x in (arm_ms, gate_ms) if int(x or 0) > 0]
            if not starts:
                return False
            started_ms = min(starts)
            now_ms = int(time.time() * 1000.0)
            elapsed_ms = max(0, now_ms - started_ms)
            if elapsed_ms < 12000:
                return False

            update_text = str(win.getProperty("PlexKM.Startup.UpdateTextV2375") or "").strip()
            new_content = bool(win.getProperty("PlexKM.Startup.NewContentAddedV2535") == "1")
            problem_active = bool(win.getProperty("PlexKM.Startup.ProblemActiveV2535") == "1")
            passed_text = str(text or "").strip()
            passed_phase = str(phase or "").strip()
            explicit_problem = bool(
                problem_active
                or "완료하지 못" in passed_text
                or "오류" in passed_text
                or any(tag in passed_phase.lower() for tag in ("error", "fail", "fatal", "problem"))
            )
            # V2665: elapsed time alone is not a user-facing error.  Normal startup
            # stays logo-only even when a slow device takes >6 s.  Keep notices only
            # for explicit errors/failures, PKM update text, or genuine new content.
            problem_text = str(win.getProperty("PlexKM.Startup.ProblemTextV2535") or "").strip()

            # R137: timed status messages are informational, not proof of a
            # library change. Explicit failure/update notices still win.
            r137_stages = (
                (60, "코디를 종료합니다"),
                (55, "코디를 5초 뒤에 종료할게요. 다시 실행해 주세요"),
                (52, "아무래도 코디를 곧 종료해야 할 것 같습니다"),
                (47, "조금만 더 기다려 주세요"),
                (42, "아직 시작 준비가 끝나지 않았습니다"),
                (37, "슬슬 기다리기 지루하시지요?"),
                (32, "생각보다 더 길어지고 있습니다"),
                (27, "조금만 더 기다려 주세요"),
                (22, "시작 위젯을 준비하고 있어요"),
                (17, "시작 준비가 예상보다 오래 걸리고 있습니다"),
                (12, "시작이 좀 길어지고 있습니다"),
            )
            r137_stage = next(((sec, label) for sec, label in r137_stages
                               if elapsed_ms >= sec * 1000), (12, "시작이 좀 길어지고 있습니다"))
            if explicit_problem and elapsed_ms < 12000:
                msg = problem_text or passed_text or "시작 준비가 예상보다 오래 걸리고 있습니다"
                resolved_phase = "problem_v2535"
            elif update_text:
                msg = update_text
                resolved_phase = "pkm_update"
            elif new_content and elapsed_ms < 12000:
                msg = "새 콘텐츠를 반영 중입니다"
                resolved_phase = "new_content_v2535"
            else:
                msg = r137_stage[1]
                resolved_phase = "r137_elapsed_%ds" % r137_stage[0]

            already_visible = win.getProperty("PlexKM.Startup.SlowVisibleV2365") == "1"
            old_msg = str(win.getProperty("PlexKM.Startup.SlowTextV2365") or "").strip()
            old_phase = str(win.getProperty("PlexKM.Startup.SlowPhaseV2365") or "").strip()
            win.setProperty("PlexKM.Startup.SlowVisibleV2365", "1")
            win.setProperty("PlexKM.Startup.SlowTextV2365", msg)
            win.setProperty("PlexKM.Startup.SlowPhaseV2365", resolved_phase)
            try:
                xbmc.executebuiltin("SetProperty(PlexKM.Startup.SlowVisibleV2365,1,home)")
                xbmc.executebuiltin("SetProperty(PlexKM.Startup.SlowTextV2365,%s,home)" % msg.replace(",", " "))
                xbmc.executebuiltin("SetProperty(PlexKM.Startup.SlowPhaseV2365,%s,home)" % resolved_phase.replace(",", " "))
            except Exception:
                pass
            if already_visible:
                if old_msg != msg or old_phase != resolved_phase:
                    _log("STARTUP_SLOW_NOTICE_PHASE_UPDATE_V2535 from_phase=%s to_phase=%s from_text=%s to_text=%s elapsed_ms=%d" % (
                        old_phase or "-", resolved_phase, _short_log_value(old_msg or "-", 80), _short_log_value(msg, 80), elapsed_ms
                    ))
            else:
                _log("STARTUP_SLOW_NOTICE_SHOW_V2535 threshold_ms=%d elapsed_ms=%d phase=%s text=%s" % (
                    12000, elapsed_ms, resolved_phase, msg
                ), xbmc.LOGWARNING if resolved_phase == "problem_v2535" else xbmc.LOGINFO)
            return True
        except Exception:
            _log("STARTUP_SLOW_NOTICE_FAILED_V2535 owner=home_whitelist err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _startup_acceptance_log_v2494r3(self, result="AUTO", stage="", reason="", wait_ms=-1, slow_seen_override=-1, slow_text_override="", texture_ready=-1, texture_total=-1, final=1):
        """Emit one machine-readable PASS/FAIL line for startup acceptance.

        This is diagnostics only. It does not mutate startup readiness, snapshots,
        A/B visibility, spinner ownership, or Home release policy.
        """
        try:
            win = xbmcgui.Window(10000)
            try:
                sections, rec_ready, lib_ready, _nonempty = self._startup_prepare_readiness_v2477()
            except Exception:
                sections = len(list(getattr(self, "sections", []) or []))
                rec_ready = lib_ready = -1
            native_ready = 1 if bool(getattr(self, "_startup_native_prebuild_done_v2492", False)) else 0
            texture_prewarm = 1 if bool(getattr(self, "_startup_texture_prewarm_done_v2492", False)) else 0
            full_scene = 1 if win.getProperty("PlexKM.Home.FullSceneComposedV1643") == "1" else 0
            home_ready = 1 if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1" else 0
            if int(slow_seen_override) >= 0:
                slow_seen = 1 if int(slow_seen_override) else 0
            else:
                slow_seen = 1 if win.getProperty("PlexKM.Startup.SlowVisibleV2365") == "1" else 0
            slow_text = str(slow_text_override or win.getProperty("PlexKM.Startup.SlowTextV2365") or "").strip()
            gate_started_v2495 = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
            total_elapsed_v2495 = (max(0, int(time.time() * 1000) - gate_started_v2495) if gate_started_v2495 > 0 else -1)
            if total_elapsed_v2495 >= 0:
                wait_ms = max(int(wait_ms), int(total_elapsed_v2495)) if int(wait_ms) >= 0 else int(total_elapsed_v2495)
            current_home_only_v2535 = bool(getattr(self, "_startup_established_current_home_only_v2535", False))
            new_content_notice_v2535 = bool(win.getProperty("PlexKM.Startup.NewContentAddedV2535") == "1" or getattr(self, "_startup_new_content_sections_v2535", set()))
            update_notice_v2535 = bool(str(win.getProperty("PlexKM.Startup.UpdateTextV2375") or "").strip())
            slow_required = (
                1 if int(wait_ms) >= 6000
                else (1 if int(wait_ms) >= 3000 and (new_content_notice_v2535 or update_notice_v2535) else (0 if int(wait_ms) >= 0 else -1))
            )
            changed = sorted(str(x) for x in (getattr(self, "_startup_changed_section_ids_v2489", set()) or set()))
            item_changed = sorted(str(x) for x in (getattr(self, "_startup_items_changed_section_ids_v2489", set()) or set()))
            cause = str(getattr(self, "_startup_prepare_cause_v2487", "") or "unknown")
            result_u = str(result or "AUTO").upper()
            auto_reason = []
            if result_u == "AUTO":
                ok = True
                if not current_home_only_v2535:
                    if sections <= 0 or rec_ready != sections or lib_ready != sections:
                        ok = False
                        auto_reason.append("snapshot_not_complete")
                    if not native_ready:
                        ok = False
                        auto_reason.append("native_not_ready")
                    if not texture_prewarm:
                        ok = False
                        auto_reason.append("texture_prewarm_not_ready")
                elif sections <= 0:
                    ok = False
                    auto_reason.append("no_selected_sections")
                if not full_scene:
                    ok = False
                    auto_reason.append("home_not_composed")
                if int(texture_total) >= 0 and int(texture_ready) < int(texture_total):
                    ok = False
                    auto_reason.append("visible_texture_not_ready")
                if slow_required == 1 and (not slow_seen or not slow_text):
                    ok = False
                    auto_reason.append("slow_reason_text_missing")
                if int(final) and not home_ready:
                    ok = False
                    auto_reason.append("home_not_released")
                result_u = "PASS" if ok else "FAIL"
                if (not ok and str(stage or "") == "home_release"
                        and bool(getattr(self, "_initial_compose_r57_active", False))):
                    # R59: Home is released under the R57 overlay on purpose.
                    result_u = "PASS"
                    auto_reason.append("deferred_to_initial_compose_overlay_r57")
                if not reason:
                    reason = "+".join(auto_reason) or "all_contracts_satisfied"
            _log("STARTUP_ACCEPTANCE_V2496 result=%s final=%d stage=%s cause=%s sections=%d recommend=%d library=%d native=%d texture_prewarm=%d full_scene=%d home_ready=%d slow_required=%d slow_seen=%d slow_text=%s wait_ms=%d visible_texture=%d/%d changed_sections=%s item_changed_sections=%s library_firstpaint=18 actual_local_required=1 reason=%s" % (
                result_u, 1 if int(final) else 0, str(stage or "unknown"), cause,
                int(sections), int(rec_ready), int(lib_ready), native_ready, texture_prewarm,
                full_scene, home_ready, slow_required, slow_seen, _short_log_value(slow_text or "-", 80), int(wait_ms),
                int(texture_ready), int(texture_total),
                ",".join(changed) or "none", ",".join(item_changed) or "none",
                _short_log_value(str(reason or "-"), 160)
            ), xbmc.LOGINFO if result_u == "PASS" else xbmc.LOGERROR)
            if int(final):
                try:
                    _gate_v2534 = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
                    _compose_at_v2534 = int(getattr(self, "_startup_full_scene_composed_at_ms_v2534", 0) or 0)
                    _prepare_at_v2534 = int(getattr(self, "_startup_prepare_done_at_ms_v2534", 0) or 0)
                    _compose_ms_v2534 = max(0, _compose_at_v2534 - _gate_v2534) if _gate_v2534 > 0 and _compose_at_v2534 > 0 else -1
                    _prepare_ms_v2534 = max(0, _prepare_at_v2534 - _gate_v2534) if _gate_v2534 > 0 and _prepare_at_v2534 > 0 else -1
                    _fast_v2534 = dict(getattr(self, "_home_startup_fastpath_stats_v2499", {}) or {})
                    _log("STARTUP_PERF_SUMMARY_V2534 cause=%s total_wait_ms=%d home_compose_ms=%d selective_prepare_done_ms=%d fast_enabled=%d fast_hits=%d fast_misses=%d fast_coverage=%d render_ms=%d changed_sections=%s" % (
                        cause, int(wait_ms), _compose_ms_v2534, _prepare_ms_v2534,
                        int(_fast_v2534.get("enabled") or 0), int(_fast_v2534.get("hits") or 0),
                        int(_fast_v2534.get("misses") or 0), int(_fast_v2534.get("coverage") or 0),
                        int(_fast_v2534.get("render_ms") or -1), ",".join(changed) or "none"
                    ))
                except Exception:
                    pass
                try:
                    _budget_result_v2535 = "NORMAL" if int(wait_ms) < 6000 else "ABNORMAL"
                    _log("STARTUP_BUDGET_SUMMARY_V2535 result=%s wait_ms=%d target_unchanged_ms=3000 abnormal_ms=6000 current_home_only=%d new_content=%d update=%d problem_text=%d deferred_destinations=%d" % (
                        _budget_result_v2535, int(wait_ms), 1 if current_home_only_v2535 else 0,
                        1 if new_content_notice_v2535 else 0, 1 if update_notice_v2535 else 0,
                        1 if (int(wait_ms) >= 6000) else 0,
                        1 if getattr(self, "_startup_deferred_destination_repair_v2535", False) else 0
                    ), xbmc.LOGINFO if _budget_result_v2535 == "NORMAL" else xbmc.LOGWARNING)
                except Exception:
                    pass
            if int(final) and cause == "ready" and int(wait_ms) >= 0:
                _fast_stats_v2499 = dict(getattr(self, "_home_startup_fastpath_stats_v2499", {}) or {})
                _perf_ok_v2499 = bool(int(wait_ms) < 3000)
                _ready_slow_expected_v2535 = 1 if int(wait_ms) >= 6000 else 0
                _ready_reason_v2535 = (
                    "ready_start_under_3s" if _perf_ok_v2499
                    else ("ready_start_3to6s_text_suppressed_v2535" if int(wait_ms) < 6000 else "ready_start_abnormal_over_6s_v2535")
                )
                _log("STARTUP_READY_FASTPATH_ACCEPTANCE_V2499 result=%s wait_ms=%d threshold_ms=3000 fastpath=%d hits=%d misses=%d coverage=%d render_ms=%d slow_notice_expected=%d reason=%s" % (
                    "PASS" if _perf_ok_v2499 else "FAIL", int(wait_ms),
                    int(_fast_stats_v2499.get("enabled") or 0), int(_fast_stats_v2499.get("hits") or 0),
                    int(_fast_stats_v2499.get("misses") or 0), int(_fast_stats_v2499.get("coverage") or 0),
                    int(_fast_stats_v2499.get("render_ms") or -1), _ready_slow_expected_v2535,
                    _ready_reason_v2535
                ), xbmc.LOGINFO if _perf_ok_v2499 else xbmc.LOGERROR)
                _fast_stats_v2500 = dict(getattr(self, "_home_startup_fastpath_stats_v2500", {}) or {})
                _log("STARTUP_READY_FASTPATH_ACCEPTANCE_V2500 result=%s wait_ms=%d threshold_ms=3000 home_persistent_hits=%d section_fallback_hits=%d misses=%d coverage=%d render_ms=%d poster_verified_hits=%d poster_verified_entries=%d slow_notice_expected=%d reason=%s" % (
                    "PASS" if _perf_ok_v2499 else "FAIL", int(wait_ms),
                    int(_fast_stats_v2500.get("home_hits") or 0), int(_fast_stats_v2500.get("section_hits") or 0),
                    int(_fast_stats_v2500.get("misses") or 0), int(_fast_stats_v2500.get("coverage") or 0),
                    int(_fast_stats_v2500.get("render_ms") or -1),
                    int(getattr(self, "_startup_verified_poster_hits_v2500", 0) or 0),
                    len(getattr(self, "_startup_verified_poster_cache_v2500", {}) or {}),
                    _ready_slow_expected_v2535,
                    _ready_reason_v2535
                ), xbmc.LOGINFO if _perf_ok_v2499 else xbmc.LOGERROR)
            return result_u == "PASS"
        except Exception:
            _log("STARTUP_ACCEPTANCE_V2496 result=FAIL final=%d stage=%s reason=acceptance_logger_exception err=%s" % (
                1 if int(final) else 0, str(stage or "unknown"), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _startup_acceptance_watchdog_v2494r3(self):
        """R140: 60s timeout and guarded native Kodi Quit countdown."""
        try:
            if bool(getattr(self, "_startup_acceptance_watchdog_armed_v2494r3", False)):
                return
            self._startup_acceptance_watchdog_armed_v2494r3 = True
            generation = int(getattr(self, "_lifecycle_generation_v1841", 0) or 0)

            def _watch():
                try:
                    win = xbmcgui.Window(10000)
                    profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
                    marker = os.path.join(profile, "r139_auto_quit_guard.json")
                    try:
                        with open(marker, "r", encoding="utf-8") as f:
                            guard = json.load(f)
                        guard_recent = (time.time() - float(guard.get("at", 0))) < 3600
                    except Exception:
                        guard_recent = False
                    # Keep one thread alive until the ready signal, and use actual
                    # wall clock time (not cumulative sleeps) for all stage changes.
                    last_stage = -1
                    while not self._closing_event_v1841.wait(0.5):
                        if not self._worker_alive_v1841(generation):
                            return
                        if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                            return
                        if (win.getProperty("PlexKM.StartupSettingsIncomplete") == "1"
                                or win.getProperty("PlexKM.Startup.InitialSurfaceV2558") == "1"
                                or win.getProperty("PlexKM.Home.SettingsRequired") == "1"):
                            return
                        raw_arm = str(win.getProperty("PlexKM.Startup.SlowArmAtMsV2493") or "").strip()
                        try:
                            arm_ms = int(float(raw_arm)) if raw_arm else 0
                        except Exception:
                            arm_ms = 0
                        gate_ms = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
                        starts = [x for x in (arm_ms, gate_ms) if x > 0]
                        if not starts:
                            continue
                        elapsed = max(0, int(time.time() * 1000) - min(starts))
                        stage = (60 if elapsed >= 60000 else 55 if elapsed >= 55000
                                 else 52 if elapsed >= 52000 else 47 if elapsed >= 47000
                                 else 42 if elapsed >= 42000 else 37 if elapsed >= 37000
                                 else 32 if elapsed >= 32000 else 27 if elapsed >= 27000
                                 else 22 if elapsed >= 22000 else 17 if elapsed >= 17000
                                 else 12 if elapsed >= 12000 else 0)
                        if stage and stage != last_stage:
                            last_stage = stage
                            self._startup_force_slow_notice_if_due_v2494(phase="r137_elapsed")
                            _log("R140_STARTUP_STAGE elapsed_ms=%d stage_sec=%d restart_guard=%d" % (
                                elapsed, stage, int(guard_recent)))
                            if stage == 12:
                                self._startup_acceptance_log_v2494r3(
                                    result="FAIL", stage="watchdog12s",
                                    reason="startup_exceeded_12s_diagnostic_ceiling",
                                    wait_ms=elapsed, final=0)
                        if elapsed >= 60000:
                            if guard_recent:
                                _log("R140_QUIT_SKIPPED reason=recent_restart_guard", xbmc.LOGWARNING)
                                return
                            if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                                return
                            try:
                                os.makedirs(profile, exist_ok=True)
                                with open(marker, "w", encoding="utf-8") as f:
                                    json.dump({"at": time.time()}, f)
                            except Exception as exc:
                                _log("R140_QUIT_SKIPPED reason=guard_write_failed err=%s" % exc, xbmc.LOGERROR)
                                return
                            # At 60 seconds, show PKM's existing 3-2-1 exit
                            # surface. Its own code dispatches native Kodi Quit.
                            # Never invoke RestartApp on Android.
                            if win.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                                return
                            _log("R140_QUIT_REQUEST existing_pkm_countdown=1", xbmc.LOGWARNING)
                            request_kodi_exit_v2171(
                                reason="startup_timeout_r140",
                                title="Kodi 종료",
                                detail="시작이 지연되어 Kodi를 종료합니다. 종료 후 다시 실행해 주세요.",
                            )
                            return
                except Exception:
                    _log("R140_STARTUP_WATCHDOG_EXCEPTION err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            _PKMHomeThreadV2151(target=_watch, name="PlexKMStartupR137", daemon=True).start()
        except Exception:
            _log("R140_STARTUP_WATCHDOG_ARM_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)

    def _startup_prepare_status_v2477(self, text, progress=None):
        """Publish truthful startup phase without ever revealing text before 3s.

        V2492 makes service.py's V2365 delayed notice the only owner of visibility.
        This method only publishes the pending cause/text, and updates the line if
        the 3-second guard has already made it visible. Fast startup therefore
        reaches Home with no text at all.
        """
        if progress is not None and bool(getattr(self, "_initial_compose_r57_active", False)):
            try:
                self._initial_compose_r57_progress(None, int(max(0, min(87, int(progress))) * 40 / 88))
            except Exception:
                pass
        try:
            win = xbmcgui.Window(10000)
            msg = str(text or "").strip()
            phase = str(getattr(self, "_startup_prepare_cause_v2487", "") or "snapshot_prepare")
            if msg:
                win.setProperty("PlexKM.Startup.PrepareTextV2492", msg)
                win.setProperty("PlexKM.Startup.PreparePhaseV2492", phase)
                if win.getProperty("PlexKM.Startup.InitialPrepareActiveCumulative") == "1":
                    win.setProperty("PlexKM.Startup.InitialPrepareMessageCumulative", msg)
                # V2535: the whitelist function is the only owner allowed to
                # reveal/update the visible line.  Do not overwrite update/problem
                # text with an internal cache/poster phase.
                self._startup_force_slow_notice_if_due_v2494(msg, "prepare_" + phase)
            else:
                win.clearProperty("PlexKM.Startup.PrepareTextV2492")
                win.clearProperty("PlexKM.Startup.PreparePhaseV2492")
            if progress is not None:
                _startup_progress_v1845(max(20, min(87, int(progress))), reason="startup_prepare_v2492")
        except Exception:
            pass

    def _startup_publish_early_status_hint_v2492(self):
        """Give the delayed startup guard a truthful hint before hydrate.

        v2493: a patch/migration can legitimately lack the durable v2490 marker
        while still having a completed prepared-state file.  Such an established
        install must never be labelled as a first library bootstrap.
        """
        try:
            win = xbmcgui.Window(10000)
            marker_done = bool(self._startup_initial_prepare_verified_cumulative())
            prepared_state = self._startup_prepare_state_load_v2477()
            prepared_done = bool(isinstance(prepared_state, dict) and prepared_state.get("completed"))
            try:
                snapshot_evidence = bool(self._section_persistent_cache_load_v2467() or self._library_persistent_cache_load_v2470())
            except Exception:
                snapshot_evidence = False
            first_bootstrap = bool((not marker_done) and (not prepared_done) and (not snapshot_evidence))
            text = "라이브러리를 구성 중입니다" if first_bootstrap else "라이브러리 상태를 확인 중입니다"
            phase = "first_library_compose" if first_bootstrap else "library_state_check"
            win.setProperty("PlexKM.Startup.PrepareTextV2492", text)
            win.setProperty("PlexKM.Startup.PreparePhaseV2492", phase)
            # V2535: early hints remain internal diagnostics only. They never
            # overwrite a visible update/new-content/problem line.
            _log("STARTUP_STATUS_HINT_V2493 first_bootstrap=%d marker_done=%d prepared_done=%d snapshot_evidence=%d text=%s delayed_visibility_only=1" % (
                1 if first_bootstrap else 0, 1 if marker_done else 0, 1 if prepared_done else 0, 1 if snapshot_evidence else 0, text
            ))
            return True
        except Exception:
            return False

    def _startup_section_counts_load_v2484(self):
        """Resolve selected-section content state from synchronized local DB only.

        V2483 still preferred Plex section metadata when item_count/total existed.
        Those fields can contain placeholder zero even for large non-empty libraries,
        which falsely marked rejected snapshots as ready.  V2484 never consumes
        those remote/section metadata fields for startup readiness.

        Rules:
        - items COUNT > 0: authoritative non-empty.
        - items COUNT == 0 + recommendation-index row item_count == 0 with a
          non-empty indexed_at: authoritative empty (local sync proof).
        - items COUNT == 0 + index says > 0, missing index, or missing index time:
          unknown/inconsistent and fail closed.
        No Plex/network request is performed here.
        """
        cached = getattr(self, "_startup_section_counts_v2484", None)
        if isinstance(cached, dict):
            return cached

        selected = []
        seen = set()
        for sec in list(getattr(self, "sections", []) or []):
            if not isinstance(sec, dict):
                continue
            sid = str(sec.get("section_id") or sec.get("key") or "").strip()
            if sid and sid not in seen:
                seen.add(sid)
                selected.append(sid)

        states = {sid: {"known": False, "count": 0, "source": "unknown_local_db"} for sid in selected}
        item_counts = {}
        index_state = {}
        db_ok = False
        try:
            dbp = self._profile_db_path()
            if dbp and os.path.exists(dbp):
                conn = _pkm_ro_connect(dbp, timeout=2.0)
                try:
                    if selected:
                        placeholders = ",".join("?" for _ in selected)
                        # v2494: never trust sections.item_count for startup authority.
                        # fetch_sections() historically writes a placeholder 0 before
                        # sync, so V2493 falsely declared every established library
                        # changed. Reuse the exact V2489 authority count when already
                        # computed; otherwise COUNT through the section-leading items
                        # index. This is exact local membership without a full GROUP BY.
                        cached_stats_v2494 = getattr(self, "_persistent_section_items_stats_v2489", None)
                        if isinstance(cached_stats_v2494, dict):
                            for sid in selected:
                                st_v2494 = cached_stats_v2494.get(sid)
                                if isinstance(st_v2494, dict) and "count" in st_v2494:
                                    item_counts[sid] = max(0, int(st_v2494.get("count") or 0))
                        missing_counts_v2494 = [sid for sid in selected if sid not in item_counts]
                        for sid in missing_counts_v2494:
                            try:
                                row_v2494 = conn.execute(
                                    "SELECT COUNT(*) FROM items WHERE section_id=?", (sid,)
                                ).fetchone()
                                item_counts[sid] = max(0, int((row_v2494 or (0,))[0] or 0))
                            except Exception:
                                pass

                        q_idx = (
                            "SELECT section_id,item_count,indexed_at,source "
                            "FROM item_recommend_index_state WHERE section_id IN (%s)" % placeholders
                        )
                        for sid, count, indexed_at, source in conn.execute(q_idx, tuple(selected)).fetchall() or []:
                            sid = str(sid or "").strip()
                            if sid:
                                index_state[sid] = {
                                    "count": max(0, int(count or 0)),
                                    "indexed_at": str(indexed_at or "").strip(),
                                    "source": str(source or "").strip(),
                                }
                    db_ok = True
                finally:
                    conn.close()
        except Exception:
            _log("STARTUP_SECTION_COUNTS_FAILED_V2484 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        known = 0
        nonempty = 0
        empty = 0
        unknown = 0
        inconsistent = 0
        if db_ok:
            for sid in selected:
                actual = max(0, int(item_counts.get(sid, 0) or 0))
                idx = index_state.get(sid)
                if actual > 0:
                    states[sid] = {"known": True, "count": actual, "source": "local_items"}
                    known += 1
                    nonempty += 1
                    continue
                if isinstance(idx, dict):
                    idx_count = max(0, int(idx.get("count") or 0))
                    indexed_at = str(idx.get("indexed_at") or "").strip()
                    if idx_count == 0 and indexed_at:
                        states[sid] = {"known": True, "count": 0, "source": "local_indexed_empty"}
                        known += 1
                        empty += 1
                        continue
                    if idx_count > 0:
                        states[sid] = {"known": False, "count": 0, "source": "local_inconsistent_items0_index%d" % idx_count}
                        inconsistent += 1
                        unknown += 1
                        continue
                states[sid] = {"known": False, "count": 0, "source": "local_unsynced_or_unproven_empty"}
                unknown += 1
        else:
            unknown = len(selected)

        self._startup_section_counts_v2484 = states
        _log("STARTUP_SECTION_COUNTS_V2494 selected=%d known=%d nonempty=%d empty=%d unknown=%d inconsistent=%d items_rows=%d index_rows=%d count_source=indexed_exact_or_authority_cache sections_item_count=ignored local_only=1 network=0" % (
            len(selected), known, nonempty, empty, unknown, inconsistent, len(item_counts), len(index_state)
        ))
        return states

    def _startup_section_count_v2484(self, sec):
        """Return (known, count, source) from local synchronized DB only."""
        try:
            sid = str((sec or {}).get("section_id") or (sec or {}).get("key") or "").strip()
            states = self._startup_section_counts_load_v2484()
            state = states.get(sid) if sid else None
            if isinstance(state, dict):
                return bool(state.get("known")), max(0, int(state.get("count") or 0)), str(state.get("source") or "unknown_local_db")
        except Exception:
            pass
        return False, 0, "unknown_local_db"

    def _startup_prepare_readiness_v2477(self):
        sections = [dict(sec) for sec in list(getattr(self, "sections", []) or [])
                    if isinstance(sec, dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
        rec_ready = 0
        lib_ready = 0
        nonempty = 0
        unknown = 0
        empty = 0
        for sec in sections:
            sid = str(sec.get("section_id") or sec.get("key") or "").strip()
            known_count, total_hint, count_source = self._startup_section_count_v2484(sec)
            if known_count:
                if total_hint > 0:
                    nonempty += 1
                else:
                    empty += 1
            else:
                # Fail closed: unknown is not empty.
                unknown += 1
            rkey = "recommend:%s" % sid
            rrows = list(getattr(self, "_section_rows_cache", {}).get(rkey) or [])
            rsnaps = list(getattr(self, "_section_render_snapshots_v2473", {}).get(rkey) or [])
            rec_exact = bool(rrows and len(rsnaps) == len(rrows))
            rec_empty = bool(known_count and total_hint == 0)
            if rec_exact or rec_empty:
                rec_ready += 1
            st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid) or {}
            lkey = str(st.get("cache_key") or "") if isinstance(st, dict) else ""
            if not lkey:
                prefix = sid + "|sort="
                candidates = [k for k in getattr(self, "_library_render_snapshots_v2473", {}).keys() if str(k).startswith(prefix)]
                if candidates:
                    lkey = str(candidates[0])
            lrows = list(getattr(self, "_section_rows_cache", {}).get(lkey) or []) if lkey else []
            lsnaps = list(getattr(self, "_library_render_snapshots_v2473", {}).get(lkey) or []) if lkey else []
            lib_exact = bool(lrows and len(lsnaps) == len(lrows))
            lib_empty = bool(known_count and total_hint == 0)
            if lib_exact or lib_empty:
                lib_ready += 1
            if not rec_exact or not lib_exact:
                _log("STARTUP_SECTION_READINESS_V2484 section=%s count_known=%d count=%d source=%s recommend_exact=%d library_exact=%d authoritative_empty=%d" % (
                    sid, 1 if known_count else 0, total_hint, count_source,
                    1 if rec_exact else 0, 1 if lib_exact else 0,
                    1 if (known_count and total_hint == 0) else 0
                ))
        _log("STARTUP_SNAPSHOT_READINESS_V2484 sections=%d recommend_ready=%d library_ready=%d nonempty=%d empty=%d unknown=%d fail_closed_unknown=1" % (
            len(sections), rec_ready, lib_ready, nonempty, empty, unknown
        ))
        return len(sections), rec_ready, lib_ready, nonempty

    def _arm_startup_prepare_policy_v2477(self, reason=""):
        try:
            # PKM_PATCH_ACTIVE v2582 uhd3_startup_prepare_local_first_bypass
            # service.py marks established launches local-first before WindowXML
            # opens.  If the durable first-bootstrap marker exists, skip all
            # per-section COUNT/fingerprint/presentation-readiness work here.
            # Those checks are maintenance, not pixels required for current Home.
            # This removes another large SQLite path from the <10 s UHD3 budget.
            try:
                # V2657: current Home pixels do not depend on an off-screen
                # snapshot bootstrap marker.  Local-first means local-first even on
                # the first restart after a completed library import.
                fast_local_v2582 = (
                    xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                )
            except Exception:
                fast_local_v2582 = False
            # PKM_CUMULATIVE_STAGE2_FIRST_PREPARE
            bootstrap_proved = bool(self._startup_initial_prepare_verified_cumulative())
            if fast_local_v2582 and bootstrap_proved and not bool(getattr(self, "_r70_full_prepare_required", True)):
                self._startup_prepare_required_v2477 = False
                self._startup_prepare_cause_v2487 = "local_first_v2582"
                self._startup_prepare_display_text_v2482 = ""
                self._startup_established_current_home_only_v2535 = True
                self._startup_deferred_destination_repair_v2535 = True
                self._startup_prepare_done_event_v2477.set()
                _log("UHD3_STARTUP_PREPARE_BYPASS_V2657 local_db_first=1 bootstrap_marker_required=0 db_section_stats=0 destination_verify=0 presentation_rebuild=0 startup_block=0")
                return False
            total, rec_ready, lib_ready, nonempty = self._startup_prepare_readiness_v2477()
            sig, ids = self._startup_prepare_selected_signature_v2477()
            section_fp_v2489, section_stats_v2489 = self._persistent_section_authority_state_v2489()
            authority = self._persistent_selected_section_authority_combined_v2489(ids)
            state = self._startup_prepare_state_load_v2477()
            state_section_model_v2489 = bool(
                isinstance(state, dict)
                and str(state.get("authority_model") or "") == "content_section_v2489"
            )
            stored_section_fp_v2489 = dict((state or {}).get("section_authority_v2489") or {}) if isinstance(state, dict) else {}
            stored_section_stats_v2489 = dict((state or {}).get("section_items_stats_v2489") or {}) if isinstance(state, dict) else {}
            selected_same_v2489 = bool(
                isinstance(state, dict)
                and str(state.get("selected_sig") or "")
                and str(state.get("selected_sig") or "") == str(sig or "")
            )
            all_section_proof_v2489 = bool(ids) and all(str((section_fp_v2489 or {}).get(sid) or "") for sid in ids)
            changed_sections_v2489 = []
            rescued_state_sections_v2494 = []
            if state_section_model_v2489 and selected_same_v2489:
                for sid in ids:
                    old_fp_v2494 = str(stored_section_fp_v2489.get(sid) or "")
                    new_fp_v2494 = str((section_fp_v2489 or {}).get(sid) or "")
                    if old_fp_v2494 == new_fp_v2494:
                        continue
                    old_stats_v2494 = dict(stored_section_stats_v2489.get(sid) or {})
                    new_stats_v2494 = dict((section_stats_v2489 or {}).get(sid) or {})
                    bad_fp_v2494 = self._persistent_v2493_zero_count_fingerprint_v2494(sid)
                    poison_signature_v2494 = bool(
                        bad_fp_v2494
                        and old_fp_v2494 == bad_fp_v2494
                        and int(old_stats_v2494.get("count") or 0) == 0
                        and int(new_stats_v2494.get("count") or 0) > 0
                        and str(old_stats_v2494.get("max_updated") or "0") == str(new_stats_v2494.get("max_updated") or "0")
                        and str(old_stats_v2494.get("max_added") or "0") == str(new_stats_v2494.get("max_added") or "0")
                    )
                    if poison_signature_v2494:
                        stored_section_fp_v2489[sid] = new_fp_v2494
                        stored_section_stats_v2489[sid] = dict(new_stats_v2494)
                        rescued_state_sections_v2494.append(sid)
                        continue
                    changed_sections_v2489.append(sid)
                if rescued_state_sections_v2494 and isinstance(state, dict):
                    state["section_authority_v2489"] = dict(stored_section_fp_v2489)
                    state["section_items_stats_v2489"] = dict(stored_section_stats_v2489)
                    _log("STARTUP_V2493_STATE_POISON_RESCUE_V2494 sections=%s rows_rebuild=0 baseline_migrate=1" % (
                        ",".join(rescued_state_sections_v2494)
                    ))
            self._startup_changed_section_ids_v2489 = set(changed_sections_v2489)

            # PKM_PATCH_ACTIVE v2577 selective_presentation_invalidation_by_section
            # v2487 presentation fingerprints are intentionally global (ratings /
            # Cine21 / Watcha).  When one Plex section gains/removes content, that
            # global fingerprint can change and make all 14 persistent destinations
            # look stale even though only one section's rows changed.  Hydration now
            # holds exact old snapshots temporarily; once content fingerprints are
            # known, discard only the changed sections and reuse/promote unrelated
            # snapshots.  If there is no content change and the presentation DB alone
            # changed, keep the original fail-closed behaviour and rebuild all stale
            # presentation snapshots so real rating updates are never hidden.
            stale_keys_v2577 = set(getattr(self, "_startup_presentation_stale_keys_v2487", set()) or set())
            if stale_keys_v2577:
                changed_set_v2577 = set(str(x) for x in (changed_sections_v2489 or []) if str(x))
                kept_v2577 = 0
                dropped_v2577 = 0
                promote_sids_v2577 = set()
                lib_key_map_v2577 = dict(getattr(self, "_startup_stale_library_cache_keys_v2577", {}) or {})
                for stale_tag_v2577 in list(stale_keys_v2577):
                    tag_v2577 = str(stale_tag_v2577 or "")
                    if tag_v2577.startswith("recommend:"):
                        sid_v2577 = tag_v2577.split(":", 1)[1]
                        render_key_v2577 = tag_v2577
                        render_map_v2577 = self._section_render_snapshots_v2473
                    elif tag_v2577.startswith("library:"):
                        sid_v2577 = tag_v2577.split(":", 1)[1]
                        render_key_v2577 = str(lib_key_map_v2577.get(sid_v2577) or "")
                        if not render_key_v2577:
                            prefix_v2577 = sid_v2577 + "|sort="
                            render_key_v2577 = next((str(k) for k in self._library_render_snapshots_v2473.keys() if str(k).startswith(prefix_v2577)), "")
                        render_map_v2577 = self._library_render_snapshots_v2473
                    else:
                        continue
                    must_drop_v2577 = (not changed_set_v2577) or (sid_v2577 in changed_set_v2577)
                    if must_drop_v2577:
                        if render_key_v2577:
                            render_map_v2577.pop(render_key_v2577, None)
                        dropped_v2577 += 1
                    else:
                        self._startup_presentation_stale_keys_v2487.discard(stale_tag_v2577)
                        promote_sids_v2577.add(sid_v2577)
                        kept_v2577 += 1

                # Persist the promotion only for the safe mixed case: content did
                # change somewhere, but this particular section's content fingerprint
                # did not.  This prevents the next restart from paying the same global
                # presentation rebuild again. Presentation-only global changes never
                # enter this promotion path.
                if changed_set_v2577 and promote_sids_v2577:
                    try:
                        current_presentation_v2577 = str(self._persistent_presentation_fingerprint_v2487() or "")
                        if current_presentation_v2577:
                            rec_cache_v2577 = self._section_persistent_cache_load_v2467()
                            rec_changed_v2577 = False
                            if isinstance(rec_cache_v2577, dict):
                                for sid_v2577 in promote_sids_v2577:
                                    rec_v2577 = rec_cache_v2577.get("recommend:%s" % sid_v2577)
                                    if isinstance(rec_v2577, dict):
                                        rec_v2577["presentation_fp_v2487"] = current_presentation_v2577
                                        rec_changed_v2577 = True
                                if rec_changed_v2577:
                                    path_v2577 = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
                                    _pkm_write_cache_json_v2801(path_v2577, rec_cache_v2577)
                            lib_cache_v2577 = self._library_persistent_cache_load_v2470()
                            lib_changed_v2577 = False
                            if isinstance(lib_cache_v2577, dict):
                                for _key_v2577, rec_v2577 in list(lib_cache_v2577.items()):
                                    if isinstance(rec_v2577, dict) and str(rec_v2577.get("section_id") or "") in promote_sids_v2577:
                                        rec_v2577["presentation_fp_v2487"] = current_presentation_v2577
                                        lib_changed_v2577 = True
                                if lib_changed_v2577:
                                    path_v2577 = self._derived_cache_path_v2467("library_wall_prepared_cache_v2470.json")
                                    _pkm_write_cache_json_v2801(path_v2577, lib_cache_v2577)
                    except Exception:
                        _log("STARTUP_PRESENTATION_PROMOTE_FAILED_V2577 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

                total, rec_ready, lib_ready, nonempty = self._startup_prepare_readiness_v2477()
                _log("STARTUP_PRESENTATION_SELECTIVE_INVALIDATION_V2577 changed_sections=%s stale=%d kept_unaffected=%d dropped=%d recommend_ready=%d/%d library_ready=%d/%d presentation_only_full_rebuild=%d" % (
                    ",".join(sorted(changed_set_v2577)) or "none", len(stale_keys_v2577), kept_v2577, dropped_v2577,
                    rec_ready, total, lib_ready, total, 1 if not changed_set_v2577 else 0
                ))

            state_match = bool(
                isinstance(state, dict)
                and int(state.get("version") or 0) == 2477
                and bool(state.get("completed"))
                and state_section_model_v2489
                and selected_same_v2489
                and all_section_proof_v2489
                and not changed_sections_v2489
            )
            complete_now = bool(total > 0 and rec_ready == total and lib_ready == total)
            if rescued_state_sections_v2494 and complete_now:
                try:
                    self._startup_prepare_state_store_v2477(authority, rec_ready, lib_ready, ids)
                    _log("STARTUP_V2493_STATE_POISON_FLUSH_V2494 sections=%s baseline_persisted=1 rebuild=0" % (
                        ",".join(rescued_state_sections_v2494)
                    ))
                except Exception:
                    _log("STARTUP_V2493_STATE_POISON_FLUSH_FAILED_V2494 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            # v2490: this is the only predicate allowed to request the expensive
            # all-section foreground snapshot bootstrap.  It is durable and is
            # intentionally independent from the mutable authority-state file.
            bootstrap_done_v2490 = self._startup_snapshot_bootstrap_done_v2490(
                state=state, complete_now=complete_now
            )
            first_bootstrap = bool(total > 0 and not bootstrap_done_v2490)
            if first_bootstrap:
                _log("INITIAL_PREPARATION_REQUIRED reason=no_verified_bootstrap selected=%d fast_bypass=0" % total)
                self._startup_prepare_display_text_v2482 = "최초 라이브러리 화면을 준비 중입니다"
                self._startup_prepare_status_v2477(self._startup_prepare_display_text_v2482, progress=28)

            # v2492: every selected destination must be ready before Home release,
            # but only incomplete sections are rebuilt. Existing ready snapshots
            # are skipped by the prepare loops, so a one-section Plex change does
            # not recreate the other selected libraries.
            self._startup_prepare_required_v2477 = bool(
                total > 0 and (not complete_now or not bootstrap_done_v2490)
            )
            self._startup_prepare_reason_v2477 = str(reason or "")

            if complete_now and not state_match:
                # Migration/repair fast path: persist the current per-section
                # baseline without rebuilding pixels that are already complete.
                self._startup_prepare_state_store_v2477(authority, rec_ready, lib_ready, ids)
                state_match = True
            authority_changed_v2487, items_changed_sections_v2489, local_index_only_changed_v2487, new_content_sections_v2535, plex_items_changed_v2487, selected_changed_v2487 = self._arm_startup_prepare_policy_v2477_step1(bootstrap_done_v2490, changed_sections_v2489, complete_now, section_stats_v2489, selected_same_v2489, sig, state, state_section_model_v2489, stored_section_stats_v2489)
            cause_v2487, content_reject_v2487, display_v2487, legacy_state_v2487, presentation_stale_v2487, startup_destination_barrier_v2638 = self._arm_startup_prepare_policy_v2477_step2(bootstrap_done_v2490, changed_sections_v2489, complete_now, first_bootstrap, local_index_only_changed_v2487, new_content_sections_v2535, plex_items_changed_v2487, selected_changed_v2487, state, state_match, state_section_model_v2489, total)
            established_current_home_v2535 = bool(
                total > 0 and bootstrap_done_v2490 and not first_bootstrap
                and not startup_destination_barrier_v2638
            )
            if (established_current_home_v2535 and not state_match
                    and complete_now and not changed_sections_v2489):
                _log("STARTUP_R81_PRESENTATION_ONLY_FASTPATH cause=%s snapshot_complete=1 changed_sections=none full_texture_prewarm=not_required first_viewport_gate=required" % cause_v2487)
            self._startup_established_current_home_only_v2535 = bool(established_current_home_v2535)
            self._startup_deferred_destination_repair_v2535 = False
            if startup_destination_barrier_v2638:
                self._startup_prepare_required_v2477 = True
                self._startup_prepare_done_event_v2477.clear()
                self._startup_scene_composed_event_v1841.clear()
                _log("STARTUP_DESTINATION_BARRIER_V2639 cause=%s changed_sections=%s recommend_ready=%d/%d library_ready=%d/%d home_release_blocked=1 post_home_first_focus_rebuild=0" % (
                    cause_v2487, ",".join(changed_sections_v2489) or "none",
                    rec_ready, total, lib_ready, total
                ))
            elif established_current_home_v2535 and (not complete_now or not state_match):
                self._startup_prepare_required_v2477 = False
                self._startup_prepare_done_event_v2477.set()
                self._startup_deferred_destination_repair_v2535 = True
                _log("UHD3_STARTUP_DESTINATION_DEFER_V2639 cause=%s changed_sections=%s recommend_ready=%d/%d library_ready=%d/%d current_home_only=1 repair=post_home_idle startup_block=0" % (
                    cause_v2487, ",".join(changed_sections_v2489) or "none",
                    rec_ready, total, lib_ready, total
                ))

            # V2492 visibility remains owned by the delayed notice. V2535 narrows
            # the pending text to the whitelist above.  New-content evidence is also
            # published independently so the service guard can show it even when
            # destination repair has been deferred.
            self._startup_prepare_display_text_v2482 = display_v2487 if (display_v2487 and (self._startup_prepare_required_v2477 or new_content_sections_v2535)) else ""
            self._startup_prepare_status_v2477(
                self._startup_prepare_display_text_v2482,
                progress=28 if self._startup_prepare_required_v2477 else None,
            )
            if not self._startup_prepare_required_v2477:
                self._startup_prepare_done_event_v2477.set()

            _log("STARTUP_PREPARE_REASON_V2487 cause=%s first=%d selection_changed=%d authority_changed=%d plex_items_changed=%d local_index_only=%d presentation_stale=%d content_reject=%d legacy_state=%d addon_update_notice=0 text=%s" % (
                cause_v2487, 1 if first_bootstrap else 0, 1 if selected_changed_v2487 else 0,
                1 if authority_changed_v2487 else 0, 1 if plex_items_changed_v2487 else 0,
                1 if local_index_only_changed_v2487 else 0, 1 if presentation_stale_v2487 else 0,
                1 if content_reject_v2487 else 0, 1 if legacy_state_v2487 else 0,
                _short_log_value(self._startup_prepare_display_text_v2482, 80)
            ))
            _log("STARTUP_PREPARE_REASON_V2489 cause=%s changed_sections=%s item_changed_sections=%s selective_rebuild=1 unchanged_snapshot_reuse=1 legacy_state=%d" % (
                cause_v2487,
                ",".join(changed_sections_v2489) or "none",
                ",".join(items_changed_sections_v2489) or "none",
                1 if legacy_state_v2487 else 0,
            ))
            _log("STARTUP_REASON_EVIDENCE_V2533 cause=%s evidence=%s live_plex_probe=0 current_source=local_items_index persisted_source=startup_section_baseline changed_sections=%s item_changed_sections=%s" % (
                cause_v2487,
                "local_items_stats_vs_persisted_baseline" if plex_items_changed_v2487 else ("presentation_fingerprint" if cause_v2487 == "presentation_refresh" else "startup_state"),
                ",".join(changed_sections_v2489) or "none",
                ",".join(items_changed_sections_v2489) or "none",
            ))
            if (not first_bootstrap) and (not complete_now):
                _log("STARTUP_SELECTIVE_FOREGROUND_REPAIR_V2492 cause=%s sections=%d recommend_ready=%d library_ready=%d changed_sections=%s startup_barrier=1 unchanged_reuse=1 background_repair=0" % (
                    cause_v2487, total, rec_ready, lib_ready,
                    ",".join(changed_sections_v2489) or "none"
                ))
            _log("STARTUP_PREPARE_POLICY_V2492 reason=%s sections=%d recommend_ready=%d library_ready=%d first_bootstrap=%d bootstrap_done=%d foreground_required=%d complete_now=%d state_match=%d authority=%s selected_sig=%s" % (
                reason or "", total, rec_ready, lib_ready,
                1 if first_bootstrap else 0, 1 if bootstrap_done_v2490 else 0,
                1 if self._startup_prepare_required_v2477 else 0, 1 if complete_now else 0,
                1 if state_match else 0, str(authority or "")[:12], str(sig or "")[:12]
            ))
            return self._startup_prepare_required_v2477
        except Exception:
            # Only an unproven first bootstrap may fail closed behind the logo.
            # Existing installs must never regress to a global startup rebuild
            # because a mutable cache/status probe raised an exception.
            marker_v2490 = self._startup_initial_prepare_verified_cumulative()
            if marker_v2490:
                self._startup_prepare_required_v2477 = False
                self._startup_prepare_display_text_v2482 = ""
                self._startup_prepare_done_event_v2477.set()
                _log("STARTUP_PREPARE_POLICY_FAILED_V2490 established=1 global_barrier=0 deferred_repair=1 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                return False
            self._startup_prepare_required_v2477 = True
            self._startup_prepare_display_text_v2482 = "초기 준비 상태를 확인하고 있습니다"
            self._startup_prepare_status_v2477(self._startup_prepare_display_text_v2482, progress=28)
            _log("STARTUP_PREPARE_POLICY_FAILED_V2482 fail_closed=1 home_release_unblocked=0 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return True

    def _arm_startup_prepare_policy_v2477_step1(self, bootstrap_done_v2490, changed_sections_v2489, complete_now, section_stats_v2489, selected_same_v2489, sig, state, state_section_model_v2489, stored_section_stats_v2489):
        """Step 1 of _arm_startup_prepare_policy_v2477 (R76 split, moved verbatim). Logs: INITIAL_PREPARATION_REQUIRED, STARTUP_SECTION_CONTENT_CHANGE_V2489, STARTUP_NEW_CONTENT_EVIDENCE_V2535."""
        if complete_now and not bootstrap_done_v2490:
            _log("INITIAL_PREPARATION_REQUIRED reason=ready_snapshots_without_native_texture_proof action=verify_before_marker")

        selected_changed_v2487 = bool(
            isinstance(state, dict) and str(state.get("selected_sig") or "")
            and str(state.get("selected_sig") or "") != str(sig or "")
        )
        authority_changed_v2487 = bool(
            state_section_model_v2489 and selected_same_v2489 and changed_sections_v2489
        )

        items_changed_sections_v2489 = []
        new_content_sections_v2535 = []
        removed_content_sections_v2535 = []
        metadata_only_sections_v2535 = []
        if state_section_model_v2489 and selected_same_v2489:
            for sid in changed_sections_v2489:
                old_stats = dict(stored_section_stats_v2489.get(sid) or {})
                new_stats = dict((section_stats_v2489 or {}).get(sid) or {})
                if old_stats != new_stats:
                    items_changed_sections_v2489.append(sid)
                    reasons = []
                    if str(old_stats.get("count", "")) != str(new_stats.get("count", "")):
                        reasons.append("count")
                    if str(old_stats.get("max_updated", "")) != str(new_stats.get("max_updated", "")):
                        reasons.append("updated")
                    if str(old_stats.get("max_added", "")) != str(new_stats.get("max_added", "")):
                        reasons.append("added")
                    try:
                        old_count_v2535 = int(float(str(old_stats.get("count") or 0)))
                    except Exception:
                        old_count_v2535 = 0
                    try:
                        new_count_v2535 = int(float(str(new_stats.get("count") or 0)))
                    except Exception:
                        new_count_v2535 = 0
                    try:
                        old_added_v2535 = int(float(str(old_stats.get("max_added") or 0)))
                    except Exception:
                        old_added_v2535 = 0
                    try:
                        new_added_v2535 = int(float(str(new_stats.get("max_added") or 0)))
                    except Exception:
                        new_added_v2535 = 0
                    try:
                        old_updated_v2535 = int(float(str(old_stats.get("max_updated") or 0)))
                    except Exception:
                        old_updated_v2535 = 0
                    try:
                        new_updated_v2535 = int(float(str(new_stats.get("max_updated") or 0)))
                    except Exception:
                        new_updated_v2535 = 0
                    # V2535 wording truth: only genuine additions are allowed to
                    # display a library-change status line.  A count increase is
                    # direct evidence.  A newer max_added timestamp also counts
                    # because an add+remove transaction can leave COUNT unchanged.
                    if new_count_v2535 > old_count_v2535 or new_added_v2535 > old_added_v2535:
                        new_content_sections_v2535.append(sid)
                    elif new_count_v2535 < old_count_v2535:
                        removed_content_sections_v2535.append(sid)
                    elif new_updated_v2535 != old_updated_v2535:
                        metadata_only_sections_v2535.append(sid)
                    _log("STARTUP_SECTION_CONTENT_CHANGE_V2489 section=%s old_count=%s new_count=%s old_updated=%s new_updated=%s old_added=%s new_added=%s reason=%s" % (
                        sid,
                        str(old_stats.get("count", "?")), str(new_stats.get("count", "?")),
                        _short_log_value(old_stats.get("max_updated", "?"), 32), _short_log_value(new_stats.get("max_updated", "?"), 32),
                        _short_log_value(old_stats.get("max_added", "?"), 32), _short_log_value(new_stats.get("max_added", "?"), 32),
                        "+".join(reasons) or "items_stats"
                    ))
        self._startup_items_changed_section_ids_v2489 = set(items_changed_sections_v2489)
        self._startup_new_content_sections_v2535 = set(new_content_sections_v2535)
        self._startup_removed_content_sections_v2535 = set(removed_content_sections_v2535)
        self._startup_metadata_only_sections_v2535 = set(metadata_only_sections_v2535)
        try:
            _win_v2535 = xbmcgui.Window(10000)
            if new_content_sections_v2535:
                _win_v2535.setProperty("PlexKM.Startup.NewContentAddedV2535", "1")
                _win_v2535.setProperty("PlexKM.Startup.NewContentSectionsV2535", ",".join(new_content_sections_v2535))
            else:
                _win_v2535.clearProperty("PlexKM.Startup.NewContentAddedV2535")
                _win_v2535.clearProperty("PlexKM.Startup.NewContentSectionsV2535")
        except Exception:
            pass
        _log("STARTUP_NEW_CONTENT_EVIDENCE_V2535 added_sections=%s removed_sections=%s metadata_only_sections=%s text_allowed=%d" % (
            ",".join(new_content_sections_v2535) or "none",
            ",".join(removed_content_sections_v2535) or "none",
            ",".join(metadata_only_sections_v2535) or "none",
            1 if new_content_sections_v2535 else 0
        ))
        plex_items_changed_v2487 = bool(items_changed_sections_v2489)
        local_index_only_changed_v2487 = bool(authority_changed_v2487 and not plex_items_changed_v2487)
        return authority_changed_v2487, items_changed_sections_v2489, local_index_only_changed_v2487, new_content_sections_v2535, plex_items_changed_v2487, selected_changed_v2487

    def _arm_startup_prepare_policy_v2477_step2(self, bootstrap_done_v2490, changed_sections_v2489, complete_now, first_bootstrap, local_index_only_changed_v2487, new_content_sections_v2535, plex_items_changed_v2487, selected_changed_v2487, state, state_match, state_section_model_v2489, total):
        """Step 2 of _arm_startup_prepare_policy_v2477 (R76 split, moved verbatim)."""
        content_changed_v2487 = plex_items_changed_v2487
        presentation_stale_v2487 = bool(getattr(self, "_startup_presentation_stale_keys_v2487", set()) or set())
        content_reject_v2487 = bool(getattr(self, "_startup_content_reject_keys_v2487", set()) or set())
        legacy_state_v2487 = bool(state) and not state_section_model_v2489

        # V2535 user-visible whitelist: only real new-content additions are
        # allowed to produce a library status line.  Selection changes, metadata
        # refreshes, local index/cache repair and first-bootstrap bookkeeping stay
        # silent unless the separate 6-second abnormal/problem policy fires.
        if first_bootstrap:
            cause_v2487 = "first_bootstrap"
            display_v2487 = ""
        elif selected_changed_v2487:
            cause_v2487 = "selection_changed"
            display_v2487 = ""
        elif content_changed_v2487:
            cause_v2487 = "plex_items_changed"
            display_v2487 = "새 콘텐츠를 반영 중입니다" if new_content_sections_v2535 else ""
        elif local_index_only_changed_v2487:
            cause_v2487 = "local_index_changed"
            display_v2487 = ""
        elif presentation_stale_v2487 and not content_reject_v2487:
            cause_v2487 = "presentation_refresh"
            display_v2487 = ""
        elif legacy_state_v2487:
            cause_v2487 = "legacy_cache_migration"
            display_v2487 = ""
        elif not complete_now:
            cause_v2487 = "cache_gap_or_repair"
            display_v2487 = ""
        else:
            cause_v2487 = "ready"
            display_v2487 = ""

        if (cause_v2487 not in ("first_bootstrap", "selection_changed") and not first_bootstrap
                and bootstrap_done_v2490 and total > 0 and self._startup_texture_cache_wiped_r57()):
            cause_v2487 = "cache_wiped_r57"
            display_v2487 = ""

        self._startup_prepare_cause_v2487 = cause_v2487

        # PKM_PATCH_ACTIVE v2582 uhd3_startup_current_home_first
        # Established UHD3 launches must reveal from the already-committed
        # current Home snapshot instead of rebuilding every stale off-screen
        # Recommendation/Library destination under the splash.  The user has
        # explicitly accepted progressive filling after reveal.  First-ever
        # bootstrap remains fail-closed; only established installs take this
        # current-Home-only path.
        # V2638: Home READY is a destination-readiness contract again when
        # selected libraries or authoritative Plex contents changed.
        # V2582 may still defer harmless presentation/local-index maintenance,
        # but it must never push a real library-selection/content rebuild into
        # the user's first sidebar focus after Home is already visible.
        # V2639: every selected sidebar destination uses the same readiness contract.
        # Initial construction, add/remove, Plex change and repair are not allowed
        # to become a first-focus foreground rebuild after HOME READY.
        startup_destination_barrier_v2638 = bool(
            total > 0 and bootstrap_done_v2490 and not first_bootstrap
            and (not complete_now or not state_match)
            # R81: a presentation-only fingerprint mismatch with every
            # destination already complete is not an authoritative Plex change.
            and not (complete_now and not changed_sections_v2489
                     and cause_v2487 in ("ready", "presentation_refresh", "local_index_changed"))
        )
        if cause_v2487 == "cache_wiped_r57":
            # R57: poster cache was wiped -> rebuild posters once under the
            # initial-compose overlay instead of filling in on screen.
            startup_destination_barrier_v2638 = True
        return cause_v2487, content_reject_v2487, display_v2487, legacy_state_v2487, presentation_stale_v2487, startup_destination_barrier_v2638

    def _startup_prepare_recommend_all_v2477(self, sections, generation):
        completed = 0
        failed = []
        total = len(sections)
        for idx, sec in enumerate(sections):
            if not self._worker_alive_v1841(generation):
                return completed, failed + ["aborted"]
            sid = str(sec.get("section_id") or sec.get("key") or "").strip()
            if not sid:
                continue
            key = "recommend:%s" % sid
            title = str(sec.get("title") or sec.get("name") or sid)
            stype = str(sec.get("section_type") or sec.get("type") or "")
            self._initial_compose_r57_progress(
                "라이브러리 화면 구성 %d / %d · %s" % (idx + 1, total, _display_library_title(title)),
                int(idx * 34 / max(1, total)))
            known_count, total_hint, _count_source_v2484 = self._startup_section_count_v2484(sec)
            authoritative_empty_v2484 = bool(known_count and total_hint == 0)
            rows = list(self._section_rows_cache.get(key) or [])
            snaps = list(self._section_render_snapshots_v2473.get(key) or [])
            if (rows and len(snaps) == len(rows)) or authoritative_empty_v2484:
                completed += 1
            else:
                try:
                    # v2487: when content rows were hydrated successfully but only
                    # the rating/presentation snapshot is stale, do not recompose
                    # Recommendation data. Refresh display properties from the
                    # immutable rows under the logo and persist the new presentation fp.
                    if rows:
                        try:
                            self._preload_visible_row_ratings(rows, reason="startup_presentation_refresh_v2487:%s" % sid)
                        except Exception:
                            pass
                        ok = bool(self._ensure_recommend_persistent_snapshot_v2476(
                            key, title, rows, reason="startup_presentation_refresh_v2487"
                        ))
                        _log("STARTUP_PRESENTATION_REFRESH_V2487 kind=recommend section=%s rows=%d data_recompose=0 db_row_query=0 ok=%d" % (
                            sid, len(rows), 1 if ok else 0
                        ))
                    else:
                        ok = bool(self._prebuild_one_sidebar_scene_v1644(sid, title, stype))
                        rows = list(self._section_rows_cache.get(key) or [])
                        if ok and rows:
                            ok = bool(self._ensure_recommend_persistent_snapshot_v2476(
                                key, title, rows, reason="startup_logo_prepare_v2484"
                            ))
                    if authoritative_empty_v2484 and not rows:
                        ok = True
                    elif not rows:
                        # Unknown or known-nonempty with no rows is a real failure.
                        ok = False
                    if ok:
                        completed += 1
                    else:
                        failed.append(sid)
                except Exception:
                    failed.append(sid)
                    _log("STARTUP_PREPARE_RECOMMEND_FAILED_V2477 section=%s err=%s" % (
                        sid, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            progress = 30 + int(((idx + 1) * 24) / max(1, total))
            self._startup_prepare_status_v2477(
                getattr(self, "_startup_prepare_display_text_v2482", "") or "화면을 준비 중입니다",
                progress=progress,
            )
            _log("STARTUP_PREPARE_RECOMMEND_SECTION_V2477 section=%s ready=%d rows=%d index=%d total=%d native_listitems=0" % (
                sid, 0 if sid in failed else 1, len(self._section_rows_cache.get(key) or []), idx + 1, total
            ))
        return completed, failed

    def _startup_prepare_library_all_v2477(self, sections, generation):
        completed = 0
        failed = []
        total_sections = len(sections)
        self._section_tab_state_load_v2471()
        authority = self._persistent_selected_section_authority_combined_v2489()
        default_sort = str(getattr(self, "sort", "title") or "title")
        default_dir = str(getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(default_sort)) or "")
        for idx, sec in enumerate(sections):
            if not self._worker_alive_v1841(generation):
                return completed, failed + ["aborted"]
            sid = str(sec.get("section_id") or sec.get("key") or "").strip()
            if not sid:
                continue
            self._initial_compose_r57_progress("라이브러리 목록 준비 %d / %d" % (idx + 1, total_sections),
                                               34 + int(idx * 6 / max(1, total_sections)))
            known_count, total_hint, _count_source_v2484 = self._startup_section_count_v2484(sec)
            authoritative_empty_v2484 = bool(known_count and total_hint == 0)
            try:
                st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid)
                if isinstance(st, dict) and str(st.get("sort") or "").strip():
                    sort_key = str(st.get("sort") or "title").strip().lower()
                    sort_dir = str(st.get("sort_dir") or pkm_library_sort.default_sort_dir(sort_key)).strip().lower()
                else:
                    stype = str(sec.get("section_type") or sec.get("type") or "").lower().strip()
                    media_kind = "tv" if stype in ("show", "tv", "tvshow", "series", "episode", "season") else "movie"
                    sort_key = pkm_library_sort.normalize_sort_key(default_sort, media_kind=media_kind)
                    sort_dir = default_dir if default_dir in ("asc", "desc") else pkm_library_sort.default_sort_dir(sort_key)
                if sort_dir not in ("asc", "desc"):
                    sort_dir = pkm_library_sort.default_sort_dir(sort_key)
                key = self._section_cache_key(sid, sort_key, sort_dir) + ":genre="
                rows = list(self._section_rows_cache.get(key) or [])
                snaps = list(self._library_render_snapshots_v2473.get(key) or [])
                if (rows and len(snaps) == len(rows)) or authoritative_empty_v2484:
                    completed += 1
                else:
                    rows_reused_v2487 = bool(rows)
                    if not rows:
                        limit = max(1, int(self._library_wall_initial_bound_count_v2077()))
                        rows = list(self._query_library_wall_rows_v1870(
                            sid, sort=sort_key, sort_dir=sort_dir, limit=limit, offset=0,
                            random_seed=self._wall_random_seed_v1644, genre=None,
                        ) or [])
                    if not rows:
                        if authoritative_empty_v2484:
                            completed += 1
                        else:
                            # Unknown is not empty; known-nonempty without rows is
                            # also a startup preparation failure.
                            failed.append(sid)
                    else:
                        total_value = int(self._section_total_cache.get(key, 0) or 0)
                        if total_value <= 0:
                            if rows_reused_v2487:
                                total_value = max(total_hint, len(rows))
                            else:
                                queried_total = self._query_library_wall_total_v1870(sid, genre=None)
                                total_value = int(queried_total) if queried_total is not None else max(total_hint, len(rows))
                        try:
                            self._preload_visible_row_ratings(rows, reason="startup_library_presentation_refresh_v2487:%s" % sid)
                        except Exception:
                            pass
                        snaps = self._library_render_snapshots_from_rows_v2476(rows)
                        if rows_reused_v2487:
                            _log("STARTUP_PRESENTATION_REFRESH_V2487 kind=library section=%s rows=%d data_recompose=0 wall_query=0" % (sid, len(rows)))
                        if len(snaps) != len(rows):
                            failed.append(sid)
                        else:
                            index_rows = list(self._section_index_rows_for_section(sid) or [])
                            title = _display_library_title(sec.get("title") or sec.get("name") or sid)
                            self._section_rows_cache[key] = list(rows)
                            self._section_total_cache[key] = int(total_value)
                            self._library_render_snapshots_v2473[key] = list(snaps)
                            self._library_post_reveal_data_warm_keys_v2472.add(key)
                            self._library_persistent_hit_keys_v2470.add(key)
                            self._section_last_library_state_by_sid_v2471[sid] = {
                                "sort": sort_key, "sort_dir": sort_dir, "cache_key": key
                            }
                            ok = self._library_persistent_scene_store_v2470(
                                key, sid, title, total_value, rows,
                                sort_key=sort_key, sort_dir=sort_dir, genre="",
                                index_rows=index_rows, render_snapshots_v2476=snaps,
                            )
                            if ok:
                                completed += 1
                            else:
                                failed.append(sid)
                _log("STARTUP_PREPARE_LIBRARY_SECTION_V2477 section=%s ready=%d key=%s rows=%d index=%d total=%d native_listitems=0 authority=%s" % (
                    sid, 0 if sid in failed else 1, key,
                    len(self._section_rows_cache.get(key) or []), idx + 1, total_sections,
                    str(authority or "")[:12]
                ))
            except Exception:
                failed.append(sid)
                _log("STARTUP_PREPARE_LIBRARY_FAILED_V2477 section=%s err=%s" % (
                    sid, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            progress = 55 + int(((idx + 1) * 30) / max(1, total_sections))
            self._startup_prepare_status_v2477(
                getattr(self, "_startup_prepare_display_text_v2482", "") or "화면을 준비 중입니다",
                progress=progress,
            )
        try:
            self._section_tab_state_store_v2471(reason="startup_logo_prepare_v2477")
        except Exception:
            pass
        return completed, failed

    def _start_startup_prepare_v2477(self, reason=""):
        if not bool(getattr(self, "_startup_prepare_required_v2477", False)):
            self._startup_prepare_done_event_v2477.set()
            self._startup_scene_composed_event_v1841.set()
            return False
        if bool(getattr(self, "_startup_prepare_running_v2477", False)):
            return True
        self._startup_prepare_running_v2477 = True
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Startup.PrepareRunningR59", "1")
        except Exception:
            pass
        generation = int(getattr(self, "_lifecycle_generation_v1841", 0) or 0)
        sections = [dict(sec) for sec in list(getattr(self, "sections", []) or [])
                    if isinstance(sec, dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
        first_state = self._startup_prepare_state_load_v2477()
        display_text = (
            getattr(self, "_startup_prepare_display_text_v2482", "")
            or ("라이브러리를 구성 중입니다" if not first_state else "화면을 준비 중입니다")
        )
        self._startup_prepare_display_text_v2482 = display_text
        self._startup_prepare_status_v2477(display_text, progress=30)

        def _worker():
            started = _pkm_speed_ms()
            rec_completed = lib_completed = 0
            rec_failed = []
            lib_failed = []
            try:
                _log("STARTUP_PREPARE_BEGIN_V2492 reason=%s sections=%d home_release_blocked=1 selective_skip_ready=1 native_existing_reuse=1" % (
                    reason or "", len(sections)
                ))
                complete = False
                total = rec_ready = lib_ready = 0
                authority = ""
                # v2482: transient cache/write races do not release an incomplete
                # Home.  Up to three passes are allowed under the opaque logo;
                # each later pass skips already-ready sections.
                for attempt_v2482 in range(1, 4):
                    if not self._worker_alive_v1841(generation):
                        return
                    # v2507: compose exactly the same snapshots as before, but do
                    # not rewrite the full section/library JSON file after every
                    # section. Two atomic flushes happen after the batch.
                    batch_flush_ok_v2507 = False
                    self._startup_persist_batch_active_v2507 = True
                    try:
                        rec_completed, rec_failed = self._startup_prepare_recommend_all_v2477(sections, generation)
                        lib_completed, lib_failed = self._startup_prepare_library_all_v2477(sections, generation)
                    finally:
                        self._startup_persist_batch_active_v2507 = False
                        batch_flush_ok_v2507 = self._startup_persistent_cache_flush_v2507()
                    total, rec_ready, lib_ready, _nonempty = self._startup_prepare_readiness_v2477()
                    authority = self._persistent_selected_section_authority_combined_v2489()
                    # Final readiness is authoritative. Persistence is also part
                    # of the startup contract; failed batch flush never releases
                    # Home merely because process-local snapshots are complete.
                    complete = bool(total > 0 and rec_ready == total and lib_ready == total and batch_flush_ok_v2507)
                    _log("STARTUP_PREPARE_VERIFY_V2507 attempt=%d sections=%d recommend_ready=%d library_ready=%d transient_rec_failed=%d transient_lib_failed=%d batch_flush_ok=%d complete=%d home_release_unblocked=0" % (
                        attempt_v2482, total, rec_ready, lib_ready, len(set(rec_failed)), len(set(lib_failed)),
                        1 if batch_flush_ok_v2507 else 0, 1 if complete else 0
                    ))
                    if complete:
                        break
                    if attempt_v2482 < 3:
                        self._startup_prepare_status_v2477(
                            self._startup_prepare_display_text_v2482 or display_text,
                            progress=min(87, 82 + attempt_v2482),
                        )
                        if self._closing_event_v1841.wait(0.35):
                            return

                self._startup_prepare_result_v2477 = {
                    "complete": complete,
                    "sections": total,
                    "recommend_ready": rec_ready,
                    "library_ready": lib_ready,
                    "recommend_failed": list(rec_failed),
                    "library_failed": list(lib_failed),
                }
                if complete:
                    sig, ids = self._startup_prepare_selected_signature_v2477()
                    state_stored_cumulative = bool(self._startup_prepare_state_store_v2477(
                        authority, rec_ready, lib_ready, ids
                    ))
                    native_ok_v2492 = self._startup_prebuild_all_native_v2492(reason="startup_prepare_complete")
                    texture_ok_v2492 = self._startup_prewarm_all_destination_textures_v2492(reason="startup_prepare_complete")
                    # The legacy native prebuild reports True for 0/0 rows.
                    # A first-install proof needs coverage of ALL selected
                    # destinations, not only equality of the processed subset.
                    native_stats_cumulative = getattr(self, '_startup_native_prebuild_stats_v2492', {}) or {}
                    texture_stats_cumulative = getattr(self, '_startup_texture_prewarm_stats_v2492', {}) or {}
                    expected_destinations_cumulative = len(ids)
                    native_coverage_cumulative = bool(
                        expected_destinations_cumulative > 0
                        and int(native_stats_cumulative.get('recommend') or 0) >= expected_destinations_cumulative
                        and int(native_stats_cumulative.get('library') or 0) >= expected_destinations_cumulative
                        and int(native_stats_cumulative.get('recommend_total') or 0) >= expected_destinations_cumulative
                        and int(native_stats_cumulative.get('library_total') or 0) >= expected_destinations_cumulative
                    )
                    texture_coverage_cumulative = bool(
                        int(texture_stats_cumulative.get('recommend') or 0) >= expected_destinations_cumulative
                        and int(texture_stats_cumulative.get('library') or 0) >= expected_destinations_cumulative
                        and int(texture_stats_cumulative.get('ready') or 0) >= expected_destinations_cumulative * 2
                        and int(texture_stats_cumulative.get('failed') or 0) == 0
                    )
                    native_ok_v2492 = bool(native_ok_v2492 and native_coverage_cumulative)
                    texture_ok_v2492 = bool(texture_ok_v2492 and texture_coverage_cumulative)
                    _log('INITIAL_PREPARATION_DESTINATION_COVERAGE selected=%d native_recommend=%d native_library=%d texture_recommend=%d texture_library=%d native_ok=%d texture_ok=%d' % (
                        expected_destinations_cumulative,
                        int(native_stats_cumulative.get('recommend') or 0),
                        int(native_stats_cumulative.get('library') or 0),
                        int(texture_stats_cumulative.get('recommend') or 0),
                        int(texture_stats_cumulative.get('library') or 0),
                        1 if native_ok_v2492 else 0, 1 if texture_ok_v2492 else 0
                    ))
                    if state_stored_cumulative and native_ok_v2492 and texture_ok_v2492:
                        # R61: hydrate persisted actor profiles before marking the
                        # destination snapshot. This is disk-only and never touches
                        # Kodi GUI controls from the preparation worker.
                        try:
                            _r61_actor_pages = self._startup_hydrate_actor_caches_v2480(
                                reason="initial_prepare_before_snapshot_proof_r61")
                            _log("INITIAL_PREPARATION_ACTOR_CACHE_R61 pages=%d scope=disk_only" % int(_r61_actor_pages or 0))
                        except Exception:
                            _log("INITIAL_PREPARATION_ACTOR_CACHE_R61 error=%s" % (
                                traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                        # R63: on first install, fetch portraits from the initial
                        # viewports of every selected recommendation and library
                        # sidebar destination. Missing portraits are valid.
                        _r64_cast_ok = self._startup_all_sidebar_cast_images_r63()
                        if not _r64_cast_ok:
                            _log("R64_CAST_PREP_INCOMPLETE marker_held=1", xbmc.LOGWARNING)
                        if _r64_cast_ok and self._startup_snapshot_bootstrap_marker_store_v2490(reason="full_destinations_verified"):
                            if not self._startup_initial_prepare_mark_cumulative(reason="full_destinations_verified"):
                                _log("R65_INITIAL_PROOF_NOT_COMMITTED reason=portrait_proof_failed", xbmc.LOGWARNING)
                    else:
                        _log("INITIAL_PREPARATION_MARKER_HELD state=%d native=%d texture=%d" % (
                            1 if state_stored_cumulative else 0,
                            1 if native_ok_v2492 else 0, 1 if texture_ok_v2492 else 0
                        ), xbmc.LOGERROR)
                    _log("STARTUP_DESTINATION_FINALIZE_V2492 native_ok=%d texture_ok=%d before_home_release=1" % (1 if native_ok_v2492 else 0, 1 if texture_ok_v2492 else 0))
                    self._post_reveal_all_sections_prewarm_done_v1649 = True
                    self._post_reveal_library_data_warm_done_v2472 = True
                    self._auto_snapshot_done_v2476 = True
                    _native_texture_proved_cumulative = bool(
                        native_ok_v2492 and texture_ok_v2492
                        and self._startup_initial_prepare_verified_cumulative()
                    )
                    self._startup_prepare_required_v2477 = not _native_texture_proved_cumulative
                    if _native_texture_proved_cumulative:
                        self._startup_prepare_done_event_v2477.set()
                    else:
                        self._startup_prepare_done_event_v2477.clear()
                    # V2495: snapshot completeness alone is not enough.  Current-process
                    # native targets and first-viewport poster proof are part of the same
                    # pre-Home contract.
                    destination_ok_v2495 = bool(
                        native_ok_v2492 and texture_ok_v2492
                        and self._startup_initial_prepare_verified_cumulative()
                    )
                    if destination_ok_v2495:
                        self._startup_scene_composed_event_v1841.set()
                    else:
                        self._startup_scene_composed_event_v1841.clear()
                        self._startup_force_slow_notice_if_due_v2494("포스터 이미지를 준비 중입니다", "startup_texture_prewarm")
                    _startup_progress_v1845(88, reason="startup_prepare_complete_v2482")
                    self._startup_prepare_done_at_ms_v2534 = int(time.time() * 1000.0)
                    _log("STARTUP_PREPARE_DONE_V2495 sections=%d recommend_ready=%d library_ready=%d recommend_failed=%d library_failed=%d complete=1 native_ok=%d texture_ok=%d home_release_unblocked=%d selective=1 post_reveal_repair=0 total_ms=%d" % (
                        total, rec_ready, lib_ready, len(set(rec_failed)), len(set(lib_failed)),
                        1 if native_ok_v2492 else 0, 1 if texture_ok_v2492 else 0,
                        1 if destination_ok_v2495 else 0, _pkm_speed_ms() - started
                    ))
                    try:
                        _gate_v2534 = int(getattr(self, "_startup_gate_started_ms_v2495", 0) or 0)
                        _elapsed_v2534 = max(0, int(self._startup_prepare_done_at_ms_v2534) - _gate_v2534) if _gate_v2534 > 0 else -1
                        _log("STARTUP_PHASE_TIMING_V2534 phase=selective_prepare_complete elapsed_from_gate_ms=%d prepare_worker_ms=%d cause=%s" % (
                            _elapsed_v2534, _pkm_speed_ms() - started, str(getattr(self, "_startup_prepare_cause_v2487", "") or "unknown")
                        ))
                    except Exception:
                        pass
                    if not destination_ok_v2495:
                        self._startup_acceptance_log_v2494r3(
                            result="FAIL", stage="startup_prepare_destination",
                            reason="snapshot_complete_but_native_or_texture_incomplete", wait_ms=_pkm_speed_ms() - started, final=0
                        )
                else:
                    # Fail closed visually.  Exposing Home here recreates the
                    # first-visit cold/spinner problem the startup barrier exists
                    # to prevent.  Keep the logo and publish an actionable status.
                    self._startup_prepare_required_v2477 = True
                    fail_text_v2482 = "초기 준비를 완료하지 못했습니다. Kodi를 재시작해 주세요."
                    self._startup_prepare_status_v2477(fail_text_v2482, progress=87)
                    _log("STARTUP_PREPARE_BLOCKED_V2482 sections=%d recommend_ready=%d library_ready=%d complete=0 home_release_unblocked=0 retry_next_start=1 total_ms=%d" % (
                        total, rec_ready, lib_ready, _pkm_speed_ms() - started
                    ), xbmc.LOGERROR)
                    self._startup_acceptance_log_v2494r3(
                        result="FAIL", stage="snapshot_prepare",
                        reason="snapshot_prepare_incomplete_after_3_attempts",
                        wait_ms=_pkm_speed_ms() - started, final=1
                    )
            except Exception:
                self._startup_prepare_required_v2477 = True
                fail_text_v2482 = "초기 준비를 완료하지 못했습니다. Kodi를 재시작해 주세요."
                self._startup_prepare_status_v2477(fail_text_v2482, progress=87)
                _log("STARTUP_PREPARE_FATAL_V2482 home_release_unblocked=0 retry_next_start=1 err=%s" % (
                    traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGERROR)
                self._startup_acceptance_log_v2494r3(
                    result="FAIL", stage="snapshot_prepare_fatal",
                    reason="snapshot_prepare_exception", wait_ms=_pkm_speed_ms() - started, final=1
                )
            finally:
                self._startup_prepare_running_v2477 = False
                try:
                    xbmcgui.Window(10000).clearProperty("PlexKM.Startup.PrepareRunningR59")
                except Exception:
                    pass
                if bool(getattr(self, "_initial_compose_r57_active", False)):
                    self._initial_compose_r57_end(reason="prepare_worker_exit")

        _PKMHomeThreadV2151(target=_worker, name="PlexKMStartupPrepareV2477", daemon=True).start()
        return True

    def _li_from_render_snapshot_v2473(self, row, snapshot, row_title="", row_type="", row_first=False, row_id="", row_start=-1, row_index=-1):
        """Create a Kodi ListItem from already-computed display properties only."""
        try:
            values = tuple(row or ())
            if len(values) < 21 or not isinstance(snapshot, dict):
                return None
            rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = values[:21]
            parent_rating_key = values[21] if len(values) > 21 else ""
            grandparent_rating_key = values[22] if len(values) > 22 else ""
            props = dict(snapshot.get("props") or {})
            if part_key and plex_type in ("movie", "episode"):
                url = _pkm_play_url(rating_key, part_key, mode="start")
            elif plex_type == "show":
                url = core.build_plugin_url({"action":"show","rating_key":rating_key,"section_id":section_id})
            else:
                url = core.build_plugin_url({"action":"noop"})
            li = xbmcgui.ListItem(label=str(snapshot.get("label") or title or ""), path=url)
            try:
                li.setPath(url)
            except Exception:
                pass
            mediatype = kodi_type or ("tvshow" if plex_type in ("show", "season") else plex_type or "video")
            info = {
                "title": title or "", "sorttitle": sort_title or title or "", "originaltitle": original_title or "",
                "year": _safe_int(year, 0), "plot": summary or props.get("Summary") or "", "duration": _safe_int(duration, 0),
                "mediatype": mediatype,
            }
            if props.get("Genre"):
                info["genre"] = props.get("Genre")
            if props.get("ContentRating"):
                info["mpaa"] = props.get("ContentRating")
            if plex_type in ("episode", "season"):
                info.update({"tvshowtitle": show_title or title or "", "season": _safe_int(season, 0)})
                if plex_type == "episode":
                    info["episode"] = _safe_int(episode, 0)
            apply_video_info(li, info)
            art_map = dict(snapshot.get("art") or {})
            # v2498: V2496 could persist a local Textures13 file chosen from the
            # old poster/fanart pair.  Never trust that local display binding as
            # poster authority across restarts.  Rehydrate from the immutable
            # poster URL/properties, then materialize the exact poster again.
            poster_authority_v2498 = str(
                props.get("PosterAuthorityV2498")
                or props.get("WallPosterRemoteV1644")
                or props.get("Thumb")
                or thumb
                or ""
            ).strip()
            # Old snapshots have no typed fallback role. Their PosterFallbackArt
            # may be landscape fanart from the pre-v2498 contract, so scrub it.
            if str(props.get("PosterFallbackRoleV2498") or "").strip().lower() != "poster":
                props["PosterFallbackArt"] = ""
                props["PosterFallbackArtActive"] = ""
            if poster_authority_v2498:
                props["WallPosterDisplayV1644"] = poster_authority_v2498
                props["PosterAuthorityV2498"] = poster_authority_v2498
                props["PosterLocalSourceV2498"] = ""
            persisted_poster_v2498 = str(art_map.get("poster") or art_map.get("thumb") or "").strip()
            if poster_authority_v2498:
                if persisted_poster_v2498 and persisted_poster_v2498 != poster_authority_v2498:
                    lower_persisted_v2498 = persisted_poster_v2498.lower()
                    if not lower_persisted_v2498.startswith(("http://", "https://")):
                        _log("PERSISTENT_POSTER_LOCAL_BIND_BYPASS_V2498 rating_key=%s authority=poster persisted_local=1 action=rebind_from_authority" % str(rating_key or ""))
                art_map["poster"] = poster_authority_v2498
                art_map["thumb"] = poster_authority_v2498
                art_map["icon"] = poster_authority_v2498
                art_map["fanart"] = ""
            elif not art_map:
                art_map = {"poster":"","thumb":"","icon":"","fanart":""}
            li.setArt({str(k):str(v or "") for k,v in art_map.items()})
            for key, value in props.items():
                li.setProperty("PlexKM.%s" % str(key), str(value or ""))
            if row_title:
                li.setProperty("PlexKM.HomeRowTitle", _display_library_title(row_title))
                li.setProperty("PlexKM.HomeLayout", "1")
                li.setProperty("PlexKM.HomeRowId", str(row_id or row_title or ""))
                li.setProperty("PlexKM.HomeRowStart", str(row_start if row_start is not None else -1))
                li.setProperty("PlexKM.HomeRowIndex", str(row_index if row_index is not None else -1))
            if row_first:
                li.setProperty("PlexKM.HomeRowFirst", "1")
            if row_type:
                li.setProperty("PlexKM.HomeRowType", str(row_type))
            if part_key and plex_type in ("movie", "episode"):
                li.setProperty("IsPlayable", "true")
            return self._overlay_gate_register_r56(li, art_key="poster")
        except Exception:
            return None

    def _section_render_snapshots_from_bank_v2473(self, bank, rows_cache):
        try:
            snaps = []
            for cid in self._section_bank_row_ids_v1612(bank):
                ctrl = self.getControl(cid)
                for idx in range(int(ctrl.size())):
                    snap = self._render_snapshot_from_li_v2473(ctrl.getListItem(idx))
                    if snap:
                        snaps.append(snap)
            return snaps if len(snaps) == len(list(rows_cache or [])) else []
        except Exception:
            return []

    def _section_persistent_snapshot_native_ready_v2478(self, cache_key, rows_cache=None):
        """True only when the foreground can render entirely from persisted snapshots.

        A restart does not preserve the in-memory rating snapshot used by v1644,
        but v2473/v2476 render snapshots already contain the final rating/genre/
        certification/display properties.  When those snapshots have been
        converted to native ListItems, foreground DB/rating/canonical enrichment
        is redundant and is forbidden by the v2478 fast path.
        """
        key = str(cache_key or "")
        try:
            rows = list(rows_cache or self._section_rows_cache.get(key) or [])
            snaps = list(getattr(self, "_section_render_snapshots_v2473", {}).get(key) or [])
            groups = list(getattr(self, "_section_prebuilt_listitems_v1644", {}).get(key) or [])
            if not rows or len(snaps) != len(rows) or not groups:
                return False
            native_count = sum(len(list(group or [])) for group in groups)
            return native_count == len(rows)
        except Exception:
            return False

    def _section_snapshot_prebuild_v2473(self, cache_key, rows_cache=None):
        key = str(cache_key or "")
        try:
            if bool(getattr(self, "_section_prebuilt_listitems_v1644", {}).get(key)):
                return True
            rows = list(rows_cache or self._section_rows_cache.get(key) or [])
            snaps = list(getattr(self, "_section_render_snapshots_v2473", {}).get(key) or [])
            if not rows or len(snaps) != len(rows):
                return False
            grouped = []
            current = []
            current_id = None
            flat_i = 0
            titles = []
            for entry in rows:
                rid = entry.get("row_id") or entry.get("row_title") or "row" if isinstance(entry, dict) else "row"
                if current and rid != current_id:
                    grouped.append(current); current=[]
                if not current:
                    titles.append(_display_library_title(entry.get("row_title", "") if isinstance(entry, dict) else ""))
                current_id = rid
                snap = snaps[flat_i]; flat_i += 1
                li = self._li_from_render_snapshot_v2473(
                    entry.get("row") if isinstance(entry, dict) else entry, snap,
                    row_title=_display_library_title(entry.get("row_title", "") if isinstance(entry, dict) else ""),
                    row_type=entry.get("row_type", "") if isinstance(entry, dict) else "",
                    row_first=(len(current) == 0),
                    row_id=entry.get("row_id", "") if isinstance(entry, dict) else "",
                    row_start=0, row_index=len(current),
                )
                if not li:
                    return False
                current.append(li)
            if current:
                grouped.append(current)
            self._li_release_r118(self._section_prebuilt_listitems_v1644.get(key))
            self._section_prebuilt_listitems_v1644[key] = grouped
            self._section_prebuilt_titles_v1644[key] = titles
            self._section_startup_prebuilt_keys_v2469.add(key)
            _log("SECTION_RENDER_SNAPSHOT_PREBUILD_V2473 key=%s rows=%d groups=%d spinner=0 db_io=0 rating_preload=0" % (key, len(rows), len(grouped)))
            return True
        except Exception:
            return False

    def _library_snapshot_prebuild_v2473(self, cache_key, section_id="", limit_v2588=0, skip_index_v2588=False):
        key = str(cache_key or "")
        try:
            if bool(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(key)):
                return True
            rows = list(self._section_rows_cache.get(key) or [])
            snaps = list(getattr(self, "_library_render_snapshots_v2473", {}).get(key) or [])
            if not rows or len(snaps) != len(rows):
                return False
            full_count_v2588 = len(rows)
            build_limit_v2588 = max(0, int(limit_v2588 or 0))
            if build_limit_v2588 > 0:
                build_count_v2588 = min(full_count_v2588, build_limit_v2588)
                build_rows_v2588 = rows[:build_count_v2588]
                build_snaps_v2588 = snaps[:build_count_v2588]
            else:
                build_count_v2588 = full_count_v2588
                build_rows_v2588 = rows
                build_snaps_v2588 = snaps
            prepared = []
            for row, snap in zip(build_rows_v2588, build_snaps_v2588):
                li = self._li_from_render_snapshot_v2473(row.get("row") if isinstance(row, dict) else row, snap)
                if not li:
                    return False
                prepared.append(li)
            # R55: 왓챠/씨네21 sort line for persisted first-paint snapshots.  The
            # sort comes from the cache key ("1|sort=watcha|..."), because
            # self.sort is switched only after this prebuild.
            try:
                _m_r55 = re.search(r"\|sort=([a-z0-9_]+)\|", key)
                _sort_r55 = _m_r55.group(1) if _m_r55 else ""
                if _sort_r55 in ("watcha", "cine21") and prepared:
                    _keys_r55 = [str(li_r55.getProperty("PlexKM.RatingKey") or "") for li_r55 in prepared]
                    _txt_r55 = getattr(_ensure_core(), "wall_provider_display_for_keys_r55")(
                        section_id or "", _sort_r55, _keys_r55) or {}
                    for li_r55, k_r55 in zip(prepared, _keys_r55):
                        v_r55 = _txt_r55.get(k_r55, "")
                        li_r55.setProperty("PlexKM.WallSortLine", v_r55)
                        li_r55.setProperty("PlexKM.WallMetaLine", v_r55)
            except Exception:
                pass
            self._li_release_r118(self._library_prebuilt_listitems_v2470.get(key), self._library_prebuilt_indexitems_v2470.get(key))
            self._library_prebuilt_listitems_v2470[key] = prepared
            sid = str(section_id or "")
            if sid and sid in self._section_index_cache and not bool(skip_index_v2588):
                self._library_prebuilt_indexitems_v2470[key] = self._library_index_listitems_from_rows_v2470(self._section_index_cache.get(sid) or [])
            if build_limit_v2588 > 0:
                _log("LIBRARY_RENDER_SNAPSHOT_PARTIAL_PREBUILD_V2588 key=%s section=%s built=%d full_rows=%d index_native_prebuild=%d firstpaint_only=1" % (
                    key, sid, len(prepared), full_count_v2588, 0 if bool(skip_index_v2588) else 1
                ))
            else:
                _log("LIBRARY_RENDER_SNAPSHOT_PREBUILD_V2473 key=%s section=%s listitems=%d spinner=0 db_io=0 rating_preload=0" % (key, sid, len(prepared)))
            return True
        except Exception:
            return False

    def _startup_prebuild_all_native_v2492(self, reason=""):
        """GUI-thread materialization of every already-complete selected snapshot.

        No DB/rating/network work is allowed here. Persistent snapshots are the
        restart-safe source; this only removes per-focus ListItem construction from
        normal sidebar/tab transitions in the current Kodi process.
        """
        started = _pkm_speed_ms()
        rec_ok = lib_ok = rec_total = lib_total = 0
        try:
            try:
                self._section_tab_state_load_v2471()
            except Exception:
                pass
            sections = [dict(sec) for sec in list(getattr(self, "sections", []) or [])
                        if isinstance(sec, dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
            for sec in sections:
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                if not sid:
                    continue
                rec_key = "recommend:%s" % sid
                rec_rows = list(getattr(self, "_section_rows_cache", {}).get(rec_key) or [])
                rec_snaps = list(getattr(self, "_section_render_snapshots_v2473", {}).get(rec_key) or [])
                if rec_rows and len(rec_snaps) == len(rec_rows):
                    rec_total += 1
                    if self._section_snapshot_prebuild_v2473(rec_key, rec_rows):
                        rec_ok += 1

                st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid)
                lib_key = str((st or {}).get("cache_key") or "").strip() if isinstance(st, dict) else ""
                if lib_key:
                    lib_rows = list(getattr(self, "_section_rows_cache", {}).get(lib_key) or [])
                    lib_snaps = list(getattr(self, "_library_render_snapshots_v2473", {}).get(lib_key) or [])
                    if lib_rows and len(lib_snaps) == len(lib_rows):
                        lib_total += 1
                        if self._library_snapshot_prebuild_v2473(lib_key, sid):
                            lib_ok += 1
            self._startup_native_prebuild_done_v2492 = bool(rec_ok == rec_total and lib_ok == lib_total)
            self._startup_native_prebuild_stats_v2492 = {
                "recommend": rec_ok, "recommend_total": rec_total,
                "library": lib_ok, "library_total": lib_total,
            }
            _log("STARTUP_NATIVE_PREBUILD_ALL_V2492 reason=%s recommend=%d/%d library=%d/%d db_io=0 rating_io=0 network_io=0 total_ms=%d" % (
                reason or "", rec_ok, rec_total, lib_ok, lib_total, _pkm_speed_ms() - started
            ))
            return self._startup_native_prebuild_done_v2492
        except Exception:
            self._startup_native_prebuild_done_v2492 = False
            _log("STARTUP_NATIVE_PREBUILD_ALL_FAILED_V2492 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _startup_bind_local_poster_v2495(self, li, local_path):
        """Bind one verified local poster to an unbound/prebuilt ListItem on GUI thread."""
        try:
            local = str(local_path or "").strip()
            if not local or not self._local_poster_file_ready_v1865(local):
                return False
            fanart = str(li.getArt("fanart") or "")
            li.setArt({"poster": local, "thumb": local, "icon": local, "fanart": fanart})
            li.setProperty("PlexKM.WallPosterDisplayV1644", local)
            li.setProperty("PlexKM.WidgetPosterReadyV1644", "1")
            li.setProperty("PlexKM.ViewportTextureV1866", "1")
            li.setProperty("PlexKM.PosterMissingV1963", "")
            li.setProperty("PlexKM.PosterMissingReasonV1963", "")
            li.setProperty("PlexKM.LibraryInitialAtomicV1868", "1")
            return True
        except Exception:
            return False

    def _startup_bind_local_poster_v2498(self, li, local_path, source=""):
        """Bind only a verified portrait file; clear legacy landscape fallback."""
        try:
            local = str(local_path or "").strip()
            if not local or not self._local_portrait_poster_file_ready_v2498(local):
                return False
            if not self._startup_bind_local_poster_v2495(li, local):
                return False
            li.setProperty("PlexKM.PosterFallbackArt", "")
            li.setProperty("PlexKM.PosterFallbackArtActive", "")
            li.setProperty("PlexKM.PosterFallbackRoleV2498", "")
            li.setProperty("PlexKM.PosterLocalSourceV2498", str(source or "local_portrait"))
            return True
        except Exception:
            return False

    def _startup_mark_transient_missing_poster_v2530(self, rec, reason=""):
        """Make one bounded-fetch failure render-safe for this session only.

        V2496 deliberately failed the whole Home gate when a single first-paint
        poster could not be materialized.  That is safe against blank posters but
        can deadlock startup forever when Plex has one temporarily unavailable thumb.
        V2530 reuses the existing item-level missing-poster card after both bounded
        fetch passes are exhausted.  Nothing is written to the persistent snapshot or
        negative image cache, so the authoritative poster is retried on the next rebuild.
        """
        try:
            li = (rec or {}).get("li")
            if not li:
                return False
            li.setProperty("PlexKM.PosterMissingV1963", "1")
            li.setProperty("PlexKM.PosterMissingReasonV1963", "transient_startup_v2530")
            li.setProperty("PlexKM.PosterTransientMissingV2530", "1")
            li.setProperty("PlexKM.LibraryInitialAtomicV1868", "1")
            li.setProperty("PlexKM.WallPosterDisplayV1644", "")
            li.setProperty("PlexKM.PosterFallbackArt", "")
            li.setProperty("PlexKM.PosterFallbackArtActive", "")
            li.setProperty("PlexKM.PosterFallbackRoleV2498", "")
            rec["ready"] = True
            rec["source"] = "session_missing_card_v2530"
            _log("STARTUP_POSTER_FAILSOFT_ITEM_V2530 reason=%s rating_key=%s action=session_missing_card retry_next_rebuild=1 persistent_negative=0" % (
                str(reason or ""), str((rec or {}).get("rating_key") or "-")
            ), xbmc.LOGWARNING)
            return True
        except Exception:
            return False

    def _startup_prewarm_all_destination_textures_v2492(self, reason=""):
        """Verify every sidebar first viewport using the real caches PKM actually uses.

        V2493 only checked Kodi Textures13 URLs, but the first-viewport pipeline stores
        server-small posters in PKM's own deterministic local cache.  The 1st V2494-R3
        run proved the mismatch: FIRST_VIEWPORT item status reported C1/E1 while the
        batch gate still failed 39/44 destinations.  V2495 treats either Kodi texture
        proof or a real PKM-local server-small file as ready, binds local files on the
        GUI thread, and downloads only unique genuinely-missing items.  A transient
        fetch failure is never converted into a fake missing-poster placeholder.
        """
        started = _pkm_speed_ms()
        checked = ready_dest = failed_dest = 0
        rec_dest = lib_dest = 0
        item_total = item_ready = 0
        kodi_ready = local_ready = downloaded = preexisting_missing = 0
        try:
            status = str(getattr(self, "_startup_prepare_display_text_v2482", "") or "화면을 준비 중입니다")
            self._startup_prepare_status_v2477(status, progress=None)

            destinations = []
            flat_pairs = []

            def _append_destination(kind, sid, items, limit):
                nonlocal rec_dest, lib_dest, item_total
                lis = list(items or [])[:max(1, int(limit or 1))]
                if not lis:
                    return
                dest = {"kind": str(kind), "sid": str(sid or ""), "items": []}
                for li in lis:
                    try:
                        sources = tuple(self._poster_authority_sources_v2498(li) or [])
                        primary = str(sources[0] if sources else "").strip()
                        fallback = ""
                        rating_key = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                        explicit_missing = str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1"
                    except Exception:
                        primary = fallback = rating_key = ""
                        sources = tuple()
                        explicit_missing = False
                    pair_idx = len(flat_pairs)
                    flat_pairs.append(list(sources))
                    dest["items"].append({
                        "li": li, "primary": primary, "fallback": fallback,
                        "sources": sources, "rating_key": rating_key,
                        "explicit_missing": bool(explicit_missing),
                        "pair_idx": pair_idx, "ready": False, "source": "", "local_path_r98": "",
                    })
                    item_total += 1
                destinations.append(dest)
                if kind == "recommend":
                    rec_dest += 1
                else:
                    lib_dest += 1

            sections = [dict(sec) for sec in list(getattr(self, "sections", []) or [])
                        if isinstance(sec, dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
            for sec in sections:
                if self._closing_event_v1841.is_set():
                    break
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                rkey = "recommend:%s" % sid
                groups = list(getattr(self, "_section_prebuilt_listitems_v1644", {}).get(rkey) or [])
                rec_items = []
                # R95: include every prebuilt widget row and every item for
                # each selected section, not only the first visible rail.
                for group in groups:
                    rec_items.extend(list(group or []))
                _log("R95_STARTUP_ALL_WIDGET_ROWS section=%s groups=%d items=%d" % (
                    sid, len(groups), len(rec_items)))
                _append_destination("recommend", sid, rec_items, len(rec_items) or 1)

                st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid)
                lkey = str((st or {}).get("cache_key") or "").strip() if isinstance(st, dict) else ""
                # R95: all prebuilt wall items for each selected library.
                lib_items = list(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(lkey) or []) if lkey else []
                _log("R95_STARTUP_ALL_LIBRARY_WALL section=%s items=%d" % (sid, len(lib_items)))
                _append_destination("library", sid, lib_items, len(lib_items) or 1)

            checked = len(destinations)
            # V2500: on unchanged starts, exact poster authority can reuse the
            # local file that V2498 already portrait-verified on the previous
            # successful startup.  Only cache misses pay Textures13 + image
            # geometry verification again.
            verified_cache_v2500 = self._startup_verified_poster_cache_load_v2500()
            local_paths_v2496 = [""] * len(flat_pairs)
            verified_hits_v2500 = 0
            unresolved_pair_indices_v2500 = []
            unresolved_pair_sets_v2500 = []
            for _pair_idx_v2500, _sources_v2500 in enumerate(flat_pairs):
                _primary_v2500 = str((_sources_v2500 or [""])[0] or "").strip()
                _cached_local_v2500 = str((verified_cache_v2500 or {}).get(_primary_v2500) or "").strip() if _primary_v2500 else ""
                if _cached_local_v2500 and self._local_poster_file_ready_v1865(_cached_local_v2500):
                    local_paths_v2496[_pair_idx_v2500] = _cached_local_v2500
                    verified_hits_v2500 += 1
                else:
                    unresolved_pair_indices_v2500.append(_pair_idx_v2500)
                    unresolved_pair_sets_v2500.append(_sources_v2500)
            if unresolved_pair_sets_v2500:
                _resolved_miss_v2500 = self._poster_primary_local_paths_v2498(unresolved_pair_sets_v2500)
                for _sub_idx_v2500, _pair_idx_v2500 in enumerate(unresolved_pair_indices_v2500):
                    if _sub_idx_v2500 < len(_resolved_miss_v2500):
                        local_paths_v2496[_pair_idx_v2500] = str(_resolved_miss_v2500[_sub_idx_v2500] or "")
            unresolved_jobs = {}

            # V2496: cache presence is not visual readiness.  Rebind every first-paint
            # item to an actual local file path before Home can be released.
            for dest in destinations:
                for rec in dest["items"]:
                    if rec["explicit_missing"]:
                        try:
                            rec["li"].setProperty("PlexKM.PosterFallbackArt", "")
                            rec["li"].setProperty("PlexKM.PosterFallbackArtActive", "")
                            rec["li"].setProperty("PlexKM.PosterFallbackRoleV2498", "")
                            rec["li"].setProperty("PlexKM.WallPosterDisplayV1644", "")
                        except Exception:
                            pass
                        rec["ready"] = True
                        rec["source"] = "explicit_missing"
                        preexisting_missing += 1
                        item_ready += 1
                        continue
                    idx = int(rec["pair_idx"])
                    local_cached_v2496 = str(local_paths_v2496[idx] if idx < len(local_paths_v2496) else "").strip()
                    _primary_v2500 = str((rec.get("sources") or ("",))[0] or "").strip()
                    _trusted_v2500 = bool(_primary_v2500 and str((verified_cache_v2500 or {}).get(_primary_v2500) or "").strip() == local_cached_v2496)
                    _bound_v2500 = False
                    if local_cached_v2496:
                        if _trusted_v2500:
                            _bound_v2500 = self._startup_bind_trusted_local_poster_v2500(rec["li"], local_cached_v2496)
                        else:
                            _bound_v2500 = self._startup_bind_local_poster_v2498(rec["li"], local_cached_v2496, source="textures13_exact_poster")
                    if _bound_v2500:
                        rec["local_path_r98"] = local_cached_v2496
                        rec["ready"] = True
                        rec["source"] = "verified_authority_cache_v2500" if _trusted_v2500 else "kodi_cached_local_v2496"
                        kodi_ready += 1
                        item_ready += 1
                        continue
                    small_url = ""
                    try:
                        small_url = self._viewport_poster_url_v1937(rec["sources"], rating_key=rec["rating_key"])
                    except Exception:
                        small_url = ""
                    local = self._wall_poster_local_path_v1644(small_url) if small_url else ""
                    if local and self._local_poster_file_ready_v1865(local):
                        bound = self._startup_bind_local_poster_v2498(rec["li"], local, source="pkm_server_small_poster")
                        if bound:
                            rec["ready"] = True
                            rec["source"] = "pkm_local_small"
                            local_ready += 1
                            item_ready += 1
                            continue
                    # Unique job key: server-small URL when possible; otherwise rating/source tuple.
                    key = small_url or ("rk:%s|%s" % (rec["rating_key"], "|".join(rec["sources"])))
                    unresolved_jobs.setdefault(key, {"small_url": small_url, "records": [], "sources": rec["sources"], "rating_key": rec["rating_key"]})["records"].append(rec)

            self._initial_compose_r57_posters(item_ready, item_total)

            def _fetch_one(job, timeout_sec):
                if self._closing_event_v1841.is_set():
                    return ""
                try:
                    small_url = str(job.get("small_url") or "").strip()
                    if small_url:
                        local = self._wall_poster_download_bounded_v1862(
                            small_url, timeout_sec=max(0.8, float(timeout_sec)),
                            max_bytes=2 * 1024 * 1024,
                            priority=pkm_artwork_scheduler.PRIORITY_FOREGROUND,
                            cancel_check=lambda: self._closing_event_v1841.is_set(),
                        )
                        if local and self._local_poster_file_ready_v1865(local):
                            return local
                    # Last resort: existing helper may reuse an already-valid original.
                    return self._resolve_visible_poster_sources_server_small_v1937(
                        job.get("sources") or (), rating_key=job.get("rating_key") or "",
                        timeout_sec=max(0.8, float(timeout_sec)),
                        cancel_check=lambda: self._closing_event_v1841.is_set(),
                    ) or ""
                except Exception:
                    return ""

            # Two bounded passes, deduplicated across Recommendation/Library duplicates.
            pending = dict(unresolved_jobs)
            for attempt, timeout_sec in ((1, 2.2), (2, 3.2)):
                if not pending or self._closing_event_v1841.is_set():
                    break
                self._startup_force_slow_notice_if_due_v2494("포스터 이미지를 준비 중입니다", "startup_texture_prewarm")
                next_pending = {}
                workers = min(2 if self._is_android_v2591() else 6, max(1, len(pending)))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    futures = {executor.submit(_fetch_one, job, timeout_sec): key for key, job in pending.items()}
                    for future in as_completed(futures):
                        key = futures[future]
                        job = pending[key]
                        try:
                            local = str(future.result() or "").strip()
                        except Exception:
                            local = ""
                        if local and self._local_poster_file_ready_v1865(local):
                            failed_records = []
                            bound_any = False
                            for rec in job["records"]:
                                # These ListItems were created on the GUI thread and are not
                                # yet attached to visible controls; binding happens here, after
                                # worker I/O is complete, never from the worker itself.
                                bound = self._startup_bind_local_poster_v2498(rec["li"], local, source="downloaded_poster_only")
                                rec["ready"] = bool(bound)
                                rec["source"] = "downloaded_local" if bound else "bind_failed"
                                if bound:
                                    rec["local_path_r98"] = local
                                    item_ready += 1
                                    bound_any = True
                                else:
                                    failed_records.append(rec)
                            if bound_any:
                                downloaded += 1
                                self._initial_compose_r57_posters(item_ready, item_total)
                            if failed_records:
                                retry_job = dict(job)
                                retry_job["records"] = failed_records
                                next_pending[key] = retry_job
                        else:
                            next_pending[key] = job
                pending = next_pending
                _log("STARTUP_TEXTURE_FETCH_PASS_V2495 attempt=%d unique_pending=%d unique_remaining=%d timeout_ms=%d" % (
                    attempt, len(futures), len(pending), int(timeout_sec * 1000.0)
                ))

            # v2531: diagnose the exact authority state before v2530 fail-soft.
            # This is intentionally metadata-only logging: no extra network I/O and
            # no token-bearing URLs are emitted.  source_count=0 means the ListItem
            # supplied no captured poster authority and V1937 had to synthesize the
            # canonical /library/metadata/<ratingKey>/thumb route.
            if pending and not self._closing_event_v1841.is_set():
                for _diag_job_v2531 in list(pending.values()):
                    try:
                        _diag_rk_v2531 = str(_diag_job_v2531.get("rating_key") or "-").strip()
                        _diag_sources_v2531 = [str(v or "").strip() for v in list(_diag_job_v2531.get("sources") or []) if str(v or "").strip()]
                        _diag_source_count_v2531 = len(_diag_sources_v2531)
                        _diag_route_v2531 = "captured_authority" if _diag_source_count_v2531 else "synthesized_ratingkey_thumb"
                        _diag_source_paths_v2531 = []
                        for _diag_src_v2531 in _diag_sources_v2531[:3]:
                            try:
                                _diag_parsed_v2531 = urlsplit(_diag_src_v2531)
                                _diag_path_v2531 = str(_diag_parsed_v2531.path or _diag_src_v2531).strip()
                            except Exception:
                                _diag_path_v2531 = ""
                            if _diag_path_v2531:
                                _diag_source_paths_v2531.append(_diag_path_v2531[:180])
                        _diag_small_v2531 = str(_diag_job_v2531.get("small_url") or "").strip()
                        _diag_small_path_v2531 = ""
                        _diag_nested_path_v2531 = ""
                        if _diag_small_v2531:
                            try:
                                _diag_small_parts_v2531 = urlsplit(_diag_small_v2531)
                                _diag_small_path_v2531 = str(_diag_small_parts_v2531.path or "")[:180]
                                _diag_q_v2531 = dict(parse_qsl(_diag_small_parts_v2531.query or "", keep_blank_values=True))
                                _diag_nested_v2531 = str(_diag_q_v2531.get("url") or "").strip()
                                if _diag_nested_v2531:
                                    _diag_nested_path_v2531 = str(urlsplit(_diag_nested_v2531).path or _diag_nested_v2531)[:180]
                            except Exception:
                                pass
                        _log("STARTUP_POSTER_UNRESOLVED_DIAG_V2531 rating_key=%s authority_source_count=%d route=%s source_paths=%s small_path=%s nested_path=%s fetch_passes_exhausted=2 usable_local=0" % (
                            _diag_rk_v2531, _diag_source_count_v2531, _diag_route_v2531,
                            ";".join(_diag_source_paths_v2531) or "-", _diag_small_path_v2531 or "-",
                            _diag_nested_path_v2531 or "-"
                        ), xbmc.LOGWARNING)
                    except Exception:
                        pass

            # v2530: a single poster that is still unavailable after both bounded
            # fetch passes must not hold the entire PKM startup gate forever.
            # Convert only the unresolved in-memory ListItems to the existing
            # stable missing-poster card.  No persistent negative state is stored,
            # so a later rebuild retries the real Plex poster authority.
            if pending and not self._closing_event_v1841.is_set():
                failsoft_items_v2530 = 0
                failsoft_jobs_v2530 = len(pending)
                for job in list(pending.values()):
                    for rec in list(job.get("records") or []):
                        if rec.get("ready"):
                            continue
                        if self._startup_mark_transient_missing_poster_v2530(rec, reason=reason or "startup_texture_prewarm"):
                            item_ready += 1
                            failsoft_items_v2530 += 1
                if failsoft_items_v2530:
                    _log("STARTUP_TEXTURE_FAILSOFT_V2530 reason=%s jobs=%d items=%d action=release_with_stable_missing_card blank=0 live_popin=0 retry_next_rebuild=1" % (
                        reason or "", failsoft_jobs_v2530, failsoft_items_v2530
                    ), xbmc.LOGWARNING)
                pending = {}

            for dest in destinations:
                d_ready = sum(1 for rec in dest["items"] if rec.get("ready"))
                if dest["items"] and d_ready == len(dest["items"]):
                    ready_dest += 1
                else:
                    failed_dest += 1
                    missing_keys = [str(rec.get("rating_key") or "-") for rec in dest["items"] if not rec.get("ready")]
                    _log("STARTUP_DESTINATION_TEXTURE_NOT_READY_V2495 kind=%s section=%s ready=%d total=%d missing_keys=%s action=keep_unready_fail_closed" % (
                        dest["kind"], dest["sid"], d_ready, len(dest["items"]), ",".join(missing_keys[:12]) or "-"
                    ), xbmc.LOGWARNING)

            # R109: no R97 handoff to invisible pre-reveal image controls.
            self._r97_startup_texture_paths = ()

            done = bool(checked > 0 and failed_dest == 0)
            self._startup_texture_prewarm_done_v2492 = done
            self._startup_texture_prewarm_stats_v2492 = {
                "checked": checked, "ready": ready_dest, "failed": failed_dest,
                "recommend": rec_dest, "library": lib_dest, "batch_v2493": 1,
                "v2495": 1, "item_total": item_total, "item_ready": item_ready,
                "kodi_ready": kodi_ready, "local_ready": local_ready,
                "downloaded_unique": downloaded, "remaining_unique": len(pending),
            }
            self._startup_local_home_publishable_v2493 = bool(done)
            elapsed_v2498 = _pkm_speed_ms() - started
            self._startup_verified_poster_hits_v2500 = int(verified_hits_v2500)
            if done and ((not verified_cache_v2500) or unresolved_pair_sets_v2500 or downloaded):
                try:
                    self._startup_verified_poster_cache_store_v2500(destinations)
                except Exception:
                    pass
            elif done and verified_cache_v2500:
                _log("STARTUP_VERIFIED_POSTER_CACHE_STORE_SKIP_V2500 reason=authority_match_no_miss entries=%d disk_write=0" % len(verified_cache_v2500))
            _log("STARTUP_TEXTURE_PREWARM_V2500 result=%s verified_cache_hits=%d verified_cache_entries=%d full_verify_misses=%d destinations=%d items=%d total_ms=%d" % (
                "PASS" if done else "FAIL", int(verified_hits_v2500), len(verified_cache_v2500 or {}),
                len(unresolved_pair_sets_v2500), checked, item_total, elapsed_v2498
            ), xbmc.LOGINFO if done else xbmc.LOGWARNING)
            _log("STARTUP_TEXTURE_PREWARM_ALL_V2496 reason=%s destinations=%d ready=%d failed=%d items=%d item_ready=%d local_cache_bound=%d pkm_local_small=%d downloaded_unique=%d unresolved_unique=%d recommend=%d library=%d library_firstpaint=%d actual_local_required=1 total_ms=%d" % (
                reason or "", checked, ready_dest, failed_dest, item_total, item_ready,
                kodi_ready, local_ready, downloaded, len(pending), rec_dest, lib_dest,
                self._library_wall_viewport_count_v1865(), elapsed_v2498
            ), xbmc.LOGINFO if done else xbmc.LOGWARNING)
            _log("STARTUP_POSTER_PROVENANCE_ACCEPTANCE_V2498 result=%s destinations=%d ready=%d failed=%d items=%d item_ready=%d poster_only=1 fallback_art_used=0 portrait_required=1 persisted_local_bypass=1 total_ms=%d" % (
                "PASS" if done else "FAIL", checked, ready_dest, failed_dest, item_total, item_ready, elapsed_v2498
            ), xbmc.LOGINFO if done else xbmc.LOGWARNING)
            return done
        except Exception:
            self._startup_texture_prewarm_done_v2492 = False
            self._startup_local_home_publishable_v2493 = False
            _log("STARTUP_TEXTURE_PREWARM_ALL_FAILED_V2496 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _persistent_plex_items_fingerprint_v2487(self):
        """Cheap content-only combined fingerprint for startup wording.

        v2493 derives this from the already-computed section authority stats.
        It never performs a second GROUP BY scan of the large items table.
        """
        cached = str(getattr(self, "_persistent_plex_items_fp_v2487", "") or "")
        if cached:
            return cached
        try:
            _fps, stats = self._persistent_section_authority_state_v2489()
            if not stats:
                return ""
            h = hashlib.sha1()
            for sid in sorted(stats.keys()):
                st = dict(stats.get(sid) or {})
                h.update(("items|%s|%s|%s|%s\n" % (
                    sid, st.get("count", 0), st.get("max_updated", 0), st.get("max_added", 0)
                )).encode("utf-8", "replace"))
            fp = h.hexdigest()
            self._persistent_plex_items_fp_v2487 = fp
            return fp
        except Exception:
            return ""

    def _persistent_section_authority_state_v2489(self):
        """Return exact V2489 section authority using section-leading indexes.

        v2494 fixes the V2493 regression where ``sections.item_count`` was read as
        zero after the normal Plex section refresh.  COUNT/MAX are now exact local
        ``items`` proofs per selected section and use existing section-leading
        indexes, preserving the original V2489 fingerprint byte-for-byte without
        the expensive whole-table GROUP BY.
        """
        cached_fp = getattr(self, "_persistent_section_authority_map_v2489", None)
        cached_stats = getattr(self, "_persistent_section_items_stats_v2489", None)
        if isinstance(cached_fp, dict) and isinstance(cached_stats, dict):
            return cached_fp, cached_stats
        fps = {}
        stats = {}
        poison_fps_v2494 = {}
        started_v2494 = _pkm_speed_ms()
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return {}, {}

            selected = []
            for sec in list(getattr(self, "sections", []) or []):
                if not isinstance(sec, dict):
                    continue
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                if sid and sid not in selected:
                    selected.append(sid)
            if not selected:
                return {}, {}

            idx_by_sid = {}
            conn = sqlite3.connect(dbp, timeout=2.0)
            try:
                placeholders = ",".join("?" for _ in selected)
                try:
                    rows = conn.execute(
                        "SELECT section_id,item_count,people_count,genre_count,country_count "
                        "FROM item_recommend_index_state WHERE section_id IN (%s)" % placeholders, tuple(selected)
                    ).fetchall()
                except Exception:
                    rows = []
                for row in rows or []:
                    sid = str(row[0] or "").strip()
                    if sid:
                        idx_by_sid[sid] = tuple(row[1:5])

                # V2707: keep the exact V2489 count/max fingerprint, but avoid a
                # GROUP BY scan across every selected item.  The main DB already owns
                # narrow section/type and section/max indexes.  COUNT uses the covering
                # section/type index; MAX(updated/added) is an O(log N) first-row lookup.
                # If an older DB lacks any expected index, fall back to V2660 unchanged.
                item_stats_v2660 = {}
                authority_mode_v2707 = "indexed_scalar"
                authority_queries_v2707 = 0
                # R115: COUNT(*) over ~300k index rows cost ~0.7 s on SHIELD at
                # every start.  Membership (insert/delete/move) bumps the v2578
                # epoch by trigger, so an exact count cached for the same epoch
                # is still exact; only the O(log N) MAX lookups run each start.
                epochs_r115 = {}
                count_cache_r115 = {}
                count_writes_r115 = []
                count_hits_r115 = 0
                try:
                    for _row_r115 in conn.execute(
                            "SELECT section_id, epoch FROM section_membership_epoch_v2578 WHERE section_id IN (%s)" % placeholders,
                            tuple(selected)).fetchall():
                        epochs_r115[str(_row_r115[0] or "")] = int(_row_r115[1] or 0)
                    for _row_r115 in conn.execute(
                            "SELECT section_id, epoch, item_count FROM section_count_cache_r115 WHERE section_id IN (%s)" % placeholders,
                            tuple(selected)).fetchall():
                        count_cache_r115[str(_row_r115[0] or "")] = (int(_row_r115[1] or 0), int(_row_r115[2] or 0))
                except Exception:
                    pass
                try:
                    for sid_v2707 in selected:
                        _ep_r115 = int(epochs_r115.get(str(sid_v2707), 0) or 0)
                        _hit_r115 = count_cache_r115.get(str(sid_v2707))
                        if _ep_r115 > 0 and _hit_r115 is not None and _hit_r115[0] == _ep_r115:
                            _mx_r115 = conn.execute(
                                "SELECT "
                                "COALESCE((SELECT updated_at FROM items INDEXED BY idx_items_section_updated WHERE section_id=? ORDER BY updated_at DESC LIMIT 1),0),"
                                "COALESCE((SELECT added_at FROM items WHERE section_id=? ORDER BY added_at DESC LIMIT 1),0)",
                                (sid_v2707, sid_v2707),
                            ).fetchone()
                            stat_v2707 = (_hit_r115[1], _mx_r115[0], _mx_r115[1]) if _mx_r115 is not None else None
                            count_hits_r115 += 1
                        else:
                            stat_v2707 = conn.execute(
                                "SELECT "
                                "(SELECT COUNT(*) FROM items INDEXED BY idx_items_type WHERE section_id=?),"
                                "COALESCE((SELECT updated_at FROM items INDEXED BY idx_items_section_updated WHERE section_id=? ORDER BY updated_at DESC LIMIT 1),0),"
                                "COALESCE((SELECT added_at FROM items WHERE section_id=? ORDER BY added_at DESC LIMIT 1),0)",
                                (sid_v2707, sid_v2707, sid_v2707),
                            ).fetchone()
                            if _ep_r115 > 0 and stat_v2707 is not None:
                                count_writes_r115.append((str(sid_v2707), _ep_r115, int(stat_v2707[0] or 0)))
                        authority_queries_v2707 += 1
                        if stat_v2707 is not None:
                            item_stats_v2660[str(sid_v2707)] = (
                                max(0, int(stat_v2707[0] or 0)),
                                str(stat_v2707[1] or "0"),
                                str(stat_v2707[2] or "0"),
                            )
                except Exception:
                    authority_mode_v2707 = "grouped_fallback"
                    authority_queries_v2707 = 1
                    item_stats_v2660 = {}
                    try:
                        stat_rows_v2660 = self._items_section_stats_fast_r115(conn, selected=selected)
                    except Exception:
                        stat_rows_v2660 = []
                    for stat_v2660 in stat_rows_v2660 or []:
                        stat_sid_v2660 = str(stat_v2660[0] or "").strip()
                        if stat_sid_v2660:
                            item_stats_v2660[stat_sid_v2660] = (
                                max(0, int(stat_v2660[1] or 0)),
                                str(stat_v2660[2] or "0"),
                                str(stat_v2660[3] or "0"),
                            )

                for sid in selected:
                    count_v2494, max_updated, max_added = item_stats_v2660.get(sid, (0, "0", "0"))
                    # GROUP BY has no row for an empty section.  Preserve the
                    # previous fail-closed rule: an index-state row proves a
                    # selected empty section, otherwise authority is unknown.
                    count_ok_v2494 = bool(sid in item_stats_v2660 or sid in idx_by_sid)

                    idx = idx_by_sid.get(sid)
                    # Match V2489 fail-closed semantics exactly. COUNT(*) always
                    # returns a row, including 0, so an empty selected section is
                    # authoritative only when the recommendation-index row exists.
                    # A positive items count is itself local membership proof.
                    if (not count_ok_v2494) or (count_v2494 <= 0 and idx is None):
                        continue
                    idx_vals = idx if idx is not None else (0, 0, 0, 0)
                    item_vals = (count_v2494, max_updated, max_added)
                    payload = (
                        "sid|%s\nidx|%s\nitems|%s\n" % (
                            sid,
                            "|".join(str(v or "") for v in idx_vals),
                            "|".join(str(v or "") for v in item_vals),
                        )
                    )
                    fps[sid] = hashlib.sha1(payload.encode("utf-8", "replace")).hexdigest()
                    stats[sid] = {
                        "count": int(count_v2494 or 0),
                        "max_updated": str(max_updated or "0"),
                        "max_added": str(max_added or "0"),
                    }

                    # Exact fingerprint emitted by broken V2493 for a non-empty
                    # section: the same index/maxima but items count forced to 0.
                    # This lets already-rebuilt V2493 snapshots migrate in place.
                    if count_v2494 > 0:
                        poison_payload_v2494 = (
                            "sid|%s\nidx|%s\nitems|%s\n" % (
                                sid,
                                "|".join(str(v or "") for v in idx_vals),
                                "|".join(str(v or "") for v in (0, max_updated, max_added)),
                            )
                        )
                        poison_fps_v2494[sid] = hashlib.sha1(poison_payload_v2494.encode("utf-8", "replace")).hexdigest()
                if count_writes_r115:
                    try:
                        conn.execute("CREATE TABLE IF NOT EXISTS section_count_cache_r115 ("
                                     "section_id TEXT PRIMARY KEY, epoch INTEGER NOT NULL, item_count INTEGER NOT NULL)")
                        conn.executemany(
                            "INSERT INTO section_count_cache_r115(section_id, epoch, item_count) VALUES(?,?,?) "
                            "ON CONFLICT(section_id) DO UPDATE SET epoch=excluded.epoch, item_count=excluded.item_count",
                            count_writes_r115)
                        conn.commit()
                    except Exception:
                        pass
                _log("PERSISTENT_SECTION_COUNT_CACHE_R115 hits=%d writes=%d" % (count_hits_r115, len(count_writes_r115)))
            finally:
                conn.close()

            self._persistent_section_authority_map_v2489 = fps
            self._persistent_section_items_stats_v2489 = stats
            self._persistent_v2493_zero_count_fp_v2494 = poison_fps_v2494
            _log("PERSISTENT_SECTION_AUTHORITY_MAP_V2707 sections=%d selected=%d mode=%s sql_calls=%d exact_count=1 exact_max_updated=1 exact_max_added=1 full_items_group_scan=%d elapsed_ms=%d ratings=0" % (
                len(fps), len(selected), str(locals().get("authority_mode_v2707", "unknown")),
                int(locals().get("authority_queries_v2707", 0) or 0),
                1 if str(locals().get("authority_mode_v2707", "")) == "grouped_fallback" else 0,
                _pkm_speed_ms() - started_v2494
            ))
            return fps, stats
        except Exception:
            _log("PERSISTENT_SECTION_AUTHORITY_MAP_FAILED_V2494 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return {}, {}

    def _persistent_v2493_zero_count_fingerprint_v2494(self, section_id):
        try:
            sid = str(section_id or "").strip()
            if not sid:
                return ""
            self._persistent_section_authority_state_v2489()
            return str((getattr(self, "_persistent_v2493_zero_count_fp_v2494", {}) or {}).get(sid) or "")
        except Exception:
            return ""

    def _persistent_section_authority_fingerprint_v2489(self, section_id):
        try:
            sid = str(section_id or "").strip()
            if not sid:
                return ""
            fps, _stats = self._persistent_section_authority_state_v2489()
            return str((fps or {}).get(sid) or "")
        except Exception:
            return ""

    def _persistent_selected_section_authority_combined_v2489(self, section_ids=None):
        """Cheap combined proof for startup state bookkeeping, not cache eviction."""
        try:
            fps, _stats = self._persistent_section_authority_state_v2489()
            ids = list(section_ids or [])
            if not ids:
                for sec in list(getattr(self, "sections", []) or []):
                    if isinstance(sec, dict):
                        sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                        if sid:
                            ids.append(sid)
            ids = [str(x or "").strip() for x in ids if str(x or "").strip()]
            if not ids or any(not str((fps or {}).get(sid) or "") for sid in ids):
                return ""
            payload = "\n".join("%s=%s" % (sid, fps[sid]) for sid in ids)
            return hashlib.sha1(payload.encode("utf-8", "replace")).hexdigest()
        except Exception:
            return ""

    def _persistent_entry_section_id_v2489(self, rec, entry_key=""):
        try:
            sid = str((rec or {}).get("section_id") or "").strip() if isinstance(rec, dict) else ""
            if sid:
                return sid
            # v2507: Info prepared-cache records historically stored SectionId
            # inside the immutable property payload rather than at record root.
            if isinstance(rec, dict) and isinstance(rec.get("props"), dict):
                sid = str((rec.get("props") or {}).get("SectionId") or "").strip()
                if sid:
                    return sid
            key = str(entry_key or "")
            if key.startswith("recommend:"):
                return key.split(":", 1)[1].strip()
            if key.startswith("library:"):
                return key.split(":", 1)[1].split("|", 1)[0].strip()
            return ""
        except Exception:
            return ""

    def _persistent_entry_upgrade_section_authority_v2489(self, rec, section_id):
        """Upgrade a V2487 entry in-place after its legacy global proof matched."""
        try:
            if not isinstance(rec, dict):
                return False
            sid = str(section_id or "").strip()
            fp = self._persistent_section_authority_fingerprint_v2489(sid)
            if not sid or not fp:
                return False
            rec["authority_model"] = "content_section_v2489"
            rec["authority_fp"] = fp
            rec["section_id"] = sid
            _log("PERSISTENT_SECTION_AUTHORITY_MIGRATE_V2489 section=%s fp=%s rows_reuse=1 rebuild=0" % (sid, fp[:12]))
            return True
        except Exception:
            return False

    def _persistent_legacy_authority_fingerprint_v2487(self):
        """Recreate the V2486 combined content+item_ratings fingerprint once.

        This exists only to migrate already-built V2486 caches without throwing
        away valid row data on the first V2487 run. New stores never use it.
        """
        cached = str(getattr(self, "_persistent_legacy_authority_fp_v2487", "") or "")
        if cached:
            return cached
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""
            started = time.time()
            h = hashlib.sha1()
            conn = sqlite3.connect(dbp, timeout=2.0)
            try:
                try:
                    rows = conn.execute(
                        "SELECT section_id,item_count,people_count,genre_count,country_count,rating_count "
                        "FROM item_recommend_index_state ORDER BY section_id"
                    ).fetchall()
                except Exception:
                    rows = []
                for row in rows or []:
                    h.update(("idx|" + "|".join(str(v or "") for v in row) + "\n").encode("utf-8", "replace"))
                try:
                    item_rows = self._items_section_stats_fast_r115(conn)
                except Exception:
                    item_rows = []
                if item_rows:
                    for row in item_rows:
                        h.update(("items|" + "|".join(str(v or "") for v in row) + "\n").encode("utf-8", "replace"))
                else:
                    fallback = conn.execute(
                        "SELECT COUNT(*),COALESCE(MAX(updated_at),0),COALESCE(MAX(added_at),0) FROM items"
                    ).fetchone() or (0, 0, 0)
                    h.update(("items|fallback|" + "|".join(str(v or "") for v in fallback) + "\n").encode("utf-8", "replace"))
                try:
                    rating_rows = conn.execute(
                        "SELECT rating_key,COALESCE(score,''),COALESCE(rating,''),"
                        "COALESCE(audience_rating,''),COALESCE(user_rating,'') "
                        "FROM item_ratings ORDER BY rating_key"
                    )
                    for row in rating_rows:
                        h.update(("rating|" + "|".join(str(v or "") for v in row) + "\n").encode("utf-8", "replace"))
                except Exception:
                    pass
            finally:
                conn.close()
            fp = h.hexdigest()
            self._persistent_legacy_authority_fp_v2487 = fp
            _log("PERSISTENT_LEGACY_AUTHORITY_FP_V2487 fp=%s elapsed_ms=%d migration_only=1" % (
                fp[:12], int((time.time() - started) * 1000.0)
            ))
            return fp
        except Exception:
            return ""

    def _persistent_presentation_quick_signature_v2487(self, dbp):
        """R112: hash rating *content*, not mutable SQLite file mtimes.

        SQLite writes to unrelated tables or WAL checkpointing must not
        invalidate every Home presentation snapshot. A genuine rating change
        must still invalidate it. This is deliberately separate from Plex
        section authority and playstate synchronization.

        R29: the R112 version sorted and repr()-hashed every row of three
        rating tables in Python: 8.7-9.7 s on SHIELD, and the first sidebar
        click waited for it on the GUI thread.  Each table is now summarised
        by one SQLite aggregate pass (no sort, no Python per row).  Values are
        weighted by rowid, so a changed score, an added/removed row or two
        rows trading values all change the signature.
        """
        try:
            h = hashlib.sha1(b"PKM_R112_RATING_CONTENT_V2_R29\n")
            conn = sqlite3.connect(dbp, timeout=2.0)
            try:
                for table in ("item_ratings", "cine21_matches", "watcha_ratings"):
                    safe = '"' + table.replace('"', '""') + '"'
                    cols = conn.execute("PRAGMA table_info(%s)" % safe).fetchall()
                    if not cols:
                        h.update((table + ':absent\n').encode('utf-8'))
                        continue
                    names = [str(c[1]) for c in cols]
                    h.update((table + ':' + ','.join(names) + '\n').encode('utf-8'))
                    parts = ["count(*)", "total(rowid)"]
                    for n in names:
                        q = '"' + n.replace('"', '""') + '"'
                        parts.append(
                            "total(CASE WHEN typeof(%s) IN ('integer','real') THEN %s * ((rowid %% 997) + 1) "
                            "WHEN %s IS NULL THEN 0 "
                            "ELSE (length(%s) * 131 + coalesce(unicode(%s), 0) + coalesce(unicode(substr(%s, -1)), 0)) "
                            "* ((rowid %% 991) + 1) END)" % (q, q, q, q, q, q)
                        )
                    row = conn.execute("SELECT %s FROM %s" % (", ".join(parts), safe)).fetchone()
                    h.update(repr(tuple(row or ())).encode('utf-8', 'replace'))
                    h.update(b'\n')
            finally:
                conn.close()
            return h.hexdigest()
        except Exception as exc:
            _log("R112_PRESENTATION_CONTENT_FINGERPRINT_ERROR err=%s" % str(exc), xbmc.LOGWARNING)
            return ''

    def _persistent_presentation_stamp_load_v2487(self):
        try:
            path = self._derived_cache_path_v2467("presentation_stamp_v2487.json")
            if not path or not os.path.exists(path):
                return {}
            with open(path, "r", encoding="utf-8") as fh:
                obj = json.load(fh)
            return obj if isinstance(obj, dict) and int(obj.get("version") or 0) == 2487 else {}
        except Exception:
            return {}

    def _persistent_presentation_stamp_store_v2487(self, quick_sig, fp):
        try:
            if not quick_sig or not fp:
                return False
            path = self._derived_cache_path_v2467("presentation_stamp_v2487.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"version":2487,"quick_sig":quick_sig,"fp":fp,"ts":time.time()}, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            return True
        except Exception:
            return False

    def _presentation_fp_prewarm_r23(self, delay_ms=5000, reason=""):
        """R23: compute the rating-content fingerprint on a background thread.

        It hashes every row of three rating tables (~5 s on SHIELD) and was
        first needed inside a library sort apply on the GUI thread.
        """
        def _run():
            try:
                xbmc.sleep(max(0, int(delay_ms or 0)))
                if str(getattr(self, "_persistent_presentation_fp_v2487", "") or ""):
                    return
                # R85: ~3 s of hashing; never while the user is moving.
                self._bg_wait_quiet_r85(quiet_ms=1500, max_s=60.0)
                if str(getattr(self, "_persistent_presentation_fp_v2487", "") or ""):
                    return
                t0 = time.time()
                fp = self._persistent_presentation_fingerprint_v2487()
                _log("R23_PRESENTATION_FP_PREWARM reason=%s ok=%d elapsed_ms=%d" % (
                    reason or "", 1 if fp else 0, int((time.time() - t0) * 1000)))
            except Exception:
                _log("R23_PRESENTATION_FP_PREWARM_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            _PKMHomeThreadV2151(target=_run, name="PKMPresentationFpR23", daemon=True).start()
        except Exception:
            pass

    def _persistent_presentation_fingerprint_v2487(self):
        """PKM_UHD_STABILITY_U1: preserve presentation invalidation without full scan."""
        cached = str(getattr(self, '_persistent_presentation_fp_v2487', '') or '')
        if cached:
            return cached
        # R29: single flight.  The R23 background prewarm and a GUI-thread
        # caller used to compute this at the same time; the caller now waits
        # for the in-flight result instead of starting a second pass.
        _wait_t0_r29 = time.time()
        with _R29_PRESENTATION_FP_LOCK:
            cached = str(getattr(self, '_persistent_presentation_fp_v2487', '') or '')
            if cached:
                _log('R29_PRESENTATION_FP_SHARED wait_ms=%d' % int((time.time() - _wait_t0_r29) * 1000))
                return cached
            return self._persistent_presentation_fingerprint_compute_r29()

    def _persistent_presentation_fingerprint_compute_r29(self):
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.isfile(dbp):
                return ''
            started = time.time()
            quick = self._persistent_presentation_quick_signature_v2487(dbp)
            if not quick:
                return ''
            stamp = self._persistent_presentation_stamp_load_v2487()
            # The U1 scheme marker prevents mixing file-state and legacy SQL
            # digest semantics across versions.
            if stamp.get('quick_sig') == 'R29:' + quick and stamp.get('fp'):
                fp = str(stamp['fp'])
            else:
                fp = hashlib.sha1(('PKM_R112_PRESENTATION|' + quick).encode('ascii')).hexdigest()
                self._persistent_presentation_stamp_store_v2487('R29:' + quick, fp)
            self._persistent_presentation_fp_v2487 = fp
            _log('R112_PRESENTATION_CONTENT_FP fp=%s elapsed_ms=%d rows_scanned=0' % (
                fp[:12], int((time.time()-started)*1000)))
            return fp
        except Exception:
            return ''

    def _items_section_stats_fast_r115(self, conn, selected=None):
        """R115: same rows as
        SELECT section_id,COUNT(*),COALESCE(MAX(updated_at),0),COALESCE(MAX(added_at),0)
        FROM items GROUP BY section_id ORDER BY section_id
        but answered from indexes. The GROUP BY form scanned every items row
        (raw_json pages, ~200k rows) and took 2-4s cold on Android devices.
        """
        if selected is not None:
            sids = [str(x) for x in selected]
            counted = []
            for sid in sids:
                n = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=?", (sid,)).fetchone()[0]
                if n:
                    counted.append((sid, n))
        else:
            # Distinct section ids by O(log N) index hops (no full index scan).
            sids = []
            has_null = conn.execute("SELECT 1 FROM items WHERE section_id IS NULL LIMIT 1").fetchone() is not None
            cur = conn.execute("SELECT MIN(section_id) FROM items WHERE section_id IS NOT NULL").fetchone()
            cur = cur[0] if cur else None
            guard = 0
            while cur is not None and guard < 2000:
                sids.append(cur)
                guard += 1
                nxt = conn.execute("SELECT MIN(section_id) FROM items WHERE section_id > ?", (cur,)).fetchone()
                cur = nxt[0] if nxt else None
            # Exact counts cached per membership epoch (insert/delete/move
            # triggers bump it), same contract as PERSISTENT_SECTION_COUNT_CACHE_R115.
            epochs = {}
            cache = {}
            try:
                for r in conn.execute("SELECT section_id, epoch FROM section_membership_epoch_v2578").fetchall():
                    epochs[str(r[0] or "")] = int(r[1] or 0)
                for r in conn.execute("SELECT section_id, epoch, item_count FROM section_count_cache_r115").fetchall():
                    cache[str(r[0] or "")] = (int(r[1] or 0), int(r[2] or 0))
            except Exception:
                pass
            counted = []
            writes = []
            if has_null:
                counted.append((None, conn.execute("SELECT COUNT(*) FROM items WHERE section_id IS NULL").fetchone()[0]))
            for sid in sids:
                ep = int(epochs.get(str(sid), 0) or 0)
                hit = cache.get(str(sid))
                if ep > 0 and hit is not None and hit[0] == ep:
                    cnt = hit[1]
                else:
                    cnt = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=?", (sid,)).fetchone()[0]
                    if ep > 0:
                        writes.append((str(sid), ep, int(cnt or 0)))
                if cnt:
                    counted.append((sid, cnt))
            if writes:
                try:
                    conn.execute("CREATE TABLE IF NOT EXISTS section_count_cache_r115 ("
                                 "section_id TEXT PRIMARY KEY, epoch INTEGER NOT NULL, item_count INTEGER NOT NULL)")
                    conn.executemany(
                        "INSERT INTO section_count_cache_r115(section_id, epoch, item_count) VALUES(?,?,?) "
                        "ON CONFLICT(section_id) DO UPDATE SET epoch=excluded.epoch, item_count=excluded.item_count",
                        writes)
                    conn.commit()
                except Exception:
                    pass
        out = []
        for sid, n in counted or []:
            if sid is None:
                u = conn.execute("SELECT COALESCE(MAX(updated_at),0) FROM items WHERE section_id IS NULL").fetchone()[0]
                a = conn.execute("SELECT COALESCE(MAX(added_at),0) FROM items WHERE section_id IS NULL").fetchone()[0]
            else:
                u = conn.execute("SELECT COALESCE(MAX(updated_at),0) FROM items WHERE section_id=?", (sid,)).fetchone()[0]
                a = conn.execute("SELECT COALESCE(MAX(added_at),0) FROM items WHERE section_id=?", (sid,)).fetchone()[0]
            out.append((sid, n, u, a))
        return out

    def _persistent_entry_content_match_v2487(self, rec, entry_key=""):
        try:
            if not isinstance(rec, dict):
                return False, "invalid"
            model = str(rec.get("authority_model") or "")
            stored = str(rec.get("authority_fp") or "")
            if model == "content_section_v2489":
                sid_v2489 = self._persistent_entry_section_id_v2489(rec, entry_key=entry_key)
                current_section_v2489 = self._persistent_section_authority_fingerprint_v2489(sid_v2489)
                if not sid_v2489 or not current_section_v2489:
                    return False, "no_section_content_fp"
                if stored == current_section_v2489:
                    return True, "section_content_match"
                bad_v2493 = self._persistent_v2493_zero_count_fingerprint_v2494(sid_v2489)
                if bad_v2493 and stored == bad_v2493:
                    rec["authority_fp"] = current_section_v2489
                    rec["authority_migrated_v2494"] = "v2493_zero_count"
                    _log("PERSISTENT_V2493_ZERO_COUNT_MIGRATE_V2494 key=%s section=%s rows_reuse=1 rebuild=0 old=%s new=%s" % (
                        str(entry_key or ""), sid_v2489, stored[:12], current_section_v2489[:12]
                    ))
                    return True, "v2493_zero_count_migrated"
                return False, "section_content_changed"
            current = self._persistent_authority_fingerprint_v2467(include_playstate=False)
            if not current:
                return False, "no_content_fp"
            if model == "content_v2487":
                return (stored == current), ("content_match" if stored == current else "content_changed")
            legacy = self._persistent_legacy_authority_fingerprint_v2487()
            if legacy and stored == legacy:
                key = str(entry_key or "legacy")
                self._startup_legacy_migration_keys_v2487.add(key)
                _log("PERSISTENT_AUTHORITY_LEGACY_MIGRATE_V2487 key=%s old_model=combined_v2486 content_match=1 rows_reuse=1" % key)
                return True, "legacy_current_match"
            return False, "legacy_or_content_changed"
        except Exception:
            return False, "error"

    def _persistent_entry_presentation_match_v2487(self, rec):
        try:
            stored = str((rec or {}).get("presentation_fp_v2487") or "")
            current = self._persistent_presentation_fingerprint_v2487()
            return bool(stored and current and stored == current)
        except Exception:
            return False

    def _persistent_authority_fingerprint_v2467(self, include_playstate=False):
        """V2487 stable *content authority* fingerprint.

        Content authority is deliberately independent from rating presentation.
        It includes synchronized recommendation membership/metadata counters and
        Plex item membership/update maxima, but excludes item_ratings, Cine21,
        Watcha, DB mtime/size, and recommendation rating_count. Rating changes are
        handled by _persistent_presentation_fingerprint_v2487() instead.
        """
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""

            db_fp = str(getattr(self, "_persistent_authority_db_fp_v2468", "") or "")
            if not db_fp:
                started_v2487 = time.time()
                quick_sig_v2473 = self._persistent_authority_quick_signature_v2473(dbp)
                stamp_v2473 = self._persistent_authority_stamp_load_v2473()
                if (quick_sig_v2473 and str(stamp_v2473.get("quick_sig") or "") == quick_sig_v2473
                        and str(stamp_v2473.get("db_fp") or "")
                        and str(stamp_v2473.get("model") or "") == "content_v2487"):
                    db_fp = str(stamp_v2473.get("db_fp") or "")
                    self._persistent_authority_db_fp_v2468 = db_fp
                    _log("PERSISTENT_CONTENT_AUTHORITY_STAMP_HIT_V2487 fp=%s elapsed_ms=%d full_scan=0" % (
                        db_fp[:12], int((time.time() - started_v2487) * 1000.0)))
            if not db_fp:
                started_v2487 = time.time()
                h_v2487 = hashlib.sha1()
                conn = sqlite3.connect(dbp, timeout=2.0)
                try:
                    try:
                        rows = conn.execute(
                            "SELECT section_id,item_count,people_count,genre_count,country_count "
                            "FROM item_recommend_index_state ORDER BY section_id"
                        ).fetchall()
                    except Exception:
                        rows = []
                    for row in rows or []:
                        h_v2487.update(("idx|" + "|".join(str(v or "") for v in row) + "\n").encode("utf-8", "replace"))

                    try:
                        item_rows = self._items_section_stats_fast_r115(conn)
                    except Exception:
                        item_rows = []
                    if item_rows:
                        for row in item_rows:
                            h_v2487.update(("items|" + "|".join(str(v or "") for v in row) + "\n").encode("utf-8", "replace"))
                    else:
                        fallback = conn.execute(
                            "SELECT COUNT(*),COALESCE(MAX(updated_at),0),COALESCE(MAX(added_at),0) FROM items"
                        ).fetchone() or (0, 0, 0)
                        h_v2487.update(("items|fallback|" + "|".join(str(v or "") for v in fallback) + "\n").encode("utf-8", "replace"))
                finally:
                    conn.close()

                db_fp = h_v2487.hexdigest()
                self._persistent_authority_db_fp_v2468 = db_fp
                try:
                    quick_sig_v2473 = self._persistent_authority_quick_signature_v2473(dbp)
                    self._persistent_authority_stamp_store_v2473(quick_sig_v2473, db_fp)
                    _log("PERSISTENT_CONTENT_AUTHORITY_STAMP_STORE_V2487 fp=%s quick=%s" % (db_fp[:12], str(quick_sig_v2473 or "")[:12]))
                except Exception:
                    pass
                _log("PERSISTENT_CONTENT_AUTHORITY_DB_FP_V2487 fp=%s elapsed_ms=%d ratings=0 cine21=0 watcha=0 db_mtime=0" % (
                    db_fp[:12], int((time.time() - started_v2487) * 1000.0)
                ))

            if not include_playstate:
                return db_fp

            # Sidebar scenes contain Continue Watching / viewed-state rows.
            # V2467 used file mtime, which changes after harmless rewrites.
            # Hash canonical JSON content instead.  Root-level cache bookkeeping
            # timestamps are ignored, while nested item progress/view fields are
            # retained.
            ph = hashlib.sha1()
            ph.update(("db|" + db_fp + "\n").encode("utf-8", "replace"))
            profile_dir = os.path.dirname(dbp)
            try:
                names = [
                    name for name in sorted(os.listdir(profile_dir))
                    if str(name or "").lower().startswith("playstate")
                    and str(name or "").lower().endswith(".json")
                ]
            except Exception:
                names = []

            volatile_root_keys_v2468 = {
                "generated_at", "generatedat", "generated",
                "saved_at", "savedat", "saved",
                "fetched_at", "fetchedat", "refreshed_at", "refreshedat",
                "cache_ts", "cache_time", "cache_age", "mtime",
            }

            for name in names:
                path = os.path.join(profile_dir, name)
                ph.update(("file|" + name + "|").encode("utf-8", "replace"))
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        obj = json.load(f)
                    if isinstance(obj, dict):
                        obj = {
                            k: v for k, v in obj.items()
                            if str(k or "").replace("-", "_").lower()
                            not in volatile_root_keys_v2468
                        }
                    canonical = json.dumps(
                        obj, ensure_ascii=False, sort_keys=True,
                        separators=(",", ":")
                    ).encode("utf-8", "replace")
                    ph.update(hashlib.sha1(canonical).digest())
                except Exception:
                    # Parse failure fallback still hashes bytes rather than mtime.
                    try:
                        fh = hashlib.sha1()
                        with open(path, "rb") as f:
                            while True:
                                chunk = f.read(65536)
                                if not chunk:
                                    break
                                fh.update(chunk)
                        ph.update(fh.digest())
                    except Exception:
                        ph.update(b"missing")
                ph.update(b"\n")

            return ph.hexdigest()
        except Exception:
            return ""

    def _section_persistent_cache_load_v2467(self):
        cache = getattr(self, "_section_persistent_cache_v2467", None)
        if isinstance(cache, dict):
            return cache
        cache = {}
        path = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
        try:
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                if isinstance(payload, dict):
                    cache = dict(payload.get("entries") or {})
        except Exception:
            cache = {}
        self._section_persistent_cache_v2467 = cache
        return cache

    def _section_persistent_scene_get_v2467(self, cache_key):
        key = str(cache_key or "")
        if not key.startswith("recommend:"):
            return None
        try:
            cache = self._section_persistent_cache_load_v2467()
            rec = cache.get(key)
            if not isinstance(rec, dict):
                return None
            if int(rec.get("fingerprint_version") or 0) != 2471:
                cache.pop(key, None)
                return None
            # Home sidebar first-paint is local-snapshot-first.  Exact section
            # authority validation can scan the items table for seconds on low-power
            # Android storage, so it must never sit between focus and first paint.
            # Validate synchronously only when an authority map is already resident;
            # otherwise show the persisted, signature-checked scene immediately and
            # let the existing post-reveal/background authority path revalidate it.
            authority_ready = isinstance(getattr(self, "_persistent_section_authority_map_v2489", None), dict)
            if authority_ready or not xbmc.getCondVisibility("System.Platform.Android"):
                content_ok_v2487, content_reason_v2487 = self._persistent_entry_content_match_v2487(rec, entry_key=key)
                if not content_ok_v2487:
                    cache.pop(key, None)
                    self._startup_content_reject_keys_v2487.add(key)
                    _log("SECTION_PERSISTENT_CACHE_REJECT_V2487 key=%s reason=content_authority_changed detail=%s" % (key, content_reason_v2487))
                    return None
            else:
                _log("SECTION_PERSISTENT_CACHE_FIRSTPAINT_LOCAL key=%s authority=deferred rows=%d" % (key, len(list(rec.get("rows") or []))))
            rows_raw = list(rec.get("rows") or [])
            rows = []
            for entry in rows_raw:
                if not isinstance(entry, dict):
                    continue
                d = dict(entry)
                if isinstance(d.get("row"), list):
                    d["row"] = tuple(d.get("row") or [])
                rows.append(d)
            if not rows:
                return None
            sig = self._section_rows_signature_v1620(rows)
            expected_sig = str(rec.get("row_signature") or "")
            if expected_sig and sig != expected_sig:
                cache.pop(key, None)
                return None
            scene = {
                "title": str(rec.get("title") or ""),
                "count": str(rec.get("count") or "추천"),
                "meta": rec.get("meta") if isinstance(rec.get("meta"), dict) else {},
                "row_count": len(rows),
                "row_signature": sig,
                "rows_snapshot_v1621": [dict(x) for x in rows],
                "bank": "",
                "created_ms": int(float(rec.get("ts") or time.time()) * 1000),
                "persistent_v2467": 1,
            }
            self._section_rows_cache[key] = rows
            self._section_scene_cache_v1620[key] = scene
            self._section_visited_keys_v1635.add(key)
            self._section_persistent_hit_keys_v2467.add(key)
            _log("SECTION_PERSISTENT_CACHE_HIT_V2468 key=%s rows=%d spinner=0 authority=match" % (
                key, len(rows)
            ))
            return scene
        except Exception:
            _log("SECTION_PERSISTENT_CACHE_LOAD_FAILED_V2468 key=%s err=%s" % (
                key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return None

    def _startup_hydrate_persistent_sections_v2469(self, reason=""):
        """V2473: hydrate all recommendation row/snapshot data, no native ListItems."""
        started = _pkm_speed_ms(); hydrated = 0; rejected = 0; snapshot_ready = 0; presentation_stale = 0
        try:
            sections = [dict(sec) for sec in list(getattr(self, "sections", []) or []) if isinstance(sec, dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
            if not sections:
                return 0
            cache = self._section_persistent_cache_load_v2467()
            if not isinstance(cache, dict) or not cache:
                _log("SECTION_STARTUP_HYDRATE_SKIP_V2473 reason=no_persistent_entries")
                return 0
            authority = self._persistent_selected_section_authority_combined_v2489()
            presentation_v2487 = self._persistent_presentation_fingerprint_v2487()
            _log("SECTION_STARTUP_AUTHORITY_V2487 mode=content_only playstate_global_invalidation=0 fp=%s presentation=%s ratings_content_invalidate=0" % (
                str(authority or "")[:12], str(presentation_v2487 or "")[:12]
            ))
            if not authority:
                return 0
            migrated_v2489 = False
            for sec in sections:
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                key = "recommend:%s" % sid
                rec = cache.get(key)
                if not isinstance(rec, dict):
                    continue
                if int(rec.get("fingerprint_version") or 0) != 2471:
                    rejected += 1
                    self._startup_content_reject_keys_v2487.add(key)
                    continue
                model_before_v2489 = str(rec.get("authority_model") or "")
                content_ok_v2487, content_reason_v2487 = self._persistent_entry_content_match_v2487(rec, entry_key=key)
                if not content_ok_v2487:
                    rejected += 1
                    self._startup_content_reject_keys_v2487.add(key)
                    _log("SECTION_STARTUP_CONTENT_REJECT_V2487 key=%s detail=%s" % (key, content_reason_v2487))
                    continue
                if model_before_v2489 != "content_section_v2489":
                    migrated_v2489 = bool(self._persistent_entry_upgrade_section_authority_v2489(rec, sid)) or migrated_v2489
                if content_reason_v2487 == "v2493_zero_count_migrated":
                    migrated_v2489 = True
                rows=[]
                for raw in list(rec.get("rows") or []):
                    if not isinstance(raw, dict):
                        continue
                    d=dict(raw)
                    if isinstance(d.get("row"), list): d["row"]=tuple(d.get("row") or [])
                    rows.append(d)
                if not rows:
                    continue
                sig=self._section_rows_signature_v1620(rows)
                expected=str(rec.get("row_signature") or "")
                if expected and sig != expected:
                    rejected += 1; continue
                meta=rec.get("meta") if isinstance(rec.get("meta"),dict) else {}
                self._section_rows_cache[key]=rows
                self._section_scene_cache_v1620[key]={
                    "title":str(rec.get("title") or ""),"count":str(rec.get("count") or "추천"),"meta":meta,
                    "row_count":len(rows),"row_signature":sig,"rows_snapshot_v1621":[dict(x) for x in rows],"bank":"",
                    "created_ms":int(float(rec.get("ts") or time.time())*1000),"persistent_v2467":1,"startup_data_hydrated_v2473":1,
                }
                self._section_visited_keys_v1635.add(key)
                self._section_persistent_hit_keys_v2467.add(key)
                self._section_startup_hydrated_keys_v2469.add(key)
                self._section_full_rows_ready_v1644.add(key)
                snaps=list(rec.get("render_snapshots_v2473") or [])
                presentation_ok_v2487 = self._persistent_entry_presentation_match_v2487(rec)
                if len(snaps)==len(rows) and presentation_ok_v2487:
                    self._section_render_snapshots_v2473[key]=snaps; snapshot_ready += 1
                else:
                    presentation_stale += 1
                    self._startup_presentation_stale_keys_v2487.add(key)
                    # PKM_PATCH_ACTIVE v2577 selective_presentation_snapshot_hold
                    # Keep an exact stale snapshot in memory temporarily.  After
                    # per-section content fingerprints are compared, v2577 drops
                    # stale snapshots only for sections that actually changed.
                    # If this is a presentation-only global change, the old v2487
                    # behaviour is preserved and every stale snapshot is removed.
                    if len(snaps)==len(rows) and len(snaps)>0:
                        self._section_render_snapshots_v2473[key]=snaps
                    else:
                        self._section_render_snapshots_v2473.pop(key, None)
                    _log("SECTION_PRESENTATION_STALE_V2577 key=%s rows=%d snapshot_rows=%d data_reuse=1 temporary_hold=%d" % (key, len(rows), len(snaps), 1 if (len(snaps)==len(rows) and len(snaps)>0) else 0))
                hydrated += 1
                _log("SECTION_STARTUP_DATA_READY_V2487 key=%s rows=%d snapshot=%d presentation_ok=%d native_listitems=0 spinner=0 focus_io=0" % (key,len(rows),1 if (len(snaps)==len(rows) and presentation_ok_v2487) else 0,1 if presentation_ok_v2487 else 0))
            if migrated_v2489:
                try:
                    path_v2489 = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
                    _pkm_write_cache_json_v2801(path_v2489, cache)
                    _log("SECTION_STARTUP_MIGRATION_FLUSH_V2489 migrated=1 rebuild=0")
                except Exception:
                    _log("SECTION_STARTUP_MIGRATION_FLUSH_FAILED_V2489 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            _log("SECTION_STARTUP_HYDRATE_DONE_V2487 sections=%d hydrated=%d rejected=%d snapshot_ready=%d presentation_stale=%d native_listitems=0 all_tabs_data=1 total_ms=%d" % (len(sections),hydrated,rejected,snapshot_ready,presentation_stale,_pkm_speed_ms()-started))
            return hydrated
        except Exception:
            _log("SECTION_STARTUP_HYDRATE_FAILED_V2473 err=%s" % traceback.format_exc().replace(chr(10)," | "), xbmc.LOGWARNING)
            return hydrated

    def _pkm_low_memory_trim_v2801(self, mem_avail_mb):
        """Drop process-local library accelerators under low memory (sampler thread).

        Fresh dicts are rebound instead of clear() so GUI code iterating the old
        object is never mutated mid-loop. The active wall entry is kept; every
        dropped key falls back to the existing rebuild/disk-load path.
        """
        active = str(getattr(self, "_active_wall_cache_key_v1841", "") or "")
        dropped = 0
        for attr in ("_library_prebuilt_listitems_v2470",
                     "_library_prebuilt_indexitems_v2470",
                     "_library_render_snapshots_v2473"):
            old = getattr(self, attr, None) or {}
            keep = {active: old[active]} if active in old else {}
            setattr(self, attr, keep)
            dropped += len(old) - len(keep)
        # A deferred batch keeps unflushed entries only in memory; never drop those.
        cache_dropped = 0
        if not bool(getattr(self, "_startup_library_cache_dirty_v2507", False)):
            cache = getattr(self, "_library_persistent_cache_v2470", None)
            if isinstance(cache, dict):
                cache_dropped = len(cache)
                self._library_persistent_cache_v2470 = None
        _log("PKM_LOW_MEMORY_TRIM_V2801 mem_avail_mb=%d active=%s prebuilt_dropped=%d persistent_entries_dropped=%d" % (
            int(mem_avail_mb), active or "-", dropped, cache_dropped), xbmc.LOGWARNING)

    def _library_persistent_cache_load_v2470(self):
        cache = getattr(self, "_library_persistent_cache_v2470", None)
        if isinstance(cache, dict):
            return cache
        cache = {}
        path = self._derived_cache_path_v2467("library_wall_prepared_cache_v2470.json")
        try:
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                if isinstance(payload, dict):
                    cache = dict(payload.get("entries") or {})
        except Exception:
            cache = {}
        self._library_persistent_cache_v2470 = cache
        return cache

    def _startup_persistent_cache_flush_one_v2507(self, kind):
        """Flush one already-mutated startup cache atomically. No scene semantics change."""
        kind = str(kind or "").strip().lower()
        if kind not in ("section", "library"):
            return False
        dirty_attr = "_startup_section_cache_dirty_v2507" if kind == "section" else "_startup_library_cache_dirty_v2507"
        if not bool(getattr(self, dirty_attr, False)):
            return True
        started = _pkm_speed_ms()
        try:
            if kind == "section":
                cache = self._section_persistent_cache_load_v2467()
                filename = "section_scene_cache_v2468.json"
            else:
                cache = self._library_persistent_cache_load_v2470()
                filename = "library_wall_prepared_cache_v2470.json"
            path = self._derived_cache_path_v2467(filename)
            if not path:
                return False
            _pkm_write_cache_json_v2801(path, cache)
            setattr(self, dirty_attr, False)
            _log("STARTUP_PERSIST_BATCH_FLUSH_V2507 kind=%s entries=%d elapsed_ms=%d atomic=1 texture_gate_unchanged=1" % (
                kind, len(cache or {}), _pkm_speed_ms() - started
            ))
            return True
        except Exception:
            _log("STARTUP_PERSIST_BATCH_FLUSH_FAILED_V2507 kind=%s elapsed_ms=%d err=%s" % (
                kind, _pkm_speed_ms() - started, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _startup_persistent_cache_flush_v2507(self):
        started = _pkm_speed_ms()
        section_ok = self._startup_persistent_cache_flush_one_v2507("section")
        library_ok = self._startup_persistent_cache_flush_one_v2507("library")
        ok = bool(section_ok and library_ok)
        _log("STARTUP_PERSIST_BATCH_DONE_V2507 section_ok=%d library_ok=%d total_ms=%d writes_max=2 snapshot_semantics_unchanged=1" % (
            1 if section_ok else 0, 1 if library_ok else 0, _pkm_speed_ms() - started
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        return ok

    def _library_persistent_scene_store_v2470(self, cache_key, section_id, title,
                                               total, rows_cache, sort_key="title",
                                               sort_dir="asc", genre="", index_rows=None,
                                               render_snapshots_v2476=None):
        """Persist one completed Library first-runway scene under local authority.

        The cache never replaces Plex/DB authority.  It contains only the already
        completed local wall rows plus the title-index data required to bind the
        hidden Library target without any focus-time JSON/DB/rating work.
        """
        key = str(cache_key or "")
        sid = str(section_id or "").strip()
        if not key or not sid or not rows_cache:
            return False
        try:
            fp = self._persistent_section_authority_fingerprint_v2489(sid)
            if not fp:
                return False
            cache = self._library_persistent_cache_load_v2470()
            rows_out = list(rows_cache or [])[:max(1, int(self._library_wall_initial_bound_count_v2077()))]
            idx_rows = list(index_rows or self._section_index_cache.get(sid) or [])
            cache[key] = {
                "ts": time.time(),
                "authority_model": "content_section_v2489",
                "authority_fp": fp,
                "presentation_fp_v2487": str(self._persistent_presentation_fingerprint_v2487() or ""),
                "fingerprint_version": 2471,
                "section_id": sid,
                "title": _display_library_title(title or ""),
                "total": int(total or 0),
                "sort": str(sort_key or "title"),
                "sort_dir": str(sort_dir or "asc"),
                "genre": str(genre or ""),
                "row_signature": self._library_rows_signature_v2470(rows_out),
                "rows": self._json_safe_v2467(rows_out),
                "index_rows": self._json_safe_v2467(idx_rows),
                "render_snapshots_v2473": self._json_safe_v2467(
                    list(render_snapshots_v2476 or [])[:len(rows_out)]
                    if render_snapshots_v2476 is not None else
                    [snap for snap in (self._render_snapshot_from_li_v2473(li) for li in list(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(key) or [])) if snap]
                ),
            }
            if len(cache) > 96:
                ordered = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0))
                for old_key, _ in ordered[:-96]:
                    cache.pop(old_key, None)
            if bool(getattr(self, "_startup_persist_batch_active_v2507", False)):
                self._startup_library_cache_dirty_v2507 = True
                _log("LIBRARY_PERSISTENT_CACHE_DEFER_V2507 key=%s section=%s rows=%d disk_write=0 batch=1" % (key, sid, len(rows_out)))
            else:
                path = self._derived_cache_path_v2467("library_wall_prepared_cache_v2470.json")
                # R116: 1.2 MB rewrite moved off the GUI thread.
                _pkm_write_cache_json_async_r116(path, cache, tag="library:%s" % sid)
            self._library_persistent_hit_keys_v2470.add(key)
            if not str(genre or "").strip():
                self._remember_section_library_state_v2471(
                    sid, cache_key=key, sort_key=sort_key, sort_dir=sort_dir,
                    genre="", reason="library_persistent_store"
                )
            _log("LIBRARY_PERSISTENT_CACHE_STORE_V2489 key=%s section=%s rows=%d total=%d index=%d authority=section_content presentation=separate" % (
                key, sid, len(rows_out), int(total or 0), len(idx_rows)
            ))
            return True
        except Exception:
            _log("LIBRARY_PERSISTENT_CACHE_STORE_FAILED_V2471 key=%s section=%s err=%s" % (
                key, sid, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _library_persistent_scene_invalidate_section_v2470(self, section_id, reason=""):
        sid = str(section_id or "").strip()
        if not sid:
            return
        try:
            cache = self._library_persistent_cache_load_v2470()
            removed = []
            for key, rec in list(cache.items()):
                try:
                    if str((rec or {}).get("section_id") or "") != sid:
                        continue
                except Exception:
                    continue
                removed.append(str(key))
                cache.pop(key, None)
                self._library_persistent_hit_keys_v2470.discard(str(key))
                self._library_startup_hydrated_keys_v2470.discard(str(key))
                self._library_post_reveal_data_warm_keys_v2472.discard(str(key))
                self._li_release_r118(self._library_prebuilt_listitems_v2470.pop(str(key), None))
                self._library_render_snapshots_v2473.pop(str(key), None)
                self._li_release_r118(self._library_prebuilt_indexitems_v2470.pop(str(key), None))
                self._section_rows_cache.pop(str(key), None)
                self._section_total_cache.pop(str(key), None)
            if str(getattr(self, "_active_wall_cache_key_v1841", "") or "") in removed:
                self._active_wall_cache_key_v1841 = ""
                self._active_wall_verified_empty_v1841 = False
            if removed:
                path = self._derived_cache_path_v2467("library_wall_prepared_cache_v2470.json")
                _pkm_write_cache_json_v2801(path, cache)
            self._section_index_cache.pop(sid, None)
            _log("LIBRARY_PERSISTENT_CACHE_INVALIDATE_V2470 section=%s keys=%d reason=%s" % (
                sid, len(removed), reason or ""
            ))
            self._rearm_auto_persistent_snapshots_v2476(reason="library_invalidated:%s" % (reason or ""))
        except Exception:
            _log("LIBRARY_PERSISTENT_CACHE_INVALIDATE_FAILED_V2470 section=%s reason=%s err=%s" % (
                sid, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _startup_hydrate_persistent_library_tabs_v2470(self, reason=""):
        """V2473: restore every section's saved Library runway/index/snapshot as data only."""
        started=_pkm_speed_ms(); hydrated=0; rejected=0; snapshot_ready=0; presentation_stale=0
        try:
            sections=[dict(sec) for sec in list(getattr(self,"sections",[]) or []) if isinstance(sec,dict) and str(sec.get("section_id") or sec.get("key") or "").strip()]
            if not sections: return 0
            cache=self._library_persistent_cache_load_v2470()
            if not isinstance(cache,dict) or not cache:
                _log("LIBRARY_STARTUP_HYDRATE_SKIP_V2473 reason=no_persistent_entries"); return 0
            self._section_tab_state_load_v2471()
            authority=self._persistent_selected_section_authority_combined_v2489()
            if not authority: return 0
            selected=set(str(sec.get("section_id") or sec.get("key") or "").strip() for sec in sections)
            by_sid={}
            for key,rec in list(cache.items()):
                if not isinstance(rec,dict): continue
                sid=str(rec.get("section_id") or "").strip()
                if sid in selected and not str(rec.get("genre") or "").strip(): by_sid.setdefault(sid,[]).append((str(key),rec))
            migrated_v2489 = False
            for sec in sections:
                sid=str(sec.get("section_id") or sec.get("key") or "").strip(); candidates=list(by_sid.get(sid) or [])
                if not candidates: continue
                saved=(getattr(self,"_section_last_library_state_by_sid_v2471",{}) or {}).get(sid)
                saved_key=str((saved or {}).get("cache_key") or "").strip() if isinstance(saved,dict) else ""
                chosen=next((pair for pair in candidates if saved_key and pair[0]==saved_key),None)
                if chosen is None: chosen=max(candidates,key=lambda pair:float((pair[1] or {}).get("ts") or 0.0))
                key,rec=chosen
                if int(rec.get("fingerprint_version") or 0)!=2471:
                    rejected += 1
                    self._startup_content_reject_keys_v2487.add("library:%s" % sid)
                    continue
                model_before_v2489 = str(rec.get("authority_model") or "")
                content_ok_v2487, content_reason_v2487 = self._persistent_entry_content_match_v2487(rec, entry_key="library:%s" % sid)
                if not content_ok_v2487:
                    rejected += 1
                    self._startup_content_reject_keys_v2487.add("library:%s" % sid)
                    _log("LIBRARY_STARTUP_CONTENT_REJECT_V2487 section=%s key=%s detail=%s" % (sid, key, content_reason_v2487))
                    continue
                if model_before_v2489 != "content_section_v2489":
                    migrated_v2489 = bool(self._persistent_entry_upgrade_section_authority_v2489(rec, sid)) or migrated_v2489
                if content_reason_v2487 == "v2493_zero_count_migrated":
                    migrated_v2489 = True
                rows=[]
                for raw in list(rec.get("rows") or []):
                    if isinstance(raw,list): rows.append(tuple(raw))
                    elif isinstance(raw,dict):
                        d=dict(raw)
                        if isinstance(d.get("row"),list): d["row"]=tuple(d.get("row") or [])
                        rows.append(d)
                    else: rows.append(raw)
                if not rows: continue
                sig=self._library_rows_signature_v2470(rows); expected=str(rec.get("row_signature") or "")
                if expected and sig!=expected: rejected += 1; continue
                index_rows=[dict(x) for x in list(rec.get("index_rows") or []) if isinstance(x,dict)]
                self._section_rows_cache[key]=rows; self._section_total_cache[key]=int(rec.get("total") or 0)
                if index_rows: self._section_index_cache[sid]=index_rows
                self._library_persistent_hit_keys_v2470.add(key)
                self._library_post_reveal_data_warm_keys_v2472.add(key)  # data-ready semantics, no focus DB/spinner
                self._section_last_library_state_by_sid_v2471[sid]={"sort":str(rec.get("sort") or "title"),"sort_dir":str(rec.get("sort_dir") or pkm_library_sort.default_sort_dir(str(rec.get("sort") or "title"))),"cache_key":key}
                snaps=list(rec.get("render_snapshots_v2473") or [])
                presentation_ok_v2487 = self._persistent_entry_presentation_match_v2487(rec)
                if len(snaps)==len(rows) and presentation_ok_v2487:
                    self._library_render_snapshots_v2473[key]=snaps; snapshot_ready += 1
                else:
                    presentation_stale += 1
                    self._startup_presentation_stale_keys_v2487.add("library:%s" % sid)
                    if not hasattr(self, "_startup_stale_library_cache_keys_v2577"):
                        self._startup_stale_library_cache_keys_v2577 = {}
                    self._startup_stale_library_cache_keys_v2577[str(sid)] = str(key)
                    # v2577: same temporary-hold policy as Recommendation.
                    if len(snaps)==len(rows) and len(snaps)>0:
                        self._library_render_snapshots_v2473[key]=snaps
                    else:
                        self._library_render_snapshots_v2473.pop(key, None)
                    _log("LIBRARY_PRESENTATION_STALE_V2577 section=%s key=%s rows=%d snapshot_rows=%d data_reuse=1 temporary_hold=%d wall_query=0" % (sid, key, len(rows), len(snaps), 1 if (len(snaps)==len(rows) and len(snaps)>0) else 0))
                hydrated += 1
                _log("LIBRARY_STARTUP_DATA_READY_V2487 key=%s section=%s rows=%d index=%d snapshot=%d presentation_ok=%d native_listitems=0 spinner=0 focus_io=0" % (key,sid,len(rows),len(index_rows),1 if (len(snaps)==len(rows) and presentation_ok_v2487) else 0,1 if presentation_ok_v2487 else 0))
            if migrated_v2489:
                try:
                    path_v2489 = self._derived_cache_path_v2467("library_wall_prepared_cache_v2470.json")
                    _pkm_write_cache_json_v2801(path_v2489, cache)
                    _log("LIBRARY_STARTUP_MIGRATION_FLUSH_V2489 migrated=1 rebuild=0")
                except Exception:
                    _log("LIBRARY_STARTUP_MIGRATION_FLUSH_FAILED_V2489 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            _log("LIBRARY_STARTUP_HYDRATE_DONE_V2487 sections=%d hydrated=%d rejected=%d snapshot_ready=%d presentation_stale=%d native_listitems=0 all_tabs_data=1 total_ms=%d" % (len(sections),hydrated,rejected,snapshot_ready,presentation_stale,_pkm_speed_ms()-started))
            return hydrated
        except Exception:
            _log("LIBRARY_STARTUP_HYDRATE_FAILED_V2473 err=%s" % traceback.format_exc().replace(chr(10)," | "), xbmc.LOGWARNING); return hydrated

    def _section_persistent_scene_invalidate_v2467(self, cache_key, reason=""):
        key = str(cache_key or "")
        try:
            self._section_persistent_hit_keys_v2467.discard(key)
            cache = self._section_persistent_cache_load_v2467()
            if key in cache:
                cache.pop(key, None)
            self._section_scene_cache_v1620.pop(key, None)
            self._section_rows_cache.pop(key, None)
            self._section_visited_keys_v1635.discard(key)
            # v2469: a real dirty/change invalidation must also retire the
            # process-local startup-hydrated ListItems so stale GUI objects can
            # never bypass authoritative rebuild.
            self._section_startup_hydrated_keys_v2469.discard(key)
            self._section_startup_prebuilt_keys_v2469.discard(key)
            self._li_release_r118(self._section_prebuilt_listitems_v1644.pop(key, None))
            self._section_render_snapshots_v2473.pop(key, None)
            self._section_prebuilt_titles_v1644.pop(key, None)
            self._section_prebuilt_meta_v1644.pop(key, None)
            self._section_prebuilt_rating_v1644.pop(key, None)
            self._section_full_rows_ready_v1644.discard(key)
            self._section_texture_ready_v1644.discard(key)
            try:
                path = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
                if path:
                    _pkm_write_cache_json_v2801(path, cache)
            except Exception:
                pass
            _log("SECTION_PERSISTENT_CACHE_INVALIDATE_V2468 key=%s reason=%s" % (key, reason or ""))
            self._rearm_auto_persistent_snapshots_v2476(reason="section_invalidated:%s" % (reason or ""))
        except Exception:
            pass

    def _section_persistent_scene_store_v2467(self, cache_key, title, count_text, rows_cache, meta_snapshot, render_snapshots_v2473=None):
        key = str(cache_key or "")
        if not key.startswith("recommend:") or not rows_cache:
            return False
        try:
            _r116_t0 = time.perf_counter()
            sid_v2489 = key.split(":", 1)[1].strip() if key.startswith("recommend:") else ""
            fp = self._persistent_section_authority_fingerprint_v2489(sid_v2489)
            if not fp:
                return False
            _r116_t1 = time.perf_counter()
            cache = self._section_persistent_cache_load_v2467()
            cache[key] = {
                "ts": time.time(),
                "authority_model": "content_section_v2489",
                "authority_fp": fp,
                "section_id": sid_v2489,
                "presentation_fp_v2487": str(self._persistent_presentation_fingerprint_v2487() or ""),
                "fingerprint_version": 2471,
                "title": _display_library_title(title or ""),
                "count": _display_library_title(count_text or "추천"),
                "meta": self._json_safe_v2467(self._section_scene_snapshot_safe_v1620(meta_snapshot) or {}),
                "row_signature": self._section_rows_signature_v1620(rows_cache),
                "rows": self._json_safe_v2467(list(rows_cache or [])),
                "render_snapshots_v2473": self._json_safe_v2467(list(render_snapshots_v2473 or [])),
            }
            if len(cache) > 64:
                ordered = sorted(cache.items(), key=lambda kv: float((kv[1] or {}).get("ts") or 0))
                for old_key, _ in ordered[:-64]:
                    cache.pop(old_key, None)
            if bool(getattr(self, "_startup_persist_batch_active_v2507", False)):
                self._startup_section_cache_dirty_v2507 = True
                _log("SECTION_PERSISTENT_CACHE_DEFER_V2507 key=%s section=%s rows=%d disk_write=0 batch=1" % (key, sid_v2489, len(rows_cache or [])))
            else:
                path = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
                # R116: the 3 MB rewrite stalled the GUI thread 0.46 s on SHIELD
                # after each first section visit; write it on the cache worker.
                _pkm_write_cache_json_async_r116(path, cache, tag=key)
            _log("SECTION_PERSISTENT_CACHE_STORE_V2489 key=%s section=%s rows=%d authority=section_content presentation=separate playstate_global_invalidation=0" % (key, sid_v2489, len(rows_cache or [])))
            _log("SECTION_PERSISTENT_STORE_TIMING_R116 key=%s fp_ms=%.1f build_ms=%.1f disk_write=async" % (
                key, (_r116_t1 - _r116_t0) * 1000.0, (time.perf_counter() - _r116_t1) * 1000.0))
            return True
        except Exception:
            _log("SECTION_PERSISTENT_CACHE_STORE_FAILED_V2471 key=%s err=%s" % (
                key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _section_scene_get_v1620(self, cache_key):
        """Return the immutable completed scene for this Kodi window session.

        v1621: the scene owns its own row snapshot. Background startup/incremental
        sync may mark a library dirty, but it must never make a menu that was
        already visited look cold again. If an older path cleared the shared row
        cache, restore it from the completed scene and keep re-entry spinner-free.
        """
        try:
            key = str(cache_key or "")
            scene = self._section_scene_cache_v1620.get(key)
            if not isinstance(scene, dict):
                return None
            expected_count = int(scene.get("row_count") or 0)
            expected_sig = str(scene.get("row_signature") or "")
            rows = self._section_rows_cache.get(key)
            rows_ok = bool(
                rows and expected_count == len(rows)
                and expected_sig == self._section_rows_signature_v1620(rows)
            )
            if not rows_ok:
                stored_rows = scene.get("rows_snapshot_v1621")
                if stored_rows:
                    restored = []
                    for entry in stored_rows:
                        restored.append(dict(entry) if isinstance(entry, dict) else entry)
                    if (expected_count == len(restored)
                            and expected_sig == self._section_rows_signature_v1620(restored)):
                        self._section_rows_cache[key] = restored
                        rows = restored
                        rows_ok = True
                        _log("SECTION_SCENE_ROWS_RESURRECT_V1621 key=%s rows=%d reason=session_scene_owns_rows spinner=0" % (
                            key, len(restored)
                        ))
            if not rows_ok:
                return None
            return scene
        except Exception:
            return None

    def _section_scene_store_v1620(self, cache_key, title, count_text, rows_cache, meta_snapshot, bank, reason=""):
        try:
            key = str(cache_key or "")
            if not key or not rows_cache:
                return False
            # v2585: a progressive first-paint bank is intentionally incomplete.
            # Never register/persist it as a reusable complete scene; the follow-up
            # full A/B fill owns scene persistence once every widget row is ready.
            if key and key == str(getattr(self, "_section_progressive_firstpaint_key_v2585", "") or ""):
                _log("SECTION_PROGRESSIVE_SCENE_STORE_DEFER_V2585 key=%s rows=%d bank=%s reason=%s" % (
                    key, len(rows_cache or []), str(bank or "").upper(), reason or ""
                ))
                return True
            safe_snapshot = self._section_scene_snapshot_safe_v1620(meta_snapshot)
            if not safe_snapshot:
                return False
            rows_snapshot_v1621 = []
            for entry in rows_cache or []:
                rows_snapshot_v1621.append(dict(entry) if isinstance(entry, dict) else entry)
            self._section_scene_cache_v1620[key] = {
                "title": _display_library_title(title or ""),
                "count": _display_library_title(count_text or "추천"),
                "meta": safe_snapshot,
                "row_count": len(rows_cache or []),
                "row_signature": self._section_rows_signature_v1620(rows_cache),
                "rows_snapshot_v1621": rows_snapshot_v1621,
                "bank": str(bank or "").upper(),
                "created_ms": int(time.time() * 1000),
            }
            self._section_visited_keys_v1635.add(key)
            _log("SECTION_SCENE_CACHE_STORE_V1635 key=%s rows=%d bank=%s reason=%s visited_registry=1" % (
                key, len(rows_cache or []), str(bank or "").upper(), reason or ""
            ))
            try:
                existing_snaps_v2479 = list(getattr(self, "_section_render_snapshots_v2473", {}).get(key) or [])
                prepared_persistent_v2479 = bool(
                    key in getattr(self, "_section_persistent_hit_keys_v2467", set())
                    and len(existing_snaps_v2479) == len(rows_cache or [])
                )
                same_on_disk_r116 = False
                if not prepared_persistent_v2479 and key.startswith("recommend:"):
                    # R116: a persistent HIT re-stored the identical scene on
                    # every first visit after restart (46 ms render snapshot on
                    # the GUI thread + 3 MB rewrite).  Skip when the stored
                    # record already matches rows, authority and presentation.
                    try:
                        rec_r116 = self._section_persistent_cache_load_v2467().get(key)
                        if isinstance(rec_r116, dict):
                            sid_r116 = key.split(":", 1)[1].strip()
                            same_on_disk_r116 = bool(
                                str(rec_r116.get("row_signature") or "") == self._section_rows_signature_v1620(rows_cache)
                                and len(list(rec_r116.get("render_snapshots_v2473") or [])) == len(rows_cache or [])
                                and str(rec_r116.get("authority_fp") or "") == str(self._persistent_section_authority_fingerprint_v2489(sid_r116) or "")
                                and str(rec_r116.get("presentation_fp_v2487") or "") == str(self._persistent_presentation_fingerprint_v2487() or "")
                                and str(rec_r116.get("authority_fp") or "")
                            )
                    except Exception:
                        same_on_disk_r116 = False
                if same_on_disk_r116:
                    self._section_persistent_hit_keys_v2467.add(key)
                    _log("SECTION_PERSIST_SAME_SKIP_R116 key=%s rows=%d render_snapshot_rebuild=0 disk_write=0 reason=%s" % (
                        key, len(rows_cache or []), reason or ""
                    ))
                elif prepared_persistent_v2479:
                    _log("SECTION_PREPARED_PERSIST_WRITE_SKIP_V2479 key=%s rows=%d render_snapshot_rebuild=0 disk_write=0 reason=%s" % (
                        key, len(rows_cache or []), reason or ""
                    ))
                else:
                    _r116_rs0 = time.perf_counter()
                    render_snapshots_v2473 = self._section_render_snapshots_from_bank_v2473(bank, rows_cache)
                    _log("SECTION_RENDER_SNAPSHOT_TIMING_R116 key=%s rows=%d ms=%.1f" % (
                        key, len(rows_cache or []), (time.perf_counter() - _r116_rs0) * 1000.0))
                    if render_snapshots_v2473:
                        self._section_render_snapshots_v2473[key] = list(render_snapshots_v2473)
                    stored_v2479 = self._section_persistent_scene_store_v2467(
                        key, title, count_text, rows_cache, safe_snapshot,
                        render_snapshots_v2473=render_snapshots_v2473
                    )
                    if stored_v2479:
                        self._section_persistent_hit_keys_v2467.add(key)
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _section_ready_bank_for_scene_v1620(self, cache_key):
        """Return an already-populated A/B bank that still owns this scene."""
        try:
            key = str(cache_key or "")
            if not key:
                return ""
            pending_v2585 = getattr(self, "_section_progressive_pending_keys_v2585", set())
            if isinstance(pending_v2585, set) and key in pending_v2585:
                _log("SECTION_READY_BANK_SKIP_PROGRESSIVE_V2585 key=%s reason=full_fill_pending" % key)
                return ""
            owners = getattr(self, "_section_bank_cache_key_v1612", {}) or {}
            for bank in ("A", "B"):
                if str(owners.get(bank) or "") != key:
                    continue
                ids = self._section_bank_row_ids_v1612(bank)
                if ids and self.getControl(ids[0]).size() > 0:
                    return bank
        except Exception:
            pass
        return ""

    def _home_persistent_snapshot_key_v2500(self, entry):
        try:
            if not isinstance(entry, dict):
                return ""
            values = tuple(entry.get("row") or ())
            if len(values) < 2:
                return ""
            rk = str(values[0] or "").strip()
            sid = str(values[1] or "").strip()
            row_id = str(entry.get("row_id") or entry.get("row_title") or "row").strip()
            row_type = str(entry.get("row_type") or "").strip()
            if not rk or not row_id:
                return ""
            return "%s\x1f%s\x1f%s\x1f%s" % (row_type, row_id, sid, rk)
        except Exception:
            return ""

    # PKM_PATCH_ACTIVE v2588 home_persistent_local_first_selected_reuse
    def _home_persistent_local_first_enabled_v2588(self):
        """Return True only for an established startup explicitly marked local-first.

        V2582 deliberately removed Plex/content-authority and rating-presentation
        scans from the pre-Home path.  Re-running those scans merely to validate
        the already-committed Home render snapshot defeats that policy.  On an
        established launch the selected-library signature is the foreground
        identity proof; content/presentation maintenance remains post-reveal.
        """
        try:
            return bool(
                xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                and self._startup_initial_prepare_verified_cumulative()
            )
        except Exception:
            return False

    def _home_persistent_render_cache_load_v2500(self):
        """Load exact Home render snapshots, with V2534 selective reuse for unchanged sections.

        V2500 rejected the entire Home render cache when one selected section changed.
        V2534 keeps the same fail-closed rule for the changed section itself, but allows
        cache records belonging to sections whose V2489 authority did not change.  The
        final native/texture startup gate is untouched, so this only avoids repeating
        static ListItem/rating composition for proven-unchanged sections.
        """
        cached = getattr(self, "_home_persistent_render_cache_v2500", None)
        if isinstance(cached, dict):
            return cached
        out = {}
        reason = "missing"
        started = _pkm_speed_ms()
        selective_v2534 = False
        selective_dropped_v2534 = 0
        try:
            path = self._derived_cache_path_v2467("home_render_snapshot_v2500.json")
            if not path or not os.path.exists(path):
                self._home_persistent_render_cache_v2500 = {}
                _log("HOME_PERSISTENT_RENDER_CACHE_V2500 result=MISS reason=missing entries=0 total_ms=%d" % (_pkm_speed_ms()-started))
                return {}
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            if not isinstance(payload, dict) or int(payload.get("version") or 0) != 2500:
                reason = "version"
                raise ValueError("version")
            # V2588: selection identity is cheap and is always checked first.
            # Established local-first launches must not reintroduce the authority /
            # presentation DB scans that V2582 removed from the pre-Home path.
            current_sig, _ids = self._startup_prepare_selected_signature_v2477()
            if str(payload.get("selected_sig") or "") != str(current_sig or ""):
                reason = "selection"
                raise ValueError(reason)
            entries = payload.get("entries")
            if not isinstance(entries, dict):
                entries = {}
            if self._home_persistent_local_first_enabled_v2588() and entries:
                out = dict(entries)
                reason = "local_first_selected_match_v2588"
                _log("HOME_PERSISTENT_RENDER_CACHE_LOCAL_FIRST_V2588 result=HIT entries=%d selected_match=1 authority_scan=0 presentation_scan=0 post_reveal_repair=1 total_ms=%d" % (
                    len(out), _pkm_speed_ms() - started
                ))
            else:
                current_authority = str(self._persistent_selected_section_authority_combined_v2489() or "")
                current_presentation = str(self._persistent_presentation_fingerprint_v2487() or "")
                payload_authority = str(payload.get("authority_fp") or "")
                # PKM_U7_EXACT_ROW_CACHE_PROOF_20261011
                # Combined section fingerprints include updated_at from files not
                # necessarily present on the Home screen. A mismatch alone does
                # not prove that an EXISTING rendered ListItem has changed.
                # Reuse snapshots only when the current 180 displayed rating keys
                # have exactly identical local metadata and ratings. Rendering
                # still looks up snapshots via the current row's unique key;
                # absent/new Plex items cannot be introduced by the cache.
                row_proof_u7 = False
                if (str(payload.get("presentation_fp") or "") != current_presentation
                        or not current_authority or payload_authority != current_authority):
                    stored_guard_u5 = str(payload.get("presentation_guard_u5") or "")
                    current_guard_u5 = self._home_presentation_guard_u5(entries) if (
                        stored_guard_u5 and current_authority and entries
                    ) else ""
                    if not current_guard_u5 or current_guard_u5 != stored_guard_u5:
                        _log('HOME_PRESENTATION_GUARD_MISS_U6 stored_guard=%d current_guard=%d '
                             'same_authority=%d entries=%d reason=%s' % (
                                 1 if stored_guard_u5 else 0,
                                 1 if current_guard_u5 else 0,
                                 1 if current_authority and payload_authority == current_authority else 0,
                                 len(entries),
                                 'guard_not_ready' if not stored_guard_u5 or not current_guard_u5 else 'display_data_changed'))
                        reason = "presentation"
                        raise ValueError(reason)
                    row_proof_u7 = True
                    _log("HOME_EXACT_ROW_PROOF_HIT_U7 entries=%d section_fingerprint_changed=%d bounded_sql=1" % (
                        len(entries), 1 if payload_authority != current_authority else 0))
                if (current_authority and payload_authority == current_authority) or row_proof_u7:
                    out = dict(entries)
                    reason = "exact_display_rows_u7" if row_proof_u7 else "authority_match"
                else:
                    cause_v2534 = str(getattr(self, "_startup_prepare_cause_v2487", "") or "")
                    changed_v2534 = set(str(x or "").strip() for x in (getattr(self, "_startup_changed_section_ids_v2489", set()) or set()) if str(x or "").strip())
                    if cause_v2534 != "plex_items_changed" or not changed_v2534:
                        reason = "content_authority"
                        raise ValueError(reason)
                    selective_v2534 = True
                    for key_v2534, rec_v2534 in entries.items():
                        try:
                            parts_v2534 = str(key_v2534 or "").split("\x1f")
                            sid_v2534 = str(parts_v2534[2] if len(parts_v2534) > 2 else "").strip()
                        except Exception:
                            sid_v2534 = ""
                        if sid_v2534 and sid_v2534 not in changed_v2534:
                            out[key_v2534] = rec_v2534
                        else:
                            selective_dropped_v2534 += 1
                    reason = "selective_unchanged_sections"
                    _log("HOME_PERSISTENT_RENDER_CACHE_SELECTIVE_V2534 changed_sections=%s kept=%d dropped=%d presentation_match=1 selection_match=1 changed_section_reuse=0" % (
                        ",".join(sorted(changed_v2534)) or "none", len(out), selective_dropped_v2534
                    ))
        except Exception:
            out = {}
        self._home_persistent_render_cache_v2500 = out
        _log("HOME_PERSISTENT_RENDER_CACHE_V2500 result=%s reason=%s entries=%d total_ms=%d" % (
            "HIT" if out else "MISS", reason, len(out), _pkm_speed_ms()-started
        ))
        return out

    def _home_persistent_render_cache_store_v2500(self, rows_cache):
        """Persist the Home ListItems that Kodi just accepted as the completed scene."""
        started = _pkm_speed_ms()
        try:
            rows = [x for x in list(rows_cache or []) if isinstance(x, dict)]
            if not rows:
                return False
            grouped = []
            current = []
            current_id = None
            for entry in rows:
                rid = str(entry.get("row_id") or entry.get("row_title") or "row")
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            entries = {}
            safe_local = 0
            for row_idx, row_entries in enumerate(grouped[:HOME_ROW_COUNT]):
                try:
                    ctrl = self.getControl(HOME_ROW_IDS[row_idx])
                except Exception:
                    continue
                max_items = min(len(row_entries), int(ctrl.size()))
                for item_idx in range(max_items):
                    entry = row_entries[item_idx]
                    key = self._home_persistent_snapshot_key_v2500(entry)
                    if not key:
                        continue
                    try:
                        li = ctrl.getListItem(item_idx)
                        snap = self._render_snapshot_from_li_v2473(li)
                    except Exception:
                        li = None
                        snap = None
                    if not isinstance(snap, dict):
                        continue
                    props = dict(snap.get("props") or {})
                    authority = str(
                        props.get("PosterAuthorityV2498")
                        or props.get("WallPosterRemoteV1644")
                        or props.get("Thumb")
                        or ""
                    ).strip()
                    local_path = ""
                    local_verified = 0
                    try:
                        source = str(li.getProperty("PlexKM.PosterLocalSourceV2498") or "").strip() if li else ""
                        poster = str(li.getArt("poster") or "").strip() if li else ""
                        if source and poster and not poster.lower().startswith(("http://", "https://")) and self._local_poster_file_ready_v1865(poster):
                            local_path = poster
                            local_verified = 1
                            safe_local += 1
                    except Exception:
                        local_path = ""
                        local_verified = 0
                    entries[key] = {
                        "snapshot": self._json_safe_v2467(snap),
                        "authority": authority,
                        "local": local_path,
                        "local_verified_v2500": int(local_verified),
                    }
            if not entries:
                return False
            selected_sig, section_ids = self._startup_prepare_selected_signature_v2477()
            local_first_store_v2588 = self._home_persistent_local_first_enabled_v2588()
            if local_first_store_v2588:
                authority_fp = ""
                presentation_fp = ""
                if not selected_sig:
                    return False
                _log("HOME_PERSISTENT_RENDER_STORE_LOCAL_FIRST_V2588 entries=%d selected_match=1 authority_scan=0 presentation_scan=0" % len(entries))
            else:
                authority_fp = str(self._persistent_selected_section_authority_combined_v2489() or "")
                presentation_fp = str(self._persistent_presentation_fingerprint_v2487() or "")
                if not authority_fp or not selected_sig:
                    return False
            payload = {
                "version": 2500,
                "authority_model": "local_first_selected_v2588" if local_first_store_v2588 else "content_section_v2489",
                "authority_fp": authority_fp,
                "presentation_fp": presentation_fp,
                "presentation_guard_u5": self._home_presentation_guard_u5(entries),
                "selected_sig": str(selected_sig or ""),
                "section_ids": list(section_ids or []),
                "entries": entries,
                "ts": time.time(),
            }
            path = self._derived_cache_path_v2467("home_render_snapshot_v2500.json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            self._home_persistent_render_cache_v2500 = dict(entries)
            _log("HOME_PERSISTENT_RENDER_STORE_V2500 entries=%d safe_local=%d authority=match presentation=match total_ms=%d" % (
                len(entries), safe_local, _pkm_speed_ms()-started
            ))
            return True
        except Exception:
            _log("HOME_PERSISTENT_RENDER_STORE_FAILED_V2500 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _startup_verified_poster_cache_load_v2500(self):
        """Load previously V2498-verified portrait files for an unchanged startup."""
        cached = getattr(self, "_startup_verified_poster_cache_v2500", None)
        if isinstance(cached, dict):
            return cached
        out = {}
        reason = "missing"
        started = _pkm_speed_ms()
        try:
            if str(getattr(self, "_startup_prepare_cause_v2487", "") or "") != "ready":
                self._startup_verified_poster_cache_v2500 = {}
                return {}
            path = self._derived_cache_path_v2467("verified_poster_local_v2500.json")
            if not path or not os.path.exists(path):
                self._startup_verified_poster_cache_v2500 = {}
                _log("STARTUP_VERIFIED_POSTER_CACHE_V2500 result=MISS reason=missing entries=0 total_ms=%d" % (_pkm_speed_ms()-started))
                return {}
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            if not isinstance(payload, dict) or int(payload.get("version") or 0) != 2500:
                reason = "version"
                raise ValueError(reason)
            authority_fp = str(self._persistent_selected_section_authority_combined_v2489() or "")
            selected_sig, _ids = self._startup_prepare_selected_signature_v2477()
            if str(payload.get("authority_fp") or "") != authority_fp:
                reason = "content_authority"
                raise ValueError(reason)
            if str(payload.get("selected_sig") or "") != str(selected_sig or ""):
                reason = "selection"
                raise ValueError(reason)
            raw = payload.get("entries")
            if isinstance(raw, dict):
                for authority, local in raw.items():
                    a = str(authority or "").strip()
                    lp = str(local or "").strip()
                    if a and lp and self._local_poster_file_ready_v1865(lp):
                        out[a] = lp
            reason = "authority_match"
        except Exception:
            out = {}
        self._startup_verified_poster_cache_v2500 = out
        _log("STARTUP_VERIFIED_POSTER_CACHE_V2500 result=%s reason=%s entries=%d total_ms=%d portrait_redecode=0" % (
            "HIT" if out else "MISS", reason, len(out), _pkm_speed_ms()-started
        ))
        return out

    def _startup_verified_poster_cache_store_v2500(self, destinations):
        try:
            entries = {}
            for dest in list(destinations or []):
                for rec in list(dest.get("items") or []):
                    li = rec.get("li")
                    if not li or not rec.get("ready") or rec.get("explicit_missing"):
                        continue
                    authority = str((rec.get("sources") or ("",))[0] or "").strip()
                    if not authority:
                        continue
                    try:
                        local = str(li.getArt("poster") or "").strip()
                        source = str(li.getProperty("PlexKM.PosterLocalSourceV2498") or "").strip()
                    except Exception:
                        local = source = ""
                    if source and local and not local.lower().startswith(("http://", "https://")) and self._local_poster_file_ready_v1865(local):
                        entries[authority] = local
            if not entries:
                return False
            authority_fp = str(self._persistent_selected_section_authority_combined_v2489() or "")
            selected_sig, section_ids = self._startup_prepare_selected_signature_v2477()
            if not authority_fp or not selected_sig:
                return False
            path = self._derived_cache_path_v2467("verified_poster_local_v2500.json")
            tmp = path + ".tmp"
            payload = {
                "version": 2500, "authority_fp": authority_fp,
                "selected_sig": str(selected_sig or ""), "section_ids": list(section_ids or []),
                "entries": entries, "ts": time.time(),
            }
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            self._startup_verified_poster_cache_v2500 = dict(entries)
            _log("STARTUP_VERIFIED_POSTER_CACHE_STORE_V2500 entries=%d exact_authority=1 portrait_verified_by_v2498=1" % len(entries))
            return True
        except Exception:
            _log("STARTUP_VERIFIED_POSTER_CACHE_STORE_FAILED_V2500 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _startup_bind_trusted_local_poster_v2500(self, li, local_path):
        """Rebind a file that was portrait-verified under this exact content authority."""
        try:
            local = str(local_path or "").strip()
            if not local or not self._local_poster_file_ready_v1865(local):
                return False
            if not self._startup_bind_local_poster_v2495(li, local):
                return False
            li.setProperty("PlexKM.PosterFallbackArt", "")
            li.setProperty("PlexKM.PosterFallbackArtActive", "")
            li.setProperty("PlexKM.PosterFallbackRoleV2498", "")
            li.setProperty("PlexKM.PosterLocalSourceV2498", "verified_authority_cache_v2500")
            return True
        except Exception:
            return False

    def _home_li_from_persistent_snapshot_v2500(self, entry, snapshot_index, progress_map):
        try:
            if not isinstance(entry, dict):
                return None
            key = self._home_persistent_snapshot_key_v2500(entry)
            hit = (snapshot_index or {}).get(key)
            if not isinstance(hit, dict):
                return None
            snapshot = hit.get("snapshot")
            row = tuple(entry.get("row") or ())
            if not isinstance(snapshot, dict) or len(row) < 21:
                return None
            row_type = str(entry.get("row_type") or "")
            snap_use = {
                "label": str(snapshot.get("label") or ""),
                "props": dict(snapshot.get("props") or {}),
                "art": dict(snapshot.get("art") or {}),
            }
            cached_authority = str(hit.get("authority") or "").strip()
            if row_type == "continue":
                current_poster = str(row[12] if len(row) > 12 else "").strip()
                if current_poster and cached_authority and current_poster != cached_authority:
                    return None
                if current_poster:
                    cached_authority = current_poster
                    snap_use["props"]["Thumb"] = current_poster
                    snap_use["props"]["WallPosterRemoteV1644"] = current_poster
                    snap_use["props"]["PosterAuthorityV2498"] = current_poster
                    snap_use["art"]["poster"] = current_poster
                    snap_use["art"]["thumb"] = current_poster
                    snap_use["art"]["icon"] = current_poster
            li = self._li_from_render_snapshot_v2473(
                row, snap_use,
                row_title=_display_library_title(entry.get("row_title", "")), row_type=row_type,
                row_first=bool(entry.get("row_first")), row_id=entry.get("row_id", ""),
                row_start=entry.get("row_start", 0), row_index=entry.get("row_index", -1),
            )
            if not li:
                return None
            local = str(hit.get("local") or "").strip()
            if int(hit.get("local_verified_v2500") or 0) == 1 and local and cached_authority and self._local_poster_file_ready_v1865(local):
                try:
                    self._startup_bind_trusted_local_poster_v2500(li, local)
                except Exception:
                    pass
            self._home_apply_runtime_progress_v2499(li, row, progress_map)
            li.setProperty("PlexKM.HomeSnapshotFastV2499", "1")
            li.setProperty("PlexKM.HomeSnapshotFastV2500", "1")
            return li
        except Exception:
            return None

    def _home_startup_snapshot_fast_enabled_v2499(self):
        """Reuse already-authoritative render snapshots before the final texture gate.

        V2534 keeps V2499's exact snapshot renderer but removes two unnecessary
        prerequisites from *composition*: native-list prebuild and poster prewarm.
        Those are still mandatory before Home is revealed by the existing V2495
        gate.  For a selective Plex change, snapshots from changed sections were
        already rejected by V2487, so only proven-unchanged sections can hit here;
        changed-section items fall back to the original renderer.
        """
        try:
            if not self._startup_full_compose_required_v1643():
                return False
            cause_v2534 = str(getattr(self, "_startup_prepare_cause_v2487", "") or "")
            if cause_v2534 in ("ready", "local_first_v2582", "local_first_v2583"):
                # V2583: established local-first startup is exactly when the
                # persistent Home render cache is most valuable. V2582 skipped
                # this fast path for cause=local_first_v2582, forcing rating,
                # canonical-movie and Watcha bulk work before reveal.
                enabled_v2583 = not bool(getattr(self, "_startup_prepare_required_v2477", False))
                if enabled_v2583 and cause_v2534.startswith("local_first"):
                    _log("UHD3_STARTUP_RENDER_CACHE_ARM_V2583 cause=%s prepare_required=0 static_meta_reuse=1" % cause_v2534)
                return enabled_v2583
            if cause_v2534 == "plex_items_changed":
                changed_v2534 = set(getattr(self, "_startup_changed_section_ids_v2489", set()) or set())
                if not changed_v2534:
                    return False
                has_current_snapshots_v2534 = bool(
                    getattr(self, "_section_render_snapshots_v2473", {})
                    or getattr(self, "_library_render_snapshots_v2473", {})
                )
                if has_current_snapshots_v2534:
                    _log("HOME_STARTUP_SELECTIVE_FASTPATH_ARM_V2534 changed_sections=%s changed_section_reuse=0 final_texture_gate_unchanged=1" % (
                        ",".join(sorted(str(x) for x in changed_v2534)) or "none"
                    ))
                return has_current_snapshots_v2534
            return False
        except Exception:
            return False

    def _home_runtime_snapshot_index_v2499(self):
        """Index already-authoritative native snapshots by exact section/rating key.

        Recommendation snapshots are preferred because Home's Continue/Recent
        rows are subsets of those same per-section destinations. Remembered
        Library snapshots are only a supplement for older Continue items.
        No rating/canonical/network work is performed here.
        """
        cached = getattr(self, "_home_runtime_snapshot_index_v2499_cache", None)
        if isinstance(cached, dict):
            return cached
        started = _pkm_speed_ms()
        out = {}
        rec_added = 0
        lib_added = 0
        local_bound = 0

        def _add_rows(rows, snaps, native_flat, source_name, overwrite=False):
            nonlocal rec_added, lib_added, local_bound
            if not rows or not snaps or len(rows) != len(snaps):
                return
            if native_flat and len(native_flat) != len(rows):
                native_flat = []
            for idx, (entry, snap) in enumerate(zip(rows, snaps)):
                try:
                    values = tuple(entry.get("row") if isinstance(entry, dict) else entry or ())
                    if len(values) < 2:
                        continue
                    rk = str(values[0] or "").strip()
                    sid = str(values[1] or "").strip()
                    if not rk or not sid or not isinstance(snap, dict):
                        continue
                    key = (sid, rk)
                    if key in out and not overwrite:
                        continue
                    snap_copy = {
                        "label": str(snap.get("label") or ""),
                        "props": dict(snap.get("props") or {}),
                        "art": dict(snap.get("art") or {}),
                    }
                    local_path = ""
                    source_authority = str(
                        snap_copy["props"].get("PosterAuthorityV2498")
                        or snap_copy["props"].get("WallPosterRemoteV1644")
                        or snap_copy["props"].get("Thumb")
                        or (values[12] if len(values) > 12 else "")
                        or ""
                    ).strip()
                    if native_flat:
                        try:
                            native_li = native_flat[idx]
                            live_authority = str(native_li.getProperty("PlexKM.PosterAuthorityV2498") or "").strip()
                            if live_authority:
                                source_authority = live_authority
                            local_source = str(native_li.getProperty("PlexKM.PosterLocalSourceV2498") or "").strip()
                            maybe_local = str(native_li.getArt("poster") or "").strip()
                            if local_source and maybe_local and not maybe_local.lower().startswith(("http://", "https://")):
                                local_path = maybe_local
                                local_bound += 1
                        except Exception:
                            local_path = ""
                    if source_authority:
                        snap_copy["props"]["PosterAuthorityV2498"] = source_authority
                        snap_copy["props"]["WallPosterRemoteV1644"] = source_authority
                        snap_copy["props"]["PosterFallbackArt"] = ""
                        snap_copy["props"]["PosterFallbackArtActive"] = ""
                        snap_copy["props"]["PosterFallbackRoleV2498"] = ""
                    out[key] = {
                        "snapshot": snap_copy,
                        "local": local_path,
                        "authority": source_authority,
                        "source": source_name,
                    }
                    if source_name == "recommend":
                        rec_added += 1
                    else:
                        lib_added += 1
                except Exception:
                    continue

        try:
            sections = [dict(sec) for sec in list(getattr(self, "sections", []) or []) if isinstance(sec, dict)]
            for sec in sections:
                sid = str(sec.get("section_id") or sec.get("key") or "").strip()
                if not sid:
                    continue
                rec_key = "recommend:%s" % sid
                rec_rows = list(getattr(self, "_section_rows_cache", {}).get(rec_key) or [])
                rec_snaps = list(getattr(self, "_section_render_snapshots_v2473", {}).get(rec_key) or [])
                rec_groups = list(getattr(self, "_section_prebuilt_listitems_v1644", {}).get(rec_key) or [])
                rec_native = [li for group in rec_groups for li in list(group or [])]
                _add_rows(rec_rows, rec_snaps, rec_native, "recommend", overwrite=False)

                st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid)
                lib_key = str((st or {}).get("cache_key") or "").strip() if isinstance(st, dict) else ""
                if lib_key:
                    lib_rows = list(getattr(self, "_section_rows_cache", {}).get(lib_key) or [])
                    lib_snaps = list(getattr(self, "_library_render_snapshots_v2473", {}).get(lib_key) or [])
                    lib_native = list(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(lib_key) or [])
                    _add_rows(lib_rows, lib_snaps, lib_native, "library", overwrite=False)
        except Exception:
            out = {}

        self._home_runtime_snapshot_index_v2499_cache = out
        self._home_runtime_snapshot_index_v2499_stats = {
            "entries": len(out), "recommend": rec_added, "library": lib_added,
            "local": local_bound, "total_ms": _pkm_speed_ms() - started,
        }
        _log("HOME_STARTUP_SNAPSHOT_INDEX_V2499 entries=%d recommend=%d library_supplement=%d local_bound=%d db_io=0 rating_io=0 canonical=0 network_io=0 total_ms=%d" % (
            len(out), rec_added, lib_added, local_bound, _pkm_speed_ms() - started
        ))
        return out

    def _home_runtime_progress_map_v2499_build(self, rows_cache):
        """Bulk current TV watched totals for snapshot-based Home ListItems."""
        started = _pkm_speed_ms()
        show_keys = set()
        for entry in list(rows_cache or []):
            try:
                values = tuple(entry.get("row") if isinstance(entry, dict) else entry or ())
                ptype = str(values[2] if len(values) > 2 else "").strip().lower()
                if ptype == "show":
                    show_key = str(values[0] if len(values) > 0 else "").strip()
                elif ptype == "episode":
                    show_key = str(values[22] if len(values) > 22 else "").strip()
                else:
                    show_key = ""
                if show_key:
                    show_keys.add(show_key)
            except Exception:
                continue
        result = {}
        if show_keys:
            conn = None
            try:
                dbp = self._profile_db_path()
                if dbp and os.path.exists(dbp):
                    conn = _pkm_ro_connect(dbp, timeout=0.20)
                    keys = sorted(show_keys)
                    step = 180
                    for start in range(0, len(keys), step):
                        chunk = keys[start:start + step]
                        marks = ",".join("?" for _ in chunk)
                        sql = (
                            "SELECT grandparent_rating_key, COUNT(*), "
                            "SUM(CASE WHEN COALESCE(view_count,0) > 0 THEN 1 ELSE 0 END) "
                            "FROM items WHERE plex_type='episode' AND grandparent_rating_key IN (%s) "
                            "GROUP BY grandparent_rating_key" % marks
                        )
                        for show_key, total, watched in conn.execute(sql, tuple(chunk)).fetchall():
                            result[str(show_key or "")] = (int(total or 0), int(watched or 0))
            except Exception:
                result = {}
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
        self._home_runtime_progress_map_v2499 = result
        _log("HOME_PROGRESS_BULK_V2499 show_keys=%d resolved=%d db_queries=%d total_ms=%d" % (
            len(show_keys), len(result), ((len(show_keys) + 179) // 180) if show_keys else 0,
            _pkm_speed_ms() - started
        ))
        return result

    def _home_apply_runtime_progress_v2499(self, li, row, progress_map):
        try:
            values = tuple(row or ())
            if len(values) < 21 or not li:
                return
            rating_key = str(values[0] or "")
            plex_type = str(values[2] or "").strip().lower()
            duration = values[9] if len(values) > 9 else 0
            view_count = values[16] if len(values) > 16 else 0
            grandparent_rating_key = str(values[22] if len(values) > 22 else "").strip()
            view_offset = values[23] if len(values) > 23 else ""
            resume_duration_ms = values[24] if len(values) > 24 else ""
            resume_updated_at = values[25] if len(values) > 25 else ""
            resume_source = values[26] if len(values) > 26 else ""
            try:
                off_ms, dur_ms, media_pct = getattr(_ensure_core(), "_pkm_progress_pair")(
                    view_offset, duration, resume_duration_ms
                )
            except Exception:
                off_ms = 0
                dur_ms = 0
                media_pct = 0
            pct = int(max(0, min(100, _safe_int(media_pct, 0))))
            watched = "1" if _safe_int(view_count, 0) > 0 else ""
            if plex_type in ("movie", "episode") and 0 < pct < 90:
                watched = ""
            show_key = rating_key if plex_type == "show" else (grandparent_rating_key if plex_type == "episode" else "")
            strict_continue_active = bool(
                plex_type == "episode"
                and str(resume_source or "") == "home_continue_active"
                and 0 < pct < 90
            )
            if show_key and show_key in (progress_map or {}) and not strict_continue_active:
                total, watched_count = (progress_map or {}).get(show_key) or (0, 0)
                if int(total or 0) > 0:
                    watched_units = float(watched_count or 0)
                    synthetic_series_progress = (
                        str(resume_source or "") == "home_continue_series_progress"
                    )
                    if (
                        plex_type == "episode"
                        and not synthetic_series_progress
                        and not _safe_int(view_count, 0)
                        and int(dur_ms or 0) > 0
                        and int(off_ms or 0) > 0
                    ):
                        watched_units += max(0.0, min(1.0, float(off_ms) / float(dur_ms)))
                    pct = int(max(0, min(100, round((watched_units * 100.0) / float(total)))))
                    watched = "1" if int(watched_count or 0) >= int(total or 0) else ""
            elif strict_continue_active:
                watched = ""
            try:
                pprops = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(pct) or {}
            except Exception:
                pprops = {}
            li.setProperty("PlexKM.ViewCount", str(view_count or ""))
            li.setProperty("PlexKM.IsWatched", str(watched or ""))
            li.setProperty("PlexKM.ViewOffset", str(view_offset or ""))
            li.setProperty("PlexKM.ResumeDurationMs", str(resume_duration_ms or ""))
            li.setProperty("PlexKM.ResumeUpdatedAt", str(resume_updated_at or ""))
            li.setProperty("PlexKM.ResumeSource", str(resume_source or ""))
            li.setProperty("PlexKM.ResumePercent", str(pprops.get("ResumePercent") or ""))
            li.setProperty("PlexKM.ResumeProgressComposite350x10", str(pprops.get("ResumeProgressComposite350x10") or ""))
            li.setProperty("PlexKM.ResumeProgressComposite370x10", str(pprops.get("ResumeProgressComposite370x10") or ""))
        except Exception:
            pass

    def _home_li_from_runtime_snapshot_v2499(self, entry, snapshot_index, progress_map):
        try:
            if not isinstance(entry, dict):
                return None
            row = entry.get("row")
            values = tuple(row or ())
            if len(values) < 21:
                return None
            rk = str(values[0] or "").strip()
            sid = str(values[1] or "").strip()
            hit = (snapshot_index or {}).get((sid, rk))
            if not isinstance(hit, dict):
                return None
            snapshot = hit.get("snapshot")
            if not isinstance(snapshot, dict):
                return None
            snap_use = {
                "label": str(snapshot.get("label") or ""),
                "props": dict(snapshot.get("props") or {}),
                "art": dict(snapshot.get("art") or {}),
            }
            row_type = str(entry.get("row_type") or "")
            desired_authority = str(hit.get("authority") or "").strip()
            if row_type == "continue":
                # V2497 already converted onDeck stills to the canonical movie/show
                # portrait poster in the current row. That current authority wins
                # over any older persistent section snapshot.
                current_poster = str(values[12] if len(values) > 12 else "").strip()
                if current_poster:
                    desired_authority = current_poster
                    snap_use["props"]["Thumb"] = current_poster
                    snap_use["props"]["WallPosterRemoteV1644"] = current_poster
                    snap_use["props"]["PosterAuthorityV2498"] = current_poster
                    snap_use["art"]["poster"] = current_poster
                    snap_use["art"]["thumb"] = current_poster
                    snap_use["art"]["icon"] = current_poster
            li = self._li_from_render_snapshot_v2473(
                row, snap_use,
                row_title=_display_library_title(entry.get("row_title", "")),
                row_type=row_type,
                row_first=bool(entry.get("row_first")),
                row_id=entry.get("row_id", ""),
                row_start=0,
                row_index=entry.get("row_index", -1),
            )
            if not li:
                return None
            local_path = str(hit.get("local") or "").strip()
            source_authority = str(hit.get("authority") or "").strip()
            if local_path and desired_authority and source_authority == desired_authority:
                # Source ListItem reached this state only through V2498's verified
                # portrait binder. Reusing that exact file does not repeat image IO.
                try:
                    fanart = str(li.getArt("fanart") or "")
                    li.setArt({"poster": local_path, "thumb": local_path, "icon": local_path, "fanart": fanart})
                    li.setProperty("PlexKM.WallPosterDisplayV1644", local_path)
                    li.setProperty("PlexKM.WidgetPosterReadyV1644", "1")
                    li.setProperty("PlexKM.ViewportTextureV1866", "1")
                    li.setProperty("PlexKM.PosterMissingV1963", "")
                    li.setProperty("PlexKM.PosterMissingReasonV1963", "")
                    li.setProperty("PlexKM.PosterLocalSourceV2498", "home_runtime_snapshot_v2499")
                except Exception:
                    pass
            self._home_apply_runtime_progress_v2499(li, row, progress_map)
            li.setProperty("PlexKM.HomeSnapshotFastV2499", "1")
            return li
        except Exception:
            return None

    def _sidebar_selection_snapshot_v1887(self):
        """Return Kodi's actual native sidebar selection without moving focus."""
        try:
            menu = self.getControl(MENU_ID)
            size = int(menu.size() or 0)
            if size <= 0:
                return None
            pos = max(0, min(size - 1, int(menu.getSelectedPosition())))
            item = menu.getListItem(pos)
            if item is None:
                return None
            return {
                "pos": pos,
                "size": size,
                "kind": str(item.getProperty("kind") or ""),
                "sid": str(item.getProperty("section_id") or ""),
                "label": str(item.getLabel() or ""),
            }
        except Exception:
            return None

    # PKM_PATCH_ACTIVE v2621 wall_texture_runway_local_before_visible
    def _library_texture_runway_store_v2621(self, section_id="", rating_key="", canonical="", local_path=""):
        """Remember one already-verified local portrait for zero-I/O GUI handoff."""
        local = str(local_path or "").strip()
        if not local:
            return False
        sid = str(section_id or "").strip()
        rk = str(rating_key or "").strip()
        canonical = str(canonical or "").strip()
        try:
            lock = getattr(self, "_library_texture_runway_lock_v2621", None)
            if lock is None:
                return False
            with lock:
                cache = self._library_texture_runway_local_v2621
                if sid and rk:
                    cache["rk:%s:%s" % (sid, rk)] = local
                if canonical:
                    cache["url:%s" % canonical] = local
                # Session cache only.  Keep it bounded without disk writes.
                while len(cache) > 4096:
                    try:
                        cache.pop(next(iter(cache)))
                    except Exception:
                        break
            return True
        except Exception:
            return False

    def _library_texture_runway_lookup_v2621(self, section_id="", rating_key="", canonical=""):
        try:
            sid = str(section_id or "").strip()
            rk = str(rating_key or "").strip()
            canonical = str(canonical or "").strip()
            lock = getattr(self, "_library_texture_runway_lock_v2621", None)
            if lock is None:
                return ""
            with lock:
                cache = self._library_texture_runway_local_v2621
                if sid and rk:
                    local = str(cache.get("rk:%s:%s" % (sid, rk)) or "").strip()
                    if local:
                        return local
                if canonical:
                    return str(cache.get("url:%s" % canonical) or "").strip()
        except Exception:
            pass
        return ""

    def _queue_library_texture_runway_v2621(self, rows, owner, offset, reason="", distance_pages_v2622=0):
        """Prepare future wall posters before they become visible, without gating DOWN.

        Stage 1 reuses already-decoded Kodi Textures13 files and PKM small-poster
        files. Stage 2 queues unresolved canonical 240x360 Plex images through the
        bounded artwork scheduler.  Android/U+ keeps its single network lane.
        """
        try:
            owner = tuple(owner or ())
            if not owner or len(owner) < 5 or self._closing_event_v1841.is_set():
                return 0
            sid = str(owner[0] or "")
            if not sid or sid != str(getattr(self, "active_section_id", "") or ""):
                return 0
            all_rows_v2623 = list(rows or [])
            if not all_rows_v2623:
                return 0
            distance_pages_v2622 = max(0, int(distance_pages_v2622 or 0))
            tv_deadline_v2623 = bool(self._is_tv_library_section_v1870(sid))
            media_kind_v2625 = "tv" if tv_deadline_v2623 else "movie"
            # V2625: actual Kodi viewport authority is shared by Movie and TV.
            # V2623's TV-only data/deep-page policy remains separate below; only
            # poster transport priority is generalized here.
            viewport_start_v2624 = 0
            viewport_end_v2624 = 18
            viewport_horizon_v2624 = 42
            try:
                if str(getattr(self, "_library_texture_viewport_sid_v2624", "") or "") == sid:
                    viewport_start_v2624 = max(0, int(getattr(self, "_library_texture_viewport_start_v2624", 0) or 0))
                    viewport_end_v2624 = max(
                        viewport_start_v2624,
                        int(getattr(self, "_library_texture_viewport_end_v2624", viewport_start_v2624 + 18) or (viewport_start_v2624 + 18))
                    )
                    if viewport_end_v2624 <= viewport_start_v2624:
                        viewport_end_v2624 = viewport_start_v2624 + 18
                    viewport_horizon_v2624 = viewport_end_v2624 + 24
            except Exception:
                viewport_start_v2624, viewport_end_v2624, viewport_horizon_v2624 = 0, 18, 42
            if tv_deadline_v2623 and distance_pages_v2622 >= 2:
                # V2623: the second deep page is data runway only. Scanning 48
                # Textures13 identities and queuing 20-30 cold downloads this far
                # ahead filled the transport queue with work the user could skip
                # before it ever became visible. Keep the DB rows ready, then let
                # the rolling current/deep1 windows own poster I/O.
                _log("LIBRARY_TV_TEXTURE_DATA_ONLY_V2623 section=%s offset=%d distance_pages=%d rows=%d texture_scan=0 network_queue=0" % (
                    sid, int(offset or 0), distance_pages_v2622, len(all_rows_v2623)
                ))
                return 0
            if tv_deadline_v2623:
                # Current runway: 3 visible rows + 1 safety row. First deep page:
                # exactly the next 3 rows. This bounds cold poster backlog so the
                # single U+ lane works toward deadlines instead of far-future cards.
                window_v2623 = 24 if distance_pages_v2622 <= 0 else 18
                sample = all_rows_v2623[:window_v2623]
            else:
                sample = all_rows_v2623[:48]
            started = time.perf_counter()
            meta = []
            candidates = []
            pkm_ready = 0
            for row in sample:
                t = tuple(row or ())
                rk = str(t[0] or "").strip() if t else ""
                canonical = self._library_row_poster_canonical_v2580(row)
                sources = []
                if canonical:
                    sources.append(canonical)
                for src in self._library_row_poster_sources_v2579(row):
                    src = str(src or "").strip()
                    if src and src not in sources:
                        sources.append(src)
                local_small = self._library_row_poster_local_v2580(row) if canonical else ""
                if local_small:
                    self._library_texture_runway_store_v2621(sid, rk, canonical, local_small)
                    pkm_ready += 1
                meta.append((rk, canonical, local_small))
                candidates.append(tuple(sources))

            # This batch Textures13 lookup runs only on the background prefetch
            # worker.  It can recover an existing Kodi-cached ORIGINAL poster even
            # when V2619's new 240x360 URL itself has never been requested before.
            resolved = self._poster_primary_local_paths_v2498(candidates)
            texture_ready = 0
            for (rk, canonical, local_small), local in zip(meta, resolved):
                local = str(local or "").strip()
                if local and not local_small:
                    self._library_texture_runway_store_v2621(sid, rk, canonical, local)
                    texture_ready += 1

            payloads = []
            already_ready = 0
            for idx, ((rk, canonical, _local_small), local_cached) in enumerate(zip(meta, resolved)):
                if not canonical:
                    continue
                if self._library_texture_runway_lookup_v2621(sid, rk, canonical):
                    already_ready += 1
                    continue
                # V2625: Movie and TV poster priority both follow the REAL
                # selected Kodi viewport. Append/data frontiers never grant
                # VISIBLE priority. Keep only current 18 + next 24 near-ahead
                # cards armed; farther poster I/O is deferred until relevant.
                absolute_index_v2624 = int(offset or 0) + int(idx)
                if absolute_index_v2624 < max(0, viewport_start_v2624 - 6):
                    continue
                if viewport_start_v2624 <= absolute_index_v2624 < viewport_end_v2624:
                    priority = pkm_artwork_scheduler.PRIORITY_VISIBLE
                elif absolute_index_v2624 < viewport_horizon_v2624:
                    priority = pkm_artwork_scheduler.PRIORITY_AHEAD
                else:
                    continue
                token = "v2621runway:%s:%s" % (sid, rk or hashlib.sha1(canonical.encode("utf-8", "ignore")).hexdigest())
                payloads.append({
                    "token": token,
                    "remote": canonical,
                    "fallback": "",
                    "priority": int(priority),
                    "section_id": sid,
                    "rating_key_v2621": rk,
                    "canonical_v2621": canonical,
                    "absolute_index_v2622": int(absolute_index_v2624),
                    "media_kind_v2625": media_kind_v2625,
                    "distance_pages_v2622": distance_pages_v2622,
                    "generation": int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0),
                    "discard_on_generation": 1,
                    # Runway work is stable future content. Do NOT cancel it every
                    # time the selected viewport generation changes.
                    "discard_on_viewport_v2594": 0,
                })

            added = 0
            purged_stale_v2622 = 0
            purged_section_v2622 = 0
            if payloads:
                with self._wall_poster_prefetch_lock_v1644:
                    # V2622: do not let already-passed runway cards or the prior
                    # section consume the download lane. V2621 intentionally kept
                    # all future work stable, which left a long cold-TV backlog.
                    keep_v2622 = []
                    # V2625: stale purge follows the actual viewport, never the
                    # append/data offset. Otherwise a future Movie append (for
                    # example offset 144 while viewport is 108-125) could delete
                    # the very visible-missing jobs we are trying to prioritize.
                    stale_before_v2622 = max(0, int(viewport_start_v2624) - 6)
                    for old_v2622 in list(self._wall_poster_prefetch_queue_v1644):
                        tok_v2622 = str((old_v2622 or {}).get("token") or "")
                        sec_v2622 = str((old_v2622 or {}).get("section_id") or "")
                        abs_v2622 = int((old_v2622 or {}).get("absolute_index_v2622") or -1)
                        is_runway_v2622 = tok_v2622.startswith("v2621runway:")
                        if is_runway_v2622 and sec_v2622 and sec_v2622 != sid:
                            self._wall_poster_prefetch_seen_v1644.discard(tok_v2622)
                            purged_section_v2622 += 1
                            continue
                        if (distance_pages_v2622 <= 0 and is_runway_v2622 and sec_v2622 == sid
                                and abs_v2622 >= 0 and abs_v2622 < stale_before_v2622):
                            self._wall_poster_prefetch_seen_v1644.discard(tok_v2622)
                            purged_stale_v2622 += 1
                            continue
                        keep_v2622.append(old_v2622)
                    self._wall_poster_prefetch_queue_v1644[:] = keep_v2622
                    max_queue = min(120, max(72, int(getattr(self, "_wall_poster_prefetch_max_queue_v1841", 192) or 192)))
                    for payload in payloads:
                        if len(self._wall_poster_prefetch_queue_v1644) >= max_queue:
                            break
                        token = str(payload.get("token") or "")
                        if not token or token in self._wall_poster_prefetch_seen_v1644:
                            continue
                        self._wall_poster_prefetch_seen_v1644.add(token)
                        self._wall_poster_prefetch_queue_v1644.append(payload)
                        added += 1
                    # V2625 common wall sort: priority first, then absolute
                    # distance from the real viewport for both Movie and TV.
                    self._wall_poster_prefetch_queue_v1644.sort(
                        key=lambda payload: (
                            int(payload.get("priority") if payload.get("priority") is not None else pkm_artwork_scheduler.PRIORITY_BACKGROUND),
                            abs(int(payload.get("absolute_index_v2622") or 0) - int(viewport_start_v2624))
                            if str(payload.get("section_id") or "") == sid and str(payload.get("token") or "").startswith("v2621runway:") else 999999
                        )
                    )
                if added:
                    self._start_wall_poster_workers_v1644()
            if purged_stale_v2622 or purged_section_v2622:
                _log("LIBRARY_TEXTURE_QUEUE_PURGE_V2622 section=%s offset=%d stale=%d other_section=%d queue=%d" % (
                    sid, int(offset or 0), purged_stale_v2622, purged_section_v2622,
                    len(getattr(self, "_wall_poster_prefetch_queue_v1644", []) or [])
                ))
            _log("LIBRARY_TEXTURE_RUNWAY_ARM_V2621 section=%s offset=%d rows=%d local_ready=%d pkm_small=%d kodi_texture=%d queued=%d unresolved=%d scan_ms=%.1f scheduler_limit=%d navigation_gate=0" % (
                sid, int(offset or 0), len(sample), already_ready, pkm_ready, texture_ready,
                added, max(0, len(payloads) - added), (time.perf_counter() - started) * 1000.0,
                int(pkm_artwork_scheduler.MAX_ACTIVE_DOWNLOADS)
            ))
            _log("LIBRARY_TEXTURE_RUNWAY_DEPTH_V2622 section=%s offset=%d distance_pages=%d visible_priority_rows=%d queued=%d" % (
                sid, int(offset or 0), distance_pages_v2622, 18 if distance_pages_v2622 <= 0 else 0, added
            ))
            if tv_deadline_v2623:
                _log("LIBRARY_TV_TEXTURE_DEADLINE_WINDOW_V2623 section=%s offset=%d distance_pages=%d source_rows=%d scan_rows=%d local_ready=%d queued=%d queue_cap_scope=%s" % (
                    sid, int(offset or 0), distance_pages_v2622, len(all_rows_v2623), len(sample),
                    already_ready, added, "current24" if distance_pages_v2622 <= 0 else "deep1_18"
                ))
                _log("LIBRARY_TV_VIEWPORT_QUEUE_V2624 section=%s offset=%d viewport=%d-%d horizon=%d distance_pages=%d queued=%d append_frontier_visible=0" % (
                    sid, int(offset or 0), viewport_start_v2624, max(viewport_start_v2624, viewport_end_v2624 - 1),
                    max(viewport_start_v2624, viewport_horizon_v2624 - 1), distance_pages_v2622, added
                ))
            _log("LIBRARY_WALL_VIEWPORT_QUEUE_V2625 media=%s section=%s offset=%d viewport=%d-%d horizon=%d distance_pages=%d queued=%d append_frontier_visible=0" % (
                media_kind_v2625, sid, int(offset or 0), viewport_start_v2624, max(viewport_start_v2624, viewport_end_v2624 - 1),
                max(viewport_start_v2624, viewport_horizon_v2624 - 1), distance_pages_v2622, added
            ))
            return added
        except Exception:
            _log("LIBRARY_TEXTURE_RUNWAY_FAILED_V2621 section=%s offset=%s err=%s" % (
                str(getattr(self, "active_section_id", "") or ""), offset,
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0

    def _library_texture_promote_visible_v2622(self, sid, missing):
        """Make the actual Kodi viewport the sole Movie/TV poster authority.

        V2625 generalizes V2624's TV fix to Movie wall mode: future append pages
        can never retain VISIBLE priority while the selected viewport still has
        missing posters. Queue edits are memory-only; workers own all network I/O.
        """
        try:
            sid = str(sid or "").strip()
            normalized_missing_v2622 = []
            for entry_v2622 in list(missing or []):
                try:
                    rk_v2622 = str(entry_v2622[0] or "").strip()
                    url_v2622 = str(entry_v2622[1] or "").strip()
                    idx_v2622 = int(entry_v2622[2]) if len(entry_v2622) > 2 else -1
                except Exception:
                    continue
                if url_v2622:
                    normalized_missing_v2622.append((rk_v2622, url_v2622, idx_v2622))
            missing = normalized_missing_v2622
            if not sid:
                return 0
            wanted = set(url for _rk, url, _idx in missing)
            promoted = 0
            added = 0
            purged = 0
            demoted = 0
            far_purged = 0
            try:
                viewport_start_v2624 = max(0, int(getattr(self, "_library_texture_viewport_start_v2624", 0) or 0))
                viewport_end_v2624 = max(viewport_start_v2624, int(getattr(self, "_library_texture_viewport_end_v2624", viewport_start_v2624 + 18) or (viewport_start_v2624 + 18)))
            except Exception:
                viewport_start_v2624, viewport_end_v2624 = 0, 18
            viewport_horizon_v2624 = viewport_start_v2624 + 42
            stale_before = max(0, viewport_start_v2624 - 6)
            is_tv_v2624 = bool(self._is_tv_library_section_v1870(sid))
            media_kind_v2625 = "tv" if is_tv_v2624 else "movie"
            with self._wall_poster_prefetch_lock_v1644:
                kept = []
                for payload in list(self._wall_poster_prefetch_queue_v1644):
                    token = str((payload or {}).get("token") or "")
                    sec = str((payload or {}).get("section_id") or "")
                    abs_idx = int((payload or {}).get("absolute_index_v2622") or -1)
                    is_runway = token.startswith("v2621runway:")
                    if is_runway and sec == sid and abs_idx >= 0:
                        if abs_idx < stale_before:
                            self._wall_poster_prefetch_seen_v1644.discard(token)
                            purged += 1
                            continue
                        if abs_idx >= viewport_horizon_v2624:
                            # Data remains cached by V2622. Drop only poster I/O;
                            # the row will be re-armed when it enters the 42-card
                            # viewport horizon.
                            self._wall_poster_prefetch_seen_v1644.discard(token)
                            far_purged += 1
                            continue
                        old_priority = int((payload or {}).get("priority") or pkm_artwork_scheduler.PRIORITY_BACKGROUND)
                        new_priority = (pkm_artwork_scheduler.PRIORITY_VISIBLE
                                        if viewport_start_v2624 <= abs_idx < viewport_end_v2624
                                        else pkm_artwork_scheduler.PRIORITY_AHEAD)
                        if old_priority != int(new_priority):
                            if int(new_priority) < old_priority:
                                promoted += 1
                            else:
                                demoted += 1
                            payload["priority"] = int(new_priority)
                    remote = str((payload or {}).get("remote") or "")
                    if sec == sid and remote in wanted:
                        if int((payload or {}).get("priority") or pkm_artwork_scheduler.PRIORITY_BACKGROUND) != int(pkm_artwork_scheduler.PRIORITY_VISIBLE):
                            payload["priority"] = int(pkm_artwork_scheduler.PRIORITY_VISIBLE)
                            promoted += 1
                    kept.append(payload)
                self._wall_poster_prefetch_queue_v1644[:] = kept
                queued_urls = set(str((payload or {}).get("remote") or "") for payload in kept if str((payload or {}).get("section_id") or "") == sid)
                for rk, canonical, absolute_idx_v2622 in missing:
                    if canonical in queued_urls:
                        continue
                    token = "v2621runway:%s:%s" % (sid, rk or hashlib.sha1(canonical.encode("utf-8", "ignore")).hexdigest())
                    if token in self._wall_poster_prefetch_seen_v1644:
                        continue
                    self._wall_poster_prefetch_seen_v1644.add(token)
                    self._wall_poster_prefetch_queue_v1644.append({
                        "token": token, "remote": canonical, "fallback": "",
                        "priority": int(pkm_artwork_scheduler.PRIORITY_VISIBLE),
                        "section_id": sid, "rating_key_v2621": rk, "canonical_v2621": canonical,
                        "absolute_index_v2622": int(absolute_idx_v2622),
                        "media_kind_v2625": media_kind_v2625,
                        "generation": int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0),
                        "discard_on_generation": 1, "discard_on_viewport_v2594": 0,
                    })
                    added += 1
                self._wall_poster_prefetch_queue_v1644.sort(
                    key=lambda payload: (
                        int(payload.get("priority") if payload.get("priority") is not None else pkm_artwork_scheduler.PRIORITY_BACKGROUND),
                        abs(int(payload.get("absolute_index_v2622") or 0) - int(viewport_start_v2624))
                        if str(payload.get("section_id") or "") == sid and str(payload.get("token") or "").startswith("v2621runway:") else 999999
                    )
                )
            if promoted or added:
                self._start_wall_poster_workers_v1644()
            try:
                self._library_texture_visible_missing_v2624 = int(len(missing))
            except Exception:
                pass
            if promoted or added or purged or demoted or far_purged:
                if is_tv_v2624:
                    _log("LIBRARY_TV_VIEWPORT_QUEUE_RECLASS_V2624 section=%s viewport=%d-%d missing=%d promoted=%d added=%d demoted=%d stale_purged=%d far_purged=%d network_wait=0" % (
                        sid, viewport_start_v2624, max(viewport_start_v2624, viewport_end_v2624 - 1), len(missing),
                        promoted, added, demoted, purged, far_purged
                    ))
                _log("LIBRARY_WALL_VIEWPORT_QUEUE_RECLASS_V2625 media=%s section=%s viewport=%d-%d missing=%d promoted=%d added=%d demoted=%d stale_purged=%d far_purged=%d network_wait=0" % (
                    media_kind_v2625, sid, viewport_start_v2624, max(viewport_start_v2624, viewport_end_v2624 - 1), len(missing),
                    promoted, added, demoted, purged, far_purged
                ))
            if promoted or added or purged:
                _log("LIBRARY_TEXTURE_VISIBLE_PROMOTE_V2622 section=%s missing=%d promoted=%d added=%d stale_purged=%d network_wait=0" % (
                    sid, len(missing), promoted, added, purged
                ))
            return int(promoted + added)
        except Exception:
            return 0

    def _library_texture_runway_apply_visible_v2621(self, reason=""):
        """Swap current + next two native wall rows to ready local files only."""
        try:
            if self._safe_focus_id() != WALL_ID or self.getProperty("PlexKM.Window.IsSectionWall") != "1":
                return 0
            wall = self.getControl(WALL_ID)
            size = int(wall.size())
            if size <= 0:
                return 0
            pos = int(wall.getSelectedPosition())
            cols = max(1, int(self._wall_column_count() or 6))
            row_start = max(0, (max(0, pos) // cols) * cols)
            end = min(size, row_start + cols * 3)
            sid = str(getattr(self, "active_section_id", "") or "")
            # V2624 GUI-owned primitive viewport snapshot. Background poster
            # workers use this instead of reading Kodi controls.
            try:
                self._library_texture_viewport_sid_v2624 = sid
                self._library_texture_viewport_start_v2624 = int(row_start)
                self._library_texture_viewport_end_v2624 = int(end)
                self._library_texture_viewport_stamp_v2624 = int(self._now_ms())
            except Exception:
                pass
            bound = 0
            ready_seen = 0
            missing_v2622 = []
            for idx in range(row_start, end):
                li = wall.getListItem(idx)
                if li is None:
                    continue
                rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                canonical = str(li.getProperty("PlexKM.PosterAuthorityV2498") or li.getProperty("PlexKM.WallPosterRemoteV1644") or "").strip()
                local = self._library_texture_runway_lookup_v2621(sid, rk, canonical)
                if not local:
                    if canonical:
                        missing_v2622.append((rk, canonical, idx))
                    continue
                ready_seen += 1
                current = str(li.getArt("poster") or "").strip()
                if current == local:
                    continue
                fanart = str(li.getArt("fanart") or "")
                li.setArt({"poster": local, "thumb": local, "icon": local, "fanart": fanart})
                li.setProperty("PlexKM.WallPosterDisplayV1644", local)
                li.setProperty("PlexKM.WidgetPosterReadyV1644", "1")
                li.setProperty("PlexKM.ViewportTextureV1866", "1")
                li.setProperty("PlexKM.PosterLocalSourceV2498", "runway_visible_v2621")
                li.setProperty("PlexKM.PosterMissingV1963", "")
                li.setProperty("PlexKM.PosterMissingReasonV1963", "")
                bound += 1
            try:
                self._library_texture_visible_missing_v2624 = int(len(missing_v2622))
            except Exception:
                pass
            promoted_v2622 = self._library_texture_promote_visible_v2622(sid, missing_v2622)
            if bound or missing_v2622:
                _log("LIBRARY_TEXTURE_RUNWAY_VISIBLE_COMMIT_V2621 section=%s pos=%d range=%d-%d ready=%d rebound=%d reason=%s db=0 network=0 selection_write=0" % (
                    sid, pos, row_start, max(row_start, end - 1), ready_seen, bound, reason or ""
                ))
                _log("LIBRARY_TEXTURE_VISIBLE_STATE_V2622 section=%s pos=%d ready=%d missing=%d promoted=%d target=%d" % (
                    sid, pos, ready_seen, len(missing_v2622), int(promoted_v2622 or 0), max(0, end-row_start)
                ))
            return bound
        except Exception:
            return 0

    def _library_texture_runway_commit_v2621(self):
        try:
            lock = getattr(self, "_library_texture_commit_lock_v2621", None)
            if lock is None:
                return False
            with lock:
                pending = bool(getattr(self, "_library_texture_commit_pending_v2621", False))
                self._library_texture_commit_pending_v2621 = False
                self._library_texture_commit_active_v2621 = False
            if not pending:
                return False
            self._library_texture_runway_apply_visible_v2621(reason="post_native_key")
            return True
        except Exception:
            return False

    def _schedule_library_texture_runway_commit_v2621(self):
        """Post a 20 ms GUI callback; key handler does no poster file/DB/network I/O."""
        try:
            lock = getattr(self, "_library_texture_commit_lock_v2621", None)
            if lock is None:
                return False
            with lock:
                self._library_texture_commit_pending_v2621 = True
                if bool(getattr(self, "_library_texture_commit_active_v2621", False)):
                    return True
                self._library_texture_commit_active_v2621 = True
            def _post_v2621():
                posted = False
                try:
                    if self._closing_event_v1841.wait(0.020):
                        return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    posted = True
                except Exception:
                    pass
                finally:
                    if not posted:
                        try:
                            with lock:
                                self._library_texture_commit_active_v2621 = False
                        except Exception:
                            pass
            _PKMHomeThreadV2151(target=_post_v2621, name="PKMWallTextureV2621", daemon=True).start()
            return True
        except Exception:
            return False


    def _publish_section_scene_atomic_v1619(self, target_bank, cache_key, title, count_text, meta_snapshot, reason=""):
        """Publish header, hero metadata and target A/B bank in one tight block."""
        # PKM_PATCH_ACTIVE v2572 sidebar_first_widget_meta_publish_restore
        # PKM_PATCH_ACTIVE v2573 uhd3_startup_parallel_latest_guard_sidebar_repeat_noop_phase2
        # PKM_PATCH_ACTIVE v2574 uhd3_incremental_add_duplicate_sync_skip_sidebar_latest_target_hard_cancel
        firstpaint_token_v2547r2 = ""
        source_bank_v2547r2 = ""
        try:
            if str(getattr(self, "active_section_id", "") or "") != str(cache_key or ""):
                _log("SECTION_SCENE_ATOMIC_ABORT_V1619 reason=%s target=%s active=%s" % (
                    reason or "", cache_key or "", getattr(self, "active_section_id", "") or ""
                ), xbmc.LOGWARNING)
                return False
            # v1887: active_section_id is Python's last committed intent, not
            # necessarily Kodi XML's current sidebar selection.  Validate the
            # actual selected menu item immediately before the single A/B flip.
            # A stale render must never publish under a different highlighted
            # library.  The old completed scene remains visible, the stale gate
            # is released, and the native selected item starts its own transaction.
            target_sid_v1887 = ""
            try:
                key_text_v1887 = str(cache_key or "")
                if key_text_v1887.startswith("recommend:"):
                    target_sid_v1887 = key_text_v1887.split(":", 1)[1]
            except Exception:
                target_sid_v1887 = ""
            if target_sid_v1887 and bool(getattr(self, "menu_ready", False)):
                snap_v1887 = self._sidebar_selection_snapshot_v1887()
                if snap_v1887 and (
                        snap_v1887.get("kind") != "section"
                        or str(snap_v1887.get("sid") or "") != target_sid_v1887):
                    _log("SECTION_SCENE_MENU_OWNER_ABORT_V1887 reason=%s target=%s target_sid=%s selected_pos=%s selected_kind=%s selected_sid=%s selected_label=%s active_menu_index=%s previous_scene_kept=1" % (
                        reason or "", cache_key or "", target_sid_v1887,
                        snap_v1887.get("pos"), snap_v1887.get("kind"),
                        snap_v1887.get("sid"), _short_log_value(snap_v1887.get("label")),
                        getattr(self, "active_menu_index", -1),
                    ), xbmc.LOGWARNING)
                    try:
                        self._section_first_visit_gate_cancel_v1620(
                            reason="menu_owner_changed_v1887", only_if_key=cache_key
                        )
                    except Exception:
                        pass
                    self._sync_sidebar_selection_owner_v1887(
                        aid=0, reason="atomic_publish_owner_guard_v1887"
                    )
                    return False
            # v2121 fast-key hard boundary: even if a RIGHT/UP/DOWN action was
            # already queued before Python armed the first-visit gate, never
            # replace the old visible surface underneath a control that now owns
            # native focus.  Same-section tab/mode changes remain allowed because
            # their published section id already equals the target.
            if target_sid_v1887:
                _actual_focus_v2121 = int(self._safe_focus_id() or 0)
                _published_sid_v2121 = self._published_section_id_v2121()
                if (_actual_focus_v2121 > 0 and _actual_focus_v2121 != MENU_ID
                        and _published_sid_v2121 != target_sid_v1887):
                    _log("FAST_NAV_PUBLISH_ABORT_V2121 target_sid=%s published_sid=%s actual_focus=%s reason=%s previous_scene_kept=1 python_focus_write=0" % (
                        target_sid_v1887, _published_sid_v2121 or "home",
                        _actual_focus_v2121, reason or ""
                    ), xbmc.LOGWARNING)
                    try:
                        self._section_first_visit_gate_cancel_v1620(
                            reason="fast_nav_focus_left_menu_v2121", only_if_key=cache_key
                        )
                    except Exception:
                        pass
                    return False
            title = _display_library_title(title)
            count_text = _display_library_title(count_text)
            win = xbmcgui.Window(10000)
            source_mode_v2479 = self._pkm_surface_mode_v2479()
            # V2572: a persistent/ready A/B scene may legitimately have complete
            # poster rows but an empty legacy hero snapshot (props={}, rating_key='').
            # V2570 made those ready banks much more common by preparing destinations
            # before Home reveal.  Never publish that empty snapshot when the first
            # target ListItem already contains the correct local metadata.  Re-capture
            # the first visible item's metadata from the completed target bank using
            # the existing capture-only hot path.  capture_v1619 is explicitly
            # cache/ListItem-only (no Plex request, no DB lookup, no focus write).
            try:
                _meta_props_v2572 = dict((meta_snapshot or {}).get("props") or {}) if isinstance(meta_snapshot, dict) else {}
                _meta_valid_v2572 = bool(
                    str(_meta_props_v2572.get("RatingKey") or "")
                    or str(_meta_props_v2572.get("Title") or "")
                    or str((meta_snapshot or {}).get("hero_title") or "")
                )
            except Exception:
                _meta_valid_v2572 = False
            if not _meta_valid_v2572:
                try:
                    _bank_ids_v2572 = self._section_bank_row_ids_v1612(target_bank)
                    _first_li_v2572 = None
                    if _bank_ids_v2572:
                        _first_ctrl_v2572 = self.getControl(_bank_ids_v2572[0])
                        if int(_first_ctrl_v2572.size() or 0) > 0:
                            _first_li_v2572 = _first_ctrl_v2572.getListItem(0)
                    if _first_li_v2572 is not None:
                        _repair_v2572 = self._capture_home_meta_snapshot_v1619(
                            _first_li_v2572, reason="section_publish_first_item_v2572"
                        )
                        _repair_props_v2572 = dict((_repair_v2572 or {}).get("props") or {}) if isinstance(_repair_v2572, dict) else {}
                        if (str(_repair_props_v2572.get("RatingKey") or "")
                                or str(_repair_props_v2572.get("Title") or "")
                                or str((_repair_v2572 or {}).get("hero_title") or "")):
                            meta_snapshot = _repair_v2572
                            try:
                                _scene_v2572 = (getattr(self, "_section_scene_cache_v1620", {}) or {}).get(str(cache_key or ""))
                                if isinstance(_scene_v2572, dict):
                                    _scene_v2572["meta"] = self._section_scene_snapshot_safe_v1620(_repair_v2572)
                            except Exception:
                                pass
                            _log("SECTION_FIRST_ITEM_META_REPAIR_V2572 key=%s bank=%s title=%s rating_key=%s source=bound_listitem cache_only=1 network=0 db=0" % (
                                cache_key or "", str(target_bank or "").upper(),
                                _short_log_value((_repair_v2572 or {}).get("hero_title") or _repair_props_v2572.get("Title") or ""),
                                _repair_props_v2572.get("RatingKey") or ""
                            ))
                        else:
                            _log("SECTION_FIRST_ITEM_META_REPAIR_MISS_V2572 key=%s bank=%s reason=capture_empty" % (
                                cache_key or "", str(target_bank or "").upper()
                            ), xbmc.LOGWARNING)
                    else:
                        _log("SECTION_FIRST_ITEM_META_REPAIR_MISS_V2572 key=%s bank=%s reason=no_first_listitem" % (
                            cache_key or "", str(target_bank or "").upper()
                        ), xbmc.LOGWARNING)
                except Exception:
                    _log("SECTION_FIRST_ITEM_META_REPAIR_FAILED_V2572 key=%s bank=%s err=%s" % (
                        cache_key or "", str(target_bank or "").upper(),
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            # All expensive metadata work was completed in capture mode.  v2479
            # changes the ownership order: when Recommend is not the current scene,
            # flip its already-complete A/B bank while the whole Recommend group is
            # still hidden.  Only after one GUI frame do we retire the source mode.
            # R116: hero text/fanart used to be published here, before the A/B
            # bank swap, the 80 ms first-paint hold and the Home->Recommend mode
            # flip, so the new title sat over the previous scene's widgets and
            # art for 0.1-0.25 s on SHIELD.  Publish it with the mode flip below.
            meta_published_r116 = False
            # v2547r2: C1:E1 / Textures13 readiness proves cache presence, not
            # a real first paint.  For section->section A/B swaps, switch the
            # logical active bank under a bank-level 1%% visual hold, keep the
            # old bank at 100%%, cross 80ms of real GUI time, then release the
            # normal 200ms crossfade.  Poster and watched/progress overlays are
            # in the same bank group, so they become visible atomically.
            source_bank_v2547r2 = str(self._section_bank_name_v1612() or "A").upper()
            if source_mode_v2479 == "section_recommend" and source_bank_v2547r2 != str(target_bank or "").upper():
                firstpaint_token_v2547r2 = self._section_firstpaint_hold_begin_v2547r2(
                    target_bank, cache_key=cache_key, reason=reason or "section_scene"
                )
            swapped = self._section_set_active_bank_v1612(
                target_bank, cache_key=cache_key, reason="atomic_v2479:%s" % (reason or "")
            )
            if not swapped:
                if firstpaint_token_v2547r2:
                    self._section_firstpaint_hold_clear_v2547r2(
                        firstpaint_token_v2547r2, reason="active_bank_swap_failed"
                    )
                return False
            if firstpaint_token_v2547r2:
                settled_v2547r2, settle_ms_v2547r2, settle_reason_v2547r2 = self._section_firstpaint_post_active_settle_v2547r2(
                    target_bank, cache_key=cache_key, token=firstpaint_token_v2547r2,
                    reason=reason or "section_scene", settle_ms=80
                )
                if not settled_v2547r2:
                    try:
                        self._section_set_active_bank_v1612(
                            source_bank_v2547r2, cache_key="",
                            reason="firstpaint_stale_rollback_v2547r2:%s" % (reason or "")
                        )
                    except Exception:
                        pass
                    self._section_firstpaint_hold_clear_v2547r2(
                        firstpaint_token_v2547r2, reason="stale:%s" % settle_reason_v2547r2
                    )
                    _log("SECTION_FIRSTPAINT_STALE_ABORT_V2547R2 key=%s target_bank=%s source_bank=%s wait_ms=%d cause=%s previous_scene_kept=1" % (
                        cache_key or "", str(target_bank or "").upper(), source_bank_v2547r2,
                        settle_ms_v2547r2, settle_reason_v2547r2
                    ), xbmc.LOGWARNING)
                    return False
                self._section_firstpaint_hold_clear_v2547r2(
                    firstpaint_token_v2547r2, reason="render_settled_release"
                )
                _log("SECTION_FIRSTPAINT_ATOMIC_RELEASE_V2547R2 key=%s bank=%s wait_ms=%d poster_overlay_same_reveal=1 source_bank_held=1" % (
                    cache_key or "", str(target_bank or "").upper(), settle_ms_v2547r2
                ))
                firstpaint_token_v2547r2 = ""
            if source_mode_v2479 == "section_recommend":
                _log("SECTION_RECOMMEND_AB_CROSSFADE_V2707 bank=%s fade_ms=150 tween=linear old_bank_preserved=1 no_blank=1 reason=%s" % (
                    str(target_bank or "").upper(), reason or ""
                ))
            # R35: retire Info/Actor at this destination commit boundary (R18 parity).
            if source_mode_v2479 in ("info", "actor_profile"):
                self._section_commit_overlay_retire_r35("section_recommend", reason=reason or "section_scene")
                source_mode_v2479 = str(self._pkm_surface_mode_v2479() or "home")
            swap_token_v2479 = ""
            if source_mode_v2479 != "section_recommend":
                swap_token_v2479 = self._pkm_swap_settle_v2479(
                    source_mode_v2479, "section_recommend", reason="recommend_target_bank_ready:%s" % (reason or ""), wait_ms=16
                )
            for target in (self, win):
                # v2503: the preflight fade flag may intentionally survive while
                # Library is visible.  Reset it while Recommendation is still
                # hidden, before publishing the prepared Recommendation bank.
                target.clearProperty("PlexKM.Scene.RecommendWidgetFadeOutV2503")
                target.setProperty("PlexKM.Window.HomeLayout", "1")
                target.setProperty("PlexKM.Window.IsSectionRecommend", "1")
                target.clearProperty("PlexKM.Window.IsSectionWall")
                target.clearProperty("PlexKM.Window.IsSectionCategory")
                target.clearProperty("PlexKM.Window.IsHome")
                target.setProperty("PlexKM.Window.Title", title or "")
                target.setProperty("PlexKM.Window.CountLabel", count_text or "")
            if not meta_published_r116:
                meta_published_r116 = True
                self._apply_home_meta_snapshot_v1619(meta_snapshot, reason=reason or "section_scene")
                try:
                    self.getControl(COUNT_ID).setLabel(count_text or "")
                except Exception:
                    pass
            if swap_token_v2479:
                self._pkm_swap_finish_v2479(
                    swap_token_v2479, source_mode_v2479, "section_recommend", reason="recommend_mode_commit:%s" % (reason or "")
                )
            if target_sid_v1887:
                self._set_published_section_id_v2121(
                    target_sid_v1887, reason="recommend_commit:%s" % (reason or "")
                )
            self._section_stage_bank_clear_v1612(reason="atomic_publish_v1619:%s" % (reason or ""))
            try:
                self._search_info_sidebar_ab_commit_v2284(
                    section_id=target_sid_v1887, reason="recommend_atomic:%s" % (reason or "")
                )
            except Exception:
                pass
            self._clear_sidebar_menu_browsing_later(reason="atomic_publish_v1619:%s" % (reason or ""), delay_ms=620)
            _log("SECTION_SCENE_ATOMIC_COMMIT_V1619 reason=%s bank=%s cache_key=%s title=%s whole_scene=1 no_cover=1" % (
                reason or "", str(target_bank or "").upper(), cache_key or "", _short_log_value(title)
            ))
            return True
        except Exception:
            if firstpaint_token_v2547r2:
                try:
                    self._section_firstpaint_hold_clear_v2547r2(
                        firstpaint_token_v2547r2, reason="publish_exception"
                    )
                except Exception:
                    pass
            _log("SECTION_SCENE_ATOMIC_COMMIT_FAILED_V1619 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _menu_refresh_snapshot_v1906(self):
        """Read only the native sidebar selection for transaction diagnostics."""
        try:
            menu = self.getControl(MENU_ID)
            pos = int(menu.getSelectedPosition())
            item = menu.getListItem(pos) if pos >= 0 else None
            kind = str(item.getProperty("kind") or "") if item else ""
            sid = str(item.getProperty("section_id") or "") if item else ""
            label = str(item.getLabel() or "") if item else ""
            return pos, kind, sid, label
        except Exception:
            return -1, "", "", ""

    def _sort_head_prewarm_worker_v2628(self, sid, media, sort_key, sort_dir, genre, signature, priority):
        """Pre-materialize the first 12 poster files for one likely sort target.

        This worker is entirely post-visible/background.  It never owns focus,
        ListItems, a scene spinner, or a foreground wait.  The normal V2496 gate
        remains authoritative; this only makes that gate a cache hit when the
        user confirms a sort that was already highlighted in the dropdown.
        """
        started = _pkm_speed_ms()
        requested = local_ready = downloaded = unresolved = 0
        try:
            if self._closing_event_v1841.is_set() or (self._is_android_v2591() and pkm_sort_index_v2626.background_blocked_u3()):
                return
            query = pkm_sort_index_v2626.query_tv if str(media) == "tv" else pkm_sort_index_v2626.query_movie
            rows = query(
                str(sid), str(sort_key), str(sort_dir), 12, 0,
                genre=(str(genre or "") or None), random_seed=0,
            )
            if rows is None:
                _log("SORT_HEAD_PREWARM_SKIP_V2628 section=%s media=%s sort=%s dir=%s reason=index_not_ready" % (
                    sid, media, sort_key, sort_dir
                ))
                return
            rows = list(rows or [])[:12]
            requested = len(rows)
            source_sets = []
            jobs = []
            for row in rows:
                t = tuple(row or ())
                rk = str(t[0] if len(t) > 0 else "").strip()
                thumb = str(t[12] if len(t) > 12 else "").strip()
                source_sets.append([thumb] if thumb else [])
                jobs.append((rk, thumb))

            # Reuse Kodi's exact texture cache first, then PKM's persistent
            # server-small poster cache.  No GUI object is retained here.
            exact_local = self._poster_primary_local_paths_v2498(source_sets)
            missing = []
            for idx, (rk, thumb) in enumerate(jobs):
                local = str(exact_local[idx] if idx < len(exact_local) else "").strip()
                if local and self._local_portrait_poster_file_ready_v2498(local):
                    local_ready += 1
                    continue
                small_url = self._viewport_poster_url_v1937((thumb,), rating_key=rk)
                small_local = self._wall_poster_local_path_v1644(small_url) if small_url else ""
                if small_local and self._local_poster_file_ready_v1865(small_local):
                    local_ready += 1
                    continue
                if small_url:
                    missing.append((rk, small_url))
                else:
                    # No authoritative poster source: the regular firstpaint path
                    # will render the stable missing-poster card without network.
                    local_ready += 1

            def cancelled_v2628():
                if self._is_android_v2591() and pkm_sort_index_v2626.background_blocked_u3():
                    return True
                if self._closing_event_v1841.is_set():
                    return True
                try:
                    active = set(getattr(self, "_sort_head_allowed_v2628", set()) or set())
                    apply_target = str(getattr(self, "_sort_head_apply_target_v2628", "") or "")
                    if signature not in active and signature != apply_target:
                        return True
                    active_sid = str(getattr(self, "active_section_id", "") or "")
                    if active_sid and active_sid != str(sid) and not active_sid.endswith(":" + str(sid)):
                        return True
                except Exception:
                    pass
                return False

            if missing and not cancelled_v2628():
                workers = 1 if self._is_android_v2591() else min(2, len(missing))
                def fetch_one_v2628(pair):
                    rk, url = pair
                    if cancelled_v2628():
                        return ""
                    return self._wall_poster_download_bounded_v1862(
                        url, timeout_sec=2.2, max_bytes=2 * 1024 * 1024,
                        priority=int(priority), cancel_check=cancelled_v2628,
                    ) or ""
                with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
                    futures = [executor.submit(fetch_one_v2628, pair) for pair in missing]
                    for future in as_completed(futures):
                        if cancelled_v2628():
                            break
                        try:
                            local = str(future.result() or "").strip()
                        except Exception:
                            local = ""
                        if local and self._local_poster_file_ready_v1865(local):
                            downloaded += 1
                        else:
                            unresolved += 1

            if not cancelled_v2628() and requested > 0 and (local_ready + downloaded) >= requested:
                lock = getattr(self, "_sort_head_prewarm_lock_v2628", None)
                if lock is None:
                    self._sort_head_prewarm_lock_v2628 = threading.RLock()
                    lock = self._sort_head_prewarm_lock_v2628
                with lock:
                    ready = getattr(self, "_sort_head_ready_v2628", None)
                    if not isinstance(ready, set):
                        ready = set()
                        self._sort_head_ready_v2628 = ready
                    ready.add(signature)
            _log("SORT_HEAD_PREWARM_DONE_V2628 section=%s media=%s sort=%s dir=%s requested=%d local_ready=%d downloaded=%d unresolved=%d elapsed_ms=%d priority=%d cancelled=%d" % (
                sid, media, sort_key, sort_dir, requested, local_ready, downloaded, unresolved,
                max(0, _pkm_speed_ms() - started), int(priority), 1 if cancelled_v2628() else 0
            ))
        except Exception:
            _log("SORT_HEAD_PREWARM_FAILED_V2628 section=%s media=%s sort=%s dir=%s err=%s" % (
                sid, media, sort_key, sort_dir, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        finally:
            try:
                lock = getattr(self, "_sort_head_prewarm_lock_v2628", None)
                if lock is None:
                    self._sort_head_prewarm_lock_v2628 = threading.RLock()
                    lock = self._sort_head_prewarm_lock_v2628
                with lock:
                    running = getattr(self, "_sort_head_running_v2628", None)
                    if isinstance(running, set):
                        running.discard(signature)
            except Exception:
                pass

    def _sort_head_prewarm_schedule_v2628(self, control_id, reason=""):
        """Use sort-menu focus as user intent and warm the focused/nearby heads."""
        try:
            if self._is_android_v2591() and pkm_sort_index_v2626.background_blocked_u3():
                return False
            if not (self.getProperty("PlexKM.Section.SortDropdownOpen") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Section.SortDropdownOpen") == "1"):
                return False
            media = self._section_sort_media_kind()
            options = list(self._section_sort_options(media_kind=media) or [])
            ids = list(SECTION_SORT_ITEM_IDS[:len(options)])
            cid = int(control_id or 0)
            if cid not in ids:
                return False
            item = self._current_section_menu_item()
            sid = self._section_sid_from_item(item)
            if not sid:
                return False
            idx = ids.index(cid)
            try:
                prev_idx = int(getattr(self, "_sort_head_focus_idx_v2628", idx))
            except Exception:
                prev_idx = idx
            direction = 1 if idx > prev_idx else (-1 if idx < prev_idx else 0)
            self._sort_head_focus_idx_v2628 = idx
            if direction > 0:
                candidate_indices = list(range(idx, min(len(ids), idx + 4)))
            elif direction < 0:
                candidate_indices = list(range(idx, max(-1, idx - 4), -1))
            else:
                candidate_indices = [i for i in range(max(0, idx - 2), min(len(ids), idx + 3))]
                candidate_indices.sort(key=lambda i: (abs(i - idx), i))
            genre = ""
            try:
                if str(getattr(self, "_active_genre_section_id", "") or "") == str(sid):
                    genre = str(getattr(self, "_active_genre_filter", "") or "")
            except Exception:
                genre = ""
            candidates = []
            allowed = set()
            for i in candidate_indices:
                key = str(options[i][0] or "")
                sort_dir = pkm_library_sort.default_sort_dir(key)
                signature = self._sort_head_signature_v2628(sid, key, sort_dir, genre)
                allowed.add(signature)
                candidates.append((i, key, sort_dir, signature))
            self._sort_head_allowed_v2628 = allowed
            lock = getattr(self, "_sort_head_prewarm_lock_v2628", None)
            if lock is None:
                self._sort_head_prewarm_lock_v2628 = threading.RLock()
                lock = self._sort_head_prewarm_lock_v2628
            with lock:
                running = getattr(self, "_sort_head_running_v2628", None)
                if not isinstance(running, set):
                    running = set()
                    self._sort_head_running_v2628 = running
                ready = getattr(self, "_sort_head_ready_v2628", None)
                if not isinstance(ready, set):
                    ready = set()
                    self._sort_head_ready_v2628 = ready
                armed = 0
                for i, key, sort_dir, signature in candidates:
                    if signature in ready or signature in running:
                        continue
                    running.add(signature)
                    priority = (pkm_artwork_scheduler.PRIORITY_VISIBLE if i == idx
                                else pkm_artwork_scheduler.PRIORITY_AHEAD)
                    _PKMHomeThreadV2151(
                        target=self._sort_head_prewarm_worker_v2628,
                        args=(sid, media, key, sort_dir, genre, signature, priority),
                        name="PKMSortHeadV2628", daemon=True,
                    ).start()
                    armed += 1
            _log("SORT_HEAD_PREWARM_ARM_V2628 section=%s media=%s focus_sort=%s focus_control=%d direction=%d candidates=%s armed=%d foreground_wait=0 reason=%s" % (
                sid, media, str(options[idx][0] or ""), cid, direction,
                ",".join(str(options[i][0] or "") for i in candidate_indices), armed, reason or ""
            ))
            return True
        except Exception:
            _log("SORT_HEAD_PREWARM_ARM_FAILED_V2628 control=%s err=%s" % (
                control_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _scene_busy_arm_v2482(self, reason="", scope="scene", owner="", replace_scope=True, threshold_ms=1000):
        """Arm one delayed PKM scene spinner without exposing the broker early.

        The source A/B surface stays visible during the entire grace interval.
        pkm_global_busy.begin() is intentionally deferred until the threshold so
        its legacy 180ms default can never create a sub-second spinner flash.
        """
        try:
            threshold_ms = max(0, int(1000 if threshold_ms is None else threshold_ms))
            scope_key = str(scope or "scene")
            prior_token = ""
            prior_busy = ""
            with self._scene_busy_lock_v2482:
                if replace_scope:
                    prior_token = str(self._scene_busy_latest_by_scope_v2482.get(scope_key) or "")
                    if prior_token:
                        prior_rec = self._scene_busy_gates_v2482.pop(prior_token, None)
                        if isinstance(prior_rec, dict):
                            prior_rec["active"] = False
                            prior_busy = str(prior_rec.get("busy_token") or "")
                self._scene_busy_seq_v2482 += 1
                token = "scene2482:%d:%d" % (self._scene_busy_seq_v2482, self._now_ms())
                self._scene_busy_gates_v2482[token] = {
                    "active": True, "started_ms": self._now_ms(), "threshold_ms": threshold_ms,
                    "reason": str(reason or ""), "scope": scope_key,
                    "owner": str(owner or ""), "replace_scope": bool(replace_scope),
                    "busy_token": "", "promoted_ms": 0,
                }
                if replace_scope:
                    self._scene_busy_latest_by_scope_v2482[scope_key] = token
            if prior_busy:
                try:
                    pkm_global_busy.end(prior_busy, reason="scene_scope_replaced_v2482:%s" % scope_key)
                except Exception:
                    pass
            if prior_token:
                _log("PKM_SCENE_SPINNER_REPLACE_V2482 scope=%s prior=%s next=%s prior_promoted=%d" % (
                    scope_key, prior_token, token, 1 if prior_busy else 0
                ))

            # v2505: a caller that already KNOWS the operation is cold/slow can
            # request threshold 0.  Do not hand that case to a helper thread: a
            # long Kodi JSON-RPC/Helper call on the GUI callback can delay Python
            # thread scheduling, which made the nominal 180ms actor spinner paint
            # around 500ms later in real logs.  Begin + promote synchronously while
            # the complete source surface is still visible, then let the normal
            # scene gate own exact cleanup.
            if threshold_ms <= 0:
                busy_token = ""
                try:
                    busy_token = pkm_global_busy.begin(
                        reason="scene_v2482:%s" % (reason or ""),
                        scope=str(scope or "scene"), owner=str(owner or ""),
                        replace_scope=bool(replace_scope),
                    )
                    if busy_token:
                        pkm_global_busy.promote(
                            busy_token, reason="scene_sync_v2505:%s" % (reason or "")
                        )
                except Exception:
                    busy_token = ""
                if busy_token:
                    with self._scene_busy_lock_v2482:
                        rec = self._scene_busy_gates_v2482.get(token)
                        if isinstance(rec, dict) and rec.get("active"):
                            rec["busy_token"] = busy_token
                            rec["promoted_ms"] = self._now_ms()
                    _log("PKM_SCENE_SPINNER_PROMOTE_SYNC_V2505 token=%s threshold_ms=0 reason=%s scope=%s owner=%s source_held=1" % (
                        token, reason or "", scope or "scene", owner or ""
                    ))
                    return token

            def _promote():
                monitor = xbmc.Monitor()
                if threshold_ms > 0 and monitor.waitForAbort(threshold_ms / 1000.0):
                    return
                busy_token = ""
                with self._scene_busy_lock_v2482:
                    rec = self._scene_busy_gates_v2482.get(token)
                    if not isinstance(rec, dict) or not rec.get("active"):
                        return
                    try:
                        busy_token = pkm_global_busy.begin(
                            reason="scene_v2482:%s" % (reason or ""),
                            scope=str(scope or "scene"), owner=str(owner or ""),
                            replace_scope=bool(replace_scope),
                        )
                    except Exception:
                        busy_token = ""
                    if not busy_token:
                        return
                    rec["busy_token"] = busy_token
                    rec["promoted_ms"] = self._now_ms()
                    # Promotion is immediate *after* the 1s scene threshold; the
                    # broker's own 180ms legacy delay is bypassed intentionally.
                    try:
                        pkm_global_busy.promote(busy_token, reason="scene_1000ms_v2482:%s" % (reason or ""))
                    except Exception:
                        pass
                _log("PKM_SCENE_SPINNER_PROMOTE_V2482 token=%s threshold_ms=%d reason=%s scope=%s owner=%s source_held=1" % (
                    token, threshold_ms, reason or "", scope or "scene", owner or ""
                ))

            _PKMHomeThreadV2151(target=_promote, name="PKMSceneSpinner1000V2482", daemon=True).start()
            _log("PKM_SCENE_SPINNER_ARM_V2482 token=%s threshold_ms=%d reason=%s scope=%s owner=%s broker_begin_deferred=1" % (
                token, threshold_ms, reason or "", scope or "scene", owner or ""
            ))
            return token
        except Exception:
            return ""

    def _scene_busy_finish_v2482(self, token, reason=""):
        token = str(token or "")
        if not token:
            return False
        busy_token = ""
        started_ms = promoted_ms = threshold_ms = 0
        try:
            with self._scene_busy_lock_v2482:
                rec = self._scene_busy_gates_v2482.pop(token, None)
                if not isinstance(rec, dict):
                    return False
                rec["active"] = False
                busy_token = str(rec.get("busy_token") or "")
                started_ms = int(rec.get("started_ms") or 0)
                promoted_ms = int(rec.get("promoted_ms") or 0)
                _threshold_value_v2505 = rec.get("threshold_ms")
                threshold_ms = int(1000 if _threshold_value_v2505 is None else _threshold_value_v2505)
                scope_key = str(rec.get("scope") or "scene")
                if str(self._scene_busy_latest_by_scope_v2482.get(scope_key) or "") == token:
                    self._scene_busy_latest_by_scope_v2482.pop(scope_key, None)
            if busy_token:
                try:
                    pkm_global_busy.end(busy_token, reason="scene_done_v2482:%s" % (reason or ""))
                except Exception:
                    pass
            elapsed = max(0, self._now_ms() - started_ms) if started_ms else 0
            visible_ms = max(0, self._now_ms() - promoted_ms) if promoted_ms else 0
            _log("PKM_SCENE_SPINNER_FINISH_V2482 token=%s elapsed_ms=%d threshold_ms=%d promoted=%d visible_ms=%d reason=%s" % (
                token, elapsed, threshold_ms, 1 if promoted_ms else 0, visible_ms, reason or ""
            ))
            return True
        except Exception:
            return False

    def _capture_home_meta_snapshot_v1619(self, li, reason=""):
        """Prepare all visible hero/meta values without publishing any of them."""
        old_mode = bool(getattr(self, "_home_meta_capture_only_v1619", False))
        self._home_meta_capture_only_v1619 = True
        self._home_meta_snapshot_v1619 = None
        try:
            self._set_home_meta_from_item(li, reason="capture_v1619:%s" % (reason or ""))
            snapshot = self._home_meta_snapshot_v1619
            return snapshot if isinstance(snapshot, dict) else None
        finally:
            self._home_meta_capture_only_v1619 = old_mode
            self._home_meta_snapshot_v1619 = None

    def _apply_home_meta_snapshot_v1619(self, snapshot, reason=""):
        """Publish a precomputed metadata snapshot without DB work or waits."""
        if not isinstance(snapshot, dict):
            return False
        try:
            props = dict(snapshot.get("props") or {})
            fanart = str(snapshot.get("fanart") or "")
            hero_title = str(snapshot.get("hero_title") or props.get("Title") or "")
            li = snapshot.get("li")
            win = xbmcgui.Window(10000)
            for k, v in props.items():
                if k == "Fanart":
                    continue
                val = str(v or "")
                win.setProperty("PlexKM.Home.%s" % k, val)
                try:
                    self.setProperty("PlexKM.Home.%s" % k, val)
                except Exception:
                    pass
            self._set_home_fanart_smooth(fanart, reason="atomic_v1619:%s" % (reason or ""), scene_switch_r116=True)
            try:
                self._tmdb_fill_home_apply_r41(str(props.get("RatingKey") or ""), reason="atomic_v1619")
            except Exception:
                pass
            try:
                fid_r155 = int(self._safe_focus_id() or 0)
                if (self._is_home_row_control(fid_r155) or fid_r155 == WALL_ID):
                    self._r155_rating_schedule(li, reason="first_snapshot")
            except Exception:
                pass
            try:
                self.getControl(TITLE_ID).setLabel(self._title_display_text(hero_title) or "")
            except Exception:
                pass
            # v2385: Home/section scene publication must remain lightweight.
            # Cancel any stale stable-focus cast task but never start actor-photo
            # prewarm from Home metadata/atomic widget publication.
            try:
                self._cast_focus_idle_token_v1642 = int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0) + 1
            except Exception:
                pass
            try:
                rating_key = str(props.get("RatingKey") or "")
                plex_type = str(props.get("Type") or "")
                genre = str(props.get("Genre") or "")
                director = str(props.get("Director") or "")
                content_rating = str(props.get("ContentRating") or "")
                rating = str(props.get("Rating") or "")
                verified = bool(snapshot.get("rating_verified_exact"))
                need_rating_verify = bool(plex_type == "movie" and not verified)
                need_tv_rating = bool(plex_type != "movie" and not rating)
                if rating_key and (not genre or not content_rating or (plex_type == "movie" and not director) or need_rating_verify or need_tv_rating):
                    self._start_home_meta_enrich(
                        rating_key, reason="atomic_v1619:%s" % (reason or ""),
                        force_rating_refresh=need_rating_verify
                    )
            except Exception:
                pass
            _log("META_ATOMIC_APPLY_V1619 reason=%s title=%s fanart=%s rating_key=%s" % (
                reason or "", _short_log_value(hero_title), "yes" if fanart else "no", props.get("RatingKey") or ""
            ))
            return True
        except Exception:
            _log("META_ATOMIC_APPLY_FAILED_V1619 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _start_post_startup_background_v1643(self, reason=""):
        """V2570: visible Home is a quiet zone; no speculative post-reveal work."""
        try:
            win_v2570 = xbmcgui.Window(10000)
            self._post_startup_background_started_v1643 = True
            win_v2570.setProperty("PlexKM.Home.PostStartupBackgroundStartedV1645", "1")
            win_v2570.setProperty("PlexKM.Home.PostStartupBackgroundModeV1645", "disabled_uhd3_quiet_v2570")
            win_v2570.setProperty("PlexKM.HomeQuiet.ActiveV2570", "1")
            _log("UHD3_HOME_QUIET_POST_STARTUP_SUPPRESSED_V2570 reason=%s deferred_snapshot=0 cine21=0" % (reason or ""))
        except Exception:
            pass
        return

    def _startup_widget_poster_sources_v1644(self, li):
        # v2498: all Home/section poster prefetchers now consume poster-only
        # authority.  Landscape fanart remains available to the hero/background
        # pipeline but is never a portrait-card fallback.
        return self._poster_authority_sources_v2498(li)

    def _startup_widget_poster_resolve_v1644(self, sources):
        # v1937: Home/section widget posters use the same bounded Plex image
        # bucket as the Library wall before falling back to any original source.
        try:
            small_url_v1937 = self._viewport_poster_url_v1937(sources, rating_key="")
            if small_url_v1937:
                local_v1937 = self._wall_poster_download_one_v1644(
                    small_url_v1937, priority=pkm_artwork_scheduler.PRIORITY_VISIBLE,
                    pause_when_playing=False
                )
                if local_v1937 and self._local_portrait_poster_file_ready_v2498(local_v1937):
                    _log("WIDGET_SERVER_SMALL_POSTER_READY_V1937 size_bucket=240x360 scheduler=1 poster_only_v2498=1")
                    return local_v1937
        except Exception:
            pass
        for source in list(sources or []):
            try:
                lower = source.lower()
                if lower.startswith("special://"):
                    translated = xbmcvfs.translatePath(source)
                    if translated and self._local_portrait_poster_file_ready_v2498(translated):
                        return translated
                elif not lower.startswith(("http://", "https://")):
                    if self._local_portrait_poster_file_ready_v2498(source):
                        return source
                else:
                    # Two bounded attempts handle a just-started Plex image endpoint
                    # without using any UI timer/reveal shortcut.
                    for _attempt in range(2):
                        local = self._wall_poster_download_one_v1644(
                            source, priority=pkm_artwork_scheduler.PRIORITY_VISIBLE,
                            pause_when_playing=False
                        )
                        if local and self._local_portrait_poster_file_ready_v2498(local):
                            return local
            except Exception:
                continue
        return ""

    def _section_rating_snapshot_store_v1644(self, cache_key):
        try:
            cine = getattr(self, "_home_visible_cine21_rating_cache", {}) or {}
            self._section_prebuilt_rating_v1644[str(cache_key)] = (
                dict(getattr(self, "_home_visible_imdb_rating_cache", {}) or {}),
                {"by_rk": dict(cine.get("by_rk", {}) or {}),
                 "by_ty": dict(cine.get("by_ty", {}) or {})},
            )
        except Exception:
            pass

    def _section_rating_snapshot_restore_v1644(self, cache_key):
        try:
            snap = self._section_prebuilt_rating_v1644.get(str(cache_key))
            if not snap:
                return False
            imdb, cine = snap
            self._home_visible_imdb_rating_cache = dict(imdb or {})
            self._home_visible_cine21_rating_cache = {
                "by_rk": dict((cine or {}).get("by_rk", {}) or {}),
                "by_ty": dict((cine or {}).get("by_ty", {}) or {}),
            }
            return True
        except Exception:
            return False

    def _prebuild_one_sidebar_scene_v1644(self, sid, title, stype):
        cache_key = "recommend:%s" % str(sid)
        started = _pkm_speed_ms()
        rows = list(self._section_rows_cache.get(cache_key) or [])
        movie_target = self._is_movie_recommend_section(sid, stype)
        if movie_target:
            valid = bool(rows and self._movie_full_compose_titles_valid_v1616(
                self._movie_full_compose_group_titles_v1616(rows), require_extra=True
            ))
        else:
            valid = bool(rows)
        if not valid:
            self._section_rows_cache.pop(cache_key, None)
            self._prebuild_section_recommend_rows_cache(
                sid, title, section_type=stype, reason="startup_snapshot_v1644"
            )
            rows = list(self._section_rows_cache.get(cache_key) or [])
        if not rows:
            # A selected Plex section can legitimately contain zero items.  It is
            # still a fully known startup scene and must not hold the splash
            # forever.  Cache an explicit empty result; a non-empty section that
            # failed to build remains a hard startup failure.
            section_total_v1644 = 0
            try:
                for sec_v1644 in list(getattr(self, "sections", []) or []):
                    sec_sid_v1644 = str(sec_v1644.get("section_id") or sec_v1644.get("key") or "").strip()
                    if sec_sid_v1644 == str(sid):
                        section_total_v1644 = _safe_int(sec_v1644.get("item_count"), _safe_int(sec_v1644.get("total"), 0))
                        break
            except Exception:
                section_total_v1644 = 0
            if section_total_v1644 <= 0:
                self._li_release_r118(self._section_prebuilt_listitems_v1644.get(cache_key))
                self._section_prebuilt_listitems_v1644[cache_key] = []
                self._section_prebuilt_titles_v1644[cache_key] = []
                self._section_full_rows_ready_v1644.add(cache_key)
                self._section_texture_ready_v1644.add(cache_key)
                _log("STARTUP_SIDEBAR_SCENE_READY_EMPTY_V1644 section=%s title=%s total=0" % (
                    sid, _short_log_value(title)
                ))
                return True
            _log("STARTUP_SIDEBAR_SCENE_BUILD_FAILED_V1644 section=%s title=%s total=%d reason=no_rows" % (
                sid, _short_log_value(title), section_total_v1644
            ), xbmc.LOGERROR)
            return False

        grouped = self._section_group_rows_v1644(rows)
        if not grouped or len(grouped) > SECTION_RECOMMEND_ROW_CAPACITY:
            _log("STARTUP_SIDEBAR_SCENE_SCHEMA_FAILED_V1644 section=%s groups=%d capacity=%d" % (
                sid, len(grouped), SECTION_RECOMMEND_ROW_CAPACITY
            ), xbmc.LOGERROR)
            return False

        self._preload_visible_row_ratings(rows, reason="STARTUP_SIDEBAR_FULL_V1644:%s" % sid)
        self._section_rating_snapshot_store_v1644(cache_key)
        titles = [
            _display_library_title(entries[0].get("row_title", "") if entries else "")
            for entries in grouped
        ]
        # v1841: a background-prepared Scene contains immutable row dictionaries
        # only. Never retain xbmcgui.ListItem objects or attach them to a hidden
        # Control from this path. The GUI callback creates fresh ListItems in the
        # inactive A/B bank when the section is actually selected.
        self._li_release_r118(self._section_prebuilt_listitems_v1644.get(cache_key))
        self._section_prebuilt_listitems_v1644[cache_key] = []
        self._section_prebuilt_titles_v1644[cache_key] = titles
        self._section_prebuilt_meta_v1644.pop(cache_key, None)
        self._section_full_rows_ready_v1644.add(cache_key)
        # Remote poster URLs plus the XML fallback are a valid ready source. Kodi
        # texture-cache completion is not a Scene barrier and cannot wait forever.
        self._section_texture_ready_v1644.add(cache_key)
        _log("STARTUP_SIDEBAR_SCENE_DATA_READY_V1841 section=%s title=%s groups=%d items=%d native_listitems=0 texture_wait_ms=0 total_ms=%d" % (
            sid, _short_log_value(title), len(grouped),
            sum(len(x) for x in grouped),
            _pkm_speed_ms() - started
        ))
        return True

    def _section_reconcile_cached_continue_rows(self, section_id, cached_rows):
        sid = str(section_id or "").strip()
        source = [dict(entry) if isinstance(entry, dict) else entry for entry in list(cached_rows or [])]
        if not sid or not source:
            return source, False

        fresh_rows = list(
            self._section_continue_rows(
                sid, limit=max(120, HOME_ROW_ITEM_LIMIT), local_first_v2589=True
            ) or []
        )

        old_entries = [
            entry for entry in source
            if isinstance(entry, dict)
            and _display_library_title(entry.get("row_title") or "") == "이어보기"
        ]

        def _row_signature(row):
            values = tuple(row or ())
            return (
                str(values[0] if len(values) > 0 else ""),
                str(values[2] if len(values) > 2 else ""),
                str(values[18] if len(values) > 18 else ""),
                _safe_int(values[19] if len(values) > 19 else 0, 0),
                _safe_int(values[20] if len(values) > 20 else 0, 0),
                _safe_int(values[23] if len(values) > 23 else 0, 0),
                _safe_int(values[24] if len(values) > 24 else 0, 0),
                str(values[26] if len(values) > 26 else ""),
            )

        old_signatures = [
            _row_signature(entry.get("row")) for entry in old_entries
        ]
        new_signatures = [_row_signature(row) for row in fresh_rows]

        if old_signatures == new_signatures:
            _log(
                "SECTION_CONTINUE_CACHE_ACCEPT section=%s rows=%d reason=membership_current" %
                (sid, len(fresh_rows))
            )
            return source, False

        fresh_entries = []
        row_id = "recommend:%s:0" % sid
        for idx, row in enumerate(fresh_rows):
            fresh_entries.append({
                "row_title": "이어보기",
                "row_type": "section_recommend",
                "section_id": sid,
                "row_first": idx == 0,
                "row_id": row_id,
                "row_start": 0,
                "row_index": idx,
                "row": row,
                "r154_policy": SECTION_RECOMMEND_POLICY_R154,
            })

        remaining = [
            entry for entry in source
            if not (
                isinstance(entry, dict)
                and _display_library_title(entry.get("row_title") or "") == "이어보기"
            )
        ]
        corrected = fresh_entries + remaining
        cache_key = "recommend:%s" % sid
        self._section_rows_cache[cache_key] = list(corrected)

        # Retire only process-local presentation objects for this scene. No
        # persistent cache file is deleted or purged.
        try:
            self._section_scene_cache_v1620.pop(cache_key, None)
            self._li_release_r118(self._section_prebuilt_listitems_v1644.pop(cache_key, None))
            self._section_render_snapshots_v2473.pop(cache_key, None)
            self._section_prebuilt_titles_v1644.pop(cache_key, None)
            self._section_prebuilt_meta_v1644.pop(cache_key, None)
            self._section_prebuilt_rating_v1644.pop(cache_key, None)
            self._section_full_rows_ready_v1644.discard(cache_key)
            self._section_texture_ready_v1644.discard(cache_key)
            self._section_visited_keys_v1635.discard(cache_key)
            owners = getattr(self, "_section_bank_cache_key_v1612", {}) or {}
            for bank in ("A", "B"):
                if str(owners.get(bank) or "") == cache_key:
                    owners[bank] = ""
        except Exception:
            pass

        _log(
            "SECTION_CONTINUE_CACHE_REJECT section=%s cached=%d current=%d reason=membership_changed runtime_scene_retired=1 disk_cache_deleted=0" %
            (sid, len(old_entries), len(fresh_entries))
        )
        return corrected, True

    def _section_target_texture_candidates_v1612(self, bank, max_rows=2, max_items=10):
        """Collect poster URLs for the actual first visible hidden-bank viewport."""
        candidates = []
        seen_v2491 = 0
        try:
            row_ids = self._section_bank_row_ids_v1612(bank)
            total_limit_v2491 = max(1, int(max_items or 10))
            for cid in row_ids[:max(1, int(max_rows or 2))]:
                try:
                    ctrl = self.getControl(cid)
                    count = min(max(0, int(ctrl.size())), max(0, total_limit_v2491 - seen_v2491))
                except Exception:
                    continue
                for idx in range(count):
                    try:
                        li = ctrl.getListItem(idx)
                        seen_v2491 += 1
                        # An explicit item-level missing-poster placeholder is
                        # already render-safe and must not block the section.
                        if str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1":
                            continue
                        sources_v2498 = list(self._poster_authority_sources_v2498(li) or [])
                        primary = str(sources_v2498[0] if sources_v2498 else "").strip()
                        fallback = str(sources_v2498[1] if len(sources_v2498) > 1 else "").strip()
                        if primary or fallback:
                            candidates.append((primary, fallback))
                    except Exception:
                        pass
                if seen_v2491 >= total_limit_v2491:
                    break
        except Exception:
            pass
        return candidates

    def _section_stale_core_scene_retire_r47(self, cache_key, reason=""):
        """R47: drop a stale core-only (3-group) section scene before healing.

        The completed-scene registry keeps its own row snapshot, and
        _section_scene_get_v1620 *resurrects* those rows into
        _section_rows_cache whenever they differ from the live cache. So after
        R44 consumed the full 7-group compose, the very next scene lookup put
        the old 32-row core rows straight back, the revisit fast path reused the
        old 3-row native bank, and the persistent scene file kept saving 32
        rows. Retire the scene, its native/prebuilt artifacts and its
        persistent entry -- but NOT the row cache itself, which the caller is
        about to refill with the full compose -- and without the global
        snapshot re-arm a real Plex dirty invalidation performs.
        """
        key = str(cache_key or "")
        if not key:
            return
        try:
            self._section_scene_cache_v1620.pop(key, None)
            self._section_persistent_hit_keys_v2467.discard(key)
            self._section_startup_hydrated_keys_v2469.discard(key)
            self._section_startup_prebuilt_keys_v2469.discard(key)
            self._li_release_r118(self._section_prebuilt_listitems_v1644.pop(key, None))
            self._section_render_snapshots_v2473.pop(key, None)
            self._section_prebuilt_titles_v1644.pop(key, None)
            self._section_prebuilt_meta_v1644.pop(key, None)
            self._section_prebuilt_rating_v1644.pop(key, None)
            self._section_full_rows_ready_v1644.discard(key)
            self._section_texture_ready_v1644.discard(key)
        except Exception:
            pass
        try:
            cache = self._section_persistent_cache_load_v2467()
            if key in cache:
                cache.pop(key, None)
                path = self._derived_cache_path_v2467("section_scene_cache_v2468.json")
                if path:
                    _pkm_write_cache_json_v2801(path, cache)
        except Exception:
            pass
        _log("SECTION_STALE_CORE_SCENE_RETIRE_R47 key=%s reason=%s rows_cache_kept=1" % (key, reason or ""))
