# -*- coding: utf-8 -*-
"""Movie recommendation data helpers for Plex KM.

This module is data-only: SQL fragments, country-bucket lookup, and section-id
helpers used by default.py recommendation index queries.  It does not touch
Kodi WindowXML focus, navigation, playback, or UI flow.
"""
from __future__ import absolute_import, unicode_literals


def recommend_row_columns_sql(prefix="i"):
    p = (str(prefix or "").strip() + ".") if str(prefix or "").strip() else ""
    # Keep this tuple shape aligned with the pre-split default.py helper and
    # the DB-backed recommendation item conversion path.  Do not add columns
    # that are not present in the items table, such as view_offset.
    return ", ".join([
        p + "rating_key",
        p + "section_id",
        p + "plex_type",
        "'' AS kodi_type",
        p + "title",
        "'' AS original_title",
        "COALESCE(" + p + "sort_title," + p + "title) AS sort_title",
        p + "year",
        p + "summary",
        p + "duration",
        p + "added_at",
        p + "updated_at",
        p + "thumb",
        p + "art",
        p + "media_file",
        p + "part_key",
        p + "view_count",
        p + "last_viewed_at",
        p + "show_title",
        p + "season",
        p + "episode",
        p + "parent_rating_key",
        p + "grandparent_rating_key",
    ])


def recommend_exclude_clause(alias, exclude_keys, args):
    keys = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    if not keys:
        return ""
    ph = ",".join(["?"] * len(keys))
    args.extend(keys)
    return " AND %s.rating_key NOT IN (%s)" % ((alias or "i"), ph)


def movie_section_ids_from_db(conn):
    try:
        rows = conn.execute(
            "SELECT DISTINCT section_id FROM items WHERE plex_type='movie' ORDER BY CAST(section_id AS INTEGER), section_id"
        ).fetchall()
        return [str(r[0]) for r in rows if str(r[0] or "").strip()]
    except Exception:
        return []


def section_country_bucket_from_db(conn, section_id, plex_type, min_ratio=0.60):
    """Return dominant coarse country bucket for a section: 한국 / 외국 / ''.

    Uses item_countries only; no library-title or section-name matching.
    """
    sid = str(section_id or "").strip()
    ptype = str(plex_type or "").strip()
    if not sid or not ptype:
        return ""
    try:
        rows = conn.execute("""
            SELECT c.country, COUNT(DISTINCT c.rating_key) AS cnt
            FROM item_countries c
            JOIN items i ON i.rating_key=c.rating_key
            WHERE c.section_id=?
              AND i.section_id=?
              AND i.plex_type=?
              AND c.country IN ('한국','외국')
            GROUP BY c.country
        """, (sid, sid, ptype)).fetchall()
    except Exception:
        rows = []
    counts, total = {}, 0
    for row in rows or []:
        try:
            country = str(row[0] or "").strip()
            cnt = int(row[1] or 0)
            if country in ("한국", "외국") and cnt > 0:
                counts[country] = counts.get(country, 0) + cnt
                total += cnt
        except Exception:
            continue
    if total <= 0:
        return ""
    bucket, cnt = max(counts.items(), key=lambda kv: kv[1])
    try:
        if float(cnt) / float(total) >= float(min_ratio or 0.60):
            return bucket
    except Exception:
        pass
    return ""


def recommend_rows_thumb_stats(rows):
    total = len(rows or [])
    thumb_ready = 0
    art_ready = 0
    try:
        for r in rows or []:
            t = tuple(r)
            if len(t) > 12 and str(t[12] or "").strip():
                thumb_ready += 1
            if len(t) > 13 and str(t[13] or "").strip():
                art_ready += 1
    except Exception:
        pass
    return total, thumb_ready, art_ready

def recommend_widget_result_log_message(kind, section_id, rows, want, elapsed, source="db_local", result="ok", extra=""):
    """Build the stable recommendation-widget result log message.

    Data-only helper: computes row/thumb/art counts and returns the exact log
    message string used by default.py.  It does not call Kodi APIs.
    """
    total, thumb_ready, art_ready = recommend_rows_thumb_stats(rows)
    try:
        return "[PKM_INDEX] recommend_widget_result kind=%s section=%s rows=%d want=%d thumb_ready=%d art_ready=%d metadata_fetch=0 source=%s ms=%d result=%s%s" % (
            kind, section_id, total, int(want or 0), thumb_ready, art_ready, source, int(elapsed or 0), result, (" " + extra) if extra else ""
        )
    except Exception:
        return "[PKM_INDEX] recommend_widget_result kind=%s section=%s rows=%d want=%s thumb_ready=%d art_ready=%d metadata_fetch=0 source=%s ms=%s result=%s%s" % (
            kind, section_id, total, want, thumb_ready, art_ready, source, elapsed, result, (" " + extra) if extra else ""
        )



def db_row_person_name(rows):
    """Return recommendation person-name appended after the stable wall row tuple.

    Data-only helper used by the WindowXML home window when naming movie
    director/actor extra rows.  It does not touch Kodi UI state.
    """
    try:
        if rows and len(tuple(rows[0])) > 23:
            return str(tuple(rows[0])[-1] or "").strip()
    except Exception:
        pass
    return ""


def db_row_art_stats(rows):
    """Return (total, thumb_ready, art_ready) for DB-backed wall rows."""
    return recommend_rows_thumb_stats(rows)


def clean_float(value):
    try:
        txt = str(value if value is not None else "").strip()
        if not txt:
            return None
        return float(txt)
    except Exception:
        return None


def movie_extra_rating_values(node):
    """Return (audienceRating, rating, userRating, best_score) from a Plex node.

    Data-only helper.  Score priority is unchanged from the pre-split window
    helper: audienceRating -> rating -> userRating.
    """
    try:
        get_value = getattr(node, "get", None)
        audience = clean_float(get_value("audienceRating") if get_value else None)
        rating = clean_float(get_value("rating") if get_value else None)
        user = clean_float(get_value("userRating") if get_value else None)
        score = audience if audience is not None else (rating if rating is not None else user)
        return audience, rating, user, score
    except Exception:
        return None, None, None, None


def movie_extra_score_threshold():
    """Current movie extra recommendation score threshold.

    Kept as a helper so the value has one data-only owner while the WindowXML
    class keeps its existing method wrapper.
    """
    return 6.5
