# -*- coding: utf-8 -*-
"""Startup cache gate and Plex playback-state bridge for plugin.video.km.

WindowXML wall mode is opened from skin.estuary.km Home.xml.  This service keeps
library startup checks lightweight and also mirrors Kodi playback progress back
to PMS so Plex Continue Watching/onDeck stays in sync.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_shutdown_v2039 import install_fast_shutdown_policy
install_fast_shutdown_policy()
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import sys
import time
import os
import re
import threading
import weakref
import json
import hashlib
import math
import traceback
try:
    from urllib.parse import urlparse
except Exception:
    from urlparse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


try:
    from resources.lib.pkm_network_health import NetworkHealthMonitor
except Exception:
    NetworkHealthMonitor = None

try:
    from resources.lib import pkm_update_flow_v2169
except Exception:
    pkm_update_flow_v2169 = None

try:
    from resources.lib import pkm_episode_flow_v2222
except Exception:
    pkm_episode_flow_v2222 = None

try:
    from resources.lib import pkm_ratings_service_bridge
except Exception:
    pkm_ratings_service_bridge = None

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# PKM_PATCH_ACTIVE v2584 uhd3_under5_startup_log_quiet
def _pkm_log_v2584(message, level=xbmc.LOGINFO):
    """Keep operational diagnostics, drop patch-marker log spam.

    Android/UHD3 pays materially for hundreds of synchronous Kodi log writes while
    Python modules are importing.  Patch markers are build-time evidence, not runtime
    behavior, so V2584 emits one compact marker and preserves every warning/error and
    every real timing/state diagnostic.
    """
    try:
        text = str(message or "")
        if level == xbmc.LOGINFO and "PKM_PATCH_ACTIVE" in text:
            return
        xbmc.log(text, level)
    except Exception:
        try:
            xbmc.log(str(message or ""), level)
        except Exception:
            pass

_pkm_log_v2584("[plugin.video.km] V2584_ACTIVE uhd3_under5_instant_home_wall_skeleton", xbmc.LOGINFO)
try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2578 startup_local_epoch_parallel_playstate_tv_prewarm_priority", xbmc.LOGINFO)
except Exception:
    pass
try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2041 sync_return_focus_bootstrap_no_always_100\n[plugin.video.km] PKM_PATCH_ACTIVE v2042 sync_home_menu_inplace_focus_preserve", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2044 initial_sync_home_precompose_no_duplicate_post_confirm_refresh", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2039 abort_all_background_no_wait_next_start_rebuild\n[plugin.video.km] PKM_PATCH_ACTIVE v2040 sync_live_bar_settings_focus_first_run_surface", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2067 library_direct_db_page_sync_modal_close_reset_purge", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2068 sidebar_focus_owner_visible_before_transfer_xml_only", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2069 global_foreground_spinner_library_append_sort_playback_policy", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2070 library_selection_single_owner_kodi9100_full_audit", xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2071 library_append_post_native_commit_single_owner" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2073 library_rebind_transaction_preserve_native_column", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2074 tv_info_widget_navigation_single_graph_6110_actor_rows", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2075 info_cast_eight_actors_tighter_focus_ring", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2076 info_cast_native_repeat_safe_scroll0_portrait_256_278", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2077 library_wall_native_runway66_reserve48_publish24_no_down_wrap", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2078 tv_info_cast_before_season_compact_stack_exact_ring", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2079 info_focus_cumulative_step_motion_no_bounce_library_smooth_scroll", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2080 actor_work_horizontal_smooth_scroll_260_sine", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2307 actor_work_safe_viewport_native_edge_scroll_full_focus_poster", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2309 history_back_safe_rebuild_hold_child_surface_no_spinner_no_cover", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2310 history_back_exact_position_sidebar_tint_static_prime_no_native_reuse", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2311 history_back_sidebar_tint_no_inlineactive_gap_exact_parent_pin", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2312 history_back_sidebar_tint_commit_order_exact_target_color_atomic_ready", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2313 home_info_hero_title_meta_exact_geometry_no_return_nudge", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2314 home_library_bg_focus_dwell_slow_latest_only_transition", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2081 restore_approved_info_more_text_chevron_cue", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2082 info_actor_work_reentrant_safe_detach_focus_gated_rebuild_hq_more", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2083 info_reentrant_visual_stage_offscreen_bind_visible_art_freeze", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2084 info_direct_surface_swap_no_reveal_slide_episode_summary_explicit_ellipsis", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2085 inline_info_nested_history_exact_actor_work_focus_return", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2086 actor_work_direct_swap_render_boundary_scroll_reset_single_entry_focus_owner", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2087 unified_inline_info_entry_pipeline_two_frame_scroll_state_reset", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2089 movie_resolution_rect_dropdown_single_visible_color_selection", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2090 library_add_exit_restart_boundary_no_live_home_spinner", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2091 playback_version_settings_rect_dropdown_library_add_next_start_boundary", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2092 explicit_kodi_restart_required_completion_kodi_exit_button", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2093 playback_version_end_icon_click_cycle_no_dropdown", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2094 playback_version_round_action_source_default_single_gray_multi_white_no_refresh", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2095 playback_return_primary_play_focus_after_back", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2096 resolution_first_compact_focus_pill_primary_play_default", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2097 action_pill_equal_icon_label_gap_trim_width", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2098 tv_episode_actionbar_movie_parity_restart_watched_pills", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2099 tv_episode_versions_same_show_same_episode_selected_libraries_no_refresh", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2118 adaptive_startup_logo_sidebar_spinner_ownership_playback_priority", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2119 home_window_pre_xml_control9000_lifecycle_root_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2120 section_tab_focus_destination_first_atomic_mode_commit", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2121 fast_key_native_owner_stale_focus_publish_guard", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2122 wall_append_exact_item_restore_tv_100series_4k_identity_root_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2123 tv_version_authoritative_state_child_info_fresh_top_focus_gate", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2124 video_stream_attached_picture_filter", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2125 video_info_positive_bitrate_local_fallback_return_surface_settle_fade", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2126 playback_network_health_osd_icon_inline_detail_no_probe", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2127 network_panel_runscript_root_and_screen_mode_center_toast", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2128 network_panel_geometry_seekbar_align_focus_translucent", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2129 movie_info_more_cue_tv_parity_only_when_more_exists", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2130 actor_work_poster_current_token_canonical_ratingkey_fallback_no_probe", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2131 sidebar_right_selected_published_owner_exclusive_surface_gate", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2132 actor_work_child_info_atomic_art_meta_no_home_fanart_leak_no_previsible_cast_network", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2134 rollback_v2133_transition_gate_deadlock_keep_v2132_atomic_info_fanart_fadetime0", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2136 universal_info_visual_ab_two_fanart_slide_all_entry_paths_no_focus_timer", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2137 universal_info_ab_fade_cover_no_slide_old_art_new_meta_overlap_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2138 actor_work_quality_priority_fill_remaining_capacity_no_exclusion", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2139 info_spinner_delayed_750ms_only_slow_info_global_busy_policy", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2140 universal_dynamic_bg_info_owner_ab_commit_android_single_sampler_empty_preserve", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2141 info_sidebar_same_dynamic_tint_home_info_fanart_large_geometry_parity", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2142 info_spinner_1200ms_previsible_stale_more_widget_clear", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2143 actor_work_child_hold_previous_info_until_final_publish_stage_cast_before_cover", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2144 source_surface_hold_spinner_before_info_direct_complete_publish", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2145 info_smart_spinner_full_surface_fade_local_only_cast_fast_open", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2146 cast_portraits_required_first_paint_plex_missing_only_placeholder_raw_cache_no_pil", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2147 pil_runtime_image_processing_cleanup_kodi_texture_owner_dynamic_bg_only", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2148 actor_thumb_sync_time_diagnostic_no_behavior_change", xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2151 full_reset_live_home_worker_drain_memory_purge_first_run_handoff" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2152 info_fade_only_cast_placeholder_back_one_step" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2153 info_scene_pure_fade_hidden_reset_no_420ms_wait" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2157 restore_v2153_sidebar_tint_same_transition_owner_no_early_color_strip" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2158 actor_work_target_top_bind_before_opacity_release_no_vertical_scene_exposure" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2159 same_surface_universal_top_anchor_tv_focus_deadlock_root_fix" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2160 actor_work_tv_prestage_before_cover_strict_thumb_timeout_no_blank_spinner_surface" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2161 universal_info_sidebar_tint_same_fade_owner_source_cover_no_live_target_late_unified_lerp" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2162 cast_cache_duplicate_writer_windows_permission_race_reuse_peer" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2190 actor_info_full_page_atomic_reveal_scroll_compensation" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2191 info_fanart_home_geometry_atomic_spinner_reveal" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2194 info_fanart_exact_home_visible_texture_owner" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2206 widget_title_focus_gap_all_home_section_rows" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2207 cast_direct_light_metadata_single_owner_no_short_prewarm_poison" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2208 cast_global_library_plex_role_reuse_tag_identity_persist" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2163 full_reset_kodi_exit_process_boundary_no_live_home_handoff" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2164 full_reset_visible_stage_progress_then_kodi_exit" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2165 full_reset_autostart_ui_owner_not_service_worker_force_purge" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2166 full_reset_passive_empty_settings_watch_immediate_abort_progress_border_2px", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2167 full_reset_success_3_2_1_visible_shutdown_countdown", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2169 pkm_update_notice_confirm_timeout_progress_restart_countdown", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2171 unified_kodi_exit_3_2_1_countdown_all_quit_paths", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2172 kodi_exit_no_post_quit_hold_settings_required_gradient_box", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2173 tv_sync_final_total_from_start_sidebar_native_nav_timing_diag", xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2150 full_reset_hard_stop_zero_trace_safe_no_default_confirm" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2149 full_reset_background_barrier_sync_drain_final_survivor_truth", xbmc.LOGINFO)
except Exception:
    pass





def _start_r57_background_membership(core, home, sids):
    """R57: sections whose Plex count/newest items already match the local DB but
    have no stored proof are audited right after Home instead of before it.

    Runs once Home is revealed and the user has been idle briefly, shows a small
    left notice "라이브러리 확인 중 (i/n)", and only asks Home to refresh when the
    audit actually changed something.
    """
    sids = [str(s) for s in list(sids or []) if str(s or "")]
    if not sids:
        return
    try:
        if home.getProperty("PlexKM.Bg.R57MembershipArmed") == "1":
            return
        home.setProperty("PlexKM.Bg.R57MembershipArmed", "1")
    except Exception:
        pass

    def _runner():
        notify = None
        token = ""
        t0 = time.time()
        try:
            mon = xbmc.Monitor()
            ready_at = 0.0
            while not mon.abortRequested():
                if home.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    ready_at = time.monotonic()
                    break
                if mon.waitForAbort(0.15):
                    return
            if not ready_at:
                return
            # Let the first Home frames settle and keep out of the user's way.
            while not mon.abortRequested():
                now_ms = int(time.time() * 1000)
                try:
                    last_ms = int(float(home.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or "0"))
                except Exception:
                    last_ms = 0
                idle_ms = (now_ms - last_ms) if last_ms > 0 else 999999
                settled = (time.monotonic() - ready_at) >= 3.0
                busy = (home.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                        or home.getProperty("PlexKM.Startup.InitialComposeR57") == "1"
                        or home.getProperty("PlexKM.Startup.PrepareRunningR59") == "1")
                try:
                    playing = bool(xbmc.Player().isPlayingVideo())
                except Exception:
                    playing = False
                if settled and idle_ms >= 1500 and not busy and not playing:
                    break
                if mon.waitForAbort(0.25):
                    return
            _pkm_log_v2584("[%s] R57_BG_MEMBERSHIP_BEGIN sections=%s" % (ADDON_ID, ",".join(sids)), xbmc.LOGINFO)
            box = {"result": None, "error": None, "done": False}

            def _gate():
                try:
                    box["result"] = dict(getattr(core, "startup_prehome_authority_gate_v2349")(
                        only_sids_r57=sids, allow_defer_r57=False) or {})
                except Exception as exc_gate:
                    box["error"] = exc_gate
                finally:
                    box["done"] = True

            th = threading.Thread(target=_gate, name="pkm-r57-bg-membership", daemon=True)
            th.start()
            last_msg = None
            while not box["done"] and not mon.abortRequested():
                th.join(0.30)
                try:
                    idx = int(home.getProperty("PlexKM.Bg.R57SyncIndex") or "0")
                    tot = int(home.getProperty("PlexKM.Bg.R57SyncTotal") or "0")
                except Exception:
                    idx, tot = 0, 0
                title = str(home.getProperty("PlexKM.Bg.R57SyncTitle") or "").strip()
                if tot <= 0 or not title:
                    continue
                msg = ("라이브러리 확인", "라이브러리 확인 중 (%d/%d)" % (max(1, min(idx, tot)), tot),
                       title)
                if msg == last_msg:
                    continue
                try:
                    if notify is None:
                        from resources.lib import pkm_notify as notify
                    if notify:
                        token = str(notify.pkm_notice_set(msg[0], msg[1], msg[2], token=token or "",
                                                          sticky=True, force_replace=True, busy=True) or token)
                    last_msg = msg
                except Exception as exc_n:
                    _pkm_log_v2584("[%s] R57_BG_MEMBERSHIP_NOTICE_FAILED error=%s" % (ADDON_ID, exc_n), xbmc.LOGWARNING)
                    notify = False
            res = dict(box.get("result") or {})
            pruned = int(((res.get("pruned") or {}).get("total", 0)) or 0)
            changed = bool(pruned > 0 or int(res.get("incremental_syncs", 0) or 0) > 0
                           or int(res.get("full_syncs", 0) or 0) > 0
                           or int(res.get("removed_sections", 0) or 0) > 0)
            _pkm_log_v2584("[%s] R57_BG_MEMBERSHIP_DONE ok=%d checked=%d membership_scans=%d pruned=%d incremental=%d full_syncs=%d changed=%d errors=%d error=%s elapsed_ms=%d" % (
                ADDON_ID, 1 if res.get("ok") else 0, int(res.get("checked", 0) or 0),
                int(res.get("membership_scans", 0) or 0), pruned,
                int(res.get("incremental_syncs", 0) or 0), int(res.get("full_syncs", 0) or 0),
                1 if changed else 0, len(res.get("errors") or []), box.get("error") or "-",
                int((time.time() - t0) * 1000)), xbmc.LOGINFO)
            if res.get("ok") and not (res.get("errors") or []):
                try:
                    home.setProperty("PlexKM.Startup.PrehomeAuthorityDoneR19", "1")
                except Exception:
                    pass
            if changed:
                try:
                    if hasattr(core, "_signal_home_data_refresh"):
                        core._signal_home_data_refresh("r57_background_membership")
                except Exception as exc_sig:
                    _pkm_log_v2584("[%s] R57_BG_MEMBERSHIP_SIGNAL_FAILED error=%s" % (ADDON_ID, exc_sig), xbmc.LOGWARNING)
        except Exception as exc_r57:
            _pkm_log_v2584("[%s] R57_BG_MEMBERSHIP_FAILED error=%s" % (ADDON_ID, exc_r57), xbmc.LOGWARNING)
        finally:
            if token and notify:
                try:
                    notify.pkm_notice_clear(expected_token=token, force=True)
                except Exception:
                    pass
            try:
                home.clearProperty("PlexKM.Bg.R57MembershipArmed")
            except Exception:
                pass

    threading.Thread(target=_runner, name="pkm-r57-bg-runner", daemon=True).start()

def _library_add_restart_marker_path():
    """Canonical persistent marker; runtime state is never keyed by patch version."""
    try:
        return xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.km/library_add_restart.json"
        )
    except Exception:
        return ""


def _library_add_restart_marker_read():
    path = _library_add_restart_marker_path()
    if not path or not os.path.isfile(path):
        return path, None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            data = {}
        return path, data
    except Exception:
        _pkm_log_v2584("[%s] LIBRARY_ADD_RESTART_MARKER_READ_FAILED err=%s" % (
            ADDON_ID, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return path, {}


def _library_add_restart_marker_clear(path, reason=""):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
        _pkm_log_v2584("[%s] LIBRARY_ADD_RESTART_MARKER_CLEAR reason=%s" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
        return True
    except Exception:
        _pkm_log_v2584("[%s] LIBRARY_ADD_RESTART_MARKER_CLEAR_FAILED reason=%s err=%s" % (
            ADDON_ID, reason or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return False

def _ensure_ui_sounds_off_once_r275():
    """R275: UI click/navigation sounds are off by default.  Applied once per
    profile (marker file), so a user who turns them on again keeps them on."""
    try:
        marker = xbmcvfs.translatePath("special://profile/addon_data/%s/ui_sounds_off_r275.flag" % ADDON_ID)
        if marker and os.path.exists(marker):
            return
        req = {"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
               "params": {"setting": "audiooutput.guisoundmode", "value": 0}}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)) or "{}")
        ok = "error" not in resp
        _pkm_log_v2584("[%s] PKM_UI_SOUNDS_OFF_R275 ok=%s" % (ADDON_ID, ok), xbmc.LOGINFO)
        if ok and marker:
            d = os.path.dirname(marker)
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            with open(marker, "w") as fh:
                fh.write("1")
    except Exception as exc:
        try:
            _pkm_log_v2584("[%s] PKM_UI_SOUNDS_OFF_R275 failed=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        except Exception:
            pass


def _ensure_kodi_splash_disabled_v1737(reason="service_startup_v1737"):
    """Disable Kodi's core splash on the next application launch.

    Kodi draws its own splash before the skin and this add-on can start, so the
    current launch cannot be covered by PKM.  Persisting <splash>false</splash>
    in advancedsettings.xml removes that core logo from subsequent launches.
    Existing advancedsettings content is preserved by replacing or inserting
    only the direct splash element.  Invalid/nonstandard files are never
    overwritten.
    """
    path = ""
    try:
        path = xbmcvfs.translatePath("special://profile/advancedsettings.xml")
        exists = bool(path and os.path.exists(path))
        newline = "\n"
        if exists:
            with open(path, "r", encoding="utf-8-sig") as src:
                original = src.read()
            newline = "\r\n" if "\r\n" in original else "\n"
            if re.search(r"<splash\b[^>]*>\s*false\s*</splash\s*>", original, re.I | re.S):
                _pkm_log_v2584("[%s] PKM_KODI_SPLASH_DISABLED_V1737 changed=0 path=%s reason=%s" % (
                    ADDON_ID, path, reason), xbmc.LOGINFO)
                return True
            splash_pattern = re.compile(r"<splash\b[^>]*>.*?</splash\s*>", re.I | re.S)
            if splash_pattern.search(original):
                updated = splash_pattern.sub("<splash>false</splash>", original, count=1)
            else:
                close_match = re.search(r"</advancedsettings\s*>", original, re.I)
                open_match = re.search(r"<advancedsettings(?:\s[^>]*)?>", original, re.I)
                if not close_match or not open_match:
                    _pkm_log_v2584("[%s] PKM_KODI_SPLASH_DISABLE_SKIP_V1737 reason=invalid_advancedsettings path=%s" % (
                        ADDON_ID, path), xbmc.LOGWARNING)
                    return False
                insert_at = close_match.start()
                prefix = original[:insert_at]
                if prefix and not prefix.endswith(("\n", "\r")):
                    prefix += newline
                updated = prefix + "  <splash>false</splash>" + newline + original[insert_at:]
        else:
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            updated = (
                '<?xml version="1.0" encoding="UTF-8"?>' + newline +
                '<advancedsettings>' + newline +
                '  <splash>false</splash>' + newline +
                '</advancedsettings>' + newline
            )

        # Validate before touching the live file.  Comments/formatting are kept
        # in the written text; ElementTree is used only as a structural check.
        try:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(updated.encode("utf-8"))
            root_tag = str(root.tag or "").split("}")[-1].lower()
            if root_tag != "advancedsettings":
                raise ValueError("unexpected root %s" % root_tag)
        except Exception as exc:
            _pkm_log_v2584("[%s] PKM_KODI_SPLASH_DISABLE_SKIP_V1737 reason=xml_validation_failed err=%s path=%s" % (
                ADDON_ID, exc, path), xbmc.LOGWARNING)
            return False

        if exists:
            backup = path + ".pkm_v1737.bak"
            if not os.path.exists(backup):
                try:
                    with open(path, "rb") as src, open(backup, "wb") as dst:
                        dst.write(src.read())
                except Exception:
                    pass
        tmp_path = path + ".pkm_v1737.tmp"
        with open(tmp_path, "w", encoding="utf-8", newline="") as dst:
            dst.write(updated)
        os.replace(tmp_path, path)
        _pkm_log_v2584("[%s] PKM_KODI_SPLASH_DISABLED_V1737 changed=1 applies=next_launch path=%s reason=%s" % (
            ADDON_ID, path, reason), xbmc.LOGINFO)
        return True
    except Exception as exc:
        try:
            if path:
                tmp_path = path + ".pkm_v1737.tmp"
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
        except Exception:
            pass
        _pkm_log_v2584("[%s] PKM_KODI_SPLASH_DISABLE_FAILED_V1737 err=%s path=%s reason=%s" % (
            ADDON_ID, exc, path, reason), xbmc.LOGWARNING)
        return False


try:
    from resources.lib import pkm_subtitle_font
except Exception:
    try:
        import pkm_subtitle_font
    except Exception:
        pkm_subtitle_font = None

try:
    from resources.lib import pkm_seek_quick
except Exception:
    try:
        import pkm_seek_quick
    except Exception:
        pkm_seek_quick = None


try:
    from resources.lib import pkm_notify
except Exception:
    try:
        import pkm_notify
    except Exception:
        pkm_notify = None

try:
    from resources.lib import pkm_spinner
except Exception:
    try:
        import pkm_spinner
    except Exception:
        pkm_spinner = None


def _register_subtitle_font_on_startup(reason="service_startup"):
    try:
        if not pkm_subtitle_font:
            _pkm_log_v2584("[%s][subtitle_font] subtitle_font_service_skip reason=helper_import_failed" % ADDON_ID, xbmc.LOGWARNING)
            return False
        if hasattr(pkm_subtitle_font, "register_saved_subtitle_font"):
            state = pkm_subtitle_font.register_saved_subtitle_font(reason=reason, allow_copy=True, apply_setting=True)
        else:
            state = pkm_subtitle_font.register_pkm_subtitle_font(reason=reason, allow_copy=True, apply_setting=True)
        _pkm_log_v2584("[%s][subtitle_font] subtitle_font_service_done ok=%s filename=%s saved_key=%s dst=%s copied=%s reason=%s" % (
            ADDON_ID,
            "1" if state.get("ok") else "0",
            state.get("filename", ""),
            state.get("saved_key", ""),
            state.get("dst", ""),
            "1" if state.get("copied") else "0",
            reason,
        ), xbmc.LOGINFO if state.get("ok") else xbmc.LOGWARNING)
        return bool(state.get("ok"))
    except Exception as exc:
        _pkm_log_v2584("[%s][subtitle_font] subtitle_font_service_failed reason=%s err=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
        return False

# v531: process-local shutdown flag. Kodi kills service.py if the invoker
# keeps Python/network work alive for more than a few seconds during app exit.
# This flag is data-service only; it does not control UI focus/navigation.
_SERVICE_STOP = threading.Event()
_SERVICE_STOP_LOGGED = [False]

# v2151: service-owned daemon workers are registered so full reset can drain
# them before reporting the service stopped.
_PKM_SERVICE_THREADS_V2151_LOCK = threading.RLock()
_PKM_SERVICE_THREADS_V2151 = weakref.WeakSet()


class _PKMServiceThreadV2151(threading.Thread):
    def __init__(self, *args, **kwargs):
        threading.Thread.__init__(self, *args, **kwargs)
        try:
            with _PKM_SERVICE_THREADS_V2151_LOCK:
                _PKM_SERVICE_THREADS_V2151.add(self)
        except Exception:
            pass


def _service_worker_drain_v2151(timeout_ms=20000):
    current = threading.current_thread()
    waited = 0
    pending = []
    while waited < max(0, int(timeout_ms or 0)):
        try:
            with _PKM_SERVICE_THREADS_V2151_LOCK:
                pending = [t for t in list(_PKM_SERVICE_THREADS_V2151) if t is not current and t.is_alive()]
        except Exception:
            pending = []
        if not pending:
            break
        xbmc.sleep(25)
        waited += 25
    names = [str(getattr(t, "name", "") or "") for t in pending]
    try:
        _pkm_log_v2584("[%s] PKM_FULL_RESET_SERVICE_WORKER_DRAIN_V2151 waited_ms=%d active=%d pending=%s ok=%d" % (
            ADDON_ID, waited, len(pending), " | ".join(names[:12]) if names else "-", 0 if pending else 1
        ), xbmc.LOGWARNING if pending else xbmc.LOGINFO)
    except Exception:
        pass
    return not bool(pending)


def _bool_setting(key, default=True):
    try:
        value = ADDON.getSetting(key)
        if value == "":
            return default
        return value.lower() == "true"
    except Exception:
        return default




def _text_setting(key, default=""):
    try:
        value = ADDON.getSetting(key)
        if value is None:
            return default
        return str(value).strip()
    except Exception:
        return default


_R108_GATE_LOGGED = {}


def _plex_config_ready():
    """Return True only after the user has completed the minimum Plex settings.

    Fresh installs have a default plex_url but an empty token.  Autostarting the
    WindowXML Home before the token is saved steals focus from Kodi's add-on
    settings dialog, so gate Home autostart on real connection settings.
    """
    plex_url = _text_setting("plex_url")
    plex_token = _text_setting("plex_token")
    # R108: content source registry.  Existing installs migrate to a single
    # Plex source, so for them this is the same url+token check as before.
    try:
        from resources.lib import pkm_sources as _pkm_sources_r108
        _pkm_sources_r108.ensure_migrated(reason="autostart_gate")
        if _pkm_sources_r108.has_kodi() and not _pkm_sources_r108.has_plex():
            ready_r108 = _pkm_sources_r108.startup_ready()
            if _R108_GATE_LOGGED.get("value") != ready_r108:
                _R108_GATE_LOGGED["value"] = ready_r108
                _pkm_log_v2584("[%s] PKM_SOURCES_R108_GATE kodi_only=1 ready=%s" % (ADDON_ID, "1" if ready_r108 else "0"), xbmc.LOGINFO)
            return bool(ready_r108)
    except Exception as _exc_r108:
        _pkm_log_v2584("[%s] PKM_SOURCES_R108_GATE_FAILED %s" % (ADDON_ID, _exc_r108), xbmc.LOGWARNING)
    if not plex_url or not plex_token:
        try:
            _pkm_log_v2584("[%s] AUTOSTART_HOME_SKIP reason=settings_incomplete url=%s token=%s" % (ADDON_ID, "1" if plex_url else "0", "1" if plex_token else "0"), xbmc.LOGINFO)
        except Exception:
            pass
        return False
    return True


def _server_host_key_v1310(url):
    try:
        text = str(url or "").strip()
        if not text:
            return ""
        if "://" not in text:
            text = "http://" + text
        parsed = urlparse(text)
        host = (getattr(parsed, "netloc", "") or "").strip().lower()
        if "@" in host:
            host = host.rsplit("@", 1)[-1]
        return host.rstrip("/")
    except Exception:
        return ""


def _current_server_identity_v1310():
    try:
        server = _text_setting("plex_url").rstrip("/")
        token = _text_setting("plex_token")
        host = _server_host_key_v1310(server)
        if not server or not token or not host:
            return {}
        sig = hashlib.sha1(("v1310|%s|%s" % (host, token)).encode("utf-8")).hexdigest()
        return {"signature": sig, "server_url": server, "server_host": host}
    except Exception:
        return {}


def _server_switch_pending_active_v1310():
    try:
        win = xbmcgui.Window(10000)
        return (
            win.getProperty("PlexKM.Home.ServerSwitchPending") == "1"
            or win.getProperty("PlexKM.Settings.ServerSwitchPendingV1310") == "1"
        )
    except Exception:
        return False


def _settings_dialog_active():
    try:
        return bool(
            xbmc.getCondVisibility("Window.IsActive(addonsettings)")
            or xbmc.getCondVisibility("System.HasModalDialog")
        )
    except Exception:
        return False


def _request_service_stop(reason=""):
    try:
        _SERVICE_STOP.set()
    except Exception:
        pass
    try:
        _set_service_window_stopping(True)
        _set_service_stopping(True)
    except Exception:
        pass
    try:
        if not _SERVICE_STOP_LOGGED[0]:
            _SERVICE_STOP_LOGGED[0] = True
            _pkm_log_v2584("[%s] SERVICE_STOP_REQUEST reason=%s" % (ADDON_ID, str(reason or "")), xbmc.LOGINFO)
    except Exception:
        pass


def _set_service_window_stopping(value):
    # v517: diagnostic/shutdown flag only.  No UI focus or navigation control.
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.ServiceStopping", "1" if value else "0")
    except Exception:
        pass


def _load_core():
    addon_dir = ADDON.getAddonInfo("path")
    if addon_dir and addon_dir not in sys.path:
        sys.path.insert(0, addon_dir)
    import default as plex_km_default
    return plex_km_default


class PlexKMPlaybackMonitor(xbmc.Player):
    """Push Kodi playback state to Plex.

    Kodi plays the direct Plex media URL after default.py resolves action=play.
    Direct playback alone does not guarantee PMS receives progress updates, so
    this monitor sends /:/timeline updates using the ratingKey saved by play_item().
    """

    def __init__(self, core, monitor):
        xbmc.Player.__init__(self)
        self.core = core
        self.monitor = monitor
        self.rating_key = ""
        self._active = False
        self._last_push_ms = 0
        self._last_pos_ms = 0
        self._last_duration_ms = 0
        self._watched_ask_snap_r301 = None
        self._lock = threading.Lock()
        self._shutting_down = False
        self._pause_preread_thread = None
        self._pause_preread_started_ms = 0
        self._videoosd_preloaded_v1947 = False
        self._videoosd_preload_running_v1947 = False
        self._network_health_v2126 = NetworkHealthMonitor() if NetworkHealthMonitor else None
        self._episode_flow_v2222 = pkm_episode_flow_v2222.EpisodeFlowRuntimeV2222() if pkm_episode_flow_v2222 else None

    def _window(self):
        return xbmcgui.Window(10000)

    def _resolver_pre_avstarted_v1547(self):
        """Return resolver-opening context before the real AV session exists.

        Kodi emits a short onPlayBackStarted -> onPlayBackStopped pair while a
        plugin:// URL is handed from PlayMedia to setResolvedUrl.  That pair is
        a resolver boundary, not the movie session.  It must never enter the
        Plex playstate tracker.  The real session starts only at onAVStarted.
        """
        try:
            win = self._window()
            phase = win.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
            source = win.getProperty("PlexKM.Playback.NativeOpening.Source") or ""
            token = win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
            native_token = win.getProperty("PlexKM.Playback.NativeOpening.Token") or ""
            if win.getProperty("PlexKM.Playback.BackStopRequested") == "1":
                return False
            if win.getProperty("PlexKM.Playback.OpeningActive") != "1":
                return False
            if win.getProperty("PlexKM.Playback.NativeOpening.Pending") != "1":
                return False
            if source != "info_playmedia_native_v1454_locked":
                return False
            if not token or token != native_token:
                return False
            return phase in ("armed", "resolver_started", "handoff_stop_blocked")
        except Exception:
            return False

    def _clear_resolver_phase_v1547(self, reason=""):
        try:
            win = self._window()
            token = win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
            for key in (
                "PlexKM.Playback.ResolverTokenV1547",
                "PlexKM.Playback.ResolverPhaseV1547",
                "PlexKM.Playback.ResolverHandoffStopAtMsV1547",
                "PlexKM.Playback.ResolverAVStartedAtMsV1547",
                "PlexKM.Playback.ResolverTickHoldLoggedV1547",
                "PlexKM.Playback.OpenFailureCandidateV2224",
                "PlexKM.Playback.OpenFailureCandidateAtMsV2224",
                "PlexKM.Playback.FailureHomeRequestV2224",
                "PlexKM.Playback.FailureHomeRequestSourceV2224",
            ):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
            _pkm_log_v2584("[%s] PLAYBACK_RESOLVER_PHASE_CLEAR_V1547 reason=%s token=%s" % (ADDON_ID, reason or "", token), xbmc.LOGINFO)
        except Exception:
            pass

    def _read_pending_rating_key(self):
        try:
            return self._window().getProperty("PlexKM.NowPlaying.RatingKey") or self._window().getProperty("PlexKM.MainPlaybackRatingKey") or ""
        except Exception:
            return ""

    def _read_pending_expected_resume_ms(self):
        try:
            return max(0, int(float(self._window().getProperty("PlexKM.NowPlaying.ExpectedResumeMs") or 0)))
        except Exception:
            return 0

    def _pending_nowplaying_age_ms(self):
        try:
            started = int(float(self._window().getProperty("PlexKM.NowPlaying.StartedAtMs") or 0))
            if started <= 0:
                started_s = int(float(self._window().getProperty("PlexKM.NowPlaying.StartedAt") or 0))
                started = started_s * 1000 if started_s > 0 else 0
            return max(0, int(time.time() * 1000) - started) if started > 0 else 999999
        except Exception:
            return 999999

    def _resume_seek_pending_unverified_v1551(self):
        """True while a resume playback has not reached its requested position.

        A cold different-file switch can report onAVStarted while Kodi is still at
        0 seconds.  During that window PKM must not start the linear pre-reader,
        because its extra HTTP Range reader competes with Kodi's own resume seek.
        """
        try:
            e = self._read_pending_expected_resume_ms()
            if e < 60000:
                return False
            if self._pending_nowplaying_age_ms() > 45000:
                return False
            try:
                if not self.isPlayingVideo():
                    return False
            except Exception:
                return False
            p, d = self._player_times_ms()
            if int(d or 0) <= 0:
                return True
            return bool(int(p or 0) > int(e) + 120000 or int(p or 0) + 30000 < int(e))
        except Exception:
            return False

    def _apply_expected_resume_seek_v1506(self, rating_key, reason, pos_ms, duration_ms, expected_ms, age_ms):
        """v1553: service-layer automatic resume seek is permanently disabled.

        Resume belongs to the Kodi-native PlayMedia(plugin://...) + setResolvedUrl
        handoff. The resolver supplies StartOffset, ResumeTime, TotalTime and the
        InfoTagVideo resume point before VideoPlayer opens the Plex part. This
        monitor only verifies the resulting position; it must never call
        self.seekTime() to manufacture resume after playback has started.
        """
        try:
            win = self._window()
            if win.getProperty("PlexKM.NowPlaying.NativeResumeWaitLoggedV1553") != "1":
                win.setProperty("PlexKM.NowPlaying.NativeResumeWaitLoggedV1553", "1")
                _pkm_log_v2584("[%s] PKM_NATIVE_RESUME_VERIFY_ONLY_V1553 rating_key=%s event=%s pos=%s expected=%s duration=%s age_ms=%s action=no_seek_wait_for_kodi_native_resume" % (
                    ADDON_ID, rating_key, reason, max(0, int(pos_ms or 0)), max(0, int(expected_ms or 0)), max(0, int(duration_ms or 0)), max(0, int(age_ms or 0))
                ), xbmc.LOGINFO)
        except Exception:
            pass
        return False

    def _looks_like_stale_player_position(self, rating_key, reason, pos_ms, duration_ms, expected_ms, age_ms):
        try:
            p = max(0, int(pos_ms or 0))
            d = max(0, int(duration_ms or 0))
            e = max(0, int(expected_ms or 0))
            age = max(0, int(age_ms or 0))
            win = self._window()
            if d > 0 and e > 0:
                mismatch = bool(p > e + 120000 or p + 30000 < e)
                if not mismatch:
                    had_pending_seek = win.getProperty("PlexKM.NowPlaying.ResumeSeekPendingV1548") == "1"
                    waiting_cover = win.getProperty("PlexKM.Playback.NativeOpening.WaitResumeV1551") == "1"
                    if had_pending_seek or waiting_cover:
                        attempts = win.getProperty("PlexKM.NowPlaying.ResumeSeekAttemptsV1548") or "0"
                        _pkm_log_v2584("[%s] PKM_NATIVE_RESUME_VERIFIED_V1553 rating_key=%s event=%s pos=%s expected=%s duration=%s age_ms=%s attempts=%s native_position=1 auto_seek=0 preread_release=%s spinner_release=%s" % (ADDON_ID, rating_key, reason, p, e, d, age, attempts, "1" if had_pending_seek else "0", "1" if waiting_cover else "0"), xbmc.LOGINFO)
                        win.clearProperty("PlexKM.NowPlaying.ResumeSeekPendingV1548")
                        win.clearProperty("PlexKM.NowPlaying.ResumeSeekCachingHoldLoggedV1551")
                        win.clearProperty("PlexKM.NowPlaying.NativeResumeWaitLoggedV1553")
                        if waiting_cover:
                            try:
                                self._clear_native_opening_spinner_v1415(reason="resume_verified_v1551", force=True)
                            except Exception:
                                pass
                        try:
                            self._cancel_auto_preread_v1449(reason="native_resume_verified_v1635_playback_owns_network")
                            _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=native_resume_verified_v1553 state=playing policy=pause_only_single_http_reader" % ADDON_ID, xbmc.LOGINFO)
                        except Exception:
                            pass
                    return False
                requested = self._apply_expected_resume_seek_v1506(rating_key, reason, p, d, e, age)
                attempts = win.getProperty("PlexKM.NowPlaying.ResumeSeekAttemptsV1548") or "0"
                if age <= 15000:
                    _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START_DEFER reason=stale_position_guard_v1548 event=%s rating_key=%s pos=%s duration=%s expected=%s age_ms=%s native_resume_wait=1 auto_seek=0 attempts=%s" % (ADDON_ID, reason, rating_key, p, d, e, age, attempts), xbmc.LOGINFO)
                elif win.getProperty("PlexKM.NowPlaying.ResumeSeekMismatchHoldLoggedV1548") != "1":
                    win.setProperty("PlexKM.NowPlaying.ResumeSeekMismatchHoldLoggedV1548", "1")
                    _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START_HOLD_V1548 reason=native_resume_position_not_verified event=%s rating_key=%s pos=%s duration=%s expected=%s age_ms=%s attempts=%s action=no_seek_do_not_accept_zero_do_not_overwrite_resume" % (ADDON_ID, reason, rating_key, p, d, e, age, attempts), xbmc.LOGWARNING)
                return True
            if age <= 8000 and d > 0 and e <= 0 and p > 60000:
                _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START_DEFER reason=stale_position_guard event=%s rating_key=%s pos=%s duration=%s expected=0 age_ms=%s" % (ADDON_ID, reason, rating_key, p, d, age), xbmc.LOGINFO)
                return True
        except Exception:
            pass
        return False

    def _clear_pending_properties(self):
        try:
            win = self._window()
            win.clearProperty("PlexKM.NowPlaying.RatingKey")
            win.clearProperty("PlexKM.NowPlaying.PartKey")
            win.clearProperty("PlexKM.NowPlaying.AudioStreamIndex")
            win.clearProperty("PlexKM.NowPlaying.StartedAt")
            win.clearProperty("PlexKM.NowPlaying.StartedAtMs")
            win.clearProperty("PlexKM.NowPlaying.ExpectedResumeMs")
            win.clearProperty("PlexKM.NowPlaying.ExpectedDurationMs")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekAppliedV1506")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekAppliedAtMs")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekAttemptsV1548")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekSingleSentLoggedV1552")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekLastAtMsV1548")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekPendingV1548")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekExhaustedLoggedV1548")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekMismatchHoldLoggedV1548")
            win.clearProperty("PlexKM.NowPlaying.ResumeSeekCachingHoldLoggedV1551")
            win.clearProperty("PlexKM.NowPlaying.NativeResumeWaitLoggedV1553")
            win.clearProperty("PlexKM.Playback.NativeOpening.WaitResumeV1551")
            win.clearProperty("PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551")
            win.clearProperty("PlexKM.Player.Title")
            win.clearProperty("PlexKM.Player.Meta")
            win.clearProperty("PlexKM.Player.Year")
            win.clearProperty("PlexKM.Player.Runtime")
            win.clearProperty("PlexKM.Player.EpPrefix")
            win.clearProperty("PlexKM.Player.EpLine")
            win.clearProperty("PlexKM.Player.EpNav")
            win.clearProperty("PlexKM.Player.OsdTitleR290")
            win.clearProperty("PlexKM.PendingSubtitle.RatingKey")
            win.clearProperty("PlexKM.PendingSubtitle.Url")
            win.clearProperty("PlexKM.PendingSubtitle.Label")
            win.clearProperty("PlexKM.PendingSubtitle.Source")
            win.clearProperty("PlexKM.PendingSubtitle.SetAt")
            win.clearProperty("PlexKM.PendingSubtitle.Attempt")
            win.clearProperty("PlexKM.PendingSubtitle.Done")
            win.clearProperty("PlexKM.PendingSubtitle.InternalAttempt")
            win.clearProperty("PlexKM.PendingSubtitle.InternalDone")
            win.clearProperty("PlexKM.Playback.NativeOpening")
            win.clearProperty("PlexKM.Playback.NativeOpening.SpinnerVisible")
            win.clearProperty("PlexKM.Playback.NativeOpening.Pending")
            win.clearProperty("PlexKM.Playback.NativeOpening.HoldClear")
            win.clearProperty("PlexKM.Playback.OpeningActive")
            win.clearProperty("PlexKM.Playback.OpeningRatingKey")
            win.clearProperty("PlexKM.Playback.NativeOpening.RatingKey")
            win.clearProperty("PlexKM.Playback.NativeOpening.Token")
            win.clearProperty("PlexKM.Playback.NativeOpening.Source")
            win.clearProperty("PlexKM.Playback.NativeOpening.ArmedAtMs")
            win.clearProperty("PlexKM.Playback.NativeOpening.ShownAtMs")
            win.clearProperty("PlexKM.Playback.ResolverTokenV1547")
            win.clearProperty("PlexKM.Playback.ResolverPhaseV1547")
            win.clearProperty("PlexKM.Playback.ResolverHandoffStopAtMsV1547")
            win.clearProperty("PlexKM.Playback.ResolverAVStartedAtMsV1547")
            win.clearProperty("PlexKM.Playback.ResolverTickHoldLoggedV1547")
        except Exception:
            pass

    def _clear_native_opening_spinner_v1415(self, reason="", force=False):
        try:
            win = self._window()
            token = win.getProperty("PlexKM.Playback.NativeOpening.Token") or ""
            rk = win.getProperty("PlexKM.Playback.NativeOpening.RatingKey") or ""
            visible = win.getProperty("PlexKM.Playback.NativeOpening") == "1"
            pending = win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
            if not visible and not pending:
                return

            def _clear_all(_reason, _token, _rk):
                try:
                    w = xbmcgui.Window(10000)
                    if _token and w.getProperty("PlexKM.Playback.NativeOpening.Token") != _token:
                        return
                    w.clearProperty("PlexKM.Playback.NativeOpening")
                    w.clearProperty("PlexKM.Playback.NativeOpening.SpinnerVisible")
                    w.clearProperty("PlexKM.Playback.NativeOpening.Pending")
                    w.clearProperty("PlexKM.Playback.NativeOpening.HoldClear")
                    w.clearProperty("PlexKM.Playback.NativeOpening.WaitResumeV1551")
                    w.clearProperty("PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551")
                    w.clearProperty("PlexKM.Playback.OpeningActive")
                    w.clearProperty("PlexKM.Playback.OpeningRatingKey")
                    w.clearProperty("PlexKM.Playback.NativeOpening.RatingKey")
                    w.clearProperty("PlexKM.Playback.NativeOpening.Token")
                    w.clearProperty("PlexKM.Playback.NativeOpening.Source")
                    w.clearProperty("PlexKM.Playback.NativeOpening.ArmedAtMs")
                    w.clearProperty("PlexKM.Playback.NativeOpening.ShownAtMs")
                    for _nk in ("Active", "Title", "Line1", "Line2"):
                        w.clearProperty("PlexKM.Playback.OpeningNotice." + _nk)
                    _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_CLEAR_V1551 reason=%s rating_key=%s token=%s" % (ADDON_ID, _reason or "", _rk, _token), xbmc.LOGINFO)
                except Exception:
                    pass

            # v1940: onAVStarted means Kodi has published the real video surface.
            # Remove the opening overlay immediately so the spinner can never sit
            # above visible video. Native resume verification continues separately
            # and must not own or delay the visual opening overlay.
            if reason == "onAVStarted":
                _clear_all("onAVStarted_immediate_v1940", token, rk)
                _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_CLEAR_IMMEDIATE_V1940 reason=onAVStarted rating_key=%s token=%s video_surface=1" % (ADDON_ID, rk, token), xbmc.LOGINFO)
                return

            if force:
                _clear_all(reason or "resume_verified_immediate_v1940", token, rk)
                _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_FORCE_CLEAR_IMMEDIATE_V1940 reason=%s rating_key=%s token=%s hold_ms=0" % (ADDON_ID, reason or "", rk, token), xbmc.LOGINFO)
                return

            if visible:
                if win.getProperty("PlexKM.Playback.NativeOpening.HoldClear") != "1":
                    win.setProperty("PlexKM.Playback.NativeOpening.HoldClear", "1")
                    _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_HOLD_V1497 reason=%s rating_key=%s token=%s hold_ms=350" % (ADDON_ID, reason or "", rk, token), xbmc.LOGINFO)
                    try:
                        import threading
                        def _delayed():
                            xbmc.sleep(350)
                            _clear_all(reason or "hold_350ms", token, rk)
                        _PKMServiceThreadV2151(target=_delayed, daemon=True).start()
                    except Exception:
                        xbmc.sleep(350)
                        _clear_all(reason or "hold_350ms", token, rk)
                return

            _clear_all((reason or "") + "_fast_skip", token, rk)
            _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_FAST_SKIP_V1419 reason=%s rating_key=%s token=%s" % (ADDON_ID, reason or "", rk, token), xbmc.LOGINFO)
        except Exception:
            pass

    def _player_times_ms(self):
        pos_ms = self._last_pos_ms
        duration_ms = self._last_duration_ms
        try:
            if self.isPlayingVideo():
                pos_ms = int(float(self.getTime() or 0) * 1000.0)
        except Exception:
            pass
        try:
            if self.isPlayingVideo():
                duration_ms = int(float(self.getTotalTime() or 0) * 1000.0)
        except Exception:
            pass
        self._last_pos_ms = max(0, int(pos_ms or 0))
        self._last_duration_ms = max(0, int(duration_ms or 0))
        return self._last_pos_ms, self._last_duration_ms

    def _is_near_end(self, pos_ms, duration_ms):
        try:
            p = int(pos_ms or 0)
            d = int(duration_ms or 0)
            return d > 0 and (p >= max(0, d - 15000) or (float(p) / float(d)) >= 0.90)
        except Exception:
            return False

    def _mark_update_done(self, rating_key, success=True, error_text=""):
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.PlayStateDirty", "1")
            win.setProperty("PlexKM.PlayStateDirtyRatingKey", str(rating_key or ""))
            now_ms = str(int(time.time() * 1000))
            win.setProperty("PlexKM.PlayStateRefreshDoneAt", now_ms)
            # v1632: do not dispatch a Home DataRefresh worker from playback stop.
            # The old signal was converted into global PlexUpdate dirty and rebuilt
            # the complete Home stack while the first sidebar key was being handled.
            # Queue a Home-only Continue Watching refresh for the next natural Home
            # entry; the current completed scene remains immediately navigable.
            try:
                if rating_key:
                    win.setProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632", "1")
                    win.setProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632", str(rating_key or ""))
                    win.setProperty("PlexKM.Playback.PostStopHomeRefreshTokenV1632", "playstate:%s:%s" % (rating_key, now_ms))
                    win.clearProperty("PlexKM.Home.DataRefreshReason")
                    win.clearProperty("PlexKM.Home.DataRefreshToken")
                    _pkm_log_v2584("[%s] PLAYSTATE_HOME_REFRESH_QUEUE_V1632 rating_key=%s token=playstate:%s:%s immediate_home_rebuild=0" % (
                        ADDON_ID, rating_key, rating_key, now_ms
                    ), xbmc.LOGINFO)
            except Exception:
                pass
            if success:
                win.clearProperty("PlexKM.PlayStateUpdateFailed")
            else:
                win.setProperty("PlexKM.PlayStateUpdateFailed", str(error_text or "1"))
            win.clearProperty("PlexKM.PlayStateUpdatePending")
            win.clearProperty("PlexKM.PlayStatePendingRatingKey")
            win.clearProperty("PlexKM.PlayStatePendingStartedAt")
        except Exception:
            pass

    def _async_push(self, state, pos_ms=None, duration_ms=None, refresh_after=False, mark_watched=False, shutdown=False):
        # v531: never start network/timeline worker while Kodi is shutting down.
        # The service must return quickly; Plex will keep the last already-sent state.
        if shutdown or self._shutting_down or _service_stopping(self.monitor):
            try:
                _pkm_log_v2584("[%s] PLAYSTATE_ASYNC_SKIP reason=service_stopping state=%s" % (ADDON_ID, state), xbmc.LOGINFO)
            except Exception:
                pass
            return
        rating_key = self.rating_key or self._read_pending_rating_key()
        if not rating_key:
            return
        if pos_ms is None or duration_ms is None:
            pos_ms, duration_ms = self._player_times_ms()

        def _run():
            try:
                if self._shutting_down or _service_stopping(self.monitor):
                    return
                ok = self.core.plex_timeline(rating_key, state=state, time_ms=pos_ms, duration_ms=duration_ms, context="playback")
                if shutdown:
                    # Kodi is exiting.  Never block shutdown for PMS commit/read-back;
                    # the final timeline push is fire-and-forget and daemon-threaded.
                    try:
                        _pkm_log_v2584("[%s] PLAYSTATE_SHUTDOWN_FAST_EXIT rating_key=%s state=%s" % (ADDON_ID, rating_key, state), xbmc.LOGINFO)
                    except Exception:
                        pass
                    return
                if refresh_after:
                    if mark_watched:
                        self.core.plex_scrobble(rating_key, reason="playback_ended")
                        try:
                            self.core.clear_local_resume_state(rating_key, reason="watched")
                        except Exception:
                            pass
                    elif pos_ms and duration_ms and not self._is_near_end(pos_ms, duration_ms):
                        # Do NOT unscrobble on every partial stop.  On some PMS builds
                        # /:/unscrobble also clears the freshly saved resume position,
                        # which keeps the item out of onDeck.  Instead keep a tiny local
                        # resume sidecar so Kodi Home updates immediately while PMS catches up.
                        try:
                            pct = (float(pos_ms) / float(duration_ms) * 100.0) if duration_ms else 0.0
                        except Exception:
                            pct = 0.0
                        try:
                            _pkm_log_v2584("[%s] PLAYSTATE_PARTIAL_STOP_SAVE_REQUEST rating_key=%s pos=%s duration=%s pct=%.2f" % (ADDON_ID, rating_key, pos_ms, duration_ms, pct), xbmc.LOGINFO)
                            saved = self.core.record_local_resume_state(rating_key, time_ms=pos_ms, duration_ms=duration_ms, reason="partial_stop")
                            _pkm_log_v2584("[%s] PLAYSTATE_PARTIAL_STOP_SAVE_RESULT rating_key=%s saved=%s" % (ADDON_ID, rating_key, "1" if saved else "0"), xbmc.LOGINFO)
                        except Exception as exc:
                            _pkm_log_v2584("[%s] PLAYSTATE_PARTIAL_STOP_SAVE_FAILED rating_key=%s error=%s" % (ADDON_ID, rating_key, exc), xbmc.LOGWARNING)
                    # Give PMS a short moment to commit viewOffset/viewCount before pulling it back.
                    xbmc.sleep(650)
                    refreshed = self.core.refresh_item_state_from_plex(rating_key, reason="playback_%s" % state, expect_watched=bool(mark_watched))
                    self._mark_update_done(rating_key, success=bool(ok or refreshed))
            except Exception as exc:
                try:
                    _pkm_log_v2584("[%s] PLAYSTATE_ASYNC_FAILED state=%s rating_key=%s error=%s" % (ADDON_ID, state, rating_key, exc), xbmc.LOGWARNING)
                except Exception:
                    pass
                if refresh_after:
                    self._mark_update_done(rating_key, success=False, error_text=str(exc))

        t = _PKMServiceThreadV2151(target=_run, name="PlexKMPlayStatePush", daemon=True)
        t.daemon = True
        t.start()

    def _jsonrpc(self, method, params=None):
        try:
            payload = {"jsonrpc": "2.0", "id": 1, "method": method}
            if params is not None:
                payload["params"] = params
            raw = xbmc.executeJSONRPC(json.dumps(payload))
            return json.loads(raw or "{}")
        except Exception:
            return {}

    def _is_korean_subtitle_entry(self, stream):
        try:
            vals = []
            if isinstance(stream, dict):
                for key in ("language", "lang", "name", "label", "title"):
                    v = stream.get(key)
                    if v:
                        vals.append(str(v).lower())
            else:
                vals.append(str(stream or "").lower())
            joined = " ".join(vals)
            return ("kor" in joined) or ("korean" in joined) or ("한국" in joined) or (joined.strip() == "ko")
        except Exception:
            return False

    def _internal_subtitle_label(self, stream, index):
        try:
            lang = ""
            name = ""
            codec = ""
            if isinstance(stream, dict):
                lang = str(stream.get("language") or stream.get("lang") or "")
                name = str(stream.get("name") or stream.get("label") or "")
                codec = str(stream.get("codec") or stream.get("format") or "")
            label = "한국어" if self._is_korean_subtitle_entry(stream) else (lang or name or ("자막 %s" % (int(index) + 1)))
            if codec:
                label = "%s (내장 %s)" % (label, codec.upper())
            else:
                label = "%s (내장)" % label
            return label
        except Exception:
            return "한국어 (내장)"

    def _apply_internal_korean_default_subtitle(self, reason="tick"):
        """Fallback policy when no Plex external Korean subtitle was pending.

        User policy: external Korean subtitles win first; when no external Korean
        was found, select a Korean internal/muxed subtitle automatically.
        """
        try:
            if self._shutting_down or _service_stopping(self.monitor):
                return False
            if not self.isPlayingVideo():
                return False
            win = self._window()
            if win.getProperty("PlexKM.PendingSubtitle.InternalDone") == "1":
                return False
            attempt = int(win.getProperty("PlexKM.PendingSubtitle.InternalAttempt") or "0")
            if attempt >= 3:
                return False
            attempt += 1
            win.setProperty("PlexKM.PendingSubtitle.InternalAttempt", str(attempt))

            subs = []
            try:
                res = self._jsonrpc("Player.GetProperties", {"playerid": 1, "properties": ["subtitles", "currentsubtitle"]})
                subs = (((res or {}).get("result") or {}).get("subtitles") or [])
            except Exception:
                subs = []
            if not subs:
                try:
                    raw = xbmc.Player().getAvailableSubtitleStreams()
                    for i, st in enumerate(list(raw or [])):
                        if isinstance(st, dict):
                            d = dict(st)
                            d.setdefault("index", i)
                            subs.append(d)
                        else:
                            subs.append({"language": str(st or ""), "index": i})
                except Exception:
                    subs = []

            for i, st in enumerate(list(subs or [])):
                if not self._is_korean_subtitle_entry(st):
                    continue
                try:
                    idx = int(st.get("index", i)) if isinstance(st, dict) else i
                except Exception:
                    idx = i
                label = self._internal_subtitle_label(st, idx)
                try:
                    self.setSubtitleStream(idx)
                    try:
                        self.showSubtitles(True)
                    except Exception:
                        pass
                    win.setProperty("PlexKM.PendingSubtitle.InternalDone", "1")
                    _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_INTERNAL_APPLY rating_key=%s index=%s label=%s attempt=%s reason=%s" % (ADDON_ID, self.rating_key, idx, label, attempt, reason), xbmc.LOGINFO)
                    return True
                except Exception as exc:
                    _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_INTERNAL_APPLY_FAILED rating_key=%s index=%s label=%s attempt=%s reason=%s error=%s" % (ADDON_ID, self.rating_key, idx, label, attempt, reason, exc), xbmc.LOGWARNING)
                    return False

            _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_INTERNAL_NONE rating_key=%s attempt=%s streams=%d reason=%s" % (ADDON_ID, self.rating_key, attempt, len(subs or []), reason), xbmc.LOGINFO)
            return False
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_INTERNAL_GUARD_FAILED reason=%s error=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _apply_pending_default_subtitle(self, reason="tick"):
        """Default subtitle policy after playback starts.

        Priority is Plex/external Korean first.  If no external subtitle is
        pending, fall back to Kodi's internal Korean subtitle stream.
        """
        try:
            if self._shutting_down or _service_stopping(self.monitor):
                return
            win = self._window()
            url = win.getProperty("PlexKM.PendingSubtitle.Url") or ""
            if not url:
                self._apply_internal_korean_default_subtitle(reason=reason)
                return
            rk = win.getProperty("PlexKM.PendingSubtitle.RatingKey") or ""
            if self.rating_key and rk and str(rk) != str(self.rating_key):
                return
            if not self.isPlayingVideo():
                return
            attempt = int(win.getProperty("PlexKM.PendingSubtitle.Attempt") or "0")
            if attempt >= 2:
                return
            label = win.getProperty("PlexKM.PendingSubtitle.Label") or "한국어 (외부)"
            try:
                self.setSubtitles(url)
                try:
                    self.showSubtitles(True)
                except Exception:
                    pass
                try:
                    win.setProperty("PlexKM.CurrentSubtitle.Source", "external")
                    win.setProperty("PlexKM.CurrentSubtitle.Url", url)
                    win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                except Exception:
                    pass
                attempt += 1
                win.setProperty("PlexKM.PendingSubtitle.Attempt", str(attempt))
                # R140: 성공하면 한 번으로 끝 — 두 번째 setSubtitles 가 자막 스트림을 다시 열어 재생 시작 때 멈칫함
                win.setProperty("PlexKM.PendingSubtitle.Done", "1")
                win.clearProperty("PlexKM.PendingSubtitle.Url")
                _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_APPLY rating_key=%s attempt=%s label=%s url=1 source=external reason=%s" % (ADDON_ID, rk or self.rating_key, attempt, label, reason), xbmc.LOGINFO)
            except Exception as exc:
                attempt += 1
                win.setProperty("PlexKM.PendingSubtitle.Attempt", str(attempt))
                _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_APPLY_FAILED rating_key=%s attempt=%s label=%s reason=%s error=%s" % (ADDON_ID, rk or self.rating_key, attempt, label, reason, exc), xbmc.LOGWARNING)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] PLAYBACK_SUBTITLE_DEFAULT_GUARD_FAILED reason=%s error=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    def _start_tracking(self, reason="started"):
        if self._shutting_down or _service_stopping(self.monitor):
            return
        rating_key = self._read_pending_rating_key()
        if not rating_key:
            return
        rating_key = str(rating_key)
        expected_ms = self._read_pending_expected_resume_ms()
        age_ms = self._pending_nowplaying_age_ms()
        with self._lock:
            pos_ms, duration_ms = self._player_times_ms()
            if self._looks_like_stale_player_position(rating_key, reason, pos_ms, duration_ms, expected_ms, age_ms):
                return
            was_active = bool(self._active and self.rating_key == rating_key)
            self.rating_key = rating_key
            self._active = True
            if not was_active:
                self._last_push_ms = 0
        try:
            self._apply_pending_default_subtitle(reason=reason)
        except Exception:
            pass
        if int(duration_ms or 0) <= 0:
            _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START_DEFER reason=%s rating_key=%s pos=%s duration=%s expected=%s age_ms=%s" % (ADDON_ID, reason, self.rating_key, pos_ms, duration_ms, expected_ms, age_ms), xbmc.LOGINFO)
            return
        if was_active and reason != "onAVStarted":
            _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START_SKIP_DUP reason=%s rating_key=%s pos=%s duration=%s" % (ADDON_ID, reason, self.rating_key, pos_ms, duration_ms), xbmc.LOGINFO)
            return
        _pkm_log_v2584("[%s] PLAYSTATE_TRACK_START reason=%s rating_key=%s pos=%s duration=%s expected=%s age_ms=%s" % (ADDON_ID, reason, self.rating_key, pos_ms, duration_ms, expected_ms, age_ms), xbmc.LOGINFO)
        self._async_push("playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)

    def _ask_mark_watched_on_back_r301(self, rating_key, pos_ms, duration_ms, ended=False, shutdown=False):
        """R301: Back/Stop during the ending credits of an episode -> ask once
        whether to mark it as watched (Netflix-style long credits).

        Normal flows are unchanged: reaching the end / starting the next
        episode already marks watched, and stopping mid-episode keeps the resume
        bar.  Only a user stop between the credits start and the "near end"
        threshold asks.  No answer (auto-close) keeps the current state.
        """
        snap = self._watched_ask_snap_r301
        self._watched_ask_snap_r301 = None
        try:
            if ended or shutdown or not snap or str(snap.get("rk") or "") != str(rating_key or ""):
                return False
            if snap.get("to_next"):
                # Went on to the next episode: this one is finished.  No prompt;
                # the normal mark_watched path scrobbles it to Plex and clears
                # the local resume bar.
                _pkm_log_v2584("[%s] PLAYSTATE_WATCHED_ON_NEXT_R301 rating_key=%s pos=%s duration=%s" % (
                    ADDON_ID, rating_key, pos_ms, duration_ms), xbmc.LOGINFO)
                return True
            if ADDON.getSetting("pkm_ask_watched_on_back") == "false":
                return False
            pos = int(pos_ms or 0)
            dur = int(duration_ms or 0) or int(snap.get("duration_ms") or 0)
            if dur <= 0 or pos < 30000 or self._is_near_end(pos, dur):
                return False
            threshold = int(dur * 0.85)
            trig = int(snap.get("trigger_ms") if snap.get("trigger_ms") is not None else -1)
            if trig > 0:
                threshold = min(threshold, trig)
            if pos < threshold:
                return False
            if self._shutting_down or _service_stopping(self.monitor):
                return False
            heading = "시청 완료"
            message = "엔딩 구간에서 재생을 종료했습니다.[CR]이 회차를 다 본 것으로 표시할까요?"
            dlg = xbmcgui.Dialog()
            try:
                yes = dlg.yesno(heading, message, nolabel="아니요", yeslabel="다 봤어요",
                                autoclose=15000, defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
            except TypeError:
                yes = dlg.yesno(heading, message, nolabel="아니요", yeslabel="다 봤어요", autoclose=15000)
            _pkm_log_v2584("[%s] PLAYSTATE_ASK_WATCHED_R301 rating_key=%s pos=%s duration=%s threshold=%s answer=%s" % (
                ADDON_ID, rating_key, pos, dur, threshold, "yes" if yes else "no"), xbmc.LOGINFO)
            return bool(yes)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] PLAYSTATE_ASK_WATCHED_FAILED_R301 rating_key=%s error=%s" % (ADDON_ID, rating_key, exc), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _stop_tracking(self, state="stopped", ended=False, shutdown=False):
        with self._lock:
            if not self._active and not self.rating_key:
                self._clear_pending_properties()
                return
            pos_ms, duration_ms = self._player_times_ms()
            rating_key = self.rating_key
            self._active = False
        try:
            if not ended and not shutdown and int(pos_ms or 0) <= 0 and int(duration_ms or 0) <= 0 and self._pending_nowplaying_age_ms() <= 15000:
                _pkm_log_v2584("[%s] PLAYSTATE_TRACK_STOP_IGNORED reason=zero_duration_opening rating_key=%s age_ms=%s" % (ADDON_ID, rating_key, self._pending_nowplaying_age_ms()), xbmc.LOGINFO)
                with self._lock:
                    self._active = False
                return
        except Exception:
            pass
        mark_watched = bool(ended or self._is_near_end(pos_ms, duration_ms))
        if not mark_watched:
            mark_watched = self._ask_mark_watched_on_back_r301(rating_key, pos_ms, duration_ms, ended=ended, shutdown=shutdown)
        else:
            self._watched_ask_snap_r301 = None
        try:
            pct = (float(pos_ms) / float(duration_ms) * 100.0) if duration_ms else 0.0
        except Exception:
            pct = 0.0
        _pkm_log_v2584("[%s] PLAYSTATE_TRACK_STOP state=%s rating_key=%s pos=%s duration=%s pct=%.2f mark_watched=%s" % (ADDON_ID, state, rating_key, pos_ms, duration_ms, pct, "1" if mark_watched else "0"), xbmc.LOGINFO)
        if not shutdown:
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.PlayStateUpdatePending", "1")
                win.setProperty("PlexKM.PlayStatePendingRatingKey", str(rating_key or ""))
                win.setProperty("PlexKM.PlayStatePendingStartedAt", str(int(time.time() * 1000)))
            except Exception:
                pass
            # v2575: commit the local resume state synchronously before Kodi restores
            # the PKM Info/Home surface.  Previously the write happened inside the
            # async Plex timeline worker, so the UI could reopen ~1s earlier and
            # reuse a stale "최근 추가됨" card with no progress bar.  This local
            # write is tiny and network-free; the existing async worker still pushes
            # Plex and performs authoritative read-back afterwards.
            try:
                local_ready_v2575 = False
                if mark_watched:
                    try:
                        self.core.clear_local_resume_state(rating_key, reason="watched_pre_ui_v2575")
                    except Exception:
                        pass
                    local_ready_v2575 = True
                elif int(pos_ms or 0) > 0 and int(duration_ms or 0) > 0 and not self._is_near_end(pos_ms, duration_ms):
                    pct_v2575 = (float(pos_ms) / float(duration_ms) * 100.0) if duration_ms else 0.0
                    # Match Continue Watching eligibility: at least 30s (R31), below 90%.
                    if int(pos_ms or 0) >= 30000 and 0.0 < pct_v2575 < 90.0:
                        local_ready_v2575 = bool(self.core.record_local_resume_state(
                            rating_key, time_ms=pos_ms, duration_ms=duration_ms, reason="partial_stop_pre_ui_v2575"
                        ))
                if local_ready_v2575:
                    try:
                        win = xbmcgui.Window(10000)
                        now_v2575 = str(int(time.time() * 1000))
                        win.setProperty("PlexKM.Playback.LocalResumeReadyV2575", "1")
                        win.setProperty("PlexKM.Playback.LocalResumeRatingKeyV2575", str(rating_key or ""))
                        win.setProperty("PlexKM.Playback.LocalResumeReadyAtV2575", now_v2575)
                        # R33: durable stamp (never cleared) so every Continue
                        # consumer can tell its membership predates this stop.
                        win.setProperty("PlexKM.Playback.PlayStateStampMsR33", now_v2575)
                        win.setProperty("PlexKM.PlayStateDirty", "1")
                        win.setProperty("PlexKM.PlayStateDirtyRatingKey", str(rating_key or ""))
                        win.setProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632", "1")
                        win.setProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632", str(rating_key or ""))
                        win.setProperty("PlexKM.Playback.PostStopHomeRefreshTokenV1632", "playstate:%s:%s" % (rating_key, now_v2575))
                    except Exception:
                        pass
                    _pkm_log_v2584("[%s] PLAYSTATE_LOCAL_PRE_UI_COMMIT_V2575 rating_key=%s pos=%s duration=%s watched=%s network=0 ui_ready=1" % (
                        ADDON_ID, rating_key, pos_ms, duration_ms, "1" if mark_watched else "0"
                    ), xbmc.LOGINFO)
            except Exception as exc:
                _pkm_log_v2584("[%s] PLAYSTATE_LOCAL_PRE_UI_COMMIT_FAILED_V2575 rating_key=%s error=%s" % (ADDON_ID, rating_key, exc), xbmc.LOGWARNING)
        self._async_push(state, pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=(not shutdown), mark_watched=mark_watched, shutdown=shutdown)
        self._clear_pending_properties()
        self.rating_key = ""

    def shutdown_fast(self):
        # v531: Kodi gives service.py only a small shutdown window. Do not start
        # new Plex timeline/scrobble/read-back requests here. Clear local state and
        # let run() return immediately.
        try:
            self._shutting_down = True
            with self._lock:
                self._active = False
                self.rating_key = ""
            self._clear_pending_properties()
            try:
                if self._network_health_v2126:
                    self._network_health_v2126.stop(reason="shutdown_fast")
            except Exception:
                pass
            _pkm_log_v2584("[%s] PLAYSTATE_SHUTDOWN_FAST_CLEAR" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass

    def tick(self):
        if self.monitor.abortRequested() or self._shutting_down or _service_stopping(self.monitor):
            return
        try:
            playing = self.isPlayingVideo()
        except Exception:
            playing = False
        if playing and not self._active:
            if self._resolver_pre_avstarted_v1547():
                try:
                    win = self._window()
                    if win.getProperty("PlexKM.Playback.ResolverTickHoldLoggedV1547") != "1":
                        win.setProperty("PlexKM.Playback.ResolverTickHoldLoggedV1547", "1")
                        _pkm_log_v2584("[%s] PLAYBACK_RESOLVER_TICK_TRACKING_HELD_V1547 action=wait_for_onAVStarted cached_position_untouched=1" % ADDON_ID, xbmc.LOGINFO)
                except Exception:
                    pass
                return
            self._start_tracking(reason="tick_detected")
            return
        if not playing and self._active:
            self._stop_tracking(state="stopped")
            return
        if not playing or not self._active:
            return

        try:
            self._apply_pending_default_subtitle(reason="tick")
        except Exception:
            pass
        # v2222: prompt timing runs at the service loop cadence (250ms);
        # Plex timeline pushes below remain on their established 10s throttle.
        try:
            if self._episode_flow_v2222:
                self._episode_flow_v2222.tick(self)
        except Exception as exc:
            _pkm_log_v2584("[%s] EPISODE_FLOW_TICK_FAILED_V2222 err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)

        now_ms = int(time.time() * 1000)
        # R51: keep the cached position fresh (every 500ms).  onPlayBackStopped
        # can no longer query getTime(), so _stop_tracking() used the last 10s
        # timeline push (e.g. 29.2s for a ~38s play) and the 30s Continue rule
        # rejected it.  getTime() is a cheap local call; no network here.
        if now_ms - int(getattr(self, "_last_sample_ms_r51", 0) or 0) >= 500:
            self._last_sample_ms_r51 = now_ms
            try:
                self._player_times_ms()
            except Exception:
                pass
        try:
            if self._network_health_v2126:
                self._network_health_v2126.tick(self)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] NETWORK_HEALTH_TICK_FAILED_V2126 err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
            except Exception:
                pass
        if now_ms - self._last_push_ms < 10000:
            return
        self._last_push_ms = now_ms
        pos_ms, duration_ms = self._player_times_ms()
        self._async_push("playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)

    def _cancel_auto_preread_v1449(self, reason=""):
        try:
            if pkm_seek_quick and hasattr(pkm_seek_quick, "cancel_manual_preread"):
                pkm_seek_quick.cancel_manual_preread(reason=reason)
            _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_CANCEL_V1452 reason=%s" % (ADDON_ID, reason), xbmc.LOGINFO)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_CANCEL_FAILED_V1452 reason=%s err=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    def _return_fade_suppresses_preread_v1499(self, reason=""):
        """Return True while Back/return fade is stopping playback.

        v1499: the fade routine intentionally pauses the video for a frozen
        frame.  That synthetic Pause must not start the normal pause pre-read
        workers; otherwise repeated seeks + Back can leave Range readers racing
        against PlayerControl(Stop).
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Playback.ReturnFade.Stopping") == "1":
                return True
            if win.getProperty("PlexKM.Playback.ReturnFade.SuppressPreread") == "1":
                return True
            if win.getProperty("PlexKM.Playback.BackStopRequested") == "1":
                return True
        except Exception:
            pass
        return False

    def _start_auto_preread_v1449(self, reason="", force_restart=False):
        if self._shutting_down or _service_stopping(self.monitor):
            return
        if not pkm_seek_quick:
            return
        if self._resume_seek_pending_unverified_v1551():
            try:
                self._cancel_auto_preread_v1449(reason="resume_unverified_v1551_%s" % (reason or "playback"))
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_BLOCKED_RESUME_UNVERIFIED_V1551 reason=%s expected=%s action=no_http_range_competition" % (ADDON_ID, reason or "", self._read_pending_expected_resume_ms()), xbmc.LOGINFO)
            except Exception:
                pass
            return
        if self._return_fade_suppresses_preread_v1499(reason=reason):
            try:
                self._cancel_auto_preread_v1449(reason="ReturnFadeStoppedSuppressStartV1499_%s" % (reason or ""))
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1499 reason=%s state=return_fade_stopping" % (ADDON_ID, reason), xbmc.LOGINFO)
            except Exception:
                pass
            return
        try:
            if not self.isPlayingVideo():
                return
        except Exception:
            return
        # v1635: auxiliary HTTP Range reading is pause-only.  During active
        # playback Kodi/VideoPlayer is the sole owner of the media connection.
        # This is a lifecycle invariant, not a timer or bitrate workaround:
        # no onAVStarted/resume/playing seek path may compete with Kodi for the
        # same Plex/rclone file.
        try:
            paused_policy_v1635 = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            paused_policy_v1635 = False
        if not paused_policy_v1635:
            try:
                self._cancel_auto_preread_v1449(reason="v1635_pause_only_%s" % (reason or "playing"))
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=%s state=playing policy=pause_only_single_http_reader" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
            except Exception:
                pass
            return
        try:
            now_ms = int(time.time() * 1000)
            # Avoid duplicate bursts while the same position is settling, except seek/pause restarts.
            if (not force_restart) and now_ms - int(self._pause_preread_started_ms or 0) < 900:
                return
            self._pause_preread_started_ms = now_ms
        except Exception:
            pass
        try:
            # v1452: the visual response must be immediate. Show a visible
            # pale-yellow lead before Plex/rclone returns the first Range byte.
            if force_restart:
                try:
                    pkm_seek_quick.cancel_manual_preread(reason="force_restart_%s" % (reason or ""))
                except Exception:
                    pass
            if hasattr(pkm_seek_quick, "prime_preread_visible_marker"):
                pkm_seek_quick.prime_preread_visible_marker(reason="auto_%s" % (reason or "playback"), extra_nib=1)
        except Exception:
            pass

        def _worker():
            try:
                # Give Kodi a short moment to settle Player.Paused and the current time after pause/seek.
                if self.monitor.waitForAbort(0.06):
                    return
                if _service_stopping(self.monitor) or self._shutting_down:
                    return
                if self._return_fade_suppresses_preread_v1499(reason=reason):
                    try:
                        self._cancel_auto_preread_v1449(reason="ReturnFadeStoppedSuppressWorkerV1499_%s" % (reason or ""))
                    except Exception:
                        pass
                    try:
                        _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_WORKER_SKIP_V1499 reason=%s state=return_fade_stopping" % (ADDON_ID, reason), xbmc.LOGINFO)
                    except Exception:
                        pass
                    return
                try:
                    if not self.isPlayingVideo():
                        _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1452 reason=%s state=not_playing" % (ADDON_ID, reason), xbmc.LOGINFO)
                        return
                except Exception:
                    return
                try:
                    paused_now = bool(xbmc.getCondVisibility("Player.Paused"))
                except Exception:
                    paused_now = False
                if not paused_now:
                    try:
                        self._cancel_auto_preread_v1449(reason="v1635_worker_resume_%s" % (reason or "playing"))
                    except Exception:
                        pass
                    _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_WORKER_SKIP_V1635 reason=%s state=playing policy=pause_only_single_http_reader" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
                    return
                workers = 3
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_START_V1635 reason=%s mode=pause_only_linear_to_eof paused=1 force_restart=%s workers=%s single_http_reader_during_playback=1" % (ADDON_ID, reason, "1" if force_restart else "0", workers), xbmc.LOGINFO)
                pkm_seek_quick.manual_preread({
                    "source": "continuous_preread_%s" % (reason or "playback"),
                    "pause": "0",
                    "resume": "0",
                    "auto_resume": "0",
                    "ahead": "0",
                    "to_end": "1",
                    "force_restart": "1" if force_restart else "0",
                    "workers": str(workers),
                })
            except Exception as exc:
                try:
                    _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_FAILED_V1452 reason=%s err=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
                except Exception:
                    pass

        try:
            t = _PKMServiceThreadV2151(target=_worker, name="PlexKMAutoLinearPreReadV1452", daemon=True)
            t.daemon = True
            self._pause_preread_thread = t
            t.start()
        except Exception:
            pass

    def _reset_preread_cache_for_new_playback_v1484(self, reason=""):
        try:
            if pkm_seek_quick and hasattr(pkm_seek_quick, "reset_preread_cache_for_new_playback"):
                pkm_seek_quick.reset_preread_cache_for_new_playback(reason=reason)
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_NEW_PLAYBACK_RESET_V1484 reason=%s" % (ADDON_ID, reason), xbmc.LOGINFO)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_NEW_PLAYBACK_RESET_FAILED_V1484 reason=%s err=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    def _start_videoosd_cold_preload_v1947(self):
        """Load VideoOSD behind the existing black playback cover once per Kodi run.

        The animated opening spinner is cleared immediately at AV start.  Only the
        plain black cover remains while Kodi creates the heavy KEEP_IN_MEMORY OSD,
        so the first user ENTER does not instantiate it over moving video.
        """
        try:
            win = self._window()
            if self._videoosd_preloaded_v1947 or win.getProperty("PlexKM.PlayerOSD.PreloadedV1947") == "1":
                self._videoosd_preloaded_v1947 = True
                self._clear_native_opening_spinner_v1415(reason="onAVStarted_osd_already_preloaded_v1947", force=True)
                return
            if self._videoosd_preload_running_v1947:
                return
            self._videoosd_preload_running_v1947 = True
            # R140: 미리 열기 동안 스피너(흰색=곧 재생)는 그대로 둠 (검정 덮개만 남기면 멈춘 것처럼 보임)
            _pkm_log_v2584("[%s] PKM_VIDEOOSD_COLD_PRELOAD_BEGIN_V1947 spinner=0 black_cover=1 visible_ui=0" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            self._clear_native_opening_spinner_v1415(reason="onAVStarted_osd_preload_arm_failed_v1947", force=True)
            return

        def _worker():
            started = int(time.time() * 1000)
            opened = False
            try:
                w = self._window()
                w.setProperty("PlexKM.PlayerOSD.PreloadHidden", "1")
                w.setProperty("PlexKM.PlayerOSD.NoAutoClose", "1")
                w.setProperty("PlexKM.PlayerOSD.AutoCloseCancelled", "1")
                w.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
                w.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
                xbmc.executebuiltin("Action(OSD)")
                deadline = time.time() + 1.20
                while time.time() < deadline and not self.monitor.abortRequested():
                    if w.getProperty("PlexKM.PlayerOSD.Visible") == "1":
                        opened = True
                        break
                    xbmc.sleep(10)
                if opened:
                    # One render cycle is enough to finish control allocation.
                    xbmc.sleep(35)
                    xbmc.executebuiltin("Dialog.Close(VideoOSD,true)")
                    close_deadline = time.time() + 0.35
                    while time.time() < close_deadline and not self.monitor.abortRequested():
                        if w.getProperty("PlexKM.PlayerOSD.Visible") != "1":
                            break
                        xbmc.sleep(10)
                    w.setProperty("PlexKM.PlayerOSD.PreloadedV1947", "1")
                    self._videoosd_preloaded_v1947 = True
                elapsed = int(time.time() * 1000) - started
                _pkm_log_v2584("[%s] PKM_VIDEOOSD_COLD_PRELOAD_DONE_V1947 opened=%d elapsed_ms=%d playback_action=none" % (ADDON_ID, 1 if opened else 0, elapsed), xbmc.LOGINFO)
            except Exception as exc:
                try:
                    _pkm_log_v2584("[%s] PKM_VIDEOOSD_COLD_PRELOAD_FAILED_V1947 err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
                except Exception:
                    pass
            finally:
                try:
                    w = self._window()
                    w.clearProperty("PlexKM.PlayerOSD.PreloadHidden")
                    w.clearProperty("PlexKM.PlayerOSD.NoAutoClose")
                    w.clearProperty("PlexKM.PlayerOSD.ChildDialogActive")
                    w.clearProperty("PlexKM.PlayerOSD.AutoCloseCancelled")
                    w.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
                    w.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
                except Exception:
                    pass
                self._videoosd_preload_running_v1947 = False
                self._clear_native_opening_spinner_v1415(reason="onAVStarted_osd_preload_complete_v1947", force=True)

        try:
            t = _PKMServiceThreadV2151(target=_worker, name="PKMVideoOSDColdPreloadV1947", daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            self._videoosd_preload_running_v1947 = False
            self._clear_native_opening_spinner_v1415(reason="onAVStarted_osd_preload_thread_failed_v1947", force=True)

    def _apply_pending_media_audio_stream_v2114(self, reason=""):
        """Apply the audio track chosen by the media-version row after Kodi opens AV.

        Playback start remains the locked native PlayMedia(plugin://) ->
        setResolvedUrl path.  This only changes Kodi's already-open audio stream.
        """
        try:
            raw = str(self._window().getProperty("PlexKM.NowPlaying.AudioStreamIndex") or "").strip()
            if raw == "":
                return False
            target = int(raw)
            if target < 0:
                return False
        except Exception:
            return False

        def _worker():
            for attempt in range(10):
                try:
                    if self.monitor.waitForAbort(0.12 if attempt else 0.04):
                        return
                    if not self.isPlayingVideo():
                        continue
                    streams = list(self.getAvailableAudioStreams() or [])
                    if target >= len(streams):
                        continue
                    current = int(self.getAudioStream())
                    if current != target:
                        self.setAudioStream(target)
                    _pkm_log_v2584("[%s] MEDIA_VERSION_AUDIO_STREAM_APPLY_V2114 target=%s current_before=%s available=%s attempt=%s reason=%s" % (
                        ADDON_ID, target, current, len(streams), attempt + 1, reason or ""
                    ), xbmc.LOGINFO)
                    return
                except Exception:
                    continue
            try:
                _pkm_log_v2584("[%s] MEDIA_VERSION_AUDIO_STREAM_APPLY_FAILED_V2114 target=%s reason=%s" % (ADDON_ID, target, reason or ""), xbmc.LOGWARNING)
            except Exception:
                pass
        try:
            _PKMServiceThreadV2151(target=_worker, name="PKMMediaAudioV2114", daemon=True).start()
            return True
        except Exception:
            return False

    def onAVStarted(self):
        try:
            from resources.lib import pkm_rate_dialog as _pkm_rate_r175
            _pkm_rate_r175.prefetch()
        except Exception:
            pass

        audit_event(None, "playback_onAVStarted")
        try:
            win = xbmcgui.Window(10000)
            _resolver_token = win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
            if _resolver_token:
                win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "avstarted")
                win.setProperty("PlexKM.Playback.ResolverAVStartedAtMsV1547", str(int(time.time() * 1000)))
                _pkm_log_v2584("[%s] PLAYBACK_REAL_SESSION_BEGIN_V1547 event=onAVStarted token=%s cached_position_untouched=1" % (ADDON_ID, _resolver_token), xbmc.LOGINFO)
            # v2224: AVStarted is authoritative success. Cancel every pre-AV
            # failure/home recovery candidate before clearing the opening cover.
            win.clearProperty("PlexKM.Playback.OpenFailureCandidateV2224")
            win.clearProperty("PlexKM.Playback.OpenFailureCandidateAtMsV2224")
            win.clearProperty("PlexKM.Playback.FailureHomeRequestV2224")
            win.clearProperty("PlexKM.Playback.FailureHomeRequestSourceV2224")
            win.clearProperty("PlexKM.Playback.DefinitiveFailureV2229")
            win.clearProperty("PlexKM.Playback.NextHandoffV2227")
            win.clearProperty("PlexKM.Playback.NextHandoffRatingKeyV2227")
            win.clearProperty("PlexKM.Playback.OpeningActive")
            win.clearProperty("PlexKM.Playback.OpeningRatingKey")
            for _key_v2118 in (
                "PlexKM.Playback.PriorityV2118",
                "PlexKM.Playback.PriorityRatingKeyV2118",
                "PlexKM.Playback.PriorityArmedAtMsV2118",
            ):
                win.clearProperty(_key_v2118)
            _pkm_log_v2584("[%s] PLAYBACK_PRIORITY_CLEAR_V2118 reason=onAVStarted" % ADDON_ID, xbmc.LOGINFO)
            _pkm_log_v2584("[%s] PLAYBACK_OPENING_ACTIVE_CLEAR_V1450 reason=onAVStarted" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass
        try:
            from resources.lib import pkm_playback_wait_notice
            pkm_playback_wait_notice.start_buffering_watch()
        except Exception:
            pass
        self._apply_pending_media_audio_stream_v2114(reason="onAVStarted")
        self._start_videoosd_cold_preload_v1947()
        self._start_tracking(reason="onAVStarted")
        try:
            if self._episode_flow_v2222:
                self._episode_flow_v2222.on_av_started(self.rating_key or self._read_pending_rating_key())
        except Exception as exc:
            _pkm_log_v2584("[%s] EPISODE_FLOW_AVSTART_FAILED_V2222 err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        try:
            if self._network_health_v2126:
                self._network_health_v2126.start(self, reason="onAVStarted")
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] NETWORK_HEALTH_START_FAILED_V2126 err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
            except Exception:
                pass
        self._reset_preread_cache_for_new_playback_v1484(reason="onAVStarted")
        self._cancel_auto_preread_v1449(reason="onAVStarted_v1635_playback_owns_network")
        try:
            _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=onAVStarted state=playing policy=pause_only_single_http_reader" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass
        try:
            from resources.lib import pkm_video_select
            pkm_video_select.apply_saved_video_defaults(reason="onAVStarted", delayed=True)
        except Exception:
            try:
                _pkm_log_v2584("[%s] video_default_apply_failed\n%s" % (ADDON_ID, traceback.format_exc()), xbmc.LOGWARNING)
            except Exception:
                pass

    def onPlayBackStarted(self):

        audit_event(None, "playback_onPlayBackStarted")
        # v1547: PlayMedia(plugin://...) first creates a short resolver player.
        # Do not create the real Plex tracking session from that placeholder.
        # The movie session is owned exclusively by onAVStarted.
        if self._resolver_pre_avstarted_v1547():
            try:
                win = self._window()
                # v2224: a fresh resolver start invalidates any stale failure
                # candidate left by a previous attempt. A real pre-AV Stop below
                # will arm it again only for this exact opening token.
                win.clearProperty("PlexKM.Playback.OpenFailureCandidateV2224")
                win.clearProperty("PlexKM.Playback.OpenFailureCandidateAtMsV2224")
                win.clearProperty("PlexKM.Playback.FailureHomeRequestV2224")
                win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "resolver_started")
                _pkm_log_v2584("[%s] PLAYBACK_RESOLVER_PLACEHOLDER_START_BLOCKED_V1547 action=no_tracking_no_preread wait_for=onAVStarted token=%s" % (ADDON_ID, win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""), xbmc.LOGINFO)
            except Exception:
                pass
            return
        # v1420: non-resolver/direct playback keeps the legacy behavior.
        try:
            _pkm_log_v2584("[%s] PLAYBACK_NATIVE_OPENING_SPINNER_KEEP_PENDING_V1420 reason=onPlayBackStarted" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass
        self._start_tracking(reason="onPlayBackStarted")
        self._reset_preread_cache_for_new_playback_v1484(reason="onPlayBackStarted")
        self._cancel_auto_preread_v1449(reason="onPlayBackStarted_v1635_playback_owns_network")
        try:
            _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=onPlayBackStarted state=playing policy=pause_only_single_http_reader" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass

    def _cancel_videoosd_autoclose_play_toggle_v1946(self, state):
        """A real Play/Pause selection is OSD interaction, so keep the OSD open."""
        try:
            win = self._window()
            if win.getProperty("PlexKM.PlayerOSD.Visible") != "1":
                return
            win.setProperty("PlexKM.PlayerOSD.AutoCloseCancelled", "1")
            win.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
            win.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
            _pkm_log_v2584("[%s] PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1946 reason=native_playpause state=%s focus=602" % (ADDON_ID, state), xbmc.LOGINFO)
        except Exception:
            pass

    def onPlayBackPaused(self):

        audit_event(None, "playback_onPlayBackPaused")
        if self._shutting_down or _service_stopping(self.monitor):
            return
        # v2230: seekbar final commit temporarily pauses Kodi's playback clock
        # so a slow rclone random range cannot accumulate A/V drift. This is
        # not a user Pause and must NOT start the legacy 3-worker pause pre-read
        # or cancel the seekbar's normal OSD idle-close policy.
        try:
            if self._window().getProperty("PlexKM.SeekQuick.SeekManagedPauseV2230") == "1":
                self._cancel_auto_preread_v1449(reason="managed_seek_pause_v2230")
                _pkm_log_v2584("[%s] PKM_SEEK_MANAGED_PAUSE_CALLBACK_SKIP_V2230 preread=0 osd_user_pause=0" % ADDON_ID, xbmc.LOGINFO)
                return
        except Exception:
            pass
        self._cancel_videoosd_autoclose_play_toggle_v1946("paused")
        if self._resume_seek_pending_unverified_v1551():
            try:
                self._cancel_auto_preread_v1449(reason="resume_unverified_pause_v1551")
                _pkm_log_v2584("[%s] PLAYSTATE_PAUSE_TIMELINE_HELD_V1551 reason=native_resume_position_not_verified expected=%s" % (ADDON_ID, self._read_pending_expected_resume_ms()), xbmc.LOGINFO)
            except Exception:
                pass
            return
        if self._return_fade_suppresses_preread_v1499(reason="onPlayBackPaused"):
            try:
                self._cancel_auto_preread_v1449(reason="ReturnFadeStoppedOnPlayBackPausedV1499")
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_PAUSE_SKIP_V1499 reason=return_fade_stop" % ADDON_ID, xbmc.LOGINFO)
            except Exception:
                pass
            return
        pos_ms, duration_ms = self._player_times_ms()
        self._async_push("paused", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)
        try:
            from resources.lib import pkm_rate_dialog as _pkm_rate_r175
            _pkm_rate_r175.schedule_open()
        except Exception:
            pass
        # v1452: Pause restarts from the exact paused
        # position with pause workers=3 and prime the OSD immediately so the pale-yellow
        # cache lead appears without waiting for the first HTTP Range byte.
        self._start_auto_preread_v1449(reason="onPlayBackPaused", force_restart=True)

    def onPlayBackResumed(self):
        try:
            from resources.lib import pkm_rate_dialog as _pkm_rate_r175
            _pkm_rate_r175.cancel()
        except Exception:
            pass

        audit_event(None, "playback_onPlayBackResumed")
        if self._shutting_down or _service_stopping(self.monitor):
            return
        # v2230: synthetic resume after a managed seek is not user OSD input.
        # Keep exclusive media-network ownership with Kodi and leave the
        # seek-wait transaction alive until its clock-rate check says READY.
        try:
            _w_v2230 = self._window()
            if (
                _w_v2230.getProperty("PlexKM.SeekQuick.SeekManagedPauseV2230") == "1" and
                _w_v2230.getProperty("PlexKM.SeekQuick.SeekManagedResumeIssuedV2230") == "1"
            ):
                self._cancel_auto_preread_v1449(reason="managed_seek_resume_v2230")
                pos_ms, duration_ms = self._player_times_ms()
                self._async_push("playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)
                _pkm_log_v2584("[%s] PKM_SEEK_MANAGED_RESUME_CALLBACK_V2230 preread=0 osd_user_resume=0" % ADDON_ID, xbmc.LOGINFO)
                return
        except Exception:
            pass
        # v2227: PlayMedia(next episode) can emit a transient Resumed callback
        # from the outgoing episode after the new resolver has been armed. Do
        # not let that stale clock/timeline participate in the new session.
        if self._resolver_pre_avstarted_v1547():
            try:
                _pkm_log_v2584("[%s] PLAYBACK_NEXT_REPLACEMENT_RESUME_BLOCKED_V2227 token=%s action=wait_for_onAVStarted" % (
                    ADDON_ID, self._window().getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
                ), xbmc.LOGINFO)
            except Exception:
                pass
            return
        self._cancel_videoosd_autoclose_play_toggle_v1946("playing")
        if self._resume_seek_pending_unverified_v1551():
            try:
                self._cancel_auto_preread_v1449(reason="resume_unverified_resume_v1551")
                _pkm_log_v2584("[%s] PLAYSTATE_RESUME_TIMELINE_HELD_V1551 reason=native_resume_position_not_verified expected=%s" % (ADDON_ID, self._read_pending_expected_resume_ms()), xbmc.LOGINFO)
            except Exception:
                pass
            return
        if self._return_fade_suppresses_preread_v1499(reason="onPlayBackResumed"):
            try:
                self._cancel_auto_preread_v1449(reason="ReturnFadeStoppedOnPlayBackResumedV1499")
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_RESUME_SKIP_V1499 reason=return_fade_stop" % ADDON_ID, xbmc.LOGINFO)
            except Exception:
                pass
            return
        # v1635: resuming hands exclusive media-network ownership back to Kodi.
        self._cancel_auto_preread_v1449(reason="onPlayBackResumed_v1635_playback_owns_network")
        try:
            _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=onPlayBackResumed state=playing policy=pause_only_single_http_reader" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass
        pos_ms, duration_ms = self._player_times_ms()
        self._async_push("playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)

    def onPlayBackSeek(self, time_value, seek_offset):

        audit_event(None, "playback_onPlayBackSeek", time_value=time_value, seek_offset=seek_offset)
        if self._shutting_down or _service_stopping(self.monitor):
            return
        # R165: intro-learn candidate (condition checks only; the card opens from tick).
        # Before the managed-seek return below: scrub/speed-seek commits count too.
        try:
            if self._episode_flow_v2222:
                self._episode_flow_v2222.on_user_seek_r165(time_value, seek_offset)
        except Exception:
            pass
        # v2230 managed seek owns the one playback HTTP reader. Do not launch
        # pause pre-read workers from this synthetic seek callback.
        try:
            if self._window().getProperty("PlexKM.SeekQuick.SeekManagedPauseV2230") == "1":
                self._cancel_auto_preread_v1449(reason="managed_seek_callback_v2230")
                pos_ms, duration_ms = self._player_times_ms()
                if self._active:
                    self._async_push("paused" if xbmc.getCondVisibility("Player.Paused") else "playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)
                _pkm_log_v2584("[%s] PKM_SEEK_MANAGED_SEEK_CALLBACK_V2230 preread=0 pos=%s duration=%s" % (ADDON_ID, pos_ms, duration_ms), xbmc.LOGINFO)
                return
        except Exception:
            pass
        if self._return_fade_suppresses_preread_v1499(reason="onPlayBackSeek"):
            try:
                self._cancel_auto_preread_v1449(reason="ReturnFadeStoppedOnPlayBackSeekV1499")
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SEEK_SKIP_V1499 reason=return_fade_stop" % ADDON_ID, xbmc.LOGINFO)
            except Exception:
                pass
            return
        pos_ms, duration_ms = self._player_times_ms()
        if self._resume_seek_pending_unverified_v1551():
            try:
                self._cancel_auto_preread_v1449(reason="resume_seek_callback_unverified_v1551")
                _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SEEK_CALLBACK_BLOCKED_V1551 pos=%s duration=%s expected=%s action=wait_for_actual_position" % (ADDON_ID, pos_ms, duration_ms, self._read_pending_expected_resume_ms()), xbmc.LOGINFO)
            except Exception:
                pass
        else:
            try:
                self._cancel_auto_preread_v1449(reason="onPlayBackSeek_restart")
                if xbmc.getCondVisibility("Player.Paused"):
                    self._start_auto_preread_v1449(reason="onPlayBackSeekPaused", force_restart=True)
                else:
                    _pkm_log_v2584("[%s] PKM_AUTO_PREREAD_SKIP_V1635 reason=onPlayBackSeek state=playing policy=pause_only_single_http_reader" % ADDON_ID, xbmc.LOGINFO)
            except Exception:
                pass
        if not self._active:
            try:
                _pkm_log_v2584("[%s] PLAYSTATE_SEEK_TIMELINE_HELD_V1548 reason=tracking_not_verified pos=%s duration=%s expected=%s" % (ADDON_ID, pos_ms, duration_ms, self._read_pending_expected_resume_ms()), xbmc.LOGINFO)
            except Exception:
                pass
            return
        self._async_push("playing", pos_ms=pos_ms, duration_ms=duration_ms, refresh_after=False)

    def _mark_post_playback_ui_session_v1635(self, reason=""):
        """Switch Home sidebar transitions to stale-while-compose after real playback.

        A completed playback return must never be reclassified as a cold visual
        start.  Keep the current scene visible and atomically publish the target
        section when ready; no section spinner is permitted for the remainder of
        this Kodi process.  Window(10000) naturally resets on a real Kodi restart.
        """
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.Home.PostPlaybackSectionNoSpinnerV1635", "1")
            win.setProperty("PlexKM.Home.PostPlaybackSectionNoSpinnerAtV1635", str(int(time.time() * 1000)))
            for prop in (
                "PlexKM.Section.FirstVisitGateV1620",
                "PlexKM.Section.FirstVisitGateKeyV1620",
                "PlexKM.Section.FirstVisitGateTokenV1620",
            ):
                win.clearProperty(prop)
            _pkm_log_v2584("[%s] POST_PLAYBACK_SECTION_POLICY_V1635 reason=%s mode=keep_previous_scene_atomic_commit spinner=0 session_lifetime=1" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
        except Exception:
            pass

    def onPlayBackStopped(self):
        try:
            from resources.lib import pkm_rate_dialog as _pkm_rate_r175
            _pkm_rate_r175.cancel()
        except Exception:
            pass

        audit_event(None, "playback_onPlayBackStopped")
        # v1547: the plugin resolver emits its own pre-AV stop callback.  Block
        # that callback at the lifecycle boundary so it never reaches the real
        # session tracker, never clears NowPlaying, and never cancels opening.
        if self._resolver_pre_avstarted_v1547():
            try:
                win = self._window()
                now_ms_v2224 = int(time.time() * 1000)
                win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "handoff_stop_blocked")
                win.setProperty("PlexKM.Playback.ResolverHandoffStopAtMsV1547", str(now_ms_v2224))
                # v2224: this Stop happened before AVStarted. Do not immediately
                # tear down the resolver because some platforms can still finish
                # a slow handoff. Mark it as a failure candidate instead. The
                # PKM Home opening timer owns the finite 15 s recovery boundary.
                win.setProperty("PlexKM.Playback.OpenFailureCandidateV2224", "1")
                win.setProperty("PlexKM.Playback.OpenFailureCandidateAtMsV2224", str(now_ms_v2224))
                token_v2229 = win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
                # v2229: a resolver pre-AV Stop is not a failure verdict.  With
                # rclone-backed Plex it can be followed by a long InputStream /
                # demux open and eventually a valid AVStarted.  Never start a
                # fixed countdown here.  Keep it only as a candidate so Back
                # can cancel and a later authoritative terminal callback can
                # distinguish a real failed opening.
                _pkm_log_v2584("[%s] PLAYBACK_RESOLVER_BOUNDARY_STOP_BLOCKED_V2229 action=mark_candidate_no_timeout wait_for=AVStarted_or_definitive_player_end_or_user_back token=%s" % (
                    ADDON_ID, token_v2229
                ), xbmc.LOGINFO)
            except Exception:
                pass
            return
        try:
            _w_v2118 = xbmcgui.Window(10000)
            _w_v2118.clearProperty("PlexKM.Playback.OpeningActive")
            _w_v2118.clearProperty("PlexKM.Playback.OpeningRatingKey")
            for _key_v2118 in (
                "PlexKM.Playback.PriorityV2118",
                "PlexKM.Playback.PriorityRatingKeyV2118",
                "PlexKM.Playback.PriorityArmedAtMsV2118",
            ):
                _w_v2118.clearProperty(_key_v2118)
        except Exception:
            pass
        try:
            if self._network_health_v2126:
                self._network_health_v2126.stop(reason="onPlayBackStopped")
        except Exception:
            pass
        self._cancel_auto_preread_v1449(reason="onPlayBackStopped")
        try:
            # R301: remember the episode/credits context before reset() clears it.
            self._watched_ask_snap_r301 = (
                self._episode_flow_v2222.back_exit_snapshot_r301() if self._episode_flow_v2222 else None
            )
        except Exception:
            self._watched_ask_snap_r301 = None
        try:
            if self._episode_flow_v2222:
                self._episode_flow_v2222.reset(reason="onPlayBackStopped")
        except Exception:
            pass
        self._mark_post_playback_ui_session_v1635(reason="onPlayBackStopped")
        self._clear_native_opening_spinner_v1415(reason="onPlayBackStopped")
        if self._shutting_down or _service_stopping(self.monitor):
            self.shutdown_fast()
        else:
            self._stop_tracking(state="stopped")
        self._clear_resolver_phase_v1547(reason="real_onPlayBackStopped")

    def onPlayBackEnded(self):
        try:
            from resources.lib import pkm_rate_dialog as _pkm_rate_r175
            _pkm_rate_r175.cancel()
        except Exception:
            pass

        audit_event(None, "playback_onPlayBackEnded")
        # v2229: only an authoritative terminal callback can convert a slow
        # pre-AV opening into failure.  Elapsed time and the resolver's
        # placeholder Stop are never sufficient because rclone-backed Plex may
        # legitimately take tens of seconds to open a remote file.
        try:
            _w_v2229 = xbmcgui.Window(10000)
            _token_v2229 = _w_v2229.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
            _phase_v2229 = _w_v2229.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
            _candidate_v2229 = _w_v2229.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
            _avstarted_v2229 = bool(_w_v2229.getProperty("PlexKM.Playback.ResolverAVStartedAtMsV1547")) or _phase_v2229 == "avstarted"
            _opening_v2229 = (
                _w_v2229.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                or _w_v2229.getProperty("PlexKM.Playback.OpeningActive") == "1"
            )
            try:
                _video_v2229 = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
            except Exception:
                _video_v2229 = False
            if _token_v2229 and _candidate_v2229 and not _avstarted_v2229 and _opening_v2229 and not _video_v2229:
                _w_v2229.setProperty("PlexKM.Playback.DefinitiveFailureV2229", "1")
                _w_v2229.setProperty("PlexKM.Playback.ResolverPhaseV1547", "definitive_failed")
                _pkm_log_v2584("[%s] PLAYBACK_PREAV_DEFINITIVE_FAILURE_V2229 event=onPlayBackEnded token=%s action=pkm_failure_dialog timeout_policy=none" % (ADDON_ID, _token_v2229), xbmc.LOGINFO)
                # Keep opening/spinner state until the user closes the PKM-styled
                # dialog; its existing recovery route atomically returns Home.
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.km/?action=playback_failure_dialog_v2228&source=definitive_player_end_v2229)")
                return
        except Exception:
            pass
        try:
            _w_v2118 = xbmcgui.Window(10000)
            _w_v2118.clearProperty("PlexKM.Playback.OpeningActive")
            _w_v2118.clearProperty("PlexKM.Playback.OpeningRatingKey")
            for _key_v2118 in (
                "PlexKM.Playback.PriorityV2118",
                "PlexKM.Playback.PriorityRatingKeyV2118",
                "PlexKM.Playback.PriorityArmedAtMsV2118",
            ):
                _w_v2118.clearProperty(_key_v2118)
        except Exception:
            pass
        try:
            if self._network_health_v2126:
                self._network_health_v2126.stop(reason="onPlayBackEnded")
        except Exception:
            pass
        self._cancel_auto_preread_v1449(reason="onPlayBackEnded")
        try:
            if self._episode_flow_v2222:
                self._episode_flow_v2222.reset(reason="onPlayBackEnded")
        except Exception:
            pass
        self._mark_post_playback_ui_session_v1635(reason="onPlayBackEnded")
        self._clear_native_opening_spinner_v1415(reason="onPlayBackEnded")
        if self._shutting_down or _service_stopping(self.monitor):
            self.shutdown_fast()
        else:
            self._stop_tracking(state="stopped", ended=True)
        self._clear_resolver_phase_v1547(reason="onPlayBackEnded")



def _startup_boot_frame_path_v2388(value):
    """Return the full-screen PlexKM startup frame for a 0..100 progress value."""
    try:
        pct = max(0.0, min(100.0, float(value)))
    except Exception:
        pct = 0.0
    frame = int(round((pct / 100.0) * 239.0))
    frame = max(0, min(239, frame))
    return "special://home/addons/skin.plex.km/media/startup/plexkm_loading_v3_pfirst_frames/frame_%03d.png" % frame


def _publish_startup_boot_progress_v2388(value, reason=""):
    """Publish pre-Home startup progress to both Startup.xml and later Home WindowXML.

    This path never rewinds progress.  Builtin SetProperty is intentionally used
    in addition to Window.setProperty so Kodi invalidates skin info labels/images
    on the GUI thread even when the publisher is a service worker.
    """
    try:
        win = xbmcgui.Window(10000)
        try:
            current = float(win.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0")
        except Exception:
            current = 0.0
        if win.getProperty('PlexKM.Startup.LinearLogoToken') and reason != 'linear_logo_4sec':
            return current
        value = max(current, max(0.0, min(100.0, float(value))))
        text = ("%.2f" % value).rstrip("0").rstrip(".")
        why = str(reason or "")
        frame_path = _startup_boot_frame_path_v2388(value)
        if reason != 'linear_logo_4sec':
            win.setProperty("PlexKM.Startup.ProgressV1845", str(int(value)))
            win.setProperty("PlexKM.Startup.ProgressReasonV1845", why)
            win.setProperty("PlexKM.Startup.DisplayReasonV1891", why)
        win.setProperty("PlexKM.Startup.DisplayProgressV1891", text)
        win.setProperty("PlexKM.Startup.BootFramePathV2388", frame_path)
        # R82: the animation runs at most one GUI builtin per changed frame.
        # Window(10000) properties above are already published synchronously;
        # repeated home-window builtins for nonvisual metadata congest the GUI queue.
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.BootFramePathV2388,%s,home)" % frame_path)
        return value
    except Exception as exc:
        try:
            _pkm_log_v2584("[%s] STARTUP_BOOT_PROGRESS_PUBLISH_FAILED_V2388 error=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        except Exception:
            pass
        return 0.0


def _start_startup_boot_activity_fill_v2388(monitor):
    """SHIELD: four-second linear logo animation, independent of sync milestones."""
    try:
        win = xbmcgui.Window(10000)
        token = 'linear-%d' % int(time.time() * 1000)
        started = time.monotonic()
        win.setProperty('PlexKM.Startup.LinearLogoToken', token)
        win.clearProperty('PlexKM.Startup.LinearLogoCompleteR80')
        win.setProperty('PlexKM.Startup.LinearLogoStart', str(started))
        win.setProperty('PlexKM.Startup.BootFramePathV2388', _startup_boot_frame_path_v2388(0.0))
        win.setProperty('PlexKM.Startup.DisplayFrameV1904', '0')
        win.clearProperty('PlexKM.Startup.BootFillStopV2388')
        def _fill():
            last = -1
            cur = xbmcgui.Window(10000)
            while not monitor.abortRequested() and not _service_stopping(monitor):
                if cur.getProperty('PlexKM.Startup.LinearLogoToken') != token:
                    return
                # R80: Home may clear the splash flag while the clock is running.
                # Only token replacement or service shutdown may cancel this clock.
                elapsed = max(0.0, time.monotonic() - started)
                pct = min(100.0, elapsed * 25.0)
                frame = min(239, int(pct * 239.0 / 100.0))
                if frame != last:
                    last = frame
                    # R119: publish the SAME frame used by all three splash XMLs.
                    # Previously the R113 service advanced only diagnostic progress,
                    # leaving BootFramePathV2388 unchanged and the logo frozen.
                    frame_path = _startup_boot_frame_path_v2388(frame * 100.0 / 239.0)
                    # R121: native multiimage owns frames; avoid texture invalidation at 60Hz.
                    cur.setProperty('PlexKM.Startup.DisplayFrameV1904', str(frame))
                    if frame == 0 or frame == 239 or frame % 60 == 0:
                        cur.setProperty('PlexKM.Startup.DisplayProgressV1891',
                                        str(int(round(frame * 100.0 / 239.0))))
                if pct >= 100.0:
                    # Publish final frame BEFORE publishing completion. The
                    # consumer additionally holds the cover for render latency.
                    cur.setProperty('PlexKM.Startup.BootFramePathV2388',
                                    _startup_boot_frame_path_v2388(100.0))
                    cur.setProperty('PlexKM.Startup.DisplayFrameV1904', '239')
                    cur.setProperty('PlexKM.Startup.DisplayProgressV1891', '100')
                    cur.setProperty('PlexKM.Startup.LinearLogoCompleteR80', '1')
                    _pkm_log_v2584('[%s] R119_STARTUP_LOGO_FINAL_PUBLISHED elapsed_ms=%d frame=239' % (ADDON_ID, int(elapsed*1000)), xbmc.LOGINFO)
                    return
                # R82: 240 source images over 4 s = 60 distinct frames/s.
                # Wake on the next frame boundary instead of free-running at
                # 40 Hz and sending redundant Kodi GUI property commands.
                next_boundary = started + (min(239, frame + 1) / 239.0) * 4.0
                delay = max(0.004, min(0.018, next_boundary - time.monotonic()))
                if monitor.waitForAbort(delay):
                    return
        threading.Thread(target=_fill, name='PKMShieldLinearLogo', daemon=True).start()
        _pkm_log_v2584('[%s] STARTUP_LINEAR_LOGO_ARM duration_ms=4000 mode=linear native_skin_frames=240 gui_builtins_per_frame=0' % ADDON_ID, xbmc.LOGINFO)
        return True
    except Exception as exc:
        _pkm_log_v2584('[%s] STARTUP_LINEAR_LOGO_FAILED error=%s' % (ADDON_ID, exc), xbmc.LOGWARNING)
        return False

def _stop_startup_boot_activity_fill_v2388(reason=""):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Startup.BootFillStopV2388", "1")
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.BootFillStopV2388,1,home)")
        _pkm_log_v2584("[%s] STARTUP_BOOT_FILL_STOP_V2388 reason=%s" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
    except Exception:
        pass


def _clear_startup_slow_notice_v2365(reason=""):
    """Clear the delayed startup status text without touching any other notice UI."""
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Startup.SlowGuardTokenV2365",
            "PlexKM.Startup.SlowVisibleV2365",
            "PlexKM.Startup.SlowTextV2365",
            "PlexKM.Startup.SlowPhaseV2365",
            "PlexKM.Startup.SlowArmAtMsV2493",
        ):
            win.clearProperty(key)
            xbmc.executebuiltin("ClearProperty(%s,home)" % key)
        _pkm_log_v2584("[%s] STARTUP_SLOW_NOTICE_CLEAR_V2365 reason=%s" % (ADDON_ID, reason or ""), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _resolve_startup_status_v2375(fallback_text="", fallback_phase=""):
    """V2535 startup text whitelist: PKM update, real new content, or problem only."""
    try:
        win = xbmcgui.Window(10000)
        update_text = str(win.getProperty("PlexKM.Startup.UpdateTextV2375") or "").strip()
        update_phase = str(win.getProperty("PlexKM.Startup.UpdatePhaseV2375") or "").strip()
        if update_text:
            return update_text, "update_" + (update_phase or "active")

        problem_active = win.getProperty("PlexKM.Startup.ProblemActiveV2535") == "1"
        if problem_active:
            problem_text = str(win.getProperty("PlexKM.Startup.ProblemTextV2535") or "시작 준비가 예상보다 오래 걸리고 있습니다").strip()
            return problem_text, "problem_v2535"

        if win.getProperty("PlexKM.Startup.NewContentAddedV2535") == "1":
            return "새 콘텐츠를 반영 중입니다", "new_content_v2535"
    except Exception:
        pass
    # No generic fallback, ratings message, poster message, selection/cache text,
    # or authority-check text is user-visible under V2535.
    return "", ""


def _wait_startup_update_gate_v2375(monitor, max_wait_sec=180.0):
    """Keep Plex authority/Home composition behind the update decision.

    The updater itself is non-blocking and runs on the service loop.  Home's
    autostart worker waits here only while the updater explicitly owns the startup
    gate.  Failure is bounded and fail-open so a broken network can never strand
    the user permanently behind the PKM logo.
    """
    started = time.time()
    announced = False
    while not monitor.abortRequested() and not _service_stopping(monitor):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Startup.UpdateBlockV2375") != "1":
                if announced:
                    _pkm_log_v2584("[%s] STARTUP_UPDATE_GATE_RELEASE_V2375 waited_ms=%d" % (
                        ADDON_ID, int((time.time() - started) * 1000.0)
                    ), xbmc.LOGINFO)
                return True
            if not announced:
                announced = True
                _pkm_log_v2584("[%s] STARTUP_UPDATE_GATE_WAIT_V2375 phase=%s home_authority_blocked=1" % (
                    ADDON_ID, win.getProperty("PlexKM.Startup.UpdatePhaseV2375") or "unknown"
                ), xbmc.LOGINFO)
        except Exception:
            return True
        if (time.time() - started) >= float(max_wait_sec):
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty("PlexKM.Startup.UpdateBlockV2375")
                win.clearProperty("PlexKM.Startup.UpdatePhaseV2375")
                win.clearProperty("PlexKM.Startup.UpdateTextV2375")
            except Exception:
                pass
            _pkm_log_v2584("[%s] STARTUP_UPDATE_GATE_TIMEOUT_V2375 waited_sec=%d action=fail_open_home" % (
                ADDON_ID, int(time.time() - started)
            ), xbmc.LOGWARNING)
            return True
        if monitor.waitForAbort(0.05):
            return False
    return False


def _update_startup_slow_notice_v2365(text, phase=""):
    """Update an already-visible delayed startup status; never reveal it early."""
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Startup.SlowVisibleV2365") != "1":
            return False
        resolved_text, resolved_phase = _resolve_startup_status_v2375(text, phase)
        resolved_text = str(resolved_text or "").strip()
        resolved_phase = str(resolved_phase or "").strip()
        if not resolved_text:
            return False
        win.setProperty("PlexKM.Startup.SlowTextV2365", resolved_text)
        win.setProperty("PlexKM.Startup.SlowPhaseV2365", resolved_phase)
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.SlowTextV2365,%s,home)" % resolved_text.replace(",", " "))
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.SlowPhaseV2365,%s,home)" % resolved_phase.replace(",", " "))
        _pkm_log_v2584("[%s] STARTUP_SLOW_NOTICE_UPDATE_V2375 phase=%s text=%s" % (
            ADDON_ID, resolved_phase or "startup", str(resolved_text or "")
        ), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _arm_startup_slow_notice_v2365(monitor, delay_sec=5.0):
    """R161: show the original PKM top-right notice only after a real slow start.

    Dedicated token prevents a late startup worker from erasing an independent
    Plex failure/update/exit alert. No GUI list, focus, or skin mutation here.
    """
    _clear_startup_slow_notice_v2365(reason="r161_topright_owner")
    win = xbmcgui.Window(10000)
    token = "r161-%d" % int(time.time() * 1000)
    win.setProperty("PlexKM.Startup.SlowGuardTokenV2365", token)

    def _watch():
        notice_token = ""
        last_message = None
        last_bucket = -1
        started = time.monotonic()
        try:
            from resources.lib import pkm_notify as notify
            while not monitor.waitForAbort(0.20):
                cur = xbmcgui.Window(10000)
                if cur.getProperty("PlexKM.Startup.SlowGuardTokenV2365") != token:
                    break
                # IMPORTANT: never notify during a successfully completed start.
                if cur.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    break
                if cur.getProperty("PlexKM.StartupSettingsIncomplete") == "1" or cur.getProperty("PlexKM.Home.SettingsRequired") == "1":
                    break
                if cur.getProperty("PlexKM.SkinStartupSplash") != "1":
                    break
                elapsed = time.monotonic() - started
                if elapsed < max(5.0, float(delay_sec or 5.0)):
                    continue
                bucket = int((elapsed - 5.0) // 5.0)
                if bucket == last_bucket:
                    continue
                last_bucket = bucket

                update = str(cur.getProperty("PlexKM.Startup.UpdateTextV2375") or "").strip()
                problem = str(cur.getProperty("PlexKM.Startup.ProblemTextV2535") or "").strip()
                offline = cur.getProperty("PlexKM.PlexOffline") == "1" or cur.getProperty("PlexKM.Startup.PlexProofRejectedR160") == "1"
                if cur.getProperty("PlexKM.Startup.PlexProofRejectedR160") == "1":
                    # R160 has already dispatched its own reason-specific exit dialog.
                    # It must own the screen; do not replace it with a generic notice.
                    break
                if problem and cur.getProperty("PlexKM.Startup.ProblemActiveV2535") == "1":
                    title, line1, line2 = "PlexKM 시작 상태", problem, "확인된 시작 문제를 처리하고 있습니다"
                elif offline:
                    title, line1, line2 = "Plex 서버 연결 확인", "설정된 Plex 서버의 응답을 확인 중입니다", "연결 결과를 다시 확인하고 있습니다"
                elif update:
                    title, line1, line2 = "PlexKM 업데이트 확인", update, "시작 필수 작업을 확인하고 있습니다"
                elif cur.getProperty("PlexKM.Startup.NewContentAddedV2535") == "1":
                    title, line1, line2 = "Plex 라이브러리 준비", "변경된 콘텐츠를 확인하고 있습니다", "라이브러리 정보를 준비 중입니다"
                else:
                    # R106: elapsed time alone is not shown as a notice (it surfaced
                    # right as Home was revealed).  Only problem/offline/update/new
                    # content get a notice.
                    continue
                    title, line1, line2 = "PlexKM 시작 상태", "시작 준비가 예상보다 오래 걸리고 있습니다", (
                        "현재 필수 시작 작업을 확인 중입니다" if bucket % 2 == 0
                        else "Plex 및 라이브러리 준비 상태를 확인 중입니다")

                active = str(cur.getProperty("PlexKM.Notify.Active") or "") == "1"
                active_token = str(cur.getProperty("PlexKM.Notify.Token") or "")
                active_title = str(cur.getProperty("PlexKM.Notify.Title") or "")
                # Never overwrite an alert another subsystem owns.
                if active and active_token != notice_token and not active_title.startswith("PlexKM 시작 상태"):
                    continue
                if (title, line1, line2) == last_message:
                    continue
                next_token = str(notify.pkm_notice_set(title, line1, line2,
                                     sticky=True, force_replace=True) or "")
                if next_token:
                    notice_token = next_token
                    last_message = (title, line1, line2)
                    _pkm_log_v2584("[%s] R161_STARTUP_NOTICE_SHOW bucket=%d title=%s" % (
                        ADDON_ID, bucket, title), xbmc.LOGINFO)
        except Exception as exc:
            _pkm_log_v2584("[%s] R161_STARTUP_NOTICE_ERROR type=%s" % (
                ADDON_ID, type(exc).__name__), xbmc.LOGWARNING)
        finally:
            if notice_token:
                try:
                    from resources.lib import pkm_notify as notify
                    notify.pkm_notice_clear(expected_token=notice_token, force=True)
                except Exception:
                    pass
    threading.Thread(target=_watch, name="PKMStartupNoticeR161", daemon=True).start()
    return True

def _r42_start_native_focus_owner(monitor):
    """Restore focus to native Home or recovery controls after window returns.

    Never touch PKM's modal UI, Settings, or an already focused control.
    The guard stays alive because Settings can be visited minutes later.
    """
    def _watch():
        last_target = None
        while not _service_stopping(monitor):
            if monitor.waitForAbort(0.5):
                return
            try:
                if xbmcgui.getCurrentWindowId() != 10000:
                    last_target = None
                    continue
                if _settings_dialog_active() or xbmc.getCondVisibility('System.HasActiveModalDialog'):
                    last_target = None
                    continue
                home = xbmcgui.Window(10000)
                recovery = (home.getProperty('PlexKM.Startup.RecoveryArmedR2') == '1'
                            and home.getProperty('PlexKM.Home.StartupReadyV1619') != '1'
                            and home.getProperty('PlexKM.FullResetInProgressV2150') != '1'
                            and not xbmc.Player().isPlayingVideo())
                if recovery:
                    # Kodi's condition engine checks actual focus without relying
                    # on unsupported xbmcgui module functions.
                    if any(xbmc.getCondVisibility('Control.HasFocus(%d)' % i)
                           for i in (16501, 16502, 16503)):
                        last_target = 'recovery'
                        continue
                    xbmc.executebuiltin('SetFocus(16501)')
                    if last_target != 'recovery':
                        _pkm_log_v2584('[%s] R42_RECOVERY_FOCUS target=16501' % ADDON_ID, xbmc.LOGINFO)
                    last_target = 'recovery'
                elif not _plex_config_ready():
                    # Do not steal focus from any already selected Kodi Home item.
                    if xbmc.getCondVisibility('Control.HasFocus(9000)'):
                        last_target = 'home'
                        continue
                    # Only repair a genuinely missing focus. getFocusId is
                    # queried on Window (not on the xbmcgui module).
                    try:
                        focus_id = int(home.getFocusId())
                    except (RuntimeError, TypeError, ValueError):
                        focus_id = -1
                    if focus_id > 0:
                        last_target = 'other'
                        continue
                    xbmc.executebuiltin('SetFocus(9000)')
                    if last_target != 'home':
                        _pkm_log_v2584('[%s] R42_HOME_FOCUS target=9000' % ADDON_ID, xbmc.LOGINFO)
                    last_target = 'home'
                else:
                    last_target = None
            except Exception as exc:
                # Throttle errors; never flood kodi.log every 500 ms.
                if last_target != 'error':
                    _pkm_log_v2584('[%s] R42_FOCUS_OWNER_ERROR %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
                last_target = 'error'
    threading.Thread(target=_watch, name='PKMR42NativeFocusOwner', daemon=True).start()


def _r69_prehome_authority_bg_finish(core, home, box):
    """R69: commit a pre-home authority gate that outlived the V2700 ceiling.

    Home was opened from the local DB; this worker finished later.  Apply its
    result exactly once (deferred R57 membership, refresh signal) and mark the
    gate done so deferred maintenance (V2582) does not run a second one.
    """
    try:
        if box.get("error") is not None:
            _pkm_log_v2584("[%s] R69_PREHOME_AUTHORITY_BG_FAILED error=%s" % (ADDON_ID, box.get("error")), xbmc.LOGWARNING)
            return
        result = dict(box.get("result") or {})
        ok = bool(result.get("ok") and not (result.get("errors") or []))
        if ok:
            home.setProperty("PlexKM.Startup.PrehomeAuthorityDoneR19", "1")
        deferred = [str(x) for x in list(result.get("deferred_r57") or []) if str(x or "")]
        if deferred:
            _start_r57_background_membership(core, home, deferred)
        try:
            pruned = int((result.get("pruned") or {}).get("total", 0) or 0)
        except Exception:
            pruned = 0
        changed = (int(result.get("dirty", 0) or 0) + int(result.get("incremental_syncs", 0) or 0)
                   + int(result.get("full_syncs", 0) or 0) + pruned)
        if changed > 0:
            try:
                getattr(core, "_signal_home_data_refresh")("r69_prehome_authority_bg")
            except Exception as exc:
                _pkm_log_v2584("[%s] R69_PREHOME_AUTHORITY_BG_REFRESH_FAILED error=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        _pkm_log_v2584("[%s] R69_PREHOME_AUTHORITY_BG_DONE ok=%d checked=%d dirty=%d incremental=%d full_syncs=%d pruned=%d deferred=%d refresh=%d" % (
            ADDON_ID, 1 if ok else 0, int(result.get("checked", 0) or 0), int(result.get("dirty", 0) or 0),
            int(result.get("incremental_syncs", 0) or 0), int(result.get("full_syncs", 0) or 0),
            pruned, len(deferred), 1 if changed > 0 else 0), xbmc.LOGINFO)
    except Exception as exc:
        _pkm_log_v2584("[%s] R69_PREHOME_AUTHORITY_BG_COMMIT_FAILED error=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
    finally:
        try:
            home.clearProperty("PlexKM.Startup.PrehomeAuthorityBgR69")
        except Exception:
            pass


def _autostart_home_window(monitor):
    """Open PlexKM Home automatically without exposing Kodi Home.

    v984: Startup.xml is visual-only. The service is the single owner of PKM
    Home autostart, so skin startup cannot accidentally run the root plugin path
    or show the interactive initial-sync progress dialog.
    """
    _r42_start_native_focus_owner(monitor)
    def _worker():
        try:
            try:
                _startup_home_v1643 = xbmcgui.Window(10000)
                _startup_home_v1643.setProperty("PlexKM.SkinStartupSplash", "1")
                _publish_startup_boot_progress_v2388(3, reason="service_start")
                _startup_home_v1643.setProperty("PlexKM.ServiceAutostartV984", "1")
                # R90: reset process-local window ownership flags before first launch.
                # Previous attempts may have died without executing their finally block.
                _startup_home_v1643.clearProperty("PlexKM.HomeWindowOpening")
                _startup_home_v1643.clearProperty("PlexKM.HomeWindowActive")
                _pkm_log_v2584("[%s] R90_STARTUP_OWNER_FLAGS_RESET reason=fresh_service_autostart" % ADDON_ID, xbmc.LOGWARNING)
                _startup_home_v1643.clearProperty("PlexKM.Home.StartupReadyV1619")
                _startup_home_v1643.clearProperty("PlexKM.Home.FullSceneComposedV1643")
                _startup_home_v1643.clearProperty("PlexKM.Home.StartupCurrentMenuCompleteV1643")
                _startup_home_v1643.clearProperty("PlexKM.Home.PostStartupBackgroundStartedV1643")
                _startup_home_v1643.clearProperty("PlexKM.Home.PostStartupBackgroundStartedV1645")
                _startup_home_v1643.clearProperty("PlexKM.Home.PostStartupBackgroundModeV1645")
                _startup_home_v1643.clearProperty("PlexKM.Cine21.PostRevealDoneV1645")
                _startup_home_v1643.clearProperty("PlexKM.Cine21.NextStartupApplyV1645")
                _startup_home_v1643.clearProperty("PlexKM.StartupSnapshotSyncDoneV1644")
                _startup_home_v1643.clearProperty("PlexKM.StartupSnapshotSyncSuccessV1644")
                _startup_home_v1643.clearProperty("PlexKM.StartupPlaystateSyncDoneV1644")
                _startup_home_v1643.clearProperty("PlexKM.Home.AllSidebarScenesReadyV1644")
                _startup_home_v1643.setProperty("PlexKM.RuntimeWidgetUpdatesDisabledV1644", "1")
                _pkm_log_v2584("[%s] STARTUP_SPLASH_ARM_V1647 source=user_4k pipeline=local_home_first network_post_reveal" % ADDON_ID, xbmc.LOGINFO)
                _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2349 superseded_by_v2407_post_reveal_authority" % ADDON_ID, xbmc.LOGINFO)
                _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2407 startup_home_first_defer_heavy_authority" % ADDON_ID, xbmc.LOGINFO)
                _pkm_log_v2584("[%s] STARTUP_PROGRESS_V1847 value=3 reason=service_start gui_invalidate=1" % ADDON_ID, xbmc.LOGINFO)
                _arm_startup_slow_notice_v2365(monitor, delay_sec=5.0)
                _start_startup_boot_activity_fill_v2388(monitor)
            except Exception:
                pass

            # v1841: the splash is already visible before this point, so do not
            # impose an unconditional 400 ms floor on a Home scene that may be
            # ready locally. Try immediately and use short, bounded retries only
            # when Kodi or the addon window is not ready yet.
            # v2053: one event-driven startup attempt. Do not compensate for
            # lifecycle ordering with a timed retry ladder.
            delays = (0.0, 1.0, 2.0)
            for attempt, delay_sec in enumerate(delays, start=1):
                # Kodi treats waitForAbort(0) as an unbounded wait on some
                # builds.  The first attempt is intentionally immediate, so do
                # not call waitForAbort at all for the zero-delay slot.
                if float(delay_sec) > 0 and monitor.waitForAbort(float(delay_sec)):
                    return
                if _service_stopping(monitor):
                    return
                _pkm_log_v2584("[%s] AUTOSTART_HOME_ATTEMPT_V1842 attempt=%d delay=%.2f" % (
                    ADDON_ID, attempt, float(delay_sec)
                ), xbmc.LOGINFO)

                config_ready = _plex_config_ready()
                try:
                    home = xbmcgui.Window(10000)
                    if config_ready:
                        home.clearProperty("PlexKM.Home.SettingsRequired")
                        home.clearProperty("PlexKM.StartupSettingsIncomplete")
                    else:
                        # R46: first installation is not a startup failure.
                        # Remove any stale recovery flag before handing off to Settings.
                        home.clearProperty("PlexKM.Startup.RecoveryArmedR2")
                        home.clearProperty("PlexKM.Startup.RecoveryReasonR2")
                        home.setProperty("PlexKM.Home.SettingsRequired", "1")
                        home.setProperty("PlexKM.StartupSettingsIncomplete", "1")
                        _pkm_log_v2584("[%s] FIRST_INSTALL_R46 state=SETTINGS_REQUIRED recovery=SUPPRESSED" % ADDON_ID, xbmc.LOGINFO)
                        _pkm_log_v2584("[%s] AUTOSTART_HOME_EMPTY reason=settings_incomplete_v1270 attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)
                except Exception:
                    pass

                # PKM_RECOVERY_R1: a temporary setup/update modal must not kill
                # the *only* autostart attempt. Await its closure without timeout;
                # the independent recovery watchdog handles genuine startup stalls.
                if _settings_dialog_active():
                    _pkm_log_v2584("[%s] STARTUP_MODAL_HANDOFF_WAIT_R1 attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)
                    settings_wait_r88 = time.monotonic()
                    while _settings_dialog_active() and not _service_stopping(monitor):
                        if time.monotonic() - settings_wait_r88 >= 8.0:
                            _pkm_log_v2584("[%s] R88_SETTINGS_HANDOFF_TIMEOUT attempt=%d elapsed_ms=%d action=continue_home_attempt" % (
                                ADDON_ID, attempt, int((time.monotonic()-settings_wait_r88)*1000)), xbmc.LOGWARNING)
                            break
                        if monitor.waitForAbort(0.20):
                            return
                    if _service_stopping(monitor):
                        return
                    _pkm_log_v2584("[%s] STARTUP_MODAL_HANDOFF_RESUME_R1 attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)

                # R89: independent startup visibility watchdog. The owner can be
                # blocked inside Kodi's native doModal(), so retries on that
                # same thread cannot guarantee a visible surface.
                if attempt == 0:
                    def _r89_surface_watch():
                        if monitor.waitForAbort(35.0):
                            return
                        try:
                            w = xbmcgui.Window(10000)
                            ready = w.getProperty("PlexKM.Home.StartupReadyV1619") == "1"
                            win_id = xbmcgui.getCurrentWindowId()
                            dialog_id = xbmcgui.getCurrentWindowDialogId()
                            modal = bool(xbmc.getCondVisibility("System.HasModalDialog"))
                            _pkm_log_v2584("[%s] R89_SURFACE_WATCH ready=%d window=%s dialog=%s modal=%d" % (
                                ADDON_ID, int(ready), win_id, dialog_id, int(modal)), xbmc.LOGWARNING)
                            if not ready and not modal:
                                w.clearProperty("PlexKM.SkinStartupSplash")
                                _pkm_log_v2584("[%s] R89_SPLASH_RELEASE reason=home_not_ready_35s action=native_home" % ADDON_ID, xbmc.LOGERROR)
                                xbmc.executebuiltin("ActivateWindow(Home)")
                            elif not ready:
                                _pkm_log_v2584("[%s] R89_SURFACE_WATCH_MODAL_BLOCKED dialog=%s action=preserve_modal" % (ADDON_ID, dialog_id), xbmc.LOGERROR)
                                _pkm_log_v2584("[%s] R90_HOME_NOT_REACHED cause=active_modal dialog=%s; Kodi_window_activation_cannot_be_forced" % (ADDON_ID, dialog_id), xbmc.LOGERROR)
                        except Exception as e:
                            _pkm_log_v2584("[%s] R89_SURFACE_WATCH_ERROR type=%s" % (ADDON_ID, type(e).__name__), xbmc.LOGERROR)
                    threading.Thread(target=_r89_surface_watch, name="PKMR89SurfaceWatch", daemon=True).start()

                # R48: A fresh installation MUST create the PKM WindowXML owner.
                # Its onInit owns the native SettingsRequired -> initial settings
                # handoff. R39 returned here before the owner was ever created,
                # leaving users at Kodi Home or the recovery overlay.
                if not _plex_config_ready():
                    _pkm_log_v2584("[%s] FIRST_INSTALL_R48 action=CONTINUE_TO_SETTINGS_OWNER reason=unconfigured" % ADDON_ID, xbmc.LOGINFO)

                try:
                    home = xbmcgui.Window(10000)
                    if home.getProperty("PlexKM.HomeWindowOpening") == "true" or home.getProperty("PlexKM.HomeWindowActive") == "true":
                        _pkm_log_v2584("[%s] AUTOSTART_HOME_SKIP reason=already_open attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)
                        return
                    home.setProperty("PlexKM.SkinStartupSplash", "1")
                except Exception:
                    pass

                try:
                    if xbmc.Player().isPlayingVideo():
                        _pkm_log_v2584("[%s] AUTOSTART_HOME_SKIP reason=player_active attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)
                        return
                except Exception:
                    pass

                try:
                    core = _load_core()
                    home = xbmcgui.Window(10000)

                    # PKM_PATCH_ACTIVE v2592 startup_update_check_during_logo_restore
                    # Restore the pre-V2584 behavior requested for distribution:
                    # every configured PKM run performs its update decision while
                    # the PKM startup logo is still covering the UI.  The service
                    # loop drives update_flow.tick() immediately whenever
                    # UpdateBlockV2375 owns the startup gate (V2590), so this wait
                    # does not deadlock.  Local Home preparation remains independent
                    # of Plex/library authority work; only the repository update
                    # decision is allowed to hold Home reveal.  Fail open after a
                    # bounded 12 seconds so Git/network trouble cannot strand boot.
                    try:
                        established_update_gate_v2592 = bool(
                            config_ready and getattr(core, "initial_sync_done", lambda: False)()
                        )
                    except Exception:
                        established_update_gate_v2592 = False
                    _pkm_log_v2584(
                        "[%s] STARTUP_UPDATE_DURING_LOGO_V2592 configured=%d established=%d gate=%s max_wait_ms=12000" % (
                            ADDON_ID,
                            1 if config_ready else 0,
                            1 if established_update_gate_v2592 else 0,
                            home.getProperty("PlexKM.Startup.UpdateBlockV2375") or "0",
                        ),
                        xbmc.LOGINFO,
                    )
                    # R84: import the Home window modules (11 MB of Python, ~4 s
                    # on the Shield) while the logo and the sync run, instead of
                    # after them.  Same interpreter, so open_window_home's import
                    # is then a dict lookup.  Pure import; nothing is shown.
                    try:
                        def _prewarm_home_import_r84():
                            t_r84 = time.time()
                            try:
                                # Same environment open_window_home() prepares.
                                lib_r84 = os.path.join(os.path.dirname(os.path.abspath(core.__file__)), "resources", "lib")
                                if lib_r84 not in sys.path:
                                    sys.path.insert(0, lib_r84)
                                sys.modules.setdefault("default", core)
                                import plexkm_home_window  # noqa: F401
                                _pkm_log_v2584("[%s] HOME_IMPORT_PREWARM_R84 ok=1 ms=%d" % (
                                    ADDON_ID, int((time.time() - t_r84) * 1000)), xbmc.LOGINFO)
                            except Exception as exc_r84:
                                _pkm_log_v2584("[%s] HOME_IMPORT_PREWARM_R84 ok=0 err=%s" % (
                                    ADDON_ID, exc_r84), xbmc.LOGWARNING)
                        threading.Thread(target=_prewarm_home_import_r84, name="PKMHomeImportR84", daemon=True).start()
                    except Exception:
                        pass
                    if not _wait_startup_update_gate_v2375(monitor, max_wait_sec=12.0):
                        return

                    # Library-add restart boundary (canonical policy):
                    # The selection transaction has already completed its authoritative sync
                    # before this marker is written.  The next process must therefore consume
                    # the committed marker and compose Home from the committed local DB; it must
                    # NOT run a second synchronous Plex/cache refresh before Home.
                    library_restart_committed = False
                    marker_path, marker_data = _library_add_restart_marker_read()
                    if config_ready and marker_data is not None:
                        library_restart_committed = True
                        _pkm_log_v2584("[%s] LIBRARY_ADD_RESTART_COMMIT_CONSUME sections=%s home_open=0 duplicate_sync=0" % (
                            ADDON_ID, ",".join(str(x) for x in (marker_data.get("sections") or []))
                        ), xbmc.LOGINFO)
                        # R58: preserve the committed marker until Home reports actual readiness.
                        # A refused doModal() must not consume the only restart boundary.
                        def _r58_clear_marker_after_ready(path=marker_path):
                            wait_start = time.monotonic()
                            while time.monotonic() - wait_start < 180.0 and not monitor.abortRequested():
                                try:
                                    if xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                                        _library_add_restart_marker_clear(path, reason="r58_home_ready_confirmed")
                                        return
                                except Exception:
                                    pass
                                if monitor.waitForAbort(0.25):
                                    return
                            _pkm_log_v2584("[%s] R58_MARKER_PRESERVED reason=home_not_ready" % ADDON_ID, xbmc.LOGWARNING)
                        threading.Thread(target=_r58_clear_marker_after_ready, name="PKMR58MarkerCommit", daemon=True).start()
                        try:
                            home.setProperty("PlexKM.LibraryAdd.RestartCommitted", "1")
                        except Exception:
                            pass

                    # v2349: keep the fast local startup architecture, but never
                    # publish a selected library whose cheap Plex delta probe already
                    # proves that the local DB membership is stale.  Only suspicious
                    # sections pay for a full ratingKey inventory before Home opens;
                    # the exhaustive v2348 audit still runs post-reveal for the rare
                    # equal-count/equal-latest drift case.
                    home.setProperty("PlexKM.StartupPlaystateSyncDoneV1644", "1")
                    home.setProperty("PlexKM.StartupSnapshotSyncDoneV1644", "1")
                    home.setProperty("PlexKM.StartupSnapshotSyncSuccessV1644", "1" if config_ready else "0")
                    activation_ready_v1989 = False
                    if config_ready:
                        try:
                            activation_ready_v1989 = bool(getattr(core, "initial_sync_done", lambda: False)())
                        except Exception:
                            activation_ready_v1989 = False

                    # v2570 UHD3 HOME QUIET PHASE 1:
                    # The UHD3 measurements showed that post-reveal Plex authority/sync work
                    # can starve Kodi input/render scheduling for seconds.  User policy is now
                    # explicit: a longer opaque startup is acceptable, but once Home is shown
                    # heavy Plex/SQLite maintenance must already be finished.
                    #
                    # Keep Plex authoritative by running the existing v2349 proof/audit and the
                    # existing startup cache refresh *before* Home opens.  ensure_startup_cache_ready
                    # reuses the v2349 proof map, so unchanged sections stay on the fast path and
                    # dirty sections are repaired under the startup cover instead of on live Home.
                    prehome_authority_v2349 = {}
                    prehome_quiet_sync_ok_v2570 = False

                    # PKM_PATCH_ACTIVE v2582 uhd3_startup_local_first_under5_v2584
                    # Established UHD3 starts are local-first.  Do not block the
                    # splash on Plex authority, membership reconciliation or
                    # /library/onDeck.  The last committed DB/snapshots/playstate
                    # are already sufficient to paint Home.  Heavy maintenance is
                    # deferred until Home is visible AND the remote has been idle.
                    # This is the deliberate trade requested for UHD3: reveal in
                    # <=5 s first, then refresh quietly only after a long true idle.
                    # V2657 UHD3 canonical light-start policy:
                    # Once Plex is configured, Home is always composed from the last
                    # committed local DB.  initial_sync_done is not a pre-Home gate:
                    # library selection already owns the explicit first import and a
                    # restart must never repeat authority/cache preparation.
                    startup_fast_local_v2582 = bool(config_ready)
                    if startup_fast_local_v2582:
                        prehome_quiet_sync_ok_v2570 = True
                        try:
                            home.setProperty("PlexKM.Startup.FastLocalFirstV2582", "1")
                            home.setProperty("PlexKM.Startup.PreHomeNetworkV2582", "0")
                        except Exception:
                            pass
                        _pkm_log_v2584("[%s] UHD3_STARTUP_LOCAL_FIRST_V2582 attempt=%d prehome_authority=0 prehome_playstate=0 prehome_membership=0 prehome_full_sync=0 target_home_ms=5000" % (ADDON_ID, attempt), xbmc.LOGINFO)

                        # R19: every Kodi start checks Plex before Home is composed.
                        # The check runs while the 4.5 s logo pass (R125) is playing,
                        # so an unchanged library costs no visible time: the gate is
                        # one /library/sections request plus local proof reuse.  Only
                        # sections whose Plex contentChangedAt moved are probed and
                        # repaired (incremental for pure additions).  Playstate
                        # (/library/onDeck) runs in parallel and is waited for only
                        # until the logo pass ends; it never extends startup.
                        try:
                            for prop_r19 in ("PlexKM.Startup.PrehomeAuthorityDoneR19",
                                             "PlexKM.Startup.PrehomePlaystateDoneR19"):
                                home.clearProperty(prop_r19)
                        except Exception:
                            pass
                        if _plex_offline_active() or _server_switch_pending_active_v1310():
                            _pkm_log_v2584("[%s] R19_PREHOME_SYNC_SKIP reason=offline_or_server_switch action=deferred_maintenance" % ADDON_ID, xbmc.LOGWARNING)
                        else:
                            try:
                                logo_clock_r19 = float(home.getProperty('PlexKM.Startup.LinearLogoStart') or '0')
                            except (ValueError, TypeError):
                                logo_clock_r19 = 0.0
                            logo_deadline_r19 = (logo_clock_r19 + 4.50) if logo_clock_r19 > 0 else (time.monotonic() + 3.0)
                            playstate_r19 = {"done": False, "ok": False, "error": "", "elapsed_ms": 0}
                            playstate_t0_r19 = time.time()
                            def _prehome_playstate_r19():
                                try:
                                    core.sync_play_state_from_plex_light(reason="prehome_parallel_r19")
                                    playstate_r19["ok"] = True
                                    try:
                                        home.setProperty("PlexKM.Startup.PrehomePlaystateDoneR19", "1")
                                    except Exception:
                                        pass
                                except Exception as exc_ps_r19:
                                    playstate_r19["error"] = str(exc_ps_r19)
                                finally:
                                    playstate_r19["elapsed_ms"] = int((time.time() - playstate_t0_r19) * 1000)
                                    playstate_r19["done"] = True
                            playstate_thread_r19 = None
                            # R22: one-time watched index.  While it is built the DB
                            # is write-locked, so the playstate pull starts after it.
                            need_index_r22 = False
                            try:
                                need_index_r22 = not bool(getattr(core, "watched_index_present_r22")())
                            except Exception as exc_idx_r22:
                                _pkm_log_v2584("[%s] R22_WATCHED_INDEX_PROBE_FAILED error=%s" % (ADDON_ID, exc_idx_r22), xbmc.LOGWARNING)
                            try:
                                playstate_thread_r19 = threading.Thread(target=_prehome_playstate_r19, name="pkm-prehome-playstate-r19", daemon=True)
                                if not need_index_r22:
                                    playstate_thread_r19.start()
                            except Exception as exc_pst_r19:
                                playstate_thread_r19 = None
                                _pkm_log_v2584("[%s] R19_PREHOME_PLAYSTATE_START_FAILED error=%s" % (ADDON_ID, exc_pst_r19), xbmc.LOGWARNING)
                            authority_t0_r19 = time.time()
                            try:
                                # R20: run the gate on a worker so this thread can show the
                                # top-right notice while a real library repair keeps Home
                                # waiting after the logo pass.  Unchanged libraries finish
                                # in ~0.2 s and never reach the notice threshold.
                                gate_box_r20 = {"result": None, "error": None, "done": False,
                                                # R69: if the V2700 ceiling hands the gate to the
                                                # background, the worker itself commits its result.
                                                "abandoned_r69": False, "lock_r69": threading.Lock()}
                                def _gate_worker_r20():
                                    try:
                                        if need_index_r22:
                                            try:
                                                home.setProperty("PlexKM.Startup.R22IndexBuilding", "1")
                                                getattr(core, "ensure_watched_index_r22")()
                                            except Exception as exc_mk_r22:
                                                _pkm_log_v2584("[%s] R22_WATCHED_INDEX_FAILED error=%s action=continue" % (ADDON_ID, exc_mk_r22), xbmc.LOGWARNING)
                                            finally:
                                                try:
                                                    home.clearProperty("PlexKM.Startup.R22IndexBuilding")
                                                except Exception:
                                                    pass
                                            try:
                                                if playstate_thread_r19 is not None:
                                                    playstate_thread_r19.start()
                                            except Exception:
                                                pass
                                        gate_box_r20["result"] = dict(getattr(core, "startup_prehome_authority_gate_v2349")() or {})
                                    except Exception as exc_gate_r20:
                                        gate_box_r20["error"] = exc_gate_r20
                                    finally:
                                        with gate_box_r20["lock_r69"]:
                                            gate_box_r20["done"] = True
                                            abandoned_r69 = bool(gate_box_r20.get("abandoned_r69"))
                                        if abandoned_r69:
                                            _r69_prehome_authority_bg_finish(core, home, gate_box_r20)
                                try:
                                    home.clearProperty("PlexKM.Startup.R20SyncSectionTitle")
                                except Exception:
                                    pass
                                gate_thread_r20 = threading.Thread(target=_gate_worker_r20, name="pkm-prehome-authority-r20", daemon=True)
                                gate_thread_r20.start()
                                notice_token_r20 = ""
                                notice_last_r20 = None
                                notice_shown_at_r20 = 0.0
                                notify_r20 = None
                                # V2700: the pre-home authority gate talks to Plex (per-section
                                # probes / syncs).  A slow or hung server must never keep Home
                                # closed for minutes.  For an established install, stop waiting
                                # after the ceiling and open Home from the local DB; the gate
                                # thread keeps running in the background and any later change is
                                # picked up by the normal refresh/next start.  First-time index
                                # builds / local seeding legitimately take long and are exempt.
                                try:
                                    established_r2700 = bool(getattr(core, "initial_sync_done", lambda: False)())
                                except Exception:
                                    established_r2700 = False
                                # R138: the 45 s ceiling used to be absolute, so a healthy
                                # multi-library update (n/N notice) was cut off at 2/7 and
                                # the notice vanished while the sync went on unseen.  The
                                # ceiling now measures time WITHOUT progress (section
                                # index / section title change); a hard cap still applies.
                                # R171: the logo must not sit there: established installs hand the
                                # gate over to the background after ~9 s (probe + short sync); the
                                # rest (sync, purge, Continue pull) finishes after Home is up.
                                PREHOME_CEILING_S_R2700 = 6.0
                                PREHOME_ABS_MAX_S_R138 = 9.0
                                progress_sig_r138 = None
                                progress_at_r138 = authority_t0_r19
                                extended_logged_r138 = False
                                while not gate_box_r20["done"] and not monitor.abortRequested():
                                    gate_thread_r20.join(0.20)
                                    if gate_box_r20["done"]:
                                        break
                                    try:
                                        sig_r138 = (
                                            str(home.getProperty("PlexKM.Startup.R57SyncIndex") or ""),
                                            str(home.getProperty("PlexKM.Startup.R20SyncSectionTitle") or ""),
                                        )
                                    except Exception:
                                        sig_r138 = progress_sig_r138
                                    if sig_r138 != progress_sig_r138:
                                        progress_sig_r138 = sig_r138
                                        progress_at_r138 = time.time()
                                    waited_all_r138 = time.time() - authority_t0_r19
                                    stalled_r138 = time.time() - progress_at_r138
                                    if (not extended_logged_r138 and waited_all_r138 >= 45.0
                                            and stalled_r138 < PREHOME_CEILING_S_R2700):
                                        extended_logged_r138 = True
                                        _pkm_log_v2584("[%s] R138_PREHOME_WAIT_EXTENDED waited_ms=%d stalled_ms=%d progress=%s/%s section=%s" % (
                                            ADDON_ID, int(waited_all_r138 * 1000), int(stalled_r138 * 1000),
                                            sig_r138[0] or "-", str(home.getProperty("PlexKM.Startup.R57SyncTotal") or "-"),
                                            sig_r138[1] or "-"), xbmc.LOGINFO)
                                    if (established_r2700
                                            and not need_index_r22
                                            and home.getProperty("PlexKM.Startup.R22IndexBuilding") != "1"
                                            and home.getProperty("PlexKM.Startup.R59LocalSeed") != "1"
                                            and (stalled_r138 >= PREHOME_CEILING_S_R2700
                                                 or waited_all_r138 >= PREHOME_ABS_MAX_S_R138
                                                 # R141: an established Home never makes the logo wait for Plex; at the end of the
                                                 # logo sweep (3.0 s) the gate is handed to the background so "powered by KM" and Home follow at once.
                                                 or (logo_clock_r19 > 0 and (time.monotonic() - logo_clock_r19) >= 3.0))):
                                        with gate_box_r20["lock_r69"]:
                                            handoff_r69 = not gate_box_r20["done"]
                                            if handoff_r69:
                                                try:
                                                    home.setProperty("PlexKM.Startup.PrehomeAuthorityBgR69", "1")
                                                except Exception:
                                                    pass
                                                gate_box_r20["abandoned_r69"] = True
                                        if not handoff_r69:
                                            # finished at the same moment: normal commit below
                                            break
                                        _pkm_log_v2584("[%s] R20_PREHOME_AUTHORITY_TIMEOUT_V2700 waited_ms=%d section=%s action=open_home_from_local_db sync_continues_in_background=1" % (
                                            ADDON_ID, int((time.time() - authority_t0_r19) * 1000),
                                            str(home.getProperty("PlexKM.Startup.R20SyncSectionTitle") or "-")), xbmc.LOGERROR)
                                        break
                                    since_logo_r20 = (time.monotonic() - logo_clock_r19) if logo_clock_r19 > 0 else (time.time() - authority_t0_r19 + 4.5)
                                    # R57: the logo fill takes 4s; anything after that
                                    # is real waiting and is explained on the left.
                                    # R106: notices that appeared just before Home was
                                    # revealed read as an error flash.  Real work waits
                                    # until 6.5 s; the generic server wait is never shown.
                                    if since_logo_r20 < 6.5:
                                        continue
                                    try:
                                        if notify_r20 is None:
                                            from resources.lib import pkm_notify as notify_r20
                                        section_r20 = str(home.getProperty("PlexKM.Startup.R20SyncSectionTitle") or "").strip()
                                        waited_r20 = int(time.time() - authority_t0_r19)
                                        try:
                                            idx_r57 = int(home.getProperty("PlexKM.Startup.R57SyncIndex") or "0")
                                            tot_r57 = int(home.getProperty("PlexKM.Startup.R57SyncTotal") or "0")
                                        except Exception:
                                            idx_r57, tot_r57 = 0, 0
                                        if home.getProperty("PlexKM.Startup.R22IndexBuilding") == "1":
                                            line1_r20 = "라이브러리 데이터를 최적화 중입니다"
                                            line2_r20 = "업데이트 후 최초 1회"
                                        elif home.getProperty("PlexKM.Startup.R59LocalSeed") == "1":
                                            line1_r20 = "라이브러리 데이터 확인 중"
                                            line2_r20 = "최초 1회"
                                        elif section_r20 and tot_r57 > 0:
                                            line1_r20 = "라이브러리 업데이트 확인 중 (%d/%d)" % (max(1, min(idx_r57, tot_r57)), tot_r57)
                                            line2_r20 = section_r20
                                        elif section_r20:
                                            line1_r20 = "새 콘텐츠를 반영 중입니다"
                                            line2_r20 = "%s 동기화 중" % section_r20
                                        else:
                                            # R106: a plain "server response" wait that ends
                                            # ~1 s later only flashed the notice (SHIELD 22:20:49
                                            # shown 810 ms).  Real work (section sync / index /
                                            # seed) still shows at 4.2 s; this one waits to 6.5 s.
                                            continue
                                            line1_r20 = "Plex 변경 사항을 확인 중입니다"
                                            line2_r20 = "서버 응답 대기"
                                        message_r20 = ("라이브러리 업데이트", line1_r20, line2_r20)
                                        if message_r20 != notice_last_r20:
                                            notice_token_r20 = str(notify_r20.pkm_notice_set(
                                                message_r20[0], message_r20[1], message_r20[2],
                                                token=notice_token_r20 or "", sticky=True, force_replace=True, busy=True) or notice_token_r20)
                                            if notice_last_r20 is None:
                                                notice_shown_at_r20 = time.monotonic()
                                                _pkm_log_v2584("[%s] R20_PREHOME_SYNC_NOTICE_SHOW since_logo_ms=%d section=%s" % (
                                                    ADDON_ID, int(since_logo_r20 * 1000), section_r20 or "-"), xbmc.LOGINFO)
                                            notice_last_r20 = message_r20
                                    except Exception as exc_notice_r20:
                                        _pkm_log_v2584("[%s] R20_PREHOME_SYNC_NOTICE_FAILED error=%s" % (ADDON_ID, exc_notice_r20), xbmc.LOGWARNING)
                                        notify_r20 = False
                                if notice_token_r20 and notify_r20:
                                    try:
                                        notify_r20.pkm_notice_clear(expected_token=notice_token_r20, force=True)
                                        _pkm_log_v2584("[%s] R20_PREHOME_SYNC_NOTICE_CLEAR shown_ms=%d" % (
                                            ADDON_ID, int((time.monotonic() - notice_shown_at_r20) * 1000)), xbmc.LOGINFO)
                                    except Exception:
                                        pass
                                try:
                                    home.clearProperty("PlexKM.Startup.R20SyncSectionTitle")
                                except Exception:
                                    pass
                                abandoned_main_r69 = bool(gate_box_r20.get("abandoned_r69"))
                                if gate_box_r20["error"] is not None and not abandoned_main_r69:
                                    raise gate_box_r20["error"]
                                # R69: an abandoned gate is committed by its own worker
                                # (_r69_prehome_authority_bg_finish), never twice here.
                                prehome_authority_v2349 = dict((None if abandoned_main_r69 else gate_box_r20["result"]) or {})
                                authority_ok_r19 = bool(prehome_authority_v2349.get("ok") and not (prehome_authority_v2349.get("errors") or []))
                                if authority_ok_r19:
                                    home.setProperty("PlexKM.Startup.PrehomeAuthorityDoneR19", "1")
                                deferred_sids_r57 = [str(x) for x in list(prehome_authority_v2349.get("deferred_r57") or []) if str(x or "")]
                                if deferred_sids_r57:
                                    _start_r57_background_membership(core, home, deferred_sids_r57)
                                _pkm_log_v2584("[%s] R19_PREHOME_AUTHORITY_DONE ok=%d checked=%d dirty=%d incremental=%d full_syncs=%d membership_scans=%d errors=%d elapsed_ms=%d" % (
                                    ADDON_ID, 1 if authority_ok_r19 else 0,
                                    int(prehome_authority_v2349.get("checked", 0) or 0),
                                    int(prehome_authority_v2349.get("dirty", 0) or 0),
                                    int(prehome_authority_v2349.get("incremental_syncs", 0) or 0),
                                    int(prehome_authority_v2349.get("full_syncs", 0) or 0),
                                    int(prehome_authority_v2349.get("membership_scans", 0) or 0),
                                    len(prehome_authority_v2349.get("errors") or []),
                                    int((time.time() - authority_t0_r19) * 1000),
                                ), xbmc.LOGINFO)
                            except Exception as exc_auth_r19:
                                _pkm_log_v2584("[%s] R19_PREHOME_AUTHORITY_FAILED error=%s action=deferred_maintenance" % (ADDON_ID, exc_auth_r19), xbmc.LOGWARNING)
                            # Dirty signals raised before Home exists are already in the
                            # DB the new WindowXML composes from (same rule as V2570).
                            for prop_r19 in ("PlexKM.Home.SyncRefreshPendingV1554",
                                             "PlexKM.Home.SyncRefreshPendingTokenV1554",
                                             "PlexKM.Home.SyncRefreshPendingReasonV1554",
                                             "PlexKM.PlexUpdate.Dirty"):
                                try:
                                    home.clearProperty(prop_r19)
                                except Exception:
                                    pass
                            if playstate_thread_r19 is not None and playstate_thread_r19.ident is not None:
                                while (playstate_thread_r19.is_alive() and time.monotonic() < logo_deadline_r19
                                       and not monitor.abortRequested()):
                                    playstate_thread_r19.join(0.04)
                            _pkm_log_v2584("[%s] R19_PREHOME_PLAYSTATE done=%d ok=%d elapsed_ms=%d waited_until_logo_end=1 error=%s" % (
                                ADDON_ID, 1 if playstate_r19.get("done") else 0, 1 if playstate_r19.get("ok") else 0,
                                int(playstate_r19.get("elapsed_ms", 0) or int((time.time() - playstate_t0_r19) * 1000)),
                                playstate_r19.get("error") or "-"), xbmc.LOGINFO)

                        # One daemon waits for a genuinely quiet Home.  Existing
                        # navigation timestamps come from WindowXML.onAction; every
                        # remote key pushes the deadline out again.  The worker is
                        # single-instance per service process and never owns splash.
                        try:
                            if home.getProperty("PlexKM.DeferredMaintenance.ArmedV2582") != "1":
                                home.setProperty("PlexKM.DeferredMaintenance.ArmedV2582", "1")
                                def _deferred_maintenance_v2582():
                                    try:
                                        monitor_v2582 = xbmc.Monitor()
                                        ready_at_v2582 = 0
                                        # Wait for actual atomic Home reveal first.
                                        while not monitor_v2582.abortRequested():
                                            if home.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                                                ready_at_v2582 = int(time.time() * 1000)
                                                break
                                            if monitor_v2582.waitForAbort(0.10):
                                                return
                                        if not ready_at_v2582:
                                            return
                                        # V2584 UHD3 under-5 / input-first policy: background
                                        # authority work is next-start preparation, not a live-Home
                                        # dependency.  Give the user a long clean interaction window:
                                        # >=120 s after reveal AND >=60 s with no user action.
                                        # Rapid wall mode postpones maintenance indefinitely.
                                        _pkm_log_v2584("[%s] UHD3_DEFERRED_MAINTENANCE_IDLE_BUDGET_V2584 reveal_ms=120000 idle_ms=60000 wall_rapid_cancel=1" % ADDON_ID, xbmc.LOGINFO)
                                        while not monitor_v2582.abortRequested():
                                            now_ms_v2582 = int(time.time() * 1000)
                                            try:
                                                last_input_v2582 = int(float(home.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or "0"))
                                            except Exception:
                                                last_input_v2582 = 0
                                            since_reveal_v2582 = now_ms_v2582 - ready_at_v2582
                                            idle_ms_v2582 = now_ms_v2582 - last_input_v2582 if last_input_v2582 > 0 else since_reveal_v2582
                                            wall_rapid_v2582 = home.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                                            try:
                                                playing_v2582 = bool(xbmc.Player().isPlayingVideo())
                                            except Exception:
                                                playing_v2582 = False
                                            if since_reveal_v2582 >= 120000 and idle_ms_v2582 >= 60000 and not wall_rapid_v2582 and not playing_v2582:
                                                break
                                            if monitor_v2582.waitForAbort(0.25):
                                                return
                                        home.setProperty("PlexKM.DeferredMaintenance.ActiveV2582", "1")
                                        _pkm_log_v2584("[%s] UHD3_DEFERRED_MAINTENANCE_BEGIN_V2582 home_visible=1 prehome_block=0 idle_ms=%d" % (ADDON_ID, idle_ms_v2582), xbmc.LOGINFO)
                                        authority_v2582 = {}
                                        try:
                                            # R69: never start a second authority gate while the
                                            # one handed off by the V2700 ceiling is still running.
                                            while home.getProperty("PlexKM.Startup.PrehomeAuthorityBgR69") == "1":
                                                if monitor_v2582.waitForAbort(1.0):
                                                    return
                                            if home.getProperty("PlexKM.Startup.PrehomeAuthorityDoneR19") == "1":
                                                raise _R19AlreadyDone()
                                            authority_v2582 = dict(getattr(core, "startup_prehome_authority_gate_v2349")(allow_defer_r57=False) or {})
                                            _pkm_log_v2584("[%s] UHD3_DEFERRED_AUTHORITY_DONE_V2582 ok=%d checked=%d dirty=%d incremental=%d full_syncs=%d membership_scans=%d errors=%d" % (
                                                ADDON_ID, 1 if authority_v2582.get("ok") else 0,
                                                int(authority_v2582.get("checked", 0) or 0),
                                                int(authority_v2582.get("dirty", 0) or 0),
                                                int(authority_v2582.get("incremental_syncs", 0) or 0),
                                                int(authority_v2582.get("full_syncs", 0) or 0),
                                                int(authority_v2582.get("membership_scans", 0) or 0),
                                                len(authority_v2582.get("errors") or []),
                                            ), xbmc.LOGINFO)
                                        except _R19AlreadyDone:
                                            _pkm_log_v2584("[%s] R19_DEFERRED_AUTHORITY_SKIP reason=prehome_authority_done" % ADDON_ID, xbmc.LOGINFO)
                                        except Exception as exc_v2582:
                                            _pkm_log_v2584("[%s] UHD3_DEFERRED_AUTHORITY_FAILED_V2582 error=%s action=keep_committed_local" % (ADDON_ID, exc_v2582), xbmc.LOGWARNING)
                                        # Re-check idle after authority before pulling
                                        # playstate. If the user resumed navigation,
                                        # leave playstate for the next idle/start.
                                        try:
                                            now2_v2582 = int(time.time() * 1000)
                                            last2_v2582 = int(float(home.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or "0"))
                                            idle2_v2582 = now2_v2582 - last2_v2582 if last2_v2582 > 0 else 999999
                                        except Exception:
                                            idle2_v2582 = 999999
                                        if home.getProperty("PlexKM.Startup.PrehomePlaystateDoneR19") == "1":
                                            _pkm_log_v2584("[%s] R19_DEFERRED_PLAYSTATE_SKIP reason=prehome_playstate_done" % ADDON_ID, xbmc.LOGINFO)
                                        elif idle2_v2582 >= 4000 and home.getProperty("PlexKM.WallRapidScrollV2581") != "1":
                                            try:
                                                core.sync_play_state_from_plex_light(reason="deferred_idle_v2582")
                                                _pkm_log_v2584("[%s] UHD3_DEFERRED_PLAYSTATE_DONE_V2582 idle_guard=1" % ADDON_ID, xbmc.LOGINFO)
                                            except Exception as exc_ps_v2582:
                                                _pkm_log_v2584("[%s] UHD3_DEFERRED_PLAYSTATE_FAILED_V2582 error=%s" % (ADDON_ID, exc_ps_v2582), xbmc.LOGWARNING)
                                        else:
                                            _pkm_log_v2584("[%s] UHD3_DEFERRED_PLAYSTATE_SKIP_V2582 reason=user_resumed idle_ms=%d" % (ADDON_ID, idle2_v2582), xbmc.LOGINFO)
                                    finally:
                                        try:
                                            home.clearProperty("PlexKM.DeferredMaintenance.ActiveV2582")
                                            home.setProperty("PlexKM.DeferredMaintenance.DoneV2582", "1")
                                        except Exception:
                                            pass
                                threading.Thread(target=_deferred_maintenance_v2582, name="pkm-deferred-maint-v2582", daemon=True).start()
                        except Exception as arm_exc_v2582:
                            _pkm_log_v2584("[%s] UHD3_DEFERRED_MAINTENANCE_ARM_FAILED_V2582 error=%s" % (ADDON_ID, arm_exc_v2582), xbmc.LOGWARNING)

                    if config_ready and activation_ready_v1989 and not library_restart_committed and not startup_fast_local_v2582:
                        _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_BEGIN_V2578 attempt=%d authority=1 playstate=parallel startup_sync=authority_single_owner post_reveal_heavy=0" % (ADDON_ID, attempt), xbmc.LOGINFO)

                        # PKM_PATCH_ACTIVE v2578 authority_playstate_parallel_startup
                        # /library/onDeck + recentlyViewed are independent from the
                        # authority proof.  Start that network pull before the local
                        # authority check so the two startup costs overlap instead of
                        # adding serially.  Home still waits for both, preserving exact
                        # Continue Watching/progress state at first paint.
                        playstate_parallel_v2578 = {"done": False, "ok": False, "error": "", "elapsed_ms": 0}
                        playstate_started_v2578 = time.time()
                        def _prehome_playstate_worker_v2578():
                            try:
                                core.sync_play_state_from_plex_light(reason="prehome_parallel_v2578")
                                playstate_parallel_v2578["ok"] = True
                            except Exception as playstate_exc_v2578:
                                playstate_parallel_v2578["error"] = str(playstate_exc_v2578)
                            finally:
                                playstate_parallel_v2578["elapsed_ms"] = int((time.time() - playstate_started_v2578) * 1000)
                                playstate_parallel_v2578["done"] = True
                        playstate_thread_v2578 = threading.Thread(
                            target=_prehome_playstate_worker_v2578,
                            name="pkm-prehome-playstate-v2578",
                            daemon=True
                        )
                        try:
                            playstate_thread_v2578.start()
                            _pkm_log_v2584("[%s] UHD3_STARTUP_PLAYSTATE_PARALLEL_START_V2578" % ADDON_ID, xbmc.LOGINFO)
                        except Exception as playstate_start_exc_v2578:
                            playstate_thread_v2578 = None
                            playstate_parallel_v2578["done"] = True
                            playstate_parallel_v2578["error"] = str(playstate_start_exc_v2578)
                            _pkm_log_v2584("[%s] UHD3_STARTUP_PLAYSTATE_PARALLEL_START_FAILED_V2578 error=%s" % (ADDON_ID, playstate_start_exc_v2578), xbmc.LOGWARNING)

                        authority_started_v2578 = time.time()
                        try:
                            prehome_authority_v2349 = dict(getattr(core, "startup_prehome_authority_gate_v2349")() or {})
                            if prehome_authority_v2349.get("deferred_r57"):
                                _start_r57_background_membership(core, home, list(prehome_authority_v2349.get("deferred_r57") or []))
                            _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_AUTHORITY_DONE_V2578 ok=%d checked=%d dirty=%d incremental=%d full_syncs=%d membership_scans=%d errors=%d elapsed_ms=%d" % (
                                ADDON_ID,
                                1 if prehome_authority_v2349.get("ok") else 0,
                                int(prehome_authority_v2349.get("checked", 0) or 0),
                                int(prehome_authority_v2349.get("dirty", 0) or 0),
                                int(prehome_authority_v2349.get("incremental_syncs", 0) or 0),
                                int(prehome_authority_v2349.get("full_syncs", 0) or 0),
                                int(prehome_authority_v2349.get("membership_scans", 0) or 0),
                                len(prehome_authority_v2349.get("errors") or []),
                                int((time.time() - authority_started_v2578) * 1000),
                            ), xbmc.LOGINFO)
                        except Exception as authority_exc_v2570:
                            _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_AUTHORITY_FAILED_V2578 error=%s action=fail_open_local" % (ADDON_ID, authority_exc_v2570), xbmc.LOGWARNING)

                        # Wait only after authority is finished: normally the Plex
                        # playstate pull is already done by this point.  This keeps
                        # first Home metadata/progress authoritative without serial I/O.
                        try:
                            if playstate_thread_v2578 is not None:
                                while playstate_thread_v2578.is_alive() and not monitor.abortRequested():
                                    playstate_thread_v2578.join(0.05)
                            if playstate_parallel_v2578.get("ok"):
                                _pkm_log_v2584("[%s] UHD3_STARTUP_PLAYSTATE_PARALLEL_DONE_V2578 elapsed_ms=%d overlap=1" % (
                                    ADDON_ID, int(playstate_parallel_v2578.get("elapsed_ms", 0) or 0)
                                ), xbmc.LOGINFO)
                            elif playstate_parallel_v2578.get("error"):
                                _pkm_log_v2584("[%s] UHD3_STARTUP_PLAYSTATE_PARALLEL_FAILED_V2578 elapsed_ms=%d error=%s action=continue" % (
                                    ADDON_ID, int(playstate_parallel_v2578.get("elapsed_ms", 0) or 0),
                                    playstate_parallel_v2578.get("error")
                                ), xbmc.LOGWARNING)
                        except Exception as playstate_join_exc_v2578:
                            _pkm_log_v2584("[%s] UHD3_STARTUP_PLAYSTATE_PARALLEL_JOIN_FAILED_V2578 error=%s action=continue" % (ADDON_ID, playstate_join_exc_v2578), xbmc.LOGWARNING)
                        # PKM_PATCH_ACTIVE v2577 authority_gate_is_startup_sync_owner
                        # v2577: startup_prehome_authority_gate_v2349 is already the canonical
                        # selected-library authority barrier.  It compares live Plex section
                        # state, repairs exact small additions/metadata, prunes proven deletes,
                        # and falls back to full membership/full sync only when required.
                        # Running startup_latest_guard + ensure_startup_cache_ready again after
                        # a successful gate duplicated the same Plex work and cost ~5.5s on PC.
                        # A successful authority gate is therefore sufficient.  Only a failed
                        # or unproven gate uses the legacy cache verifier as a fail-safe.
                        try:
                            authority_proven_v2577 = bool(
                                prehome_authority_v2349.get("ok")
                                and not (prehome_authority_v2349.get("errors") or [])
                            )
                            if authority_proven_v2577:
                                prehome_quiet_sync_ok_v2570 = True
                                _pkm_log_v2584("[%s] UHD3_STARTUP_DUPLICATE_SYNC_SKIP_V2577 reason=authority_gate_committed checked=%d dirty=%d incremental=%d membership_scans=%d full_syncs=%d extra_latest_guard=0 serial_verifier=0" % (
                                    ADDON_ID,
                                    int(prehome_authority_v2349.get("checked", 0) or 0),
                                    int(prehome_authority_v2349.get("dirty", 0) or 0),
                                    int(prehome_authority_v2349.get("incremental_syncs", 0) or 0),
                                    int(prehome_authority_v2349.get("membership_scans", 0) or 0),
                                    int(prehome_authority_v2349.get("full_syncs", 0) or 0),
                                ), xbmc.LOGINFO)
                            else:
                                _pkm_log_v2584("[%s] UHD3_STARTUP_AUTHORITY_FALLBACK_VERIFY_V2577 authority_ok=%d errors=%d action=legacy_startup_cache_verify" % (
                                    ADDON_ID, 1 if prehome_authority_v2349.get("ok") else 0,
                                    len(prehome_authority_v2349.get("errors") or []),
                                ), xbmc.LOGWARNING)
                                prehome_quiet_sync_ok_v2570 = bool(core.ensure_startup_cache_ready(
                                    show_progress=False, notice_progress=False, caller="service_startup"
                                ))
                            _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_SYNC_DONE_V2577 success=%d authority_proven=%d duplicate_verify=0" % (
                                ADDON_ID, 1 if prehome_quiet_sync_ok_v2570 else 0,
                                1 if authority_proven_v2577 else 0
                            ), xbmc.LOGINFO)
                        except Exception as sync_exc_v2570:
                            _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_SYNC_FAILED_V2577 error=%s action=fail_open_local" % (ADDON_ID, sync_exc_v2570), xbmc.LOGWARNING)
                        # Any dirty signal emitted before Home exists is already represented in
                        # the DB/snapshots that the new WindowXML will compose.  Do not let that
                        # stale signal schedule a second live-Home rebuild.
                        for prop_v2570 in (
                            "PlexKM.Home.SyncRefreshPendingV1554",
                            "PlexKM.Home.SyncRefreshPendingTokenV1554",
                            "PlexKM.Home.SyncRefreshPendingReasonV1554",
                            "PlexKM.PlexUpdate.Dirty",
                        ):
                            try:
                                home.clearProperty(prop_v2570)
                            except Exception:
                                pass
                        try:
                            home.setProperty("PlexKM.HomeQuiet.PreHomeDoneV2570", "1")
                        except Exception:
                            pass
                        _pkm_log_v2584("[%s] UHD3_HOME_QUIET_PREHOME_END_V2570 attempt=%d home_open_next=1" % (ADDON_ID, attempt), xbmc.LOGINFO)

                    # V2669: authority completion must not freeze the visual logo around the mid-fill point.
                    _pkm_log_v2584("[%s] STARTUP_BOOT_FILL_KEEP_RUNNING_V2669 reason=authority_gate_done visual_only=1" % ADDON_ID, xbmc.LOGINFO)
                    _update_startup_slow_notice_v2365(
                        "홈 화면 준비로 PlexKM 로딩입니다",
                        phase="home_compose",
                    )
                    _pkm_log_v2584("[%s] STARTUP_LOCAL_GATE_READY_V2349 attempt=%d authority_checked=%d authority_dirty=%d authority_pruned=%d next_start_apply=1" % (
                        ADDON_ID, attempt,
                        int(prehome_authority_v2349.get("checked", 0) or 0),
                        int(prehome_authority_v2349.get("dirty", 0) or 0),
                        int((prehome_authority_v2349.get("pruned") or {}).get("total", 0) or 0),
                    ), xbmc.LOGINFO)
                    # v2407: keep the 3-second notice guard armed through Home composition.
                    # plexkm_home_window clears the notice at the atomic reveal boundary.
                    _pkm_log_v2584("[%s] STARTUP_SLOW_NOTICE_KEEP_ARMED_V2407 phase=home_compose service_notice_after_ms=5000 window_text_after_ms=12000" % ADDON_ID, xbmc.LOGINFO)
                    if config_ready and activation_ready_v1989 and not library_restart_committed:
                        _pkm_log_v2584("[%s] UHD3_HOME_QUIET_POST_REVEAL_SYNC_SUPPRESSED_V2570 reason=prehome_maintenance_owner" % ADDON_ID, xbmc.LOGINFO)
                    if library_restart_committed:
                        _pkm_log_v2584("[%s] POST_REVEAL_PLEX_SYNC_SKIP_V2091 reason=library_add_prehome_refresh_already_applied" % ADDON_ID, xbmc.LOGINFO)

                    _progress_ready_v2388 = _publish_startup_boot_progress_v2388(8, reason="local_gate_ready")
                    _pkm_log_v2584("[%s] STARTUP_PROGRESS_V2388 value=%.2f minimum=8 reason=local_gate_ready no_rewind=1 gui_invalidate=1" % (ADDON_ID, _progress_ready_v2388), xbmc.LOGINFO)
                    # R58: one bounded modal handoff for BOTH configured and fresh setups.
                    # The native 75/90s recovery deadline remains unchanged.
                    handoff_started_r58 = time.monotonic()
                    clear_since_r58 = None
                    while not monitor.abortRequested() and not _service_stopping(monitor):
                        now_r58 = time.monotonic()
                        try:
                            modal_r58 = bool(xbmc.getCondVisibility("System.HasModalDialog"))
                        except Exception:
                            modal_r58 = False
                        if modal_r58:
                            clear_since_r58 = None
                        else:
                            if clear_since_r58 is None:
                                clear_since_r58 = now_r58
                            if now_r58 - clear_since_r58 >= 0.35:
                                break
                        if now_r58 - handoff_started_r58 >= 5.0:
                            _pkm_log_v2584("[%s] R58_HOME_MODAL_TIMEOUT attempt=%d elapsed_ms=%d action=leave_recovery_owner" % (
                                ADDON_ID, attempt, int((now_r58-handoff_started_r58)*1000)), xbmc.LOGWARNING)
                            break
                        if monitor.waitForAbort(0.05):
                            return
                    if monitor.abortRequested() or _service_stopping(monitor):
                        return
                    if modal_r58:
                        _pkm_log_v2584("[%s] R88_MODAL_STILL_ACTIVE attempt=%d reason=modal_not_cleared action=try_window_owner_guarded" % (ADDON_ID, attempt), xbmc.LOGWARNING)
                        # Do not silently abandon the home attempt here: the
                        # window owner performs its own bounded dialog check.
                    _pkm_log_v2584("[%s] R58_HOME_OPEN_ATTEMPT attempt=%d config_ready=%d" % (
                        ADDON_ID, attempt, 1 if config_ready else 0), xbmc.LOGINFO)
                    # R87 diagnostic-only independent observer: doModal blocks this owner thread.
                    # Never change window/modal state or restart from this observer.
                    diag_start_r87 = time.monotonic()
                    def _r87_home_probe(owner_attempt=attempt, started=diag_start_r87):
                        checkpoints = (1, 3, 5, 10, 20, 40, 75, 95)
                        for checkpoint in checkpoints:
                            while not monitor.abortRequested() and time.monotonic() - started < checkpoint:
                                if monitor.waitForAbort(min(0.25, max(0.01, checkpoint - (time.monotonic() - started)))):
                                    return
                            try:
                                w = xbmcgui.Window(10000)
                                ready = w.getProperty("PlexKM.Home.StartupReadyV1619") or "0"
                                opening = w.getProperty("PlexKM.HomeWindowOpening") or "0"
                                active = w.getProperty("PlexKM.HomeWindowActive") or "0"
                                xml_ready = w.getProperty("PlexKM.Home.XmlControlsReadyV2119") or "0"
                                win_id = xbmcgui.getCurrentWindowId()
                                dialog_id = xbmcgui.getCurrentWindowDialogId()
                                modal = int(bool(xbmc.getCondVisibility("System.HasModalDialog")))
                                _pkm_log_v2584("[%s] R87_HOME_ACTIVATION_PROBE attempt=%d elapsed_ms=%d window_id=%s dialog_id=%s modal=%d opening=%s active=%s xml_ready=%s startup_ready=%s" % (
                                    ADDON_ID, owner_attempt, int((time.monotonic()-started)*1000),
                                    win_id, dialog_id, modal, opening, active, xml_ready, ready),
                                    xbmc.LOGWARNING if ready != "1" else xbmc.LOGINFO)
                                if ready == "1":
                                    _pkm_log_v2584("[%s] R87_HOME_ACTIVATION_CONFIRMED attempt=%d elapsed_ms=%d" % (
                                        ADDON_ID, owner_attempt, int((time.monotonic()-started)*1000)), xbmc.LOGINFO)
                                    return
                            except Exception as diag_exc:
                                _pkm_log_v2584("[%s] R87_HOME_ACTIVATION_PROBE_ERROR attempt=%d error_type=%s" % (
                                    ADDON_ID, owner_attempt, type(diag_exc).__name__), xbmc.LOGWARNING)
                        _pkm_log_v2584("[%s] R87_HOME_ACTIVATION_UNCONFIRMED attempt=%d after_ms=95000 diagnostic_only=1" % (
                            ADDON_ID, owner_attempt), xbmc.LOGERROR)
                    threading.Thread(target=_r87_home_probe, name="PKMR87HomeProbe", daemon=True).start()
                    # R125: keep the native Home multiimage visible for its entire
                    # 120 x 34ms pass. Opening WindowXML earlier occludes Home,
                    # exposing its unfinished menu while the logo is still filling.
                    # The startup clock is armed before this owner thread runs.
                    try:
                        _r125_logo_clock = float(home.getProperty('PlexKM.Startup.LinearLogoStart') or '0')
                    except (ValueError, TypeError):
                        _r125_logo_clock = 0.0
                    # PKM_STARTUP_OPEN_LEAD_R33: with the cropped R33 frames the
                    # native sweep really ends ~4.1 s after it starts (it was
                    # ~7.5 s on SHIELD with full-screen frames).  open_window_home
                    # needs ~1.3-1.9 s (construct, R86 modal check, XML load)
                    # before the WindowXML actually occludes Home, so starting
                    # the call at 3.0 s still lets the sweep finish on screen.
                    # R71: do not hold the owner thread here any more.  The
                    # WindowXML import/construct (~0.6 s PC) runs during the
                    # sweep and only doModal waits for the 3.65 s mark inside
                    # open_window_home (activation adds ~0.4 s -> ~4.05 s).
                    # R115: the XML load (~0.7 s on SHIELD) blocks the GUI thread, so
                    # it must start only once the fill is complete (starting it
                    # earlier froze the sweep at ~70 % for 0.77 s).  doModal fires
                    # at lead - 0.5 + ~0.1 (R86 single re-check), i.e. ~3.6 s on
                    # Android; Kodi starts the XML load ~0.4 s later, as frame 239 lands. Composition was
                    # made cheaper instead (section count cache).
                    # R283: the native sweep is now 121 x 66 ms = 8.0 s (Home.xml timeperimage).
                    # Opening the WindowXML at 4.0 s froze the fill at ~70 % while the XML
                    # loaded, then jumped.  Keep the original "end of sweep - 0.1 s" tie.
                    _lead_r115 = 3.60 if xbmc.getCondVisibility("System.Platform.Android") else 3.65  # R295: sweep 121 x 25 ms = 3.0 s (was 66 ms / lead 9.5)
                    domodal_at_r71 = (_r125_logo_clock + _lead_r115) if _r125_logo_clock > 0 else 0.0
                    _pkm_log_v2584('[%s] R125_NATIVE_HOME_ANIMATION_PASS elapsed_ms=%d' % (
                        ADDON_ID, int((time.monotonic()-_r125_logo_clock)*1000) if _r125_logo_clock else -1), xbmc.LOGINFO)
                    _pkm_log_v2584("[%s] R87_HOME_OPEN_CALL attempt=%d" % (ADDON_ID, attempt), xbmc.LOGWARNING)
                    core.open_window_home({"index": "home", "sort": "added", "autostart": "1", "source": "service_startup_r58_local", "attempt": str(attempt), "no_interactive_sync": "1",
                                           "domodal_not_before_mono_r71": ("%.3f" % domodal_at_r71) if (attempt == 1 and domodal_at_r71 > 0) else ""})
                    _pkm_log_v2584("[%s] R87_HOME_OPEN_RETURN attempt=%d elapsed_ms=%d" % (
                        ADDON_ID, attempt, int((time.monotonic()-diag_start_r87)*1000)), xbmc.LOGWARNING)
                    # doModal normally returns only after the user closes Home.
                    # Retry only if it returned without ever reaching HomeReady.
                    try:
                        ready_r58 = xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") == "1"
                    except Exception:
                        ready_r58 = False
                    if ready_r58:
                        _pkm_log_v2584("[%s] R58_HOME_RETURN reason=normal_or_ready attempt=%d" % (ADDON_ID, attempt), xbmc.LOGINFO)
                        return
                    _pkm_log_v2584("[%s] R58_HOME_RETURN_NOT_READY attempt=%d action=bounded_retry" % (ADDON_ID, attempt), xbmc.LOGWARNING)
                    if monitor.waitForAbort(0.60):
                        return
                    continue
                except Exception as exc:
                    _pkm_log_v2584("[%s] AUTOSTART_HOME_ATTEMPT_FAILED_V984 attempt=%d error=%s" % (ADDON_ID, attempt, exc), xbmc.LOGWARNING)

            _stop_startup_boot_activity_fill_v2388(reason="autostart_failed")
            _clear_startup_slow_notice_v2365(reason="autostart_failed")
            _pkm_log_v2584("[%s] R88_HOME_ATTEMPTS_EXHAUSTED action=release_splash_and_show_kodi_home" % ADDON_ID, xbmc.LOGERROR)
            try:
                recovery_home_r88 = xbmcgui.Window(10000)
                recovery_home_r88.clearProperty("PlexKM.SkinStartupSplash")
                recovery_home_r88.clearProperty("PlexKM.HomeWindowOpening")
                recovery_home_r88.clearProperty("PlexKM.HomeWindowActive")
                xbmc.executebuiltin("ActivateWindow(Home)")
            except Exception as recovery_exc_r88:
                _pkm_log_v2584("[%s] R88_NATIVE_HOME_FALLBACK_FAILED error_type=%s" % (ADDON_ID, type(recovery_exc_r88).__name__), xbmc.LOGERROR)
            _pkm_log_v2584("[%s] AUTOSTART_HOME_FAILED retries_exhausted_v984" % ADDON_ID, xbmc.LOGERROR)
        except Exception as exc:
            _pkm_log_v2584("[%s] AUTOSTART_HOME_FAILED_V984: %s" % (ADDON_ID, exc), xbmc.LOGERROR)

    # v2165: this thread is the WindowXML owner, not a background data worker.
    # core.open_window_home() stays on this thread for the entire lifetime of the
    # PKM Home WindowXML and only returns when that window closes.  Full reset is
    # launched from a settings dialog on top of that same Home, so waiting for
    # this thread to die before purge is a structural deadlock: Home cannot close
    # until reset/settings finishes, while reset was waiting for Home's owner.
    # Keep it daemonized, but do NOT register it in the service-worker drain set.
    t = threading.Thread(target=_worker, name="PlexKMHomeAutostartV984", daemon=True)
    t.daemon = True
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.Service.HomeAutostartUiOwnerV2165", "1")
        _pkm_log_v2584("[%s] PKM_SERVICE_THREAD_CLASS_V2165 name=PlexKMHomeAutostartV984 class=ui_window_owner service_drain_blocker=0" % ADDON_ID, xbmc.LOGINFO)
    except Exception:
        pass
    t.start()
    # R79: disarm any stale/native deadline from an earlier launch. A slow
    # home transition is not a configuration/data-recovery condition.
    try:
        _r79_home = xbmcgui.Window(10000)
        _r79_home.clearProperty("PlexKM.Startup.RecoveryArmedR2")
        _r79_home.clearProperty("PlexKM.Startup.RecoveryReasonR2")
        for _r79_alarm in ("PKM_R2_RecoveryArm", "PKM_R2_ReleaseSplash", "PKM_R2_FocusNative", "PKM_R2_RecoveryFocus"):
            xbmc.executebuiltin("CancelAlarm(%s,silent)" % _r79_alarm)
        _pkm_log_v2584("[%s] STARTUP_RECOVERY_R79 stale_alarm_cancelled=1 timeout_recovery=disabled" % ADDON_ID, xbmc.LOGINFO)
    except Exception:
        pass
    # PKM_R2: soft recovery plus an independent native Kodi-skin deadline.
    # Never reset selected libraries or delete DB/cache automatically.
    try:
        from resources.lib import pkm_startup_recovery_r2
        pkm_startup_recovery_r2.start_watchdog(
            monitor=monitor, home_thread=t, logger=_pkm_log_v2584
        )
    except Exception as exc:
        _pkm_log_v2584("[%s] STARTUP_GUARD_R2_ARM_FAILED err=%s" % (ADDON_ID, exc), xbmc.LOGERROR)
    # R69: last-resort reveal, independent of the Home WindowXML threads.
    try:
        from resources.lib import pkm_startup_recovery_r2 as recovery_r69
        recovery_r69.start_last_resort_reveal_r69(monitor=monitor, logger=_pkm_log_v2584)
    except Exception as exc_r69:
        _pkm_log_v2584("[%s] STARTUP_LAST_RESORT_ARM_FAILED_R69 err=%s" % (ADDON_ID, exc_r69), xbmc.LOGERROR)


def _clear_fast_startup_plex_notice(reason="startup_probe_ok"):
    """Clear only the offline failure notice after the fast /identity probe.

    v1311: this quick health probe must not clear normal status/progress
    notices such as Plex connection check or PKM update progress.  v1310 used
    a force clear and removed the only visible notice while initial library
    sync was still running.
    """
    cleared = False
    try:
        if pkm_notify and hasattr(pkm_notify, "pkm_notice_clear_if_title"):
            cleared = bool(pkm_notify.pkm_notice_clear_if_title(["Plex 연결 실패"], force=True))
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Notify.Title") == "Plex 연결 실패":
            for key in ("PlexKM.Notify.Active", "PlexKM.Notify.Title", "PlexKM.Notify.Line1", "PlexKM.Notify.Line2", "PlexKM.Notify.Token", "PlexKM.Notify.Sticky"):
                win.clearProperty(key)
            cleared = True
        for key in ("PlexKM.PlexOffline", "PlexKM.PlexOfflineReason", "PlexKM.PlexOfflineLine1", "PlexKM.PlexOfflineLine2", "PlexKM.PlexOfflineAt"):
            win.clearProperty(key)
    except Exception:
        pass
    _pkm_log_v2584("[%s] FAST_PLEX_OFFLINE_NOTICE_CLEAR_V1311 reason=%s cleared=%s" % (ADDON_ID, reason, "1" if cleared else "0"), xbmc.LOGINFO)
    return True


def _startup_fast_plex_probe(core, monitor, timeout_sec=1.15):
    """Probe Plex quickly after Home autostart has been requested.

    v1289: The old service flow blocked on /library/onDeck with an 8s timeout
    before PKM Home could open.  When PMS was stopped the screen looked frozen
    and the first notice could only be logged.  This fast probe runs in a daemon
    worker, uses a short timeout, sets a sticky PKM notice immediately on failure,
    and never blocks Home startup.
    """
    if not core:
        return

    def _worker():
        try:
            # V2584: even a lightweight /identity request competes for Python, DNS,
            # sockets and logging on UHD3.  It is advisory, so start only after the
            # atomic Home reveal AND the user's first navigation burst has settled.
            wait_started_v2584 = time.time()
            ready_seen_ms_v2584 = 0
            while not monitor.abortRequested() and not _service_stopping(monitor):
                now_probe_ms_v2584 = int(time.time() * 1000)
                try:
                    home_probe_v2584 = xbmcgui.Window(10000)
                    if home_probe_v2584.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                        if not ready_seen_ms_v2584:
                            ready_seen_ms_v2584 = now_probe_ms_v2584
                        try:
                            last_input_probe_v2584 = int(float(home_probe_v2584.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or "0"))
                        except Exception:
                            last_input_probe_v2584 = 0
                        idle_probe_ms_v2584 = (now_probe_ms_v2584 - last_input_probe_v2584) if last_input_probe_v2584 > 0 else (now_probe_ms_v2584 - ready_seen_ms_v2584)
                        if (now_probe_ms_v2584 - ready_seen_ms_v2584) >= 10000 and idle_probe_ms_v2584 >= 5000 and home_probe_v2584.getProperty("PlexKM.WallRapidScrollV2581") != "1":
                            break
                except Exception:
                    pass
                if time.time() - wait_started_v2584 > 120.0:
                    return
                if monitor.waitForAbort(0.25):
                    return
            _pkm_log_v2584("[%s] UHD3_STARTUP_PLEX_PROBE_DEFERRED_V2584 home_ready=1 delay_ms>=10000 idle_ms>=5000" % ADDON_ID, xbmc.LOGINFO)
            if not _plex_config_ready():
                return
            # v1686: during first setup, token authentication and library selection
            # own the Plex connection.  The startup health probe must not run in
            # parallel with the existing manual-token fetch_sections flow.
            try:
                state = core.load_state() if hasattr(core, "load_state") else {}
                if not bool((state or {}).get("selected_sections_configured", False)):
                    _pkm_log_v2584("[%s] FAST_PLEX_PROBE_SKIP_V1686 reason=library_selection_not_configured" % ADDON_ID, xbmc.LOGINFO)
                    return
            except Exception:
                pass
            try:
                _pkm_log_v2584("[%s] FAST_PLEX_PROBE_BEGIN path=/identity timeout=%.2f" % (ADDON_ID, float(timeout_sec or 1.15)), xbmc.LOGINFO)
                # Use Plex's lightweight identity endpoint.  This is only a health
                # probe, not a content pull, so it must not delay Home building.
                core.plex_request_xml("/identity", timeout=float(timeout_sec or 1.15), log_failures=False)
                _clear_fast_startup_plex_notice(reason="startup_fast_probe_ok")
                _pkm_log_v2584("[%s] FAST_PLEX_PROBE_OK path=/identity" % ADDON_ID, xbmc.LOGINFO)
            except Exception as exc:
                # V2714: /identity is advisory only.  Never let this short probe
                # create the user-visible "Plex 연결 실패" state.  Real offline
                # UI is owned by authoritative Plex content requests such as
                # /library/sections through pkm_plex_client.
                _pkm_log_v2584("[%s] FAST_PLEX_PROBE_FAIL_ADVISORY_V2714 path=/identity timeout=%.2f offline_state_unchanged=1 notice_set=0 err=%s" % (
                    ADDON_ID, float(timeout_sec or 1.15), exc
                ), xbmc.LOGWARNING)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] FAST_PLEX_PROBE_WORKER_FAILED err=%s" % (ADDON_ID, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    t = _PKMServiceThreadV2151(target=_worker, name="PlexKMFastPlexProbeV1289", daemon=True)
    t.daemon = True
    t.start()


def _player_has_video():
    """Playback-priority guard for service background work.

    v2118 treats the user's Play request as active before AVStarted so startup
    sync/network maintenance cannot contend with the resolver/open-file path.
    """
    try:
        if xbmc.Player().isPlayingVideo():
            return True
    except Exception:
        pass
    try:
        if bool(
            xbmc.getCondVisibility("Player.HasVideo")
            or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
            or xbmc.getCondVisibility("Window.IsActive(videoosd)")
        ):
            return True
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Playback.PriorityV2118") == "1"
            or win.getProperty("PlexKM.Playback.OpeningActive") == "1"
            or win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
        )
    except Exception:
        return False


class _R19AlreadyDone(Exception):
    """R19: deferred maintenance skips the authority gate already run pre-Home."""
    pass


def _plex_offline_active():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1"
    except Exception:
        return False


def _full_reset_in_progress_v2149():
    try:
        win_v2150 = xbmcgui.Window(10000)
        return bool(win_v2150.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win_v2150.getProperty("PlexKM.FullResetInProgressV2149") == "1")
    except Exception:
        return False


def _startup_sync_background(core, monitor):
    """Run the one-time post-Home startup update check with PKM small notice.

    Initial install keeps the existing interactive first-sync path.  Later Kodi
    starts open PKM Home first, then show a small top-right status line while
    changed libraries are checked/refreshed.  No focus/navigation control here.
    """
    def _worker():
        try:
            # V2584: V2582 local-first already installs one long-idle deferred
            # authority owner.  The historical post-Home startup-sync worker was
            # still waking as soon as InitialWidgetsReady became true and could
            # run ensure_startup_cache_ready() directly under sidebar/wall input.
            # That duplicate owner is exactly the kind of BG/PLEX burst seen on
            # UHD3.  Fast-local runs therefore skip this worker completely.
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1":
                    _pkm_log_v2584("[%s] UHD3_STARTUP_SYNC_BACKGROUND_SKIP_V2584 deferred_owner=1 live_home_heavy=0" % ADDON_ID, xbmc.LOGINFO)
                    return
            except Exception:
                pass
            if _full_reset_in_progress_v2149():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP_V2149 reason=full_reset_before_worker" % ADDON_ID, xbmc.LOGINFO)
                return
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.StartupSnapshotSyncDoneV1644") == "1":
                    _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP_V1644 reason=snapshot_already_synced_under_cover" % ADDON_ID, xbmc.LOGINFO)
                    return
            except Exception:
                pass
            if _plex_offline_active():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=plex_offline_v1290" % ADDON_ID, xbmc.LOGWARNING)
                return
            if _server_switch_pending_active_v1310():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=server_switch_pending_v1310" % ADDON_ID, xbmc.LOGWARNING)
                return
            if not _bool_setting("startup_prewarm", True):
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=startup_prewarm_disabled" % ADDON_ID, xbmc.LOGINFO)
                return
            if not getattr(core, "initial_sync_done", lambda: False)():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=initial_sync_not_done" % ADDON_ID, xbmc.LOGINFO)
                return
            # v948: do not start service startup sync while PKM Home is still
            # building its first visible widgets.  The sync is network/DB heavy
            # and was starting before HOME_APPEND_XML_ROWS, making the Home row
            # appear late even though the screen had already opened.
            win_guard = xbmcgui.Window(10000)
            waited_ms = 0
            while waited_ms < 9000:
                if monitor.waitForAbort(0.2):
                    return
                waited_ms += 200
                if _full_reset_in_progress_v2149():
                    _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP_V2149 reason=full_reset_during_home_wait" % ADDON_ID, xbmc.LOGINFO)
                    return
                if _player_has_video():
                    _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=player_active" % ADDON_ID, xbmc.LOGINFO)
                    return
                try:
                    if win_guard.getProperty("PlexKM.Home.InitialWidgetsReady") == "1":
                        break
                except Exception:
                    pass
            try:
                ready_flag = win_guard.getProperty("PlexKM.Home.InitialWidgetsReady") or ""
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_HOME_READY_WAIT waited_ms=%d ready=%s" % (ADDON_ID, waited_ms, ready_flag), xbmc.LOGINFO)
            except Exception:
                ready_flag = ""
            if ready_flag != "1":
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=home_not_ready_no_startup_sync" % ADDON_ID, xbmc.LOGWARNING)
                return
            if _player_has_video():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=player_active" % ADDON_ID, xbmc.LOGINFO)
                return
            if _service_stopping(monitor):
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=service_stopping_before_begin" % ADDON_ID, xbmc.LOGINFO)
                return
            if _service_stopping(monitor):
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=service_stopping_before_core" % ADDON_ID, xbmc.LOGINFO)
                return
            if _plex_offline_active():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=plex_offline_before_begin_v1290" % ADDON_ID, xbmc.LOGWARNING)
                return
            if _server_switch_pending_active_v1310():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP reason=server_switch_pending_before_begin_v1310" % ADDON_ID, xbmc.LOGWARNING)
                return
            # v1644: the post-Home worker can be created before the under-cover
            # snapshot sync has finished.  Re-check here after the Home-ready wait
            # so it cannot run the same Plex sync a second time.
            try:
                if win_guard.getProperty("PlexKM.StartupSnapshotSyncDoneV1644") == "1":
                    _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP_V1644 reason=snapshot_synced_during_home_wait" % ADDON_ID, xbmc.LOGINFO)
                    return
            except Exception:
                pass
            if _full_reset_in_progress_v2149():
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_SKIP_V2149 reason=full_reset_before_core" % ADDON_ID, xbmc.LOGINFO)
                return
            try:
                if win_guard.getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1":
                    _pkm_log_v2584("[%s] UHD3_STARTUP_SYNC_BACKGROUND_SKIP_V2584 deferred_owner=1 live_home_heavy=0 phase=pre_core" % ADDON_ID, xbmc.LOGINFO)
                    return
            except Exception:
                pass
            _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_NOTICE_BEGIN" % ADDON_ID, xbmc.LOGINFO)
            core.ensure_startup_cache_ready(show_progress=False, notice_progress=True, caller="service_startup")
            if _service_stopping(monitor):
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_NOTICE_ABORTED_BY_STOP" % ADDON_ID, xbmc.LOGINFO)
                return
            _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_NOTICE_END" % ADDON_ID, xbmc.LOGINFO)
        except Exception as exc:
            try:
                _pkm_log_v2584("[%s] STARTUP_SYNC_SERVICE_NOTICE_FAILED: %s" % (ADDON_ID, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    t = _PKMServiceThreadV2151(target=_worker, daemon=True)
    t.daemon = True
    t.start()






def _poll_incremental_updates(core, monitor, min_interval_sec=120):
    """v1644: runtime Plex/widget snapshot is immutable until next Kodi start."""
    try:
        win_v1644 = xbmcgui.Window(10000)
        if win_v1644.getProperty("PlexKM.RuntimePollSkipLoggedV1644") != "1":
            win_v1644.setProperty("PlexKM.RuntimePollSkipLoggedV1644", "1")
            _pkm_log_v2584("[%s] RUNTIME_PLEX_POLL_DISABLED_V1644 next_refresh=kodi_restart" % ADDON_ID, xbmc.LOGINFO)
    except Exception:
        pass
    return

def _install_seek_quick_keymap(reason="service_startup"):
    """Install PKM playback keymap.

    v1386: LEFT/RIGHT quick seek keeps the real VideoOSD open, focuses the seek bar, and uses static PNG high-resolution marker/fill. DialogSeekBar is not redrawn.

    v1947: Fullscreen ENTER uses Kodi native OSD and VideoOSD ENTER uses native
    Select. No Python ENTER dispatcher or synthetic focus movement is used.
    """
    try:
        profile = xbmcvfs.translatePath("special://profile/keymaps")
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
        path = profile.rstrip("/\\") + "/plex_km_seek_quick.xml"
        entry = "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,key=%s,source=%s)"
        # v1445: LEFT/RIGHT return through PKM dispatcher so the dynamic
        # bitrate table can select direct Kodi built-in Seek(30/10), not fixed StepForward.
        # v1557: bind only the user's real FullscreenVideo Back/Escape input to
        # the stabilized v1505 live-video fade route.  The route fades a
        # WindowXMLDialog over the running video and issues one native Stop only
        # after full black; the unsafe WindowXML onInit inference stays removed.
        content = """<keymap>
  <!-- v1557: actual fullscreen Back input performs live-video overlay fade, then one native Stop; no forced pause and no onInit heuristic. -->
  <FullscreenVideo>
    <keyboard>
      <backspace>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_keyboard_backspace_r140)</backspace>
      <escape>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_keyboard_escape_r140)</escape>
      <browser_back>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_keyboard_browser_back_r140)</browser_back>
      <left mod="longpress">%s</left>
      <right mod="longpress">%s</right>
      <left>%s</left>
      <right>%s</right>
      <up>%s</up>
      <down>%s</down>
      <return mod="longpress">OSD</return>
      <enter mod="longpress">OSD</enter>
      <return>OSD</return>
      <enter>OSD</enter>
      <space>%s</space>
      <!-- R140: FF/REW 배속 탐색 (OSD 없이, 영상은 멈춘 화면) -->
      <fastforward mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</fastforward>
      <fastforward>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_keyboard_fastforward_short)</fastforward>
      <rewind mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</rewind>
      <rewind>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_keyboard_rewind_short)</rewind>
      <f mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</f>
      <f>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_keyboard_f_short)</f>
      <r mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</r>
      <r>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_keyboard_r_short)</r>
    </keyboard>
    <remote>
      <forward mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</forward>
      <forward>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_remote_forward_short)</forward>
      <reverse mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</reverse>
      <reverse>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_remote_reverse_short)</reverse>
      <back>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_remote_back_r140)</back>
      <left mod="longpress">%s</left>
      <right mod="longpress">%s</right>
      <left>%s</left>
      <right>%s</right>
      <up>%s</up>
      <down>%s</down>
      <select mod="longpress">OSD</select>
      <enter mod="longpress">OSD</enter>
      <select>OSD</select>
      <enter>OSD</enter>
    </remote>
    <!-- R140: 게임패드(쉴드 컨트롤러) 트리거·방향 좌/우도 배속 탐색 -->
    <joystick profile="game.controller.default">
      <lefttrigger>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</lefttrigger>
      <righttrigger>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</righttrigger>
      <leftbumper>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</leftbumper>
      <rightbumper>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</rightbumper>
      <!-- R2801: Kodi joystick keymaps do not know mod="longpress" (keyboard/remote only); the attribute was ignored and the
           plain <left>/<right> always won, so a long press never reached trickplay.  Joystick uses holdtime (ms): hold = trickplay seek,
           short press (released before holdtime) = fixed jump. -->
      <left holdtime="450">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)</left>
      <left>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_joystick_left_short)</left>
      <right holdtime="450">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)</right>
      <right>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_joystick_right_short)</right>
      <!-- R140b: 게임패드 B/뒤로 버튼도 리모컨 BACK 과 같이 페이드 후 정지 (Kodi 기본은 바로 Stop) -->
      <b>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_joystick_b_r140)</b>
      <back>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_return_fade_r140.py,source=fullscreen_joystick_back_r140)</back>
    </joystick>
  </FullscreenVideo>
  <VideoOSD>
    <keyboard>
      <return mod="longpress">%s</return>
      <enter mod="longpress">%s</enter>
      <left>left</left>
      <right>right</right>
      <up>up</up>
      <down>down</down>
      <return>%s</return>
      <enter>%s</enter>
    </keyboard>
    <remote>
      <select mod="longpress">%s</select>
      <enter mod="longpress">%s</enter>
      <left>left</left>
      <right>right</right>
      <up>up</up>
      <down>down</down>
      <select>%s</select>
      <enter>%s</enter>
    </remote>
    <!-- R140b: OSD 에서 게임패드 B/뒤로 = OSD 닫기 (리모컨 BACK 과 같음, 바로 정지 안 함) -->
    <joystick profile="game.controller.default">
      <b>Back</b>
      <back>Back</back>
    </joystick>
  </VideoOSD>
  <!-- R61: holding Back anywhere exits Kodi (3-2-1 countdown). A short Back keeps every existing per-window meaning. -->
  <global>
    <keyboard>
      <backspace mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_longpress_exit_r61.py,source=keyboard_backspace)</backspace>
      <escape mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_longpress_exit_r61.py,source=keyboard_escape)</escape>
      <browser_back mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_longpress_exit_r61.py,source=keyboard_browser_back)</browser_back>
      <!-- R75: user log marker (PKM_USER_MARK n): hold Play/Pause (SHIELD remote / media key) or press F12 (PC). -->
      <play_pause mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_user_mark_r75.py,source=play_pause_longpress)</play_pause>
      <f12>RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_user_mark_r75.py,source=keyboard_f12)</f12>
      <!-- R119: hold OK on a poster card opens the PKM card menu (즐겨찾기). -->
      <return mod="longpress">ContextMenu</return>
      <enter mod="longpress">ContextMenu</enter>
    </keyboard>
    <remote>
      <back mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_longpress_exit_r61.py,source=remote_back)</back>
      <playpause mod="longpress">RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_user_mark_r75.py,source=remote_playpause_longpress)</playpause>
      <select mod="longpress">ContextMenu</select>
      <enter mod="longpress">ContextMenu</enter>
    </remote>
  </global>
  <!-- R61: holding Backspace in the on-screen keyboard still deletes text. -->
  <virtualkeyboard>
    <keyboard>
      <backspace mod="longpress">Backspace</backspace>
      <return mod="longpress">Select</return>
      <enter mod="longpress">Select</enter>
    </keyboard>
    <remote>
      <select mod="longpress">Select</select>
      <enter mod="longpress">Select</enter>
    </remote>
  </virtualkeyboard>
</keymap>
""" % (
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)",  # R165-0: 길게=배속 탐색
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)",
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_keyboard_left_short)",  # R165-0: 짧게=고정 점프(뒤 10초)
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_keyboard_right_short)",
            entry % ("up", "fullscreen_up"),
            entry % ("down", "fullscreen_down"),
            entry % ("space", "fullscreen_space"),
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=rew)",  # R165-0: 길게=배속 탐색
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_trickplay_r140.py,dir=fwd)",
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=-10,source=fullscreen_remote_left_short)",  # R165-0: 짧게=고정 점프
            "RunScript(special://home/addons/plugin.video.km/resources/lib/pkm_seek_quick_entry.py,delta=30,source=fullscreen_remote_right_short)",
            entry % ("up", "fullscreen_up"),
            entry % ("down", "fullscreen_down"),
            entry % ("longselect", "videoosd_keyboard_return_longpress"),
            entry % ("longselect", "videoosd_keyboard_enter_longpress"),
            "Select",
            "Select",
            entry % ("longselect", "videoosd_remote_select_longpress"),
            entry % ("longselect", "videoosd_remote_enter_longpress"),
            "Select",
            "Select",
        )
        old = ""
        if xbmcvfs.exists(path):
            try:
                f = xbmcvfs.File(path, "r")
                old = f.read()
                f.close()
            except Exception:
                old = ""
        if old == content:
            _pkm_log_v2584("[%s][seek_quick] PKM_SEEK_KEYMAP_READY path=%s reason=%s changed=0 version=v1947 videoosd_native_second_enter_single_autoclose_owner_cold_preload_child_overlay=1 cold_different_movie_resume_serialized=1 real_fullscreen_back_video_fade_then_native_stop=1 no_oninit_stop=1 no_resume_state_reset=1 no_forced_pause=1 v1505_stabilized_dialog_close=1 wall_index_right_align_clock_end=1 wall_index_scroll_sync_dedicated_font_top205=1 wall_index_title_order_safe=1 wall_16x9_top_poster_no_ellipsis=1 new_playback_cache_reset=1 info_back_native_stop=1 info_resume_label_left10=1 pause_workers3_fixed_osd_gray_info_spacing=1 step_menu_focus_no_play_flash=1 home_offline_center_confirmed=1 no_immediate_home_offline_surface=1 step_menu_order_focus_fix=1 workers3_plus_equal_spacing=1 seek_step_menu_equal_spacing=1 pause_workers3_contiguous_test=1 pause_start_from_preserved_cache_end=1 cachebar_cross_seq_monotonic=1 restore_main_videoosd_play_fwd=1 collapsed_seek_menu_hq20=1 pause_cache_display_reset=1 step_menu_excludes_current_manual_step=1 cache_fast_start_no_duplicate_head=1 faint_white_cachebar=1 no_drop=1 restore_osd_meta=1 seek_side_menu=1 fwd30_font_match=1 smooth_cachebar_real_bytes=1 tiny_pause_marker=1 continue_respects_selected_libraries=1 seek_30s_requires_http_trusted_bitrate=1 native_plugin_http_resolve_cache=1 true_kodi_native_playmedia=1 playback_open_network_quiet=1 linear_to_eof_preread_no_cache_button=1 pause_workers3_contiguous=1 instant_visible_marker=1 preserve_seek_cache=1 seek_restart_preread=1 enter_videoosd_restore=1 dynamic_seek_30s_low_10s_high=1 seek_icons_with_s_suffix=1 play_row_aligned=1 real_videoosd_seekbar_focus=1 no_separate_seek_ui=1 static_marker_fill=1 space_pause_osd=1" % (ADDON_ID, path, reason), xbmc.LOGINFO)
            return True
        f = xbmcvfs.File(path, "w")
        f.write(content)
        f.close()
        try:
            xbmc.executebuiltin("Action(reloadkeymaps)")
        except Exception:
            pass
        _pkm_log_v2584("[%s][seek_quick] PKM_SEEK_KEYMAP_INSTALLED path=%s reason=%s changed=1 reload=Action(reloadkeymaps) version=v1947 videoosd_native_second_enter_single_autoclose_owner_cold_preload_child_overlay=1 cold_different_movie_resume_serialized=1 real_fullscreen_back_video_fade_then_native_stop=1 no_oninit_stop=1 no_resume_state_reset=1 no_forced_pause=1 v1505_stabilized_dialog_close=1 wall_index_right_align_clock_end=1 wall_index_scroll_sync_dedicated_font_top205=1 wall_index_title_order_safe=1 wall_16x9_top_poster_no_ellipsis=1 new_playback_cache_reset=1 info_back_native_stop=1 info_resume_label_left10=1 pause_workers3_fixed_osd_gray_info_spacing=1 step_menu_focus_no_play_flash=1 home_offline_center_confirmed=1 no_immediate_home_offline_surface=1 step_menu_order_focus_fix=1 workers3_plus_equal_spacing=1 seek_step_menu_equal_spacing=1 pause_workers3_contiguous_test=1 pause_start_from_preserved_cache_end=1 cachebar_cross_seq_monotonic=1 restore_main_videoosd_play_fwd=1 collapsed_seek_menu_hq20=1 pause_cache_display_reset=1 step_menu_excludes_current_manual_step=1 cache_fast_start_no_duplicate_head=1 faint_white_cachebar=1 no_drop=1 restore_osd_meta=1 seek_side_menu=1 fwd30_font_match=1 smooth_cachebar_real_bytes=1 tiny_pause_marker=1 continue_respects_selected_libraries=1 seek_30s_requires_http_trusted_bitrate=1 native_plugin_http_resolve_cache=1 true_kodi_native_playmedia=1 playback_open_network_quiet=1 linear_to_eof_preread_no_cache_button=1 pause_workers3_contiguous=1 instant_visible_marker=1 preserve_seek_cache=1 seek_restart_preread=1 enter_videoosd_restore=1 dynamic_seek_30s_low_10s_high=1 seek_icons_with_s_suffix=1 play_row_aligned=1 real_videoosd_seekbar_focus=1 no_separate_seek_ui=1 static_marker_fill=1 space_pause_osd=1" % (ADDON_ID, path, reason), xbmc.LOGINFO)
        return True
    except Exception as exc:
        try:
            _pkm_log_v2584("[%s][seek_quick] PKM_SEEK_KEYMAP_INSTALL_FAILED reason=%s err=%s" % (ADDON_ID, reason, exc), xbmc.LOGWARNING)
        except Exception:
            pass
        return False

def _set_service_stopping(value=True):
    try:
        win = xbmcgui.Window(10000)
        if value:
            win.setProperty("PlexKM.ServiceStopping", "1")
        else:
            win.clearProperty("PlexKM.ServiceStopping")
    except Exception:
        pass


def _service_stopping(monitor=None):
    try:
        win_v2150 = xbmcgui.Window(10000)
        if (win_v2150.getProperty("PlexKM.FullResetInProgressV2150") == "1"
                or win_v2150.getProperty("PlexKM.FullResetInProgressV2149") == "1"):
            return True
    except Exception:
        pass
    try:
        if _SERVICE_STOP.is_set():
            return True
    except Exception:
        pass
    try:
        if monitor is not None and monitor.abortRequested():
            return True
    except Exception:
        pass
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.ServiceStopping") == "1"
    except Exception:
        return False

def _pkm_skin_runtime_ready_v2276():
    """True only after skin.plex.km/Home.xml itself has actually loaded.

    Kodi may retain the requested skin id even when startup falls back to Estuary.
    The Home.xml sentinel keeps the PKM WindowXML/font graph from opening under
    the wrong active skin.  No ReloadSkin or runtime skin switch is attempted.
    """
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.Skin.RuntimeReadyV2276") == "1"
    except Exception:
        return False


def _pkm_skin_install_state_v1917():
    installed = False
    try:
        installed = bool(xbmc.getCondVisibility("System.HasAddon(skin.plex.km)"))
    except Exception:
        installed = False
    if not installed:
        try:
            xbmcaddon.Addon("skin.plex.km")
            installed = True
        except Exception:
            installed = False
    try:
        active_skin = str(xbmc.getSkinDir() or "")
    except Exception:
        active_skin = ""
    return installed, active_skin


def _show_pkm_skin_notice_v1917(state):
    """v2378R7: never emit a Kodi-native toast from PKM.

    Before skin.plex.km is runtime-ready there is no PKM-owned renderer yet, so
    showing a native Estuary/Kodi toast would violate the single PKM alert style.
    Record the state only; the state-driven skin gate handles readiness.
    """
    try:
        _pkm_log_v2584(
            "[%s] INSTALL_GATE_NOTICE_SUPPRESSED_V2378R7 state=%s reason=pkm_style_only"
            % (ADDON_ID, state),
            xbmc.LOGINFO,
        )
    except Exception:
        pass

def _wait_for_pkm_skin_active_v1917(monitor):
    """Canonical startup gate: active PKM skin is sufficient to start PKM.

    RuntimeReadyV2276 is a transient Home.xml property and is not a valid
    process-start prerequisite: during addon/skin update Kodi can show PKM's
    Startup.xml while Home.xml has not set that property yet. Waiting for the
    Home property before opening PKM Home creates a circular dependency.

    We therefore gate only on the actual installed + active skin.  A settings
    modal may delay for a short bounded interval, but no skin property can hold
    service startup indefinitely.
    """
    stable_active = 0
    modal_wait_started = None
    last_state = None
    notice_state_r91 = None
    gate_started_r90 = time.monotonic()
    gate_patient_logged_r91 = False
    while not monitor.abortRequested() and not _service_stopping(monitor):
        # R91: the former R90 hard timeout (15 s) stopped the whole service when the
        # skin was installed from the repository but not yet *active*.  Right after
        # install Kodi shows its native "use this skin?" confirm dialog; a user who
        # needs more than 15 s to answer it left PKM without a service, so the
        # first-run Settings handoff never happened (Home stayed on the splash until
        # the 90 s recovery buttons).  The gate now waits patiently, with a slower
        # poll, and only ends when the skin becomes active or Kodi/service stops.
        gate_waited_r91 = time.monotonic() - gate_started_r90
        if gate_waited_r91 >= 15.0 and not gate_patient_logged_r91:
            gate_patient_logged_r91 = True
            _pkm_log_v2584("[%s] R91_SKIN_GATE_PATIENT_WAIT elapsed_ms=%d action=keep_service_alive_until_skin_active" % (
                ADDON_ID, int(gate_waited_r91 * 1000)), xbmc.LOGWARNING)
        installed, active_skin = _pkm_skin_install_state_v1917()
        active = bool(installed and active_skin == "skin.plex.km")
        modal = _settings_dialog_active()
        runtime_ready = _pkm_skin_runtime_ready_v2276()
        state = (installed, active_skin, runtime_ready, modal, active)
        if state != last_state:
            _pkm_log_v2584(
                "[%s] SKIN_START_GATE installed=%d active_skin=%s runtime_hint=%d modal=%d active=%d runtime_required=0" % (
                    ADDON_ID, 1 if installed else 0, active_skin or "-",
                    1 if runtime_ready else 0, 1 if modal else 0, 1 if active else 0,
                ), xbmc.LOGINFO)
            last_state = state

        if active:
            stable_active += 1
            if not modal and stable_active >= 2:
                _pkm_log_v2584("[%s] SKIN_START_GATE_PASS source=active_skin runtime_required=0" % ADDON_ID, xbmc.LOGINFO)
                return True
            if modal:
                if modal_wait_started is None:
                    modal_wait_started = time.time()
                # A stale modal condition must never strand the startup splash.
                if (time.time() - modal_wait_started) >= 2.0:
                    _pkm_log_v2584("[%s] SKIN_START_GATE_PASS source=active_skin modal_guard_expired=1 runtime_required=0" % ADDON_ID, xbmc.LOGWARNING)
                    return True
            else:
                modal_wait_started = None
        else:
            stable_active = 0
            modal_wait_started = None
            notice_r91 = "missing" if not installed else "inactive"
            if notice_r91 != notice_state_r91:
                notice_state_r91 = notice_r91
                _show_pkm_skin_notice_v1917(notice_r91)

        if monitor.waitForAbort(0.10 if gate_waited_r91 < 15.0 else 0.50):
            return False
    return False

try:
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2276 skin_runtime_ready_gate_no_estuary_font_fallback_windowxml" % ADDON_ID, xbmc.LOGINFO)
except Exception:
    pass

try:
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2702 R91 skin_gate_no_timeout_stop_wait_for_skin_activation_first_run_settings_handoff" % ADDON_ID, xbmc.LOGINFO)
except Exception:
    pass

def run():
    monitor = xbmc.Monitor()
    # R108: create/migrate the content source registry before any Home work.
    try:
        from resources.lib import pkm_sources as _pkm_sources_r108
        _pkm_sources_r108.ensure_migrated(reason="service_start")
        from resources.lib import pkm_kodi_source as _pkm_kodi_source_r108
        _pkm_kodi_source_r108.start_background(stop_event=_SERVICE_STOP)
    except Exception as _src_r108_exc:
        _pkm_log_v2584('[plugin.video.km] PKM_SOURCES_R108_START_FAILED %s' % _src_r108_exc, xbmc.LOGWARNING)
    # PKM_UHD_STABILITY_U1: actor addon may exist on disk without its service
    # having started. One non-blocking recovery attempt; Home never waits.
    try:
        from resources.lib import pkm_actor_bootstrap_u1
        pkm_actor_bootstrap_u1.start_async()
    except Exception as _actor_boot_u1_exc:
        _pkm_log_v2584('[plugin.video.km] ACTOR_BOOTSTRAP_U1_FAILED %s' % _actor_boot_u1_exc, xbmc.LOGWARNING)


    # PKM_UHD3_PERF_DIAG_V2600_BEGIN
    # Android: retire the old 200 ms poller and use the event + 1 s sampler.
    # Desktop keeps the legacy diagnostic helper for comparison.
    try:
        from resources.lib import pkm_uhd_diag_v2600 as _pkm_uhd_diag_v2600
        _pkm_uhd_diag_v2600.start_sampler(interval_sec=1.0)
        _pkm_log_v2584('[plugin.video.km] PKM_UHD_DIAG_V2600_STARTED sampler_ms=1000 event_driven=1 old_200ms_android=0', xbmc.LOGINFO)
    except Exception as _pkm_diag2600_exc:
        try:
            _pkm_log_v2584('[plugin.video.km] PKM_UHD_DIAG_V2600_START_FAILED: %s' % _pkm_diag2600_exc, xbmc.LOGERROR)
        except Exception:
            pass
    try:
        if not xbmc.getCondVisibility('System.Platform.Android'):
            from resources.lib import pkm_perf_diag_inline as _pkm_perf_diag_inline
            _pkm_perf_diag_inline.start()
            _pkm_log_v2584('[plugin.video.km] PKM_UHD3_PERF_DIAG_V5_EXTENDED_STARTED desktop_only=1', xbmc.LOGINFO)
        else:
            _pkm_log_v2584('[plugin.video.km] PKM_UHD3_PERF_DIAG_V5_EXTENDED_DISABLED_V2600 platform=android reason=avoid_200ms_polling', xbmc.LOGINFO)
    except Exception as _pkm_diag_exc:
        try:
            _pkm_log_v2584('[plugin.video.km] PKM_UHD3_PERF_DIAG_V5_EXTENDED_START_FAILED: %s' % _pkm_diag_exc, xbmc.LOGERROR)
        except Exception:
            pass
    # PKM_UHD3_PERF_DIAG_V2600_END

    try:
        _SERVICE_STOP.clear()
        _SERVICE_STOP_LOGGED[0] = False
    except Exception:
        pass
    _set_service_window_stopping(False)
    _set_service_stopping(False)
    try:
        _service_win_v2151 = xbmcgui.Window(10000)
        _service_win_v2151.setProperty("PlexKM.ServiceRunningV2151", "1")
        _service_win_v2151.clearProperty("PlexKM.ServiceFullResetStoppedV2151")
    except Exception:
        pass
    if not _wait_for_pkm_skin_active_v1917(monitor):
        _request_service_stop("skin_install_gate_abort_v1917")
        return
    _pkm_log_v2584(
        "[%s] PKM_PATCH_ACTIVE v1917 bidirectional_install_skin_active_gate" % ADDON_ID,
        xbmc.LOGINFO,
    )
    # v1745: retire the v1742-v1744 sync-to-home cover transaction completely.
    # The v1744 log ended abruptly immediately after HomeFlowApplied, indicating
    # a native Kodi window-stack crash rather than a normal application exit.
    # Clear every legacy transition property before any window can evaluate it.
    try:
        _transition_win_v1745 = xbmcgui.Window(10000)
        for _transition_key_v1745 in (
            "PlexKM.Home.ReturnMetaPendingV1750",
            "PlexKM.Home.ReturnMetaReasonV1750",
            "PlexKM.Settings.SyncHandoffCoverV1747",
            "PlexKM.Sync.HandoffProbeV1747",
            "PlexKM.Sync.ExitToHomeV1744",
            "PlexKM.Home.ReturnCoverV1744",
            "PlexKM.HomeTransition.HomeFlowAppliedV1744",
            "PlexKM.Sync.ExitToHomeV1743",
            "PlexKM.HomeTransition.ActiveV1743",
            "PlexKM.HomeTransition.HomeFlowAppliedV1743",
            "PlexKM.Sync.ExitToHomeV1742",
            "PlexKM.HomeTransition.ActiveV1742",
            "PlexKM.HomeTransition.HomeFlowAppliedV1742",
        ):
            _transition_win_v1745.clearProperty(_transition_key_v1745)
        _pkm_log_v2584("[%s] PKM_SYNC_HOME_TRANSITION_STATE_CLEARED_V1745 mode=direct_no_fade_no_cover" % ADDON_ID, xbmc.LOGINFO)
    except Exception:
        pass
    _ensure_kodi_splash_disabled_v1737(reason="service_startup_v1737")
    _ensure_ui_sounds_off_once_r275()
    if pkm_spinner:
        try:
            pkm_spinner.apply_global_properties(reason="service_startup_v1636")
        except Exception:
            pass
    _register_subtitle_font_on_startup(reason="service_startup_v1099")
    _install_seek_quick_keymap(reason="service_startup_v1379")
    # R140: PKM 공통 링 스피너 색 단계 (흰 -> 노랑 -> 주황)
    try:
        from resources.lib import pkm_spinner_stage_r140
        pkm_spinner_stage_r140.start()
    except Exception:
        pass
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1937 plezy_nonseek_shared_artwork_scheduler_request_coalescing_row_ahead" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1938 playback_return_resume_no_spinner_exit_focus_cast_inset" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1939 cast_true_circle_scaled_diffuse_and_playback_return_info_cover_handshake" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1940 playback_video_surface_immediate_opening_spinner_clear" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1941 playback_opening_spinner_delayed_only_when_needed_450ms" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1943 videoosd_enter_no_pause_idle3s_smooth_close_and_quit_fade" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1944 native_osd_enter_play_focus_one_shot_idle_close_fast_info_return_quit_black_hold" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1945 native_osd_open_select_leak_guard_child_dialog_overlay_hold" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1946 videoosd_native_second_enter_playpause_no_python_cold_load_diagnosis" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1947 videoosd_native_second_enter_single_autoclose_owner_cold_preload_child_overlay" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1737 disable_kodi_core_splash_next_launch" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1738 recommend_benchmark_timing_logs" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1739 info_cast_first_paint_and_sync_confirm_action_fix" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1740 sync_completion_main_thread_modal_root_fix" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1741 completion_fade_full_progress_quickmode_group" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1745 sync_home_direct_no_fade_no_cover_native_crash_rollback" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1747 cached_and_uncached_sync_progress_single_handoff_window_trace" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1748 library_selection_focus_restore_after_remove_confirm" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1749 home_return_wait_menu_and_first_meta_commit" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1750 home_return_focus_single_apply_meta_async_no_search_snapback" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1752 library_sync_live_home_section_refresh_before_focus" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1753 library_operation_completion_confirm_then_home" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1754 library_completion_modal_before_return_and_atomic_home_sidebar_apply_spinner" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1756 home_row_control_readiness_root_fix_no_false_75_percent_wait" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1757 home_widgets_atomic_precompose_and_remove_legacy_home_wall_fallback" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1758 sidebar_content_reverse_slide_sync_no_overlap" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1759 sidebar_expand_delayed_reveal_home_scene_fast_clear_no_overlap" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1760 search_best_home_poster_geometry_compact_more_labels_info_open_before_search_reset" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1761 search_focus_home_style_thin_frame_six_columns_compact_labels" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1765 search_view_explicit_top_layout_centered_focus_gray_best_card" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1762 search_all_posters_focus_enlarge_exact_home_best_geometry_next_row_peek" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1763 search_scope_movie_default_tvshow_all_tabs" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1766 search_scope_single_toggle_top_compact_center_focus_layout" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1767 search_best_poster_lowered_center_focus_safe_label_gap" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1768 search_more_label_raise_and_compact_poster_title_gap", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1769 search_more_label_lower_and_second_row_viewport_to_screen_bottom", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1770 search_more_title_clip_normal_focus_only_marquee", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1771 search_info_action_select_root_fix_best_label_raise_more_label_lower", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1772 search_info_preserve_explicit_listitem_root_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1773 search_info_fast_open_and_back_restore_search", xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1774 search_info_fast_cast_names_without_image_gate" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1775 sqlite_wal_busy_timeout_and_tv_chosung_scope_sql" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1776 service_startup_logger_nameerror_fix" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1778 search_info_cast_local_cache_root_and_search_back_snapshot" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1777 search_info_background_cast_photo_publish" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1783 search_cast_latest_query_cancel_four_workers_short_speculative_timeout" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1784 search_best_cast_exclusive_first_lane" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1791 sidebar_swap_frame_settle_tv_info_nonblocking_episode_local_visible_atomic", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1793 section_poster_foreground_hidden_bank_no_placeholder_atomic", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1794 section_readiness_timeout_safe_fallback_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1795 section_ui_publish_gate_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1796 section_ui_wait_gate_all_hidden_bank_rebuilds", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1797 section_ui_wait_gate_render_invariant_movie_early_return", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1798 section_gate_visibility_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1799 section_home_genre_parity_from_local_index", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1801 universal_genre_inheritance_startup_integrity_restore", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1802 remaining_time_badge_opaque_black", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1803 remaining_time_badge_dynamic_width_right_padding", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1805 tv_episode_info_remaining_time_badge", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1806 tv_episode_remaining_badge_contiguous_dynamic_layout", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1808 tv_episode_remaining_badge_top236_baseline_align", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1809 episode_info_home_metadata_row_parity", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1810 episode_info_actual_rail_canonical_metadata_row", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1812 episode_info_home_canonical_row_skin_binding", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1813 section_prewarm_foreground_cooperative_pause_resume", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1811 episode_rail_restore_keep_info_metadata_parity", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1804 universal_home_section_metadata_parity_content_rating_imdb", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1816 canonical_duplicate_movie_metadata_parity", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1817 startup_canonical_movie_bulk_index_no_per_item_sql", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1818 added_library_confirm_default_sync_focus", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1819 library_selection_sync_later_transactional_rollback", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1975 startup_state_matrix_read_only_no_modal", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1978 operational_failopen_to_pkm_home", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1983 authoritative_initial_and_reselected_library_merge_sync", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1984 live_home_connection_reset_atomic_empty_surface", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1985 transactional_library_activation_cancel_empty_home", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1822 complete_category_tab_sort_dropdown_cine21_watcha_imdb", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1824 category_to_library_ready_wall_reuse_syntax_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1832 category_reentry_collapse_filter_sort_count_header", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1834 category_filter_section_owner_destination_tab_restore", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1835 post_reveal_new_movie_episode_notice_added_only", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1836 certification_never_imdb_fallback_and_sidebar_genre_reset", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1837 large_library_focus_metadata_debounce_and_windowed_restore", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1838 kodi_gui_thread_safety_large_wall_crash_stop", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1839 newly_added_library_cold_gate_after_playback", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1840 sidebar_scene_nonblocking_poster_cache_and_stability_audit", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1841 android_lifecycle_atomic_scene_stability", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1842 startup_zero_delay_waitforabort_deadlock_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1843 infotagvideo_explicit_setters_no_listitem_setinfo", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1844 section_ab_bank_owner_guard_forced_rebuild_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1848 startup_logo_then_segmented_real_progress_no_spinner", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1850 sidebar_kodi_xml_single_focus_owner_no_python_runtime_recovery", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1852 section_tabs_kodi_focus_then_click_no_onfocus_mutation", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1855 inline_sort_dropdown_below_button_no_modal", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1856 inline_sort_dropdown_compact_right_aligned", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1858 inline_sort_dropdown_top_layer_enter_apply_restore", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1860 inline_sort_fixed_kodi_buttons_exact_apply_real_version_bump", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1861 sort_bitrate_full_label_fixed_white_bar_width", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1862 first_viewport_local_poster_gate_library_and_recommend", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1863 library_wall_transition_gate_and_xml_sidebar_return_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1864 sidebar_entry_preserve_current_library_mode", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1865 library_first12_foreground_local_then_down_chunk", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1866 library_first12_exact_texture_atomic_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1867 library_first12_progressive_late_fill_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1868 library_first12_atomic_scene_cache_append_progressive_visual_superseded_v1883", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1869 library_wall_append_preserve_native_column_after_down", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1870 tv_library_season_folders_open_selected_episode_info", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1871 tv_season_first12_cached_prewarm_fast_jpeg_draft_no_worker_storm", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1872 service_startup_logger_nameerror_fix", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1873 category_filtered_wall_sidebar_reentry_preserve_until_sidebar_selection_change", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1874 startup_progress_lower_right_x85_y91", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1875 search_selected_cast_direct_lane_fast_known_thumbs", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1876 cast_missing_thumb_local_reuse_no_plex_people_network", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1877 search_visible_poster_priority_no_lower_cast_storm", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1878 search_cast_focus_settled_only_no_missing_portrait_scan", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1879 search_small_transcode_visible_cache_exact_incremental_index", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1880 startup_progress_original_center_logo_width_440", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1881 search_poster_visible_texture_complete_timing", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1882 cast_placeholder_bg_lighter_focus_scale", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1883 global_busy_single_broker_tv_info_no_cover_no_mask_local_first_search_index_movie_show_only_actor_actual_focus_debounce_startup_bar_y634", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1884 global_busy_single_modal_xml_input_owner_tv_transaction_restore_playback_return_atomic", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1885 global_busy_active_window_renderer_no_external_dialog_no_white_wash", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1886 tv_info_active_ab_buffer_focus_recovery_no_hidden_5712", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1887 sidebar_native_selection_content_owner_atomic_guard", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1889 startup_logo_left_to_right_gold_fill_no_bar", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1890 startup_logo_gold_fill_correct_source_bbox_visible_slices", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1891 startup_logo_linear_1pct_20ms_fill_100_slices", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1892 startup_logo_white_base_slow_smooth_gold_fill", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1893 startup_logo_native_reveal_continuous_gold_fill", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1894 startup_logo_direct_native_progress_percent_binding", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1906 sidebar_menu_refresh_latest_only_nonreentrant_ab_render_cancel_fail_closed", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1907 library_sort_meta_bounded_two_line_no_ellipsis_no_overlap", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1909 sort_button_longest_label_fixed_width_font_parity_no_ellipsis", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1910 library_title_one_line_focus_scroll_sort_meta_direct_below", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1912 wall_sort_font_title_parity_relative_time_days_under10_weeks_4weeks_month", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1915 library_rating_key_versions_keep_all_resume_progress_all_sorts", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1888 sort_dropdown_anchor_to_sort_button_sidebar_native_offset", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1822 section_category_tab_genre_cards_filtered_wall", xbmc.LOGINFO)
    try:
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1613 recommend_widgets_selected_library_pool_only_ab_v1612_unchanged" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1614 sidebar_true_ab_nonzero_render_settle_no_old_poster_flash" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1615 sidebar_true_ab_first_visit_composed_reveal_no_plate" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1616 sidebar_true_ab_movie_full_compose_bankB_nav_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1617 section_ab_canonical_20row_schema_no_silent_truncation" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1619 startup_atomic_gate_and_section_meta_bank_single_commit_no_cover" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1620 startup_once_completed_scene_cache_fast_revisit_visual_superseded_v1883" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1621 section_previous_scene_session_immutable_fast_revisit_visual_superseded_v1883" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1622 section_delayed_visual_policy_superseded_by_global_broker_v1883" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1632 playback_return_session_scene_cache_no_live_sync_rebuild" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1633 audio_top_menu_focus_same_track_no_decoder_restart" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1634 audio_tab_focus_auto_activate_up_to_tabs_down_once_no_enter" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1635 root_playback_single_http_reader_postplayback_section_atomic_no_spinner" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1636 apple_ring_spinner_shared_size_profile_small64_medium128_large256" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1637 videoosd_bidirectional_subtitle_audio_resolution_video_stream_info_menu" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1638 stream_info_runtime_fps_hdr_decoder_compact_osd_panel_round_focus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1639 info_home_rating_stack_autocollapse_localized_genre" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1640 info_movie_meta_title_gap_cine21_optical_align_summary_spacing" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1641 info_cine21_logo_left_edge_align" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1642 home_two_phase_progressive_no_reset_shared_watcha_stable_focus_cast_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1644 startup_plex_snapshot_all_sidebar_full_scene_before_reveal_runtime_updates_off_wall_poster_ahead" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1645 startup_no_cine21_post_reveal_idle_small_batch_next_start_apply" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1646 startup_atomic_release_worker_scope_fix_cursor_hidden_home_flash_block" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1647 local_home_under3s_network_and_sidebar_post_reveal_pointer_off" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1703 native_edit_physical_typing_unique_nested_dialog_parent_focus_restore" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] SERVICE_SHUTDOWN_GUARD_ACTIVE v1132" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1290 offline_skip_all_updates home_first_probe" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1314 connection_failure_hide_fanart_notice_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1315 sidebar_cached_posters_no_placeholder_fast_reveal" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1318 section_recommend_home_viewport_clip_no_tab_overlap" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1325 recent_added_desc_default" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1330 sync_detail_index_root_fix_no_info_direct_repair" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1331 inline_info_art_auth_focus_repair" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1332 info_cast_previsible_plex_cache_circle_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1333 unified_info_cast_plex_source_movie_tv" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1334 info_cast_property_scope_sync" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1335 info_open_fast_cast_background_repair" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1336 visible_focus_cast_prewarm_local_png" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1337 info_first_paint_cast_gate_no_after_popin" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1338 visible_widgets_cast_cache_no_info_gate" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1339 visible_budget_all_sections_cast_cache" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1340 priority_cast_cache_negative_queue" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1341 taste_continue_cast_priority_hq_placeholder" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1342 duplicate_resume_cast_thumb_source" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1343 continue_canonical_cast_source_single_placeholder_ring" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1344 continue_recommend_source_people_exact_thumb" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1350 cast_avatar_focus_scaled_geometry_single_source" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1351 cast_cache_legacy_geometry_reject_focus_consistent" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1352 cast_focus_ring_slightly_larger" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1353 cast_focus_ring_276_hq" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1367 info_fast_direct_playback" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1368 player_osd_title_metadata" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1369 plex_style_player_osd_title_meta" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1370 update_notice_only_when_needed" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1371 player_osd_enter_and_navigation_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1372 player_osd_dispatcher_nav_after_seek" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1373 update_notice_actual_rows_home_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1374 fullscreen_seek_restore_after_osd_nav" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1375 player_osd_real_visible_enter_seek_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1377 plex_style_seek_overlay_corrected" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1380 real_videoosd_seekbar_navigation_gold_nib" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1381 offline_connection_sidebar_settings_focus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1382 offline_settings_fast_no_network" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1383 seekbar_focus_gold_nib_on_bar_end" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1384 static_png_seekbar_nib_no_righttexture" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1385 static_png_seekbar_marker_visible_on_bar_end" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1387 seekbar_white_marker_full_baseline" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1388 seekbar_gray_marker_full_baseline" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1389 seekbar_focus_strong_yellow_option1" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1390 suppress_kodi_dialogseekbar_during_pkm_seek" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1391 native_dialogseekbar_hard_disabled" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1392 native_volume_osd_hard_disabled" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1393 seekbar_focus_color_restore_target_fill" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1394 native_busy_spinner_osd_hard_disabled" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1395 seek_target_latch_no_backtrack" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1396 fullscreen_cache_dotring_spinner" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1397 fullscreen_cache_dotring_spinner_visible_fast" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1399 fullscreen_cache_donutring_hq_path_aligned" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1401 user_spinner_frames_zip_encoding_fixed" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1402 subtitle_sample_cinema_font_ascii_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1403 subtitle_sample_cinema_no_duplicate_font" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1404 cinema_font_single_skin_ascii_source" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1405 dynamic_seek_directional_debounce_icons" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1407 discard_v1406_restore_playback_safe" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1411 playback_quiet_seek_probe_throttle" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1414 native_playback_stop_revert" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1415 native_opening_spinner_display_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1416 spinner_arc_v2_frames_replace" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1417 post_playback_sidebar_refresh" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1418 sidebar_focus_force_clear_inline_info" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1419 spinner_delay_fast_skip_hold" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1420 spinner_avstarted_fast_skip_early_started_fix" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1421 cinematic_spinner_fade_space_pause_osd" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1425 seek_coldcache_profile_fwd10_mid5_hi3_back10_no_ready_poll" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1426 osd_long_jump_30m_buttons_keep_videoosd" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1427 osd_jump_30s_range_prewarm_under3s_target" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1428 osd_jump_30s_immediate_no_prewarm_keep_short_seek_table" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1429 native_kodi_seek_actions_no_pkm_seektime" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1459 smooth_cachebar_real_bytes_tiny_pause_marker_continue_watching_respects_selected_libraries_settings_quiet_no_background_prewarm" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1456 seek_30s_requires_http_trusted_bitrate_native_playback_locked_plugin_url_resolved_for_cachebar_no_python_player_play_preserve_seek_cache_instant_visible_marker_pause_workers2_contiguous_pale_yellow_no_cache_button_seek_10s_default_30s_only_trusted_http" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1460 seek_side_menu_skin_plus_pkm_fwd30_font_match_native_seek" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1495 wall_index_right_align_clock_end_v1494_scroll_sync_dedicated_font_top205_v1492_title_order_safe_v1491_right_align_new_playback_cache_reset_info_back_native_stop_info_resume_label_left10_pause_workers3_fixed_osd_gray_info_spacing_step_menu_focus_no_play_flash_home_offline_center_confirmed_no_immediate_home_surface_step_menu_order_focus_fix_pause_workers3_seek_menu_equal_spacing_pause_start_from_preserved_cache_end_cachebar_cross_seq_monotonic_restore_main_videoosd_play_pause_fwd_collapsed_seek_menu_hq20" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1506 info_resume_threshold60_seek_fix_v1505_pass_fade" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1545 second_play_gui_thread_race_fix_playstate_refresh_deferred_clean_session_plain_native_stop" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1548 verified_resume_seek_retry_no_zero_timeline_onfocus_pos_fix_v1547_resolver_boundary" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1549 no_oninit_auto_stop_event_driven_opening_cover_no_info_flash" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1550 actual_fullscreen_back_plain_stop_no_overlap_resume_unchanged" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1553 native_resume_real_totaltime_no_service_seek" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1554 sync_commit_widget_dirty_guarantee_gui_thread_refresh_new_items" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1555 sync_widget_atomic_old_row_cover_no_blink_hidden_reentry_fallback" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1556 sidebar_widget_atomic_no_placeholder_no_fade" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1612 sidebar_true_ab_hidden_target_full_stack_crossfade" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1557 live_video_return_fade_v1505_restored_no_forced_pause_stop_after_black" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1564 videoosd_seek_round_icons_exact_pair_geometry" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1567 tv_info_field_identity_korean_season_episode_raw_episode_index" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1568 tv_episode_summary_selected_item_no_stale_fallback_body_down18" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1571 content_rating_age_only_no_cheongbul_home_info_consistent" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1572 home_genre_below_meta_summary_720px_three_lines" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1573 home_summary_real_three_line_viewport_720px_python_ellipsis" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1574 home_genre_rating_summary_reserved_vertical_slots" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1575 home_hero_left_align_title_gap_rating_slots_small_remaining_font_ring" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1576 home_remaining_font17_ring22_skin_defined" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1578 home_rating_row_down16_summary_follow" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1551 cold_different_movie_resume_seek_serialized_preread_block_spinner_until_verified" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1552 native_resume_single_fallback_seek_no_timer_retry" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_NATIVE_PLAYBACK_LOCK_V1455 rule=Info/Main playback must use PlayMedia(plugin://...action=play) + setResolvedUrl; cache/pre-read may resolve plugin URL to HTTP internally only; do_not_change_playback_to_xbmc_Player_play_or_direct_http" % ADDON_ID, xbmc.LOGINFO)
        try:
            _w = xbmcgui.Window(10000)
            _w.clearProperty("PlexKM.Playback.NativeOpening")
            _w.clearProperty("PlexKM.Playback.NativeOpening.SpinnerVisible")
            _w.clearProperty("PlexKM.Playback.NativeOpening.Pending")
            _w.clearProperty("PlexKM.Playback.NativeOpening.HoldClear")
            _w.clearProperty("PlexKM.Playback.NativeOpening.WaitResumeV1551")
            _w.clearProperty("PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551")
            _w.clearProperty("PlexKM.Playback.NativeOpening.RatingKey")
            _w.clearProperty("PlexKM.Playback.NativeOpening.Token")
            _w.clearProperty("PlexKM.Playback.NativeOpening.Source")
            _w.clearProperty("PlexKM.Playback.NativeOpening.ArmedAtMs")
            _w.clearProperty("PlexKM.Playback.NativeOpening.ShownAtMs")
            _pkm_log_v2584("[%s] PKM_V1420_CLEAR_NATIVE_OPENING_SPINNER_PROPS" % ADDON_ID, xbmc.LOGINFO)
        except Exception:
            pass
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1386 seekbar_marker_fill_no_osd_close" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1349 unified_cast_placeholder_photo_ring_geometry" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1348 cast_focus_ring_match_photo_inside" % ADDON_ID, xbmc.LOGINFO)
    except Exception:
        pass
    playback_monitor = None
    core = None
    update_flow_v2169 = None
    if pkm_update_flow_v2169:
        try:
            update_flow_v2169 = pkm_update_flow_v2169.PKMUpdateFlowV2169(
                request_service_stop=_request_service_stop,
            )
        except Exception as update_flow_exc_v2169:
            _pkm_log_v2584("[%s] PKM_UPDATE_FLOW_INIT_FAILED_V2169 err=%s" % (ADDON_ID, update_flow_exc_v2169), xbmc.LOGWARNING)

    try:
        core = _load_core()
        playback_monitor = PlexKMPlaybackMonitor(core, monitor)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2222 tv_exact_selected_episode_plex_intro_credits_next_fallback" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2223 live_part_repair_plex_next_and_pkm_confirm_style" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2224 playback_failure_back_confirm_timeout_home_recovery" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2228 preav_timeout_pkm_failure_dialog_background_playback_priority" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2229 rclone_safe_no_fixed_open_timeout_authoritative_failure_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2230 seekbar_active_target_chain_managed_pause_no_av_catchup" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2231 seekbar_small_to_big_accel_target_time_bubble" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2232 seek_single_resume_buffer_gate_opaque_stable_reveal" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2233 seek_target_white_rounded_time_chip" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2234 smaller_seek_time_chip_fast_stable_spinner_release" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2235 compact_lower_fade_episode_action_intro_ui" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2236 per_show_next_timing_compact_two_row_media_popup" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2237 plex_marker_priority_confirm_saved_strict_same_season_next" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2239 home_fanart_tinted_summary_card_full_plot_popup" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2240 summary_card_contrast_dynamic_height_back_home_focus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2245 transparent_plot_overlay_home_rating_dark_summary_focus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2246 summary_safe_3line_equal_padding_vivid_focus_native_window_no_bg_dim_all_home_rows_up" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2247 summary_gold_full_border_one_line_label_widget_stack_gap_exact_row_return" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2243 summary_popup_back_close_restore_home_no_exit" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2241 summary_card_full_three_line_height_no_clip" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2242 spinner_immediate_hide_on_playback_ready_no_visual_tail" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2248 summary_exact_widget_item_return_faint_gold_border_xml_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2249 section_all_widgets_summary_up_exact_item_return_xml_only" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2250 home_genre_async_global_property_live_publish_no_refocus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2251 home_hero_body_atomic_genre_rating_summary_single_reveal\n[plugin.video.km] PKM_PATCH_ACTIVE v2252 summary_fixed_y_reserved_genre_rating_slots\n[plugin.video.km] PKM_PATCH_ACTIVE v2253 summary_absolute_top_y348_movie_tv_common" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2254 summary_top_y360_reserved_empty_rating_movie_tv" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2255 summary_fixed_3line_height_y360_movie_tv" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2256 summary_native_exact_item_return_all_widget_rows" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2257 section_up_previous_widget_anchor_restore" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2258 episode_genre_local_show_inherit_first_paint" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2259 movie_rating_canonical_live_and_home_recent_tv_show_dedup" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2260 rating_raw_first_frame_atomic_badge_no_blink" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2261 conditional_summary_up_previous_widget_and_recent_tv_show_dedup" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2262 up_actual_visible_summary_only_no_hidden_focus" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2263 kodi_condition_square_bracket_fix_all_widget_up" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2264 home_synopsis_local_first_no_async_gate_stable_up" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2570 uhd3_home_quiet_prehome_heavy_no_post_reveal_sync" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2225 videoosd_seekbar_scrub_preview_single_native_commit" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2226 native_seek_wait_real_target_ready_spinner" % ADDON_ID, xbmc.LOGINFO)
        _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2227 next_episode_continuous_opening_spinner_seekbar_idle_autoclose_focus_nib" % ADDON_ID, xbmc.LOGINFO)

        # v1289: never block PKM Home autostart on Plex play-state pull.
        # If PMS is stopped, sync_play_state_from_plex_light() waits for the
        # /library/onDeck network timeout.  Home must open first from the local
        # DB and a fast sticky offline notice must appear independently.
        # Play-state pull is started below after Home autostart request.
        _pkm_log_v2584("[%s] STARTUP_PLAYSTATE_LIGHT_DEFERRED reason=home_first_v1289" % ADDON_ID, xbmc.LOGINFO)

        # v474: Never block PKM Home autostart on the full metadata refresh.
        # v473 ran ensure_startup_cache_ready() synchronously here.  With large TV
        # libraries that leaves the service inside STARTUP_SYNC_REFRESH for a long
        # time and _autostart_home_window() is not reached, so PKM Home never opens.
        # Startup sync remains enabled, but it is launched after Home autostart as a
        # background data task.
    except Exception as exc:
        _pkm_log_v2584("[%s] service init failed: %s" % (ADDON_ID, exc), xbmc.LOGERROR)

    # V2657 UHD3 canonical light-start: server/authority reconciliation is not
    # allowed to own the foreground startup.  Explicit server/library selection
    # flows still perform their required import transaction; normal/restart boot
    # opens the committed local DB first and maintenance happens after Home.
    _pkm_log_v2584("[%s] UHD3_CANONICAL_START_V2657 prehome_server_switch_guard=0 prehome_plex_sync=0 prehome_cache_warm=0" % ADDON_ID, xbmc.LOGINFO)

    # v096: start PlexKM Home automatically when Kodi reaches Home.
    if not _service_stopping(monitor):
        _autostart_home_window(monitor)

    # v1644: only the fast health probe remains independent.  Continue-watching
    # playstate is pulled synchronously by the opaque startup-cover pipeline so
    # Home can never be revealed from an older preload file.
    if core and not _service_stopping(monitor):
        _startup_fast_plex_probe(core, monitor, timeout_sec=1.15)

    # v474: run Plex metadata refresh in the background so Home entry is not blocked.
    if core and not _service_stopping(monitor):
        _startup_sync_background(core, monitor)

    # v921: Cine21 update is not scheduled from the Kodi runtime service.
    # Cine21 refresh must be an explicit/manual or sync-stage DB job, not a timed UI background task.

    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1686 token_auth_manual_equivalent_single_library_owner" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1697 spinner_inplace_square_fullfill_action_button_muted_border" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1699 kodi_native_settings_navigation_no_python_updown" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1692 pkm_action_buttons_full_white_box_solid_gold_focus", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1693 settings_menu_plex_spinner_only_apple_ring_size_large_medium_small", xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v1691 actionable_rows_only_home_user_square_confirm" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] WindowXML wall mode active; old Home lazy wall monitor disabled" % ADDON_ID, xbmc.LOGINFO)
    _pkm_log_v2584("[%s] PKM_PATCH_ACTIVE v2386 ratings_bridge_yields_to_home_navigation" % ADDON_ID, xbmc.LOGINFO)
    _last_update_poll = time.time()
    _poll_worker_running = [False]

    _ratings_bridge_last_poll_v2374 = 0.0
    _ratings_bridge_worker_running_v2374 = [False]

    def _start_ratings_bridge_worker_v2374():
        if _ratings_bridge_worker_running_v2374[0] or _service_stopping(monitor):
            return
        if not core or not pkm_ratings_service_bridge:
            return
        _ratings_bridge_worker_running_v2374[0] = True

        def _ratings_worker_v2374():
            try:
                if _service_stopping(monitor):
                    return
                # v2386: ratings Master imports are large local-DB writes. They
                # are optional background work and must never race initial Home
                # reveal or active widget navigation. No GUI control is touched.
                win_v2386 = xbmcgui.Window(10000)
                if win_v2386.getProperty("PlexKM.Home.StartupReadyV1619") != "1":
                    _pkm_log_v2584("[%s] RATINGS_SERVICE_BRIDGE_UI_YIELD_V2386 reason=home_not_ready action=defer_next_poll" % ADDON_ID, xbmc.LOGINFO)
                    return
                # R113: never run the Cine21/Watcha master matching while a Plex
                # library sync is writing (first install: it matched a half-filled
                # DB for ~2.5 min, doubled CPU and blocked WAL checkpoints) or
                # before the first setup is complete.  It runs on the next poll.
                try:
                    if (hasattr(core, "initial_setup_completed") and not core.initial_setup_completed()) or \
                            (hasattr(core, "is_sync_locked") and core.is_sync_locked()):
                        _pkm_log_v2584("[%s] RATINGS_SERVICE_BRIDGE_SYNC_YIELD_R113 action=defer_next_poll" % ADDON_ID, xbmc.LOGINFO)
                        return
                except Exception:
                    pass
                if monitor.waitForAbort(3.0):
                    return
                now_epoch_v2386 = int(time.time() * 1000)
                try:
                    last_action_v2386 = int(float(win_v2386.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or 0))
                except Exception:
                    last_action_v2386 = 0
                try:
                    nav_until_v2386 = int(float(win_v2386.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
                except Exception:
                    nav_until_v2386 = 0
                recent_nav_v2386 = bool(
                    (last_action_v2386 and (now_epoch_v2386 - last_action_v2386) < 6000)
                    or (nav_until_v2386 and now_epoch_v2386 < nav_until_v2386)
                )
                active_surface_v2386 = bool(
                    win_v2386.getProperty("PlexKM.Info.InlineActive") == "1"
                    or win_v2386.getProperty("PlexKM.Playback.OpeningActive") == "1"
                    or win_v2386.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                )
                try:
                    active_surface_v2386 = active_surface_v2386 or bool(xbmc.getCondVisibility("Player.HasVideo"))
                except Exception:
                    pass
                if recent_nav_v2386 or active_surface_v2386:
                    _pkm_log_v2584("[%s] RATINGS_SERVICE_BRIDGE_UI_YIELD_V2386 reason=%s action=defer_next_poll" % (
                        ADDON_ID, "recent_navigation" if recent_nav_v2386 else "info_or_playback"
                    ), xbmc.LOGINFO)
                    return
                win_v2386.setProperty("PlexKM.RatingsBridge.ActiveV2386", "1")
                try:
                    pkm_ratings_service_bridge.sync_if_needed(core)
                finally:
                    win_v2386.clearProperty("PlexKM.RatingsBridge.ActiveV2386")
            except Exception as exc_v2374:
                _pkm_log_v2584("[%s] RATINGS_SERVICE_BRIDGE_WORKER_FAILED_V2374 err=%s" % (
                    ADDON_ID, exc_v2374
                ), xbmc.LOGWARNING)
            finally:
                _ratings_bridge_worker_running_v2374[0] = False

        t_v2374 = _PKMServiceThreadV2151(
            target=_ratings_worker_v2374,
            name="PKMRatingsMasterBridge",
            daemon=True
        )
        t_v2374.daemon = True
        t_v2374.start()

    def _start_poll_worker():
        if _poll_worker_running[0] or _service_stopping(monitor):
            return
        _poll_worker_running[0] = True

        def _worker():
            try:
                if not _service_stopping(monitor):
                    _poll_incremental_updates(core, monitor, min_interval_sec=120)
            finally:
                _poll_worker_running[0] = False

        t = _PKMServiceThreadV2151(target=_worker, name="PlexKMServicePoll", daemon=True)
        t.daemon = True
        t.start()

    _update_home_ready_seen_v2584 = 0
    _update_defer_logged_v2584 = False
    while not monitor.abortRequested() and not _service_stopping(monitor):
        if update_flow_v2169:
            try:
                _allow_update_tick_v2584 = False
                _home_update_v2584 = xbmcgui.Window(10000)
                _now_update_v2584 = int(time.time() * 1000)

                # PKM_PATCH_ACTIVE v2590 startup_update_gate_tick_immediate
                # V2584 defers normal background update discovery until Home has
                # been visible for 10s and idle for 5s.  Keep that policy for
                # established runs, but NEVER defer while the first-run/update
                # startup gate itself owns UpdateBlockV2375.  Otherwise Home waits
                # for the updater while the updater waits for Home -> deadlock.
                _startup_update_gate_active_v2590 = bool(
                    _home_update_v2584.getProperty("PlexKM.Startup.UpdateBlockV2375") == "1"
                )
                if _startup_update_gate_active_v2590:
                    if _home_update_v2584.getProperty("PlexKM.Startup.UpdateGateTickLoggedV2590") != "1":
                        _home_update_v2584.setProperty("PlexKM.Startup.UpdateGateTickLoggedV2590", "1")
                        _pkm_log_v2584(
                            "[%s] STARTUP_UPDATE_GATE_TICK_V2590 phase=%s home_ready=%s immediate=1 reason=break_prehome_update_deadlock" % (
                                ADDON_ID,
                                _home_update_v2584.getProperty("PlexKM.Startup.UpdatePhaseV2375") or "unknown",
                                _home_update_v2584.getProperty("PlexKM.Home.StartupReadyV1619") or "0",
                            ),
                            xbmc.LOGINFO,
                        )
                    if update_flow_v2169.tick(monitor=monitor):
                        break
                else:
                    if _home_update_v2584.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                        if not _update_home_ready_seen_v2584:
                            _update_home_ready_seen_v2584 = _now_update_v2584
                        try:
                            _last_update_input_v2584 = int(float(_home_update_v2584.getProperty("PlexKM.Home.LastUserActionEpochMsV2386") or "0"))
                        except Exception:
                            _last_update_input_v2584 = 0
                        _idle_update_v2584 = (_now_update_v2584 - _last_update_input_v2584) if _last_update_input_v2584 > 0 else (_now_update_v2584 - _update_home_ready_seen_v2584)
                        _allow_update_tick_v2584 = bool(
                            (_now_update_v2584 - _update_home_ready_seen_v2584) >= 10000
                            and _idle_update_v2584 >= 5000
                            and _home_update_v2584.getProperty("PlexKM.WallRapidScrollV2581") != "1"
                        )
                    # PKM_RECOVERY_R1: once the 12s logo gate fails open, a pending
                    # update check/result MUST continue to be serviced. Otherwise
                    # input activity can postpone the confirmation until next Kodi run.
                    # PKM_IDLE_HOME_UPDATE_RECHECK
                    # Recheck Git at most once per 10 minutes when the PKM Home
                    # has been idle; network work stays on updater's worker thread.
                    # The updater refuses to reset an explicit "Later" decision.
                    if _allow_update_tick_v2584:
                        update_flow_v2169.pkm_maybe_recheck_at_idle_home(interval_sec=600)
                    # R69: Home has not appeared yet (stuck or very slow start).
                    # Keep looking for a newer PKM on Git so a published fix can
                    # still reach this device instead of waiting for Home.
                    if _home_update_v2584.getProperty("PlexKM.Home.StartupReadyV1619") != "1":
                        try:
                            update_flow_v2169.pkm_maybe_recheck_while_startup_stuck_r69()
                        except Exception as stuck_exc_r69:
                            _pkm_log_v2584("[%s] PKM_UPDATE_STUCK_RECHECK_FAILED_R69 err=%s" % (ADDON_ID, stuck_exc_r69), xbmc.LOGWARNING)
                    _update_decision_pending_r1 = bool(
                        not update_flow_v2169.deferred_this_run
                        and not update_flow_v2169.finished
                    )
                    if _allow_update_tick_v2584 or _update_decision_pending_r1:
                        if update_flow_v2169.tick(monitor=monitor):
                            break
                    elif not _update_defer_logged_v2584:
                        _update_defer_logged_v2584 = True
                        _pkm_log_v2584("[%s] UHD3_UPDATE_TICK_DEFER_V2584 home_first=1 min_after_ready_ms=10000 min_idle_ms=5000" % ADDON_ID, xbmc.LOGINFO)
            except Exception as update_flow_exc_v2169:
                _pkm_log_v2584("[%s] PKM_UPDATE_FLOW_TICK_FAILED_V2169 err=%s" % (ADDON_ID, update_flow_exc_v2169), xbmc.LOGWARNING)
        seek_quick_active = False
        try:
            if playback_monitor:
                playback_monitor.tick()
        except Exception as exc:
            _pkm_log_v2584("[%s] playback monitor tick failed: %s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        try:
            if pkm_seek_quick:
                seek_quick_active = bool(pkm_seek_quick.service_tick(monitor))
        except Exception as exc:
            _pkm_log_v2584("[%s][seek_quick] PKM_SEEK_SERVICE_TICK_FAILED: %s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        try:
            now = time.time()
            if core and (now - _last_update_poll) >= 120:
                _last_update_poll = now
                _start_poll_worker()
        except Exception as exc:
            _pkm_log_v2584("[%s] startup update poll failed: %s" % (ADDON_ID, exc), xbmc.LOGWARNING)
        try:
            now_v2374 = time.time()
            if core and pkm_ratings_service_bridge and (now_v2374 - _ratings_bridge_last_poll_v2374) >= 30:
                _ratings_bridge_last_poll_v2374 = now_v2374
                _start_ratings_bridge_worker_v2374()
        except Exception as exc_v2374:
            _pkm_log_v2584("[%s] ratings bridge poll failed v2374: %s" % (ADDON_ID, exc_v2374), xbmc.LOGWARNING)
        wait_interval = 0.05 if seek_quick_active else 0.25
        if monitor.waitForAbort(wait_interval):
            _request_service_stop("monitor_abort")
            break

    _request_service_stop("run_exit")
    try:
        if playback_monitor:
            playback_monitor.shutdown_fast()
    except Exception:
        pass
    try:
        _service_win_v2151 = xbmcgui.Window(10000)
        full_reset_v2151 = (_service_win_v2151.getProperty("PlexKM.FullResetInProgressV2150") == "1"
                            or _service_win_v2151.getProperty("PlexKM.FullResetInProgressV2149") == "1")
    except Exception:
        full_reset_v2151 = False
    service_drain_ok_v2151 = True
    if full_reset_v2151:
        service_drain_ok_v2151 = _service_worker_drain_v2151(timeout_ms=20000)
    try:
        _service_win_v2151 = xbmcgui.Window(10000)
        _service_win_v2151.clearProperty("PlexKM.ServiceRunningV2151")
        _service_win_v2151.setProperty("PlexKM.ServiceFullResetStoppedV2151", "1" if (full_reset_v2151 and service_drain_ok_v2151) else "")
    except Exception:
        pass
    # R120c: pending threading.Timer objects (e.g. the 600 s search-index text
    # release) kept the interpreter alive past Kodi's 5 s deadline; Kodi then
    # killed the script and the Windows exit hung after "Unloaded skin".
    # Cancel every pending timer, then give the background loops (which watch
    # the closing event) up to 2 s to return.
    try:
        _cancelled_r120 = 0
        for _t_r120 in list(threading.enumerate()):
            if isinstance(_t_r120, threading.Timer) and _t_r120.is_alive():
                _t_r120.cancel()
                _cancelled_r120 += 1
        _deadline_r120 = time.time() + 2.0
        for _t_r120 in list(threading.enumerate()):
            if _t_r120 is threading.current_thread() or not _t_r120.is_alive():
                continue
            _left_r120 = _deadline_r120 - time.time()
            if _left_r120 <= 0:
                break
            if isinstance(_t_r120, threading.Timer) or str(_t_r120.name).startswith(("PKMPosterBackfillR118", "PKMNavFlagJanitorR118", "PKMUHDDiagV2600")):
                _t_r120.join(_left_r120)
        _pkm_log_v2584("[%s] SERVICE_EXIT_TIMER_CANCEL_R120 cancelled=%d" % (ADDON_ID, _cancelled_r120), xbmc.LOGINFO)
    except Exception:
        pass
    # PKM_SHIELD_POSTLOG_EXIT_DIAGNOSTIC
    # Report active threads before Kodi's five-second service shutdown deadline.
    # No blocking join and no forced close of Plex/DB transactions.
    try:
        remaining = [t.name for t in threading.enumerate()
                     if t is not threading.current_thread() and t.is_alive()]
        _pkm_log_v2584("[%s] SERVICE_EXIT_THREAD_AUDIT remaining=%d names=%s" % (
            ADDON_ID, len(remaining), ",".join(remaining[:16])
        ), xbmc.LOGINFO)
    except Exception:
        pass
    try:
        _pkm_log_v2584("[%s] SERVICE_STOP_DONE quick_exit=1 full_reset=%d drain_ok=%d" % (ADDON_ID, 1 if full_reset_v2151 else 0, 1 if service_drain_ok_v2151 else 0), xbmc.LOGINFO)
    except Exception:
        pass


if __name__ == "__main__":
    run()

try:
    import xbmc
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1347 cast_focus_ring_inside_placeholder', xbmc.LOGINFO)
except Exception:
    pass


try:
    import xbmc
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1579 home_rating_dynamic_full_cine21_watcha_imdb', xbmc.LOGINFO)
except Exception:
    pass


try:
    import xbmc
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1580 home_rating_existing_icons_dynamic_segments', xbmc.LOGINFO)
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1582 cine21_match_test_full_scores_clear_status_labels', xbmc.LOGINFO)
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1583 cine21_status_simple_vertical_four_values', xbmc.LOGINFO)
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1584 cine21_match_test_left_shift_full_expert_label', xbmc.LOGINFO)
    _pkm_log_v2584('[plugin.video.km] PKM_PATCH_ACTIVE v1587 external_rating_hierarchy_unified_provider_menus_strict_build_filenames', xbmc.LOGINFO)
except Exception:
    pass

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1626 videoosd_screen_mode_cycle_center_toast_no_more", xbmc.LOGINFO)
_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1628 view_mode_labels_explicit_no_ellipsis", xbmc.LOGINFO)

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1627 videoosd_cycle_current_only_keep_pkm_viewmode_and_all_media_default", xbmc.LOGINFO)

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1779 search_info_back_topmost_owner_restore_search", xbmc.LOGINFO)

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1780 search_info_use_home_cast_first_paint_path", xbmc.LOGINFO)
_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1781 search_results_idle_cast_prewarm_nonblocking_info_open", xbmc.LOGINFO)

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1782 search_visible_cast_prewarm_actual_priority_queue", xbmc.LOGINFO)

_pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1785 search_best_direct_lane_home_info_isolation", xbmc.LOGINFO)


try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1788 episode_info_atomic_thumb_bank_and_diagnostics", xbmc.LOGINFO)
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1789 episode_exact_count_no_fixed_placeholder_and_sidebar_first_row_texture_prewarm", xbmc.LOGINFO)
except Exception:
    pass

# v1790 dynamic library scene reconcile

try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1792 dynamic_sidebar_viewport_texture_warm_and_tv_cast_after_rows", xbmc.LOGINFO)
except Exception:
    pass
try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v1911 tv_show_sort_three_line_relative_hours_no_ellipsis", xbmc.LOGINFO)
except Exception:
    pass



try:
    _pkm_log_v2584("[plugin.video.km] PKM_PATCH_ACTIVE v2267 synopsis_absolute_single_surface_no_widget_label_overlap", xbmc.LOGINFO)
except Exception:
    pass
