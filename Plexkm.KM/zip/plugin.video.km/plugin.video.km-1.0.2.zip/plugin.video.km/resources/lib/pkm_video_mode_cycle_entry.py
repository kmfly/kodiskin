# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import traceback
import xbmc

ADDON_ID = "plugin.video.km"


def main():
    try:
        import pkm_video_select
        pkm_video_select.cycle_view_mode(show_toast=True)
    except Exception:
        xbmc.log("[%s][video_mode_cycle] failed\n%s" % (ADDON_ID, traceback.format_exc()), xbmc.LOGERROR)


if __name__ == "__main__":
    main()
