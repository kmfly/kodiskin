# -*- coding: utf-8 -*-
"""Low-noise, window-scoped focus/action diagnostics for PKM v1961.

The v1956 tracer queried a single global list of control ids against every
WindowXML/Dialog instance. Kodi logs "Non-Existent Control" before Python can
catch the exception, so that approach polluted logs and could obscure the real
focus transition.  v1961 only queries controls declared for the current class.
Unknown classes are still traced, but only their focus id and active window are
recorded.
"""
import json
import threading
import time
import weakref

import xbmc
import xbmcgui

PREFIX = "[plugin.video.km][FOCUS_TRACE_V1961]"
# v2385: full focus auditing probes many controls and serializes a large JSON
# object on every key/focus callback. Keep that diagnostic available, but make
# it opt-in so production widget navigation has zero audit work.
FOCUS_AUDIT_ENABLE_PROP_V2385 = "PlexKM.Debug.FocusAudit"

# Only ids that actually belong to each WindowXML/Dialog class are inspected.
# Keep this conservative: missing an optional diagnostic field is safer than
# asking Kodi for a control that does not belong to the window.
CLASS_CONTROLS = {
    "PlexKMHomeWindow": (
        9000, 9001, 5001, 5002, 5003, 5004, 5005, 5006, 5007, 5008, 5009,
        5711, 5712, 5713, 5721, 5722, 5724, 5725, 5726,
        6100, 6110, 6210, 6220, 6310, 6320, 6330,
        8410, 8610, 9410, 9420, 9430, 9440,
    ),
    "PlexKMHomeExitConfirmDialog": (300, 301),
    "PKMProgressDialog": (100, 200, 201, 300),
    "PKMSyncProgressDialog": (100, 200, 201, 300),
    "PKMTokenImportDialog": (100, 200, 201, 202, 203, 300, 301),
    "PKMSubtitleSelectDialog": (100, 200, 300, 400, 500, 600),
    "PKMAudioSelectDialog": (100, 200, 300, 400, 500, 600),
    "PKMVideoSelectDialog": (100, 200, 300, 400, 500, 600),
}

PROPS = (
    "PlexKM.Info.InlineActive", "PlexKM.Info.IsTV", "PlexKM.Info.TVMode", "PlexKM.Info.Type",
    "PlexKM.LibraryMode", "PlexKM.Window.IsHome", "PlexKM.Search.Active",
    "PlexKM.Playback.ReturnInline.Pending", "PlexKM.Playback.Active",
    "PlexKM.Sync.Active", "PlexKM.Focus.MenuReadyV1954",
)


def _safe_focus(win):
    if win is None:
        return -1
    try:
        return int(win.getFocusId())
    except Exception:
        return -1


def _safe_selected(win, cid):
    """Read list position only for an id known to belong to this window."""
    try:
        control = win.getControl(int(cid))
    except Exception:
        return -1, -1
    try:
        pos = int(control.getSelectedPosition())
    except Exception:
        pos = -1
    try:
        size = int(control.size())
    except Exception:
        size = -1
    return pos, size


def _visible(cid):
    try:
        return bool(xbmc.getCondVisibility("Control.IsVisible(%d)" % int(cid)))
    except Exception:
        return False


def _enabled(cid):
    try:
        return bool(xbmc.getCondVisibility("Control.IsEnabled(%d)" % int(cid)))
    except Exception:
        return False


def _props():
    out = {}
    try:
        window = xbmcgui.Window(10000)
        for key in PROPS:
            value = window.getProperty(key)
            if value:
                out[key] = value
    except Exception:
        pass
    return out


def _class_name(win, extra):
    supplied = extra.get("class_name") or extra.get("tag")
    if supplied:
        return str(supplied)
    try:
        return win.__class__.__name__ if win is not None else "Global"
    except Exception:
        return "Unknown"


def _controls_for(win, extra):
    name = _class_name(win, extra)
    # Exact class first. For subclasses/legacy names, use conservative tokens.
    if name in CLASS_CONTROLS:
        return CLASS_CONTROLS[name]
    lower = name.lower()
    if "exit" in lower and "confirm" in lower:
        return (300, 301)
    if "homewindow" in lower:
        return CLASS_CONTROLS["PlexKMHomeWindow"]
    # Unknown dialogs: never probe arbitrary ids.
    return ()


def _audit_enabled_v2385():
    try:
        return str(xbmcgui.Window(10000).getProperty(FOCUS_AUDIT_ENABLE_PROP_V2385) or "").strip() == "1"
    except Exception:
        return False


def audit_event(win, event, **extra):
    # v2385: no Control.IsVisible/IsEnabled/list-position probes and no JSON
    # serialization during normal navigation. Enable explicitly only for a
    # diagnostic session by setting PlexKM.Debug.FocusAudit=1 on Window(10000).
    if not _audit_enabled_v2385():
        return
    try:
        focus = _safe_focus(win)
        try:
            active = int(xbmcgui.getCurrentWindowId())
        except Exception:
            active = -1

        controls = {}
        known_ids = _controls_for(win, extra)
        for cid in known_ids:
            visible = _visible(cid)
            if cid != focus and not visible:
                continue
            pos, size = _safe_selected(win, cid)
            controls[str(cid)] = {
                "v": int(visible),
                "e": int(_enabled(cid)),
                "p": pos,
                "n": size,
            }

        payload = {
            "event": str(event),
            "focus": focus,
            "active_window": active,
            "window_class": _class_name(win, extra),
            "controls": controls,
            "props": _props(),
        }
        payload.update(extra)
        xbmc.log(PREFIX + " " + json.dumps(payload, ensure_ascii=False, sort_keys=True), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(PREFIX + " audit_error event=%s error=%s" % (event, exc), xbmc.LOGERROR)




def start_focus_monitor(win, tag):
    """Continuous focus polling removed.

    The diagnostic worker survived after modal dialogs had closed and kept the
    owning default.py interpreter alive during Kodi shutdown. One-shot
    audit_event() calls remain available, but no background monitor thread is
    created.
    """
    return




# v2700: focus safety net.  When focus is lost (no focused control, a stale
# startup sink, or a focused control that is no longer visible) every key is
# swallowed and the user cannot tell where focus is.  On the next navigation
# key the window moves focus back to where it belongs.
NAV_ACTIONS_V2700 = (1, 2, 3, 4, 5, 6, 7)
_LAST_RECOVER_V2700 = {}


def _ctrl_visible_v2700(cid):
    try:
        return bool(xbmc.getCondVisibility("Control.IsVisible(%d)" % int(cid)))
    except Exception:
        return True


def ensure_focus(win, action_id, preferred, check_visible=True, stale=(), tag=""):
    """Return True when focus had been lost and was restored to the first
    usable id in ``preferred``.  Cheap: one getFocusId() per navigation key."""
    try:
        if int(action_id) not in NAV_ACTIONS_V2700:
            return False
    except Exception:
        return False
    try:
        fid = int(win.getFocusId())
    except Exception:
        fid = 0
    lost = fid <= 0 or fid in stale
    if not lost and check_visible and fid not in preferred:
        lost = not _ctrl_visible_v2700(fid)
    if not lost:
        return False
    now = time.time()
    key = id(win)
    if now - _LAST_RECOVER_V2700.get(key, 0.0) < 0.25:
        return False
    _LAST_RECOVER_V2700[key] = now
    for cid in preferred:
        try:
            if check_visible and not _ctrl_visible_v2700(cid):
                continue
            win.setFocusId(int(cid))
            xbmc.log("[plugin.video.km] FOCUS_SAFETY_NET_V2700 tag=%s lost_focus=%s restored=%s action=%s" % (
                tag, fid, cid, action_id), xbmc.LOGINFO)
            return True
        except Exception:
            continue
    return False
