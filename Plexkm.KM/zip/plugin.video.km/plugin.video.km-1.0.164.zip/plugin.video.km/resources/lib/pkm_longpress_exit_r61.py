# -*- coding: utf-8 -*-
"""R61: long-press Back exits Kodi from any screen.

Bound by the PKM keymap (<global> ... mod="longpress").  A short Back keeps
its normal per-window behaviour.  When a video is playing it is stopped first
so the PKM service can save the resume position, then the shared PKM 3-2-1
exit countdown runs (pkm_kodi_exit_v2171).
"""
from __future__ import absolute_import, unicode_literals

import sys
import time

import xbmc
import xbmcgui

ADDON_ID = "plugin.video.km"


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _source():
    for arg in sys.argv[1:]:
        text = str(arg or "")
        if text.startswith("source="):
            return text.split("=", 1)[1]
    return "unknown"


def main():
    source = _source()
    win = xbmcgui.Window(10000)
    if win.getProperty("PlexKM.KodiExit.CountdownActiveV2171") == "1":
        _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=countdown_active" % source)
        return
    try:
        if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
            _log("LONGPRESS_EXIT_SKIP_R61 source=%s reason=virtual_keyboard" % source)
            return
    except Exception:
        pass
    _log("LONGPRESS_EXIT_BEGIN_R61 source=%s" % source)
    player = xbmc.Player()
    try:
        playing = bool(player.isPlaying())
    except Exception:
        playing = False
    if playing:
        try:
            player.stop()
        except Exception:
            pass
        monitor = xbmc.Monitor()
        deadline = time.time() + 4.0
        while time.time() < deadline:
            try:
                if not player.isPlaying():
                    break
            except Exception:
                break
            if monitor.waitForAbort(0.1):
                return
        # Give the PKM service time to write the local resume sidecar and
        # push the stopped timeline to Plex.
        monitor.waitForAbort(0.8)
        _log("LONGPRESS_EXIT_PLAYBACK_STOPPED_R61 source=%s" % source)
    try:
        win.setProperty("PlexKM.App.Quitting", "1")
    except Exception:
        pass
    try:
        import pkm_kodi_exit_v2171
        pkm_kodi_exit_v2171.request_kodi_exit_v2171(
            reason="longpress_back_r61_%s" % source, title="Kodi 종료", detail="")
    except Exception as exc:
        _log("LONGPRESS_EXIT_COUNTDOWN_FAILED_R61 err=%s action=Quit" % exc, xbmc.LOGWARNING)
        xbmc.executebuiltin("Quit")


if __name__ == "__main__":
    main()
