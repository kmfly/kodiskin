# -*- coding: utf-8 -*-
import os
import sys

import xbmcaddon

_PATH = xbmcaddon.Addon().getAddonInfo("path")
if _PATH not in sys.path:
    sys.path.insert(0, _PATH)

from resources.lib import wizard

if __name__ == "__main__":
    wizard.run()
