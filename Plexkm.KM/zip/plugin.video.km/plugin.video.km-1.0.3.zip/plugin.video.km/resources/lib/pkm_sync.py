# -*- coding: utf-8 -*-
"""PKM sync/startup-cache data flow helpers.

Large feature split from default.py.  This module owns PMS cache validation,
sync locks, remote/local change checks, and startup/auto-sync state decisions.
It does not control Kodi focus, navigation, WindowXML, or playback return flow.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import os
import time
import json
import traceback

try:
    import xbmc
    import xbmcgui
except Exception:  # pragma: no cover - Kodi runtime supplies these modules.
    xbmc = None
    xbmcgui = None

_ENV = {}

def _bind_env(env=None):
    if env:
        _ENV.update(env)
        globals().update(env)
    return _ENV

def _last_fetch_section_stats():
    getter = _ENV.get("get_last_fetch_section_stats")
    if callable(getter):
        try:
            return getter() or {}
        except Exception:
            return {}
    return _ENV.get("LAST_FETCH_SECTION_STATS", {}) or {}


_KODI_DISPLAY_TRANSLATE = {
    ord("\u007C"): "|",
    ord("\u00A6"): "|",
    ord("\u01C0"): "|",
    ord("\u2016"): "|",
    ord("\u2223"): "|",
    ord("\u2225"): "|",
    ord("\u23AA"): "|",
    ord("\u23D0"): "|",
    ord("\u2502"): "|",
    ord("\u2503"): "|",
    ord("\u2758"): "|",
    ord("\u2759"): "|",
    ord("\u275A"): "|",
    ord("\u3163"): "|",
    ord("\u4E28"): "|",
    ord("\uFF5C"): "|",
    ord("\uFFE8"): "|",
}

def _display_text_for_kodi(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def _pkm_window_property(name):
    try:
        if xbmcgui is None:
            return ""
        return xbmcgui.Window(10000).getProperty(str(name or "")) or ""
    except Exception:
        return ""


def _startup_recent_sync_active():
    return _pkm_window_property("PlexKM.StartupRecentSync.Active") == "1"


def _pkm_notice_clear_later(expected_token="", ms=1800):
    fn = _ENV.get("pkm_notice_clear_later")
    if callable(fn):
        try:
            return bool(fn(expected_token=expected_token, ms=ms))
        except TypeError:
            try:
                return bool(fn(expected_token, ms))
            except Exception:
                return False
        except Exception:
            return False
    return False




def _pkm_notice_clear_update(force=True):
    fn = _ENV.get("pkm_notice_clear_if_title")
    if callable(fn):
        try:
            return bool(fn(["PKM 업데이트"], force=force))
        except TypeError:
            try:
                return bool(fn(["PKM 업데이트"], "", force))
            except Exception:
                return False
        except Exception:
            return False
    return False

def _signal_home_data_refresh(reason="sync"):

    audit_event(None, "sync__signal_home_data_refresh_enter")
    """Signal the visible Home WindowXML to rebuild its currently displayed widgets.

    This is data/UI refresh signaling only. It does not control focus, playback,
    back handling, or window flow.  Completion notices should be shown only after
    the Home window acknowledges this token, so a visible "완료" means the
    visible Home widgets already had a chance to rebuild from the updated DB.
    """
    fn = _ENV.get("signal_home_data_refresh")
    if callable(fn):
        try:
            return str(fn(reason=reason) or "")
        except TypeError:
            try:
                return str(fn(reason) or "")
            except Exception:
                return ""
        except Exception:
            return ""
    try:
        if xbmcgui is None:
            return ""
        token = str(int(time.time() * 1000))
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.DataRefreshReason", str(reason or "sync"))
        win.setProperty("PlexKM.Home.DataRefreshToken", token)
        return token
    except Exception:
        return ""


def _wait_home_data_refresh_applied(token="", timeout_ms=6500):
    """Wait briefly until Home reports the refresh token was applied.

    Returns True only when visible Home data refresh has been acknowledged.
    If Home is not open or cannot acknowledge within the bounded timeout, do not
    show a misleading completion notice.
    """
    token = str(token or "")
    if not token or xbmcgui is None:
        return False
    try:
        win = xbmcgui.Window(10000)
        waited = 0
        step = 100
        while waited < int(timeout_ms or 6500):
            try:
                if win.getProperty("PlexKM.Home.DataRefreshAppliedToken") == token:
                    return True
                if win.getProperty("PlexKM.ServiceStopping") == "1":
                    return False
            except Exception:
                pass
            if xbmc is not None:
                xbmc.sleep(step)
            else:
                time.sleep(step / 1000.0)
            waited += step
        return False
    except Exception:
        return False



def _repair_tv_art_cache_integrity(section_id, section_title="", fetch_remote=True, reason="startup"):
    func = _ENV.get("repair_tv_art_cache_integrity")
    if callable(func):
        try:
            return int(func(section_id, section_title=section_title, fetch_remote=fetch_remote, reason=reason) or 0)
        except TypeError:
            try:
                return int(func(section_id, section_title, fetch_remote, reason) or 0)
            except Exception:
                return 0
        except Exception:
            return 0
    return 0


def autosync_request_lock_path(env=None):
    _bind_env(env)
    return os.path.join(addon_profile_dir(), "autosync.request.lock")

def _read_lock_timestamp(path, env=None):
    _bind_env(env)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = f.read().strip()
        return int((data.split("|", 1)[0] or "0").strip() or 0)
    except Exception:
        return 0

def is_sync_locked(max_age_sec=1800, env=None):
    _bind_env(env)
    path = sync_lock_path()
    if not os.path.exists(path):
        return False
    ts = _read_lock_timestamp(path)
    if ts and int(time.time()) - ts < max_age_sec:
        return True
    try:
        os.remove(path)
        log("removed stale sync lock: %s" % path, xbmc.LOGWARNING)
        return False
    except Exception:
        return True

def acquire_sync_lock(max_age_sec=1800, label="sync", env=None):
    _bind_env(env)
    """Acquire an atomic cross-process lock for PMS sync."""
    path = sync_lock_path()
    now = int(time.time())
    try:
        if os.path.exists(path):
            ts = _read_lock_timestamp(path)
            if ts and now - ts < max_age_sec:
                log("sync lock exists; skipping duplicate sync label=%s age=%ss" % (label, now - ts), xbmc.LOGINFO)
                return False
            try:
                os.remove(path)
                log("removed stale sync lock before acquire label=%s" % label, xbmc.LOGWARNING)
            except Exception:
                log("stale sync lock exists but cannot remove; skip label=%s" % label, xbmc.LOGWARNING)
                return False
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, ("%d|%s|%s" % (now, os.getpid(), label)).encode("utf-8"))
        finally:
            os.close(fd)
        log("sync lock acquired label=%s" % label, xbmc.LOGINFO)
        return True
    except FileExistsError:
        log("sync lock race lost; skipping duplicate sync label=%s" % label, xbmc.LOGINFO)
        return False
    except Exception as e:
        log("sync lock acquire failed; skip sync label=%s error=%s" % (label, e), xbmc.LOGWARNING)
        return False

def release_sync_lock(env=None):
    _bind_env(env)
    try:
        path = sync_lock_path()
        if os.path.exists(path):
            os.remove(path)
            log("sync lock released", xbmc.LOGINFO)
    except Exception:
        pass

def acquire_autosync_request_lock(cooldown_sec=120, env=None):
    _bind_env(env)
    path = autosync_request_lock_path()
    now = int(time.time())
    try:
        if os.path.exists(path):
            ts = _read_lock_timestamp(path)
            if ts and now - ts < cooldown_sec:
                return False
            try:
                os.remove(path)
            except Exception:
                return False
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, ("%d|%s|autosync-request" % (now, os.getpid())).encode("utf-8"))
        finally:
            os.close(fd)
        return True
    except Exception:
        return False

def initial_sync_done(env=None):
    _bind_env(env)
    return bool(load_state().get("initial_sync_done"))

def set_initial_sync_done(value=True, env=None):
    _bind_env(env)
    state = load_state()
    state["initial_sync_done"] = bool(value)
    state["initial_sync_at"] = int(time.time()) if value else 0
    save_state(state)

def last_auto_sync_at(env=None):
    _bind_env(env)
    try:
        return int(load_state().get("last_auto_sync_at", 0) or 0)
    except Exception:
        return 0

def set_last_auto_sync_at(value=None, env=None):
    _bind_env(env)
    state = load_state()
    state["last_auto_sync_at"] = int(value if value is not None else time.time())
    save_state(state)

def _remote_total_for_path(path, params=None, env=None):
    _bind_env(env)
    params2 = {
        "checkFiles": 0, "includeExtras": 0, "includeReviews": 0,
        "includeRelated": 0, "skipRefresh": 1,
        "X-Plex-Container-Start": 0, "X-Plex-Container-Size": 1,
    }
    if params:
        params2.update(params)
    root = plex_request_xml(path, params=params2, timeout=20)
    return xml_attr_int(root, "totalSize", 0)

def remote_section_counts(section, env=None):
    _bind_env(env)
    """Return PMS item counts by type for startup sync validation."""
    section_id = str(section.get("section_id", ""))
    section_type = section.get("section_type", "")
    result = {"movie": 0, "show": 0, "episode": 0, "total": 0}
    if not section_id:
        return result
    if section_type == PLEX_TYPE_MOVIE:
        result["movie"] = _remote_total_for_path("/library/sections/%s/all" % section_id, {"type": PLEX_TYPE_TO_NUM[PLEX_TYPE_MOVIE]})
    elif section_type == PLEX_TYPE_SHOW:
        result["show"] = _remote_total_for_path("/library/sections/%s/all" % section_id, {"type": PLEX_TYPE_TO_NUM[PLEX_TYPE_SHOW]})
        # allLeaves is required.  Show rows alone do not prove the episode DB is current.
        result["episode"] = _remote_total_for_path("/library/sections/%s/allLeaves" % section_id)
    else:
        result["total"] = _remote_total_for_path("/library/sections/%s/all" % section_id)
    result["total"] = int(result.get("movie", 0) or 0) + int(result.get("show", 0) or 0) + int(result.get("episode", 0) or 0) or int(result.get("total", 0) or 0)
    return result

def remote_section_total(section, env=None):
    _bind_env(env)
    return int((remote_section_counts(section) or {}).get("total", 0) or 0)

def _remote_section_latest_items(section, limit=10, env=None):
    _bind_env(env)
    """Return newest Plex item keys for a section without doing a full sync.

    Plex section updatedAt can stay unchanged even when the section's
    recently-added row has newer items.  This small latest-item query verifies
    the first few addedAt-desc keys before allowing service fast-skip.

    v481: apply the guard to every section at startup/poll.  TV sections use
    /allLeaves because their visible Recently Added rows are episode based;
    movie sections keep /all type=movie.  This is still a small query only and
    does not affect side-menu navigation.
    """
    section_id = str((section or {}).get("section_id", ""))
    section_type = str((section or {}).get("section_type", ""))
    if not section_id:
        return []
    params = {
        "checkFiles": 0,
        "includeExtras": 0,
        "includeReviews": 0,
        "includeRelated": 0,
        "skipRefresh": 1,
        "sort": "addedAt:desc",
        "X-Plex-Container-Start": 0,
        "X-Plex-Container-Size": max(1, int(limit or 10)),
    }
    path = "/library/sections/%s/all" % section_id
    if section_type == PLEX_TYPE_SHOW:
        path = "/library/sections/%s/allLeaves" % section_id
    elif section_type == PLEX_TYPE_MOVIE:
        params["type"] = PLEX_TYPE_TO_NUM.get(PLEX_TYPE_MOVIE, "")
    root = plex_request_xml(path, params=params, timeout=20)
    rows = []
    for node in list(root):
        if node.tag not in ("Video", "Directory"):
            continue
        rk = str(node.get("ratingKey") or "").strip()
        if not rk:
            continue
        rows.append({
            "rating_key": rk,
            "added_at": xml_attr_int(node, "addedAt", 0),
            "updated_at": xml_attr_int(node, "updatedAt", 0),
            "title": node.get("title") or "",
        })
    return rows

def _local_section_latest_items(section_id, plex_type=None, limit=10, env=None):
    _bind_env(env)
    sid = str(section_id or "").strip()
    if not sid:
        return []
    conn = init_db()
    try:
        params = [sid]
        where = ["section_id=?"]
        if plex_type:
            where.append("plex_type=?")
            params.append(str(plex_type))
        params.append(max(1, int(limit or 10)))
        rows = conn.execute(
            "SELECT rating_key, COALESCE(added_at,0), COALESCE(updated_at,0), COALESCE(title,'') "
            "FROM items WHERE %s ORDER BY COALESCE(added_at,0) DESC, rating_key DESC LIMIT ?" % (" AND ".join(where),),
            tuple(params)
        ).fetchall()
        return [{
            "rating_key": str(r[0] or ""),
            "added_at": int(r[1] or 0),
            "updated_at": int(r[2] or 0),
            "title": str(r[3] or ""),
        } for r in rows if str(r[0] or "")]
    except Exception:
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass

def _latest_item_keys(rows, env=None):
    _bind_env(env)
    return [str((x or {}).get("rating_key") or "") for x in (rows or []) if str((x or {}).get("rating_key") or "")]

def _local_latest_detail_incomplete(section_id, section_type, remote_rows=None, local_rows=None, env=None):
    _bind_env(env)
    """Detect newest rows that exist locally but only as sparse item rows.

    The fast-skip guard used to compare only newest ratingKeys.  That missed the
    real broken state: the item row existed, but the side tables read by Info
    (item_people/item_genres/item_ratings for movies, item_people/item_studios
    for TV shows) were empty.  Return True so startup partial sync fetches the
    same /library/metadata/<ratingKey> XML and persists those side tables.
    """
    sid = str(section_id or "").strip()
    stype = str(section_type or "").strip()
    keys = _latest_item_keys(remote_rows or local_rows or [])
    if not sid or not keys:
        return False, ""
    conn = init_db()
    try:
        incomplete = []
        for rk in keys[:max(1, min(10, len(keys)))]:
            try:
                row = conn.execute(
                    "SELECT plex_type, COALESCE(parent_rating_key,''), COALESCE(grandparent_rating_key,''), COALESCE(summary,''), COALESCE(thumb,''), COALESCE(art,'') FROM items WHERE rating_key=?",
                    (str(rk),)
                ).fetchone()
            except Exception:
                row = None
            if not row:
                continue
            ptype = str(row[0] or "")
            parent_key = str(row[1] or "")
            grand_key = str(row[2] or "")
            summary = str(row[3] or "")
            thumb = str(row[4] or "")
            art = str(row[5] or "")
            if stype == PLEX_TYPE_MOVIE or ptype == PLEX_TYPE_MOVIE:
                try:
                    people_count = int((conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    people_count = 0
                try:
                    genre_count = int((conn.execute("SELECT COUNT(*) FROM item_genres WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    genre_count = 0
                try:
                    rating_count = int((conn.execute("SELECT COUNT(*) FROM item_ratings WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    rating_count = 0
                # item_ratings is a completion marker. If Plex really has no
                # people/genres, a completed sync still writes item_ratings and
                # prevents endless repair.
                if (people_count + genre_count + rating_count) <= 0 or not (summary and thumb and art):
                    incomplete.append(str(rk))
            elif stype == PLEX_TYPE_SHOW or ptype in (PLEX_TYPE_SHOW, PLEX_TYPE_EPISODE):
                show_key = str(rk) if ptype == PLEX_TYPE_SHOW else (grand_key or parent_key)
                show_detail_count = 0
                if show_key:
                    try:
                        show_detail_count += int((conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=?", (show_key,)).fetchone() or [0])[0] or 0)
                    except Exception:
                        pass
                    try:
                        show_detail_count += int((conn.execute("SELECT COUNT(*) FROM item_studios WHERE rating_key=?", (show_key,)).fetchone() or [0])[0] or 0)
                    except Exception:
                        pass
                if not (thumb and art) or (show_key and show_detail_count <= 0):
                    incomplete.append(str(rk))
            if incomplete:
                break
        if incomplete:
            return True, "metadata_incomplete:%s" % ",".join(incomplete[:10])
        return False, ""
    except Exception as exc:
        return False, "detail_check_error:%s" % exc
    finally:
        try:
            conn.close()
        except Exception:
            pass


def verify_section_latest_for_fast_skip(section, limit=10, env=None):
    _bind_env(env)
    """Return (changed, remote_rows, local_rows, error_text) for the fast-skip guard."""
    try:
        section_id = str((section or {}).get("section_id", ""))
        section_type = str((section or {}).get("section_type", ""))
        remote_rows = _remote_section_latest_items(section, limit=limit)
        local_plex_type = section_type if section_type else None
        # TV libraries show recent episodes.  Compare the Plex allLeaves keys
        # against local episode keys, not show keys, otherwise new episodes can
        # be missed when the show row itself is old.
        if section_type == PLEX_TYPE_SHOW:
            local_plex_type = PLEX_TYPE_EPISODE
        local_rows = _local_section_latest_items(section_id, plex_type=local_plex_type, limit=limit)
        remote_keys = _latest_item_keys(remote_rows)
        local_keys = _latest_item_keys(local_rows)
        if not remote_keys:
            return False, remote_rows, local_rows, "remote_empty"
        # Kodi/PKM must never miss newly-added Plex items.  Treat the
        # guard as dirty when any newest Plex key is absent from the local
        # PKM latest window.  This avoids false DIRTY from equal-addedAt
        # ordering differences while still catching new items.
        missing_in_pkm = [k for k in remote_keys if k not in set(local_keys)]
        if missing_in_pkm:
            return True, remote_rows, local_rows, "missing_in_pkm:%s" % ",".join(missing_in_pkm[:10])
        detail_incomplete, detail_reason = _local_latest_detail_incomplete(section_id, section_type, remote_rows=remote_rows, local_rows=local_rows)
        if detail_incomplete:
            return True, remote_rows, local_rows, detail_reason or "metadata_incomplete"
        return False, remote_rows, local_rows, ""
    except Exception as exc:
        return False, [], [], str(exc)

def local_section_counts(section_id, env=None):
    _bind_env(env)
    result = {"movie": 0, "show": 0, "episode": 0, "total": 0, "max_synced_at": 0, "max_updated_at": 0}
    conn = init_db()
    try:
        for plex_type, count in conn.execute("SELECT plex_type, COUNT(*) FROM items WHERE section_id=? GROUP BY plex_type", (str(section_id),)).fetchall():
            key = str(plex_type or "")
            if key in result:
                result[key] = int(count or 0)
        row = conn.execute("SELECT COUNT(*), COALESCE(MAX(synced_at),0), COALESCE(MAX(updated_at),0) FROM items WHERE section_id=?", (str(section_id),)).fetchone()
        if row:
            result["total"] = int(row[0] or 0)
            result["max_synced_at"] = int(row[1] or 0)
            result["max_updated_at"] = int(row[2] or 0)
    finally:
        conn.close()
    return result


def _repair_section_type_mismatch_v1370(sections=None, env=None):
    _bind_env(env)
    """v1370: remove rows written into the wrong library section by the v1367~v1369
    startup latest-item partial sync bug.

    The bug reused the last section's latest rows for every changed section.  In
    practice TV episode rows could be inserted under movie libraries, which made
    every Kodi start look like a new update.  This cleanup is limited to clear
    type mismatches only: movie libraries keep movie rows, TV libraries keep show
    and episode rows.
    """
    try:
        sections = list(sections or [])
    except Exception:
        sections = []
    if not sections:
        return 0
    conn = None
    removed = 0
    try:
        conn = init_db()
        for sec in sections:
            sid = str((sec or {}).get("section_id") or "").strip()
            stype = str((sec or {}).get("section_type") or "").strip()
            if not sid:
                continue
            if stype == PLEX_TYPE_MOVIE:
                cur = conn.execute("DELETE FROM items WHERE section_id=? AND plex_type<>?", (sid, PLEX_TYPE_MOVIE))
            elif stype == PLEX_TYPE_SHOW:
                cur = conn.execute("DELETE FROM items WHERE section_id=? AND plex_type NOT IN (?,?)", (sid, PLEX_TYPE_SHOW, PLEX_TYPE_EPISODE))
            else:
                continue
            try:
                removed += int(cur.rowcount or 0)
            except Exception:
                pass
        if removed:
            conn.commit()
            log("PKM_V1370_SECTION_TYPE_MISMATCH_CLEANUP removed=%d" % removed, xbmc.LOGWARNING)
        return removed
    except Exception:
        try:
            log("PKM_V1370_SECTION_TYPE_MISMATCH_CLEANUP_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        except Exception:
            pass
        return 0
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

def local_tv_tag_index_missing_for_section(section_id, env=None):
    _bind_env(env)
    """Return True when an existing TV section has no actor/studio tag index yet.

    This lets the first startup after v471 build the DB index during the normal
    sync path instead of waiting for a future Plex library change.
    """
    sid = str(section_id or "").strip()
    if not sid:
        return False
    conn = init_db()
    try:
        show_count = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=? AND plex_type=?", (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        if int(show_count or 0) <= 0:
            return False
        people_count = conn.execute("""
            SELECT COUNT(DISTINCT p.rating_key)
            FROM item_people p
            JOIN items s ON s.rating_key=p.rating_key
            WHERE p.section_id=? AND s.plex_type=?
        """, (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        studio_count = conn.execute("""
            SELECT COUNT(DISTINCT st.rating_key)
            FROM item_studios st
            JOIN items s ON s.rating_key=st.rating_key
            WHERE st.section_id=? AND s.plex_type=?
        """, (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        return int(people_count or 0) <= 0 and int(studio_count or 0) <= 0
    except Exception:
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass

def local_section_count(section_id, env=None):
    _bind_env(env)
    try:
        return int((local_section_counts(str(section_id)) or {}).get("total", 0) or 0)
    except Exception:
        return 0

def update_section_count(section_id, count_value, env=None):
    _bind_env(env)
    conn = init_db()
    try:
        conn.execute("UPDATE sections SET item_count=? WHERE section_id=?", (int(count_value or 0), str(section_id)))
        conn.commit()
    finally:
        conn.close()

def load_local_section_meta_map(env=None):
    _bind_env(env)
    conn = init_db()
    try:
        rows = conn.execute("SELECT section_id, COALESCE(scanned_at,0), COALESCE(item_count,0) FROM sections").fetchall()
        return {str(r[0]): {"scanned_at": int(r[1] or 0), "item_count": int(r[2] or 0)} for r in rows}
    except Exception:
        return {}
    finally:
        conn.close()

def load_sync_state_map(env=None):
    _bind_env(env)
    conn = init_db()
    try:
        rows = conn.execute("SELECT section_id, COALESCE(remote_updated_at,0), COALESCE(remote_count,0), COALESCE(last_checked_at,0), COALESCE(last_synced_at,0) FROM sync_state").fetchall()
        return {str(r[0]): {
            "remote_updated_at": int(r[1] or 0),
            "remote_count": int(r[2] or 0),
            "last_checked_at": int(r[3] or 0),
            "last_synced_at": int(r[4] or 0),
        } for r in rows}
    except Exception:
        return {}
    finally:
        conn.close()

def update_sync_state(section_id, remote_updated_at=0, remote_count=0, synced=False, env=None):
    _bind_env(env)
    conn = init_db()
    now = int(time.time())
    try:
        current_synced = 0
        try:
            row = conn.execute("SELECT COALESCE(last_synced_at,0) FROM sync_state WHERE section_id=?", (str(section_id),)).fetchone()
            current_synced = int(row[0] or 0) if row else 0
        except Exception:
            current_synced = 0
        last_synced = now if synced else current_synced
        conn.execute(
            "INSERT INTO sync_state(section_id, remote_updated_at, remote_count, last_checked_at, last_synced_at) "
            "VALUES(?,?,?,?,?) "
            "ON CONFLICT(section_id) DO UPDATE SET "
            "remote_updated_at=excluded.remote_updated_at, "
            "remote_count=excluded.remote_count, "
            "last_checked_at=excluded.last_checked_at, "
            "last_synced_at=excluded.last_synced_at",
            (str(section_id), int(remote_updated_at or 0), int(remote_count or 0), now, int(last_synced or 0))
        )
        conn.commit()
    finally:
        conn.close()

def _pkm_service_abort_requested(env=None):
    _bind_env(env)
    # v517: used only by service startup/poll cache refresh so Kodi can shut down
    # cleanly.  This does not control focus, navigation, Info, fanart, or Home rows.
    try:
        if xbmc.Monitor().abortRequested():
            return True
    except Exception:
        pass
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.ServiceStopping") == "1"
    except Exception:
        return False


def _pkm_background_video_or_trailer_active():
    """Passive guard for automatic/background work.

    v942: Home trailer preview is also playback.  When a trailer is preparing or
    visible in the Home video window, Cine21/Plex background writes must not run.
    """
    try:
        func = globals().get("pkm_player_has_video")
        if callable(func) and func():
            return True
    except Exception:
        pass
    try:
        if xbmc and (xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility("Player.HasVideo") or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)") or xbmc.getCondVisibility("Window.IsActive(videoosd)")):
            return True
    except Exception:
        pass
    try:
        if xbmcgui:
            win = xbmcgui.Window(10000)
            return bool(
                win.getProperty("PlexKM.Home.TrailerPreparing") == "1"
                or win.getProperty("PlexKM.Home.TrailerActive") == "1"
                or win.getProperty("PlexKM.Home.TrailerFadeHold") == "1"
            )
    except Exception:
        pass
    return False


def _run_cine21_sync_update(caller="", reason="", env=None):
    """Run a small Cine21 DB update immediately after Plex sync/cache validation.

    v922: no delayed timer and no Info/Home UI network access.  This is tied to
    the Plex sync thread.  It seeds missing movie rows, safely exact-matches
    title+year on Cine21, and fetches scores for matched rows.  Missing scores
    are stored as no_match/ambiguous/error so the UI can treat them as empty
    without retrying during screen entry.

    v940: single background worker guard.  If another Cine21 worker is already
    active, this call is recorded internally and returns without any UI notice.
    """
    _bind_env(env)
    try:
        win_guard = xbmcgui.Window(10000)
        if win_guard.getProperty("PlexKM.Cine21.WorkerRunning") == "1":
            win_guard.setProperty("PlexKM.Cine21.QueuedInternal", "1")
            log("CINE21_SYNC_UPDATE_SKIP reason=worker_running caller=%s queued_internal=1" % (caller or ""), xbmc.LOGINFO)
            return {"queued_internal": 1}
        win_guard.setProperty("PlexKM.Cine21.WorkerRunning", "1")
        win_guard.setProperty("PlexKM.Cine21.WorkerCaller", caller or "")
    except Exception:
        win_guard = None
    # v941: no automatic/background Cine21 DB work is allowed during playback.
    # UI playback has priority over every cache updater, regardless of caller.
    if _pkm_background_video_or_trailer_active():
        log("CINE21_SYNC_UPDATE_SKIP reason=player_or_trailer_active caller=%s" % (caller or ""), xbmc.LOGINFO)
        try:
            if win_guard is not None:
                win_guard.clearProperty("PlexKM.Cine21.WorkerRunning")
                win_guard.clearProperty("PlexKM.Cine21.WorkerCaller")
        except Exception:
            pass
        return None
    conn = None
    t0 = time.time()
    try:
        from resources.lib import pkm_cine21
        conn = init_db()
        stats = pkm_cine21.auto_update_cine21_cache(
            conn,
            seed_limit=80,
            match_limit=12,
            fetch_limit=12,
            timeout=6,
            mark_missing_limit=0,
            abort_cb=lambda: (_pkm_service_abort_requested(env) or _pkm_background_video_or_trailer_active()),
        ) or {}
        elapsed = (time.time() - t0) * 1000.0
        try:
            win = xbmcgui.Window(10000)
            token = str(int(time.time() * 1000))
            win.setProperty("PlexKM.Cine21.LastUpdateToken", token)
            # Home watcher will rebuild/re-read DB after a Cine21 write so newly
            # added movie ratings appear in the same Kodi run, not only after
            # restart.  Rendering itself remains DB-only.
            if int(stats.get("seeded", 0) or 0) or int(stats.get("matched", 0) or 0) or int(stats.get("fetched_ok", 0) or 0):
                win.setProperty("PlexKM.Home.DataRefreshReason", "cine21_sync_%s" % (reason or caller or "update"))
                win.setProperty("PlexKM.Home.DataRefreshToken", token)
        except Exception:
            pass
        log("CINE21_SYNC_UPDATE_DONE caller=%s reason=%s seeded=%s match_checked=%s matched=%s no_match=%s ambiguous=%s fetch_candidates=%s ok=%s error=%s elapsed=%.1fms" % (
            caller or "", reason or "",
            stats.get("seeded", 0), stats.get("match_checked", 0), stats.get("matched", 0),
            stats.get("match_no_match", 0), stats.get("match_ambiguous", 0),
            stats.get("candidates", 0), stats.get("fetched_ok", 0), stats.get("fetched_error", 0), elapsed
        ), xbmc.LOGINFO)
        return stats
    except Exception:
        log("CINE21_SYNC_UPDATE_FAILED caller=%s reason=%s err=%s" % (
            caller or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return None
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
        try:
            if win_guard is not None:
                win_guard.clearProperty("PlexKM.Cine21.WorkerRunning")
                win_guard.clearProperty("PlexKM.Cine21.WorkerCaller")
        except Exception:
            pass

def _startup_partial_sync_latest_items(section, latest_remote_rows=None, latest_local_rows=None, caller="", reason="latest_item", limit=24, env=None):
    _bind_env(env)
    """v996: update only the latest changed Plex items during startup.

    Update detection remains correct.  When latest keys differ, startup should cache
    those latest items immediately, but it must not force-sync a 16k-item section.
    Full cleanup/prune remains in the existing full/manual sync path.
    """
    t0 = time.time()
    section = section or {}
    sid = str(section.get("section_id") or "").strip()
    section_type = str(section.get("section_type") or "").strip()
    title = section.get("title", "")
    max_items = max(1, int(limit or 24))
    stats = {"movie": 0, "show": 0, "episode": 0}
    if not sid:
        return 0, 0, 0.0, stats
    extract_item_func = _ENV.get("extract_item") or globals().get("extract_item")
    if not callable(extract_item_func):
        log("STARTUP_SYNC_PARTIAL_SKIP section=%s title=%s caller=%s reason=no_extract_item_env" % (sid, title or "", caller or ""), xbmc.LOGWARNING)
        return 0, 0, 0.0, stats

    def _rk(row):
        return str((row or {}).get("rating_key") or "").strip()

    local_map = {}
    try:
        for row in latest_local_rows or []:
            key = _rk(row)
            if key:
                local_map[key] = row or {}
    except Exception:
        local_map = {}

    candidates = []
    seen = set()
    try:
        for row in latest_remote_rows or []:
            key = _rk(row)
            if not key or key in seen:
                continue
            local = local_map.get(key)
            changed = False
            if not local:
                changed = True
            else:
                try:
                    changed = int((row or {}).get("updated_at") or 0) > int((local or {}).get("updated_at") or 0)
                except Exception:
                    changed = False
            if changed:
                candidates.append(key)
                seen.add(key)
            if len(candidates) >= max_items:
                break
    except Exception:
        pass

    if not candidates:
        try:
            for row in latest_remote_rows or []:
                key = _rk(row)
                if key and key not in seen:
                    candidates.append(key)
                    seen.add(key)
                if len(candidates) >= min(10, max_items):
                    break
        except Exception:
            pass

    if not candidates:
        log("STARTUP_SYNC_PARTIAL_SKIP section=%s title=%s caller=%s reason=no_candidates" % (sid, title or "", caller or ""), xbmc.LOGINFO)
        return 0, 0, 0.0, stats

    conn = None
    search_conn = None
    fetched = 0
    total_seen = 0
    show_parent_keys = set()
    try:
        conn = init_db()
        try:
            import sqlite3
            search_conn = sqlite3.connect(search_db_path(), timeout=8.0)
            init_search_db(search_conn)
        except Exception:
            search_conn = None
            log("STARTUP_SYNC_PARTIAL_SEARCH_OPEN_FAILED section=%s err=%s" % (sid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

        def _upsert_xml_node(node, source_label="item"):
            nonlocal fetched, total_seen
            item = extract_item_func(node, sid, section_type)
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                return
            old_checksum = None
            old_row = None
            try:
                old_row = conn.execute("SELECT checksum FROM items WHERE rating_key=?", (rk,)).fetchone()
                old_checksum = old_row[0] if old_row else None
            except Exception:
                old_checksum = None
            upsert_item(conn, item)
            # v1330: partial sync must persist detail side tables, not only the
            # items row.  Info reads actor/director/genre/rating/studio data from
            # these tables.  The missing call here is why newly-added items existed
            # in PKM but opened with empty cast/genre/director until an Info-time
            # Plex repair was attempted.
            try:
                ptype_for_detail = str(item.get("plex_type") or "")
                if ptype_for_detail == PLEX_TYPE_MOVIE:
                    updater = _ENV.get("update_recommend_index_from_live_xml")
                    if callable(updater):
                        updater(node, item, reason="startup_partial_latest_v1330", conn=conn, bootstrap_ready=True, log_skips=False)
                elif ptype_for_detail == PLEX_TYPE_SHOW:
                    tv_indexer = _ENV.get("save_tv_show_tag_index")
                    if callable(tv_indexer):
                        tv_indexer(conn, item, node, reason="startup_partial_latest_v1330")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_DETAIL_INDEX_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            try:
                if search_conn is not None:
                    upsert_search_index_item(search_conn, item, section_title="")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_SEARCH_UPSERT_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            if old_row is None:
                ptype = str(item.get("plex_type") or "")
                if ptype in stats:
                    stats[ptype] += 1
            try:
                gp = str(item.get("grandparent_rating_key") or "").strip()
                if gp:
                    show_parent_keys.add(gp)
            except Exception:
                pass
            fetched += 1

        for key in candidates[:max_items]:
            try:
                root = plex_request_xml("/library/metadata/%s" % key, params={
                    "checkFiles": 0,
                    "includeExtras": 0,
                    "includeReviews": 0,
                    "includeRelated": 0,
                    "skipRefresh": 1,
                }, timeout=12)
                nodes = [x for x in list(root) if x.tag in ("Video", "Directory")]
                total_seen += len(nodes)
                for node in nodes:
                    _upsert_xml_node(node, source_label="latest")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_ITEM_FAILED section=%s key=%s title=%s err=%s" % (
                    sid, key, title or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        # For new TV episodes, cache parent show poster/fanart if possible.
        if section_type == PLEX_TYPE_SHOW and show_parent_keys:
            for show_key in list(show_parent_keys)[:max_items]:
                try:
                    root = plex_request_xml("/library/metadata/%s" % show_key, params={
                        "checkFiles": 0,
                        "includeExtras": 0,
                        "includeReviews": 0,
                        "includeRelated": 0,
                        "skipRefresh": 1,
                    }, timeout=12)
                    for node in [x for x in list(root) if x.tag in ("Video", "Directory")]:
                        total_seen += 1
                        _upsert_xml_node(node, source_label="parent_show")
                except Exception:
                    log("STARTUP_SYNC_PARTIAL_SHOW_FAILED section=%s show_key=%s title=%s err=%s" % (
                        sid, show_key, title or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

        try:
            now = int(time.time())
            conn.execute("UPDATE sections SET scanned_at=? WHERE section_id=?", (now, sid))
        except Exception:
            pass
        try:
            conn.commit()
            if search_conn is not None:
                search_conn.commit()
        except Exception:
            pass
    finally:
        try:
            if search_conn is not None:
                search_conn.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

    elapsed = time.time() - t0
    log("STARTUP_SYNC_PARTIAL_DONE section=%s title=%s caller=%s reason=%s candidates=%d fetched=%d total_seen=%d elapsed=%.1f movie=%d show=%d episode=%d keys=%s" % (
        sid, title or "", caller or "", reason or "", len(candidates), fetched, total_seen, elapsed,
        int(stats.get("movie", 0) or 0), int(stats.get("show", 0) or 0), int(stats.get("episode", 0) or 0),
        ",".join(candidates[:10])
    ), xbmc.LOGINFO)
    return fetched, total_seen or fetched, elapsed, stats


def _plex_offline_active():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1"
    except Exception:
        return False


def ensure_startup_cache_ready(show_progress=True, notice_progress=False, caller="startup", precreated_progress=None, env=None):
    _bind_env(env)
    """Make the Plex KM SQLite cache current before PKM Home opens.

    Startup sync is intentionally quiet by default.  If Plex is newer than the
    local DB, movie/show/episode rows are refreshed here, not inside the Info UI.
    """
    def _close_precreated_early_v1747(reason):
        if precreated_progress is None:
            return
        try:
            log("STARTUP_SYNC_PRECREATED_CLOSE_EARLY_V1747 caller=%s reason=%s" % (caller or "", reason or ""), xbmc.LOGINFO)
            precreated_progress.close()
            xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
        except Exception:
            pass

    if _plex_offline_active():
        log("STARTUP_SYNC_SKIP reason=plex_offline_v1290 caller=%s" % (caller or ""), xbmc.LOGWARNING)
        _close_precreated_early_v1747("plex_offline")
        return False
    if not clean_server_url() or not plex_token():
        log("startup cache skipped: Plex URL/token missing", xbmc.LOGWARNING)
        _close_precreated_early_v1747("missing_credentials")
        return False
    if not initial_sync_done():
        # Fresh installs still use the existing interactive first-sync path.
        # The small top-right updater is only for later incremental startup checks
        # after PKM Home can open with an existing DB.
        log("STARTUP_SYNC_SKIP reason=initial_sync_not_done caller=%s" % (caller or ""), xbmc.LOGINFO)
        _close_precreated_early_v1747("initial_sync_not_done")
        return False
    if caller in ("service_poll", "service_startup") and pkm_player_has_video():
        log("STARTUP_SYNC_SKIP reason=player_active caller=%s" % (caller or ""), xbmc.LOGINFO)
        _close_precreated_early_v1747("player_active")
        return False
    if is_sync_locked(max_age_sec=1800):
        log("startup cache skipped: sync already running", xbmc.LOGINFO)
        _close_precreated_early_v1747("sync_locked")
        return False
    if not acquire_sync_lock(label="startup-cache"):
        _close_precreated_early_v1747("lock_acquire_failed")
        return False
    progress = precreated_progress
    startup_stats = {"movie": 0, "show": 0, "episode": 0}
    notice_token = ""
    visible_notice_started = False
    try:
        # v1370: defer visible PKM update notices until an actual update is found.
        # Startup/polling should not show a notification on every Kodi launch just
        # for the "checking" phase.
        deferred_notice_progress = bool(notice_progress and caller in ("service_startup", "service_poll"))
        if deferred_notice_progress:
            _pkm_notice_clear_update(force=True)
            log("UPDATE_NOTIFY_STALE_CLEAR stage=before_scan caller=%s" % (caller or ""), xbmc.LOGINFO)
        if notice_progress and not deferred_notice_progress:
            notice_token = pkm_notice_set("PKM 업데이트", "라이브러리 상태 확인 준비", "Plex 변경사항 확인 중")
        if show_progress:
            if progress is None:
                progress = _create_pkm_sync_progress()
                log("STARTUP_SYNC_PROGRESS_CREATE_V1747 caller=%s precreated=0" % (caller or ""), xbmc.LOGINFO)
            else:
                log("STARTUP_SYNC_PROGRESS_REUSE_PREARMED_V1747 caller=%s precreated=1" % (caller or ""), xbmc.LOGINFO)
            progress_create(progress, ADDON_NAME, "메타데이터를 확인하고 있습니다")
            try:
                if xbmc.getCondVisibility("Window.IsVisible(13032)"):
                    xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            try:
                log("STARTUP_SYNC_PROGRESS_ACTIVE_V1747 caller=%s base=%s dialog=%s vis13030=%d vis13031=%d vis13032=%d" % (
                    caller or "", xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId(),
                    1 if xbmc.getCondVisibility("Window.IsVisible(13030)") else 0,
                    1 if xbmc.getCondVisibility("Window.IsVisible(13031)") else 0,
                    1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0,
                ), xbmc.LOGINFO)
            except Exception:
                pass
        if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
            log("STARTUP_SYNC_ABORT reason=service_stopping stage=before_scan caller=%s" % (caller or ""), xbmc.LOGINFO)
            return False
        previous_section_meta = load_local_section_meta_map()
        sync_state = load_sync_state_map()
        sections = fetch_sections(refresh=True)
        sections = apply_section_order(sections, save_merged=True)
        _repair_section_type_mismatch_v1370(sections)
        total_sections = len(sections)
        if notice_progress and not deferred_notice_progress:
            pkm_notice_set("PKM 업데이트", "라이브러리 확인 0/%d" % total_sections, "Plex 변경사항 확인 중", token=notice_token)
        if not sections:
            if progress:
                progress_update(progress, 100, "Plex 라이브러리가 없습니다")
            return False

        changed = []
        for index, section in enumerate(sections, start=1):
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=check_sections index=%d caller=%s" % (index, caller or ""), xbmc.LOGINFO)
                return False
            if progress and progress.iscanceled():
                break
            section_id = str(section.get("section_id", ""))
            section_type = str(section.get("section_type", ""))
            pct = int(((index - 1) / float(max(1, total_sections))) * 30)
            progress_update(progress, pct, "라이브러리 상태 확인 중\n%s" % _display_text_for_kodi(section.get("title", "")))
            if notice_progress and not deferred_notice_progress:
                pkm_notice_set("PKM 업데이트", "라이브러리 확인 %d/%d" % (index, total_sections), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            remote_updated_at = int(section.get("updated_at") or section.get("scanned_at") or 0)
            prev_meta = previous_section_meta.get(section_id) or {}
            state_meta = sync_state.get(section_id) or {}
            prev_remote_updated = int(state_meta.get("remote_updated_at") or prev_meta.get("scanned_at") or 0)
            tv_tag_index_missing = False
            latest_item_changed = False
            latest_item_reason = ""
            latest_remote_rows = []
            latest_local_rows = []
            if section_type == PLEX_TYPE_SHOW:
                try:
                    tv_tag_index_missing = local_tv_tag_index_missing_for_section(section_id)
                except Exception:
                    tv_tag_index_missing = False
            # Fast path for normal startup/polling: section updatedAt may stay
            # unchanged while Plex recently-added rows receive new items.  v482
            # verifies the newest keys for every section with a wider window and
            # still falls through to the lightweight count check before allowing
            # a skip.  This keeps side-menu navigation untouched while preventing
            # newly-added Plex items from being missed.
            if caller in ("service_startup", "service_poll") and remote_updated_at and prev_remote_updated == remote_updated_at and not tv_tag_index_missing:
                latest_item_changed, latest_remote_rows, latest_local_rows, latest_item_reason = verify_section_latest_for_fast_skip(section, limit=10)
                log("STARTUP_SYNC_FAST_SKIP_VERIFY section=%s title=%s caller=%s type=%s remote_updated=%s remote_latest=%s local_latest=%s changed=%s reason=%s scope=all_sections_v482 limit=10" % (
                    section_id, section.get("title", ""), caller or "", section_type or "", remote_updated_at,
                    ",".join(_latest_item_keys(latest_remote_rows)),
                    ",".join(_latest_item_keys(latest_local_rows)),
                    "1" if latest_item_changed else "0", latest_item_reason or "ok"
                ), xbmc.LOGINFO)
                if latest_item_changed:
                    log("STARTUP_SYNC_FAST_SKIP_BYPASS section=%s title=%s caller=%s reason=latest_item_changed remote_latest=%s local_latest=%s" % (
                        section_id, section.get("title", ""), caller or "",
                        ",".join(_latest_item_keys(latest_remote_rows)),
                        ",".join(_latest_item_keys(latest_local_rows))
                    ), xbmc.LOGINFO)
                else:
                    if caller == "service_startup":
                        # v993: keep the visible PKM update notice, but make the
                        # no-change startup path fast again.  When section updatedAt
                        # is unchanged and the newest Plex keys match local DB, startup
                        # should not run the extra remote count guard or TV art-cache
                        # repair pass.  Those maintenance checks caused long "no update"
                        # startup checks while the notice stayed on screen.
                        try:
                            known_total = int(
                                state_meta.get("remote_count")
                                or prev_meta.get("item_count")
                                or prev_meta.get("total")
                                or 0
                            )
                        except Exception:
                            known_total = 0
                        try:
                            update_sync_state(section_id, remote_updated_at, known_total, synced=False)
                        except Exception:
                            pass
                        log("STARTUP_SYNC_QUICK_SKIP section=%s title=%s caller=%s reason=latest_ok_no_count_guard_no_art_cache remote_updated=%s known_total=%s" % (
                            section_id, section.get("title", ""), caller or "", remote_updated_at, known_total
                        ), xbmc.LOGINFO)
                        if section_type == PLEX_TYPE_SHOW:
                            log("STARTUP_SYNC_TV_ART_CACHE_DEFER section=%s title=%s caller=%s reason=startup_quick_skip_latest_ok" % (
                                section_id, section.get("title", ""), caller or ""
                            ), xbmc.LOGINFO)
                        log("STARTUP_SYNC_CHECK section=%s title=%s type=%s local_movie=%s local_show=%s local_episode=%s remote_movie=%s remote_show=%s remote_episode=%s local_max_updated=%s remote_updated=%s changed=0 latest_changed=0 reason=quick_no_change" % (
                            section_id, section.get("title", ""), section_type,
                            "-", "-", "-", "-", "-", "-", "-", remote_updated_at
                        ), xbmc.LOGINFO)
                        continue
                    else:
                        log("STARTUP_SYNC_FAST_SKIP_COUNT_GUARD section=%s title=%s caller=%s remote_updated=%s latest_guard=ok action=verify_counts" % (
                            section_id, section.get("title", ""), caller or "", remote_updated_at
                        ), xbmc.LOGINFO)
            if tv_tag_index_missing:
                if caller in ("service_startup", "service_poll"):
                    # v472: do not backfill all missing TV actor/studio tags from
                    # the startup service.  v471 correctly moved these tags into
                    # plex_km.db, but first-run backfill scanned big TV sections
                    # while the user was moving the side menu and contended on the
                    # same DB.  Changed sections still index tags during normal
                    # fetch_section_items(); this only skips tag-only backfill.
                    update_sync_state(section_id, remote_updated_at, int(prev_meta.get("item_count") or state_meta.get("remote_count") or 0), synced=False)
                    log("STARTUP_SYNC_TV_TAG_INDEX_DEFER section=%s title=%s caller=%s reason=service_startup_no_tag_backfill" % (section_id, section.get("title", ""), caller or ""), xbmc.LOGINFO)
                    continue
                log("STARTUP_SYNC_TV_TAG_INDEX_MISSING section=%s title=%s caller=%s" % (section_id, section.get("title", ""), caller or ""), xbmc.LOGINFO)
            try:
                remote_counts = remote_section_counts(section)
            except Exception as exc:
                log("STARTUP_SYNC_REMOTE_COUNT_FAILED section=%s title=%s error=%s" % (section_id, section.get("title"), exc), xbmc.LOGWARNING)
                remote_counts = {"movie": 0, "show": 0, "episode": 0, "total": 0}
            try:
                local_counts = local_section_counts(section_id)
            except Exception:
                local_counts = {"movie": 0, "show": 0, "episode": 0, "total": 0, "max_synced_at": 0, "max_updated_at": 0}

            if section_type == PLEX_TYPE_MOVIE:
                count_changed = int(local_counts.get("movie", 0) or 0) != int(remote_counts.get("movie", 0) or 0)
            elif section_type == PLEX_TYPE_SHOW:
                count_changed = (
                    int(local_counts.get("show", 0) or 0) != int(remote_counts.get("show", 0) or 0)
                    or int(local_counts.get("episode", 0) or 0) != int(remote_counts.get("episode", 0) or 0)
                )
            else:
                count_changed = int(local_counts.get("total", 0) or 0) != int(remote_counts.get("total", 0) or 0)
            time_changed = bool(remote_updated_at and int(local_counts.get("max_updated_at", 0) or 0) < int(remote_updated_at))
            is_changed = bool(count_changed or time_changed or tv_tag_index_missing or latest_item_changed)
            remote_total_for_state = int(remote_counts.get("total") if remote_counts.get("total") else local_counts.get("total", 0) or 0)
            update_section_count(section_id, remote_total_for_state)
            if is_changed:
                changed.append((
                    section,
                    remote_counts,
                    local_counts,
                    "tv_tags" if tv_tag_index_missing else ("latest_item" if latest_item_changed else ("count" if count_changed else "updatedAt")),
                    list(latest_remote_rows or []),
                    list(latest_local_rows or []),
                ))
            else:
                update_sync_state(section_id, remote_updated_at, remote_total_for_state, synced=False)
                if section_type == PLEX_TYPE_SHOW:
                    repaired = _repair_tv_art_cache_integrity(
                        section_id,
                        section_title=section.get("title", ""),
                        fetch_remote=True,
                        reason="startup_no_change_%s" % (caller or "startup"),
                    )
                    if repaired:
                        startup_stats["show"] += 0
                        log("STARTUP_SYNC_TV_ART_CACHE_REPAIRED section=%s title=%s repaired=%d reason=no_change" % (
                            section_id, section.get("title", ""), repaired
                        ), xbmc.LOGINFO)
            log("STARTUP_SYNC_CHECK section=%s title=%s type=%s local_movie=%s local_show=%s local_episode=%s remote_movie=%s remote_show=%s remote_episode=%s local_max_updated=%s remote_updated=%s changed=%s latest_changed=%s reason=%s" % (
                section_id, section.get("title", ""), section_type,
                local_counts.get("movie", 0), local_counts.get("show", 0), local_counts.get("episode", 0),
                remote_counts.get("movie", 0), remote_counts.get("show", 0), remote_counts.get("episode", 0),
                local_counts.get("max_updated_at", 0), remote_updated_at, "1" if is_changed else "0",
                "1" if latest_item_changed else "0",
                "tv_tags" if tv_tag_index_missing else ("latest_item" if latest_item_changed else ("count" if count_changed else ("updatedAt" if time_changed else "no_change")))
            ), xbmc.LOGINFO)

        if not changed:
            set_initial_sync_done(True)
            set_last_auto_sync_at()
            if progress:
                progress_update(progress, 100, "캐시 확인 완료")
            if notice_progress and notice_token:
                pkm_notice_clear(notice_token)
            if notice_progress:
                _pkm_notice_clear_update(force=True)
                log("UPDATE_NOTIFY_SKIPPED stage=no_change reason=no_actual_plex_change caller=%s" % (caller or ""), xbmc.LOGINFO)
            # v1645: Plex startup snapshot must never wait for Cine21 web/DB
            # maintenance. Existing ratings are read from the local DB while
            # missing ratings are collected only after the completed PKM scene
            # is revealed. The collected values become visible next Kodi start.
            log("CINE21_STARTUP_SYNC_DEFER_V1645 caller=%s reason=no_plex_change phase=post_reveal_next_start" % (caller or ""), xbmc.LOGINFO)
            log("STARTUP_SYNC_VALID sections=%d" % total_sections, xbmc.LOGINFO)
            return True

        log("STARTUP_SYNC_REFRESH sections=%d" % len(changed), xbmc.LOGINFO)
        # v884: keep startup Plex sync silent unless the caller explicitly asked
        # for progress UI.  The Home window already has its own PKM notice stack;
        # adding a separate "PKM 업데이트 감지" notice here overlaps existing
        # notifications and was not requested.
        log("UPDATE_NOTIFY_SKIPPED stage=detected reason=silent_startup_sync sections=%d" % len(changed), xbmc.LOGINFO)
        if notice_progress and not deferred_notice_progress:
            if not notice_token:
                notice_token = pkm_notice_set("PKM 업데이트 중", "업데이트 대상 %d개 라이브러리" % len(changed), "잠시 후 홈 데이터가 갱신됩니다")
                visible_notice_started = True
            else:
                pkm_notice_set("PKM 업데이트 중", "업데이트 대상 %d개 라이브러리" % len(changed), "잠시 후 홈 데이터가 갱신됩니다", token=notice_token)
                visible_notice_started = True
        elif notice_progress and deferred_notice_progress:
            log("UPDATE_NOTIFY_DEFERRED stage=detected reason=wait_actual_changed_rows sections=%d caller=%s" % (len(changed), caller or ""), xbmc.LOGINFO)
        total_fetched = 0
        for index, changed_entry in enumerate(changed, start=1):
            section, remote_counts, local_counts, reason = changed_entry[:4]
            entry_latest_remote_rows = changed_entry[4] if len(changed_entry) > 4 else []
            entry_latest_local_rows = changed_entry[5] if len(changed_entry) > 5 else []
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=refresh_sections index=%d caller=%s" % (index, caller or ""), xbmc.LOGINFO)
                return False
            if progress and progress.iscanceled():
                break
            pct = 30 + int(((index - 1) / float(max(1, len(changed)))) * 70)
            progress_update(progress, pct, "메타데이터를 업데이트하고 있습니다\n%s" % _display_text_for_kodi(section.get("title", "")))
            if notice_progress and not deferred_notice_progress:
                pkm_notice_set("PKM 업데이트 중", "라이브러리 %d/%d 진행 중" % (index, len(changed)), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            before = local_section_counts(section["section_id"])
            if caller == "service_startup" and reason == "latest_item":
                fetched, total, elapsed, partial_stats = _startup_partial_sync_latest_items(
                    section,
                    latest_remote_rows=entry_latest_remote_rows,
                    latest_local_rows=entry_latest_local_rows,
                    caller=caller,
                    reason=reason,
                    limit=24,
                )
                log("STARTUP_SYNC_PARTIAL_APPLIED section=%s title=%s reason=%s fetched=%d total=%s elapsed=%.1f mode=latest_only_no_force_all" % (
                    section.get("section_id", ""), section.get("title", ""), reason, fetched, total, elapsed
                ), xbmc.LOGINFO)
            else:
                partial_stats = None
                fetched, total, elapsed = fetch_section_items(section["section_id"], section["section_type"], progress=None, prune_missing=True, force_all=True)
                if section.get("section_type") == PLEX_TYPE_SHOW:
                    repaired = _repair_tv_art_cache_integrity(
                        section["section_id"],
                        section_title=section.get("title", ""),
                        fetch_remote=False,
                        reason="startup_after_sync_%s" % (caller or "startup"),
                    )
                    if repaired:
                        log("STARTUP_SYNC_TV_ART_CACHE_REPAIRED section=%s title=%s repaired=%d reason=after_sync" % (
                            section.get("section_id", ""), section.get("title", ""), repaired
                        ), xbmc.LOGINFO)
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=after_fetch section=%s caller=%s" % (section.get("section_id", ""), caller or ""), xbmc.LOGINFO)
                return False
            after = local_section_counts(section["section_id"])
            total_fetched += fetched
            changed_stats = partial_stats if partial_stats is not None else _last_fetch_section_stats()
            section_actual_changes = 0
            for key in ("movie", "show", "episode"):
                changed_count = int(changed_stats.get(key, 0) or 0)
                if changed_count <= 0:
                    changed_count = max(0, int(after.get(key, 0) or 0) - int(before.get(key, 0) or 0))
                if changed_count > 0:
                    section_actual_changes += changed_count
                startup_stats[key] += changed_count
            if notice_progress and deferred_notice_progress and section_actual_changes > 0:
                visible_text = _format_startup_sync_notice(startup_stats)
                if not notice_token:
                    notice_token = pkm_notice_set("PKM 업데이트 중", visible_text or ("라이브러리 %d/%d 진행 중" % (index, len(changed))), _display_text_for_kodi(section.get("title", "")))
                    visible_notice_started = True
                    log("UPDATE_NOTIFY_STARTED stage=actual_changed_rows section=%s changed=%d text=%s" % (section.get("section_id", ""), section_actual_changes, visible_text or ""), xbmc.LOGINFO)
                elif visible_notice_started:
                    pkm_notice_set("PKM 업데이트 중", visible_text or ("라이브러리 %d/%d 진행 중" % (index, len(changed))), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            update_sync_state(section["section_id"], int(section.get("updated_at") or section.get("scanned_at") or 0), int(total or after.get("total", 0) or 0), synced=False if (caller == "service_startup" and reason == "latest_item") else True)
            log("STARTUP_SYNC_SECTION_DONE section=%s title=%s reason=%s fetched=%d total=%s elapsed=%.1f before=%s after=%s" % (
                section["section_id"], section.get("title", ""), reason, fetched, total, elapsed, before, after
            ), xbmc.LOGINFO)

        if progress:
            progress_update(progress, 100, "메타데이터 캐시 완료\n%d개 항목 확인" % total_fetched)
        set_initial_sync_done(True)
        set_last_auto_sync_at()
        state = load_state()
        state["startup_cache_completed_at"] = int(time.time())
        save_state(state)
        # v1554: widget invalidation is a correctness requirement, not a notice
        # side effect.  Signal after every committed changed-section sync even
        # when no visible notice is requested or changed-row statistics are zero.
        refresh_token_v1554 = _signal_home_data_refresh(reason="incremental_sync_committed_v1554")
        log("SYNC_WIDGET_REFRESH_SIGNAL_V1554 scope=incremental sections=%d fetched=%d token=%s movie=%d show=%d episode=%d" % (
            len(changed), total_fetched, refresh_token_v1554,
            startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)
        ), xbmc.LOGINFO)
        notice = _format_startup_sync_notice(startup_stats)
        if not notice and notice_progress:
            if notice_token:
                pkm_notice_clear(notice_token)
            _pkm_notice_clear_update(force=True)
            log("UPDATE_NOTIFY_SKIPPED stage=completed reason=no_actual_changed_rows caller=%s fetched=%d" % (caller or "", total_fetched), xbmc.LOGINFO)
        if notice and notice_progress:
            try:
                pkm_notice_set("PKM 업데이트 중", notice, "홈 위젯 갱신 중", token=notice_token)
                refresh_token = refresh_token_v1554
                applied = _wait_home_data_refresh_applied(refresh_token, timeout_ms=6500) if refresh_token else False
                if applied:
                    pkm_notice_set("PKM 업데이트 완료", notice, "홈 위젯 업데이트 완료", token=notice_token)
                    _pkm_notice_clear_later(notice_token, ms=1800)
                    log("UPDATE_NOTIFY_SHOWN stage=completed_visible_widgets movie=%d show=%d episode=%d text=%s refresh_token=%s auto_clear_ms=1800" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0), notice, refresh_token), xbmc.LOGINFO)
                else:
                    pkm_notice_set("새 콘텐츠 추가", notice, "Plex 라이브러리 동기화 완료", token=notice_token)
                    _pkm_notice_clear_later(notice_token, ms=3500)
                    log("UPDATE_NOTIFY_SHOWN stage=completed_new_content movie=%d show=%d episode=%d text=%s refresh_token=%s home_refresh_applied=0 auto_clear_ms=3500" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0), notice, refresh_token), xbmc.LOGINFO)
            except Exception as exc:
                log("UPDATE_NOTIFY_FAILED stage=completed_visible_widgets error=%s" % exc, xbmc.LOGWARNING)
                try:
                    pkm_notice_clear(notice_token)
                except Exception:
                    pass
        elif notice_progress and notice_token:
            pkm_notice_clear(notice_token)
        else:
            log("UPDATE_NOTIFY_SKIPPED stage=completed_added reason=silent_startup_sync movie=%d show=%d episode=%d" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)), xbmc.LOGINFO)
        # v1645: do not couple Cine21 collection to the opaque startup Plex
        # snapshot. This point owns only Plex freshness; Cine21 runs later from
        # the post-reveal idle worker and never triggers a same-run widget rebuild.
        log("CINE21_STARTUP_SYNC_DEFER_V1645 caller=%s reason=plex_sync_complete phase=post_reveal_next_start" % (caller or ""), xbmc.LOGINFO)
        log("STARTUP_SYNC_END sections=%d fetched=%d movie=%d show=%d episode=%d" % (len(changed), total_fetched, startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)), xbmc.LOGINFO)
        return True
    finally:
        if progress:
            try:
                log("STARTUP_SYNC_PROGRESS_CLOSE_BEGIN_V1747 caller=%s vis13032=%d" % (
                    caller or "", 1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0
                ), xbmc.LOGINFO)
            except Exception:
                pass
            try:
                xbmc.sleep(300)
            except Exception:
                pass
            progress.close()
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            try:
                log("STARTUP_SYNC_PROGRESS_CLOSE_REQUESTED_V1747 caller=%s" % (caller or ""), xbmc.LOGINFO)
            except Exception:
                pass
        release_sync_lock()

def auto_sync_due(env=None):
    _bind_env(env)
    if not setting_bool("auto_sync_on_start", True):
        return False
    if not clean_server_url() or not plex_token():
        return False
    interval_min = setting_int("auto_sync_interval_minutes", 60, min_value=0, max_value=10080)
    last = last_auto_sync_at()
    if last <= 0:
        return True
    if interval_min <= 0:
        return True
    return (time.time() - last) >= (interval_min * 60)

def maybe_trigger_background_auto_sync(caller="library", env=None):

    audit_event(None, "sync_maybe_trigger_background_auto_sync_enter")
    _bind_env(env)
    """Disabled: startup cache check/sync owns all PMS updates."""
    return False
