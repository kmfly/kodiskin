# -*- coding: utf-8 -*-
"""TV episode intro/next-episode flow for PKM v2223.

Scope is intentionally narrow:
- prepare the selected episode and exact same-season E+1 from local state before PlayMedia;
- reuse one bounded resolver metadata read for Plex intro/credits markers;
- show a small selectable playback overlay without changing the native playback path;
- use Plex credits marker when present; otherwise use a duration fallback;
- never infer an intro when Plex does not provide one.
"""
from __future__ import absolute_import, unicode_literals

import time
import traceback
import threading
import json
import os
import sqlite3
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ACTION_XML = "plexkm_episode_action_v2222.xml"

FLOW_PREFIX = "PlexKM.EpisodeFlowV2222."

# v2237 policy: the per-show value is only a fallback when Plex has no current
# credits marker. Plex marker data is authoritative and is read fresh at each
# playback boundary. The stored value is seconds before episode end.
_TIMING_LOCK_V2236 = threading.RLock()
_TIMING_FILENAME_V2236 = "next_episode_timing_v2236.json"


def _timing_path_v2236():
    try:
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile") or "")
        if profile:
            try:
                os.makedirs(profile, exist_ok=True)
            except Exception:
                pass
            return os.path.join(profile, _TIMING_FILENAME_V2236)
    except Exception:
        pass
    return ""


def _load_timing_map_v2236():
    path = _timing_path_v2236()
    if not path or not os.path.exists(path):
        return {}
    try:
        with _TIMING_LOCK_V2236:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        shows = raw.get("shows", {}) if isinstance(raw, dict) else {}
        if not isinstance(shows, dict):
            return {}
        out = {}
        for key, value in shows.items():
            try:
                sec = int(value)
            except Exception:
                continue
            if 5 <= sec <= 600:
                out[str(key)] = sec
        return out
    except Exception:
        return {}


def _save_timing_map_v2236(shows):
    path = _timing_path_v2236()
    if not path:
        return False
    tmp = path + ".tmp"
    try:
        payload = {"version": 1, "shows": dict(shows or {})}
        with _TIMING_LOCK_V2236:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, path)
        return True
    except Exception as exc:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _log("EPISODE_FLOW_NEXT_TIMING_SAVE_FAILED_V2236 err=%s" % exc, xbmc.LOGWARNING)
        return False


def get_show_next_offset_seconds_v2236(show_rating_key):
    key = str(show_rating_key or "").strip()
    if not key:
        return None
    return _load_timing_map_v2236().get(key)


def set_show_next_offset_seconds_v2236(show_rating_key, seconds):
    key = str(show_rating_key or "").strip()
    if not key:
        return False
    shows = _load_timing_map_v2236()
    if seconds is None:
        shows.pop(key, None)
        ok = _save_timing_map_v2236(shows)
        if ok:
            _log("EPISODE_FLOW_NEXT_TIMING_CLEAR_V2236 show=%s mode=auto" % key)
        return ok
    try:
        sec = max(5, min(600, int(seconds)))
    except Exception:
        return False
    shows[key] = sec
    ok = _save_timing_map_v2236(shows)
    if ok:
        _log("EPISODE_FLOW_NEXT_TIMING_SET_V2236 show=%s seconds_before_end=%s" % (key, sec))
    return ok


def _resolve_next_trigger_v2236(show_key, duration_ms, has_credits, credits_start):
    # v2237 authoritative priority:
    #   1) a current Plex credits marker always wins;
    #   2) only when Plex has no credits marker, use the saved per-show value;
    #   3) otherwise use PKM's duration fallback.
    # A user setting is therefore a fallback for marker-less episodes, never an
    # override of data that Plex later learned/updated.
    if has_credits:
        return max(0, int(credits_start)), "plex_credits_v2237", None
    custom_sec = get_show_next_offset_seconds_v2236(show_key)
    if custom_sec is not None and int(duration_ms or 0) > 0:
        return max(0, int(duration_ms) - (int(custom_sec) * 1000)), "show_fallback_v2237", custom_sec
    if int(duration_ms or 0) > 0:
        fallback_before = 30000 if int(duration_ms) < (30 * 60 * 1000) else 45000
        return max(0, int(duration_ms) - fallback_before), "pkm_default_v2237", None
    return -1, "", None


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _to_int(value, default=0):
    try:
        if value is None or str(value).strip() == "":
            return int(default)
        return int(float(value))
    except Exception:
        return int(default)


def _win():
    return xbmcgui.Window(10000)


def _set(name, value):
    try:
        _win().setProperty(FLOW_PREFIX + name, str(value if value is not None else ""))
    except Exception:
        pass


def _get(name):
    try:
        return _win().getProperty(FLOW_PREFIX + name) or ""
    except Exception:
        return ""


def _clear(name):
    try:
        _win().clearProperty(FLOW_PREFIX + name)
    except Exception:
        pass


def _arm_next_opening_v2227(next_rating_key=""):
    """Arm the established native opening cover for episode-to-episode handoff.

    Keep the playback contract unchanged: the actual next title is still opened by
    Kodi PlayMedia(plugin://...) and resolved by setResolvedUrl.  This helper only
    publishes the same Window(10000) lifecycle properties used by Info playback,
    with the spinner visible immediately because the user explicitly requested
    the next episode transition and the old video surface is about to disappear.
    """
    try:
        win = _win()
        rk = str(next_rating_key or "").strip()
        token = "%s-%d" % (rk, int(time.time() * 1000))
        # Match service.py::_resolver_pre_avstarted_v1547 ownership exactly so
        # Kodi's resolver placeholder Start/Stop cannot be mistaken for a real
        # playback stop during the replacement.
        win.setProperty("PlexKM.Playback.OpeningActive", "1")
        win.setProperty("PlexKM.Playback.OpeningRatingKey", rk)
        win.setProperty("PlexKM.Playback.NativeOpening.Pending", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.RatingKey", rk)
        win.setProperty("PlexKM.Playback.NativeOpening.Token", token)
        win.setProperty("PlexKM.Playback.NativeOpening.Source", "info_playmedia_native_v1454_locked")
        win.setProperty("PlexKM.Playback.NativeOpening.ArmedAtMs", str(int(time.time() * 1000)))
        win.setProperty("PlexKM.Playback.ResolverTokenV1547", token)
        win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "armed")
        for name in (
            "PlexKM.Playback.ResolverHandoffStopAtMsV1547",
            "PlexKM.Playback.ResolverAVStartedAtMsV1547",
            "PlexKM.Playback.ResolverTickHoldLoggedV1547",
            "PlexKM.Playback.OpenFailureCandidateV2224",
            "PlexKM.Playback.OpenFailureCandidateAtMsV2224",
            "PlexKM.Playback.FailureHomeRequestV2224",
            "PlexKM.Playback.FailureHomeRequestSourceV2224",
            "PlexKM.Playback.NativeOpening.HoldClear",
            "PlexKM.Playback.NativeOpening.WaitResumeV1551",
            "PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551",
        ):
            win.clearProperty(name)
        # FullscreenVideo already renders the native-opening spinner from the
        # opening flag.  Home's overlay gates its ring separately, so publish
        # SpinnerVisible immediately to guarantee there is never a visible Home
        # frame during a slow next-episode replacement.
        win.setProperty("PlexKM.Playback.NativeOpening", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.SpinnerVisible", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.ShownAtMs", str(int(time.time() * 1000)))
        win.setProperty("PlexKM.Playback.NextHandoffV2227", "1")
        win.setProperty("PlexKM.Playback.NextHandoffRatingKeyV2227", rk)
        _log("EPISODE_FLOW_NEXT_OPENING_ARM_V2227 next_rk=%s token=%s cover=1 spinner=1 native_playback_unchanged=1" % (rk, token))

        def _failure_watch(_token):
            try:
                monitor = xbmc.Monitor()
                if monitor.waitForAbort(15.0):
                    return
                w = _win()
                if w.getProperty("PlexKM.Playback.NativeOpening.Token") != _token:
                    return
                phase = w.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
                candidate = w.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
                try:
                    video = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                except Exception:
                    video = False
                if candidate and phase == "handoff_stop_blocked" and not video:
                    w.setProperty("PlexKM.Playback.FailureHomeRequestV2224", "1")
                    w.setProperty("PlexKM.Playback.FailureHomeRequestSourceV2224", "next_timeout_15s_v2227")
                    _log("EPISODE_FLOW_NEXT_OPENING_FAILURE_TIMEOUT_V2227 token=%s action=home" % _token)
                    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.km/?action=playback_failure_home_v2224&source=next_timeout_15s_v2227)")
            except Exception:
                pass
        threading.Thread(target=_failure_watch, args=(token,), name="PKMNextOpeningV2227", daemon=True).start()
        return token
    except Exception:
        _log("EPISODE_FLOW_NEXT_OPENING_ARM_FAILED_V2227 next_rk=%s err=%s" % (
            next_rating_key or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return ""


def clear_prepared(reason=""):
    for name in (
        "Prepared", "RatingKey", "DurationMs", "IntroStartMs", "IntroEndMs",
        "HasIntro", "CreditsStartMs", "HasCredits", "NextTriggerMs", "NextSource",
        "NextRatingKey", "NextPartKey", "NextSeason", "NextEpisode", "NextTitle",
        "NextPlayUrl", "CurrentPartKey", "PreparedAtMs", "ShowRatingKey", "SectionId",
    ):
        _clear(name)
    _log("EPISODE_FLOW_CLEAR_V2223 reason=%s" % (reason or ""))


def _first_video(root):
    try:
        if root is None:
            return None
        if getattr(root, "tag", "") == "Video":
            return root
        for node in list(root):
            if getattr(node, "tag", "") == "Video":
                return node
        for node in root.iter("Video"):
            return node
    except Exception:
        pass
    return None


def _marker_ranges(video):
    intros = []
    credits = []
    if video is None:
        return intros, credits
    try:
        for marker in video.iter("Marker"):
            mtype = str(marker.get("type") or "").strip().lower()
            start = _to_int(marker.get("startTimeOffset"), -1)
            end = _to_int(marker.get("endTimeOffset"), -1)
            if start < 0:
                continue
            entry = (start, end)
            if mtype == "intro":
                intros.append(entry)
            elif mtype == "credits":
                credits.append(entry)
    except Exception:
        pass
    intros.sort(key=lambda x: (x[0], x[1]))
    credits.sort(key=lambda x: (x[0], x[1]))
    return intros, credits



def _part_id_from_key_v2223(part_key):
    try:
        bits = [x for x in str(part_key or "").strip().split("/") if x]
        if len(bits) >= 3 and bits[0] == "library" and bits[1] == "parts":
            return str(bits[2] or "").strip()
    except Exception:
        pass
    return ""


def _part_key_from_video_v2223(video, preferred_part_key=""):
    if video is None:
        return ""
    preferred = str(preferred_part_key or "").strip()
    preferred_id = _part_id_from_key_v2223(preferred)
    parts = []
    try:
        for part in video.iter("Part"):
            key = str(part.get("key") or "").strip()
            if not key:
                continue
            pid = str(part.get("id") or _part_id_from_key_v2223(key) or "").strip()
            parts.append((pid, key))
    except Exception:
        parts = []
    if preferred:
        for pid, key in parts:
            if key == preferred:
                return key
        if preferred_id:
            for pid, key in parts:
                if pid == preferred_id:
                    return key
    if len(parts) == 1:
        return parts[0][1]
    return ""


def _find_video_by_rating_key_v2223(root, rating_key):
    target = str(rating_key or "").strip()
    if root is None or not target:
        return None
    try:
        for video in root.iter("Video"):
            if str(video.get("ratingKey") or "").strip() == target:
                return video
    except Exception:
        pass
    return None


def _next_video_from_all_leaves_v2223(root, current_rating_key, season, episode):
    """Find only exact E+1 inside the exact Plex parentIndex/season.

    v2237: season identity is authoritative. S01 stays S01 and S101 stays
    S101. There is deliberately no season-boundary fallback, so a season's
    final episode has no next-episode prompt.
    """
    current_rk = str(current_rating_key or "").strip()
    season_i = _to_int(season, -1)
    episode_i = _to_int(episode, -1)
    if root is None or season_i < 0 or episode_i < 0:
        return None
    try:
        for video in root.iter("Video"):
            rk = str(video.get("ratingKey") or "").strip()
            if not rk or rk == current_rk:
                continue
            s = _to_int(video.get("parentIndex"), -1)
            e = _to_int(video.get("index"), -1)
            if s == season_i and e == episode_i + 1:
                return video
    except Exception:
        return None
    return None


def _row_field(row, index, default=""):
    try:
        if row is None or len(row) <= index:
            return default
        value = row[index]
        return default if value is None else value
    except Exception:
        return default


def _next_episode_from_rows(rows, current_rating_key, season, episode):
    """Return exact E+1 inside the exact season only (v2237 policy)."""
    current_rating_key = str(current_rating_key or "")
    season_i = _to_int(season, -1)
    episode_i = _to_int(episode, -1)
    if season_i < 0 or episode_i < 0:
        return None
    for row in list(rows or []):
        rk = str(_row_field(row, 0, "") or "")
        if not rk or rk == current_rating_key:
            continue
        s = _to_int(_row_field(row, 19, -1), -1)
        e = _to_int(_row_field(row, 20, -1), -1)
        if s == season_i and e == episode_i + 1:
            return row
    return None


def _build_start_url(core, rating_key, part_key):
    try:
        return core.build_plugin_url({
            "action": "play",
            "rating_key": str(rating_key or ""),
            "part_key": str(part_key or ""),
            "start": "0",
            "noresume": "1",
            "pkm_resume_policy": "start",
        })
    except Exception:
        return ""


def prepare_for_playback(core, item, actual_rating_key=""):
    """Prepare episode playback without network work on the click path (v2380).

    The Info click must reach native PlayMedia immediately.  Current duration,
    ownership and the exact E+1 candidate come from the selected ListItem/local
    DB only.  The resolver performs one bounded metadata read and calls
    refresh_prepared_from_metadata_v2380() before setResolvedUrl so Plex intro /
    credits markers still become authoritative when available.
    """
    clear_prepared(reason="prepare_begin_v2380")
    if core is None or item is None:
        return False

    source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
    rating_key = str(actual_rating_key or source_rk or "").strip()
    if not rating_key:
        return False

    item_type = str(item.getProperty("PlexKM.Type") or "").strip().lower()
    if item_type and item_type != "episode":
        return False

    section_id = str(item.getProperty("PlexKM.SectionId") or "").strip()
    show_key = str(item.getProperty("PlexKM.GrandparentRatingKey") or "").strip()
    season = str(item.getProperty("PlexKM.Season") or "").strip()
    episode = str(item.getProperty("PlexKM.Episode") or "").strip()
    duration_ms = _to_int(item.getProperty("PlexKM.Duration"), 0)
    preferred_part_key = str(
        item.getProperty("PlexKM.VersionSelectedPartKey")
        or item.getProperty("PlexKM.PartKey")
        or ""
    ).strip()

    next_row = None
    rows = []
    if show_key and section_id:
        try:
            rows = list(core.query_episodes_for_show(section_id, show_key) or [])
            next_row = _next_episode_from_rows(rows, rating_key, season, episode)
        except Exception as exc:
            _log("EPISODE_FLOW_NEXT_LOCAL_FAILED_V2380 rk=%s show=%s err=%s" % (
                rating_key, show_key, exc
            ), xbmc.LOGWARNING)

    next_rk = next_part = next_season = next_episode = next_title = next_url = ""
    next_trigger = -1
    next_source = ""
    if next_row is not None:
        next_rk = str(_row_field(next_row, 0, "") or "").strip()
        next_title = str(_row_field(next_row, 4, "") or "").strip()
        next_part = str(_row_field(next_row, 15, "") or "").strip()
        next_season = str(_row_field(next_row, 19, "") or "").strip()
        next_episode = str(_row_field(next_row, 20, "") or "").strip()
        if next_rk and next_part:
            next_url = _build_start_url(core, next_rk, next_part)
            next_trigger, next_source, custom_sec_v2236 = _resolve_next_trigger_v2236(
                show_key, duration_ms, False, -1
            )
            if custom_sec_v2236 is not None:
                _log("EPISODE_FLOW_NEXT_TIMING_LOCAL_V2380 show=%s rk=%s seconds_before_end=%s trigger=%s source=%s" % (
                    show_key, rating_key, custom_sec_v2236, next_trigger, next_source
                ))

    _set("RatingKey", rating_key)
    _set("CurrentPartKey", preferred_part_key)
    _set("DurationMs", duration_ms)
    _set("HasIntro", "")
    _set("IntroStartMs", "")
    _set("IntroEndMs", "")
    _set("HasCredits", "")
    _set("CreditsStartMs", "")
    _set("NextTriggerMs", next_trigger if next_trigger >= 0 and next_url else "")
    _set("NextSource", next_source if next_url else "")
    _set("NextRatingKey", next_rk)
    _set("NextPartKey", next_part)
    _set("NextSeason", next_season)
    _set("NextEpisode", next_episode)
    _set("NextTitle", next_title)
    _set("NextPlayUrl", next_url)
    _set("ShowRatingKey", show_key)
    _set("SectionId", section_id)
    _set("PreparedAtMs", int(time.time() * 1000))
    _set("Prepared", "1")

    _log(
        "EPISODE_FLOW_PREPARED_LOCAL_V2380 rk=%s source_rk=%s s=%s e=%s duration=%s "
        "next_rk=%s next_s=%s next_e=%s next_trigger=%s next_source=%s local_rows=%s network=0" % (
            rating_key, source_rk, season, episode, duration_ms,
            next_rk, next_season, next_episode, next_trigger, next_source or "none", len(rows)
        )
    )
    return True


def refresh_prepared_from_metadata_v2380(root, rating_key, preferred_part_key=""):
    """Refresh prepared marker state from the resolver's single Plex XML read.

    No request is made here.  The resolver owns the bounded metadata request and
    supplies the parsed XML before Kodi receives setResolvedUrl.
    """
    rk = str(rating_key or "").strip()
    if root is None or not rk:
        return False
    if _get("Prepared") != "1" or str(_get("RatingKey") or "").strip() != rk:
        return False
    video = _find_video_by_rating_key_v2223(root, rk)
    if video is None:
        video = _first_video(root)
    if video is None:
        return False

    duration_ms = _to_int(video.get("duration"), _to_int(_get("DurationMs"), 0))
    show_key = str(video.get("grandparentRatingKey") or _get("ShowRatingKey") or "").strip()
    live_part_key = _part_key_from_video_v2223(video, preferred_part_key or _get("CurrentPartKey"))
    intros, credits = _marker_ranges(video)
    has_intro = bool(intros)
    intro_start = intros[0][0] if has_intro else -1
    intro_end = intros[0][1] if has_intro else -1
    has_credits = bool(credits)
    credits_start = credits[0][0] if has_credits else -1

    next_url = str(_get("NextPlayUrl") or "").strip()
    next_trigger = -1
    next_source = ""
    if next_url:
        next_trigger, next_source, custom_sec_v2236 = _resolve_next_trigger_v2236(
            show_key, duration_ms, has_credits, credits_start
        )
        if custom_sec_v2236 is not None:
            _log("EPISODE_FLOW_NEXT_TIMING_RESOLVER_V2380 show=%s rk=%s seconds_before_end=%s trigger=%s source=%s" % (
                show_key, rk, custom_sec_v2236, next_trigger, next_source
            ))

    _set("CurrentPartKey", live_part_key or preferred_part_key or _get("CurrentPartKey"))
    _set("DurationMs", duration_ms)
    _set("HasIntro", "1" if has_intro and intro_end > intro_start >= 0 else "")
    _set("IntroStartMs", intro_start if has_intro else "")
    _set("IntroEndMs", intro_end if has_intro else "")
    _set("HasCredits", "1" if has_credits else "")
    _set("CreditsStartMs", credits_start if has_credits else "")
    _set("NextTriggerMs", next_trigger if next_trigger >= 0 and next_url else "")
    _set("NextSource", next_source if next_url else "")
    _set("ShowRatingKey", show_key)
    _set("PreparedAtMs", int(time.time() * 1000))
    _log("EPISODE_FLOW_RESOLVER_METADATA_APPLY_V2380 rk=%s duration=%s intro=%s-%s credits=%s next_trigger=%s next_source=%s network=0_reuse" % (
        rk, duration_ms, intro_start, intro_end, credits_start, next_trigger, next_source or "none"
    ))
    return True


def _build_start_url_runtime_v2227(rating_key, part_key):
    try:
        return "plugin://%s/?%s" % (ADDON_ID, urlencode({
            "action": "play",
            "rating_key": str(rating_key or ""),
            "part_key": str(part_key or ""),
            "start": "0",
            "noresume": "1",
            "pkm_resume_policy": "start",
        }))
    except Exception:
        return ""


def _query_local_episode_rows_v2380(show_key, section_id):
    """Read the cached show episode rows without importing default.py or Plex."""
    show_key = str(show_key or "").strip()
    section_id = str(section_id or "").strip()
    if not show_key or not section_id:
        return []
    db_path = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/plex_km.db" % ADDON_ID
    )
    if not db_path or not os.path.exists(db_path):
        return []
    conn = None
    try:
        conn = sqlite3.connect(db_path, timeout=0.15)
        # v2380R1: chained playback must also work against an older-but-valid
        # local DB.  Read only columns that have existed throughout the episode
        # cache lifetime; do not depend on later resume/view-offset migrations.
        # Empty literals keep the established row indexes used by _row_field().
        return conn.execute("""
            SELECT rating_key, '', '', '', title, '', '', '', '', '', '', '', '', '', '', part_key,
                   '', '', '', season, episode
            FROM items
            WHERE section_id=? AND plex_type='episode' AND grandparent_rating_key=?
            ORDER BY season ASC, episode ASC, title COLLATE NOCASE ASC
        """, (section_id, show_key)).fetchall()
    except Exception as exc:
        _log("EPISODE_FLOW_LOCAL_DB_QUERY_FAILED_V2380 show=%s section=%s err=%s" % (
            show_key, section_id, exc
        ), xbmc.LOGWARNING)
        return []
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def _prepare_runtime_episode_v2227(rating_key, preferred_part_key=""):
    """Prepare chained next-episode playback without pre-PlayMedia network I/O.

    The previous prepared state already contains the selected next episode's
    show/season/episode identity.  Preserve that identity, find E+1 from the
    local DB, and let the resolver's one bounded metadata read refresh current
    markers/duration before setResolvedUrl.
    """
    rk = str(rating_key or "").strip()
    if not rk:
        return False

    # Capture the selected-next identity before clearing the previous episode.
    show_key = str(_get("ShowRatingKey") or "").strip()
    section_id = str(_get("SectionId") or "").strip()
    season = str(_get("NextSeason") or "").strip()
    episode = str(_get("NextEpisode") or "").strip()
    next_title_current = str(_get("NextTitle") or "").strip()
    part_key = str(preferred_part_key or _get("NextPartKey") or "").strip()

    clear_prepared(reason="next_runtime_prepare_local_v2380")
    try:
        rows = _query_local_episode_rows_v2380(show_key, section_id)
        next_row = _next_episode_from_rows(rows, rk, season, episode)
        next_rk = next_part = next_season = next_episode = next_title = next_url = ""
        if next_row is not None:
            next_rk = str(_row_field(next_row, 0, "") or "").strip()
            next_title = str(_row_field(next_row, 4, "") or "").strip()
            next_part = str(_row_field(next_row, 15, "") or "").strip()
            next_season = str(_row_field(next_row, 19, "") or "").strip()
            next_episode = str(_row_field(next_row, 20, "") or "").strip()
            if next_rk and next_part:
                next_url = _build_start_url_runtime_v2227(next_rk, next_part)

        _set("RatingKey", rk)
        _set("CurrentPartKey", part_key)
        _set("DurationMs", "")
        _set("HasIntro", "")
        _set("IntroStartMs", "")
        _set("IntroEndMs", "")
        _set("HasCredits", "")
        _set("CreditsStartMs", "")
        _set("NextTriggerMs", "")
        _set("NextSource", "")
        _set("NextRatingKey", next_rk)
        _set("NextPartKey", next_part)
        _set("NextSeason", next_season)
        _set("NextEpisode", next_episode)
        _set("NextTitle", next_title)
        _set("NextPlayUrl", next_url)
        _set("ShowRatingKey", show_key)
        _set("SectionId", section_id)
        _set("PreparedAtMs", int(time.time() * 1000))
        _set("Prepared", "1")
        _log("EPISODE_FLOW_NEXT_RUNTIME_PREPARED_LOCAL_V2380 rk=%s title=%s s=%s e=%s next_rk=%s next_s=%s next_e=%s local_rows=%d network=0" % (
            rk, next_title_current, season, episode, next_rk, next_season, next_episode, len(rows)
        ))
        return True
    except Exception:
        _log("EPISODE_FLOW_NEXT_RUNTIME_PREPARE_FAILED_V2380 rk=%s err=%s" % (
            rk, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return False




class PKMEpisodeActionDialogV2222(xbmcgui.WindowXMLDialog):
    BUTTON_ID = 100

    def __init__(self, *args, **kwargs):
        self.choice = False
        self.kind = str(kwargs.pop("kind", "") or "")
        super(PKMEpisodeActionDialogV2222, self).__init__(*args, **kwargs)

    def onClick(self, control_id):
        if int(control_id or 0) == self.BUTTON_ID:
            self.choice = True
            self.close()

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = -1
        if aid in (9, 10, 92, 216, 247):
            self.choice = False
            self.close()


class EpisodeFlowRuntimeV2222(object):
    """Small service-owned runtime for one currently playing episode."""

    def __init__(self):
        self.rating_key = ""
        self.intro_shown = False
        self.next_shown = False
        self.prompt = None
        self.prompt_kind = ""
        self.prompt_until = 0.0
        self._session_started = False

    def _close_prompt(self, reason=""):
        try:
            if self.prompt is not None:
                self.prompt.close()
        except Exception:
            pass
        self.prompt = None
        self.prompt_kind = ""
        self.prompt_until = 0.0
        for key in ("PromptVisible", "PromptKind", "PromptLabel", "PromptDetail"):
            _clear(key)
        if reason:
            _log("EPISODE_FLOW_PROMPT_CLOSE_V2222 reason=%s" % reason)

    def reset(self, reason=""):
        self._close_prompt(reason="reset_%s" % (reason or ""))
        self.rating_key = ""
        self.intro_shown = False
        self.next_shown = False
        self._session_started = False

    def on_av_started(self, rating_key):
        self._close_prompt(reason="new_av_started")
        self.rating_key = str(rating_key or "").strip()
        self.intro_shown = False
        self.next_shown = False
        self._session_started = True
        prepared_rk = _get("RatingKey")
        _log("EPISODE_FLOW_SESSION_BEGIN_V2223 playing_rk=%s prepared_rk=%s prepared=%s" % (
            self.rating_key, prepared_rk, _get("Prepared") or "0"
        ))

    def _open_prompt(self, kind, label, detail, timeout_sec):
        if self.prompt is not None:
            return False
        try:
            _set("PromptVisible", "1")
            _set("PromptKind", kind)
            _set("PromptLabel", label)
            _set("PromptDetail", detail)
            self.prompt = PKMEpisodeActionDialogV2222(
                ACTION_XML, ADDON.getAddonInfo("path"), "Default", "1080i", kind=kind
            )
            self.prompt_kind = kind
            self.prompt_until = time.time() + max(0.25, float(timeout_sec or 0.25))
            self.prompt.show()
            _log("EPISODE_FLOW_PROMPT_OPEN_V2223 kind=%s timeout=%.2f detail=%s" % (
                kind, float(timeout_sec or 0), detail or ""
            ))
            return True
        except Exception:
            self._close_prompt(reason="open_failed")
            _log("EPISODE_FLOW_PROMPT_OPEN_FAILED_V2222 kind=%s err=%s" % (
                kind, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _consume_prompt(self, player):
        if self.prompt is None:
            return False
        choice = bool(getattr(self.prompt, "choice", False))
        kind = self.prompt_kind
        if choice:
            self._close_prompt(reason="selected_%s" % kind)
            if kind == "intro":
                end_ms = _to_int(_get("IntroEndMs"), -1)
                if end_ms >= 0:
                    try:
                        # v2226: Plex owns the exact introEnd target, but the
                        # actual seek uses the same Kodi-native relative Seek()
                        # path as PKM VideoOSD. Direct Player.seekTime() could
                        # fire onPlayBackSeek while the player clock remained
                        # stuck on the old frame under slow Range delivery.
                        from resources.lib import pkm_seek_quick
                        target_sec = float(end_ms) / 1000.0
                        ok = bool(pkm_seek_quick.request_absolute_native_seek_v2226(
                            target_sec, source="plex_intro_exact_v2226"
                        ))
                        if not ok:
                            raise RuntimeError("native_intro_seek_dispatch_failed_v2226")
                        _log("EPISODE_FLOW_INTRO_SKIP_V2226 rk=%s target_ms=%s owner=plex native_seek=1" % (self.rating_key, end_ms))
                    except Exception as exc:
                        _log("EPISODE_FLOW_INTRO_SKIP_FAILED_V2226 rk=%s err=%s" % (self.rating_key, exc), xbmc.LOGWARNING)
                return True
            if kind == "next":
                play_url = _get("NextPlayUrl")
                next_rk = _get("NextRatingKey")
                if play_url:
                    try:
                        next_part = _get("NextPartKey")
                        _arm_next_opening_v2227(next_rk)
                        # Prepare E(n+1)'s own intro/end plan behind the spinner so
                        # chained next-episode playback keeps working without an
                        # intervening Info page. The already-resolved play_url is
                        # retained locally, so preparation failure never blocks play.
                        _prepare_runtime_episode_v2227(next_rk, next_part)
                        xbmc.executebuiltin("PlayMedia(%s,noresume)" % play_url)
                        _log("EPISODE_FLOW_NEXT_PLAY_V2227 from_rk=%s next_rk=%s native_playmedia=1 opening_cover=1 spinner=1 runtime_prepared=%s" % (
                            self.rating_key, next_rk, "1" if _get("RatingKey") == str(next_rk or "") else "0"
                        ))
                    except Exception as exc:
                        _log("EPISODE_FLOW_NEXT_PLAY_FAILED_V2222 from_rk=%s next_rk=%s err=%s" % (
                            self.rating_key, next_rk, exc
                        ), xbmc.LOGWARNING)
                return True
        if kind == "intro":
            try:
                pos_ms = int(float(player.getTime() or 0) * 1000.0)
            except Exception:
                pos_ms = 0
            intro_start = _to_int(_get("IntroStartMs"), -1)
            intro_end = _to_int(_get("IntroEndMs"), -1)
            if intro_end >= 0 and (pos_ms >= intro_end or (intro_start >= 0 and pos_ms < intro_start)):
                self._close_prompt(reason="marker_exit_intro")
                return True
            # Wall-clock deadline is only a safety net; normal lifetime follows
            # the Plex marker so pausing the video does not consume skip time.
            if time.time() >= self.prompt_until + 30.0:
                self._close_prompt(reason="safety_timeout_intro")
                return True
            return False
        if time.time() >= self.prompt_until:
            self._close_prompt(reason="timeout_%s" % kind)
            return True
        return False

    def tick(self, player):
        try:
            if player is None or not player.isPlayingVideo():
                if self.prompt is not None:
                    self._close_prompt(reason="not_playing")
                return
        except Exception:
            return

        if not self._session_started:
            return

        if self.prompt is not None:
            self._consume_prompt(player)
            if self.prompt is not None:
                return

        prepared_rk = _get("RatingKey")
        if not prepared_rk or prepared_rk != self.rating_key or _get("Prepared") != "1":
            return

        try:
            pos_ms = int(float(player.getTime() or 0) * 1000.0)
        except Exception:
            pos_ms = 0

        if not self.intro_shown and _get("HasIntro") == "1":
            intro_start = _to_int(_get("IntroStartMs"), -1)
            intro_end = _to_int(_get("IntroEndMs"), -1)
            if intro_start >= 0 and intro_end > intro_start and intro_start <= pos_ms < intro_end:
                # Keep the skip control available for the remaining Plex intro
                # marker interval. Back dismisses it immediately if desired.
                remaining_sec = max(0.5, float(intro_end - pos_ms) / 1000.0)
                self.intro_shown = True
                self._open_prompt("intro", "인트로 건너뛰기", "", remaining_sec)
                return

        if not self.next_shown:
            next_url = _get("NextPlayUrl")
            trigger_ms = _to_int(_get("NextTriggerMs"), -1)
            if next_url and trigger_ms >= 0 and pos_ms >= trigger_ms:
                s = _to_int(_get("NextSeason"), 0)
                e = _to_int(_get("NextEpisode"), 0)
                title = _get("NextTitle")
                detail_parts = []
                if s > 0 and e > 0:
                    detail_parts.append("S%02d E%02d" % (s, e))
                if title:
                    detail_parts.append(title)
                self.next_shown = True
                self._open_prompt("next", "다음 화 재생", "  ".join(detail_parts), 5.0)
                _log("EPISODE_FLOW_NEXT_TRIGGER_V2223 rk=%s pos=%s trigger=%s source=%s next_rk=%s" % (
                    self.rating_key, pos_ms, trigger_ms, _get("NextSource") or "", _get("NextRatingKey") or ""
                ))
                return
