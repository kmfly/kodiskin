# PKM_PATCH_ACTIVE v2640 tv_first_episode_hotpath
# SIDEBAR_POLICY_V2640 no_long_correlated_cte=1 bounded_index_seek=1 movie_path_unchanged=1 section_hardcode=0
# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import random


_KODI_DISPLAY_TRANSLATE = {
    ord("\u23D0"): "|",
}

def display_library_title(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def tv_episode_row_columns_sql(alias="i"):
    """Return the common SELECT column list for TV episode recommendation rows."""
    a = (str(alias or "i").strip() or "i") + "."
    return ", ".join([
        a + "rating_key",
        a + "section_id",
        a + "plex_type",
        "'' AS kodi_type",
        a + "title",
        "'' AS original_title",
        a + "title AS sort_title",
        a + "year",
        a + "summary",
        a + "duration",
        a + "added_at",
        a + "updated_at",
        a + "thumb",
        a + "art",
        a + "media_file",
        a + "part_key",
        a + "view_count",
        a + "last_viewed_at",
        a + "show_title",
        a + "season",
        a + "episode",
        a + "parent_rating_key",
        a + "grandparent_rating_key",
    ])


def tv_rows_from_episode_map(episode_map, show_keys, exclude_keys=None, limit=None, row_item_limit=24, allow_duplicate_fallback=False, speed_log=None):
    """Return episode rows for TV show keys using an existing show->episode map.

    This is data-only. It preserves cross-row duplicate suppression but allows
    duplicate fallback only when duplicate filtering would otherwise remove the
    whole row.
    """
    try:
        max_rows = int(limit or row_item_limit)
    except Exception:
        max_rows = int(row_item_limit or 24)
    excluded = set(str(x) for x in (exclude_keys or []) if str(x or "").strip())
    out = []
    skipped_by_exclude = []
    seen_in_row = set()
    ordered_keys = []
    seen_show = set()
    for show_key in show_keys or []:
        skey = str(show_key or "").strip()
        if skey and skey not in seen_show:
            seen_show.add(skey)
            ordered_keys.append(skey)
    for skey in ordered_keys:
        row = (episode_map or {}).get(skey)
        if not row:
            continue
        try:
            rk = str(tuple(row)[0] or "")
            if rk and rk in seen_in_row:
                continue
            if rk and rk in excluded:
                skipped_by_exclude.append(row)
                continue
            if rk:
                excluded.add(rk)
                seen_in_row.add(rk)
        except Exception:
            pass
        out.append(row)
        if len(out) >= max_rows:
            break
    if (not out) and allow_duplicate_fallback and skipped_by_exclude:
        seen_fallback = set()
        for row in skipped_by_exclude:
            try:
                rk = str(tuple(row)[0] or "")
                if rk and rk in seen_fallback:
                    continue
                if rk:
                    seen_fallback.add(rk)
            except Exception:
                pass
            out.append(row)
            if len(out) >= max_rows:
                break
        if speed_log:
            try:
                speed_log("tv_rows_duplicate_fallback", rows=len(out), skipped=len(skipped_by_exclude), shows=len(ordered_keys), limit=max_rows)
            except Exception:
                pass
    return out


def tv_cache_limit(limit=None, row_item_limit=24):
    try:
        return max(1, min(int(row_item_limit), int(limit or row_item_limit)))
    except Exception:
        return int(row_item_limit or 24)


def tv_candidate_limit(limit=None, row_item_limit=24):
    row_limit = tv_cache_limit(limit, row_item_limit=row_item_limit)
    return min(max(row_limit * 2, int(row_item_limit or 24) + 12), 48)


def _ordered_unique(values):
    out = []
    seen = set()
    for value in values or []:
        key = str(value or "").strip()
        if key and key not in seen:
            seen.add(key)
            out.append(key)
    return out


def tv_first_episode_row_map_from_show_keys(conn, section_id, show_keys, columns_sql=None):
    """V2640: bounded indexed seeks; never one long correlated CTE on sidebar hotpath.

    The previous V2631 VALUES + correlated-subquery statement could monopolize the
    SQLite call for many seconds on some TV libraries.  One indexed LIMIT 1 seek per
    requested show keeps each DB operation short and preserves identical first-episode
    ordering.  The caller's show-key order remains authoritative.
    """
    sid = str(section_id or "").strip()
    ordered = _ordered_unique(show_keys)
    if not sid or not ordered:
        return {}

    row_by_show = {}
    cols = columns_sql or tv_episode_row_columns_sql("i")
    sql = """
        SELECT %s
        FROM items i
        WHERE i.section_id=?
          AND i.plex_type='episode'
          AND i.grandparent_rating_key=?
        ORDER BY COALESCE(i.season,0) ASC,
                 COALESCE(i.episode,0) ASC,
                 i.rating_key ASC
        LIMIT 1
    """ % cols

    # V2640 deliberately avoids a single long-running SQL statement.  If a library
    # is cold or large, control returns to Python after every tiny indexed seek.
    for skey in ordered:
        try:
            row = conn.execute(sql, (sid, skey)).fetchone()
        except Exception:
            row = None
        if row:
            row_by_show[skey] = row
    return row_by_show

