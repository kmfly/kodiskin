# -*- coding: utf-8 -*-
"""PlexKM 뮤직비디오 앨범아트·가수 사진 수집(이름 읽기 모듈의 2단계).

색인(parser/store 결과)의 가수·곡 이름으로 Deezer(가수·앨범·곡)와 iTunes(미국 스토어)를 조회해
가수 사진, 앨범 자켓 목록, 곡별 자켓을 캐시 파일에 저장한다. Kodi 없이도 동작한다.
화면·DB 반영은 쓰는 쪽(플러그인)이 하고, 여기서는 '조회와 캐시'만 한다.

configure(data_dir, log=None, aborted=None, wait=None) 로 캐시 폴더와 로그/중단 확인 함수를 넘긴다.
"""
import json
import os
import re
import threading
import time
import unicodedata

try:
    from urllib.parse import quote
    from urllib.request import Request, urlopen
except ImportError:  # pragma: no cover
    from urllib import quote
    from urllib2 import Request, urlopen

from . import parser as P

_CFG = {"dir": ".", "log": None, "aborted": None, "wait": None}


def configure(data_dir, log=None, aborted=None, wait=None):
    """data_dir: 캐시 json 을 둘 폴더. log(msg, warn=False). aborted() -> 종료 요청 여부. wait(sec) -> 종료 요청이면 True."""
    _CFG["dir"] = data_dir
    _CFG["log"] = log
    _CFG["aborted"] = aborted
    _CFG["wait"] = wait
    _ART_CACHE[0] = None
    _SONG_CACHE[0] = None


def _log(msg, warn=False):
    f = _CFG.get("log")
    if f:
        try:
            f(msg, warn)
        except Exception:
            pass


class _Mon(object):
    def abortRequested(self):
        f = _CFG.get("aborted")
        return bool(f and f())

    def waitForAbort(self, sec):
        f = _CFG.get("wait")
        if f:
            return bool(f(sec))
        time.sleep(sec)
        return False


class _XBMC(object):
    Monitor = _Mon


xbmc = _XBMC()


class _Agent(object):
    parser = P


_agent = _Agent()

_ART_LOCK = threading.Lock()
_ART_CACHE = [None]
_ART_RUNNING = [False]


def _art_path():
    return os.path.join(_CFG["dir"], "pkm_mv_artist_art.json")


def _norm_name(x):
    import re as _re
    return _re.sub(r"[^0-9a-z가-힣]+", "", str(x or "").lower())


def _artist_forms(name):
    """'(여자)아이들((G)I-DLE)' -> 시험해 볼 이름들(영문 우선). 끝의 괄호 묶음을 짝을 맞춰 떼어 낸다."""
    import re as _re
    name = str(name or "").strip()
    forms = []
    if name.endswith(")"):
        depth = 0
        for i in range(len(name) - 1, -1, -1):
            c = name[i]
            depth += 1 if c == ")" else (-1 if c == "(" else 0)
            if depth == 0:
                head, inner = name[:i].strip(), name[i + 1:-1].strip()
                if head and inner:
                    pair = (inner, head) if (_re.search(r"[A-Za-z]", inner) and not _re.search(r"[A-Za-z]", head)) else (head, inner)
                    forms.extend(pair)
                break
    if name not in forms:
        forms.append(name)
    import re as _re2
    first = _re2.split(r"\s+[xX]\s+|\s*,\s*|\s*&\s*|\s*\(?[Ff]eat\.?", name)[0].strip()
    if first and first != name:                 # 'A X B', 'A, B' 같은 협업은 첫 가수 이름도 시험한다
        sub = _artist_forms(first)
        forms.extend(sub[:2])
    out = []
    for f in forms:
        if f and f not in out:
            out.append(f)
    return out[:4]


def artist_art_cache():
    if _ART_CACHE[0] is None:
        try:
            import json
            with open(_art_path(), "r", encoding="utf-8") as f:
                _ART_CACHE[0] = json.load(f)
        except Exception:
            _ART_CACHE[0] = {}
    return _ART_CACHE[0]


def _save_art_cache():
    try:
        import json
        tmp = _art_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_ART_CACHE[0] or {}, f, ensure_ascii=False)
        os.replace(tmp, _art_path())
    except Exception:
        pass


def _audiodb(name):
    import json
    try:
        from urllib.request import Request, urlopen
    except ImportError:  # pragma: no cover
        return None
    url = "https://www.theaudiodb.com/api/v1/json/123/search.php?s=" + quote(name)
    req = Request(url, headers={"User-Agent": "PlexKM/1.0"})
    with urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data.get("artists") or []


def _deezer_artist(name):
    import json
    from urllib.request import Request, urlopen
    url = "https://api.deezer.com/search/artist?limit=3&q=" + quote(name)
    req = Request(url, headers={"User-Agent": "PlexKM/1.0"})
    with urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data.get("data") or []




_DZ_LOCK = threading.Lock()
_DZ_LAST = [0.0]


def _dz_get(url, tries=3):
    """Deezer 호출. 전체 초당 8회 안쪽으로 맞추고, 한도 오류·일시 오류는 잠깐 쉬고 다시 시도한다."""
    import json
    from urllib.request import Request, urlopen
    last = None
    for n in range(tries):
        with _DZ_LOCK:
            wait = _DZ_LAST[0] + 0.125 - time.time()
            if wait > 0:
                time.sleep(wait)
            _DZ_LAST[0] = time.time()
        try:
            with urlopen(Request(url, headers={"User-Agent": "PlexKM/1.0"}), timeout=10) as r:
                d = json.loads(r.read().decode("utf-8", "replace") or "{}")
            err = d.get("error") if isinstance(d, dict) else None
            if isinstance(err, dict) and err.get("code") in (4, 100):
                time.sleep(2.0 * (n + 1))
                last = RuntimeError("quota")
                continue
            return d
        except Exception as e:
            last = e
            time.sleep(0.6 * (n + 1))
    raise last


def _albums_of(dz_id):
    out, seen = [], set()
    for al in (_dz_get("https://api.deezer.com/artist/%s/albums?limit=100" % dz_id).get("data") or []):
        c = al.get("cover_xl") or al.get("cover_big") or ""
        if not c or "/album//" in c or al.get("record_type") not in ("album", "single", "ep"):
            continue
        k = _norm_name(al.get("title"))
        if k in seen:
            continue
        seen.add(k)
        out.append({"t": al.get("title") or "", "c": c, "y": str(al.get("release_date") or "")[:4]})
    return out


def _overlap(albums, titles):
    """이 가수의 앨범·싱글 제목 중 우리 곡 제목과 겹치는 개수(동명이인을 가려내는 데 쓴다)."""
    from difflib import SequenceMatcher
    n = 0
    for t in titles:
        tv = set(_agent.parser.title_variants(t)) if (_agent and hasattr(_agent, "parser")) else set([_norm_name(t)])
        for al in albums:
            av = set(_agent.parser.title_variants(al["t"])) if (_agent and hasattr(_agent, "parser")) else set([_norm_name(al["t"])])
            if any(x == y or (len(x) >= 4 and (x in y or y in x)) or SequenceMatcher(None, x, y).ratio() >= 0.88 for x in tv for y in av if x and y):
                n += 1
                break
    return n


def _fast_artist(a, titles=()):
    """가수 한 팀: Deezer 가수 사진(1000px) + 앨범·싱글 자켓 목록. 동명 가수가 여럿이면 우리 곡 제목과 앨범이 겹치는 쪽을 고른다.
    확인할 수 없는 동명 가수는 쓰지 않는다. 실패하면 예외(다음 실행에서 다시)."""
    want = set(_norm_name(f) for f in _artist_forms(a))
    cands, seen = [], set()
    for form in _artist_forms(a)[:4]:
        for dz in (_dz_get("https://api.deezer.com/search/artist?limit=6&q=" + quote(form)).get("data") or []):
            if _norm_name(dz.get("name")) in want and dz.get("id") not in seen:
                seen.add(dz.get("id"))
                cands.append(dz)
        if cands:
            break
    ent = {"at": int(time.time()), "albums": [], "v": 3}
    if not cands:
        return ent
    cands.sort(key=lambda d: -int(d.get("nb_fan") or 0))
    cands = cands[:3]
    best, best_albums, best_n = None, [], -1
    for dz in cands:
        albums = _albums_of(dz.get("id"))
        n = _overlap(albums, titles)
        if n > best_n or (n == best_n and len(albums) > len(best_albums)):
            best, best_albums, best_n = dz, albums, n
    if len(cands) > 1 and best_n <= 0:
        return ent                    # 동명 가수를 가릴 근거가 없으면 쓰지 않는다
    pic = best.get("picture_xl") or ""
    if pic and "/artist//" not in pic:
        ent["thumb"] = pic
    ent["dz"] = best.get("id")
    ent["albums"] = best_albums
    ent["ov"] = best_n
    return ent


def enrich_fast(idx, progress=None):
    """가수 사진과 앨범 자켓 목록을 병렬로 받는다. 이미 받은 가수는 건너뛴다(이어받기)."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = artist_art_cache()
    names, seen, tmap = [], set(), {}
    for it in idx.get("items", []):
        a = (it.get("artist") or "").strip()
        k = _norm_name(a)
        if a and k:
            tmap.setdefault(k, []).append(it.get("title") or "")
        if a and k and k not in seen:
            seen.add(k)
            names.append((k, a))
    todo = [(k, a) for k, a in names if (cache.get(k) or {}).get("v") != 3 or ((cache.get(k) or {}).get("albums") == [] and time.time() - (cache.get(k) or {}).get("at", 0) > 7 * 86400)]
    _log("fast_start artists=%d todo=%d" % (len(names), len(todo)))
    done = hit = fail = 0
    mon = xbmc.Monitor()

    def one(item):
        k, a = item
        if mon.abortRequested():
            return k, None
        try:
            return k, _fast_artist(a, tmap.get(k, ()))
        except Exception:
            return k, None
    with ThreadPoolExecutor(max_workers=6) as ex:
        for k, ent in ex.map(one, todo):
            done += 1
            if ent is None:
                fail += 1
            else:
                old = cache.get(k) or {}
                if ent.get("dz"):                  # 확인된 가수만 이전에 받은 팬아트를 이어 쓴다
                    for key in ("fanart", "fanart2", "banner", "logo"):
                        if old.get(key):
                            ent.setdefault(key, old[key])
                cache[k] = ent
                hit += 1 if (ent.get("thumb") or ent.get("albums")) else 0
            if done % 50 == 0:
                _save_art_cache()
                if progress:
                    progress(done, len(todo))
    _save_art_cache()
    _log("fast_done looked=%d hits=%d fail=%d sec=%.1f" % (done, hit, fail, time.time() - t0))
    return {"looked": done, "hits": hit, "failed": fail}


def _album_cover_exact(ent, title):
    """확인된 가수의 앨범·싱글 중 제목이 거의 같은 것의 자켓(없으면 빈 문자열). 이 경우 곡 검색을 건너뛴다."""
    albums = (ent or {}).get("albums") or []
    if not albums or not ((ent or {}).get("dz") or (ent or {}).get("it")):
        return ""
    from difflib import SequenceMatcher
    try:
        tv = set(_agent.parser.title_variants(title))
    except Exception:
        tv = set([_norm_name(title)])
    for al in albums:
        try:
            av = set(_agent.parser.title_variants(al["t"]))
        except Exception:
            av = set([_norm_name(al["t"])])
        if any(x and y and (x == y or SequenceMatcher(None, x, y).ratio() >= 0.92) for x in tv for y in av):
            return al["c"]
    return ""


def _best_cover(ent, title):
    """곡 제목과 같은(비슷한) 앨범·싱글 자켓, 없으면 그 가수의 가장 최근 앨범 자켓."""
    albums = (ent or {}).get("albums") or []
    if not albums:
        return ""
    try:
        tv = set(_agent.parser.title_variants(title))
    except Exception:
        tv = set([_norm_name(title)])
    best, bs = None, 0.0
    from difflib import SequenceMatcher
    for al in albums:
        av = set(_agent.parser.title_variants(al["t"])) if hasattr(_agent, "parser") else set([_norm_name(al["t"])])
        sc = max([1.0 if x == y else SequenceMatcher(None, x, y).ratio() for x in tv for y in av] or [0])
        if sc > bs:
            best, bs = al, sc
    if best and bs >= 0.85:
        return best["c"]
    return sorted(albums, key=lambda a: a.get("y") or "0", reverse=True)[0]["c"]


_SONG_CACHE = [None]


def _song_path():
    return os.path.join(_CFG["dir"], "pkm_mv_song_cover.json")


def song_cover_cache():
    if _SONG_CACHE[0] is None:
        try:
            import json
            with open(_song_path(), "r", encoding="utf-8") as f:
                _SONG_CACHE[0] = json.load(f)
        except Exception:
            _SONG_CACHE[0] = {}
    return _SONG_CACHE[0]


def _pkey(path):
    import hashlib
    return hashlib.md5(path.encode("utf-8")).hexdigest()[:12]


def _core(x):
    import re as _re
    return _norm_name(_re.sub(r"[\(\[][^)\]]*[\)\]]", " ", str(x or "")))


def _song_cover(it):
    """파일 이름 전체와 맞는 곡을 Deezer 에서 찾아 앨범 자켓을 돌려준다. 가수와 제목이 둘 다 파일 이름에 있어야 받아들인다."""
    import unicodedata
    fn = unicodedata.normalize("NFC", os.path.splitext(os.path.basename(it["path"]))[0])
    fnn = _norm_name(fn)
    artist = unicodedata.normalize("NFC", it.get("artist") or "")
    title = unicodedata.normalize("NFC", it.get("title") or "")
    import re as _re
    qs = []
    first = (_artist_forms(artist) or [""])[0]
    tcore = _re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", title).strip() or title
    if first and tcore:
        qs.append(first + " " + tcore)
    m_in = _re.search(r"[\(\[]([^)\]]*[A-Za-z][^)\]]*)[\)\]]", title)
    if first and m_in and m_in.group(1).strip() and _norm_name(m_in.group(1)) != _norm_name(tcore):
        qs.append(first + " " + m_in.group(1).strip())
    qs.append(_re.sub(r"\s+", " ", _re.sub(r"\(1080p\)|\(Official[^)]*\)|\bOfficial\b|\bM_?V\b|Music Video|Performance Video|[\[\]「」『』【】\ue000-\uf8ff_\-]", " ", fn)).strip())
    for q in qs[:3]:
        rs = _dz_get("https://api.deezer.com/search?limit=8&q=" + quote(q)).get("data") or []
        for r in rs:
            an = _norm_name((r.get("artist") or {}).get("name"))
            tn = _core(r.get("title")) or _norm_name(r.get("title"))
            al = r.get("album") or {}
            cv = al.get("cover_xl") or al.get("cover_big") or ""
            if an and tn and an in fnn and tn in fnn and cv and "/album//" not in cv:
                return {"c": cv, "a": al.get("title") or ""}
        if rs:              # 결과는 있었는데 가수·제목이 안 맞으면 두 번째 검색은 하지 않는다(요청 절약)
            break
    return {}


# ------------------------------------------------------------------ 국내 소스(네이버 VIBE): 한국 곡은 앨범·발매일·장르·한글 이름이 가장 정확하다
_VB_LOCK = threading.Lock()
_VB_LAST = [0.0]


def _vb_get(q, display=5):
    """네이버 VIBE 곡 검색(인증 없는 공개 응답, XML). 초당 8회 이하. -> [{title, artists[], album, date, cover, genre, sec}]"""
    import xml.etree.ElementTree as ET
    url = "https://apis.naver.com/vibeWeb/musicapiweb/v4/search/track?start=1&display=%d&query=%s" % (display, quote(q))
    for attempt in range(3):
        with _VB_LOCK:
            wait = 0.125 - (time.time() - _VB_LAST[0])
            if wait > 0:
                time.sleep(wait)
            _VB_LAST[0] = time.time()
        try:
            req = Request(url, headers={"User-Agent": "Mozilla/5.0 PlexKM"})
            with urlopen(req, timeout=10) as r:
                root = ET.fromstring(r.read())
            break
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1.5 * (attempt + 1))
    out = []
    for t in root.findall("./result/tracks/tracks"):
        al = t.find("album")
        arts = [a.findtext("artistName") or "" for a in t.findall("./artists/artists")]
        genre = ""
        for a in t.findall("./artists/artists"):
            genre = genre or (a.findtext("genreNames") or "")
        pt = t.findtext("playTime") or ""
        sec = 0
        m = re.match(r"^(\d+):(\d+)$", pt)
        if m:
            sec = int(m.group(1)) * 60 + int(m.group(2))
        out.append({"title": t.findtext("trackTitle") or "", "artists": arts,
                    "album": (al.findtext("albumTitle") if al is not None else "") or "",
                    "date": (al.findtext("releaseDate") if al is not None else "") or "",
                    "cover": (al.findtext("imageUrl") if al is not None else "") or "",
                    "genre": genre, "sec": sec})
    return out


def _name_parts(x):
    """'ITZY(있지)' -> ['itzy', '있지'] (정규화한 이름 조각, 2글자 이상)."""
    x = unicodedata.normalize("NFC", str(x or ""))
    parts = [_norm_name(x)] + [_norm_name(g) for g in re.findall(r"[\(\[]([^\)\]]+)[\)\]]", x)] + [_norm_name(re.sub(r"[\(\[][^\)\]]*[\)\]]", "", x))]
    return [p for p in dict.fromkeys(parts) if len(p) >= 2]


def _song_kr(it):
    """네이버 VIBE 에서 이 영상의 곡을 찾는다. 가수 이름 조각과 곡 제목이 모두 파일 이름에 있어야 받아들인다.
    -> {c, a, y, g, d, an, src} 또는 {}"""
    fn = unicodedata.normalize("NFC", os.path.splitext(os.path.basename(it["path"]))[0])
    fnn = _norm_name(fn)
    artist = unicodedata.normalize("NFC", it.get("artist") or "")
    title = unicodedata.normalize("NFC", it.get("title") or "")
    tcore = re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", title).strip() or title
    qs = []
    first = (_artist_forms(artist) or [""])[0]
    kart = [x.strip() for x in re.findall(r"[\(\[]([^)\]]*[가-힣][^)\]]*)[\)\]]", artist)] or ([artist] if re.search(r"[가-힣]", artist) else [])
    tko = [x.strip() for x in re.findall(r"[\(\[]([^)\]]*[가-힣][^)\]]*)[\)\]]", title)]
    if not tko and re.search(r"[가-힣]", tcore):
        tko = [tcore]
    for a_, t_ in ((first, tcore), (first, tko[0] if tko else ""), (kart[0] if kart else "", tko[0] if tko else tcore)):
        q = (a_ + " " + t_).strip() if (a_ and t_) else ""
        if q and q not in qs:
            qs.append(q)
    for q in qs[:3]:
        rs = _vb_get(q)
        for r in rs:
            tn = _core(r["title"]) or _norm_name(r["title"])
            if not tn or tn not in fnn:
                continue
            ok = False
            for a in r["artists"]:
                if any(pp in fnn for pp in _name_parts(a)):
                    ok = True
                    break
            if ok and r["cover"]:
                y = (r["date"] or "")[:4]
                return {"c": r["cover"], "a": r["album"], "y": y if y.isdigit() else "", "g": r["genre"], "d": r["sec"],
                        "an": r["artists"][0] if r["artists"] else "", "src": "vibe"}
    return {}


def enrich_songs(idx, progress=None):
    """곡별 앨범 자켓·발매연도·장르. 1순위 네이버 VIBE(국내), 못 찾은 곡은 Deezer, 그래도 없으면 가수 앨범 자켓으로 대신한다."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = song_cover_cache()
    mon = xbmc.Monitor()
    items = [it for it in idx.get("items", []) if it.get("kind") in ("mv", "broadcast")]
    todo = [it for it in items if (cache.get(_pkey(it["path"])) or {}).get("v") != 3]
    _log("songs_start todo=%d" % len(todo))

    def one(it):
        if mon.abortRequested():
            return it, None
        res = {}
        try:
            res = _song_kr(it)
        except Exception:
            res = None
        if res == {}:
            try:
                res = _song_cover(it)
            except Exception:
                res = None if res is None else {}
        return it, res
    done = hit = kr = fail = 0

    def _save():
        try:
            tmp = _song_path() + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cache, f, ensure_ascii=False)
            os.replace(tmp, _song_path())
        except Exception:
            pass
    with ThreadPoolExecutor(max_workers=4) as ex:
        for it, res in ex.map(one, todo):
            done += 1
            if res is None:
                fail += 1
                continue
            cache[_pkey(it["path"])] = dict(res, at=int(time.time()), v=3)
            hit += 1 if res.get("c") else 0
            kr += 1 if res.get("src") == "vibe" else 0
            if done % 100 == 0:
                _save()
                if progress:
                    progress(done, len(todo))
    _save()
    _log("songs_done looked=%d hits=%d vibe=%d fail=%d sec=%.1f" % (done, hit, kr, fail, time.time() - t0))
    return {"looked": done, "hits": hit, "vibe": kr, "failed": fail}


# ------------------------------------------------------------------ iTunes(미국 스토어: 한국 스토어는 음악 검색 결과가 없다) 가수별 앨범: Deezer 에서 못 찾은 가수 보충
_IT_RUNNING = [False]
_IT_LAST = [0.0]


def _it_get(url):
    import json
    from urllib.request import Request, urlopen
    wait = _IT_LAST[0] + 3.2 - time.time()      # iTunes 는 분당 약 20회
    if wait > 0:
        time.sleep(wait)
    _IT_LAST[0] = time.time()
    with urlopen(Request(url, headers={"User-Agent": "PlexKM/1.0"}), timeout=12) as r:
        return json.loads(r.read().decode("utf-8", "replace") or "{}")


def _it_artist(a, titles):
    want = set(_norm_name(f) for f in _artist_forms(a))
    by = {}
    for form in _artist_forms(a)[:2]:
        d = _it_get("https://itunes.apple.com/search?country=us&entity=album&attribute=artistTerm&limit=60&term=" + quote(form))
        for r in d.get("results") or []:
            an = _norm_name(r.get("artistName"))
            if an in want and r.get("artworkUrl100"):
                import re as _re
                t = _re.sub(r"\s+-\s+(Single|EP)$", "", r.get("collectionName") or "")
                by.setdefault(r.get("artistId"), []).append({"t": t, "c": r["artworkUrl100"].replace("100x100bb", "600x600bb"),
                                                           "y": str(r.get("releaseDate") or "")[:4]})
        if by:
            break
    if not by:
        return None
    best = max(by.items(), key=lambda kv: (_overlap(kv[1], titles), len(kv[1])))
    if _overlap(best[1], titles) <= 0:       # 우리 곡 제목이 앨범에 하나도 없으면 동명이인으로 보고 쓰지 않는다
        return None
    return {"albums": best[1], "ov": _overlap(best[1], titles)}




# ------------------------------------------------------------------ 느린 보충 단계(차단형: 쓰는 쪽이 스레드에서 부른다)
def enrich_artists(idx, tick=None):
    """TheAudioDB 팬아트·가수 사진(없으면 Deezer 사진). 이어받기. tick(n) 은 60곳마다 불린다."""
    cache = artist_art_cache()
    names, seen = [], set()
    for it in idx.get("items", []):
        a = (it.get("artist") or "").strip()
        k = _norm_name(a)
        if a and k and k not in seen:
            seen.add(k)
            names.append((k, a))
    todo = [(k, a) for k, a in names if not (cache.get(k) and (cache[k].get("thumb") or time.time() - cache[k].get("at", 0) < 30 * 86400))]
    _log("artist_art_start total=%d todo=%d" % (len(names), len(todo)))
    mon = xbmc.Monitor()
    hits = n = errs = 0
    for k, a in todo:
        if mon.abortRequested():
            break
        found = None
        try:
            for form in _artist_forms(a):
                res = _audiodb(form)
                want = set(_norm_name(f) for f in _artist_forms(a))
                for ar in res:
                    if _norm_name(ar.get("strArtist")) in want or _norm_name(ar.get("strArtistAlternate")) in want:
                        found = ar
                        break
                if found or mon.waitForAbort(2.2):
                    break
            errs = 0
        except Exception:
            errs += 1
            if errs >= 6:
                _log("artist_art_stopped errs=%d" % errs, True)
                break
            if mon.waitForAbort(5.0):
                break
            continue
        ent = {"at": int(time.time())}
        if not found or not found.get("strArtistThumb"):
            try:      # TheAudioDB 에 없으면 Deezer 가수 사진(1000px)으로 채운다
                want2 = set(_norm_name(f) for f in _artist_forms(a))
                for form in _artist_forms(a)[:2]:
                    for dz in _deezer_artist(form):
                        if _norm_name(dz.get("name")) in want2 and dz.get("picture_xl") and "/artist//" not in dz.get("picture_xl"):
                            ent["thumb"] = dz["picture_xl"]
                            break
                    if ent.get("thumb"):
                        break
            except Exception:
                pass
        if found:
            for key, fld in (("thumb", "strArtistThumb"), ("fanart", "strArtistFanart"), ("fanart2", "strArtistFanart2"),
                             ("banner", "strArtistBanner"), ("logo", "strArtistLogo")):
                if found.get(fld):
                    ent[key] = found[fld]
            hits += 1
        old = cache.get(k) or {}
        for key in ("albums", "dz", "v", "it", "itv", "ov"):
            if key in old:
                ent.setdefault(key, old[key])
        cache[k] = ent
        n += 1
        if n % 20 == 0:
            _save_art_cache()
        if n % 60 == 0 and tick:
            tick(n)
        if mon.waitForAbort(2.2):
            break
    _save_art_cache()
    _log("artist_art_done looked=%d hits=%d" % (n, hits))
    return {"looked": n, "hits": hits}


def enrich_itunes(idx, tick=None):
    """Deezer(한국 IP 는 카탈로그가 좁다)에서 확인하지 못한 가수를 iTunes(미국 스토어)로 보충한다. 천천히, 이어받기."""
    cache = artist_art_cache()
    tmap, names = {}, {}
    for it in idx.get("items", []):
        a = (it.get("artist") or "").strip()
        k = _norm_name(a)
        if a and k:
            tmap.setdefault(k, []).append(it.get("title") or "")
            names[k] = a
    todo = [(k, a) for k, a in names.items()
            if not (cache.get(k) or {}).get("albums") and (cache.get(k) or {}).get("itv") != 1]
    _log("itunes_start todo=%d" % len(todo))
    mon = xbmc.Monitor()
    n = hits = errs = 0
    t0 = time.time()
    for k, a in todo:
        if mon.abortRequested():
            break
        try:
            res = _it_artist(a, tmap.get(k, ()))
            errs = 0
        except Exception:
            errs += 1
            if errs >= 5:
                break
            continue
        ent = cache.setdefault(k, {"at": int(time.time())})
        ent["itv"] = 1
        if res:
            ent["albums"] = res["albums"]
            ent["it"] = True
            hits += 1
        n += 1
        if n % 25 == 0:
            _save_art_cache()
            if tick:
                tick(n)
    _save_art_cache()
    _log("itunes_done looked=%d hits=%d sec=%.1f" % (n, hits, time.time() - t0))
    return {"looked": n, "hits": hits}
