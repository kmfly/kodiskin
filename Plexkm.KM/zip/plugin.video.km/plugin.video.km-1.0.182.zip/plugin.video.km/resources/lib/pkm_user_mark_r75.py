# -*- coding: utf-8 -*-
"""R75: user log marker.

Bound by the PKM keymap: Play/Pause held (SHIELD remote, keyboard media key)
and F12 (PC keyboard).  Each press writes one easy-to-find line

    PKM_USER_MARK n ...

to kodi.log with the current screen state, and shows "로그 표시 n" for a
moment, so a symptom can be pointed at without noting the clock time.
Nothing else is changed: no focus, window or playback action.
"""
from __future__ import absolute_import, unicode_literals

import sys

import xbmc
import xbmcgui

ADDON_ID = "plugin.video.km"
_COUNT_PROP = "PlexKM.UserMark.CountR75"


def _source():
    for arg in sys.argv[1:]:
        text = str(arg or "")
        if text.startswith("source="):
            return text.split("=", 1)[1]
    return "unknown"


def _info(label):
    try:
        return str(xbmc.getInfoLabel(label) or "").replace(" ", "_")[:80]
    except Exception:
        return ""


def main():
    win = xbmcgui.Window(10000)
    try:
        count = int(win.getProperty(_COUNT_PROP) or "0") + 1
    except Exception:
        count = 1
    win.setProperty(_COUNT_PROP, str(count))
    try:
        playing = int(bool(xbmc.Player().isPlaying()))
    except Exception:
        playing = 0
    fields = [
        "source=%s" % _source(),
        "window=%s" % xbmcgui.getCurrentWindowId(),
        "dialog=%s" % xbmcgui.getCurrentWindowDialogId(),
        "xml=%s" % _info("Window.Property(xmlfile)"),
        "focus=%s" % _info("System.CurrentControlId"),
        "item=%s" % _info("ListItem.Label")[:40],
        "playing=%d" % playing,
    ]
    if playing:
        fields.append("time=%s/%s" % (_info("Player.Time"), _info("Player.Duration")))
    for key, name in (("PlexKM.Info.InlineActive", "info"),
                      ("PlexKM.Home.StartupReadyV1619", "home_ready"),
                      ("PlexKM.SkinStartupSplash", "splash")):
        try:
            fields.append("%s=%s" % (name, win.getProperty(key) or "0"))
        except Exception:
            pass
    xbmc.log("[%s] PKM_USER_MARK %d %s" % (ADDON_ID, count, " ".join(fields)), xbmc.LOGWARNING)
    try:
        import pkm_notify
        token = pkm_notify.pkm_notice_set("로그 표시 %d" % count, "이 시점이 로그에 기록됐습니다")
        xbmc.Monitor().waitForAbort(1.5)
        pkm_notify.pkm_notice_clear(token)
    except Exception:
        pass


if __name__ == "__main__":
    main()
