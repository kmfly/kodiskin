# -*- coding: utf-8 -*-
"""PKM process-exit policy v2039.

Kodi shutdown must never wait for optional PKM background work.  Every PKM
thread is treated as disposable, and ThreadPoolExecutor must not wait for
queued/running jobs after Kodi has raised the global abort flag.  Persistent
work is rebuilt on the next start from SQLite/Plex.
"""
from __future__ import absolute_import, unicode_literals

import threading

_INSTALLED = False
_ORIGINAL_THREAD_INIT = None
_ORIGINAL_EXECUTOR_SHUTDOWN = None


def install_fast_shutdown_policy():
    global _INSTALLED, _ORIGINAL_THREAD_INIT, _ORIGINAL_EXECUTOR_SHUTDOWN
    if _INSTALLED:
        return
    _INSTALLED = True

    # Kodi's CPythonInvoker can wait for non-daemon Python threads even after
    # the add-on/service main function has returned.  PKM workers are all
    # recoverable and therefore must never own interpreter lifetime.
    _ORIGINAL_THREAD_INIT = threading.Thread.__init__

    def _pkm_thread_init(self, *args, **kwargs):
        if "daemon" not in kwargs or kwargs.get("daemon") is None:
            kwargs["daemon"] = True
        return _ORIGINAL_THREAD_INIT(self, *args, **kwargs)

    threading.Thread.__init__ = _pkm_thread_init

    # Executor context managers normally call shutdown(wait=True).  During
    # Kodi abort that can hold the interpreter until network/cache jobs finish.
    # Convert only the abort path to cancel-pending/no-wait; normal runtime
    # behavior remains unchanged.
    try:
        import concurrent.futures
        _ORIGINAL_EXECUTOR_SHUTDOWN = concurrent.futures.ThreadPoolExecutor.shutdown

        def _pkm_executor_shutdown(self, wait=True, *args, **kwargs):
            aborting = False
            try:
                import xbmc
                aborting = bool(xbmc.Monitor().abortRequested())
            except Exception:
                aborting = False
            if aborting:
                wait = False
                kwargs["cancel_futures"] = True
            try:
                return _ORIGINAL_EXECUTOR_SHUTDOWN(self, wait=wait, *args, **kwargs)
            except TypeError:
                # Compatibility with Python builds without cancel_futures.
                kwargs.pop("cancel_futures", None)
                return _ORIGINAL_EXECUTOR_SHUTDOWN(self, wait=wait, *args, **kwargs)

        concurrent.futures.ThreadPoolExecutor.shutdown = _pkm_executor_shutdown
    except Exception:
        pass
