# -*- coding: utf-8 -*-
"""PKM sync/startup-cache data flow helpers.

Large feature split from default.py.  This module owns PMS cache validation,
sync locks, remote/local change checks, and startup/auto-sync state decisions.
It does not control Kodi focus, navigation, WindowXML, or playback return flow.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import os
import time
import json
import traceback
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import xbmc
    import xbmcgui
except Exception:  # pragma: no cover - Kodi runtime supplies these modules.
    xbmc = None
    xbmcgui = None

_ENV = {}

# v2349 process-local proof reused by the post-reveal startup worker.
# Only sections that completed the pre-Home authority gate are recorded.
_PREHOME_AUTHORITY_READY_V2349 = {}
_MEMBERSHIP_EPOCH_SCHEMA_READY_V2578 = False

def _bind_env(env=None):
    if env:
        _ENV.update(env)
        globals().update(env)
    return _ENV

def _last_fetch_section_stats():
    getter = _ENV.get("get_last_fetch_section_stats")
    if callable(getter):
        try:
            return getter() or {}
        except Exception:
            return {}
    return _ENV.get("LAST_FETCH_SECTION_STATS", {}) or {}


_KODI_DISPLAY_TRANSLATE = {
    ord("\u007C"): "|",
    ord("\u00A6"): "|",
    ord("\u01C0"): "|",
    ord("\u2016"): "|",
    ord("\u2223"): "|",
    ord("\u2225"): "|",
    ord("\u23AA"): "|",
    ord("\u23D0"): "|",
    ord("\u2502"): "|",
    ord("\u2503"): "|",
    ord("\u2758"): "|",
    ord("\u2759"): "|",
    ord("\u275A"): "|",
    ord("\u3163"): "|",
    ord("\u4E28"): "|",
    ord("\uFF5C"): "|",
    ord("\uFFE8"): "|",
}

def _display_text_for_kodi(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def _pkm_window_property(name):
    try:
        if xbmcgui is None:
            return ""
        return xbmcgui.Window(10000).getProperty(str(name or "")) or ""
    except Exception:
        return ""


def _startup_recent_sync_active():
    return _pkm_window_property("PlexKM.StartupRecentSync.Active") == "1"


def _pkm_notice_clear_later(expected_token="", ms=1800):
    fn = _ENV.get("pkm_notice_clear_later")
    if callable(fn):
        try:
            return bool(fn(expected_token=expected_token, ms=ms))
        except TypeError:
            try:
                return bool(fn(expected_token, ms))
            except Exception:
                return False
        except Exception:
            return False
    return False




def _pkm_notice_clear_update(force=True):
    fn = _ENV.get("pkm_notice_clear_if_title")
    if callable(fn):
        try:
            return bool(fn(["PKM 업데이트"], force=force))
        except TypeError:
            try:
                return bool(fn(["PKM 업데이트"], "", force))
            except Exception:
                return False
        except Exception:
            return False
    return False

def _signal_home_data_refresh(reason="sync"):

    audit_event(None, "sync__signal_home_data_refresh_enter")
    """Signal the visible Home WindowXML to rebuild its currently displayed widgets.

    This is data/UI refresh signaling only. It does not control focus, playback,
    back handling, or window flow.  Completion notices should be shown only after
    the Home window acknowledges this token, so a visible "완료" means the
    visible Home widgets already had a chance to rebuild from the updated DB.
    """
    fn = _ENV.get("signal_home_data_refresh")
    if callable(fn):
        try:
            return str(fn(reason=reason) or "")
        except TypeError:
            try:
                return str(fn(reason) or "")
            except Exception:
                return ""
        except Exception:
            return ""
    try:
        if xbmcgui is None:
            return ""
        token = str(int(time.time() * 1000))
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.DataRefreshReason", str(reason or "sync"))
        win.setProperty("PlexKM.Home.DataRefreshToken", token)
        return token
    except Exception:
        return ""


def _wait_home_data_refresh_applied(token="", timeout_ms=6500):
    """Wait briefly until Home reports the refresh token was applied.

    Returns True only when visible Home data refresh has been acknowledged.
    If Home is not open or cannot acknowledge within the bounded timeout, do not
    show a misleading completion notice.
    """
    token = str(token or "")
    if not token or xbmcgui is None:
        return False
    try:
        win = xbmcgui.Window(10000)
        waited = 0
        step = 100
        while waited < int(timeout_ms or 6500):
            try:
                if win.getProperty("PlexKM.Home.DataRefreshAppliedToken") == token:
                    return True
                if win.getProperty("PlexKM.ServiceStopping") == "1":
                    return False
            except Exception:
                pass
            if xbmc is not None:
                xbmc.sleep(step)
            else:
                time.sleep(step / 1000.0)
            waited += step
        return False
    except Exception:
        return False



def _repair_tv_art_cache_integrity(section_id, section_title="", fetch_remote=True, reason="startup"):
    func = _ENV.get("repair_tv_art_cache_integrity")
    if callable(func):
        try:
            return int(func(section_id, section_title=section_title, fetch_remote=fetch_remote, reason=reason) or 0)
        except TypeError:
            try:
                return int(func(section_id, section_title, fetch_remote, reason) or 0)
            except Exception:
                return 0
        except Exception:
            return 0
    return 0


def autosync_request_lock_path(env=None):
    _bind_env(env)
    return os.path.join(addon_profile_dir(), "autosync.request.lock")

def _read_lock_timestamp(path, env=None):
    _bind_env(env)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = f.read().strip()
        return int((data.split("|", 1)[0] or "0").strip() or 0)
    except Exception:
        return 0

def is_sync_locked(max_age_sec=1800, env=None):
    _bind_env(env)
    path = sync_lock_path()
    if not os.path.exists(path):
        return False
    ts = _read_lock_timestamp(path)
    if ts and int(time.time()) - ts < max_age_sec:
        return True
    try:
        os.remove(path)
        log("removed stale sync lock: %s" % path, xbmc.LOGWARNING)
        return False
    except Exception:
        return True

def acquire_sync_lock(max_age_sec=1800, label="sync", env=None):
    _bind_env(env)
    """Acquire an atomic cross-process lock for PMS sync."""
    if _pkm_full_reset_in_progress_v2149():
        log("sync lock skipped label=%s reason=full_reset_v2149" % (label or "sync"), xbmc.LOGINFO)
        return False
    path = sync_lock_path()
    now = int(time.time())
    try:
        if os.path.exists(path):
            ts = _read_lock_timestamp(path)
            if ts and now - ts < max_age_sec:
                log("sync lock exists; skipping duplicate sync label=%s age=%ss" % (label, now - ts), xbmc.LOGINFO)
                return False
            try:
                os.remove(path)
                log("removed stale sync lock before acquire label=%s" % label, xbmc.LOGWARNING)
            except Exception:
                log("stale sync lock exists but cannot remove; skip label=%s" % label, xbmc.LOGWARNING)
                return False
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, ("%d|%s|%s" % (now, os.getpid(), label)).encode("utf-8"))
        finally:
            os.close(fd)
        log("sync lock acquired label=%s" % label, xbmc.LOGINFO)
        return True
    except FileExistsError:
        log("sync lock race lost; skipping duplicate sync label=%s" % label, xbmc.LOGINFO)
        return False
    except Exception as e:
        log("sync lock acquire failed; skip sync label=%s error=%s" % (label, e), xbmc.LOGWARNING)
        return False

def release_sync_lock(env=None):
    _bind_env(env)
    try:
        path = sync_lock_path()
        if os.path.exists(path):
            os.remove(path)
            log("sync lock released", xbmc.LOGINFO)
    except Exception:
        pass

def acquire_autosync_request_lock(cooldown_sec=120, env=None):
    _bind_env(env)
    path = autosync_request_lock_path()
    now = int(time.time())
    try:
        if os.path.exists(path):
            ts = _read_lock_timestamp(path)
            if ts and now - ts < cooldown_sec:
                return False
            try:
                os.remove(path)
            except Exception:
                return False
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, ("%d|%s|autosync-request" % (now, os.getpid())).encode("utf-8"))
        finally:
            os.close(fd)
        return True
    except Exception:
        return False

def initial_sync_done(env=None):
    _bind_env(env)
    return bool(load_state().get("initial_sync_done"))


def initial_setup_completed(env=None):
    """Durable first-install completion authority (v2562).

    This is intentionally independent from Plex credentials and initial_sync_done.
    Server switches/re-auth may temporarily clear sync readiness, but must never
    resurrect the first-install screen. Full PKM reset removes the profile state,
    which is the only normal path back to False after completion.
    """
    _bind_env(env)
    state = load_state() or {}
    key = "initial_setup_completed_v2562"
    if key in state:
        return bool(state.get(key))
    # One-time upgrade migration for already-configured PKM installs.
    if bool(state.get("initial_sync_done")):
        state[key] = True
        state["initial_setup_completed_at_v2562"] = int(time.time())
        save_state(state)
        try:
            log("INITIAL_SETUP_AUTHORITY_MIGRATE_V2562 source=initial_sync_done completed=1", xbmc.LOGINFO)
        except Exception:
            pass
        return True
    return False


def set_initial_setup_completed(value=True, env=None):
    _bind_env(env)
    state = load_state() or {}
    state["initial_setup_completed_v2562"] = bool(value)
    state["initial_setup_completed_at_v2562"] = int(time.time()) if value else 0
    save_state(state)


def set_initial_sync_done(value=True, env=None):
    _bind_env(env)
    state = load_state()
    state["initial_sync_done"] = bool(value)
    state["initial_sync_at"] = int(time.time()) if value else 0
    save_state(state)

def last_auto_sync_at(env=None):
    _bind_env(env)
    try:
        return int(load_state().get("last_auto_sync_at", 0) or 0)
    except Exception:
        return 0

def set_last_auto_sync_at(value=None, env=None):
    _bind_env(env)
    state = load_state()
    state["last_auto_sync_at"] = int(value if value is not None else time.time())
    save_state(state)

def _remote_total_for_path(path, params=None, env=None):
    _bind_env(env)
    params2 = {
        "checkFiles": 0, "includeExtras": 0, "includeReviews": 0,
        "includeRelated": 0, "skipRefresh": 1,
        "X-Plex-Container-Start": 0, "X-Plex-Container-Size": 1,
    }
    if params:
        params2.update(params)
    root = plex_request_xml(path, params=params2, timeout=20)
    return xml_attr_int(root, "totalSize", 0)

def remote_section_counts(section, env=None):
    _bind_env(env)
    """Return PMS item counts by type for startup sync validation."""
    section_id = str(section.get("section_id", ""))
    section_type = section.get("section_type", "")
    result = {"movie": 0, "show": 0, "episode": 0, "total": 0}
    if not section_id:
        return result
    if section_type == PLEX_TYPE_MOVIE:
        result["movie"] = _remote_total_for_path("/library/sections/%s/all" % section_id, {"type": PLEX_TYPE_TO_NUM[PLEX_TYPE_MOVIE]})
    elif section_type == PLEX_TYPE_SHOW:
        result["show"] = _remote_total_for_path("/library/sections/%s/all" % section_id, {"type": PLEX_TYPE_TO_NUM[PLEX_TYPE_SHOW]})
        # allLeaves is required.  Show rows alone do not prove the episode DB is current.
        result["episode"] = _remote_total_for_path("/library/sections/%s/allLeaves" % section_id)
    else:
        result["total"] = _remote_total_for_path("/library/sections/%s/all" % section_id)
    result["total"] = int(result.get("movie", 0) or 0) + int(result.get("show", 0) or 0) + int(result.get("episode", 0) or 0) or int(result.get("total", 0) or 0)
    return result

def remote_section_total(section, env=None):
    _bind_env(env)
    return int((remote_section_counts(section) or {}).get("total", 0) or 0)

def _remote_section_latest_items(section, limit=10, env=None):
    _bind_env(env)
    """Return newest Plex item keys for a section without doing a full sync.

    Plex section updatedAt can stay unchanged even when the section's
    recently-added row has newer items.  This small latest-item query verifies
    the first few addedAt-desc keys before allowing service fast-skip.

    v481: apply the guard to every section at startup/poll.  TV sections use
    /allLeaves because their visible Recently Added rows are episode based;
    movie sections keep /all type=movie.  This is still a small query only and
    does not affect side-menu navigation.
    """
    section_id = str((section or {}).get("section_id", ""))
    section_type = str((section or {}).get("section_type", ""))
    if not section_id:
        return []
    params = {
        "checkFiles": 0,
        "includeExtras": 0,
        "includeReviews": 0,
        "includeRelated": 0,
        "skipRefresh": 1,
        "sort": "addedAt:desc",
        "X-Plex-Container-Start": 0,
        "X-Plex-Container-Size": max(1, int(limit or 10)),
    }
    path = "/library/sections/%s/all" % section_id
    if section_type == PLEX_TYPE_SHOW:
        path = "/library/sections/%s/allLeaves" % section_id
    elif section_type == PLEX_TYPE_MOVIE:
        params["type"] = PLEX_TYPE_TO_NUM.get(PLEX_TYPE_MOVIE, "")
    root = plex_request_xml(path, params=params, timeout=20)
    rows = []
    for node in list(root):
        if node.tag not in ("Video", "Directory"):
            continue
        rk = str(node.get("ratingKey") or "").strip()
        if not rk:
            continue
        rows.append({
            "rating_key": rk,
            "added_at": xml_attr_int(node, "addedAt", 0),
            "updated_at": xml_attr_int(node, "updatedAt", 0),
            "title": node.get("title") or "",
        })
    return rows

def _remote_latest_rows_from_root_v2367(root, env=None):
    _bind_env(env)
    rows = []
    for node in list(root or []):
        if getattr(node, "tag", "") not in ("Video", "Directory"):
            continue
        rk = str(node.get("ratingKey") or "").strip()
        if not rk:
            continue
        rows.append({
            "rating_key": rk,
            "added_at": xml_attr_int(node, "addedAt", 0),
            "updated_at": xml_attr_int(node, "updatedAt", 0),
            "title": node.get("title") or "",
        })
    return rows


def _startup_remote_probe_v2367(section, limit=10, env=None):
    """Return count + newest rows with the minimum Plex requests.

    v2349 originally fetched counts and newest rows separately.  That meant two
    requests for movie sections and three for TV sections, even though the
    newest-row response already carries MediaContainer.totalSize.  v2367 merges
    those probes: movie=1 request; TV=2 requests (show count + allLeaves newest
    rows/episode count).  This changes no authority decision; it only removes
    duplicate network work before Home is allowed to open.
    """
    _bind_env(env)
    section = section or {}
    sid = str(section.get("section_id") or "").strip()
    stype = str(section.get("section_type") or "").strip()
    result = {
        "counts": {"movie": 0, "show": 0, "episode": 0, "total": 0},
        "latest_rows": [],
        "requests": 0,
    }
    if not sid:
        return result
    params_latest = {
        "checkFiles": 0,
        "includeExtras": 0,
        "includeReviews": 0,
        "includeRelated": 0,
        "skipRefresh": 1,
        "sort": "addedAt:desc",
        "X-Plex-Container-Start": 0,
        "X-Plex-Container-Size": max(1, int(limit or 10)),
    }
    counts = result["counts"]
    if stype == PLEX_TYPE_MOVIE:
        params_latest["type"] = PLEX_TYPE_TO_NUM.get(PLEX_TYPE_MOVIE, "")
        root = plex_request_xml("/library/sections/%s/all" % sid, params=params_latest, timeout=20)
        result["requests"] += 1
        counts["movie"] = xml_attr_int(root, "totalSize", 0)
        result["latest_rows"] = _remote_latest_rows_from_root_v2367(root)
    elif stype == PLEX_TYPE_SHOW:
        # Show count is not represented by allLeaves, so this one small request
        # remains required.  The allLeaves newest-row request supplies both the
        # episode count and the newest episode keys.
        show_params = {
            "checkFiles": 0,
            "includeExtras": 0,
            "includeReviews": 0,
            "includeRelated": 0,
            "skipRefresh": 1,
            "type": PLEX_TYPE_TO_NUM.get(PLEX_TYPE_SHOW, ""),
            "X-Plex-Container-Start": 0,
            "X-Plex-Container-Size": 1,
        }
        show_root = plex_request_xml("/library/sections/%s/all" % sid, params=show_params, timeout=20)
        result["requests"] += 1
        counts["show"] = xml_attr_int(show_root, "totalSize", 0)
        leaves_root = plex_request_xml("/library/sections/%s/allLeaves" % sid, params=params_latest, timeout=20)
        result["requests"] += 1
        counts["episode"] = xml_attr_int(leaves_root, "totalSize", 0)
        result["latest_rows"] = _remote_latest_rows_from_root_v2367(leaves_root)
    else:
        root = plex_request_xml("/library/sections/%s/all" % sid, params=params_latest, timeout=20)
        result["requests"] += 1
        counts["total"] = xml_attr_int(root, "totalSize", 0)
        result["latest_rows"] = _remote_latest_rows_from_root_v2367(root)
    typed_total = int(counts.get("movie", 0) or 0) + int(counts.get("show", 0) or 0) + int(counts.get("episode", 0) or 0)
    if typed_total:
        counts["total"] = typed_total
    return result


def _verify_section_latest_with_remote_rows_v2367(section, remote_rows, limit=10, env=None):
    """Run the existing latest-key/detail guard without a second Plex fetch."""
    _bind_env(env)
    try:
        section_id = str((section or {}).get("section_id", ""))
        section_type = str((section or {}).get("section_type", ""))
        local_plex_type = section_type if section_type else None
        if section_type == PLEX_TYPE_SHOW:
            local_plex_type = PLEX_TYPE_EPISODE
        local_rows = _local_section_latest_items(section_id, plex_type=local_plex_type, limit=limit)
        remote_rows = list(remote_rows or [])
        remote_keys = _latest_item_keys(remote_rows)
        local_keys = _latest_item_keys(local_rows)
        if not remote_keys:
            return False, remote_rows, local_rows, "remote_empty"
        local_key_set = set(local_keys)
        missing_in_pkm = [k for k in remote_keys if k not in local_key_set]
        if missing_in_pkm:
            return True, remote_rows, local_rows, "missing_in_pkm:%s" % ",".join(missing_in_pkm[:10])
        detail_incomplete, detail_reason = _local_latest_detail_incomplete(
            section_id, section_type, remote_rows=remote_rows, local_rows=local_rows
        )
        if detail_incomplete:
            return True, remote_rows, local_rows, detail_reason or "metadata_incomplete"
        return False, remote_rows, local_rows, ""
    except Exception as exc:
        return False, list(remote_rows or []), [], str(exc)


def _local_section_latest_items(section_id, plex_type=None, limit=10, env=None):
    _bind_env(env)
    sid = str(section_id or "").strip()
    if not sid:
        return []
    conn = init_db()
    try:
        params = [sid]
        where = ["section_id=?"]
        if plex_type:
            where.append("plex_type=?")
            params.append(str(plex_type))
        params.append(max(1, int(limit or 10)))
        rows = conn.execute(
            "SELECT rating_key, COALESCE(added_at,0), COALESCE(updated_at,0), COALESCE(title,'') "
            "FROM items WHERE %s ORDER BY COALESCE(added_at,0) DESC, rating_key DESC LIMIT ?" % (" AND ".join(where),),
            tuple(params)
        ).fetchall()
        return [{
            "rating_key": str(r[0] or ""),
            "added_at": int(r[1] or 0),
            "updated_at": int(r[2] or 0),
            "title": str(r[3] or ""),
        } for r in rows if str(r[0] or "")]
    except Exception:
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass

def _latest_item_keys(rows, env=None):
    _bind_env(env)
    return [str((x or {}).get("rating_key") or "") for x in (rows or []) if str((x or {}).get("rating_key") or "")]

def _local_latest_detail_incomplete(section_id, section_type, remote_rows=None, local_rows=None, env=None):
    _bind_env(env)
    """Detect newest rows that exist locally but only as sparse item rows.

    The fast-skip guard compares newest ratingKeys and also checks whether the
    local newest row is structurally usable.  Movie detail tables retain their
    explicit completion marker.  v2352 deliberately does not use optional TV
    cast/studio/art fields as a startup dirty signal, because valid sparse Plex
    metadata otherwise creates an endless repair loop on every Kodi start.
    """
    sid = str(section_id or "").strip()
    stype = str(section_type or "").strip()
    keys = _latest_item_keys(remote_rows or local_rows or [])
    if not sid or not keys:
        return False, ""
    conn = init_db()
    try:
        incomplete = []
        for rk in keys[:max(1, min(10, len(keys)))]:
            try:
                row = conn.execute(
                    "SELECT plex_type, COALESCE(parent_rating_key,''), COALESCE(grandparent_rating_key,''), COALESCE(summary,''), COALESCE(thumb,''), COALESCE(art,'') FROM items WHERE rating_key=?",
                    (str(rk),)
                ).fetchone()
            except Exception:
                row = None
            if not row:
                continue
            ptype = str(row[0] or "")
            parent_key = str(row[1] or "")
            grand_key = str(row[2] or "")
            summary = str(row[3] or "")
            thumb = str(row[4] or "")
            art = str(row[5] or "")
            if stype == PLEX_TYPE_MOVIE or ptype == PLEX_TYPE_MOVIE:
                try:
                    people_count = int((conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    people_count = 0
                try:
                    genre_count = int((conn.execute("SELECT COUNT(*) FROM item_genres WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    genre_count = 0
                try:
                    rating_count = int((conn.execute("SELECT COUNT(*) FROM item_ratings WHERE rating_key=?", (str(rk),)).fetchone() or [0])[0] or 0)
                except Exception:
                    rating_count = 0
                # item_ratings is a completion marker. If Plex really has no
                # people/genres, a completed sync still writes item_ratings and
                # prevents endless repair.
                if (people_count + genre_count + rating_count) <= 0 or not (summary and thumb and art):
                    incomplete.append(str(rk))
            elif stype == PLEX_TYPE_SHOW or ptype in (PLEX_TYPE_SHOW, PLEX_TYPE_EPISODE):
                # v2352: TV people/studio rows are optional metadata, not a
                # membership/completeness proof.  Some perfectly valid Plex
                # shows expose no cast/studio tags, and episode metadata may
                # legitimately omit episode-level art because PKM uses the
                # grandparent/show artwork fallback.  Treating either case as
                # "metadata_incomplete" made the same TV sections dirty on
                # every Kodi start and repeatedly triggered membership scans.
                #
                # For newest TV rows, only fail this guard when the local row is
                # structurally unusable: a show has no poster/fanart at all, or
                # an episode has lost its show linkage / parent show row.
                if ptype == PLEX_TYPE_SHOW:
                    if not (thumb or art):
                        incomplete.append(str(rk))
                elif ptype == PLEX_TYPE_EPISODE:
                    show_key = grand_key or parent_key
                    show_exists = False
                    if show_key:
                        try:
                            show_exists = bool(conn.execute(
                                "SELECT 1 FROM items WHERE rating_key=? AND plex_type=? LIMIT 1",
                                (str(show_key), PLEX_TYPE_SHOW)
                            ).fetchone())
                        except Exception:
                            show_exists = False
                    if not show_key or not show_exists:
                        incomplete.append(str(rk))
            if incomplete:
                break
        if incomplete:
            return True, "metadata_incomplete:%s" % ",".join(incomplete[:10])
        return False, ""
    except Exception as exc:
        return False, "detail_check_error:%s" % exc
    finally:
        try:
            conn.close()
        except Exception:
            pass


def verify_section_latest_for_fast_skip(section, limit=10, env=None):
    _bind_env(env)
    """Return (changed, remote_rows, local_rows, error_text) for the fast-skip guard."""
    try:
        section_id = str((section or {}).get("section_id", ""))
        section_type = str((section or {}).get("section_type", ""))
        remote_rows = _remote_section_latest_items(section, limit=limit)
        local_plex_type = section_type if section_type else None
        # TV libraries show recent episodes.  Compare the Plex allLeaves keys
        # against local episode keys, not show keys, otherwise new episodes can
        # be missed when the show row itself is old.
        if section_type == PLEX_TYPE_SHOW:
            local_plex_type = PLEX_TYPE_EPISODE
        local_rows = _local_section_latest_items(section_id, plex_type=local_plex_type, limit=limit)
        remote_keys = _latest_item_keys(remote_rows)
        local_keys = _latest_item_keys(local_rows)
        if not remote_keys:
            return False, remote_rows, local_rows, "remote_empty"
        # Kodi/PKM must never miss newly-added Plex items.  Treat the
        # guard as dirty when any newest Plex key is absent from the local
        # PKM latest window.  This avoids false DIRTY from equal-addedAt
        # ordering differences while still catching new items.
        missing_in_pkm = [k for k in remote_keys if k not in set(local_keys)]
        if missing_in_pkm:
            return True, remote_rows, local_rows, "missing_in_pkm:%s" % ",".join(missing_in_pkm[:10])
        detail_incomplete, detail_reason = _local_latest_detail_incomplete(section_id, section_type, remote_rows=remote_rows, local_rows=local_rows)
        if detail_incomplete:
            return True, remote_rows, local_rows, detail_reason or "metadata_incomplete"
        return False, remote_rows, local_rows, ""
    except Exception as exc:
        return False, [], [], str(exc)

def startup_latest_guard_v2573(limit=10, env=None):
    """Parallel newest-key guard used by the UHD3 pre-Home fast path.

    v2570 moved the full startup sync in front of Home so live navigation would
    stay quiet, but the legacy service_startup verifier still queried every
    selected Plex section serially. On unchanged starts that duplicated the
    authority proof and added several seconds before Home.

    Only remote newest-key requests run in workers. SQLite reads/completeness
    checks remain serialized on the service thread, matching the existing
    authority design and avoiding low-memory-device DB contention. Any changed
    or unproven section makes the caller fall back to the canonical full sync.
    """
    _bind_env(env)
    result = {
        "ok": False, "checked": 0, "changed": 0, "changed_ids": [],
        "errors": [], "elapsed_ms": 0, "workers": 0,
    }
    started = time.time()
    try:
        try:
            sections = list(fetch_sections(refresh=False, selected_only=True) or [])
        except TypeError:
            sections = list(fetch_sections(refresh=False) or [])
        try:
            sections = list(apply_section_order(sections, save_merged=False) or sections)
        except TypeError:
            sections = list(apply_section_order(sections) or sections)
        if not sections:
            result["ok"] = True
            return result

        workers = max(1, min(5, len(sections)))
        result["workers"] = workers
        remote_by_sid = {}
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {
                executor.submit(_remote_section_latest_items, section, limit): section
                for section in sections
            }
            for future in as_completed(future_map):
                section = future_map[future]
                sid = str((section or {}).get("section_id") or "")
                try:
                    remote_by_sid[sid] = {"rows": list(future.result() or []), "error": ""}
                except Exception as exc:
                    remote_by_sid[sid] = {"rows": [], "error": str(exc)}

        for section in sections:
            sid = str((section or {}).get("section_id") or "")
            stype = str((section or {}).get("section_type") or "")
            title = str((section or {}).get("title") or "")
            result["checked"] += 1
            remote_result = dict(remote_by_sid.get(sid) or {})
            remote_rows = list(remote_result.get("rows") or [])
            error = str(remote_result.get("error") or "")
            changed = False
            reason = ""
            local_rows = []
            if error:
                reason = "remote_error:%s" % error
            elif not remote_rows:
                reason = "remote_empty"
            else:
                try:
                    local_plex_type = stype if stype else None
                    if stype == PLEX_TYPE_SHOW:
                        local_plex_type = PLEX_TYPE_EPISODE
                    local_rows = _local_section_latest_items(
                        sid, plex_type=local_plex_type, limit=limit
                    )
                    remote_keys = _latest_item_keys(remote_rows)
                    local_keys = _latest_item_keys(local_rows)
                    local_key_set = set(local_keys)
                    missing_in_pkm = [k for k in remote_keys if k not in local_key_set]
                    if missing_in_pkm:
                        changed = True
                        reason = "missing_in_pkm:%s" % ",".join(missing_in_pkm[:10])
                    else:
                        detail_incomplete, detail_reason = _local_latest_detail_incomplete(
                            sid, stype, remote_rows=remote_rows, local_rows=local_rows
                        )
                        if detail_incomplete:
                            changed = True
                            reason = detail_reason or "metadata_incomplete"
                except Exception as exc:
                    reason = "local_verify_error:%s" % exc

            if changed:
                result["changed"] += 1
                result["changed_ids"].append(sid)
            elif reason:
                result["errors"].append("%s:%s" % (sid, reason))
            log("UHD3_STARTUP_LATEST_GUARD_SECTION_V2573 section=%s title=%s changed=%d remote=%s local=%s reason=%s" % (
                sid, title, 1 if changed else 0,
                ",".join(_latest_item_keys(remote_rows)),
                ",".join(_latest_item_keys(local_rows)),
                reason or "ok"
            ), xbmc.LOGINFO)
        result["ok"] = bool(result["checked"] == len(sections) and not result["errors"])
        return result
    except Exception as exc:
        result["errors"].append("fatal:%s" % exc)
        return result
    finally:
        result["elapsed_ms"] = int((time.time() - started) * 1000)
        log("UHD3_STARTUP_LATEST_GUARD_DONE_V2573 ok=%d checked=%d changed=%d workers=%d elapsed_ms=%d errors=%d" % (
            1 if result.get("ok") else 0,
            int(result.get("checked", 0) or 0),
            int(result.get("changed", 0) or 0),
            int(result.get("workers", 0) or 0),
            int(result.get("elapsed_ms", 0) or 0),
            len(result.get("errors") or []),
        ), xbmc.LOGINFO)

def local_section_counts(section_id, env=None):
    _bind_env(env)
    result = {"movie": 0, "show": 0, "episode": 0, "total": 0, "max_synced_at": 0, "max_updated_at": 0}
    conn = init_db()
    try:
        for plex_type, count in conn.execute("SELECT plex_type, COUNT(*) FROM items WHERE section_id=? GROUP BY plex_type", (str(section_id),)).fetchall():
            key = str(plex_type or "")
            if key in result:
                result[key] = int(count or 0)
        row = conn.execute("SELECT COUNT(*), COALESCE(MAX(synced_at),0), COALESCE(MAX(updated_at),0) FROM items WHERE section_id=?", (str(section_id),)).fetchone()
        if row:
            result["total"] = int(row[0] or 0)
            result["max_synced_at"] = int(row[1] or 0)
            result["max_updated_at"] = int(row[2] or 0)
    finally:
        conn.close()
    return result


def _local_section_counts_bulk_v2368(section_ids):
    """Read all selected-section counts in one DB open/query set.

    v2367 still opened/initialized SQLite once per selected section merely to
    order the authority checks.  On a large PKM DB that cost about a second
    before the first authority marker even though the values are read-only.
    """
    ids = [str(x or "").strip() for x in (section_ids or []) if str(x or "").strip()]
    result = {sid: {"movie": 0, "show": 0, "episode": 0, "total": 0, "max_synced_at": 0, "max_updated_at": 0} for sid in ids}
    if not ids:
        return result
    conn = init_db()
    try:
        placeholders = ",".join("?" for _ in ids)
        sql_counts = "SELECT section_id, plex_type, COUNT(*) FROM items WHERE section_id IN (%s) GROUP BY section_id, plex_type" % placeholders
        for sid, plex_type, count in conn.execute(sql_counts, tuple(ids)).fetchall():
            sid = str(sid or "")
            key = str(plex_type or "")
            if sid in result and key in result[sid]:
                result[sid][key] = int(count or 0)
        sql_total = "SELECT section_id, COUNT(*), COALESCE(MAX(synced_at),0), COALESCE(MAX(updated_at),0) FROM items WHERE section_id IN (%s) GROUP BY section_id" % placeholders
        for sid, total, max_synced, max_updated in conn.execute(sql_total, tuple(ids)).fetchall():
            sid = str(sid or "")
            if sid in result:
                result[sid]["total"] = int(total or 0)
                result[sid]["max_synced_at"] = int(max_synced or 0)
                result[sid]["max_updated_at"] = int(max_updated or 0)
    finally:
        conn.close()
    return result


def _local_membership_digests_bulk_v2368(section_ids):
    """Compute selected-section membership digests with one DB connection."""
    ids = [str(x or "").strip() for x in (section_ids or []) if str(x or "").strip()]
    hashes = {sid: hashlib.sha1() for sid in ids}
    if not ids:
        return {}
    conn = init_db()
    try:
        placeholders = ",".join("?" for _ in ids)
        sql = "SELECT section_id, rating_key FROM items WHERE section_id IN (%s) ORDER BY section_id, rating_key" % placeholders
        for sid, rating_key in conn.execute(sql, tuple(ids)):
            sid = str(sid or "")
            h = hashes.get(sid)
            if h is not None and rating_key is not None:
                h.update(str(rating_key).encode("utf-8", "replace"))
                h.update(b"\n")
    finally:
        conn.close()
    return {sid: h.hexdigest() for sid, h in hashes.items()}





# PKM_PATCH_ACTIVE v2578 persisted_local_membership_epoch_summary
# Avoid re-hashing every selected ratingKey on every unchanged Kodi start.
# A tiny SQLite epoch table is maintained by membership-only triggers:
# - INSERT of a new ratingKey bumps the destination section epoch
# - DELETE bumps the old section epoch
# - ratingKey/section moves bump only when the membership identity actually changes
# Metadata/playstate UPDATEs do not bump the epoch.  The first V2578 start seeds
# the persisted proof by doing the old exact scan once; later unchanged starts can
# validate the local side from 7 tiny epoch rows + the previously proven counts/digest.
def _ensure_membership_epoch_schema_v2578():
    global _MEMBERSHIP_EPOCH_SCHEMA_READY_V2578
    if _MEMBERSHIP_EPOCH_SCHEMA_READY_V2578:
        return True
    conn = init_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS section_membership_epoch_v2578 (
                section_id TEXT PRIMARY KEY,
                epoch INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS trg_items_membership_insert_v2578
            AFTER INSERT ON items
            WHEN NEW.section_id IS NOT NULL AND NEW.section_id <> ''
            BEGIN
                INSERT INTO section_membership_epoch_v2578(section_id, epoch, updated_at)
                VALUES(NEW.section_id, 1, CAST(strftime('%s','now') AS INTEGER))
                ON CONFLICT(section_id) DO UPDATE SET
                    epoch=section_membership_epoch_v2578.epoch+1,
                    updated_at=excluded.updated_at;
            END
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS trg_items_membership_delete_v2578
            AFTER DELETE ON items
            WHEN OLD.section_id IS NOT NULL AND OLD.section_id <> ''
            BEGIN
                INSERT INTO section_membership_epoch_v2578(section_id, epoch, updated_at)
                VALUES(OLD.section_id, 1, CAST(strftime('%s','now') AS INTEGER))
                ON CONFLICT(section_id) DO UPDATE SET
                    epoch=section_membership_epoch_v2578.epoch+1,
                    updated_at=excluded.updated_at;
            END
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS trg_items_membership_move_old_v2578
            AFTER UPDATE OF section_id, rating_key ON items
            WHEN (COALESCE(OLD.section_id,'') <> COALESCE(NEW.section_id,'')
                  OR COALESCE(OLD.rating_key,'') <> COALESCE(NEW.rating_key,''))
                 AND OLD.section_id IS NOT NULL AND OLD.section_id <> ''
            BEGIN
                INSERT INTO section_membership_epoch_v2578(section_id, epoch, updated_at)
                VALUES(OLD.section_id, 1, CAST(strftime('%s','now') AS INTEGER))
                ON CONFLICT(section_id) DO UPDATE SET
                    epoch=section_membership_epoch_v2578.epoch+1,
                    updated_at=excluded.updated_at;
            END
        """)
        conn.execute("""
            CREATE TRIGGER IF NOT EXISTS trg_items_membership_move_new_v2578
            AFTER UPDATE OF section_id, rating_key ON items
            WHEN (COALESCE(OLD.section_id,'') <> COALESCE(NEW.section_id,'')
                  OR COALESCE(OLD.rating_key,'') <> COALESCE(NEW.rating_key,''))
                 AND NEW.section_id IS NOT NULL AND NEW.section_id <> ''
            BEGIN
                INSERT INTO section_membership_epoch_v2578(section_id, epoch, updated_at)
                VALUES(NEW.section_id, 1, CAST(strftime('%s','now') AS INTEGER))
                ON CONFLICT(section_id) DO UPDATE SET
                    epoch=section_membership_epoch_v2578.epoch+1,
                    updated_at=excluded.updated_at;
            END
        """)
        conn.commit()
        _MEMBERSHIP_EPOCH_SCHEMA_READY_V2578 = True
        return True
    finally:
        conn.close()


def _local_membership_epochs_v2578(section_ids):
    ids = [str(x or '').strip() for x in (section_ids or []) if str(x or '').strip()]
    result = {sid: 0 for sid in ids}
    if not ids:
        return result
    _ensure_membership_epoch_schema_v2578()
    conn = init_db()
    try:
        placeholders = ','.join('?' for _ in ids)
        for sid, epoch in conn.execute(
            'SELECT section_id, epoch FROM section_membership_epoch_v2578 WHERE section_id IN (%s)' % placeholders,
            tuple(ids)
        ).fetchall():
            result[str(sid or '')] = int(epoch or 0)
    finally:
        conn.close()
    return result


def _local_membership_epoch_v2578(section_id):
    sid = str(section_id or '').strip()
    if not sid:
        return 0
    try:
        return int(_local_membership_epochs_v2578([sid]).get(sid, 0) or 0)
    except Exception:
        return 0


def _startup_remote_membership_inventory_v2348(section, env=None):
    """Read complete current Plex membership for one selected section.

    v2368 keeps the same fail-closed exact membership proof, but after the
    first page reveals ``totalSize`` it fetches the remaining pages in bounded
    parallel batches.  No deletion/prune is allowed unless every page agrees
    on the same total and the final unique-key count is exact.
    """
    _bind_env(env)
    sec = section or {}
    sid = str(sec.get("section_id") or "").strip()
    stype = str(sec.get("section_type") or "").strip()
    result = {
        "ok": False, "section_id": sid, "keys": set(),
        "counts": {"movie": 0, "show": 0, "episode": 0, "total": 0},
        "requests": 0, "elapsed": 0.0, "error": "",
    }
    if not sid:
        result["error"] = "missing_section_id"
        return result

    endpoints = []
    base = {
        "checkFiles": 0, "includeExtras": 0, "includeReviews": 0,
        "includeRelated": 0, "skipRefresh": 1,
        "includeGuids": 0, "includeMarkers": 0,
    }
    if stype == PLEX_TYPE_MOVIE:
        params = dict(base)
        params["type"] = PLEX_TYPE_TO_NUM.get(PLEX_TYPE_MOVIE, "1")
        endpoints.append(("/library/sections/%s/all" % sid, params, "movie"))
    elif stype == PLEX_TYPE_SHOW:
        params = dict(base)
        params["type"] = PLEX_TYPE_TO_NUM.get(PLEX_TYPE_SHOW, "2")
        endpoints.append(("/library/sections/%s/all" % sid, params, "show"))
        endpoints.append(("/library/sections/%s/allLeaves" % sid, dict(base), "episode"))
    else:
        endpoints.append(("/library/sections/%s/all" % sid, dict(base), "total"))

    t0 = time.time()
    chunk = 1000

    def fetch_page(path, params_base, start):
        if _pkm_service_abort_requested():
            raise RuntimeError("service_abort")
        params = dict(params_base)
        params["X-Plex-Container-Start"] = int(start)
        params["X-Plex-Container-Size"] = chunk
        root = plex_request_xml(path, params=params, timeout=30)
        expected = int(xml_attr_int(root, "totalSize", 0) or 0)
        children = [node for node in list(root) if node.tag in ("Video", "Directory")]
        keys = []
        for node in children:
            rk = str(node.get("ratingKey") or "").strip()
            if rk:
                keys.append(rk)
        return expected, len(children), keys

    try:
        for path, params_base, bucket in endpoints:
            expected, first_children, first_keys = fetch_page(path, params_base, 0)
            result["requests"] += 1
            endpoint_keys = set(first_keys)
            if expected == 0:
                if first_children:
                    raise RuntimeError("membership_zero_total_with_rows:%s" % bucket)
            elif first_children <= 0:
                raise RuntimeError("membership_short_page:%s:0/%d" % (bucket, expected))

            starts = list(range(chunk, expected, chunk)) if expected > chunk else []
            if starts:
                workers = max(1, min(5, len(starts)))
                page_t0 = time.time()
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    future_map = {executor.submit(fetch_page, path, params_base, start): start for start in starts}
                    for future in as_completed(future_map):
                        start = future_map[future]
                        page_expected, child_count, page_keys = future.result()
                        result["requests"] += 1
                        if page_expected != expected:
                            raise RuntimeError("membership_total_changed:%s:%d/%d@%d" % (bucket, page_expected, expected, start))
                        if child_count <= 0 and start < expected:
                            raise RuntimeError("membership_short_page:%s:%d/%d" % (bucket, start, expected))
                        if start + child_count < expected and child_count < chunk:
                            raise RuntimeError("membership_short_page:%s:%d/%d" % (bucket, start + child_count, expected))
                        endpoint_keys.update(page_keys)
                log("STARTUP_MEMBERSHIP_PAGES_PARALLEL_V2368 section=%s bucket=%s pages=%d workers=%d expected=%d elapsed_ms=%d" % (
                    sid, bucket, len(starts) + 1, workers, expected, int((time.time() - page_t0) * 1000)
                ), xbmc.LOGINFO)

            if len(endpoint_keys) != expected:
                raise RuntimeError("membership_count_mismatch:%s:%d/%d" % (bucket, len(endpoint_keys), expected))
            result["keys"].update(endpoint_keys)
            if bucket in result["counts"]:
                result["counts"][bucket] = int(expected)
            elif bucket == "total":
                result["counts"]["total"] = int(expected)

        if stype in (PLEX_TYPE_MOVIE, PLEX_TYPE_SHOW):
            result["counts"]["total"] = (
                int(result["counts"].get("movie", 0) or 0)
                + int(result["counts"].get("show", 0) or 0)
                + int(result["counts"].get("episode", 0) or 0)
            )
        result["ok"] = True
        return result
    except Exception as exc:
        result["error"] = str(exc or "membership_scan_failed")
        log("STARTUP_SERVER_MEMBERSHIP_SCAN_FAILED_V2348 section=%s title=%s type=%s error=%s action=preserve_local_no_prune" % (
            sid, sec.get("title", ""), stype, result["error"]
        ), xbmc.LOGWARNING)
        return result
    finally:
        result["elapsed"] = time.time() - t0


def _startup_reconcile_section_membership_v2348(section, env=None):
    """Compare one selected library's local keys against current Plex keys."""
    _bind_env(env)
    sec = section or {}
    sid = str(sec.get("section_id") or "").strip()
    out = {
        "ok": False, "section_id": sid, "stale": [], "missing": [],
        "pruned": {"total": 0, "movie": 0, "show": 0, "episode": 0},
        "force_full": False, "counts": {}, "remote_total": 0, "elapsed": 0.0,
    }
    scan = _startup_remote_membership_inventory_v2348(sec)
    out["elapsed"] = float(scan.get("elapsed", 0.0) or 0.0)
    if not scan.get("ok"):
        return out
    conn = init_db()
    try:
        rows = conn.execute("SELECT rating_key FROM items WHERE section_id=?", (sid,)).fetchall()
        local_keys = set(str(r[0]) for r in rows if r and r[0] is not None)
    finally:
        conn.close()
    remote_keys = set(scan.get("keys") or set())
    stale = sorted(local_keys - remote_keys)
    missing = sorted(remote_keys - local_keys)
    out.update({
        "ok": True,
        "stale": stale,
        "missing": missing,
        "force_full": bool(missing),
        "counts": dict(scan.get("counts") or {}),
        "remote_total": int((scan.get("counts") or {}).get("total", 0) or 0),
    })

    # Deletion-only drift does not require a second full metadata download.
    # Remove the proven server-missing keys immediately. If Plex also contains
    # locally-missing keys, defer both directions to the existing authoritative
    # full-sync+prune path so moves/replacements are reconstructed correctly.
    if stale and not missing:
        purge = _ENV.get("purge_rating_keys_local_v2348")
        if callable(purge):
            out["pruned"] = purge(sid, stale, reason="startup_membership_stale_v2348") or out["pruned"]
        else:
            out["force_full"] = True

    log("STARTUP_SERVER_MEMBERSHIP_V2348 section=%s title=%s remote=%d local_before=%d stale=%d missing=%d direct_prune=%d force_full=%d requests=%d elapsed=%.2fs authoritative=plex" % (
        sid, sec.get("title", ""), len(remote_keys), len(local_keys), len(stale), len(missing),
        int((out.get("pruned") or {}).get("total", 0) or 0), 1 if out.get("force_full") else 0,
        int(scan.get("requests", 0) or 0), float(scan.get("elapsed", 0.0) or 0.0)
    ), xbmc.LOGINFO)
    return out


def _startup_purge_removed_plex_sections_v2348(remote_sections, local_section_ids, env=None):
    """Remove complete library caches when the Plex section itself disappeared."""
    _bind_env(env)
    remote_ids = set(str((s or {}).get("section_id") or "").strip() for s in (remote_sections or []))
    remote_ids.discard("")
    local_ids = set(str(x or "").strip() for x in (local_section_ids or []))
    local_ids.discard("")
    missing_sections = sorted(local_ids - remote_ids)
    result = {"total": 0, "movie": 0, "show": 0, "episode": 0, "sections": 0}
    if not missing_sections:
        return result
    purge = _ENV.get("purge_sections_local_v2348")
    if not callable(purge):
        log("STARTUP_SERVER_SECTION_RECONCILE_SKIP_V2348 ids=%s reason=no_purge_hook" % ",".join(missing_sections), xbmc.LOGWARNING)
        return result
    result = purge(missing_sections, reason="startup_plex_section_removed_v2348") or result
    log("STARTUP_SERVER_SECTION_RECONCILE_V2348 removed_sections=%d removed_items=%d ids=%s authoritative=plex" % (
        int(result.get("sections", 0) or 0), int(result.get("total", 0) or 0), ",".join(missing_sections)
    ), xbmc.LOGWARNING)
    return result


def _repair_section_type_mismatch_v1370(sections=None, env=None):
    _bind_env(env)
    """v1370: remove rows written into the wrong library section by the v1367~v1369
    startup latest-item partial sync bug.

    The bug reused the last section's latest rows for every changed section.  In
    practice TV episode rows could be inserted under movie libraries, which made
    every Kodi start look like a new update.  This cleanup is limited to clear
    type mismatches only: movie libraries keep movie rows, TV libraries keep show
    and episode rows.
    """
    try:
        sections = list(sections or [])
    except Exception:
        sections = []
    if not sections:
        return 0
    conn = None
    removed = 0
    try:
        conn = init_db()
        for sec in sections:
            sid = str((sec or {}).get("section_id") or "").strip()
            stype = str((sec or {}).get("section_type") or "").strip()
            if not sid:
                continue
            if stype == PLEX_TYPE_MOVIE:
                cur = conn.execute("DELETE FROM items WHERE section_id=? AND plex_type<>?", (sid, PLEX_TYPE_MOVIE))
            elif stype == PLEX_TYPE_SHOW:
                cur = conn.execute("DELETE FROM items WHERE section_id=? AND plex_type NOT IN (?,?)", (sid, PLEX_TYPE_SHOW, PLEX_TYPE_EPISODE))
            else:
                continue
            try:
                removed += int(cur.rowcount or 0)
            except Exception:
                pass
        if removed:
            conn.commit()
            log("PKM_V1370_SECTION_TYPE_MISMATCH_CLEANUP removed=%d" % removed, xbmc.LOGWARNING)
        return removed
    except Exception:
        try:
            log("PKM_V1370_SECTION_TYPE_MISMATCH_CLEANUP_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        except Exception:
            pass
        return 0
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

def local_tv_tag_index_missing_for_section(section_id, env=None):
    _bind_env(env)
    """Return True when an existing TV section has no actor/studio tag index yet.

    This lets the first startup after v471 build the DB index during the normal
    sync path instead of waiting for a future Plex library change.
    """
    sid = str(section_id or "").strip()
    if not sid:
        return False
    conn = init_db()
    try:
        show_count = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=? AND plex_type=?", (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        if int(show_count or 0) <= 0:
            return False
        people_count = conn.execute("""
            SELECT COUNT(DISTINCT p.rating_key)
            FROM item_people p
            JOIN items s ON s.rating_key=p.rating_key
            WHERE p.section_id=? AND s.plex_type=?
        """, (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        studio_count = conn.execute("""
            SELECT COUNT(DISTINCT st.rating_key)
            FROM item_studios st
            JOIN items s ON s.rating_key=st.rating_key
            WHERE st.section_id=? AND s.plex_type=?
        """, (sid, PLEX_TYPE_SHOW)).fetchone()[0]
        return int(people_count or 0) <= 0 and int(studio_count or 0) <= 0
    except Exception:
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass

def local_section_count(section_id, env=None):
    _bind_env(env)
    try:
        return int((local_section_counts(str(section_id)) or {}).get("total", 0) or 0)
    except Exception:
        return 0

def update_section_count(section_id, count_value, env=None):
    _bind_env(env)
    conn = init_db()
    try:
        conn.execute("UPDATE sections SET item_count=? WHERE section_id=?", (int(count_value or 0), str(section_id)))
        conn.commit()
    finally:
        conn.close()

def load_local_section_meta_map(env=None):
    _bind_env(env)
    conn = init_db()
    try:
        rows = conn.execute("SELECT section_id, COALESCE(scanned_at,0), COALESCE(item_count,0) FROM sections").fetchall()
        return {str(r[0]): {"scanned_at": int(r[1] or 0), "item_count": int(r[2] or 0)} for r in rows}
    except Exception:
        return {}
    finally:
        conn.close()

def load_sync_state_map(env=None):
    _bind_env(env)
    conn = init_db()
    try:
        rows = conn.execute("SELECT section_id, COALESCE(remote_updated_at,0), COALESCE(remote_count,0), COALESCE(last_checked_at,0), COALESCE(last_synced_at,0) FROM sync_state").fetchall()
        return {str(r[0]): {
            "remote_updated_at": int(r[1] or 0),
            "remote_count": int(r[2] or 0),
            "last_checked_at": int(r[3] or 0),
            "last_synced_at": int(r[4] or 0),
        } for r in rows}
    except Exception:
        return {}
    finally:
        conn.close()

def update_sync_state(section_id, remote_updated_at=0, remote_count=0, synced=False, env=None):
    _bind_env(env)
    conn = init_db()
    now = int(time.time())
    try:
        current_synced = 0
        try:
            row = conn.execute("SELECT COALESCE(last_synced_at,0) FROM sync_state WHERE section_id=?", (str(section_id),)).fetchone()
            current_synced = int(row[0] or 0) if row else 0
        except Exception:
            current_synced = 0
        last_synced = now if synced else current_synced
        conn.execute(
            "INSERT INTO sync_state(section_id, remote_updated_at, remote_count, last_checked_at, last_synced_at) "
            "VALUES(?,?,?,?,?) "
            "ON CONFLICT(section_id) DO UPDATE SET "
            "remote_updated_at=excluded.remote_updated_at, "
            "remote_count=excluded.remote_count, "
            "last_checked_at=excluded.last_checked_at, "
            "last_synced_at=excluded.last_synced_at",
            (str(section_id), int(remote_updated_at or 0), int(remote_count or 0), now, int(last_synced or 0))
        )
        conn.commit()
    finally:
        conn.close()

def _pkm_full_reset_in_progress_v2149():
    try:
        win_v2150 = xbmcgui.Window(10000)
        return bool(win_v2150.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win_v2150.getProperty("PlexKM.FullResetInProgressV2149") == "1")
    except Exception:
        return False


def _pkm_service_abort_requested(env=None):
    _bind_env(env)
    # v2149: full reset uses the same cooperative cancellation boundary as
    # service shutdown.  This prevents a startup sync from continuing after the
    # reset clears Plex credentials or deletes the SQLite profile.
    if _pkm_full_reset_in_progress_v2149():
        return True
    try:
        if xbmc.Monitor().abortRequested():
            return True
    except Exception:
        pass
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.ServiceStopping") == "1"
    except Exception:
        return False


def _pkm_background_video_or_trailer_active():
    """Passive guard for automatic/background work.

    v942: Home trailer preview is also playback.  When a trailer is preparing or
    visible in the Home video window, Cine21/Plex background writes must not run.
    """
    try:
        func = globals().get("pkm_player_has_video")
        if callable(func) and func():
            return True
    except Exception:
        pass
    try:
        if xbmc and (xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility("Player.HasVideo") or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)") or xbmc.getCondVisibility("Window.IsActive(videoosd)")):
            return True
    except Exception:
        pass
    try:
        if xbmcgui:
            win = xbmcgui.Window(10000)
            return bool(
                win.getProperty("PlexKM.Home.TrailerPreparing") == "1"
                or win.getProperty("PlexKM.Home.TrailerActive") == "1"
                or win.getProperty("PlexKM.Home.TrailerFadeHold") == "1"
            )
    except Exception:
        pass
    return False


def _run_cine21_sync_update(caller="", reason="", env=None):
    """Run a small Cine21 DB update immediately after Plex sync/cache validation.

    v922: no delayed timer and no Info/Home UI network access.  This is tied to
    the Plex sync thread.  It seeds missing movie rows, safely exact-matches
    title+year on Cine21, and fetches scores for matched rows.  Missing scores
    are stored as no_match/ambiguous/error so the UI can treat them as empty
    without retrying during screen entry.

    v940: single background worker guard.  If another Cine21 worker is already
    active, this call is recorded internally and returns without any UI notice.
    """
    _bind_env(env)
    try:
        win_guard = xbmcgui.Window(10000)
        if win_guard.getProperty("PlexKM.Cine21.WorkerRunning") == "1":
            win_guard.setProperty("PlexKM.Cine21.QueuedInternal", "1")
            log("CINE21_SYNC_UPDATE_SKIP reason=worker_running caller=%s queued_internal=1" % (caller or ""), xbmc.LOGINFO)
            return {"queued_internal": 1}
        win_guard.setProperty("PlexKM.Cine21.WorkerRunning", "1")
        win_guard.setProperty("PlexKM.Cine21.WorkerCaller", caller or "")
    except Exception:
        win_guard = None
    # v941: no automatic/background Cine21 DB work is allowed during playback.
    # UI playback has priority over every cache updater, regardless of caller.
    if _pkm_background_video_or_trailer_active():
        log("CINE21_SYNC_UPDATE_SKIP reason=player_or_trailer_active caller=%s" % (caller or ""), xbmc.LOGINFO)
        try:
            if win_guard is not None:
                win_guard.clearProperty("PlexKM.Cine21.WorkerRunning")
                win_guard.clearProperty("PlexKM.Cine21.WorkerCaller")
        except Exception:
            pass
        return None
    conn = None
    t0 = time.time()
    try:
        from resources.lib import pkm_cine21
        conn = init_db()
        stats = pkm_cine21.auto_update_cine21_cache(
            conn,
            seed_limit=80,
            match_limit=12,
            fetch_limit=12,
            timeout=6,
            mark_missing_limit=0,
            abort_cb=lambda: (_pkm_service_abort_requested(env) or _pkm_background_video_or_trailer_active()),
        ) or {}
        elapsed = (time.time() - t0) * 1000.0
        try:
            win = xbmcgui.Window(10000)
            token = str(int(time.time() * 1000))
            win.setProperty("PlexKM.Cine21.LastUpdateToken", token)
            # Home watcher will rebuild/re-read DB after a Cine21 write so newly
            # added movie ratings appear in the same Kodi run, not only after
            # restart.  Rendering itself remains DB-only.
            if int(stats.get("seeded", 0) or 0) or int(stats.get("matched", 0) or 0) or int(stats.get("fetched_ok", 0) or 0):
                win.setProperty("PlexKM.Home.DataRefreshReason", "cine21_sync_%s" % (reason or caller or "update"))
                win.setProperty("PlexKM.Home.DataRefreshToken", token)
        except Exception:
            pass
        log("CINE21_SYNC_UPDATE_DONE caller=%s reason=%s seeded=%s match_checked=%s matched=%s no_match=%s ambiguous=%s fetch_candidates=%s ok=%s error=%s elapsed=%.1fms" % (
            caller or "", reason or "",
            stats.get("seeded", 0), stats.get("match_checked", 0), stats.get("matched", 0),
            stats.get("match_no_match", 0), stats.get("match_ambiguous", 0),
            stats.get("candidates", 0), stats.get("fetched_ok", 0), stats.get("fetched_error", 0), elapsed
        ), xbmc.LOGINFO)
        return stats
    except Exception:
        log("CINE21_SYNC_UPDATE_FAILED caller=%s reason=%s err=%s" % (
            caller or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return None
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
        try:
            if win_guard is not None:
                win_guard.clearProperty("PlexKM.Cine21.WorkerRunning")
                win_guard.clearProperty("PlexKM.Cine21.WorkerCaller")
        except Exception:
            pass

def _startup_partial_sync_latest_items(section, latest_remote_rows=None, latest_local_rows=None, caller="", reason="latest_item", limit=24, detail_reason="", env=None):
    _bind_env(env)
    """v996: update only the latest changed Plex items during startup.

    Update detection remains correct. When latest keys differ, startup caches
    those latest items immediately without force-syncing a large section. v2348
    separately proves complete Plex membership before this partial path is used,
    so deletion/prune correctness no longer depends on a full/manual sync.
    """
    t0 = time.time()
    section = section or {}
    sid = str(section.get("section_id") or "").strip()
    section_type = str(section.get("section_type") or "").strip()
    title = section.get("title", "")
    max_items = max(1, int(limit or 24))
    stats = {"movie": 0, "show": 0, "episode": 0}
    if not sid:
        return 0, 0, 0.0, stats
    extract_item_func = _ENV.get("extract_item") or globals().get("extract_item")
    if not callable(extract_item_func):
        log("STARTUP_SYNC_PARTIAL_SKIP section=%s title=%s caller=%s reason=no_extract_item_env" % (sid, title or "", caller or ""), xbmc.LOGWARNING)
        return 0, 0, 0.0, stats

    def _rk(row):
        return str((row or {}).get("rating_key") or "").strip()

    local_map = {}
    try:
        for row in latest_local_rows or []:
            key = _rk(row)
            if key:
                local_map[key] = row or {}
    except Exception:
        local_map = {}

    candidates = []
    seen = set()
    try:
        for row in latest_remote_rows or []:
            key = _rk(row)
            if not key or key in seen:
                continue
            local = local_map.get(key)
            changed = False
            if not local:
                changed = True
            else:
                try:
                    changed = int((row or {}).get("updated_at") or 0) > int((local or {}).get("updated_at") or 0)
                except Exception:
                    changed = False
            if changed:
                candidates.append(key)
                seen.add(key)
            if len(candidates) >= max_items:
                break
    except Exception:
        pass

    if not candidates and str(detail_reason or "").startswith("metadata_incomplete:"):
        # v2352: a metadata-only repair names the exact sparse ratingKey(s).
        # Do not refetch the whole newest-10 window just because updatedAt is
        # unchanged; that was the second repeated startup loop after Home.
        try:
            wanted = [x.strip() for x in str(detail_reason).split(":", 1)[1].split(",") if x.strip()]
            remote_keys = set(_rk(row) for row in (latest_remote_rows or []) if _rk(row))
            for key in wanted:
                if key in remote_keys and key not in seen:
                    candidates.append(key)
                    seen.add(key)
                if len(candidates) >= max_items:
                    break
            if candidates:
                log("STARTUP_SYNC_PARTIAL_METADATA_TARGET_V2352 section=%s title=%s keys=%s full_latest_window=0" % (
                    sid, title or "", ",".join(candidates[:10])
                ), xbmc.LOGINFO)
        except Exception:
            pass

    if not candidates:
        try:
            for row in latest_remote_rows or []:
                key = _rk(row)
                if key and key not in seen:
                    candidates.append(key)
                    seen.add(key)
                if len(candidates) >= min(10, max_items):
                    break
        except Exception:
            pass

    if not candidates:
        log("STARTUP_SYNC_PARTIAL_SKIP section=%s title=%s caller=%s reason=no_candidates" % (sid, title or "", caller or ""), xbmc.LOGINFO)
        return 0, 0, 0.0, stats

    conn = None
    search_conn = None
    fetched = 0
    total_seen = 0
    show_parent_keys = set()
    try:
        conn = init_db()
        try:
            import sqlite3
            search_conn = sqlite3.connect(search_db_path(), timeout=8.0)
            init_search_db(search_conn)
        except Exception:
            search_conn = None
            log("STARTUP_SYNC_PARTIAL_SEARCH_OPEN_FAILED section=%s err=%s" % (sid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

        def _upsert_xml_node(node, source_label="item"):
            nonlocal fetched, total_seen
            item = extract_item_func(node, sid, section_type)
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                return
            old_checksum = None
            old_row = None
            try:
                old_row = conn.execute("SELECT checksum FROM items WHERE rating_key=?", (rk,)).fetchone()
                old_checksum = old_row[0] if old_row else None
            except Exception:
                old_checksum = None
            upsert_item(conn, item)
            # v1330: partial sync must persist detail side tables, not only the
            # items row.  Info reads actor/director/genre/rating/studio data from
            # these tables.  The missing call here is why newly-added items existed
            # in PKM but opened with empty cast/genre/director until an Info-time
            # Plex repair was attempted.
            try:
                ptype_for_detail = str(item.get("plex_type") or "")
                if ptype_for_detail == PLEX_TYPE_MOVIE:
                    updater = _ENV.get("update_recommend_index_from_live_xml")
                    if callable(updater):
                        updater(node, item, reason="startup_partial_latest_v1330", conn=conn, bootstrap_ready=True, log_skips=False)
                elif ptype_for_detail == PLEX_TYPE_SHOW:
                    tv_indexer = _ENV.get("save_tv_show_tag_index")
                    if callable(tv_indexer):
                        tv_indexer(conn, item, node, reason="startup_partial_latest_v1330")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_DETAIL_INDEX_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            try:
                if search_conn is not None:
                    upsert_search_index_item(search_conn, item, section_title="")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_SEARCH_UPSERT_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            if old_row is None:
                ptype = str(item.get("plex_type") or "")
                if ptype in stats:
                    stats[ptype] += 1
            try:
                gp = str(item.get("grandparent_rating_key") or "").strip()
                if gp:
                    show_parent_keys.add(gp)
            except Exception:
                pass
            fetched += 1

        for key in candidates[:max_items]:
            if _pkm_service_abort_requested():
                log("STARTUP_SYNC_PARTIAL_ABORT_V2149 section=%s key=%s caller=%s reason=full_reset_or_service_stop" % (
                    sid, key, caller or ""
                ), xbmc.LOGINFO)
                break
            try:
                root = plex_request_xml("/library/metadata/%s" % key, params={
                    "checkFiles": 0,
                    "includeExtras": 0,
                    "includeReviews": 0,
                    "includeRelated": 0,
                    "skipRefresh": 1,
                }, timeout=12)
                nodes = [x for x in list(root) if x.tag in ("Video", "Directory")]
                total_seen += len(nodes)
                for node in nodes:
                    _upsert_xml_node(node, source_label="latest")
            except Exception:
                log("STARTUP_SYNC_PARTIAL_ITEM_FAILED section=%s key=%s title=%s err=%s" % (
                    sid, key, title or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        # For new TV episodes, cache parent show poster/fanart if possible.
        if section_type == PLEX_TYPE_SHOW and show_parent_keys and not _pkm_service_abort_requested():
            for show_key in list(show_parent_keys)[:max_items]:
                if _pkm_service_abort_requested():
                    log("STARTUP_SYNC_PARTIAL_PARENT_ABORT_V2149 section=%s show_key=%s caller=%s reason=full_reset_or_service_stop" % (
                        sid, show_key, caller or ""
                    ), xbmc.LOGINFO)
                    break
                try:
                    root = plex_request_xml("/library/metadata/%s" % show_key, params={
                        "checkFiles": 0,
                        "includeExtras": 0,
                        "includeReviews": 0,
                        "includeRelated": 0,
                        "skipRefresh": 1,
                    }, timeout=12)
                    for node in [x for x in list(root) if x.tag in ("Video", "Directory")]:
                        total_seen += 1
                        _upsert_xml_node(node, source_label="parent_show")
                except Exception:
                    log("STARTUP_SYNC_PARTIAL_SHOW_FAILED section=%s show_key=%s title=%s err=%s" % (
                        sid, show_key, title or "", traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

        try:
            now = int(time.time())
            conn.execute("UPDATE sections SET scanned_at=? WHERE section_id=?", (now, sid))
        except Exception:
            pass
        try:
            conn.commit()
            if search_conn is not None:
                search_conn.commit()
        except Exception:
            pass
    finally:
        try:
            if search_conn is not None:
                search_conn.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

    elapsed = time.time() - t0
    log("STARTUP_SYNC_PARTIAL_DONE section=%s title=%s caller=%s reason=%s candidates=%d fetched=%d total_seen=%d elapsed=%.1f movie=%d show=%d episode=%d keys=%s" % (
        sid, title or "", caller or "", reason or "", len(candidates), fetched, total_seen, elapsed,
        int(stats.get("movie", 0) or 0), int(stats.get("show", 0) or 0), int(stats.get("episode", 0) or 0),
        ",".join(candidates[:10])
    ), xbmc.LOGINFO)
    return fetched, total_seen or fetched, elapsed, stats


def _plex_offline_active():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1"
    except Exception:
        return False



def _local_membership_digest_v2349(section_id):
    """Cheap local key fingerprint used to prove the DB did not drift after audit."""
    sid = str(section_id or "").strip()
    h = hashlib.sha1()
    conn = init_db()
    try:
        for row in conn.execute("SELECT rating_key FROM items WHERE section_id=? ORDER BY rating_key", (sid,)).fetchall():
            if row and row[0] is not None:
                h.update(str(row[0]).encode("utf-8", "replace"))
                h.update(b"\n")
    finally:
        conn.close()
    return h.hexdigest()


def startup_prehome_authority_gate_v2349(env=None):
    """Prove selected-library membership before PKM Home can publish local rows.

    First v2349 run performs one complete ratingKey membership audit per selected
    section and stores a compact proof (Plex section timestamp/count/latest keys +
    local key digest). Later Kodi starts use cheap count/latest probes and the
    local digest; a full membership scan is repeated only when Plex section
    updatedAt/local membership changes or the proof is missing.  v2577 removes the
    old six-hour age expiry so unchanged libraries do not periodically pay a full
    set of remote probes before Home.
    """
    _bind_env(env)
    global _PREHOME_AUTHORITY_READY_V2349
    _PREHOME_AUTHORITY_READY_V2349 = {}
    result = {
        "ok": False, "checked": 0, "dirty": 0, "membership_scans": 0,
        "full_syncs": 0, "incremental_syncs": 0, "removed_sections": 0,
        "pruned": {"total": 0, "movie": 0, "show": 0, "episode": 0},
        "verified": 0, "reused": 0, "elapsed": 0.0, "errors": [],
    }
    t0 = time.time()
    if not clean_server_url() or not plex_token() or not initial_sync_done():
        result["elapsed"] = time.time() - t0
        return result
    if _pkm_service_abort_requested():
        result["elapsed"] = time.time() - t0
        return result
    if not acquire_sync_lock(label="prehome-authority-v2349"):
        result["errors"].append("sync_lock_busy")
        result["elapsed"] = time.time() - t0
        log("STARTUP_PREHOME_AUTHORITY_SKIP_V2349 reason=sync_lock_busy action=preserve_local", xbmc.LOGWARNING)
        return result

    try:
        sections_t0_v2367 = time.time()
        try:
            # v2367: authority needs the live Plex section snapshot, not a second
            # write of the sections table.  Home refresh persists this same
            # snapshot moments later (the Plex response is request-coalesced), so
            # writing all section rows here only adds startup I/O.
            all_remote = fetch_sections(refresh=True, selected_only=False, persist=False)
            full_section_list = True
            section_snapshot_persist_v2367 = 0
        except TypeError:
            try:
                all_remote = fetch_sections(refresh=True, selected_only=False)
                full_section_list = True
            except TypeError:
                all_remote = fetch_sections(refresh=True)
                full_section_list = False
            section_snapshot_persist_v2367 = 1
        log("STARTUP_PREHOME_SECTION_SNAPSHOT_V2367 sections=%d persist=%d elapsed_ms=%d" % (
            len(all_remote or []), section_snapshot_persist_v2367,
            int((time.time() - sections_t0_v2367) * 1000)
        ), xbmc.LOGINFO)

        previous_section_meta = load_local_section_meta_map()
        state = load_state() or {}
        proof_map = dict(state.get("server_authority_verified_v2349") or {})

        removed_stats = {"total": 0, "movie": 0, "show": 0, "episode": 0, "sections": 0}
        if full_section_list:
            remote_ids = set(str((x or {}).get("section_id") or "").strip() for x in (all_remote or []))
            for old_sid in list(proof_map.keys()):
                if str(old_sid) not in remote_ids:
                    proof_map.pop(old_sid, None)
            removed_stats = _startup_purge_removed_plex_sections_v2348(
                all_remote, list(previous_section_meta.keys())
            ) or removed_stats
            result["removed_sections"] = int(removed_stats.get("sections", 0) or 0)
            for k in ("total", "movie", "show", "episode"):
                result["pruned"][k] += int(removed_stats.get(k, 0) or 0)

        configured = bool(state.get("selected_sections_configured", False))
        selected_ids = set(
            str(x or "").strip() for x in (state.get("selected_sections", []) or [])
            if str(x or "").strip()
        )
        if not configured or not selected_ids:
            state["server_authority_verified_v2349"] = proof_map
            save_state(state)
            result["ok"] = True
            return result

        sections = [
            sec for sec in (all_remote or [])
            if str((sec or {}).get("section_id") or "").strip() in selected_ids
        ]
        sections = apply_section_order(sections, save_merged=True)
        # First-run full audits can be noticeable.  Small sections are verified
        # first, but Home remains hidden until every selected section has either
        # a valid proof or an explicit network-failure fail-open result.
        ordered_local_counts_v2367 = {}
        bulk_local_digests_v2368 = {}
        local_membership_epochs_v2578 = {}
        bulk_t0_v2368 = time.time()
        try:
            section_ids_v2368 = [str((sec or {}).get("section_id") or "") for sec in sections if str((sec or {}).get("section_id") or "")]
            local_membership_epochs_v2578 = _local_membership_epochs_v2578(section_ids_v2368)
            summary_fast_ids_v2578 = []
            summary_scan_ids_v2578 = []
            # v2578: once an exact proof has been seeded under the membership
            # triggers, unchanged sections do not rescan/hash tens of thousands
            # of local ratingKeys.  Only sections whose membership epoch changed
            # (or old proofs without the v2578 baseline) pay the exact scan.
            for sid_v2578 in section_ids_v2368:
                proof_v2578 = dict(proof_map.get(sid_v2578) or {})
                proof_counts_v2578 = dict(proof_v2578.get("local_counts_v2578") or {})
                proof_epoch_raw_v2578 = proof_v2578.get("local_membership_epoch_v2578", None)
                current_epoch_v2578 = int(local_membership_epochs_v2578.get(sid_v2578, 0) or 0)
                can_reuse_local_summary_v2578 = bool(
                    proof_v2578
                    and proof_epoch_raw_v2578 is not None
                    and int(proof_epoch_raw_v2578 or 0) == current_epoch_v2578
                    and proof_counts_v2578
                    and str(proof_v2578.get("local_digest") or "")
                )
                if can_reuse_local_summary_v2578:
                    ordered_local_counts_v2367[sid_v2578] = proof_counts_v2578
                    bulk_local_digests_v2368[sid_v2578] = str(proof_v2578.get("local_digest") or "")
                    summary_fast_ids_v2578.append(sid_v2578)
                else:
                    summary_scan_ids_v2578.append(sid_v2578)
            if summary_scan_ids_v2578:
                ordered_local_counts_v2367.update(_local_section_counts_bulk_v2368(summary_scan_ids_v2578))
                bulk_local_digests_v2368.update(_local_membership_digests_bulk_v2368(summary_scan_ids_v2578))
            ordered = []
            for sec in sections:
                sid = str((sec or {}).get("section_id") or "")
                counts_v2367 = dict(ordered_local_counts_v2367.get(sid) or {})
                cnt = int(counts_v2367.get("total", 0) or 0)
                ordered.append((cnt, sid, sec))
            ordered.sort(key=lambda x: (x[0], x[1]))
            sections = [x[2] for x in ordered]
            log("STARTUP_PREHOME_LOCAL_SUMMARY_V2578 sections=%d fast=%d scanned=%d elapsed_ms=%d epoch_rows=%d" % (
                len(section_ids_v2368), len(summary_fast_ids_v2578), len(summary_scan_ids_v2578),
                int((time.time() - bulk_t0_v2368) * 1000),
                sum(1 for _sid_v2578, _epoch_v2578 in local_membership_epochs_v2578.items() if int(_epoch_v2578 or 0) > 0)
            ), xbmc.LOGINFO)
            if summary_scan_ids_v2578:
                log("STARTUP_PREHOME_LOCAL_BULK_V2368 sections=%d elapsed_ms=%d db_opens=2 reason=v2578_seed_or_epoch_change ids=%s" % (
                    len(summary_scan_ids_v2578), int((time.time() - bulk_t0_v2368) * 1000), ",".join(summary_scan_ids_v2578)
                ), xbmc.LOGINFO)
        except Exception as exc:
            ordered_local_counts_v2367 = {}
            bulk_local_digests_v2368 = {}
            local_membership_epochs_v2578 = {}
            log("STARTUP_PREHOME_LOCAL_BULK_FALLBACK_V2368 error=%s" % exc, xbmc.LOGWARNING)

        log("STARTUP_PREHOME_AUTHORITY_BEGIN_V2349 sections=%d ids=%s mode=persisted_proof_full_on_change home_open=0" % (
            len(sections), ",".join(str((s or {}).get("section_id") or "") for s in sections)
        ), xbmc.LOGINFO)

        # v2367: split the gate into a cheap local precheck and a parallel
        # network probe phase.  All DB/proof writes remain on this thread; worker
        # threads only issue read-only Plex requests and return immutable probe
        # data.  This preserves the v2349 authority barrier while removing the
        # previous per-section serial network latency.
        precheck_t0_v2367 = time.time()
        probe_contexts_v2367 = []
        for section in sections:
            if _pkm_service_abort_requested():
                result["errors"].append("service_abort")
                break
            sid = str((section or {}).get("section_id") or "").strip()
            stype = str((section or {}).get("section_type") or "").strip()
            if not sid:
                continue
            result["checked"] += 1
            try:
                local_counts = dict(ordered_local_counts_v2367.get(sid) or local_section_counts(sid))
                local_digest = str(bulk_local_digests_v2368.get(sid) or _local_membership_digest_v2349(sid))
            except Exception as exc:
                result["errors"].append("count:%s:%s" % (sid, exc))
                log("STARTUP_PREHOME_AUTHORITY_PROBE_FAILED_V2349 section=%s title=%s stage=local_count_or_digest error=%s action=preserve_local" % (
                    sid, section.get("title", ""), exc
                ), xbmc.LOGWARNING)
                continue

            remote_updated = int(section.get("updated_at") or section.get("scanned_at") or 0)
            proof = dict(proof_map.get(sid) or {})
            proof_missing = not bool(proof)
            now_v2358 = int(time.time())
            deep_verified_at_v2358 = int(proof.get("deep_verified_at") or proof.get("verified_at") or 0)
            proof_remote_total_v2358 = int(proof.get("remote_total", -1) or -1)
            local_total_v2358 = int(local_counts.get("total", 0) or 0)
            # PKM_PATCH_ACTIVE v2577 authority_proof_event_driven_reuse
            # The previous six-hour TTL forced every selected section back through
            # 1-2 Plex requests even when the live /library/sections snapshot said
            # the section updatedAt was unchanged and the local membership digest
            # still matched the last deep proof. On the UHD3/PC benchmark this
            # periodic expiry alone cost ~17.7s.  Treat the live Plex section
            # updatedAt as the invalidation event: unchanged timestamp + unchanged
            # local digest + unchanged proven total reuses the deep proof without
            # an age-triggered network probe. Any Plex library change, local DB
            # membership change, missing proof, or count mismatch still falls into
            # the existing remote probe/membership reconciliation path.
            fast_proof_reuse_v2358 = bool(
                proof
                and str(proof.get("local_digest") or "") == local_digest
                and remote_updated > 0
                and int(proof.get("remote_updated_at", -1) or -1) == remote_updated
                and proof_remote_total_v2358 == local_total_v2358
                and deep_verified_at_v2358 > 0
            )
            probe_contexts_v2367.append({
                "section": section,
                "sid": sid,
                "stype": stype,
                "local_counts": local_counts,
                "local_digest": local_digest,
                "remote_updated": remote_updated,
                "proof": proof,
                "proof_missing": proof_missing,
                "now_v2358": now_v2358,
                "deep_verified_at_v2358": deep_verified_at_v2358,
                "proof_remote_total_v2358": proof_remote_total_v2358,
                "local_total_v2358": local_total_v2358,
                "fast_proof_reuse_v2358": fast_proof_reuse_v2358,
                "remote_probe": None,
                "remote_error": "",
            })
        log("STARTUP_PREHOME_LOCAL_PRECHECK_V2367 sections=%d elapsed_ms=%d" % (
            len(probe_contexts_v2367), int((time.time() - precheck_t0_v2367) * 1000)
        ), xbmc.LOGINFO)

        network_contexts_v2367 = [
            ctx for ctx in probe_contexts_v2367 if not ctx.get("fast_proof_reuse_v2358")
        ]
        if network_contexts_v2367:
            network_t0_v2367 = time.time()
            workers_v2367 = max(1, min(5, len(network_contexts_v2367)))
            request_count_v2367 = 0
            with ThreadPoolExecutor(max_workers=workers_v2367) as executor_v2367:
                future_map_v2367 = {
                    executor_v2367.submit(_startup_remote_probe_v2367, ctx["section"], 10): ctx
                    for ctx in network_contexts_v2367
                }
                for future_v2367 in as_completed(future_map_v2367):
                    ctx = future_map_v2367[future_v2367]
                    try:
                        probe = future_v2367.result() or {}
                        ctx["remote_probe"] = probe
                        request_count_v2367 += int(probe.get("requests", 0) or 0)
                    except Exception as exc:
                        ctx["remote_error"] = str(exc)
            log("STARTUP_PREHOME_REMOTE_PROBES_PARALLEL_V2367 sections=%d workers=%d requests=%d elapsed_ms=%d" % (
                len(network_contexts_v2367), workers_v2367, request_count_v2367,
                int((time.time() - network_t0_v2367) * 1000)
            ), xbmc.LOGINFO)
        else:
            log("STARTUP_PREHOME_REMOTE_PROBES_PARALLEL_V2367 sections=0 workers=0 requests=0 elapsed_ms=0 reason=all_fast_proof_reuse", xbmc.LOGINFO)

        for ctx in probe_contexts_v2367:
            if _pkm_service_abort_requested():
                result["errors"].append("service_abort")
                break
            section = ctx["section"]
            sid = ctx["sid"]
            stype = ctx["stype"]
            local_counts = ctx["local_counts"]
            local_digest = ctx["local_digest"]
            remote_updated = ctx["remote_updated"]
            proof = ctx["proof"]
            proof_missing = ctx["proof_missing"]
            now_v2358 = ctx["now_v2358"]
            deep_verified_at_v2358 = ctx["deep_verified_at_v2358"]
            proof_remote_total_v2358 = ctx["proof_remote_total_v2358"]
            local_total_v2358 = ctx["local_total_v2358"]
            fast_proof_reuse_v2358 = ctx["fast_proof_reuse_v2358"]
            verified_remote_rows_v2574 = []
            verified_local_rows_v2574 = []
            pure_addition_keys_v2574 = []
            pure_addition_v2574 = False

            if fast_proof_reuse_v2358:
                remote_counts = dict(local_counts or {})
                remote_total = proof_remote_total_v2358
                remote_latest_keys = list(proof.get("remote_latest_keys") or [])
                count_changed = False
                latest_changed = False
                latest_reason = "fast_proof_reuse_v2358"
                proof_changed = False
                metadata_only_dirty_v2352 = False
                need_full_membership = False
                log("STARTUP_PREHOME_FAST_PROOF_REUSE_V2577 section=%s title=%s local=%d remote=%d section_updated=%d deep_age_s=%d network_per_section=0 membership_scan=0 invalidation=plex_updatedAt_or_local_digest" % (
                    sid, section.get("title", ""), local_total_v2358, remote_total, remote_updated,
                    max(0, now_v2358 - deep_verified_at_v2358)
                ), xbmc.LOGINFO)
            else:
                if ctx.get("remote_error"):
                    exc = ctx.get("remote_error")
                    result["errors"].append("probe:%s:%s" % (sid, exc))
                    log("STARTUP_PREHOME_AUTHORITY_PROBE_FAILED_V2367 section=%s title=%s stage=combined_remote_probe error=%s action=preserve_local" % (
                        sid, section.get("title", ""), exc
                    ), xbmc.LOGWARNING)
                    continue
                remote_probe_v2367 = dict(ctx.get("remote_probe") or {})
                remote_counts = dict(remote_probe_v2367.get("counts") or {})
                remote_latest_rows = list(remote_probe_v2367.get("latest_rows") or [])

                if stype == PLEX_TYPE_MOVIE:
                    count_changed = int(local_counts.get("movie", 0) or 0) != int(remote_counts.get("movie", 0) or 0)
                elif stype == PLEX_TYPE_SHOW:
                    count_changed = (
                        int(local_counts.get("show", 0) or 0) != int(remote_counts.get("show", 0) or 0)
                        or int(local_counts.get("episode", 0) or 0) != int(remote_counts.get("episode", 0) or 0)
                    )
                else:
                    count_changed = int(local_counts.get("total", 0) or 0) != int(remote_counts.get("total", 0) or 0)

                latest_changed = False
                latest_reason = ""
                remote_latest_keys = _latest_item_keys(remote_latest_rows)
                verified_remote_rows_v2574 = list(remote_latest_rows or [])
                verified_local_rows_v2574 = []
                try:
                    latest_changed, verified_remote_rows_v2574, verified_local_rows_v2574, latest_reason = _verify_section_latest_with_remote_rows_v2367(
                        section, remote_latest_rows, limit=10
                    )
                except Exception as exc:
                    latest_reason = "latest_probe_error:%s" % exc
                    result["errors"].append("latest:%s:%s" % (sid, exc))

                remote_total = int(remote_counts.get("total", 0) or 0)
                proof_changed = bool(
                    str(proof.get("local_digest") or "") != local_digest
                    or int(proof.get("remote_total", -1) or -1) != remote_total
                    or int(proof.get("remote_updated_at", -1) or -1) != remote_updated
                    or list(proof.get("remote_latest_keys") or []) != list(remote_latest_keys or [])
                )
                metadata_only_dirty_v2352 = bool(
                    latest_changed and str(latest_reason or "").startswith("metadata_incomplete:")
                )

                # v2574: a small pure-addition change must not trigger a complete
                # membership inventory + force_all sync of a 20k-item library.
                # We can prove the safe case from the already-fetched count/latest
                # probe when (a) the persisted local digest still matches, (b) the
                # remote count only increased, and (c) every count delta is
                # explained by newest Plex ratingKeys missing locally. Deletions,
                # replacements, new TV show rows, large bursts, or any ambiguous
                # state still fall back to the existing authoritative full path.
                local_latest_keys_v2574 = set(_latest_item_keys(verified_local_rows_v2574))
                missing_latest_keys_v2574 = [
                    key for key in remote_latest_keys if key and key not in local_latest_keys_v2574
                ]
                movie_delta_v2574 = int(remote_counts.get("movie", 0) or 0) - int(local_counts.get("movie", 0) or 0)
                show_delta_v2574 = int(remote_counts.get("show", 0) or 0) - int(local_counts.get("show", 0) or 0)
                episode_delta_v2574 = int(remote_counts.get("episode", 0) or 0) - int(local_counts.get("episode", 0) or 0)
                proof_digest_clean_v2574 = bool(
                    proof
                    and str(proof.get("local_digest") or "") == str(local_digest or "")
                )
                pure_addition_keys_v2574 = []
                if (not proof_missing and proof_digest_clean_v2574 and latest_changed
                        and str(latest_reason or "").startswith("missing_in_pkm:")
                        and missing_latest_keys_v2574):
                    if (stype == PLEX_TYPE_MOVIE and 0 < movie_delta_v2574 <= 24
                            and show_delta_v2574 == 0 and episode_delta_v2574 == 0
                            and len(missing_latest_keys_v2574) == movie_delta_v2574):
                        pure_addition_keys_v2574 = list(missing_latest_keys_v2574)
                    elif (stype == PLEX_TYPE_SHOW and show_delta_v2574 == 0
                            and 0 < episode_delta_v2574 <= 24
                            and len(missing_latest_keys_v2574) == episode_delta_v2574):
                        pure_addition_keys_v2574 = list(missing_latest_keys_v2574)
                pure_addition_v2574 = bool(pure_addition_keys_v2574)
                need_full_membership = bool(
                    proof_missing
                    or (proof_changed and not pure_addition_v2574 and not metadata_only_dirty_v2352)
                    or (count_changed and not pure_addition_v2574)
                    or (latest_changed and not metadata_only_dirty_v2352 and not pure_addition_v2574)
                )
            if metadata_only_dirty_v2352 and not need_full_membership:
                log("STARTUP_PREHOME_METADATA_ONLY_REUSE_V2352 section=%s title=%s reason=%s membership_scan=0 proof_reused=1" % (
                    sid, section.get("title", ""), latest_reason or "metadata_incomplete"
                ), xbmc.LOGINFO)
            log("STARTUP_PREHOME_AUTHORITY_PROBE_V2349 section=%s title=%s type=%s local=%d remote=%d count_changed=%d latest_changed=%d proof_missing=%d proof_changed=%d need_membership=%d latest_reason=%s" % (
                sid, section.get("title", ""), stype,
                int(local_counts.get("total", 0) or 0), remote_total,
                1 if count_changed else 0, 1 if latest_changed else 0,
                1 if proof_missing else 0, 1 if proof_changed else 0,
                1 if need_full_membership else 0, latest_reason or ""
            ), xbmc.LOGINFO)

            membership = None
            incremental_resolved_v2574 = False
            authority_source_v2574 = "prehome_proof_v2349"

            # v2574 fast repair: fetch only the newly-added newest ratingKeys.
            # The helper writes the same item/search/detail indexes as the normal
            # startup partial path and, for TV episodes, also refreshes parent-show
            # art. Post-count verification is mandatory; any mismatch immediately
            # falls back to the old full-membership/full-sync path.
            if pure_addition_v2574:
                result["dirty"] += 1
                target_set_v2574 = set(pure_addition_keys_v2574)
                target_rows_v2574 = [
                    row for row in (verified_remote_rows_v2574 or [])
                    if str((row or {}).get("rating_key") or "") in target_set_v2574
                ]
                try:
                    fetched_v2574, _partial_total_v2574, partial_elapsed_v2574, _partial_stats_v2574 = _startup_partial_sync_latest_items(
                        section, latest_remote_rows=target_rows_v2574, latest_local_rows=[],
                        caller="prehome_authority_v2574", reason="pure_addition_v2574",
                        limit=max(1, len(pure_addition_keys_v2574))
                    )
                    post_counts_v2574 = local_section_counts(sid)
                    if stype == PLEX_TYPE_MOVIE:
                        post_match_v2574 = (
                            int(post_counts_v2574.get("movie", 0) or 0) == int(remote_counts.get("movie", 0) or 0)
                        )
                    elif stype == PLEX_TYPE_SHOW:
                        post_match_v2574 = (
                            int(post_counts_v2574.get("show", 0) or 0) == int(remote_counts.get("show", 0) or 0)
                            and int(post_counts_v2574.get("episode", 0) or 0) == int(remote_counts.get("episode", 0) or 0)
                        )
                    else:
                        post_match_v2574 = False
                    if fetched_v2574 >= len(pure_addition_keys_v2574) and post_match_v2574:
                        local_counts = post_counts_v2574
                        local_digest = _local_membership_digest_v2349(sid)
                        result["incremental_syncs"] += 1
                        result["verified"] += 1
                        incremental_resolved_v2574 = True
                        authority_source_v2574 = "prehome_incremental_add_v2574"
                        need_full_membership = False
                        log("STARTUP_PREHOME_INCREMENTAL_ADD_V2574 section=%s title=%s type=%s keys=%s fetched=%d elapsed_ms=%d local_after=%d remote=%d membership_scan=0 force_all=0" % (
                            sid, section.get("title", ""), stype, ",".join(pure_addition_keys_v2574),
                            int(fetched_v2574 or 0), int(float(partial_elapsed_v2574 or 0.0) * 1000),
                            int(local_counts.get("total", 0) or 0), remote_total
                        ), xbmc.LOGINFO)
                    else:
                        need_full_membership = True
                        log("STARTUP_PREHOME_INCREMENTAL_ADD_FALLBACK_V2574 section=%s title=%s keys=%s fetched=%d count_match=%d action=full_membership" % (
                            sid, section.get("title", ""), ",".join(pure_addition_keys_v2574),
                            int(fetched_v2574 or 0), 1 if post_match_v2574 else 0
                        ), xbmc.LOGWARNING)
                except Exception as exc:
                    need_full_membership = True
                    log("STARTUP_PREHOME_INCREMENTAL_ADD_FAILED_V2574 section=%s title=%s keys=%s error=%s action=full_membership" % (
                        sid, section.get("title", ""), ",".join(pure_addition_keys_v2574), exc
                    ), xbmc.LOGWARNING)

            # v2574: sparse metadata is also an exact-ratingKey repair. Repair it
            # here so the authority gate is genuinely current before Home and the
            # service does not need a second startup sync pass.
            if metadata_only_dirty_v2352 and not incremental_resolved_v2574:
                result["dirty"] += 1
                try:
                    wanted_v2574 = [x.strip() for x in str(latest_reason).split(":", 1)[1].split(",") if x.strip()]
                except Exception:
                    wanted_v2574 = []
                target_set_meta_v2574 = set(wanted_v2574[:24])
                target_rows_meta_v2574 = [
                    row for row in (verified_remote_rows_v2574 or [])
                    if str((row or {}).get("rating_key") or "") in target_set_meta_v2574
                ]
                try:
                    fetched_meta_v2574, _meta_total_v2574, meta_elapsed_v2574, _meta_stats_v2574 = _startup_partial_sync_latest_items(
                        section, latest_remote_rows=target_rows_meta_v2574, latest_local_rows=verified_local_rows_v2574,
                        caller="prehome_authority_v2574", reason="metadata_repair_v2574",
                        limit=max(1, len(target_set_meta_v2574) or 10), detail_reason=latest_reason
                    )
                    verify_local_meta_v2574 = _local_section_latest_items(
                        sid, plex_type=(PLEX_TYPE_EPISODE if stype == PLEX_TYPE_SHOW else stype), limit=10
                    )
                    still_incomplete_v2574, still_reason_v2574 = _local_latest_detail_incomplete(
                        sid, stype, remote_rows=verified_remote_rows_v2574, local_rows=verify_local_meta_v2574
                    )
                    if fetched_meta_v2574 > 0 and not still_incomplete_v2574:
                        local_counts = local_section_counts(sid)
                        local_digest = _local_membership_digest_v2349(sid)
                        result["incremental_syncs"] += 1
                        result["verified"] += 1
                        incremental_resolved_v2574 = True
                        authority_source_v2574 = "prehome_metadata_repair_v2574"
                        need_full_membership = False
                        log("STARTUP_PREHOME_METADATA_REPAIR_V2574 section=%s title=%s keys=%s fetched=%d elapsed_ms=%d membership_scan=0 force_all=0" % (
                            sid, section.get("title", ""), ",".join(wanted_v2574[:10]),
                            int(fetched_meta_v2574 or 0), int(float(meta_elapsed_v2574 or 0.0) * 1000)
                        ), xbmc.LOGINFO)
                    else:
                        result["errors"].append("metadata_repair:%s:%s" % (sid, still_reason_v2574 or "not_repaired"))
                        proof_map.pop(sid, None)
                        log("STARTUP_PREHOME_METADATA_REPAIR_FAILED_V2574 section=%s title=%s fetched=%d reason=%s action=no_proof_service_fallback" % (
                            sid, section.get("title", ""), int(fetched_meta_v2574 or 0), still_reason_v2574 or "not_repaired"
                        ), xbmc.LOGWARNING)
                        continue
                except Exception as exc:
                    result["errors"].append("metadata_repair:%s:%s" % (sid, exc))
                    proof_map.pop(sid, None)
                    log("STARTUP_PREHOME_METADATA_REPAIR_FAILED_V2574 section=%s title=%s error=%s action=no_proof_service_fallback" % (
                        sid, section.get("title", ""), exc
                    ), xbmc.LOGWARNING)
                    continue

            if need_full_membership:
                if not pure_addition_v2574:
                    result["dirty"] += 1
                membership = _startup_reconcile_section_membership_v2348(section) or {}
                result["membership_scans"] += 1
                if not membership.get("ok"):
                    result["errors"].append("membership:%s" % sid)
                    proof_map.pop(sid, None)
                    log("STARTUP_PREHOME_AUTHORITY_DIRTY_UNVERIFIED_V2349 section=%s title=%s action=preserve_local_no_proof" % (
                        sid, section.get("title", "")
                    ), xbmc.LOGWARNING)
                    continue

                pruned = membership.get("pruned") or {}
                for k in ("total", "movie", "show", "episode"):
                    result["pruned"][k] += int(pruned.get(k, 0) or 0)

                if membership.get("force_full"):
                    try:
                        fetched = fetch_section_items(
                            sid, stype, progress=None, prune_missing=True, force_all=True
                        )
                        result["full_syncs"] += 1
                        log("STARTUP_PREHOME_AUTHORITY_FULL_SYNC_V2349 section=%s title=%s fetched=%s reason=remote_missing_local_or_replacement home_open=0" % (
                            sid, section.get("title", ""), fetched
                        ), xbmc.LOGINFO)
                    except Exception as exc:
                        result["errors"].append("full_sync:%s:%s" % (sid, exc))
                        proof_map.pop(sid, None)
                        log("STARTUP_PREHOME_AUTHORITY_FULL_SYNC_FAILED_V2349 section=%s title=%s error=%s action=preserve_last_committed_no_proof" % (
                            sid, section.get("title", ""), exc
                        ), xbmc.LOGWARNING)
                        continue

                try:
                    local_counts = local_section_counts(sid)
                    local_digest = _local_membership_digest_v2349(sid)
                except Exception as exc:
                    result["errors"].append("post_digest:%s:%s" % (sid, exc))
                    proof_map.pop(sid, None)
                    continue
                membership_total = int(membership.get("remote_total", remote_total) or remote_total)
                if int(local_counts.get("total", 0) or 0) != membership_total:
                    result["errors"].append("post_count_mismatch:%s:%s/%s" % (
                        sid, local_counts.get("total", 0), membership_total
                    ))
                    proof_map.pop(sid, None)
                    log("STARTUP_PREHOME_AUTHORITY_POSTCHECK_FAILED_V2349 section=%s local=%d remote=%d action=no_proof" % (
                        sid, int(local_counts.get("total", 0) or 0), membership_total
                    ), xbmc.LOGWARNING)
                    continue
                remote_counts = dict(membership.get("counts") or remote_counts)
                remote_total = membership_total
                result["verified"] += 1
                authority_source_v2574 = "prehome_full_membership_v2574"
            else:
                if not incremental_resolved_v2574:
                    result["reused"] += 1

            # v2578: bind the exact local proof to a tiny membership epoch.
            # Subsequent unchanged starts can trust the already-proven digest and
            # counts without scanning every ratingKey again.  Re-read the epoch
            # after any incremental/full repair so the proof commits the final DB.
            local_membership_epoch_final_v2578 = _local_membership_epoch_v2578(sid)
            local_membership_epoch_start_v2578 = int(local_membership_epochs_v2578.get(sid, 0) or 0)
            if int(local_membership_epoch_final_v2578 or 0) != local_membership_epoch_start_v2578:
                # A concurrent pre-Home writer (notably the v2578 playstate pull)
                # inserted/deleted membership while this gate was running.  The
                # epoch makes that race visible; refresh only this section before
                # sealing the persisted proof instead of accepting stale counts.
                local_counts = local_section_counts(sid)
                local_digest = _local_membership_digest_v2349(sid)
                log("STARTUP_PREHOME_LOCAL_EPOCH_RACE_RESCAN_V2578 section=%s epoch_start=%d epoch_final=%d total=%d" % (
                    sid, local_membership_epoch_start_v2578, int(local_membership_epoch_final_v2578 or 0),
                    int(local_counts.get("total", 0) or 0)
                ), xbmc.LOGINFO)
            proof_map[sid] = {
                "remote_updated_at": remote_updated,
                "remote_total": remote_total,
                "remote_latest_keys": list(remote_latest_keys or []),
                "local_digest": local_digest,
                "local_counts_v2578": dict(local_counts or {}),
                "local_membership_epoch_v2578": int(local_membership_epoch_final_v2578 or 0),
                "verified_at": int(time.time()),
                "deep_verified_at": (
                    int(deep_verified_at_v2358 or time.time())
                    if fast_proof_reuse_v2358 else int(time.time())
                ),
            }
            _PREHOME_AUTHORITY_READY_V2349[sid] = {
                "ok": True,
                "counts": dict(remote_counts or {}),
                "remote_total": remote_total,
                "force_full": False,
                "pruned": {"total": 0, "movie": 0, "show": 0, "episode": 0},
                "source": authority_source_v2574,
            }
            try:
                update_section_count(sid, remote_total)
                update_sync_state(sid, remote_updated, remote_total, synced=False)
            except Exception:
                pass

        state["server_authority_verified_v2349"] = proof_map
        save_state(state)
        result["ok"] = (result["checked"] > 0 and len(_PREHOME_AUTHORITY_READY_V2349) == result["checked"])
        return result
    except Exception as exc:
        result["errors"].append("fatal:%s" % exc)
        log("STARTUP_PREHOME_AUTHORITY_FAILED_V2349 error=%s action=preserve_local_fail_open" % exc, xbmc.LOGWARNING)
        return result
    finally:
        result["elapsed"] = time.time() - t0
        log("STARTUP_PREHOME_AUTHORITY_DONE_V2574 ok=%d checked=%d verified=%d reused=%d dirty=%d incremental_syncs=%d membership_scans=%d full_syncs=%d removed_sections=%d pruned=%d elapsed=%.2fs errors=%d home_open=0" % (
            1 if result.get("ok") else 0, int(result.get("checked", 0) or 0),
            int(result.get("verified", 0) or 0), int(result.get("reused", 0) or 0),
            int(result.get("dirty", 0) or 0), int(result.get("incremental_syncs", 0) or 0),
            int(result.get("membership_scans", 0) or 0), int(result.get("full_syncs", 0) or 0),
            int(result.get("removed_sections", 0) or 0),
            int((result.get("pruned") or {}).get("total", 0) or 0), float(result.get("elapsed", 0.0) or 0.0),
            len(result.get("errors") or [])
        ), xbmc.LOGINFO)
        release_sync_lock()

def ensure_startup_cache_ready(show_progress=True, notice_progress=False, caller="startup", precreated_progress=None, env=None):
    _bind_env(env)
    """Make the Plex KM SQLite cache current before PKM Home opens.

    Startup sync is intentionally quiet by default.  If Plex is newer than the
    local DB, movie/show/episode rows are refreshed here, not inside the Info UI.
    """
    def _close_precreated_early_v1747(reason):
        if precreated_progress is None:
            return
        try:
            log("STARTUP_SYNC_PRECREATED_CLOSE_EARLY_V1747 caller=%s reason=%s" % (caller or "", reason or ""), xbmc.LOGINFO)
            precreated_progress.close()
            xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
        except Exception:
            pass

    if _pkm_full_reset_in_progress_v2149():
        log("STARTUP_SYNC_SKIP reason=full_reset_v2149 caller=%s" % (caller or ""), xbmc.LOGINFO)
        _close_precreated_early_v1747("full_reset_v2149")
        return False
    if _plex_offline_active():
        log("STARTUP_SYNC_SKIP reason=plex_offline_v1290 caller=%s" % (caller or ""), xbmc.LOGWARNING)
        _close_precreated_early_v1747("plex_offline")
        return False
    if not clean_server_url() or not plex_token():
        log("startup cache skipped: Plex URL/token missing", xbmc.LOGWARNING)
        _close_precreated_early_v1747("missing_credentials")
        return False
    if not initial_sync_done():
        # Fresh installs still use the existing interactive first-sync path.
        # The small top-right updater is only for later incremental startup checks
        # after PKM Home can open with an existing DB.
        log("STARTUP_SYNC_SKIP reason=initial_sync_not_done caller=%s" % (caller or ""), xbmc.LOGINFO)
        _close_precreated_early_v1747("initial_sync_not_done")
        return False
    if caller in ("service_poll", "service_startup") and pkm_player_has_video():
        log("STARTUP_SYNC_SKIP reason=player_active caller=%s" % (caller or ""), xbmc.LOGINFO)
        _close_precreated_early_v1747("player_active")
        return False
    if is_sync_locked(max_age_sec=1800):
        log("startup cache skipped: sync already running", xbmc.LOGINFO)
        _close_precreated_early_v1747("sync_locked")
        return False
    if not acquire_sync_lock(label="startup-cache"):
        _close_precreated_early_v1747("lock_acquire_failed")
        return False
    log("PKM_PATCH_ACTIVE v2348 startup_server_authoritative_membership_reconcile_no_local_ghosts", xbmc.LOGINFO)
    progress = precreated_progress
    startup_stats = {"movie": 0, "show": 0, "episode": 0}
    notice_token = ""
    visible_notice_started = False
    try:
        # v1370: defer visible PKM update notices until an actual update is found.
        # Startup/polling should not show a notification on every Kodi launch just
        # for the "checking" phase.
        deferred_notice_progress = bool(notice_progress and caller in ("service_startup", "service_poll"))
        if deferred_notice_progress:
            _pkm_notice_clear_update(force=True)
            log("UPDATE_NOTIFY_STALE_CLEAR stage=before_scan caller=%s" % (caller or ""), xbmc.LOGINFO)
        if notice_progress and not deferred_notice_progress:
            notice_token = pkm_notice_set("PKM 업데이트", "라이브러리 상태 확인 준비", "Plex 변경사항 확인 중")
        if show_progress:
            if progress is None:
                progress = _create_pkm_sync_progress()
                log("STARTUP_SYNC_PROGRESS_CREATE_V1747 caller=%s precreated=0" % (caller or ""), xbmc.LOGINFO)
            else:
                log("STARTUP_SYNC_PROGRESS_REUSE_PREARMED_V1747 caller=%s precreated=1" % (caller or ""), xbmc.LOGINFO)
            progress_create(progress, ADDON_NAME, "메타데이터를 확인하고 있습니다")
            try:
                if xbmc.getCondVisibility("Window.IsVisible(13032)"):
                    xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            try:
                log("STARTUP_SYNC_PROGRESS_ACTIVE_V1747 caller=%s base=%s dialog=%s vis13030=%d vis13031=%d vis13032=%d" % (
                    caller or "", xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId(),
                    1 if xbmc.getCondVisibility("Window.IsVisible(13030)") else 0,
                    1 if xbmc.getCondVisibility("Window.IsVisible(13031)") else 0,
                    1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0,
                ), xbmc.LOGINFO)
            except Exception:
                pass
        if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
            log("STARTUP_SYNC_ABORT reason=service_stopping stage=before_scan caller=%s" % (caller or ""), xbmc.LOGINFO)
            return False
        previous_section_meta = load_local_section_meta_map()
        sync_state = load_sync_state_map()

        # v2348: fetch the complete current Plex section list before applying the
        # user's visibility selection.  The old selected-only call could not tell
        # whether a cached section had actually disappeared from Plex, so its
        # local items could survive forever as ghosts.
        try:
            all_remote_sections_v2348 = fetch_sections(refresh=True, selected_only=False)
        except TypeError:
            # Compatibility fallback for older env hooks; current PKM supplies
            # the selected_only argument. Never purge removed sections when the
            # full remote section list cannot be proven.
            all_remote_sections_v2348 = fetch_sections(refresh=True)

        startup_purged_v2348 = {"total": 0, "movie": 0, "show": 0, "episode": 0, "sections": 0}
        if caller == "service_startup":
            startup_purged_v2348 = _startup_purge_removed_plex_sections_v2348(
                all_remote_sections_v2348, list(previous_section_meta.keys())
            )

        selection_state_v2348 = load_state() or {}
        selection_configured_v2348 = bool(selection_state_v2348.get("selected_sections_configured", False))
        selected_ids_v2348 = set(
            str(x or "").strip() for x in (selection_state_v2348.get("selected_sections", []) or [])
            if str(x or "").strip()
        )
        if selection_configured_v2348 and selected_ids_v2348:
            sections = [
                sec for sec in (all_remote_sections_v2348 or [])
                if str((sec or {}).get("section_id") or "").strip() in selected_ids_v2348
            ]
        else:
            sections = []
        sections = apply_section_order(sections, save_merged=True)
        # v2349: the v2348 deep membership audit is post-reveal and can be very
        # expensive for a large movie section.  Audit smaller selected sections
        # first so any residual ghost not caught by the pre-Home delta gate is
        # retired quickly instead of waiting behind multi-thousand-item sections.
        if caller == "service_startup":
            try:
                _order_meta_v2349 = []
                for _sec_v2349 in sections:
                    _sid_v2349 = str((_sec_v2349 or {}).get("section_id") or "")
                    _cnt_v2349 = int((local_section_counts(_sid_v2349) or {}).get("total", 0) or 0)
                    _order_meta_v2349.append((_cnt_v2349, _sid_v2349, _sec_v2349))
                _order_meta_v2349.sort(key=lambda x: (x[0], x[1]))
                sections = [x[2] for x in _order_meta_v2349]
                log("STARTUP_SERVER_MEMBERSHIP_ORDER_V2349 order=%s basis=local_total_asc" % ",".join(
                    "%s:%d" % (x[1], x[0]) for x in _order_meta_v2349
                ), xbmc.LOGINFO)
            except Exception as _order_exc_v2349:
                log("STARTUP_SERVER_MEMBERSHIP_ORDER_SKIP_V2349 error=%s action=keep_saved_order" % _order_exc_v2349, xbmc.LOGWARNING)
        _repair_section_type_mismatch_v1370(sections)
        total_sections = len(sections)
        if notice_progress and not deferred_notice_progress:
            pkm_notice_set("PKM 업데이트", "라이브러리 확인 0/%d" % total_sections, "Plex 변경사항 확인 중", token=notice_token)
        if not sections:
            purged_total_v2348 = int(startup_purged_v2348.get("total", 0) or 0)
            purged_sections_v2348 = int(startup_purged_v2348.get("sections", 0) or 0)
            if purged_total_v2348 or purged_sections_v2348:
                refresh_token_v2348 = _signal_home_data_refresh(reason="startup_server_authority_prune_v2348")
                log("STARTUP_SERVER_AUTH_REFRESH_V2348 reason=no_selected_sections_after_remote_reconcile removed=%d sections=%d token=%s" % (
                    purged_total_v2348, purged_sections_v2348, refresh_token_v2348
                ), xbmc.LOGINFO)
            if progress:
                progress_update(progress, 100, "Plex 라이브러리가 없습니다")
            return bool(purged_total_v2348 or purged_sections_v2348)

        changed = []
        for index, section in enumerate(sections, start=1):
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=check_sections index=%d caller=%s" % (index, caller or ""), xbmc.LOGINFO)
                return False
            if progress and progress.iscanceled():
                break
            section_id = str(section.get("section_id", ""))
            section_type = str(section.get("section_type", ""))
            pct = int(((index - 1) / float(max(1, total_sections))) * 30)
            progress_update(progress, pct, "라이브러리 상태 확인 중\n%s" % _display_text_for_kodi(section.get("title", "")))
            if notice_progress and not deferred_notice_progress:
                pkm_notice_set("PKM 업데이트", "라이브러리 확인 %d/%d" % (index, total_sections), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            membership_v2348 = {}
            membership_force_full_v2348 = False
            if caller == "service_startup":
                _prehome_reuse_v2349 = dict(_PREHOME_AUTHORITY_READY_V2349.get(section_id) or {})
                if _prehome_reuse_v2349.get("ok"):
                    membership_v2348 = _prehome_reuse_v2349
                    log("STARTUP_SERVER_MEMBERSHIP_REUSE_V2349 section=%s title=%s source=prehome_proof no_second_full_scan=1" % (
                        section_id, section.get("title", "")
                    ), xbmc.LOGINFO)
                else:
                    membership_v2348 = _startup_reconcile_section_membership_v2348(section) or {}
                membership_force_full_v2348 = bool(membership_v2348.get("force_full"))
                pruned_now_v2348 = membership_v2348.get("pruned") or {}
                for key_v2348 in ("total", "movie", "show", "episode"):
                    startup_purged_v2348[key_v2348] = int(startup_purged_v2348.get(key_v2348, 0) or 0) + int(pruned_now_v2348.get(key_v2348, 0) or 0)

            remote_updated_at = int(section.get("updated_at") or section.get("scanned_at") or 0)
            prev_meta = previous_section_meta.get(section_id) or {}
            state_meta = sync_state.get(section_id) or {}
            prev_remote_updated = int(state_meta.get("remote_updated_at") or prev_meta.get("scanned_at") or 0)
            tv_tag_index_missing = False
            latest_item_changed = False
            latest_item_reason = ""
            latest_remote_rows = []
            latest_local_rows = []
            if section_type == PLEX_TYPE_SHOW:
                try:
                    tv_tag_index_missing = local_tv_tag_index_missing_for_section(section_id)
                except Exception:
                    tv_tag_index_missing = False
            # Fast path for normal startup/polling: section updatedAt may stay
            # unchanged while Plex recently-added rows receive new items.  v482
            # verifies the newest keys for every section with a wider window and
            # still falls through to the lightweight count check before allowing
            # a skip.  This keeps side-menu navigation untouched while preventing
            # newly-added Plex items from being missed.
            if caller in ("service_startup", "service_poll") and remote_updated_at and prev_remote_updated == remote_updated_at and not tv_tag_index_missing and not membership_force_full_v2348:
                latest_item_changed, latest_remote_rows, latest_local_rows, latest_item_reason = verify_section_latest_for_fast_skip(section, limit=10)
                log("STARTUP_SYNC_FAST_SKIP_VERIFY section=%s title=%s caller=%s type=%s remote_updated=%s remote_latest=%s local_latest=%s changed=%s reason=%s scope=all_sections_v482 limit=10" % (
                    section_id, section.get("title", ""), caller or "", section_type or "", remote_updated_at,
                    ",".join(_latest_item_keys(latest_remote_rows)),
                    ",".join(_latest_item_keys(latest_local_rows)),
                    "1" if latest_item_changed else "0", latest_item_reason or "ok"
                ), xbmc.LOGINFO)
                if latest_item_changed:
                    log("STARTUP_SYNC_FAST_SKIP_BYPASS section=%s title=%s caller=%s reason=latest_item_changed remote_latest=%s local_latest=%s" % (
                        section_id, section.get("title", ""), caller or "",
                        ",".join(_latest_item_keys(latest_remote_rows)),
                        ",".join(_latest_item_keys(latest_local_rows))
                    ), xbmc.LOGINFO)
                else:
                    if caller == "service_startup":
                        # v993: keep the visible PKM update notice, but make the
                        # no-change startup path fast again.  When section updatedAt
                        # is unchanged and the newest Plex keys match local DB, startup
                        # should not run the extra remote count guard or TV art-cache
                        # repair pass.  Those maintenance checks caused long "no update"
                        # startup checks while the notice stayed on screen.
                        try:
                            known_total = int(
                                (membership_v2348.get("remote_total") if membership_v2348.get("ok") else 0)
                                or state_meta.get("remote_count")
                                or prev_meta.get("item_count")
                                or prev_meta.get("total")
                                or 0
                            )
                        except Exception:
                            known_total = 0
                        try:
                            update_sync_state(section_id, remote_updated_at, known_total, synced=False)
                            if membership_v2348.get("ok"):
                                update_section_count(section_id, known_total)
                        except Exception:
                            pass
                        log("STARTUP_SYNC_QUICK_SKIP section=%s title=%s caller=%s reason=latest_ok_no_count_guard_no_art_cache remote_updated=%s known_total=%s" % (
                            section_id, section.get("title", ""), caller or "", remote_updated_at, known_total
                        ), xbmc.LOGINFO)
                        if section_type == PLEX_TYPE_SHOW:
                            log("STARTUP_SYNC_TV_ART_CACHE_DEFER section=%s title=%s caller=%s reason=startup_quick_skip_latest_ok" % (
                                section_id, section.get("title", ""), caller or ""
                            ), xbmc.LOGINFO)
                        log("STARTUP_SYNC_CHECK section=%s title=%s type=%s local_movie=%s local_show=%s local_episode=%s remote_movie=%s remote_show=%s remote_episode=%s local_max_updated=%s remote_updated=%s changed=0 latest_changed=0 reason=quick_no_change" % (
                            section_id, section.get("title", ""), section_type,
                            "-", "-", "-", "-", "-", "-", "-", remote_updated_at
                        ), xbmc.LOGINFO)
                        continue
                    else:
                        log("STARTUP_SYNC_FAST_SKIP_COUNT_GUARD section=%s title=%s caller=%s remote_updated=%s latest_guard=ok action=verify_counts" % (
                            section_id, section.get("title", ""), caller or "", remote_updated_at
                        ), xbmc.LOGINFO)
            if tv_tag_index_missing:
                if caller in ("service_startup", "service_poll") and not membership_force_full_v2348:
                    # v472: do not backfill all missing TV actor/studio tags from
                    # the startup service.  v471 correctly moved these tags into
                    # plex_km.db, but first-run backfill scanned big TV sections
                    # while the user was moving the side menu and contended on the
                    # same DB.  Changed sections still index tags during normal
                    # fetch_section_items(); this only skips tag-only backfill.
                    update_sync_state(section_id, remote_updated_at, int(prev_meta.get("item_count") or state_meta.get("remote_count") or 0), synced=False)
                    log("STARTUP_SYNC_TV_TAG_INDEX_DEFER section=%s title=%s caller=%s reason=service_startup_no_tag_backfill" % (section_id, section.get("title", ""), caller or ""), xbmc.LOGINFO)
                    continue
                log("STARTUP_SYNC_TV_TAG_INDEX_MISSING section=%s title=%s caller=%s" % (section_id, section.get("title", ""), caller or ""), xbmc.LOGINFO)
            if membership_v2348.get("ok"):
                remote_counts = dict(membership_v2348.get("counts") or {})
                for key_v2348 in ("movie", "show", "episode", "total"):
                    remote_counts.setdefault(key_v2348, 0)
                log("STARTUP_SYNC_REMOTE_COUNT_REUSE_V2348 section=%s source=membership_inventory total=%d" % (
                    section_id, int(remote_counts.get("total", 0) or 0)
                ), xbmc.LOGINFO)
            else:
                try:
                    remote_counts = remote_section_counts(section)
                except Exception as exc:
                    log("STARTUP_SYNC_REMOTE_COUNT_FAILED section=%s title=%s error=%s" % (section_id, section.get("title"), exc), xbmc.LOGWARNING)
                    remote_counts = {"movie": 0, "show": 0, "episode": 0, "total": 0}
            try:
                local_counts = local_section_counts(section_id)
            except Exception:
                local_counts = {"movie": 0, "show": 0, "episode": 0, "total": 0, "max_synced_at": 0, "max_updated_at": 0}

            if section_type == PLEX_TYPE_MOVIE:
                count_changed = int(local_counts.get("movie", 0) or 0) != int(remote_counts.get("movie", 0) or 0)
            elif section_type == PLEX_TYPE_SHOW:
                count_changed = (
                    int(local_counts.get("show", 0) or 0) != int(remote_counts.get("show", 0) or 0)
                    or int(local_counts.get("episode", 0) or 0) != int(remote_counts.get("episode", 0) or 0)
                )
            else:
                count_changed = int(local_counts.get("total", 0) or 0) != int(remote_counts.get("total", 0) or 0)
            time_changed = bool(remote_updated_at and int(local_counts.get("max_updated_at", 0) or 0) < int(remote_updated_at))
            is_changed = bool(membership_force_full_v2348 or count_changed or time_changed or tv_tag_index_missing or latest_item_changed)
            remote_total_for_state = int(remote_counts.get("total") if remote_counts.get("total") is not None else local_counts.get("total", 0) or 0)
            update_section_count(section_id, remote_total_for_state)
            if is_changed:
                change_reason_v2348 = (
                    "membership" if membership_force_full_v2348 else
                    ("tv_tags" if tv_tag_index_missing else
                     ("latest_item" if latest_item_changed else
                      ("count" if count_changed else "updatedAt")))
                )
                changed.append((
                    section,
                    remote_counts,
                    local_counts,
                    change_reason_v2348,
                    list(latest_remote_rows or []),
                    list(latest_local_rows or []),
                    str(latest_item_reason or ""),
                ))
            else:
                update_sync_state(section_id, remote_updated_at, remote_total_for_state, synced=False)
                if section_type == PLEX_TYPE_SHOW:
                    repaired = _repair_tv_art_cache_integrity(
                        section_id,
                        section_title=section.get("title", ""),
                        fetch_remote=True,
                        reason="startup_no_change_%s" % (caller or "startup"),
                    )
                    if repaired:
                        startup_stats["show"] += 0
                        log("STARTUP_SYNC_TV_ART_CACHE_REPAIRED section=%s title=%s repaired=%d reason=no_change" % (
                            section_id, section.get("title", ""), repaired
                        ), xbmc.LOGINFO)
            log("STARTUP_SYNC_CHECK section=%s title=%s type=%s local_movie=%s local_show=%s local_episode=%s remote_movie=%s remote_show=%s remote_episode=%s local_max_updated=%s remote_updated=%s changed=%s latest_changed=%s reason=%s" % (
                section_id, section.get("title", ""), section_type,
                local_counts.get("movie", 0), local_counts.get("show", 0), local_counts.get("episode", 0),
                remote_counts.get("movie", 0), remote_counts.get("show", 0), remote_counts.get("episode", 0),
                local_counts.get("max_updated_at", 0), remote_updated_at, "1" if is_changed else "0",
                "1" if latest_item_changed else "0",
                "membership" if membership_force_full_v2348 else ("tv_tags" if tv_tag_index_missing else ("latest_item" if latest_item_changed else ("count" if count_changed else ("updatedAt" if time_changed else "no_change"))))
            ), xbmc.LOGINFO)

        if not changed:
            set_initial_sync_done(True)
            set_last_auto_sync_at()
            purged_total_v2348 = int(startup_purged_v2348.get("total", 0) or 0)
            purged_sections_v2348 = int(startup_purged_v2348.get("sections", 0) or 0)
            if purged_total_v2348 or purged_sections_v2348:
                refresh_token_v2348 = _signal_home_data_refresh(reason="startup_server_authority_prune_v2348")
                log("STARTUP_SERVER_AUTH_REFRESH_V2348 removed=%d movie=%d show=%d episode=%d sections=%d token=%s visible_cache_rebuild=1" % (
                    purged_total_v2348, int(startup_purged_v2348.get("movie", 0) or 0),
                    int(startup_purged_v2348.get("show", 0) or 0), int(startup_purged_v2348.get("episode", 0) or 0),
                    purged_sections_v2348, refresh_token_v2348
                ), xbmc.LOGINFO)
            if progress:
                progress_update(progress, 100, "캐시 확인 완료")
            if notice_progress and notice_token:
                pkm_notice_clear(notice_token)
            if notice_progress:
                _pkm_notice_clear_update(force=True)
                log("UPDATE_NOTIFY_SKIPPED stage=no_change reason=%s caller=%s" % (
                    "server_missing_items_pruned" if (purged_total_v2348 or purged_sections_v2348) else "no_actual_plex_change", caller or ""
                ), xbmc.LOGINFO)
            # v1645: Plex startup snapshot must never wait for Cine21 web/DB
            # maintenance. Existing ratings are read from the local DB while
            # missing ratings are collected only after the completed PKM scene
            # is revealed. The collected values become visible next Kodi start.
            log("CINE21_RUNTIME_WEB_DISABLED_V2377 caller=%s reason=no_plex_change source=ratings_master_only network=0" % (caller or ""), xbmc.LOGINFO)
            log("STARTUP_SYNC_VALID sections=%d" % total_sections, xbmc.LOGINFO)
            return True

        log("STARTUP_SYNC_REFRESH sections=%d" % len(changed), xbmc.LOGINFO)
        # v884: keep startup Plex sync silent unless the caller explicitly asked
        # for progress UI.  The Home window already has its own PKM notice stack;
        # adding a separate "PKM 업데이트 감지" notice here overlaps existing
        # notifications and was not requested.
        log("UPDATE_NOTIFY_SKIPPED stage=detected reason=silent_startup_sync sections=%d" % len(changed), xbmc.LOGINFO)
        if notice_progress and not deferred_notice_progress:
            if not notice_token:
                notice_token = pkm_notice_set("PKM 업데이트 중", "업데이트 대상 %d개 라이브러리" % len(changed), "잠시 후 홈 데이터가 갱신됩니다")
                visible_notice_started = True
            else:
                pkm_notice_set("PKM 업데이트 중", "업데이트 대상 %d개 라이브러리" % len(changed), "잠시 후 홈 데이터가 갱신됩니다", token=notice_token)
                visible_notice_started = True
        elif notice_progress and deferred_notice_progress:
            log("UPDATE_NOTIFY_DEFERRED stage=detected reason=wait_actual_changed_rows sections=%d caller=%s" % (len(changed), caller or ""), xbmc.LOGINFO)
        total_fetched = 0
        for index, changed_entry in enumerate(changed, start=1):
            section, remote_counts, local_counts, reason = changed_entry[:4]
            entry_latest_remote_rows = changed_entry[4] if len(changed_entry) > 4 else []
            entry_latest_local_rows = changed_entry[5] if len(changed_entry) > 5 else []
            entry_latest_detail_reason = changed_entry[6] if len(changed_entry) > 6 else ""
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=refresh_sections index=%d caller=%s" % (index, caller or ""), xbmc.LOGINFO)
                return False
            if progress and progress.iscanceled():
                break
            pct = 30 + int(((index - 1) / float(max(1, len(changed)))) * 70)
            progress_update(progress, pct, "메타데이터를 업데이트하고 있습니다\n%s" % _display_text_for_kodi(section.get("title", "")))
            if notice_progress and not deferred_notice_progress:
                pkm_notice_set("PKM 업데이트 중", "라이브러리 %d/%d 진행 중" % (index, len(changed)), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            before = local_section_counts(section["section_id"])
            if caller == "service_startup" and reason == "latest_item":
                fetched, total, elapsed, partial_stats = _startup_partial_sync_latest_items(
                    section,
                    latest_remote_rows=entry_latest_remote_rows,
                    latest_local_rows=entry_latest_local_rows,
                    caller=caller,
                    reason=reason,
                    limit=24,
                    detail_reason=entry_latest_detail_reason,
                )
                log("STARTUP_SYNC_PARTIAL_APPLIED section=%s title=%s reason=%s fetched=%d total=%s elapsed=%.1f mode=latest_only_no_force_all" % (
                    section.get("section_id", ""), section.get("title", ""), reason, fetched, total, elapsed
                ), xbmc.LOGINFO)
            else:
                partial_stats = None
                fetched, total, elapsed = fetch_section_items(section["section_id"], section["section_type"], progress=None, prune_missing=True, force_all=True)
                if section.get("section_type") == PLEX_TYPE_SHOW:
                    repaired = _repair_tv_art_cache_integrity(
                        section["section_id"],
                        section_title=section.get("title", ""),
                        fetch_remote=False,
                        reason="startup_after_sync_%s" % (caller or "startup"),
                    )
                    if repaired:
                        log("STARTUP_SYNC_TV_ART_CACHE_REPAIRED section=%s title=%s repaired=%d reason=after_sync" % (
                            section.get("section_id", ""), section.get("title", ""), repaired
                        ), xbmc.LOGINFO)
            if caller in ("service_startup", "service_poll") and _pkm_service_abort_requested():
                log("STARTUP_SYNC_ABORT reason=service_stopping stage=after_fetch section=%s caller=%s" % (section.get("section_id", ""), caller or ""), xbmc.LOGINFO)
                return False
            after = local_section_counts(section["section_id"])
            total_fetched += fetched
            changed_stats = partial_stats if partial_stats is not None else _last_fetch_section_stats()
            section_actual_changes = 0
            for key in ("movie", "show", "episode"):
                changed_count = int(changed_stats.get(key, 0) or 0)
                if changed_count <= 0:
                    changed_count = max(0, int(after.get(key, 0) or 0) - int(before.get(key, 0) or 0))
                if changed_count > 0:
                    section_actual_changes += changed_count
                startup_stats[key] += changed_count
            if notice_progress and deferred_notice_progress and section_actual_changes > 0:
                visible_text = _format_startup_sync_notice(startup_stats)
                if not notice_token:
                    notice_token = pkm_notice_set("PKM 업데이트 중", visible_text or ("라이브러리 %d/%d 진행 중" % (index, len(changed))), _display_text_for_kodi(section.get("title", "")))
                    visible_notice_started = True
                    log("UPDATE_NOTIFY_STARTED stage=actual_changed_rows section=%s changed=%d text=%s" % (section.get("section_id", ""), section_actual_changes, visible_text or ""), xbmc.LOGINFO)
                elif visible_notice_started:
                    pkm_notice_set("PKM 업데이트 중", visible_text or ("라이브러리 %d/%d 진행 중" % (index, len(changed))), _display_text_for_kodi(section.get("title", "")), token=notice_token)
            update_sync_state(section["section_id"], int(section.get("updated_at") or section.get("scanned_at") or 0), int(total or after.get("total", 0) or 0), synced=False if (caller == "service_startup" and reason == "latest_item") else True)
            log("STARTUP_SYNC_SECTION_DONE section=%s title=%s reason=%s fetched=%d total=%s elapsed=%.1f before=%s after=%s" % (
                section["section_id"], section.get("title", ""), reason, fetched, total, elapsed, before, after
            ), xbmc.LOGINFO)

        if progress:
            progress_update(progress, 100, "메타데이터 캐시 완료\n%d개 항목 확인" % total_fetched)
        set_initial_sync_done(True)
        set_last_auto_sync_at()
        state = load_state()
        state["startup_cache_completed_at"] = int(time.time())
        save_state(state)
        # v1554: widget invalidation is a correctness requirement, not a notice
        # side effect.  Signal after every committed changed-section sync even
        # when no visible notice is requested or changed-row statistics are zero.
        refresh_token_v1554 = _signal_home_data_refresh(reason="incremental_sync_committed_v1554")
        log("SYNC_WIDGET_REFRESH_SIGNAL_V1554 scope=incremental sections=%d fetched=%d token=%s movie=%d show=%d episode=%d" % (
            len(changed), total_fetched, refresh_token_v1554,
            startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)
        ), xbmc.LOGINFO)
        notice = _format_startup_sync_notice(startup_stats)
        if not notice and notice_progress:
            if notice_token:
                pkm_notice_clear(notice_token)
            _pkm_notice_clear_update(force=True)
            log("UPDATE_NOTIFY_SKIPPED stage=completed reason=no_actual_changed_rows caller=%s fetched=%d" % (caller or "", total_fetched), xbmc.LOGINFO)
        if notice and notice_progress:
            try:
                pkm_notice_set("PKM 업데이트 중", notice, "홈 위젯 갱신 중", token=notice_token)
                refresh_token = refresh_token_v1554
                applied = _wait_home_data_refresh_applied(refresh_token, timeout_ms=6500) if refresh_token else False
                if applied:
                    pkm_notice_set("PKM 업데이트 완료", notice, "홈 위젯 업데이트 완료", token=notice_token)
                    _pkm_notice_clear_later(notice_token, ms=1800)
                    log("UPDATE_NOTIFY_SHOWN stage=completed_visible_widgets movie=%d show=%d episode=%d text=%s refresh_token=%s auto_clear_ms=1800" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0), notice, refresh_token), xbmc.LOGINFO)
                else:
                    pkm_notice_set("새 콘텐츠 추가", notice, "라이브러리 싱크 완료", token=notice_token)
                    _pkm_notice_clear_later(notice_token, ms=3500)
                    log("UPDATE_NOTIFY_SHOWN stage=completed_new_content movie=%d show=%d episode=%d text=%s refresh_token=%s home_refresh_applied=0 auto_clear_ms=3500" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0), notice, refresh_token), xbmc.LOGINFO)
            except Exception as exc:
                log("UPDATE_NOTIFY_FAILED stage=completed_visible_widgets error=%s" % exc, xbmc.LOGWARNING)
                try:
                    pkm_notice_clear(notice_token)
                except Exception:
                    pass
        elif notice_progress and notice_token:
            pkm_notice_clear(notice_token)
        else:
            log("UPDATE_NOTIFY_SKIPPED stage=completed_added reason=silent_startup_sync movie=%d show=%d episode=%d" % (startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)), xbmc.LOGINFO)
        # v2377: runtime Cine21 web collection was removed. Plex sync owns only
        # Plex freshness; ratings are rematched locally against the service-managed
        # Cine21 Master DB by pkm_ratings_service_bridge.
        log("CINE21_RUNTIME_WEB_DISABLED_V2377 caller=%s reason=plex_sync_complete source=ratings_master_only network=0" % (caller or ""), xbmc.LOGINFO)
        log("STARTUP_SYNC_END sections=%d fetched=%d movie=%d show=%d episode=%d" % (len(changed), total_fetched, startup_stats.get("movie", 0), startup_stats.get("show", 0), startup_stats.get("episode", 0)), xbmc.LOGINFO)
        return True
    finally:
        if progress:
            try:
                log("STARTUP_SYNC_PROGRESS_CLOSE_BEGIN_V1747 caller=%s vis13032=%d" % (
                    caller or "", 1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0
                ), xbmc.LOGINFO)
            except Exception:
                pass
            try:
                xbmc.sleep(300)
            except Exception:
                pass
            progress.close()
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            try:
                log("STARTUP_SYNC_PROGRESS_CLOSE_REQUESTED_V1747 caller=%s" % (caller or ""), xbmc.LOGINFO)
            except Exception:
                pass
        release_sync_lock()

def auto_sync_due(env=None):
    _bind_env(env)
    if not setting_bool("auto_sync_on_start", True):
        return False
    if not clean_server_url() or not plex_token():
        return False
    interval_min = setting_int("auto_sync_interval_minutes", 60, min_value=0, max_value=10080)
    last = last_auto_sync_at()
    if last <= 0:
        return True
    if interval_min <= 0:
        return True
    return (time.time() - last) >= (interval_min * 60)

def maybe_trigger_background_auto_sync(caller="library", env=None):

    audit_event(None, "sync_maybe_trigger_background_auto_sync_enter")
    _bind_env(env)
    """Disabled: startup cache check/sync owns all PMS updates."""
    return False
