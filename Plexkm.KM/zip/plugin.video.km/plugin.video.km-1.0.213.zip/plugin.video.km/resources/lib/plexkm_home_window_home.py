# -*- coding: utf-8 -*-
"""PKM home window part (R73): 홈 위젯 줄/이어보기/오버레이.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartHomeR73
    def _full_reset_purge_live_home_v2151(self, token=""):
        """Erase the already-instantiated Home surface without DB/network access."""
        win = xbmcgui.Window(10000)
        try:
            # Authoritative data state first: no selected libraries or scenes exist.
            self.sections = []
            self.active_section_id = "__home__"
            self.active_menu_index = 0
            self.wall_offset = 0
            self.wall_total = 0
            self.wall_loading = False
            self.wall_items = []
            self._last_rendered_section_id = ""
            self._home_rows_cache = []
            self._home_wall_ready = False
            self._home_row_items_cache = []
            self._home_row_memory = {}
            self._home_visible_row_controls = []
            self._section_rows_cache = {}
            self._section_total_cache = {}
            self._section_scene_cache_v1620 = {}
            self._library_first12_scene_cache_v1868 = {}
            self._section_visited_keys_v1635 = set()
            self._section_full_rows_ready_v1644 = set()
            self._section_index_cache = {}
            self._section_last_tab_by_sid = {}
            self._section_last_library_state_by_sid_v2471 = {}
            self._section_tab_state_loaded_v2471 = True
            try:
                _tab_state_path_v2471 = self._derived_cache_path_v2467("section_tab_state_v2471.json")
                if _tab_state_path_v2471 and os.path.exists(_tab_state_path_v2471):
                    os.remove(_tab_state_path_v2471)
            except Exception:
                pass
            self._tv_show_key_cache = {}
            self._tv_actor_name_pool_cache = {}
            self._tv_studio_name_pool_cache = {}
            self._tv_actor_show_key_cache = {}
            self._tv_studio_show_key_cache = {}
            self._tv_group_section_ids_cache = {}
            self._home_meta_enrich_cache = {}
            self._home_meta_hint_cache = {}
            self._home_bg_color_cache = {}
            try:
                self._info_cast_prewarm_cache = {}
                self._info_cast_prewarm_negative_v1340 = {}
                self._info_cast_prewarm_running = set()
            except Exception:
                pass

            # Process-wide Home-only caches must also forget the old Plex state.
            try:
                with _HOME_WATCHA_SHARED_CACHE_V1642["lock"]:
                    _HOME_WATCHA_SHARED_CACHE_V1642["db_path"] = ""
                    _HOME_WATCHA_SHARED_CACHE_V1642["db_mtime"] = None
                    _HOME_WATCHA_SHARED_CACHE_V1642["cache"] = None
                    _HOME_WATCHA_SHARED_CACHE_V1642["loaded_at"] = 0.0
            except Exception:
                pass

            # Clear all visible ListItems.  These operations are local WindowXML
            # mutations only and cannot recreate the deleted addon profile.
            self._home_reset_row_controls()
            try:
                self.getControl(WALL_ID).reset()
            except Exception:
                pass
            try:
                self._section_reset_recommend_row_controls()  # R36: _clear_section_lists() never existed
            except Exception:
                pass
            try:
                self._section_reset_recommend_row_controls()
            except Exception:
                pass
            try:
                self._section_placeholder_clear_v1305(reason="full_reset_v2151")
            except Exception:
                pass

            # No smooth-fanart/tint helper here: reset must not spawn another
            # background thread after the worker barrier has completed.
            for prop in (
                "PlexKM.Home.Fanart", "PlexKM.Home.DisplayFanart", "PlexKM.Home.DisplayFanartRaw",
                "PlexKM.Window.Title", "PlexKM.Window.SubTitle", "PlexKM.Window.Meta",
                "PlexKM.Window.Summary", "PlexKM.Window.Genre", "PlexKM.Window.CountLabel",
                "PlexKM.Window.IsSectionRecommend", "PlexKM.Window.IsSectionWall",
                "PlexKM.Home.SessionCacheRestoredV1632", "PlexKM.PlexUpdate.Dirty",
                "PlexKM.PlexUpdate.Sections", "PlexKM.Home.SyncRefreshPendingV1554",
                "PlexKM.Home.DataRefreshToken", "PlexKM.Home.DataRefreshReason",
            ):
                try:
                    self.clearProperty(prop)
                except Exception:
                    pass
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            try:
                for key in (
                    "Title", "SubTitle", "Meta", "Summary", "Genre", "Director", "Year",
                    "Duration", "DurationText", "ContentRating", "Rating", "RatingKey", "Type",
                    "EpisodeTitle", "ShowTitle", "Season", "Episode", "RemainingText", "RemainingIcon",
                    "Poster", "Thumb", "Cine21CriticRating", "Cine21AudienceRating", "Cine21BarDisplay",
                    "WatchaRating", "WatchaCount", "WatchaDisplay", "WatchaBarDisplay", "IMDbRating",
                    "RatingBarDisplay", "AddedAt", "SectionId", "PlayUrl", "ShowUrl", "Art",
                    "EpisodeMeta", "SeasonEpisode", "Resolution", "Studio",
                ):
                    for prefix in ("PlexKM.Home.", "PlexKM.Window."):
                        try:
                            self.clearProperty(prefix + key)
                        except Exception:
                            pass
                        try:
                            win.clearProperty(prefix + key)
                        except Exception:
                            pass
            except Exception:
                pass
            self._home_fanart_current = ""
            self._home_bg_current_fanart = ""
            self._home_bg_target_fanart_v2314 = ""
            self._home_bg_target_since_ms_v2314 = 0
            self._home_bg_display_color = self._home_bg_default
            try:
                self._apply_home_dynamic_bg_props(self._home_bg_default[-6:], "full_reset_v2151_direct")
            except Exception:
                pass
            try:
                self.getControl(TITLE_ID).setLabel("")
            except Exception:
                pass
            try:
                self._set_header("", "")
            except Exception:
                pass

            # Rebuild only the local three-row unconfigured menu (Home / PKM
            # settings / Kodi settings); sections=[] guarantees no DB count query.
            self._set_empty_home_settings_state(required=True, reason="full_reset_v2151")
            self.setProperty("PlexKM.Window.IsHome", "1")
            win.setProperty("PlexKM.Window.IsHome", "1")
            self.setProperty("PlexKM.Home.StartupReadyV1619", "1")
            win.setProperty("PlexKM.Home.StartupReadyV1619", "1")
            try:
                self._build_menu()
                self.getControl(MENU_ID).selectItem(0)
                self._sync_collapsed_menu_selection()
                self._last_menu_pos = 0
            except Exception:
                _log("PKM_FULL_RESET_HOME_MENU_REBUILD_FAILED_V2151 token=%s err=%s" % (
                    token or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

            # Reset-related properties are deliberately kept latched; they block
            # every normal background entry until the Kodi process restarts.
            win.setProperty("PlexKM.Home.FullResetMemoryPurgedV2151", str(token or ""))
            _log("PKM_FULL_RESET_HOME_MEMORY_PURGE_V2151 token=%s sections=0 rows=0 wall=0 fanart=0 meta=0 menu_libraries=0 settings_required=1 ok=1" % (token or ""))
            return True
        except Exception:
            try:
                win.clearProperty("PlexKM.Home.FullResetMemoryPurgedV2151")
            except Exception:
                pass
            _log("PKM_FULL_RESET_HOME_MEMORY_PURGE_FAILED_V2151 token=%s err=%s" % (
                token or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _initial_compose_r57_posters(self, ready, total):
        if not bool(getattr(self, "_initial_compose_r57_active", False)):
            return
        try:
            ready = int(ready or 0)
            total = int(total or 0)
        except Exception:
            return
        if total <= 0:
            return
        ready = max(0, min(ready, total))
        self._initial_compose_r57_progress("포스터 준비 %d / %d" % (ready, total), 40 + int(ready * 60 / total))

    def _poster_primary_local_paths_v2498(self, candidates):
        """Resolve ordered poster-only sources to exact Textures13/local files.

        Each source retains its identity and rank.  A fallback/fanart URL is never
        merged with the primary poster set, and every local result must be portrait.
        """
        source_sets = [list(x or []) for x in list(candidates or [])]
        if not source_sets:
            return []
        resolved = [""] * len(source_sets)
        remote_values = []
        remote_seen = set()
        for idx, values in enumerate(source_sets):
            for value in values:
                value = str(value or "").strip()
                if not value:
                    continue
                lower = value.lower()
                if lower.startswith(("http://", "https://")):
                    if value not in remote_seen:
                        remote_seen.add(value)
                        remote_values.append(value)
                    continue
                try:
                    translated = xbmcvfs.translatePath(value) if lower.startswith("special://") else value
                except Exception:
                    translated = value
                if translated and self._local_portrait_poster_file_ready_v2498(translated):
                    resolved[idx] = translated
                    break

        cached_by_url = {}
        if remote_values:
            try:
                db_path = xbmcvfs.translatePath("special://database/Textures13.db")
            except Exception:
                db_path = ""
            if db_path and os.path.exists(db_path):
                try:
                    conn = _pkm_ro_connect(db_path, timeout=0.20)
                    try:
                        step = 80
                        for start in range(0, len(remote_values), step):
                            chunk = remote_values[start:start + step]
                            marks = ",".join("?" for _ in chunk)
                            query = "SELECT url,cachedurl FROM texture WHERE url IN (%s)" % marks
                            for url, cachedurl in conn.execute(query, tuple(chunk)).fetchall():
                                url = str(url or "").strip()
                                cachedurl = str(cachedurl or "").strip()
                                if not url or not cachedurl:
                                    continue
                                try:
                                    thumb_path = xbmcvfs.translatePath("special://thumbnails/" + cachedurl.replace("\\", "/"))
                                except Exception:
                                    thumb_path = ""
                                if thumb_path and self._local_portrait_poster_file_ready_v2498(thumb_path):
                                    cached_by_url[url] = thumb_path
                    finally:
                        conn.close()
                except Exception:
                    pass

        for idx, values in enumerate(source_sets):
            if resolved[idx]:
                continue
            # Exact source order is authoritative; SQL row order is irrelevant.
            for value in values:
                value = str(value or "").strip()
                local = cached_by_url.get(value) or ""
                if local:
                    resolved[idx] = local
                    break
        return resolved

    def _set_empty_home_settings_state(self, required=False, reason=""):
        try:
            value = "1" if required else ""
            if required:
                self.setProperty("PlexKM.Home.SettingsRequired", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.Home.SettingsRequired", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.StartupSettingsIncomplete", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.Startup.InitialSurfaceV2558", "1")
                try:
                    # v2562: only a genuinely incomplete first-install may own
                    # this surface. Credential loss/server switching after setup
                    # must not resurrect it.
                    home_v1736 = xbmcgui.Window(10000)
                    if (not self._pkm_initial_setup_completed_v2562()) and home_v1736.getProperty("PlexKM.InitialSetupSyncActiveV1736") != "1":
                        home_v1736.clearProperty("PlexKM.InitialSetupReadyV1736")
                except Exception:
                    pass
            else:
                self.clearProperty("PlexKM.Home.SettingsRequired")
                xbmcgui.Window(10000).clearProperty("PlexKM.Home.SettingsRequired")
                xbmcgui.Window(10000).clearProperty("PlexKM.StartupSettingsIncomplete")
                xbmcgui.Window(10000).clearProperty("PlexKM.Startup.InitialSurfaceV2558")
            _log("EMPTY_HOME_SETTINGS_STATE required=%s reason=%s" % ("1" if required else "0", reason or ""))
        except Exception:
            pass



    def _home_has_visible_or_cached_rows_v1477(self):
        """v1477: True when Home already has real rows to show.

        The full-screen Home offline surface must not appear for short startup
        hiccups that recover into widgets.  Keep the central surface gated by
        this helper while the top-right sticky notice remains immediate.
        """
        try:
            if self._home_rendered_xml_rows_ready():
                return True
        except Exception:
            pass
        try:
            if self._home_rows_cache:
                return True
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Home.InitialWidgetsReady") == "1" or self.getProperty("PlexKM.Home.InitialWidgetsReady") == "1":
                return True
        except Exception:
            pass
        return False

    def _set_home_plex_offline_confirmed_v1477(self, confirmed, reason="", line1="", line2=""):
        """v1477: separate Home full-screen offline surface from global offline.

        Global PlexOffline is still used immediately for the top-right notice and
        background throttling, but the Home center message is shown only after the
        Home content path also proves that no widgets/cache can be displayed.
        """
        try:
            win = xbmcgui.Window(10000)
            if confirmed:
                if self._home_has_visible_or_cached_rows_v1477():
                    return False
                l1 = str(line1 or win.getProperty("PlexKM.PlexOfflineLine1") or "Plex 서버 응답 없음")
                l2 = str(line2 or win.getProperty("PlexKM.PlexOfflineLine2") or "서버 상태와 네트워크를 확인해주세요")
                for w in (self, win):
                    try:
                        w.setProperty("PlexKM.Home.PlexOfflineConfirmed", "1")
                        w.setProperty("PlexKM.Home.PlexOfflineConfirmedReason", str(reason or "offline_confirmed"))
                        w.setProperty("PlexKM.Home.PlexOfflineConfirmedLine1", l1)
                        w.setProperty("PlexKM.Home.PlexOfflineConfirmedLine2", l2)
                        w.setProperty("PlexKM.Home.PlexOfflineConfirmedAt", str(int(time.time() * 1000)))
                    except Exception:
                        pass
                _log("HOME_PLEX_OFFLINE_CONFIRMED_SET_V1477 reason=%s line1=%s" % (reason or "", l1), xbmc.LOGWARNING)
                return True
            for w in (self, win):
                try:
                    for key in ("PlexKM.Home.PlexOfflineConfirmed", "PlexKM.Home.PlexOfflineConfirmedReason", "PlexKM.Home.PlexOfflineConfirmedLine1", "PlexKM.Home.PlexOfflineConfirmedLine2", "PlexKM.Home.PlexOfflineConfirmedAt"):
                        w.clearProperty(key)
                except Exception:
                    pass
            _log("HOME_PLEX_OFFLINE_CONFIRMED_CLEAR_V1477 reason=%s" % (reason or ""))
            return True
        except Exception:
            try:
                _log("HOME_PLEX_OFFLINE_CONFIRMED_FAILED_V1477 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _start_home_plex_pending_confirm_guard_v1477(self, reason=""):
        """v1477: delayed guard for the center offline surface.

        Do not show 'Plex 서버 응답 없음' in the Home content area from the first
        /identity timeout.  Wait long enough for Home rows/cache to recover.  If
        Plex is still marked offline and Home still has no visible/cached rows,
        then show the center offline surface.
        """
        try:
            token = str(int(time.time() * 1000))
            win = xbmcgui.Window(10000)
            for w in (self, win):
                try:
                    w.setProperty("PlexKM.Home.PlexPendingGuardToken", token)
                except Exception:
                    pass
            def _guard():
                try:
                    monitor = xbmc.Monitor()
                    # Give the normal Home data path enough time to either build
                    # rows or timeout on the main /library/onDeck request.
                    for delay_ms in (2500, 6500):
                        if monitor.abortRequested():
                            return
                        xbmc.sleep(delay_ms)
                    try:
                        if win.getProperty("PlexKM.Home.PlexPendingGuardToken") != token:
                            return
                    except Exception:
                        pass
                    try:
                        if not win.getProperty("PlexKM.HomeWindowActive"):
                            return
                    except Exception:
                        pass
                    if self._home_has_visible_or_cached_rows_v1477():
                        self._set_home_plex_offline_confirmed_v1477(False, reason="pending_guard_rows_ready")
                        return
                    if win.getProperty("PlexKM.PlexOffline") == "1":
                        self._set_home_plex_offline_confirmed_v1477(True, reason="pending_guard_timeout_no_rows")
                except Exception:
                    try:
                        _log("HOME_PLEX_PENDING_GUARD_FAILED_V1477 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                    except Exception:
                        pass
            _PKMHomeThreadV2151(target=_guard, name="PlexKMHomePlexPendingGuardV1477", daemon=True).start()
            return True
        except Exception:
            return False

    def _clear_home_loading_notice_v1565(self, reason=""):
        """Clear only the delayed Home-loading notice created by v1565.

        The token guard is important: if Plex becomes truly unavailable, the
        normal sticky ``Plex 연결 실패`` notice replaces this loading notice.
        A later Home-row callback must never clear that newer failure notice.
        """
        try:
            win = xbmcgui.Window(10000)
            token = str(win.getProperty("PlexKM.Home.LoadingNoticeTokenV1565") or self.getProperty("PlexKM.Home.LoadingNoticeTokenV1565") or "")
            visible = bool(win.getProperty("PlexKM.Home.LoadingNoticeVisibleV1565") == "1" or self.getProperty("PlexKM.Home.LoadingNoticeVisibleV1565") == "1")
            for w in (self, win):
                try:
                    for key in (
                        "PlexKM.Home.LoadingNoticeGuardTokenV1565",
                        "PlexKM.Home.LoadingNoticeTokenV1565",
                        "PlexKM.Home.LoadingNoticeVisibleV1565",
                    ):
                        w.clearProperty(key)
                except Exception:
                    pass
            cleared = False
            if token:
                # This notice is sticky only so it remains visible for the whole
                # blank interval.  Force applies only when the exact token still
                # owns the active notice; token mismatch protects a newer alarm.
                cleared = bool(pkm_notify.pkm_notice_clear(expected_token=token, force=True))
            elif visible:
                cleared = bool(pkm_notify.pkm_notice_clear_if_title(["Plex 홈 준비 중"], force=True))
            _log("HOME_DELAYED_LOADING_NOTICE_CLEAR_V1565 reason=%s token=%s visible=%s cleared=%s" % (
                reason or "", token or "", "1" if visible else "0", "1" if cleared else "0"
            ))
            return cleared
        except Exception:
            try:
                _log("HOME_DELAYED_LOADING_NOTICE_CLEAR_FAILED_V1565 reason=%s err=%s" % (
                    reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _start_home_loading_notice_guard_v1565(self, reason=""):
        """Show a top-right loading notice only when Home stays truly blank.

        Fast/normal Home builds finish before the 2.5 second guard and never
        display anything.  When no visible or cached rows exist after the delay,
        the user sees that PKM is waiting for Plex metadata.  The existing Plex
        offline path remains authoritative and may replace this status notice at
        any time with the original connection-failure alarm.
        """
        try:
            win = xbmcgui.Window(10000)
            guard_token = "v1565-%d" % int(time.time() * 1000)
            # Invalidate an earlier pending guard and retire only our own old
            # notice before starting a fresh blank-Home observation.
            self._clear_home_loading_notice_v1565(reason="restart:%s" % (reason or "home_pending"))
            for w in (self, win):
                try:
                    w.setProperty("PlexKM.Home.LoadingNoticeGuardTokenV1565", guard_token)
                except Exception:
                    pass

            def _guard():
                try:
                    monitor = xbmc.Monitor()
                    xbmc.sleep(2500)
                    if monitor.abortRequested():
                        return
                    if win.getProperty("PlexKM.Home.LoadingNoticeGuardTokenV1565") != guard_token:
                        return
                    if win.getProperty("PlexKM.HomeWindowActive") != "1":
                        return
                    # At cold startup IsHome may not be published yet because
                    # the first Home header is committed after row construction.
                    # active_section_id is already switched before this guard starts.
                    if str(getattr(self, "active_section_id", "") or "") != "__home__" and win.getProperty("PlexKM.Window.IsHome") != "1":
                        return
                    if win.getProperty("PlexKM.Info.InlineActive") == "1":
                        return
                    if win.getProperty("PlexKM.Home.PlexPending") != "1":
                        return
                    if win.getProperty("PlexKM.PlexOffline") == "1":
                        _log("HOME_DELAYED_LOADING_NOTICE_SKIP_V1565 reason=plex_offline guard=%s" % guard_token)
                        return
                    if win.getProperty("PlexKM.Home.SettingsRequired") == "1" or win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
                        return
                    if _pkm_playback_active_v1411() or pkm_notify.pkm_player_has_video():
                        return
                    if self._home_has_visible_or_cached_rows_v1477():
                        _log("HOME_DELAYED_LOADING_NOTICE_SKIP_V1565 reason=rows_ready guard=%s" % guard_token)
                        return

                    notice_token = str(pkm_notify.pkm_notice_set(
                        "Plex 홈 준비 중",
                        "홈 위젯을 불러오는 중",
                        "메타데이터 응답을 기다립니다",
                        sticky=True,
                        force_replace=False,
                    ) or "")
                    # Store ownership only when this exact notice actually became
                    # active.  A pre-existing or concurrently raised Plex failure
                    # alarm must remain untouched.
                    active_token = str(win.getProperty("PlexKM.Notify.Token") or "")
                    active_title = str(win.getProperty("PlexKM.Notify.Title") or "")
                    if notice_token and active_token == notice_token and active_title.startswith("Plex 홈 준비 중"):
                        for w in (self, win):
                            try:
                                w.setProperty("PlexKM.Home.LoadingNoticeTokenV1565", notice_token)
                                w.setProperty("PlexKM.Home.LoadingNoticeVisibleV1565", "1")
                            except Exception:
                                pass
                        _log("HOME_DELAYED_LOADING_NOTICE_SHOW_V1565 reason=%s delay_ms=2500 token=%s rows=0" % (
                            reason or "", notice_token
                        ), xbmc.LOGWARNING)
                    else:
                        _log("HOME_DELAYED_LOADING_NOTICE_NOT_OWNER_V1565 reason=%s requested=%s active=%s title=%s" % (
                            reason or "", notice_token, active_token, active_title
                        ))
                except Exception:
                    try:
                        _log("HOME_DELAYED_LOADING_NOTICE_GUARD_FAILED_V1565 reason=%s err=%s" % (
                            reason or "", traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_guard, name="PlexKMHomeLoadingNoticeV1565", daemon=True).start()
            return True
        except Exception:
            try:
                _log("HOME_DELAYED_LOADING_NOTICE_START_FAILED_V1565 reason=%s err=%s" % (
                    reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _set_home_plex_pending_v1476(self, pending, reason="", line1="", line2=""):
        """v1477 adjusted: track pending but do not immediately paint a center
        Home surface.  The immediate user-visible feedback is the top-right
        sticky notice; the center Home offline surface is delayed until confirmed.
        """
        try:
            win = xbmcgui.Window(10000)
            if pending:
                l1 = str(line1 or "Plex 서버 연결 확인 중")
                l2 = str(line2 or "응답을 기다리는 중입니다")
                for w in (self, win):
                    try:
                        w.setProperty("PlexKM.Home.PlexPending", "1")
                        w.clearProperty("PlexKM.Home.PlexPendingSurface")
                        w.setProperty("PlexKM.Home.PlexPendingReason", str(reason or "home_pending"))
                        w.setProperty("PlexKM.Home.PlexPendingLine1", l1)
                        w.setProperty("PlexKM.Home.PlexPendingLine2", l2)
                        w.setProperty("PlexKM.Home.PlexPendingAt", str(int(time.time() * 1000)))
                    except Exception:
                        pass
                self._start_home_plex_pending_confirm_guard_v1477(reason=reason or "home_pending")
                self._start_home_loading_notice_guard_v1565(reason=reason or "home_pending")
                _log("HOME_PLEX_PENDING_TRACK_V1477 reason=%s center_surface=0 delayed_topright_v1565=1 line1=%s" % (reason or "", l1))
            else:
                self._clear_home_loading_notice_v1565(reason="pending_clear:%s" % (reason or ""))
                for w in (self, win):
                    try:
                        for key in ("PlexKM.Home.PlexPending", "PlexKM.Home.PlexPendingSurface", "PlexKM.Home.PlexPendingReason", "PlexKM.Home.PlexPendingLine1", "PlexKM.Home.PlexPendingLine2", "PlexKM.Home.PlexPendingAt", "PlexKM.Home.PlexPendingGuardToken"):
                            w.clearProperty(key)
                    except Exception:
                        pass
                self._set_home_plex_offline_confirmed_v1477(False, reason="pending_clear:%s" % (reason or ""))
                _log("HOME_PLEX_PENDING_CLEAR_V1477 reason=%s" % (reason or ""))
            return True
        except Exception:
            try:
                _log("HOME_PLEX_PENDING_SET_FAILED_V1477 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _maybe_show_home_plex_pending_v1476(self, reason=""):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.PlexOffline") == "1":
                return False
            if self.getProperty("PlexKM.Home.SettingsRequired") == "1" or win.getProperty("PlexKM.Home.SettingsRequired") == "1":
                return False
            if self.getProperty("PlexKM.Home.ServerSwitchPending") == "1" or win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
                return False
            if not getattr(self, "sections", None):
                return False
            if self._home_has_visible_or_cached_rows_v1477():
                return False
            return self._set_home_plex_pending_v1476(True, reason=reason or "home_no_cache_before_plex_query")
        except Exception:
            return False

    def _open_empty_home_pkm_settings(self):
        """Open the PKM settings flow from the empty first-run Home surface."""
        try:
            _log("EMPTY_HOME_SETTINGS_OPEN action=pkm_settings")
            xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.km/default.py,action=pkm_settings)")
        except Exception:
            _log("EMPTY_HOME_SETTINGS_OPEN_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return

        def _watch_settings_close():
            try:
                saw_modal = False
                monitor = xbmc.Monitor()
                for _ in range(900):
                    # v2166: this thread is only a passive first-run UI watcher.
                    # It owns no DB/network work and must never hold the destructive
                    # reset barrier open.  Use the shared reset Event as the wait
                    # primitive so a reset wakes this watcher immediately instead
                    # of leaving it asleep for the remainder of the settings modal.
                    if _PKM_HOME_FULL_RESET_STOP_V2151.is_set():
                        _log("PKM_FULL_RESET_PASSIVE_WATCH_STOP_V2166 name=PlexKMEmptyHomeSettingsWatchV1270 reason=full_reset")
                        return
                    if monitor.abortRequested():
                        return
                    try:
                        active = bool(xbmc.getCondVisibility("System.HasModalDialog") or xbmc.getCondVisibility("Window.IsActive(addonsettings)"))
                    except Exception:
                        active = False
                    if active:
                        saw_modal = True
                    elif saw_modal:
                        break
                    if _PKM_HOME_FULL_RESET_STOP_V2151.wait(0.150):
                        _log("PKM_FULL_RESET_PASSIVE_WATCH_STOP_V2166 name=PlexKMEmptyHomeSettingsWatchV1270 reason=full_reset_wait_wakeup")
                        return
                if self._pkm_initial_setup_completed_v2562():
                    self._set_empty_home_settings_state(False, reason="settings_closed_initial_setup_complete_v2562")
                    try:
                        self._load_sections(refresh=True)
                    except Exception:
                        pass
                    try:
                        self._build_menu()
                    except Exception:
                        pass
                    try:
                        self._home_reset_row_controls()
                    except Exception:
                        pass
                    try:
                        self._force_home_menu_focus("settings_complete_refresh_home", select_home=True)
                        self._refresh_for_menu_focus(force=True)
                    except Exception:
                        _log("EMPTY_HOME_SETTINGS_REFRESH_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                else:
                    self._set_empty_home_settings_state(True, reason="settings_closed_first_install_still_incomplete_v2562")
                    self._focus_pkm_settings_menu_item(reason="settings_closed_still_incomplete")
                    try:
                        home = xbmcgui.Window(10000)
                        requested = home.getProperty("PlexKM.Home.RestoreSettingsFocusAfterDialog") == "1"
                        restore_reason = home.getProperty("PlexKM.Home.RestoreSettingsFocusReason") or "settings_closed_still_incomplete"
                        home.clearProperty("PlexKM.Home.RestoreSettingsFocusAfterDialog")
                        home.clearProperty("PlexKM.Home.RestoreSettingsFocusReason")
                    except Exception:
                        requested = False
                        restore_reason = "settings_closed_still_incomplete"
                    if requested:
                        for delay in (120, 320, 650):
                            xbmc.sleep(delay)
                            if self._focus_pkm_settings_menu_item(reason="%s_retry_%s" % (restore_reason, delay)):
                                if self._safe_focus_id() == MENU_ID:
                                    break
            except Exception:
                _log("EMPTY_HOME_SETTINGS_WATCH_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        try:
            t = _PKMHomeThreadV2151(target=_watch_settings_close, name="PlexKMEmptyHomeSettingsWatchV1270", daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            pass

    def _start_widget_stack_transition(self, reason=""):
        """v881: common smooth reveal for Home/section recommendation widget stacks."""
        try:
            self._widget_transition_token += 1
            token = self._widget_transition_token
            self._widget_transition_active = True
            # v987: side-menu movement must not use a black/blank cover.
            # Keep the transition token for sequencing/logging, but do not set
            # PlexKM.WidgetTransitionHold=1 because XML would hide the content stack.
            self.clearProperty("PlexKM.WidgetTransitionHold")
            xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
            _log("WIDGET_STACK_TRANSITION_NO_BLANK_HOLD reason=%s token=%s" % (reason or "", token))

            def _failsafe():
                try:
                    xbmc.sleep(900)
                    if token != getattr(self, "_widget_transition_token", 0):
                        return
                    if self.getProperty("PlexKM.WidgetTransitionHold") == "1":
                        self.clearProperty("PlexKM.WidgetTransitionHold")
                        xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
                        self._widget_transition_active = False
                        _log("WIDGET_STACK_TRANSITION_FAILSAFE_RELEASE reason=%s token=%s" % (reason or "", token), xbmc.LOGWARNING)
                except Exception:
                    pass

            _PKMHomeThreadV2151(target=_failsafe, name="PlexKMWidgetRevealFailSafe", daemon=True).start()
        except Exception:
            try:
                self.clearProperty("PlexKM.WidgetTransitionHold")
                xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
                self._widget_transition_active = False
            except Exception:
                pass

    def _release_widget_stack_transition_later(self, reason="", delay_ms=25):
        """v882: release the common widget-stack reveal quickly after target rows are ready.
        v881 used 70ms in many paths; with the XML 220ms visible animation this made
        startup/library switches feel late. Keep the reveal, but shorten the hidden
        hold so rows appear sooner.
        """
        try:
            if not getattr(self, "_widget_transition_active", False):
                return
            self._widget_transition_token += 1
            token = self._widget_transition_token

            def _release():
                try:
                    xbmc.sleep(max(0, int(delay_ms)))
                    if token != getattr(self, "_widget_transition_token", 0):
                        return
                    self.clearProperty("PlexKM.WidgetTransitionHold")
                    xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
                    self._widget_transition_active = False
                    _log("WIDGET_STACK_TRANSITION_RELEASE reason=%s delay_ms=%d token=%s" % (reason or "", int(delay_ms), token))
                except Exception:
                    try:
                        self.clearProperty("PlexKM.WidgetTransitionHold")
                        xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
                        self._widget_transition_active = False
                    except Exception:
                        pass

            _PKMHomeThreadV2151(target=_release, name="PlexKMWidgetRevealRelease", daemon=True).start()
        except Exception:
            try:
                self.clearProperty("PlexKM.WidgetTransitionHold")
                xbmcgui.Window(10000).clearProperty("PlexKM.WidgetTransitionHold")
                self._widget_transition_active = False
            except Exception:
                pass


    def _start_home_data_refresh_watcher(self, reason=""):
        """Watch settings/sync data-refresh signals while PKM Home is open."""
        try:
            if self._home_data_refresh_watch_running:
                return
            self._home_data_refresh_watch_running = True
            win = xbmcgui.Window(10000)
            self._home_data_refresh_token = win.getProperty("PlexKM.Home.DataRefreshToken") or ""

            def _watch():
                try:
                    monitor = xbmc.Monitor()
                    while not monitor.abortRequested() and not getattr(self, "_plex_update_watch_stop", False):
                        try:
                            if win.getProperty("PlexKM.ServiceStopping") == "1":
                                return
                        except Exception:
                            pass
                        try:
                            token = win.getProperty("PlexKM.Home.DataRefreshToken") or ""
                        except Exception:
                            token = ""
                        if token and token != getattr(self, "_home_data_refresh_token", ""):
                            self._home_data_refresh_token = token
                            try:
                                refresh_reason = win.getProperty("PlexKM.Home.DataRefreshReason") or "sync"
                            except Exception:
                                refresh_reason = "sync"
                            self._apply_home_data_refresh_signal(refresh_reason, token)
                        # V2595: settings/sync refresh tokens are not latency-
                        # critical enough to justify four wakeups per second on UHD.
                        if monitor.waitForAbort(1.0 if self._is_android_v2591() else 0.26):
                            return
                except Exception:
                    _log("HOME_DATA_REFRESH_WATCH_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                finally:
                    self._home_data_refresh_watch_running = False

            _PKMHomeThreadV2151(target=_watch, name="PlexKMHomeDataRefreshWatch", daemon=True).start()
            _log("HOME_DATA_REFRESH_WATCH_START reason=%s token=%s" % (reason or "", self._home_data_refresh_token))
        except Exception:
            _log("HOME_DATA_REFRESH_WATCH_START_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _apply_home_data_refresh_signal(self, reason="sync", token=""):
        try:
            reason_s = str(reason or "")
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.LibraryAdd.RestartRequiredV2090") == "1":
                    _log("HOME_DATA_REFRESH_DEFER_NEXT_START_V2091 reason=%s token=%s live_home_apply=0 spinner=0 next_start_loading_apply=1" % (reason_s, token or ""))
                    return
            except Exception:
                pass
            _log("HOME_DATA_REFRESH_APPLY_START reason=%s token=%s" % (reason or "", token or ""))
            if reason_s.startswith(("playstate", "sync", "incremental_sync", "startup_visible_sync")):
                # R108: index buckets that depend on watch state (감상한 날짜,
                # 진행상황, 미시청 수) are rebuilt on the next index request
                # instead of living until the next Kodi start.
                try:
                    dropped_r108 = 0
                    for cache_name in ("_section_index_sorted_cache_r102", "_section_index_bucket_maps_r107"):
                        cache = getattr(self, cache_name, None)
                        if isinstance(cache, dict):
                            for ck in list(cache.keys()):
                                if isinstance(ck, tuple) and len(ck) > 1 and ck[1] in ("viewed", "progress", "unwatched"):
                                    cache.pop(ck, None)
                                    dropped_r108 += 1
                    if dropped_r108:
                        _log("SECTION_INDEX_PLAYSTATE_INVALIDATE_R108 dropped=%d reason=%s" % (dropped_r108, reason_s))
                except Exception:
                    pass
            if reason_s.startswith("kodi_first_run_r108"):
                # R108: first-run setup finished with a Kodi-library source only.
                # Leave the "settings required" surface; the generic refresh below
                # rebuilds sidebar + Home from the local mirror.
                if self._pkm_initial_setup_completed_v2562():
                    self._set_empty_home_settings_state(False, reason="kodi_first_run_r108")
            if reason_s.startswith("playstate_live_v2669"):
                # V2669: live Plex playstate is independent from library membership.
                # Refresh only Home Continue Watching; never rebuild sidebar/sections.
                try:
                    self._home_rows_cache = None
                    self._home_wall_ready = False
                    if self._pkm_surface_mode_v2479() == "home":
                        self._show_home_wall(force=True)
                        _log("PLAYSTATE_LIVE_HOME_REFRESH_APPLY_V2669 token=%s visible_home=1 full_library_sync=0" % (token or ""))
                    else:
                        _log("PLAYSTATE_LIVE_HOME_REFRESH_DEFER_V2669 token=%s visible_home=0 cache_invalidated=1 full_library_sync=0" % (token or ""))
                    win_v2669 = xbmcgui.Window(10000)
                    win_v2669.setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                    win_v2669.setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                    win_v2669.setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
                except Exception:
                    _log("PLAYSTATE_LIVE_HOME_REFRESH_FAILED_V2669 token=%s err=%s" % (token or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                return
            if reason_s.startswith(("cine21_", "watcha_", "ratings_")):
                # v2487 rating-provider updates are presentation-only. Never clear
                # content authority or claim that the Plex library changed.
                self._persistent_presentation_fp_v2487 = ""
                _log("PERSISTENT_PRESENTATION_RUNTIME_INVALIDATE_V2487 reason=%s content_invalidate=0" % reason_s)
                self._presentation_fp_prewarm_r23(delay_ms=3000, reason="ratings_invalidate")
            if reason_s.startswith("settings_server_switch_pending"):
                self._apply_server_switch_pending_view_v1310(reason_s, token)
                return

            # v2016: PKM settings always returns directly to Home.  Startup
            # logo replay is intentionally not supported on this path.

            # v2005: full reset now emits the connection-reset reason so this atomic purge path always runs.
            # v1970: Plex connection reset must atomically remove every visible
            # library-owned surface. Do not reuse normal refresh/session caches.
            if reason_s.startswith("plex_connection_reset"):
                win_v1970 = xbmcgui.Window(10000)
                # v2043: Enter the canonical unconfigured-Home state before any
                # menu/widget operation.  The old order called _show_home_wall()
                # first, allowing the normal Home builder to preserve/publish a
                # stale row title (for example "최근 추가됨") before the
                # SettingsRequired flag was applied.
                try:
                    self._set_empty_home_settings_state(required=True, reason="connection_reset_v2043_pre_purge")
                    win_v1970.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    self.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    self._clear_all_home_metadata_v2034(reason="connection_reset_v2043_pre_purge")
                except Exception:
                    pass
                try:
                    self.sections = []
                    self.active_section_id = "__home__"
                    self._home_rows_cache = []
                    self._home_wall_ready = False
                    self.wall_items = []
                    self.wall_total = 0
                    self._section_rows_cache.clear()
                    self._section_total_cache.clear()
                    self._section_scene_cache_v1620.clear()
                    self._library_first12_scene_cache_v1868.clear()
                    self._tv_show_key_cache.clear()
                    self._tv_actor_name_pool_cache.clear()
                    self._tv_studio_name_pool_cache.clear()
                    self._tv_actor_show_key_cache.clear()
                    self._tv_studio_show_key_cache.clear()
                    self._tv_group_section_ids_cache.clear()
                except Exception:
                    pass
                try:
                    self._home_render_xml_rows([], reason="PLEX_CONNECTION_RESET_V1970")
                except Exception:
                    try:
                        self._home_reset_row_controls()
                    except Exception:
                        pass
                try:
                    self.getControl(WALL_ID).reset()
                except Exception:
                    pass
                try:
                    self._section_reset_recommend_row_controls()  # R36: _clear_section_lists() never existed
                except Exception:
                    pass
                try:
                    self._section_placeholder_clear_v1305(reason="plex_connection_reset_v1970")
                except Exception:
                    pass
                try:
                    self._build_menu()
                except Exception:
                    _log("PKM_CONNECTION_RESET_MENU_REBUILD_FAILED_V1970 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                # v2043: Do not run the normal Home widget builder while the
                # configuration is incomplete.  Keep Home as the destination,
                # clear every row/header property, and let the existing XML
                # first-run surface be the sole content owner.
                try:
                    self.active_section_id = "__home__"
                    self.setProperty("PlexKM.Window.IsHome", "1")
                    win_v1970.setProperty("PlexKM.Window.IsHome", "1")
                    for _state_prop in ("PlexKM.Window.IsSectionRecommend", "PlexKM.Window.IsSectionWall"):
                        self.clearProperty(_state_prop)
                        win_v1970.clearProperty(_state_prop)
                    self._home_reset_row_controls()
                    self._set_header("", "")
                    _log("RESET_FIRST_RUN_SURFACE_V2043 widget_builder=blocked rows=0 header=0 settings_required=1")
                except Exception:
                    pass
                # v1984: purge the hero surface as part of the same state
                # transition.  Clearing DB/state alone is not enough while the
                # existing WindowXML controls are still alive.
                try:
                    self._set_home_fanart_smooth("", reason="connection_reset_v1984")
                except Exception:
                    pass
                try:
                    self._set_home_dynamic_bg_color(self._home_bg_default, reason="connection_reset_v1984")
                except Exception:
                    pass
                for prop_v1984 in (
                    "PlexKM.Home.Fanart",
                    "PlexKM.Home.DisplayFanart",
                    "PlexKM.Home.DisplayFanartRaw",
                    "PlexKM.Window.Title",
                    "PlexKM.Window.SubTitle",
                    "PlexKM.Window.Meta",
                    "PlexKM.Window.Summary",
                    "PlexKM.Window.Genre",
                    "PlexKM.Window.CountLabel",
                    "PlexKM.Window.IsSectionRecommend",
                    "PlexKM.Window.IsSectionWall",
                ):
                    try:
                        self.clearProperty(prop_v1984)
                    except Exception:
                        pass
                    try:
                        win_v1970.clearProperty(prop_v1984)
                    except Exception:
                        pass
                try:
                    self._home_fanart_current = ""
                    self._home_bg_current_fanart = ""
                    self._home_bg_target_fanart_v2314 = ""
                    self._home_bg_target_since_ms_v2314 = 0
                except Exception:
                    pass
                try:
                    # v2040: restore the canonical first-run surface after a full/reset
                    # transaction. This also clears InitialSetupReadyV1736, which
                    # otherwise hides the existing "Plex 서버 설정이 필요합니다" group.
                    self._set_empty_home_settings_state(required=True, reason="connection_reset_v2040")
                    win_v1970.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    self.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    self._clear_all_home_metadata_v2034(reason="connection_reset_v2040")
                except Exception:
                    pass
                # Dynamic menu 9000 now contains Home / PKM settings / Kodi
                # settings only.  Hand focus to Home exactly once after rebuild.
                try:
                    # v2020: reset runs while the PKM settings dialog still owns
                    # focus. Select Home in the live sidebar, but never transfer
                    # GUI focus behind that modal. Kodi will restore the existing
                    # XML-owned 9000 focus when the settings dialog closes.
                    self._force_home_menu_focus(
                        "connection_reset_home_select_only_v2020",
                        select_home=True,
                        force_handoff=False,
                    )
                except Exception:
                    pass
                # v2019: a live reset happens behind the still-open PKM settings
                # dialog.  StartupReady owns only the one-time Kodi startup gate;
                # clearing it here makes the already-rendered Home expose the
                # completed logo again when the settings dialog closes.
                # Keep StartupReady=1 and clear only reset/data-refresh state.
                for key in (
                    "PlexKM.Home.ConnectionResetV1970",
                    "PlexKM.Home.SessionCacheRestoredV1632",
                    "PlexKM.PlexUpdate.Dirty",
                    "PlexKM.PlexUpdate.Sections",
                    "PlexKM.Home.SyncRefreshPendingV1554",
                ):
                    try:
                        win_v1970.clearProperty(key)
                    except Exception:
                        pass
                    try:
                        self.clearProperty(key)
                    except Exception:
                        pass
                try:
                    win_v1970.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    self.setProperty("PlexKM.Home.StartupReadyV1619", "1")
                    win_v1970.clearProperty("PlexKM.SkinStartupSplash")
                    self.clearProperty("PlexKM.SkinStartupSplash")
                    _log("PKM_CONNECTION_RESET_KEEP_STARTUP_READY_V2019 ready=1 logo=blocked live_home=1")
                except Exception:
                    pass
                try:
                    win_v1970.setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                    win_v1970.setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                    win_v1970.setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
                except Exception:
                    pass
                _log("PKM_CONNECTION_RESET_HOME_PURGE_DONE_V1984 sections=0 home_rows=0 wall_items=0 fanart=0 meta=0 menu_libraries=0 focus=home session_cache=cleared")
                return

            # v930: Cine21 startup/update is a rating-cache refresh only.
            # Rebuilding the menu here forced focus back to Home while the user
            # was already entering a movie section. Keep the current focus and
            # just invalidate Cine21 memory + republish metadata for the current
            # focused item. Full menu/row rebuild remains for non-Cine21 sync
            # signals.
            if reason_s.startswith("cine21_"):
                try:
                    self._home_cine21_cache.clear()
                except Exception:
                    self._home_cine21_cache = {}
                try:
                    self._home_cine21_db_mtime = None
                except Exception:
                    pass
                try:
                    self._set_home_meta_from_item(reason="home_data_refresh_%s" % reason_s)
                except Exception:
                    pass
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                    xbmcgui.Window(10000).setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                    xbmcgui.Window(10000).setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
                except Exception:
                    pass
                _log("HOME_DATA_REFRESH_APPLY_DONE reason=%s token=%s mode=cine21_meta_only focus=%s active_section=%s" % (
                    reason or "", token or "", self._safe_focus_id(), getattr(self, "active_section_id", "")
                ))
                return

            # v1206: service startup sync must not rebuild the visible side menu.
            # The startup_visible_sync signal arrives after the first Home screen is
            # already visible.  The old path below reloaded sections, rebuilt MENU_ID,
            # forced focus back to Home, and repainted widgets; visually this looked
            # like the side menu and Home widgets refreshed/flickered after startup.
            # Keep the refreshed DB/cache data by marking Home/sections dirty for the
            # next natural entry, but do not touch the current menu/list controls.
            if reason_s.startswith((
                "startup_visible_sync",
                "incremental_sync_committed_v1554",
                "manual_section_sync_committed_v1554",
            )):
                dirty_ids = []
                # v1621: completed sidebar scenes are immutable for this Kodi
                # window session. The old global clear raced a large movie compose:
                # its scene was published, but its row cache disappeared moments
                # earlier, so the next visit was misclassified as cold and showed
                # the first-visit spinner again. Keep scene/row/total caches intact;
                # dirty flags still record that DB data changed and the next PKM
                # start (or an explicit refresh path) can build a new snapshot.
                try:
                    self._tv_show_key_cache.clear()
                    self._tv_actor_name_pool_cache.clear()
                    self._tv_studio_name_pool_cache.clear()
                    self._tv_actor_show_key_cache.clear()
                    self._tv_studio_show_key_cache.clear()
                    self._tv_group_section_ids_cache.clear()
                    _log("SECTION_SCENE_SESSION_CACHE_KEEP_V1621 reason=%s rows=%d scenes=%d action=dirty_mark_only" % (
                        reason or "", len(self._section_rows_cache or {}), len(self._section_scene_cache_v1620 or {})
                    ))
                except Exception:
                    pass
                try:
                    self._home_cine21_cache.clear()
                except Exception:
                    self._home_cine21_cache = {}
                try:
                    self._home_cine21_db_mtime = None
                except Exception:
                    pass
                try:
                    for sec in getattr(self, "sections", []) or []:
                        sid = str(sec.get("section_id") or sec.get("key") or "").strip() if isinstance(sec, dict) else ""
                        if sid:
                            dirty_ids.append(sid)
                            self._plex_update_dirty_sections.add(sid)
                    self._plex_update_dirty_home = True
                except Exception:
                    pass
                try:
                    win = xbmcgui.Window(10000)
                    win.setProperty("PlexKM.PlexUpdate.Dirty", "1")
                    if dirty_ids:
                        win.setProperty("PlexKM.PlexUpdate.Sections", ",".join(dirty_ids))
                    win.setProperty("PlexKM.PlexUpdate.Time", str(int(time.time())))
                    win.setProperty("PlexKM.Home.SyncRefreshPendingV1554", "1")
                    win.setProperty("PlexKM.Home.SyncRefreshPendingTokenV1554", str(token or ""))
                    win.setProperty("PlexKM.Home.SyncRefreshPendingReasonV1554", str(reason or ""))
                    # v1554: do not acknowledge DataRefreshAppliedToken here.
                    # This watcher is a worker thread and has only marked data
                    # dirty.  The GUI-thread rebuild helper acknowledges after
                    # visible widgets are actually rebuilt from the committed DB.
                except Exception:
                    pass
                _log("HOME_DATA_REFRESH_APPLY_DONE reason=%s token=%s mode=sync_dirty_pending_gui_refresh_v1554 dirty_sections=%d focus=%s active_section=%s" % (
                    reason or "", token or "", len(dirty_ids), self._safe_focus_id(), getattr(self, "active_section_id", "")
                ))
                return

            # v1632: playback stop changes only Continue Watching. It must not be
            # promoted to the global PlexUpdate dirty path because that path rebuilds
            # the entire Home stack from an onAction/onFocus callback and competes
            # with the first sidebar navigation after playback. Queue one Home-only
            # refresh and consume it only when Home is naturally entered later.
            if reason_s.startswith("playstate_"):
                try:
                    win = xbmcgui.Window(10000)
                    win.setProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632", "1")
                    win.setProperty("PlexKM.Playback.PostStopHomeRefreshTokenV1632", str(token or ""))
                    win.setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                    win.setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                    win.setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
                    win.clearProperty("PlexKM.Playback.PostStopRefreshDeferredV1545")
                except Exception:
                    pass
                self._playstate_home_refresh_pending_v1632 = True
                _log("HOME_PLAYSTATE_REFRESH_QUEUE_V1632 reason=%s token=%s action=home_only_next_natural_entry global_dirty=0 no_control_mutation=1 focus=%s active_section=%s" % (
                    reason or "", token or "", self._safe_focus_id(), getattr(self, "active_section_id", "")
                ))
                return
            try:
                if not xbmcgui.Window(10000).getProperty("PlexKM.Home.ServerSwitchPending"):
                    for key in (
                        "PlexKM.Home.ServerSwitchPending",
                        "PlexKM.Home.ServerSwitchPendingLine1",
                        "PlexKM.Home.ServerSwitchPendingLine2",
                    ):
                        try:
                            self.clearProperty(key)
                        except Exception:
                            pass
            except Exception:
                pass
            self._load_sections(refresh=True)
            try:
                self._section_rows_cache.clear()
                self._section_total_cache.clear()
                self._library_first12_scene_cache_v1868.clear()
                self._tv_show_key_cache.clear()
                self._tv_actor_name_pool_cache.clear()
                self._tv_studio_name_pool_cache.clear()
                self._tv_actor_show_key_cache.clear()
                self._tv_studio_show_key_cache.clear()
                self._tv_group_section_ids_cache.clear()
            except Exception:
                pass
            self._home_rows_cache = None
            self._home_wall_ready = False
            self.active_section_id = "__home__"
            self._build_menu()
            # Preserve the existing V2042/V2043 focus path. No new focus write,
            # retry, timer, or delayed handoff is introduced by V2045.
            self._force_home_menu_focus("home_data_refresh_%s" % (reason or "sync"), select_home=True)
            self._refresh_for_menu_focus(force=True)
            if reason_s.startswith("kodi_first_run_r108"):
                # R108: focus was on the (now hidden) settings CTA 5858.  Hand it
                # to the first Home row like a normal start, else to the menu.
                try:
                    if self._safe_focus_id() in (0, 100, EMPTY_HOME_SETTINGS_BUTTON_ID):
                        self.setFocusId(MENU_ID)
                        # V2804: never push Right into a modal dialog above Home.
                        if not _pkm_modal_over_home_v2804():
                            xbmc.executebuiltin("Action(Right)")
                    _log("KODI_FIRST_RUN_FOCUS_R108 focus=%s" % self._safe_focus_id())
                except Exception:
                    pass
            try:
                win_v2044 = xbmcgui.Window(10000)
                win_v2044.setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                xbmcgui.Window(10000).setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                xbmcgui.Window(10000).setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
            except Exception:
                pass
            _log("HOME_DATA_REFRESH_APPLY_DONE reason=%s token=%s sections=%d visible_widgets=updated" % (reason or "", token or "", len(self.sections or [])))
        except Exception:
            _log("HOME_DATA_REFRESH_APPLY_FAILED reason=%s token=%s err=%s" % (reason or "", token or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _force_home_menu_focus(self, reason="", select_home=False, force_handoff=False):
        """v1961: select the sidebar item and perform one startup handoff after population.

        Control 9000 is created by WindowXML before onInit. _build_menu() fills
        it and position 0 is always Home. No delay, retry, guard thread, or runtime focus recovery is performed here.
        """
        try:
            menu = self.getControl(MENU_ID)
            size = int(menu.size())
            if size <= 0:
                _log("FOCUS_V1961_MENU_SELECTION_SKIPPED reason=%s menu_empty=1" % (reason or ""))
                return False
            pos = 0 if select_home else max(0, min(int(getattr(self, "_last_menu_pos", 0) or 0), size - 1))
            menu.selectItem(pos)
            try:
                collapsed = self.getControl(MENU_COLLAPSED_ID)
                if int(collapsed.size()) > pos:
                    collapsed.selectItem(pos)
            except Exception:
                pass
            self._last_menu_pos = pos
            before_focus_v1960 = self._safe_focus_id()
            handed_off_v1960 = 0
            # v1961: one immediate handoff only after 9000 contains real items.
            # No delay, retry loop, guard thread, or runtime focus recovery.
            handoff_reason_v1982 = str(reason or "")
            handoff_allowed_v1982 = bool(force_handoff) or (
                handoff_reason_v1982.startswith("oninit_after_dynamic_menu_build")
                or handoff_reason_v1982.startswith("settings_return_empty_")
                or handoff_reason_v1982.startswith("connection_reset_home_rebuild_")
                or handoff_reason_v1982.startswith("home_data_refresh_library_added_sync")
            )
            if handoff_allowed_v1982 and before_focus_v1960 not in (MENU_ID,):
                try:
                    handed_off_v1960 = 1 if self._focus_menu_control_v1993(
                        pos=pos, reason="force_home_menu_focus_" + handoff_reason_v1982) else 0
                except Exception:
                    _log("FOCUS_V1961_HANDOFF_FAILED reason=%s err=%s" % (
                        reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            _log("FOCUS_V1961_MENU_READY reason=%s control=9000 pos=%d size=%d focus_before=%s focus_after=%s handoff=%d" % (
                reason or "", pos, size, before_focus_v1960, self._safe_focus_id(), handed_off_v1960))
            # R83b: start folded (Plex) -- once Home row 0 is published, focus
            # moves to the first poster and the sidebar collapses.  Only for the
            # PKM start itself, never when the settings screen is required.
            if (handoff_reason_v1982.startswith("oninit_after_dynamic_menu_build")
                    and not getattr(self, "_startup_fold_done_r83b", False)
                    and self.getProperty("PlexKM.Home.SettingsRequired") != "1"
                    and xbmcgui.Window(10000).getProperty("PlexKM.Home.SettingsRequired") != "1"):
                self._startup_fold_done_r83b = True
                try:
                    self._sidebar_enter_collapse_r82("home", startup=True)
                except Exception:
                    _log("R83B_STARTUP_FOLD_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return True
        except Exception:
            _log("FOCUS_V1961_MENU_SELECTION_FAILED reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _show_home_exit_confirm(self, reason="back"):
        """Back on the main PKM Home asks whether to quit Kodi and PKM together."""
        if getattr(self, "_home_exit_confirm_active", False):
            _log("HOME_EXIT_CONFIRM_SKIP reason=already_active")
            return
        self._home_exit_confirm_active = True
        try:
            try:
                previous_focus = self._safe_focus_id()
            except Exception:
                previous_focus = -1
            _log("HOME_EXIT_CONFIRM_OPEN reason=%s focus=%s" % (reason or "", previous_focus))
            if open_pkm_home_exit_confirm_dialog():
                # v2187 normally never reaches here: on YES the confirm dialog
                # intentionally stays open while the countdown is shown above it,
                # and Kodi exits before doModal returns.  This branch is only the
                # emergency fallback when that worker could not start.
                _log("HOME_EXIT_CONFIRM_ACCEPT_FALLBACK_V2187 action=quit_kodi")
                try:
                    pkm_notify.pkm_notice_clear(force=True)
                except Exception:
                    pass
                try:
                    xbmcgui.Window(10000).setProperty("PlexKM.App.Quitting", "1")
                except Exception:
                    pass
                try:
                    request_kodi_exit_v2171(reason="home_exit_confirm_fallback_v2187", title="Kodi 종료", detail="")
                except Exception:
                    _log("HOME_EXIT_COUNTDOWN_FALLBACK_FAILED_V2187 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                return
            _log("HOME_EXIT_CONFIRM_CANCEL return_focus=%s" % previous_focus)
            try:
                if previous_focus and int(previous_focus) > 0:
                    self.setFocusId(int(previous_focus))
                else:
                    self._force_home_menu_focus("exit_confirm_cancel", select_home=False)
            except Exception:
                try:
                    self._force_home_menu_focus("exit_confirm_cancel_fallback", select_home=False)
                except Exception:
                    pass
        finally:
            self._home_exit_confirm_active = False

    def _visible_row_controls_for_scope(self, scope):
        try:
            # v2385: recompute the visible-row registry from live panel sizes.
            # Kodi's native grouplist owns placement/scrolling; Python uses this
            # list only for row-memory/telemetry and never translates the stack.
            if scope == SECTION_ROW_ANCHOR_SCOPE:
                rows = [cid for cid in self._section_active_row_ids_v1612() if self.getControl(cid).size() > 0]
                self._section_visible_row_controls = list(rows)
                return rows
            rows = [cid for cid in HOME_ROW_IDS if self.getControl(cid).size() > 0]
            self._home_visible_row_controls = list(rows)
            return rows
        except Exception:
            return []

    def _row_anchor_scope_for_control(self, control_id):
        try:
            fid = int(control_id)
            if fid in SECTION_RECOMMEND_ALL_ROW_IDS:
                bank = "B" if fid in SECTION_RECOMMEND_ROW_IDS_B else "A"
                return SECTION_ROW_ANCHOR_SCOPE, self._section_bank_stack_id_v1612(bank)
            if fid in HOME_ROW_IDS:
                return HOME_ROW_ANCHOR_SCOPE, HOME_ROW_STACK_ID
        except Exception:
            pass
        return "", 0

    # v2385: 8xxx/9xxx row movement and vertical scrolling are both native.
    # Python may observe focus for metadata, but it never writes row focus or Y.


    def _row_anchor_layout_for_scope(self, scope):
        """Return the XML geometry constants used for row-anchor diagnostics.

        Kodi does not expose grouplist/group controls such as 9298/8298 to
        Python WindowXML; trying to getControl() for them logs
        "Unknown control type for python".  These values mirror the XML so
        logs can still show absolute row positions without touching focus.
        """
        if scope == SECTION_ROW_ANCHOR_SCOPE:
            bank_v1612 = self._section_bank_name_v1612()
            return {
                "scope": SECTION_ROW_ANCHOR_SCOPE,
                "stack_id": self._section_bank_stack_id_v1612(bank_v1612),
                "viewport_id": SECTION_RECOMMEND_ROW_VIEWPORT_ID,
                "outer_id": self._section_bank_outer_id_v1612(bank_v1612),
                "outer_left": 410,
                "outer_top": SECTION_WIDGET_OUTER_TOP_V2275,
                "viewport_left": 0,
                "viewport_top": 0,
                "viewport_width": 1920,
                "viewport_height": 588,
                "row_height": WIDGET_ROW_PITCH_V2275,
                "panel_top": WIDGET_PANEL_TOP_V2275,
                "panel_height": WIDGET_PANEL_HEIGHT_V2275,
            }
        return {
            "scope": HOME_ROW_ANCHOR_SCOPE,
            "stack_id": HOME_ROW_STACK_ID,
            "viewport_id": HOME_ROW_VIEWPORT_ID,
            "outer_id": 9299,
            "outer_left": 410,
            "outer_top": HOME_WIDGET_OUTER_TOP_V2275,
            "viewport_left": 0,
            "viewport_top": 0,
            "viewport_width": 1920,
            "viewport_height": 588,
            "row_height": WIDGET_ROW_PITCH_V2275,
            "panel_top": WIDGET_PANEL_TOP_V2275,
            "panel_height": WIDGET_PANEL_HEIGHT_V2275,
        }

    def _home_row_block_metric_log(self, reason="", focus_id=0, scroll_index=None):
        """Log every Home 9xxx vertical block value used for row-unit tuning.

        This is diagnostic only.  It does not change XML geometry, focus, or
        stack movement.  The goal is to expose the full 1-row block equation:
        row_unit = title_area + title_to_poster_gap + poster_area + bottom_gap.
        20 rows are only the maximum XML pool; real scroll range is calculated
        from populated rows.
        """
        try:
            rows = self._visible_row_controls_for_scope(HOME_ROW_ANCHOR_SCOPE)
            layout = self._row_anchor_layout_for_scope(HOME_ROW_ANCHOR_SCOPE)
            row_unit = int(layout.get("row_height", 0) or 0)
            panel_top = int(layout.get("panel_top", 0) or 0)
            panel_h = int(layout.get("panel_height", 0) or 0)
            viewport_h = int(layout.get("viewport_height", 0) or 0)
            outer_top = int(layout.get("outer_top", 0) or 0)
            outer_left = int(layout.get("outer_left", 0) or 0)
            viewport_w = int(layout.get("viewport_width", 0) or 0)
            if scroll_index is None:
                scroll_index = int(getattr(self, "_row_anchor_scroll_index", {}).get(HOME_ROW_ANCHOR_SCOPE, 0) or 0)
            visible_count = len(rows)
            max_pool_rows = int(HOME_ROW_COUNT)
            max_scroll_index = max(0, visible_count - 1)

            # Current Home 9xxx XML block values.  These are logged as tuning
            # constants so poster cropping/size work can be recalculated without
            # guessing.  When XML geometry changes, update these log constants in
            # the same patch.
            title_top = 0
            title_height = 52
            title_area = title_height
            title_bottom = title_top + title_height
            title_to_panel_gap = panel_top - title_bottom
            poster_area = panel_h
            row_bottom_gap = row_unit - (panel_top + panel_h)
            panel_bottom = panel_top + panel_h

            itemlayout_width = 260
            itemlayout_height = 390
            normal_poster_left = 20
            normal_poster_top = 10
            normal_poster_width = 220
            normal_poster_height = 360
            normal_poster_right = normal_poster_left + normal_poster_width
            normal_poster_bottom = normal_poster_top + normal_poster_height
            normal_aspectratio = "scale"

            focusedlayout_width = 260
            focusedlayout_height = 390
            focused_poster_left = 20
            focused_poster_top = 10
            focused_poster_width = 220
            focused_poster_height = 360
            focused_poster_right = focused_poster_left + focused_poster_width
            focused_poster_bottom = focused_poster_top + focused_poster_height
            focused_aspectratio = "scale"

            outline_top_left = 20
            outline_top_top = 10
            outline_top_width = 220
            outline_top_height = 2
            outline_bottom_left = 20
            outline_bottom_top = 368
            outline_bottom_width = 220
            outline_bottom_height = 2
            outline_left_left = 20
            outline_left_top = 10
            outline_left_width = 2
            outline_left_height = 360
            outline_right_left = 238
            outline_right_top = 10
            outline_right_width = 2
            outline_right_height = 360

            normal_progress_bg_left = 20
            normal_progress_bg_top = 366
            normal_progress_bg_width = 220
            normal_progress_bg_height = 4
            focused_progress_bg_left = 20
            focused_progress_bg_top = 366
            focused_progress_bg_width = 220
            focused_progress_bg_height = 4

            first_row_full = 1 if viewport_h >= (panel_top + panel_h) else 0
            second_panel_visible_px = max(0, min(panel_h, viewport_h - (row_unit + panel_top))) if row_unit and panel_h else 0
            second_panel_visible_ratio = (float(second_panel_visible_px) / float(panel_h)) if panel_h else 0.0
            second_row_total_visible_px = max(0, min(row_unit, viewport_h - row_unit)) if row_unit else 0
            second_row_total_visible_ratio = (float(second_row_total_visible_px) / float(row_unit)) if row_unit else 0.0
            stack_height_visible = visible_count * row_unit
            stack_height_max_pool = max_pool_rows * row_unit
            current_stack_y = -int(scroll_index) * row_unit
            focus_id_int = int(focus_id or 0)
            focus_visible_index = rows.index(focus_id_int) if focus_id_int in rows else -1
            focus_row_top_abs = outer_top + ((focus_visible_index - int(scroll_index)) * row_unit) if focus_visible_index >= 0 else -1
            focus_panel_top_abs = focus_row_top_abs + panel_top if focus_visible_index >= 0 else -1
            focus_panel_bottom_abs = focus_panel_top_abs + panel_h if focus_visible_index >= 0 else -1

            _log(
                "HOME_ROW_BLOCK_METRIC reason=%s focus=%s "
                "max_pool_rows=%s visible_rows=%s visible_row_ids=%s "
                "row_unit=%s title_area=%s title_top=%s title_height=%s title_bottom=%s "
                "title_to_poster_gap=%s panel_top=%s poster_area=%s panel_height=%s panel_bottom=%s row_bottom_gap=%s "
                "viewport_left=%s viewport_top=%s viewport_width=%s viewport_height=%s outer_left=%s outer_top=%s "
                "first_row_full=%s second_row_total_visible_px=%s second_row_total_visible_ratio=%.3f "
                "second_panel_visible_px=%s second_panel_visible_ratio=%.3f "
                "stack_height_visible=%s stack_height_max_pool=%s max_scroll_index=%s current_scroll_index=%s current_stack_y=%s "
                "focus_visible_index=%s focus_row_top_abs=%s focus_panel_top_abs=%s focus_panel_bottom_abs=%s"
                % (
                    reason or "", focus_id_int,
                    max_pool_rows, visible_count, ",".join(str(x) for x in rows),
                    row_unit, title_area, title_top, title_height, title_bottom,
                    title_to_panel_gap, panel_top, poster_area, panel_h, panel_bottom, row_bottom_gap,
                    int(layout.get("viewport_left", 0) or 0), int(layout.get("viewport_top", 0) or 0), viewport_w, viewport_h, outer_left, outer_top,
                    first_row_full, second_row_total_visible_px, second_row_total_visible_ratio,
                    second_panel_visible_px, second_panel_visible_ratio,
                    stack_height_visible, stack_height_max_pool, max_scroll_index, int(scroll_index), current_stack_y,
                    focus_visible_index, focus_row_top_abs, focus_panel_top_abs, focus_panel_bottom_abs
                )
            )
            _log(
                "HOME_ROW_POSTER_METRIC reason=%s "
                "itemlayout_width=%s itemlayout_height=%s normal_poster_left=%s normal_poster_top=%s normal_poster_width=%s normal_poster_height=%s normal_poster_right=%s normal_poster_bottom=%s normal_aspectratio=%s "
                "focusedlayout_width=%s focusedlayout_height=%s focused_poster_left=%s focused_poster_top=%s focused_poster_width=%s focused_poster_height=%s focused_poster_right=%s focused_poster_bottom=%s focused_aspectratio=%s "
                "outline_top=(left=%s,top=%s,width=%s,height=%s) outline_bottom=(left=%s,top=%s,width=%s,height=%s) outline_left=(left=%s,top=%s,width=%s,height=%s) outline_right=(left=%s,top=%s,width=%s,height=%s) "
                "normal_progress_image=(left=%s,top=%s,width=%s,height=%s) "
                "focused_progress_image=(left=%s,top=%s,width=%s,height=%s)"
                % (
                    reason or "",
                    itemlayout_width, itemlayout_height, normal_poster_left, normal_poster_top, normal_poster_width, normal_poster_height, normal_poster_right, normal_poster_bottom, normal_aspectratio,
                    focusedlayout_width, focusedlayout_height, focused_poster_left, focused_poster_top, focused_poster_width, focused_poster_height, focused_poster_right, focused_poster_bottom, focused_aspectratio,
                    outline_top_left, outline_top_top, outline_top_width, outline_top_height,
                    outline_bottom_left, outline_bottom_top, outline_bottom_width, outline_bottom_height,
                    outline_left_left, outline_left_top, outline_left_width, outline_left_height,
                    outline_right_left, outline_right_top, outline_right_width, outline_right_height,
                    normal_progress_bg_left, normal_progress_bg_top, normal_progress_bg_width, normal_progress_bg_height,
                    focused_progress_bg_left, focused_progress_bg_top, focused_progress_bg_width, focused_progress_bg_height,
                )
            )
            parts = []
            for idx, cid in enumerate(rows):
                row_top_abs = outer_top + ((idx - int(scroll_index)) * row_unit)
                row_bottom_abs = row_top_abs + row_unit
                title_top_abs = row_top_abs + title_top
                title_bottom_abs = title_top_abs + title_height
                panel_top_abs = row_top_abs + panel_top
                panel_bottom_abs = panel_top_abs + panel_h
                visible_top = max(outer_top, panel_top_abs)
                visible_bottom = min(outer_top + viewport_h, panel_bottom_abs)
                panel_visible_px = max(0, visible_bottom - visible_top)
                row_visible_top = max(outer_top, row_top_abs)
                row_visible_bottom = min(outer_top + viewport_h, row_bottom_abs)
                row_visible_px = max(0, row_visible_bottom - row_visible_top)
                try:
                    size = self.getControl(cid).size()
                except Exception:
                    size = -1
                parts.append(
                    "idx=%s id=%s size=%s row_top_abs=%s row_bottom_abs=%s row_visible_px=%s title_top_abs=%s title_bottom_abs=%s panel_top_abs=%s panel_bottom_abs=%s panel_visible_px=%s"
                    % (idx, cid, size, row_top_abs, row_bottom_abs, row_visible_px, title_top_abs, title_bottom_abs, panel_top_abs, panel_bottom_abs, panel_visible_px)
                )
            _log("HOME_ROW_BLOCK_GEOMS reason=%s scroll_index=%s rows=[%s]" % (reason or "", int(scroll_index), " | ".join(parts)))
        except Exception:
            _log("HOME_ROW_BLOCK_METRIC_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _move_row_stack_relative(self, stack_id, delta, animate=True):
        """Move the complete widget stack as one surface.

        Title and poster controls keep their existing row geometry.  Only the
        parent stack Y changes, so every visible row moves together.
        """
        # PKM_NATIVE_ROW_SCROLL_U6_20261011
        # These three *virtual* stack IDs were never instantiated in the Kodi
        # home XML. Real widget rows belong to native vertical grouplists
        # 9298 / 8298 / 8398, which already handle focus-following scroll.
        # Probing the missing IDs with getControl() generates Kodi EXCEPTIONs
        # and wastes main-thread time on every UP/DOWN and INFO -> Back.
        # Do not invent a substitute geometry move or change A/B bank positions.
        if int(stack_id) in (HOME_ROW_STACK_ID, SECTION_RECOMMEND_ROW_STACK_ID,
                             SECTION_RECOMMEND_ROW_STACK_ID_B):
            if not getattr(self, '_pkm_native_row_scroll_noted_u6', False):
                self._pkm_native_row_scroll_noted_u6 = True
                _log('ROW_STACK_NATIVE_GROUPLIST_U6 native_scroll=1 virtual_stack_move=skipped')
            return True
        try:
            stack = self.getControl(int(stack_id))
            try:
                x, y = stack.getPosition()
            except Exception:
                x, y = 0, 0
            target_y = int(y) + int(delta)
            if not animate or int(y) == target_y:
                stack.setPosition(int(x), target_y)
                return True

            distance = target_y - int(y)
            # Short fixed animation: enough samples for a smooth 60 Hz-ish move,
            # while avoiding long queued transitions on low-power set-top boxes.
            steps = 8
            duration_ms = 144
            for step in range(1, steps + 1):
                t = float(step) / float(steps)
                # cubic smoothstep, no overshoot
                eased = (3.0 * t * t) - (2.0 * t * t * t)
                next_y = int(round(int(y) + (distance * eased)))
                stack.setPosition(int(x), next_y)
                if step < steps:
                    xbmc.sleep(max(1, int(duration_ms / steps)))
            stack.setPosition(int(x), target_y)
            return True
        except Exception:
            _log("ROW_STACK_MOVE_FAILED stack=%s delta=%s err=%s" % (
                stack_id, delta, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False


    def _reset_row_anchor_scroll(self, scope=None, reason="", animate=True):
        """Return the complete row stack to its first-row anchor."""
        try:
            if not hasattr(self, "_row_anchor_scroll_index"):
                self._row_anchor_scroll_index = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
            if not hasattr(self, "_row_anchor_current_y"):
                self._row_anchor_current_y = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
            scopes = [scope] if scope in (HOME_ROW_ANCHOR_SCOPE, SECTION_ROW_ANCHOR_SCOPE) else [
                HOME_ROW_ANCHOR_SCOPE, SECTION_ROW_ANCHOR_SCOPE
            ]
            for sc in scopes:
                current = int(self._row_anchor_scroll_index.get(sc, 0) or 0)
                if sc == HOME_ROW_ANCHOR_SCOPE:
                    stack_id = HOME_ROW_STACK_ID
                else:
                    stack_id = self._section_bank_stack_id_v1612()
                if current:
                    self._move_row_stack_relative(
                        stack_id,
                        current * int(WIDGET_ROW_PITCH_V2275),
                        animate=bool(animate),
                    )
                self._row_anchor_scroll_index[sc] = 0
                self._row_anchor_current_y[sc] = 0
            return True
        except Exception:
            return False
    def _apply_dynamic_row_anchor_scroll(self, control_id, reason=""):
        """Anchor the focused row by moving the complete title+poster stack.

        DOWN advances exactly one populated row; the next row occupies the same
        first-row anchor and the following row remains partially visible below.
        UP is the exact reverse.  Focus itself remains Kodi-native.
        """
        try:
            fid = int(control_id)
            scope, stack_id = self._row_anchor_scope_for_control(fid)
            if not scope:
                return False
            row_index = self._visible_row_index_for_control(fid)
            if row_index < 0:
                return False
            if not hasattr(self, "_row_anchor_scroll_index"):
                self._row_anchor_scroll_index = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
            if not hasattr(self, "_row_anchor_current_y"):
                self._row_anchor_current_y = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}

            prev = int(self._row_anchor_scroll_index.get(scope, 0) or 0)
            delta_rows = int(row_index) - prev
            if delta_rows:
                moved = self._move_row_stack_relative(
                    stack_id,
                    -delta_rows * int(WIDGET_ROW_PITCH_V2275),
                    animate=True,
                )
                if not moved:
                    return False

            self._row_anchor_scroll_index[scope] = int(row_index)
            self._row_anchor_current_y[scope] = -int(row_index) * int(WIDGET_ROW_PITCH_V2275)
            return True
        except Exception:
            _log("ROW_ANCHOR_APPLY_FAILED reason=%s focus=%s err=%s" % (
                reason, control_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _home_row_ids_for_control(self, control_id=None):
        """Return the row-id group for the focused Home-like widget row.

        9410~9450 are Home rows, 8410~8450 are copied section-recommend rows.
        Both must feed the exact same metadata path; only the XML containers differ.
        """
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
            if fid in SECTION_RECOMMEND_ROW_IDS_A:
                return SECTION_RECOMMEND_ROW_IDS_A
            if fid in SECTION_RECOMMEND_ROW_IDS_B:
                return SECTION_RECOMMEND_ROW_IDS_B
            if fid in INFO_MOVIE_WIDGET_ROW_IDS:
                return INFO_MOVIE_WIDGET_ROW_IDS
            if fid in INFO_TV_ACTOR_WIDGET_ROW_IDS:
                return INFO_TV_ACTOR_WIDGET_ROW_IDS
            if fid in HOME_ROW_IDS:
                return HOME_ROW_IDS
        except Exception:
            pass
        return HOME_ROW_IDS

    def _is_home_row_control(self, control_id=None):
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
            return fid in HOME_LIKE_ROW_IDS
        except Exception:
            return False

    def _home_row_selected_position(self, row_index=None, control_id=None):
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
            ids = self._home_row_ids_for_control(fid)
            if row_index is None or row_index < 0:
                row_index = self._home_row_index_for_control(fid)
            if row_index < 0:
                return -1
            # Use the focused control id directly; row_index is the visible-row order
            # and may not match the fixed tuple position when Plex data skips rows.
            return int(self.getControl(fid).getSelectedPosition())
        except Exception:
            return -1

    def _home_focused_item(self, control_id=None):
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
            ids = self._home_row_ids_for_control(fid)
            ri = self._home_row_index_for_control(fid)
            if ri < 0:
                return None
            # Use focused control directly; visible row index is data-dependent.
            return self.getControl(fid).getSelectedItem()
        except Exception:
            return None

    def _home_action_name(self, aid):
        try:
            aid = int(aid)
        except Exception:
            return str(aid)
        return {
            ACTION_MOVE_LEFT: "LEFT",
            ACTION_MOVE_RIGHT: "RIGHT",
            ACTION_MOVE_UP: "UP",
            ACTION_MOVE_DOWN: "DOWN",
            ACTION_SELECT_ITEM: "SELECT",
            ACTION_MOUSE_LEFT_CLICK: "CLICK",
            ACTION_SHOW_INFO: "INFO",
            ACTION_CONTEXT_MENU: "CONTEXT",
            ACTION_PREVIOUS_MENU: "BACK",
            ACTION_NAV_BACK: "NAV_BACK",
        }.get(aid, str(aid))

    def _home_row_state_for_log(self, control_id=None):
        try:
            fid = self._safe_focus_id() if control_id is None else int(control_id)
        except Exception:
            fid = -1
        row_idx = self._home_row_index_for_control(fid) if self._is_home_row_control(fid) else -1
        pos = -1
        size = -1
        label = ""
        rating_key = ""
        row_id = ""
        if row_idx >= 0:
            try:
                ctrl = self.getControl(fid)
                size = int(ctrl.size())
                pos = int(ctrl.getSelectedPosition())
                if size > 0 and pos >= 0:
                    li = ctrl.getSelectedItem()
                    label = _short_log_value(li.getLabel(), 80)
                    rating_key = _short_log_value(li.getProperty("PlexKM.RatingKey") or li.getProperty("ratingKey"), 40)
                    row_id = _short_log_value(li.getProperty("PlexKM.HomeRowId"), 60)
            except Exception:
                pass
        elif fid == MENU_ID:
            try:
                menu = self.getControl(MENU_ID)
                size = int(menu.size())
                pos = int(menu.getSelectedPosition())
                if size > 0 and pos >= 0:
                    li = menu.getSelectedItem()
                    label = _short_log_value(li.getLabel(), 80)
            except Exception:
                pass
        elif fid == WALL_ID:
            try:
                wall = self.getControl(WALL_ID)
                size = int(wall.size())
                pos = int(wall.getSelectedPosition())
                if size > 0 and pos >= 0:
                    li = wall.getSelectedItem()
                    label = _short_log_value(li.getLabel(), 80)
                    rating_key = _short_log_value(li.getProperty("PlexKM.RatingKey") or li.getProperty("ratingKey"), 40)
            except Exception:
                pass
        kind = "row" if row_idx >= 0 else ("menu" if fid == MENU_ID else ("wall" if fid == WALL_ID else "other"))
        return "fid=%s kind=%s row=%s pos=%s size=%s row_id=%s rating_key=%s label=%s" % (
            fid, kind, row_idx, pos, size, row_id, rating_key, label)

    def _home_reset_row_controls(self):
        try:
            for idx, cid in enumerate(HOME_ROW_IDS):
                try:
                    self.getControl(cid).reset()
                except Exception:
                    pass
                try:
                    self.clearProperty("PlexKM.Home.Row%d.Title" % idx)
                except Exception:
                    pass
            self._home_row_memory = {}
            self._home_row_items_cache = []
            self._home_visible_row_controls = []
            self._home_active_row = 0
            self._reset_row_anchor_scroll(HOME_ROW_ANCHOR_SCOPE, reason="home_rows_reset")
        except Exception:
            pass

    def _home_rendered_xml_rows_ready(self):
        """Return True when Home XML row controls still contain the cached Home widgets.

        Home rows (9410~9450) are separate from library recommendation rows
        (8410~8450), so they can remain populated while the user moves through
        sidebar library items.  Reusing them avoids rebuilding the large Home
        cache (often 20 rows / 400+ items) when the user returns to Home.
        """
        try:
            if not self._home_wall_ready or self._home_rows_cache is None:
                return False
            for cid in HOME_ROW_IDS:
                try:
                    if self.getControl(cid).size() > 0:
                        return True
                except Exception:
                    pass
        except Exception:
            pass
        return False

    def _home_reuse_rendered_xml_rows(self, reason=""):
        try:
            if not self._home_rendered_xml_rows_ready():
                return False
            total = len(self._home_rows_cache or [])
            self.wall_total = total
            self.wall_offset = total
            first_title = "홈"
            try:
                first = (self._home_rows_cache or [None])[0]
                if isinstance(first, dict):
                    first_title = first.get("row_title") or first_title
            except Exception:
                pass
            self._set_header("홈", first_title)
            try:
                first_ctrl = self.getControl(HOME_ROW_IDS[0])
                if first_ctrl.size() > 0:
                    try:
                        first_ctrl.selectItem(0)
                    except Exception:
                        pass
                    self._set_home_meta_from_item(first_ctrl.getListItem(0), reason=(reason or "home_rendered_reuse"))
            except Exception:
                pass
            if self._startup_full_compose_required_v1643():
                self._mark_startup_full_scene_composed_v1643(reason="home_rows_reuse")
            self._schedule_startup_atomic_release_v1619(reason="home_rows_reuse")
            _log("HOME_XML_ROWS_REUSE reason=%s rows_cached=%d controls_ready=1 no_rebuild=1" % (reason or "home_rendered_reuse", total))
            return True
        except Exception:
            _log("HOME_XML_ROWS_REUSE_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _home_presentation_guard_u5(self, entries):
        """Verify only locally displayed rows when file mtime changes elsewhere.

        Preserves cache correctness: any missing index, SQLite error, deadline,
        changed metadata/rating, or new schema fails closed (ordinary rebuild).
        No DB schema mutations and no network calls.
        """
        try:
            keys = sorted(set(str(k).split("\x1f")[-1] for k in entries if str(k).split("\x1f")[-1]))
            if not keys or len(keys) > 256:
                return ""
            dbp = self._profile_db_path()
            if not dbp or not os.path.isfile(dbp):
                return ""
            conn = sqlite3.connect(dbp, timeout=0.10)
            started = time.monotonic()
            limit = 0.24 if self._is_android_v2591() else 0.42
            try:
                conn.set_progress_handler(lambda: 1 if (time.monotonic() - started) > limit else 0, 1000)
                h = hashlib.sha256()
                marks = ",".join("?" for _ in keys)
                # All values are scoped to current Home rows, never a million-row scan.
                for table in ("items", "item_ratings", "cine21_matches", "item_genres", "item_countries", "item_studios", "watcha_ratings"):
                    if time.monotonic() - started > limit:
                        return ""
                    try:
                        # Do not read multi-kilobyte items.raw_json blobs for a
                        # small Home metadata/progress fingerprint.
                        if table == "items":
                            query = ("SELECT rating_key, plex_type, title, original_title, "
                                     "year, summary, duration, thumb, art, view_count, "
                                     "last_viewed_at, updated_at FROM items WHERE rating_key IN (" + marks + ")")
                        else:
                            query = "SELECT * FROM " + table + " WHERE rating_key IN (" + marks + ")"
                        rows = conn.execute(query, tuple(keys)).fetchall()
                    except sqlite3.OperationalError as exc:
                        if "no such table" in str(exc).lower():
                            rows = [("__TABLE_MISSING__",)]
                        else:
                            raise
                    h.update((table + ":" + str(len(rows)) + "\n").encode("ascii"))
                    for row in sorted((repr(tuple(x)) for x in rows)):
                        h.update(row.encode("utf-8", "replace"))
                        h.update(b"\n")
                return h.hexdigest()
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        except Exception:
            return ""

    def _home_render_xml_rows(self, rows_cache, reason=""):
        """Render Home widgets into XML horizontal list rows without changing the existing layout."""
        render_started_v2499 = _pkm_speed_ms()
        fast_enabled_v2499 = False
        fast_index_v2499 = {}
        home_index_v2500 = {}
        progress_map_v2499 = {}
        fast_hits_v2499 = 0
        fast_misses_v2499 = 0
        home_hits_v2500 = 0
        section_hits_v2500 = 0
        try:
            self._home_reset_row_controls()
            grouped = []
            current = []
            current_id = None
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            try:
                fast_enabled_v2499 = self._home_startup_snapshot_fast_enabled_v2499()
                if fast_enabled_v2499:
                    home_index_v2500 = self._home_persistent_render_cache_load_v2500()
                    fast_index_v2499 = self._home_runtime_snapshot_index_v2499()
                    progress_map_v2499 = self._home_runtime_progress_map_v2499_build(rows_cache)
            except Exception:
                fast_enabled_v2499 = False
                home_index_v2500 = {}
                fast_index_v2499 = {}
                progress_map_v2499 = {}

            # PKM_PATCH_ACTIVE v2591 uhd3_home_row_partial_native_bind_lazy_append
            # UHD3 pays heavily for 100+ native ListItems even when only ~6 cards
            # per rail are visible. Bind 8 per rail and retain the immutable full
            # row cache; RIGHT near the bound edge appends six more synchronously.
            # V2593 UHD hard-minimal: a 6-column 1080p rail needs only one
            # visible row at startup.  Keep the full immutable cache and append
            # six more only when RIGHT approaches the edge.
            _home_bind_cap_v2591 = 6 if self._is_android_v2591() else 0
            _rows_for_bind_v2591 = []
            for _entries_v2591 in grouped[:HOME_ROW_COUNT]:
                _rows_for_bind_v2591.extend(list(_entries_v2591 or [])[:_home_bind_cap_v2591 or len(_entries_v2591 or [])])
            self._home_lazy_fast_enabled_v2591 = bool(fast_enabled_v2499)
            self._home_lazy_home_index_v2591 = dict(home_index_v2500 or {})
            self._home_lazy_fast_index_v2591 = dict(fast_index_v2499 or {})
            self._home_lazy_progress_map_v2591 = dict(progress_map_v2499 or {})

            # V2499: complete persistent render snapshots already contain the
            # static rating/genre/certification truth. Only rows that cannot be
            # mapped exactly need the old visible-rating preload.
            slow_entries_v2499 = []
            if fast_enabled_v2499:
                for _entry_v2499 in list(_rows_for_bind_v2591 or []):
                    try:
                        _values_v2499 = tuple(_entry_v2499.get("row") if isinstance(_entry_v2499, dict) else ())
                        _key_v2499 = (str(_values_v2499[1] or "").strip(), str(_values_v2499[0] or "").strip()) if len(_values_v2499) > 1 else ("", "")
                        _home_key_v2500 = self._home_persistent_snapshot_key_v2500(_entry_v2499)
                        _home_hit_rec_v2500 = (home_index_v2500 or {}).get(_home_key_v2500) if _home_key_v2500 else None
                        _home_hit_v2500 = bool(isinstance(_home_hit_rec_v2500, dict))
                        if _home_hit_v2500 and str(_entry_v2499.get("row_type") or "") == "continue":
                            _current_poster_v2500 = str(_values_v2499[12] if len(_values_v2499) > 12 else "").strip()
                            _cached_poster_v2500 = str((_home_hit_rec_v2500 or {}).get("authority") or "").strip()
                            if _current_poster_v2500 and _cached_poster_v2500 and _current_poster_v2500 != _cached_poster_v2500:
                                _home_hit_v2500 = False
                        if (not _home_hit_v2500) and (not _key_v2499[0] or not _key_v2499[1] or _key_v2499 not in fast_index_v2499):
                            slow_entries_v2499.append(_entry_v2499)
                    except Exception:
                        slow_entries_v2499.append(_entry_v2499)
            else:
                slow_entries_v2499 = list(_rows_for_bind_v2591 or [])
            try:
                _startup_local_first_render_v2583 = bool(
                    getattr(self, "_startup_established_current_home_only_v2535", False)
                    and xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                    and xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") != "1"
                )
                if slow_entries_v2499 and _startup_local_first_render_v2583:
                    # V2583: startup cache misses may render with basic local row
                    # metadata. Never load bulk rating/canonical maps under splash.
                    _log("UHD3_STARTUP_SLOW_RATING_BYPASS_V2583 entries=%d reveal_first=1 focus_fill=1" % len(slow_entries_v2499))
                elif slow_entries_v2499:
                    self._preload_visible_row_ratings(slow_entries_v2499, reason="%s_home_xml_rows" % (reason or ""))
            except Exception:
                pass
            rendered_rows = 0
            rendered_items = 0
            _cast_prewarm_rows_v1339 = []
            for row_idx, entries in enumerate(grouped[:HOME_ROW_COUNT]):
                _cast_prewarm_row_v1339 = []
                ctrl = self.getControl(HOME_ROW_IDS[row_idx])
                _entries_render_v2591 = list(entries or [])[:_home_bind_cap_v2591 or len(entries or [])]
                try:
                    title0 = ""
                    if entries:
                        title0 = _display_library_title(entries[0].get("row_title", "") or "")
                    self.setProperty("PlexKM.Home.Row%d.Title" % row_idx, title0)
                except Exception:
                    pass
                cast_row_v2499 = []
                for item_idx, entry in enumerate(_entries_render_v2591):
                    li = None
                    if fast_enabled_v2499:
                        if home_index_v2500:
                            li = self._home_li_from_persistent_snapshot_v2500(entry, home_index_v2500, progress_map_v2499)
                            if li is not None:
                                home_hits_v2500 += 1
                        if li is None:
                            li = self._home_li_from_runtime_snapshot_v2499(entry, fast_index_v2499, progress_map_v2499)
                            if li is not None:
                                section_hits_v2500 += 1
                        if li is not None:
                            fast_hits_v2499 += 1
                        else:
                            fast_misses_v2499 += 1
                    if li is None:
                        li = self._li_from_row(
                            entry.get("row"),
                            row_title=_display_library_title(entry.get("row_title", "")),
                            row_type=entry.get("row_type", ""),
                            row_first=(item_idx == 0),
                            row_id=entry.get("row_id", ""),
                            row_start=0,
                            row_index=item_idx,
                        )
                    if li is not None:
                        cast_row_v2499.append(li)
                        try:
                            _cast_prewarm_row_v1339.append(li)
                        except Exception:
                            pass
                # HOME_CONTINUE_PROGRESS_ATOMIC_R20D:
                # Home XML intentionally hides every resume bar until
                # WidgetPosterReadyV1644=1. Sections already run V2716, but the
                # Home Continue rail did not, leaving valid ResumePercent values
                # invisible even after R20C corrected the active episode.
                # Run the existing progress-only poster gate before publishing the
                # Continue rail. The gate skips zero-progress/watched cards, so it
                # does not reinstate an all-poster Home viewport wait.
                try:
                    _home_row_type_r20d = str(
                        (_entries_render_v2591[0].get("row_type") if _entries_render_v2591 else "") or ""
                    )
                except Exception:
                    _home_row_type_r20d = ""
                if _home_row_type_r20d == "continue" and cast_row_v2499:
                    _progress_candidates_r20d = 0
                    _progress_ready_before_r20d = 0
                    for _li_r20d in list(cast_row_v2499 or []):
                        try:
                            _pct_r20d = _safe_int(_li_r20d.getProperty("PlexKM.ResumePercent"), 0)
                            _watched_r20d = str(_li_r20d.getProperty("PlexKM.IsWatched") or "") == "1"
                            if _pct_r20d > 0 and not _watched_r20d:
                                _progress_candidates_r20d += 1
                                if str(_li_r20d.getProperty("PlexKM.WidgetPosterReadyV1644") or "") == "1":
                                    _progress_ready_before_r20d += 1
                        except Exception:
                            pass
                    if _progress_candidates_r20d:
                        self._progress_overlay_poster_gate_v2716(
                            cast_row_v2499,
                            reason="HOME_CONTINUE_PROGRESS_ATOMIC_R20D"
                        )
                    _progress_ready_after_r20d = 0
                    for _li_r20d in list(cast_row_v2499 or []):
                        try:
                            if (
                                _safe_int(_li_r20d.getProperty("PlexKM.ResumePercent"), 0) > 0
                                and str(_li_r20d.getProperty("PlexKM.IsWatched") or "") != "1"
                                and str(_li_r20d.getProperty("PlexKM.WidgetPosterReadyV1644") or "") == "1"
                            ):
                                _progress_ready_after_r20d += 1
                        except Exception:
                            pass
                    _log("HOME_CONTINUE_PROGRESS_ATOMIC_R20D candidates=%d ready_before=%d ready_after=%d items=%d overlay_requires_poster_ready=1" % (
                        _progress_candidates_r20d, _progress_ready_before_r20d,
                        _progress_ready_after_r20d, len(cast_row_v2499 or [])
                    ))
                try:
                    ctrl.addItems(cast_row_v2499)
                except Exception:
                    for li in cast_row_v2499:
                        ctrl.addItem(li)
                rendered_items += len(cast_row_v2499)
                try:
                    _cast_prewarm_rows_v1339.append(_cast_prewarm_row_v1339)
                except Exception:
                    pass
                if ctrl.size() > 0:
                    try:
                        ctrl.selectItem(0)
                    except Exception:
                        pass
                    try:
                        self._home_visible_row_controls.append(HOME_ROW_IDS[row_idx])
                    except Exception:
                        pass
                    rendered_rows += 1
            self._home_row_items_cache = grouped
            self.wall_total = rendered_items
            self.wall_offset = rendered_items
            if rendered_rows > 0:
                # v106: Do not set focus to a row during Home construction.
                # The Home menu is the only initial focus; rows are entered by
                # the XML menu <onright>.  Selecting row0 here made Kodi report
                # ROW focus and then MENU focus immediately, leaving a stale
                # selected row visual that looked like double focus.
                try:
                    first_ctrl = self.getControl(HOME_ROW_IDS[0])
                    if first_ctrl.size() > 0:
                        self._set_home_meta_from_item(first_ctrl.getListItem(0), reason="%s_initial_meta" % (reason or "home_xml"))
                except Exception:
                    pass
                _log("HOME_XML_ROWS_INITIAL_FOCUS_SKIPPED reason=%s menu_initial=1 rows=%d" % (reason, rendered_rows))
            if fast_enabled_v2499:
                _render_ms_v2499 = _pkm_speed_ms() - render_started_v2499
                _coverage_v2499 = int(round((float(fast_hits_v2499) * 100.0) / float(max(1, fast_hits_v2499 + fast_misses_v2499))))
                self._home_startup_fastpath_stats_v2499 = {
                    "enabled": 1, "hits": int(fast_hits_v2499), "misses": int(fast_misses_v2499),
                    "coverage": int(_coverage_v2499), "slow_preload": len(slow_entries_v2499),
                    "render_ms": int(_render_ms_v2499),
                }
                _log("HOME_STARTUP_SNAPSHOT_FASTPATH_V2499 result=%s rows=%d items=%d hits=%d misses=%d coverage=%d slow_rating_rows=%d batch_additems=1 static_db_io=0 canonical_recompute=0 render_ms=%d" % (
                    "PASS" if fast_hits_v2499 > 0 and fast_misses_v2499 == 0 else "DEGRADED",
                    rendered_rows, rendered_items, fast_hits_v2499, fast_misses_v2499, _coverage_v2499,
                    len(slow_entries_v2499), _render_ms_v2499
                ))
                self._home_startup_fastpath_stats_v2500 = {
                    "enabled": 1, "home_hits": int(home_hits_v2500), "section_hits": int(section_hits_v2500),
                    "misses": int(fast_misses_v2499), "coverage": int(_coverage_v2499),
                    "render_ms": int(_render_ms_v2499), "persistent_entries": len(home_index_v2500 or {}),
                }
                _log("HOME_STARTUP_PERSISTENT_FASTPATH_V2500 result=%s rows=%d items=%d home_hits=%d section_fallback_hits=%d misses=%d coverage=%d persistent_entries=%d render_ms=%d" % (
                    "PASS" if fast_misses_v2499 == 0 and fast_hits_v2499 > 0 else ("WARMUP" if not home_index_v2500 else "DEGRADED"),
                    rendered_rows, rendered_items, home_hits_v2500, section_hits_v2500, fast_misses_v2499, _coverage_v2499,
                    len(home_index_v2500 or {}), _render_ms_v2499
                ))
            try:
                _store_home_v2500 = bool(
                    rendered_items > 0 and (
                        (not fast_enabled_v2499) or (not home_index_v2500) or fast_misses_v2499 > 0
                    )
                )
                if _store_home_v2500:
                    self._home_persistent_render_cache_store_v2500(rows_cache)
                elif rendered_items > 0 and home_index_v2500:
                    _log("HOME_PERSISTENT_RENDER_STORE_SKIP_V2500 reason=authority_match_full_hit entries=%d disk_write=0" % len(home_index_v2500))
            except Exception:
                pass
            if _home_bind_cap_v2591:
                _log("UHD3_HOME_PARTIAL_NATIVE_BIND_V2591 reason=%s rows=%d native_items=%d source_items=%d per_row_cap=%d lazy_chunk=6 ratings_firstpaint=0" % (
                    reason, rendered_rows, rendered_items, len(rows_cache or []), _home_bind_cap_v2591
                ))
            _log("HOME_XML_ROWS_RENDER reason=%s rows=%d items=%d source_rows=%d row_item_limit=%d stack_top=445 confined=1 structure=estuary_panel_rows_v107" % (reason, rendered_rows, rendered_items, len(rows_cache or []), HOME_ROW_ITEM_LIMIT))
            try:
                self._schedule_info_cast_prewarm_for_visible_rows_v1339(_cast_prewarm_rows_v1339, reason="%s_home_visible_widgets_v1339" % (reason or "home_render"))
            except Exception:
                pass
            self._home_row_block_metric_log(reason=(reason or "home_render") + "_rendered", focus_id=HOME_ROW_IDS[0] if rendered_rows else 0, scroll_index=0)
            return rendered_items
        except Exception:
            _log("HOME_XML_ROWS_RENDER_FAILED reason=%s err=%s" % (reason, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGERROR)
            return 0

    def _row_instant_jump_arm_r45(self, reason="", delay_ms=260):
        """R45: make the next Home/section row-grouplist focus change instant.

        A fresh sidebar ENTER resets the remembered row to the first one, but
        the row-stack grouplist (8298/8398/9298) still has its own 300ms
        scrolltime, so Kodi visibly glides through every intervening row when
        the user then presses RIGHT from a position scrolled far down. Arming
        this property makes the skin XML use scrolltime=0 for the next
        focus change, then this clears it again so normal up/down browsing
        keeps its smooth animation. The window is time-boxed (not cleared by
        the RIGHT press itself) because Kodi XML has no reliable "this one
        focus change only" hook; a short window after an explicit ENTER is a
        safe place to trade a little animation for no visible scroll-flash.

        R48: Kodi reads only the FIRST <scrolltime> tag (no condition
        support), so the R45 conditional scrolltime=0 made every up/down
        move instant. The row stacks now always slide (200ms, Plex style);
        this property instead fades the stack out (alpha 0, still processed
        so the grouplist keeps scrolling) while the ENTER bounce scrolls back
        to row 0, then PlexKM.Row.RevealR48 fades it back in.
        """
        try:
            token = int(time.time() * 1000)
            self._row_instant_jump_token_r45 = token
            for _w in (self, xbmcgui.Window(10000)):
                _w.setProperty("PlexKM.Row.InstantJumpR45", "1")
            _log("ROW_INSTANT_JUMP_ARM_R45 reason=%s token=%s delay_ms=%d" % (reason or "", token, delay_ms))
            def _clear():
                try:
                    xbmc.sleep(int(delay_ms or 260))
                    if getattr(self, "_row_instant_jump_token_r45", None) != token:
                        return
                    for _w2 in (self, xbmcgui.Window(10000)):
                        _w2.setProperty("PlexKM.Row.RevealR48", "1")
                        _w2.clearProperty("PlexKM.Row.InstantJumpR45")
                    _log("ROW_INSTANT_JUMP_CLEAR_R45 reason=%s token=%s" % (reason or "", token))
                    xbmc.sleep(260)
                    if getattr(self, "_row_instant_jump_token_r45", None) != token:
                        return
                    for _w2 in (self, xbmcgui.Window(10000)):
                        _w2.clearProperty("PlexKM.Row.RevealR48")
                except Exception:
                    pass
            _PKMHomeThreadV2151(target=_clear, name="PlexKMRowInstantJumpR45", daemon=True).start()
        except Exception:
            pass

    def _row_prescroll_bounce_r46(self, row_id, reason=""):
        """R46: show the first widget row right on ENTER, before RIGHT.

        _row_instant_jump_arm_r45 fixed the *animation* (no more visible
        glide), and selectItem(0) on the row control fixed *which item*
        gets selected once focus actually reaches it -- but Kodi only
        repositions a grouplist's own scroll when one of its children
        actually receives focus. Since a sidebar ENTER keeps real Kodi
        focus on the menu (RIGHT is what moves it into the row stack), the
        outer grouplist (8298/8398/9298) keeps showing wherever it was
        scrolled to from the *previous* visit until the user presses RIGHT.

        This bounces real focus onto the target row and straight back to
        the sidebar menu within the same handler -- call it only while
        _row_instant_jump_arm_r45's scrolltime=0 window is still open, so
        the bounce itself is instant and invisible. onFocus side effects
        are suppressed for the whole bounce (see _on_focus_impl_r26): the
        sidebar never really lost focus, so nothing about navigation state
        should change because of it.
        """
        try:
            row_id = int(row_id)
        except Exception:
            return
        try:
            for _w in (self, xbmcgui.Window(10000)):
                _w.setProperty("PlexKM.Row.PrescrollBounceR46", "1")
            self.setFocusId(row_id)
            self.setFocusId(MENU_ID)
            _log("ROW_PRESCROLL_BOUNCE_R46 reason=%s row=%s" % (reason or "", row_id))
        except Exception:
            pass
        finally:
            try:
                for _w in (self, xbmcgui.Window(10000)):
                    _w.clearProperty("PlexKM.Row.PrescrollBounceR46")
            except Exception:
                pass

    def _widget_focus_commit_ping_v2596(self):
        """Publish hero metadata once after UHD widget focus has settled."""
        try:
            if self._closing_event_v1841.is_set():
                return False
            with self._widget_focus_debounce_lock_v2596:
                self._widget_focus_posted_v2599 = False
                commit = self._widget_focus_commit_v2596
                self._widget_focus_commit_v2596 = None
            if not commit:
                return False
            token, target_fid = commit
            current_fid = int(self._safe_focus_id() or -1)
            if current_fid != int(target_fid) or not self._is_home_row_control(current_fid):
                _log("WIDGET_FOCUS_DEBOUNCE_STALE_DROP_V2596 token=%s target=%s current=%s meta=0" % (
                    token, target_fid, current_fid
                ))
                return False
            li = self._home_focused_item(current_fid)
            if li is None:
                return False
            # UHD rule: Info-art staging, trailer and cast prewarm are not visible
            # requirements for row movement.  Only cache/ListItem hero metadata is
            # committed, after the user has stopped moving.
            _meta_t0_v2600 = time.perf_counter()
            self._set_home_meta_from_item(li, reason="home_row_xml_nav")
            _r88_m1 = time.perf_counter()
            self._r155_rating_schedule(li, reason="widget_stable")
            _r88_m2 = time.perf_counter()
            _meta_ms_v2600 = (time.perf_counter() - _meta_t0_v2600) * 1000.0
            _stable_v2600 = 220 if self._is_android_v2591() else 0
            _cast_prime_v2607 = 0
            try:
                if self._is_android_v2591():
                    try:
                        _shield_prime_vnext = "tegra" in str(os.uname().release or "").lower()
                    except Exception:
                        _shield_prime_vnext = False
                    if _shield_prime_vnext:
                        _cast_prime_v2607 = self._schedule_info_cast_prewarm_around_focus(
                            li, reason="shield_stable_widget_cast_vnext"
                        )
                        _log("SHIELD_CAST_FOCUS_PREWARM_VNEXT armed=%d stability_ms=120 worker_owns_gui=0" % (
                            int(_cast_prime_v2607 or 0)))
                    else:
                        # Preserve original UHD3 and other Android navigation policy.
                        _cast_prime_v2607 = 0
                else:
                    # Desktop/UHD proxy gets the same intent through the stable-focus
                    # coalescer below; rapid row movement cancels before network work.
                    _cast_prime_v2607 = self._schedule_info_cast_prewarm_around_focus(
                        li, reason="widget_portrait_prime_v2607"
                    )
            except Exception:
                _cast_prime_v2607 = 0
            _log("WIDGET_FOCUS_COMMIT_V2607 token=%s focus=%s stable_ms=%d meta_ms=%.1f art_preload=0 trailer=0 cast_prime=%d first_frame_block=0" % (
                token, current_fid, _stable_v2600, _meta_ms_v2600, int(_cast_prime_v2607 or 0)
            ))
            try:
                _log("WIDGET_COMMIT_BREAKDOWN_R88 focus=%s meta_item_ms=%.1f rating_sched_ms=%.1f cast_prime_ms=%.1f" % (
                    current_fid, (_r88_m1 - _meta_t0_v2600) * 1000.0, (_r88_m2 - _r88_m1) * 1000.0,
                    (time.perf_counter() - _r88_m2) * 1000.0
                ))
            except Exception:
                pass
            try:
                pkm_uhd_diag_v2600.event(
                    "WIDGET_META", extra="focus=%s meta_ms=%.1f stable_ms=%d" % (current_fid, _meta_ms_v2600, _stable_v2600)
                )
            except Exception:
                pass
            return True
        except Exception:
            _log("WIDGET_FOCUS_DEBOUNCE_COMMIT_FAILED_V2596 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            return False

    def _schedule_widget_focus_commit_v2596(self, control_id, settle_ms=80):
        """V2600: native focus first; Android coalesces metadata only.

        Kodi XML/grouplist remains the sole focus mover. On weak Android the
        visual focus moves immediately, while decorative hero metadata is
        committed only after the final row stays stable for 140 ms. Desktop
        retains V2599's next-GUI zero-delay behavior.
        """
        try:
            fid = int(control_id or 0)
            if not self._is_home_row_control(fid):
                return False
            self._widget_focus_token_v2596 = int(getattr(self, "_widget_focus_token_v2596", 0) or 0) + 1
            token = int(self._widget_focus_token_v2596)
            with self._widget_focus_debounce_lock_v2596:
                self._widget_focus_commit_v2596 = (token, fid)
                self._widget_focus_pending_v2596 = None

            if not self._is_android_v2591():
                with self._widget_focus_debounce_lock_v2596:
                    if self._widget_focus_posted_v2599:
                        return True
                    self._widget_focus_posted_v2599 = True
                _log("WIDGET_FOCUS_POST_V2600 token=%s focus=%s stable_ms=0 worker=0 platform=desktop meta_now=0" % (token, fid))
                try:
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    with self._widget_focus_debounce_lock_v2596:
                        self._widget_focus_posted_v2599 = False
                    return False
                return True

            # Android: one small coalescer thread for metadata only. Repeated
            # keys replace the token; no Kodi focus/position call occurs here.
            with self._widget_focus_debounce_lock_v2596:
                if self._widget_focus_posted_v2599:
                    _log("WIDGET_META_REPLACE_V2600 token=%s focus=%s stable_ms=120 xml_focus_only=1" % (token, fid))
                    return True
                self._widget_focus_posted_v2599 = True
            _log("WIDGET_META_ARM_V2600 token=%s focus=%s stable_ms=120 xml_focus_only=1" % (token, fid))

            def _coalesce_v2600():
                posted_v2600 = False
                try:
                    while not self._closing_event_v1841.is_set():
                        with self._widget_focus_debounce_lock_v2596:
                            pending_v2600 = self._widget_focus_commit_v2596
                        if not pending_v2600:
                            break
                        watch_token_v2600, _watch_fid_v2600 = pending_v2600
                        if self._closing_event_v1841.wait(0.120):
                            break
                        with self._widget_focus_debounce_lock_v2596:
                            latest_v2600 = self._widget_focus_commit_v2596
                        if not latest_v2600:
                            break
                        if int(latest_v2600[0]) != int(watch_token_v2600):
                            continue
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        posted_v2600 = True
                        return
                except Exception:
                    pass
                finally:
                    if not posted_v2600:
                        try:
                            with self._widget_focus_debounce_lock_v2596:
                                self._widget_focus_posted_v2599 = False
                        except Exception:
                            pass

            _PKMHomeThreadV2151(target=_coalesce_v2600, name="PKMWidgetMetaV2600", daemon=True).start()
            return True
        except Exception:
            return False

    def _row_reentry_property_prefix(self, scope):
        if scope == SECTION_ROW_ANCHOR_SCOPE:
            return "PlexKM.Section"
        if scope == HOME_ROW_ANCHOR_SCOPE:
            return "PlexKM.Home"
        return ""

    def _clear_row_reentry_memory(self, scope=None, reason=""):
        """Clear remembered widget row for same-menu LEFT->RIGHT re-entry."""
        try:
            scopes = (HOME_ROW_ANCHOR_SCOPE, SECTION_ROW_ANCHOR_SCOPE) if scope is None else (scope,)
            if not hasattr(self, "_menu_reentry_last_row"):
                self._menu_reentry_last_row = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
            for sc in scopes:
                self._menu_reentry_last_row[sc] = 0
                prefix = self._row_reentry_property_prefix(sc)
                if prefix:
                    self.clearProperty("%s.LastFocusRow" % prefix)
                    xbmcgui.Window(10000).clearProperty("%s.LastFocusRow" % prefix)
            _log("ROW_REENTRY_CLEAR scope=%s reason=%s" % (scope or "all", reason or ""))
        except Exception:
            pass

    def _remember_row_reentry_focus(self, control_id, reason=""):
        """Remember current Home/section recommendation row without moving focus.

        Kodi XML still owns LEFT/RIGHT/UP/DOWN.  This only exposes a stable
        Window property that XML <onright> can use when returning from the
        sidebar to the same menu, matching Plex behavior.
        """
        try:
            cid = int(control_id)
        except Exception:
            return
        try:
            if cid in SECTION_RECOMMEND_ALL_ROW_IDS:
                scope = SECTION_ROW_ANCHOR_SCOPE
                valid_rows = self._visible_row_controls_for_scope(scope)
            elif cid in HOME_ROW_IDS:
                scope = HOME_ROW_ANCHOR_SCOPE
                valid_rows = self._visible_row_controls_for_scope(scope)
            else:
                return
            if cid not in valid_rows:
                return
            if not hasattr(self, "_menu_reentry_last_row"):
                self._menu_reentry_last_row = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
            self._menu_reentry_last_row[scope] = cid
            prefix = self._row_reentry_property_prefix(scope)
            if prefix:
                self.setProperty("%s.LastFocusRow" % prefix, str(cid))
                xbmcgui.Window(10000).setProperty("%s.LastFocusRow" % prefix, str(cid))
            _log("ROW_REENTRY_REMEMBER scope=%s row=%s reason=%s rows=%s" % (scope, cid, reason or "", ",".join(str(x) for x in valid_rows)))
        except Exception:
            pass

    def _pkm_overlay_retire_for_target_v2479(self, target="", reason=""):
        """Retire Info/Actor only after a full-scene target is already prepared.

        Actor Profile is layered over its parent Info, so the target may be
        completely bound underneath while Actor remains the visible source.
        This helper is called only at the final destination commit boundary.
        """
        target = str(target or "")
        try:
            win = xbmcgui.Window(10000)
            actor_active = bool(self._actor_profile_is_active_v2454())
            info_active = bool(
                self.getProperty("PlexKM.Info.InlineActive") == "1"
                or win.getProperty("PlexKM.Info.InlineActive") == "1"
            )
            if target in ("info", "actor_profile"):
                return False
            if not actor_active and not info_active:
                return False
            source = "actor_profile" if actor_active else "info"
            token = self._pkm_swap_settle_v2479(
                source, target or "unknown", reason="overlay_target_ready:%s" % (reason or ""), wait_ms=16
            )
            # Keep Actor visible while its parent Info properties are retired;
            # then clear Actor in the same GUI callback so no intermediate base
            # surface can be rendered.
            if info_active:
                try:
                    self._clear_inline_info(reason="v2479_target_commit:%s" % (reason or target))
                except Exception:
                    pass
            if actor_active:
                self._actor_profile_active_v2454 = False
                self._actor_profile_set_prop_v2454("Active", "")
                _log("ACTOR_PROFILE_TARGET_FIRST_RETIRE_V2479 target=%s reason=%s parent_info_retired=%d" % (
                    target or "", reason or "", 1 if info_active else 0
                ))
            self._pkm_swap_finish_v2479(
                token, source, target or "unknown", reason="overlay_retire:%s" % (reason or "")
            )
            return True
        except Exception:
            _log("PKM_OVERLAY_RETIRE_FAILED_V2479 target=%s reason=%s err=%s" % (
                target or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _home_atomic_commit_v2479(self, source="", reason=""):
        """Expose already-populated Home controls and retire prior base mode once."""
        try:
            source = str(source or self._pkm_surface_mode_v2479() or "unknown")
            # R18: Home focus(R143)/ENTER(R155) call _show_home_wall directly and
            # never reach the old menu-focus path that retired Info/Actor via
            # _info_sidebar_hold_release_v2387(home_ready_*). Retire the overlay
            # here, at the Home commit boundary, so Info cannot stay on top.
            if source in ("info", "actor_profile"):
                retired_r18 = False
                try:
                    retired_r18 = bool(self._pkm_overlay_retire_for_target_v2479(
                        "home", reason="home_commit_r18:%s" % (reason or "")
                    ))
                except Exception:
                    retired_r18 = False
                try:
                    self._info_sidebar_hold_v2387 = None
                    self._info_clear_property_all("PlexKM.Info.SidebarHoldV2387")
                except Exception:
                    pass
                _log("HOME_COMMIT_OVERLAY_RETIRE_R18 source=%s retired=%d reason=%s" % (
                    source, 1 if retired_r18 else 0, reason or ""
                ))
                source = str(self._pkm_surface_mode_v2479() or "unknown")
            token = ""
            if source != "home":
                token = self._pkm_swap_settle_v2479(
                    source, "home", reason="home_target_ready:%s" % (reason or ""), wait_ms=16
                )
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.setProperty("PlexKM.Window.HomeLayout", "1")
                target.setProperty("PlexKM.Window.IsHome", "1")
                target.clearProperty("PlexKM.Window.IsSectionRecommend")
                target.clearProperty("PlexKM.Window.IsSectionWall")
                target.clearProperty("PlexKM.Window.IsSectionCategory")
            self._home_target_hidden_v2479 = False
            if bool(getattr(self, "_home_wall_reset_pending_r54", False)):
                self._home_wall_reset_pending_r54 = False
                try:
                    if str(getattr(self, "active_section_id", "") or "") == "__home__":
                        self.getControl(WALL_ID).reset()
                    _log("HOME_WALL_RESET_AT_COMMIT_R54 reason=%s" % (reason or ""))
                except Exception:
                    pass
            self._set_published_section_id_v2121("", reason="home_commit_v2479:%s" % (reason or ""))
            if token:
                self._pkm_swap_finish_v2479(token, source, "home", reason="home_mode_commit:%s" % (reason or ""))
            # R38: the swap above only hides Search visually; its active state
            # stayed set under Home, so a later Back was swallowed by the Search
            # close handler ("Search -> Info -> Home -> Back" felt tangled).
            if source == "search" and win.getProperty("PlexKM.Search.Closing") != "1":
                try:
                    if (bool(getattr(self, "_search_inline_active", False))
                            or self.getProperty("PlexKM.Search.InlineActive") == "1"
                            or win.getProperty("PlexKM.Search.InlineActive") == "1"):
                        self._search_info_sidebar_retire_search_v2284(reason="home_commit_r38")
                        _log("HOME_COMMIT_SEARCH_RETIRE_R38 reason=%s" % (reason or ""))
                except Exception:
                    pass
            _log("HOME_TARGET_FIRST_COMMIT_V2479 source=%s reason=%s controls_ready=1 one_frame=1" % (source, reason or ""))
            return True
        except Exception:
            self._home_target_hidden_v2479 = False
            _log("HOME_TARGET_FIRST_COMMIT_FAILED_V2479 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _home_summary_line_count_v2240(self, text):
        """Estimate the actual Home synopsis line count (1..3) using the same
        720px/NotoSansKR width model as the v2179 truncator.  This is display
        geometry only; it performs no font/PIL work and no network I/O.
        """
        try:
            value = " ".join((text or "").replace("\r", " ").replace("\n", " ").split())
            if not value:
                return 0
            line_limit = 27600

            def _cw(ch):
                if not ch:
                    return 0
                if ch.isspace():
                    return 225
                if unicodedata.east_asian_width(ch) in ("W", "F"):
                    return 920
                if ch in ".,'`":
                    return 300
                if ch in "()[]{}":
                    return 360
                if ch in "!?:;":
                    return 360
                if ch in "·/\\|-_":
                    return 500
                if "A" <= ch <= "Z":
                    return 620
                if "a" <= ch <= "z":
                    return 560
                if "0" <= ch <= "9":
                    return 570
                cat = unicodedata.category(ch)
                if cat.startswith("P"):
                    return 500
                return 600

            lines = 1
            used = 0
            for word in value.split(" "):
                if not word:
                    continue
                ww = sum(_cw(ch) for ch in word)
                sw = 225 if used else 0
                if ww <= line_limit:
                    if used and used + sw + ww > line_limit:
                        lines += 1
                        used = ww
                    else:
                        used += sw + ww
                else:
                    if used:
                        lines += 1
                        used = 0
                    for ch in word:
                        cw = _cw(ch)
                        if used and used + cw > line_limit:
                            lines += 1
                            used = 0
                        used += cw
                if lines >= 3:
                    return 3
            return max(1, min(3, lines))
        except Exception:
            return 3 if len(str(text or "")) > 70 else (2 if len(str(text or "")) > 30 else 1)

    def _home_db_content_rating_value_v1804(self, rating_key, parent_rating_key="", grandparent_rating_key="", plex_type=""):
        """Return the canonical localized content rating from the local raw item index.

        Uses the same inheritance policy as genre metadata so every Home,
        recommendation, library and hidden A/B-bank ListItem receives identical
        age-rating metadata before it can be published or focused.
        """
        ptype = str(plex_type or "").strip().lower()
        rk = str(rating_key or "").strip()
        parent = str(parent_rating_key or "").strip()
        grandparent = str(grandparent_rating_key or "").strip()
        if ptype == "episode":
            candidates = (grandparent, parent, rk)
        elif ptype == "season":
            candidates = (parent, grandparent, rk)
        else:
            candidates = (rk, grandparent, parent)
        ordered, seen = [], set()
        for key in candidates:
            if key and key not in seen:
                seen.add(key)
                ordered.append(key)
        if not ordered:
            return ""
        try:
            cache = getattr(self, "_home_db_content_rating_cache_v1804", None)
            if cache is None:
                cache = {}
                self._home_db_content_rating_cache_v1804 = cache
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""
            conn = None
            try:
                for source_key in ordered:
                    if source_key in cache:
                        value = cache.get(source_key) or ""
                    else:
                        if conn is None:
                            conn = _pkm_ro_connect(dbp, timeout=2.0)
                        row = conn.execute("SELECT raw_json FROM items WHERE rating_key=? LIMIT 1", (source_key,)).fetchone()
                        raw = row[0] if row else ""
                        value = ""
                        if raw:
                            try:
                                node = json.loads(raw) if isinstance(raw, str) else raw
                                if isinstance(node, dict):
                                    value = pkm_info_data.localize_content_rating(
                                        node.get("contentRating") or node.get("content_rating") or node.get("mpaa") or ""
                                    )
                            except Exception:
                                value = ""
                        cache[source_key] = value
                    if value:
                        if source_key != rk:
                            _log("SECTION_CONTENT_RATING_INHERIT_V1804 rating_key=%s source_key=%s type=%s content_rating=%s" % (
                                rk, source_key, ptype or "unknown", value
                            ))
                        return value
                return ""
            finally:
                if conn is not None:
                    conn.close()
        except Exception:
            _log("SECTION_CONTENT_RATING_DB_READ_FAILED_V1804 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return ""

    def _home_db_year_value_v1809(self, rating_key, parent_rating_key="", grandparent_rating_key="", plex_type=""):
        """Return the same canonical year used by Home/section cards.

        Episode Info can be opened from an episode-rail ListItem that is more
        compact than the Home/section ListItem.  Resolve the episode first and
        then its show/season parents so the visible Info metadata row never
        loses a year that is already present on Home.
        """
        ptype = str(plex_type or "").strip().lower()
        rk = str(rating_key or "").strip()
        parent = str(parent_rating_key or "").strip()
        grandparent = str(grandparent_rating_key or "").strip()
        if ptype == "episode":
            candidates = (rk, grandparent, parent)
        elif ptype == "season":
            candidates = (rk, parent, grandparent)
        else:
            candidates = (rk, grandparent, parent)
        ordered, seen = [], set()
        for key in candidates:
            if key and key not in seen:
                seen.add(key); ordered.append(key)
        if not ordered:
            return ""
        try:
            cache = getattr(self, "_home_db_year_cache_v1809", None)
            if cache is None:
                cache = {}; self._home_db_year_cache_v1809 = cache
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""
            conn = None
            try:
                for source_key in ordered:
                    if source_key in cache:
                        value = cache.get(source_key) or ""
                    else:
                        if conn is None:
                            conn = _pkm_ro_connect(dbp, timeout=2.0)
                        row = conn.execute("SELECT year, raw_json FROM items WHERE rating_key=? LIMIT 1", (source_key,)).fetchone()
                        value = str((row[0] if row else "") or "").strip()
                        if not value and row and row[1]:
                            try:
                                node = json.loads(row[1]) if isinstance(row[1], str) else row[1]
                                if isinstance(node, dict):
                                    value = str(node.get("year") or "").strip()
                            except Exception:
                                value = ""
                        cache[source_key] = value
                    if value:
                        return value
                return ""
            finally:
                if conn is not None:
                    conn.close()
        except Exception:
            _log("INFO_YEAR_DB_READ_FAILED_V1809 rating_key=%s err=%s" % (rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return ""

    def _home_titles_for_meta(self, plex_type, title, show_title, episode):
        return pkm_info_data.home_titles_for_meta(plex_type, title, show_title, episode)

    def _home_meta_line(self, plex_type, show_title, season, episode, year, duration, content_rating, rating, added_at=""):
        return pkm_info_data.home_meta_line(plex_type, show_title, season, episode, year, duration, content_rating, rating, added_at)

    def _home_meta_line_base_v2291(self, plex_type, season, episode, year, duration):
        """Home/Section hero metadata excluding age certification."""
        parts = []
        if str(plex_type or "").lower() == "episode":
            values = (pkm_info_data.home_episode_code_text(season, episode), year, duration)
        else:
            values = (year, duration)
        for value in values:
            text = str(value or "").strip()
            if text:
                parts.append(text)
        return "   ".join(parts)

    def _home_meta_props_from_node(self, node, rating_key="", reason="", request_label=""):
        """Build cached metadata props from a Plex metadata node.

        v209: keep this parser in one place so sparse Plex responses can be
        detected and retried without caching an empty metadata result.
        """
        plex_type = node.get("type") or ""
        title = node.get("title") or ""
        summary = node.get("summary") or ""
        year = node.get("year") or ""
        premiered = node.get("originallyAvailableAt") or node.get("premiered") or ""
        added_at = node.get("addedAt") or premiered or ""
        duration_raw = node.get("duration") or ""
        view_offset = node.get("viewOffset") or ""
        duration = self._duration_text(duration_raw)
        play_button_label = self._play_button_label(view_offset, duration_raw, "")
        remaining_text, remaining_icon = self._remaining_time_props(duration_raw, view_offset)
        content_rating = pkm_info_data.localize_content_rating(node.get("contentRating") or "")
        rating = node.get("rating") or node.get("audienceRating") or ""
        genre = _join_tags(node, "Genre") or ""
        director = _join_tags(node, "Director") or ""
        show_title = node.get("grandparentTitle") or node.get("parentTitle") or ""
        season = node.get("parentIndex") or ""
        episode = node.get("index") or ""
        # v718: For TV episodes, the Home hero background must stay on the
        # show-level 16:9 fanart.  Plex episode metadata can expose the season
        # background in `art` while the DB/list row already has the correct
        # grandparent/show art.  In v717 the async enrich worker overwrote
        # /library/metadata/<show>/art with /library/metadata/<season>/art
        # a few milliseconds after the correct initial META_SYNC, so the Home
        # fanart disappeared again for items such as 참교육.
        # This is display-data preparation only; it does not touch focus,
        # navigation, playback, Back, or window flow.
        if plex_type == "episode":
            art = _plex_art(node.get("grandparentArt") or node.get("art") or node.get("parentArt"), width=1920, height=1080)
        else:
            art = _plex_art(node.get("art") or node.get("parentArt") or node.get("grandparentArt"), width=1920, height=1080)
        # v229: episodes in Continue Watching/Home must keep the TV-show poster.
        # Plex metadata often returns an episode still in `thumb`; using that during
        # enrich/update_visual made the poster briefly appear correctly and then
        # flip back to the episode thumbnail.  Prefer grandparent/show poster for
        # episodes everywhere the wall/Info ListItem art is updated.
        if plex_type == "episode":
            thumb = _plex_art(node.get("grandparentThumb") or node.get("parentThumb") or node.get("thumb"), width=720, height=1080)
        else:
            thumb = _plex_art(node.get("thumb") or node.get("parentThumb") or node.get("grandparentThumb"), width=720, height=1080)
        hero_title, episode_title = self._home_titles_for_meta(plex_type, title, show_title, episode)
        cast_slots = _extract_cast_slots(node, max_count=8)
        director_line = self._person_list_display_text(director) if plex_type == "movie" else ""
        props = {
            "Title": hero_title,
            "TitleDisplay": self._title_display_text(hero_title),
            "EpisodeTitle": episode_title,
            "ShowTitle": show_title,
            "Season": season,
            "Episode": episode,
            "ParentRatingKey": node.get("parentRatingKey") or "",
            "GrandparentRatingKey": node.get("grandparentRatingKey") or "",
            "Year": year,
            "Premiered": premiered,
            "Summary": summary,
            "SummaryDisplay": self._home_summary_display_text_v2179(summary),
            "SummaryLineCount": str(self._home_summary_line_count_v2240(self._home_summary_display_text_v2179(summary))),
            "Duration": duration_raw,
            "DurationText": duration,
            "ViewOffset": view_offset,
            "RemainingText": remaining_text,
            "RemainingIcon": remaining_icon,
            "PlayButtonLabel": play_button_label,
            "ContentRating": content_rating,
            # v1570: mark contentRating parsed from the current PMS metadata
            # node. Home rows/local DB caches can contain an older or differently
            # normalized value; only this marker proves that the displayed rating
            # came from /library/metadata/<current ratingKey>.
            "ContentRatingPMSVerified": "1",
            "ContentRatingVerifiedRatingKey": str(node.get("ratingKey") or rating_key or "").strip(),
            "Rating": rating,
            "ImdbRating": self._home_imdb_rating_value(rating) if plex_type == "movie" else "",
            "TmdbRating": self._home_tmdb_rating_value(rating) if plex_type != "movie" else "",
            "Genre": genre,
            "GenreLine": self._genre_display_text(genre),
            "Director": director,
            "DirectorLine": director_line,
            "DirectorLineUseOpenSans": "1" if self._text_has_cyrillic(director_line) else "0",
            "Cast": _join_tags(node, "Role") or "",
            "CastSlots": cast_slots,
            "MetaLine": self._home_meta_line(plex_type, show_title, season, episode, year, duration, content_rating, rating if plex_type == "movie" else "", added_at),
            "MetaLineBaseV2291": self._home_meta_line_base_v2291(plex_type, season, episode, year, duration),
            "PlexType": plex_type,
        }
        if art:
            props["Fanart"] = art
        if thumb:
            props["Poster"] = thumb
        # A valid Plex metadata response may have only title/year/art, but for
        # Info view that is not enough. Treat it as sparse and retry before
        # caching, otherwise InfoLoaded=1 freezes an empty detail screen.
        props["_Sparse"] = not self._meta_props_useful(props)
        props["_RequestLabel"] = request_label or "primary"
        props["_SourceRatingKey"] = node.get("ratingKey") or rating_key or ""
        return props

    def _set_home_hero_body_ready_v2251(self, rating_key, ready, reason=""):
        """Publish the Home genre/rating/summary body as one visual transaction.

        The focused ListItem can already contain a plot while show-level genre/rating
        arrives a few milliseconds later from Plex.  Kodi grouplists then visibly
        reflow the plot card.  V2251 keeps that body hidden while enrichment is
        pending and releases it only after all final properties have been committed.
        This is property gating only; it does not own directional focus/navigation.
        """
        try:
            rk = str(rating_key or "").strip()
            win = xbmcgui.Window(10000)
            current = str(win.getProperty("PlexKM.Home.RatingKey") or "").strip()
            if rk and current and current != rk:
                return False
            if ready:
                win.setProperty("PlexKM.Home.HeroBodyReadyV2251", "1")
                if not rk or str(win.getProperty("PlexKM.Home.HeroBodyPendingRatingKeyV2251") or "") == rk:
                    win.clearProperty("PlexKM.Home.HeroBodyPendingRatingKeyV2251")
            else:
                # v2264: visual gating was retired. Keep the legacy property ready
                # even if an old call site asks for HOLD, so cached enrichment can
                # never strand the Home body invisible.
                win.setProperty("PlexKM.Home.HeroBodyReadyV2251", "1")
                win.clearProperty("PlexKM.Home.HeroBodyPendingRatingKeyV2251")
            _log("HOME_HERO_BODY_%s_V2251 rating_key=%s reason=%s" % (
                "RELEASE" if ready else "HOLD_BYPASS_V2264", rk or current or "", reason or ""
            ))
            return True
        except Exception:
            return False

    def _home_focus_hotpath_v2386(self, reason=""):
        """True for Home/section navigation paths that must remain I/O-free.

        Kodi XML owns directional movement. These reasons are visual focus/scene
        publication callbacks, so they may only consume already prepared memory or
        ListItem properties; they must never start Plex metadata repair.
        """
        try:
            r = str(reason or "")
            if r in (
                "home_xml_focus", "home_row_xml_nav", "wall_focus", "wall_xml_nav",
                "menu_focus", "search_fixed_focus", "SECTION_CACHE_RESTORE",
                "home_already_rendered", "section_recommend_already",
                "section_recommend_initial",
            ):
                return True
            return r.startswith((
                "index_jump:", "home_row_select", "capture_v1619:",
                "atomic_v1619:", "section_recommend_",
            ))
        except Exception:
            return True

    def _start_home_meta_enrich(self, rating_key, reason="", force_rating_refresh=False):
        try:
            rating_key = str(rating_key or "")
            if self._home_focus_hotpath_v2386(reason):
                _log("HOME_META_ENRICH_NAV_SUPPRESS_V2386 rating_key=%s reason=%s network=0 db=0 focus_write=0" % (
                    rating_key, reason or ""
                ))
                return
            nav_reason_v1837 = str(reason or "") in (
                "wall_focus", "wall_xml_nav", "SECTION_CACHE_RESTORE"
            )
            if nav_reason_v1837:
                self._home_meta_nav_generation_v1837 = int(
                    getattr(self, "_home_meta_nav_generation_v1837", 0) or 0
                ) + 1
                generation_v1837 = self._home_meta_nav_generation_v1837

                def _settled_wall_meta_v1837():
                    try:
                        if xbmc.Monitor().waitForAbort(0.35):
                            return
                        if generation_v1837 != int(
                            getattr(self, "_home_meta_nav_generation_v1837", 0) or 0
                        ):
                            return
                        win_v1837 = xbmcgui.Window(10000)
                        if str(win_v1837.getProperty("PlexKM.Home.RatingKey") or "") != rating_key:
                            return
                        self._start_home_meta_enrich(
                            rating_key,
                            reason="wall_focus_settled_v1837",
                            force_rating_refresh=force_rating_refresh,
                        )
                    except Exception:
                        pass

                thread_v1837 = _PKMHomeThreadV2151(target=_settled_wall_meta_v1837, daemon=True)
                thread_v1837.daemon = True
                thread_v1837.start()
                return
            cached_entry = self._home_meta_enrich_cache.get(rating_key) if rating_key else None
            rating_verified_exact = bool(
                isinstance(cached_entry, dict)
                and str(cached_entry.get("ContentRatingPMSVerified") or "") == "1"
                and str(cached_entry.get("ContentRatingVerifiedRatingKey") or "") == rating_key
            )
            if (not rating_key or rating_key in self._home_meta_enriching
                    or (cached_entry and (not force_rating_refresh or rating_verified_exact))):
                return
            try:
                fail_until = float(self._home_meta_enrich_fail_until.get(rating_key, 0) or 0)
            except Exception:
                fail_until = 0
            if fail_until and time.time() < fail_until:
                _log("HOME_META_ENRICH_SKIP rating_key=%s reason=recent_failure source=%s" % (rating_key, reason), xbmc.LOGDEBUG)
                return
            self._home_meta_enriching.add(rating_key)

            def _worker():
                remote_lock_v1837 = getattr(self, "_home_meta_remote_lock_v1837", None)
                remote_lock_acquired_v1837 = False
                try:
                    if remote_lock_v1837 is not None:
                        remote_lock_acquired_v1837 = remote_lock_v1837.acquire(False)
                        if not remote_lock_acquired_v1837:
                            _log("HOME_META_ENRICH_SKIP_V1837 rating_key=%s reason=remote_request_busy source=%s" % (
                                rating_key, reason
                            ), xbmc.LOGDEBUG)
                            return
                    start = time.time()
                    props = None
                    for request_label, params, timeout in (
                        ("primary", {"includeGuids": 0}, 2),
                        ("retry_include_guids", {"includeGuids": 1}, 6),
                        ("retry_rich", {"includeGuids": 1, "includeCollections": 1, "includeConcerts": 1, "includeExternalMedia": 1}, 6),
                    ):
                        try:
                            win = xbmcgui.Window(10000)
                            if win.getProperty("PlexKM.Home.RatingKey") and win.getProperty("PlexKM.Home.RatingKey") != rating_key:
                                _log("HOME_META_ENRICH_SKIP rating_key=%s reason=focus_changed current=%s source=%s" % (
                                    rating_key, win.getProperty("PlexKM.Home.RatingKey"), reason), xbmc.LOGDEBUG)
                                return
                        except Exception:
                            pass
                        try:
                            root = core.plex_request_xml(
                                "/library/metadata/%s" % rating_key,
                                params=params,
                                timeout=timeout,
                                log_failures=False
                            )
                        except Exception as e:
                            self._home_meta_enrich_fail_until[rating_key] = time.time() + 20.0
                            _log("HOME_META_ENRICH_SKIP rating_key=%s request=%s reason=%s error=%s" % (
                                rating_key, request_label, reason, _short_log_value(str(e), 160)), xbmc.LOGINFO)
                            return
                        node = _first_metadata_node(root)
                        if node is None:
                            continue
                        props = self._home_meta_props_from_node(node, rating_key=rating_key, reason=reason, request_label=request_label)
                        try:
                            if (node.get("type") or "") == "episode":
                                show_key = str(node.get("grandparentRatingKey") or "").strip()
                                if show_key:
                                    show_root = core.plex_request_xml(
                                        "/library/metadata/%s" % show_key,
                                        params={"includeGuids": 1},
                                        timeout=timeout,
                                        log_failures=False
                                    )
                                    show_node = _first_metadata_node(show_root)
                                    if show_node is not None:
                                        show_props = self._home_meta_props_from_node(show_node, rating_key=show_key, reason=reason, request_label="episode_show_%s" % request_label)
                                        props = self._merge_episode_with_show_metadata_props(props, show_props, reason=reason)
                        except Exception:
                            _log("INFO_EPISODE_SHOW_MERGE_PLEX_FAILED rating_key=%s request=%s err=%s" % (
                                rating_key, request_label, traceback.format_exc().replace(chr(10), " | ")
                            ), xbmc.LOGWARNING)
                        if not props.get("_Sparse"):
                            break
                        _log("HOME_META_ENRICH_SPARSE rating_key=%s request=%s title=%s reason=%s" % (
                            rating_key, request_label, _short_log_value(props.get("Title") or "", 80), reason), xbmc.LOGINFO)

                    if not props:
                        return

                    if props.get("_Sparse"):
                        canonical = self._find_canonical_metadata_props(rating_key, reason=reason)
                        if canonical and not canonical.get("_Sparse"):
                            props = canonical
                        else:
                            # Do not cache empty detail metadata. This lets later
                            # focus/info attempts retry instead of permanently
                            # marking the item as loaded with no plot/genre/cast.
                            _log("HOME_META_ENRICH_SPARSE_NOT_CACHED rating_key=%s elapsed=%.1fms reason=%s" % (
                                rating_key, (time.time() - start) * 1000.0, reason), xbmc.LOGINFO)
                            return

                    props.pop("_Sparse", None)
                    request_label = props.pop("_RequestLabel", "")
                    canonical_source = props.pop("_CanonicalSource", "")
                    canonical_key = props.pop("_CanonicalRatingKey", "")
                    props.pop("_SourceRatingKey", None)
                    self._store_home_meta_enrich_cache(rating_key, props, reason="home_meta_enrich_%s" % (reason or request_label or ""), drop_name_only_cast=True)

                    try:
                        win = xbmcgui.Window(10000)
                        if win.getProperty("PlexKM.Home.RatingKey") == rating_key:
                            kept_r41 = []
                            for k, v in props.items():
                                if k == "Fanart":
                                    continue
                                val = str(v or "")
                                # R41: Plex enrich often has no TV rating / summary; an empty
                                # value must not erase what is already shown for this item.
                                if not val and k in self._HOME_KEEP_FILLED_R41 and win.getProperty("PlexKM.Home.%s" % k):
                                    kept_r41.append(k)
                                    continue
                                win.setProperty("PlexKM.Home.%s" % k, val)
                            if kept_r41:
                                _log("HOME_META_ENRICH_KEEP_FILLED_R41 rating_key=%s kept=%s" % (rating_key, ",".join(kept_r41)))
                            self._tmdb_fill_home_apply_r41(rating_key, reason="enrich")
                            if "Fanart" in props:
                                raw_fanart_v1841 = str(props.get("Fanart") or "")
                                display_fanart_v1841 = self._home_fanart_display_url(raw_fanart_v1841)
                                win.setProperty("PlexKM.Home.Fanart", raw_fanart_v1841)
                                win.setProperty("PlexKM.Home.DisplayFanart", display_fanart_v1841)
                                win.setProperty("PlexKM.Home.DisplayFanartRaw", raw_fanart_v1841)
                            # v1841: the delayed enrichment worker may outlive
                            # the WindowXML/control that started it. Global
                            # properties are the only publish surface here; XML
                            # binds them without retaining native controls.
                            # v2251: release genre/rating/plot only after every final
                            # property above has landed, so Kodi renders one body frame.
                            self._set_home_hero_body_ready_v2251(
                                rating_key, True, reason="enrich_commit_%s" % (reason or request_label or "meta")
                            )
                            _log("HOME_META_ENRICH_GLOBAL_COMMIT_V1841 rating_key=%s native_control_access=0" % rating_key)
                    except Exception:
                        pass
                    elapsed = (time.time() - start) * 1000.0
                    _log("HOME_META_ENRICH rating_key=%s genre=%s director=%s content_rating=%s elapsed=%.3fms reason=%s request=%s" % (
                        rating_key,
                        "yes" if props.get("Genre") else "no",
                        "yes" if props.get("Director") else "no",
                        props.get("ContentRating") or "",
                        elapsed,
                        reason,
                        (request_label + ("/" + canonical_source if canonical_source else "") + ("#" + canonical_key if canonical_key else ""))))
                except Exception as e:
                    try:
                        self._home_meta_enrich_fail_until[rating_key] = time.time() + 20.0
                    except Exception:
                        pass
                    _log("HOME_META_ENRICH_SKIP rating_key=%s reason=%s error=%s" % (
                        rating_key, reason, _short_log_value(str(e), 160)), xbmc.LOGINFO)
                finally:
                    if remote_lock_acquired_v1837:
                        try:
                            remote_lock_v1837.release()
                        except Exception:
                            pass
                    try:
                        self._home_meta_enriching.discard(rating_key)
                    except Exception:
                        pass
                    # v2251 fail-open: a network/error/remote-lock exit must never
                    # leave a valid local summary hidden.  Only release when this
                    # exact ratingKey still owns the pending body transaction.
                    try:
                        win_v2251 = xbmcgui.Window(10000)
                        if (str(win_v2251.getProperty("PlexKM.Home.RatingKey") or "") == str(rating_key or "")
                                and str(win_v2251.getProperty("PlexKM.Home.HeroBodyPendingRatingKeyV2251") or "") == str(rating_key or "")):
                            self._set_home_hero_body_ready_v2251(rating_key, True, reason="enrich_failopen_%s" % (reason or "meta"))
                    except Exception:
                        pass

            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            pass


    def _dynamic_bg_props_for_rgb(self, rgb):
        try:
            rgb = str(rgb or "").strip().upper()[-6:]
            int(rgb, 16)
            # v2245: focused synopsis uses the same fanart hue, but intentionally
            # darker and denser. Selection is communicated by the card fill itself
            # instead of a separate gold left-edge marker.
            _r, _g, _b = int(rgb[0:2], 16), int(rgb[2:4], 16), int(rgb[4:6], 16)
            # v2247: focused synopsis keeps the stronger fanart tint; XML adds the approved full gold border.
            # Preserve the fanart hue, deepen brightness slightly, and expand channel
            # separation so the fill becomes visibly richer/more saturated.
            _avg = (_r + _g + _b) / 3.0
            def _focus_ch(v):
                return max(0, min(255, int((_avg + (v - _avg) * 1.38) * 0.88)))
            focus_rgb = "%02X%02X%02X" % (_focus_ch(_r), _focus_ch(_g), _focus_ch(_b))
            return {
                "PlexKM.Home.DynamicBgColor": "FF" + rgb,
                "PlexKM.Home.DynamicBgFanartFadeColor": "99" + rgb,
                "PlexKM.Home.DynamicBgRailColor": "B8" + rgb,
                "PlexKM.Home.DynamicBgSideColor": "D8" + rgb,
                "PlexKM.Home.DynamicBgSideOpaqueColor": "FF" + rgb,
                "PlexKM.Home.DynamicBgSideSoftColor": "55" + rgb,
                # v2240: synopsis still follows the fanart hue, but the stronger alpha
                # sits on top of a dark translucent base so white artwork/logos cannot
                # compete visually with the synopsis text.
                "PlexKM.Home.SummaryBoxColor": "68" + rgb,
                "PlexKM.Home.SummaryBoxFocusColor": "E8" + focus_rgb,
                "PlexKM.Home.SummaryPopupTintColor": "62" + rgb,
            }
        except Exception:
            return self._dynamic_bg_props_for_rgb(self._home_bg_default[-6:])

    def _apply_home_dynamic_bg_props(self, rgb, reason=""):
        try:
            props = self._dynamic_bg_props_for_rgb(rgb)
            win = xbmcgui.Window(10000)
            for k, v in props.items():
                win.setProperty(k, v)
                try:
                    self.setProperty(k, v)
                except Exception:
                    pass
            return props
        except Exception:
            return {}

    def _home_bg_cancel_apply_v2315(self):
        """Invalidate the current Home tint transition without publishing UI state."""
        try:
            lock = getattr(self, "_home_bg_apply_lock_v2315", None)
            if lock is None:
                self._home_bg_apply_token += 1
                return int(self._home_bg_apply_token)
            with lock:
                self._home_bg_apply_token += 1
                return int(self._home_bg_apply_token)
        except Exception:
            try:
                self._home_bg_apply_token += 1
                return int(self._home_bg_apply_token)
            except Exception:
                return 0

    def _home_bg_apply_if_current_v2315(self, token, rgb, reason=""):
        """Publish one tint frame only while this Home instance still owns it.

        v2315 keeps the existing worker-based easing model, but makes cancellation
        atomic with each property publish.  This removes the small stale-frame race
        where an old worker could pass its token check just before a focus change.
        """
        try:
            lock = getattr(self, "_home_bg_apply_lock_v2315", None)
            if lock is None:
                return {}
            with lock:
                if token != int(getattr(self, "_home_bg_apply_token", 0) or 0):
                    return {}
                if getattr(self, "_closing_event_v1841", None) is not None and self._closing_event_v1841.is_set():
                    return {}
                if _pkm_full_reset_active_v2150():
                    return {}
                props = self._apply_home_dynamic_bg_props(rgb, reason)
                self._home_bg_display_color = "FF" + str(rgb or "")[-6:].upper()
                return props
        except Exception:
            return {}

    def _set_home_dynamic_bg_color(self, color, reason=""):
        try:
            color = self._normalize_argb_color(color) or self._home_bg_default
            target_rgb = color[-6:].upper()
            current_rgb = (self._home_bg_display_color or self._home_bg_default)[-6:].upper()
            token = self._home_bg_cancel_apply_v2315()

            # v2315: Windows and Android now share the exact same dwell/easing
            # path.  Only lifecycle/first-paint resets are immediate.  Platform
            # is not a rendering-policy input.
            _reason_v2315 = str(reason or "")
            force_direct_v2315 = (
                _reason_v2315 in ("init", "server_switch_pending_v1314", "connection_reset_v1984")
                or _reason_v2315.endswith("_empty")
                or _reason_v2315.endswith("_empty_initial")
                or _reason_v2315.endswith("_no_probe")
            )
            if (force_direct_v2315 or not self._home_bg_display_color
                    or current_rgb == target_rgb):
                props = self._home_bg_apply_if_current_v2315(token, target_rgb, reason)
                if not props:
                    return
                _log("DYNAMIC_BG_SET reason=%s color=%s fanart_fade=%s mode=%s platform_shared=1" % (
                    reason,
                    props.get("PlexKM.Home.DynamicBgColor", "FF" + target_rgb),
                    props.get("PlexKM.Home.DynamicBgFanartFadeColor", "99" + target_rgb),
                    "lifecycle_direct_v2315" if force_direct_v2315 else "direct",
                ))
                return

            steps = max(2, int(getattr(self, "_home_bg_lerp_steps", 8) or 8))
            sleep_ms = max(20, int(getattr(self, "_home_bg_lerp_sleep_ms", 45) or 45))
            _log("DYNAMIC_BG_SET reason=%s from=FF%s to=FF%s mode=lerp steps=%s sleep_ms=%s platform_shared=1" % (
                reason, current_rgb, target_rgb, steps, sleep_ms
            ))

            def _worker():
                try:
                    props = {}
                    for i in range(1, steps + 1):
                        if token != int(getattr(self, "_home_bg_apply_token", 0) or 0):
                            return
                        if getattr(self, "_closing_event_v1841", None) is not None and self._closing_event_v1841.is_set():
                            return
                        if _pkm_full_reset_active_v2150():
                            return
                        rgb = self._lerp_rgb_hex(current_rgb, target_rgb, float(i) / float(steps))
                        props = self._home_bg_apply_if_current_v2315(token, rgb, reason + "_lerp")
                        if not props:
                            return
                        if i < steps:
                            # Event wait wakes immediately during Home close instead
                            # of leaving a sleeping transition worker behind.
                            closing = getattr(self, "_closing_event_v1841", None)
                            if closing is not None:
                                if closing.wait(float(sleep_ms) / 1000.0):
                                    return
                            else:
                                xbmc.sleep(sleep_ms)
                    _log("DYNAMIC_BG_LERP_DONE reason=%s color=%s fanart_fade=%s platform_shared=1" % (
                        reason,
                        props.get("PlexKM.Home.DynamicBgColor", "FF" + target_rgb),
                        props.get("PlexKM.Home.DynamicBgFanartFadeColor", "99" + target_rgb),
                    ))
                except Exception:
                    pass

            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            pass

    def _fanart_color_cache_key_v2218(self, fanart):
        # v2218 ties color selection to the actual diffuse seam band.
        # Version the in-memory key so a broad-strip v2217 result can never be
        # reused after the seam-band algorithm changes.
        return "r81|" + str(fanart or "")

    def _schedule_home_dynamic_bg_from_fanart(self, fanart, reason=""):
        """Latest-only Home/library tint with dwell-before-change (v2314).

        Focus movement changes the hero/poster immediately, but background tint is
        intentionally decoupled from key-repeat speed.  A new fanart target must
        remain current for ``_home_bg_focus_dwell_ms_v2314`` before any tint is
        published.  Moving again cancels both the pending target and any in-flight
        lerp immediately; the currently visible intermediate color is held until
        the newly selected item itself satisfies the dwell period.

        Color detection may run during the dwell window so the delay is visual,
        not wasted I/O time.  Cached and uncached colors follow the same policy.
        """
        try:
            fanart = str(fanart or "")
            now_ms_v2314 = self._now_ms()

            # V2600 UHD hard-minimal: fanart tint extraction is decorative and
            # can consume HTTP, Pillow decode, Python CPU and a multi-frame lerp.
            # On Android never start that work. Reuse only an already-in-memory
            # color and apply it directly; cache misses preserve the visible tint.
            if self._is_android_v2591():
                self._home_bg_token += 1
                self._home_bg_cancel_apply_v2315()
                try:
                    with self._home_bg_probe_lock_v2140:
                        self._home_bg_probe_pending_v2140 = None
                except Exception:
                    pass
                # R81: cached and uncached Plex items both go through the shared
                # dwell + slow glide worker below (a cache hit costs nothing there).
                if not re.search(r"/library/metadata/\d+", fanart or ""):
                    if not self._home_bg_display_color:
                        direct_v2600 = self._home_bg_default
                        apply_token_v2600 = self._home_bg_cancel_apply_v2315()
                        self._home_bg_apply_if_current_v2315(apply_token_v2600, direct_v2600[-6:], reason + "_v2600_default_direct")
                    _log("UHD_DYNAMIC_BG_SKIP_V2600 reason=%s cache_hit=0 network=0 decode=0 lerp=0 preserve=1" % (reason or ""))
                    return
                _log("UHD_DYNAMIC_BG_ULTRABLUR_R81 reason=%s decode=0" % (reason or ""))

            # V2584: wall key-repeat owns the box.  A previously queued tint
            # worker must not download/decode/sample fanart while the Panel is
            # appending.  Hold the currently visible color and cancel pending
            # latest-only work; the settled focus will schedule a fresh sample.
            try:
                if self._wall_rapid_scroll_active_v2581():
                    self._home_bg_token += 1
                    self._home_bg_cancel_apply_v2315()
                    with self._home_bg_probe_lock_v2140:
                        self._home_bg_probe_pending_v2140 = None
                    _log("WALL_RAPID_DYNAMIC_BG_SUPPRESS_V2584 network=0 decode=0 apply=0")
                    return
            except Exception:
                pass

            # V2595: fanart color extraction/HTTP/Pillow/lerp is decorative.
            # On UHD it must never overlap startup or remote navigation. Hold the
            # current tint; a later settled metadata publication may reschedule.
            try:
                if self._uhd3_foreground_isolation_active_v2591():
                    self._home_bg_token += 1
                    self._home_bg_cancel_apply_v2315()
                    with self._home_bg_probe_lock_v2140:
                        self._home_bg_probe_pending_v2140 = None
                    _log("UHD3_DYNAMIC_BG_SUPPRESS_V2595 reason=%s network=0 decode=0 lerp=0" % (reason or ""))
                    return
            except Exception:
                pass

            # A no-art item must not wash a valid surface back to neutral.
            if not fanart:
                self._home_bg_token += 1
                self._home_bg_cancel_apply_v2315()
                self._home_bg_target_fanart_v2314 = ""
                self._home_bg_target_since_ms_v2314 = now_ms_v2314
                if not self._home_bg_display_color:
                    self._set_home_dynamic_bg_color(self._home_bg_default, reason=reason + "_empty_initial")
                else:
                    _log("DYNAMIC_BG_EMPTY_PRESERVE_V2314 reason=%s color=%s" % (
                        reason or "", self._home_bg_display_color or self._home_bg_default
                    ))
                return

            same_target_v2314 = (
                fanart == str(getattr(self, "_home_bg_target_fanart_v2314", "") or "")
                and int(getattr(self, "_home_bg_target_since_ms_v2314", 0) or 0) > 0
            )
            if same_target_v2314:
                token = int(self._home_bg_token)
                target_since_v2314 = int(self._home_bg_target_since_ms_v2314)
                # Once this exact target is already fully applied, repeated meta
                # refreshes must not restart the dwell timer or create workers.
                if (fanart == str(self._home_bg_current_fanart or "")
                        and self._home_bg_probe_pending_v2140 is None):
                    return
            else:
                self._home_bg_token += 1
                token = int(self._home_bg_token)
                target_since_v2314 = now_ms_v2314
                self._home_bg_target_fanart_v2314 = fanart
                self._home_bg_target_since_ms_v2314 = target_since_v2314

                # Critical v2314 behavior: cancel the OLD color destination at
                # the instant focus moves.  If a slow lerp was in progress it
                # freezes at its current visible color; it never continues
                # drifting toward an item that is no longer selected.
                self._home_bg_cancel_apply_v2315()
                _log("DYNAMIC_BG_TARGET_REPLACE_V2314 reason=%s token=%s dwell_ms=%s cancel_old_lerp=1" % (
                    reason or "", token, int(getattr(self, "_home_bg_focus_dwell_ms_v2314", 480) or 480)
                ))

            with self._home_bg_probe_lock_v2140:
                # Repeated metadata/fanart publication for the SAME focus must
                # not enqueue a duplicate while that target is already being
                # sampled or waiting out its dwell period.
                if (same_target_v2314 and self._home_bg_probe_worker_running_v2140
                        and (self._home_bg_probe_pending_v2140 is not None
                             or int(getattr(self, "_home_bg_probe_active_token_v2314", 0) or 0) == token)):
                    return
                # Keep only the latest target.  The timestamp belongs to the
                # focus acquisition, not to worker pickup, so repeated calls for
                # the same selection cannot postpone the commit indefinitely.
                self._home_bg_probe_pending_v2140 = (
                    token, fanart, str(reason or ""), target_since_v2314
                )
                if self._home_bg_probe_worker_running_v2140:
                    return
                self._home_bg_probe_worker_running_v2140 = True

            def _worker():
                try:
                    while True:
                        # Small coalesce only; the real stability gate is the
                        # focus dwell below.
                        xbmc.sleep(55)
                        with self._home_bg_probe_lock_v2140:
                            pending = self._home_bg_probe_pending_v2140
                            self._home_bg_probe_pending_v2140 = None
                        if not pending:
                            break
                        p_token, p_fanart, p_reason, p_since = pending
                        self._home_bg_probe_active_token_v2314 = int(p_token)
                        if p_token != self._home_bg_token:
                            self._home_bg_probe_active_token_v2314 = 0
                            continue

                        cache_key_v2218 = self._fanart_color_cache_key_v2218(p_fanart)
                        # v2386: memory lookup is free, but a cache miss must not
                        # download/decode/sample abandoned fanart while keys repeat.
                        color = self._home_bg_color_cache.get(cache_key_v2218)

                        dwell_ms_v2314 = max(0, int(getattr(self, "_home_bg_focus_dwell_ms_v2314", 480) or 480))
                        due_ms_v2314 = int(p_since or self._now_ms()) + dwell_ms_v2314
                        while self._now_ms() < due_ms_v2314:
                            if p_token != self._home_bg_token:
                                break
                            xbmc.sleep(min(40, max(1, due_ms_v2314 - self._now_ms())))
                        if p_token != self._home_bg_token:
                            _log("DYNAMIC_BG_DWELL_CANCEL_V2314 reason=%s token=%s new_token=%s" % (
                                p_reason or "", p_token, self._home_bg_token
                            ))
                            self._home_bg_probe_active_token_v2314 = 0
                            continue

                        if not color:
                            try:
                                if self._wall_rapid_scroll_active_v2581():
                                    _log("WALL_RAPID_DYNAMIC_BG_WORKER_CANCEL_V2584 token=%s network=0 decode=0" % p_token)
                                    self._home_bg_probe_active_token_v2314 = 0
                                    continue
                            except Exception:
                                pass
                            _log("DYNAMIC_BG_SAMPLE_AFTER_DWELL_V2386 reason=%s token=%s dwell_ms=%s" % (
                                p_reason or "", p_token, dwell_ms_v2314
                            ))
                            color = self._detect_fanart_background_color(p_fanart)
                            if p_token != self._home_bg_token:
                                self._home_bg_probe_active_token_v2314 = 0
                                continue
                            if not color:
                                _log("DYNAMIC_BG_DETECT_PRESERVE_V2314 reason=%s fanart=yes" % (p_reason or ""), xbmc.LOGWARNING)
                                self._home_bg_probe_active_token_v2314 = 0
                                continue
                            self._home_bg_color_cache[cache_key_v2218] = color

                        # Only now has the user actually stayed on this selection
                        # long enough.  Start a slow transition from the color that
                        # is visible at this exact moment.
                        self._home_bg_current_fanart = p_fanart
                        self._set_home_dynamic_bg_color(color, reason=p_reason + "_dwell_v2314")
                        _log("DYNAMIC_BG_DWELL_COMMIT_V2314 reason=%s token=%s color=%s dwell_ms=%s lerp_steps=%s lerp_sleep_ms=%s" % (
                            p_reason or "", p_token, color, dwell_ms_v2314,
                            int(getattr(self, "_home_bg_lerp_steps", 14) or 14),
                            int(getattr(self, "_home_bg_lerp_sleep_ms", 55) or 55),
                        ))
                        self._home_bg_probe_active_token_v2314 = 0

                        with self._home_bg_probe_lock_v2140:
                            if self._home_bg_probe_pending_v2140 is None:
                                break
                except Exception:
                    _log("DYNAMIC_BG_FAILED_V2314 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                finally:
                    restart = False
                    with self._home_bg_probe_lock_v2140:
                        self._home_bg_probe_worker_running_v2140 = False
                        self._home_bg_probe_active_token_v2314 = 0
                        restart = self._home_bg_probe_pending_v2140 is not None
                    if restart and not self._closing_event_v1841.is_set():
                        try:
                            pending_now = self._home_bg_probe_pending_v2140
                            if pending_now:
                                _t, _f, _r, _since = pending_now
                                # Re-enter without changing the target timestamp.
                                # Same-target logic above preserves the original dwell.
                                self._schedule_home_dynamic_bg_from_fanart(_f, reason=_r + "_restart")
                        except Exception:
                            pass

            t = _PKMHomeThreadV2151(target=_worker, daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            _log("DYNAMIC_BG_SCHEDULE_FAILED_V2314 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _ultrablur_color_r81(self, fanart):
        """R81: tint from Plex's own UltraBlurColors for the artwork's item.

        Plex computes four corner colours from the *whole* background art (the
        palette the Plex apps paint behind their UI).  That follows the overall
        artwork colour - a mostly yellow fanart gives yellow, a mostly white one a
        light neutral - unlike the old seam-band sampler which only looked at the
        left 17% of the image.  One small metadata XML per item, no image decode,
        cached per ratingKey.  Returns "" when the artwork is not a Plex item.
        """
        try:
            text = str(fanart or "")
            m = re.search(r"/library/metadata/(\d+)(?:/|$|\?)", text)
            if not m or not (text.startswith("http://") or text.startswith("https://")):
                return ""
            rk = m.group(1)
            cache = getattr(self, "_ultrablur_cache_r81", None)
            if cache is None:
                cache = {}
                self._ultrablur_cache_r81 = cache
            if rk in cache:
                return cache[rk]
            parts = urlsplit(text)
            token = ""
            for k, v in parse_qsl(parts.query, keep_blank_values=True):
                if str(k or "").lower() == "x-plex-token":
                    token = v
            if not token:
                try:
                    token = (xbmcaddon.Addon("plugin.video.km").getSetting("plex_token") or "").strip()
                except Exception:
                    token = ""
            q = urlencode({"X-Plex-Token": token}) if token else ""
            url = urlunsplit((parts.scheme, parts.netloc, "/library/metadata/%s" % rk, q, ""))
            req = Request(url, headers={"Accept": "application/xml", "User-Agent": "Kodi PlexKM"})
            body = urlopen(req, timeout=3.0).read(512 * 1024)
            root = ET.fromstring(body)
            node = root.find(".//UltraBlurColors")
            if node is None:
                cache[rk] = ""
                _log("DYNAMIC_BG_ULTRABLUR_MISS_R81 rk=%s" % rk)
                return ""
            import colorsys
            acc = [0.0, 0.0, 0.0]
            wsum = 0.0
            corners = []
            for key in ("topLeft", "topRight", "bottomRight", "bottomLeft"):
                hx = str(node.get(key) or "").strip().lstrip("#")
                if len(hx) != 6:
                    continue
                r, g, b = int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16)
                _h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
                # colourful corners lead; a single neutral corner cannot grey-out the rest
                w = 0.35 + s * v * 2.0
                acc[0] += r * w
                acc[1] += g * w
                acc[2] += b * w
                wsum += w
                corners.append(hx)
            if wsum <= 0:
                cache[rk] = ""
                return ""
            r, g, b = [acc[i] / wsum for i in range(3)]
            h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            # Keep the hue; a little more chroma so yellow reads yellow; lightness in
            # a band that keeps white text readable (white art -> light neutral grey).
            out_s = min(1.0, s * 1.15) if s >= 0.06 else s
            out_v = max(0.20, min(0.42, v * 1.05))
            rr, gg, bb = colorsys.hsv_to_rgb(h, out_s, out_v)
            color = "FF%02X%02X%02X" % (int(round(rr * 255)), int(round(gg * 255)), int(round(bb * 255)))
            cache[rk] = color
            if len(cache) > 1500:
                try:
                    for old_key in list(cache.keys())[:500]:
                        cache.pop(old_key, None)
                except Exception:
                    pass
            _log("DYNAMIC_BG_ULTRABLUR_R81 rk=%s corners=%s color=%s" % (rk, ",".join(corners), color))
            return color
        except Exception as e:
            _log("DYNAMIC_BG_ULTRABLUR_FAILED_R81 err=%s" % e, xbmc.LOGWARNING)
            return ""

    def _dominant_rgb_r81(self, data):
        """R81: area-based dominant colour over the WHOLE artwork.

        The v2218 sampler only looked at the left 17% seam band, so a mostly
        yellow/white fanart could still give an unrelated tint.  Here every pixel
        of a 64x36 thumbnail votes into 15-degree hue bins (lit, saturated pixels
        weigh more, the centre a bit more than the edges); near-greys vote into a
        neutral bin that wins only when the picture really is mostly neutral.
        Returns (r, g, b) or None when Pillow cannot decode."""
        try:
            from PIL import Image
            import colorsys
            im = Image.open(BytesIO(data)).convert("RGB")
            im.thumbnail((64, 36))
            w, h = im.size
            px = list(im.getdata())
            if not px or w <= 0 or h <= 0:
                return None
            bins = [[0.0, 0.0, 0.0, 0.0] for _ in range(24)]
            neu = [0.0, 0.0, 0.0, 0.0]
            for i, (r, g, b) in enumerate(px):
                x = i % w
                y = i // w
                cw = 1.0 - 0.35 * (abs((x + 0.5) / w - 0.5) * 2) ** 2 - 0.35 * (abs((y + 0.5) / h - 0.5) * 2) ** 2
                hh, sat, val = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
                if val < 0.06:
                    continue
                wt = cw * (0.4 + 0.6 * val)
                if sat < 0.07 or (max(r, g, b) - min(r, g, b)) < 8:
                    t = neu
                else:
                    t = bins[int(hh * 24) % 24]
                    wt *= (0.6 + sat)
                t[0] += wt
                t[1] += r * wt
                t[2] += g * wt
                t[3] += b * wt
            best = max(range(24), key=lambda k: bins[k][0] + 0.5 * (bins[k - 1][0] + bins[(k + 1) % 24][0]))
            chroma = [0.0, 0.0, 0.0, 0.0]
            for k in (best - 1, best, (best + 1) % 24):
                for j in range(4):
                    chroma[j] += bins[k][j]
            pick = neu if (neu[0] > chroma[0] * 1.8 or chroma[0] <= 0) else chroma
            if pick[0] <= 0:
                return (40, 40, 40)
            rgb = tuple(pick[j] / pick[0] for j in (1, 2, 3))
            _log("DYNAMIC_BG_DOMINANT_R81 mode=%s rgb=(%d,%d,%d)" % (
                "neutral" if pick is neu else "hue%d" % (best * 15), rgb[0], rgb[1], rgb[2]))
            return rgb
        except ImportError:
            return None
        except Exception:
            _log("DYNAMIC_BG_DOMINANT_FAILED_R81 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return None

    def _tint_r81(self, rgb):
        """Keep the hue, give it a bit more colour, and keep lightness in a band
        where white text stays readable (white art -> light grey, not black)."""
        try:
            import colorsys
            r, g, b = rgb
            hh, sat, val = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            out_s = min(0.85, sat * 1.45) if sat >= 0.06 else sat * 0.6
            out_v = max(0.20, min(0.44, 0.10 + val * 0.55))
            rr, gg, bb = colorsys.hsv_to_rgb(hh, out_s, out_v)
            return "FF%02X%02X%02X" % (int(round(rr * 255)), int(round(gg * 255)), int(round(bb * 255)))
        except Exception:
            return self._home_bg_default

    def _detect_fanart_background_color(self, fanart):
        try:
            # R81: colour = the *overall* dominant colour of the whole artwork
            # (Plex transcodes the art to a 96x54 probe, so decode is tiny on every
            # platform).  If Pillow is unavailable, use Plex UltraBlurColors.
            data = self._read_fanart_bytes(fanart, max_bytes=2 * 1024 * 1024)
            if data:
                rgb_r81 = self._dominant_rgb_r81(data)
                if rgb_r81 is not None:
                    return self._tint_r81(rgb_r81)
            color_r81 = self._ultrablur_color_r81(fanart)
            if color_r81:
                return color_r81
            if not data:
                _log("DYNAMIC_BG_DETECT_SKIP reason=no_fanart_bytes", xbmc.LOGWARNING)
                return ""
            rgb = self._average_image_rgb_with_pillow(data)
            if rgb is None:
                # Android-safe rule: never launch PowerShell/cmd/GDI+ or any other
                # external process. If Pillow cannot decode this image format, keep
                # the current/default background and log the exact fallback reason.
                _log("DYNAMIC_BG_DETECT_SKIP reason=pillow_decode_failed bytes=%s head=%s" % (len(data), data[:12].hex()), xbmc.LOGWARNING)
                return ""
            return self._rgb_to_home_tint(rgb)
        except Exception:
            _log("DYNAMIC_BG_DETECT_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return ""

    def _fanart_color_probe_urls(self, url):
        try:
            urls = []
            def _add(u):
                if u and u not in urls:
                    urls.append(u)

            text = str(url or "")
            if not (text.startswith("http://") or text.startswith("https://")):
                return [text]

            display_text = self._home_fanart_display_url(text)

            # v946: color probing must never compete with Kodi's visible hero
            # fanart texture load.  For direct Plex artwork URLs, probe a tiny
            # Plex photo transcode first and keep the original URL only as the
            # last fallback.  The displayed fanart remains original quality; only
            # the background-tint sampler uses this small image.
            try:
                probe_source = display_text or text
                p2 = urlsplit(probe_source)
                if (p2.scheme and p2.netloc and (p2.path or "").startswith("/library/metadata/")):
                    qsrc = dict(parse_qsl(p2.query, keep_blank_values=True))
                    tq = {
                        "width": "96",
                        "height": "54",
                        "minSize": "1",
                        "upscale": "0",
                        "format": "jpg",
                        "url": p2.path,
                    }
                    for k, v in qsrc.items():
                        if str(k or "").lower() == "x-plex-token":
                            tq[k] = v
                    _add(urlunsplit((p2.scheme, p2.netloc, "/photo/:/transcode", urlencode(tq), "")))
            except Exception:
                pass

            if display_text and display_text != text:
                _add(display_text)

            parts = urlsplit(text)
            query = dict(parse_qsl(parts.query, keep_blank_values=True))
            if "format" in query:
                for fmt in ("jpg", "jpeg", "png"):
                    q = dict(query)
                    q["format"] = fmt
                    _add(urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(q), parts.fragment)))
            elif "/photo/:/transcode" in parts.path:
                q = dict(query)
                q["format"] = "jpg"
                _add(urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(q), parts.fragment)))

            _add(text)
            return urls
        except Exception:
            return [url]

    def _read_fanart_bytes(self, fanart, max_bytes=8388608):
        try:
            if fanart.startswith("http://") or fanart.startswith("https://"):
                last_err = ""
                for url in self._fanart_color_probe_urls(fanart):
                    try:
                        data = pkm_artwork_scheduler.fetch_bytes(
                            url, timeout=4.0, max_bytes=max_bytes,
                            headers={
                                "User-Agent": "Kodi PlexKM",
                                "Accept": "image/jpeg,image/png,image/*;q=0.8,*/*;q=0.5",
                            },
                            priority=pkm_artwork_scheduler.PRIORITY_VISIBLE,
                            tag="dynamic_fanart",
                            cancel_check=self._closing_event_v1841.is_set,
                            pause_check=_pkm_playback_active_v1411,
                            pause_when_playing=True,
                        )
                        if data:
                            _log("DYNAMIC_BG_READ_OK_V1937 bytes=%s url_variant=%s scheduler=1" % (len(data), "jpg_probe" if url != fanart else "original"))
                            return data
                    except Exception as e:
                        last_err = str(e)
                if last_err:
                    _log("DYNAMIC_BG_READ_FAILED err=%s" % last_err, xbmc.LOGWARNING)
                return b""
            path = fanart
            try:
                if path.startswith("special://") and core is not None:
                    path = core.xbmcvfs.translatePath(path)
            except Exception:
                pass
            with open(path, "rb") as f:
                return f.read(max_bytes)
        except Exception:
            return b""

    def _rgb_to_home_tint(self, rgb):
        """Turn the sampled seam color into the solid UI field with no hue shift.

        v2218 does not boost saturation or blend with a generic base color.  The
        actual seam hue/saturation are preserved.  Only brightness is capped when
        needed for white-text readability, so the fanart fade and solid field stay
        in the same color family and the join is visually continuous.
        """
        try:
            import colorsys
            r, g, b = [max(0, min(255, int(vv))) for vv in rgb]
            h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)

            # Preserve the sampled chroma exactly.  Only keep a very small floor
            # for almost-neutral samples so 8-bit rounding does not erase a real
            # blue/green cast.  Never force vividness.
            out_s = s if s >= 0.055 else max(0.0, s)
            # If the seam itself is already dark, leave its value untouched.
            # Bright sky/wall edges are uniformly darkened, preserving hue/sat.
            out_v = max(0.16, min(0.36, v))
            rr_f, gg_f, bb_f = colorsys.hsv_to_rgb(h, out_s, out_v)
            rr = int(round(rr_f * 255.0))
            gg = int(round(gg_f * 255.0))
            bb = int(round(bb_f * 255.0))
            color = "FF%02X%02X%02X" % (rr, gg, bb)
            _log("DYNAMIC_BG_TINT_V2218 rgb=(%d,%d,%d) color=%s sat=%.3f->%.3f value=%.3f->%.3f mode=diffuse_seam_no_hue_shift" % (
                r, g, b, color, s, out_s, v, out_v
            ))
            return color
        except Exception:
            return self._home_bg_default

    def _fanart_log_url(self, url):
        try:
            text = str(url or "")
            if not text:
                return ""
            parts = urlsplit(text)
            if not parts.scheme or not parts.netloc:
                return _short_log_value(text, 180)
            query = []
            for k, v in parse_qsl(parts.query, keep_blank_values=True):
                if k.lower() == "x-plex-token":
                    query.append((k, "***"))
                else:
                    query.append((k, v))
            safe = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))
            return _short_log_value(safe, 220)
        except Exception:
            return _short_log_value(url, 180)

    def _set_home_fanart_smooth(self, fanart, reason=""):
        """Update the displayed hero fanart texture.

        v716: Do not rely on the delayed DisplayFanart worker for the primary
        texture assignment.  Keep the immediate texture property update, but use
        the original Plex art URL as the displayed texture to avoid the low
        quality introduced by the JPEG transcode path used in v715.
        """
        try:
            if self._wall_rapid_scroll_active_v2581():
                _log("HOME_FANART_SUPPRESS_WALL_RAPID_V2581 reason=%s" % (reason or ""))
                return
            raw_fanart = str(fanart or "")
            display_fanart = self._home_fanart_display_url(raw_fanart)
            # Keep the raw DB/Plex property for compatibility and diagnostics.
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.Home.Fanart", raw_fanart)
                win.setProperty("PlexKM.Home.DisplayFanart", display_fanart)
                win.setProperty("PlexKM.Home.DisplayFanartRaw", raw_fanart)
                self.setProperty("PlexKM.Home.Fanart", raw_fanart)
                self.setProperty("PlexKM.Home.DisplayFanart", display_fanart)
                self.setProperty("PlexKM.Home.DisplayFanartRaw", raw_fanart)
            except Exception:
                pass

            # v946: first Home paint must not start a second artwork download for
            # dynamic tint while Kodi is still loading the visible hero fanart.
            # Keep the display texture immediate, but skip initial color probing.
            # Later focus changes still use the normal async probe, now using a
            # tiny transcode sampler above instead of the original full artwork.
            initial_prepaint = str(reason or "").startswith(("home_continue_first_row", "home_recent_first_row"))
            if initial_prepaint:
                try:
                    # v2140: do not poison the real fanart-color cache with the
                    # neutral startup color and do not mark this artwork as fully
                    # sampled. Keep first paint cheap, then let the single debounced
                    # sampler resolve the actual tint after the Home surface settles.
                    self._set_home_dynamic_bg_color(self._home_bg_default, reason=str(reason or "home_prepaint") + "_no_probe")
                    _log("DYNAMIC_BG_INITIAL_PROBE_DEFER_V2140 reason=%s fanart=%s cache_poison=0" % (
                        reason, "yes" if display_fanart else "no"
                    ))
                    if display_fanart:
                        self._schedule_home_dynamic_bg_from_fanart(
                            display_fanart, reason=str(reason or "home_prepaint") + "_postpaint_v2140"
                        )
                except Exception:
                    pass
            else:
                # Use the actual display texture for color probing as well, so Plex
                # JPEG transcode is used consistently.  Color failure must never
                # clear or block the display texture.
                self._schedule_home_dynamic_bg_from_fanart(display_fanart, reason=reason)

            if display_fanart != self._home_fanart_current:
                self._home_fanart_token += 1
                self._home_fanart_current = display_fanart
                source = "direct_original" if display_fanart else "empty"
                _log("FANART_TEXTURE_SET reason=%s source=%s raw=%s display=%s" % (
                    reason, source, self._fanart_log_url(raw_fanart), self._fanart_log_url(display_fanart)
                ))
            else:
                _log("FANART_TEXTURE_KEEP reason=%s display=%s" % (reason, self._fanart_log_url(display_fanart)))
        except Exception:
            _log("FANART_TEXTURE_SET_FAILED reason=%s err=%s" % (reason, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)


    def _format_watcha_rating_value(self, value):
        try:
            if value is None:
                return ""
            s = str(value).strip()
            if not s:
                return ""
            f = float(s)
            if f <= 0:
                return ""
            # Watcha build DB stores a 5-point score. Home UI shows it on a 10-point scale.
            return "%.1f" % round(f * 2.0, 1)
        except Exception:
            return ""

    def _format_watcha_count_value(self, value):
        try:
            s = str(value or "").strip()
            if not s:
                return ""
            return s
        except Exception:
            return ""

    def _watcha_title_key(self, value):
        try:
            s = unicodedata.normalize("NFKC", str(value or "").strip().lower())
            if not s:
                return ""
            s = re.sub(r"[\s\-_:;,.!?\'\"~`·•()\[\]{}]+", "", s)
            return s
        except Exception:
            return ""

    def _home_watcha_preload_props(self, rating_key, title="", original_title="", year=""):
        """Return Watcha Pedia rating/count from a DB-only bulk preload cache.

        Loads positive watcha_ratings rows once per plex_km.db mtime into in-memory
        maps, then answers by rating_key or normalized title/year without repeated SQL.
        """
        try:
            rk = str(rating_key or "").strip()
            t = str(title or "").strip()
            ot = str(original_title or "").strip()
            y = str(year or "").strip()
            empty = {"Rating": "", "Count": "", "Display": ""}
            if not rk and not t:
                return empty
            # PKM_PATCH_ACTIVE v2591 uhd3_watcha_point_lookup_no_bulk_preload
            # Android/UHD3 must never materialize the complete watcha_ratings table
            # just to decorate a visible card. Exact rating-key lookup is enough;
            # misses remain blank until a later idle/focus path.
            if self._is_android_v2591():
                if t.startswith("__pkm_"):
                    return empty
                if self._uhd3_foreground_isolation_active_v2591():
                    return empty
                point_cache = getattr(self, "_home_watcha_point_cache_v2591", None)
                if not isinstance(point_cache, dict):
                    point_cache = {}
                    self._home_watcha_point_cache_v2591 = point_cache
                point_key = str(rk or "")
                if point_key and point_key in point_cache:
                    return point_cache.get(point_key) or empty
                if not point_key:
                    return empty
                dbp_point = self._profile_db_path()
                if not dbp_point or not os.path.exists(dbp_point):
                    return empty
                result = empty
                conn_point = _pkm_ro_connect(dbp_point, timeout=0.35)
                try:
                    has_table = conn_point.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='watcha_ratings' LIMIT 1").fetchone()
                    rr = None
                    if has_table:
                        rr = conn_point.execute(
                            "SELECT watcha_rating, watcha_count FROM watcha_ratings WHERE rating_key=? AND watcha_rating IS NOT NULL LIMIT 1",
                            (point_key,)
                        ).fetchone()
                    if rr:
                        rating = self._format_watcha_rating_value(rr[0] if len(rr) > 0 else "")
                        count = self._format_watcha_count_value(rr[1] if len(rr) > 1 else "")
                        display = "%s(%s)" % (rating, count) if rating and count else rating
                        result = {"Rating": rating, "Count": count, "Display": display}
                finally:
                    conn_point.close()
                if len(point_cache) >= 256:
                    point_cache.clear()
                point_cache[point_key] = result
                return result
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return empty
            try:
                db_mtime = os.path.getmtime(dbp)
            except Exception:
                db_mtime = 0
            # v1642: restore the process-wide cache before considering any SQL.
            try:
                with _HOME_WATCHA_SHARED_CACHE_V1642["lock"]:
                    if (
                        _HOME_WATCHA_SHARED_CACHE_V1642.get("db_path") == dbp
                        and float(_HOME_WATCHA_SHARED_CACHE_V1642.get("db_mtime") or 0) == float(db_mtime)
                        and isinstance(_HOME_WATCHA_SHARED_CACHE_V1642.get("cache"), dict)
                    ):
                        self._home_watcha_preload_cache = _HOME_WATCHA_SHARED_CACHE_V1642.get("cache")
                        self._home_watcha_preload_cache_mtime = db_mtime
                        self._home_watcha_preload_cache_loaded_at = float(_HOME_WATCHA_SHARED_CACHE_V1642.get("loaded_at") or time.time())
            except Exception:
                pass
            cache = getattr(self, "_home_watcha_preload_cache", None)
            cache_mtime = getattr(self, "_home_watcha_preload_cache_mtime", None)
            cache_loaded_at = float(getattr(self, "_home_watcha_preload_cache_loaded_at", 0.0) or 0.0)
            cache_age = time.time() - cache_loaded_at if cache_loaded_at > 0 else 999999.0
            need_reload = (not isinstance(cache, dict)) or cache_mtime is None or not cache
            if (not need_reload) and float(cache_mtime) != float(db_mtime) and cache_age >= 30.0:
                need_reload = True
            if (
                need_reload
                and bool(getattr(self, "_home_first_paint_critical_v1642", False))
                and threading.current_thread().name != "PlexKMWatchaPreloadV1642"
            ):
                self._start_home_watcha_preload_async_v1642(reason="first_paint_defer")
                return empty
            if need_reload:
                started = time.time()
                by_rk = {}
                by_ty = {}
                row_count = 0
                conn = _pkm_ro_connect(dbp, timeout=5.0)
                try:
                    # v1291: On many installs watcha_ratings does not exist.
                    # Do not run the failing SELECT for every poster.  Cache an
                    # empty result for this DB mtime so widget rendering stays stable.
                    has_table = conn.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='watcha_ratings' LIMIT 1"
                    ).fetchone()
                    if not has_table:
                        cache = {"by_rk": {}, "by_ty": {}, "_missing_table": True}
                        self._home_watcha_preload_cache = cache
                        self._home_watcha_preload_cache_mtime = db_mtime
                        self._home_watcha_preload_cache_loaded_at = time.time()
                        try:
                            _log("WATCHA_PRELOAD_SKIP reason=missing_table cache_empty=1")
                        except Exception:
                            pass
                        return empty
                    rows = conn.execute("""
                        SELECT rating_key, title, original_title, watcha_title, year,
                               watcha_rating, watcha_count, updated_at
                        FROM watcha_ratings
                        WHERE watcha_rating IS NOT NULL
                        ORDER BY COALESCE(updated_at, '') DESC
                    """).fetchall()
                finally:
                    conn.close()
                for rr in rows:
                    rating = self._format_watcha_rating_value(rr[5] if len(rr) > 5 else "")
                    count = self._format_watcha_count_value(rr[6] if len(rr) > 6 else "")
                    if not rating:
                        continue
                    display = "%s(%s)" % (rating, count) if count else rating
                    result = {"Rating": rating, "Count": count, "Display": display}
                    key = str(rr[0] or "").strip()
                    if key and key not in by_rk:
                        by_rk[key] = result
                    yy = str(rr[4] or "").strip()
                    if yy:
                        for name in (rr[1] if len(rr) > 1 else "", rr[2] if len(rr) > 2 else "", rr[3] if len(rr) > 3 else ""):
                            nk = self._watcha_title_key(name)
                            if nk:
                                ty = (nk, yy)
                                if ty not in by_ty:
                                    by_ty[ty] = result
                    row_count += 1
                cache = {"by_rk": by_rk, "by_ty": by_ty}
                self._home_watcha_preload_cache = cache
                self._home_watcha_preload_cache_mtime = db_mtime
                self._home_watcha_preload_cache_loaded_at = time.time()
                try:
                    with _HOME_WATCHA_SHARED_CACHE_V1642["lock"]:
                        _HOME_WATCHA_SHARED_CACHE_V1642["db_path"] = dbp
                        _HOME_WATCHA_SHARED_CACHE_V1642["db_mtime"] = db_mtime
                        _HOME_WATCHA_SHARED_CACHE_V1642["cache"] = cache
                        _HOME_WATCHA_SHARED_CACHE_V1642["loaded_at"] = self._home_watcha_preload_cache_loaded_at
                except Exception:
                    pass
                try:
                    _log("WATCHA_PRELOAD source=db_bulk rows=%d by_rk=%d by_title_year=%d elapsed=%.1fms" % (
                        row_count, len(by_rk), len(by_ty), (time.time() - started) * 1000.0
                    ))
                except Exception:
                    pass
            by_rk = cache.get("by_rk", {}) if isinstance(cache, dict) else {}
            by_ty = cache.get("by_ty", {}) if isinstance(cache, dict) else {}
            if rk and rk in by_rk:
                return by_rk.get(rk) or empty
            if y:
                for name in (t, ot):
                    nk = self._watcha_title_key(name)
                    if nk:
                        res = by_ty.get((nk, y))
                        if res:
                            return res
            return empty
        except Exception:
            try:
                _log("WATCHA_PRELOAD source=db_error rating_key=%s err=%s" % (str(rating_key or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return {"Rating": "", "Count": "", "Display": ""}

    def _home_imdb_rating_value(self, rating):
        try:
            s = str(rating or "").strip()
            if not s:
                return ""
            f = float(s)
            if f <= 0:
                return ""
            return ("%.1f" % f).rstrip("0").rstrip(".")
        except Exception:
            return str(rating or "").strip()

    def _home_db_imdb_rating_point_v2630(self, rating_key):
        """V2630 Info-only IMDb/Plex score point lookup.

        Never materialize the full item_ratings table because one Info page needs
        one score. Existing visible/full caches are reused when already warm; a
        cold miss performs one indexed rating_key query only.
        """
        t0 = time.perf_counter()
        rk = str(rating_key or "").strip()
        if not rk:
            return ""
        try:
            visible = self._home_visible_imdb_rating_value(rk)
            if visible:
                _log("INFO_IMDB_POINT_V2630 rating_key=%s source=visible_cache elapsed_ms=%.1f" % (rk, (time.perf_counter()-t0)*1000.0))
                return visible
        except Exception:
            pass
        try:
            cache = getattr(self, "_home_imdb_rating_cache", None)
            if isinstance(cache, dict) and rk in cache:
                value = str(cache.get(rk) or "")
                _log("INFO_IMDB_POINT_V2630 rating_key=%s source=warm_bulk_cache elapsed_ms=%.1f" % (rk, (time.perf_counter()-t0)*1000.0))
                return value
        except Exception:
            pass
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""
            conn = _pkm_ro_connect(dbp, timeout=1.0)
            try:
                rr = conn.execute(
                    "SELECT score,rating,audience_rating,user_rating FROM item_ratings WHERE rating_key=? LIMIT 1",
                    (rk,)
                ).fetchone()
            finally:
                conn.close()
            value = ""
            if rr:
                for raw in rr[:4]:
                    value = self._home_imdb_rating_value(raw)
                    if value:
                        break
            _log("INFO_IMDB_POINT_V2630 rating_key=%s source=db_point hit=%d elapsed_ms=%.1f" % (
                rk, 1 if value else 0, (time.perf_counter()-t0)*1000.0
            ))
            return value
        except Exception:
            _log("INFO_IMDB_POINT_V2630 rating_key=%s source=db_error elapsed_ms=%.1f err=%s" % (
                rk, (time.perf_counter()-t0)*1000.0, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return ""

    def _home_db_imdb_rating_value(self, rating_key):
        """Return local IMDb/Plex fallback rating from item_ratings immediately.

        v939: Home/section/recent rows must not wait for focus-time enrich.
        Load item_ratings into a small in-memory map keyed by rating_key and
        invalidate it by plex_km.db mtime.  This is DB-only and never performs
        Plex/Cine21 network work.
        """
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return ""
            # PKM_PATCH_ACTIVE v2595 uhd_no_full_imdb_bulk_sidebar_count_sql
            # V2595 UHD runtime-minimal: never build the full item_ratings map on
            # Android.  The old fallback can read tens of thousands of rows just
            # because one poster needs a rating.  Use only the tiny visible/cache
            # maps already prepared for the current surface; focused metadata may
            # enrich later without blocking Home/sidebar/Library navigation.
            if self._is_android_v2591():
                visible = self._home_visible_imdb_rating_value(rk)
                if visible:
                    return visible
                cache = getattr(self, "_home_imdb_rating_cache", None)
                return (cache.get(rk, "") or "") if isinstance(cache, dict) else ""
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return ""
            try:
                db_mtime = os.path.getmtime(dbp)
            except Exception:
                db_mtime = 0
            cache = getattr(self, "_home_imdb_rating_cache", None)
            cache_mtime = getattr(self, "_home_imdb_rating_cache_mtime", None)
            cache_loaded_at = float(getattr(self, "_home_imdb_rating_cache_loaded_at", 0.0) or 0.0)
            cache_age = time.time() - cache_loaded_at if cache_loaded_at > 0 else 999999.0
            # v944: item_ratings bulk cache is UI-critical fallback data.  Startup
            # sync writes can change DB mtime several times per second; reloading all
            # 16k ratings on every poster ListItem caused repeated focus/build stalls.
            need_reload = (not isinstance(cache, dict)) or cache_mtime is None or not cache
            if (not need_reload) and float(cache_mtime) != float(db_mtime) and cache_age >= 30.0:
                need_reload = True
            if need_reload:
                cache = {}
                started = time.time()
                conn = _pkm_ro_connect(dbp, timeout=5.0)
                try:
                    rows = conn.execute("""
                        SELECT rating_key, score, rating, audience_rating, user_rating
                        FROM item_ratings
                        WHERE COALESCE(score, rating, audience_rating, user_rating, 0) > 0
                    """).fetchall()
                finally:
                    conn.close()
                for rr in rows:
                    key = str(rr[0] or "").strip()
                    if not key:
                        continue
                    val = ""
                    # Prefer score because item_ratings.score is the normalized PKM
                    # fallback score, then keep the raw Plex/IMDb values as backup.
                    for idx in (1, 2, 3, 4):
                        val = self._home_imdb_rating_value(rr[idx] if len(rr) > idx else "")
                        if val:
                            break
                    if val:
                        cache[key] = val
                self._home_imdb_rating_cache = cache
                self._home_imdb_rating_cache_mtime = db_mtime
                self._home_imdb_rating_cache_loaded_at = time.time()
                try:
                    _log("IMDB_TIMING source=db_bulk rows=%d elapsed=%.1fms" % (len(cache), (time.time() - started) * 1000.0))
                except Exception:
                    pass
            return cache.get(rk, "") or ""
        except Exception:
            try:
                _log("IMDB_TIMING source=db_error rating_key=%s err=%s" % (str(rating_key or ""), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
            return ""

    def _home_visible_imdb_rating_value(self, rating_key):
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return ""
            cache = getattr(self, "_home_visible_imdb_rating_cache", None)
            if isinstance(cache, dict):
                return cache.get(rk, "") or ""
        except Exception:
            pass
        return ""

    def _home_imdb_rating_cache_only_v2386(self, rating_key):
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return ""
            value = self._home_visible_imdb_rating_value(rk)
            if value:
                return value
            cache = getattr(self, "_home_imdb_rating_cache", None)
            return (cache.get(rk, "") or "") if isinstance(cache, dict) else ""
        except Exception:
            return ""

    def _home_watcha_cache_only_v2386(self, rating_key, title="", original_title="", year=""):
        empty = {"Rating": "", "Count": "", "Display": ""}
        try:
            rk = str(rating_key or "").strip()
            t = str(title or "").strip()
            ot = str(original_title or "").strip()
            y = str(year or "").strip()
            cache = getattr(self, "_home_watcha_preload_cache", None)
            if not isinstance(cache, dict):
                return empty
            by_rk = cache.get("by_rk", {}) or {}
            by_ty = cache.get("by_ty", {}) or {}
            if rk and rk in by_rk:
                return by_rk.get(rk) or empty
            if y:
                for name in (t, ot):
                    nk = self._watcha_title_key(name)
                    if nk:
                        result = by_ty.get((nk, y))
                        if result:
                            return result
        except Exception:
            pass
        return empty

    def _preload_visible_row_ratings(self, rows_or_entries, reason=""):
        """Batch-load ratings only for the rows that are about to be painted.

        v947: v943/v944 used full item_ratings/cine21_matches bulk maps on the UI
        thread before the first poster row was added.  Logs showed 90ms IMDb +
        190ms Cine21 pauses before POSTER_GEOM_BUILD, so Home widgets appeared
        late even though focus movement was smooth afterwards.  This function
        preloads only the current visible Home/section row set in one small DB
        pass, then _li_from_row reads these maps.  No network/crawl is used.
        """
        started = time.time()
        try:
            _reason_v2591 = str(reason or "")
            if self._is_android_v2591() and (
                self._uhd3_foreground_isolation_active_v2591()
                or "LIBRARY" in _reason_v2591.upper()
                or "SECTION_STARTUP_HYDRATED" in _reason_v2591.upper()
            ):
                self._home_visible_imdb_rating_cache = {}
                self._home_visible_cine21_rating_cache = {"by_rk": {}, "by_ty": {}}
                self._home_visible_rating_preload_ready = True
                _log("UHD3_VISIBLE_RATING_PRELOAD_BYPASS_V2591 reason=%s sql=0 firstpaint_priority=1" % _reason_v2591)
                return
            if self._wall_rapid_scroll_active_v2581():
                _log("VISIBLE_RATING_PRELOAD_SUPPRESS_WALL_RAPID_V2581 reason=%s" % (reason or ""))
                return
            movie_rows = []
            for entry in list(rows_or_entries or []):
                try:
                    row = entry.get("row") if isinstance(entry, dict) else entry
                    t = tuple(row or ())
                    if len(t) < 8:
                        continue
                    if str(t[2] or "") != "movie":
                        continue
                    rk = str(t[0] or "").strip()
                    title = str(t[4] or "").strip()
                    original = str(t[5] or "").strip()
                    year = str(t[7] or "").strip()
                    duration = str(t[9] or "") if len(t) > 9 else ""
                    if rk or title:
                        movie_rows.append((rk, title, original, year, duration))
                except Exception:
                    continue
            imdb_cache = {}
            cine_cache = {"by_rk": {}, "by_ty": {}}
            self._home_visible_imdb_rating_cache = imdb_cache
            self._home_visible_cine21_rating_cache = cine_cache
            self._home_visible_rating_preload_ready = True
            if not movie_rows:
                return
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return
            keys = []
            seen_keys = set()
            years = []
            seen_years = set()
            names = []
            seen_names = set()
            for rk, title, original, year, duration in movie_rows:
                if rk and rk not in seen_keys:
                    seen_keys.add(rk)
                    keys.append(rk)
                if year and year not in seen_years:
                    seen_years.add(year)
                    years.append(year)
                for name in (title, original):
                    if name and name not in seen_names:
                        seen_names.add(name)
                        names.append(name)

            conn = _pkm_ro_connect(dbp, timeout=5.0)
            try:
                if keys:
                    ph = ",".join(["?"] * len(keys))
                    try:
                        rows = conn.execute("""
                            SELECT rating_key, score, rating, audience_rating, user_rating
                            FROM item_ratings
                            WHERE rating_key IN (%s)
                              AND COALESCE(score, rating, audience_rating, user_rating, 0) > 0
                        """ % ph, keys).fetchall()
                    except Exception:
                        rows = []
                    for rr in rows or []:
                        key = str(rr[0] or "").strip()
                        if not key:
                            continue
                        val = ""
                        for idx in (1, 2, 3, 4):
                            val = self._home_imdb_rating_value(rr[idx] if len(rr) > idx else "")
                            if val:
                                break
                        if val:
                            imdb_cache[key] = val

                    # v2259: exact ratingKey가 비어 있는 보이는 영화는 동일 제목/연도
                    # 복제본의 현재 item_ratings에서 평점을 상속한다. 이전 canonical
                    # bulk index가 DB 갱신 직후 stale일 때도 현재 스냅샷을 사용한다.
                    missing_visible_v2259 = [m for m in movie_rows if str(m[0] or "").strip() not in imdb_cache]
                    if missing_visible_v2259 and years:
                        try:
                            ph_y_rating_v2259 = ",".join(["?"] * len(years))
                            missing_names_v2627 = []
                            seen_missing_names_v2627 = set()
                            for _m_v2627 in missing_visible_v2259:
                                for _name_v2627 in (_m_v2627[1], _m_v2627[2]):
                                    _name_v2627 = str(_name_v2627 or "").strip()
                                    if _name_v2627 and _name_v2627 not in seen_missing_names_v2627:
                                        seen_missing_names_v2627.add(_name_v2627)
                                        missing_names_v2627.append(_name_v2627)
                            if missing_names_v2627:
                                ph_n_rating_v2627 = ",".join(["?"] * len(missing_names_v2627))
                                duplicate_rows_v2259 = conn.execute("""
                                    SELECT i.rating_key, i.title, i.original_title,
                                           CAST(COALESCE(i.year,'') AS TEXT), i.duration,
                                           r.score, r.rating, r.audience_rating, r.user_rating
                                    FROM items i
                                    JOIN item_ratings r ON r.rating_key=i.rating_key
                                    WHERE i.plex_type='movie'
                                      AND CAST(COALESCE(i.year,'') AS TEXT) IN (%s)
                                      AND (i.title IN (%s) OR i.original_title IN (%s))
                                      AND COALESCE(r.score, r.rating, r.audience_rating, r.user_rating, 0) > 0
                                """ % (ph_y_rating_v2259, ph_n_rating_v2627, ph_n_rating_v2627),
                                list(years) + list(missing_names_v2627) + list(missing_names_v2627)).fetchall()
                            else:
                                duplicate_rows_v2259 = []
                        except Exception:
                            duplicate_rows_v2259 = []

                        dup_map_v2259 = {}
                        for dr in duplicate_rows_v2259 or []:
                            source_rk_v2259 = str(dr[0] or "").strip()
                            source_year_v2259 = str(dr[3] or "").strip()
                            source_duration_v2259 = _safe_int(dr[4], 0)
                            source_rating_v2259 = ""
                            for idx_v2259 in (5, 6, 7, 8):
                                source_rating_v2259 = self._home_imdb_rating_value(dr[idx_v2259] if len(dr) > idx_v2259 else "")
                                if source_rating_v2259:
                                    break
                            if not source_rating_v2259:
                                continue
                            for source_name_v2259 in (dr[1] if len(dr) > 1 else "", dr[2] if len(dr) > 2 else ""):
                                norm_name_v2259 = self._dedup_text_key(source_name_v2259)
                                if not norm_name_v2259 or not source_year_v2259:
                                    continue
                                dup_map_v2259.setdefault((norm_name_v2259, source_year_v2259), []).append(
                                    (source_rk_v2259, source_duration_v2259, source_rating_v2259)
                                )

                        for target_rk_v2259, target_title_v2259, target_original_v2259, target_year_v2259, target_duration_v2259 in missing_visible_v2259:
                            target_rk_v2259 = str(target_rk_v2259 or "").strip()
                            target_year_v2259 = str(target_year_v2259 or "").strip()
                            target_duration_i_v2259 = _safe_int(target_duration_v2259, 0)
                            candidates_v2259 = []
                            seen_source_v2259 = set()
                            for target_name_v2259 in (target_title_v2259, target_original_v2259):
                                norm_target_v2259 = self._dedup_text_key(target_name_v2259)
                                for candidate_v2259 in dup_map_v2259.get((norm_target_v2259, target_year_v2259), []):
                                    source_rk_v2259 = str(candidate_v2259[0] or "").strip()
                                    if not source_rk_v2259 or source_rk_v2259 == target_rk_v2259 or source_rk_v2259 in seen_source_v2259:
                                        continue
                                    seen_source_v2259.add(source_rk_v2259)
                                    candidates_v2259.append(candidate_v2259)
                            candidates_v2259.sort(
                                key=lambda c: abs(_safe_int(c[1], 0) - target_duration_i_v2259)
                                if target_duration_i_v2259 > 0 and _safe_int(c[1], 0) > 0 else 0
                            )
                            for source_rk_v2259, source_duration_v2259, source_rating_v2259 in candidates_v2259:
                                if target_duration_i_v2259 > 0 and _safe_int(source_duration_v2259, 0) > 0:
                                    if abs(target_duration_i_v2259 - _safe_int(source_duration_v2259, 0)) > 900:
                                        continue
                                imdb_cache[target_rk_v2259] = source_rating_v2259
                                _log("RATING_ROW_CANONICAL_INHERIT_V2259 rating_key=%s source_key=%s title=%s year=%s rating=%s" % (
                                    target_rk_v2259, source_rk_v2259,
                                    _short_log_value(target_title_v2259, 80),
                                    target_year_v2259, source_rating_v2259
                                ))
                                break

                    try:
                        rows = conn.execute("""
                            SELECT rating_key, pkm_title, pkm_original_title, cine21_title, pkm_year,
                                   critic_rating, audience_rating, updated_at
                            FROM cine21_matches
                            WHERE rating_key IN (%s)
                              AND match_status='MATCHED'
                              AND COALESCE(pkm_quality_status,'') IN ('', 'PKM_METADATA_OK')
                              AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
                            ORDER BY COALESCE(updated_at, 0) DESC
                        """ % ph, keys).fetchall()
                    except Exception:
                        rows = []
                    for rr in rows or []:
                        critic = self._format_cine21_rating_value(rr[5] if len(rr) > 5 else "")
                        audience = self._format_cine21_rating_value(rr[6] if len(rr) > 6 else "")
                        if not (critic or audience):
                            continue
                        result = {"CriticRating": critic, "AudienceRating": audience}
                        rk = str(rr[0] or "").strip()
                        if rk and rk not in cine_cache["by_rk"]:
                            cine_cache["by_rk"][rk] = result
                        yy = str(rr[4] or "").strip()
                        if yy:
                            for name in (rr[1] if len(rr) > 1 else "", rr[2] if len(rr) > 2 else "", rr[3] if len(rr) > 3 else ""):
                                name_s = str(name or "").strip()
                                if name_s and (name_s, yy) not in cine_cache["by_ty"]:
                                    cine_cache["by_ty"][(name_s, yy)] = result

                # Same-title/year duplicate fallback for the visible row set.
                # Limit the query to visible years/names only, not the whole DB.
                if years and names:
                    ph_y = ",".join(["?"] * len(years))
                    ph_n = ",".join(["?"] * len(names))
                    params = list(years) + list(names) + list(names) + list(names)
                    try:
                        rows = conn.execute("""
                            SELECT rating_key, pkm_title, pkm_original_title, cine21_title, pkm_year,
                                   critic_rating, audience_rating, updated_at
                            FROM cine21_matches
                            WHERE match_status='MATCHED'
                              AND COALESCE(pkm_quality_status,'') IN ('', 'PKM_METADATA_OK')
                              AND CAST(COALESCE(pkm_year,'') AS TEXT) IN (%s)
                              AND (pkm_title IN (%s) OR pkm_original_title IN (%s) OR cine21_title IN (%s))
                              AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
                            ORDER BY COALESCE(updated_at, 0) DESC
                        """ % (ph_y, ph_n, ph_n, ph_n), params).fetchall()
                    except Exception:
                        rows = []
                    for rr in rows or []:
                        critic = self._format_cine21_rating_value(rr[5] if len(rr) > 5 else "")
                        audience = self._format_cine21_rating_value(rr[6] if len(rr) > 6 else "")
                        if not (critic or audience):
                            continue
                        result = {"CriticRating": critic, "AudienceRating": audience}
                        yy = str(rr[4] or "").strip()
                        if yy:
                            for name in (rr[1] if len(rr) > 1 else "", rr[2] if len(rr) > 2 else "", rr[3] if len(rr) > 3 else ""):
                                name_s = str(name or "").strip()
                                if name_s and (name_s, yy) not in cine_cache["by_ty"]:
                                    cine_cache["by_ty"][(name_s, yy)] = result
                            rk = str(rr[0] or "").strip()
                            if rk and rk not in cine_cache["by_rk"]:
                                cine_cache["by_rk"][rk] = result
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            try:
                _log("RATING_ROW_PRELOAD source=visible_batch reason=%s movies=%d keys=%d imdb=%d cine21_rk=%d cine21_ty=%d elapsed=%.1fms" % (
                    reason or "", len(movie_rows), len(keys), len(imdb_cache), len(cine_cache.get("by_rk", {})), len(cine_cache.get("by_ty", {})), (time.time() - started) * 1000.0
                ))
            except Exception:
                pass
        except Exception:
            self._home_visible_imdb_rating_cache = {}
            self._home_visible_cine21_rating_cache = {"by_rk": {}, "by_ty": {}}
            self._home_visible_rating_preload_ready = True
            try:
                _log("RATING_ROW_PRELOAD source=visible_batch_error reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass

    def _prepaint_home_meta_from_row(self, row, row_title="", row_type="", reason=""):
        """Fast first-paint for startup Home metadata/fanart.

        v945: startup Home used to wait until all Home rows and rating preloads
        were rendered before the hero area received title/summary/fanart.  That
        made the Home screen appear with empty/late metadata.  This helper uses
        the first already-known DB row only, with no network and no Cine21/IMDb
        bulk lookup, so the hero fanart and basic metadata start loading before
        the off-screen rows are built.  The normal ListItem meta sync still runs
        later and fills Cine21/IMDb/genre/director without changing focus flow.
        """
        try:
            t = tuple(row or ())
            if len(t) < 21:
                return False
            rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = t[:21]
            parent_rating_key = t[21] if len(t) > 21 else ""
            grandparent_rating_key = t[22] if len(t) > 22 else ""
            view_offset = t[23] if len(t) > 23 else ""
            resume_duration_ms = t[24] if len(t) > 24 else ""

            rating_key = str(rating_key or "")
            plex_type = str(plex_type or "")
            title = str(title or "")
            show_title = str(show_title or "")
            year = str(year or "")
            summary = str(summary or "")
            fanart = str(art or "")
            poster = str(thumb or "")
            duration_raw = str(duration or "")
            view_offset = str(view_offset or "")

            # Keep this function DB-only and cheap.  Do not call episode show-art
            # fallback or any rating/Cine21 lookup here.  The full ListItem sync
            # immediately follows after row render and will enrich sparse values.
            hero_title, episode_title = self._home_titles_for_meta(plex_type, title, show_title, episode)
            duration_text = self._duration_text(duration_raw)
            remaining_text, remaining_icon = self._remaining_time_props(resume_duration_ms or duration_raw, view_offset)
            meta_line = self._home_meta_line(plex_type, show_title, season, episode, year, duration_text, "", "", added_at)
            director_line = ""
            play_url = ""
            try:
                if part_key and plex_type in ("movie", "episode"):
                    play_url = _pkm_play_url(rating_key, part_key, mode="start")
            except Exception:
                play_url = ""

            props = {
                "Title": hero_title,
                "TitleDisplay": self._title_display_text(hero_title),
                "EpisodeTitle": episode_title,
                "Year": year,
                "Summary": summary,
                "SummaryDisplay": self._home_summary_display_text_v2179(summary),
            "SummaryLineCount": str(self._home_summary_line_count_v2240(self._home_summary_display_text_v2179(summary))),
                "Poster": poster,
                "DurationText": duration_text,
                "RemainingText": remaining_text,
                "RemainingIcon": remaining_icon,
                "MetaLine": meta_line,
                "MetaLineBaseV2291": self._home_meta_line_base_v2291(plex_type, season, episode, year, duration_text),
                "Genre": "",
                "GenreLine": "",
                "Director": "",
                "DirectorLine": director_line,
                "DirectorLineUseOpenSans": "0",
                "ContentRating": "",
                "Rating": "",
                "Cine21CriticRating": "",
                "Cine21AudienceRating": "",
                "Cine21BarDisplay": "",
                "WatchaRating": "",
                "WatchaCount": "",
                "WatchaDisplay": "",
                "WatchaBarDisplay": "",
                "ImdbRating": "",
                "RatingBarDisplay": "",
                "TmdbRating": "",
                "Type": plex_type,
                "RatingKey": rating_key,
                "PlayUrl": play_url,
                # v1597: Publish the focused Home row type before the first paint so
                # non-Continue widgets can use their own metadata-line alignment
                # without changing the Continue Watching reference layout.
                "RowType": str(row_type or ""),
            }
            win = xbmcgui.Window(10000)
            for k, v in props.items():
                val = str(v or "")
                win.setProperty("PlexKM.Home.%s" % k, val)
                try:
                    self.setProperty("PlexKM.Home.%s" % k, val)
                except Exception:
                    pass
            try:
                self._tmdb_fill_home_apply_r41(rating_key, reason="prepaint")
            except Exception:
                pass
            if fanart:
                self._set_home_fanart_smooth(fanart, reason=reason or "home_prepaint")
            try:
                self.getControl(TITLE_ID).setLabel(self._title_display_text(hero_title) or "")
            except Exception:
                pass
            try:
                if row_title:
                    row_title = _display_library_title(row_title)
                    self.getControl(COUNT_ID).setLabel(row_title)
                    win.setProperty("PlexKM.Window.CountLabel", row_title)
                    try:
                        self.setProperty("PlexKM.Window.CountLabel", row_title)
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                self._remember_meta_hint(rating_key, title=title, year=year, section_id=section_id, plex_type=plex_type)
            except Exception:
                pass
            _log("HOME_INITIAL_META_PREPAINT reason=%s title=%s fanart=%s row_title=%s rating_key=%s" % (
                reason or "", hero_title, "yes" if fanart else "no", row_title or "", rating_key
            ))
            return True
        except Exception:
            _log("HOME_INITIAL_META_PREPAINT_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _clear_all_home_metadata_v2034(self, reason=""):
        keys = (
            "Title", "SubTitle", "Meta", "MetaLine", "MetaLineBaseV2291", "Summary", "Genre", "Director",
            "Year", "Duration", "DurationText", "ContentRating", "Rating",
            "RatingKey", "Type", "EpisodeTitle", "ShowTitle", "Season", "Episode",
            "HeroBodyReadyV2251", "HeroBodyPendingRatingKeyV2251",
            "RemainingText", "RemainingIcon", "Fanart", "DisplayFanart", "DisplayFanartRaw",
            "Poster", "Thumb", "Cine21CriticRating", "Cine21AudienceRating",
            "Cine21BarDisplay", "WatchaRating", "WatchaCount", "WatchaDisplay",
            "WatchaBarDisplay", "IMDbRating", "RatingBarDisplay", "CountLabel",
            "AddedAt", "SectionId", "PlayUrl", "ShowUrl", "Art",
            "EpisodeMeta", "SeasonEpisode", "Resolution", "Studio",
        )
        win = xbmcgui.Window(10000)
        for key in keys:
            for prefix in ("PlexKM.Home.", "PlexKM.Window."):
                try:
                    win.clearProperty(prefix + key)
                except Exception:
                    pass
                try:
                    self.clearProperty(prefix + key)
                except Exception:
                    pass
        try:
            self._home_meta_enrich_cache.clear()
        except Exception:
            self._home_meta_enrich_cache = {}
        try:
            self._home_meta_hint_cache.clear()
        except Exception:
            pass
        try:
            self._home_fanart_current = ""
            self._home_bg_current_fanart = ""
            self._home_bg_target_fanart_v2314 = ""
            self._home_bg_target_since_ms_v2314 = 0
            self._set_home_fanart_smooth("", reason="clear_v2034:%s" % (reason or ""))
            self.getControl(TITLE_ID).setLabel("")
        except Exception:
            pass
        _log("HOME_METADATA_HARD_CLEAR_V2034 reason=%s" % (reason or ""))

    def _home_movie_resolution_r102(self, li, rating_key=""):
        """R102: hero resolution badge text ("1080P") for THIS movie's own file.

        Same rule as Info's _info_movie_resolution_first_frame_vnext so both show the
        identical text: ListItem raw value -> 4K flag -> one primary-key read of this
        rating key's own row (cached per key; never a sibling copy, never network).
        """
        rk = str(rating_key or (li.getProperty("PlexKM.RatingKey") if li else "") or "").strip()
        if not rk:
            return ""
        cache = getattr(self, "_home_resolution_cache_r102", None)
        if cache is None:
            cache = self._home_resolution_cache_r102 = {}
        if rk in cache:
            return cache[rk]
        res = str((li.getProperty("PlexKM.SourceResolutionFirstVNext") if li else "") or "").strip().lower()
        if res not in ("720p", "1080p", "2160p"):
            res = "2160p" if (li is not None and li.getProperty("PlexKM.Is4K") == "1") else ""
        if not res:
            try:
                dbp = self._profile_db_path()
                if dbp and os.path.exists(dbp):
                    conn = _pkm_ro_connect(dbp, timeout=0.5)
                    try:
                        row = conn.execute(
                            "SELECT raw_json FROM items WHERE rating_key=? AND plex_type='movie' LIMIT 1", (rk,)
                        ).fetchone()
                    finally:
                        try:
                            conn.close()
                        except Exception:
                            pass
                    rawv = pkm_library_sort.sort_raw_values(row[0]) if row and row[0] else {}
                    r = str(rawv.get("resolution") or "").strip().lower()
                    h = _safe_int(rawv.get("height"), 0)
                    if r in ("4k", "uhd", "2160", "2160p") or "2160" in r or h >= 2000:
                        res = "2160p"
                    elif "1080" in r or h >= 1000:
                        res = "1080p"
                    elif "720" in r or h >= 700:
                        res = "720p"
            except Exception:
                res = ""
        out = res.upper()
        if len(cache) > 4000:
            cache.clear()
        cache[rk] = out
        return out

    def _set_home_meta_from_item(self, li=None, reason=""):
        try:
            # V2034: an unconfigured/reset Home never inherits a previously focused
            # ListItem or enriched metadata. Empty Home is authoritative.
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.Home.SettingsRequired") == "1":
                    self._clear_all_home_metadata_v2034(reason="settings_required:%s" % (reason or ""))
                    return
            except Exception:
                pass
            if li is None:
                li = self._first_wall_item_for_home_meta()
                if li is None:
                    return
            else:
                # Menu/folder items have labels such as '홈' and no media keys.
                # Do not allow them to clear the fanart/summary/title area.
                if not (li.getProperty("PlexKM.RatingKey") or li.getProperty("PlexKM.PlayUrl") or li.getProperty("PlexKM.ShowUrl")):
                    media_li = self._first_wall_item_for_home_meta()
                    if media_li is not None:
                        li = media_li
            title = li.getProperty("PlexKM.Title") or li.getLabel() or ""
            year = li.getProperty("PlexKM.Year") or ""
            added_at = li.getProperty("PlexKM.AddedAt") or ""
            summary = li.getProperty("PlexKM.Summary") or ""
            fanart = li.getProperty("PlexKM.Art") or li.getArt("fanart") or ""
            thumb = li.getProperty("PlexKM.Thumb") or li.getArt("poster") or li.getArt("thumb") or ""
            # Do not fall back to poster/thumb for the hero fanart.
            # Plex HTPC keeps the right-top background as true 16:9 artwork;
            # using a poster here creates the tall/vertical image artifact.
            duration_raw = li.getProperty("PlexKM.Duration") or ""
            view_offset = li.getProperty("PlexKM.ViewOffset") or ""
            duration = self._duration_text(duration_raw)
            show_title = li.getProperty("PlexKM.ShowTitle") or ""
            season = li.getProperty("PlexKM.Season") or ""
            episode = li.getProperty("PlexKM.Episode") or ""
            plex_type = li.getProperty("PlexKM.Type") or ""
            genre = li.getProperty("PlexKM.Genre") or ""
            director = li.getProperty("PlexKM.Director") or ""
            content_rating = li.getProperty("PlexKM.ContentRating") or ""
            rating = li.getProperty("PlexKM.Rating") or ""
            rating_key = li.getProperty("PlexKM.RatingKey") or ""
            section_id = li.getProperty("PlexKM.SectionId") or ""
            self._remember_meta_hint(rating_key, title=title, year=year, section_id=section_id, plex_type=plex_type)

            cached = self._home_meta_enrich_cache.get(rating_key) if rating_key else None
            rating_verified_exact = bool(
                isinstance(cached, dict)
                and str(cached.get("ContentRatingPMSVerified") or "") == "1"
                and str(cached.get("ContentRatingVerifiedRatingKey") or "") == str(rating_key or "")
            )
            if cached:
                title = cached.get("Title") or title
                year = cached.get("Year") or year
                summary = cached.get("Summary") or summary
                fanart = cached.get("Fanart") or fanart
                thumb = cached.get("Poster") or thumb
                duration_raw = cached.get("Duration") or duration_raw
                view_offset = cached.get("ViewOffset") or view_offset
                duration = cached.get("DurationText") or duration
                genre = cached.get("Genre") or genre
                director = cached.get("Director") or director
                content_rating = cached.get("ContentRating") or content_rating
                rating = cached.get("Rating") or rating

            _home_nav_hot_v2386 = self._home_focus_hotpath_v2386(reason)
            if not genre and rating_key:
                # R42: genre is local Plex data; do not wait for the deferred
                # network enrich (UHD defers it during navigation).
                try:
                    _g_t0_r42 = time.time()
                    genre = self._home_db_genre_value_v1801(
                        rating_key,
                        li.getProperty("PlexKM.ParentRatingKey") or "",
                        li.getProperty("PlexKM.GrandparentRatingKey") or "",
                        plex_type, section_id=section_id) or ""
                    if genre:
                        li.setProperty("PlexKM.Genre", genre)
                    _log("HOME_GENRE_LOCAL_R42 rating_key=%s found=%d ms=%.1f" % (
                        rating_key, 1 if genre else 0, (time.time() - _g_t0_r42) * 1000.0))
                except Exception:
                    genre = ""
            if plex_type == "movie" and not rating:
                rating = (
                    self._home_imdb_rating_cache_only_v2386(rating_key)
                    if _home_nav_hot_v2386
                    else self._home_db_imdb_rating_value(rating_key)
                )
                if rating:
                    try:
                        li.setProperty("PlexKM.Rating", rating)
                    except Exception:
                        pass
            elif plex_type != "movie" and not rating:
                tv_rating_key = (
                    li.getProperty("PlexKM.GrandparentRatingKey")
                    or li.getProperty("PlexKM.ParentRatingKey")
                    or rating_key
                )
                rating = (
                    self._home_imdb_rating_cache_only_v2386(tv_rating_key)
                    if _home_nav_hot_v2386
                    else self._home_db_imdb_rating_value(tv_rating_key)
                )
                if rating:
                    try:
                        li.setProperty("PlexKM.Rating", rating)
                    except Exception:
                        pass

            hero_title, episode_title = self._home_titles_for_meta(plex_type, title, show_title, episode)
            if cached:
                hero_title = cached.get("Title") or hero_title
                episode_title = cached.get("EpisodeTitle") or episode_title

            remaining_text, remaining_icon = self._remaining_time_props(duration_raw, view_offset)
            _home_meta_cine21_start = time.time()
            cine21_source = "none"
            watcha_source = "none"
            if plex_type == "movie":
                pre_critic = li.getProperty("PlexKM.Cine21CriticRating") or ""
                pre_audience = li.getProperty("PlexKM.Cine21AudienceRating") or ""
                if pre_critic or pre_audience:
                    # v943: visible row preload already populated Cine21 while the
                    # panel was being built.  Focus movement should only copy the
                    # property to the Home meta area.
                    cine21_props = {"CriticRating": pre_critic, "AudienceRating": pre_audience}
                    cine21_source = "listitem_preload"
                else:
                    cine21_props = (
                        self._home_cine21_cache_only_v2386(
                            rating_key, title=title,
                            original_title=li.getProperty("PlexKM.OriginalTitle") or "", year=year
                        )
                        if _home_nav_hot_v2386
                        else self._home_cine21_rating_props(
                            rating_key, title=title,
                            original_title=li.getProperty("PlexKM.OriginalTitle") or "", year=year
                        )
                    )
                    if cine21_props.get("CriticRating") or cine21_props.get("AudienceRating"):
                        try:
                            li.setProperty("PlexKM.Cine21CriticRating", cine21_props.get("CriticRating", ""))
                            li.setProperty("PlexKM.Cine21AudienceRating", cine21_props.get("AudienceRating", ""))
                        except Exception:
                            pass
                    if _home_nav_hot_v2386:
                        cine21_source = "memory_cache_v2386" if (cine21_props.get("CriticRating") or cine21_props.get("AudienceRating")) else "cache_miss_v2386"
                    else:
                        cine21_source = "focus_db"
                pre_watcha_rating = li.getProperty("PlexKM.WatchaRating") or ""
                pre_watcha_count = li.getProperty("PlexKM.WatchaCount") or ""
                pre_watcha_display = li.getProperty("PlexKM.WatchaDisplay") or ""
                if pre_watcha_rating or pre_watcha_display:
                    watcha_props = {"Rating": pre_watcha_rating, "Count": pre_watcha_count, "Display": pre_watcha_display or (("%s(%s)" % (pre_watcha_rating, pre_watcha_count)) if pre_watcha_count else pre_watcha_rating)}
                    watcha_source = "listitem_preload"
                else:
                    watcha_props = (
                        self._home_watcha_cache_only_v2386(
                            rating_key, title=title,
                            original_title=li.getProperty("PlexKM.OriginalTitle") or "", year=year
                        )
                        if _home_nav_hot_v2386
                        else self._home_watcha_preload_props(
                            rating_key, title=title,
                            original_title=li.getProperty("PlexKM.OriginalTitle") or "", year=year
                        )
                    )
                    if watcha_props.get("Rating") or watcha_props.get("Display"):
                        try:
                            li.setProperty("PlexKM.WatchaRating", watcha_props.get("Rating", ""))
                            li.setProperty("PlexKM.WatchaCount", watcha_props.get("Count", ""))
                            li.setProperty("PlexKM.WatchaDisplay", watcha_props.get("Display", ""))
                        except Exception:
                            pass
                    if _home_nav_hot_v2386:
                        watcha_source = "memory_cache_v2386" if (watcha_props.get("Rating") or watcha_props.get("Display")) else "cache_miss_v2386"
                    else:
                        watcha_source = "focus_db"
            else:
                cine21_props = {"CriticRating": "", "AudienceRating": ""}
                watcha_props = {"Rating": "", "Count": "", "Display": ""}
            # v2386: reaching this point from navigation is cache/ListItem-only.
            if _home_nav_hot_v2386:
                _log("HOME_FOCUS_CACHE_ONLY_V2386 reason=%s rating_key=%s db_query=0 plex_request=0 actor_prewarm=0 python_nav=0" % (
                    reason or "", rating_key or ""
                ))
            # v1579: IMDb is an independent source.  Cine21/Watcha must not suppress it.
            imdb_rating = self._home_imdb_rating_value(rating) if plex_type == "movie" else ""
            cine21_bar_display = self._home_cine21_bar_display(cine21_props) if plex_type == "movie" else ""
            watcha_bar_display = self._home_watcha_bar_display(watcha_props) if plex_type == "movie" else ""
            rating_bar_display = self._home_rating_bar_display(cine21_props, watcha_props, imdb_rating) if plex_type == "movie" else ""
            try:
                _log("HOME_META_TIMING rating_key=%s type=%s cine21=%s/%s source=%s watcha=%s source=%s elapsed=%.1fms" % (
                    rating_key, plex_type, cine21_props.get("CriticRating", ""), cine21_props.get("AudienceRating", ""), cine21_source, watcha_props.get("Display", "") or watcha_props.get("Rating", ""), watcha_source,
                    (time.time() - _home_meta_cine21_start) * 1000.0
                ))
            except Exception:
                pass

            win = xbmcgui.Window(10000)
            director_line = self._person_list_display_text(director) if plex_type == "movie" else ""
            props = {
                "Title": hero_title, "TitleDisplay": self._title_display_text(hero_title), "EpisodeTitle": episode_title, "Year": year, "Summary": summary,
                "SummaryDisplay": self._home_summary_display_text_v2179(summary),
            "SummaryLineCount": str(self._home_summary_line_count_v2240(self._home_summary_display_text_v2179(summary))), "Fanart": fanart,
                "Poster": thumb, "DurationText": duration,
                "RemainingText": remaining_text, "RemainingIcon": remaining_icon,
                "MetaLine": self._home_meta_line(plex_type, show_title, season, episode, year, duration, content_rating, rating if plex_type == "movie" else "", added_at),
                "MetaLineBaseV2291": self._home_meta_line_base_v2291(plex_type, season, episode, year, duration),
                "Genre": genre, "GenreLine": self._genre_display_text(genre),
                "Director": director, "DirectorLine": director_line,
                "DirectorLineUseOpenSans": "1" if self._text_has_cyrillic(director_line) else "0",
                "ContentRating": content_rating, "Rating": rating,
                "Cine21CriticRating": cine21_props.get("CriticRating", ""),
                "Cine21AudienceRating": cine21_props.get("AudienceRating", ""),
                "Cine21BarDisplay": cine21_bar_display,
                "WatchaRating": watcha_props.get("Rating", ""),
                "WatchaCount": watcha_props.get("Count", ""),
                "WatchaDisplay": watcha_props.get("Display", ""),
                "WatchaBarDisplay": watcha_bar_display,
                "ImdbRating": imdb_rating,
                "RatingBarDisplay": rating_bar_display,
                "TmdbRating": self._home_tmdb_rating_value(rating) if plex_type != "movie" else "",
                "Type": plex_type, "RatingKey": rating_key,
                # R102: movie resolution badge on the hero meta line (same text Info shows
                # from PlexKM.Info.VersionIconLabel, so Home -> Info stays stationary).
                "Resolution": (self._home_movie_resolution_r102(li, rating_key) if plex_type == "movie" else ""),
                "PlayUrl": li.getProperty("PlexKM.PlayUrl") or "",
                # v1597: Keep Continue Watching untouched and identify every other
                # Home/section widget from the ListItem's canonical row type.
                "RowType": li.getProperty("PlexKM.HomeRowType") or "",
            }
            # R155: a score already visible on Home must be reusable in a
            # Section/Library ListItem for the same title and ratingKey.
            self._r155_rating_record(li, props)
            try:
                self._tmdb_fill_ctx_set_r41(li)
            except Exception:
                pass
            if bool(getattr(self, "_home_meta_capture_only_v1619", False)):
                self._home_meta_snapshot_v1619 = {
                    "props": dict(props),
                    "fanart": str(fanart or ""),
                    "hero_title": str(hero_title or ""),
                    "li": li,
                    "rating_verified_exact": bool(rating_verified_exact),
                }
                _log("META_ATOMIC_CAPTURE_V1619 reason=%s title=%s fanart=%s rating_key=%s" % (
                    reason or "", _short_log_value(hero_title), "yes" if fanart else "no", rating_key or ""
                ))
                return

            # v2264: V2251's asynchronous Home-body HOLD is retired.
            # Since v2252-v2255 the genre/rating slots, synopsis top, and 156px
            # synopsis height are fixed. Missing metadata can therefore stay blank
            # and fill in-place later without moving the synopsis. Publish every
            # locally available property immediately and never hide a completed
            # synopsis while Plex enrichment is pending/cached.
            need_director = (plex_type == "movie")
            need_rating_verify = bool(plex_type == "movie" and not rating_verified_exact)
            need_tv_rating = bool(plex_type != "movie" and not rating)

            _r88_l0 = time.perf_counter()
            for k, v in props.items():
                if k == "Fanart":
                    continue
                val = str(v or "")
                win.setProperty("PlexKM.Home.%s" % k, val)
                try:
                    self.setProperty("PlexKM.Home.%s" % k, val)
                except Exception:
                    pass
            _r88_l1 = time.perf_counter()

            # R41: fill empty synopsis / TV rating / genre from the TMDb cache.
            self._tmdb_fill_home_apply_r41(rating_key, reason=reason or "meta_sync")
            self._tmdb_fill_prefetch_focus_r43(reason=reason or "meta_sync")
            _r88_l2 = time.perf_counter()
            # Compatibility property only. It no longer controls Home visibility.
            self._set_home_hero_body_ready_v2251(
                rating_key, True, reason="v2264_local_publish_%s" % (reason or "meta")
            )
            _r88_l3 = time.perf_counter()
            self._set_home_fanart_smooth(fanart, reason=reason)
            if not fanart:
                self._tmdb_fill_home_fanart_r42(rating_key, reason=reason or "meta_sync")
            try:
                _log("META_BREAKDOWN_R88 rating_key=%s props=%d set_props_ms=%.1f tmdb_fill_ms=%.1f hero_flag_ms=%.1f fanart_ms=%.1f" % (
                    rating_key, len(props), (_r88_l1 - _r88_l0) * 1000.0, (_r88_l2 - _r88_l1) * 1000.0,
                    (_r88_l3 - _r88_l2) * 1000.0, (time.perf_counter() - _r88_l3) * 1000.0
                ))
            except Exception:
                pass
            try:
                if self.active_section_id == "__home__":
                    row_title = _display_library_title(li.getProperty("PlexKM.HomeRowTitle") or "홈")
                    self.getControl(COUNT_ID).setLabel(row_title)
                    win.setProperty("PlexKM.Window.CountLabel", row_title)
                    try:
                        self.setProperty("PlexKM.Window.CountLabel", row_title)
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                # Some Kodi builds do not refresh Window.Property labels fast
                # enough in WindowXMLDialog after setLabel() was used before.
                # Update the hero title control directly as a safe fallback.
                self.getControl(TITLE_ID).setLabel(self._title_display_text(hero_title) or "")
            except Exception:
                pass
            # v2385: normal Home/wall/widget focus never prepares actors.
            # Home only publishes the focused item's already-local metadata/fanart.
            # Bumping the token cancels a stale 250ms cast task from a surface the
            # user has already left, without starting any replacement worker.
            try:
                self._cast_focus_idle_token_v1642 = int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0) + 1
            except Exception:
                pass
            # v1570: movie rows can be restored from local/list caches whose
            # contentRating was normalized differently from the current PMS item.
            # Verify once against the exact focused ratingKey, then cache that
            # result. This prevents Home and Info from showing different labels
            # for the same poster (for example 청불 vs 18세).
            if rating_key and (not summary or not genre or not content_rating or (need_director and not director) or need_rating_verify or need_tv_rating):
                _defer_enrich_v2600 = False
                try:
                    _defer_enrich_v2600 = bool(self._is_android_v2591() and self._uhd3_foreground_isolation_active_v2591())
                except Exception:
                    _defer_enrich_v2600 = False
                if _defer_enrich_v2600:
                    _log("UHD_META_ENRICH_DEFER_V2600 rating_key=%s reason=%s navigation_hot=1 network=0 db_extra=0" % (
                        rating_key, reason or ""
                    ))
                else:
                    self._start_home_meta_enrich(
                        rating_key, reason=reason, force_rating_refresh=need_rating_verify
                    )
            _log("META_SYNC reason=%s title=%s episode_title=%s fanart=%s genre=%s director=%s rating=%s" % (
                reason, hero_title, episode_title, "yes" if fanart else "no", "yes" if genre else "no", "yes" if director else "no", content_rating or rating or "no"))
        except Exception:
            _log("META_SYNC_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _poster_authority_sources_v2498(self, li):
        """Return only portrait-poster authorities, never fanart/background fallback.

        V2496 flattened poster and PosterFallbackArt into one Textures13 lookup.
        Since PosterFallbackArt historically contained landscape ``art`` for many
        cards, SQLite row order could make a fanart cache file win and then be
        rebound as the poster.  V2498 keeps the semantic roles separate.
        """
        sources = []
        if not li:
            return sources
        try:
            poster_role_fallback = str(li.getProperty("PlexKM.PosterFallbackRoleV2498") or "").strip().lower() == "poster"
        except Exception:
            poster_role_fallback = False
        values = []
        for getter in (
            lambda: li.getProperty("PlexKM.PosterAuthorityV2498"),
            lambda: li.getProperty("PlexKM.WallPosterRemoteV1644"),
            lambda: li.getProperty("PlexKM.Thumb"),
            lambda: li.getProperty("PlexKM.OriginalThumbV1877"),
            lambda: li.getArt("poster"),
            lambda: li.getArt("thumb"),
        ):
            try:
                values.append(str(getter() or "").strip())
            except Exception:
                pass
        if poster_role_fallback:
            try:
                values.append(str(li.getProperty("PlexKM.PosterFallbackArt") or "").strip())
            except Exception:
                pass
        try:
            forbidden = {
                str(li.getProperty("PlexKM.Art") or "").strip(),
                str(li.getArt("fanart") or "").strip(),
            }
        except Exception:
            forbidden = set()
        forbidden.discard("")
        for value in values:
            if not value or value in sources or value in forbidden:
                continue
            # Old V2496 snapshots may carry an arbitrary local file in ListItem art.
            # A local file is accepted as authority only if it is actually portrait.
            lower = value.lower()
            if not lower.startswith(("http://", "https://", "/", "special://", "resource://", "image://", "file://")):
                if not self._local_portrait_poster_file_ready_v2498(value):
                    continue
            sources.append(value)
        return sources

    def _sync_widget_refresh_pending_v1555(self):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.LibraryAdd.RestartRequiredV2090") == "1":
                _log("SYNC_WIDGET_REFRESH_PENDING_BLOCK_V2091 reason=library_add_restart_boundary next_start_loading_apply=1")
                return False
            if win.getProperty("PlexKM.RuntimeWidgetUpdatesDisabledV1644") == "1":
                return False
            return bool(
                getattr(self, "_plex_update_dirty_home", False)
                or win.getProperty("PlexKM.PlexUpdate.Dirty") == "1"
                or win.getProperty("PlexKM.Home.SyncRefreshPendingV1554") == "1"
            )
        except Exception:
            return bool(getattr(self, "_plex_update_dirty_home", False))

    def _sync_widget_refresh_ack_v1555(self, reason="", mode=""):
        """Acknowledge a sync refresh only after Home rows were really rebuilt."""
        token = ""
        sync_reason = ""
        try:
            win = xbmcgui.Window(10000)
            token = win.getProperty("PlexKM.Home.SyncRefreshPendingTokenV1554") or win.getProperty("PlexKM.Home.DataRefreshToken") or ""
            sync_reason = win.getProperty("PlexKM.Home.SyncRefreshPendingReasonV1554") or win.getProperty("PlexKM.Home.DataRefreshReason") or "sync"
            if token:
                win.setProperty("PlexKM.Home.DataRefreshAppliedToken", token)
                win.setProperty("PlexKM.Home.DataRefreshAppliedReason", sync_reason)
                win.setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
            win.clearProperty("PlexKM.Home.SyncRefreshPendingV1554")
            win.clearProperty("PlexKM.Home.SyncRefreshPendingTokenV1554")
            win.clearProperty("PlexKM.Home.SyncRefreshPendingReasonV1554")
        except Exception:
            pass
        _log("SYNC_WIDGET_REFRESH_GUI_APPLIED_V1555 reason=%s mode=%s token=%s sync_reason=%s no_blank_reset=1" % (
            reason or "", mode or "", token, sync_reason
        ))
        return token, sync_reason

    def _home_refresh_prev_overlay_show_v1555(self, reason=""):
        """Cover visible Home rows with an exact old-row buffer before reset.

        8610~8800 use the same 410/500 viewport and poster geometry as
        Home.  They are filled first and drawn above 9410~9600.  Only then may
        the real Home controls be reset/rebuilt.  Every operation is performed
        from the current Kodi GUI callback; no worker thread touches controls.
        """
        try:
            if self.getProperty("PlexKM.SectionTransitionPrevVisible") == "1":
                return False
            if self._section_bank_name_v1612() == "B":
                _log("SYNC_WIDGET_REFRESH_ATOMIC_COVER_SKIP_V1612 reason=%s bank_b_active=1" % (reason or ""))
                return False
            rows = self._home_current_visible_rows_for_section_prev(max_rows=len(SECTION_RECOMMEND_PREV_ROW_IDS))
            if not rows:
                return False
            selected = []
            for cid in HOME_ROW_IDS[:len(SECTION_RECOMMEND_PREV_ROW_IDS)]:
                try:
                    selected.append(int(self.getControl(cid).getSelectedPosition()))
                except Exception:
                    selected.append(0)
            rendered = self._section_render_prev_xml_rows(rows, reason="home_sync_atomic_v1555:%s" % (reason or ""))
            if rendered <= 0:
                return False
            # Switch the already-populated buffer to the dedicated Home-refresh
            # visibility property.  Clearing the section-transition property does
            # not hide the group because the XML visibility is an OR condition.
            self.setProperty("PlexKM.HomeRefreshPrevVisibleV1555", "1")
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.HomeRefreshPrevVisibleV1555", "1")
            except Exception:
                pass
            self.clearProperty("PlexKM.SectionTransitionPrevVisible")
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.SectionTransitionPrevVisible")
            except Exception:
                pass
            for idx, cid in enumerate(SECTION_RECOMMEND_PREV_ROW_IDS):
                try:
                    ctrl = self.getControl(cid)
                    size = int(ctrl.size())
                    if size > 0:
                        pos = selected[idx] if idx < len(selected) else 0
                        ctrl.selectItem(max(0, min(int(pos), size - 1)))
                except Exception:
                    pass
            _log("SYNC_WIDGET_REFRESH_ATOMIC_COVER_SHOW_V1555 reason=%s rows=%d items=%d focus=%s anchor=0" % (
                reason or "", len(rows), rendered, self._safe_focus_id()
            ))
            return True
        except Exception:
            _log("SYNC_WIDGET_REFRESH_ATOMIC_COVER_SHOW_FAILED_V1555 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _home_refresh_prev_overlay_hide_v1555(self, reason=""):
        """Reveal the completed Home rows and clear the now-hidden old buffer."""
        try:
            self.clearProperty("PlexKM.HomeRefreshPrevVisibleV1555")
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.HomeRefreshPrevVisibleV1555")
            except Exception:
                pass
            self._section_clear_prev_recommend_row_controls(clear_visible=False)
            _log("SYNC_WIDGET_REFRESH_ATOMIC_COVER_HIDE_V1555 reason=%s replacement_ready=1" % (reason or ""))
            return True
        except Exception:
            _log("SYNC_WIDGET_REFRESH_ATOMIC_COVER_HIDE_FAILED_V1555 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _consume_sync_widget_refresh_gui_v1555(self, reason=""):
        """Apply committed sync data without a visible Home-widget blank frame.

        A live Home refresh is allowed only while focus is on the fixed sidebar
        and the Home row stack is at its top anchor.  In every other state the
        committed DB remains marked dirty and is rebuilt while Home is hidden on
        the next natural Home re-entry.  Correctness is preserved; unsafe live
        resets are never attempted.
        """
        if getattr(self, "_sync_widget_refresh_applying_v1555", False):
            return False
        if not self._sync_widget_refresh_pending_v1555():
            return False
        # v1632: an input/focus callback is never a safe refresh trigger. The
        # pending committed DB is consumed by _show_home_wall() on a natural Home
        # entry, while the current Home/section scene remains fully interactive.
        if str(reason or "") in ("onAction", "onFocus"):
            now_ms_v1632 = int(time.time() * 1000)
            if now_ms_v1632 - int(getattr(self, "_sync_refresh_defer_log_ms_v1632", 0) or 0) >= 1500:
                self._sync_refresh_defer_log_ms_v1632 = now_ms_v1632
                _log("SYNC_WIDGET_REFRESH_INPUT_DEFER_V1632 reason=%s action=keep_current_scene pending=1 consume=next_home_entry" % (reason or ""))
            return False
        try:
            if getattr(self, "active_section_id", "") != "__home__":
                # Home is already hidden.  Do not make it visible just to refresh;
                # _show_home_wall() will query the committed DB before the next
                # Home visible commit.
                return False
            if getattr(self, "_widget_transition_active", False):
                return False
            if getattr(self, "_search_inline_active", False):
                return False
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                return False
            if getattr(self, "_playback_opening", False) or getattr(self, "_main_playback_requested", False):
                return False
            try:
                if xbmc.getCondVisibility("Player.HasVideo") or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                    return False
            except Exception:
                pass

            focus_id = self._safe_focus_id()
            try:
                anchor_index = int(getattr(self, "_row_anchor_scroll_index", {}).get(HOME_ROW_ANCHOR_SCOPE, 0) or 0)
            except Exception:
                anchor_index = 0
            # Exact visual overlay geometry is guaranteed at the top Home anchor.
            # While a user is browsing/scrolled inside widgets, keep their screen
            # untouched and defer to sidebar/top or the next Home entry.
            if focus_id not in (MENU_ID, SEARCH_FIXED_ID) or anchor_index != 0:
                _log("SYNC_WIDGET_REFRESH_DEFER_NO_BLINK_V1555 reason=%s focus=%s anchor=%s action=keep_current_widgets pending=1" % (
                    reason or "", focus_id, anchor_index
                ))
                return False
            if not self._home_rendered_xml_rows_ready():
                _log("SYNC_WIDGET_REFRESH_DEFER_NO_BLINK_V1555 reason=%s focus=%s anchor=%s action=no_visible_snapshot pending=1" % (
                    reason or "", focus_id, anchor_index
                ))
                return False

            focus_pos = -1
            focus_key = ""
            try:
                ctl = self.getControl(focus_id)
                focus_pos = int(ctl.getSelectedPosition())
                li = ctl.getSelectedItem()
                if li:
                    focus_key = str(li.getProperty("PlexKM.RatingKey") or li.getProperty("rating_key") or "")
            except Exception:
                pass

            self._sync_widget_refresh_applying_v1555 = True
            if not self._home_refresh_prev_overlay_show_v1555(reason=reason):
                _log("SYNC_WIDGET_REFRESH_DEFER_NO_BLINK_V1555 reason=%s focus=%s anchor=%s action=cover_unavailable pending=1" % (
                    reason or "", focus_id, anchor_index
                ))
                return False
            rebuilt = False
            try:
                self._show_home_wall(force=False)
                rebuilt = not self._sync_widget_refresh_pending_v1555()

                # Best-effort focus restoration.  Sidebar focus is kept stable;
                # no row control receives an artificial focus during refresh.
                try:
                    ctl = self.getControl(focus_id)
                    size = int(ctl.size())
                    target = min(max(0, int(focus_pos)), max(0, size - 1)) if size > 0 else -1
                    if focus_key and size > 0:
                        for idx in range(size):
                            try:
                                li = ctl.getListItem(idx)
                                rk = str(li.getProperty("PlexKM.RatingKey") or li.getProperty("rating_key") or "")
                                if rk and rk == focus_key:
                                    target = idx
                                    break
                            except Exception:
                                continue
                    if target >= 0:
                        ctl.selectItem(target)
                        try:
                            self.setFocusId(int(focus_id), int(target))
                        except TypeError:
                            self.setFocusId(int(focus_id))
                    elif focus_id > 0:
                        self.setFocusId(int(focus_id))
                except Exception:
                    pass
            finally:
                # The old buffer stays above the rows for the entire reset/add
                # sequence and is removed only after replacement-ready state.
                self._home_refresh_prev_overlay_hide_v1555(reason=reason)

            if rebuilt:
                _log("SYNC_WIDGET_REFRESH_ATOMIC_DONE_V1555 reason=%s focus=%s pos=%s key=%s no_blank_frame=1" % (
                    reason or "", focus_id, focus_pos, focus_key
                ))
                return True
            _log("SYNC_WIDGET_REFRESH_ATOMIC_INCOMPLETE_V1555 reason=%s pending=1" % (reason or ""), xbmc.LOGWARNING)
            return False
        except Exception:
            _log("SYNC_WIDGET_REFRESH_GUI_FAILED_V1555 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False
        finally:
            self._sync_widget_refresh_applying_v1555 = False

    def _consume_plex_update_home_dirty(self, reason="", force=False):
        try:
            try:
                win_v1644 = xbmcgui.Window(10000)
                if win_v1644.getProperty("PlexKM.RuntimeWidgetUpdatesDisabledV1644") == "1":
                    self._plex_update_dirty_home = False
                    win_v1644.clearProperty("PlexKM.PlexUpdate.Dirty")
                    win_v1644.clearProperty("PlexKM.PlexUpdate.Sections")
                    win_v1644.clearProperty("PlexKM.ArtCacheRepaired")
                    win_v1644.clearProperty("PlexKM.Home.SyncRefreshPendingV1554")
                    return False
            except Exception:
                pass
            if force:
                return False
            global_dirty = False
            try:
                win = xbmcgui.Window(10000)
                global_dirty = win.getProperty("PlexKM.PlexUpdate.Dirty") == "1" or win.getProperty("PlexKM.ArtCacheRepaired") == "1"
            except Exception:
                global_dirty = False
            if not self._plex_update_dirty_home and not global_dirty:
                return False
            self._plex_update_dirty_home = False
            self._home_rows_cache = None
            self._home_wall_ready = False
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty("PlexKM.PlexUpdate.Dirty")
                win.clearProperty("PlexKM.ArtCacheRepaired")
            except Exception:
                pass
            _log("PLEX_UPDATE_DIRTY_CONSUME scope=home reason=%s action=rebuild_home_cache global=%s" % (reason or "", "1" if global_dirty else "0"))
            return True
        except Exception:
            return False


    def _home_render_fast_first_paint(self, rows_cache, reason="HOME_FAST_FIRST_PAINT"):
        """Paint only the columns that are visible at Home startup, then return."""
        # v1841: the former follow-up worker appended native ListItems directly
        # into Home controls. Use the existing full-render fallback in the
        # current WindowXML callback instead.
        _log("HOME_FAST_FIRST_PAINT_DISABLED_V1841 reason=%s action=full_gui_render" % (reason or ""))
        return False

    def _start_home_watcha_preload_async_v1642(self, reason=""):
        try:
            if self._home_watcha_preload_event_v1642.is_set():
                return
            if self._home_watcha_preload_started_v1642:
                return
            self._home_watcha_preload_started_v1642 = True
            def _worker():
                try:
                    # A non-empty synthetic title forces the normal cache loader
                    # without matching any real row.
                    self._home_watcha_preload_props("", title="__pkm_watcha_preload_v1642__", original_title="", year="")
                    _log("WATCHA_PRELOAD_ASYNC_DONE_V1642 reason=%s" % (reason or ""))
                except Exception:
                    _log("WATCHA_PRELOAD_ASYNC_FAILED_V1642 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                finally:
                    self._home_watcha_preload_event_v1642.set()
            _PKMHomeThreadV2151(target=_worker, name="PlexKMWatchaPreloadV1642", daemon=True).start()
        except Exception:
            try:
                self._home_watcha_preload_event_v1642.set()
            except Exception:
                pass

    def _home_progressive_fill_v1642(self, rows_cache, generation):
        """Append the off-screen Home rows without resetting the first paint."""
        # v1841: intentionally disabled. No daemon thread may mutate Kodi Home
        # controls; both callers fall through to `_home_render_xml_rows()`.
        _log("HOME_PROGRESSIVE_FILL_DISABLED_V1841 generation=%s action=full_gui_render" % generation)
        return

    def _continue_status_fp_r25(self, show_keys):
        """R25: watch-state fingerprint of every episode of the given shows.

        The U5 version verified each episode by ``rating_key IN (...)`` and
        refused to cache more than 800 episodes, so a Continue row with one
        long drama (or several) was never stored and every start logged
        HOME_CONTINUE_CACHE_MISS_U6 reason=not_stored.  Aggregating per show
        uses idx_items_episode_show_progress, has no size limit and binds at
        most 400 parameters per statement.
        """
        keys = sorted(set(str(k or "").strip() for k in (show_keys or []) if str(k or "").strip()))
        if not keys:
            return None
        dbp = self._profile_db_path()
        if not dbp or not os.path.isfile(dbp):
            return None
        started = time.monotonic()
        conn = sqlite3.connect(dbp, timeout=0.25)
        try:
            conn.set_progress_handler(lambda: 1 if (time.monotonic() - started) > 0.60 else 0, 2000)
            parts = []
            for i in range(0, len(keys), 400):
                chunk = keys[i:i + 400]
                marks = ",".join("?" for _ in chunk)
                parts.extend(conn.execute(
                    "SELECT grandparent_rating_key, count(*), total(view_count > 0), total(view_count), "
                    "max(last_viewed_at), max(updated_at), group_concat(rating_key) "
                    "FROM items WHERE plex_type='episode' AND grandparent_rating_key IN (" + marks + ") "
                    "GROUP BY grandparent_rating_key",
                    tuple(chunk)
                ).fetchall())
        finally:
            conn.close()
        normalized = sorted(
            (str(r[0] or ""), int(r[1] or 0), float(r[2] or 0), float(r[3] or 0),
             int(r[4] or 0), int(r[5] or 0), ",".join(sorted(str(r[6] or "").split(","))))
            for r in parts
        )
        digest = hashlib.sha256(repr(normalized).encode("utf-8", "replace")).hexdigest()
        episodes = sum(x[1] for x in normalized)
        return digest, episodes, int((time.monotonic() - started) * 1000)

    @staticmethod
    def _continue_sig_parts_r25(parts):
        return hashlib.sha256(repr(sorted((parts or {}).items())).encode("utf-8", "replace")).hexdigest()

    def _continue_membership_cache_check_u5(self, signature, sig_parts=None):
        try:
            path = self._derived_cache_path_v2467("continue_membership_validated_u5.json")
            if not path or not os.path.isfile(path):
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=not_stored')
                return None
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or data.get("version") != 26:
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=format_changed')
                return None
            # R33: several callers (24-row Home view, 29-row all-Continue
            # authority) used to overwrite one slot and miss on every switch.
            entries = data.get("entries") or {}
            if not isinstance(entries, dict):
                entries = {}
            hit = entries.get(signature)
            if not isinstance(hit, dict):
                changed = []
                try:
                    newest = max((e for e in entries.values() if isinstance(e, dict)),
                                 key=lambda e: _safe_int(e.get("ts"), 0), default={})
                    old_parts = newest.get("parts") or {}
                    for name in sorted(set(old_parts) | set(sig_parts or {})):
                        if old_parts.get(name) != (sig_parts or {}).get(name):
                            changed.append(name)
                except Exception:
                    pass
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=source_or_resume_changed parts=%s slots=%d' % (
                    ",".join(changed) or "unknown", len(entries)))
                return None
            data = hit
            show_keys = data.get("show_keys") or []
            if not isinstance(show_keys, list) or not show_keys:
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=no_show_keys')
                return None
            started = time.monotonic()
            try:
                fp = self._continue_status_fp_r25(show_keys)
            except Exception as exc_fp:
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=status_query_failed err=%s' % str(exc_fp))
                return None
            if not fp:
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=status_unavailable')
                return None
            digest, episodes, _fp_ms = fp
            if digest != str(data.get("status_fp") or ""):
                _log('HOME_CONTINUE_CACHE_MISS_U6 reason=watch_state_changed expected=%d actual=%d' % (
                    _safe_int(data.get("episodes"), 0), episodes))
                return None
            cached_rows = data.get("rows") or []
            if not isinstance(cached_rows, list):
                return None
            _log("HOME_CONTINUE_CACHE_HIT_U5 rows=%d verified=%d shows=%d elapsed_ms=%d" % (
                len(cached_rows), episodes, len(show_keys), int((time.monotonic()-started)*1000)))
            return [tuple(x) for x in cached_rows]
        except Exception:
            _log('HOME_CONTINUE_CACHE_MISS_U6 reason=exception err=%s' % traceback.format_exc().replace(chr(10), " | "))
            return None

    def _continue_membership_cache_store_u5(self, signature, db_rows, result_rows, sig_parts=None):
        try:
            show_keys = sorted(set(str(row[22] or "").strip() for row in db_rows
                                   if row and len(row) > 22 and str(row[22] or "").strip()))
            if not show_keys:
                _log("HOME_CONTINUE_CACHE_STORE_SKIP_R25 reason=no_show_keys")
                return False
            fp = self._continue_status_fp_r25(show_keys)
            if not fp:
                _log("HOME_CONTINUE_CACHE_STORE_SKIP_R25 reason=status_unavailable")
                return False
            digest, episodes, fp_ms = fp
            path = self._derived_cache_path_v2467("continue_membership_validated_u5.json")
            if not path:
                return False
            entry = {"sig": signature, "parts": dict(sig_parts or {}), "ts": int(time.time() * 1000),
                     "show_keys": show_keys, "episodes": episodes,
                     "status_fp": digest, "rows": [list(x) for x in result_rows]}
            entries = {}
            try:
                if os.path.isfile(path):
                    with open(path, "r", encoding="utf-8") as fh:
                        old = json.load(fh)
                    if isinstance(old, dict) and old.get("version") == 26 and isinstance(old.get("entries"), dict):
                        entries = dict(old["entries"])
            except Exception:
                entries = {}
            entries[signature] = entry
            # R33: keep the 4 newest signatures.
            for stale in sorted(entries, key=lambda k: _safe_int((entries.get(k) or {}).get("ts"), 0))[:-4]:
                entries.pop(stale, None)
            payload = {"version": 26, "entries": entries}
            # Avoid serializing non-JSON types on the Home critical path.
            text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(text)
            os.replace(tmp, path)
            _log("HOME_CONTINUE_CACHE_STORE_U5 rows=%d verified=%d shows=%d fp_ms=%d" % (
                len(result_rows), episodes, len(show_keys), fp_ms))
            return True
        except Exception:
            return False


    def _continue_authority_refresh_if_stale_r33(self, reason=""):
        """R33: rebuild the shared Continue membership after a playback stop.

        Section Recommend reuses the membership Home published.  After a stop
        inside a library, Home is not rebuilt until the next Home entry, so the
        section's 이어보기 row kept the pre-playback membership (the episode
        just watched appeared only after visiting Home).  Rebuild it locally
        (Continue snapshot + Kodi resume sidecar, no network) when the
        service's playstate stamp is newer than the published membership.
        """
        try:
            stamp = int(float(xbmcgui.Window(10000).getProperty("PlexKM.Playback.PlayStateStampMsR33") or 0))
        except Exception:
            stamp = 0
        if stamp <= 0 or not getattr(self, "_continue_membership_authority_rows", None):
            return False
        updated = int(getattr(self, "_continue_membership_authority_updated_ms", 0) or 0)
        if updated >= stamp:
            return False
        started = time.monotonic()
        try:
            raw_rows = core.query_continue_watching_wall_light(
                limit=max(120, int(HOME_ROW_ITEM_LIMIT)),
                prefer_preload=True,
                allow_network=False,
                stale_preload_max_age=604800,
            ) or []
        except Exception:
            raw_rows = []
        if not raw_rows:
            _log("CONTINUE_AUTHORITY_REFRESH_SKIP_R33 reason=%s cause=no_local_rows" % (reason or ""))
            return False
        try:
            self._home_filter_continue_membership(list(raw_rows), publish_authority=True)
        except Exception:
            _log("CONTINUE_AUTHORITY_REFRESH_FAILED_R33 err=%s" % traceback.format_exc().replace(chr(10), " | "),
                 xbmc.LOGWARNING)
            return False
        # Home must also rebuild its Continue row on the next entry.
        try:
            self._home_rows_cache = None
            self._home_wall_ready = False
        except Exception:
            pass
        _log("CONTINUE_AUTHORITY_REFRESH_R33 reason=%s raw=%d rows=%d stamp_age_ms=%d elapsed_ms=%d network=0" % (
            reason or "", len(raw_rows), len(getattr(self, "_continue_membership_authority_rows", None) or []),
            max(0, int(time.time() * 1000) - stamp), int((time.monotonic() - started) * 1000)))
        return True

    def _build_movie_extra_rows_cache(self, sid, title, recent_viewed_rows, home_columns, added_start, allow_live_update=True):
        """Build movie recommendation rows from the current section only.

        v201 policy:
        - Do not use recently-viewed movie as the recommendation base.
        - Korean/foreign taste rows are high-rating + random from this section.
        - Director/actor rows choose a random person from this section, then show
          that person's works from this same section.
        - Director/actor rows do not require rating because person-based pools can
          be small or unevenly rated.
        """
        speed_start = _pkm_speed_ms()
        extra_rows_cache = []
        added = int(added_start or 0)
        sid = str(sid or "").strip()
        exclude = set()
        try:
            indexed_rows = self._build_movie_extra_rows_cache_from_index(sid, title, home_columns, added_start)
            if indexed_rows is not None:
                _speed_log("movie_extra_source_selected", section=sid, source="db_local", rows=len(indexed_rows or []), reason="index_available", metadata_fetch=0, policy="v227_db_index_main_actor_fast_no_metadata")
                return indexed_rows

            _speed_log("movie_extra_source_selected", section=sid, source="plex_http_fallback", reason="index_unavailable_or_error")
            row_limit = max(10, min(HOME_ROW_ITEM_LIMIT, max(int(home_columns or 5) * 2, int(home_columns or 5) + 4)))
            rating_min = float(self._movie_extra_score_threshold())
            _speed_log(
                "movie_extra_strategy",
                section=sid,
                title=title,
                policy="section_random_rating_person_random",
                row_limit=row_limit,
                rating_min=rating_min,
                section_only=1,
                recent_base_used=0,
                nonce=getattr(self, "_movie_extra_random_nonce", ""),
            )

            # 1) Korean high-rated random pool from the current section only.
            rows = self._movie_rows_from_movie_sections(
                sid, title, "", "", exclude_keys=exclude, limit=row_limit,
                sort="audienceRating:desc", country_mode="korean",
                allow_broad_fallback=True, min_score=rating_min, require_rating=True,
            )
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, "취향 한국영화", rows, sid, added)
            _speed_log("movie_extra_row_append", section=sid, type="korean_random_rating", title="취향 한국영화", rows=len(rows or []), added_delta=added-before, rating_min=rating_min, section_only=1)
            for r in rows or []:
                try:
                    rk = str((tuple(r or ())[0]) or "")
                    if rk:
                        exclude.add(rk)
                except Exception:
                    pass

            # 2) Foreign high-rated random pool from the current section only.
            rows = self._movie_rows_from_movie_sections(
                sid, title, "", "", exclude_keys=exclude, limit=row_limit,
                sort="audienceRating:desc", country_mode="foreign",
                allow_broad_fallback=True, min_score=rating_min, require_rating=True,
            )
            before = added
            added = self._append_recommend_row_items(None, extra_rows_cache, "취향 외국영화", rows, sid, added)
            _speed_log("movie_extra_row_append", section=sid, type="foreign_random_rating", title="취향 외국영화", rows=len(rows or []), added_delta=added-before, rating_min=rating_min, section_only=1)
            for r in rows or []:
                try:
                    rk = str((tuple(r or ())[0]) or "")
                    if rk:
                        exclude.add(rk)
                except Exception:
                    pass

            # v208: show the two taste rows as soon as they are ready.
            # Director/actor discovery can require metadata probes and slow Plex
            # person filters, so do not make rows 4~5 wait for rows 6~7.
            try:
                if allow_live_update and extra_rows_cache and self.active_section_id == ("recommend:%s" % sid):
                    fid_now = self._safe_focus_id()
                    safe_live_focus = set([9000])
                    try:
                        safe_live_focus.update(self._section_active_row_ids_v1612()[:3])
                    except Exception:
                        pass
                    if fid_now in safe_live_focus or fid_now not in SECTION_RECOMMEND_ALL_ROW_IDS:
                        self._section_update_extra_row_controls(extra_rows_cache, start_row_index=3, reason="movie_extra_worker_taste_stage")
                        _speed_log("movie_extra_rows_ui_update_stage", section=sid, stage="taste", focus_id=fid_now, rows=len(extra_rows_cache or []))
                    else:
                        _speed_log("movie_extra_rows_ui_update_stage_deferred", section=sid, stage="taste", focus_id=fid_now, rows=len(extra_rows_cache or []))
            except Exception:
                pass

            # 3) Random director from the whole movie pool.  No score cutoff.
            # v210: director/actor rows are intentionally not limited to this
            # section so sparse sections can still show 5~10 meaningful works.
            director_name, director_id, rows = self._pick_movie_extra_person_global(
                sid, "Director", exclude_keys=exclude, target_min=5, row_limit=row_limit
            )
            if director_id and rows:
                director_title = "%s 감독작" % director_name if director_name else "감독작"
                before = added
                added = self._append_recommend_row_items(None, extra_rows_cache, director_title, rows, sid, added)
                _speed_log("movie_extra_row_append", section=sid, type="director_random_person", title=director_title, rows=len(rows or []), added_delta=added-before, require_rating=0, scope="all_movie_sections", min_target=5)
                for r in rows or []:
                    try:
                        rk = str((tuple(r or ())[0]) or "")
                        if rk:
                            exclude.add(rk)
                    except Exception:
                        pass
                try:
                    if allow_live_update and extra_rows_cache and self.active_section_id == ("recommend:%s" % sid):
                        self._section_update_extra_row_controls(extra_rows_cache, start_row_index=3, reason="movie_extra_worker_director_stage")
                        _speed_log("movie_extra_rows_ui_update_stage", section=sid, stage="director", rows=len(extra_rows_cache or []), focus_id=self._safe_focus_id())
                except Exception:
                    pass
            else:
                _speed_log("movie_extra_row_skip", section=sid, type="director_random_person", reason="no_director_candidate", scope="all_movie_sections")

            # 4) Random actor from the whole movie pool.  No score cutoff.
            actor_name, actor_id, rows = self._pick_movie_extra_person_global(
                sid, "Role", exclude_keys=exclude, target_min=5, row_limit=row_limit
            )
            if actor_id and rows:
                actor_title = "%s 출연작" % actor_name if actor_name else "배우작"
                before = added
                added = self._append_recommend_row_items(None, extra_rows_cache, actor_title, rows, sid, added)
                _speed_log("movie_extra_row_append", section=sid, type="actor_random_person", title=actor_title, rows=len(rows or []), added_delta=added-before, require_rating=0, scope="all_movie_sections", min_target=5)
                try:
                    if allow_live_update and extra_rows_cache and self.active_section_id == ("recommend:%s" % sid):
                        self._section_update_extra_row_controls(extra_rows_cache, start_row_index=3, reason="movie_extra_worker_actor_stage")
                        _speed_log("movie_extra_rows_ui_update_stage", section=sid, stage="actor", rows=len(extra_rows_cache or []), focus_id=self._safe_focus_id())
                except Exception:
                    pass
            else:
                _speed_log("movie_extra_row_skip", section=sid, type="actor_random_person", reason="no_actor_candidate", scope="all_movie_sections")

            _speed_log("movie_extra_rows_build_end", section=sid, title=title, result="ok", rows=len(extra_rows_cache or []), total_ms=_pkm_speed_ms() - speed_start, section_only=1, recent_base_used=0)
        except Exception:
            _log("MOVIE_EXTRA_ROWS_BUILD_FAILED section=%s\n%s" % (sid, traceback.format_exc()), xbmc.LOGWARNING)
            _speed_log("movie_extra_rows_build_end", section=sid, title=title, result="error", rows=len(extra_rows_cache or []), total_ms=_pkm_speed_ms() - speed_start, section_only=1, recent_base_used=0)
        return extra_rows_cache

    def _start_movie_extra_rows_worker(self, cache_key, sid, title, recent_viewed_rows, home_columns, added_start):
        try:
            if _pkm_playback_active_v1411():
                _speed_log("movie_extra_rows_worker_skip", section=sid, reason="playback_active_v1411")
                _log("MOVIE_EXTRA_ROWS_SKIP_PLAYBACK_ACTIVE_V1411 section=%s title=%s" % (sid or "", title or ""))
                return
            if not sid or not self._is_movie_recommend_section(sid, ""):
                return
            worker_key = "movie_extra:%s" % sid
            if getattr(self, "_movie_extra_building", None) is None:
                self._movie_extra_building = set()
            if worker_key in self._movie_extra_building:
                _speed_log("movie_extra_rows_worker_skip", section=sid, reason="already_running")
                return
            # v207: do not drop the current section just because another movie extra
            # worker is running. Debounce+active-section check below will cancel
            # pass-through menu items before expensive work starts. Dropping here
            # caused sections to keep only the base 3 rows until leaving/re-entering.
            if self._movie_extra_building:
                _speed_log("movie_extra_rows_worker_parallel_allowed", section=sid, active_workers=",".join(list(self._movie_extra_building)))
            self._movie_extra_building.add(worker_key)
            rows_snapshot = list(recent_viewed_rows or [])
            columns_snapshot = int(home_columns or 5)
            start_snapshot = int(added_start or 0)

            def _worker():
                try:
                    # Do not build expensive movie extras while the user is merely
                    # passing through side-menu items.  Wait briefly and only
                    # continue if this section is still active.
                    debounce_ms = 650
                    try:
                        xbmc.sleep(debounce_ms)
                    except Exception:
                        time.sleep(debounce_ms / 1000.0)
                    if self.active_section_id != cache_key:
                        _speed_log("movie_extra_rows_worker_skip", section=sid, reason="stale_focus_after_debounce", debounce_ms=debounce_ms, active=self.active_section_id, expected=cache_key)
                        return
                    start_row_index = self._section_rows_group_count(self._section_rows_cache.get(cache_key) or [])
                    _speed_log("movie_extra_rows_worker_start", section=sid, title=title, start_row=start_row_index, base_recent_rows=len(rows_snapshot), debounce_ms=debounce_ms)
                    extra_rows = self._build_movie_extra_rows_cache(sid, title, rows_snapshot, columns_snapshot, start_snapshot, allow_live_update=False)
                    if not extra_rows:
                        return
                    # v1621: once a scene has been published, keep both its
                    # row snapshot and metadata immutable for the whole Kodi window
                    # session. A background enrichment result must not invalidate a
                    # visited menu and turn the next visit into a spinner/cold build.
                    # Full movie compose already includes the extra rows; legacy
                    # late results are simply deferred to the next PKM start.
                    published_scene_v1621 = self._section_scene_get_v1620(cache_key)
                    if published_scene_v1621:
                        _speed_log("movie_extra_rows_deferred_v1621", section=sid, reason="published_scene_immutable_fast_revisit", rows=len(extra_rows or []))
                        _log("SECTION_SCENE_SESSION_IMMUTABLE_V1621 key=%s section=%s deferred_rows=%d spinner_next_visit=0" % (
                            cache_key, sid, len(extra_rows or [])
                        ))
                        return
                    try:
                        base_rows = list(self._section_rows_cache.get(cache_key) or [])
                        merged = base_rows + list(extra_rows or [])
                        self._section_rows_cache[cache_key] = merged
                    except Exception:
                        pass
                    _speed_log("movie_extra_rows_cache_only_v1621", section=sid, reason="unpublished_scene_data_only", rows=len(extra_rows or []))
                except Exception:
                    _log("MOVIE_EXTRA_ROWS_WORKER_FAILED section=%s err=%s" % (sid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                finally:
                    try:
                        self._movie_extra_building.discard(worker_key)
                    except Exception:
                        pass
                    _speed_log("movie_extra_rows_worker_done", section=sid)

            _PKMHomeThreadV2151(target=_worker, name="PlexKMMovieExtraRows", daemon=True).start()
        except Exception:
            _log("MOVIE_EXTRA_ROWS_WORKER_START_FAILED section=%s err=%s" % (sid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _local_poster_file_ready_v1865(self, path):
        """Accept only a real local image file, never an HTML/error cache body."""
        try:
            raw = str(path or "").strip()
            if not raw:
                return False
            translated = xbmcvfs.translatePath(raw) if raw.lower().startswith("special://") else raw
            if not translated or not os.path.exists(translated) or os.path.getsize(translated) <= 1024:
                return False
            with open(translated, "rb") as fh:
                head = fh.read(16)
            return bool(
                head.startswith(b"\xff\xd8\xff")
                or head.startswith(b"\x89PNG\r\n\x1a\n")
                or (len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP")
            )
        except Exception:
            return False

    def _local_portrait_poster_file_ready_v2498(self, path):
        """A portrait-card local binding must be a real image with portrait geometry."""
        try:
            if not self._local_poster_file_ready_v1865(path):
                return False
            width, height = self._image_dimensions_no_decode_v2498(path)
            return bool(width >= 80 and height >= 120 and height > width)
        except Exception:
            return False

    def _cached_poster_source_path_v1871(self, source):
        """Return an already-present poster file without starting network I/O."""
        try:
            source = str(source or "").strip()
            if not source:
                return ""
            lower = source.lower()
            if lower.startswith("special://"):
                candidate = xbmcvfs.translatePath(source)
            elif lower.startswith(("http://", "https://")):
                candidate = self._wall_poster_local_path_v1644(source)
            else:
                candidate = source
            if candidate and self._local_portrait_poster_file_ready_v2498(candidate):
                return candidate
        except Exception:
            pass
        return ""

    def _resolve_visible_poster_sources_server_small_v1937(self, sources, rating_key="", timeout_sec=3.0, cancel_check=None):
        """Return one complete local small poster using the Plex image server first.

        v2147 uses one path on every platform. Plex server-small JPEGs are preferred;
        an already-valid local original may be reused as a last resort. Python never
        decodes/resizes/re-encodes the poster; Kodi XML owns final 240x360 geometry.
        """
        small_url = self._viewport_poster_url_v1937(sources, rating_key=rating_key)
        if small_url:
            local = self._wall_poster_download_bounded_v1862(
                small_url,
                timeout_sec=max(0.8, float(timeout_sec or 3.0)),
                max_bytes=2 * 1024 * 1024,
                priority=pkm_artwork_scheduler.PRIORITY_FOREGROUND,
                cancel_check=cancel_check,
            )
            if local and self._local_poster_file_ready_v1865(local):
                width, height = self._jpeg_dimensions_no_pil_v1931(local)
                valid_small = bool(
                    width > 0 and height > 0 and width <= 720 and height <= 720
                    and height >= 240 and width < height
                )
                if valid_small:
                    _log("LIBRARY_SERVER_SMALL_POSTER_READY_V1937 rating_key=%s size=%sx%s visual_box=240x360 pil=0 platform_shared=1" % (
                        str(rating_key or ""), width, height
                    ))
                    return local
                _log("LIBRARY_SERVER_SMALL_POSTER_REJECT_V1937 rating_key=%s size=%sx%s pil=0" % (
                    str(rating_key or ""), width, height
                ), xbmc.LOGWARNING)
                try:
                    os.remove(local)
                except Exception:
                    pass

        for source in list(sources or []):
            try:
                value = str(source or "").strip()
                if not value:
                    continue
                lower = value.lower()
                if lower.startswith("special://"):
                    candidate = xbmcvfs.translatePath(value)
                elif lower.startswith(("http://", "https://")):
                    candidate = self._wall_poster_local_path_v1644(value)
                else:
                    candidate = value
                if not candidate or not self._local_portrait_poster_file_ready_v2498(candidate):
                    if candidate and self._local_poster_file_ready_v1865(candidate):
                        width_v2498, height_v2498 = self._image_dimensions_no_decode_v2498(candidate)
                        _log("POSTER_LOCAL_GEOMETRY_REJECT_V2498 rating_key=%s size=%sx%s source_role=poster action=do_not_publish" % (
                            str(rating_key or ""), width_v2498, height_v2498
                        ), xbmc.LOGWARNING)
                    continue
                _log("LIBRARY_SERVER_SMALL_LOCAL_REUSE_V2147 rating_key=%s pil=0 platform_shared=1 kodi_geometry_owner=1" % str(rating_key or ""))
                return candidate
            except Exception:
                continue
        return ""

    # R56: poster overlays (watched check, progress bar, 4K, TV episode badge)
    # must appear together with the poster, never before it.  Kodi exposes no
    # "texture loaded" condition, so an item whose image is still a remote URL
    # is marked OverlayGateR56=1 and its overlays wait for OverlayReadyR56=1.
    # A light watcher flips that bit when the exact art URL is in Kodi's
    # Textures13 cache (i.e. Kodi can now draw the poster) or the art is a local
    # file.  12s fail-open so an unavailable poster never hides a check forever.
    # Items not registered keep the previous XML behaviour.
    def _overlay_gate_register_r56(self, li, art_key="poster", ready_prop="PlexKM.WidgetPosterReadyV1644"):
        try:
            if li is None:
                return li
            watched = str(li.getProperty("PlexKM.IsWatched") or "") == "1"
            pct = _safe_int(li.getProperty("PlexKM.ResumePercent"), 0)
            badge = str(li.getProperty("PlexKM.EpisodeBadgeLabel") or "")
            is4k = str(li.getProperty("PlexKM.Is4K") or "") == "1"
            if not (watched or pct > 0 or badge or is4k):
                return li
            if ready_prop and str(li.getProperty(ready_prop) or "") == "1":
                li.setProperty("PlexKM.OverlayReadyR56", "1")
                return li
            url = str(li.getArt(art_key) or "").strip()
            if not url:
                return li
            lower = url.lower()
            if not lower.startswith(("http://", "https://", "image://")):
                try:
                    path = xbmcvfs.translatePath(url) if lower.startswith("special://") else url
                except Exception:
                    path = url
                if path and os.path.exists(path):
                    li.setProperty("PlexKM.OverlayReadyR56", "1")
                    return li
            li.setProperty("PlexKM.OverlayGateR56", "1")
            li.setProperty("PlexKM.OverlayReadyR56", "")
            lock = getattr(self, "_overlay_lock_r56", None)
            if lock is None:
                lock = threading.RLock()
                self._overlay_lock_r56 = lock
            start = False
            with lock:
                pending = getattr(self, "_overlay_pending_r56", None)
                if pending is None:
                    pending = []
                    self._overlay_pending_r56 = pending
                pending.append((li, url, str(ready_prop or ""), self._now_ms()))
                if len(pending) > 400:
                    for old in pending[:len(pending) - 400]:
                        try:
                            old[0].setProperty("PlexKM.OverlayReadyR56", "1")
                        except Exception:
                            pass
                    del pending[:len(pending) - 400]
                if not bool(getattr(self, "_overlay_worker_on_r56", False)):
                    self._overlay_worker_on_r56 = True
                    start = True
            if start:
                _PKMHomeThreadV2151(target=self._overlay_ready_worker_r56, name="PKMOverlayReadyR56", daemon=True).start()
        except Exception:
            pass
        return li

    def _overlay_cached_urls_r56(self, urls):
        found = set()
        urls = [u for u in list(urls or []) if u]
        if not urls:
            return found
        try:
            db_path = xbmcvfs.translatePath("special://database/Textures13.db")
        except Exception:
            db_path = ""
        if not db_path or not os.path.exists(db_path):
            return found
        try:
            conn = _pkm_ro_connect(db_path, timeout=0.20)
            try:
                for start in range(0, len(urls), 80):
                    chunk = urls[start:start + 80]
                    marks = ",".join("?" for _ in chunk)
                    for url, cachedurl in conn.execute(
                            "SELECT url,cachedurl FROM texture WHERE url IN (%s)" % marks, tuple(chunk)).fetchall():
                        cachedurl = str(cachedurl or "").strip()
                        if not cachedurl:
                            continue
                        try:
                            thumb_path = xbmcvfs.translatePath("special://thumbnails/" + cachedurl.replace("\\", "/"))
                        except Exception:
                            thumb_path = ""
                        if thumb_path and os.path.exists(thumb_path):
                            found.add(str(url or "").strip())
            finally:
                conn.close()
        except Exception:
            pass
        return found

    def _overlay_ready_worker_r56(self):
        marked = timed_out = 0
        first = True
        try:
            while not self._closing_event_v1841.is_set():
                if self._closing_event_v1841.wait(0.06 if first else 0.30):
                    return
                first = False
                lock = self._overlay_lock_r56
                with lock:
                    items = list(self._overlay_pending_r56 or [])
                    self._overlay_pending_r56 = []
                if not items:
                    with lock:
                        if not self._overlay_pending_r56:
                            self._overlay_worker_on_r56 = False
                            if marked or timed_out:
                                _log("OVERLAY_READY_R56 marked=%d timeout_open=%d pending=0" % (marked, timed_out))
                            return
                    continue
                now = self._now_ms()
                still = []
                urls = set()
                for rec in items:
                    li, url, rp, t0 = rec
                    try:
                        if str(li.getProperty("PlexKM.OverlayReadyR56") or "") == "1" or (
                                rp and str(li.getProperty(rp) or "") == "1"):
                            li.setProperty("PlexKM.OverlayReadyR56", "1")
                            marked += 1
                            continue
                        if now - int(t0) > 12000:
                            li.setProperty("PlexKM.OverlayReadyR56", "1")
                            timed_out += 1
                            continue
                    except Exception:
                        continue
                    still.append(rec)
                    urls.add(url)
                cached = self._overlay_cached_urls_r56(urls) if still else set()
                keep = []
                for rec in still:
                    if rec[1] in cached:
                        try:
                            rec[0].setProperty("PlexKM.OverlayReadyR56", "1")
                            marked += 1
                        except Exception:
                            pass
                    else:
                        keep.append(rec)
                if keep:
                    with lock:
                        self._overlay_pending_r56 = keep + list(self._overlay_pending_r56 or [])
        except Exception:
            _log("OVERLAY_READY_WORKER_FAILED_R56 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            try:
                with self._overlay_lock_r56:
                    if self._closing_event_v1841.is_set() or not self._overlay_pending_r56:
                        self._overlay_worker_on_r56 = False
            except Exception:
                pass

    def _progress_overlay_poster_gate_v2716(self, listitems, reason=""):
        """Bind poster bytes before exposing a resume/progress overlay.

        V2716 quality contract: a progress bar must never outrun its poster.
        Only cards with real resume progress participate in this gate, so normal
        poster-only sidebar first-paint keeps the V2715 zero-wait path.  Existing
        local/PKM cache files are reused first; a cold progress card resolves its
        poster through the existing bounded artwork scheduler.
        """
        started = _pkm_speed_ms()
        requested = ready = resolved = failed = 0
        for li in list(listitems or []):
            if li is None:
                continue
            try:
                pct = _safe_int(li.getProperty("PlexKM.ResumePercent"), 0)
                watched = str(li.getProperty("PlexKM.IsWatched") or "") == "1"
            except Exception:
                pct = 0
                watched = False
            if pct <= 0 and not watched:
                continue
            requested += 1
            try:
                if str(li.getProperty("PlexKM.WidgetPosterReadyV1644") or "") == "1":
                    ready += 1
                    continue
            except Exception:
                pass
            local = ""
            try:
                sources = self._startup_widget_poster_sources_v1644(li) or []
            except Exception:
                sources = []
            # Fast local-cache probe first. This is the common warm/revisit path.
            for src in list(sources or []):
                try:
                    candidate = self._wall_poster_local_path_v1644(src)
                    if candidate and self._local_portrait_poster_file_ready_v2498(candidate):
                        local = candidate
                        break
                except Exception:
                    continue
            if not local and sources and pct <= 0:
                # R43: a watched-only card never downloads on this path (zero-wait
                # sidebar first paint); its check mark appears once the poster is local.
                continue
            if not local and sources:
                try:
                    local = self._startup_widget_poster_resolve_v1644(sources) or ""
                except Exception:
                    local = ""
            if local and self._startup_bind_local_poster_v2498(li, local, source="progress_atomic_v2716"):
                resolved += 1
                ready += 1
            else:
                failed += 1
                # Fail closed for the overlay. XML also requires this ready bit,
                # so a slow/missing poster can never leave a floating progress bar.
                try:
                    li.setProperty("PlexKM.WidgetPosterReadyV1644", "0")
                except Exception:
                    pass
        _log("POSTER_PROGRESS_ATOMIC_GATE_V2716 reason=%s requested=%d ready=%d resolved=%d failed=%d elapsed_ms=%d overlay_requires_poster_ready=1 spinner_policy=unchanged_1500ms" % (
            reason or "", requested, ready, resolved, failed, _pkm_speed_ms() - started
        ))
        return failed == 0

    def _li_from_row(self, row, row_title="", row_type="", row_first=False, row_id="", row_start=-1, row_index=-1, _snapshot_only_v2476=False):
        row = tuple(row or ())
        rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = row[:21]
        parent_rating_key = row[21] if len(row) > 21 else ""
        grandparent_rating_key = row[22] if len(row) > 22 else ""
        # Optional live resume offset appended by default.py for Plex onDeck/local resume.
        # Unit is milliseconds. Keep it outside the stable DB row columns to avoid
        # touching cache/lazy-wall behavior.
        view_offset = row[23] if len(row) > 23 else ""
        resume_duration_ms = row[24] if len(row) > 24 else ""
        resume_updated_at = row[25] if len(row) > 25 else ""
        resume_source = row[26] if len(row) > 26 else ""
        try:
            _startup_light_v2583 = bool(
                getattr(self, "_startup_established_current_home_only_v2535", False)
                and xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
                and xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") != "1"
            )
        except Exception:
            _startup_light_v2583 = False
        _rapid_wall_light_v2584 = bool(getattr(self, "_library_rapid_skeleton_v2584", False))
        _sidebar_light_v2586 = bool(getattr(self, "_section_sidebar_fastpaint_v2586", False))
        _foreground_light_v2591 = bool(self._uhd3_foreground_isolation_active_v2591())
        _light_item_v2584 = bool(_startup_light_v2583 or _rapid_wall_light_v2584 or _sidebar_light_v2586 or _foreground_light_v2591)
        if _rapid_wall_light_v2584:
            # Card-first policy: row ordering/identity/poster are already in the
            # local query. Long synopsis and decorative ratings fill on focus/idle.
            summary = ""
        # v1907: local raw metadata is appended after the stable resume fields.
        # It is parsed only for the visible Library wall label; Home rows keep
        # their existing hidden-title layout and do not pay this formatting cost.
        sort_raw_json_v1907 = row[27] if len(row) > 27 else ""
        tv_sort_meta_json_v1911 = row[28] if len(row) > 28 else ""
        try:
            tv_sort_meta_v1911 = pkm_library_sort.parse_tv_sort_meta(tv_sort_meta_json_v1911)
        except Exception:
            tv_sort_meta_v1911 = {}
        # v2260: raw_json is already part of the local row. Parse its Plex score
        # before the ListItem becomes focusable so a movie badge never needs to
        # disappear and reappear while async metadata enrichment catches up.
        try:
            raw_sort_preload_v2260 = pkm_library_sort.sort_raw_values(sort_raw_json_v1907)
            raw_rating_preload_v2260 = self._home_imdb_rating_value(
                raw_sort_preload_v2260.get("rating", "")
            )
        except Exception:
            raw_sort_preload_v2260 = {}
            raw_rating_preload_v2260 = ""
        display_thumb = thumb
        # v2130: actor-work rows can surface old library items that have not been
        # rewritten since a Plex token/art revision.  The DB may therefore hold
        # a stale tokenized poster URL (or no poster URL at all) even though the
        # ratingKey itself is valid.  Normalize the cached URL without probing
        # the server, and keep the canonical ratingKey poster endpoint as Kodi's
        # native texture fallback.  This is deliberately scoped to actor-work
        # rows so normal Home/Library artwork ownership is unchanged.
        actor_work_poster_fallback_v2130 = ""
        actor_work_poster_source_v2130 = ""
        if str(row_type or "") == "info_actor_works_v1966" and str(rating_key or "").strip():
            try:
                raw_actor_thumb_v2130 = str(thumb or "").strip()
                normalized_actor_thumb_v2130 = _plex_art(raw_actor_thumb_v2130, width=720, height=1080) if raw_actor_thumb_v2130 else ""
                canonical_actor_thumb_v2130 = _plex_art(
                    "/library/metadata/%s/thumb" % str(rating_key).strip(),
                    width=720, height=1080,
                )
                normalized_actor_art_v2130 = _plex_art(str(art or "").strip(), width=1920, height=1080) if str(art or "").strip() else ""
                if normalized_actor_thumb_v2130:
                    display_thumb = normalized_actor_thumb_v2130
                    actor_work_poster_source_v2130 = "db_normalized" if normalized_actor_thumb_v2130 != raw_actor_thumb_v2130 else "db"
                elif canonical_actor_thumb_v2130:
                    display_thumb = canonical_actor_thumb_v2130
                    actor_work_poster_source_v2130 = "canonical"
                elif normalized_actor_art_v2130:
                    display_thumb = normalized_actor_art_v2130
                    actor_work_poster_source_v2130 = "art"
                actor_work_poster_fallback_v2130 = canonical_actor_thumb_v2130 or normalized_actor_art_v2130
                if normalized_actor_art_v2130:
                    art = normalized_actor_art_v2130
            except Exception:
                actor_work_poster_fallback_v2130 = ""
                actor_work_poster_source_v2130 = "error"
        season_show_poster_fallback_v1870 = ""
        if plex_type == "season":
            # Prefer Plex's season-folder poster when the parent key is a real
            # season rating key. The first-12 gate caches this URL before the
            # Library wall is published; the show poster remains the fallback.
            season_key_v1870 = str(parent_rating_key or "").strip()
            season_show_poster_fallback_v1870 = str(thumb or "")
            if season_key_v1870 and ":season:" not in season_key_v1870:
                display_thumb = _plex_art(
                    "/library/metadata/%s/thumb" % season_key_v1870,
                    width=720, height=1080,
                ) or thumb
        if plex_type == "episode":
            # v2264: a Home episode visually represents its SHOW. Rapid wall
            # append skips synopsis/fanart DB enrichment; focus can fill it later.
            if (not _rapid_wall_light_v2584) and (not _sidebar_light_v2586) and not str(summary or "").strip():
                summary_local_v2264 = self._home_episode_show_summary_value_v2264(
                    parent_rating_key=parent_rating_key,
                    grandparent_rating_key=grandparent_rating_key,
                    section_id=section_id,
                    show_title=show_title or title,
                )
                if summary_local_v2264:
                    summary = summary_local_v2264
                    _log("HOME_EPISODE_SUMMARY_FIRST_PAINT_V2264 rating_key=%s show_key=%s chars=%d" % (
                        rating_key,
                        str(grandparent_rating_key or parent_rating_key or ""),
                        len(summary),
                    ))
            if str(row_type or "") == "continue" and str(thumb or "").strip():
                # v2497: query_continue_watching_wall_light already replaced the
                # onDeck still with the synchronized show poster.  Do not override
                # it with another remote path here.
                display_thumb = str(thumb or "").strip()
            else:
                display_thumb = self._episode_show_poster_from_key(grandparent_rating_key) or thumb
            # Home/Wall episode cards visually represent the show poster.
            # Use DB-confirmed show fanart only when it exists.  Do not blindly
            # synthesize /metadata/<show>/art because Plex may return an empty
            # placeholder for some shows; in that case keep the original episode
            # art instead of forcing the hero fanart blank.
            if (not _rapid_wall_light_v2584) and (not _sidebar_light_v2586):
                show_art = self._episode_show_art_from_key(grandparent_rating_key, section_id=section_id, show_title=show_title, fallback_title=title)
                if show_art:
                    art = show_art

        if part_key and plex_type in ("movie", "episode"):
            url = _pkm_play_url(rating_key, part_key, mode="start")
        elif plex_type == "show":
            url = core.build_plugin_url({"action": "show", "rating_key": rating_key, "section_id": section_id})
        else:
            url = core.build_plugin_url({"action": "noop"})

        li = (_PKMRenderSnapshotItemV2476(label=title or "", path=url) if _snapshot_only_v2476 else xbmcgui.ListItem(label=title or "", path=url))
        try:
            li.setPath(url)
        except Exception:
            pass

        mediatype = kodi_type or ("tvshow" if plex_type in ("show", "season") else plex_type or "video")
        if _light_item_v2584:
            # V2584: title/poster/playback are startup/rapid-scroll critical; genre, MPAA,
            # duplicate-canonical metadata and external rating decorations are not.
            genre_preload_v1801 = ""
            content_rating_preload_v1804 = ""
            canonical_movie_meta_v1816 = {"Rating": "", "ContentRating": "", "SourceKey": ""}
        else:
            genre_preload_v1801 = self._home_db_genre_value_v1801(rating_key, parent_rating_key, grandparent_rating_key, plex_type, section_id=section_id, show_title=show_title)
            content_rating_preload_v1804 = self._home_db_content_rating_value_v1804(rating_key, parent_rating_key, grandparent_rating_key, plex_type)
            canonical_movie_meta_v1816 = {"Rating": "", "ContentRating": "", "SourceKey": ""}
            if str(plex_type or "").strip().lower() == "movie":
                canonical_movie_meta_v1816 = self._canonical_movie_duplicate_meta_v1816(
                    rating_key, title=title, original_title=original_title, year=year, duration=duration
                )
                if not content_rating_preload_v1804:
                    content_rating_preload_v1804 = canonical_movie_meta_v1816.get("ContentRating") or ""
                if not content_rating_preload_v1804:
                    for verified_key_v1836 in (
                        rating_key,
                        canonical_movie_meta_v1816.get("SourceKey") or "",
                    ):
                        verified_meta_v1836 = self._home_meta_enrich_cache.get(str(verified_key_v1836 or "")) or {}
                        if (verified_meta_v1836.get("ContentRating")
                                and str(verified_meta_v1836.get("ContentRatingPMSVerified") or "") == "1"):
                            content_rating_preload_v1804 = str(verified_meta_v1836.get("ContentRating") or "")
                            _log("CANONICAL_CONTENT_RATING_REUSE_V1836 rating_key=%s source_key=%s content_rating=%s" % (
                                rating_key, verified_key_v1836, content_rating_preload_v1804
                            ))
                            break
        info = {"title": title or "", "sorttitle": sort_title or title or "", "originaltitle": original_title or "", "year": _safe_int(year, 0), "plot": summary or "", "duration": _safe_int(duration, 0), "mediatype": mediatype}
        if genre_preload_v1801:
            info["genre"] = genre_preload_v1801
        if content_rating_preload_v1804:
            info["mpaa"] = content_rating_preload_v1804
        if plex_type in ("episode", "season"):
            info.update({"tvshowtitle": show_title or title or "", "season": _safe_int(season, 0)})
            if plex_type == "episode":
                info["episode"] = _safe_int(episode, 0)
        if not _snapshot_only_v2476:
            apply_video_info(li, info)

        # v248 crash-stop: do not attach remote fanart/art to wall ListItems.
        # Kodi's texture loader can keep loading stale Plex /art URLs after fast
        # focus/menu changes.  Hero fanart still uses PlexKM.Art via properties.
        continue_poster_fallback_v2497 = ""
        if str(row_type or "") == "continue":
            # v2497: onDeck is resume authority only. If a canonical poster is
            # unavailable, use the stable movie/show poster endpoint; never stretch
            # landscape fanart/video still into the portrait card.
            continue_key_v2497 = str(grandparent_rating_key or "").strip() if plex_type == "episode" else str(rating_key or "").strip()
            if continue_key_v2497:
                continue_poster_fallback_v2497 = _plex_art(
                    "/library/metadata/%s/thumb" % continue_key_v2497,
                    width=720, height=1080,
                )
            poster_primary_v2497 = str(display_thumb or continue_poster_fallback_v2497 or "").strip()
        else:
            poster_primary_v2497 = str(display_thumb or art or "").strip()
        li.setArt({"poster": poster_primary_v2497, "thumb": poster_primary_v2497, "icon": poster_primary_v2497, "fanart": ""})
        try:
            # v2497: keep downstream poster prewarm/persistence on the same portrait
            # authority that was bound to ListItem art.  A Continue row must not
            # reintroduce landscape ``art`` through WallPosterRemote/Display.
            li.setProperty("PlexKM.WallPosterRemoteV1644", poster_primary_v2497)
            li.setProperty("PlexKM.WallPosterDisplayV1644", poster_primary_v2497)
        except Exception:
            pass
        # v697: Kodi-native image fallback.  Keep the primary poster/thumb exactly as-is
        # for speed and Kodi texture-cache reuse.  Provide art only as the XML
        # <texture fallback=...> candidate, so it is used only if the primary
        # thumb fails to render.  No HEAD/GET probe, no UI-flow/focus control.
        try:
            poster_fallback_v2498 = (
                continue_poster_fallback_v2497 if str(row_type or "") == "continue"
                else (actor_work_poster_fallback_v2130 or season_show_poster_fallback_v1870 or "")
            )
            # v2498: ``art`` is landscape hero/background artwork and must never
            # be a fallback for a portrait poster control.
            li.setProperty("PlexKM.PosterFallbackArt", poster_fallback_v2498)
            li.setProperty("PlexKM.PosterFallbackRoleV2498", "poster" if poster_fallback_v2498 else "")
            li.setProperty("PlexKM.PosterAuthorityV2498", poster_primary_v2497)
            li.setProperty("PlexKM.PosterLocalSourceV2498", "")
            li.setProperty("PlexKM.PosterFallbackArtActive", "")
            li.setProperty("PlexKM.PosterFallbackChecked", "")
            if str(row_type or "") == "info_actor_works_v1966":
                li.setProperty("PlexKM.ActorWorkPosterSourceV2130", actor_work_poster_source_v2130 or "none")
                li.setProperty("PlexKM.ActorWorkPosterCanonicalFallbackV2130", "1" if actor_work_poster_fallback_v2130 else "")
                _log("INFO_ACTOR_POSTER_BIND_V2130 rating_key=%s source=%s db_thumb=%d primary=%d canonical_fallback=%d network_probe=0" % (
                    rating_key, actor_work_poster_source_v2130 or "none",
                    1 if str(thumb or "").strip() else 0,
                    1 if str(display_thumb or "").strip() else 0,
                    1 if str(actor_work_poster_fallback_v2130 or "").strip() else 0,
                ))
        except Exception:
            pass
        progress_percent = 0
        progress_composite_350x10 = ""
        progress_composite_370x10 = ""
        try:
            off_raw = _safe_int(view_offset, 0)
            off_ms, dur_ms, progress_percent = getattr(_ensure_core(), "_pkm_progress_pair")(
                off_raw, duration, resume_duration_ms
            )
            progress_percent = int(max(0, min(100, _safe_int(progress_percent, 0))))
            if progress_percent > 0:
                progress_props_v2330 = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(progress_percent) or {}
                progress_composite_350x10 = str(progress_props_v2330.get("ResumeProgressComposite350x10") or "")
                progress_composite_370x10 = str(progress_props_v2330.get("ResumeProgressComposite370x10") or "")
            try:
                if not bool(getattr(self, "_suppress_item_diag_v2473", False)):
                    _log("WINDOW_HOME RESUME_PROGRESS_V2330 rating_key=%s title=%s source=%s updated_at=%s offset_raw=%s offset_ms=%s duration_ms=%s pct=%s composite=1 no_fill=1" % (
                    rating_key, title, resume_source, resume_updated_at, off_raw, off_ms, dur_ms, progress_percent
                ))
            except Exception:
                pass
        except Exception:
            progress_percent = 0
            progress_composite_350x10 = ""
            progress_composite_370x10 = ""

        watched_flag = "1" if _safe_int(view_count, 0) > 0 else ""
        imdb_rating_preload = ""
        cine21_preload = {"CriticRating": "", "AudienceRating": ""}
        watcha_preload = {"Rating": "", "Count": "", "Display": ""}
        try:
            if _light_item_v2584:
                # Keep the raw Plex/TMDB score already embedded in the local row
                # but never initialize IMDb/Cine21/Watcha bulk maps under splash.
                imdb_rating_preload = raw_rating_preload_v2260 or ""
                cine21_preload = {"CriticRating": "", "AudienceRating": ""}
                watcha_preload = {"Rating": "", "Count": "", "Display": ""}
            elif str(plex_type or "") == "movie":
                # v938/v943: put IMDb/Plex and Cine21 DB-only ratings on the
                # ListItem while rows are being built, before the poster row is
                # visible/focusable.  Focus changes should mostly read existing
                # ListItem properties, not perform fresh SQL.  No network/crawl.
                imdb_rating_preload = self._home_visible_imdb_rating_value(rating_key)
                # v1804: visible-row preload maps can legitimately be Home-only.
                # Never publish a section ListItem without its local IMDb score.
                if not imdb_rating_preload:
                    imdb_rating_preload = self._home_db_imdb_rating_value(rating_key)
                if not imdb_rating_preload:
                    imdb_rating_preload = canonical_movie_meta_v1816.get("Rating") or ""
                if not imdb_rating_preload and raw_rating_preload_v2260:
                    imdb_rating_preload = raw_rating_preload_v2260
                    _log("HOME_RATING_RAW_PRELOAD_V2260 rating_key=%s type=movie rating=%s source=local_raw_json" % (
                        rating_key, imdb_rating_preload
                    ))
                if not content_rating_preload_v1804:
                    content_rating_preload_v1804 = canonical_movie_meta_v1816.get("ContentRating") or ""
                cine21_preload = self._home_visible_cine21_rating_props(rating_key, title=title, original_title=original_title, year=year)
                watcha_preload = self._home_watcha_preload_props(rating_key, title=title, original_title=original_title, year=year)
                # v947: during Home/section poster construction, do not fall back to
                # full DB bulk maps here.  Visible-row batch preload runs before
                # rendering; if a value is absent, leave it blank for focus-time
                # DB-only meta sync rather than delaying all widgets.
                if not getattr(self, "_home_visible_rating_preload_ready", False):
                    imdb_rating_preload = imdb_rating_preload or self._home_db_imdb_rating_value(rating_key)
                    if not (cine21_preload.get("CriticRating") or cine21_preload.get("AudienceRating")):
                        cine21_preload = self._home_cine21_preload_props(rating_key, title=title, original_title=original_title, year=year)
                    if not (watcha_preload.get("Rating") or watcha_preload.get("Display")):
                        watcha_preload = self._home_watcha_preload_props(rating_key, title=title, original_title=original_title, year=year)
            else:
                # v1600: Home TV uses only the Plex/TMDB score. Episodes inherit the
                # show score from grandparentRatingKey when the local index has it.
                tv_rating_key = grandparent_rating_key or parent_rating_key or rating_key
                imdb_rating_preload = str(tv_sort_meta_v1911.get("tmdb_rating") or "")
                if not imdb_rating_preload:
                    imdb_rating_preload = self._home_db_imdb_rating_value(tv_rating_key)
                if not imdb_rating_preload and raw_rating_preload_v2260:
                    imdb_rating_preload = raw_rating_preload_v2260
                    _log("HOME_RATING_RAW_PRELOAD_V2260 rating_key=%s type=%s rating=%s source=local_raw_json" % (
                        rating_key, plex_type, imdb_rating_preload
                    ))
        except Exception:
            imdb_rating_preload = ""
            cine21_preload = {"CriticRating": "", "AudienceRating": ""}
            watcha_preload = {"Rating": "", "Count": "", "Display": ""}
        try:
            common_props = getattr(_ensure_core(), "pkm_common_progress_props", lambda *a, **k: {})(rating_key, plex_type, grandparent_rating_key, view_count, view_offset, duration, resume_duration_ms) or {}
            if _safe_int(common_props.get("ResumePercent"), 0) > 0:
                progress_percent = _safe_int(common_props.get("ResumePercent"), progress_percent)
                progress_composite_350x10 = str(common_props.get("ResumeProgressComposite350x10") or progress_composite_350x10)
                progress_composite_370x10 = str(common_props.get("ResumeProgressComposite370x10") or progress_composite_370x10)
                watched_flag = common_props.get("IsWatched") or watched_flag
        except Exception:
            pass

        # v1911: show-level Library rows carry episode aggregates in plain JSON.
        # Apply them only to those rows; Home/recommendation ListItems keep their
        # existing resume calculation.
        try:
            if str(plex_type or "").lower() == "show" and tv_sort_meta_v1911:
                episode_count_v1911 = int(tv_sort_meta_v1911.get("episode_count") or 0)
                if episode_count_v1911 > 0:
                    progress_percent = int(max(0, min(100, int(tv_sort_meta_v1911.get("progress_percent") or 0))))
                    watched_flag = "1" if bool(tv_sort_meta_v1911.get("is_watched")) else ""
                    view_count = 1 if watched_flag else 0
                    _tv_progress_props_v2330 = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(progress_percent) or {}
                    progress_composite_350x10 = str(_tv_progress_props_v2330.get("ResumeProgressComposite350x10") or "")
                    progress_composite_370x10 = str(_tv_progress_props_v2330.get("ResumeProgressComposite370x10") or "")
        except Exception:
            pass

        props = {"RatingKey": rating_key, "SectionId": section_id, "Type": plex_type, "KodiType": mediatype, "Title": title, "OriginalTitle": original_title, "SortTitle": sort_title, "Year": year, "Summary": summary, "Duration": duration, "AddedAt": added_at, "UpdatedAt": updated_at, "Thumb": display_thumb, "EpisodeThumb": thumb, "Art": art, "PartKey": part_key, "ViewCount": view_count, "IsWatched": watched_flag, "Genre": genre_preload_v1801, "ContentRating": content_rating_preload_v1804, "Rating": imdb_rating_preload, "Cine21CriticRating": cine21_preload.get("CriticRating", "") if isinstance(cine21_preload, dict) else "", "Cine21AudienceRating": cine21_preload.get("AudienceRating", "") if isinstance(cine21_preload, dict) else "", "WatchaRating": watcha_preload.get("Rating", "") if isinstance(watcha_preload, dict) else "", "WatchaCount": watcha_preload.get("Count", "") if isinstance(watcha_preload, dict) else "", "WatchaDisplay": watcha_preload.get("Display", "") if isinstance(watcha_preload, dict) else "", "ShowTitle": show_title, "Season": season, "Episode": episode, "ParentRatingKey": parent_rating_key, "GrandparentRatingKey": grandparent_rating_key, "ViewOffset": view_offset, "ResumeDurationMs": resume_duration_ms, "ResumeUpdatedAt": resume_updated_at, "ResumeSource": resume_source, "ResumePercent": progress_percent, "ResumeProgressComposite350x10": progress_composite_350x10, "ResumeProgressComposite370x10": progress_composite_370x10}
        # v2330: resume progress is one precomposed rounded image; no separate fill layer or width property.
        for k, v in props.items():
            li.setProperty("PlexKM.%s" % k, str(v or ""))
        season_label_v1870 = ""
        if plex_type == "season":
            season_number_v1870 = _safe_int(season, 0)
            season_label_v1870 = self._info_tv_normalize_season_label("", season_number_v1870)
            li.setProperty("PlexKM.IsSeasonFolderV1870", "1")
            li.setProperty("PlexKM.SeasonFolderLabel", season_label_v1870)
            li.setProperty("PlexKM.ShowTitle", str(show_title or title or ""))
            li.setProperty("PlexKM.KodiType", "tvshow")
            _log("TV_SEASON_FOLDER_LISTITEM_V1870 section=%s show=%s season=%s representative=%s title=%s label=%s" % (
                section_id, grandparent_rating_key, season_number_v1870, rating_key,
                _short_log_value(show_title or title or "", 100), season_label_v1870
            ))
        # v1911: Library cards use three bounded lines below the poster:
        # one-line title, year, and the active sort value. Only the focused title
        # scrolls in XML; year/sort lines are fixed and never synthesize ellipsis.
        try:
            wall_title_v1911 = pkm_library_sort.wall_title_layout(title or "")
        except Exception:
            wall_title_v1911 = {"line1": pkm_library_sort.no_ellipsis_text(title or "")}
        try:
            raw_sort_v1911 = pkm_library_sort.sort_raw_values(sort_raw_json_v1907)
        except Exception:
            raw_sort_v1911 = {}
        wall_year_v1911 = pkm_library_sort.wall_year_text(year)
        wall_sort_v1911 = ""
        try:
            cine21_sort_v1911 = ""
            if isinstance(cine21_preload, dict):
                cine21_sort_v1911 = cine21_preload.get("CriticRating") or cine21_preload.get("AudienceRating") or ""
            watcha_sort_v1911 = ""
            if isinstance(watcha_preload, dict):
                watcha_sort_v1911 = watcha_preload.get("Rating") or ""
            wall_media_kind_v1911 = "tv" if str(plex_type or "").lower() in ("show", "season", "episode", "tv") else "movie"
            if season_label_v1870 and not tv_sort_meta_v1911:
                wall_sort_v1911 = pkm_library_sort.no_ellipsis_text(season_label_v1870)
            else:
                wall_sort_v1911 = pkm_library_sort.wall_sort_meta(
                    getattr(self, "sort", "title"),
                    year=year,
                    added_at=added_at,
                    last_viewed_at=last_viewed_at,
                    release_date=raw_sort_v1911.get("release", ""),
                    resolution=raw_sort_v1911.get("resolution", ""),
                    height=raw_sort_v1911.get("height", ""),
                    bitrate=raw_sort_v1911.get("bitrate", 0),
                    cine21=cine21_sort_v1911,
                    watcha=watcha_sort_v1911,
                    imdb=imdb_rating_preload or raw_sort_v1911.get("rating", ""),
                    progress_percent=progress_percent,
                    is_watched=bool(watched_flag),
                    media_kind=wall_media_kind_v1911,
                    tv_meta=tv_sort_meta_v1911,
                )
        except Exception:
            wall_sort_v1911 = pkm_library_sort.no_ellipsis_text(season_label_v1870) if season_label_v1870 else ""
        # R53: 왓챠/씨네21 평점순 -> show that provider's score on the poster sort
        # line (rating preloads are bypassed on Android, so it was blank).
        try:
            _sort_r53 = str(getattr(self, "sort", "") or "").strip().lower()
            if _sort_r53 in ("watcha", "cine21") and not season_label_v1870 and not row_title:
                _map_r53 = getattr(_ensure_core(), "wall_provider_display_for_keys_r55")(section_id, _sort_r53, [str(rating_key or "")]) or {}
                _txt_r53 = _map_r53.get(str(rating_key or ""), "")
                wall_sort_v1911 = _txt_r53 or ""
        except Exception:
            pass
        li.setProperty("PlexKM.WallTitleLine1", str(wall_title_v1911.get("line1") or ""))
        li.setProperty("PlexKM.WallTitleFull", str(wall_title_v1911.get("full") or wall_title_v1911.get("line1") or ""))
        li.setProperty("PlexKM.WallYearLine", str(wall_year_v1911 or ""))
        try:
            li.setProperty("PlexKM.WallDurationText", str(self._duration_text(duration) or "") if str(plex_type or "").lower() == "movie" else "")
        except Exception:
            pass
        li.setProperty("PlexKM.WallSortLine", str(wall_sort_v1911 or ""))
        # Legacy property retained for any older XML copy; it receives only the
        # sort line and never duplicates the year.
        li.setProperty("PlexKM.WallMetaLine", str(wall_sort_v1911 or ""))
        # v1917: 4K badge is version-specific across library walls and home/sidebar
        # movie widgets. It is derived only from this rating_key's own raw Media
        # values; canonical duplicate metadata must never mark a 1080p sibling 4K.
        is_4k_v1914 = False
        try:
            resolution_v1914 = str(raw_sort_v1911.get("resolution") or "").strip().lower()
            height_v1914 = _safe_int(raw_sort_v1911.get("height"), 0)
            is_4k_v1914 = (
                str(plex_type or "").strip().lower() == "movie"
                and (resolution_v1914 in ("4k", "uhd", "2160", "2160p") or height_v1914 >= 2000)
            )
        except Exception:
            is_4k_v1914 = False
        li.setProperty("PlexKM.Is4K", "1" if is_4k_v1914 else "")
        # PKM_INFO_RESOLUTION_FIRSTFRAME_20261014
        # The wall/source row already parsed raw_json. Attach ONLY this movie's
        # own verified resolution so Info can show its round icon immediately.
        # Do not inherit the resolution of another movie/library copy.
        if str(plex_type or "").strip().lower() == "movie":
            _raw_resolution_first_vnext = str(raw_sort_preload_v2260.get("resolution") or "").strip().lower()
            _raw_height_first_vnext = _safe_int(raw_sort_preload_v2260.get("height"), 0)
            _source_resolution_first_vnext = ""
            if (_raw_resolution_first_vnext in ("4k", "uhd", "2160", "2160p")
                    or "2160" in _raw_resolution_first_vnext or _raw_height_first_vnext >= 2000):
                _source_resolution_first_vnext = "2160p"
            elif ("1080" in _raw_resolution_first_vnext or _raw_height_first_vnext >= 1000):
                _source_resolution_first_vnext = "1080p"
            elif ("720" in _raw_resolution_first_vnext or _raw_height_first_vnext >= 700):
                _source_resolution_first_vnext = "720p"
            li.setProperty("PlexKM.SourceResolutionFirstVNext", _source_resolution_first_vnext)
        if genre_preload_v1801 and not bool(getattr(self, "_suppress_item_diag_v2473", False)):
            try:
                _log("SECTION_LISTITEM_GENRE_V1801 rating_key=%s section=%s genre=%s" % (
                    rating_key, section_id, _short_log_value(genre_preload_v1801, 120)
                ))
            except Exception:
                pass
        self._remember_meta_hint(rating_key, title=title, year=year, section_id=section_id, plex_type=plex_type)
        li.setProperty("PlexKM.PlayUrl", url if part_key and plex_type in ("movie", "episode") else "")
        li.setProperty("PlexKM.ShowUrl", url if plex_type == "show" else "")
        li.setProperty("PlexKM.OpenEpisodeInfo", "1" if plex_type == "season" else "")
        if row_title:
            row_title = _display_library_title(row_title)
            li.setProperty("PlexKM.HomeRowTitle", row_title)
            li.setProperty("PlexKM.HomeLayout", "1")
            li.setProperty("PlexKM.HomeRowId", str(row_id or row_title or ""))
            li.setProperty("PlexKM.HomeRowStart", str(row_start if row_start is not None else -1))
            li.setProperty("PlexKM.HomeRowIndex", str(row_index if row_index is not None else -1))
            try:
                if _safe_int(row_start, -1) >= 0 and _safe_int(row_index, -1) >= 0:
                    li.setProperty("PlexKM.DebugGlobalPos", str(_safe_int(row_start, -1) + _safe_int(row_index, -1)))
            except Exception:
                pass
        if row_first:
            li.setProperty("PlexKM.HomeRowFirst", "1")
        if row_type:
            li.setProperty("PlexKM.HomeRowType", row_type)
        try:
            if row_title and (not bool(getattr(self, "_suppress_item_diag_v2473", False))) and getattr(_ensure_core(), "debug_enabled", lambda: False)():
                dbg_pos = _safe_int(li.getProperty("PlexKM.DebugGlobalPos"), -1)
                _log("POSTER_GEOM_BUILD %s" % self._debug_wall_geometry(li, dbg_pos))
        except Exception:
            pass
        if part_key and plex_type in ("movie", "episode"):
            li.setProperty("IsPlayable", "true")
        return self._overlay_gate_register_r56(li, art_key="poster")

    def _home_fanart_if_owned_r65(self, li):
        """R65: Home's DisplayFanart is a fallback only when Home is showing
        THIS title.  A show without Plex fanart (꽃보다 여자) used to inherit
        the previous title's background (나인 퍼즐) from Home."""
        try:
            target = str(li.getProperty("PlexKM.RatingKey") or "").strip() if li is not None else ""
            parent = str(li.getProperty("PlexKM.GrandparentRatingKey") or "").strip() if li is not None else ""
            win = xbmcgui.Window(10000)
            owner = str(win.getProperty("PlexKM.Home.RatingKey") or self.getProperty("PlexKM.Home.RatingKey") or "").strip()
            # Home keeps the previous fanart when the focused title has none,
            # so ownership also requires the focused title to have its own art.
            own_art = str(win.getProperty("PlexKM.Home.Art") or self.getProperty("PlexKM.Home.Art") or "").strip()
            if owner and owner in (target, parent) and own_art:
                return (win.getProperty("PlexKM.Home.DisplayFanart") or
                        self.getProperty("PlexKM.Home.DisplayFanart") or "")
            if owner or target:
                _log("INFO_HOME_FANART_FALLBACK_SKIP_R65 target=%s home_owner=%s" % (target or "-", owner or "-"))
        except Exception:
            pass
        return ""


    def _store_home_meta_enrich_cache(self, rating_key, props, reason="", drop_name_only_cast=False):
        """Store Home/Info metadata without allowing cast artwork regression.

        v1216 root fix:
        Home enrich/startup sync can receive a temporary Plex/cache response where
        Role names are present but Role thumbs are empty.  That response must not
        overwrite an existing cache/DB entry that already has actor artwork.
        """
        try:
            rk = str(rating_key or "").strip()
            if not rk or not isinstance(props, dict):
                return False
            cache = getattr(self, "_home_meta_enrich_cache", None)
            if not isinstance(cache, dict):
                cache = {}
                self._home_meta_enrich_cache = cache

            incoming = dict(props)
            incoming_slots = incoming.get("CastSlots") or []
            incoming_names, incoming_real = self._cast_slots_thumb_stats(incoming_slots)

            best_slots = incoming_slots
            best_cast = incoming.get("Cast") or ""
            best_names = incoming_names
            best_real = incoming_real
            best_source = "incoming"

            existing = cache.get(rk)
            if isinstance(existing, dict):
                existing_slots = existing.get("CastSlots") or []
                existing_names, existing_real = self._cast_slots_thumb_stats(existing_slots)
                if existing_names > 0 and existing_real > best_real:
                    best_slots = existing_slots
                    best_cast = existing.get("Cast") or best_cast
                    best_names = existing_names
                    best_real = existing_real
                    best_source = "existing_cache"

            # DB is the authoritative sync result for actor/person thumbnails.
            # Use it only for comparing cast artwork; all other metadata still
            # comes from the incoming Plex/Home props.
            try:
                db_cached = self._load_info_cache_from_local_db(rk, reason="%s_cast_cache_guard" % (reason or "store"))
                if isinstance(db_cached, dict):
                    db_slots = db_cached.get("CastSlots") or []
                    db_names, db_real = self._cast_slots_thumb_stats(db_slots)
                    if db_names > 0 and db_real > best_real:
                        best_slots = db_slots
                        best_cast = db_cached.get("Cast") or best_cast
                        best_names = db_names
                        best_real = db_real
                        best_source = "local_db"
            except Exception:
                pass

            if best_source != "incoming":
                incoming["CastSlots"] = best_slots
                incoming["Cast"] = best_cast or incoming.get("Cast") or ""
                _log("HOME_META_ENRICH_CAST_GUARD rating_key=%s reason=%s incoming_names=%d incoming_real=%d best_source=%s best_names=%d best_real=%d action=preserve_better_cast" % (
                    rk, reason or "", incoming_names, incoming_real, best_source, best_names, best_real
                ), xbmc.LOGWARNING)
            elif drop_name_only_cast and incoming_names > 0 and incoming_real <= 0:
                # Do not cache a names-only cast as if it were valid.  This was
                # the source of the grey-avatar regression: later Info code saw
                # names, filled thumbnails with placeholders, and froze them.
                incoming["CastSlots"] = []
                incoming["Cast"] = ""
                _log("HOME_META_ENRICH_CAST_GUARD rating_key=%s reason=%s incoming_names=%d incoming_real=%d action=drop_name_only_cast" % (
                    rk, reason or "", incoming_names, incoming_real
                ), xbmc.LOGWARNING)

            cache[rk] = incoming
            return True
        except Exception:
            try:
                _log("HOME_META_ENRICH_CAST_GUARD_FAILED rating_key=%s reason=%s err=%s" % (
                    rating_key or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            except Exception:
                pass
            return False

    def _recover_failed_opening_to_home_v2224(self, reason=""):
        """Cancel a pre-AV failed/aborted opening and return directly to PKM Home.

        This runs only on the live WindowXML GUI callback path (onAction). It
        never changes the successful playback path and never performs playback
        selection/resolution itself.
        """
        try:
            win = xbmcgui.Window(10000)
            try:
                video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
            except Exception:
                video_active = False
            if video_active:
                win.clearProperty("PlexKM.Playback.FailureHomeRequestV2224")
                win.clearProperty("PlexKM.Playback.FailureHomeRequestSourceV2224")
                _log("PLAYBACK_FAILURE_HOME_ABORT_V2224 reason=%s video_active=1 action=leave_playback_untouched" % (reason or ""))
                return False

            token_v2224 = win.getProperty("PlexKM.Playback.NativeOpening.Token") or win.getProperty("PlexKM.Playback.ResolverTokenV1547") or ""
            phase_v2224 = win.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
            # Stop any half-open native player. It is safe when no player exists.
            try:
                xbmc.executebuiltin("PlayerControl(Stop)")
            except Exception:
                pass

            for key in (
                "PlexKM.Playback.NativeOpening",
                "PlexKM.Playback.NativeOpening.SpinnerVisible",
                "PlexKM.Playback.NativeOpening.HoldClear",
                "PlexKM.Playback.NativeOpening.WaitResumeV1551",
                "PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551",
                "PlexKM.Playback.NativeOpening.Pending",
                "PlexKM.Playback.NativeOpening.RatingKey",
                "PlexKM.Playback.NativeOpening.Token",
                "PlexKM.Playback.NativeOpening.Source",
                "PlexKM.Playback.NativeOpening.ArmedAtMs",
                "PlexKM.Playback.NativeOpening.ShownAtMs",
                "PlexKM.Playback.OpeningActive",
                "PlexKM.Playback.OpeningRatingKey",
                "PlexKM.Playback.PriorityV2118",
                "PlexKM.Playback.PriorityRatingKeyV2118",
                "PlexKM.Playback.PriorityArmedAtMsV2118",
                "PlexKM.Playback.ResolverTokenV1547",
                "PlexKM.Playback.ResolverPhaseV1547",
                "PlexKM.Playback.ResolverHandoffStopAtMsV1547",
                "PlexKM.Playback.ResolverAVStartedAtMsV1547",
                "PlexKM.Playback.ResolverTickHoldLoggedV1547",
                "PlexKM.Playback.OpenFailureCandidateV2224",
                "PlexKM.Playback.OpenFailureCandidateAtMsV2224",
                "PlexKM.Playback.FailureHomeRequestV2224",
                "PlexKM.Playback.FailureHomeRequestSourceV2224",
                "PlexKM.Playback.FailureDialogShownV2228",
                "PlexKM.Playback.DefinitiveFailureV2229",
                "PlexKM.Playback.BackStopRequested",
                "PlexKM.NativePlayback.SuppressNextInlineBack",
                "PlexKM.MainPlaybackStarting",
                "PlexKM.MainPlaybackRatingKey",
                "PlexKM.Playback.HidePKMUI",
                "PlexKM.Playback.HideSkinHome",
            ):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
            try:
                self.clearProperty("PlexKM.NativePlayback.SuppressNextInlineBack")
            except Exception:
                pass
            self._main_playback_requested = False
            self._playback_opening = False

            # Failure recovery is explicitly Home, not the previous Info page.
            try:
                self._clear_inline_info(reason="playback_failure_home_v2224")
            except Exception:
                pass
            try:
                self.active_menu_index = 0
                self._last_menu_pos = 0
                self._start_widget_stack_transition(reason="playback_failure_home_v2224")
                self._show_home_wall(force=False)
                self._force_home_menu_focus(
                    reason="playback_failure_home_v2224",
                    select_home=True,
                    force_handoff=True,
                )
            except Exception:
                _log("PLAYBACK_FAILURE_HOME_VISUAL_RECOVERY_FAILED_V2224 reason=%s err=%s" % (
                    reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            _log("PLAYBACK_FAILURE_HOME_RECOVERED_V2224 reason=%s token=%s phase=%s spinner=0 inline_info=0 destination=home" % (
                reason or "", token_v2224, phase_v2224 or "-"
            ))
            return True
        except Exception:
            _log("PLAYBACK_FAILURE_HOME_RECOVERY_FAILED_V2224 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False
