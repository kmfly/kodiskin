# -*- coding: utf-8 -*-
"""PKM_UHD_STABILITY_U1: bounded actor-service startup recovery.
No GUI waits, no DB download on the caller thread, no Kodi restart/quit.
"""
import json
import os
import threading
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_LOCK = threading.Lock()
_STARTED = False

def _log(msg, level=xbmc.LOGINFO):
    try: xbmc.log('[plugin.video.km] ACTOR_BOOTSTRAP_U1 ' + str(msg), level)
    except Exception: pass

def _run():
    try:
        mon = xbmc.Monitor()
        if mon.waitForAbort(2.0): return
        win = xbmcgui.Window(10000)
        if win.getProperty('PKM.Actor.ServiceRunning') == '1':
            _log('already_running=1')
            return
        try:
            addon = xbmcaddon.Addon('service.pkm.actor')
        except Exception as exc:
            _log('addon_not_registered err=%s' % exc, xbmc.LOGWARNING)
            return
        script = os.path.join(addon.getAddonInfo('path'), 'service.py')
        if not os.path.isfile(script):
            _log('service_file_missing')
            return
        # Do not override an administrator-disabled addon, and attempt native
        # AddonMgr enable only if Kodi reports it disabled.
        try:
            request = json.dumps({'jsonrpc':'2.0','method':'Addons.GetAddon',
                'params':{'addonid':'service.pkm.actor','properties':['enabled']},'id':7})
            result = json.loads(xbmc.executeJSONRPC(request) or '{}')
            enabled = ((result.get('result') or {}).get('addon') or {}).get('enabled')
            if enabled is False:
                request = json.dumps({'jsonrpc':'2.0','method':'Addons.SetAddonEnabled',
                    'params':{'addonid':'service.pkm.actor','enabled':True},'id':8})
                response = json.loads(xbmc.executeJSONRPC(request) or '{}')
                _log('kodi_enable=%s' % ('error' not in response))
        except Exception as exc:
            _log('addon_enable_probe_failed=%s' % exc, xbmc.LOGWARNING)
        # Kodi may register/launch the native service asynchronously; give
        # it a final chance before invoking the exact installed service file.
        if mon.waitForAbort(1.0): return
        if win.getProperty('PKM.Actor.ServiceRunning') == '1':
            _log('native_service_started=1')
            return
        _log('run_script_fallback=1 path=%s' % script)
        xbmc.executebuiltin('RunScript(%s)' % script)
    except Exception as exc:
        _log('start_failed=%s' % exc, xbmc.LOGWARNING)

def start_async():
    global _STARTED
    with _LOCK:
        if _STARTED: return
        _STARTED = True
    threading.Thread(target=_run, name='PKMActorBootstrapU1',daemon=True).start()
