# -*- coding: utf-8 -*-
"""R140: 재생 중 BACK -> 부드러운 정지 페이드 (가벼운 진입점).

예전에는 키맵이 RunPlugin(default.py) 로 이 동작을 불렀는데, 큰 default.py 를
읽느라 쉴드에서 BACK 후 약 1초 동안 영상이 그대로 재생되다가 페이드가 시작됐다.
이 파일은 default.py 의 v1557 페이드-정지 흐름을 그대로 옮긴 작은 스크립트로,
RunScript 로 바로 실행되어 BACK 직후 페이드가 시작된다. 페이드 0.36초.
"""
from __future__ import absolute_import, unicode_literals

import sys
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


class PKMReturnFadeOverlayWindowV1505(xbmcgui.WindowXMLDialog):
    """v1557/v1505 top-layer fade over the live Kodi video surface.

    This dialog is deliberately visual-only.  It does not pause, seek, stop,
    rebuild Home, or mutate playback state from a worker thread.  Its single
    black image fades in above the still-running DXVA video surface.
    """
    def onAction(self, action):
        return

    def onClick(self, control_id):
        return


def _pkm_open_return_video_fade_overlay_v1557(token=""):
    overlay = None
    try:
        addon_path = ADDON.getAddonInfo("path")
        overlay = PKMReturnFadeOverlayWindowV1505(
            "plexkm_return_fade_overlay_v1505.xml",
            addon_path,
            "Default",
            "1080i",
        )
        overlay.show()
        # v1944: one short frame is sufficient; do not hold live playback.
        xbmc.sleep(20)
        log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_OPENED_V1557 token=%s layer=WindowXMLDialog over_live_video=1" % (token or ""), xbmc.LOGINFO)
        return overlay
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_OPEN_FAILED_V1557 token=%s\n%s" % (token or "", traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass
        try:
            if overlay:
                overlay.close()
        except Exception:
            pass
        return None


def _pkm_wait_return_home_ready_v1557(max_ms=1800):
    """Wait until Kodi has left the real video surface before dialog close.

    The old v1501 crash risk came from closing the dynamic dialog while DXVA
    FullscreenVideo was still being torn down.  The stabilized v1505 rule is
    retained: keep the dialog fully black until both Player.HasMedia and the
    fullscreen window are gone, with a bounded timeout.
    """
    try:
        start = int(time.time() * 1000)
        while int(time.time() * 1000) - start < int(max_ms):
            if (not xbmc.getCondVisibility("Player.HasMedia")) and (not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")):
                return True
            xbmc.sleep(60)
    except Exception:
        pass
    return False


def _pkm_close_return_video_fade_overlay_v1557(overlay, token=""):
    if not overlay:
        return
    try:
        overlay.close()
        xbmc.sleep(20)
        log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_CLOSED_V1557 token=%s close_mode=instant_after_home_cover" % (token or ""), xbmc.LOGINFO)
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_CLOSE_FAILED_V1557 token=%s\n%s" % (token or "", traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass


def _pkm_clear_return_video_fade_state_v1557(token="", include_back_stop=True):
    try:
        w = xbmcgui.Window(10000)
        active_token = w.getProperty("PlexKM.Playback.ReturnFade.Token") or ""
        if token and active_token and active_token != token:
            return
        keys = [
            "PlexKM.Playback.ReturnFade",
            "PlexKM.Playback.ReturnFade.Stopping",
            "PlexKM.Playback.ReturnFade.Token",
            "PlexKM.Playback.ReturnFade.Source",
            "PlexKM.Playback.ReturnFade.StartedAtMs",
            "PlexKM.Playback.ReturnFade.FadeStartedAtMs",
            "PlexKM.Playback.ReturnFade.PauseHold",
            "PlexKM.Playback.ReturnFade.SuppressPreread",
            "PlexKM.Playback.ReturnFade.DialogMode",
            "PlexKM.Playback.ReturnFade.DialogActive",
            "PlexKM.Playback.ReturnFade.TopLayer",
            "PlexKM.Playback.ReturnFade.HomeCoverReady",
            "PlexKM.Playback.ReturnInfoReadyV1939",
        ]
        if include_back_stop:
            keys.append("PlexKM.Playback.BackStopRequested")
        for key in keys:
            try:
                w.clearProperty(key)
            except Exception:
                pass
    except Exception:
        pass


def pkm_playback_return_fade_stop(params=None):
    """v1557: restore the proven v1505 live-video fade, then native Stop.

    Visible sequence:
      live video continues -> black WindowXMLDialog fades over that video ->
      fully black -> one PlayerControl(Stop) -> Home cover is primed ->
      dialog closes only after FullscreenVideo teardown -> Home cover clears.

    There is no Action(Pause), no seek, no direct HTTP playback change, no
    onInit stop heuristic, and no background-thread GUI mutation.
    """
    params = params or {}
    source = str(params.get("source") or "fullscreen_back")
    token = "%s:%d" % (source, int(time.time() * 1000))
    # R140: 이 BACK 은 키맵이 RunScript 로 다 받아서 인포 창으로 새지 않는다.
    # "다음 BACK 하나 무시" 표시를 남겨 두면 복귀 뒤 사용자의 첫 BACK 이 먹힌다.
    try:
        xbmcgui.Window(10000).clearProperty("PlexKM.NativePlayback.SuppressNextInlineBack")
    except Exception:
        pass
    # v1944: fast return.  Keep only a short cover to prevent a raw video/home
    # frame flash; do not reuse the much longer cinematic fade used previously.
    fade_start_delay_ms = 0
    fade_ms = 360  # R140: 부드러운 정지 페이드
    post_fade_hold_ms = 0
    stop_settle_max_ms = 1100
    home_cover_prime_ms = 20
    # v2125: once the restored PKM surface reports Ready, keep the fully black
    # top layer for a small native-bind margin before starting the Home/Info
    # cover fade.  This prevents fanart (texture-ready first) from becoming
    # visible a frame before its metadata labels.
    return_surface_settle_hold_ms_v2125 = 120
    home_fadeout_ms = 0
    overlay = None
    win = None
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Playback.ReturnFade.Stopping") == "1":
            log("PLAYBACK_RETURN_VIDEO_FADE_SKIP_V1557 reason=already_stopping source=%s" % source, xbmc.LOGINFO)
            return True
        inline_return_pending_v1939 = win.getProperty("PlexKM.Playback.ReturnInline.Pending") == "1"

        # Mark stop before any delay so leaked Back and preread workers cannot
        # start a second exit path while the visible fade is running.
        win.setProperty("PlexKM.Playback.ReturnFade.Stopping", "1")
        win.setProperty("PlexKM.Playback.ReturnFade.Token", token)
        win.setProperty("PlexKM.Playback.ReturnFade.Source", source)
        win.setProperty("PlexKM.Playback.ReturnFade.StartedAtMs", str(int(time.time() * 1000)))
        win.clearProperty("PlexKM.Playback.ReturnFade.PauseHold")
        win.setProperty("PlexKM.Playback.ReturnFade.SuppressPreread", "1")
        win.setProperty("PlexKM.Playback.ReturnFade.DialogMode", "1")
        win.clearProperty("PlexKM.Playback.ReturnFade.DialogActive")
        win.clearProperty("PlexKM.Playback.ReturnFade.TopLayer")
        win.clearProperty("PlexKM.Playback.ReturnFade.HomeCoverReady")
        win.clearProperty("PlexKM.Playback.ReturnInfoReadyV1939")
        win.setProperty("PlexKM.Playback.BackStopRequested", "1")

        was_playing = bool(xbmc.getCondVisibility("Player.Playing"))
        was_paused = bool(xbmc.getCondVisibility("Player.Paused"))
        log("PLAYBACK_RETURN_VIDEO_FADE_BEGIN_V1557 source=%s token=%s was_playing=%s was_paused=%s live_video_continues=1 forced_pause=0 seek=0 fade_start_delay_ms=%d fade_ms=%d dialog_overlay=1 stop_after_black=1" % (
            source, token,
            "1" if was_playing else "0",
            "1" if was_paused else "0",
            fade_start_delay_ms, fade_ms
        ), xbmc.LOGINFO)

        # Keep the movie running.  The black image itself fades over the real
        # FullscreenVideo/DXVA frame, which is the v1505 PASS architecture.
        xbmc.sleep(fade_start_delay_ms)
        overlay = _pkm_open_return_video_fade_overlay_v1557(token=token)
        if overlay is None:
            # Never leave playback stuck merely because the visual dialog failed.
            try:
                xbmc.executebuiltin("PlayerControl(Stop)")
            except Exception:
                pass
            log("PLAYBACK_RETURN_VIDEO_FADE_FALLBACK_NATIVE_STOP_V1557 source=%s token=%s reason=dialog_open_failed" % (source, token), xbmc.LOGWARNING)
            _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
            return False

        # R140: 덮개를 먼저 띄운 뒤 preread 취소 (BACK -> 페이드 시작 지연 최소화)
        # R182: 모듈을 새로 import 하면 쉴드에서 ~1.6초가 걸려 정지가 그만큼 늦어졌다.
        # 이미 로드된 모듈을 쓰고, 없으면 백그라운드에서 처리해 정지를 막지 않는다.
        try:
            import sys as _sys_r182
            _sq_r182 = _sys_r182.modules.get("resources.lib.pkm_seek_quick") or _sys_r182.modules.get("pkm_seek_quick")
            if _sq_r182 is not None and hasattr(_sq_r182, "cancel_manual_preread"):
                _sq_r182.cancel_manual_preread(reason="ReturnVideoFadeStopNoPauseV1557")
                log("PLAYBACK_RETURN_VIDEO_FADE_CANCEL_PREREAD_V1557 source=%s token=%s mode=loaded" % (source, token), xbmc.LOGINFO)
            else:
                import threading as _th_r182

                def _cancel_bg_r182():
                    try:
                        import pkm_seek_quick as _m
                        _m.cancel_manual_preread(reason="ReturnVideoFadeStopNoPauseV1557")
                    except Exception:
                        pass
                _th_r182.Thread(target=_cancel_bg_r182, daemon=True).start()
                log("PLAYBACK_RETURN_VIDEO_FADE_CANCEL_PREREAD_V1557 source=%s token=%s mode=background" % (source, token), xbmc.LOGINFO)
        except Exception:
            try:
                log("PLAYBACK_RETURN_VIDEO_FADE_CANCEL_PREREAD_FAILED_V1557 source=%s token=%s\n%s" % (source, token, traceback.format_exc()), xbmc.LOGWARNING)
            except Exception:
                pass

        try:
            w = xbmcgui.Window(10000)
            if w.getProperty("PlexKM.Playback.ReturnFade.Token") == token:
                w.setProperty("PlexKM.Playback.ReturnFade.DialogActive", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.TopLayer", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.FadeStartedAtMs", str(int(time.time() * 1000)))
        except Exception:
            pass

        # Stop only after the live video has become fully black.
        xbmc.sleep(fade_ms + post_fade_hold_ms)
        try:
            xbmc.executebuiltin("PlayerControl(Stop)")
        except Exception:
            pass
        log("PLAYBACK_RETURN_VIDEO_FADE_STOP_AFTER_BLACK_V1557 source=%s token=%s command=PlayerControl(Stop) forced_pause=0" % (source, token), xbmc.LOGINFO)

        # Prime the Home/Info black cover underneath the dialog.  The dynamic
        # dialog stays fully black while Kodi tears down FullscreenVideo.
        try:
            w = xbmcgui.Window(10000)
            if w.getProperty("PlexKM.Playback.ReturnFade.Token") == token:
                w.clearProperty("PlexKM.Playback.ReturnFade.DialogMode")
                w.setProperty("PlexKM.Playback.ReturnFade", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.HomeCoverReady", "1")
        except Exception:
            pass

        settled = _pkm_wait_return_home_ready_v1557(max_ms=stop_settle_max_ms)

        # v1939: Inline Info is rebuilt only after FullscreenVideo teardown.
        # Keep the fully black top-layer dialog until that completed Info surface
        # is atomically published; closing it earlier exposed one Home frame.
        info_ready_v1939 = False
        info_wait_ms_v1939 = 0
        if inline_return_pending_v1939:
            wait_start_v1939 = int(time.time() * 1000)
            max_info_wait_ms_v1939 = 1500
            while int(time.time() * 1000) - wait_start_v1939 < max_info_wait_ms_v1939:
                try:
                    if win.getProperty("PlexKM.Playback.ReturnInfoReadyV1939") == "1":
                        info_ready_v1939 = True
                        break
                except Exception:
                    pass
                xbmc.sleep(20)
            info_wait_ms_v1939 = int(time.time() * 1000) - wait_start_v1939
            log("PLAYBACK_RETURN_INFO_COVER_WAIT_V1939 token=%s pending=1 ready=%s waited_ms=%d max_ms=%d" % (
                token, "1" if info_ready_v1939 else "0", info_wait_ms_v1939, max_info_wait_ms_v1939
            ), xbmc.LOGINFO)
        else:
            xbmc.sleep(home_cover_prime_ms)

        # v2125: readiness is a logical commit boundary; Kodi still needs a few
        # frames to bind the final labels/textures.  Hold black briefly so the
        # first revealed frame is a complete fanart+metadata surface.
        if return_surface_settle_hold_ms_v2125 > 0:
            xbmc.sleep(return_surface_settle_hold_ms_v2125)
            log("PLAYBACK_RETURN_SURFACE_SETTLE_HOLD_V2125 token=%s hold_ms=%d inline_pending=%s info_ready=%s" % (
                token, return_surface_settle_hold_ms_v2125,
                "1" if inline_return_pending_v1939 else "0",
                "1" if info_ready_v1939 else "0"
            ), xbmc.LOGINFO)

        _pkm_close_return_video_fade_overlay_v1557(overlay, token=token)
        overlay = None

        # Clear only after the restored Info surface is ready (or the bounded
        # fallback timeout expires), so neither Home nor a blank frame can flash.
        _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
        log("PLAYBACK_RETURN_VIDEO_FAST_DONE_V1944 source=%s token=%s settled=%s inline_pending=%s info_ready=%s info_wait_ms=%d home_cover_fadeout_ms=%d" % (
            source, token, "1" if settled else "0",
            "1" if inline_return_pending_v1939 else "0",
            "1" if info_ready_v1939 else "0",
            info_wait_ms_v1939, home_fadeout_ms
        ), xbmc.LOGINFO)
        xbmc.sleep(home_fadeout_ms)
        return True
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_FAILED_V1557 source=%s token=%s\n%s" % (source, token, traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass
        try:
            if overlay:
                overlay.close()
        except Exception:
            pass
        try:
            xbmc.executebuiltin("PlayerControl(Stop)")
        except Exception:
            pass
        _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
        return False


def _parse(argv):
    out = {}
    for a in argv[1:]:
        for part in str(a).lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                out[k] = v
    return out


if __name__ == "__main__":
    pkm_playback_return_fade_stop(_parse(sys.argv))
