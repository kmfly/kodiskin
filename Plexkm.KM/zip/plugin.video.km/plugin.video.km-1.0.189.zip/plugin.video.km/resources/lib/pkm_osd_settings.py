# -*- coding: utf-8 -*-
"""R89: Plex-style centered settings popup for the video OSD.

The OSD now shows only the progress bar plus a subtitle icon and a gear.  The
gear opens this small popup; each row launches the existing PKM dialog/action
(audio, video, stream info, screen mode, network status).  No playback or
seek logic lives here.
"""
from __future__ import absolute_import, unicode_literals

import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_osd_settings_r89.xml"
LIST_ID = 200  # 5-row panel; 4-row panel uses 201
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

_BASE = "special://home/addons/plugin.video.km/"
ROWS = (
    ("audio", "오디오", "RunScript(%sdefault.py,action=audio_select)" % _BASE, False),
    ("video", "비디오", "RunScript(%sdefault.py,action=video_select)" % _BASE, False),
    ("info", "스트림 정보", "RunScript(%sdefault.py,action=video_stream_info)" % _BASE, False),
    ("mode", "화면 모드", "RunScript(%sresources/lib/pkm_video_mode_cycle_entry.py)" % _BASE, False),
    ("network", "네트워크 상태", "RunScript(%sresources/lib/pkm_network_health_entry.py)" % _BASE, True),
)


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][osd_settings] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _set_osd_child_dialog(active):
    """Same hold the audio/video dialogs use so the OSD does not auto-close."""
    try:
        home = xbmcgui.Window(10000)
        if active:
            home.setProperty("PlexKM.PlayerOSD.ChildDialogActive", "1")
            home.setProperty("PlexKM.PlayerOSD.AutoCloseCancelled", "1")
            home.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
            home.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
        else:
            home.clearProperty("PlexKM.PlayerOSD.ChildDialogActive")
    except Exception:
        pass


def _visible_rows():
    try:
        net = xbmc.getCondVisibility("String.IsEqual(Window(home).Property(PlexKM.Network.Active),1)")
    except Exception:
        net = False
    return [r for r in ROWS if (not r[3]) or net]


class PKMOsdSettingsWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self.rows = _visible_rows()
        self.selected = ""
        self.list_id = 200 if len(self.rows) == 5 else 201

    def onInit(self):
        try:
            self.setProperty("PlexKM.OsdSettings.Rows", str(len(self.rows)))
            ctrl = self.getControl(self.list_id)
            ctrl.reset()
            items = []
            for key, label, _cmd, _opt in self.rows:
                li = xbmcgui.ListItem(label)
                li.setProperty("action", key)
                items.append(li)
            ctrl.addItems(items)
            ctrl.selectItem(0)
            self.setFocusId(self.list_id)
        except Exception:
            _log("init_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def onClick(self, control_id):
        if control_id != self.list_id:
            return
        try:
            item = self.getControl(self.list_id).getSelectedItem()
            self.selected = item.getProperty("action") if item else ""
        except Exception:
            self.selected = ""
        self.close()

    def onAction(self, action):
        try:
            if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                self.selected = ""
                self.close()
        except Exception:
            pass


def open_osd_settings():
    window = None
    chosen = ""
    try:
        if not xbmc.Player().isPlayingVideo():
            return False
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        _set_osd_child_dialog(True)
        window = PKMOsdSettingsWindow(XML_NAME, addon_path, "Default", "1080i")
        window.doModal()
        chosen = window.selected
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
    finally:
        try:
            if window is not None:
                del window
        except Exception:
            pass
        _set_osd_child_dialog(False)
    if chosen:
        for key, _label, cmd, _opt in ROWS:
            if key == chosen:
                _log("row_selected key=%s" % key)
                xbmc.executebuiltin(cmd)
                break
    return True
