# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""On-screen keyboard model shared by PKM-style inline search panels (R79).

Same keys, pages and Hangul composition as the PKM Home inline search
(plexkm_home_window: _SEARCH_KEYS_*, _search_recompose_query), without any
Kodi dependency so any window can drive it:

    kb = SearchKeyboard()
    kb.keys()            -> labels for the current page
    kb.press("ㄱ")       -> returns "text" | "page" | "done" | ""
    kb.query             -> composed text
"""

KEYS_KO_NORMAL = [
    "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ",
    "ㅅ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ",
    "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ",
    "ㅔ", "ㅕ", "ㅗ", "ㅛ", "ㅜ", "ㅠ",
    "ㅡ", "ㅣ", "영문", "숫자", "Del", "Space",
    "Clear", "Shift", "완료", "기호",
]
KEYS_KO_SHIFT = [
    "ㄲ", "ㄸ", "ㅃ", "ㅆ", "ㅉ", "ㅒ",
    "ㅖ", "ㅘ", "ㅙ", "ㅚ", "ㅝ", "ㅞ",
    "ㅟ", "ㅢ", "ㄳ", "ㄵ", "ㄶ", "ㄺ",
    "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ",
    "ㅄ", "기본", "영문", "숫자", "Del", "Space",
    "Clear", "Shift", "완료", "기호",
]
KEYS = {
    "EN": list("ABCDEFGHIJKLMNOPQRSTUVWX") + ["Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                                              "Del", "Space", "Clear", "Shift", "완료", "한글", "숫자", "기호"],
    "NUM": list("1234567890") + ["-", ".", ":", "/", "(", ")", "Del", "Space", "Clear", "Shift", "완료",
                                 "한글", "영문", "기호"],
    "SYM": ["!", "?", "@", "#", "%", "&", "+", "=", "_", "'", '"', ",", ".", ":", "/", "-", "(", ")", "[", "]",
            "Del", "Space", "Clear", "Shift", "완료", "한글", "영문", "숫자"],
}
DISPLAY = {"Del": "Delete"}

KO_CONSONANTS = set("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
KO_VOWELS = set("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
CHO = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
JUNG = ["ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"]
JONG = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ",
        "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
VOWEL_COMBINE = {
    ("ㅗ", "ㅏ"): "ㅘ", ("ㅗ", "ㅐ"): "ㅙ", ("ㅗ", "ㅣ"): "ㅚ",
    ("ㅜ", "ㅓ"): "ㅝ", ("ㅜ", "ㅔ"): "ㅞ", ("ㅜ", "ㅣ"): "ㅟ",
    ("ㅡ", "ㅣ"): "ㅢ",
}
JONG_COMBINE = {
    ("ㄱ", "ㅅ"): "ㄳ", ("ㄴ", "ㅈ"): "ㄵ", ("ㄴ", "ㅎ"): "ㄶ",
    ("ㄹ", "ㄱ"): "ㄺ", ("ㄹ", "ㅁ"): "ㄻ", ("ㄹ", "ㅂ"): "ㄼ",
    ("ㄹ", "ㅅ"): "ㄽ", ("ㄹ", "ㅌ"): "ㄾ", ("ㄹ", "ㅍ"): "ㄿ",
    ("ㄹ", "ㅎ"): "ㅀ", ("ㅂ", "ㅅ"): "ㅄ",
}
JONG_SPLIT = dict((v, k) for k, v in JONG_COMBINE.items())
CHO_COMBINE = {
    ("ㄱ", "ㄱ"): "ㄲ", ("ㄷ", "ㄷ"): "ㄸ", ("ㅂ", "ㅂ"): "ㅃ",
    ("ㅅ", "ㅅ"): "ㅆ", ("ㅈ", "ㅈ"): "ㅉ",
}


def compose(cho, jung, jong=""):
    try:
        return chr(0xAC00 + (CHO.index(cho) * 21 + JUNG.index(jung)) * 28 + JONG.index(jong or ""))
    except Exception:
        return (cho or "") + (jung or "") + (jong or "")


def recompose(tokens):
    out = []
    state = {"L": None, "V": None, "T": None}

    def commit():
        L, V, T = state["L"], state["V"], state["T"]
        if L and V:
            out.append(compose(L, V, T or ""))
        elif L:
            out.append(L)
        elif V:
            out.append(V)
        state["L"] = state["V"] = state["T"] = None

    for ch in tokens:
        ch = ch or ""
        L, V, T = state["L"], state["V"], state["T"]
        if len(ch) != 1:
            commit()
            out.append(ch)
            continue
        if ch in KO_CONSONANTS:
            if L is None:
                state["L"] = ch
            elif V is None:
                combined = CHO_COMBINE.get((L, ch))
                if combined:
                    state["L"] = combined
                else:
                    out.append(L)
                    state["L"] = ch
            elif T is None and ch in JONG:
                state["T"] = ch
            elif T is not None:
                combined = JONG_COMBINE.get((T, ch))
                if combined:
                    state["T"] = combined
                else:
                    commit()
                    state["L"] = ch
            else:
                commit()
                state["L"] = ch
        elif ch in KO_VOWELS:
            if L is None:
                if V is None:
                    state["V"] = ch
                else:
                    combined = VOWEL_COMBINE.get((V, ch))
                    if combined:
                        state["V"] = combined
                    else:
                        commit()
                        state["V"] = ch
            elif V is None:
                state["V"] = ch
            elif T is None:
                combined = VOWEL_COMBINE.get((V, ch))
                if combined:
                    state["V"] = combined
                else:
                    commit()
                    state["V"] = ch
            else:
                # a final consonant followed by a vowel starts the next syllable
                if T in JONG_SPLIT:
                    left_final, next_initial = JONG_SPLIT[T]
                    out.append(compose(L, V, left_final))
                else:
                    next_initial = T
                    out.append(compose(L, V, ""))
                state["L"], state["V"], state["T"] = next_initial, ch, None
        else:
            commit()
            out.append(ch)
    commit()
    return "".join(out)


class SearchKeyboard(object):

    def __init__(self):
        self.mode = "KO"
        self.shift = False
        self.tokens = []
        self.query = ""

    def keys(self):
        if self.mode == "KO":
            return KEYS_KO_SHIFT if self.shift else KEYS_KO_NORMAL
        return KEYS.get(self.mode, [])

    @staticmethod
    def label(key):
        return DISPLAY.get(key, key)

    def set_text(self, text):
        self.tokens = list(text or "")
        self.query = recompose(self.tokens)

    def press(self, key):
        """Apply one key.  Returns 'text' when the query changed, 'page' when
        the key page changed, 'done' for 완료, '' otherwise."""
        if key == "한글":
            self.mode, self.shift = "KO", False
            return "page"
        if key == "영문":
            self.mode, self.shift = "EN", False
            return "page"
        if key == "숫자":
            self.mode, self.shift = "NUM", False
            return "page"
        if key == "기호":
            self.mode, self.shift = "SYM", False
            return "page"
        if key == "Shift":
            if self.mode == "KO":
                self.shift = True
                return "page"
            return ""
        if key == "기본":
            self.shift = False
            return "page"
        if key == "완료":
            return "done"
        if key == "Space":
            self.tokens.append(" ")
        elif key == "Del":
            if self.tokens:
                self.tokens.pop()
            else:
                self.query = self.query[:-1]
                return "text"
        elif key == "Clear":
            self.tokens = []
        else:
            self.tokens.append(key.lower() if self.mode == "EN" else key)
        self.query = recompose(self.tokens)
        return "text"
