# -*- coding: utf-8 -*-
"""PKM home window part (R73): 섹션 추천 위젯/카테고리.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartSectionR73
    def _section_rows_signature_v1620(self, rows_cache):
        try:
            parts = []
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = str(entry.get("row_id") or entry.get("row_title") or "")
                row = entry.get("row")
                try:
                    values = tuple(row or ())
                    rk = str(values[0] if values else "")
                    title = str(values[1] if len(values) > 1 else "")
                except Exception:
                    rk = ""
                    title = ""
                parts.append("%s:%s:%s" % (rid, rk, title))
            return hashlib.sha1("\n".join(parts).encode("utf-8", "ignore")).hexdigest() if parts else ""
        except Exception:
            return ""

    def _section_reuse_ready_bank_v1620(self, cache_key, scene, rows_cache, reason=""):
        """Flip to an already complete bank under the same A/B serialization lock."""
        lock = getattr(self, "_section_render_lock_v1620", None)
        if lock is None:
            self._section_render_lock_v1620 = threading.RLock()
            lock = self._section_render_lock_v1620
        with lock:
            return self._section_reuse_ready_bank_locked_v1620(cache_key, scene, rows_cache, reason=reason)

    def _section_reuse_ready_bank_locked_v1620(self, cache_key, scene, rows_cache, reason=""):
        """Flip to a bank that already contains the completed scene: no rebuild."""
        try:
            if not isinstance(scene, dict) or not rows_cache:
                return 0
            bank = self._section_ready_bank_for_scene_v1620(cache_key)
            if not bank:
                return 0
            # v2385: there is no hidden physical inner row stack to reset.
            # Each bank is a native grouplist; focusposition=0 makes Kodi restore
            # the visible offset when focus enters the published row.
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
            swap_token = self._section_swap_guard_begin_v1615(bank, reason="ready_bank_v1620:%s" % (reason or ""))
            ok = self._publish_section_scene_atomic_v1619(
                bank, cache_key, scene.get("title") or "", scene.get("count") or "추천",
                scene.get("meta"), reason="ready_bank_v1620:%s" % (reason or "")
            )
            if not ok:
                return 0
            self.wall_total = len(rows_cache or [])
            self.wall_offset = len(rows_cache or [])
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._section_visible_row_controls = [
                cid for cid in self._section_bank_row_ids_v1612(bank)
                if self.getControl(cid).size() > 0
            ]
            self._section_swap_guard_clear_later_v1615(
                swap_token, reason="ready_bank_v1620:%s" % (reason or ""), delay_ms=80
            )
            _log("SECTION_SCENE_READY_BANK_REUSE_V1620 key=%s bank=%s rows=%d reason=%s spinner=0 wait_ms=0" % (
                cache_key, bank, len(rows_cache or []), reason or ""
            ))
            return len(rows_cache or [])
        except Exception:
            _log("SECTION_SCENE_READY_BANK_REUSE_FAILED_V1620 key=%s reason=%s err=%s" % (
                cache_key or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0

    def _section_delayed_busy_arm_v2475(self, key, token, reason=""):
        """Promote the shared sidebar spinner only after a real 1500ms wait.

        pkm_global_busy's process default is intentionally bypassed here because
        V2482 gives PKM scene/page transitions one meaningful threshold; V2536 gives sidebar section navigation 1500ms.  Section
        navigation keeps its logical A/B gate from focus until actual visible
        commit; this helper only adds the shared ring if that exact transaction
        is still pending after 1500ms.
        """
        try:
            key = str(key or "")
            token = str(token or "")
            if not key or not token:
                return False
            # V2601 UHD native-first: never cover sidebar browsing with a spinner
            # on Android/U+ STBs. Kodi XML focus stays responsive and the previous
            # completed scene remains visible until the target scene commits.
            # A spinner here is cosmetic only and competes with the weak renderer.
            # R131: the same central spinner policy applies on Android.
            # It remains token-scoped and is cancelled on a completed section commit.
            delay_ms_v2475 = 1500
            # Anchor the threshold to the user's sidebar focus, not to the later
            # point where Python happened to enter the render path.
            remaining_ms_v2475 = delay_ms_v2475
            anchor_v2479 = "sidebar_focus"
            try:
                action_key_v2479 = str(getattr(self, "_section_action_anchor_key_v2479", "") or "")
                action_started_v2479 = int(getattr(self, "_section_action_anchor_started_v2479", 0) or 0)
                elapsed_action_v2479 = max(0, self._now_ms() - action_started_v2479) if action_started_v2479 > 0 else 0
                if action_key_v2479 == key and action_started_v2479 > 0 and elapsed_action_v2479 < 5000:
                    remaining_ms_v2475 = max(0, delay_ms_v2475 - elapsed_action_v2479)
                    anchor_v2479 = "tab_action"
                else:
                    focus_started_v2475 = int(getattr(self, "_sidebar_ui_select_started_v1650", 0) or 0)
                    focus_sid_v2475 = str(getattr(self, "_sidebar_ui_select_section_v1650", "") or "")
                    key_sid_v2475 = key.split(":", 1)[1] if key.startswith("recommend:") else key
                    elapsed_focus_v2475 = max(0, self._now_ms() - focus_started_v2475) if focus_started_v2475 > 0 else 0
                    if focus_started_v2475 > 0 and focus_sid_v2475 == key_sid_v2475 and elapsed_focus_v2475 < 5000:
                        remaining_ms_v2475 = max(0, delay_ms_v2475 - elapsed_focus_v2475)
            except Exception:
                remaining_ms_v2475 = delay_ms_v2475
                anchor_v2479 = "render_start_fallback"
            _log("SECTION_DELAYED_SPINNER_ANCHOR_V2594 key=%s anchor=%s threshold_ms=%d remaining_ms=%d platform_android=%d input_block=0" % (
                key, anchor_v2479, delay_ms_v2475, remaining_ms_v2475, 1 if self._is_android_v2591() else 0
            ))

            def _promote_v2475():
                monitor = xbmc.Monitor()
                if remaining_ms_v2475 > 0 and monitor.waitForAbort(remaining_ms_v2475 / 1000.0):
                    return
                state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
                if state_lock is None:
                    return
                busy_token = ""
                with state_lock:
                    if token != str(getattr(self, "_section_first_visit_gate_token_v1620", "") or ""):
                        return
                    if key != str(getattr(self, "_section_first_visit_gate_key_v1620", "") or ""):
                        return
                    if key != str(getattr(self, "active_section_id", "") or ""):
                        return
                    busy_map = getattr(self, "_section_global_busy_v1883", None)
                    if not isinstance(busy_map, dict):
                        busy_map = {}
                        self._section_global_busy_v1883 = busy_map
                    if str(busy_map.get(token) or ""):
                        return
                    try:
                        busy_token = pkm_global_busy.begin(
                            reason="section_v2475:%s" % key,
                            scope="sidebar", owner=key, replace_scope=True
                        )
                    except Exception:
                        busy_token = ""
                    if busy_token:
                        busy_map[token] = busy_token
                if not busy_token:
                    return
                # Revalidate immediately before promotion.  A visible/cancel
                # commit may have won the race after begin() returned.
                with state_lock:
                    valid = bool(
                        token == str(getattr(self, "_section_first_visit_gate_token_v1620", "") or "")
                        and key == str(getattr(self, "_section_first_visit_gate_key_v1620", "") or "")
                        and key == str(getattr(self, "active_section_id", "") or "")
                    )
                    if not valid:
                        try:
                            (getattr(self, "_section_global_busy_v1883", {}) or {}).pop(token, None)
                        except Exception:
                            pass
                if not valid:
                    try:
                        pkm_global_busy.end(busy_token, reason="section_v2475_race_cancel")
                    except Exception:
                        pass
                    return
                try:
                    pkm_global_busy.promote(busy_token, reason="section_%dms_v2594:%s" % (delay_ms_v2475, key))
                except Exception:
                    pass
                _log("SECTION_DELAYED_SPINNER_PROMOTE_V2594 key=%s token=%s threshold_ms=%d remaining_at_arm_ms=%d previous_scene_hold=1 actual_visible_pending=1 input_block=0" % (
                    key, token, delay_ms_v2475, remaining_ms_v2475
                ))

            _PKMHomeThreadV2151(
                target=_promote_v2475,
                name="PKMSectionSpinnerV2594",
                daemon=True,
            ).start()
            return True
        except Exception:
            return False

    def _section_visible_finish_v2475(self, cache_key, reason=""):
        """Release the section spinner only after the committed target got a GUI frame."""
        try:
            key = str(cache_key or "")
            if not key:
                return False
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                return False
            with state_lock:
                token = str(getattr(self, "_section_first_visit_gate_token_v1620", "") or "")
                if not token or key != str(getattr(self, "_section_first_visit_gate_key_v1620", "") or ""):
                    return False
            # _commit_section_recommend_visible() already crossed one GUI frame
            # before calling here.  End only after its actual-visible marker.
            busy_token = ""
            with state_lock:
                if token != str(getattr(self, "_section_first_visit_gate_token_v1620", "") or ""):
                    return False
                try:
                    busy_token = (getattr(self, "_section_global_busy_v1883", {}) or {}).pop(token, "")
                except Exception:
                    busy_token = ""
            try:
                pkm_global_busy.end(busy_token, reason="section_actual_visible_v2475:%s" % (reason or ""))
            except Exception:
                pass
            select_started = int(getattr(self, "_sidebar_ui_select_started_v1650", 0) or 0)
            elapsed = max(0, self._now_ms() - select_started) if select_started > 0 else 0
            _log("SECTION_ACTUAL_VISIBLE_BUSY_RELEASE_V2475 key=%s token=%s elapsed_focus_ms=%d spinner_token=%d visible_frame_already_waited=1 reason=%s" % (
                key, token, elapsed, 1 if busy_token else 0, reason or ""
            ))
            try:
                if str(getattr(self, "_section_action_anchor_key_v2479", "") or "") == key:
                    self._section_action_anchor_key_v2479 = ""
                    self._section_action_anchor_started_v2479 = 0
            except Exception:
                pass
            return self._section_first_visit_gate_release_later_v1620(
                key, token, reason="actual_visible_v2475:%s" % (reason or ""), delay_ms=0
            )
        except Exception:
            return False

    def _section_first_visit_gate_begin_v1620(self, cache_key, reason="", force_ui_wait_v1796=False, force_delayed_spinner_v2474=False):
        """Create a cold-section gate token; use the shared global spinner only after 1000ms.

        v1622 keeps the currently completed 16:9 scene visible while the target
        is prepared. If the target UI is published before the global 1000ms delay expires,
        the spinner is never exposed. Completed/revisited scenes still bypass the
        gate entirely.
        """
        try:
            key = str(cache_key or "")
            if not key:
                return ""
            # v1883: selecting a different target must release the previous
            # operation token even when this new target is an instant cache hit.
            # Otherwise a superseded delayed worker can expose a global spinner
            # after the ready scene is already visible.
            try:
                _old_gate_key_v1883 = str(getattr(self, "_section_first_visit_gate_key_v1620", "") or "")
                _old_gate_token_v1883 = str(getattr(self, "_section_first_visit_gate_token_v1620", "") or "")
                if _old_gate_token_v1883 and _old_gate_key_v1883 and _old_gate_key_v1883 != key:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="target_changed_before_gate_v1883", only_if_key=_old_gate_key_v1883
                    )
            except Exception:
                pass
            # v1652: after startup, a genuinely cold sidebar target may still need
            # substantial composition time. Keep the previous completed scene visible,
            # register one global busy token, and publish the target atomically.
            # Completed scenes never show the gate again during this Kodi run.
            # v1796/v1883: the readiness transaction follows the visible transition, not whether a
            # scene/section was visited earlier.  Callers that already proved an
            # immediately reusable ready bank still bypass the gate.  When that
            # ready-bank reuse failed and a hidden bank must be rebuilt, force the
            # UI wait gate even for startup-prebuilt or previously visited sections.
            if not force_ui_wait_v1796 and not force_delayed_spinner_v2474:
                if self._section_scene_get_v1620(key):
                    return ""
                # v1635: visited state is independent of row/bank cache lifetime.
                if key in getattr(self, "_section_visited_keys_v1635", set()):
                    _log("SECTION_GATE_BYPASS_V1635 key=%s reason=visited_registry previous_scene_visible=1 spinner=0" % key)
                    return ""
            else:
                scene_v1928 = self._section_scene_get_v1620(key)
                visited_v1928 = key in getattr(self, "_section_visited_keys_v1635", set())
                # v2474: a caller that has already proved there is no immediately
                # reusable native bank must obey the canonical delayed-spinner
                # policy even when persistent row data or a prior visited bit exists.
                # Data-ready is not render-ready. The previous completed surface is
                # retained until the hidden target is complete; the global broker
                # only paints a spinner if this rebuild crosses its delay threshold.
                if visited_v1928 and not force_delayed_spinner_v2474:
                    _log("SECTION_REVISIT_HIDDEN_BANK_NO_SPINNER_V1928 key=%s reason=%s scene=%d visited=1 previous_scene_visible=1 atomic_swap=1" % (
                        key, reason or "", 1 if scene_v1928 else 0
                    ))
                    return ""
                _log("SECTION_UI_WAIT_GATE_FORCE_V2474 key=%s reason=%s scene=%d visited=%d delayed_spinner=%d" % (
                    key, reason or "", 1 if scene_v1928 else 0,
                    1 if visited_v1928 else 0, 1 if force_delayed_spinner_v2474 else 0
                ))
            # After any real playback return, sidebar navigation is always
            # stale-while-compose: preserve the current completed scene and
            # atomically swap only when the target is ready. This is a session
            # state machine, not a cooldown/timing exception.
            try:
                post_playback_v1635 = xbmcgui.Window(10000).getProperty("PlexKM.Home.PostPlaybackSectionNoSpinnerV1635") == "1"
            except Exception:
                post_playback_v1635 = False
            scene_ready_v1839 = bool(self._section_scene_get_v1620(key))
            visited_v1839 = key in getattr(self, "_section_visited_keys_v1635", set())
            # v1839: the post-playback policy may preserve an already completed
            # scene, but it must never turn a genuinely cold library into a fast
            # revisit. Newly selected libraries can be added after playback and
            # have startup rows without ever having published a UI scene.
            # v1841: force_ui_wait means ready-bank reuse already failed and a
            # hidden bank is really being rebuilt. A persisted scene/visited bit
            # is not an immediately displayable bank, so post-playback cannot
            # suppress the shared global wait transaction in this path.
            if (post_playback_v1635 and not force_ui_wait_v1796 and not force_delayed_spinner_v2474
                    and (scene_ready_v1839 or visited_v1839)):
                # Clear both property scopes and the in-memory gate token. A gate
                # armed before playback must not leak into the returned Home.
                self._section_first_visit_gate_cancel_v1620(
                    reason="post_playback_ready_bypass_v1883"
                )
                _log("SECTION_GATE_BYPASS_V1635 key=%s reason=post_playback_session previous_scene_visible=1 atomic_commit=1 spinner=0" % key)
                return ""
            if post_playback_v1635:
                _log("SECTION_GATE_POST_PLAYBACK_COLD_OVERRIDE_V1839 key=%s scene=0 visited=0 action=arm_first_visit_gate" % key)
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                self._section_first_visit_gate_state_lock_v1622 = threading.RLock()
                state_lock = self._section_first_visit_gate_state_lock_v1622
            prior_busy_token_v1883 = ""
            with state_lock:
                if (str(self._section_first_visit_gate_key_v1620 or "") == key
                        and str(self._section_first_visit_gate_token_v1620 or "")):
                    return str(self._section_first_visit_gate_token_v1620 or "")
                prior_gate_token_v1883 = str(self._section_first_visit_gate_token_v1620 or "")
                if prior_gate_token_v1883:
                    try:
                        prior_busy_token_v1883 = (getattr(self, "_section_global_busy_v1883", {}) or {}).pop(prior_gate_token_v1883, "")
                    except Exception:
                        prior_busy_token_v1883 = ""
                token = "%s-%d" % (key, int(time.time() * 1000))
                self._section_first_visit_gate_token_v1620 = token
                self._section_first_visit_gate_key_v1620 = key
                self._section_first_visit_gate_release_running_v1620 = False
                self._section_first_visit_gate_visible_token_v1622 = ""
                self._section_first_visit_gate_published_token_v1795 = ""
                delay_ms = 1000
                # v2475: do not create the shared broker token yet.  Its process
                # default is 180ms for other PKM surfaces; sidebar owns a strict
                # 1000ms threshold and promotes the broker only if this exact
                # focus->visible transaction is still pending then.
                self._section_delayed_busy_arm_v2475(key, token, reason=reason or "")
            if prior_busy_token_v1883:
                try:
                    pkm_global_busy.end(prior_busy_token_v1883, reason="section_gate_superseded")
                except Exception:
                    pass

            # v1883: publish the logical readiness gate immediately. The gate
            # blocks navigation into an unpublished A/B bank, but it does not
            # paint or time a spinner. The one global broker owns that policy.
            try:
                with state_lock:
                    self._section_first_visit_gate_visible_token_v1622 = token
                    for target in (self, xbmcgui.Window(10000)):
                        target.setProperty("PlexKM.Section.FirstVisitGateV1620", "1")
                        target.setProperty("PlexKM.Section.FirstVisitGateKeyV1620", key)
                        target.setProperty("PlexKM.Section.FirstVisitGateTokenV1620", token)
            except Exception:
                pass
            _log("SECTION_FIRST_VISIT_GATE_ARM_V2475 key=%s token=%s reason=%s logical_gate=1 global_busy_deferred=1 global_delay_ms=%d forced_render_wait=%d" % (
                key, token, reason or "", 350,
                1 if force_delayed_spinner_v2474 else 0
            ))

            # v1883: readiness ownership has one safety timeout only. It does
            # not own a spinner delay, status overlay, or visual timer. A late
            # worker is blocked by the exact token check in the A/B render path.
            def _watchdog_v1794():
                timeout_ms = max(1000, int(getattr(self, "_section_first_visit_timeout_ms_v1794", 15000) or 15000))
                started_ms = int(time.time() * 1000)
                monitor = xbmc.Monitor()
                while not monitor.abortRequested():
                    if monitor.waitForAbort(0.1):
                        return
                    elapsed = int(time.time() * 1000) - started_ms
                    with state_lock:
                        if token != str(self._section_first_visit_gate_token_v1620 or ""):
                            return
                        if key != str(self._section_first_visit_gate_key_v1620 or ""):
                            return
                        if key != str(getattr(self, "active_section_id", "") or ""):
                            return
                        if token == str(getattr(self, "_section_first_visit_gate_published_token_v1795", "") or ""):
                            return
                        if not force_ui_wait_v1796 and self._section_scene_get_v1620(key):
                            return
                    if elapsed >= timeout_ms:
                        try:
                            self._section_first_visit_gate_cancel_v1620(
                                reason="timeout_v1883", only_if_key=key
                            )
                        except Exception:
                            pass
                        _log("SECTION_FIRST_VISIT_TIMEOUT_FALLBACK_V1883 key=%s token=%s elapsed_ms=%d previous_scene_kept=1 unpublished_bank_discard=1" % (
                            key, token, elapsed
                        ), xbmc.LOGWARNING)
                        return

            _PKMHomeThreadV2151(
                target=_watchdog_v1794,
                name="PlexKMSectionGateWatchdogV1794",
                daemon=True,
            ).start()
            return token
        except Exception:
            return ""

    def _section_first_visit_mark_published_v1795(self, cache_key, token, reason=""):
        """Record the exact moment the target A/B bank becomes visible.

        This is intentionally independent from scene-cache persistence and all
        post-publish work. Once the requested widgets are on screen, a delayed
        spinner must not appear and an already visible spinner is removed.
        """
        busy_token_v1883 = ""
        try:
            key = str(cache_key or "")
            token = str(token or "")
            if not key or not token:
                return False
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                self._section_first_visit_gate_state_lock_v1622 = threading.RLock()
                state_lock = self._section_first_visit_gate_state_lock_v1622
            with state_lock:
                if token != str(self._section_first_visit_gate_token_v1620 or ""):
                    return False
                if key != str(self._section_first_visit_gate_key_v1620 or ""):
                    return False
                self._section_first_visit_gate_published_token_v1795 = token
                logical_gate_was_active = bool(
                    token == str(getattr(self, "_section_first_visit_gate_visible_token_v1622", "") or "")
                )
                self._section_first_visit_gate_visible_token_v1622 = ""
                for target in (self, xbmcgui.Window(10000)):
                    try:
                        target.clearProperty("PlexKM.Section.FirstVisitGateV1620")
                        target.clearProperty("PlexKM.Section.FirstVisitGateKeyV1620")
                        target.clearProperty("PlexKM.Section.FirstVisitGateTokenV1620")
                    except Exception:
                        pass
            # v2475: A/B property/bank publication is not yet proof that Kodi
            # rendered the target.  Keep the delayed broker transaction alive
            # until _commit_section_recommend_visible() crosses one GUI frame.
            _log("SECTION_UI_PUBLISHED_V2475 key=%s token=%s reason=%s logical_gate_cleared=%d global_busy_released=0 actual_visible_pending=1" % (
                key, token, reason or "", 1 if logical_gate_was_active else 0
            ))
            return True
        except Exception:
            return False

    def _section_first_visit_gate_cancel_v1620(self, reason="", only_if_key=""):
        busy_token_v1883 = ""
        try:
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                self._section_first_visit_gate_state_lock_v1622 = threading.RLock()
                state_lock = self._section_first_visit_gate_state_lock_v1622
            with state_lock:
                key = str(self._section_first_visit_gate_key_v1620 or "")
                if only_if_key and key and key != str(only_if_key or ""):
                    return False
                token = str(self._section_first_visit_gate_token_v1620 or "")
                logical_gate_active = bool(token and token == str(getattr(self, "_section_first_visit_gate_visible_token_v1622", "") or ""))
                self._section_first_visit_gate_token_v1620 = ""
                self._section_first_visit_gate_key_v1620 = ""
                self._section_first_visit_gate_release_running_v1620 = False
                self._section_first_visit_gate_visible_token_v1622 = ""
                self._section_first_visit_gate_published_token_v1795 = ""
                win = xbmcgui.Window(10000)
                for target in (self, win):
                    try:
                        target.clearProperty("PlexKM.Section.FirstVisitGateV1620")
                        target.clearProperty("PlexKM.Section.FirstVisitGateKeyV1620")
                        target.clearProperty("PlexKM.Section.FirstVisitGateTokenV1620")
                    except Exception:
                        pass
                try:
                    busy_token_v1883 = (getattr(self, "_section_global_busy_v1883", {}) or {}).pop(token, "")
                except Exception:
                    busy_token_v1883 = ""
            try:
                pkm_global_busy.end(busy_token_v1883, reason="section_cancel:%s" % (reason or ""))
            except Exception:
                pass
            if token or key:
                _log("SECTION_FIRST_VISIT_GATE_CANCEL_V1883 key=%s token=%s reason=%s logical_gate_was_active=%d global_busy_released=1" % (
                    key, token, reason or "", 1 if logical_gate_active else 0
                ))
            return True
        except Exception:
            return False

    def _section_first_visit_gate_release_later_v1620(self, cache_key, token, reason="", delay_ms=0):
        """Clear completed section transaction ownership immediately.

        The A/B publish already cleared the logical navigation gate and released
        the global busy token.  No post-commit sleep or feature-specific spinner
        timer is required; this method only retires the matching ownership token.
        """
        try:
            key = str(cache_key or "")
            token = str(token or self._section_first_visit_gate_token_v1620 or "")
            if not key or not token:
                return False
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                self._section_first_visit_gate_state_lock_v1622 = threading.RLock()
                state_lock = self._section_first_visit_gate_state_lock_v1622
            with state_lock:
                if token != str(self._section_first_visit_gate_token_v1620 or ""):
                    return False
                if key != str(self._section_first_visit_gate_key_v1620 or ""):
                    return False
                if key != str(getattr(self, "active_section_id", "") or ""):
                    pass_target_changed = True
                else:
                    pass_target_changed = False
                    self._section_first_visit_gate_token_v1620 = ""
                    self._section_first_visit_gate_key_v1620 = ""
                    self._section_first_visit_gate_visible_token_v1622 = ""
                    self._section_first_visit_gate_release_running_v1620 = False
            if pass_target_changed:
                return self._section_first_visit_gate_cancel_v1620(
                    reason="target_changed:%s" % (reason or ""), only_if_key=key
                )
            _log("SECTION_FIRST_VISIT_GATE_RELEASE_V1883 key=%s token=%s reason=%s settle_ms=0 completed_scene=1" % (
                key, token, reason or ""
            ))
            return True
        except Exception:
            self._section_first_visit_gate_release_running_v1620 = False
            return False

    def _section_gate_token_valid_v1794(self, cache_key, token):
        """Return True only while the exact cold-section build still owns publication."""
        if not token:
            return True
        try:
            state_lock = getattr(self, "_section_first_visit_gate_state_lock_v1622", None)
            if state_lock is None:
                return False
            with state_lock:
                return bool(
                    str(token or "") == str(self._section_first_visit_gate_token_v1620 or "")
                    and str(cache_key or "") == str(self._section_first_visit_gate_key_v1620 or "")
                    and str(cache_key or "") == str(getattr(self, "active_section_id", "") or "")
                )
        except Exception:
            return False

    def _section_index_key_for_title(self, title):
        """v1489: Return Plex-style right-index key from the visible movie title.

        English titles use A-Z.  Numeric/symbol-leading titles use #.
        Korean titles use the real first Hangul syllable of the movie title,
        not 가나다/초성 buckets, matching the requested 월모드 behavior.
        """
        try:
            text = str(title or "").strip()
        except Exception:
            text = ""
        if not text:
            return "#"
        # Skip only wrapper/quote characters that Plex/Kodi often keeps around titles.
        # Do not skip # or digits; they intentionally map to the # bucket.
        skip = set(["'", '"', "`", "´", "‘", "’", "“", "”", " ", "\t", "\r", "\n"])
        ch = ""
        for c in text:
            if c in skip:
                continue
            ch = c
            break
        if not ch:
            return "#"
        # R99: compact side index -> # / A (all Latin) / Hangul initial consonant (ㄱ..ㅎ, doubles merged)
        _cho_r99 = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
        _merge_r99 = {"ㄲ": "ㄱ", "ㄸ": "ㄷ", "ㅃ": "ㅂ", "ㅆ": "ㅅ", "ㅉ": "ㅈ"}
        try:
            code = ord(ch)
            if 0xAC00 <= code <= 0xD7A3:
                cho = _cho_r99[(code - 0xAC00) // 588]
                return _merge_r99.get(cho, cho)
            if 0x3130 <= code <= 0x318F:
                return _merge_r99.get(ch, ch)
        except Exception:
            pass
        try:
            up = ch.upper()
            if "A" <= up <= "Z":
                return "A"
        except Exception:
            pass
        try:
            # Accented Latin fallback: É -> E, Å -> A, etc.
            decomp = unicodedata.normalize("NFKD", ch)
            for c in decomp:
                up = c.upper()
                if "A" <= up <= "Z":
                    return "A"
        except Exception:
            pass
        try:
            if ch.isdigit():
                return "#"
        except Exception:
            pass
        # Other CJK or symbols. Keep non-symbol letters visible when possible;
        # otherwise group under #.
        return "#"

    # R107: every sort except 무작위 has a right index (see _section_index_bucket_r107).
    # R102: the right index follows the current sort.  Title sort keeps the
    # # A ㄱ..ㅎ index; date/year sorts get a year index (26, 25, ...) built
    # from the wall rows in the exact visible order.  Other sorts have no
    # meaningful buckets and hide the index.
    def _section_index_sort_now_r102(self):
        try:
            return (str(self._normalize_section_sort(getattr(self, "sort", "title")) or "title"),
                    str(self._normalize_sort_dir(getattr(self, "sort_dir", "asc")) or "asc"))
        except Exception:
            return ("title", "asc")

    def _section_index_year_key_r102(self, sort_key, year_value="", added_value=""):
        try:
            if sort_key == "added":
                ts = int(float(added_value or 0))
                if ts <= 0:
                    return "#"
                return time.strftime("%Y", time.localtime(ts))
            y = int(str(year_value or "0")[:4] or 0)
            return str(y) if y > 1800 else "#"
        except Exception:
            return "#"

    def _section_index_bucket_ctx_r107(self, section_id, sort_key):
        """R107: one-shot lookups needed by some buckets (provider scores)."""
        ctx = {}
        table = {"cine21": ("cine21_matches", "COALESCE(critic_rating,audience_rating,0)"),
                 "watcha": ("watcha_ratings", "COALESCE(watcha_rating,0)"),
                 "imdb": ("item_ratings", "COALESCE(score,rating,audience_rating,user_rating,0)")}.get(sort_key)
        if table:
            conn = None
            try:
                conn = _ensure_core().init_db()
                scores = {}
                for rk, sc in conn.execute("SELECT rating_key, MAX(%s) FROM %s GROUP BY rating_key" % (table[1], table[0])):
                    scores[str(rk)] = float(sc or 0.0)
                ctx["scores"] = scores
            except Exception:
                ctx["scores"] = {}
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
        return ctx

    def _section_index_bucket_r107(self, sort_key, rr, ctx):
        """R107: right-index bucket (key, label) for one wall row in sort order.

        Every sort gets an index like 최신순's years: ratings -> score band,
        progress -> percent band, unwatched/seasons -> counts, status -> 방영/종영,
        resolution -> 4K/FHD/HD/SD, bitrate -> Mbps band, 감상한 날짜 -> year.
        Unknown/empty values go to "-".  Buckets are contiguous because the wall
        is ordered by the same value."""
        def _meta():
            try:
                if len(rr) > 28 and rr[28]:
                    m = json.loads(rr[28]) if isinstance(rr[28], str) else dict(rr[28])
                    return m if isinstance(m, dict) else {}
            except Exception:
                pass
            return {}

        def _raw():
            try:
                if len(rr) > 27 and rr[27]:
                    d = json.loads(rr[27]) if isinstance(rr[27], str) else dict(rr[27])
                    return d if isinstance(d, dict) else {}
            except Exception:
                pass
            return {}

        def _num(v):
            try:
                return float(v or 0)
            except Exception:
                return 0.0

        def _year_of_ts(ts):
            ts = int(_num(ts))
            if ts <= 0:
                return ("-", "-")
            if ts > 19000000 and ts < 30000000:  # YYYYMMDD
                y = str(ts)[:4]
            else:
                y = time.strftime("%Y", time.localtime(ts))
            return (y, y[2:])
        try:
            if sort_key == "viewed":
                m = _meta()
                ts = m.get("latest_viewed_at") if m else None
                if not ts:
                    ts = rr[17] if len(rr) > 17 else 0
                return _year_of_ts(ts)
            if sort_key == "recent_air":
                # The UHD fast path orders 최근 방영순 by updated_at/added_at when the
                # episode aggregate is absent; bucket by the same value.
                return _year_of_ts(_meta().get("latest_air_date_num")
                                   or (rr[11] if len(rr) > 11 else 0)
                                   or (rr[10] if len(rr) > 10 else 0) or 0)
            if sort_key in ("tmdb", "imdb", "cine21"):
                if sort_key == "tmdb":
                    sc = _num(_meta().get("tmdb_rating"))
                else:
                    sc = _num((ctx.get("scores") or {}).get(str(rr[0])))
                if sc <= 0:
                    return ("-", "-")
                b = str(int(min(10.0, sc)))
                return (b, b)
            if sort_key == "watcha":
                sc = _num((ctx.get("scores") or {}).get(str(rr[0])))
                if sc <= 0:
                    return ("-", "-")
                b = int(min(5.0, sc) * 2) / 2.0
                lab = ("%d" % b) if b == int(b) else ("%.1f" % b)
                return (lab, lab)
            if sort_key == "progress":
                m = _meta()
                if m and ("progress_percent" in m) and (m.get("episode_count") or m.get("progress_percent")):
                    pct = int(_num(m.get("progress_percent")))
                else:
                    off = _num(rr[23] if len(rr) > 23 else 0)
                    dur = _num(rr[24] if len(rr) > 24 else 0) or _num(rr[9] if len(rr) > 9 else 0)
                    if _num(rr[16] if len(rr) > 16 else 0) > 0 and off <= 0:
                        pct = 100
                    elif dur > 0 and off > 0:
                        pct = int(off * 100.0 / dur)
                    else:
                        pct = 0
                if pct >= 100:
                    return ("100", "완")
                b = (max(0, pct) // 10) * 10
                return (str(b), str(b))
            if sort_key in ("unwatched", "seasons"):
                m = _meta()
                n = int(_num(m.get("unwatched_count") if sort_key == "unwatched" else m.get("season_count")))
                for lim, lab in ((100, "99+"), (50, "50+"), (20, "20+"), (10, "10+")):
                    if n >= lim:
                        return (lab, lab)
                return (str(max(0, n)), str(max(0, n)))
            if sort_key == "status":
                s = str(_meta().get("status") or _raw().get("status") or "").strip().lower()
                if s in ("continuing", "returning series", "returning", "in production", "planned", "airing"):
                    return ("on", "방영")
                if s in ("ended", "canceled", "cancelled"):
                    return ("end", "종영")
                return ("-", "-")
            if sort_key == "resolution":
                r = str(_raw().get("videoResolution") or "").strip().lower()
                if r in ("4k", "2160", "2160p", "uhd"):
                    return ("4k", "4K")
                if r in ("1080", "1080p", "fhd"):
                    return ("fhd", "FHD")
                if r in ("720", "720p", "hd"):
                    return ("hd", "HD")
                if r:
                    return ("sd", "SD")
                return ("-", "-")
            if sort_key == "bitrate":
                kb = _num(_raw().get("bitrate"))
                if kb <= 0:
                    return ("-", "-")
                mb = kb / 1000.0
                for lim, lab in ((40, "40+"), (30, "30"), (20, "20"), (15, "15"), (10, "10"), (5, "5")):
                    if mb >= lim:
                        return (lab, lab)
                return ("1", "<5")
        except Exception:
            pass
        return ("-", "-")

    def _section_index_rows_sorted_r102(self, section_id, sort_key, sort_dir, genre=None):
        """Year buckets in visible wall order: [{key, label, offset}]."""
        sid = str(section_id or "").strip()
        ck = (sid, sort_key, sort_dir, str(genre or ""))
        cache = getattr(self, "_section_index_sorted_cache_r102", None)
        if not isinstance(cache, dict):
            cache = {}
            self._section_index_sorted_cache_r102 = cache
        if ck in cache:
            return cache[ck]
        t0 = time.time()
        data_rows = list(self._query_library_wall_rows_v1870(
            sid, sort=sort_key, sort_dir=sort_dir, limit=0, offset=0,
            random_seed=self._wall_random_seed_v1644, genre=genre or None,
        ) or [])
        rows = []
        seen = set()
        bucket_map_r107 = {}
        ctx_r107 = self._section_index_bucket_ctx_r107(sid, sort_key)
        for idx, row in enumerate(data_rows):
            rr = tuple(row or ())
            if sort_key in ("added", "year", "release", "first_air"):
                key = self._section_index_year_key_r102(
                    sort_key, rr[7] if len(rr) > 7 else "", rr[10] if len(rr) > 10 else "")
                label = key[2:] if (len(key) == 4 and key.isdigit()) else key
            else:
                key, label = self._section_index_bucket_r107(sort_key, rr, ctx_r107)
            try:
                bucket_map_r107[str(rr[0])] = key
            except Exception:
                pass
            if key in seen:
                continue
            seen.add(key)
            rows.append({"key": key, "label": label, "offset": int(idx)})
        try:
            maps_r107 = getattr(self, "_section_index_bucket_maps_r107", None)
            if not isinstance(maps_r107, dict) or len(maps_r107) > 16:
                maps_r107 = {}
                self._section_index_bucket_maps_r107 = maps_r107
            maps_r107[ck] = bucket_map_r107
        except Exception:
            pass
        cache[ck] = rows
        _log("SECTION_INDEX_YEAR_BUILD_R102 section=%s sort=%s dir=%s keys=%d rows=%d elapsed_ms=%d" % (
            sid, sort_key, sort_dir, len(rows), len(data_rows), int((time.time() - t0) * 1000)))
        return rows

    def _section_index_current_rows_r102(self, section_id):
        sort_key, sort_dir = self._section_index_sort_now_r102()
        if sort_key == "title":
            return self._section_index_rows_for_section(section_id)
        if sort_key in _INDEX_SORTS_R107:
            return self._section_index_rows_sorted_r102(
                section_id, sort_key, sort_dir, getattr(self, "_active_genre_filter", "") or None)
        return []

    def _section_index_key_for_li_r102(self, li):
        sort_key, _d = self._section_index_sort_now_r102()
        if li is None:
            return ""
        if sort_key in ("added", "year", "release", "first_air"):
            return self._section_index_year_key_r102(
                sort_key, li.getProperty("PlexKM.Year") or "", li.getProperty("PlexKM.AddedAt") or "")
        if sort_key in _INDEX_SORTS_R107:
            # R107: rating/progress/... buckets come from the map built with the
            # index rows (same visible order, keyed by rating key).
            try:
                _sk, _sd = self._section_index_sort_now_r102()
                ck = (str(getattr(self, "active_section_id", "") or ""), _sk, _sd,
                      str(getattr(self, "_active_genre_filter", "") or ""))
                bmap = (getattr(self, "_section_index_bucket_maps_r107", {}) or {}).get(ck) or {}
                return str(bmap.get(str(li.getProperty("PlexKM.RatingKey") or "")) or "")
            except Exception:
                return ""
        return self._section_index_key_for_title(li.getProperty("PlexKM.Title") or li.getLabel() or "")

    def _section_index_rows_for_section(self, section_id):
        sid = str(section_id or "").strip()
        if not sid:
            return []
        cached = self._section_index_cache.get(sid)
        if cached is not None:
            return cached
        rows = []
        conn = None
        try:
            if self._is_tv_library_section_v1870(sid):
                # v1870: the visible TV wall is one row per show season. Build
                # the right-side title index from that same grouped sequence so
                # offsets never point into the hidden raw episode table.
                data_rows = list(self._query_library_wall_rows_v1870(
                    sid, sort="title", sort_dir="asc", limit=0, offset=0,
                    random_seed=self._wall_random_seed_v1644,
                    genre=None,
                ) or [])
                data = [(tuple(row)[4] if len(tuple(row)) > 4 else "", "") for row in data_rows]
                source_v1870 = "tv_season_folders"
            else:
                conn = _ensure_core().init_db()
                # v1492/v1494: The right index offset must be computed in the exact
                # visible order used by query_items_wall_light(title ASC).
                sql = (
                    "SELECT COALESCE(title,''), COALESCE(sort_title,title,'') "
                    "FROM items WHERE section_id=? "
                    "ORDER BY title COLLATE NOCASE ASC"
                )
                data = conn.execute(sql, (sid,)).fetchall()
                source_v1870 = "raw_items"
            seen = set()
            for idx, row in enumerate(data or []):
                try:
                    title = row[0] if len(row) > 0 else ""
                except Exception:
                    title = ""
                key = self._section_index_key_for_title(title)
                if key in seen:
                    continue
                seen.add(key)
                rows.append({"key": key, "label": key, "offset": int(idx)})
            # R99: fixed display order # A ㄱ..ㅎ (keys collected by first offset in title order)
            _order_r99 = ["#", "A"] + list("ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎ")
            rows.sort(key=lambda r: (_order_r99.index(r["key"]) if r["key"] in _order_r99 else 99, r["offset"]))
            self._section_index_cache[sid] = rows
            _log("SECTION_INDEX_BUILD_DATA_V1870 section=%s keys=%d total_rows=%d source=%s" % (
                sid, len(rows), len(data or []), source_v1870
            ))
        except Exception:
            _log("SECTION_INDEX_BUILD_DATA_FAILED_V1870 section=%s err=%s" % (
                sid, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            rows = []
            self._section_index_cache[sid] = rows
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
        return rows

    def _section_index_build_for_section(self, section_id, reason=""):
        try:
            sid = str(section_id or "").strip()
            ctrl = self.getControl(SECTION_INDEX_ID)
            ctrl.reset()
            rows = self._section_index_current_rows_r102(sid)
            for entry in rows:
                key = str(entry.get("key") or "#")
                li = xbmcgui.ListItem(label=str(entry.get("label") or key))
                li.setProperty("PlexKM.IndexKey", key)
                li.setProperty("PlexKM.IndexOffset", str(int(entry.get("offset", 0) or 0)))
                li.setProperty("PlexKM.IndexActive", "1" if key == self._section_index_active_key else "")
                ctrl.addItem(li)
            self._section_index_last_section_id = sid
            # R102: rows already follow the current sort (empty = no index).
            value = "1" if rows else ""
            self.setProperty("PlexKM.Section.IndexVisible", value)
            xbmcgui.Window(10000).setProperty("PlexKM.Section.IndexVisible", value)
            # v1494: keep focus on the wall, but allow the yellow current-key
            # indicator to sync/scroll once a wall item is focused.
            _log("SECTION_INDEX_BUILD_V1494 section=%s items=%d reason=%s wall_focus_sync_ready=1" % (sid, len(rows), reason or ""))
        except Exception:
            try:
                self.clearProperty("PlexKM.Section.IndexVisible")
                xbmcgui.Window(10000).clearProperty("PlexKM.Section.IndexVisible")
            except Exception:
                pass
            _log("SECTION_INDEX_BUILD_FAILED_V1494 section=%s reason=%s err=%s" % (section_id or "", reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _section_index_set_active_key(self, key, reason="", force_select=False):
        key = str(key or "#")
        old_key = getattr(self, "_section_index_active_key", "")
        self._section_index_active_key = key
        try:
            self.setProperty("PlexKM.Section.IndexActiveKey", key)
            xbmcgui.Window(10000).setProperty("PlexKM.Section.IndexActiveKey", key)
        except Exception:
            pass
        try:
            ctrl = self.getControl(SECTION_INDEX_ID)
            size = int(ctrl.size())
            active_pos = -1
            for idx in range(size):
                li = ctrl.getListItem(idx)
                ikey = li.getProperty("PlexKM.IndexKey") or li.getLabel() or "#"
                active = "1" if ikey == key else ""
                try:
                    li.setProperty("PlexKM.IndexActive", active)
                except Exception:
                    pass
                if active:
                    active_pos = idx
            focus_is_index = False
            try:
                focus_is_index = (int(self._safe_focus_id()) == int(SECTION_INDEX_ID))
            except Exception:
                focus_is_index = False
            # v1494: the right index is also the current-position indicator.
            # Selecting the matching index row scrolls the index list so long
            # Korean title-key lists follow wall navigation, but focus remains
            # on the wall unless Kodi XML has actually moved to control 7740.
            selected_pos = -1
            try:
                selected_pos = int(ctrl.getSelectedPosition())
            except Exception:
                selected_pos = -1
            if active_pos >= 0 and (force_select or focus_is_index or selected_pos != active_pos or key != old_key):
                try:
                    ctrl.selectItem(active_pos)
                except Exception:
                    pass
            if key != old_key or force_select or focus_is_index or selected_pos != active_pos:
                _log("SECTION_INDEX_ACTIVE_V1494 key=%s pos=%s focus_index=%s force=%s selected_before=%s scroll_sync=1 reason=%s" % (
                    key, active_pos, "1" if focus_is_index else "0", "1" if force_select else "0", selected_pos, reason or ""))
        except Exception:
            pass

    def _section_index_select_active(self, reason=""):
        try:
            key = getattr(self, "_section_index_active_key", "") or ""
            if not key:
                li = self._focused_wall_item()
                key = self._section_index_key_for_li_r102(li) if li else ""
            if key:
                # Force refresh even when the key value is the same, because a newly
                # rebuilt control has new ListItems whose active properties are empty.
                old = getattr(self, "_section_index_active_key", "")
                self._section_index_active_key = ""
                self._section_index_set_active_key(key, reason=reason, force_select=(self._safe_focus_id() == SECTION_INDEX_ID))
                if not old:
                    self._section_index_active_key = key
        except Exception:
            pass

    def _section_index_sync_for_item(self, li=None, reason=""):
        try:
            if not (self.getProperty("PlexKM.Window.IsSectionWall") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Window.IsSectionWall") == "1"):
                return
            if li is None:
                li = self._focused_wall_item()
            if li is None:
                return
            key = self._section_index_key_for_li_r102(li)
            self._section_index_set_active_key(key, reason=reason)
        except Exception:
            pass

    def _section_index_entry_for_key(self, section_id, key):
        key = str(key or "#")
        for entry in self._section_index_current_rows_r102(section_id) or []:
            try:
                if str(entry.get("key") or "#") == key:
                    return entry
            except Exception:
                pass
        return None

    def _section_index_click(self, reason=""):
        try:
            ctrl = self.getControl(SECTION_INDEX_ID)
            li = ctrl.getSelectedItem()
            key = li.getProperty("PlexKM.IndexKey") or li.getLabel() or "#"
            self._section_index_jump_to_key(key, reason=reason or "index_click")
        except Exception:
            _log("SECTION_INDEX_CLICK_FAILED_V1489 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _section_index_jump_to_key(self, key, reason=""):
        sid = str(self.active_section_id or "").strip()
        key = str(key or "#")
        if not sid or sid == "__home__":
            return
        entry = self._section_index_entry_for_key(sid, key)
        if not entry:
            _log("SECTION_INDEX_JUMP_SKIP_V1489 section=%s key=%s reason=no_entry" % (sid, key))
            return
        try:
            # The right index is a title index.  If the user was on another sort,
            # switch to title ASC so the clicked letter and the visible wall match.
            _jsort_r102, _jdir_r102 = self._section_index_sort_now_r102()
            if _jsort_r102 not in _INDEX_SORTS_R107 and (_jsort_r102 != "title" or _jdir_r102 != "asc"):
                self.sort = "title"
                self.sort_dir = "asc"
                self._set_section_sort_property(reason="index_jump:%s" % key)
                _jsort_r102, _jdir_r102 = "title", "asc"
            target_offset = max(0, int(entry.get("offset", 0) or 0))
            columns = max(1, int(self._wall_column_count() or 6))
            # v1491: The clicked index key's first movie must be the selected
            # poster on the second visible row / first column.  Load one full
            # row before it, then select the target at rel=columns.
            focus_row_offset = columns
            start_offset = max(0, target_offset - focus_row_offset)
            limit = max(int(self.initial or 180), int(self.batch or 240))
            rows = self._query_library_wall_rows_v1870(
                sid, sort=_jsort_r102, sort_dir=_jdir_r102, limit=limit,
                offset=start_offset, random_seed=self._wall_random_seed_v1644,
                genre=(getattr(self, "_active_genre_filter", "") or None) if _jsort_r102 != "title" else None,
            )
            wall = self.getControl(WALL_ID)
            wall.reset()
            try:
                self._preload_visible_row_ratings(rows, reason="index_jump_%s" % key)
            except Exception:
                pass
            added_lis = []
            for row in rows or []:
                li = self._li_from_row(row)
                wall.addItem(li)
                try:
                    added_lis.append(li)
                except Exception:
                    pass
            self.wall_offset = start_offset + len(rows or [])
            self._section_index_slice_active = True
            self._append_guard = set(["%s:%s" % (sid, start_offset)])
            # Do not cache this jump slice as a normal section cache.  Normal
            # cache restore assumes offset starts at 0; an index slice starts
            # near the clicked letter and would make later append offsets wrong.
            cache_key = self._section_cache_key(sid, self.sort, self.sort_dir) + ":genre=" + str(getattr(self, "_active_genre_filter", "") or "")
            try:
                self._section_rows_cache.pop(cache_key, None)
            except Exception:
                pass
            self._section_total_cache[cache_key] = self.wall_total
            rel = max(0, min(max(0, int(wall.size()) - 1), target_offset - start_offset))
            if int(wall.size()) > 0:
                # v1492: keep this Kodi-native and single-shot.  Re-selecting a
                # freshly reset, non-focused wall while the right index owns focus
                # made focus/selection timing unstable on Windows Kodi.
                try:
                    wall.selectItem(rel)
                except Exception:
                    pass
                self._logical_wall_pos = rel
                self._last_wall_pos = rel
                self._wall_tracked_pos = rel
                self._section_index_last_wall_jump_rel = rel
                self._section_index_last_wall_jump_key = key
                self._sync_wall_first_key("index_jump:%s" % key)
                self._set_home_meta_from_item(reason="index_jump:%s" % key)
                self._track_wall_selection("index_jump:%s" % key)
                self._schedule_info_asset_prewarm(reason="index_jump:%s" % key)
            try:
                self._schedule_info_cast_prewarm_for_listitems(added_lis, reason="index_jump_visible_buffer_v1494:%s:%s" % (sid, key), limit=CAST_PREWARM_VISIBLE_LIMIT_V1339)
            except Exception:
                pass
            self._section_index_set_active_key(key, reason="jump:%s" % (reason or ""), force_select=True)
            try:
                self.setFocusId(SECTION_INDEX_ID)
            except Exception:
                pass
            _log("SECTION_INDEX_JUMP_V1494 section=%s key=%s start=%d target=%d rel=%d loaded=%d second_row_first=1 visible_title_order=1 reason=%s" % (
                sid, key, start_offset, target_offset, rel, len(rows or []), reason or ""))
        except Exception:
            _log("SECTION_INDEX_JUMP_FAILED_V1494 section=%s key=%s reason=%s err=%s" % (sid, key, reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGERROR)

    def _section_bank_name_v1612(self):
        try:
            value = (self.getProperty("PlexKM.Section.ActiveBankV1612") or
                     xbmcgui.Window(10000).getProperty("PlexKM.Section.ActiveBankV1612") or
                     getattr(self, "_section_active_bank_v1612", "A") or "A").upper()
            if value not in ("A", "B"):
                value = "A"
            self._section_active_bank_v1612 = value
            return value
        except Exception:
            return "A"

    def _section_bank_row_ids_v1612(self, bank=None):
        value = str(bank or self._section_bank_name_v1612()).upper()
        return SECTION_RECOMMEND_ROW_IDS_B if value == "B" else SECTION_RECOMMEND_ROW_IDS_A

    def _section_active_row_ids_v1612(self):
        return self._section_bank_row_ids_v1612(self._section_bank_name_v1612())

    def _section_inactive_bank_v1612(self):
        return "A" if self._section_bank_name_v1612() == "B" else "B"

    def _section_bank_stack_id_v1612(self, bank=None):
        return SECTION_RECOMMEND_ROW_STACK_ID_B if str(bank or self._section_bank_name_v1612()).upper() == "B" else SECTION_RECOMMEND_ROW_STACK_ID

    def _section_bank_outer_id_v1612(self, bank=None):
        return 8399 if str(bank or self._section_bank_name_v1612()).upper() == "B" else 8299

    def _section_bank_title_property_v1612(self, bank, row_idx):
        prefix = "PlexKM.SectionPrev" if str(bank or "A").upper() == "B" else "PlexKM.Section"
        return "%s.Row%d.Title" % (prefix, int(row_idx))

    def _validate_section_ab_row_schema_v1617(self):
        """Verify the physical XML row schema before any A/B staging occurs.

        This is a structural guard, not a best-effort fallback: both banks must
        expose exactly the canonical registry.  A mismatch keeps the current
        surface intact instead of allowing a partial/truncated bank swap.
        """
        missing = []
        for bank, ids in (("A", SECTION_RECOMMEND_ROW_IDS_A), ("B", SECTION_RECOMMEND_ROW_IDS_B)):
            for idx, cid in enumerate(ids):
                try:
                    self.getControl(cid)
                except Exception:
                    missing.append("%s:%d:%d" % (bank, idx, cid))
        ok = (len(SECTION_RECOMMEND_ROW_IDS_A) == SECTION_RECOMMEND_ROW_CAPACITY and
              len(SECTION_RECOMMEND_ROW_IDS_B) == SECTION_RECOMMEND_ROW_CAPACITY and
              not missing)
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                if ok:
                    target.setProperty("PlexKM.Section.RowSchemaReadyV1617", "1")
                    target.clearProperty("PlexKM.Section.RowSchemaErrorV1617")
                else:
                    target.clearProperty("PlexKM.Section.RowSchemaReadyV1617")
                    target.setProperty("PlexKM.Section.RowSchemaErrorV1617", ",".join(missing) or "capacity_mismatch")
        except Exception:
            pass
        if ok:
            _log("SECTION_AB_SCHEMA_READY_V1617 capacity=%d bankA=%s bankB=%s" % (
                SECTION_RECOMMEND_ROW_CAPACITY,
                ",".join(str(x) for x in SECTION_RECOMMEND_ROW_IDS_A),
                ",".join(str(x) for x in SECTION_RECOMMEND_ROW_IDS_B)))
        else:
            _log("SECTION_AB_SCHEMA_INVALID_V1617 capacity=%d missing=%s" % (
                SECTION_RECOMMEND_ROW_CAPACITY, ",".join(missing) or "capacity_mismatch"), xbmc.LOGERROR)
        self._section_ab_schema_ready_v1617 = bool(ok)
        return bool(ok)

    def _section_stage_bank_begin_v1612(self, bank, reason=""):
        value = "B" if str(bank or "A").upper() == "B" else "A"
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.setProperty("PlexKM.Section.StageVisibleV1612", "1")
                target.setProperty("PlexKM.Section.StageBankV1612", value)
            _log("SECTION_TRUE_AB_STAGE_BEGIN_V1612 bank=%s reason=%s" % (value, reason or ""))
        except Exception:
            pass

    def _section_stage_bank_clear_v1612(self, reason=""):
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.clearProperty("PlexKM.Section.StageVisibleV1612")
                target.clearProperty("PlexKM.Section.StageBankV1612")
            _log("SECTION_TRUE_AB_STAGE_CLEAR_V1612 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _section_firstpaint_hold_begin_v2547r2(self, bank, cache_key="", reason=""):
        """Hold the old visible A/B bank while Kodi binds the newly-active target.

        Textures13/exact-cache readiness proves that bytes exist, not that the
        panel's ListItem poster has crossed a real renderer frame.  The target
        bank therefore stays at the XML's 1%% staging alpha for a short
        post-active settle window.  The source bank remains fully visible.
        """
        value = "B" if str(bank or "A").upper() == "B" else "A"
        token = "%s:%d" % (value, self._now_ms())
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.setProperty("PlexKM.Section.FirstPaintHoldV2547R2", "1")
                target.setProperty("PlexKM.Section.FirstPaintTargetV2547R2", value)
                target.setProperty("PlexKM.Section.FirstPaintTokenV2547R2", token)
            _log("SECTION_FIRSTPAINT_HOLD_BEGIN_V2547R2 key=%s bank=%s token=%s reason=%s source_bank_held=1 target_alpha=1" % (
                cache_key or "", value, token, reason or ""
            ))
        except Exception:
            _log("SECTION_FIRSTPAINT_HOLD_BEGIN_FAILED_V2547R2 key=%s bank=%s reason=%s err=%s" % (
                cache_key or "", value, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
        return token

    def _section_firstpaint_hold_clear_v2547r2(self, token="", reason=""):
        try:
            current = str(self.getProperty("PlexKM.Section.FirstPaintTokenV2547R2") or "")
            if token and current and current != str(token):
                return False
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.clearProperty("PlexKM.Section.FirstPaintHoldV2547R2")
                target.clearProperty("PlexKM.Section.FirstPaintTargetV2547R2")
                target.clearProperty("PlexKM.Section.FirstPaintTokenV2547R2")
            _log("SECTION_FIRSTPAINT_HOLD_CLEAR_V2547R2 token=%s reason=%s" % (
                token or current, reason or ""
            ))
            return True
        except Exception:
            _log("SECTION_FIRSTPAINT_HOLD_CLEAR_FAILED_V2547R2 token=%s reason=%s err=%s" % (
                token or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _section_firstpaint_post_active_settle_v2547r2(self, target_bank, cache_key="", token="", reason="", settle_ms=80):
        """Cross real GUI time after ActiveBank changes while the source remains visible."""
        started = self._now_ms()
        deadline = started + max(0, int(settle_ms or 0))
        while self._now_ms() < deadline:
            if xbmc.Monitor().abortRequested():
                break
            if cache_key and str(getattr(self, "active_section_id", "") or "") != str(cache_key):
                return False, max(0, self._now_ms() - started), "active_section_changed"
            remain = max(1, deadline - self._now_ms())
            xbmc.sleep(min(16, remain))
        elapsed = max(0, self._now_ms() - started)
        if cache_key and str(getattr(self, "active_section_id", "") or "") != str(cache_key):
            return False, elapsed, "active_section_changed"
        try:
            expected = "B" if str(target_bank or "A").upper() == "B" else "A"
            actual = str(self._section_bank_name_v1612() or "A").upper()
            if actual != expected:
                return False, elapsed, "active_bank_changed"
        except Exception:
            pass
        _log("SECTION_FIRSTPAINT_RENDER_SETTLE_V2547R2 key=%s bank=%s token=%s wait_ms=%d reason=%s exact_texture_not_visible_proof=1 source_bank_held=1" % (
            cache_key or "", str(target_bank or "").upper(), token or "", elapsed, reason or ""
        ))
        return True, elapsed, "ready"

    def _section_swap_guard_begin_v1615(self, bank, reason=""):
        """Hide only the target bank's neutral poster floors during the final A/B reveal."""
        value = "B" if str(bank or "A").upper() == "B" else "A"
        token = str(int(time.time() * 1000))
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.setProperty("PlexKM.Section.BankSwapInProgressV1615", "1")
                target.setProperty("PlexKM.Section.BankSwapTargetV1615", value)
                target.setProperty("PlexKM.Section.BankSwapTokenV1615", token)
            _log("SECTION_TRUE_AB_SWAP_GUARD_BEGIN_V1615 bank=%s reason=%s token=%s" % (
                value, reason or "", token
            ))
        except Exception:
            pass
        return token

    def _section_swap_guard_clear_later_v1615(self, token, reason="", delay_ms=0):
        """Clear the A/B swap guard immediately after the atomic bank publish.

        v2054 removes the historical 80/520ms timer. The active bank is already
        fully populated before _publish_section_scene_atomic_v1619 returns, so
        keeping the guard alive consumes the first Kodi DOWN action.
        """
        try:
            if str(self.getProperty("PlexKM.Section.BankSwapTokenV1615") or "") != str(token or ""):
                return
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.clearProperty("PlexKM.Section.BankSwapInProgressV1615")
                target.clearProperty("PlexKM.Section.BankSwapTargetV1615")
                target.clearProperty("PlexKM.Section.BankSwapTokenV1615")
            _log("SECTION_TRUE_AB_SWAP_GUARD_CLEAR_V2054 reason=%s token=%s delay_ms=0" % (
                reason or "", token or ""
            ))
        except Exception:
            _log("SECTION_TRUE_AB_SWAP_GUARD_CLEAR_FAILED_V2054 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _section_set_active_bank_v1612(self, bank, cache_key="", reason=""):
        value = "B" if str(bank or "A").upper() == "B" else "A"
        try:
            self._section_active_bank_v1612 = value
            if not hasattr(self, "_section_bank_cache_key_v1612"):
                self._section_bank_cache_key_v1612 = {"A": "", "B": ""}
            if cache_key:
                self._section_bank_cache_key_v1612[value] = str(cache_key)
            self.setProperty("PlexKM.Section.ActiveBankV1612", value)
            xbmcgui.Window(10000).setProperty("PlexKM.Section.ActiveBankV1612", value)
            _log("SECTION_TRUE_AB_SWAP_V1612 bank=%s cache_key=%s reason=%s" % (value, cache_key or "", reason or ""))
            return True
        except Exception:
            _log("SECTION_TRUE_AB_SWAP_FAILED_V1612 bank=%s reason=%s err=%s" % (
                value, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _load_sections(self, refresh=False):
        try:
            c = _ensure_core()
        except Exception:
            _log("SECTION_CORE_RESOLVE_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            self.sections = []
            return
        try:
            c.ensure_initial_sync(interactive=False)
        except Exception:
            pass
        try:
            # v1651: discover the real current Plex section model before applying
            # the user's visibility filter.  A newly-created Plex library did not
            # enter the sidebar because fetch_sections() filtered it against the
            # previously saved selected_sections list before Home built MENU_ID.
            cached_all = []
            try:
                cached_all = list(c.fetch_sections(refresh=False, selected_only=False) or [])
            except TypeError:
                cached_all = list(c.fetch_sections(refresh=False) or [])
            cached_ids = set(str(x.get("section_id", "")) for x in cached_all if str(x.get("section_id", "")))

            need_remote = bool(refresh)
            # Home startup must also probe once so libraries added since the last
            # Kodi run are reflected immediately.  This is section metadata only;
            # widget rows remain local/cache owned.
            if not need_remote:
                need_remote = True
            # R108: Kodi-library-only setup has no Plex server to probe.
            try:
                from resources.lib import pkm_sources as _pkm_sources_r108
                if not _pkm_sources_r108.plex_credentials_ready() and _pkm_sources_r108.has_kodi():
                    need_remote = False
                    _log("SECTION_REMOTE_SKIP_R108 reason=kodi_only")
            except Exception:
                pass

            remote_refresh_ok_v2493 = False
            if need_remote:
                try:
                    try:
                        remote_all = list(c.fetch_sections(refresh=True, selected_only=False) or [])
                    except TypeError:
                        remote_all = list(c.fetch_sections(refresh=True) or [])
                    remote_refresh_ok_v2493 = True
                except Exception:
                    if cached_all:
                        remote_all = cached_all
                        _log("SECTION_REMOTE_REFRESH_FALLBACK_LOCAL_V1732 cached=%d err=%s" % (
                            len(cached_all), traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                    else:
                        raise
            else:
                remote_all = cached_all

            remote_ids = [str(x.get("section_id", "")) for x in remote_all if str(x.get("section_id", ""))]
            new_ids = [sid for sid in remote_ids if sid not in cached_ids]

            # v1985: remote discovery never mutates the explicit user selection.
            if new_ids:
                _log("SIDEBAR_NEW_LIBRARY_DISCOVERED_NO_AUTO_SELECT_V1985 new=%s" % ",".join(new_ids))

            try:
                sections = c.filter_selected_sections(remote_all)
            except Exception:
                sections = []
                _log("LIBRARY_SELECTION_SCOPE_FAILED_V1979 sections=0 rule=selection_intersection err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            # v1985 atomic activation: until the complete selection transaction
            # succeeds, no selected section is active. Partial sync markers and
            # local DB rows are reusable cache only and must never surface in Home.
            try:
                if not bool(c.initial_sync_done()):
                    hidden_v1985 = [str(sec.get("section_id", "")) for sec in list(sections or [])]
                    sections = []
                    _log("SIDEBAR_ACTIVE_GATE_V1985 initial_done=0 active=0 hidden=%s" % (
                        ",".join(hidden_v1985) if hidden_v1985 else "-"
                    ))
            except Exception:
                sections = []
                _log("SIDEBAR_ACTIVE_GATE_FAILED_V1985 active=0 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            # R108: Kodi-library sections join the sidebar after the Plex ones.
            try:
                from resources.lib import pkm_kodi_source as _pkm_kodi_source_r108
                kodi_sections_r108 = _pkm_kodi_source_r108.virtual_sections()
                if kodi_sections_r108:
                    known_r108 = set(str(x.get("section_id", "")) for x in sections)
                    sections = list(sections) + [x for x in kodi_sections_r108 if x["section_id"] not in known_r108]
                    _log("SIDEBAR_KODI_SECTIONS_R108 added=%s" % ",".join(x["section_id"] for x in kodi_sections_r108))
            except Exception:
                _log("SIDEBAR_KODI_SECTIONS_R108_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            self.sections = c.apply_section_order(sections, save_merged=True)
            self.sections = self._apply_sidebar_order(self.sections)
            self._kodi_section_watch_start_r108()
            _startup_progress_v1845(20, reason="library_sections_ready")
            _section_success_at_v2493 = ""
            if remote_refresh_ok_v2493:
                try:
                    _section_success_at_v2493 = str(int(time.time() * 1000))
                    win_v2493 = xbmcgui.Window(10000)
                    win_v2493.setProperty("PlexKM.PlexRecentSectionSuccessAtV2493", _section_success_at_v2493)
                    self.setProperty("PlexKM.PlexRecentSectionSuccessAtV2493", _section_success_at_v2493)
                    # If the advisory identity probe lost a race and marked Plex
                    # offline first, a real /library/sections success is stronger
                    # evidence and immediately clears only that false startup state.
                    if win_v2493.getProperty("PlexKM.PlexOfflineReason") == "startup_fast_probe_fail":
                        for key_v2493 in ("PlexKM.PlexOffline", "PlexKM.PlexOfflineReason", "PlexKM.PlexOfflineLine1", "PlexKM.PlexOfflineLine2", "PlexKM.PlexOfflineAt"):
                            win_v2493.clearProperty(key_v2493)
                        try:
                            pkm_notify.pkm_notice_clear_if_title(["Plex 연결 실패"], force=True)
                        except Exception:
                            pass
                        _log("PLEX_FALSE_OFFLINE_CLEAR_V2493 reason=real_sections_success identity_probe_advisory=1")
                except Exception:
                    pass
            _log("SECTION_LOAD_OK_V1651 sections=%d remote=%d new=%s core=%s sidebar_order=applied dynamic_discovery=1" % (
                len(self.sections or []), len(remote_all or []), ",".join(new_ids) if new_ids else "-", getattr(c, "__name__", "?")
            ))
            if remote_refresh_ok_v2493:
                _log("PLEX_SECTION_SUCCESS_STAMP_V2493 at_ms=%s sections=%d identity_probe_advisory=1" % (
                    _section_success_at_v2493, len(self.sections or [])
                ))
        except Exception:
            _log("SECTION_LOAD_FAILED core=%s has_fetch=%s\n%s" % (getattr(c, "__name__", "?"), hasattr(c, "fetch_sections"), traceback.format_exc()), xbmc.LOGERROR)
            self.sections = []

    def _kodi_section_watch_start_r108(self):
        """R108: add/remove Kodi-library sidebar sections when the service mirror
        changes them (e.g. a folder added from the wizard), without a restart and
        without a Plex /library/sections round trip."""
        if getattr(self, "_kodi_section_watch_r108", None) is not None:
            return

        def _run():
            win = xbmcgui.Window(10000)
            mon = xbmc.Monitor()
            seen = win.getProperty("PlexKM.KodiSource.SyncedAtR108") or ""
            closing = getattr(self, "_closing_event_v1841", None)
            while not mon.abortRequested():
                if closing is not None and closing.is_set():
                    return
                if mon.waitForAbort(2.0):
                    return
                stamp = win.getProperty("PlexKM.KodiSource.SyncedAtR108") or ""
                if stamp == seen:
                    continue
                seen = stamp
                try:
                    from resources.lib import pkm_kodi_source as _ks
                    fresh = _ks.virtual_sections()
                    current = [x for x in (self.sections or []) if str(x.get("section_id", "")).startswith("k:")]
                    if [x["section_id"] for x in fresh] == [str(x.get("section_id")) for x in current]:
                        continue
                    others = [x for x in (self.sections or []) if not str(x.get("section_id", "")).startswith("k:")]
                    c = _ensure_core()
                    merged = c.apply_section_order(others + fresh, save_merged=True)
                    self.sections = self._apply_sidebar_order(merged)
                    self._build_menu()
                    _log("SIDEBAR_KODI_SECTIONS_LIVE_R108 now=%s" % (",".join(x["section_id"] for x in fresh) or "-"))
                except Exception:
                    _log("SIDEBAR_KODI_SECTIONS_LIVE_R108_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        t = threading.Thread(target=_run, name="PKMKodiSectionWatchR108")
        t.daemon = True
        self._kodi_section_watch_r108 = t
        t.start()

    def _selected_menu_section_sid(self):
        try:
            menu = self.getControl(MENU_ID)
            pos = int(menu.getSelectedPosition())
            if pos < 0 or pos >= int(menu.size()):
                return "", pos, None
            li = menu.getListItem(pos)
            if li.getProperty("kind") != "section":
                return "", pos, li
            return str(li.getProperty("section_id") or ""), pos, li
        except Exception:
            return "", -1, None

    def _menu_pos_for_section_sid(self, sid):
        try:
            menu = self.getControl(MENU_ID)
            for i in range(int(menu.size())):
                li = menu.getListItem(i)
                if str(li.getProperty("section_id") or "") == str(sid):
                    return i
        except Exception:
            pass
        return -1

    def _update_menu_section_item_at(self, pos, section):
        """Update one existing sidebar row in place for reorder preview.

        Avoid resetting/rebuilding the whole menu during drag/reorder because
        Kodi redraws the list/focusedlayout and the sidebar visibly shakes.
        """
        try:
            sid = str(section.get("section_id", ""))
            raw_title = section.get("title", "") or sid
            title = _display_library_title(raw_title)
            total = _safe_int(section.get("item_count"), 0)
            for cid in (MENU_ID, MENU_COLLAPSED_ID):
                try:
                    ctrl = self.getControl(cid)
                    if pos < 0 or pos >= int(ctrl.size()):
                        continue
                    li = ctrl.getListItem(pos)
                    li.setLabel(title)
                    li.setProperty("kind", "section")
                    li.setProperty("index", str(max(0, int(pos) - 1)))
                    li.setProperty("section_id", sid)
                    li.setProperty("section_title", title)
                    li.setProperty("section_title_raw", str(raw_title or ""))
                    li.setProperty("section_type", section.get("section_type", ""))
                    li.setProperty("total", str(total))
                    self._set_menu_icon(li, title, "section")
                    li.setProperty("PlexKM.SidebarDivider", "1" if int(pos) == 1 else "")
                    try:
                        active_reorder_sid = str(getattr(self, "_menu_reorder_sid", "") or "")
                        li.setProperty("MenuFocusColor", "FFFFC400" if active_reorder_sid and sid == active_reorder_sid else "FFFFFFFF")
                    except Exception:
                        pass
                except Exception:
                    pass
            return True
        except Exception:
            _log("SIDEBAR_REORDER_INPLACE_UPDATE_FAILED pos=%s err=%s" % (pos, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _published_section_id_v2121(self):
        """Return the section id of the surface that is actually published.

        This is deliberately separate from ``active_section_id``.  The latter
        can switch to a new intent before the hidden A/B bank is ready, while
        this property changes only at the final visibility commit.
        """
        try:
            value = str(self.getProperty("PlexKM.Window.PublishedSectionId") or "").strip()
            if value:
                return value
        except Exception:
            pass
        try:
            return str(xbmcgui.Window(10000).getProperty("PlexKM.Window.PublishedSectionId") or "").strip()
        except Exception:
            return ""

    def _set_published_section_id_v2121(self, sid, reason=""):
        sid = str(sid or "").strip()
        if sid.startswith("recommend:"):
            sid = sid.split(":", 1)[1]
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                if sid:
                    target.setProperty("PlexKM.Window.PublishedSectionId", sid)
                else:
                    target.clearProperty("PlexKM.Window.PublishedSectionId")
            _log("PUBLISHED_CONTENT_OWNER_V2121 section=%s reason=%s" % (sid or "home", reason or ""))
        except Exception:
            _log("PUBLISHED_CONTENT_OWNER_FAILED_V2121 section=%s reason=%s err=%s" % (
                sid or "home", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _commit_section_recommend_visible(self, title, count_text="추천", reason=""):
        """v1292: show section widgets only after their row controls are ready.

        The previous flow set IsSectionRecommend=1 at the beginning of
        _show_section_recommend_widgets().  During Home -> section movement Kodi
        rendered Home group 9299 and section group 8299 together for a frame,
        producing title overlap such as:
        취향 한국영화 + 최근 방영 ... 드라마에 추가됨.
        """
        # On rapid native sidebar navigation an older callback must not publish
        # its scene when a different section now owns the selected menu row.
        try:
            _owner_key_postlog = str(getattr(self, "active_section_id", "") or "")
            _selected_postlog = self._selected_menu_item()
            if _owner_key_postlog.startswith("recommend:") and _selected_postlog is not None:
                _selected_kind_postlog = str(_selected_postlog.getProperty("kind") or "")
                _selected_sid_postlog = str(_selected_postlog.getProperty("section_id") or "").strip()
                _owner_sid_postlog = _owner_key_postlog.split(":", 1)[1]
                if _selected_kind_postlog != "section" or _selected_sid_postlog != _owner_sid_postlog:
                    _log("SECTION_VISIBLE_STALE_OWNER_SKIP selected=%s owner=%s reason=%s" % (
                        _selected_sid_postlog, _owner_sid_postlog, reason or ""), xbmc.LOGWARNING)
                    return
        except Exception:
            _log("SECTION_VISIBLE_OWNER_PROBE_FAILED reason=%s" % (reason or ""), xbmc.LOGWARNING)
            return
        # R35: covers the already_rendered / revisit shortcuts that never reach
        # _publish_section_scene_atomic_v1619 (armed sidebar ENTER only).
        self._section_commit_overlay_retire_r35("section_recommend", reason="visible_commit:%s" % (reason or ""))
        title = _display_library_title(title)
        count_text = _display_library_title(count_text)
        try:
            self.getControl(COUNT_ID).setLabel(count_text or "")
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            win.clearProperty("PlexKM.Scene.RecommendWidgetFadeOutV2503")
            win.setProperty("PlexKM.Window.HomeLayout", "1")
            win.setProperty("PlexKM.Window.IsSectionRecommend", "1")
            win.clearProperty("PlexKM.Window.IsSectionWall")
            win.clearProperty("PlexKM.Window.IsSectionCategory")
            win.clearProperty("PlexKM.Window.IsHome")
            win.setProperty("PlexKM.Window.Title", title or "")
            win.setProperty("PlexKM.Window.CountLabel", count_text or "")
            self.clearProperty("PlexKM.Scene.RecommendWidgetFadeOutV2503")
            self.setProperty("PlexKM.Window.HomeLayout", "1")
            self.setProperty("PlexKM.Window.IsSectionRecommend", "1")
            self.clearProperty("PlexKM.Window.IsSectionWall")
            self.clearProperty("PlexKM.Window.IsSectionCategory")
            self.clearProperty("PlexKM.Window.IsHome")
            self.setProperty("PlexKM.Window.Title", title or "")
            self.setProperty("PlexKM.Window.CountLabel", count_text or "")
            self._section_stage_bank_clear_v1612(reason="section_commit:%s" % (reason or ""))
            try:
                self._search_info_sidebar_ab_commit_v2284(
                    section_id=getattr(self, "active_section_id", "") or "",
                    reason="recommend_visible:%s" % (reason or "")
                )
            except Exception:
                pass
            _log("SECTION_RECOMMEND_VISIBLE_COMMIT reason=%s title=%s count=%s" % (reason or "", _short_log_value(title), _short_log_value(count_text)))
            _visible_gate_key_v2475 = str(getattr(self, "active_section_id", "") or "")
            try:
                _gate_token_probe_v2475 = str(getattr(self, "_section_first_visit_gate_token_v1620", "") or "")
                _gate_key_probe_v2475 = str(getattr(self, "_section_first_visit_gate_key_v1620", "") or "")
                if _gate_token_probe_v2475 and _gate_key_probe_v2475 == _visible_gate_key_v2475:
                    xbmc.sleep(16)
            except Exception:
                pass
            try:
                select_started = int(getattr(self, "_sidebar_ui_select_started_v1650", 0) or 0)
                select_sid = str(getattr(self, "_sidebar_ui_select_section_v1650", "") or "")
                logged = bool(getattr(self, "_sidebar_ui_select_logged_v1650", False))
                if select_started > 0 and select_sid and not logged:
                    elapsed = max(0, self._now_ms() - select_started)
                    actual_sid = str(getattr(self, "active_section_id", "") or "").split(":", 1)[-1]
                    if actual_sid != select_sid:
                        # This was a different focus event, NOT a valid latency
                        # sample for the just-published scene.
                        _log("SIDEBAR_VISIBLE_METRIC_STALE owner=%s selected=%s reason=%s discard=1" % (
                            actual_sid, select_sid, reason or ""), xbmc.LOGWARNING)
                    else:
                        self._sidebar_ui_select_logged_v1650 = True
                        _log("SIDEBAR_UI_WIDGET_VISIBLE_V1650 section=%s elapsed_ms=%d reason=%s title=%s" % (
                            actual_sid, elapsed, reason or "", _short_log_value(title)
                        ))
            except Exception:
                pass
            try:
                if _visible_gate_key_v2475:
                    self._section_visible_finish_v2475(_visible_gate_key_v2475, reason=reason or "")
            except Exception:
                pass
            self._clear_sidebar_menu_browsing_later(reason="section_commit:%s" % (reason or ""), delay_ms=620)
            # v1871: while the user is still on the TV recommendation tab,
            # prepare only the first 12 season-folder textures from local poster
            # files. This is background/cache-only work: no PMS request, no
            # ListItem mutation, and no focus/navigation change.
            try:
                active_key_v1871 = str(getattr(self, "active_section_id", "") or "")
                sid_v1871 = active_key_v1871.split(":", 1)[1] if active_key_v1871.startswith("recommend:") else ""
                if sid_v1871:
                    self._start_tv_season_first12_texture_prewarm_v1871(
                        sid_v1871, reason="recommend_visible:%s" % (reason or "")
                    )
            except Exception:
                _log("TV_SEASON_FIRST12_PREWARM_START_FAILED_V1871 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        except Exception:
            pass

    def _sidebar_entry_preserve_current_section_view_v1864(self, prev_focus):
        """Keep the exact current section surface when LEFT only enters the sidebar.

        v1873 root fix: the native sidebar selection can still point at Home after
        a Category card opens a filtered Library wall.  LEFT is only a focus move,
        so derive the owning section from the published surface, synchronize the
        sidebar selection to that section, and leave the wall/filter/position
        untouched.  Kodi XML remains the sole focus owner; this helper never moves
        focus and never rebuilds content.
        """
        try:
            prev_focus = int(prev_focus)
        except Exception:
            return False
        try:
            section_controls = {
                WALL_ID,
                SECTION_SORT_BUTTON_ID,
                SECTION_INDEX_ID,
                SECTION_CATEGORY_PANEL_ID,
                SECTION_TAB_RECOMMEND_ID,
                SECTION_TAB_LIBRARY_ID,
                SECTION_TAB_CATEGORY_ID,
            }
            from_current_section = (
                prev_focus in section_controls
                or prev_focus in SECTION_RECOMMEND_ALL_ROW_IDS
            )
            if not from_current_section:
                return False

            active_raw = str(getattr(self, "active_section_id", "") or "").strip()
            if active_raw.startswith("recommend:"):
                active_sid = active_raw.split(":", 1)[1].strip()
            else:
                active_sid = active_raw
            if not active_sid or active_sid == "__home__":
                return False

            menu = self.getControl(MENU_ID)
            size = int(menu.size() or 0)
            if size <= 0:
                return False
            try:
                selected_before = int(menu.getSelectedPosition())
            except Exception:
                selected_before = -1

            active_pos = -1
            for idx in range(size):
                li = menu.getListItem(idx)
                if not li or li.getProperty("kind") != "section":
                    continue
                if str(li.getProperty("section_id") or "").strip() == active_sid:
                    active_pos = idx
                    break
            if active_pos < 0:
                return False

            # This is selection-state synchronization only.  Focus already belongs
            # to MENU_ID through Kodi XML and no Python focus movement is performed.
            if selected_before != active_pos:
                menu.selectItem(active_pos)
            try:
                self.getControl(MENU_COLLAPSED_ID).selectItem(active_pos)
            except Exception:
                pass
            self.active_menu_index = active_pos
            self._last_menu_pos = active_pos

            try:
                mode = (
                    "library" if self.getProperty("PlexKM.Window.IsSectionWall") == "1"
                    else "category" if self.getProperty("PlexKM.Window.IsSectionCategory") == "1"
                    else "recommend" if self.getProperty("PlexKM.Window.IsSectionRecommend") == "1"
                    else "unknown"
                )
            except Exception:
                mode = "unknown"
            genre = str(getattr(self, "_active_genre_filter", "") or "")
            try:
                wall_pos = int(self._wall_selected_position())
            except Exception:
                wall_pos = -1
            _log(
                "SIDEBAR_ENTRY_FILTERED_WALL_PRESERVE_V1873 "
                "section=%s pos=%s selected_before=%s prev_focus=%s mode=%s genre=%s "
                "wall_pos=%s python_focus_write=0 content_mutation=0"
                % (active_sid, active_pos, selected_before, prev_focus, mode, genre, wall_pos)
            )
            return True
        except Exception:
            _log(
                "SIDEBAR_ENTRY_FILTERED_WALL_PRESERVE_FAILED_V1873 err=%s"
                % traceback.format_exc().replace(chr(10), " | "),
                xbmc.LOGWARNING,
            )
            return False

    def _section_sort_media_kind(self, item=None):
        """Return movie/tv for the active or supplied Plex section."""
        # v2119: no implicit sidebar lookup exists before XML controls are live.
        # An explicitly supplied item is still safe/data-only.
        if item is None and not bool(getattr(self, "_xml_controls_ready_v2119", False)):
            return "movie"
        try:
            section_item = item or self._current_section_menu_item()
            sid = str(section_item.getProperty("section_id") or "") if section_item else ""
            if sid and self._is_tv_library_section_v1870(sid):
                return "tv"
        except Exception:
            pass
        return "movie"

    def _section_sort_options(self, media_kind=None):
        return pkm_library_sort.sort_options(media_kind or self._section_sort_media_kind())

    def _section_sort_control_maps(self, media_kind=None):
        options = self._section_sort_options(media_kind=media_kind)
        key_by_control = {
            control_id: sort_key
            for control_id, (sort_key, _label) in zip(SECTION_SORT_ITEM_IDS, options)
        }
        return key_by_control, {key: control for control, key in key_by_control.items()}

    def _normalize_section_sort(self, sort_key, media_kind=None):
        return pkm_library_sort.normalize_sort_key(
            sort_key, media_kind=(media_kind or self._section_sort_media_kind())
        )

    def _section_sort_label(self, sort_key="", media_kind=None):
        kind = media_kind or self._section_sort_media_kind()
        return pkm_library_sort.no_ellipsis_text(
            pkm_library_sort.sort_label(
                sort_key or getattr(self, "sort", "title"), media_kind=kind
            )
        )

    def _set_section_sort_property(self, reason="", media_kind_v2470=None):
        try:
            media_kind = str(media_kind_v2470 or "").strip().lower() or self._section_sort_media_kind()
            state = pkm_library_sort.sort_state(
                getattr(self, "sort", "title"),
                getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(getattr(self, "sort", "title"))),
                media_kind=media_kind,
            )
            key = state["key"]
            sort_dir = state["dir"]
            label = pkm_library_sort.no_ellipsis_text(state["label"])
            box_width = state["box_width"]
            arrow = state["arrow"]
            # A movie-only key must never leak into a TV section, or vice versa.
            self.sort = key
            self.sort_dir = sort_dir
            option_labels = [
                pkm_library_sort.no_ellipsis_text(option_label)
                for _option_key, option_label in self._section_sort_options(media_kind=media_kind)
            ]
            targets = []
            for win_id in (10000, 13000):
                try:
                    targets.append(xbmcgui.Window(win_id))
                except Exception:
                    pass
            targets.append(self)
            for target in targets:
                try:
                    target.setProperty("PlexKM.Section.SortKey", key)
                    target.setProperty("PlexKM.Section.SortLabel", label)
                    target.setProperty("PlexKM.Section.SortDir", sort_dir)
                    target.setProperty("PlexKM.Section.SortArrow", arrow)
                    target.setProperty("PlexKM.Section.SortBoxWidth", box_width)
                    target.setProperty("PlexKM.Section.SortMediaKind", media_kind)
                    for index, option_label in enumerate(option_labels, 1):
                        target.setProperty("PlexKM.Section.SortOptionLabel%d" % index, option_label)
                    # R99 L2: header sort chips. Active chip = white pill + dark text + direction arrow.
                    _chip_dir_r99 = "media/common/buttons/"
                    _chip_base_r99 = "special://home/addons/plugin.video.km/resources/skins/Default/" + _chip_dir_r99
                    for index, (option_key, option_label) in enumerate(self._section_sort_options(media_kind=media_kind), 1):
                        _lbl_r99 = pkm_library_sort.no_ellipsis_text(option_label)
                        if option_key == key:
                            target.setProperty("PlexKM.Section.SortActiveIndex", str(index))
                            target.setProperty("PlexKM.Section.SortChipLabel%d" % index, "[COLOR FF111111][B]%s[/B] %s[/COLOR]" % (_lbl_r99, arrow))
                            target.setProperty("PlexKM.Section.SortChipTex%d" % index, _chip_base_r99 + "pkm_chip_active_r99.png")
                        else:
                            target.setProperty("PlexKM.Section.SortChipLabel%d" % index, _lbl_r99)
                            target.setProperty("PlexKM.Section.SortChipTex%d" % index, _chip_base_r99 + "pkm_chip_idle_r99.png")
                    for index in range(len(option_labels) + 1, 13):
                        target.clearProperty("PlexKM.Section.SortChipLabel%d" % index)
                except Exception:
                    pass
            self._update_category_wall_summary(reason="sort_set:%s" % (reason or ""))
            _log("SECTION_SORT_SET_V1911 media=%s key=%s label=%s dir=%s arrow=%s width=%s reason=%s" % (
                media_kind, key, label, sort_dir, arrow, box_width, reason or ""
            ))
        except Exception:
            _log("SECTION_SORT_SET_FAILED_V1911 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _update_category_wall_summary(self, reason=""):
        try:
            genre = str(getattr(self, "_active_genre_filter", "") or "").strip()
            count = max(0, int(getattr(self, "_active_genre_count", 0) or 0))
            summary = ""
            if genre:
                summary = "%s   범주로   %s   %d개" % (
                    genre, self._section_sort_label(getattr(self, "sort", "title")), count
                )
            for target in (self, xbmcgui.Window(10000)):
                if genre:
                    target.setProperty("PlexKM.Section.ActiveGenre", genre)
                    target.setProperty("PlexKM.Section.CategoryWallSummary", summary)
                else:
                    target.clearProperty("PlexKM.Section.ActiveGenre")
                    target.clearProperty("PlexKM.Section.CategoryWallSummary")
            _log("SECTION_CATEGORY_WALL_SUMMARY_V1832 genre=%s count=%s summary=%s reason=%s" % (
                genre, count, summary, reason or ""
            ))
        except Exception:
            pass

    def _section_cache_key(self, sid, sort_key=None, sort_dir=None):
        return pkm_library_sort.cache_key(
            sid,
            sort_key or getattr(self, "sort", "title"),
            sort_dir or getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(sort_key or getattr(self, "sort", "title"))),
        )

    def _apply_current_section_sort(self, reason=""):
        item = self._current_section_menu_item()
        if not item:
            _log("SECTION_SORT_APPLY_SKIPPED reason=%s no_section_item=1 sort=%s dir=%s" % (reason or "", getattr(self, "sort", ""), getattr(self, "sort_dir", "")))
            return False
        self._set_section_sort_property(reason="apply:%s" % (reason or ""))
        sort_kpi_v2610 = self._sort_kpi_begin_v2610(item, reason=reason)
        try:
            self._library_wall_generation_v2069 = int(getattr(self, "_library_wall_generation_v2069", 0) or 0) + 1
            self._library_wall_owner_v2069 = ()
            self._append_guard = set()
            self._library_append_request_v2070 = False
            self._library_append_last_commit_v2579 = None
            with self._library_append_prefetch_lock_v2070:
                self._library_append_prefetch_rows_v2070.clear()
                self._library_append_prefetch_inflight_v2070.clear()
        except Exception:
            pass
        # v2610: a sort change is a new cache key, not a reason to disable the
        # exact-key prepared/persistent fast path.  force=True made every movie/TV
        # sort look cold and bypassed caches even when that exact sorted scene was
        # already prepared.  force=False still rebuilds when the target key differs.
        self._show_section_wall(item, force=False)
        if sort_kpi_v2610 and isinstance(getattr(self, "_sort_kpi_pending_v2610", None), dict):
            # Same-key/no-gate cases can return without a Library gate.  Do not let
            # that pending sample leak into the next unrelated Library transition.
            self._sort_kpi_finish_v2610(key=str(sort_kpi_v2610.get("target_key") or ""), spinner_used=False, reason="apply_return_no_gate")
        _log("SECTION_SORT_APPLY sort=%s dir=%s label=%s section=%s reason=%s cache_reuse_allowed_v2610=1" % (
            self._normalize_section_sort(getattr(self, "sort", "")),
            self._normalize_sort_dir(getattr(self, "sort_dir", "")),
            self._section_sort_label(getattr(self, "sort", "")),
            self._section_sid_from_item(item), reason or ""))
        return True

    def _open_section_sort_inline(self, reason="click"):
        """Open the in-window sort menu made of fixed Kodi button controls."""
        try:
            if not (self.getProperty("PlexKM.Window.IsSectionWall") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Window.IsSectionWall") == "1"):
                return False
            media_kind = self._section_sort_media_kind()
            current = pkm_library_sort.normalize_sort_key(
                getattr(self, "sort", "title"), media_kind=media_kind
            )
            _key_by_control, control_by_key = self._section_sort_control_maps(media_kind=media_kind)
            target_id = int(control_by_key.get(current, SECTION_SORT_ITEM_IDS[0]))
            self._set_section_sort_property(reason="dropdown_open_v1911")
            for target in (self, xbmcgui.Window(10000)):
                target.setProperty("PlexKM.Section.SortDropdownOpen", "1")
            # The menu controls are hidden until the property above is committed.
            # Kodi exposes them on its next rendered frame; under GUI load that is
            # later than 1 ms, the focus move was refused ("Control 7742 ... asked
            # to focus, but it can't") and keys drove the wall behind the menu.
            # Retry until the focus really landed, bounded at ~500 ms.
            focus_tries_fix5 = 0
            for focus_tries_fix5 in range(1, 26):
                xbmc.sleep(1 if focus_tries_fix5 == 1 else 20)
                self.setFocusId(target_id)
                try:
                    if int(self.getFocusId()) == target_id:
                        break
                except Exception:
                    pass
            _log("SECTION_SORT_DROPDOWN_OPEN_V1860 key=%s target=%s reason=%s focus_tries=%d" % (
                current, target_id, reason or "", focus_tries_fix5
            ))
            try:
                self._sort_head_prewarm_schedule_v2628(target_id, reason="dropdown_open_v2628")
            except Exception:
                pass
            return True
        except Exception:
            _log("SECTION_SORT_DROPDOWN_OPEN_FAILED_V1860 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _close_section_sort_inline(self, restore_focus=True, reason=""):
        for target in (self, xbmcgui.Window(10000)):
            try:
                target.clearProperty("PlexKM.Section.SortDropdownOpen")
            except Exception:
                pass
        if restore_focus:
            try:
                self.setFocusId(SECTION_SORT_BUTTON_ID)
            except Exception:
                pass
        if str(reason or "") != "selected_v1860":
            try:
                self._sort_head_allowed_v2628 = set()
                self._sort_head_apply_target_v2628 = ""
            except Exception:
                pass
        _log("SECTION_SORT_DROPDOWN_CLOSE_V1860 restore=%s reason=%s" % (
            1 if restore_focus else 0, reason or ""
        ))

    def _apply_section_sort_key(self, sort_key, reason="enter"):
        """Apply the exact sort key associated with a clicked dropdown button."""
        try:
            media_kind = self._section_sort_media_kind()
            key = pkm_library_sort.normalize_sort_key(sort_key, media_kind=media_kind)
            self.sort = key
            self.sort_dir = pkm_library_sort.default_sort_dir(key)
            self._sort_head_mark_apply_target_v2628(key)
            # R23: the dropdown items are hidden once it closes.  Leaving focus on
            # the hidden item (e.g. 7752) for the whole apply left the screen with
            # no visible focus until the apply returned (~5-9 s on SHIELD).
            self._close_section_sort_inline(restore_focus=True, reason="selected_v1860")
            ok = self._apply_current_section_sort(reason="dropdown:%s" % (reason or "enter"))
            try:
                self.setFocusId(SECTION_SORT_BUTTON_ID)
            except Exception:
                pass
            _log("SECTION_SORT_DROPDOWN_APPLY_V1860 key=%s dir=%s restored=7730 ok=%s reason=%s" % (
                key, self.sort_dir, 1 if ok else 0, reason or ""
            ))
            return ok
        except Exception:
            _log("SECTION_SORT_DROPDOWN_APPLY_FAILED_V1860 key=%s err=%s" % (
                sort_key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _toggle_section_sort_dir(self, reason="longpress"):
        """Long press/context: toggle ascending/descending for the current sort."""
        try:
            if not (self.getProperty("PlexKM.Window.IsSectionWall") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Window.IsSectionWall") == "1"):
                _log("SECTION_SORT_DIR_TOGGLE_SKIPPED reason=%s not_section_wall=1" % (reason or ""))
                return False
            media_kind = self._section_sort_media_kind()
            current = pkm_library_sort.normalize_sort_key(
                getattr(self, "sort", "title"), media_kind=media_kind
            )
            self.sort = current
            self.sort_dir = pkm_library_sort.toggle_sort_dir(getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(current)))
            if current == "random":
                try:
                    sid = self._section_sid_from_item(self._current_section_menu_item())
                    if sid:
                        prefix = "%s|sort=random|" % sid
                        for k in list(getattr(self, "_section_rows_cache", {}).keys()):
                            if str(k).startswith(prefix):
                                self._section_rows_cache.pop(k, None)
                                self._section_total_cache.pop(k, None)
                except Exception:
                    pass
            ok = self._apply_current_section_sort(reason="dir_toggle:%s" % (reason or "longpress"))
            if ok:
                _log("SECTION_SORT_DIR_TOGGLE_APPLY sort=%s dir=%s label=%s section=%s reason=%s" % (
                    current, self.sort_dir, self._section_sort_label(current), self._section_sid_from_item(self._current_section_menu_item()), reason or "longpress"))
            return ok
        except Exception:
            _log("SECTION_SORT_DIR_TOGGLE_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _current_section_menu_item(self):
        """Return the selected sidebar section item, if any."""
        try:
            item = self._selected_menu_item()
            if item and item.getProperty("kind") == "section":
                return item
        except Exception:
            pass
        return None

    def _section_sid_from_item(self, item):
        try:
            if item and item.getProperty("kind") == "section":
                return str(item.getProperty("section_id") or "").strip()
        except Exception:
            pass
        return ""

    def _section_tab_state_load_v2471(self):
        """Load per-section tab/sort UI state from disk once per WindowXML."""
        if bool(getattr(self, "_section_tab_state_loaded_v2471", False)):
            return
        self._section_tab_state_loaded_v2471 = True
        try:
            path = self._derived_cache_path_v2467("section_tab_state_v2471.json")
            if not path or not os.path.exists(path):
                _log("SECTION_TAB_STATE_LOAD_V2471 sections=0 reason=no_file")
                return
            with open(path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            raw_sections = payload.get("sections") if isinstance(payload, dict) else {}
            if not isinstance(raw_sections, dict):
                raw_sections = {}
            tabs = getattr(self, "_section_last_tab_by_sid", None)
            if not isinstance(tabs, dict):
                tabs = {}
                self._section_last_tab_by_sid = tabs
            states = {}
            for sid_raw, rec_raw in raw_sections.items():
                sid = str(sid_raw or "").strip()
                if not sid or not isinstance(rec_raw, dict):
                    continue
                tab = str(rec_raw.get("tab") or "").strip().lower()
                if tab in ("recommend", "library", "category"):
                    tabs[sid] = tab
                    try:
                        xbmcgui.Window(10000).setProperty("PlexKM.Section.%s.LastTab" % sid, tab)
                    except Exception:
                        pass
                sort_key = str(rec_raw.get("sort") or "").strip().lower()
                sort_dir = str(rec_raw.get("sort_dir") or "").strip().lower()
                cache_key = str(rec_raw.get("cache_key") or "").strip()
                if sort_key:
                    states[sid] = {
                        "sort": sort_key,
                        "sort_dir": sort_dir if sort_dir in ("asc", "desc") else pkm_library_sort.default_sort_dir(sort_key),
                        "cache_key": cache_key,
                    }
            self._section_last_library_state_by_sid_v2471 = states
            _log("SECTION_TAB_STATE_LOAD_V2471 sections=%d library_states=%d restart_persist=1" % (len(tabs), len(states)))
        except Exception:
            _log("SECTION_TAB_STATE_LOAD_FAILED_V2471 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _section_tab_state_store_v2471(self, reason=""):
        """Atomically persist only small user-navigation state; no scene objects."""
        try:
            self._section_tab_state_load_v2471()
            tabs = dict(getattr(self, "_section_last_tab_by_sid", {}) or {})
            states = dict(getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {})
            sections_out = {}
            for sid in sorted(set(list(tabs.keys()) + list(states.keys())), key=lambda x: str(x)):
                sid_s = str(sid or "").strip()
                if not sid_s:
                    continue
                rec = {}
                tab = str(tabs.get(sid_s) or "").strip().lower()
                if tab in ("recommend", "library", "category"):
                    rec["tab"] = tab
                st = states.get(sid_s) if isinstance(states.get(sid_s), dict) else {}
                if st:
                    sort_key = str(st.get("sort") or "").strip().lower()
                    sort_dir = str(st.get("sort_dir") or "").strip().lower()
                    cache_key = str(st.get("cache_key") or "").strip()
                    if sort_key:
                        rec["sort"] = sort_key
                        rec["sort_dir"] = sort_dir if sort_dir in ("asc", "desc") else pkm_library_sort.default_sort_dir(sort_key)
                    if cache_key:
                        rec["cache_key"] = cache_key
                if rec:
                    sections_out[sid_s] = rec
            path = self._derived_cache_path_v2467("section_tab_state_v2471.json")
            if not path:
                return False
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"version": 2471, "sections": sections_out}, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            _log("SECTION_TAB_STATE_STORE_V2471 sections=%d reason=%s restart_persist=1" % (len(sections_out), reason or ""))
            return True
        except Exception:
            _log("SECTION_TAB_STATE_STORE_FAILED_V2471 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _remember_section_library_state_v2471(self, sid, cache_key="", sort_key="", sort_dir="", genre="", reason=""):
        """Remember the unfiltered Library key needed for restart-fast restore."""
        try:
            sid = str(sid or "").strip()
            if not sid or str(genre or "").strip():
                return
            self._section_tab_state_load_v2471()
            sort_key = str(sort_key or getattr(self, "sort", "title") or "title").strip().lower()
            sort_dir = str(sort_dir or getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(sort_key)) or "").strip().lower()
            if sort_dir not in ("asc", "desc"):
                sort_dir = pkm_library_sort.default_sort_dir(sort_key)
            state = {"sort": sort_key, "sort_dir": sort_dir, "cache_key": str(cache_key or "").strip()}
            self._section_last_library_state_by_sid_v2471[sid] = state
            self._section_tab_state_store_v2471(reason=reason or "library_state")
            _log("SECTION_LIBRARY_STATE_REMEMBER_V2471 section=%s sort=%s dir=%s key=%s" % (sid, sort_key, sort_dir, str(cache_key or "")))
        except Exception:
            pass

    def _restore_section_library_state_v2471(self, sid, reason=""):
        """Restore only sort/direction for the section's normal Library tab."""
        try:
            sid = str(sid or "").strip()
            if not sid:
                return False
            self._section_tab_state_load_v2471()
            st = (getattr(self, "_section_last_library_state_by_sid_v2471", {}) or {}).get(sid)
            if not isinstance(st, dict):
                return False
            sort_key = str(st.get("sort") or "").strip().lower()
            sort_dir = str(st.get("sort_dir") or "").strip().lower()
            if not sort_key:
                return False
            self.sort = sort_key
            self.sort_dir = sort_dir if sort_dir in ("asc", "desc") else pkm_library_sort.default_sort_dir(sort_key)
            _log("SECTION_LIBRARY_STATE_RESTORE_V2471 section=%s sort=%s dir=%s reason=%s" % (sid, self.sort, self.sort_dir, reason or ""))
            return True
        except Exception:
            return False

    def _section_last_tab(self, sid, default="recommend"):
        try:
            self._section_tab_state_load_v2471()
            sid = str(sid or "").strip()
            if not sid:
                return default
            try:
                prop_tab = xbmcgui.Window(10000).getProperty("PlexKM.Section.%s.LastTab" % sid)
            except Exception:
                prop_tab = ""
            tab = str(prop_tab or getattr(self, "_section_last_tab_by_sid", {}).get(sid) or "").strip().lower()
            return tab if tab in ("recommend", "library", "category") else default
        except Exception:
            return default

    def _remember_section_tab(self, sid, tab, reason=""):
        try:
            sid = str(sid or "").strip()
            tab = str(tab or "").strip().lower()
            if not sid or tab not in ("recommend", "library", "category"):
                return
            self._section_tab_state_load_v2471()
            if not hasattr(self, "_section_last_tab_by_sid"):
                self._section_last_tab_by_sid = {}
            self._section_last_tab_by_sid[sid] = tab
            # If the successful destination is the normal (unfiltered) Library,
            # capture its exact cache key/sort so the next process can hydrate
            # the same wall instead of guessing title/asc.
            if tab == "library" and not str(getattr(self, "_active_genre_filter", "") or "").strip():
                sort_key_v2471 = str(getattr(self, "sort", "title") or "title").strip().lower()
                sort_dir_v2471 = str(getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(sort_key_v2471)) or "").strip().lower()
                cache_key_v2471 = str(getattr(self, "_active_wall_cache_key_v1841", "") or "").strip()
                self._section_last_library_state_by_sid_v2471[sid] = {
                    "sort": sort_key_v2471,
                    "sort_dir": sort_dir_v2471 if sort_dir_v2471 in ("asc", "desc") else pkm_library_sort.default_sort_dir(sort_key_v2471),
                    "cache_key": cache_key_v2471,
                }
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.Section.%s.LastTab" % sid, tab)
            except Exception:
                pass
            self._section_tab_state_store_v2471(reason="tab:%s:%s" % (sid, reason or tab))
            _log("SECTION_TAB_REMEMBER_V2471 section=%s tab=%s reason=%s restart_persist=1" % (sid, tab, reason or ""))
        except Exception:
            pass

    def _section_commit_overlay_retire_r35(self, target, reason=""):
        """R35: section ENTER from Info/Actor must retire the overlay (R18 parity).

        R134 made sidebar focus preview-only, so the old menu-focus path that
        released Info (_info_sidebar_hold_release_v2387) is no longer reached by a
        section ENTER.  R18 fixed this for Home only; a section scene was
        therefore committed UNDER the still-visible Info page and the click looked
        ignored until the user went Home.  Called at the destination commit
        boundary, after the target is fully bound.
        """
        try:
            source = str(self._pkm_surface_mode_v2479() or "")
            if source not in ("info", "actor_profile"):
                return False
            armed = getattr(self, "_section_enter_overlay_r35", None)
            owner = str(getattr(self, "active_section_id", "") or "")
            owner_sid = owner.split(":", 1)[1] if ":" in owner else owner
            if (not armed or str(armed[0]) != owner_sid
                    or time.monotonic() - float(armed[1] or 0) > 30.0):
                _log("SECTION_COMMIT_OVERLAY_KEEP_R35 source=%s target=%s owner=%s armed=%s reason=%s" % (
                    source, target, owner, armed[0] if armed else "-", reason or ""))
                return False
            self._section_enter_overlay_r35 = None
            retired = bool(self._pkm_overlay_retire_for_target_v2479(
                target, reason="section_commit_r35:%s" % (reason or "")))
            try:
                self._info_sidebar_hold_v2387 = None
                self._info_clear_property_all("PlexKM.Info.SidebarHoldV2387")
            except Exception:
                pass
            # R38: Search may still sit under a Search-opened Info (sidebar entry
            # is focus-only now).  The section is committed, so retire it too.
            try:
                if retired and (bool(getattr(self, "_search_inline_active", False))
                                or self.getProperty("PlexKM.Search.InlineActive") == "1"
                                or xbmcgui.Window(10000).getProperty("PlexKM.Search.InlineActive") == "1"):
                    self._search_info_sidebar_retire_search_v2284(reason="section_commit_r38")
                    _log("SECTION_COMMIT_SEARCH_RETIRE_R38 target=%s" % target)
            except Exception:
                pass
            _log("SECTION_COMMIT_OVERLAY_RETIRE_R35 source=%s target=%s retired=%d reason=%s" % (
                source, target, 1 if retired else 0, reason or ""))
            return retired
        except Exception:
            _log("SECTION_COMMIT_OVERLAY_RETIRE_FAILED_R35 target=%s err=%s" % (
                target, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _section_action_anchor_arm_v2479(self, cache_key, reason=""):
        try:
            self._section_action_anchor_key_v2479 = str(cache_key or "")
            self._section_action_anchor_started_v2479 = self._now_ms()
            _log("SECTION_ACTION_ANCHOR_V2479 key=%s started_ms=%d reason=%s threshold_ms=1500" % (
                self._section_action_anchor_key_v2479, self._section_action_anchor_started_v2479, reason or ""
            ))
        except Exception:
            pass

    def _show_section_last_tab(self, item, force=False, reason=""):
        sid = self._section_sid_from_item(item)
        tab = self._section_last_tab(sid, default="recommend")
        _log("SECTION_LAST_TAB_RESTORE section=%s tab=%s reason=%s" % (sid, tab, reason or ""))
        if tab == "library":
            self._restore_section_library_state_v2471(sid, reason=reason or "last_tab_library")
            self._show_section_wall(item, force=force)
            return "library"
        if tab == "category":
            self._focus_section_category_tab(reason=reason or "restore_category")
            return "category"
        self._show_section_recommend_widgets(item, force=force)
        return "recommend"

    def _focus_section_recommend_tab(self, reason=""):
        item = self._current_section_menu_item()
        if not item:
            _log("SECTION_TAB_RECOMMEND_SKIPPED reason=%s no_section_item=1" % (reason or ""))
            return False
        self._cancel_pending_sidebar_commit_v2661(reason="tab_recommend:%s" % (reason or ""))
        try:
            self._cancel_sidebar_foreground_owner_v2118(reason="tab_recommend:%s" % (reason or ""))
        except Exception:
            pass
        try:
            _sid_v2479 = self._section_sid_from_item(item)
            self._section_action_anchor_arm_v2479("recommend:%s" % _sid_v2479, reason=reason or "focus_recommend")
            self._remember_section_tab(_sid_v2479, "recommend", reason=reason or "focus_recommend")
            self._show_section_recommend_widgets(item, force=False)
        except Exception:
            _log("SECTION_TAB_RECOMMEND_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False
        return True

    def _focus_section_library_tab(self, reason=""):
        item = self._current_section_menu_item()
        if not item:
            _log("SECTION_TAB_LIBRARY_SKIPPED reason=%s no_section_item=1" % (reason or ""))
            return False
        self._cancel_pending_sidebar_commit_v2661(reason="tab_library:%s" % (reason or ""))
        try:
            self._cancel_sidebar_foreground_owner_v2118(reason="tab_library:%s" % (reason or ""))
        except Exception:
            pass
        previous_filter_v1841 = (
            str(getattr(self, "_active_genre_filter", "") or ""),
            int(getattr(self, "_active_genre_count", 0) or 0),
            str(getattr(self, "_active_genre_section_id", "") or ""),
        )
        try:
            self._restore_section_library_state_v2471(
                self._section_sid_from_item(item), reason=reason or "focus_library"
            )
            self._active_genre_filter = ""
            self._active_genre_count = 0
            self._active_genre_section_id = ""
            # v1823: 범주 탭에서 라이브러리로 돌아올 때 이미 완성된 동일 섹션 월을
            # 강제 재생성하지 않는다. v1822의 force=True는 180개 ListItem을 다시
            # 동기 생성하는 동안 마지막 범주 카드가 화면에 남아 겹쳐 보이게 했다.
            # _show_section_wall()의 기존 same-section/ready-wall fast path가 모드
            # property를 먼저 library로 전환한 뒤 완성된 월을 즉시 재사용한다.
            if self._show_section_wall(item, force=False) is False:
                self._active_genre_filter = previous_filter_v1841[0]
                self._active_genre_count = previous_filter_v1841[1]
                self._active_genre_section_id = previous_filter_v1841[2]
                self._update_category_wall_summary(reason="library_tab_prepare_failed_restore_v1841")
                return False
            self._update_category_wall_summary(reason="library_tab_clear")
            self._remember_section_tab(self._section_sid_from_item(item), "library", reason=reason or "focus_library")
            _log("SECTION_CATEGORY_TO_LIBRARY_REUSE_V1823 section=%s reason=%s" % (
                self._section_sid_from_item(item), reason or "focus_library"))
        except Exception:
            self._active_genre_filter = previous_filter_v1841[0]
            self._active_genre_count = previous_filter_v1841[1]
            self._active_genre_section_id = previous_filter_v1841[2]
            _log("SECTION_TAB_LIBRARY_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False
        return True

    def _focus_section_category_tab(self, reason=""):
        self._cancel_pending_sidebar_commit_v2661(reason="tab_category:%s" % (reason or ""))
        try:
            if self._is_tv_recommend_section(self.active_section_id, self._section_type_for_id(self.active_section_id)):
                _log("SECTION_CATEGORY_BLOCK_TV_V1966 section=%s reason=%s redirect=library" % (self.active_section_id, reason or ""))
                return self._focus_section_library_tab(reason="tv_no_category_v1966") if hasattr(self, "_focus_section_library_tab") else False
        except Exception:
            pass
        item = self._current_section_menu_item()
        if not item:
            _log("SECTION_TAB_CATEGORY_SKIPPED reason=%s no_section_item=1" % (reason or ""))
            return False
        try:
            self._cancel_sidebar_foreground_owner_v2118(reason="tab_category:%s" % (reason or ""))
        except Exception:
            pass
        try:
            sid = self._section_sid_from_item(item)
            # v1841: prepare the target panel before exposing Category mode.
            # A failed DB query or ListItem build must leave the currently
            # complete Recommend/Library view visible; mode-first switching was
            # the direct cause of an empty/category-overlap surface.
            if not self._populate_section_categories(sid, reason=reason):
                _log("SECTION_TAB_CATEGORY_RETAIN_CURRENT_V1841 section=%s reason=%s" % (
                    sid, reason or "category_prepare_failed"
                ), xbmc.LOGWARNING)
                return False
            try:
                self._category_origin_menu_pos = int(self.getControl(MENU_ID).getSelectedPosition())
            except Exception:
                self._category_origin_menu_pos = int(getattr(self, "active_menu_index", -1))
            self._category_origin_section_id = sid
            self._remember_section_tab(sid, "category", reason=reason or "focus_category")
            self._active_genre_filter = ""
            self._active_genre_count = 0
            self._active_genre_section_id = ""
            self._update_category_wall_summary(reason="category_tab_clear")
            win = xbmcgui.Window(10000)
            focus_before_v2120 = self._safe_focus_id()
            source_mode_v2479 = self._pkm_surface_mode_v2479()
            swap_token_v2479 = self._pkm_swap_settle_v2479(
                source_mode_v2479, "section_category", reason="category_target_ready:%s" % (reason or ""), wait_ms=16
            ) if source_mode_v2479 != "section_category" else ""
            for target in (win, self):
                # v2120: Category uses the same destination-first handoff as
                # Library.  Keep the focused header control alive continuously.
                target.setProperty("PlexKM.Window.IsSectionCategory", "1")
                target.clearProperty("PlexKM.Window.IsSectionRecommend")
                target.clearProperty("PlexKM.Window.IsSectionWall")
                target.clearProperty("PlexKM.Window.IsHome")
            try:
                self._set_published_section_id_v2121(
                    sid, reason="section_category_commit:%s" % (reason or "")
                )
            except Exception:
                pass
            try:
                self._search_info_sidebar_ab_commit_v2284(
                    section_id=sid, reason="section_category:%s" % (reason or "")
                )
            except Exception:
                pass
            if swap_token_v2479:
                self._pkm_swap_finish_v2479(
                    swap_token_v2479, source_mode_v2479, "section_category", reason="category_mode_commit:%s" % (reason or "")
                )
            _log("SECTION_MODE_ATOMIC_FOCUS_V2120 mode=category reason=%s focus_before=%s focus_after=%s python_focus_write=0 zero_visibility_gap=0" % (
                reason or "", focus_before_v2120, self._safe_focus_id()
            ))
            _log("SECTION_CATEGORY_COMMIT_READY_V1841 section=%s reason=%s" % (
                sid, reason or ""
            ))
            return True
        except Exception:
            _log("SECTION_TAB_CATEGORY_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _populate_section_categories(self, sid, reason=""):
        try:
            # Query/build first. Native panel contents are not touched until the
            # complete replacement exists in local Python scope.
            rows = list(core.query_section_genres(sid) or [])
            tints = ("99A94F3D", "99714F87", "993B765E", "99913C55", "996B7A2A", "998A5B24", "99377A69", "997A3C75", "995A682C")
            items = []
            for idx, row in enumerate(rows):
                genre, count, art, thumb = row[0], int(row[1] or 0), row[2] or "", row[3] or ""
                li = xbmcgui.ListItem(label=str(genre))
                li.setProperty("PlexKM.Genre", str(genre))
                li.setProperty("PlexKM.GenreCount", str(count))
                li.setProperty("PlexKM.CategoryArt", str(art or thumb))
                li.setProperty("PlexKM.CategoryTint", tints[idx % len(tints)])
                items.append(li)

            panel = self.getControl(SECTION_CATEGORY_PANEL_ID)
            panel.reset()
            if items:
                try:
                    panel.addItems(items)
                except Exception:
                    for li in items:
                        panel.addItem(li)
            self.setProperty("PlexKM.Section.CategoryCount", str(len(items)))
            _log("SECTION_CATEGORY_BUILD_V1822 section=%s categories=%d reason=%s ready_before_commit=1" % (
                sid, len(items), reason or ""
            ))
            return True
        except Exception:
            _log("SECTION_CATEGORY_BUILD_FAILED_V1841 section=%s reason=%s retain_current=1 err=%s" % (
                sid, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _section_category_click(self, reason=""):
        try:
            if self._is_tv_recommend_section(self.active_section_id, self._section_type_for_id(self.active_section_id)):
                _log("SECTION_CATEGORY_BLOCK_TV_V1966 section=%s reason=%s redirect=library" % (self.active_section_id, reason or ""))
                return self._focus_section_library_tab(reason="tv_no_category_v1966") if hasattr(self, "_focus_section_library_tab") else False
        except Exception:
            pass
        try:
            panel = self.getControl(SECTION_CATEGORY_PANEL_ID)
            li = panel.getSelectedItem() if panel and panel.size() else None
            genre = (li.getProperty("PlexKM.Genre") or li.getLabel()) if li else ""
            if not genre:
                return
            previous_filter_v1841 = (
                str(getattr(self, "_active_genre_filter", "") or ""),
                int(getattr(self, "_active_genre_count", 0) or 0),
                str(getattr(self, "_active_genre_section_id", "") or ""),
            )
            self._active_genre_filter = str(genre)
            self._active_genre_count = int(li.getProperty("PlexKM.GenreCount") or 0)
            self._active_genre_section_id = str(self.active_section_id or "")
            if self._show_section_wall(self._current_section_menu_item(), force=True) is False:
                self._active_genre_filter = previous_filter_v1841[0]
                self._active_genre_count = previous_filter_v1841[1]
                self._active_genre_section_id = previous_filter_v1841[2]
                self._update_category_wall_summary(reason="category_select_prepare_failed_restore_v1841")
                _log("SECTION_CATEGORY_SELECT_RETAIN_CURRENT_V1841 section=%s genre=%s reason=%s" % (
                    self.active_section_id, genre, reason or ""
                ), xbmc.LOGWARNING)
                return
            self._remember_section_tab(self.active_section_id, "library", reason="category_selected")
            self._update_category_wall_summary(reason="category_selected")
            try:
                self.setFocusId(WALL_ID)
            except Exception:
                pass
            _log("SECTION_CATEGORY_SELECT_V1822 section=%s genre=%s reason=%s" % (self.active_section_id, genre, reason or ""))
        except Exception:
            _log("SECTION_CATEGORY_SELECT_FAILED_V1822 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _home_row_title_for_section(self, title):
        try:
            value = _display_library_title(title).strip()
            if not value:
                return "최근 추가됨"
            return "최근 %s에 추가됨" % value
        except Exception:
            return "최근 추가됨"

    def _prebuild_section_recommend_rows_cache(self, sid, title, section_type=None, reason=""):
        """Build section recommendation row data without touching visible XML.

        v884: used by the startup background worker so first library switching can
        restore cached rows instead of doing DB row composition on the UI path.
        This does not set focus, reset controls, or render ListItems.
        """
        started = _pkm_speed_ms()
        sid = str(sid or "").strip()
        if not sid or self._closing_event_v1841.is_set():
            return 0
        cache_key = "recommend:%s" % sid
        try:
            if self._section_rows_cache.get(cache_key):
                _speed_log("section_recommend_prewarm_skip", section=sid, title=title or sid, reason="cache_exists", total_ms=_pkm_speed_ms() - started)
                return len(self._section_rows_cache.get(cache_key) or [])
        except Exception:
            pass
        # Background prewarm must not read Kodi controls.  The visible layout is
        # six columns in the current PKM Home/section widget geometry; using the
        # fixed value avoids UI-thread control access from the worker.
        home_columns = 6
        stype = section_type or self._section_type_for_id(sid)
        is_movie_extra_target = self._is_movie_recommend_section(sid, stype)
        is_tv_target = self._is_tv_recommend_section(sid, stype)
        rows_cache = []
        added = 0
        seen_keys = set()
        recent_viewed_rows = []
        try:
            if is_movie_extra_target:
                if self._closing_event_v1841.is_set() or _pkm_full_reset_active_v2150():
                    return 0
                rows_cache = self._build_movie_full_section_rows_v1616(
                    sid, title or sid, base_rows=None, home_columns=home_columns
                ) or []
                if self._closing_event_v1841.is_set() or _pkm_full_reset_active_v2150():
                    return 0
                if rows_cache:
                    self._section_rows_cache[cache_key] = list(rows_cache)
                    self._section_full_rows_ready_v1644.add(cache_key)
                _speed_log("section_recommend_prewarm_done", section=sid, title=title or sid,
                           rows=len(rows_cache), added=len(rows_cache), tv=0, movie=1,
                           reason=reason or "", full_scene=1,
                           total_ms=_pkm_speed_ms() - started)
                return len(rows_cache)

            if self._closing_event_v1841.is_set() or _pkm_full_reset_active_v2150():
                return 0
            continue_rows = self._section_continue_rows(
                    sid, limit=max(120, HOME_ROW_ITEM_LIMIT), local_first_v2589=True
                )
            for row in continue_rows or []:
                try:
                    rk = str((tuple(row or ())[0]) or "")
                    if rk:
                        seen_keys.add(rk)
                except Exception:
                    pass
            added = self._append_recommend_row_items(None, rows_cache, "이어보기", continue_rows, sid, added)

            if self._closing_event_v1841.is_set() or _pkm_full_reset_active_v2150():
                return 0
            if is_tv_target:
                extra_rows = self._build_tv_requested_rows_cache(sid, title or "라이브러리", home_columns, added, exclude_keys=seen_keys)
                if extra_rows:
                    rows_cache.extend(extra_rows)
                    added += len(extra_rows)
            else:
                if is_movie_extra_target:
                    row_plan = [("viewed", "최근 본 영화", None), ("added", "최근 추가됨", None)]
                else:
                    row_plan = [("added", self._section_recommend_row_title(title or "라이브러리", "added"), None), ("viewed", self._section_recent_viewed_row_title(title or "라이브러리"), None)]
                for sort_name, row_title, plex_type in row_plan:
                    if self._closing_event_v1841.is_set() or _pkm_full_reset_active_v2150():
                        return 0
                    visible_rows = self._query_section_rows_for_widget(sid, sort_name, row_title, home_columns, seen_keys=seen_keys, plex_type=plex_type)
                    if sort_name == "viewed":
                        recent_viewed_rows = list(visible_rows or [])
                    added = self._append_recommend_row_items(None, rows_cache, row_title, visible_rows, sid, added)
            if rows_cache:
                self._section_rows_cache[cache_key] = rows_cache
                self._section_full_rows_ready_v1644.add(cache_key)
                # v1841: this method is a data-only worker path. Cast artwork
                # warming has its own bounded queue and must not be chained here.
            _speed_log("section_recommend_prewarm_done", section=sid, title=title or sid, rows=len(rows_cache or []), added=added, tv=1 if is_tv_target else 0, movie=1 if is_movie_extra_target else 0, reason=reason or "", total_ms=_pkm_speed_ms() - started)
            return len(rows_cache or [])
        except Exception:
            _log("SECTION_RECOMMEND_PREWARM_FAILED section=%s title=%s err=%s" % (sid, _short_log_value(title or sid), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _section_group_rows_v1644(self, rows_cache):
        grouped, current, current_id = [], [], None
        for entry in rows_cache or []:
            if not isinstance(entry, dict):
                continue
            rid = entry.get("row_id") or entry.get("row_title") or "row"
            if current and rid != current_id:
                grouped.append(current)
                current = []
            current_id = rid
            current.append(entry)
        if current:
            grouped.append(current)
        return grouped

    def _consume_plex_update_section_dirty(self, section_id, reason="", force=False):
        try:
            sid = str(section_id or "")
            try:
                win_v1644 = xbmcgui.Window(10000)
                if win_v1644.getProperty("PlexKM.RuntimeWidgetUpdatesDisabledV1644") == "1":
                    self._plex_update_dirty_sections.discard(sid)
                    win_v1644.clearProperty("PlexKM.PlexUpdate.Dirty")
                    win_v1644.clearProperty("PlexKM.PlexUpdate.Sections")
                    return False
            except Exception:
                pass
            global_dirty = False
            try:
                parts = [x.strip() for x in (xbmcgui.Window(10000).getProperty("PlexKM.PlexUpdate.Sections") or "").split(",") if x.strip()]
                global_dirty = bool(sid and sid in parts)
            except Exception:
                global_dirty = False
            if force or not sid or (sid not in self._plex_update_dirty_sections and not global_dirty):
                return False
            self._plex_update_dirty_sections.discard(sid)
            # v883: do not delete the already-renderable recommendation cache here.
            # A dirty flag means Plex/DB should be refreshed, but removing the cache
            # forces a synchronous rebuild on sidebar focus and makes TV libraries
            # appear late.  Keep the cache for immediate first paint; the startup/
            # watcher sync refreshes the DB in the background and the next rebuild
            # can use updated rows without blanking the UI.
            _log("PLEX_UPDATE_DIRTY_CONSUME scope=section section=%s reason=%s action=keep_cache_background_refresh" % (sid, reason or ""))
            return True
        except Exception:
            return False

    def _section_recommend_row_title(self, section_title, sort_name="added"):
        title = _display_library_title(section_title).strip()
        if sort_name == "year":
            if "영화" in title:
                return "최근 개봉한 영화"
            if "드라마" in title or "TV" in title.upper() or "쇼" in title:
                return "최근 방영한 드라마"
            return "최근 공개된 %s" % title if title else "최근 공개됨"
        if "영화" in title:
            return "최근 영화에 추가됨"
        if "드라마" in title or "TV" in title.upper() or "쇼" in title:
            return "최근 드라마에 추가됨"
        return "최근 %s에 추가됨" % title if title else "최근 추가됨"

    def _section_recent_viewed_row_title(self, section_title):
        title = _display_library_title(section_title).strip()
        if "영화" in title:
            return "최근 본 영화"
        if "드라마" in title or "TV" in title.upper() or "쇼" in title:
            return "최근 본 드라마"
        return "최근 본 %s" % title if title else "최근 본 항목"

    def _section_type_for_id(self, section_id):
        """Return Plex library section type without relying on the visible title."""
        sid = str(section_id or "").strip()
        if not sid:
            return ""
        try:
            for section in getattr(self, "sections", []) or []:
                if str(section.get("section_id", "")).strip() == sid:
                    return str(section.get("section_type", "") or "").lower().strip()
        except Exception:
            pass
        try:
            section = core.get_section(sid)
            if section:
                return str(section.get("section_type", "") or "").lower().strip()
        except Exception:
            pass
        return ""

    def _section_movie_item_ratio(self, section_id):
        """Best-effort fallback for old DBs where section_type is missing.

        This does not use library names.  It inspects the synced item content
        type distribution in the local DB and returns (movie_count, total_count).
        """
        sid = str(section_id or "").strip()
        if not sid:
            return (0, 0)
        try:
            conn = core.init_db()
            row = conn.execute(
                "SELECT SUM(CASE WHEN plex_type='movie' THEN 1 ELSE 0 END), COUNT(*) FROM items WHERE section_id=?",
                (sid,),
            ).fetchone()
            movie_count = int((row[0] if row else 0) or 0)
            total_count = int((row[1] if row else 0) or 0)
            return (movie_count, total_count)
        except Exception:
            return (0, 0)

    def _is_movie_recommend_section(self, section_id, section_type=""):
        """Return True for Plex movie sections without title/name hardcoding."""
        try:
            sid = str(section_id or "").strip()
            stype = str(section_type or "").lower().strip() or self._section_type_for_id(sid)
            if stype == "movie":
                _speed_log("section_recommend_movie_detect", section=sid, source="section_type", section_type=stype, result=1)
                return True
            if stype:
                _speed_log("section_recommend_movie_detect", section=sid, source="section_type", section_type=stype, result=0)
                return False
            movie_count, total_count = self._section_movie_item_ratio(sid)
            result = bool(total_count > 0 and movie_count >= max(1, int(total_count * 0.8)))
            _speed_log("section_recommend_movie_detect", section=sid, source="db_ratio", movie_count=movie_count, total=total_count, result=1 if result else 0)
            return result
        except Exception:
            return False

    def _section_continue_rows(self, section_id, limit=None, local_first_v2589=False):
        """Continue Watching for only the focused library section.

        Home and Section Recommend must never maintain different Continue
        membership. The Home composition publishes the current logical Continue
        rows after watched/duplicate-resolution/resume reconciliation; section
        rows reuse that authority directly.

        If a section is opened before Home has published the authority, fall back
        to the same membership filter for that section only.
        """
        sid = str(section_id or "").strip()
        if not sid:
            return []

        rows = []
        try:
            self._continue_authority_refresh_if_stale_r33(reason="section:%s" % sid)
        except Exception:
            pass
        authority_rows = list(getattr(self, "_continue_membership_authority_rows", None) or [])
        if authority_rows:
            rows = authority_rows
            _log(
                "SECTION_CONTINUE_AUTHORITY section=%s source=home_membership rows=%d" %
                (sid, len(rows))
            )
        else:
            try:
                raw_rows = core.query_continue_watching_wall_light(
                    limit=max(120, int(limit or HOME_ROW_ITEM_LIMIT)),
                    prefer_preload=True,
                    allow_network=not bool(local_first_v2589),
                    stale_preload_max_age=604800 if local_first_v2589 else None,
                )
            except Exception:
                raw_rows = []

            section_candidates = []
            for row in list(raw_rows or []):
                try:
                    values = tuple(row or ())
                    if str(values[1] if len(values) > 1 else "") == sid:
                        section_candidates.append(row)
                except Exception:
                    continue

            try:
                rows = self._home_filter_continue_membership(
                    section_candidates, publish_authority=False
                )
            except Exception:
                rows = section_candidates
                _log(
                    "SECTION_CONTINUE_AUTHORITY_FALLBACK_FAILED section=%s err=%s" % (
                        sid, traceback.format_exc().replace(chr(10), " | ")
                    ),
                    xbmc.LOGWARNING,
                )

            _log(
                "SECTION_CONTINUE_AUTHORITY section=%s source=section_fallback raw=%d validated=%d network=%d" % (
                    sid, len(section_candidates), len(rows or []),
                    0 if local_first_v2589 else 1,
                )
            )

        out = []
        seen_movies = set()
        seen_tv = set()
        for row in rows or []:
            try:
                t = tuple(row or ())
                if str(t[1] if len(t) > 1 else "") != sid:
                    continue
                plex_type = str(t[2] if len(t) > 2 else "")
                title = str(t[4] if len(t) > 4 else "").strip()
                year = str(t[7] if len(t) > 7 else "").strip()

                if plex_type == "movie" and title:
                    key = ("movie", " ".join(title.lower().split()), year)
                    if key in seen_movies:
                        continue
                    seen_movies.add(key)
                elif plex_type in ("episode", "show"):
                    key = self._tv_visual_dedup_key_from_row(row)
                    if key:
                        if key in seen_tv:
                            try:
                                rk = str(t[0] if len(t) > 0 else "")
                                _log(
                                    "SECTION_CONTINUE_SKIP_DUP_SHOW section=%s key=%s rating_key=%s title=%s" %
                                    (sid, key, rk, title)
                                )
                            except Exception:
                                pass
                            continue
                        seen_tv.add(key)

                out.append(row)
                if len(out) >= SECTION_RECOMMEND_RESUME_REWATCH_LIMIT_R154:
                    break
            except Exception:
                continue

        _log(
            "SECTION_CONTINUE_AUTHORITY_RESULT section=%s visible=%d authority_total=%d" %
            (sid, len(out), len(rows or []))
        )
        return out

    def _section_rows_group_count(self, rows_cache):
        try:
            return len(self._section_rows_grouped(rows_cache))
        except Exception:
            return 0

    def _query_section_rows_for_widget(self, sid, sort_name, row_title, home_columns, seen_keys=None, plex_type=None):
        """Query one recommendation widget row and remove already-used items."""
        row_query_start = _pkm_speed_ms()
        try:
            rows = core.query_items_wall_light(
                sid,
                sort=sort_name,
                limit=max(SECTION_RECOMMEND_DEFAULT_LIMIT_R154 * 2, max(int(home_columns or 6) * 2, int(home_columns or 6) + 4)),
                offset=0,
                plex_type=plex_type,
            )
            query_status = "ok"
        except Exception:
            rows = []
            query_status = "error"
        _speed_log("section_recommend_core_row_query", section=sid, sort=sort_name, title=row_title, plex_type=plex_type or "", source_rows=len(rows or []), status=query_status, query_ms=_pkm_speed_ms() - row_query_start)
        visible_rows = []
        seen = seen_keys if isinstance(seen_keys, set) else set()
        seen_tv = set()
        for row in rows or []:
            try:
                t = tuple(row or ())
                rk = str((t[0] if len(t) > 0 else "") or "")
            except Exception:
                t = ()
                rk = ""
            if rk and rk in seen:
                continue
            tv_key = self._tv_visual_dedup_key_from_row(row)
            if tv_key:
                if tv_key in seen_tv:
                    continue
                seen_tv.add(tv_key)
            if rk:
                seen.add(rk)
            visible_rows.append(row)
            if len(visible_rows) >= SECTION_RECOMMEND_DEFAULT_LIMIT_R154:
                break
        return visible_rows

    def _shuffle_recommend_rows(self, rows, section_id, base_key, rec_type):
        try:
            rows = list(rows or [])
            # v193: make this intentionally non-deterministic.  The previous
            # seeded shuffle could look fixed across short test cycles and cached
            # candidates.  For recommendation rows, variety is more important
            # than reproducibility.
            random.SystemRandom().shuffle(rows)
            return rows
        except Exception:
            try:
                random.shuffle(rows)
            except Exception:
                pass
            return list(rows or [])

    def _section_rows_grouped(self, rows_cache):
        return pkm_recommend_data.section_rows_grouped(rows_cache)

    def _movie_rows_from_section_filter(self, section_id, section_title, filter_name, filter_id, exclude_keys=None, limit=10, sort="audienceRating:desc", country_mode="any", min_score=None, require_rating=True):
        """Movie-only recommendation helper for rows 4~6.

        If filter_name/filter_id are empty, this works as a broad high-rated
        fallback for the section.  That fallback is used only to make sparse
        recommendation rows reach a useful minimum size.
        """
        speed_start = _pkm_speed_ms()
        rows = []
        sid = str(section_id or "").strip()
        fid = str(filter_id or "").strip()
        fname = str(filter_name or "").strip()
        mode = str(country_mode or "any")
        status = "ok"
        request_size = 0
        try:
            if not sid:
                status = "missing_section"
                return []
            if fname and not fid:
                status = "missing_filter"
                return []
            want = max(1, int(limit or 10))
            # Request a moderate candidate pool then shuffle.  Large sorted pools
            # are expensive on big Plex sections, so keep this bounded.
            request_size = min(max(want * 6, 48), 72)
            request_timeout = 3
            # v208: person rows are not rating-filtered and can be sparse; keep
            # their filter request small and short so a slow director/actor does
            # not delay all extra widgets.
            if fname in ("director", "actor") and not require_rating:
                request_size = min(max(want * 4, 24), 48)
                request_timeout = 1
            params = {
                "type": "1",
                "sort": sort,
                "X-Plex-Container-Start": 0,
                "X-Plex-Container-Size": request_size,
            }
            if fname and fid:
                params[fname] = fid
            req_start = _pkm_speed_ms()
            root = core.plex_request_xml("/library/sections/%s/all" % sid, params=params, timeout=3)
            request_ms = _pkm_speed_ms() - req_start
            if root is None:
                status = "no_root"
                _speed_log("movie_extra_filter_request", section=sid, filter=fname or "all", filter_id=fid, country_mode=mode, request_size=request_size, request_ms=request_ms, rows=0, status=status)
                return []
            excluded = set(str(x) for x in (exclude_keys or set()) if x)
            seen = set()
            candidates = []
            rating_missing = 0
            rating_below = 0
            rating_seen = 0
            poster_missing = 0
            rating_samples = []
            selected_scores = []
            min_score_value = float(self._movie_extra_score_threshold() if min_score is None else min_score)
            require_rating = bool(require_rating)
            for node in list(root):
                if getattr(node, "tag", "") != "Video":
                    continue
                rk = str(node.get("ratingKey") or node.get("key") or "").strip()
                if rk and (rk in excluded or rk in seen):
                    continue
                is_korean = self._node_is_korean_movie(node)
                if mode == "korean" and not is_korean:
                    continue
                if mode == "foreign" and is_korean:
                    continue
                audience, rating, user_rating, score = self._movie_extra_rating_values(node)
                if score is None:
                    rating_missing += 1
                    if len(rating_samples) < 5:
                        rating_samples.append("%s:a=:r=:u=:s=" % (rk or ""))
                    if require_rating:
                        continue
                else:
                    rating_seen += 1
                    if score < min_score_value:
                        rating_below += 1
                        if len(rating_samples) < 5:
                            rating_samples.append("%s:a=%s:r=%s:u=%s:s=%.1f" % (rk or "", audience if audience is not None else "", rating if rating is not None else "", user_rating if user_rating is not None else "", score))
                        if require_rating:
                            continue
                    if len(rating_samples) < 5:
                        rating_samples.append("%s:a=%s:r=%s:u=%s:s=%s" % (rk or "", audience if audience is not None else "", rating if rating is not None else "", user_rating if user_rating is not None else "", ("%.1f" % score) if score is not None else ""))
                try:
                    item = core.extract_item(node, sid, "movie")
                    row = core._wall_light_row_from_item_dict(item)
                    if not self._recommend_row_has_poster(row):
                        poster_missing += 1
                        continue
                    candidates.append(row)
                    if score is not None:
                        selected_scores.append(score)
                    if rk:
                        seen.add(rk)
                except Exception:
                    continue
            candidates = self._shuffle_recommend_rows(candidates, sid, "%s:%s" % (fname or "all", fid), mode)
            rows = candidates[:want]
            _speed_log("movie_extra_rating_probe", section=sid, filter=fname or "all", filter_id=fid, country_mode=mode, rating_min=min_score_value, require_rating=1 if require_rating else 0, rating_seen=rating_seen, rating_missing=rating_missing, rating_below=rating_below, poster_missing=poster_missing, selected_scores=",".join(["%.1f" % x for x in selected_scores[:10]]), samples=" | ".join(rating_samples))
            _speed_log("movie_extra_filter_request", section=sid, filter=fname or "all", filter_id=fid, country_mode=mode, request_size=request_size, request_ms=request_ms, candidates=len(candidates), rows=len(rows), status=status, rating_min=min_score_value, require_rating=1 if require_rating else 0, rating_missing=rating_missing, rating_below=rating_below, poster_missing=poster_missing)
        except Exception:
            status = "error"
            _log("MOVIE_EXTRA_FILTER_FAILED section=%s filter=%s id=%s mode=%s\n%s" % (
                section_id, filter_name, filter_id, mode, traceback.format_exc()), xbmc.LOGWARNING)
        finally:
            _speed_log("movie_extra_filter_total", section=sid, filter=fname or "all", filter_id=fid, country_mode=mode, rows=len(rows), status=status, total_ms=_pkm_speed_ms() - speed_start)
        return rows

    def _movie_rows_from_movie_sections(self, section_id, section_title, filter_name, filter_id, exclude_keys=None, limit=10, sort="audienceRating:desc", country_mode="any", allow_broad_fallback=True, min_score=None, require_rating=True):
        """Collect recommendation rows from the current movie section only.

        v194: Do not borrow candidates from other movie libraries.  This is
        required for split libraries such as 4K, ADD, latest, etc. where the
        section itself encodes a quality/source constraint.  Sparse rows may be
        broadened only inside the same section, never across sections.
        """
        sid = str(section_id or "").strip()
        want = max(1, int(limit or 10))
        excluded = set(str(x) for x in (exclude_keys or set()) if x)
        unique = set()
        collected = []

        def add_rows(rows):
            for r in rows or []:
                try:
                    rk = str((tuple(r or ())[0]) or "")
                    if rk and rk in excluded:
                        continue
                    uk = self._movie_extra_unique_key(r) or rk
                    if uk and uk in unique:
                        continue
                    if rk:
                        excluded.add(rk)
                    if uk:
                        unique.add(uk)
                    collected.append(r)
                    if len(collected) >= want:
                        return True
                except Exception:
                    continue
            return len(collected) >= want

        if sid:
            rows = self._movie_rows_from_section_filter(sid, section_title, filter_name, filter_id, exclude_keys=excluded, limit=want, sort=sort, country_mode=country_mode, min_score=min_score, require_rating=require_rating)
            add_rows(rows)

        if len(collected) < want and allow_broad_fallback and sid:
            before = len(collected)
            # Broaden within the same section only.  This can fill sparse genre
            # rows while still respecting section constraints such as 4K.
            rows = self._movie_rows_from_section_filter(sid, section_title, "", "", exclude_keys=excluded, limit=want, sort=sort, country_mode=country_mode, min_score=min_score, require_rating=require_rating)
            add_rows(rows)
            _speed_log("movie_extra_broad_fallback", section=section_id, filter=filter_name or "all", filter_id=filter_id, country_mode=country_mode, scope="current_section_only", before=before, after=len(collected), target=want)

        collected = self._shuffle_recommend_rows(collected, section_id, "%s:%s" % (filter_name or "all", filter_id or ""), "section_only:%s" % country_mode)
        return collected[:want]

    def _movie_global_section_ids(self, preferred_sid):
        """Return all movie section ids, with current section first.

        v210: taste rows stay section-only, but director/actor rows can use the
        whole movie pool so sparse sections still produce useful person widgets.
        This uses Plex section type / DB item type, not title hardcoding.
        """
        ids = []
        preferred = str(preferred_sid or "").strip()
        if preferred and self._is_movie_recommend_section(preferred, ""):
            ids.append(preferred)
        try:
            for sec in getattr(self, "sections", None) or []:
                try:
                    sid = str(sec.get("key") or sec.get("section_id") or "").strip()
                    if not sid or sid in ids:
                        continue
                    stype = str(sec.get("type") or sec.get("section_type") or "").strip().lower()
                    if self._is_movie_recommend_section(sid, stype):
                        ids.append(sid)
                except Exception:
                    continue
        except Exception:
            pass
        _speed_log("movie_extra_global_movie_sections", preferred=preferred, sections=",".join(ids), count=len(ids))
        return ids

    def _section_update_extra_row_controls(self, extra_rows_cache, start_row_index=3, reason=""):
        """Append/update lower recommendation rows without resetting the first 3 rows."""
        try:
            grouped = []
            current = []
            current_id = None
            for entry in extra_rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)

            active_ids_v1612 = self._section_active_row_ids_v1612()
            active_bank_v1612 = self._section_bank_name_v1612()
            updated_rows = 0
            updated_items = 0
            for offset, entries in enumerate(grouped):
                row_idx = int(start_row_index or 0) + offset
                if row_idx >= len(active_ids_v1612):
                    break
                cid = active_ids_v1612[row_idx]
                try:
                    ctrl = self.getControl(cid)
                    ctrl.reset()
                except Exception:
                    try:
                        _log("INFO_MOVIE_WIDGETS_RENDER_CONTROL_MISSING reason=%s control=%s err=%s" % (
                            reason or "", cid, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    continue
                title0 = ""
                if entries:
                    title0 = entries[0].get("row_title", "") or ""
                try:
                    self.setProperty(self._section_bank_title_property_v1612(active_bank_v1612, row_idx), _display_library_title(title0))
                except Exception:
                    pass
                for item_idx, entry in enumerate(entries):
                    try:
                        li = self._li_from_row(
                            entry.get("row"),
                            row_title=_display_library_title(entry.get("row_title", "")),
                            row_type=entry.get("row_type", ""),
                            row_first=(item_idx == 0),
                            row_id=entry.get("row_id", ""),
                            row_start=0,
                            row_index=item_idx,
                        )
                        ctrl.addItem(li)
                        updated_items += 1
                    except Exception:
                        pass
                if entries:
                    updated_rows += 1
                    # v349: keep Kodi XML-only navigation stable after deferred movie
                    # extra rows are published.  The XML <ondown> moves focus, but
                    # the row-anchor scroll code uses _section_visible_row_controls
                    # to calculate the visible row index.  Without appending the
                    # newly populated lower controls here, 8440/8450/8460/8470 can
                    # receive focus while the anchor list still says only
                    # 8410~8430 exist, causing DOWN/scroll to appear stuck.
                    try:
                        if cid not in self._section_visible_row_controls:
                            self._section_visible_row_controls.append(cid)
                    except Exception:
                        pass
            try:
                # Preserve XML order and remove accidental duplicates.
                visible = []
                for cid in active_ids_v1612:
                    try:
                        if cid in self._section_visible_row_controls and self.getControl(cid).size() > 0:
                            visible.append(cid)
                    except Exception:
                        pass
                self._section_visible_row_controls = visible
            except Exception:
                pass
            _speed_log("movie_extra_rows_ui_update", reason=reason, rows=updated_rows, items=updated_items, start_row_index=start_row_index, visible_rows=",".join(str(x) for x in getattr(self, "_section_visible_row_controls", [])))
            return updated_items
        except Exception:
            _log("MOVIE_EXTRA_ROWS_UI_UPDATE_FAILED reason=%s err=%s" % (reason, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _recommend_db_row_art_stats(self, rows):
        return pkm_movie_recommend.db_row_art_stats(rows)

    def _build_movie_full_section_rows_v1616(self, sid, title, base_rows=None, home_columns=6):
        """Build every movie recommendation row off-screen without touching Kodi controls.

        The visible A/B bank is not reset while this runs. Core rows are always
        ordered first, and the four expensive movie rows are appended only after
        Recent Added has been secured.
        """
        sid = str(sid or "").strip()
        rows_cache = list(base_rows or [])
        base_titles_v1616 = self._movie_full_compose_group_titles_v1616(rows_cache)
        if rows_cache and not self._movie_full_compose_titles_valid_v1616(base_titles_v1616, require_extra=False):
            _log("MOVIE_FULL_COMPOSE_BASE_REBUILD_V1616 section=%s malformed_titles=%s" % (
                sid, "|".join(base_titles_v1616)
            ), xbmc.LOGWARNING)
            rows_cache = []
        added = len(rows_cache)
        recent_viewed_rows = []
        try:
            RECOMMEND_BUILD_CONTEXT_V1616.data_only = True
            if not rows_cache:
                seen_keys = set()
                continue_rows = self._section_continue_rows(
                    sid, limit=max(120, HOME_ROW_ITEM_LIMIT), local_first_v2589=True
                )
                for row in continue_rows or []:
                    try:
                        rk = str((tuple(row or ())[0]) or "")
                        if rk:
                            seen_keys.add(rk)
                    except Exception:
                        pass
                added = self._append_recommend_row_items(None, rows_cache, "이어보기", continue_rows, sid, added)

                recent_viewed_rows = self._query_section_rows_for_widget(
                    sid, "viewed", "최근 본 영화", home_columns, seen_keys=seen_keys, plex_type=None
                )
                added = self._append_recommend_row_items(
                    None, rows_cache, "최근 본 영화", recent_viewed_rows, sid, added
                )
                recent_added_rows = self._query_section_rows_for_widget(
                    sid, "added", "최근 추가됨", home_columns, seen_keys=seen_keys, plex_type=None
                )
                added = self._append_recommend_row_items(
                    None, rows_cache, "최근 추가됨", recent_added_rows, sid, added
                )
            else:
                try:
                    for entry in rows_cache:
                        if isinstance(entry, dict) and _display_library_title(entry.get("row_title", "") or "") == "최근 본 영화":
                            recent_viewed_rows.append(entry.get("row"))
                except Exception:
                    recent_viewed_rows = []

            titles_before = self._movie_full_compose_group_titles_v1616(rows_cache)
            if not self._movie_full_compose_titles_valid_v1616(titles_before, require_extra=False):
                # A malformed legacy cache must never be repaired by appending the
                # core row after taste rows. Rebuild core ordering from scratch.
                _log("MOVIE_FULL_COMPOSE_CORE_ORDER_INVALID_V1616 section=%s titles=%s" % (
                    sid, "|".join(titles_before)
                ), xbmc.LOGWARNING)
                return []

            if "최근 추가됨" not in titles_before:
                _log("MOVIE_FULL_COMPOSE_ABORT_V1616 section=%s reason=recent_added_missing titles=%s" % (
                    sid, "|".join(titles_before)
                ), xbmc.LOGWARNING)
                return []

            extra_rows = self._build_movie_extra_rows_cache(
                sid, title, recent_viewed_rows, home_columns, added, allow_live_update=False
            )
            full_rows = rows_cache + list(extra_rows or [])
            _log("MOVIE_FULL_COMPOSE_ROWS_V1616 section=%s groups=%s items=%d core_items=%d extra_items=%d" % (
                sid, "|".join(self._movie_full_compose_group_titles_v1616(full_rows)),
                len(full_rows), len(rows_cache), len(extra_rows or [])
            ))
            return full_rows
        except Exception:
            _log("MOVIE_FULL_COMPOSE_BUILD_FAILED_V1616 section=%s err=%s" % (
                sid, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return []
        finally:
            try:
                RECOMMEND_BUILD_CONTEXT_V1616.data_only = False
            except Exception:
                pass

    def _recommend_row_has_poster(self, row):
        return pkm_recommend_data.recommend_row_has_poster(row)

    def _filter_recommend_rows_with_posters(self, rows, row_title="", section_id="", source=""):
        return pkm_recommend_data.filter_recommend_rows_with_posters(
            rows,
            row_title=row_title,
            section_id=section_id,
            source=source,
            speed_log=_speed_log,
            short_log_value=_short_log_value,
        )

    def _filter_recommend_rows_selected_libraries_v1613(self, rows, row_title="", target_section_id=""):
        """Final visibility guard for every section recommendation row.

        v1613 keeps v1612 A/B rendering untouched. It only removes source items
        whose own section_id is not checked in PKM library selection. This also
        protects against an old in-memory row cache created before the filter.
        """
        source_rows = list(rows or [])
        if not source_rows:
            return []
        try:
            c = _ensure_core()
            selected, configured = c.selected_sections_state()
            allowed = set(str(x) for x in (selected or []) if str(x or "").strip())
            if not configured or not allowed:
                _log("RECOMMEND_SELECTED_LIBRARY_FILTER_V1979 target=%s title=%s before=%d after=0 configured=%d rule=selection_intersection" % (
                    str(target_section_id or ""), _short_log_value(row_title or ""), len(source_rows), 1 if configured else 0
                ))
                return []
            kept = []
            dropped = []
            for row in source_rows:
                source_sid = ""
                try:
                    if isinstance(row, dict):
                        source_sid = str(row.get("section_id") or row.get("library_section_id") or "").strip()
                    else:
                        values = tuple(row or ())
                        if len(values) > 1:
                            source_sid = str(values[1] or "").strip()
                except Exception:
                    source_sid = ""
                if source_sid and source_sid not in allowed:
                    dropped.append(source_sid)
                    continue
                kept.append(row)
            if dropped:
                _log("RECOMMEND_SELECTED_LIBRARY_FILTER_V1613 target=%s title=%s before=%d after=%d dropped_sections=%s selected=%s" % (
                    str(target_section_id or ""), _short_log_value(row_title or ""), len(source_rows), len(kept),
                    ",".join(sorted(set(dropped))), ",".join(sorted(allowed))
                ))
            return kept
        except Exception:
            _log("RECOMMEND_SELECTED_LIBRARY_FILTER_FAILED_V1613 target=%s title=%s err=%s" % (
                str(target_section_id or ""), _short_log_value(row_title or ""), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return source_rows

    def _append_recommend_row_items(self, wall, rows_cache, row_title, rows, section_id, added):
        row_title = _display_library_title(row_title)
        if not rows:
            return added
        rows = self._filter_recommend_rows_selected_libraries_v1613(rows, row_title=row_title, target_section_id=section_id)
        if not rows:
            return added
        rows = self._filter_recommend_rows_with_posters(rows, row_title=row_title, section_id=section_id, source="append")
        row_limit_r154 = (SECTION_RECOMMEND_RESUME_REWATCH_LIMIT_R154
                          if row_title in ("이어보기", "다시 보기")
                          else SECTION_RECOMMEND_DEFAULT_LIMIT_R154)
        rows = self._dedup_tv_visual_rows(rows, reason="section_recommend:%s" % (row_title or ""), limit=row_limit_r154)
        rows = list(rows or [])[:row_limit_r154]
        if not rows:
            return added
        row_start = int(added or 0)
        row_id = "recommend:%s:%s" % (section_id, row_start)
        data_only_v1616 = bool(getattr(RECOMMEND_BUILD_CONTEXT_V1616, "data_only", False))
        if not data_only_v1616:
            try:
                self._preload_visible_row_ratings(rows, reason="append_recommend:%s" % (row_title or ""))
            except Exception:
                pass
        new_entries_v1341 = []
        for idx, row in enumerate(rows):
            entry = {
                "row_title": row_title,
                "row_type": "section_recommend",
                "section_id": section_id,
                "row_first": idx == 0,
                "row_id": row_id,
                "row_start": row_start,
                "row_index": idx,
                "row": row,
                "r154_policy": SECTION_RECOMMEND_POLICY_R154,
            }
            rows_cache.append(entry)
            new_entries_v1341.append(entry)
            try:
                if wall is not None:
                    wall.addItem(self._li_from_row(row, row_title=row_title, row_type="section_recommend", row_first=(idx == 0), row_id=row_id, row_start=row_start, row_index=idx))
            except Exception:
                pass
            added += 1
        if not data_only_v1616:
            try:
                self._schedule_important_row_cast_prewarm_v1341(
                    new_entries_v1341,
                    row_title=row_title,
                    reason="append_recommend_priority_v1341:%s" % (row_title or ""),
                )
            except Exception:
                pass
        return added


    def _section_clear_prev_recommend_row_controls(self, clear_visible=True):
        """v988: clear the visual-only previous recommendation buffer 8610~8670."""
        try:
            # v2385: bank B is a native grouplist; clearing its row containers
            # must not write any physical Y position from Python.
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
            for idx, cid in enumerate(SECTION_RECOMMEND_PREV_ROW_IDS):
                try:
                    self.getControl(cid).reset()
                except Exception:
                    pass
                try:
                    self.clearProperty("PlexKM.SectionPrev.Row%d.Title" % idx)
                except Exception:
                    pass
            if clear_visible:
                try:
                    self.clearProperty("PlexKM.SectionTransitionPrevVisible")
                except Exception:
                    pass
        except Exception:
            pass

    def _home_current_visible_rows_for_section_prev(self, max_rows=7):
        """v994: Home -> library first movement A/B source.

        Use the actual grouped Home rows currently rendered in XML controls, not the
        full _home_rows_cache.  This prevents the v991-style startup oddity where the
        full background Home render could be captured while it was still changing.
        """
        try:
            grouped = getattr(self, "_home_row_items_cache", None) or []
            if grouped:
                out = []
                for group in grouped[:max(1, int(max_rows or 7))]:
                    for entry in group or []:
                        if isinstance(entry, dict):
                            out.append(entry)
                return out
        except Exception:
            pass
        try:
            rows = getattr(self, "_home_rows_cache", None) or []
            # Fallback only.  Keep it small and group-aware so this is still a visual
            # snapshot, not the entire Home data cache.
            grouped = []
            current = []
            current_id = None
            for entry in rows:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                    if len(grouped) >= max(1, int(max_rows or 7)):
                        break
                current_id = rid
                current.append(entry)
            if current and len(grouped) < max(1, int(max_rows or 7)):
                grouped.append(current)
            out = []
            for group in grouped[:max(1, int(max_rows or 7))]:
                for entry in group or []:
                    if isinstance(entry, dict):
                        out.append(entry)
            return out
        except Exception:
            return []


    def _section_render_prev_xml_rows(self, rows_cache, reason=""):
        """v988: render the currently visible recommendation rows into visual-only previous buffer.

        This is the sidebar A/B transition: the old screen is copied into 8610~8670,
        then the real focusable rows 8410~8470 are rebuilt with the new section data.
        The old buffer fades out after the new rows are ready.  No black cover and no blank hold.
        """
        try:
            if not rows_cache:
                self._section_clear_prev_recommend_row_controls(clear_visible=True)
                return 0
            self._section_clear_prev_recommend_row_controls(clear_visible=False)
            grouped = []
            current = []
            current_id = None
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            rendered_rows = 0
            rendered_items = 0
            for row_idx, entries in enumerate(grouped[:len(SECTION_RECOMMEND_PREV_ROW_IDS)]):
                ctrl = self.getControl(SECTION_RECOMMEND_PREV_ROW_IDS[row_idx])
                try:
                    title0 = entries[0].get("row_title", "") if entries else ""
                    self.setProperty("PlexKM.SectionPrev.Row%d.Title" % row_idx, _display_library_title(title0 or ""))
                except Exception:
                    pass
                for item_idx, entry in enumerate(entries):
                    li = self._li_from_row(
                        entry.get("row"),
                        row_title=_display_library_title(entry.get("row_title", "")),
                        row_type=entry.get("row_type", ""),
                        row_first=(item_idx == 0),
                        row_id=entry.get("row_id", ""),
                        row_start=0,
                        row_index=item_idx,
                    )
                    ctrl.addItem(li)
                    rendered_items += 1
                if ctrl.size() > 0:
                    try:
                        ctrl.selectItem(0)
                    except Exception:
                        pass
                    rendered_rows += 1
            if rendered_rows > 0:
                self.setProperty("PlexKM.SectionTransitionPrevVisible", "1")
                _log("SECTION_AB_TIMING phase=prev_buffer_visible reason=%s rows=%d items=%d controls=8610-8670" % (reason or "", rendered_rows, rendered_items))
            return rendered_items
        except Exception:
            _log("SECTION_PREV_BUFFER_RENDER_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            try:
                self._section_clear_prev_recommend_row_controls(clear_visible=True)
            except Exception:
                pass
            return 0

    def _section_placeholder_clear_v1305(self, reason=""):
        """v1305: clear placeholder visibility and every per-slot flag.

        The v1303/v1305 placeholder was a broad row overlay.  When the target
        row had only one real item, the empty cells remained visible as grey
        rectangles.  v1305 makes placeholders exact-slot only and clears every
        slot when leaving section preview or when the delayed hide fires.
        """
        try:
            props = ["PlexKM.Section.PlaceholderVisible"]
            for row_idx in range(0, 2):
                props.append("PlexKM.Section.Placeholder.Row%d.Slots" % row_idx)
                for slot_idx in range(0, 6):
                    props.append("PlexKM.Section.Placeholder.Row%d.Slot%d" % (row_idx, slot_idx))
            win = xbmcgui.Window(10000)
            for prop in props:
                try:
                    self.clearProperty(prop)
                except Exception:
                    pass
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            if reason:
                _log("SECTION_PLACEHOLDER_CLEAR_V1315 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _section_placeholder_show_v1305(self, rows_cache=None, reason=""):
        """v1305: show placeholder only for slots that will actually contain items.

        The placeholder is no longer a six-cell row blanket.  It is driven by
        the target row data: if 이어보기 has one item, only slot 0 is allowed;
        the remaining empty cells stay invisible.  This keeps the v1296 no-push
        behavior while avoiding fake widgets in empty places.
        """
        try:
            grouped = []
            current = []
            current_id = None
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)

            token = int(getattr(self, "_section_placeholder_token_v1305", 0) or 0) + 1
            self._section_placeholder_token_v1305 = token
            self._section_placeholder_clear_v1305(reason="prepare:%s" % (reason or ""))

            win = xbmcgui.Window(10000)
            total_slots = 0
            row_slots = []
            for row_idx in range(0, 2):
                count = len(grouped[row_idx]) if row_idx < len(grouped) else 0
                slots = max(0, min(6, int(count or 0)))
                row_slots.append(slots)
                if slots > 0:
                    prop_slots = "PlexKM.Section.Placeholder.Row%d.Slots" % row_idx
                    try:
                        self.setProperty(prop_slots, str(slots))
                    except Exception:
                        pass
                    try:
                        win.setProperty(prop_slots, str(slots))
                    except Exception:
                        pass
                    for slot_idx in range(slots):
                        prop = "PlexKM.Section.Placeholder.Row%d.Slot%d" % (row_idx, slot_idx)
                        try:
                            self.setProperty(prop, "1")
                        except Exception:
                            pass
                        try:
                            win.setProperty(prop, "1")
                        except Exception:
                            pass
                    total_slots += slots

            if total_slots > 0:
                self.setProperty("PlexKM.Section.PlaceholderVisible", "1")
                win.setProperty("PlexKM.Section.PlaceholderVisible", "1")
                _log("SECTION_PLACEHOLDER_SHOW_V1315 reason=%s token=%s row0_slots=%s row1_slots=%s total_slots=%s" % (
                    reason or "", token, row_slots[0] if len(row_slots) > 0 else 0, row_slots[1] if len(row_slots) > 1 else 0, total_slots))
            else:
                _log("SECTION_PLACEHOLDER_SKIP_V1315 reason=%s token=%s total_slots=0" % (reason or "", token))
        except Exception:
            _log("SECTION_PLACEHOLDER_SHOW_FAILED_V1315 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _section_bank_render_claim_v1844(self, bank, cache_key=""):
        """Claim one A/B bank for the newest nested render transaction."""
        bank_name = "B" if str(bank or "A").upper() == "B" else "A"
        try:
            serial = int(getattr(self, "_section_bank_render_serial_v1844", 0) or 0) + 1
            self._section_bank_render_serial_v1844 = serial
            owners = getattr(self, "_section_bank_render_owner_v1844", None)
            if not isinstance(owners, dict):
                owners = {"A": "", "B": ""}
                self._section_bank_render_owner_v1844 = owners
            token = "%s:%d:%s" % (bank_name, serial, str(cache_key or ""))
            owners[bank_name] = token
            _log("SECTION_BANK_RENDER_CLAIM_V1844 bank=%s token=%s target=%s" % (
                bank_name, token, str(cache_key or "")
            ))
            return token
        except Exception:
            return ""

    def _section_bank_render_owned_v1844(self, bank, token):
        """True only while token is still the newest builder for this bank."""
        if not token:
            return True
        bank_name = "B" if str(bank or "A").upper() == "B" else "A"
        try:
            owners = getattr(self, "_section_bank_render_owner_v1844", None)
            return isinstance(owners, dict) and str(owners.get(bank_name) or "") == str(token)
        except Exception:
            return False

    def _section_bank_render_superseded_v1844(self, bank, token, cache_key="", phase="", reason=""):
        if self._section_bank_render_owned_v1844(bank, token):
            return False
        _log("SECTION_BANK_RENDER_SUPERSEDED_DROP_V1844 bank=%s token=%s target=%s phase=%s reason=%s active_bank=%s active_section=%s destructive_clear=0" % (
            "B" if str(bank or "A").upper() == "B" else "A",
            str(token or ""), str(cache_key or ""), str(phase or ""), str(reason or ""),
            self._section_bank_name_v1612(), str(getattr(self, "active_section_id", "") or "")
        ), xbmc.LOGWARNING)
        return True

    def _section_render_cancelled_v1906(self, expected_generation, bank="", owner_token="",
                                          cache_key="", phase="", reason=""):
        """Fail closed before stale code touches or publishes native controls."""
        causes = []
        try:
            closing = getattr(self, "_closing_event_v1841", None)
            if closing is not None and closing.is_set():
                causes.append("window_closing")
        except Exception:
            causes.append("lifecycle_unknown")
        try:
            current_generation = int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0)
            if expected_generation is not None and int(expected_generation) != current_generation:
                causes.append("menu_generation_changed")
        except Exception:
            causes.append("generation_invalid")
        try:
            if owner_token and not self._section_bank_render_owned_v1844(bank, owner_token):
                causes.append("bank_owner_changed")
        except Exception:
            causes.append("bank_owner_invalid")
        try:
            if cache_key and str(getattr(self, "active_section_id", "") or "") != str(cache_key):
                causes.append("active_section_changed")
        except Exception:
            causes.append("active_section_invalid")
        if not causes:
            return False
        _log("SECTION_RENDER_CANCEL_V1906 bank=%s token=%s target=%s phase=%s reason=%s causes=%s generation=%s current_generation=%s active_bank=%s active_section=%s previous_scene_kept=1 control_publish=0" % (
            "B" if str(bank or "A").upper() == "B" else "A",
            str(owner_token or ""), str(cache_key or ""), str(phase or ""), str(reason or ""),
            ",".join(causes), str(expected_generation),
            str(getattr(self, "_menu_refresh_generation_v1906", 0)),
            self._section_bank_name_v1612(), str(getattr(self, "active_section_id", "") or ""),
        ), xbmc.LOGWARNING)
        return True

    def _section_reset_bank_controls_v1612(self, bank, reason="", allow_active_v1844=False,
                                           owner_token_v1844=""):
        """Clear a hidden bank, never the currently published visible bank."""
        bank_name = "B" if str(bank or "A").upper() == "B" else "A"
        if owner_token_v1844 and not self._section_bank_render_owned_v1844(bank_name, owner_token_v1844):
            _log("SECTION_BANK_CLEAR_BLOCK_V1844 bank=%s reason=%s cause=owner_changed token=%s active_bank=%s" % (
                bank_name, reason or "", owner_token_v1844 or "", self._section_bank_name_v1612()
            ), xbmc.LOGWARNING)
            return False
        if not allow_active_v1844 and bank_name == self._section_bank_name_v1612():
            _log("SECTION_ACTIVE_BANK_CLEAR_BLOCK_V1844 bank=%s reason=%s token=%s visible_scene_kept=1" % (
                bank_name, reason or "", owner_token_v1844 or ""
            ), xbmc.LOGWARNING)
            return False
        ids = self._section_bank_row_ids_v1612(bank_name)
        try:
            # v1620: ownership becomes invalid the instant a bank is reset. This
            # prevents rapid menu re-entry from reusing a half-rebuilt old scene.
            try:
                if not hasattr(self, "_section_bank_cache_key_v1612"):
                    self._section_bank_cache_key_v1612 = {"A": "", "B": ""}
                old_owner_v2585 = str(self._section_bank_cache_key_v1612.get(bank_name) or "")
                self._section_bank_cache_key_v1612[bank_name] = ""
                pending_v2585 = getattr(self, "_section_progressive_pending_keys_v2585", None)
                if isinstance(pending_v2585, set) and old_owner_v2585:
                    pending_v2585.discard(old_owner_v2585)
            except Exception:
                pass
            for idx, cid in enumerate(ids):
                try:
                    self.getControl(cid).reset()
                except Exception:
                    pass
                try:
                    self.clearProperty(self._section_bank_title_property_v1612(bank, idx))
                except Exception:
                    pass
            # v2385: native grouplist owns vertical offset; no Python stack reset.
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
            if bank_name == self._section_bank_name_v1612():
                self._section_visible_row_controls = []
            _log("SECTION_TRUE_AB_TARGET_CLEAR_V1612 bank=%s reason=%s" % (bank_name, reason or ""))
            return True
        except Exception:
            return False

    def _section_reset_recommend_row_controls(self):
        """Compatibility reset for server-switch/full teardown: clear both banks."""
        try:
            self._section_reset_bank_controls_v1612("A", reason="compat_reset", allow_active_v1844=True)
            self._section_reset_bank_controls_v1612("B", reason="compat_reset", allow_active_v1844=True)
            self.clearProperty("PlexKM.LastSectionRow")
            self._section_visible_row_controls = []
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
        except Exception:
            pass

    def _section_first_viewport_visual_ready_v2491(self, target_ids, max_items=10):
        """Return fail-closed visual readiness for the first visible section viewport.

        Persistent snapshots prove row/meta data readiness only.  After a Kodi
        restart their native texture bindings do not survive.  Every visible item
        must therefore own either a real local/cached poster texture or the
        explicit item-level missing-poster placeholder before an A/B publish.
        This helper performs only local file/Textures13 checks; it never performs
        network IO.
        """
        listitems = []
        pairs = []
        placeholder_count = 0
        no_source_count = 0
        try:
            for cid in list(target_ids or [])[:2]:
                try:
                    ctrl = self.getControl(cid)
                    count = max(0, int(ctrl.size()))
                except Exception:
                    continue
                for idx in range(count):
                    if len(listitems) >= max(1, int(max_items or 10)):
                        break
                    try:
                        li = ctrl.getListItem(idx)
                    except Exception:
                        continue
                    listitems.append(li)
                    try:
                        if str(li.getProperty("PlexKM.PosterMissingV1963") or "") == "1":
                            placeholder_count += 1
                            continue
                        sources_v2498 = list(self._poster_authority_sources_v2498(li) or [])
                        primary = str(sources_v2498[0] if sources_v2498 else "").strip()
                        fallback = str(sources_v2498[1] if len(sources_v2498) > 1 else "").strip()
                        if primary or fallback:
                            pairs.append((primary, fallback))
                        else:
                            no_source_count += 1
                    except Exception:
                        no_source_count += 1
                if len(listitems) >= max(1, int(max_items or 10)):
                    break
        except Exception:
            pass
        ready = 0
        total = len(pairs)
        if pairs:
            try:
                ready, total = self._texture_pairs_ready_v1619(pairs)
            except Exception:
                ready, total = 0, len(pairs)
        visible = len(listitems)
        safe = bool(
            visible > 0
            and no_source_count == 0
            and ready >= total
            and (int(total) + int(placeholder_count)) >= visible
        )
        return safe, int(ready), int(total), int(placeholder_count), int(no_source_count), listitems

    def _section_wait_hidden_bank_ready_v1612(self, bank, reason="", fast_revisit_v1620=False,
                                                   expected_generation_v1906=None,
                                                   owner_token_v1844="", cache_key_v1620=""):
        """Let Kodi bind a hidden bank, but abort immediately when it becomes stale."""
        candidates = self._section_target_texture_candidates_v1612(bank)
        started = int(time.time() * 1000)
        cold_first_visit = not bool(fast_revisit_v1620)
        if cold_first_visit:
            # V2703R1: exact poster gate remains authoritative; avoid duplicate long foreground hold.
            min_hold_ms = 160
            ready_settle_ms = 80
            max_hold_ms = 1800
        else:
            min_hold_ms = 64
            ready_settle_ms = 48
            max_hold_ms = 220
        poll_ms = 40
        ready = 0
        total = len(candidates)
        timed_out = False
        ready_since = 0

        def _cancelled(phase):
            return self._section_render_cancelled_v1906(
                expected_generation_v1906, bank=bank,
                owner_token=owner_token_v1844, cache_key=cache_key_v1620,
                phase=phase, reason=reason,
            )

        if fast_revisit_v1620:
            startup_hydrated_v2469 = bool(
                cache_key_v1620
                and cache_key_v1620 in getattr(self, "_section_startup_prebuilt_keys_v2469", set())
            )
            # v2491: a persistent/native ListItem snapshot is data-ready, not
            # texture-ready.  Keep the source scene visible while the hidden bank
            # proves that every poster file exists and has remained ready across
            # several GUI frames.  Cached restarts normally pass in ~160ms; an
            # incomplete target may wait up to 2.2s but is never published blank.
            min_hold_fast_v2491 = 160 if startup_hydrated_v2469 else 96
            ready_settle_fast_v2491 = 160 if startup_hydrated_v2469 else 80
            max_hold_fast_v2491 = 2200 if startup_hydrated_v2469 else 650
            while not xbmc.Monitor().abortRequested():
                if _cancelled("wait_fast_v2491"):
                    elapsed = int(time.time() * 1000) - started
                    _log("SECTION_TRUE_AB_TARGET_WAIT_CANCEL_V2491 bank=%s reason=%s wait_ms=%d" % (
                        str(bank or "").upper(), reason or "", elapsed
                    ), xbmc.LOGWARNING)
                    return 0, total, elapsed, False, True
                now_ms = int(time.time() * 1000)
                elapsed = now_ms - started
                try:
                    ready, checked = self._texture_pairs_ready_v1619(candidates)
                    total = checked
                except Exception:
                    checked = total
                all_ready = (checked == 0) or (ready >= checked)
                if all_ready:
                    if not ready_since:
                        ready_since = now_ms
                else:
                    ready_since = 0
                stable_ms = (now_ms - ready_since) if ready_since else 0
                if elapsed >= min_hold_fast_v2491 and all_ready and stable_ms >= ready_settle_fast_v2491:
                    break
                if elapsed >= max_hold_fast_v2491:
                    timed_out = True
                    break
                xbmc.sleep(32)
            if _cancelled("wait_fast_done_v2491"):
                elapsed = int(time.time() * 1000) - started
                return 0, total, elapsed, timed_out, True
            elapsed = int(time.time() * 1000) - started
            stable_ms = max(0, int(time.time() * 1000) - ready_since) if ready_since else 0
            _log("SECTION_STARTUP_TEXTURE_GATE_V2491 key=%s bank=%s ready=%d total=%d wait_ms=%d stable_ms=%d timeout=%d persistent=%d source_hold=1" % (
                cache_key_v1620, str(bank or "").upper(), ready, total, elapsed, stable_ms,
                1 if timed_out else 0, 1 if startup_hydrated_v2469 else 0
            ))
            return ready, total, elapsed, timed_out, False

        while True:
            if _cancelled("wait_cold"):
                elapsed = int(time.time() * 1000) - started
                _log("SECTION_TRUE_AB_TARGET_WAIT_CANCEL_V1906 bank=%s reason=%s mode=cold_spinner wait_ms=%d" % (
                    str(bank or "").upper(), reason or "", elapsed
                ), xbmc.LOGWARNING)
                return 0, total, elapsed, False, True
            now_ms = int(time.time() * 1000)
            elapsed = now_ms - started
            try:
                ready, checked = self._texture_pairs_ready_v1619(candidates)
                total = checked
            except Exception:
                checked = total
            all_ready = (checked == 0) or (ready >= checked)
            if all_ready:
                if not ready_since:
                    ready_since = now_ms
            else:
                ready_since = 0
            stable_ms = (now_ms - ready_since) if ready_since else 0
            if elapsed >= min_hold_ms and all_ready and stable_ms >= ready_settle_ms:
                break
            if elapsed >= max_hold_ms:
                timed_out = True
                break
            if xbmc.Monitor().abortRequested():
                break
            xbmc.sleep(poll_ms)
        if _cancelled("wait_cold_done"):
            elapsed = int(time.time() * 1000) - started
            return 0, total, elapsed, timed_out, True
        elapsed = int(time.time() * 1000) - started
        stable_ms = max(0, int(time.time() * 1000) - ready_since) if ready_since else 0
        _log("SECTION_TRUE_AB_TARGET_READY_V1615 bank=%s reason=%s mode=%s ready=%d total=%d wait_ms=%d stable_ms=%d timeout=%d render_alpha=1" % (
            str(bank or "").upper(), reason or "", "cold_spinner" if cold_first_visit else "revisit_fast",
            ready, total, elapsed, stable_ms, 1 if timed_out else 0
        ))
        return ready, total, elapsed, timed_out, False

    # PKM_PATCH_ACTIVE v2586 sidebar_instant_ab_firstpaint
    def _section_instant_firstpaint_rows_v2586(self, rows_cache):
        """Smallest useful A/B scene for sidebar focus.

        Bind only the first visible widget plus the beginning of the next widget.
        The full recommendation scene is completed after the first swap.  This is
        intentionally data-only: no rating/canonical/episode-summary warmup and
        no texture-ready barrier is allowed to hold the sidebar focus.
        """
        out = []
        row_order = []
        row_counts = {}
        caps = (10, 4)
        try:
            for entry in list(rows_cache or []):
                if not isinstance(entry, dict):
                    continue
                rid = str(entry.get("row_id") or entry.get("row_title") or "row")
                if rid not in row_counts:
                    if len(row_order) >= len(caps):
                        break
                    row_order.append(rid)
                    row_counts[rid] = 0
                try:
                    row_idx = row_order.index(rid)
                except Exception:
                    row_idx = -1
                if row_idx < 0 or row_idx >= len(caps):
                    continue
                if row_counts[rid] >= caps[row_idx]:
                    continue
                out.append(entry)
                row_counts[rid] += 1
            return out
        except Exception:
            return list(rows_cache or [])[:14]

    # R157: do not prebind all rails. Prefer only the approached visible rail.
    # Normal Kodi native directional movement remains the focus owner.
    def _section_tail_nav_hint_r157(self, action_id):
        if action_id not in (ACTION_MOVE_RIGHT, ACTION_MOVE_DOWN):
            return
        try:
            lock = getattr(self, "_section_same_bank_fill_lock_v2707", None)
            if lock is None:
                return
            with lock:
                task = getattr(self, "_section_same_bank_fill_task_v2707", None)
                if not isinstance(task, dict):
                    return
                active_ids = list(task.get("active_ids") or [])
                fid = int(self.getFocusId() or 0)
                if fid not in active_ids:
                    return
                focused_row = active_ids.index(fid)
                target_row = focused_row if action_id == ACTION_MOVE_RIGHT else focused_row + 1
                grouped = list(task.get("grouped") or [])
                if target_row >= len(grouped):
                    return
                entries = grouped[target_row]
                ctl = self.getControl(active_ids[target_row])
                loaded = max(0, int(ctl.size()))
                if loaded >= len(entries):
                    return
                if action_id == ACTION_MOVE_RIGHT:
                    position = int(ctl.getSelectedPosition())
                    if position < 0 or loaded - position > 5:
                        return
                elif loaded >= min(len(entries), 6):
                    return
                task["urgent_row_r157"] = target_row
                task["urgent_until_r157"] = time.monotonic() + 0.9
        except Exception:
            # Navigation must never fail due to optional prefetch hints.
            return

    def _section_tail_urgent_row_r157(self, task):
        try:
            if time.monotonic() >= float(task.get("urgent_until_r157", 0.0) or 0.0):
                return -1
            ids = list(task.get("active_ids") or [])
            fid = int(self.getFocusId() or 0)
            if fid not in ids:
                return -1
            current_row = ids.index(fid)
            urgent_row = int(task.get("urgent_row_r157", -1))
            if urgent_row in (current_row, current_row + 1):
                return urgent_row
        except Exception:
            pass
        return -1

    # PKM_PATCH_ACTIVE v2707 sidebar_same_bank_chunk_fill_no_gui_monolith
    def _section_progressive_full_fill_v2585(self, cache_key, rows_cache, title, count_text, meta_snapshot=None):
        """Schedule V2707 same-bank tail fill and return to Kodi immediately.

        The V2706 no-blink contract is preserved: the first-paint bank stays active
        and its already-visible ListItems are immutable.  V2707 additionally stops
        building 60-80 tail cards in the same sidebar callback.  Missing rows/cards
        are added in short GUI-thread chunks posted through the existing SendClick
        callback lane, while poster-authority DB priming happens off the GUI thread.
        """
        key = str(cache_key or "")
        rows = list(rows_cache or [])
        if not key or not rows:
            return False

        lock = getattr(self, "_section_same_bank_fill_lock_v2707", None)
        if lock is None:
            lock = threading.RLock()
            self._section_same_bank_fill_lock_v2707 = lock

        try:
            with lock:
                if str(getattr(self, "active_section_id", "") or "") != key:
                    _log("SECTION_SIDEBAR_CHUNK_FILL_SKIP_V2707 key=%s active=%s reason=stale_before_schedule" % (
                        key, str(getattr(self, "active_section_id", "") or "")
                    ))
                    return False

                active_bank = str(self._section_bank_name_v1612() or "").upper()
                active_ids = list(self._section_active_row_ids_v1612() or [])
                owner_map = getattr(self, "_section_bank_cache_key_v1612", {}) or {}
                owner_key = str(owner_map.get(active_bank) or "")
                if active_bank not in ("A", "B") or not active_ids or owner_key != key:
                    _log("SECTION_SIDEBAR_CHUNK_FILL_SKIP_V2707 key=%s bank=%s owner=%s reason=owner_mismatch" % (
                        key, active_bank or "-", owner_key or "-"
                    ), xbmc.LOGWARNING)
                    return False

                grouped = []
                current = []
                current_id = None
                for entry in rows:
                    if not isinstance(entry, dict):
                        continue
                    rid = entry.get("row_id") or entry.get("row_title") or "row"
                    if current and rid != current_id:
                        grouped.append(current)
                        current = []
                    current_id = rid
                    current.append(entry)
                if current:
                    grouped.append(current)
                if not grouped or len(grouped) > len(active_ids):
                    _log("SECTION_SIDEBAR_CHUNK_FILL_SKIP_V2707 key=%s groups=%d capacity=%d reason=invalid_group_count" % (
                        key, len(grouped), len(active_ids)
                    ), xbmc.LOGWARNING)
                    return False

                existing_sizes = []
                existing_items = 0
                total_items = sum(len(x) for x in grouped)
                for row_idx, entries in enumerate(grouped):
                    ctrl = self.getControl(active_ids[row_idx])
                    current_size = max(0, int(ctrl.size()))
                    if current_size > len(entries):
                        _log("SECTION_SIDEBAR_CHUNK_FILL_SKIP_V2707 key=%s row=%d current=%d expected=%d reason=size_overflow" % (
                            key, row_idx, current_size, len(entries)
                        ), xbmc.LOGWARNING)
                        return False
                    # Same V2706 fail-closed prefix proof: never repair by rebinding.
                    for item_idx in range(current_size):
                        try:
                            existing_rk = str(ctrl.getListItem(item_idx).getProperty("PlexKM.RatingKey") or "")
                        except Exception:
                            existing_rk = ""
                        try:
                            row_tuple = tuple(entries[item_idx].get("row") or ())
                            expected_rk = str((row_tuple[0] if row_tuple else "") or "")
                        except Exception:
                            expected_rk = ""
                        if existing_rk != expected_rk:
                            _log("SECTION_SIDEBAR_CHUNK_FILL_SKIP_V2707 key=%s row=%d item=%d existing=%s expected=%s reason=prefix_identity_mismatch" % (
                                key, row_idx, item_idx, existing_rk or "-", expected_rk or "-"
                            ), xbmc.LOGWARNING)
                            return False
                    existing_sizes.append(current_size)
                    existing_items += current_size

                token = int(getattr(self, "_section_same_bank_fill_token_v2707", 0) or 0) + 1
                self._section_same_bank_fill_token_v2707 = token
                self._section_same_bank_fill_task_v2707 = {
                    "token": token,
                    "key": key,
                    "bank": active_bank,
                    "active_ids": active_ids,
                    "grouped": grouped,
                    "rows": rows,
                    "title": title or "",
                    "count_text": count_text or "추천",
                    "meta_snapshot": meta_snapshot,
                    "existing_items": existing_items,
                    "total_items": total_items,
                    "seed_cursor": 0,
                    "round_row": 0,
                    "poster_primed": False,
                    "started_ms": self._now_ms(),
                    "appended": 0,
                    "chunks": 0,
                }
                self._section_same_bank_fill_posted_v2707 = False
                _log("SECTION_SIDEBAR_CHUNK_FILL_SCHEDULE_V2707 key=%s bank=%s groups=%d items=%d existing=%d missing=%d gui_blocking_fullfill=0 second_ab_swap=0 visible_prefix_rebind=0" % (
                    key, active_bank, len(grouped), total_items, existing_items,
                    max(0, total_items - existing_items)
                ))

            self._schedule_section_same_bank_fill_ping_v2707(token, delay_ms=18, prime_posters=True)
            return True
        except Exception:
            _log("SECTION_SIDEBAR_CHUNK_FILL_SCHEDULE_FAIL_V2707 key=%s err=%s" % (
                key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _schedule_section_same_bank_fill_ping_v2707(self, token, delay_ms=18, prime_posters=False):
        """Post a short fill transaction back onto Kodi's WindowXML callback thread."""
        try:
            lock = getattr(self, "_section_same_bank_fill_lock_v2707", None)
            if lock is None:
                return False
            with lock:
                task = getattr(self, "_section_same_bank_fill_task_v2707", None)
                if not isinstance(task, dict) or int(task.get("token", -1)) != int(token):
                    return False
                if bool(getattr(self, "_section_same_bank_fill_posted_v2707", False)):
                    return True
                self._section_same_bank_fill_posted_v2707 = True

            def _post_v2707():
                posted = False
                try:
                    # U2: idle admission BEFORE the poster DB prime. Old side
                    # targets are dropped instead of consuming CPU after focus.
                    if self._is_android_v2591():
                        _u2_until = time.monotonic() + 3.0
                        while time.monotonic() < _u2_until:
                            with lock:
                                _u2_curr = getattr(self, "_section_same_bank_fill_task_v2707", None)
                                if not isinstance(_u2_curr, dict) or int(_u2_curr.get("token", -1)) != int(token):
                                    return
                            _u2_elapsed = time.monotonic() - float(getattr(self, "_section_fill_last_nav_mono_u2", 0.0) or 0.0)
                            # R157: allow the existing background poster prime
                            # to finish if the focused list is nearing its bound edge.
                            _r157_urgent = (float(_u2_curr.get("urgent_until_r157", 0.0) or 0.0) > time.monotonic())
                            if _u2_elapsed >= 0.7 or _r157_urgent:
                                break
                            if self._closing_event_v1841.wait(0.12):
                                return
                    # DB-only poster authority work is deliberately off the GUI lane.
                    if prime_posters:
                        with lock:
                            current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                            valid = isinstance(current, dict) and int(current.get("token", -1)) == int(token)
                            rows_local = list(current.get("rows") or []) if valid else []
                            already = bool(current.get("poster_primed")) if valid else True
                        if valid and not already:
                            try:
                                self._prime_episode_show_poster_authority_v2706(rows_local)
                            except Exception:
                                pass
                            with lock:
                                current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                                if isinstance(current, dict) and int(current.get("token", -1)) == int(token):
                                    current["poster_primed"] = True
                    if self._closing_event_v1841.wait(max(0, int(delay_ms)) / 1000.0):
                        return
                    with lock:
                        current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                        if not isinstance(current, dict) or int(current.get("token", -1)) != int(token):
                            return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    posted = True
                except Exception:
                    pass
                finally:
                    if not posted:
                        try:
                            with lock:
                                self._section_same_bank_fill_posted_v2707 = False
                        except Exception:
                            pass

            _PKMHomeThreadV2151(target=_post_v2707, name="PKMSectionTailFillV2707", daemon=True).start()
            return True
        except Exception:
            return False

    def _section_same_bank_full_fill_commit_v2707(self):
        """Append only a tiny amount of tail content per Kodi GUI callback."""
        lock = getattr(self, "_section_same_bank_fill_lock_v2707", None)
        if lock is None:
            return False
        try:
            with lock:
                self._section_same_bank_fill_posted_v2707 = False
                task = getattr(self, "_section_same_bank_fill_task_v2707", None)
                if not isinstance(task, dict):
                    return False
                token = int(task.get("token", -1))
                key = str(task.get("key") or "")
                bank = str(task.get("bank") or "").upper()
                poster_primed = bool(task.get("poster_primed"))

            # A generic GUI ping can arrive while the DB-only poster-prime worker
            # is still running. Never create tail TV ListItems from the old
            # canonical /thumb URL; wait for the revision-bearing map first.
            if not poster_primed:
                self._schedule_section_same_bank_fill_ping_v2707(
                    token, delay_ms=12, prime_posters=True
                )
                return False

            # U2: verify actual sidebar selection, not just stale
            # active_section_id (which remains the old section in settings).
            try:
                _u2_menu = self._selected_menu_item()
                _u2_kind = str(_u2_menu.getProperty("kind") or "") if _u2_menu else ""
                _u2_sid = str(_u2_menu.getProperty("section_id") or "") if _u2_menu else ""
                _u2_expected = "recommend:%s" % _u2_sid
            except Exception:
                _u2_kind, _u2_expected = "", ""
            if _u2_kind != "section" or _u2_expected != key:
                with lock:
                    _u2_live = getattr(self, "_section_same_bank_fill_task_v2707", None)
                    if isinstance(_u2_live, dict) and int(_u2_live.get("token", -1)) == token:
                        self._section_same_bank_fill_task_v2707 = None
                        self._section_same_bank_fill_token_v2707 = token + 1
                _log("SECTION_TAIL_CANCEL_SELECTION_U2 key=%s selected_kind=%s selected_key=%s" % (key, _u2_kind, _u2_expected))
                return False
            # R157: preserve quiet-time admission for offscreen rows, but
            # let the currently approached row extend before Kodi hits its end.
            _r157_priority_row = self._section_tail_urgent_row_r157(task)
            if (self._is_android_v2591()
                    and (time.monotonic() - float(getattr(self, "_section_fill_last_nav_mono_u2", 0.0) or 0.0)) < 0.7
                    and _r157_priority_row < 0):
                self._schedule_section_same_bank_fill_ping_v2707(token, delay_ms=120, prime_posters=False)
                return False

            owner_map = getattr(self, "_section_bank_cache_key_v1612", {}) or {}
            if (str(getattr(self, "active_section_id", "") or "") != key
                    or str(self._section_bank_name_v1612() or "").upper() != bank
                    or str(owner_map.get(bank) or "") != key):
                try:
                    pending = getattr(self, "_section_progressive_pending_keys_v2585", None)
                    if isinstance(pending, set):
                        pending.discard(key)
                except Exception:
                    pass
                with lock:
                    current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                    if isinstance(current, dict) and int(current.get("token", -1)) == token:
                        self._section_same_bank_fill_task_v2707 = None
                _log("SECTION_SIDEBAR_CHUNK_FILL_CANCEL_V2707 key=%s bank=%s reason=navigation_or_owner_changed visible_scene_kept=1" % (
                    key, bank or "-"
                ))
                return False

            grouped = list(task.get("grouped") or [])
            active_ids = list(task.get("active_ids") or [])
            if not grouped or len(grouped) > len(active_ids):
                return False

            max_items = 3 if self._is_android_v2591() else 8
            budget_ms = 9.0 if self._is_android_v2591() else 14.0
            # VNext: still yield between callbacks and pause while input is
            # active. Do not touch the visible prefix or trigger another A/B.

            started = time.perf_counter()
            processed = 0
            seeded = 0
            appended = 0

            old_light = bool(getattr(self, "_section_sidebar_fastpaint_v2586", False))
            self._section_sidebar_fastpaint_v2586 = True
            try:
                # R157: a small urgent tail extension takes priority over seeding
                # unrelated rails. No reset, no rebind, no A/B swap; max 3 Android
                # additions per GUI callback under the existing 9 ms budget.
                if 0 <= _r157_priority_row < len(grouped):
                    entries = grouped[_r157_priority_row]
                    ctl = self.getControl(active_ids[_r157_priority_row])
                    while processed < max_items:
                        index = max(0, int(ctl.size()))
                        if index >= len(entries):
                            break
                        entry = entries[index]
                        if index == 0:
                            self.setProperty(
                                self._section_bank_title_property_v1612(bank, _r157_priority_row),
                                _display_library_title(entry.get("row_title", "") or ""),
                            )
                        li = self._li_from_row(
                            entry.get("row"),
                            row_title=_display_library_title(entry.get("row_title", "")),
                            row_type=entry.get("row_type", ""),
                            row_first=(index == 0),
                            row_id=entry.get("row_id", ""), row_start=0,
                            row_index=index,
                        )
                        ctl.addItem(li)
                        processed += 1
                        appended += 1
                        if index == 0:
                            seeded += 1
                        if (time.perf_counter() - started) * 1000.0 >= budget_ms:
                            break
                # First make every missing widget row exist with one card. This makes
                # the vertical stack feel complete before we fill horizontal tails.
                seed_cursor = int(task.get("seed_cursor", 0) or 0)
                while seed_cursor < len(grouped) and processed < max_items:
                    row_idx = seed_cursor
                    seed_cursor += 1
                    entries = grouped[row_idx]
                    if not entries:
                        continue
                    ctrl = self.getControl(active_ids[row_idx])
                    if int(ctrl.size()) > 0:
                        continue
                    title0 = entries[0].get("row_title", "")
                    self.setProperty(
                        self._section_bank_title_property_v1612(bank, row_idx),
                        _display_library_title(title0 or "")
                    )
                    entry = entries[0]
                    li = self._li_from_row(
                        entry.get("row"),
                        row_title=_display_library_title(entry.get("row_title", "")),
                        row_type=entry.get("row_type", ""), row_first=True,
                        row_id=entry.get("row_id", ""), row_start=0, row_index=0,
                    )
                    ctrl.addItem(li)
                    processed += 1
                    seeded += 1
                    appended += 1
                    if ((time.perf_counter() - started) * 1000.0) >= budget_ms:
                        break
                task["seed_cursor"] = seed_cursor

                # Then round-robin one card at a time so no single widget monopolizes
                # the GUI callback and lower rows remain responsive.
                if seed_cursor >= len(grouped) and processed < max_items:
                    row_cursor = int(task.get("round_row", 0) or 0) % max(1, len(grouped))
                    empty_rounds = 0
                    while processed < max_items and empty_rounds < len(grouped):
                        row_idx = row_cursor
                        row_cursor = (row_cursor + 1) % len(grouped)
                        entries = grouped[row_idx]
                        ctrl = self.getControl(active_ids[row_idx])
                        current_size = max(0, int(ctrl.size()))
                        if current_size >= len(entries):
                            empty_rounds += 1
                            continue
                        empty_rounds = 0
                        entry = entries[current_size]
                        li = self._li_from_row(
                            entry.get("row"),
                            row_title=_display_library_title(entry.get("row_title", "")),
                            row_type=entry.get("row_type", ""),
                            row_first=(current_size == 0),
                            row_id=entry.get("row_id", ""), row_start=0,
                            row_index=current_size,
                        )
                        ctrl.addItem(li)
                        processed += 1
                        appended += 1
                        if ((time.perf_counter() - started) * 1000.0) >= budget_ms:
                            break
                    task["round_row"] = row_cursor
            finally:
                self._section_sidebar_fastpaint_v2586 = old_light

            task["appended"] = int(task.get("appended", 0) or 0) + appended
            task["chunks"] = int(task.get("chunks", 0) or 0) + 1
            complete = True
            visible_ids = []
            for row_idx, entries in enumerate(grouped):
                ctrl = self.getControl(active_ids[row_idx])
                if int(ctrl.size()) < len(entries):
                    complete = False
                if int(ctrl.size()) > 0:
                    visible_ids.append(active_ids[row_idx])
            self._section_visible_row_controls = visible_ids
            self.wall_total = int(task.get("total_items", 0) or 0)
            self.wall_offset = self.wall_total

            elapsed_chunk_ms = (time.perf_counter() - started) * 1000.0
            if not complete:
                _log("SECTION_SIDEBAR_CHUNK_FILL_STEP_V2707 key=%s bank=%s chunk=%d processed=%d seeded=%d chunk_ms=%.1f remaining=%d gui_budget_ms=%.1f" % (
                    key, bank, int(task.get("chunks", 0) or 0), processed, seeded,
                    elapsed_chunk_ms,
                    max(0, int(task.get("total_items", 0) or 0) - int(task.get("existing_items", 0) or 0) - int(task.get("appended", 0) or 0)),
                    budget_ms,
                ))
                with lock:
                    current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                    if isinstance(current, dict) and int(current.get("token", -1)) == token:
                        current.update(task)
                self._schedule_section_same_bank_fill_ping_v2707(
                    token, delay_ms=(30 if self._is_android_v2591() and self._section_tail_urgent_row_r157(task) >= 0
                                     else 110 if self._is_android_v2591() else 16),
                    prime_posters=False
                )
                return True

            meta_snapshot = task.get("meta_snapshot")
            if not isinstance(meta_snapshot, dict) or not meta_snapshot:
                try:
                    meta_snapshot = self._capture_home_meta_snapshot_v1619(
                        self.getControl(active_ids[0]).getListItem(0),
                        reason="SECTION_SIDEBAR_CHUNK_FULL_FILL_V2707"
                    )
                except Exception:
                    meta_snapshot = None
            try:
                pending = getattr(self, "_section_progressive_pending_keys_v2585", None)
                if isinstance(pending, set):
                    pending.discard(key)
            except Exception:
                pass
            old_progressive_key = str(getattr(self, "_section_progressive_firstpaint_key_v2585", "") or "")
            try:
                self._section_progressive_firstpaint_key_v2585 = ""
                self._section_scene_store_v1620(
                    key, task.get("title") or "", task.get("count_text") or "추천",
                    list(task.get("rows") or []), meta_snapshot, bank,
                    reason="SECTION_SIDEBAR_CHUNK_FULL_FILL_V2707"
                )
            finally:
                self._section_progressive_firstpaint_key_v2585 = old_progressive_key
            with lock:
                current = getattr(self, "_section_same_bank_fill_task_v2707", None)
                if isinstance(current, dict) and int(current.get("token", -1)) == token:
                    self._section_same_bank_fill_task_v2707 = None
            _log("SECTION_SIDEBAR_CHUNK_FILL_DONE_V2707 key=%s bank=%s items=%d existing=%d appended=%d chunks=%d total_ms=%d second_ab_swap=0 crossfade=0 visible_prefix_rebind=0 poster_rebind=0" % (
                key, bank, int(task.get("total_items", 0) or 0),
                int(task.get("existing_items", 0) or 0), int(task.get("appended", 0) or 0),
                int(task.get("chunks", 0) or 0),
                max(0, self._now_ms() - int(task.get("started_ms", self._now_ms()) or self._now_ms())),
            ))
            return True
        except Exception:
            _log("SECTION_SIDEBAR_CHUNK_FILL_COMMIT_FAIL_V2707 err=%s visible_scene_kept=1" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _section_render_xml_rows(self, rows_cache, reason="", publish_title="", publish_count="추천",
                                 scene_cache_key_v1620="", fast_revisit_v1620=False,
                                 precomputed_meta_v1620=None, gate_token_v1620=""):
        """Serialize A/B bank construction so concurrent sidebar workers cannot collide."""
        lock = getattr(self, "_section_render_lock_v1620", None)
        if lock is None:
            self._section_render_lock_v1620 = threading.RLock()
            lock = self._section_render_lock_v1620
        with lock:
            # v2468: a persistent restart-cache hit already owns complete,
            # authority-matched row data.  After a process restart no native A/B
            # bank can physically survive, so it still has to be rebound to the
            # hidden bank.  That bind is a render step, not a data load: keep the
            # previous scene visible and swap atomically without foreground spinner.
            persistent_restore_v2468 = bool(
                scene_cache_key_v1620
                and scene_cache_key_v1620 in getattr(
                    self, "_section_persistent_hit_keys_v2467", set()
                )
            )
            # V2704: V2697 full-fill runs only after the fast first paint is already
            # visible. It must never re-arm the foreground wait/busy spinner.
            # Keep the partial scene visible while the hidden A/B bank is completed.
            full_fill_after_visible_v2704 = (
                str(reason or "") == "SECTION_SIDEBAR_FULL_FILL_V2697"
            )
            if full_fill_after_visible_v2704:
                _log("SIDEBAR_FULL_FILL_NO_SPINNER_V2704 key=%s reason=%s previous_scene_kept=1" % (
                    scene_cache_key_v1620 or "", reason or ""
                ))
            if scene_cache_key_v1620 and not gate_token_v1620 and not full_fill_after_visible_v2704:
                gate_token_v1620 = self._section_first_visit_gate_begin_v1620(
                    scene_cache_key_v1620,
                    reason="hidden_bank_render_fallback_v2474:%s" % (reason or "section_xml"),
                    force_ui_wait_v1796=True, force_delayed_spinner_v2474=True
                )
                _log("SECTION_UI_WAIT_GATE_FALLBACK_V2474 key=%s token=%s reason=%s fast_revisit=%d persistent=%d delay_ms=%d" % (
                    scene_cache_key_v1620, gate_token_v1620 or "", reason or "",
                    1 if fast_revisit_v1620 else 0, 1 if persistent_restore_v2468 else 0,
                    350
                ))
            return self._section_render_xml_rows_locked_v1620(
                rows_cache, reason=reason, publish_title=publish_title, publish_count=publish_count,
                scene_cache_key_v1620=scene_cache_key_v1620,
                fast_revisit_v1620=fast_revisit_v1620,
                precomputed_meta_v1620=precomputed_meta_v1620,
                gate_token_v1620=gate_token_v1620
            )

    def _section_render_xml_rows_locked_v1620(self, rows_cache, reason="", publish_title="", publish_count="추천",
                                              scene_cache_key_v1620="", fast_revisit_v1620=False,
                                              precomputed_meta_v1620=None, gate_token_v1620=""):
        """Build one complete hidden scene; cold scenes gate once, revisits restore fast."""
        t_total = _pkm_speed_ms()
        target_bank = self._section_inactive_bank_v1612()
        target_ids = self._section_bank_row_ids_v1612(target_bank)
        cache_key_v1620 = str(scene_cache_key_v1620 or getattr(self, "active_section_id", "") or "")
        render_token_v1844 = ""
        render_generation_v1906 = int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0)
        _reason_v2586 = str(reason or "")
        sidebar_instant_firstpaint_v2586 = (_reason_v2586 == "SECTION_SIDEBAR_INSTANT_FIRSTPAINT_V2586")
        sidebar_light_full_v2586 = (_reason_v2586 == "SECTION_SIDEBAR_LIGHT_FULL_V2586")
        sidebar_light_render_v2586 = bool(sidebar_instant_firstpaint_v2586 or sidebar_light_full_v2586)
        try:
            if cache_key_v1620 and str(getattr(self, "active_section_id", "") or "") != cache_key_v1620:
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="stale_before_build", only_if_key=cache_key_v1620)
                _log("SECTION_SCENE_STALE_ABORT_V1620 phase=before_build target=%s active=%s reason=%s" % (
                    cache_key_v1620, getattr(self, "active_section_id", "") or "", reason or ""
                ))
                return 0
            if not bool(getattr(self, "_section_ab_schema_ready_v1617", False)):
                if not self._validate_section_ab_row_schema_v1617():
                    if gate_token_v1620:
                        self._section_first_visit_gate_cancel_v1620(reason="schema_invalid", only_if_key=cache_key_v1620)
                    _log("SECTION_TRUE_AB_ABORT_V1617 reason=%s bank=%s cause=schema_invalid current_bank=%s" % (
                        reason or "", target_bank, self._section_bank_name_v1612()), xbmc.LOGERROR)
                    return 0
            render_token_v1844 = self._section_bank_render_claim_v1844(
                target_bank, cache_key=cache_key_v1620
            )
            if self._section_render_cancelled_v1906(
                    render_generation_v1906, bank=target_bank,
                    owner_token=render_token_v1844, cache_key=cache_key_v1620,
                    phase="before_prepare", reason=reason):
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="render_cancel_before_prepare_v1906", only_if_key=cache_key_v1620
                    )
                return 0
            # v1614: never expose the previous contents of the inactive bank.
            # Clear any stale staging state first, reset/rebuild the bank in full,
            # and only then mark it renderable for the texture-settle phase.
            self._section_stage_bank_clear_v1612(reason="%s_prebuild_clear_v1614" % (reason or "section_xml"))
            reset_ok_v1844 = self._section_reset_bank_controls_v1612(
                target_bank, reason="%s_prepare" % (reason or "section_xml"),
                owner_token_v1844=render_token_v1844
            )
            if not reset_ok_v1844:
                _log("SECTION_BANK_PREPARE_ABORT_V1844 bank=%s token=%s target=%s reason=%s visible_scene_kept=1" % (
                    target_bank, render_token_v1844, cache_key_v1620, reason or ""
                ), xbmc.LOGWARNING)
                return 0
            grouped = []
            current = []
            current_id = None
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if current and rid != current_id:
                    grouped.append(current)
                    current = []
                current_id = rid
                current.append(entry)
            if current:
                grouped.append(current)
            if not grouped:
                _log("SECTION_TRUE_AB_ABORT_V1612 reason=%s bank=%s cause=no_grouped_rows current_bank=%s" % (
                    reason or "", target_bank, self._section_bank_name_v1612()
                ), xbmc.LOGWARNING)
                self._section_stage_bank_clear_v1612(reason="%s_no_rows" % (reason or "section_xml"))
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="no_grouped_rows", only_if_key=cache_key_v1620)
                return 0
            if len(grouped) > len(target_ids):
                # Never publish a partial bank.  The former grouped[:capacity]
                # slice silently discarded lower widgets and broke navigation.
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="%s_overflow_abort_v1617" % (reason or "section_xml"),
                    owner_token_v1844=render_token_v1844
                )
                self._section_stage_bank_clear_v1612(reason="%s_overflow" % (reason or "section_xml"))
                try:
                    overflow = str(len(grouped) - len(target_ids))
                    for target in (self, xbmcgui.Window(10000)):
                        target.setProperty("PlexKM.Section.RowOverflowV1617", overflow)
                except Exception:
                    pass
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="row_overflow", only_if_key=cache_key_v1620)
                _log("SECTION_TRUE_AB_ABORT_V1617 reason=%s bank=%s cause=row_overflow groups=%d capacity=%d current_bank=%s" % (
                    reason or "", target_bank, len(grouped), len(target_ids), self._section_bank_name_v1612()), xbmc.LOGERROR)
                return 0
            try:
                for target in (self, xbmcgui.Window(10000)):
                    target.clearProperty("PlexKM.Section.RowOverflowV1617")
            except Exception:
                pass

            # v2478: a complete persisted render snapshot is already the final
            # foreground display truth.  _section_snapshot_prebuild_v2473() has
            # converted it to native ListItems without DB/rating/canonical work.
            # The old v1644 in-memory rating snapshot does not survive restart;
            # falling back to _preload_visible_row_ratings() here therefore made
            # every prepared Recommendation section pay 250-1000ms again.
            # Never enrich a complete persistent snapshot on sidebar focus.
            snapshot_native_ready_v2478 = self._section_persistent_snapshot_native_ready_v2478(
                cache_key_v1620, rows_cache
            )
            # V2705: V2697 full-fill is a presentation completion pass after the
            # first paint is already visible. Re-running rating/canonical/watcha
            # enrichment here blocks sidebar navigation and is duplicate work.
            # Skip only enrichment. Do NOT classify it as V2586 light-render:
            # the normal V2491 poster texture gate must still protect the atomic
            # full-scene swap so poster/progress content never reveals separately.
            full_fill_nav_priority_v2705 = (
                str(reason or "") == "SECTION_SIDEBAR_FULL_FILL_V2697"
            )
            if sidebar_light_render_v2586 or full_fill_nav_priority_v2705:
                if full_fill_nav_priority_v2705:
                    _log("SIDEBAR_FULL_FILL_NAV_PRIORITY_V2705 key=%s rows=%d duplicate_enrich=0 poster_gate=1 navigation_cancel_preserved=1" % (
                        cache_key_v1620, len(rows_cache or [])
                    ))
                else:
                    _log("SECTION_SIDEBAR_ENRICH_BYPASS_V2586 key=%s rows=%d reason=%s rating_preload=0 canonical=0 episode_summary=0 cast=0" % (
                        cache_key_v1620, len(rows_cache or []), reason or ""
                    ))
            elif snapshot_native_ready_v2478:
                _log("SECTION_SNAPSHOT_FOREGROUND_ENRICH_SKIP_V2478 key=%s rows=%d db_io=0 rating_preload=0 canonical=0 native_ready=1" % (
                    cache_key_v1620, len(rows_cache or [])
                ))
            else:
                try:
                    if not (cache_key_v1620 and self._section_rating_snapshot_restore_v1644(cache_key_v1620)):
                        self._preload_visible_row_ratings(rows_cache, reason="%s_section_xml_v1612" % (reason or ""))
                except Exception:
                    pass

            prebuilt_groups_v1644 = self._section_prebuilt_listitems_v1644.get(cache_key_v1620)
            prebuilt_titles_v1644 = self._section_prebuilt_titles_v1644.get(cache_key_v1620) or []
            if prebuilt_groups_v1644 and len(prebuilt_groups_v1644) != len(grouped):
                prebuilt_groups_v1644 = None

            # V2706: TV recommendation cards must use the synchronized show thumb
            # path (revision-bearing when Plex provides one) before ListItems are
            # created. This is one local bulk query and performs no image/network I/O.
            _prime_t0_r38 = time.perf_counter()
            try:
                self._prime_episode_show_poster_authority_v2706(rows_cache)
            except Exception:
                pass
            _prime_ms_r38 = int((time.perf_counter() - _prime_t0_r38) * 1000)
            if _prime_ms_r38 >= 50:
                _log("SECTION_POSTER_AUTHORITY_PRIME_SLOW_R38 key=%s rows=%d elapsed_ms=%d" % (
                    cache_key_v1620, len(rows_cache or []), _prime_ms_r38))

            rendered_rows = 0
            rendered_items = 0
            cast_rows = []
            _old_sidebar_light_v2586 = bool(getattr(self, "_section_sidebar_fastpaint_v2586", False))
            if sidebar_light_render_v2586:
                self._section_sidebar_fastpaint_v2586 = True
            _rows_t0_r38 = time.perf_counter()
            _row_ms_r38 = []
            try:
                for row_idx, entries in enumerate(grouped):
                    _row_t0_r38 = time.perf_counter()
                    if self._section_render_cancelled_v1906(
                            render_generation_v1906, bank=target_bank,
                            owner_token=render_token_v1844, cache_key=cache_key_v1620,
                            phase="build_row_%d" % row_idx, reason=reason):
                        if gate_token_v1620:
                            self._section_first_visit_gate_cancel_v1620(
                                reason="render_cancel_build_v1906", only_if_key=cache_key_v1620
                            )
                        return 0
                    ctrl = self.getControl(target_ids[row_idx])
                    title0 = (prebuilt_titles_v1644[row_idx] if prebuilt_groups_v1644 and row_idx < len(prebuilt_titles_v1644)
                              else (entries[0].get("row_title", "") if entries else ""))
                    self.setProperty(self._section_bank_title_property_v1612(target_bank, row_idx), _display_library_title(title0 or ""))
                    if prebuilt_groups_v1644:
                        cast_row = list(prebuilt_groups_v1644[row_idx])
                    else:
                        cast_row = []
                        for item_idx, entry in enumerate(entries):
                            cast_row.append(self._li_from_row(
                                entry.get("row"),
                                row_title=_display_library_title(entry.get("row_title", "")),
                                row_type=entry.get("row_type", ""),
                                row_first=(item_idx == 0),
                                row_id=entry.get("row_id", ""),
                                row_start=0,
                                row_index=item_idx,
                            ))
                    try:
                        if (
                            entries
                            and _display_library_title(entries[0].get("row_title") or "") == "이어보기"
                        ):
                            _continue_progress_map = dict(
                                getattr(self, "_continue_membership_progress_map", None) or {}
                            )
                            for _idx_continue, _li_continue in enumerate(list(cast_row or [])):
                                try:
                                    _entry_continue = entries[_idx_continue] if _idx_continue < len(entries) else {}
                                    _row_continue = (
                                        _entry_continue.get("row")
                                        if isinstance(_entry_continue, dict) else None
                                    )
                                    if _row_continue is not None:
                                        self._home_apply_runtime_progress_v2499(
                                            _li_continue, _row_continue, _continue_progress_map
                                        )
                                    _resume_pct = _safe_int(
                                        _li_continue.getProperty("PlexKM.ResumePercent") or 0, 0
                                    )
                                    _watched_continue = str(
                                        _li_continue.getProperty("PlexKM.IsWatched") or ""
                                    )
                                    if _watched_continue == "1":
                                        _log(
                                            "SECTION_CONTINUE_RENDER_INVARIANT_VIOLATION section=%s rating_key=%s watched=1 action=upstream_reconcile_required" % (
                                                str((entries[0] or {}).get("section_id") or ""),
                                                str(_li_continue.getProperty("PlexKM.RatingKey") or ""),
                                            ),
                                            xbmc.LOGERROR,
                                        )
                                    elif _resume_pct <= 0:
                                        _log(
                                            "SECTION_CONTINUE_RENDER_INVARIANT_VIOLATION section=%s rating_key=%s progress=0 action=upstream_reconcile_required" % (
                                                str((entries[0] or {}).get("section_id") or ""),
                                                str(_li_continue.getProperty("PlexKM.RatingKey") or ""),
                                            ),
                                            xbmc.LOGERROR,
                                        )
                                    else:
                                        _log(
                                            "SECTION_CONTINUE_PROGRESS_READY section=%s rating_key=%s pct=%d watched=0" % (
                                                str((entries[0] or {}).get("section_id") or ""),
                                                str(_li_continue.getProperty("PlexKM.RatingKey") or ""),
                                                _resume_pct,
                                            )
                                        )
                                except Exception:
                                    pass
                        ctrl.addItems(cast_row)
                    except Exception:
                        for li in cast_row:
                            ctrl.addItem(li)
                    rendered_items += len(cast_row)
                    cast_rows.append(cast_row)
                    if ctrl.size() > 0:
                        ctrl.selectItem(0)
                        rendered_rows += 1
                    _row_ms_r38.append("%d:%d" % (len(cast_row), int((time.perf_counter() - _row_t0_r38) * 1000)))
            finally:
                if sidebar_light_render_v2586:
                    self._section_sidebar_fastpaint_v2586 = _old_sidebar_light_v2586
            # R38: diagnostic only.  A section ENTER from Info spent ~1.1 s here
            # on SHIELD with no log between rows; items:ms per row pinpoints it.
            _log("SECTION_ROWS_BUILD_TIMING_R38 key=%s light=%d rows=%d items=%d total_ms=%d per_row=%s" % (
                cache_key_v1620, 1 if sidebar_light_render_v2586 else 0, rendered_rows, rendered_items,
                int((time.perf_counter() - _rows_t0_r38) * 1000), ",".join(_row_ms_r38)))

            if self._section_render_cancelled_v1906(
                    render_generation_v1906, bank=target_bank,
                    owner_token=render_token_v1844, cache_key=cache_key_v1620,
                    phase="after_rows", reason=reason):
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="render_cancel_after_rows_v1906", only_if_key=cache_key_v1620
                    )
                return 0

            # V2715: sidebar first-paint must never synchronously download the
            # first viewport.  The 1500ms delayed-spinner policy remains intact;
            # this path simply removes Python artwork download/decode work from
            # the focus transaction.  The hidden A/B target bank is built as one
            # unit and poster/progress controls are revealed by the same atomic
            # bank commit.  Normal/full renders still keep the V2711 poster gate.
            if sidebar_light_render_v2586:
                # V2716: keep V2715 zero-wait behavior for ordinary cards, but a
                # resume/progress overlay is allowed to reveal only after its own
                # poster is locally ready. This restores the poster+progress atomic
                # quality contract without reinstating an all-poster viewport gate.
                self._progress_overlay_poster_gate_v2716(
                    [li for row_items in cast_rows for li in list(row_items or [])],
                    reason="SECTION_SIDEBAR_INSTANT_FIRSTPAINT_V2716:%s:%s" % (cache_key_v1620, target_bank)
                )
                _log("SECTION_SIDEBAR_POSTER_GATE_ASYNC_V2715 key=%s bank=%s reason=%s synchronous_download=0 kodi_texture_owner=1 atomic_bank_reveal=1 spinner_threshold_ms=1500 progress_overlay_gate=v2716" % (
                    cache_key_v1620, target_bank, reason or ""
                ))
            else:
                _log("GLOBAL_POSTER_PROGRESS_ATOMIC_V2711 key=%s bank=%s reason=%s poster_gate=1 overlay_same_reveal=1" % (
                    cache_key_v1620, target_bank, reason or ""
                ))
                try:
                    # v2491: snapshot/native ListItem readiness does not imply that the
                    # current Kodi process owns decoded poster textures.  First perform
                    # a local-only readiness probe.  A fully cached restart keeps the
                    # fast path; only an incomplete viewport is primed, still entirely
                    # inside the hidden target bank.
                    startup_hydrated_v2469 = bool(
                        cache_key_v1620 in getattr(self, "_section_startup_prebuilt_keys_v2469", set())
                    )
                    visual_safe_v2491, ready_v2491, total_v2491, missing_v2491, no_source_v2491, first_viewport_lis_v1862 = (
                        self._section_first_viewport_visual_ready_v2491(target_ids, max_items=10)
                    )
                    if startup_hydrated_v2469 and visual_safe_v2491:
                        _log("SECTION_FOCUS_POSTER_CACHE_READY_V2491 key=%s bank=%s ready=%d total=%d placeholder=%d no_source=%d prime=0 hidden=1" % (
                            cache_key_v1620, target_bank, ready_v2491, total_v2491, missing_v2491, no_source_v2491
                        ))
                    else:
                        applied_v2491, missing_after_prime_v2491 = self._prime_first_viewport_posters_v1862(
                            first_viewport_lis_v1862,
                            visible_count=min(10, len(first_viewport_lis_v1862)),
                            reason="section_recommend_v2491:%s:%s" % (cache_key_v1620, target_bank)
                        )
                        _log("SECTION_FOCUS_POSTER_PRIME_V2491 key=%s bank=%s startup_hydrated=%d pre_ready=%d pre_total=%d applied=%d missing=%d hidden=1 source_hold=1" % (
                            cache_key_v1620, target_bank, 1 if startup_hydrated_v2469 else 0,
                            ready_v2491, total_v2491, int(applied_v2491 or 0), int(missing_after_prime_v2491 or 0)
                        ))
                except Exception:
                    _log("FIRST_VIEWPORT_POSTER_GATE_FAILED_V2491 reason=section_recommend target=%s bank=%s err=%s" % (
                        cache_key_v1620, target_bank,
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)

            try:
                first_size = int(self.getControl(target_ids[0]).size())
            except Exception:
                first_size = 0
            if self._section_render_cancelled_v1906(
                    render_generation_v1906, bank=target_bank,
                    owner_token=render_token_v1844, cache_key=cache_key_v1620,
                    phase="after_build_v1906", reason=reason):
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="render_cancel_after_build_v1906", only_if_key=cache_key_v1620
                    )
                return 0
            if self._section_bank_render_superseded_v1844(
                    target_bank, render_token_v1844, cache_key=cache_key_v1620,
                    phase="after_build", reason=reason):
                return 0
            if rendered_rows <= 0 or rendered_items <= 0 or first_size <= 0 or rendered_rows != len(grouped):
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="%s_incomplete_abort" % (reason or "section_xml"),
                    owner_token_v1844=render_token_v1844
                )
                _log("SECTION_TRUE_AB_ABORT_V1612 reason=%s bank=%s rows=%d items=%d first_size=%d current_bank=%s" % (
                    reason or "", target_bank, rendered_rows, rendered_items, first_size, self._section_bank_name_v1612()
                ), xbmc.LOGWARNING)
                self._section_stage_bank_clear_v1612(reason="%s_incomplete" % (reason or "section_xml"))
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="incomplete_bank", only_if_key=cache_key_v1620)
                return 0

            if gate_token_v1620:
                gate_token_v1620 = self._sidebar_gate_renew_if_same_owner_cumulative(
                    cache_key_v1620, gate_token_v1620, target_bank, render_token_v1844
                )
            if gate_token_v1620 and not self._section_gate_token_valid_v1794(cache_key_v1620, gate_token_v1620):
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="gate_expired_before_stage_v1794",
                    owner_token_v1844=render_token_v1844
                )
                self._section_stage_bank_clear_v1612(reason="gate_expired_before_stage_v1794")
                _log("SECTION_SCENE_GATE_EXPIRED_ABORT_V1794 phase=before_stage target=%s bank=%s reason=%s previous_scene_kept=1" % (
                    cache_key_v1620, target_bank, reason or ""
                ), xbmc.LOGWARNING)
                return 0

            # v1614: the inactive bank is now complete. Keep it at a non-zero
            # render alpha (XML 1%) so Kodi must bind the new panel textures while
            # the current bank remains visually dominant. Only swap after the
            # cached files have stayed ready for a real render-settle window.
            self._section_stage_bank_begin_v1612(target_bank, reason=reason or "section_xml")
            # v1620: the first visit computes one immutable hero snapshot. A
            # re-entry reuses that completed snapshot and performs no metadata DB
            # work, Plex request or rating lookup before the bank flip.
            meta_snapshot_v1619 = precomputed_meta_v1620 if isinstance(precomputed_meta_v1620, dict) else None
            if meta_snapshot_v1619 is None:
                try:
                    first_target_li_v1619 = self.getControl(target_ids[0]).getListItem(0)
                    meta_snapshot_v1619 = self._capture_home_meta_snapshot_v1619(
                        first_target_li_v1619, reason=reason or "section_xml"
                    )
                except Exception:
                    meta_snapshot_v1619 = None
            if sidebar_light_render_v2586:
                _ready_v1906 = 0
                _total_v1906 = 0
                _wait_ms_v1906 = 0
                _timeout_v1906 = False
                wait_cancelled_v1906 = False
                _log("SECTION_SIDEBAR_SWAP_NOW_V2586 key=%s bank=%s reason=%s texture_wait_ms=0 source_hold_until_bind=1 progressive_fill=1" % (
                    cache_key_v1620, target_bank, reason or ""
                ))
            else:
                _ready_v1906, _total_v1906, _wait_ms_v1906, _timeout_v1906, wait_cancelled_v1906 = self._section_wait_hidden_bank_ready_v1612(
                    target_bank, reason=reason or "section_xml", fast_revisit_v1620=fast_revisit_v1620,
                    expected_generation_v1906=render_generation_v1906,
                    owner_token_v1844=render_token_v1844,
                    cache_key_v1620=cache_key_v1620,
                )
                if wait_cancelled_v1906:
                    if gate_token_v1620:
                        self._section_first_visit_gate_cancel_v1620(
                            reason="render_wait_cancel_v1906", only_if_key=cache_key_v1620
                        )
                    if self._section_bank_render_owned_v1844(target_bank, render_token_v1844):
                        self._section_stage_bank_clear_v1612(reason="render_wait_cancel_v1906")
                    return 0

                # v2491 fail-closed contract: timeout or any unresolved first-viewport
                # visual means the hidden target is NOT publishable.  Keep the complete
                # source scene on screen and retire the hidden bank instead of ever
                # exposing empty poster slots.
                final_safe_v2491, final_ready_v2491, final_total_v2491, final_missing_v2491, final_no_source_v2491, _final_lis_v2491 = (
                    self._section_first_viewport_visual_ready_v2491(target_ids, max_items=10)
                )
                texture_incomplete_v2491 = bool(
                    (_timeout_v1906 and _total_v1906 > 0 and _ready_v1906 < _total_v1906)
                    or not final_safe_v2491
                )
                if texture_incomplete_v2491:
                    self._section_reset_bank_controls_v1612(
                        target_bank, reason="poster_texture_incomplete_v2491",
                        owner_token_v1844=render_token_v1844
                    )
                    self._section_stage_bank_clear_v1612(reason="poster_texture_incomplete_v2491")
                    if gate_token_v1620:
                        self._section_first_visit_gate_cancel_v1620(
                            reason="poster_texture_incomplete_v2491", only_if_key=cache_key_v1620
                        )
                    _log("SECTION_POSTER_SWAP_BLOCKED_V2491 key=%s bank=%s wait_ready=%d wait_total=%d wait_ms=%d timeout=%d final_ready=%d final_total=%d placeholder=%d no_source=%d source_scene_kept=1 blank_publish=0" % (
                        cache_key_v1620, target_bank, _ready_v1906, _total_v1906, _wait_ms_v1906,
                        1 if _timeout_v1906 else 0, final_ready_v2491, final_total_v2491,
                        final_missing_v2491, final_no_source_v2491
                    ), xbmc.LOGWARNING)
                    return 0
                _log("SECTION_POSTER_SWAP_READY_V2491 key=%s bank=%s ready=%d total=%d placeholder=%d wait_ms=%d blank_publish=0" % (
                    cache_key_v1620, target_bank, final_ready_v2491, final_total_v2491, final_missing_v2491, _wait_ms_v1906
                ))

            if self._section_bank_render_superseded_v1844(
                    target_bank, render_token_v1844, cache_key=cache_key_v1620,
                    phase="after_prepare", reason=reason):
                return 0
            if gate_token_v1620:
                gate_token_v1620 = self._sidebar_gate_renew_if_same_owner_cumulative(
                    cache_key_v1620, gate_token_v1620, target_bank, render_token_v1844
                )
            if gate_token_v1620 and not self._section_gate_token_valid_v1794(cache_key_v1620, gate_token_v1620):
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="gate_expired_after_prepare_v1794",
                    owner_token_v1844=render_token_v1844
                )
                self._section_stage_bank_clear_v1612(reason="gate_expired_after_prepare_v1794")
                _log("SECTION_SCENE_GATE_EXPIRED_ABORT_V1794 phase=after_prepare target=%s bank=%s reason=%s previous_scene_kept=1" % (
                    cache_key_v1620, target_bank, reason or ""
                ), xbmc.LOGWARNING)
                return 0

            if cache_key_v1620 and str(getattr(self, "active_section_id", "") or "") != cache_key_v1620:
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="stale_after_prepare_v1620",
                    owner_token_v1844=render_token_v1844
                )
                self._section_stage_bank_clear_v1612(reason="stale_after_prepare_v1620")
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="stale_after_prepare", only_if_key=cache_key_v1620)
                _log("SECTION_SCENE_STALE_ABORT_V1620 phase=after_prepare target=%s active=%s bank=%s reason=%s" % (
                    cache_key_v1620, getattr(self, "active_section_id", "") or "", target_bank, reason or ""
                ))
                return 0

            self.wall_total = rendered_items
            self.wall_offset = rendered_items
            self._row_anchor_scroll_index[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._row_anchor_current_y[SECTION_ROW_ANCHOR_SCOPE] = 0
            self._section_visible_row_controls = [cid for cid in target_ids if self.getControl(cid).size() > 0]
            cache_key = cache_key_v1620 or str(getattr(self, "active_section_id", "") or "")
            # v1615: hide only the target bank's neutral plate through the final
            # opacity transition. If Kodi needs an extra render frame, the fully
            # composed old bank remains underneath instead of exposing grey slots.
            if self._section_render_cancelled_v1906(
                    render_generation_v1906, bank=target_bank,
                    owner_token=render_token_v1844, cache_key=cache_key_v1620,
                    phase="before_publish_v1906", reason=reason):
                if gate_token_v1620:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="render_cancel_before_publish_v1906", only_if_key=cache_key_v1620
                    )
                if self._section_bank_render_owned_v1844(target_bank, render_token_v1844):
                    self._section_stage_bank_clear_v1612(reason="render_cancel_before_publish_v1906")
                return 0
            if self._section_bank_render_superseded_v1844(
                    target_bank, render_token_v1844, cache_key=cache_key_v1620,
                    phase="before_publish", reason=reason):
                return 0
            if gate_token_v1620:
                gate_token_v1620 = self._sidebar_gate_renew_if_same_owner_cumulative(
                    cache_key_v1620, gate_token_v1620, target_bank, render_token_v1844
                )
            if gate_token_v1620 and not self._section_gate_token_valid_v1794(cache_key_v1620, gate_token_v1620):
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="gate_expired_before_publish_v1794",
                    owner_token_v1844=render_token_v1844
                )
                self._section_stage_bank_clear_v1612(reason="gate_expired_before_publish_v1794")
                _log("SECTION_SCENE_GATE_EXPIRED_ABORT_V1794 phase=before_publish target=%s bank=%s reason=%s previous_scene_kept=1" % (
                    cache_key_v1620, target_bank, reason or ""
                ), xbmc.LOGWARNING)
                return 0
            swap_token_v1615 = self._section_swap_guard_begin_v1615(
                target_bank, reason=reason or "section_xml"
            )
            swapped_v1615 = self._publish_section_scene_atomic_v1619(
                target_bank, cache_key, publish_title or self.getProperty("PlexKM.Window.Title") or "",
                publish_count or "추천", meta_snapshot_v1619, reason=reason or "section_xml"
            )
            if swapped_v1615:
                if gate_token_v1620:
                    self._section_first_visit_mark_published_v1795(
                        cache_key, gate_token_v1620, reason=reason or "section_xml"
                    )
                self._section_scene_store_v1620(
                    cache_key, publish_title or self.getProperty("PlexKM.Window.Title") or "",
                    publish_count or "추천", rows_cache, meta_snapshot_v1619, target_bank,
                    reason=reason or "section_xml"
                )
                if gate_token_v1620:
                    _log("SECTION_GATE_RELEASE_DEFER_TO_VISIBLE_V2475 key=%s token=%s reason=%s" % (
                        cache_key, gate_token_v1620, reason or "section_xml"
                    ))
                self._section_swap_guard_clear_later_v1615(
                    swap_token_v1615, reason=reason or "section_xml", delay_ms=80
                )
            else:
                try:
                    win = xbmcgui.Window(10000)
                    for target in (self, win):
                        target.clearProperty("PlexKM.Section.BankSwapInProgressV1615")
                        target.clearProperty("PlexKM.Section.BankSwapTargetV1615")
                        target.clearProperty("PlexKM.Section.BankSwapTokenV1615")
                except Exception:
                    pass
                # v1887: a built hidden bank is not a successful render unless
                # the atomic publish actually committed.  Returning its item
                # count made callers publish the stale section title/count even
                # after the menu-owner guard rejected the A/B flip.
                _log("SECTION_TRUE_AB_PUBLISH_ABORT_RETURN_ZERO_V1887 reason=%s bank=%s cache_key=%s previous_scene_kept=1" % (
                    reason or "", target_bank, cache_key or ""
                ), xbmc.LOGWARNING)
                return 0
            if not sidebar_light_render_v2586:
                try:
                    self._schedule_info_cast_prewarm_for_visible_rows_v1339(cast_rows, reason="%s_section_visible_widgets_v1612" % (reason or "section_xml"))
                except Exception:
                    pass
            else:
                _log("SECTION_SIDEBAR_CAST_PREWARM_BYPASS_V2586 key=%s reason=%s" % (cache_key_v1620, reason or ""))
            _log("SECTION_TRUE_AB_READY_V1617 reason=%s bank=%s rows=%d groups=%d capacity=%d items=%d source_rows=%d total_ms=%d old_bank_untouched=1 single_visibility_flip=1" % (
                reason or "", target_bank, rendered_rows, len(grouped), len(target_ids), rendered_items, len(rows_cache or []), _pkm_speed_ms() - t_total
            ))
            return rendered_items
        except Exception:
            try:
                if sidebar_light_render_v2586:
                    self._section_sidebar_fastpaint_v2586 = False
            except Exception:
                pass
            try:
                self._section_reset_bank_controls_v1612(
                    target_bank, reason="%s_exception_abort" % (reason or "section_xml"),
                    owner_token_v1844=render_token_v1844
                )
            except Exception:
                pass
            if self._section_bank_render_owned_v1844(target_bank, render_token_v1844):
                self._section_stage_bank_clear_v1612(reason="%s_exception" % (reason or "section_xml"))
            if gate_token_v1620:
                self._section_first_visit_gate_cancel_v1620(
                    reason="render_failed:%s" % (reason or ""), only_if_key=cache_key_v1620
                )
            _log("SECTION_TRUE_AB_RENDER_FAILED_V1612 reason=%s bank=%s err=%s" % (
                reason or "", target_bank, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return 0


    def _show_section_recommend_widgets(self, item, force=False):
        self._library_native_owner_section_v2070 = ""
        """Plex HTPC-style library landing page.

        When a library item in the left menu is focused, show the Recommendation
        tab first and render Home-like horizontal widget rows.  The poster size,
        focus outline, fanart hero, dynamic background color, and LEFT behavior
        intentionally reuse the existing HomeLayout item properties instead of
        introducing a second layout path.
        """
        speed_total_start = _pkm_speed_ms()
        try:
            # v2120: keep the currently visible section mode alive while the
            # recommendation bank is staged.  In particular, do NOT clear
            # IsSectionWall here when moving Library -> Recommend.  Clearing the
            # source mode before IsSectionRecommend is committed makes all three
            # section-tab visibility conditions false for a frame and Kodi can
            # drop the focused 7710/7720/7725 control.  The destination-first
            # commit below retires the old mode only after Recommend is visible.
            xbmcgui.Window(10000).setProperty("PlexKM.Window.HomeLayout", "1")
            self.setProperty("PlexKM.Window.HomeLayout", "1")
        except Exception:
            pass

        sid = item.getProperty("section_id")
        cache_key, force, now_ms, sidebar_placeholder_v1305, title, total = self._show_section_recommend_widgets_step1(force, item, sid)

        # v133: use the copied Home-style section rows (8410~8450) for every Plex library section.
        # Home rows (9410~9450) remain dedicated to Home; section recommendation rows are shared by all libraries.
        use_section_xml_rows = True

        try:
            target_ctrl = self.getControl(self._section_active_row_ids_v1612()[0] if use_section_xml_rows else WALL_ID)
            if (not force and self.active_section_id == cache_key and self._last_rendered_section_id == cache_key
                    and target_ctrl.size() > 0 and self.wall_offset > 0):
                self._commit_section_recommend_visible(title, "추천", reason="already_rendered:%s" % sid)
                if not use_section_xml_rows:
                    self._sync_wall_first_key("section_recommend_already:%s" % sid)
                self._set_home_meta_from_item(reason="section_recommend_already")
                _log("SECTION_RECOMMEND_SKIPPED section=%s reason=already_rendered offset=%d" % (sid, self.wall_offset))
                _speed_log("section_recommend_show_end", section=sid, title=title, result="already_rendered", rows=self.wall_offset, total_ms=_pkm_speed_ms() - speed_total_start)
                self._release_widget_stack_transition_later(reason="section_recommend_already_ready:%s" % sid, delay_ms=15)
                return
            if (not force and self.active_section_id == cache_key and (now_ms - self._last_section_show_ms) < 450):
                _log("SECTION_RECOMMEND_SKIPPED section=%s reason=rapid_duplicate" % sid)
                _speed_log("section_recommend_show_end", section=sid, title=title, result="rapid_duplicate", rows=self.wall_offset, total_ms=_pkm_speed_ms() - speed_total_start)
                self._release_widget_stack_transition_later(reason="section_recommend_rapid_duplicate:%s" % sid, delay_ms=10)
                return
        except Exception:
            pass

        self.active_section_id = cache_key
        self._last_rendered_section_id = cache_key
        self._last_section_show_ms = now_ms
        self.wall_total = total
        self.wall_offset = 0
        self._section_index_slice_active = False
        self._append_guard = set()
        self._reset_wall_cursor("show_section_recommend:%s" % sid)
        # v1292: header/IsHome/IsSectionRecommend are committed after row controls
        # are ready.  Setting the header here briefly hides Home before the
        # section stack is ready and can produce title overlap/blank transition.

        cached_rows = self._section_rows_cache.get(cache_key)
        scene_v1620 = self._section_scene_get_v1620(cache_key)
        gate_token_v1620 = ""
        section_type_v1616 = item.getProperty("section_type") or self._section_type_for_id(sid)
        _section_is_tv_v1966 = self._is_tv_recommend_section(sid, section_type_v1616)
        for _target_v1966 in (self, xbmcgui.Window(10000)):
            if _section_is_tv_v1966:
                _target_v1966.setProperty("PlexKM.Section.IsTV", "1")
            else:
                _target_v1966.clearProperty("PlexKM.Section.IsTV")
        _log("SECTION_MEDIA_KIND_V1966 section=%s type=%s is_tv=%d" % (sid, section_type_v1616, 1 if _section_is_tv_v1966 else 0))
        # Cold TV data/SQL work must never execute on the Kodi focus callback.
        # Existing persisted scene wins; only genuinely cold TV sections defer.
        if not cached_rows:
            if _section_is_tv_v1966:
                if self._sidebar_prepare_consume(sid):
                    cached_rows = self._section_rows_cache.get(cache_key)
                    scene_v1620 = self._section_scene_get_v1620(cache_key)
                else:
                    queued = self._sidebar_prepare_enqueue(sid, title, priority=True)
                    _log("SIDEBAR_PREPARE_WAIT section=%s queued=%d action=keep_previous_scene gui_block=0" % (
                        sid, 1 if queued else 0
                    ))
                    # PKM_SIDEBAR_ENTER_REPLAY_R34: this ENTER must not be lost.
                    # The ready ping used to call the focus refresh, which R134
                    # made preview-only, so a cold TV section (방영-외국, 해외-미드)
                    # needed a second ENTER.  Remember it; the ready ping replays
                    # the same ENTER publish if the selection has not moved.
                    if force and queued:
                        self._sidebar_enter_pending_r34 = (str(sid), time.monotonic())
                        _log("SIDEBAR_ENTER_PENDING_R34 section=%s" % sid)
                    return
            else:
                # Movies retain the existing fast first-paint fallback when
                # their low-priority prewarm has not completed yet.
                if self._sidebar_prepare_consume(sid):
                    cached_rows = self._section_rows_cache.get(cache_key)
                    scene_v1620 = self._section_scene_get_v1620(cache_key)
        cached_rows, scene_v1620 = self._show_section_recommend_widgets_step2(cache_key, cached_rows, scene_v1620, section_type_v1616, sid, title)
        if cached_rows:
            # v2474: persistent rows are data-ready, not render-ready. First try
            # an already-bound native A/B bank. If that cannot publish immediately,
            # arm the canonical delayed-spinner broker *before* snapshot->native or
            # raw-row->native work begins. Fast work under the delay remains spinner-free.
            prebuilt_ready_v1644 = bool(cache_key in self._section_prebuilt_listitems_v1644)
            fast_revisit_v1620 = bool(scene_v1620 or prebuilt_ready_v1644)
            _speed_log("section_scene_cache_mode_v2474", section=sid,
                       mode="revisit_fast" if scene_v1620 else ("native_prebuilt" if prebuilt_ready_v1644 else "data_only"),
                       rows=len(cached_rows or []), prebuilt=1 if prebuilt_ready_v1644 else 0,
                       snapshot=1 if len(list(getattr(self, "_section_render_snapshots_v2473", {}).get(cache_key) or [])) == len(cached_rows or []) else 0)
            if fast_revisit_v1620:
                reused_v1620 = self._section_reuse_ready_bank_v1620(
                    cache_key, scene_v1620, cached_rows, reason="sidebar_revisit_v2474"
                )
                if reused_v1620 > 0:
                    self._commit_section_recommend_visible(title, "추천", reason="ready_bank_revisit_v2474:%s" % sid)
                    _speed_log("section_recommend_show_end", section=sid, title=title, result="ready_bank_revisit_v2474", rows=reused_v1620, total_ms=_pkm_speed_ms() - speed_total_start)
                    self._release_widget_stack_transition_later(reason="ready_bank_revisit_v2474:%s" % sid, delay_ms=0)
                    return
            gate_token_v1620 = self._section_first_visit_gate_begin_v1620(
                cache_key, reason="data_only_or_hidden_rebuild_v2474",
                force_ui_wait_v1796=True, force_delayed_spinner_v2474=True
            )
            snapshot_before_v2474 = bool(
                len(list(getattr(self, "_section_render_snapshots_v2473", {}).get(cache_key) or []))
                == len(cached_rows or [])
            )
            # PKM_PATCH_ACTIVE v2587 sidebar_physical_bank_firstpaint_fix
            # A persisted scene/snapshot is data/presentation state only.  It does
            # not mean a native A/B bank is physically bound in this Kodi process.
            # V2586 incorrectly treated scene_v1620/snapshot presence as a reason
            # to skip partial first paint, so cold focus still rebuilt all 60-80
            # cards before swapping.  Only a physically reusable bank may bypass
            # the instant first-paint path.
            prebuilt_before_v2586 = bool(cache_key in self._section_prebuilt_listitems_v1644)
            physical_ready_bank_v2587 = ""
            try:
                physical_ready_bank_v2587 = self._section_ready_bank_for_scene_v1620(cache_key) if scene_v1620 else ""
            except Exception:
                physical_ready_bank_v2587 = ""
            instant_firstpaint_v2586 = bool(
                not physical_ready_bank_v2587 and len(cached_rows or []) > 10
            )
            _log("SECTION_SIDEBAR_PHYSICAL_BANK_DECISION_V2587 key=%s scene=%d snapshot=%d prebuilt_listitems=%d physical_bank=%s instant=%d rows=%d" % (
                cache_key, 1 if scene_v1620 else 0, 1 if snapshot_before_v2474 else 0,
                1 if prebuilt_before_v2586 else 0, physical_ready_bank_v2587 or "none",
                1 if instant_firstpaint_v2586 else 0, len(cached_rows or [])
            ))
            if not instant_firstpaint_v2586:
                try:
                    self._section_snapshot_prebuild_v2473(cache_key, cached_rows)
                except Exception:
                    pass
            else:
                _log("SECTION_SIDEBAR_FULL_SNAPSHOT_BYPASS_V2586 key=%s rows=%d reason=focus_firstpaint native_prebuild=0" % (
                    cache_key, len(cached_rows or [])
                ))
            prebuilt_ready_v1644 = bool(cache_key in self._section_prebuilt_listitems_v1644)
            fast_revisit_v1620 = bool(scene_v1620 or prebuilt_ready_v1644)
            _log("SECTION_RENDER_WAIT_POLICY_V2474 key=%s rows=%d snapshot=%d native_prebuilt=%d token=%s delay_ms=%d previous_scene_hold=1 instant_v2586=%d" % (
                cache_key, len(cached_rows or []), 1 if snapshot_before_v2474 else 0,
                1 if prebuilt_ready_v1644 else 0, gate_token_v1620 or "",
                1000, 1 if instant_firstpaint_v2586 else 0
            ))
            if use_section_xml_rows:
                if sidebar_placeholder_v1305:
                    # v1315: cached recommendation rows already have stable poster URLs.
                    # Do not cover them with the skeleton overlay again; let Kodi reuse
                    # its texture cache immediately. This fixes the "same poster is cached
                    # but still waits behind placeholder" symptom.
                    try:
                        self._section_placeholder_clear_v1305(reason="cache_restore_no_placeholder_v1315:%s" % cache_key)
                    except Exception:
                        pass
                    try:
                        _log("SECTION_PLACEHOLDER_SKIP_V1315 reason=cache_restore_texture_cache_reuse key=%s rows=%d" % (cache_key, len(cached_rows or [])))
                    except Exception:
                        pass
                progressive_cold_v2585 = bool(instant_firstpaint_v2586)
                render_rows_v2585 = list(cached_rows or [])
                if progressive_cold_v2585:
                    render_rows_v2585 = self._section_instant_firstpaint_rows_v2586(cached_rows)
                    if not hasattr(self, "_section_progressive_pending_keys_v2585"):
                        self._section_progressive_pending_keys_v2585 = set()
                    self._section_progressive_pending_keys_v2585.add(cache_key)
                    self._section_progressive_firstpaint_key_v2585 = cache_key
                    _log("SECTION_SIDEBAR_INSTANT_FIRSTPAINT_BEGIN_V2586 key=%s source_rows=%d firstpaint_rows=%d spinner_threshold_ms=1500 ab_swap=1 full_snapshot_prebuild=0 texture_wait=0" % (
                        cache_key, len(cached_rows or []), len(render_rows_v2585 or [])
                    ))
                try:
                    added_cache = self._section_render_xml_rows(
                        render_rows_v2585, reason=("SECTION_SIDEBAR_INSTANT_FIRSTPAINT_V2586" if progressive_cold_v2585 else "SECTION_RECOMMEND_CACHE_RESTORE_V1620"),
                        publish_title=(scene_v1620 or {}).get("title") or title,
                        publish_count=(scene_v1620 or {}).get("count") or "추천",
                        scene_cache_key_v1620=cache_key,
                        fast_revisit_v1620=fast_revisit_v1620,
                        precomputed_meta_v1620=(scene_v1620 or {}).get("meta") or self._section_prebuilt_meta_v1644.get(cache_key),
                        gate_token_v1620=gate_token_v1620
                    )
                finally:
                    if progressive_cold_v2585:
                        self._section_progressive_firstpaint_key_v2585 = ""
                if added_cache <= 0:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="cache_stage_failed", only_if_key=cache_key
                    )
                    _log("SECTION_TRUE_AB_KEEP_CURRENT_V1612 section=%s reason=cache_stage_failed" % sid, xbmc.LOGWARNING)
                    return
                self._commit_section_recommend_visible(title, "추천", reason=("progressive_firstpaint_v2585:%s" % sid) if progressive_cold_v2585 else ("cache_restore:%s" % sid))
                if progressive_cold_v2585:
                    _log("SECTION_SIDEBAR_INSTANT_FIRSTPAINT_VISIBLE_V2586 key=%s firstpaint_items=%d full_items=%d spinner_policy=retained_delayed target_ms_lt_250=1" % (
                        cache_key, added_cache, len(cached_rows or [])
                    ))
                    self._section_progressive_full_fill_v2585(
                        cache_key, cached_rows, (scene_v1620 or {}).get("title") or title,
                        (scene_v1620 or {}).get("count") or "추천",
                        meta_snapshot=(scene_v1620 or {}).get("meta") or self._section_prebuilt_meta_v1644.get(cache_key)
                    )
                _log("SECTION_RECOMMEND_CACHE_RESTORE_XML section=%s title=%s added=%d controls=8410-8470 progressive_v2585=%d" % (sid, title, added_cache, 1 if progressive_cold_v2585 else 0))
                _speed_log("section_recommend_show_end", section=sid, title=title, result="cache_restore_xml", rows=added_cache, total_ms=_pkm_speed_ms() - speed_total_start)
                self._release_widget_stack_transition_later(reason="section_recommend_cache_ready:%s" % sid, delay_ms=20)
            else:
                self._set_wall_items_from_rows(cached_rows, log_prefix="SECTION_RECOMMEND_CACHE_RESTORE")
                _speed_log("section_recommend_show_end", section=sid, title=title, result="cache_restore_wall", rows=len(cached_rows or []), total_ms=_pkm_speed_ms() - speed_total_start)
            # v1620: a completed scene is immutable on re-entry. Do not start
            # post-publish movie/TV workers that would visibly replace lower rows.
            # Plex dirty handling may invalidate/rebuild the cache on a later visit.
            _speed_log("section_scene_revisit_complete_v2474", section=sid, rows=len(cached_rows or []), spinner_policy="shared_delayed" if gate_token_v1620 else "none_native")
            return

        if not gate_token_v1620:
            gate_token_v1620 = self._section_first_visit_gate_begin_v1620(
                cache_key, reason="cold_section_build"
            )
        wall = None if use_section_xml_rows else self.getControl(WALL_ID)
        if wall is not None:
            wall.reset()
        # v353: Do not clear the current recommendation rows before the new
        # section rows are actually ready.  On rapid sidebar movement, clearing
        # here makes the right widget area look blank/late until DB queries and
        # rendering finish.  _section_render_xml_rows() still resets/switches the
        # XML rows atomically right before painting the new section, so Kodi XML
        # navigation remains unchanged and there is no Python focus movement.
        rows_cache = []
        added = 0
        try:
            home_columns = max(1, int(self._wall_column_count()))
        except Exception:
            home_columns = 6

        section_type = item.getProperty("section_type") or self._section_type_for_id(sid)
        is_movie_extra_target = self._is_movie_recommend_section(sid, section_type)
        is_tv_target = self._is_tv_recommend_section(sid, section_type)
        seen_keys = set()
        recent_viewed_rows = []

        # 1) Library-local Continue Watching.  If there are no resume items in
        # this library, the row is not created and the next widget moves up.
        # V2589: TV recommendation cold first-paint is local-first.  A stale local
        # Continue snapshot is good enough for the first visible scene; Plex
        # /library/onDeck refresh remains deferred and must not block tab focus.
        continue_rows = self._section_continue_rows(
            sid, limit=max(120, HOME_ROW_ITEM_LIMIT), local_first_v2589=bool(is_tv_target)
        )
        for row in continue_rows or []:
            try:
                rk = str((tuple(row or ())[0]) or "")
                if rk:
                    seen_keys.add(rk)
            except Exception:
                pass
        append_before = added
        added = self._append_recommend_row_items(wall, rows_cache, "이어보기", continue_rows, sid, added)
        _speed_log("section_recommend_core_row_append", section=sid, sort="continue", title="이어보기", visible_rows=len(continue_rows or []), added_delta=added - append_before)

        if is_tv_target:
            # v466: Drama/TV Recommendation tab now follows the requested widget plan:
            # Continue Watching + recent airing/added + start random + rewatch + top rated + random studio.
            # These are data-only rows rendered into the existing 8410~8470 XML controls.
            extra_rows = self._build_tv_requested_rows_cache(sid, title, home_columns, added, exclude_keys=seen_keys)
            if extra_rows:
                rows_cache.extend(extra_rows)
                added += len(extra_rows)
        else:
            row_plan = []
            if is_movie_extra_target:
                row_plan = [
                    ("viewed", "최근 본 영화", None),
                    ("added", "최근 추가됨", None),
                ]
            else:
                row_plan = [
                    ("added", self._section_recommend_row_title(title, "added"), None),
                    ("viewed", self._section_recent_viewed_row_title(title), None),
                ]

            for sort_name, row_title, plex_type in row_plan:
                visible_rows = self._query_section_rows_for_widget(sid, sort_name, row_title, home_columns, seen_keys=seen_keys, plex_type=plex_type)
                if sort_name == "viewed":
                    recent_viewed_rows = list(visible_rows or [])
                append_before = added
                added = self._append_recommend_row_items(wall, rows_cache, row_title, visible_rows, sid, added)
                _speed_log("section_recommend_core_row_append", section=sid, sort=sort_name, title=row_title, plex_type=plex_type or "", visible_rows=len(visible_rows or []), added_delta=added - append_before)

        # v295: Plex HTPC library recommendation rows based on the user's most
        # recently watched item in this section.  These rows are best-effort and
        # intentionally limited to one visual row each so large libraries do not
        # block initial focus movement.
        extra_start = _pkm_speed_ms()
        extra_added_before = added
        # v191: keep v190 first-paint speed, but start movie-only extra rows
        # (taste Korean/foreign movies + director works) in the background.
        # The first 3 rows render immediately; rows 4~6 are appended to lower XML
        # row controls when ready and are cached for the current Kodi run.
        if is_movie_extra_target:
            _speed_log("section_recommend_extra_rows_deferred", section=sid, reason="movie_extra_background", base_recent_rows=len(recent_viewed_rows or []))
        elif is_tv_target:
            _speed_log("section_recommend_extra_rows_deferred", section=sid, reason="tv_actor_studio_deferred_worker", base_recent_rows=len(recent_viewed_rows or []))
        else:
            _speed_log("section_recommend_extra_rows_deferred", section=sid, reason="generic_section", base_recent_rows=len(recent_viewed_rows or []))
        _speed_log("section_recommend_extra_rows_total", section=sid, added_delta=added - extra_added_before, total_ms=_pkm_speed_ms() - extra_start, deferred=1 if (is_movie_extra_target or is_tv_target) else 0, movie_extra=1 if is_movie_extra_target else 0, tv_extra=1 if is_tv_target else 0)

        self._section_rows_cache[cache_key] = rows_cache
        if use_section_xml_rows:
            render_start = _pkm_speed_ms()
            if sidebar_placeholder_v1305:
                self._section_placeholder_show_v1305(rows_cache, reason="sidebar_built_v1315:%s" % cache_key)

            # PKM_PATCH_ACTIVE v2589 tv_recommend_cold_instant_firstpaint
            # V2588 still rendered the entire freshly-built TV recommendation scene
            # (typically 50-80 cards), waited for the first-viewport poster gate,
            # and could also block on live /library/onDeck before the first swap.
            # Build data locally, bind only the first visible rails, publish A/B
            # immediately, then complete the full bank behind the already-visible
            # scene using the proven V2586 progressive fill path.
            # V2715: V2709 already classified cold movie sidebar focus as a
            # zero-wait transaction, but the progressive first-paint branch was
            # accidentally TV-only.  That made movies fall through to the full
            # 41+ item compose and synchronous first-viewport poster gate before
            # the fast path could ever publish.  Use the same proven partial A/B
            # first-paint for both movie and TV recommendation sections.
            cold_progressive_v2589 = bool((is_tv_target or is_movie_extra_target) and len(rows_cache or []) > 10)
            if cold_progressive_v2589:
                render_rows_v2589 = self._section_instant_firstpaint_rows_v2586(rows_cache)
                if not hasattr(self, "_section_progressive_pending_keys_v2585"):
                    self._section_progressive_pending_keys_v2585 = set()
                self._section_progressive_pending_keys_v2585.add(cache_key)
                self._section_progressive_firstpaint_key_v2585 = cache_key
                _log("SECTION_COLD_INSTANT_FIRSTPAINT_BEGIN_V2715 key=%s full_items=%d firstpaint_items=%d continue_network=0 poster_wait=0 ab_swap=1" % (
                    cache_key, len(rows_cache or []), len(render_rows_v2589 or [])
                ))
                try:
                    added = self._section_render_xml_rows(
                        render_rows_v2589, reason="SECTION_SIDEBAR_INSTANT_FIRSTPAINT_V2586",
                        publish_title=title, publish_count="추천",
                        scene_cache_key_v1620=cache_key, fast_revisit_v1620=False,
                        gate_token_v1620=gate_token_v1620
                    )
                finally:
                    self._section_progressive_firstpaint_key_v2585 = ""
                if added <= 0:
                    self._section_first_visit_gate_cancel_v1620(
                        reason="cold_firstpaint_stage_failed_v2589", only_if_key=cache_key
                    )
                    _log("SECTION_TRUE_AB_KEEP_CURRENT_V1612 section=%s reason=cold_firstpaint_stage_failed_v2589" % sid, xbmc.LOGWARNING)
                    return
                self._commit_section_recommend_visible(title, "추천", reason="cold_progressive_firstpaint_v2589:%s" % sid)
                render_ms = _pkm_speed_ms() - render_start
                self.wall_total = len(rows_cache or [])
                self.wall_offset = len(rows_cache or [])
                _log("SECTION_COLD_INSTANT_FIRSTPAINT_VISIBLE_V2715 key=%s firstpaint_items=%d full_items=%d render_ms=%d spinner=0 full_fill=background" % (
                    cache_key, added, len(rows_cache or []), render_ms
                ))
                self._section_progressive_full_fill_v2585(
                    cache_key, rows_cache, title, "추천", meta_snapshot=None
                )
                _speed_log("section_recommend_render_xml", section=sid, title=title, rows=len(render_rows_v2589 or []), added=added, render_ms=render_ms)
                _speed_log("section_recommend_show_end", section=sid, title=title, result="cold_progressive_firstpaint_v2589", rows=added, total_ms=_pkm_speed_ms() - speed_total_start)
                self._release_widget_stack_transition_later(reason="section_recommend_cold_firstpaint_v2589:%s" % sid, delay_ms=20)
                _speed_log("tv_dynamic_rows_worker_defer_v2589", section=sid, reason="full_scene_background_after_firstpaint", base_rows=len(rows_cache or []))
                return

            added = self._section_render_xml_rows(
                rows_cache, reason="SECTION_RECOMMEND_APPEND_V1620",
                publish_title=title, publish_count="추천",
                scene_cache_key_v1620=cache_key, fast_revisit_v1620=False,
                gate_token_v1620=gate_token_v1620
            )
            if added <= 0:
                self._section_first_visit_gate_cancel_v1620(
                    reason="built_stage_failed", only_if_key=cache_key
                )
                _log("SECTION_TRUE_AB_KEEP_CURRENT_V1612 section=%s reason=built_stage_failed" % sid, xbmc.LOGWARNING)
                return
            self._commit_section_recommend_visible(title, "추천", reason="built:%s" % sid)
            render_ms = _pkm_speed_ms() - render_start
            self.wall_total = added
            self.wall_offset = added
            _log("SECTION_RECOMMEND_APPEND_XML section=%s title=%s added=%d columns=%d total=%d controls=8410-8470" % (sid, title, added, home_columns, total))
            _speed_log("section_recommend_render_xml", section=sid, title=title, rows=len(rows_cache or []), added=added, render_ms=render_ms)
            _speed_log("section_recommend_show_end", section=sid, title=title, result="built_xml", rows=added, total_ms=_pkm_speed_ms() - speed_total_start)
            self._release_widget_stack_transition_later(reason="section_recommend_built_ready:%s" % sid, delay_ms=20)
            if is_movie_extra_target:
                # V2709: expensive movie recommendation enrichment is no longer
                # part of the sidebar foreground transaction.
                self._start_movie_extra_rows_worker(
                    cache_key, sid, title, recent_viewed_rows, home_columns, added
                )
                _speed_log("movie_extra_rows_worker_start_v2709", section=sid, reason="postvisible_zero_wait", base_rows=len(rows_cache or []))
            elif is_tv_target:
                _speed_log("tv_dynamic_rows_worker_skip_v1620", section=sid, reason="completed_scene_no_visible_mutation", base_rows=len(rows_cache or []))
            return
        self.wall_total = added
        self.wall_offset = added
        self._sync_wall_first_key("section_recommend_append:%s" % sid)
        try:
            if wall.size() > 0:
                wall.selectItem(0)
                self._logical_wall_pos = 0
                self._last_wall_pos = 0
                self._set_home_meta_from_item(reason="section_recommend_initial")
                self._track_wall_selection("section_recommend_initial")
        except Exception:
            pass
        _log("SECTION_RECOMMEND_APPEND section=%s title=%s added=%d columns=%d total=%d" % (sid, title, added, home_columns, total))
        _speed_log("section_recommend_show_end", section=sid, title=title, result="built_wall", rows=added, total_ms=_pkm_speed_ms() - speed_total_start)

    def _show_section_recommend_widgets_step1(self, force, item, sid):
        """Step 1 of _show_section_recommend_widgets (R76 split, moved verbatim). Logs: SECTION_WIDGET_CACHE_UPGRADE_R154, PLEX_UPDATE_REUSE_ALLOWED, PLEX_UPDATE_DIRTY_NO_CACHE_V1635."""
        title = _display_library_title(item.getProperty("section_title") or item.getLabel())
        total = _safe_int(item.getProperty("total"), 0)
        cache_key = "recommend:%s" % sid
        sidebar_placeholder_v1305 = False
        # v1612: no previous-screen copy and no active-bank reset. The hidden
        # bank itself is the target staging surface.
        self._sidebar_widget_atomic_hold_v1556 = False
        self._section_transition_prev_rows = []
        try:
            self.clearProperty("PlexKM.SectionTransitionPrevVisible")
            xbmcgui.Window(10000).clearProperty("PlexKM.SectionTransitionPrevVisible")
        except Exception:
            pass

        # v2467: a completed section scene may survive Kodi restarts, but only
        # while the synchronized local authority fingerprint still matches.
        # This restores immutable row data only; A/B native controls are rebuilt
        # from that ready data and Plex reconciliation remains unchanged.
        if not self._section_rows_cache.get(cache_key):
            self._section_persistent_scene_get_v2467(cache_key)
        # R154: old persisted rows may contain 24 cards and miss watched episodes.
        # Rebuild this section from local authority once rather than showing a
        # stale 24/3-card scene. Home and Library caches are untouched.
        cached_policy_rows_r154 = list(self._section_rows_cache.get(cache_key) or [])
        if cached_policy_rows_r154 and not all(
                isinstance(e, dict) and e.get("r154_policy") == SECTION_RECOMMEND_POLICY_R154
                for e in cached_policy_rows_r154):
            self._section_persistent_scene_invalidate_v2467(cache_key, reason="r154_section_widget_limits")
            self._sidebar_prepare_invalidate(sid)
            _log("SECTION_WIDGET_CACHE_UPGRADE_R154 key=%s prior=%d rebuild=data_only" % (
                cache_key, len(cached_policy_rows_r154)
            ))
        scene_before_dirty_v1621 = self._section_scene_get_v1620(cache_key)
        cached_rows_before_dirty = self._section_rows_cache.get(cache_key)
        section_dirty = self._consume_plex_update_section_dirty(sid, reason="show_section_recommend", force=force)
        if section_dirty:
            self._sidebar_prepare_invalidate(sid)
            try:
                self._library_persistent_scene_invalidate_section_v2470(
                    sid, reason="plex_dirty_from_recommend"
                )
            except Exception:
                pass
        if section_dirty and cache_key in getattr(self, "_section_persistent_hit_keys_v2467", set()):
            # A real dirty signal always wins over restart cache reuse.
            self._section_persistent_scene_invalidate_v2467(cache_key, reason="plex_dirty")
            scene_before_dirty_v1621 = None
            cached_rows_before_dirty = None
        if section_dirty:
            if cached_rows_before_dirty:
                # v883: cache-first dirty handling.  Show existing rows immediately
                # and let the background Plex recent sync update DB/cache later.
                # This keeps library switching smooth even when Plex reports dirty.
                force = False
                _log("PLEX_UPDATE_REUSE_ALLOWED scope=section section=%s reason=dirty_cache_first rows=%d" % (sid, len(cached_rows_before_dirty or [])))
            else:
                # v1635: dirty is a data-refresh signal only. It must not turn
                # sidebar focus into a forced cold visual path. Build behind the
                # currently visible scene and publish atomically when complete.
                _log("PLEX_UPDATE_DIRTY_NO_CACHE_V1635 scope=section section=%s action=background_compose_keep_previous_scene force_unchanged=%s" % (sid, "1" if force else "0"))
        now_ms = int(time.time() * 1000)
        _speed_log("section_recommend_show_start", section=sid, title=title, force=force, total=total, dirty=1 if section_dirty else 0)
        return cache_key, force, now_ms, sidebar_placeholder_v1305, title, total

    def _show_section_recommend_widgets_step2(self, cache_key, cached_rows, scene_v1620, section_type_v1616, sid, title):
        """Step 2 of _show_section_recommend_widgets (R76 split, moved verbatim). Logs: SECTION_CONTINUE_CACHE_RECONCILE_FAILED, SIDEBAR_MOVIE_ZERO_WAIT_V2709, SIDEBAR_MOVIE_STUCK_CORE_HEALED_R44."""
        if cached_rows:
            try:
                cached_rows, continue_cache_changed = self._section_reconcile_cached_continue_rows(
                    sid, cached_rows
                )
                if continue_cache_changed:
                    scene_v1620 = None
            except Exception:
                _log(
                    "SECTION_CONTINUE_CACHE_RECONCILE_FAILED section=%s err=%s" % (
                        sid, traceback.format_exc().replace(chr(10), " | ")
                    ),
                    xbmc.LOGWARNING,
                )
        movie_target_v1616 = self._is_movie_recommend_section(sid, section_type_v1616)
        if movie_target_v1616:
            cached_groups_v1616 = self._section_rows_group_count(cached_rows or [])
            cached_titles_v1616 = self._movie_full_compose_group_titles_v1616(cached_rows or [])
            full_ready_v1616 = bool(
                cached_rows and cached_groups_v1616 > 3
                and self._movie_full_compose_titles_valid_v1616(cached_titles_v1616, require_extra=True)
            )
            if not full_ready_v1616:
                # R44: a core-only cache can be a permanent stand-in left behind
                # by an early fast first-paint build (it is never replaced
                # because the background-prepare consume below only fires when
                # the cache was *empty*, which this is not). A full compose may
                # already be sitting finished and unconsumed in the prepare
                # queue -- pick it up now instead of leaving this section stuck
                # without 취향/감독작/출연작 rows for the rest of the session.
                # R47: retire the stale 3-group scene first, or the scene
                # lookup right below resurrects its 32 core rows over the
                # freshly consumed full compose (and the revisit fast path
                # keeps reusing the old 3-row native bank).
                if self._sidebar_prepare_ready_groups_r47(sid) > 3:
                    self._section_stale_core_scene_retire_r47(cache_key, reason="r47_stuck_core_heal")
                if self._sidebar_prepare_consume(sid):
                    cached_rows = self._section_rows_cache.get(cache_key)
                    scene_v1620 = self._section_scene_get_v1620(cache_key)
                    cached_groups_v1616 = self._section_rows_group_count(cached_rows or [])
                    cached_titles_v1616 = self._movie_full_compose_group_titles_v1616(cached_rows or [])
                    full_ready_v1616 = bool(
                        cached_rows and cached_groups_v1616 > 3
                        and self._movie_full_compose_titles_valid_v1616(cached_titles_v1616, require_extra=True)
                    )
                    _log("SIDEBAR_MOVIE_STUCK_CORE_HEALED_R44 key=%s rows=%d groups=%d full_ready=%d" % (
                        cache_key, len(cached_rows or []), cached_groups_v1616, 1 if full_ready_v1616 else 0
                    ))
            if not full_ready_v1616:
                # V2709: never run the expensive full movie compose synchronously
                # from the sidebar-focus WindowXML callback. Fall through to the
                # normal cache/cold first-paint path so native focus can publish
                # the core rows immediately.
                _log("SIDEBAR_MOVIE_ZERO_WAIT_V2709 key=%s cached_rows=%d groups=%d scene=%d action=core_firstpaint_no_foreground_full_compose" % (
                    cache_key, len(cached_rows or []), cached_groups_v1616, 1 if scene_v1620 else 0
                ))
                # R44: nothing was ready to consume either -- make sure a full
                # background compose is actually queued so a LATER visit to
                # this section can self-heal the same way. Without this, a
                # section whose core-only cache was seeded before the full
                # compose finished could stay core-only forever.
                # R45: use priority=True. A prior attempt that ever failed
                # once (e.g. a transient DB hiccup) is otherwise never
                # retried by a non-priority enqueue, which would explain a
                # section healing only partially (one stale failure latched
                # forever) instead of reaching the full 7-group compose.
                try:
                    self._sidebar_prepare_enqueue(sid, title, priority=True)
                except Exception:
                    pass
        return cached_rows, scene_v1620

    def _commit_section_view_mode_v1841(self, mode, reason=""):
        """Expose exactly one already-prepared section surface."""
        mode = str(mode or "").strip().lower()
        if mode not in ("wall", "category"):
            return False
        try:
            focus_before_v2120 = self._safe_focus_id()
            win = xbmcgui.Window(10000)
            source_mode_v2479 = self._pkm_surface_mode_v2479()
            target_mode_v2479 = "section_library" if mode == "wall" else "section_category"
            swap_token_v2479 = ""
            wall_decode_stage_v2496 = False
            if source_mode_v2479 != target_mode_v2479:
                swap_token_v2479 = self._pkm_swap_settle_v2479(
                    source_mode_v2479, target_mode_v2479,
                    reason="section_mode_target_ready:%s" % (reason or ""),
                    wait_ms=0 if mode == "wall" else 16
                )
                if mode == "wall":
                    # V2496: make the already-localized wall render underneath the
                    # still-visible source scene for several GUI frames.  The wall
                    # panel is earlier in XML z-order than Home/Recommendation, so
                    # this warms Kodi's decoder/texture objects without exposing it.
                    # v2502: warm only the native wall panel underneath the source.
                    # Do NOT publish IsSectionWall during the decoder runway: that
                    # property also hides the recommendation hero/meta immediately.
                    #
                    # v2503: when the source is Recommendation, use the SAME 96 ms
                    # decoder runway as a sequential handoff phase.  Only the two
                    # recommendation widget banks fade to zero (80 ms); hero/meta,
                    # tabs and the source backdrop stay alive.  The Library panel is
                    # still decode-only during this phase.  IsSectionWall is published
                    # only after the old widget rails are already invisible, so Kodi
                    # can no longer draw Recommendation posters over Library posters.
                    if source_mode_v2479 == "section_recommend":
                        for fade_target_v2503 in (win, self):
                            fade_target_v2503.setProperty("PlexKM.Scene.RecommendWidgetFadeOutV2503", "1")
                        _log("RECOMMEND_WIDGET_PREFLIGHT_FADE_V2503 fade_ms=80 runway_ms=96 source_hero_held=1 library_hidden=1 overlap_widgets=0")
                    for stage_target_v2496 in (win, self):
                        stage_target_v2496.setProperty("PlexKM.Scene.LibraryDecodeStageV2502", "1")
                    decode_wait_ms = 32 if xbmc.getCondVisibility("System.Platform.Android") else 96
                    xbmc.sleep(decode_wait_ms)
                    wall_decode_stage_v2496 = True
                    _log("LIBRARY_TARGET_DECODE_STAGE source=%s target=%s wait_ms=%d source_hero_held=1 source_widgets_prefaded=%d target_panel_decode_only=1 local_firstpaint=18 sequential_handoff=1" % (
                        source_mode_v2479, target_mode_v2479, decode_wait_ms,
                        1 if source_mode_v2479 == "section_recommend" else 0
                    ))
                    _log("LIBRARY_TARGET_DECODE_STAGE_V2503 source=%s target=%s wait_ms=%d source_hero_held=1 source_widgets_prefaded=%d target_panel_decode_only=1 local_firstpaint=18 sequential_handoff=1" % (
                        source_mode_v2479, target_mode_v2479, decode_wait_ms,
                        1 if source_mode_v2479 == "section_recommend" else 0
                    ))
            # R35: retire Info/Actor at the Library/Category commit boundary (R18 parity).
            if source_mode_v2479 in ("info", "actor_profile"):
                self._section_commit_overlay_retire_r35(target_mode_v2479, reason=reason or "section_mode")
            for target in (win, self):
                # v2120: destination-first atomic section-mode handoff.  The
                # header tabs 7710/7720/7725 are visible while any of the three
                # section mode properties is true.  Older code cleared the old
                # mode first, briefly making every tab invisible and dropping
                # Kodi's native focus.  Make the destination visible first; an
                # overlap frame is harmless and preserves the focused control.
                if mode == "wall":
                    target.setProperty("PlexKM.Window.IsSectionWall", "1")
                else:
                    target.setProperty("PlexKM.Window.IsSectionCategory", "1")
                target.clearProperty("PlexKM.Window.HomeLayout")
                target.clearProperty("PlexKM.Window.IsHome")
                target.clearProperty("PlexKM.Window.IsSectionRecommend")
                if mode == "wall":
                    target.clearProperty("PlexKM.Window.IsSectionCategory")
                else:
                    target.clearProperty("PlexKM.Window.IsSectionWall")
                target.clearProperty("PlexKM.WidgetTransitionHold")
                # v2502: the real destination mode now owns visibility; retire the
                # decode-only wall stage without affecting the crossfade.
                target.clearProperty("PlexKM.Scene.LibraryDecodeStageV2502")
            self._widget_transition_active = False
            self._set_published_section_id_v2121(
                getattr(self, "active_section_id", "") or "",
                reason="section_%s_commit:%s" % (mode, reason or "")
            )
            try:
                self._search_info_sidebar_ab_commit_v2284(
                    section_id=getattr(self, "active_section_id", "") or "",
                    reason="section_%s:%s" % (mode, reason or "")
                )
            except Exception:
                pass
            if swap_token_v2479:
                self._pkm_swap_finish_v2479(
                    swap_token_v2479, source_mode_v2479, target_mode_v2479, reason="section_mode_commit:%s" % (reason or "")
                )
            focus_after_v2120 = self._safe_focus_id()
            _log("SECTION_MODE_ATOMIC_FOCUS_V2120 mode=%s reason=%s focus_before=%s focus_after=%s python_focus_write=0 zero_visibility_gap=0" % (
                mode, reason or "", focus_before_v2120, focus_after_v2120
            ))
            _log("SECTION_VIEW_MODE_EXCLUSIVE_V1963 mode=%s home=0 recommend=0 wall=%d category=%d reason=%s" % (
                mode, 1 if mode == "wall" else 0, 1 if mode == "category" else 0, reason or ""
            ))
            _log("SECTION_VIEW_MODE_COMMIT_V1841 mode=%s reason=%s ready_before_visible=1 v2496_decode_stage=%d v2503_target_fade_ms=180 recommend_widget_prefade_ms=80 sequential_widgets=1 source_hero_held_until_target_ready=1 no_blank=1" % (
                mode, reason or "", 1 if wall_decode_stage_v2496 else 0
            ))
            return True
        except Exception:
            try:
                _stage_win_v2502 = xbmcgui.Window(10000)
                for _stage_target_v2502 in (self, _stage_win_v2502):
                    _stage_target_v2502.clearProperty("PlexKM.Scene.LibraryDecodeStageV2502")
                    _stage_target_v2502.clearProperty("PlexKM.Scene.RecommendWidgetFadeOutV2503")
            except Exception:
                pass
            _log("SECTION_VIEW_MODE_COMMIT_FAILED_V1841 mode=%s reason=%s err=%s" % (
                mode, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _show_section_wall_ready_commit_v1841(self, item, force=False):
        """Prepare target rows and ListItems before changing visible wall state."""
        if not item:
            return False
        sid = str(item.getProperty("section_id") or "")
        if not sid:
            return False
        try:
            dirty_v2470 = self._consume_plex_update_section_dirty(
                sid, reason="show_section_library_v2470", force=False
            )
            if dirty_v2470:
                self._library_persistent_scene_invalidate_section_v2470(
                    sid, reason="plex_dirty_from_library"
                )
        except Exception:
            pass
        # v2067 core Library policy: Library is a local-DB paged wall, not a
        # recommendation-scene transaction. Entering Library immediately retires
        # any recommendation first-visit ownership and must never arm a global
        # busy/spinner gate of its own.
        try:
            self._section_first_visit_gate_cancel_v1620(
                reason="library_direct_enter_v2067"
            )
        except Exception:
            pass
        _stype_v1966 = str(item.getProperty("section_type") or "").lower().strip()
        if not _stype_v1966:
            try:
                for _sec_v2470 in list(getattr(self, "sections", []) or []):
                    if str((_sec_v2470 or {}).get("section_id") or (_sec_v2470 or {}).get("key") or "").strip() == sid:
                        _stype_v1966 = str((_sec_v2470 or {}).get("section_type") or (_sec_v2470 or {}).get("type") or "").lower().strip()
                        break
            except Exception:
                _stype_v1966 = ""
        _is_tv_v1966 = _stype_v1966 in ("show", "tv", "tvshow", "series", "episode", "season")
        for _target_v1966 in (self, xbmcgui.Window(10000)):
            if _is_tv_v1966:
                _target_v1966.setProperty("PlexKM.Section.IsTV", "1")
            else:
                _target_v1966.clearProperty("PlexKM.Section.IsTV")
        title = _display_library_title(item.getProperty("section_title") or item.getLabel())
        total_raw_v1841 = str(item.getProperty("total") or "").strip()
        total_known_v1841 = bool(total_raw_v1841)
        total = _safe_int(total_raw_v1841, 0)
        previous_sid = str(getattr(self, "active_section_id", "") or "")
        genre_owner = str(getattr(self, "_active_genre_section_id", "") or "")
        current_genre = str(getattr(self, "_active_genre_filter", "") or "")
        target_genre = current_genre if current_genre and genre_owner == sid else ""
        target_genre_count = (
            int(getattr(self, "_active_genre_count", 0) or 0)
            if target_genre else 0
        )
        # v2470: resolve the exact wall key before any total/query work.  The
        # section type already exists on the sidebar ListItem, so the prepared
        # restart path does not need a DB probe merely to normalize the sort.
        _stype_sort_v2470 = str(item.getProperty("section_type") or _stype_v1966 or "").lower().strip()
        target_media_kind_v1911 = "tv" if _stype_sort_v2470 in ("show", "tv", "tvshow", "series", "episode", "season") else "movie"
        raw_target_sort_v1911 = str(getattr(self, "sort", "title") or "title")
        target_sort = self._normalize_section_sort(
            raw_target_sort_v1911, media_kind=target_media_kind_v1911
        )
        if target_sort != pkm_library_sort.normalize_sort_key(raw_target_sort_v1911):
            target_sort_dir = pkm_library_sort.default_sort_dir(target_sort)
        else:
            target_sort_dir = self._normalize_sort_dir(
                getattr(self, "sort_dir", pkm_library_sort.default_sort_dir(target_sort))
            )
        cache_key, library_gate_token_v1863, post_reveal_data_warm_v2472, prepared_fast_v2470, retained_hidden_candidate_v2470, startup_prepared_v2470 = self._show_section_wall_ready_commit_v1841_step1(force, sid, target_genre, target_sort, target_sort_dir)
        # v1870: Plex show sections expose both show and episode rows in the
        # local cache. Library mode counts and pages season folders instead of
        # treating every episode as an independent poster.
        if prepared_fast_v2470 or post_reveal_data_warm_v2472 or retained_hidden_candidate_v2470:
            tv_folder_total_v1870 = None
            target_total_v1870 = int(self._section_total_cache.get(cache_key, total) or 0)
            target_total_known_v1870 = True
            _log("LIBRARY_FOCUS_TOTAL_QUERY_SKIP_V2470 key=%s section=%s focus_io=0 total=%d source=%s" % (
                cache_key, sid, target_total_v1870,
                ("startup_hydrated" if startup_prepared_v2470 else "memory_prebuilt")
                if prepared_fast_v2470 else ("post_reveal_data_warm_v2472" if post_reveal_data_warm_v2472 else "retained_hidden")
            ))
        else:
            tv_folder_total_v1870 = self._query_library_wall_total_v1870(
                sid, genre=(target_genre or None)
            )
            target_total_v1870 = (
                int(tv_folder_total_v1870)
                if tv_folder_total_v1870 is not None
                else (target_genre_count if target_genre else total)
            )
            target_total_known_v1870 = bool(
                tv_folder_total_v1870 is not None
                or bool(target_genre)
                or total_known_v1841
            )
        now_ms = int(time.time() * 1000)

        # v2470 same-run Recommend -> Library: if this exact wall is still bound
        # behind the Recommendation surface, there is nothing to rebuild.  Bind
        # the already-prepared index, allow one GUI frame, then expose Library.
        try:
            wall_v2470 = self.getControl(WALL_ID)
            retained_hidden_wall_v2470 = bool(retained_hidden_candidate_v2470)
            if retained_hidden_wall_v2470:
                self.active_section_id = sid
                self._library_native_owner_section_v2070 = sid
                self._last_rendered_section_id = sid
                self._last_section_show_ms = now_ms
                self.sort = target_sort
                self.sort_dir = target_sort_dir
                self.wall_total = int(self._section_total_cache.get(cache_key, target_total_v1870) or target_total_v1870)
                # v2470: a retained hidden wall is still a new Library foreground
                # ownership generation.  Reset any append work from the previous
                # owner before arming background pagination after the atomic swap.
                retained_generation_v2470 = int(getattr(self, "_library_wall_generation_v2069", 0) or 0) + 1
                self._library_wall_generation_v2069 = retained_generation_v2470
                self._library_wall_owner_v2069 = (
                    str(sid), str(target_sort), str(target_sort_dir), str(target_genre),
                    retained_generation_v2470
                )
                self._library_append_request_v2070 = False
                try:
                    with self._library_append_prefetch_lock_v2070:
                        self._library_append_prefetch_rows_v2070.clear()
                        self._library_append_prefetch_inflight_v2070.clear()
                except Exception:
                    pass
                self._set_section_sort_property(reason="library_retained_hidden_v2470:%s" % sid, media_kind_v2470=target_media_kind_v1911)
                if cache_key in getattr(self, "_library_prebuilt_indexitems_v2470", {}):
                    self._library_bind_prebuilt_index_v2470(cache_key, sid)
                self._set_header(title, ("전체 %d" % self.wall_total) if self.wall_total else "")
                retained_lis_v2496 = []
                try:
                    retained_lis_v2496 = [
                        wall_v2470.getListItem(i)
                        for i in range(min(int(wall_v2470.size()), self._library_wall_viewport_count_v1865()))
                    ]
                except Exception:
                    retained_lis_v2496 = []
                retained_ok_v2496, retained_ready_v2496, retained_total_v2496, retained_unresolved_v2496 = self._library_firstpaint_materialize_v2496(
                    retained_lis_v2496, visible_count=self._library_wall_viewport_count_v1865(),
                    reason="retained_hidden:%s" % sid, allow_network=True
                )
                if not retained_ok_v2496:
                    _log("LIBRARY_TRANSITION_ACCEPTANCE_V2496 result=FAIL section=%s key=%s firstpaint=%d/%d unresolved=%d source_hold=1 target_publish=0 reason=retained_hidden_firstpaint_unresolved" % (
                        sid, cache_key, retained_ready_v2496, retained_total_v2496, retained_unresolved_v2496
                    ), xbmc.LOGERROR)
                    return False
                xbmc.sleep(16)
                if not self._commit_section_view_mode_v1841(
                        "wall", reason="retained_hidden_one_frame_v2470:%s" % sid):
                    raise RuntimeError("retained hidden wall mode commit failed")
                try:
                    self._section_index_sync_for_item(self._focused_wall_item(), reason="retained_hidden_v2470")
                    self._set_home_meta_from_item(reason="library_retained_hidden_v2470")
                except Exception:
                    pass
                self._start_library_append_prefetch_v2070(reason="retained_hidden_v2470")
                _log("LIBRARY_RECOMMEND_TO_LIBRARY_SWAP_ONLY_V2470 key=%s section=%s wait_ms=16 spinner=0 query=0 rating_preload=0 listitem_build=0 poster_gate=visible_local_v2593 atomic_swap=1" % (
                    cache_key, sid
                ))
                _log("LIBRARY_TRANSITION_ACCEPTANCE_V2496 result=PASS section=%s key=%s firstpaint=%d/%d unresolved=0 actual_local_required=1 source_hold_until_commit=1 reason=retained_hidden_local_firstpaint_ready" % (
                    sid, cache_key, retained_ready_v2496, retained_total_v2496
                ))
                if library_gate_token_v1863:
                    self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="retained_hidden_visible", visible=True)
                return True
        except Exception:
            _log("LIBRARY_RETAINED_HIDDEN_FAST_FAILED_V2470 section=%s key=%s err=%s" % (
                sid, cache_key, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        try:
            wall = self.getControl(WALL_ID)
            already_ready_v1841 = bool(
                self.active_section_id == sid
                and self._last_rendered_section_id == sid
                and str(getattr(self, "_active_wall_cache_key_v1841", "") or "") == cache_key
                and (
                    (wall.size() > 0 and self.wall_offset > 0)
                    or bool(getattr(self, "_active_wall_verified_empty_v1841", False))
                )
            )
            if not force and already_ready_v1841:
                self._set_header(title, str(self.wall_total if self.wall_total else ""))
                self._commit_section_view_mode_v1841(
                    "wall", reason="already_ready:%s" % sid
                )
                if wall.size() > 0:
                    self._sync_wall_first_key("section_already_rendered:%s" % sid)
                    self._section_index_build_for_section(sid, reason="already_rendered")
                    self._section_index_sync_for_item(
                        self._focused_wall_item(), reason="already_rendered"
                    )
                _log("SECTION_REBUILD_SKIPPED section=%s reason=already_ready_v1841 offset=%d" % (
                    sid, self.wall_offset
                ))
                if library_gate_token_v1863:
                    self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="already_ready_race", visible=True)
                return True
        except Exception:
            pass

        # v2069: Library remains DB-first and never waits for poster/prewarm work,
        # but every *foreground* transition obeys the common delayed-spinner policy.
        # Fast local pages complete before 1000 ms and never show a ring; a genuinely
        # slow first-page query keeps the previous completed surface underneath and
        # reveals the shared spinner after the canonical threshold.
        if prepared_fast_v2470:
            _log("LIBRARY_PREPARED_FAST_BEGIN_V2474 key=%s section=%s source=%s spinner_policy=%s query=0 rating_preload=0 poster_gate=visible_local_v2593 focus_io=0 native_ready=1" % (
                cache_key, sid, "startup" if startup_prepared_v2470 else "memory",
                "shared_delayed" if library_gate_token_v1863 else "none_physical_ready"
            ))
        elif post_reveal_data_warm_v2472:
            _log("LIBRARY_DATA_ONLY_RENDER_BEGIN_V2474 key=%s section=%s spinner_policy=shared_delayed total_query=0 row_query=0 disk_io=0 listitem_build=on_demand" % (
                cache_key, sid
            ))
        generation_v2069 = int(getattr(self, "_library_wall_generation_v2069", 0) or 0) + 1
        self._library_wall_generation_v2069 = generation_v2069
        self._library_wall_owner_v2069 = (str(sid), str(target_sort), str(target_sort_dir), str(target_genre), generation_v2069)
        initial_bound_v2077 = self._library_wall_initial_bound_count_v2077()
        _log("LIBRARY_FOREGROUND_BEGIN_V2069 section=%s key=%s generation=%d spinner_policy=%s delay_ms=%d source=%s limit=%d" % (
            sid, cache_key, generation_v2069,
            "none_native_v2474" if prepared_fast_v2470 and not library_gate_token_v1863 else "shared_delayed_v2474",
            1000,
            ("startup_hydrated_v2470" if startup_prepared_v2470 else "memory_prebuilt_v2470") if prepared_fast_v2470 else ("post_reveal_data_warm_v2472" if post_reveal_data_warm_v2472 else "local_db"),
            initial_bound_v2077
        ))

        cached_rows = self._section_rows_cache.get(cache_key)
        source_v1841 = (
            ("startup_hydrated_v2470" if startup_prepared_v2470 else "memory_prebuilt_v2470")
            if prepared_fast_v2470 else ("post_reveal_data_warm_v2472" if post_reveal_data_warm_v2472 else ("cache" if cached_rows else "query"))
        )
        viewport_limit_v1865 = initial_bound_v2077
        if cached_rows:
            target_rows_v1841 = list(cached_rows[:viewport_limit_v1865])
        else:
            try:
                target_rows_v1841 = list(self._query_library_wall_rows_v1870(
                    sid, sort=target_sort, sort_dir=target_sort_dir,
                    limit=viewport_limit_v1865,
                    offset=0,
                    random_seed=self._wall_random_seed_v1644,
                    genre=(target_genre or None)
                ) or [])
            except Exception:
                _log("SECTION_WALL_PREPARE_FAILED_V1841 section=%s genre=%s reason=query_failed retain_current=1 err=%s" % (
                    sid, target_genre, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGERROR)
                self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="query_failed", visible=False)
                return False

        expected_count_v1841 = target_total_v1870
        verified_empty_v1841 = bool(
            not target_rows_v1841
            and expected_count_v1841 <= 0
            and target_total_known_v1870
        )
        if not target_rows_v1841 and not verified_empty_v1841:
            _log("SECTION_WALL_PREPARE_FAILED_V1841 section=%s genre=%s reason=unexpected_empty expected=%d retain_current=1" % (
                sid, target_genre, expected_count_v1841
            ), xbmc.LOGERROR)
            self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="unexpected_empty", visible=False)
            return False

        previous_state_v1841 = {
            "active_section_id": str(getattr(self, "active_section_id", "") or ""),
            "last_rendered_section_id": str(getattr(self, "_last_rendered_section_id", "") or ""),
            "last_section_show_ms": int(getattr(self, "_last_section_show_ms", 0) or 0),
            "sort": str(getattr(self, "sort", "title") or "title"),
            "sort_dir": str(getattr(self, "sort_dir", "asc") or "asc"),
            "wall_total": int(getattr(self, "wall_total", 0) or 0),
            "wall_offset": int(getattr(self, "wall_offset", 0) or 0),
            "section_index_slice_active": bool(getattr(self, "_section_index_slice_active", False)),
            "append_guard": set(getattr(self, "_append_guard", set()) or set()),
            "active_wall_cache_key": str(getattr(self, "_active_wall_cache_key_v1841", "") or ""),
            "active_wall_verified_empty": bool(getattr(self, "_active_wall_verified_empty_v1841", False)),
            "library_native_owner": str(getattr(self, "_library_native_owner_section_v2070", "") or ""),
            "genre": str(getattr(self, "_active_genre_filter", "") or ""),
            "genre_count": int(getattr(self, "_active_genre_count", 0) or 0),
            "genre_section": str(getattr(self, "_active_genre_section_id", "") or ""),
        }
        previous_wall_items_v1841 = []
        previous_wall_pos_v1841 = 0
        try:
            wall_v1841 = self.getControl(WALL_ID)
            previous_wall_pos_v1841 = max(0, int(wall_v1841.getSelectedPosition()))
            previous_wall_items_v1841 = [
                wall_v1841.getListItem(i)
                for i in range(max(0, int(wall_v1841.size())))
            ]
        except Exception:
            previous_wall_items_v1841 = []
            previous_wall_pos_v1841 = 0

        try:
            if prepared_fast_v2470:
                prepared_lis_v1841 = list(
                    getattr(self, "_library_prebuilt_listitems_v2470", {}).get(cache_key) or []
                )
                # PKM_PATCH_ACTIVE v2587 library_firstpaint_prebuilt_slice_fix
                # V2588 further reduces the foreground native target to 18 while a
                # restart-prepared native cache may still contain 24/66 items.
                # The strict V1841 count guard then rejected Library
                # focus entirely.  Bind exactly the foreground target count; keep
                # the complete persistent row cache untouched for later append.
                target_count_v2587 = len(target_rows_v1841 or [])
                prebuilt_count_v2587 = len(prepared_lis_v1841)
                if target_count_v2587 >= 0 and prebuilt_count_v2587 > target_count_v2587:
                    prepared_lis_v1841 = prepared_lis_v1841[:target_count_v2587]
                    _log("LIBRARY_PREBUILT_FIRSTPAINT_SLICE_V2587 key=%s section=%s cached=%d target=%d bound=%d reserve_rows=%d" % (
                        cache_key, sid, prebuilt_count_v2587, target_count_v2587, len(prepared_lis_v1841),
                        max(0, len(cached_rows or []) - target_count_v2587)
                    ))
                elif target_count_v2587 and prebuilt_count_v2587 < target_count_v2587:
                    _log("LIBRARY_PREBUILT_FIRSTPAINT_FALLBACK_V2587 key=%s section=%s cached=%d target=%d action=rebuild_target_only" % (
                        cache_key, sid, prebuilt_count_v2587, target_count_v2587
                    ), xbmc.LOGWARNING)
                    prepared_lis_v1841 = self._build_wall_listitems_v1841(
                        target_rows_v1841, log_prefix="SECTION_WALL_PREPARE_V2587"
                    )
                _log("LIBRARY_FOCUS_LISTITEM_BUILD_SKIP_V2470 key=%s section=%s source=%s listitems=%d rating_preload=0 focus_io=0" % (
                    cache_key, sid, "startup" if startup_prepared_v2470 else "memory", len(prepared_lis_v1841)
                ))
            else:
                prepared_lis_v1841 = self._build_wall_listitems_v1841(
                    target_rows_v1841, log_prefix="SECTION_WALL_PREPARE_V1841"
                )
            if target_rows_v1841 and len(prepared_lis_v1841) != len(target_rows_v1841):
                raise RuntimeError("wall ListItem count mismatch")
            if post_reveal_data_warm_v2472 and not prepared_fast_v2470:
                _log("LIBRARY_DATA_ONLY_NATIVE_READY_V2474 key=%s section=%s listitems=%d spinner_policy=shared_delayed total_query=0 row_query=0 disk_io=0" % (
                    cache_key, sid, len(prepared_lis_v1841)
                ))
        except Exception:
            _log("SECTION_WALL_PREPARE_FAILED_V1841 section=%s genre=%s reason=listitem_build retain_current=1 err=%s" % (
                sid, target_genre, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="listitem_failed", visible=False)
            return False

        # V2588: keep the V2496 fail-closed rule for the actually visible 12
        # posters only.  The third native row (items 13-18) is navigation runway
        # and may finish artwork preparation after the wall is already visible.
        firstpaint_ok_v2496, firstpaint_ready_v2496, firstpaint_total_v2496, firstpaint_unresolved_v2496 = self._library_firstpaint_materialize_v2496(
            prepared_lis_v1841, visible_count=self._library_wall_viewport_count_v1865(),
            reason="section:%s:%s" % (sid, source_v1841), allow_network=True
        )
        if not firstpaint_ok_v2496:
            _log("LIBRARY_TARGET_BLOCKED_V2496 section=%s key=%s ready=%d total=%d unresolved=%d source_hold=1 target_publish=0 spinner_threshold_ms=1000" % (
                sid, cache_key, firstpaint_ready_v2496, firstpaint_total_v2496, firstpaint_unresolved_v2496
            ), xbmc.LOGWARNING)
            _log("LIBRARY_TRANSITION_ACCEPTANCE_V2496 result=FAIL section=%s key=%s firstpaint=%d/%d unresolved=%d source_hold=1 target_publish=0 reason=firstpaint_unresolved" % (
                sid, cache_key, firstpaint_ready_v2496, firstpaint_total_v2496, firstpaint_unresolved_v2496
            ), xbmc.LOGERROR)
            self._library_render_busy_finish_v2475(
                library_gate_token_v1863, reason="firstpaint_unresolved_v2496", visible=False
            )
            return False
        _log("LIBRARY_PARTIAL_FIRSTPAINT_V2588 section=%s key=%s native_bound=%d visible_gate=%d full_cached_rows=%d index_foreground=0 append_prefetch=post_visible" % (
            sid, cache_key, len(prepared_lis_v1841), firstpaint_total_v2496, len(cached_rows or [])
        ))
        visible_items_v2067 = min(
            len(prepared_lis_v1841), self._library_wall_viewport_count_v1865()
        )
        _log("LIBRARY_DIRECT_PAGE_READY_V2069 section=%s key=%s items=%d source=%s spinner_policy=%s poster_wait=visible_local_v2593 append_chunk=%d" % (
            sid, cache_key, visible_items_v2067, source_v1841,
            "none_native_v2474" if prepared_fast_v2470 and not library_gate_token_v1863 else "shared_delayed_v2474",
            self._library_wall_append_count_v1932()
        ))

        try:
            if current_genre and genre_owner != sid:
                self._active_genre_filter = ""
                self._active_genre_count = 0
                self._active_genre_section_id = ""
                self._update_category_wall_summary(reason="section_changed_clear_genre_v1841")
                _log("SECTION_GENRE_FILTER_CLEAR_V1834 owner_section=%s from_section=%s to_section=%s genre=%s" % (
                    genre_owner, previous_sid, sid, current_genre
                ))
            self.active_section_id = sid
            self._library_native_owner_section_v2070 = sid
            self._last_rendered_section_id = sid
            self._last_section_show_ms = now_ms
            self.sort = target_sort
            self.sort_dir = target_sort_dir
            self.wall_total = int(
                self._section_total_cache.get(cache_key, target_total_v1870)
                if source_v1841 == "cache"
                else target_total_v1870
            )
            self.wall_offset = 0
            self._section_index_slice_active = False
            self._append_guard = set()
            self._set_section_sort_property(reason="show_section:%s" % sid, media_kind_v2470=target_media_kind_v1911)
            self._set_wall_items_from_rows(
                target_rows_v1841,
                log_prefix="SECTION_%s_READY_V1841" % source_v1841.upper(),
                prepared_listitems_v1841=prepared_lis_v1841,
                suppress_postbind_v2470=prepared_fast_v2470,
            )
            if source_v1841 == "query":
                self._section_rows_cache[cache_key] = list(target_rows_v1841)
                self._section_total_cache[cache_key] = self.wall_total
            defer_index_v2585 = self._show_section_wall_ready_commit_v1841_step2(cache_key, firstpaint_ready_v2496, firstpaint_total_v2496, library_gate_token_v1863, post_reveal_data_warm_v2472, prepared_fast_v2470, prepared_lis_v1841, sid, startup_prepared_v2470, target_rows_v1841, title, verified_empty_v1841)
            # v2475: the wall is now committed and has crossed its GUI handoff.
            # Release the sidebar broker here; poster prefetch, cache persistence
            # and append preparation are post-visible work and must not prolong it.
            if library_gate_token_v1863:
                self._library_render_busy_finish_v2475(
                    library_gate_token_v1863, reason="wall_visible", visible=True
                )
                library_gate_token_v1863 = ""

            if defer_index_v2585:
                try:
                    self._library_defer_index_after_visible_v2585(
                        cache_key, sid, title, self.wall_total, target_sort, target_sort_dir, target_genre
                    )
                except Exception:
                    pass
            try:
                is_tv_initial_v2625 = bool(self._is_tv_library_section_v1870(sid))
                # V2625: one runway poster scheduler owns both Movie and TV wall
                # traffic. Do not start the legacy generic queue in parallel; it
                # has no actual-viewport absolute index and therefore cannot honor
                # future-transfer preemption. Data/append behavior is untouched.
                owner_v2623 = tuple(getattr(self, "_library_wall_owner_v2069", ()) or ())
                try:
                    self._library_texture_viewport_sid_v2624 = str(sid or "")
                    self._library_texture_viewport_start_v2624 = 0
                    self._library_texture_viewport_end_v2624 = min(18, max(0, len(target_rows_v1841 or []))) or 18
                    self._library_texture_visible_missing_v2624 = 0
                    self._library_texture_viewport_stamp_v2624 = int(self._now_ms())
                except Exception:
                    pass
                initial_rows_v2625 = (
                    list(target_rows_v1841 or [])[:18]
                    if is_tv_initial_v2625
                    else list(target_rows_v1841 or [])
                )
                queued_initial_v2625 = self._queue_library_texture_runway_v2621(
                    initial_rows_v2625, owner_v2623, 0,
                    reason=("initial_tv_visible_v2623" if is_tv_initial_v2625 else "initial_movie_visible_v2625"),
                    distance_pages_v2622=0
                )
                if is_tv_initial_v2625:
                    _log("LIBRARY_TV_INITIAL_TEXTURE_PRIORITY_V2623 section=%s rows=%d queued=%d generic_background_queue=0" % (
                        sid, min(18, len(target_rows_v1841 or [])), int(queued_initial_v2625 or 0)
                    ))
                else:
                    _log("LIBRARY_MOVIE_INITIAL_TEXTURE_PRIORITY_V2625 section=%s rows=%d queued=%d generic_background_queue=0 common_runway=1" % (
                        sid, len(initial_rows_v2625), int(queued_initial_v2625 or 0)
                    ))
            except Exception:
                pass
            _log("LIBRARY_DIRECT_POLICY_V2593 section=%s visible=%d first_paint=%d native_bound=%d prefetch=%d append=%d low_watermark_rows=%d spinner_policy=%s poster_wait=visible_local_v2593 focus_write=0 generation=%d" % (
                sid, self._library_wall_viewport_count_v1865(), self._library_wall_viewport_count_v1865(),
                self._library_wall_initial_bound_count_v2077(),
                self._library_wall_prefetch_count_v2077(),
                self._library_wall_append_count_v1932(),
                self._library_wall_low_watermark_rows_v2077(),
                "none_native_v2474" if prepared_fast_v2470 and not library_gate_token_v1863 else "shared_delayed_v2474", generation_v2069
            ))
            _log("SECTION_WALL_COMMIT_READY_V1841 section=%s genre=%s rows=%d total=%d source=%s verified_empty=%d" % (
                sid, target_genre, len(target_rows_v1841), self.wall_total,
                source_v1841, 1 if verified_empty_v1841 else 0
            ))
            # v2470: a cold Library tab becomes restart-prepared only after the
            # complete wall+index commit succeeded.  Native prepared objects are
            # process-local only and may be rebound to the hidden Library wall
            # during this WindowXML lifetime; disk persistence remains row data.
            if not prepared_fast_v2470:
                try:
                    index_rows_v2470 = list(self._section_index_cache.get(sid) or [])
                    self._library_prebuilt_listitems_v2470[cache_key] = list(prepared_lis_v1841)
                    self._library_prebuilt_indexitems_v2470[cache_key] = self._library_index_listitems_from_rows_v2470(index_rows_v2470)
                    self._library_persistent_scene_store_v2470(
                        cache_key, sid, title, self.wall_total, target_rows_v1841,
                        sort_key=target_sort, sort_dir=target_sort_dir, genre=target_genre,
                        index_rows=index_rows_v2470,
                    )
                    _log("LIBRARY_MEMORY_PREBUILT_STORE_V2470 key=%s section=%s listitems=%d index=%d next_focus_io=0" % (
                        cache_key, sid, len(prepared_lis_v1841), len(index_rows_v2470)
                    ))
                except Exception:
                    pass
            self._library_append_request_v2070 = False
            try:
                with self._library_append_prefetch_lock_v2070:
                    self._library_append_prefetch_rows_v2070.clear()
                    self._library_append_prefetch_inflight_v2070.clear()
            except Exception:
                pass
            self._start_library_append_prefetch_v2070(reason="initial_ready_v2588")
            _log("LIBRARY_PARTIAL_APPEND_ARM_V2588 section=%s offset=%d total=%d initial_native=%d next_query_background=1 spinner=0" % (
                sid, int(self.wall_offset or 0), int(self.wall_total or 0), int(self.getControl(WALL_ID).size())
            ))
            try:
                _log("LIBRARY_NATIVE_RUNWAY_READY_V2593 section=%s visible=%d bound=%d rows=%d prefetch=%d append=%d low_watermark_rows=%d next_offset=%d total=%d no_down_wrap=1" % (
                    sid, self._library_wall_viewport_count_v1865(), int(self.getControl(WALL_ID).size()),
                    (int(self.getControl(WALL_ID).size()) + 5) // 6,
                    self._library_wall_prefetch_count_v2077(), self._library_wall_append_count_v1932(),
                    self._library_wall_low_watermark_rows_v2077(), int(self.wall_offset or 0), int(self.wall_total or 0)
                ))
            except Exception:
                pass
            _log("LIBRARY_FOREGROUND_END_V2069 section=%s generation=%d result=%s" % (
                sid, generation_v2069,
                ("startup_hydrated_v2470" if startup_prepared_v2470 else "memory_prebuilt_v2470") if prepared_fast_v2470 else ("post_reveal_data_warm_v2472" if post_reveal_data_warm_v2472 else "ready")
            ))
            return True
        except Exception:
            try:
                self.active_section_id = previous_state_v1841["active_section_id"]
                self._last_rendered_section_id = previous_state_v1841["last_rendered_section_id"]
                self._last_section_show_ms = previous_state_v1841["last_section_show_ms"]
                self.sort = previous_state_v1841["sort"]
                self.sort_dir = previous_state_v1841["sort_dir"]
                self.wall_total = previous_state_v1841["wall_total"]
                self.wall_offset = previous_state_v1841["wall_offset"]
                self._section_index_slice_active = previous_state_v1841["section_index_slice_active"]
                self._append_guard = previous_state_v1841["append_guard"]
                self._active_wall_cache_key_v1841 = previous_state_v1841["active_wall_cache_key"]
                self._active_wall_verified_empty_v1841 = previous_state_v1841["active_wall_verified_empty"]
                self._library_native_owner_section_v2070 = previous_state_v1841["library_native_owner"]
                self._active_genre_filter = previous_state_v1841["genre"]
                self._active_genre_count = previous_state_v1841["genre_count"]
                self._active_genre_section_id = previous_state_v1841["genre_section"]
                self._set_section_sort_property(reason="wall_commit_rollback_v1841")
                wall_v1841 = self.getControl(WALL_ID)
                wall_v1841.reset()
                if previous_wall_items_v1841:
                    try:
                        wall_v1841.addItems(previous_wall_items_v1841)
                    except Exception:
                        for old_li_v1841 in previous_wall_items_v1841:
                            wall_v1841.addItem(old_li_v1841)
                    if wall_v1841.size() > 0:
                        wall_v1841.selectItem(min(previous_wall_pos_v1841, wall_v1841.size() - 1))
            except Exception:
                _log("SECTION_WALL_ROLLBACK_FAILED_V1841 section=%s err=%s" % (
                    sid, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGERROR)
            _log("SECTION_WALL_COMMIT_FAILED_V1841 section=%s genre=%s retain_current_mode=1 err=%s" % (
                sid, target_genre, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            self._library_render_busy_finish_v2475(library_gate_token_v1863, reason="commit_failed", visible=False)
            return False

    def _show_section_wall_ready_commit_v1841_step1(self, force, sid, target_genre, target_sort, target_sort_dir):
        """Step 1 of _show_section_wall_ready_commit_v1841 (R76 split, moved verbatim). Logs: LIBRARY_RENDER_WAIT_POLICY_V2475."""
        cache_key = (
            self._section_cache_key(sid, target_sort, target_sort_dir)
            + ":genre=" + target_genre
        )
        native_prebuilt_before_v2474 = bool(
            getattr(self, "_library_prebuilt_listitems_v2470", {}).get(cache_key)
        )
        snapshot_ready_before_v2474 = bool(
            len(list(getattr(self, "_library_render_snapshots_v2473", {}).get(cache_key) or []))
            == len(list(self._section_rows_cache.get(cache_key) or []))
            and bool(self._section_rows_cache.get(cache_key))
        )
        startup_prepared_v2470 = bool(
            not force
            and cache_key in getattr(self, "_library_startup_hydrated_keys_v2470", set())
            and cache_key in getattr(self, "_library_persistent_hit_keys_v2470", set())
            and bool(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(cache_key))
            and bool(self._section_rows_cache.get(cache_key))
        )
        prepared_fast_v2470 = bool(
            not force
            and bool(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(cache_key))
            and bool(self._section_rows_cache.get(cache_key))
        )
        post_reveal_data_warm_v2472 = bool(
            not force
            and cache_key in getattr(self, "_library_post_reveal_data_warm_keys_v2472", set())
            and bool(self._section_rows_cache.get(cache_key))
        )
        retained_hidden_candidate_v2470 = False
        try:
            _wall_probe_v2470 = self.getControl(WALL_ID)
            retained_hidden_candidate_v2470 = bool(
                not force
                and str(getattr(self, "_active_wall_cache_key_v1841", "") or "") == cache_key
                and int(_wall_probe_v2470.size()) > 0
                and int(getattr(self, "wall_offset", 0) or 0) > 0
            )
        except Exception:
            retained_hidden_candidate_v2470 = False

        # v2474: arm the shared delayed spinner before *any* on-demand Library
        # materialization or DB total/page query unless this exact wall is already
        # physically reusable. Beginning a broker token is cheap and invisible;
        # only work that survives past the canonical delay paints the ring.
        already_ready_probe_v2474 = False
        try:
            _wall_probe_ready_v2474 = self.getControl(WALL_ID)
            already_ready_probe_v2474 = bool(
                not force
                and self.active_section_id == sid
                and self._last_rendered_section_id == sid
                and str(getattr(self, "_active_wall_cache_key_v1841", "") or "") == cache_key
                and ((int(_wall_probe_ready_v2474.size()) > 0 and int(getattr(self, "wall_offset", 0) or 0) > 0)
                     or bool(getattr(self, "_active_wall_verified_empty_v1841", False)))
            )
        except Exception:
            already_ready_probe_v2474 = False
        library_gate_token_v1863 = ""
        if not retained_hidden_candidate_v2470 and not already_ready_probe_v2474:
            library_gate_token_v1863 = self._library_render_busy_arm_v2475(
                sid, cache_key, reason="library_foreground"
            )
            # v2585: V2584 no longer hydrates every off-screen destination during
            # splash.  Restore only the selected Library scene from the restart
            # cache before paying a multi-second TV aggregate DB query.  The
            # delayed spinner remains armed and will still appear if this one
            # focused destination is genuinely slow.
            try:
                self._library_focus_lazy_hydrate_v2585(cache_key, sid)
            except Exception:
                pass
            try:
                self._library_snapshot_prebuild_v2473(
                    cache_key, sid,
                    limit_v2588=self._library_wall_initial_bound_count_v2077(),
                    skip_index_v2588=True,
                )
            except Exception:
                pass
            prepared_fast_v2470 = bool(
                not force
                and bool(getattr(self, "_library_prebuilt_listitems_v2470", {}).get(cache_key))
                and bool(self._section_rows_cache.get(cache_key))
            )
            startup_prepared_v2470 = bool(
                prepared_fast_v2470
                and cache_key in getattr(self, "_library_persistent_hit_keys_v2470", set())
                and cache_key in getattr(self, "_library_post_reveal_data_warm_keys_v2472", set())
            )
            _log("LIBRARY_RENDER_WAIT_POLICY_V2475 key=%s section=%s data_ready=%d snapshot=%d native_before=%d native_after=%d token=%s delay_ms=%d" % (
                cache_key, sid, 1 if post_reveal_data_warm_v2472 else 0,
                1 if snapshot_ready_before_v2474 else 0, 1 if native_prebuilt_before_v2474 else 0,
                1 if prepared_fast_v2470 else 0, library_gate_token_v1863 or "",
                1000
            ))
        return cache_key, library_gate_token_v1863, post_reveal_data_warm_v2472, prepared_fast_v2470, retained_hidden_candidate_v2470, startup_prepared_v2470

    def _show_section_wall_ready_commit_v1841_step2(self, cache_key, firstpaint_ready_v2496, firstpaint_total_v2496, library_gate_token_v1863, post_reveal_data_warm_v2472, prepared_fast_v2470, prepared_lis_v1841, sid, startup_prepared_v2470, target_rows_v1841, title, verified_empty_v1841):
        """Step 2 of _show_section_wall_ready_commit_v1841 (R76 split, moved verbatim). Logs: LIBRARY_INDEX_FIRSTPAINT_BYPASS_V2585, LIBRARY_PREPARED_ONE_FRAME_SWAP_V2470, LIBRARY_STARTUP_HYDRATE_ONE_FRAME_SWAP_V2470, LIBRARY_POST_REVEAL_DATA_WARM_ONE_FRAME_SWAP_V2472."""
        self._active_wall_cache_key_v1841 = cache_key
        self._active_wall_verified_empty_v1841 = verified_empty_v1841
        defer_index_v2585 = False
        if prepared_fast_v2470 and bool(getattr(self, "_library_prebuilt_indexitems_v2470", {}).get(cache_key)):
            self._library_bind_prebuilt_index_v2470(cache_key, sid)
        else:
            # v2585: the alphabetical/right-side index is navigation aid, not
            # first-paint content.  Building it for 2k+ TV shows before the
            # wall commit was responsible for ~1.5 s of the V2584 5 s cold
            # sidebar transition.  Hide it now and build after visibility.
            defer_index_v2585 = True
            try:
                self.getControl(SECTION_INDEX_ID).reset()
            except Exception:
                pass
            for _target_v2585 in (self, xbmcgui.Window(10000)):
                try:
                    _target_v2585.clearProperty("PlexKM.Section.IndexVisible")
                except Exception:
                    pass
            _log("LIBRARY_INDEX_FIRSTPAINT_BYPASS_V2585 key=%s section=%s full_index_query=0 firstpaint_owner=wall" % (cache_key, sid))
        self._set_header(
            title, ("전체 %d" % self.wall_total) if self.wall_total else ""
        )
        if prepared_fast_v2470:
            xbmc.sleep(16)
            _log("LIBRARY_PREPARED_ONE_FRAME_SWAP_V2470 key=%s section=%s source=%s wait_ms=16 hidden_bind=1 focus_io=0 atomic_swap=1" % (
                cache_key, sid, "startup" if startup_prepared_v2470 else "memory"
            ))
            if startup_prepared_v2470:
                _log("LIBRARY_STARTUP_HYDRATE_ONE_FRAME_SWAP_V2470 key=%s section=%s wait_ms=16 hidden_bind=1 focus_io=0 atomic_swap=1" % (
                    cache_key, sid
                ))
        elif post_reveal_data_warm_v2472:
            xbmc.sleep(16)
            _log("LIBRARY_POST_REVEAL_DATA_WARM_ONE_FRAME_SWAP_V2472 key=%s section=%s wait_ms=16 hidden_bind=1 spinner=0 total_query=0 row_query=0 disk_io=0 atomic_swap=1" % (
                cache_key, sid
            ))
        if not self._commit_section_view_mode_v1841(
                "wall", reason=("prepared_fast_v2470:%s" % sid) if prepared_fast_v2470 else ("target_ready:%s" % sid)):
            raise RuntimeError("section wall mode commit failed")
        if prepared_fast_v2470:
            try:
                self._section_index_sync_for_item(
                    self._focused_wall_item(), reason="prepared_fast_after_swap_v2470"
                )
                self._set_home_meta_from_item(reason="library_prepared_fast_after_swap_v2470")
            except Exception:
                pass
            _log("LIBRARY_PREPARED_SWAP_DONE_V2474 key=%s section=%s source=%s rows=%d spinner_policy=%s query=0 rating_preload=0 poster_gate=visible_local_v2593" % (
                cache_key, sid, "startup" if startup_prepared_v2470 else "memory", len(target_rows_v1841),
                "shared_delayed" if library_gate_token_v1863 else "none_native"
            ))
            _log("LIBRARY_TRANSITION_ACCEPTANCE_V2496 result=PASS section=%s key=%s firstpaint=%d/%d unresolved=0 actual_local_required=1 source_hold_until_commit=1 reason=local_firstpaint_ready" % (
                sid, cache_key, firstpaint_ready_v2496, firstpaint_total_v2496
            ))
        else:
            self._library_wall_render_settle_v1865(
                reason="initial_publish:%s" % sid,
                item_count=len(prepared_lis_v1841),
            )
        return defer_index_v2585

    def _show_section_wall(self, item, force=False):
        """Show the real Library tab for a Plex section using the existing lazy wall.

        Library is a direct local-DB paged wall: publish the first 18 items,
        keep one row ahead, then append 12 at a time. The first foreground
        transition uses the process-wide delayed-spinner policy; append/prefetch
        remain non-blocking background continuation and never own a spinner.
        """
        # v1841 implementation above prepares query rows and native ListItems
        # first, then flips the Library visibility property exactly once.
        return self._show_section_wall_ready_commit_v1841(item, force=force)

    def _append_section_rows(self, reason="near_end", preserve_selection_pos=None, preserve_selection_key="", rows_override_v2070=None, commit_authorized_v2071=False):
        """Append the next 12 rows without the atomic first-entry spinner.

        The all-12 barrier is reserved for the initial viewport. v1869 appends
        one ordered 12-item chunk after Kodi lands on the final loaded row, then
        preserves that same selected item while lower posters fill progressively.
        """
        if self.wall_loading or not self.active_section_id or self.active_section_id == "__home__":
            return 0
        # v2073 invariant: the initial build may populate an empty/new wall. Every
        # live append must pass through the single rebind transaction gate above,
        # which supplies the exact native 9100 position that must survive Kodi's
        # GUI_MSG_LABEL_BIND reset. Legacy/direct append callers are blocked.
        if str(reason or "") != "initial" and not bool(commit_authorized_v2071):
            _log("LIBRARY_APPEND_POLICY_BLOCK_V2071 section=%s offset=%d reason=%s policy=single_post_native_commit" % (
                self.active_section_id, int(self.wall_offset or 0), reason or ""
            ))
            return 0
        append_key = "%s:%s:%s" % (self.active_section_id, getattr(self, "_active_genre_filter", "") or "", self.wall_offset)
        if append_key in self._append_guard:
            _log("APPEND_SKIPPED reason=%s section=%s offset=%d duplicate_key=1" % (reason, self.active_section_id, self.wall_offset))
            return 0
        self._append_guard.add(append_key)
        self.wall_loading = True
        t0 = time.time()
        owner_v2069 = tuple(getattr(self, "_library_wall_owner_v2069", ()) or ())
        try:
            initial_route_v1934 = bool(
                str(reason or "").strip().lower() == "initial"
                and int(getattr(self, "wall_offset", 0) or 0) <= 0
            )
            limit = (
                self._library_wall_initial_bound_count_v2077()
                if initial_route_v1934
                else self._library_wall_append_count_v1932()
            )
            if rows_override_v2070 is not None:
                rows = list(rows_override_v2070 or [])
            else:
                rows = self._query_library_wall_rows_v1870(
                    self.active_section_id, sort=self.sort, sort_dir=self.sort_dir,
                    limit=limit, offset=self.wall_offset,
                    random_seed=self._wall_random_seed_v1644,
                    genre=(getattr(self, "_active_genre_filter", "") or None)
                )
            if owner_v2069 and tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()) != owner_v2069:
                _log("LIBRARY_APPEND_STALE_DROP_V2069 reason=%s owner=%s current=%s offset=%d" % (
                    reason or "", owner_v2069, tuple(getattr(self, "_library_wall_owner_v2069", ()) or ()), int(self.wall_offset or 0)
                ))
                return 0
            wall = self.getControl(WALL_ID)
            size_before = max(0, int(wall.size()))
            rapid_append_v2582 = bool((not initial_route_v1934) and self._wall_rapid_scroll_active_v2581())
            pc_live_light_v2620 = bool((not initial_route_v1934) and (not self._is_android_v2591()))
            progress_sort_v2620 = bool(str(getattr(self, "sort", "") or "").strip().lower() == "progress")
            if pc_live_light_v2620:
                # V2620: every desktop live append is a transport/runway build,
                # even when the rapid-scroll timer briefly expires between DOWN
                # presses.  This prevents a 24-card append from cold-starting the
                # 24k-row canonical movie index or rating bulk maps on the GUI path.
                _log("LIBRARY_APPEND_PC_LIGHT_BUILD_V2620 section=%s rows=%d rapid=%d progress=%d rating_sql=0 canonical_bulk=0" % (
                    self.active_section_id, len(rows or []), 1 if rapid_append_v2582 else 0, 1 if progress_sort_v2620 else 0
                ))
            elif not rapid_append_v2582:
                try:
                    self._preload_visible_row_ratings(rows, reason="append_section_%s" % (reason or ""))
                except Exception:
                    pass
            else:
                _log("LIBRARY_APPEND_RATING_SUPPRESS_RAPID_V2582 section=%s rows=%d rating_preload=0" % (
                    self.active_section_id, len(rows or [])
                ))
            _rapid_skeleton_prev_v2584 = bool(getattr(self, "_library_rapid_skeleton_v2584", False))
            if rapid_append_v2582 or pc_live_light_v2620:
                self._library_rapid_skeleton_v2584 = True
            build_t0_v2622 = time.perf_counter()
            tv_compact_v2622 = bool((not initial_route_v1934) and self._is_tv_library_section_v1870(self.active_section_id))
            try:
                if tv_compact_v2622:
                    prepared = [self._li_from_tv_wall_append_v2622(row) for row in rows]
                else:
                    prepared = [self._li_from_row(row) for row in rows]
            finally:
                self._library_rapid_skeleton_v2584 = _rapid_skeleton_prev_v2584
            if tv_compact_v2622:
                _log("LIBRARY_TV_COMPACT_BUILD_V2622 section=%s rows=%d build_ms=%.1f batch_properties=1 home_decor=0 info_identity=1" % (
                    self.active_section_id, len(prepared), (time.perf_counter()-build_t0_v2622)*1000.0
                ))
            if rapid_append_v2582:
                _log("LIBRARY_APPEND_RAPID_SKELETON_V2593 section=%s rows=%d synopsis=0 rating_bulk=0 canonical=0 poster_probe=visible6_only" % (
                    self.active_section_id, len(prepared)
                ))
            append_local_bound_v2580 = 0
            if not initial_route_v1934:
                append_local_bound_v2580, remote_small_bound_v2621 = self._bind_append_runway_posters_v2621(rows, prepared)
                _log("LIBRARY_APPEND_TEXTURE_RUNWAY_BIND_V2621 section=%s rows=%d local_bound=%d remote_small=%d offset=%d rapid=%d android=%d db=0 network_wait=0" % (
                    self.active_section_id, len(prepared), append_local_bound_v2580,
                    remote_small_bound_v2621, int(self.wall_offset or 0),
                    1 if rapid_append_v2582 else 0, 1 if self._is_android_v2591() else 0
                ))
                if rapid_append_v2582 and len(prepared) > 0 and append_local_bound_v2580 <= 0:
                    _log("LIBRARY_RAPID_SCROLL_SPINNER_SUPPRESS_V2594 section=%s target=%d local_bound=%d placeholder_allowed=1 input_first=1" % (
                        self.active_section_id, min(6, len(prepared)), append_local_bound_v2580
                    ))
            # v2073 root fix: Kodi 21.3 Python ControlList.addItem() and
            # addItems() both issue GUI_MSG_LABEL_BIND with param1=0. Native
            # CGUIBaseContainer handles that by Reset(), rebinding all supplied
            # items, then SelectItem(0). Repeating addItem() therefore performs
            # repeated full resets; it is not a native tail-add.
            #
            # Use exactly ONE batch bind for the live append and compensate for
            # the API's forced SelectItem(0) by immediately selecting the exact
            # numeric Kodi position captured by the single append gate. This
            # rebuilds the Panel's native cursor/offset for the same item/column
            # before the next directional action. No logical/rating-key restore
            # is permitted here.
            bind_count_v2073 = 0
            same_position_restore_v2073 = 0
            expected_pos_v2073 = -1
            if not initial_route_v1934:
                try:
                    expected_pos_v2073 = int(preserve_selection_pos)
                except Exception:
                    expected_pos_v2073 = -1
                if expected_pos_v2073 < 0 or expected_pos_v2073 >= size_before:
                    _log("LIBRARY_APPEND_REBIND_TRANSACTION_BLOCK_V2073 section=%s offset=%d expected_pos=%d size_before=%d reason=%s" % (
                        self.active_section_id, int(self.wall_offset or 0), expected_pos_v2073, size_before, reason or ""
                    ), xbmc.LOGERROR)
                    return 0
                # R106b: the position was captured before the 60-200 ms ListItem
                # build; DOWN keys pressed meanwhile already moved Kodi's cursor.
                # Restoring the stale capture pulled the user back one row per
                # rebind (SHIELD 60 x 150 ms DOWN: ~7 rows lost).  Re-read the
                # live cursor immediately before the bind and keep the newer one.
                try:
                    live_pos_r106 = int(wall.getSelectedPosition())
                    if expected_pos_v2073 < live_pos_r106 < size_before:
                        _log("R106_APPEND_LIVE_CURSOR section=%s captured=%d live=%d" % (
                            self.active_section_id, expected_pos_v2073, live_pos_r106))
                        expected_pos_v2073 = live_pos_r106
                        try:
                            preserve_selection_key = self._wall_item_key(wall.getListItem(live_pos_r106)) or ""
                        except Exception:
                            preserve_selection_key = ""
                except Exception:
                    pass
            wall.addItems(prepared)
            bind_count_v2073 = 1
            # V2621: a poster may have completed while ListItems were being built.
            # Re-check only the in-memory runway map; no filesystem/DB/network.
            self._library_texture_runway_apply_visible_v2621(reason="after_append_bind")
            if rapid_append_v2582:
                # V2594: wall rapid-scroll never owns a spinner.  If a legacy
                # V2593 token survived from an earlier path, retire it immediately.
                self._library_rapid_poster_spinner_finish_v2593(reason="v2594_wall_rapid_no_spinner")
            restore_attempts_v2122 = 0
            if not initial_route_v1934:
                if rapid_append_v2582:
                    # V2584: the existing prefix never reorders on tail append, so
                    # scanning hundreds of native ListItems by key is wasted work
                    # during a remote-key burst.  Use at most two numeric corrections.
                    requested_v2584 = expected_pos_v2073
                    selected_now_v2073 = -1
                    # R53: single queued select only (see _restore_library_append_selection_v2122).
                    for _attempt_v2584 in range(1):
                        restore_attempts_v2122 += 1
                        try:
                            wall.selectItem(max(0, min(int(wall.size()) - 1, int(requested_v2584))))
                            selected_now_v2073 = int(wall.getSelectedPosition())
                        except Exception:
                            selected_now_v2073 = -1
                    same_position_restore_v2073 = bool(selected_now_v2073 == expected_pos_v2073)
                    _log("LIBRARY_APPEND_RAPID_POSITION_RESTORE_V2584 section=%s expected=%d selected=%d attempts=%d key_scan=0" % (
                        self.active_section_id, expected_pos_v2073, selected_now_v2073, restore_attempts_v2122
                    ))
                else:
                    # v2122: numeric selectItem() alone is not enough on Kodi 21.3;
                    # the focused Panel can land one item away after LABEL_BIND.
                    same_position_restore_v2073, selected_now_v2073, restore_attempts_v2122 = self._restore_library_append_selection_v2122(
                        wall, expected_pos_v2073, preserve_selection_key, stable_prefix_size=size_before
                    )
            else:
                try:
                    selected_now_v2073 = int(wall.getSelectedPosition())
                except Exception:
                    selected_now_v2073 = -1
            added_count_v2073 = len(prepared)
            columns_now_v2073 = max(1, int(self._wall_column_count() or 6))
            col_expected_v2073 = expected_pos_v2073 % columns_now_v2073 if expected_pos_v2073 >= 0 else -1
            col_selected_v2073 = selected_now_v2073 % columns_now_v2073 if selected_now_v2073 >= 0 else -1
            selected_key_v2122 = ""
            try:
                if 0 <= selected_now_v2073 < int(wall.size()):
                    selected_key_v2122 = self._wall_item_key(wall.getListItem(selected_now_v2073)) or ""
            except Exception:
                selected_key_v2122 = ""
            key_verified_v2122 = 1 if (not preserve_selection_key or selected_key_v2122 == str(preserve_selection_key or "")) else 0
            _log("LIBRARY_APPEND_NATIVE_REBIND_V2122 section=%s mode=%s added=%d size_before=%d size_after=%d bind_count=%d expected_pos=%d selected_after=%d col_expected=%d col_after=%d exact_item_restore=%d key_verified=%d restore_attempts=%d logical_owner_write=0 focus_write=0 viewport_write=0 reason=%s" % (
                self.active_section_id, "initial_batch" if initial_route_v1934 else "single_batch_rebind",
                int(added_count_v2073), size_before, int(wall.size()), bind_count_v2073, expected_pos_v2073,
                selected_now_v2073, col_expected_v2073, col_selected_v2073, int(bool(same_position_restore_v2073)),
                key_verified_v2122, restore_attempts_v2122, reason or ""
            ))

            selection_restored_v1869 = same_position_restore_v2073
            selection_target_v1869 = expected_pos_v2073
            if not rapid_append_v2582:
                try:
                    self._schedule_info_cast_prewarm_for_listitems(
                        prepared, reason="append_section_visible_buffer_v1339:%s:%s" % (
                            self.active_section_id or "", reason or ""
                        ), limit=CAST_PREWARM_VISIBLE_LIMIT_V1339
                    )
                except Exception:
                    pass
            else:
                _log("LIBRARY_APPEND_CAST_SUPPRESS_RAPID_V2582 section=%s rows=%d cast_prewarm=0" % (
                    self.active_section_id, len(prepared)
                ))

            sid = self.active_section_id
            cache_key = self._section_cache_key(sid, self.sort, self.sort_dir) + ":genre=" + str(getattr(self, "_active_genre_filter", "") or "")
            if not getattr(self, "_section_index_slice_active", False):
                prev = self._section_rows_cache.get(cache_key, [])
                self._section_rows_cache[cache_key] = prev + list(rows or [])
                self._section_total_cache[cache_key] = self.wall_total
            self.wall_offset += len(rows)

            # V2582: during rapid scrolling do not enqueue a second poster
            # pipeline after the native rebind.  Kodi will resolve only currently
            # visible ListItem artwork; PKM speculative poster downloads resume
            # once navigation settles.  This removes the V2580/V2581 duplicate
            # 24-image pressure that pushed UHD3 PLEX/BG/thread counts up.
            if (not rapid_append_v2582) and self._is_android_v2591():
                # V2625: append rows were already armed by the common V2621 runway
                # worker before native bind. A second generic queue would have no
                # viewport distance metadata and could occupy the U+ lane with
                # future cards, so keep it suppressed for Movie and TV alike.
                _log("LIBRARY_APPEND_GENERIC_POSTER_SUPPRESS_V2625 section=%s start=%d count=%d common_runway=1 legacy_queue=0 navigation_gate=0" % (
                    self.active_section_id, size_before, len(prepared)
                ))
            elif not rapid_append_v2582:
                _log("LIBRARY_APPEND_PC_NATIVE_TEXTURE_OWNER_V2619 section=%s start=%d count=%d python_bulk_prefetch=0 kodi_small_remote=1" % (
                    self.active_section_id, size_before, len(prepared)
                ))
            else:
                _log("LIBRARY_APPEND_BULK_POSTER_SUPPRESS_RAPID_V2593 section=%s start=%d count=%d legacy_bulk=0 visible_lane_up_to=6 scheduler_lane=1" % (
                    self.active_section_id, size_before, len(prepared)
                ))
            if str(reason or "") != "prefetched_v2071":
                self._remember_focus_position()
                try:
                    self._set_home_meta_from_item(reason=reason)
                    self._track_wall_selection("append_%s" % reason)
                except Exception:
                    pass
            else:
                _log("LIBRARY_APPEND_SIDE_EFFECT_SUPPRESS_V2071 section=%s offset=%d metadata=0 selection_telemetry=0" % (
                    self.active_section_id, int(self.wall_offset or 0)
                ))
            elapsed = (time.time() - t0) * 1000.0
            if initial_route_v1934:
                _log("LIBRARY_WALL_PREBUFFER_V2593 route=legacy_initial section=%s prepared=%d visible=%d native_runway=%d append_chunk=%d low_watermark_rows=%d atomic=0 platform_android=%d" % (
                    self.active_section_id, len(rows), self._library_wall_viewport_count_v1865(),
                    max(0, len(rows) - self._library_wall_viewport_count_v1865()), self._library_wall_append_count_v1932(),
                    self._library_wall_low_watermark_rows_v2077(), 1 if self._is_android_v2591() else 0
                ))
            _log("LIBRARY_APPEND_PROGRESSIVE_V2594 reason=%s section=%s added=%d offset=%d total=%d elapsed=%.3fms chunk=%d spinner=%d atomic=0 position_guard=%d target=%d input_first=%d" % (
                reason, self.active_section_id, len(rows), self.wall_offset, self.wall_total, elapsed, int(limit or 0),
                0 if rapid_append_v2582 else (1 if str(getattr(self, "_library_rapid_poster_spinner_token_v2593", "") or "") else 0),
                int(selection_restored_v1869 or 0), int(selection_target_v1869 if selection_target_v1869 is not None else -1), 1 if rapid_append_v2582 else 0
            ))
            return len(rows)
        except Exception:
            self._append_guard.discard(append_key)
            _log("APPEND_FAILED_V1869\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            return 0
        finally:
            self.wall_loading = False
