# -*- coding: utf-8 -*-
"""PlexKM 뮤직 에이전트 - 온라인 정보 소스(국내·해외).

모든 함수는 Kodi 없이 동작하고, 결과를 같은 모양의 사전으로 돌려준다.

  곡   -> {"src", "title", "artists": [{"name", "img"}], "album", "date"(YYYYMMDD), "cover", "genre", "sec"}
  가수 -> {"src", "id", "name", "img", "group"(bool|None), "country"}
  앨범 -> {"src", "id", "title", "artist", "date", "cover"}

국내: 네이버 VIBE(1순위, 연도·장르·재생시간까지), FLO(2순위, 1000px 이미지), 멜론(3순위, 자동완성 응답).
해외: Deezer(1순위), iTunes 미국 스토어(2순위, 분당 약 20회), MusicBrainz + fanart.tv(가수 배경·로고).
호스트마다 초당 호출 수를 지키고, 한도 오류(429/503)는 잠깐 쉬었다가 다시 시도한다.
음악 파일(앨범 단위) 스캔에서도 그대로 쓰도록 곡·가수·앨범 검색을 모두 둔다.
"""
import json
import re
import threading
import time

try:
    from urllib.parse import quote
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
except ImportError:  # pragma: no cover
    from urllib import quote
    from urllib2 import Request, urlopen, HTTPError

UA_WEB = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
UA_API = "PlexKM/0.5 ( https://github.com/kmfly/kodiskin )"
# fanart.tv 개인 키가 없을 때는 Kodi 기본 스크래퍼(metadata.common.fanart.tv)와 같은 공개 프로젝트 키를 쓴다.
FANART_KEY = ["ed4b784f97227358b31ca4dd966a04f1"]

# 호스트별 최소 간격(초)
_GAP = {"vibe": 0.06, "flo": 0.1, "melon": 0.15, "deezer": 0.125, "itunes": 3.1, "mb": 1.0, "fanart": 0.3}
_LOCKS = dict((k, threading.Lock()) for k in _GAP)
_LAST = dict((k, 0.0) for k in _GAP)
STATS = {}
ABORTED = [None]          # 종료 확인 함수(art.configure 가 넣는다)


def _aborted():
    f = ABORTED[0]
    try:
        return bool(f and f())
    except Exception:
        return False


def fetch(host, url, headers=None, tries=3, timeout=10):
    """host 별 간격을 지켜 url 을 읽어 bytes 로 돌려준다. 끝내 실패하면 예외."""
    h = {"User-Agent": UA_WEB}
    h.update(headers or {})
    last = None
    for n in range(tries):
        if _aborted():
            raise RuntimeError("aborted")
        with _LOCKS[host]:
            w = _LAST[host] + _GAP[host] - time.time()
            if w > 0:
                time.sleep(w)
            _LAST[host] = time.time()
        try:
            with urlopen(Request(url, headers=h), timeout=timeout) as r:
                b = r.read()
            STATS[host] = STATS.get(host, 0) + 1
            return b
        except HTTPError as e:
            last = e
            if e.code == 404:
                raise
            time.sleep(((1.2 if host == "mb" else 3.0) if e.code in (429, 503) else 0.8) * (n + 1))
        except Exception as e:
            last = e
            time.sleep(0.8 * (n + 1))
    STATS[host + "_err"] = STATS.get(host + "_err", 0) + 1
    raise last


def fetch_json(host, url, headers=None, **kw):
    b = fetch(host, url, headers, **kw)
    s = b.decode("utf-8", "replace").strip().rstrip(";").strip()
    if s.startswith("(") and s.endswith(")"):        # 멜론 jsonp
        s = s[1:-1]
    return json.loads(s or "{}")


def _ymd(x):
    d = re.sub(r"\D", "", str(x or ""))
    return d[:8] if len(d) >= 4 else ""


def _sec(pt):
    m = re.match(r"^(?:(\d+):)?(\d+):(\d+)$", str(pt or "").strip())
    if not m:
        return 0
    return int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3))


# ------------------------------------------------------------------ 네이버 VIBE
_VB = "https://apis.naver.com/vibeWeb/musicapiweb/v4/search/%s?start=1&display=%d&query=%s"


def vibe_img(url, kind="r480Fll"):
    """VIBE 이미지 주소의 크기 지정. 원본은 수 MB, 480(r480Fll)이 쓸 수 있는 가장 큰 크기."""
    if bad_img(url):
        return ""
    base = url.split("?")[0]
    return base + "?type=" + kind


def _vb_xml(kind, q, display):
    import xml.etree.ElementTree as ET
    return ET.fromstring(fetch("vibe", _VB % (kind, display, quote(q))))


def _vb_artist_el(a):
    return {"src": "vibe", "id": a.findtext("artistId") or "", "name": a.findtext("artistName") or "",
            "img": vibe_img(a.findtext("imageUrl") or ""), "group": (a.findtext("isGroup") == "true") if a.findtext("isGroup") else None,
            "genre": a.findtext("genreNames") or ""}


def vibe_tracks(q, display=5):
    root = _vb_xml("track", q, display)
    out = []
    for t in root.findall("./result/tracks/tracks"):
        al = t.find("album")
        arts = [_vb_artist_el(a) for a in t.findall("./artists/artists")]
        genre = ""
        for a in arts:
            genre = genre or a.get("genre") or ""
        out.append({"src": "vibe", "id": t.findtext("trackId") or "", "title": t.findtext("trackTitle") or "", "artists": arts,
                    "album": (al.findtext("albumTitle") if al is not None else "") or "",
                    "album_id": (al.findtext("albumId") if al is not None else "") or "",
                    "date": _ymd(al.findtext("releaseDate") if al is not None else ""),
                    "cover": vibe_img(al.findtext("imageUrl") if al is not None else ""),
                    "genre": genre, "sec": _sec(t.findtext("playTime"))})
    return out


def vibe_artists(q, display=5):
    root = _vb_xml("artist", q, display)
    return [_vb_artist_el(a) for a in root.findall("./result/artists/artists")]


def vibe_albums(q, display=5):
    root = _vb_xml("album", q, display)
    out = []
    for a in root.findall("./result/albums/albums"):
        arts = [x.findtext("artistName") or "" for x in a.findall("./artists/artists")]
        out.append({"src": "vibe", "id": a.findtext("albumId") or "", "title": a.findtext("albumTitle") or "",
                    "artist": ", ".join(x for x in arts if x), "date": _ymd(a.findtext("releaseDate")),
                    "cover": vibe_img(a.findtext("imageUrl") or "")})
    return out


# ------------------------------------------------------------------ FLO
_FLO = "https://www.music-flo.com/api/search/v2/search?keyword=%s&searchType=%s&sortType=ACCURACY&size=%d&page=1"
_FLO_H = {"x-gm-app-name": "FLO_WEB", "Accept": "application/json"}


_PLACEHOLDER = re.compile(r"/0{6,}|noimg|no_image|noImage|default_|/blank\.|img_default", re.I)


def bad_img(url):
    """사진이 없는 가수·앨범에 소스가 주는 빈 그림(사람 모양 아이콘 등)."""
    return bool(not url or _PLACEHOLDER.search(url))


def _flo_img(lst, px=500):
    best = ""
    for i in lst or []:
        if int(i.get("size") or 0) <= px:
            best = i.get("url") or best
    best = best or ((lst or [{}])[-1].get("url") or "")
    return "" if bad_img(best) else best


def _flo_list(q, kind, size):
    d = fetch_json("flo", _FLO % (quote(q), kind, size), _FLO_H)
    for blk in ((d.get("data") or {}).get("list") or []):
        if blk.get("type") == kind:
            return blk.get("list") or []
    return []


def flo_tracks(q, size=5):
    out = []
    for t in _flo_list(q, "TRACK", size):
        al = t.get("album") or {}
        out.append({"src": "flo", "id": str(t.get("id") or ""), "title": t.get("name") or "",
                    "artists": [{"src": "flo", "id": str(a.get("id") or ""), "name": a.get("name") or "", "img": _flo_img(a.get("imgList"))}
                                for a in (t.get("artistList") or [])],
                    "album": al.get("title") or "", "album_id": str(al.get("id") or ""), "date": _ymd(al.get("releaseYmd")),
                    "cover": _flo_img(al.get("imgList")), "genre": "", "sec": _sec(t.get("playTime"))})
    return out


def flo_artists(q, size=5):
    return [{"src": "flo", "id": str(a.get("id") or ""), "name": a.get("name") or "", "img": _flo_img(a.get("imgList")),
             "group": (a.get("artistGroupTypeStr") == "그룹") if a.get("artistGroupTypeStr") else None}
            for a in _flo_list(q, "ARTIST", size)]


def flo_albums(q, size=5):
    out = []
    for a in _flo_list(q, "ALBUM", size):
        out.append({"src": "flo", "id": str(a.get("id") or ""), "title": a.get("title") or "",
                    "artist": ", ".join(x.get("name") or "" for x in (a.get("artistList") or [])),
                    "date": _ymd(a.get("releaseYmd")), "cover": _flo_img(a.get("imgList"))})
    return out


# ------------------------------------------------------------------ 멜론(자동완성 응답: 곡·가수·앨범 이름과 이미지)
def _mel_img(u, px=500):
    if bad_img(u):
        return ""
    return re.sub(r"/melon/resize/\d+", "/melon/resize/%d" % px, u or "")


def melon_suggest(q):
    d = fetch_json("melon", "https://www.melon.com/search/keyword/index.json?jscallback=&query=" + quote(q),
                   {"Referer": "https://www.melon.com/"})
    songs = [{"src": "melon", "id": s.get("SONGID") or "", "title": s.get("SONGNAME") or "",
              "artists": [{"src": "melon", "id": "", "name": n.strip(), "img": ""} for n in (s.get("ARTISTNAME") or "").split(",") if n.strip()],
              "album": s.get("ALBUMNAME") or "", "album_id": s.get("ALBUMID") or "", "date": "", "cover": _mel_img(s.get("ALBUMIMG")),
              "genre": "", "sec": 0} for s in (d.get("SONGCONTENTS") or [])]
    arts = [{"src": "melon", "id": a.get("ARTISTID") or "", "name": a.get("ARTISTNAME") or "", "img": _mel_img(a.get("ARITSTIMG")),
             "group": (a.get("ACTTYPENAMES") == "그룹") if a.get("ACTTYPENAMES") else None, "country": a.get("NATIONALITYNAME") or ""}
            for a in (d.get("ARTISTCONTENTS") or [])]
    albums = [{"src": "melon", "id": a.get("ALBUMID") or "", "title": a.get("ALBUMNAME") or "", "artist": a.get("ARTISTNAME") or "",
               "date": "", "cover": _mel_img(a.get("ALBUMIMG"))} for a in (d.get("ALBUMCONTENTS") or [])]
    return {"songs": songs, "artists": arts, "albums": albums}


# ------------------------------------------------------------------ Deezer (한국 IP 에서는 국내 곡 카탈로그가 좁다)
def _dz(url):
    d = fetch_json("deezer", url)
    err = d.get("error") if isinstance(d, dict) else None
    if isinstance(err, dict) and err.get("code") in (4, 100):
        time.sleep(2.0)
        d = fetch_json("deezer", url)
    return d


def _dz_cover(al, px=500):
    c = al.get("cover_xl") or al.get("cover_big") or ""
    if not c or "/album//" in c or "/cover//" in c:
        return ""
    return re.sub(r"/\d+x\d+-", "/%dx%d-" % (px, px), c)


def deezer_tracks(q, limit=8):
    out = []
    for r in (_dz("https://api.deezer.com/search?limit=%d&q=%s" % (limit, quote(q))).get("data") or []):
        al = r.get("album") or {}
        ar = r.get("artist") or {}
        pic = ar.get("picture_xl") or ""
        out.append({"src": "deezer", "id": str(r.get("id") or ""), "title": r.get("title") or "",
                    "artists": [{"src": "deezer", "id": str(ar.get("id") or ""), "name": ar.get("name") or "",
                                 "img": "" if "/artist//" in pic else re.sub(r"/\d+x\d+-", "/500x500-", pic)}],
                    "album": al.get("title") or "", "album_id": str(al.get("id") or ""), "date": "", "cover": _dz_cover(al),
                    "genre": "", "sec": int(r.get("duration") or 0)})
    return out


def deezer_artists(q, limit=6):
    out = []
    for a in (_dz("https://api.deezer.com/search/artist?limit=%d&q=%s" % (limit, quote(q))).get("data") or []):
        pic = a.get("picture_xl") or ""
        out.append({"src": "deezer", "id": str(a.get("id") or ""), "name": a.get("name") or "",
                    "img": "" if (not pic or "/artist//" in pic) else re.sub(r"/\d+x\d+-", "/500x500-", pic), "fans": int(a.get("nb_fan") or 0)})
    return out


def deezer_artist_albums(dz_id):
    out, seen = [], set()
    for al in (_dz("https://api.deezer.com/artist/%s/albums?limit=100" % dz_id).get("data") or []):
        c = _dz_cover(al)
        if not c or al.get("record_type") not in ("album", "single", "ep"):
            continue
        k = re.sub(r"\W+", "", (al.get("title") or "").lower())
        if k in seen:
            continue
        seen.add(k)
        out.append({"t": al.get("title") or "", "c": c, "y": str(al.get("release_date") or "")[:4]})
    return out


# ------------------------------------------------------------------ iTunes (한국 스토어는 음악 검색 결과가 없어 미국 스토어)
def _it_art(u, px=600):
    return (u or "").replace("100x100bb", "%dx%dbb" % (px, px))


def itunes_tracks(q, limit=8, country="us"):
    d = fetch_json("itunes", "https://itunes.apple.com/search?country=%s&media=music&entity=song&limit=%d&term=%s" % (country, limit, quote(q)),
                   {"User-Agent": UA_API})
    out = []
    for r in d.get("results") or []:
        out.append({"src": "itunes", "id": str(r.get("trackId") or ""), "title": r.get("trackName") or "",
                    "artists": [{"src": "itunes", "id": str(r.get("artistId") or ""), "name": r.get("artistName") or "", "img": ""}],
                    "album": re.sub(r"\s+-\s+(Single|EP)$", "", r.get("collectionName") or ""), "album_id": str(r.get("collectionId") or ""),
                    "date": _ymd(r.get("releaseDate")), "cover": _it_art(r.get("artworkUrl100")),
                    "genre": r.get("primaryGenreName") or "", "sec": int(r.get("trackTimeMillis") or 0) // 1000})
    return out


def itunes_albums(q, limit=10, country="us"):
    d = fetch_json("itunes", "https://itunes.apple.com/search?country=%s&media=music&entity=album&limit=%d&term=%s" % (country, limit, quote(q)),
                   {"User-Agent": UA_API})
    return [{"src": "itunes", "id": str(r.get("collectionId") or ""), "title": re.sub(r"\s+-\s+(Single|EP)$", "", r.get("collectionName") or ""),
             "artist": r.get("artistName") or "", "date": _ymd(r.get("releaseDate")), "cover": _it_art(r.get("artworkUrl100"))}
            for r in (d.get("results") or [])]


# ------------------------------------------------------------------ MusicBrainz + fanart.tv (가수 가로 배경·로고·사진)
def mb_artists(name, limit=5):
    q = re.sub(r'[\"\\:!(){}\[\]^~*?+\-/]', " ", name).strip()   # 검색 문법 글자는 뺀다(이름 그대로가 순위가 가장 좋다)
    d = fetch_json("mb", "https://musicbrainz.org/ws/2/artist?fmt=json&limit=%d&query=%s" % (limit, quote(q)),
                   {"User-Agent": UA_API, "Accept": "application/json"}, tries=5)
    out = []
    for a in d.get("artists") or []:
        names = [a.get("name") or "", a.get("sort-name") or ""] + [x.get("name") or "" for x in (a.get("aliases") or [])]
        out.append({"src": "mb", "id": a.get("id") or "", "name": a.get("name") or "", "names": [n for n in names if n],
                    "country": a.get("country") or "", "dis": a.get("disambiguation") or "", "score": int(a.get("score") or 0),
                    "type": a.get("type") or ""})
    return out


def fanart_artist(mbid):
    """-> {"fanart": [..], "thumb": [..], "logo": [..], "banner": [..]} (좋아요 많은 순)."""
    try:
        d = fetch_json("fanart", "https://webservice.fanart.tv/v3/music/%s?api_key=%s" % (mbid, FANART_KEY[0]), {"User-Agent": UA_API})
    except HTTPError as e:
        if e.code == 404:
            return {}
        raise

    def pick(key):
        xs = sorted(d.get(key) or [], key=lambda x: -int(x.get("likes") or 0))
        return [x.get("url") for x in xs if x.get("url")]
    return {"fanart": pick("artistbackground"), "thumb": pick("artistthumb"),
            "logo": pick("hdmusiclogo") or pick("musiclogo"), "banner": pick("musicbanner")}
