# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import ctypes
import json
import os
import sqlite3
import time

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"

PROP_PREFIX = "PlexKM.Network."
SAMPLE_MS = 500
ACTIVE_SAMPLE_MIN_MBPS = 0.20
SAMPLE_WINDOW_MS = 8000
CAPACITY_HOLD_MS = 10000
GOOD_RATIO = 1.35
GOOD_RATIO_WITH_BUFFER = 1.15
LOW_RATIO = 0.95
SEVERE_RATIO = 0.75
LOW_HOLD_MS = 3000
SEVERE_HOLD_MS = 1800
RECOVER_HOLD_MS = 2500


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][network_health] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _now_ms():
    return int(time.time() * 1000)


def _window():
    return xbmcgui.Window(10000)


def _set_prop(name, value):
    try:
        _window().setProperty(PROP_PREFIX + str(name), str(value))
    except Exception:
        pass


def _clear_prop(name):
    try:
        _window().clearProperty(PROP_PREFIX + str(name))
    except Exception:
        pass


def _get_prop(name, default=""):
    try:
        return _window().getProperty(PROP_PREFIX + str(name)) or default
    except Exception:
        return default


def _clear_all_properties(reason=""):
    for name in (
        "Active", "State", "StateLabel", "RequiredMbps", "ReceiveMbps",
        "Ratio", "Buffer", "Message", "PanelVisible", "Source",
        "UpdatedAtMs", "RatingKey", "LeadSec", "RatioValue", "RequiredValue",
        "CapacityValue", "Method",
    ):
        _clear_prop(name)
    if reason:
        _log("NETWORK_HEALTH_CLEAR_V2126 reason=%s" % str(reason or ""))


def toggle_panel():
    """Toggle the read-only network detail card without stealing OSD focus."""
    try:
        win = _window()
        if win.getProperty(PROP_PREFIX + "Active") != "1":
            return False
        visible = win.getProperty(PROP_PREFIX + "PanelVisible") == "1"
        if visible:
            win.clearProperty(PROP_PREFIX + "PanelVisible")
            _log("NETWORK_HEALTH_PANEL_V2126 visible=0")
        else:
            win.setProperty(PROP_PREFIX + "PanelVisible", "1")
            # The user deliberately navigated away from the initial play button,
            # so keep the existing VideoOSD user-navigation ownership.  Do not
            # open a modal dialog and do not write focus from Python.
            win.setProperty("PlexKM.PlayerOSD.AutoCloseCancelled", "1")
            win.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
            win.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
            _log("NETWORK_HEALTH_PANEL_V2126 visible=1 focus_write=0 modal=0")
        return True
    except Exception:
        return False


def _parse_numeric(text):
    try:
        return float(str(text or "").replace(",", "").strip())
    except Exception:
        return 0.0


def _parse_mbps(value, raw_plex_kbps=False):
    text = str(value or "").strip()
    if not text:
        return 0.0
    low = text.lower().replace(",", "").strip()
    try:
        if "mib/s" in low:
            return max(0.0, _parse_numeric(low.replace("mib/s", "")) * 8.388608)
        if "mbps" in low or "mbit/s" in low or "mbit" in low:
            for unit in ("mbps", "mbit/s", "mbit"):
                low = low.replace(unit, "")
            return max(0.0, _parse_numeric(low))
        if "kbps" in low or "kbit/s" in low or "kbit" in low:
            for unit in ("kbps", "kbit/s", "kbit"):
                low = low.replace(unit, "")
            return max(0.0, _parse_numeric(low) / 1000.0)
        if "bps" in low:
            return max(0.0, _parse_numeric(low.replace("bps", "")) / 1000000.0)
        number = _parse_numeric(low)
        if number <= 0.0:
            return 0.0
        if raw_plex_kbps:
            return number / 1000.0
        if number >= 1000000.0:
            return number / 1000000.0
        if number >= 1000.0:
            return number / 1000.0
        return number
    except Exception:
        return 0.0


def _rating_key():
    try:
        win = _window()
        return (
            win.getProperty("PlexKM.NowPlaying.RatingKey")
            or win.getProperty("PlexKM.MainPlaybackRatingKey")
            or win.getProperty("PlexKM.InfoPlaybackRatingKey")
            or ""
        )
    except Exception:
        return ""


def _required_bitrate_from_local_db():
    rating_key = _rating_key()
    if not rating_key:
        return 0.0, "", rating_key
    conn = None
    try:
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/%s/plex_km.db" % ADDON_ID
        )
        if not path or not os.path.exists(path):
            return 0.0, "", rating_key
        conn = sqlite3.connect(path, timeout=0.06)
        row = conn.execute(
            "SELECT raw_json FROM items WHERE rating_key=? LIMIT 1",
            (str(rating_key),),
        ).fetchone()
        if not row:
            return 0.0, "", rating_key
        data = json.loads(row[0] or "{}")
        if not isinstance(data, dict):
            return 0.0, "", rating_key
        bitrate = _parse_mbps(data.get("bitrate"), raw_plex_kbps=True)
        if bitrate > 0:
            return bitrate, "plex_db_media_bitrate", rating_key
    except Exception as exc:
        _log("NETWORK_HEALTH_BITRATE_DB_FAILED_V2126 rating_key=%s err=%s" % (rating_key, exc), xbmc.LOGWARNING)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
    return 0.0, "", rating_key


def _required_bitrate_mbps():
    # The seek subsystem may already have an exact bitrate, but zero is its
    # deliberate 'unknown' sentinel.  No network request is made here.
    try:
        dyn = _window().getProperty("PlexKM.SeekQuick.DynamicBitrateMbps") or ""
    except Exception:
        dyn = ""
    value = _parse_mbps(dyn)
    if value > 0:
        return value, "seek_dynamic", _rating_key()

    value, source, rk = _required_bitrate_from_local_db()
    if value > 0:
        return value, source, rk

    for label in ("VideoPlayer.VideoBitrate", "Player.VideoBitrate"):
        try:
            raw = xbmc.getInfoLabel(label) or ""
        except Exception:
            raw = ""
        value = _parse_mbps(raw)
        if value > 0:
            return value, label, rk
    return 0.0, "unknown", rk


def _linux_rx_counters():
    out = {}
    try:
        with open("/proc/net/dev", "r") as fh:
            for line in fh:
                if ":" not in line:
                    continue
                name, rest = line.split(":", 1)
                name = name.strip()
                if not name or name == "lo":
                    continue
                parts = rest.split()
                if not parts:
                    continue
                try:
                    out[name] = int(parts[0])
                except Exception:
                    continue
    except Exception:
        pass
    return out


def _windows_rx_counters():
    """Read Windows interface octet counters with iphlpapi; no subprocess."""
    out = {}
    if os.name != "nt":
        return out
    try:
        from ctypes import wintypes

        MAX_INTERFACE_NAME_LEN = 256
        MAXLEN_PHYSADDR = 8
        MAXLEN_IFDESCR = 256

        class MIB_IFROW(ctypes.Structure):
            _fields_ = [
                ("wszName", wintypes.WCHAR * MAX_INTERFACE_NAME_LEN),
                ("dwIndex", wintypes.DWORD),
                ("dwType", wintypes.DWORD),
                ("dwMtu", wintypes.DWORD),
                ("dwSpeed", wintypes.DWORD),
                ("dwPhysAddrLen", wintypes.DWORD),
                ("bPhysAddr", ctypes.c_ubyte * MAXLEN_PHYSADDR),
                ("dwAdminStatus", wintypes.DWORD),
                ("dwOperStatus", wintypes.DWORD),
                ("dwLastChange", wintypes.DWORD),
                ("dwInOctets", wintypes.DWORD),
                ("dwInUcastPkts", wintypes.DWORD),
                ("dwInNUcastPkts", wintypes.DWORD),
                ("dwInDiscards", wintypes.DWORD),
                ("dwInErrors", wintypes.DWORD),
                ("dwInUnknownProtos", wintypes.DWORD),
                ("dwOutOctets", wintypes.DWORD),
                ("dwOutUcastPkts", wintypes.DWORD),
                ("dwOutNUcastPkts", wintypes.DWORD),
                ("dwOutDiscards", wintypes.DWORD),
                ("dwOutErrors", wintypes.DWORD),
                ("dwOutQLen", wintypes.DWORD),
                ("dwDescrLen", wintypes.DWORD),
                ("bDescr", ctypes.c_ubyte * MAXLEN_IFDESCR),
            ]

        iphlpapi = ctypes.WinDLL("iphlpapi")
        get_if_table = iphlpapi.GetIfTable
        get_if_table.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.ULONG), wintypes.BOOL]
        get_if_table.restype = wintypes.DWORD

        size = wintypes.ULONG(0)
        get_if_table(None, ctypes.byref(size), False)
        if int(size.value or 0) <= 4:
            return out
        buf = ctypes.create_string_buffer(int(size.value))
        rc = int(get_if_table(buf, ctypes.byref(size), False))
        if rc != 0:
            return out
        count = ctypes.cast(buf, ctypes.POINTER(wintypes.DWORD)).contents.value
        base = ctypes.addressof(buf) + ctypes.sizeof(wintypes.DWORD)
        step = ctypes.sizeof(MIB_IFROW)
        for i in range(int(count or 0)):
            row = MIB_IFROW.from_address(base + i * step)
            # IF_TYPE_SOFTWARE_LOOPBACK = 24.  Keep connected/operational rows;
            # some drivers report 0 for status while still carrying traffic, so
            # non-zero octets are also accepted.
            if int(row.dwType) == 24:
                continue
            if int(row.dwInOctets) <= 0 and int(row.dwOperStatus) < 4:
                continue
            out[str(int(row.dwIndex))] = int(row.dwInOctets)
    except Exception as exc:
        _log("NETWORK_HEALTH_WINDOWS_COUNTER_FAILED_V2126 err=%s" % exc, xbmc.LOGWARNING)
    return out


def _rx_counters():
    if os.name == "nt":
        return _windows_rx_counters()
    return _linux_rx_counters()


def _counter_delta(prev, current):
    total = 0
    for key, cur in (current or {}).items():
        if key not in (prev or {}):
            continue
        old = int(prev.get(key) or 0)
        cur = int(cur or 0)
        if cur >= old:
            delta = cur - old
        elif os.name == "nt":
            # GetIfTable exposes 32-bit octet counters.
            delta = (1 << 32) - old + cur
        else:
            delta = 0
        # Ignore impossible jumps caused by interface reset/recreation.
        if 0 <= delta <= (2 * 1024 * 1024 * 1024):
            total += delta
    return int(total)


def _cache_percentage():
    try:
        raw = str(xbmc.getInfoLabel("Player.ProgressCache") or "").strip().replace("%", "")
        if raw:
            val = float(raw)
            if 0.0 <= val <= 100.0:
                return val
    except Exception:
        pass
    # JSON-RPC is local to Kodi and does not touch the Plex/network path.
    try:
        active = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.GetActivePlayers"
        })) or "{}").get("result") or []
        player_id = -1
        for item in active:
            if item.get("type") == "video":
                player_id = int(item.get("playerid"))
                break
        if player_id >= 0:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Player.GetProperties",
                "params": {"playerid": player_id, "properties": ["cachepercentage"]},
            })) or "{}").get("result") or {}
            val = float(result.get("cachepercentage"))
            if 0.0 <= val <= 100.0:
                return val
    except Exception:
        pass
    return None


def _format_mbps(value):
    try:
        v = float(value or 0.0)
    except Exception:
        v = 0.0
    if v <= 0:
        return "측정 중"
    if v >= 100.0:
        return "%.0f Mbps" % v
    return "%.1f Mbps" % v


def _format_ratio(value):
    try:
        v = float(value or 0.0)
    except Exception:
        v = 0.0
    if v <= 0:
        return "측정 중"
    return "%.1f배" % v


def _format_buffer(value):
    if value is None:
        return "정보 없음"
    try:
        return "%d%%" % int(round(float(value)))
    except Exception:
        return "정보 없음"


# R61: SHIELD (Android 11) does not allow reading /proc/net/dev, so the NIC
# counters are empty and the indicator stayed grey ("checking") forever.  The
# player cache itself is a better signal anyway: Kodi's cache end advances by
# (download speed / content bitrate) media-seconds per second while it fills,
# and stays far ahead of the playhead when the network keeps up.
R61_FILL_WINDOW_MS = 6000
R61_GOOD_LEAD_SEC = 20.0
R61_LOW_LEAD_SEC = 6.0
_R61_MEM = {"v": None, "at": 0}


def _r61_jsonrpc(method, params=None):
    try:
        req = {"jsonrpc": "2.0", "id": 62, "method": method}
        if params is not None:
            req["params"] = params
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)) or "{}")
    except Exception:
        return {}


def _r61_cache_mem_mb():
    now = _now_ms()
    if _R61_MEM["v"] is not None and now - int(_R61_MEM["at"] or 0) < 300000:
        return _R61_MEM["v"]
    value = 20.0
    try:
        v = float((_r61_jsonrpc("Settings.GetSettingValue", {"setting": "filecache.memorysize"}).get("result") or {}).get("value"))
        if v > 0:
            value = v
    except Exception:
        pass
    _R61_MEM["v"] = value
    _R61_MEM["at"] = now
    return value


def _r61_cache_snapshot():
    try:
        active = _r61_jsonrpc("Player.GetActivePlayers").get("result") or []
        pid = -1
        for item in active:
            if item.get("type") == "video":
                pid = int(item.get("playerid"))
                break
        if pid < 0:
            return None
        res = _r61_jsonrpc("Player.GetProperties", {
            "playerid": pid, "properties": ["cachepercentage", "time", "totaltime", "speed"],
        }).get("result") or {}

        def _secs(t):
            t = t or {}
            return (float(t.get("hours", 0)) * 3600.0 + float(t.get("minutes", 0)) * 60.0
                    + float(t.get("seconds", 0)) + float(t.get("milliseconds", 0)) / 1000.0)

        total = _secs(res.get("totaltime"))
        cur = _secs(res.get("time"))
        if total <= 1.0:
            return None
        cache_end = max(0.0, min(total, float(res.get("cachepercentage") or 0.0) * total / 100.0))
        return {"cur": cur, "total": total, "cache_end": cache_end,
                "lead": max(0.0, cache_end - cur), "speed": float(res.get("speed") or 0.0)}
    except Exception:
        return None


def _format_lead(value):
    if value is None:
        return "정보 없음"
    try:
        v = float(value)
    except Exception:
        return "정보 없음"
    if v >= 60.0:
        return "%d분 %d초 앞" % (int(v) // 60, int(v) % 60)
    return "%d초 앞" % int(round(v))


def _percentile70(values):
    vals = sorted(float(v) for v in values if float(v) > 0.0)
    if not vals:
        return 0.0
    idx = int(round((len(vals) - 1) * 0.70))
    return float(vals[max(0, min(len(vals) - 1, idx))])


class NetworkHealthMonitor(object):
    """Read-only playback network observer.

    It never starts an HTTP request, never probes Plex, and never changes Kodi
    playback.  Receive throughput comes from the device's existing NIC byte
    counters while Kodi is already streaming.
    """

    def __init__(self):
        self.active = False
        self.last_sample_ms = 0
        self.prev_counters = {}
        self.samples = []
        self.last_positive_ms = 0
        self.capacity_mbps = 0.0
        self.required_mbps = 0.0
        self.required_source = ""
        self.rating_key = ""
        self.last_bitrate_try_ms = 0
        self.last_cache = None
        self.last_cache_ms = 0
        self.state = "checking"
        self.low_since_ms = 0
        self.recover_since_ms = 0
        self.last_logged_state = ""
        self.last_log_ms = 0
        self.fill = []
        self.lead = None
        self.fill_ratio = 0.0
        self.method = ""

    def stop(self, reason=""):
        self.active = False
        self.prev_counters = {}
        self.samples = []
        self.last_positive_ms = 0
        self.capacity_mbps = 0.0
        self.required_mbps = 0.0
        self.required_source = ""
        self.rating_key = ""
        self.last_bitrate_try_ms = 0
        self.last_cache = None
        self.last_cache_ms = 0
        self.state = "checking"
        self.low_since_ms = 0
        self.recover_since_ms = 0
        self.last_logged_state = ""
        self.last_log_ms = 0
        self.fill = []
        self.lead = None
        self.fill_ratio = 0.0
        self.method = ""
        _clear_all_properties(reason=reason or "stop")

    def start(self, player=None, reason=""):
        self.stop(reason="restart_before_%s" % (reason or "start"))
        try:
            path = str(player.getPlayingFile() if player is not None else xbmc.Player().getPlayingFile() or "")
        except Exception:
            path = ""
        low = path.lower()
        is_stream = (
            low.startswith("http://")
            or low.startswith("https://")
            or (low.startswith("plugin://plugin.video.km/") and "action=play" in low and "part_key=" in low)
        )
        if not is_stream:
            _log("NETWORK_HEALTH_SKIP_V2126 reason=%s stream=0 path_type=%s" % (
                reason or "", "local_or_unknown" if path else "empty"
            ))
            return False
        self.active = True
        self.prev_counters = _rx_counters()
        self.last_sample_ms = _now_ms()
        self.required_mbps, self.required_source, self.rating_key = _required_bitrate_mbps()
        self.last_bitrate_try_ms = self.last_sample_ms
        _set_prop("Active", "1")
        _set_prop("State", "checking")
        _set_prop("StateLabel", "측정 중")
        _set_prop("RequiredMbps", _format_mbps(self.required_mbps))
        _set_prop("ReceiveMbps", "측정 중")
        _set_prop("Ratio", "측정 중")
        _set_prop("Buffer", "측정 중")
        _set_prop("Message", "네트워크 상태를 측정하고 있습니다")
        _set_prop("Source", self.required_source or "unknown")
        _set_prop("RatingKey", self.rating_key or "")
        _set_prop("UpdatedAtMs", str(self.last_sample_ms))
        _log("NETWORK_HEALTH_START_V2126 reason=%s rating_key=%s required=%.3f source=%s rx_interfaces=%d probe_http=0 focus_write=0" % (
            reason or "", self.rating_key or "", self.required_mbps, self.required_source or "unknown", len(self.prev_counters)
        ))
        return True

    def _publish(self, now_ms, cache_pct, ratio, cache_trend, caching):
        state_label = "측정 중"
        message = "네트워크 상태를 측정하고 있습니다"
        if self.state == "good":
            state_label = "원활"
            message = "현재 네트워크로 원활한 재생이 가능합니다"
        elif self.state == "poor":
            state_label = "버퍼링" if caching else "부족"
            message = "현재 상태가 지속되면 버퍼링이 발생할 수 있습니다"
        elif self.state == "warning":
            state_label = "주의"
            message = "재생은 가능하지만 네트워크 여유가 적습니다"

        lead = self.lead
        full = lead is not None and lead >= R61_GOOD_LEAD_SEC and self.capacity_mbps <= 0.0
        _set_prop("Active", "1")
        _set_prop("State", self.state)
        _set_prop("StateLabel", state_label)
        _set_prop("RequiredMbps", _format_mbps(self.required_mbps))
        if self.capacity_mbps > 0.0:
            _set_prop("ReceiveMbps", _format_mbps(self.capacity_mbps))
        elif full:
            _set_prop("ReceiveMbps", "충분 (버퍼 가득)")
        else:
            _set_prop("ReceiveMbps", "측정 중")
        if ratio > 0.0:
            _set_prop("Ratio", _format_ratio(ratio))
        elif full:
            _set_prop("Ratio", "여유 있음")
        else:
            _set_prop("Ratio", "측정 중")
        _set_prop("Buffer", _format_lead(lead))
        _set_prop("Message", message)
        _set_prop("Source", self.required_source or "unknown")
        _set_prop("RatingKey", self.rating_key or "")
        _set_prop("UpdatedAtMs", str(now_ms))
        _set_prop("LeadSec", "" if lead is None else "%.1f" % lead)
        _set_prop("RatioValue", "%.3f" % float(ratio or 0.0))
        _set_prop("RequiredValue", "%.3f" % float(self.required_mbps or 0.0))
        _set_prop("CapacityValue", "%.3f" % float(self.capacity_mbps or 0.0))
        _set_prop("Method", self.method or "")

        if self.state != self.last_logged_state or now_ms - self.last_log_ms >= 10000:
            self.last_logged_state = self.state
            self.last_log_ms = now_ms
            _log("NETWORK_HEALTH_R61 state=%s required=%.3f receive=%.3f ratio=%.3f lead=%s fill_ratio=%.2f trend=%.3f caching=%d nic_samples=%d method=%s" % (
                self.state, self.required_mbps, self.capacity_mbps, ratio,
                "unknown" if lead is None else "%.1f" % lead, self.fill_ratio,
                float(cache_trend or 0.0), 1 if caching else 0, len(self.samples), self.method or "-"
            ))

    def tick(self, player=None):
        if not self.active:
            return False
        now_ms = _now_ms()
        if now_ms - self.last_sample_ms < SAMPLE_MS:
            return True
        try:
            is_playing = bool(player.isPlayingVideo() if player is not None else xbmc.Player().isPlayingVideo())
        except Exception:
            is_playing = False
        if not is_playing:
            self.stop(reason="not_playing_tick")
            return False

        elapsed = max(0.001, float(now_ms - self.last_sample_ms) / 1000.0)
        current = _rx_counters()
        delta = _counter_delta(self.prev_counters, current)
        self.prev_counters = current
        self.last_sample_ms = now_ms
        instant_mbps = (float(delta) * 8.0) / (elapsed * 1000000.0) if delta > 0 else 0.0
        if instant_mbps >= ACTIVE_SAMPLE_MIN_MBPS:
            self.samples.append((now_ms, instant_mbps))
            self.last_positive_ms = now_ms
        self.samples = [(ts, val) for ts, val in self.samples if now_ms - int(ts) <= SAMPLE_WINDOW_MS]
        nic_values = [val for _ts, val in self.samples]

        if (self.required_mbps <= 0.0 or not self.rating_key) and now_ms - self.last_bitrate_try_ms >= 2500:
            self.required_mbps, self.required_source, self.rating_key = _required_bitrate_mbps()
            self.last_bitrate_try_ms = now_ms

        # R61: player cache lead and fill rate.
        snap = _r61_cache_snapshot()
        lead_trend = 0.0
        if snap is not None:
            prev_lead = self.lead
            self.lead = snap["lead"]
            if self.fill:
                last_ts, last_end = self.fill[-1]
                jump = snap["cache_end"] - last_end
                if jump < -1.0 or jump > 60.0:
                    # seek / cache reset: restart the measurement window
                    self.fill = []
            self.fill.append((now_ms, snap["cache_end"]))
            self.fill = [(ts, v) for ts, v in self.fill if now_ms - int(ts) <= R61_FILL_WINDOW_MS]
            if prev_lead is not None:
                lead_trend = (self.lead - prev_lead) / elapsed
        else:
            self.lead = None
            self.fill = []

        cap_sec = 0.0
        if self.required_mbps > 0.0:
            cap_sec = (_r61_cache_mem_mb() * 0.75 * 1024.0 * 1024.0 * 8.0) / (self.required_mbps * 1000000.0)
        cache_full = self.lead is not None and (
            self.lead >= R61_GOOD_LEAD_SEC * 3.0 or (cap_sec > 0.0 and self.lead >= cap_sec * 0.80))

        self.fill_ratio = 0.0
        if len(self.fill) >= 3 and not cache_full:
            span_ms = float(self.fill[-1][0] - self.fill[0][0])
            if span_ms >= 2000.0:
                self.fill_ratio = max(0.0, (self.fill[-1][1] - self.fill[0][1]) / (span_ms / 1000.0))

        if nic_values:
            self.capacity_mbps = _percentile70(nic_values)
            self.method = "nic"
        elif self.last_positive_ms and now_ms - self.last_positive_ms > CAPACITY_HOLD_MS:
            self.capacity_mbps = 0.0
        if not nic_values and self.fill_ratio > 0.0 and self.required_mbps > 0.0:
            self.capacity_mbps = self.fill_ratio * self.required_mbps
            self.method = "cache_fill"
        elif not nic_values and cache_full:
            self.method = "cache_full"

        try:
            caching = bool(xbmc.getCondVisibility("Player.Caching"))
        except Exception:
            caching = False

        ratio = (self.capacity_mbps / self.required_mbps) if self.capacity_mbps > 0.0 and self.required_mbps > 0.0 else 0.0
        lead = self.lead

        if caching:
            self.state = "poor"
            self.low_since_ms = now_ms
            self.recover_since_ms = 0
        elif (lead is None and ratio <= 0.0) or (
                ratio <= 0.0 and not cache_full
                and (lead is None or lead < R61_GOOD_LEAD_SEC)
                and (len(self.fill) < 2 or float(self.fill[-1][0] - self.fill[0][0]) < 2000.0)):
            # Still collecting the first fill-rate window (start or after seek).
            self.state = "checking"
            self.low_since_ms = 0
            self.recover_since_ms = 0
        else:
            good_now = (
                cache_full
                or (lead is not None and lead >= R61_GOOD_LEAD_SEC and lead_trend >= -0.5)
                or ratio >= GOOD_RATIO
                or (ratio >= GOOD_RATIO_WITH_BUFFER and lead is not None and lead >= R61_LOW_LEAD_SEC)
            )
            low_lead = lead is not None and lead < R61_LOW_LEAD_SEC and lead_trend <= 0.0
            severe = (ratio > 0.0 and ratio < SEVERE_RATIO) or (low_lead and lead < 2.0)
            low = (ratio > 0.0 and ratio < LOW_RATIO) or low_lead

            if self.state == "poor":
                if good_now:
                    if not self.recover_since_ms:
                        self.recover_since_ms = now_ms
                    if now_ms - self.recover_since_ms >= RECOVER_HOLD_MS:
                        self.state = "good"
                        self.low_since_ms = 0
                        self.recover_since_ms = 0
                else:
                    self.recover_since_ms = 0
            elif good_now:
                self.low_since_ms = 0
                self.state = "good"
            elif severe or low:
                if not self.low_since_ms:
                    self.low_since_ms = now_ms
                hold = SEVERE_HOLD_MS if severe else LOW_HOLD_MS
                if now_ms - self.low_since_ms >= hold:
                    self.state = "poor"
                    self.recover_since_ms = 0
                else:
                    self.state = "warning"
            else:
                self.low_since_ms = 0
                self.state = "warning" if (ratio > 0.0 or lead is not None) else "checking"

        cache_pct = None
        self._publish(now_ms, cache_pct, ratio, lead_trend, caching)
        return True
