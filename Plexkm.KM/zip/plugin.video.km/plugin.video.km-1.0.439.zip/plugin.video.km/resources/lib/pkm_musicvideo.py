# -*- coding: utf-8 -*-
"""PlexKM 뮤직비디오: 라이브러리에 등록한 뮤직비디오 폴더를 읽어 사이드메뉴와 목록으로 보여 준다.

이름 읽기·색인·갱신은 script.module.pkm.musicagent(종속 모듈)가 한다. 모듈이 없으면 이 파일은
아무 일도 하지 않고(available() == False) PlexKM 은 그대로 동작한다.
1차 버전: 사이드메뉴 항목 -> 코디 기본 목록(아티스트 -> 영상). 인포 페이지·격자 보기는 시안 확정 뒤.
"""
import os
import threading
import time
import traceback

try:
    from urllib.parse import quote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import xbmcaddon
except Exception:  # pragma: no cover
    xbmcaddon = None

def _load_agent():
    """종속 모듈을 불러온다. 코디가 아직 사용 안 함 상태로 둔 모듈이어도, 파일이 있으면 경로를 직접 더해 쓴다."""
    try:
        import pkm_musicagent as mod
        return mod
    except Exception:
        pass
    try:
        import sys
        lib = xbmcvfs.translatePath("special://home/addons/script.module.pkm.musicagent/lib")
        if lib and os.path.isdir(lib):
            if lib not in sys.path:
                sys.path.append(lib)
            import pkm_musicagent as mod
            return mod
    except Exception:
        pass
    return None


_agent = _load_agent()  # 모듈이 아직 설치되지 않은 기기는 None

from resources.lib import pkm_sources as ps

PLUGIN = "plugin://plugin.video.km/"

# 스캔 전에 보여 주는 이름 안내(확인창 글상자는 줄바꿈되지만 잘리지 않게 줄을 짧게 둔다)
GUIDE_TITLE = "뮤직비디오 이름 안내"
GUIDE_BODY = "\n".join([
    "아티스트 - 제목.mp4 로 두면 가장 잘 읽힙니다",
    "음악방송은 날짜 폴더 안에 무대 파일을 둡니다",
    "콘서트·공연은 작품마다 폴더 하나로 둡니다",
    "같은 이름의 .nfo, -poster.jpg 가 있으면 먼저 씁니다",
])
_STORE = [None]
_WATCH = {}


def _log(msg, level=xbmc.LOGINFO):
    try:
        import re as _re
        msg = _re.sub(r"(?<=://)[^/@\s]*@", "***@", msg)
        xbmc.log("[plugin.video.km] MV_R337 " + msg, level)
    except Exception:
        pass


def available():
    global _agent
    if _agent is None:
        _agent = _load_agent()
    return _agent is not None


def _store():
    if _STORE[0] is None:
        base = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
        _STORE[0] = _agent.IndexStore(base)
    return _STORE[0]


# ------------------------------------------------------------------ 소스
def sources():
    return [s for s in ps.kodi_sources() if s.get("content") == ps.KODI_CONTENT_MUSICVIDEOS]


def _root(src):
    return ps.normalize_folder(src.get("path") or "")


def _folder_name(src):
    parts = [x for x in (src.get("path") or "").replace("\\", "/").split("/") if x and not x.endswith(":")]
    return parts[-1] if parts else ""


def display_name(src):
    return ps.lib_pref(src.get("id"), "name", "") or src.get("label") or _folder_name(src) or "뮤직비디오"


def visible_sources():
    return [s for s in sources() if not ps.lib_pref(s.get("id"), "hidden", False)]


def sidebar_sig():
    return tuple((s.get("id"), display_name(s)) for s in visible_sources())


def bump():
    """사이드메뉴가 항목을 다시 만들게 한다(기존 코디 라이브러리 감시 스레드가 이 값을 본다)."""
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.SyncedAtR108", str(time.time()))
    except Exception:
        pass


def summary(src):
    """설정 화면용: (개수, 마지막 스캔 시각)."""
    if not available():
        return 0, 0
    try:
        idx = _store().load(src["id"])
        return len(idx.get("items", [])), int(idx.get("scanned_at") or 0)
    except Exception:
        return 0, 0


# ------------------------------------------------------------------ 스캔
def _listdir_for(root):
    def listdir(rel):
        path = root + (rel + "/" if rel else "")
        dirs, files = xbmcvfs.listdir(path)
        # 느린 네트워크 폴더라 파일마다 Stat 을 부르지 않는다(크기·시각 0). 추가·삭제는 목록 차이로 감지.
        return [(d, True, 0, 0) for d in dirs] + [(f, False, 0, 0) for f in files]
    return listdir


def _reader_for(root):
    def read_text(rel):
        f = xbmcvfs.File(root + rel)
        try:
            return f.read()
        finally:
            f.close()
    return read_text


def scan_source(src, notify=True):
    """백그라운드로 스캔하고, 끝나면 알림 + 사이드메뉴 갱신. 이미 돌고 있으면 False."""
    if not available():
        return False
    sid = src["id"]
    root = _root(src)
    st = _store()
    if not st.scan_async(sid, _listdir_for(root), _reader_for(root), None, default_kind="mv"):
        return False
    name = display_name(src)
    if notify:
        _toast("%s 스캔을 시작했습니다" % name)

    def _watch():
        mon = xbmc.Monitor()
        while not mon.abortRequested():
            state = (st.progress.get(sid) or {}).get("state")
            if state != "running":
                break
            if mon.waitForAbort(1.0):
                return
        res = (st.progress.get(sid) or {})
        if res.get("state") == "done":
            r = res.get("result") or {}
            if int(r.get("total") or 0) <= 0:
                _log("scan_empty sid=%s %s" % (sid, r), xbmc.LOGWARNING)
                if notify:
                    _toast("%s 폴더를 읽지 못했거나 영상이 없습니다. 주소와 접속 정보를 확인해 주세요" % name, ms=6000)
                bump()
                return
            ps.set_lib_pref(sid, synced_at=int(time.time()))
            if notify:
                _toast("%s 가수 사진과 앨범 자켓을 받는 중입니다" % name, ms=4000)
            try:
                enrich_fast(src)
            except Exception:
                _log("fast_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            try:
                mirror_source(src)
            except Exception:
                _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            if notify:
                _toast("%s 정리를 마쳤습니다: %d개" % (name, int(r.get("total") or 0)), ms=5000)
            bump()
            try:                          # 곡별 앨범 자켓은 화면을 연 뒤 이어서 받고, 받는 대로 바꿔 끼운다
                enrich_songs(src)
                mirror_source(src)
                bump()
            except Exception:
                _log("songs_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            enrich_itunes(src)           # Deezer 에 없는 가수는 iTunes 한국 스토어로(백그라운드, 느림)
            enrich_source(src, notify=notify)
            enrich_artists(src)          # 팬아트(TheAudioDB)는 여유 있게 백그라운드로
            return
        _log("scan_failed sid=%s %s" % (sid, res.get("error", "")), xbmc.LOGWARNING)
        if notify:
            _toast("%s 스캔에 실패했습니다" % name, ms=5000)
        bump()
    threading.Thread(target=_watch, name="PKMMusicVideoScanWatch", daemon=True).start()
    return True


def enrich_source(src, notify=True):
    """온라인에서 앨범 자켓·발매 정보를 찾는다(백그라운드, 이어받기). 찾는 대로 목록에 반영된다."""
    if not available() or not hasattr(_agent, "lookup"):
        return False
    sid = src["id"]
    st = _store()
    try:
        _agent.lookup.ITUNES_BUDGET[0] = 300
    except Exception:
        pass
    if not st.enrich_async(sid, _agent.lookup.candidates):
        return False
    key = sid + ":enrich"
    name = display_name(src)
    if notify:
        _toast("%s 앨범 자켓을 찾는 중입니다. 백그라운드로 계속됩니다" % name, ms=5000)

    def _watch():
        mon = xbmc.Monitor()
        last_mirror = time.time()
        while not mon.abortRequested():
            if (st.progress.get(key) or {}).get("state") != "running":
                break
            if mon.waitForAbort(2.0):
                return
            if time.time() - last_mirror >= 90:      # 찾는 대로 자켓이 화면에 나타나게 주기적으로 영화 DB 에 반영
                last_mirror = time.time()
                try:
                    mirror_source(src)
                except Exception:
                    _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        res = st.progress.get(key) or {}
        if res.get("state") == "done":
            r = res.get("result") or {}
            _log("enrich_done sid=%s %s" % (sid, r))
            if notify:
                msg = "%s 앨범 자켓 %d개를 찾았습니다" % (name, int(r.get("hits") or 0))
                if r.get("stopped"):
                    msg += "\n연결이 불안정해 중간에 멈췄습니다. 다음 스캔에서 이어서 찾습니다"
                _toast(msg, ms=6000)
        else:
            _log("enrich_failed sid=%s %s" % (sid, res.get("error", "")), xbmc.LOGWARNING)
        try:
            mirror_source(src)
        except Exception:
            _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        bump()
    threading.Thread(target=_watch, name="PKMMusicVideoEnrichWatch", daemon=True).start()
    return True


def _toast(msg, ms=3500):
    try:
        from resources.lib import pkm_notify
        pkm_notify.pkm_show_notice("뮤직비디오", msg, "", ms=ms)
        return
    except Exception:
        pass
    try:
        xbmcgui.Dialog().notification("PlexKM", msg, xbmcgui.NOTIFICATION_INFO, ms)
    except Exception:
        pass


# ------------------------------------------------------------------ 목록
def view_url(sid, view="", artist=""):
    q = {"action": "musicvideo", "source": sid}
    if view:
        q["view"] = view
    if artist != "":
        q["artist"] = artist
    return PLUGIN + "?" + urlencode(q)


def _thumb(full):
    return "image://video@%s/" % quote(full, safe="")


def _full(root, rel):
    return root + rel


def _merged(it):
    """온라인으로 찾은 정보(meta)로 비어 있는 연도·앨범·장르를 채운 사본."""
    m = it.get("meta") or {}
    if not m:
        return it
    out = dict(it)
    for k in ("year", "album", "genre"):
        if not out.get(k) and m.get(k):
            out[k] = m[k]
    return out


def _art(root, it):
    imgs = it.get("images") or {}
    meta = it.get("meta") or {}
    frame = _thumb(_full(root, it["path"]))
    art = {}
    if imgs.get("thumb"):
        art["thumb"] = _full(root, imgs["thumb"])
    if imgs.get("poster"):
        art["poster"] = _full(root, imgs["poster"])
    if imgs.get("fanart"):
        art["fanart"] = _full(root, imgs["fanart"])
    if it.get("poster") and "poster" not in art:
        art["poster"] = it["poster"]
    if it.get("fanart"):
        art.setdefault("fanart", it["fanart"])
    if meta.get("cover"):                       # 앨범 자켓: 포스터 자리, 프레임은 가로 그림으로
        art.setdefault("poster", meta["cover"])
        art.setdefault("thumb", meta["cover"])
        art["landscape"] = frame
    if "thumb" not in art:
        art["thumb"] = art.get("poster") or frame
    art["icon"] = art["thumb"]
    return art


_CATS = (("mv", "뮤직비디오", ("mv",)), ("broadcast", "음악방송", ("broadcast",)),
         ("concert", "콘서트·공연", ("concert", "disc", "other")))


def _end(handle, items, content="musicvideos"):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def list_view(handle, sid, view="", artist=""):
    src = next((s for s in sources() if s.get("id") == sid), None)
    if src is None or not available():
        _end(handle, [])
        return
    root = _root(src)
    idx = _store().load(sid)
    items = idx.get("items", [])
    if not view:
        cats = [(v, t, [i for i in items if i["kind"] in kinds]) for v, t, kinds in _CATS]
        cats = [c for c in cats if c[2]]
        if len(cats) == 1:
            view = cats[0][0]
        else:
            rows = []
            for v, t, its in cats:
                li = xbmcgui.ListItem(label=t)
                li.setLabel2("%d" % len(its))
                li.setArt({"icon": "DefaultFolder.png"})
                rows.append((view_url(sid, v), li, True))
            _end(handle, rows, "files")
            return
    if view == "mv":
        mv = [i for i in items if i["kind"] == "mv"]
        if artist == "":
            _list_artists(handle, sid, root, mv)
        else:
            _list_artist_videos(handle, root, mv, artist)
    elif view == "broadcast":
        _list_broadcast(handle, root, [i for i in items if i["kind"] == "broadcast"])
    else:
        _list_concerts(handle, root, [i for i in items if i["kind"] in ("concert", "disc", "other")])


def _group_artists(mv):
    """같은 아티스트의 표기 차이(한글/영문 병기 순서, 영문만 등)를 하나로 묶는다. -> [{'name','items'}]"""
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    keys = []
    for it in mv:
        vs = _agent.parser.name_variants(it.get("artist", "")) or ["_"]
        for v in vs[1:]:
            parent[find(v)] = find(vs[0])
        keys.append(vs[0])
    groups = {}
    for it, k in zip(mv, keys):
        groups.setdefault(find(k), []).append(it)
    out = []
    for k, its in groups.items():
        names = {}
        for it in its:
            names[it.get("artist") or ""] = names.get(it.get("artist") or "", 0) + 1
        name = max(names.items(), key=lambda kv: (kv[1], -len(kv[0])))[0]
        out.append({"name": name, "items": its})
    out.sort(key=lambda g: (g["name"] == "", (g["name"] or "~").lower()))
    return out


def _list_artists(handle, sid, root, mv):
    rows = []
    for g in _group_artists(mv):
        li = xbmcgui.ListItem(label=g["name"] or "아티스트를 알 수 없음")
        li.setLabel2("%d" % len(g["items"]))
        li.setArt(_art(root, next((x for x in g["items"] if (x.get("meta") or {}).get("cover")), g["items"][0])))
        rows.append((view_url(sid, "mv", g["name"] or "-"), li, True))
    _end(handle, rows, "artists")


def _list_artist_videos(handle, root, mv, artist):
    name = "" if artist == "-" else artist
    sel = next((g["items"] for g in _group_artists(mv) if g["name"] == name), [])
    sel = sorted(sel, key=lambda i: (-(i.get("year") or 0), (i.get("title") or "").lower()))
    rows = []
    for it in sel:
        label = it.get("title") or os.path.basename(it["path"])
        tags = [t for t in (it.get("tags") or []) if t != "hq"]
        if tags:
            label += " (" + ", ".join(tags) + ")"
        li = xbmcgui.ListItem(label=label)
        li.setArt(_art(root, it))
        _tag(li, _merged(it), "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_broadcast(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("date") or "", i.get("path") or ""), reverse=True)
    rows = []
    for it in items:
        who = it.get("artist") or ""
        what = it.get("title") or os.path.basename(it["path"])
        li = xbmcgui.ListItem(label=("%s - %s" % (who, what)) if who else what)
        li.setLabel2(" ".join(x for x in (it.get("date"), it.get("show")) if x))
        li.setArt(_art(root, it))
        _tag(li, _merged(it), "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_concerts(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("title") or "").lower())
    rows = []
    for it in items:
        li = xbmcgui.ListItem(label=it.get("title") or os.path.basename(it["path"]))
        if it.get("year"):
            li.setLabel2(str(it["year"]))
        li.setArt(_art(root, it))
        _tag(li, it, "video")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows, "videos")


def _tag(li, it, mediatype):
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        tag.setTitle(it.get("title") or "")
        if it.get("artist") and mediatype == "musicvideo":
            try:
                tag.setArtists([it["artist"]])
            except Exception:
                pass
        if it.get("year"):
            tag.setYear(int(it["year"]))
        if it.get("album"):
            try:
                tag.setAlbum(it["album"])
            except Exception:
                pass
        if it.get("plot"):
            tag.setPlot(it["plot"])
        if it.get("genre"):
            tag.setGenres(list(it["genre"]) if isinstance(it["genre"], (list, tuple)) else [it["genre"]])
        if it.get("duration"):
            tag.setDuration(int(it["duration"]))
    except Exception:
        _log("tag_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


# ------------------------------------------------------------------ 영화 틀로 보여주기(홈 위젯·섹션 화면)
def section_id(src):
    """색인을 영화 DB 에 비춰 넣을 때 쓰는 섹션 id (k: 로 시작해야 Kodi 쪽 재생·사이드메뉴 경로를 탄다)."""
    import hashlib
    return "k:mv:" + hashlib.md5(str(src.get("id")).encode("utf-8")).hexdigest()[:8]


def mirrored_sections():
    """영화 DB 에 비춰진 뮤직비디오 섹션들(보이는 것만, 항목이 있는 것만)."""
    out = []
    if not available():
        return out
    import sqlite3
    from resources.lib import pkm_kodi_source as ks
    try:
        conn = sqlite3.connect(ks.db_path(), timeout=5.0)
        try:
            counts = dict(conn.execute("SELECT section_id, COUNT(*) FROM items WHERE section_id LIKE 'k:mv:%' GROUP BY section_id").fetchall())
        finally:
            conn.close()
    except Exception:
        counts = {}
    for src in visible_sources():
        sid = section_id(src)
        if counts.get(sid):
            out.append({"section_id": sid, "title": display_name(src), "section_type": "movie", "thumb": "", "art": "",
                        "scanned_at": int(time.time()), "item_count": int(counts[sid]), "source": "kodi", "mv_source": src.get("id")})
    return out


def _small(url, px=500):
    """Deezer 이미지는 포스터 칸(약 200px)에 1000px 원본을 받으면 느리다. 500px 로 받는다."""
    if "dzcdn.net/images/" in (url or ""):
        import re as _re
        return _re.sub(r"/1000x1000-", "/%dx%d-" % (px, px), url)
    return url


def mirror_source(src):
    """색인의 영상들을 영화 DB(items)에 넣는다. 영화 섹션 화면·인포·검색이 그대로 읽는다."""
    if not available():
        return 0
    import hashlib, json, sqlite3
    from resources.lib import pkm_kodi_source as ks
    sid = src["id"]
    root = _root(src)
    sec = section_id(src)
    idx = _store().load(sid)
    now = int(time.time())
    _log("mirror_loaded items=%d" % len(idx.get("items", [])))
    rows = []
    for raw in idx.get("items", []):
        it = _merged(raw)
        art = _art(root, it)
        full = _full(root, it["path"])
        rk = "k:mv:" + hashlib.md5((sid + "|" + it["path"]).encode("utf-8")).hexdigest()[:12]
        artist = it.get("artist") or ""
        title = it.get("title") or os.path.splitext(os.path.basename(it["path"]))[0]
        kind_ko = {"mv": "뮤직비디오", "broadcast": "음악방송", "concert": "콘서트", "disc": "공연 DVD"}.get(it.get("kind"), "영상")
        summary = " · ".join(x for x in (kind_ko, artist, it.get("album") or "") if x)
        aa = artist_art_cache().get(_norm_name(artist)) or {}
        cover = (it.get("meta") or {}).get("cover") or (song_cover_cache().get(_pkey(it["path"])) or {}).get("c") or ""
        if not cover:
            try:
                cover = _best_cover(aa, title)
            except Exception:
                cover = ""
        thumb = _small(art.get("poster") or cover or aa.get("thumb") or art.get("thumb") or "")
        fan = it.get("fanart") or aa.get("fanart") or aa.get("fanart2") or art.get("fanart") or aa.get("thumb") or cover or art.get("landscape") or art.get("thumb") or ""
        row = {"rating_key": rk, "section_id": sec, "plex_type": "movie", "kodi_type": "musicvideo", "title": title,
               "original_title": "", "sort_title": title, "year": int(it.get("year") or 0), "summary": summary,
               "duration": 0, "added_at": int(it.get("mtime") or idx.get("scanned_at") or now), "updated_at": now,
               "thumb": thumb, "art": fan,
               "media_file": full, "part_key": full, "view_count": 0, "last_viewed_at": 0,
               "parent_rating_key": "", "grandparent_rating_key": "", "show_title": "", "season": 0, "episode": 0,
               "raw_json": json.dumps({"ratingKey": rk, "type": "movie", "source": "kodi", "title": title, "file": full,
                                       "part_key": full, "year": str(it.get("year") or ""), "artist": artist}, ensure_ascii=False)}
        row["checksum"] = hashlib.md5(json.dumps(row, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
        genres = [g for g in str(it.get("genre") or "").split(",") if g.strip()]
        ex = {"genres": genres, "countries": [],
              "people": ([("actor", artist, kind_ko, "")] if artist else []), "rating": 0.0, "uniqueid": {}}
        rows.append((row, ex))
    _log("mirror_rows_built rows=%d" % len(rows))
    conn = sqlite3.connect(ks.db_path(), timeout=15.0)
    try:
        ks._ensure_schema(conn)
        keep = set(r["rating_key"] for r, _ in rows)
        old = [x[0] for x in conn.execute("SELECT rating_key FROM items WHERE section_id=?", (sec,)).fetchall()]
        for r, ex in rows:
            ks._write_row(conn, dict(r, synced_at=now), ex, now)
        gone = [x for x in old if x not in keep]
        for i in range(0, len(gone), 400):
            b = gone[i:i + 400]
            q = ",".join("?" * len(b))
            for tbl in ("items", "item_genres", "item_people", "item_countries", "item_ratings", "item_ids_r108"):
                conn.execute("DELETE FROM %s WHERE rating_key IN (%s)" % (tbl, q), b)
        conn.commit()
    finally:
        conn.close()
    _log("mirror_done sid=%s rows=%d" % (sid, len(rows)))
    return len(rows)


_MIRROR_ALL_DONE = False


def mirror_all_async():
    """시작할 때 색인은 있는데 영화 DB 에 없는 소스를 한 번 비춘다(백그라운드)."""
    def _run():
        try:
            _log("mirror_all_start sources=%d" % len(visible_sources()))
            have = set(x["section_id"] for x in mirrored_sections())
            _log("mirror_all_have %s" % ",".join(sorted(have)))
            for src in visible_sources():
                idx = _store().load(src["id"])
                if not idx.get("items"):
                    continue
                try:
                    enrich_fast(src)
                except Exception:
                    _log("fast_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                mirror_source(src)     # 시작할 때마다 색인의 최신 자켓·정보를 영화 DB 에 맞춘다
                bump()
                try:
                    enrich_songs(src)
                    mirror_source(src)
                    bump()
                except Exception:
                    _log("songs_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                enrich_itunes(src)
                enrich_artists(src)
                if not any((i.get("meta") or {}) for i in idx["items"]):
                    enrich_source(src, notify=False)   # 아직 앨범 자켓을 찾은 적이 없으면 백그라운드로 시작(이어받기)
        except Exception:
            _log("mirror_all_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    global _MIRROR_ALL_DONE
    if available() and not _MIRROR_ALL_DONE:
        _MIRROR_ALL_DONE = True
        try:   # 스레드 안에서 처음 import 하면 import 잠금에 걸릴 수 있어 먼저 불러 둔다
            import sqlite3  # noqa: F401
            from resources.lib import pkm_kodi_source  # noqa: F401
        except Exception:
            pass
        threading.Thread(target=_run, name="PKMMusicVideoMirrorAll", daemon=True).start()


# ------------------------------------------------------------------ 가수 사진·팬아트 (TheAudioDB)
_ART_LOCK = threading.Lock()
_ART_CACHE = [None]
_ART_RUNNING = [False]


def _art_path():
    base = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    return os.path.join(base, "pkm_mv_artist_art.json")


def _norm_name(x):
    import re as _re
    return _re.sub(r"[^0-9a-z가-힣]+", "", str(x or "").lower())


def _artist_forms(name):
    """'(여자)아이들((G)I-DLE)' -> 시험해 볼 이름들(영문 우선). 끝의 괄호 묶음을 짝을 맞춰 떼어 낸다."""
    import re as _re
    name = str(name or "").strip()
    forms = []
    if name.endswith(")"):
        depth = 0
        for i in range(len(name) - 1, -1, -1):
            c = name[i]
            depth += 1 if c == ")" else (-1 if c == "(" else 0)
            if depth == 0:
                head, inner = name[:i].strip(), name[i + 1:-1].strip()
                if head and inner:
                    pair = (inner, head) if (_re.search(r"[A-Za-z]", inner) and not _re.search(r"[A-Za-z]", head)) else (head, inner)
                    forms.extend(pair)
                break
    if name not in forms:
        forms.append(name)
    import re as _re2
    first = _re2.split(r"\s+[xX]\s+|\s*,\s*|\s*&\s*|\s*\(?[Ff]eat\.?", name)[0].strip()
    if first and first != name:                 # 'A X B', 'A, B' 같은 협업은 첫 가수 이름도 시험한다
        sub = _artist_forms(first)
        forms.extend(sub[:2])
    out = []
    for f in forms:
        if f and f not in out:
            out.append(f)
    return out[:4]


def artist_art_cache():
    if _ART_CACHE[0] is None:
        try:
            import json
            with open(_art_path(), "r", encoding="utf-8") as f:
                _ART_CACHE[0] = json.load(f)
        except Exception:
            _ART_CACHE[0] = {}
    return _ART_CACHE[0]


def _save_art_cache():
    try:
        import json
        tmp = _art_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_ART_CACHE[0] or {}, f, ensure_ascii=False)
        os.replace(tmp, _art_path())
    except Exception:
        pass


def _audiodb(name):
    import json
    try:
        from urllib.request import Request, urlopen
    except ImportError:  # pragma: no cover
        return None
    url = "https://www.theaudiodb.com/api/v1/json/123/search.php?s=" + quote(name)
    req = Request(url, headers={"User-Agent": "PlexKM/1.0"})
    with urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data.get("artists") or []


def _deezer_artist(name):
    import json
    from urllib.request import Request, urlopen
    url = "https://api.deezer.com/search/artist?limit=3&q=" + quote(name)
    req = Request(url, headers={"User-Agent": "PlexKM/1.0"})
    with urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data.get("data") or []


def enrich_artists(src, notify=False):
    """가수 사진·팬아트(고화질)를 찾아 캐시에 저장하고, 찾는 대로 영화 DB 에 반영한다(백그라운드, 이어받기)."""
    if not available() or _ART_RUNNING[0]:
        return False
    _ART_RUNNING[0] = True

    def _run():
        try:
            cache = artist_art_cache()
            idx = _store().load(src["id"])
            names, seen = [], set()
            for it in idx.get("items", []):
                a = (it.get("artist") or "").strip()
                k = _norm_name(a)
                if a and k and k not in seen:
                    seen.add(k)
                    names.append((k, a))
            todo = [(k, a) for k, a in names if not (cache.get(k) and (cache[k].get("thumb") or time.time() - cache[k].get("at", 0) < 30 * 86400))]
            _log("artist_art_start total=%d todo=%d" % (len(names), len(todo)))
            mon = xbmc.Monitor()
            hits = n = errs = 0
            for k, a in todo:
                if mon.abortRequested():
                    break
                found = None
                try:
                    for form in _artist_forms(a):
                        res = _audiodb(form)
                        want = set(_norm_name(f) for f in _artist_forms(a))
                        for ar in res:
                            if _norm_name(ar.get("strArtist")) in want or _norm_name(ar.get("strArtistAlternate")) in want:
                                found = ar
                                break
                        if found or mon.waitForAbort(2.2):
                            break
                        # 이름 하나당 호출은 분당 30회 제한 안쪽으로
                    errs = 0
                except Exception:
                    errs += 1
                    if errs >= 6:
                        _log("artist_art_stopped errs=%d" % errs, xbmc.LOGWARNING)
                        break
                    if mon.waitForAbort(5.0):
                        break
                    continue
                ent = {"at": int(time.time())}
                if not found or not found.get("strArtistThumb"):
                    try:      # TheAudioDB 에 없으면 Deezer 가수 사진(1000px)으로 채운다
                        want2 = set(_norm_name(f) for f in _artist_forms(a))
                        for form in _artist_forms(a)[:2]:
                            for dz in _deezer_artist(form):
                                if _norm_name(dz.get("name")) in want2 and dz.get("picture_xl") and "/artist//" not in dz.get("picture_xl"):
                                    ent["thumb"] = dz["picture_xl"]
                                    break
                            if ent.get("thumb"):
                                break
                    except Exception:
                        pass
                if found:
                    for key, fld in (("thumb", "strArtistThumb"), ("fanart", "strArtistFanart"), ("fanart2", "strArtistFanart2"),
                                     ("banner", "strArtistBanner"), ("logo", "strArtistLogo")):
                        if found.get(fld):
                            ent[key] = found[fld]
                    hits += 1
                cache[k] = ent
                n += 1
                if n % 20 == 0:
                    _save_art_cache()
                if n % 60 == 0:
                    try:
                        mirror_source(src)
                    except Exception:
                        pass
                if mon.waitForAbort(2.2):
                    break
            _save_art_cache()
            _log("artist_art_done looked=%d hits=%d" % (n, hits))
            try:
                mirror_source(src)
            except Exception:
                _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            bump()
        except Exception:
            _log("artist_art_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            _ART_RUNNING[0] = False
    threading.Thread(target=_run, name="PKMMusicVideoArtistArt", daemon=True).start()
    return True


# ------------------------------------------------------------------ 빠른 가수·앨범 조회(스캔 직후 한 번에)
_DZ_LOCK = threading.Lock()
_DZ_LAST = [0.0]


def _dz_get(url, tries=3):
    """Deezer 호출. 전체 초당 8회 안쪽으로 맞추고, 한도 오류·일시 오류는 잠깐 쉬고 다시 시도한다."""
    import json
    from urllib.request import Request, urlopen
    last = None
    for n in range(tries):
        with _DZ_LOCK:
            wait = _DZ_LAST[0] + 0.125 - time.time()
            if wait > 0:
                time.sleep(wait)
            _DZ_LAST[0] = time.time()
        try:
            with urlopen(Request(url, headers={"User-Agent": "PlexKM/1.0"}), timeout=10) as r:
                d = json.loads(r.read().decode("utf-8", "replace") or "{}")
            err = d.get("error") if isinstance(d, dict) else None
            if isinstance(err, dict) and err.get("code") in (4, 100):
                time.sleep(2.0 * (n + 1))
                last = RuntimeError("quota")
                continue
            return d
        except Exception as e:
            last = e
            time.sleep(0.6 * (n + 1))
    raise last


def _albums_of(dz_id):
    out, seen = [], set()
    for al in (_dz_get("https://api.deezer.com/artist/%s/albums?limit=100" % dz_id).get("data") or []):
        c = al.get("cover_xl") or al.get("cover_big") or ""
        if not c or "/album//" in c or al.get("record_type") not in ("album", "single", "ep"):
            continue
        k = _norm_name(al.get("title"))
        if k in seen:
            continue
        seen.add(k)
        out.append({"t": al.get("title") or "", "c": c, "y": str(al.get("release_date") or "")[:4]})
    return out


def _overlap(albums, titles):
    """이 가수의 앨범·싱글 제목 중 우리 곡 제목과 겹치는 개수(동명이인을 가려내는 데 쓴다)."""
    from difflib import SequenceMatcher
    n = 0
    for t in titles:
        tv = set(_agent.parser.title_variants(t)) if (_agent and hasattr(_agent, "parser")) else set([_norm_name(t)])
        for al in albums:
            av = set(_agent.parser.title_variants(al["t"])) if (_agent and hasattr(_agent, "parser")) else set([_norm_name(al["t"])])
            if any(x == y or (len(x) >= 4 and (x in y or y in x)) or SequenceMatcher(None, x, y).ratio() >= 0.88 for x in tv for y in av if x and y):
                n += 1
                break
    return n


def _fast_artist(a, titles=()):
    """가수 한 팀: Deezer 가수 사진(1000px) + 앨범·싱글 자켓 목록. 동명 가수가 여럿이면 우리 곡 제목과 앨범이 겹치는 쪽을 고른다.
    확인할 수 없는 동명 가수는 쓰지 않는다. 실패하면 예외(다음 실행에서 다시)."""
    want = set(_norm_name(f) for f in _artist_forms(a))
    cands, seen = [], set()
    for form in _artist_forms(a)[:4]:
        for dz in (_dz_get("https://api.deezer.com/search/artist?limit=6&q=" + quote(form)).get("data") or []):
            if _norm_name(dz.get("name")) in want and dz.get("id") not in seen:
                seen.add(dz.get("id"))
                cands.append(dz)
        if cands:
            break
    ent = {"at": int(time.time()), "albums": [], "v": 3}
    if not cands:
        return ent
    cands.sort(key=lambda d: -int(d.get("nb_fan") or 0))
    cands = cands[:3]
    best, best_albums, best_n = None, [], -1
    for dz in cands:
        albums = _albums_of(dz.get("id"))
        n = _overlap(albums, titles)
        if n > best_n or (n == best_n and len(albums) > len(best_albums)):
            best, best_albums, best_n = dz, albums, n
    if len(cands) > 1 and best_n <= 0:
        return ent                    # 동명 가수를 가릴 근거가 없으면 쓰지 않는다
    pic = best.get("picture_xl") or ""
    if pic and "/artist//" not in pic:
        ent["thumb"] = pic
    ent["dz"] = best.get("id")
    ent["albums"] = best_albums
    ent["ov"] = best_n
    return ent


def enrich_fast(src, progress=None):
    """가수 사진과 앨범 자켓 목록을 병렬로 받는다. 이미 받은 가수는 건너뛴다(이어받기)."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = artist_art_cache()
    idx = _store().load(src["id"])
    names, seen, tmap = [], set(), {}
    for it in idx.get("items", []):
        a = (it.get("artist") or "").strip()
        k = _norm_name(a)
        if a and k:
            tmap.setdefault(k, []).append(it.get("title") or "")
        if a and k and k not in seen:
            seen.add(k)
            names.append((k, a))
    todo = [(k, a) for k, a in names if (cache.get(k) or {}).get("v") != 3 or ((cache.get(k) or {}).get("albums") == [] and time.time() - (cache.get(k) or {}).get("at", 0) > 7 * 86400)]
    _log("fast_start artists=%d todo=%d" % (len(names), len(todo)))
    done = hit = fail = 0
    mon = xbmc.Monitor()

    def one(item):
        k, a = item
        if mon.abortRequested():
            return k, None
        try:
            return k, _fast_artist(a, tmap.get(k, ()))
        except Exception:
            return k, None
    with ThreadPoolExecutor(max_workers=6) as ex:
        for k, ent in ex.map(one, todo):
            done += 1
            if ent is None:
                fail += 1
            else:
                old = cache.get(k) or {}
                if ent.get("dz"):                  # 확인된 가수만 이전에 받은 팬아트를 이어 쓴다
                    for key in ("fanart", "fanart2", "banner", "logo"):
                        if old.get(key):
                            ent.setdefault(key, old[key])
                cache[k] = ent
                hit += 1 if (ent.get("thumb") or ent.get("albums")) else 0
            if done % 50 == 0:
                _save_art_cache()
                if progress:
                    progress(done, len(todo))
    _save_art_cache()
    _log("fast_done looked=%d hits=%d fail=%d sec=%.1f" % (done, hit, fail, time.time() - t0))
    return {"looked": done, "hits": hit, "failed": fail}


def _album_cover_exact(ent, title):
    """확인된 가수의 앨범·싱글 중 제목이 거의 같은 것의 자켓(없으면 빈 문자열). 이 경우 곡 검색을 건너뛴다."""
    albums = (ent or {}).get("albums") or []
    if not albums or not ((ent or {}).get("dz") or (ent or {}).get("it")):
        return ""
    from difflib import SequenceMatcher
    try:
        tv = set(_agent.parser.title_variants(title))
    except Exception:
        tv = set([_norm_name(title)])
    for al in albums:
        try:
            av = set(_agent.parser.title_variants(al["t"]))
        except Exception:
            av = set([_norm_name(al["t"])])
        if any(x and y and (x == y or SequenceMatcher(None, x, y).ratio() >= 0.92) for x in tv for y in av):
            return al["c"]
    return ""


def _best_cover(ent, title):
    """곡 제목과 같은(비슷한) 앨범·싱글 자켓, 없으면 그 가수의 가장 최근 앨범 자켓."""
    albums = (ent or {}).get("albums") or []
    if not albums:
        return ""
    try:
        tv = set(_agent.parser.title_variants(title))
    except Exception:
        tv = set([_norm_name(title)])
    best, bs = None, 0.0
    from difflib import SequenceMatcher
    for al in albums:
        av = set(_agent.parser.title_variants(al["t"])) if hasattr(_agent, "parser") else set([_norm_name(al["t"])])
        sc = max([1.0 if x == y else SequenceMatcher(None, x, y).ratio() for x in tv for y in av] or [0])
        if sc > bs:
            best, bs = al, sc
    if best and bs >= 0.85:
        return best["c"]
    return sorted(albums, key=lambda a: a.get("y") or "0", reverse=True)[0]["c"]


_SONG_CACHE = [None]


def _song_path():
    return os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "pkm_mv_song_cover.json")


def song_cover_cache():
    if _SONG_CACHE[0] is None:
        try:
            import json
            with open(_song_path(), "r", encoding="utf-8") as f:
                _SONG_CACHE[0] = json.load(f)
        except Exception:
            _SONG_CACHE[0] = {}
    return _SONG_CACHE[0]


def _pkey(path):
    import hashlib
    return hashlib.md5(path.encode("utf-8")).hexdigest()[:12]


def _core(x):
    import re as _re
    return _norm_name(_re.sub(r"[\(\[][^)\]]*[\)\]]", " ", str(x or "")))


def _song_cover(it):
    """파일 이름 전체와 맞는 곡을 Deezer 에서 찾아 앨범 자켓을 돌려준다. 가수와 제목이 둘 다 파일 이름에 있어야 받아들인다."""
    import unicodedata
    fn = unicodedata.normalize("NFC", os.path.splitext(os.path.basename(it["path"]))[0])
    fnn = _norm_name(fn)
    artist = unicodedata.normalize("NFC", it.get("artist") or "")
    title = unicodedata.normalize("NFC", it.get("title") or "")
    import re as _re
    qs = []
    first = (_artist_forms(artist) or [""])[0]
    tcore = _re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", title).strip() or title
    if first and tcore:
        qs.append(first + " " + tcore)
    m_in = _re.search(r"[\(\[]([^)\]]*[A-Za-z][^)\]]*)[\)\]]", title)
    if first and m_in and m_in.group(1).strip() and _norm_name(m_in.group(1)) != _norm_name(tcore):
        qs.append(first + " " + m_in.group(1).strip())
    qs.append(_re.sub(r"\s+", " ", _re.sub(r"\(1080p\)|\(Official[^)]*\)|\bOfficial\b|\bM_?V\b|Music Video|Performance Video|[\[\]「」『』【】\ue000-\uf8ff_\-]", " ", fn)).strip())
    for q in qs[:3]:
        rs = _dz_get("https://api.deezer.com/search?limit=8&q=" + quote(q)).get("data") or []
        for r in rs:
            an = _norm_name((r.get("artist") or {}).get("name"))
            tn = _core(r.get("title")) or _norm_name(r.get("title"))
            al = r.get("album") or {}
            cv = al.get("cover_xl") or al.get("cover_big") or ""
            if an and tn and an in fnn and tn in fnn and cv and "/album//" not in cv:
                return {"c": cv, "a": al.get("title") or ""}
        if rs:              # 결과는 있었는데 가수·제목이 안 맞으면 두 번째 검색은 하지 않는다(요청 절약)
            break
    return {}


def enrich_songs(src, progress=None):
    """곡별 앨범 자켓(병렬). 가수·제목이 모두 맞은 것만 쓰고, 못 찾은 곡은 가수 앨범 자켓으로 대신한다."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = song_cover_cache()
    idx = _store().load(src["id"])
    todo = [it for it in idx.get("items", []) if it.get("kind") in ("mv", "broadcast")
            and not (it.get("meta") or {}).get("cover")
            and (_pkey(it["path"]) not in cache or (not cache[_pkey(it["path"])].get("c") and cache[_pkey(it["path"])].get("v") != 2))]
    _log("songs_start todo=%d" % len(todo))
    mon = xbmc.Monitor()
    aac = artist_art_cache()
    pre = 0
    rest = []
    for it in todo:          # 가수 앨범 목록에 제목이 있는 곡은 검색 없이 바로 쓴다
        c = _album_cover_exact(aac.get(_norm_name(it.get("artist"))), it.get("title") or "")
        if c:
            cache[_pkey(it["path"])] = {"c": c, "a": "", "at": int(time.time()), "v": 2}
            pre += 1
        else:
            rest.append(it)
    todo = rest
    _log("songs_prematched=%d search=%d" % (pre, len(todo)))

    def one(it):
        if mon.abortRequested():
            return it, None
        try:
            return it, _song_cover(it)
        except Exception:
            return it, None
    done = hit = fail = 0
    with ThreadPoolExecutor(max_workers=6) as ex:
        for it, res in ex.map(one, todo):
            done += 1
            if res is None:
                fail += 1
                continue
            cache[_pkey(it["path"])] = dict(res, at=int(time.time()), v=2)
            hit += 1 if res.get("c") else 0
            if done % 100 == 0:
                try:
                    import json
                    tmp = _song_path() + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as f:
                        json.dump(cache, f, ensure_ascii=False)
                    os.replace(tmp, _song_path())
                except Exception:
                    pass
    try:
        import json
        tmp = _song_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(tmp, _song_path())
    except Exception:
        pass
    _log("songs_done looked=%d hits=%d fail=%d sec=%.1f" % (done, hit, fail, time.time() - t0))
    return {"looked": done, "hits": hit, "failed": fail}


# ------------------------------------------------------------------ iTunes(미국 스토어: 한국 스토어는 음악 검색 결과가 없다) 가수별 앨범: Deezer 에서 못 찾은 가수 보충
_IT_RUNNING = [False]
_IT_LAST = [0.0]


def _it_get(url):
    import json
    from urllib.request import Request, urlopen
    wait = _IT_LAST[0] + 3.2 - time.time()      # iTunes 는 분당 약 20회
    if wait > 0:
        time.sleep(wait)
    _IT_LAST[0] = time.time()
    with urlopen(Request(url, headers={"User-Agent": "PlexKM/1.0"}), timeout=12) as r:
        return json.loads(r.read().decode("utf-8", "replace") or "{}")


def _it_artist(a, titles):
    want = set(_norm_name(f) for f in _artist_forms(a))
    by = {}
    for form in _artist_forms(a)[:2]:
        d = _it_get("https://itunes.apple.com/search?country=us&entity=album&attribute=artistTerm&limit=60&term=" + quote(form))
        for r in d.get("results") or []:
            an = _norm_name(r.get("artistName"))
            if an in want and r.get("artworkUrl100"):
                import re as _re
                t = _re.sub(r"\s+-\s+(Single|EP)$", "", r.get("collectionName") or "")
                by.setdefault(r.get("artistId"), []).append({"t": t, "c": r["artworkUrl100"].replace("100x100bb", "600x600bb"),
                                                           "y": str(r.get("releaseDate") or "")[:4]})
        if by:
            break
    if not by:
        return None
    best = max(by.items(), key=lambda kv: (_overlap(kv[1], titles), len(kv[1])))
    if _overlap(best[1], titles) <= 0:       # 우리 곡 제목이 앨범에 하나도 없으면 동명이인으로 보고 쓰지 않는다
        return None
    return {"albums": best[1], "ov": _overlap(best[1], titles)}


def enrich_itunes(src):
    """Deezer(한국 IP 는 카탈로그가 좁다)에서 확인하지 못한 가수를 iTunes 한국 스토어로 보충한다. 천천히, 이어받기."""
    if not available() or _IT_RUNNING[0]:
        return False
    _IT_RUNNING[0] = True

    def _run():
        try:
            cache = artist_art_cache()
            idx = _store().load(src["id"])
            tmap, names = {}, {}
            for it in idx.get("items", []):
                a = (it.get("artist") or "").strip()
                k = _norm_name(a)
                if a and k:
                    tmap.setdefault(k, []).append(it.get("title") or "")
                    names[k] = a
            todo = [(k, a) for k, a in names.items()
                    if not (cache.get(k) or {}).get("albums") and (cache.get(k) or {}).get("itv") != 1]
            _log("itunes_start todo=%d" % len(todo))
            mon = xbmc.Monitor()
            n = hits = errs = 0
            t0 = time.time()
            for k, a in todo:
                if mon.abortRequested():
                    break
                try:
                    res = _it_artist(a, tmap.get(k, ()))
                    errs = 0
                except Exception:
                    errs += 1
                    if errs >= 5:
                        break
                    continue
                ent = cache.setdefault(k, {"at": int(time.time())})
                ent["itv"] = 1
                if res:
                    ent["albums"] = res["albums"]
                    ent["it"] = True
                    hits += 1
                n += 1
                if n % 25 == 0:
                    _save_art_cache()
                    try:
                        mirror_source(src)
                        bump()
                    except Exception:
                        pass
            _save_art_cache()
            _log("itunes_done looked=%d hits=%d sec=%.1f" % (n, hits, time.time() - t0))
            try:
                enrich_songs(src)
                mirror_source(src)
                bump()
            except Exception:
                pass
        except Exception:
            _log("itunes_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            _IT_RUNNING[0] = False
    threading.Thread(target=_run, name="PKMMusicVideoITunes", daemon=True).start()
    return True
