# -*- coding: utf-8 -*-
"""R119: PKM card menu dialog (hold OK on a poster card).

open_card_menu(title, sub, options) -> selected option index or -1.
options: list of (label, icon_path).
"""
import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
MEDIA = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r97s/"
ICON_HEART_OUTLINE = MEDIA + "heart_outline_48.png"
ICON_HEART_FILL = MEDIA + "heart_fill_48.png"
ICON_REFRESH = MEDIA + "cat_reset_48.png"   # R120: 메타 새로고침

LIST_ID = 400
GROUP_ID = 410
RIM_ID = 411
CARD_ID = 412
ROW_H = 80
TOP_PAD = 140
BOTTOM_PAD = 28
CARD_W = 640

# Keep the last dialog and its ListItems alive until the next menu opens, so
# nothing the closing animation still renders is freed from this thread.
_KEEP = []

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_CONTEXT_MENU = 117


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] CARD_MENU_R119 %s" % msg, level)
    except Exception:
        pass


class _CardMenu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.options = list(kwargs.get("options") or [])
        self.result = -1
        self._items = []

    def onInit(self):
        try:
            n = max(1, len(self.options))
            h = TOP_PAD + n * ROW_H + BOTTOM_PAD - (ROW_H - 72)
            top = int((1080 - h) / 2)
            self.getControl(GROUP_ID).setPosition(int((1920 - CARD_W) / 2), top)
            self.getControl(CARD_ID).setHeight(h)
            self.getControl(RIM_ID).setHeight(h + 4)
            lst = self.getControl(LIST_ID)
            lst.reset()
            items = []
            for label, icon in self.options:
                li = xbmcgui.ListItem(label=label)
                li.setProperty("icon", icon or "")
                items.append(li)
            self._items = items
            lst.addItems(items)
            lst.setHeight(n * ROW_H)
            self.setFocusId(LIST_ID)
        except Exception:
            _log("INIT_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)

    def onClick(self, control_id):
        if control_id == LIST_ID:
            try:
                self.result = int(self.getControl(LIST_ID).getSelectedPosition())
            except Exception:
                self.result = -1
            self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.result = -1
            self.close()


def open_card_menu(title, sub, options):
    win = xbmcgui.Window(10000)
    dlg = None
    try:
        win.setProperty("PlexKM.CardMenu.Title", str(title or ""))
        win.setProperty("PlexKM.CardMenu.Sub", str(sub or ""))
        dlg = _CardMenu(
            "plexkm_card_menu_r119.xml",
            xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
            "Default", "1080i",
            options=options,
        )
        dlg.doModal()
        return int(dlg.result)
    except Exception:
        _log("OPEN_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
        return -1
    finally:
        _KEEP[:] = [dlg] if dlg is not None else []
        dlg = None
        win.clearProperty("PlexKM.CardMenu.Title")
        win.clearProperty("PlexKM.CardMenu.Sub")
