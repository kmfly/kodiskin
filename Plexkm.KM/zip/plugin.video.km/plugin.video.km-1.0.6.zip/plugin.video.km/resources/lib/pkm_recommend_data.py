# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import random


def recommend_row_poster_value(row):
    """Return the poster/thumb value used by section recommendation rows."""
    try:
        t = tuple(row or ())
        if len(t) > 12:
            return str(t[12] or "").strip()
    except Exception:
        pass
    return ""


def recommend_row_has_poster(row):
    """Do not render empty poster cells in recommendation rows."""
    return bool(recommend_row_poster_value(row))


def filter_recommend_rows_with_posters(rows, row_title="", section_id="", source="", speed_log=None, short_log_value=None):
    """Remove rows with no poster art without performing network validation.

    v680: kept in a dedicated data helper so recommendation row filtering can be
    shared without adding UI-flow/focus/navigation logic to WindowXML code.
    The v679 cache-only behavior is preserved: rows with non-empty poster/thumb
    values are kept, and no live HTTP HEAD check is performed here.
    """
    try:
        kept = []
        skipped = 0
        sample = []
        for r in rows or []:
            thumb = recommend_row_poster_value(r)
            if thumb:
                kept.append(r)
            else:
                skipped += 1
                if len(sample) < 5:
                    try:
                        t = tuple(r or ())
                        rk = str(t[0] if len(t) > 0 else "")
                        title = str(t[4] if len(t) > 4 else "")
                        if short_log_value:
                            title = short_log_value(title, 60)
                        else:
                            title = title[:60]
                        sample.append("%s:%s" % (rk, title))
                    except Exception:
                        pass
        if skipped and speed_log:
            try:
                speed_log(
                    "recommend_poster_filter",
                    section=section_id,
                    title=row_title,
                    source=source,
                    kept=len(kept),
                    skipped=skipped,
                    stale=0,
                    checked=0,
                    sample=" | ".join(sample),
                )
            except Exception:
                pass
        return kept
    except Exception:
        return rows or []


def section_rows_grouped(rows_cache):
    grouped = []
    current = []
    current_id = None
    try:
        for entry in rows_cache or []:
            if not isinstance(entry, dict):
                continue
            rid = entry.get("row_id") or entry.get("row_title") or "row"
            if current and rid != current_id:
                grouped.append(current)
                current = []
            current_id = rid
            current.append(entry)
        if current:
            grouped.append(current)
    except Exception:
        return []
    return grouped


def randomize_cached_movie_extra_rows(rows_cache, start_row_index=3, reason="cache_restore", speed_log=None):
    """Shuffle cached movie extra rows on every restore.

    Core recommendation rows before start_row_index remain stable; lower movie
    extra rows are reshuffled so cached recommendations do not look fixed.
    """
    try:
        groups = section_rows_grouped(rows_cache)
        if not groups:
            return list(rows_cache or [])
        out = []
        shuffled_rows = 0
        shuffled_items = 0
        rng = random.SystemRandom()
        for row_idx, entries in enumerate(groups):
            entries = [dict(e) for e in (entries or []) if isinstance(e, dict)]
            if row_idx >= int(start_row_index or 0):
                try:
                    rng.shuffle(entries)
                except Exception:
                    random.shuffle(entries)
                shuffled_rows += 1
                shuffled_items += len(entries)
            for item_idx, entry in enumerate(entries):
                entry["row_index"] = item_idx
                entry["row_first"] = (item_idx == 0)
                out.append(entry)
        if speed_log:
            try:
                speed_log("movie_extra_cache_randomized", reason=reason, rows=shuffled_rows, items=shuffled_items, start_row_index=start_row_index)
            except Exception:
                pass
        return out
    except Exception:
        return list(rows_cache or [])


def movie_extra_unique_key(row):
    try:
        t = tuple(row or ())
        title = str(t[4] if len(t) > 4 else "").strip().lower()
        year = str(t[7] if len(t) > 7 else "").strip()
        if title:
            return "title:%s:%s" % (title, year)
        return "key:%s" % str(t[0] if t else "")
    except Exception:
        return ""
