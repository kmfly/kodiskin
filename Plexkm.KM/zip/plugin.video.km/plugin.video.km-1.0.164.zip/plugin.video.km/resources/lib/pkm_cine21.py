# -*- coding: utf-8 -*-
"""Cine21 rating cache helpers for Plex KM.

Data-only helpers. This module never controls UI focus/navigation.

v2377R1: Kodi runtime Cine21 HTTP access is hard-disabled. Ratings and matches
come only from the service-managed Cine21 Master DB and local SQLite matching.
The old web helpers remain only for compatibility with legacy call sites, but
they fail closed before opening any HTTP connection.
"""
from __future__ import absolute_import, unicode_literals

import json
import re
import time
import traceback

try:
    from html import unescape
except Exception:
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except Exception:
        def unescape(value):
            return value

try:
    import xbmc
except Exception:  # allows import outside Kodi for py_compile
    xbmc = None
try:
    import xbmcgui
except Exception:
    xbmcgui = None

_TMDB_FROM_SJVA_RE = re.compile(r"sjva_agent://MT(\d+)", re.IGNORECASE)

# v926: constants were missing in v925 after schema/match refactor.
# Missing _CINE21_BASE_URL caused detail fetch failures; missing search regex/url
# caused movie_id matching to fall into MATCH_ERROR before any rating fetch.
_CINE21_BASE_URL = "https://cine21.com/movie/info/?movie_id=%s"
_SEARCH_MOVIE_RE = re.compile(
    r"""<a[^>]+href=["'](?:https?://(?:www\.)?cine21\.com)?/movie/info/\?movie_id=([0-9]+)[^"']*["'][^>]*>(.*?)</a>""",
    re.IGNORECASE | re.DOTALL
)
_YEAR_RE = re.compile(r"((?:19|20)\d{2})")
_OPEN_YEAR_RE = re.compile(r"(?:개봉|제작|년도|연도)[^0-9]{0,12}((?:19|20)\d{2})")
_TITLE_NORM_RE = re.compile(r"[\W_]+", re.UNICODE)


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log("[plugin.video.km] [PKM_CINE21] %s" % message, level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass



# v2377R1: defense-in-depth.  The Kodi plugin must never crawl/search Cine21.
# Master DB collection is an external/server-side job.  Keep this hard guard
# independent of Home scheduling so a stale/legacy caller still cannot emit
# cine21.com traffic.

def _runtime_web_block_v2377r1(function_name):
    _log("CINE21_RUNTIME_WEB_HARD_BLOCK_V2377R1 function=%s network=0 source=ratings_master_only" % (function_name or "unknown"), xbmc.LOGWARNING if xbmc else None)
    return True

def extract_tmdb_id_from_plex_guid(guid):
    """Return TMDb candidate digits from an SJVA Plex guid."""
    try:
        text = str(guid or "")
    except Exception:
        return ""
    m = _TMDB_FROM_SJVA_RE.search(text)
    return m.group(1) if m else ""


def _raw_value(raw_json, key, default=""):
    try:
        data = json.loads(raw_json or "{}")
        value = data.get(key, default)
        return "" if value is None else str(value)
    except Exception:
        return default




def _raw_guid(raw_json):
    return _raw_value(raw_json, "guid", "")


def _raw_tmdb_id(raw_json):
    return extract_tmdb_id_from_plex_guid(_raw_guid(raw_json))


def _register_sql_functions(conn):
    """Register small SQLite UDFs for bulk seed from items.raw_json."""
    try:
        conn.create_function("pkm_cine21_guid", 1, _raw_guid)
    except Exception:
        pass
    try:
        conn.create_function("pkm_cine21_tmdb", 1, _raw_tmdb_id)
    except Exception:
        pass

def _table_columns(conn, table_name):
    """Return existing SQLite table columns as a set."""
    try:
        return set([str(row[1]) for row in conn.execute("PRAGMA table_info(%s)" % table_name).fetchall()])
    except Exception:
        return set()


def _ensure_column(conn, table_name, column_name, column_def):
    """Add a missing column to an existing table without rebuilding the DB."""
    try:
        cols = _table_columns(conn, table_name)
        if column_name not in cols:
            conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table_name, column_name, column_def))
            _log("schema_migrate_add_column table=%s column=%s" % (table_name, column_name))
            return 1
    except Exception:
        _log("schema_migrate_add_column_failed table=%s column=%s err=%s" % (
            table_name, column_name, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING if xbmc else None)
    return 0



def init_cine21_schema(conn):
    _register_sql_functions(conn)
    """Create/migrate Cine21 tables without breaking the existing imported DB.

    v924: cine21_ratings is the master Cine21 rating table keyed by movie_id.
    Per-Plex-item state must live in cine21_matches.  v923 incorrectly treated
    cine21_ratings as an item table and failed on real user DBs where it has no
    rating_key column.
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_ratings (
            movie_id TEXT PRIMARY KEY,
            title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            image TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_matches (
            rating_key TEXT PRIMARY KEY,
            cine21_movie_id TEXT,
            match_status TEXT,
            match_type TEXT,
            match_score REAL,
            pkm_quality_status TEXT,
            pkm_title TEXT,
            pkm_original_title TEXT,
            pkm_year TEXT,
            pkm_section_id TEXT,
            pkm_media_file TEXT,
            cine21_title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_match_summary (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        )
    """)
    migrated = 0
    for col, coldef in (
        ("movie_id", "TEXT"),
        ("title", "TEXT"),
        ("critic_rating", "REAL"),
        ("audience_rating", "REAL"),
        ("image", "TEXT"),
        ("updated_at", "TEXT"),
    ):
        migrated += _ensure_column(conn, "cine21_ratings", col, coldef)
    for col, coldef in (
        ("rating_key", "TEXT"),
        ("cine21_movie_id", "TEXT"),
        ("match_status", "TEXT"),
        ("match_type", "TEXT"),
        ("match_score", "REAL"),
        ("pkm_quality_status", "TEXT"),
        ("pkm_title", "TEXT"),
        ("pkm_original_title", "TEXT"),
        ("pkm_year", "TEXT"),
        ("pkm_section_id", "TEXT"),
        ("pkm_media_file", "TEXT"),
        ("cine21_title", "TEXT"),
        ("critic_rating", "REAL"),
        ("audience_rating", "REAL"),
        ("updated_at", "TEXT"),
    ):
        migrated += _ensure_column(conn, "cine21_matches", col, coldef)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_expert_reviews (
            rating_key TEXT,
            cine21_movie_id TEXT,
            sort_order INTEGER,
            critic_name TEXT,
            critic_score REAL,
            critic_comment TEXT,
            fetched_at INTEGER,
            PRIMARY KEY (rating_key, critic_name)
        )
    """)
    for col, coldef in (
        ("rating_key", "TEXT"),
        ("cine21_movie_id", "TEXT"),
        ("sort_order", "INTEGER"),
        ("critic_name", "TEXT"),
        ("critic_score", "REAL"),
        ("critic_comment", "TEXT"),
        ("fetched_at", "INTEGER"),
    ):
        migrated += _ensure_column(conn, "cine21_expert_reviews", col, coldef)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_ratings_movie_id ON cine21_ratings(movie_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_rating_key ON cine21_matches(rating_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_movie_id ON cine21_matches(cine21_movie_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_status ON cine21_matches(match_status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_critic ON cine21_matches(critic_rating)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_audience ON cine21_matches(audience_rating)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_expert_rating_key ON cine21_expert_reviews(rating_key)")
    conn.commit()
    try:
        rcols = ",".join(sorted(_table_columns(conn, "cine21_ratings")))
        mcols = ",".join(sorted(_table_columns(conn, "cine21_matches")))
        _log("schema_ready_manual_v924 migrated=%s ratings_cols=%s match_cols=%s" % (migrated, rcols, mcols))
    except Exception:
        _log("schema_ready_manual_v924 migrated=%s" % migrated)


def build_pending_seed_rows(conn, limit=0):
    """Register PKM movie rows missing from cine21_matches.

    v925: use NOT EXISTS instead of NOT IN.  If cine21_matches contains any
    NULL rating_key row, SQL NOT IN returns no rows at all, so existing movies
    such as 9479791/마이클 never become Cine21 candidates.  This is the actual
    first gate before any Cine21 web crawl can happen.
    """
    init_cine21_schema(conn)
    now = int(time.time())
    limit = int(limit or 0)
    before = int(getattr(conn, "total_changes", 0) or 0)
    try:
        try:
            probe = conn.execute("""
                SELECT
                    (SELECT COUNT(*) FROM items WHERE plex_type='movie') AS movie_count,
                    (SELECT COUNT(*) FROM items i WHERE i.plex_type='movie' AND NOT EXISTS (
                        SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key
                    )) AS missing_count,
                    (SELECT COUNT(*) FROM cine21_matches WHERE rating_key IS NULL OR TRIM(COALESCE(rating_key,''))='') AS null_match_key_count,
                    (SELECT COUNT(*) FROM items WHERE rating_key='9479791') AS michael_item_count,
                    (SELECT COUNT(*) FROM cine21_matches WHERE rating_key='9479791') AS michael_match_count
            """).fetchone()
            _log("build_pending_seed_probe movie_count=%s missing_count=%s null_match_key_count=%s michael_item=%s michael_match=%s limit=%s" % (
                probe[0], probe[1], probe[2], probe[3], probe[4], limit
            ))
        except Exception:
            pass
        if limit > 0:
            conn.execute("""
                INSERT OR IGNORE INTO cine21_matches (
                    rating_key, cine21_movie_id, match_status, match_type, match_score,
                    pkm_quality_status, pkm_title, pkm_original_title, pkm_year,
                    pkm_section_id, pkm_media_file, cine21_title, critic_rating,
                    audience_rating, updated_at
                )
                SELECT rating_key, '', 'PENDING_CINE21', '', 0,
                       '', title, original_title, CAST(year AS TEXT), section_id,
                       '', '', NULL, NULL, ?
                FROM (
                    SELECT rating_key, section_id, title, original_title, year, added_at, synced_at
                    FROM items i
                    WHERE i.plex_type='movie'
                      AND NOT EXISTS (SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key)
                    ORDER BY COALESCE(i.added_at,0) DESC, COALESCE(i.synced_at,0) DESC, i.rating_key DESC
                    LIMIT ?
                )
            """, (now, limit))
        else:
            conn.execute("""
                INSERT OR IGNORE INTO cine21_matches (
                    rating_key, cine21_movie_id, match_status, match_type, match_score,
                    pkm_quality_status, pkm_title, pkm_original_title, pkm_year,
                    pkm_section_id, pkm_media_file, cine21_title, critic_rating,
                    audience_rating, updated_at
                )
                SELECT i.rating_key, '', 'PENDING_CINE21', '', 0,
                       '', i.title, i.original_title, CAST(i.year AS TEXT), i.section_id,
                       '', '', NULL, NULL, ?
                FROM items i
                WHERE i.plex_type='movie'
                  AND NOT EXISTS (SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key)
            """, (now,))
        conn.commit()
        count = max(0, int(getattr(conn, "total_changes", 0) or 0) - before)
        try:
            rr = conn.execute("""
                SELECT i.rating_key, i.title, i.year,
                       COALESCE(cm.cine21_movie_id,''), COALESCE(cm.match_status,''),
                       COALESCE(cm.critic_rating,''), COALESCE(cm.audience_rating,'')
                FROM items i
                LEFT JOIN cine21_matches cm ON cm.rating_key=i.rating_key
                WHERE i.rating_key='9479791'
            """).fetchone()
            if rr:
                _log("build_pending_seed_probe_after rating_key=%s title=%s year=%s movie_id=%s status=%s critic=%s audience=%s inserted=%s" % (
                    rr[0], rr[1], rr[2], rr[3], rr[4], rr[5], rr[6], count
                ))
        except Exception:
            pass
        _log("build_pending_seed_rows_matches count=%s limit=%s" % (count, limit))
        return count
    except Exception:
        _log("build_pending_seed_rows_failed %s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
        return 0

def count_total_movie_items(conn):
    """Count movie rows in the PKM item cache.  Cine21 is movie-only."""
    row = conn.execute("""
        SELECT COUNT(*)
        FROM items
        WHERE plex_type='movie'
    """).fetchone()
    try:
        return int(row[0] or 0)
    except Exception:
        return 0



def count_ok_ratings(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE match_status='MATCHED' AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_seed_candidates(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM items i
        WHERE i.plex_type='movie'
          AND NOT EXISTS (SELECT 1 FROM cine21_matches c WHERE c.rating_key=i.rating_key)
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_match_candidates_without_movie_id(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE COALESCE(cine21_movie_id, '')=''
          AND COALESCE(match_status, '') IN ('', 'PENDING_CINE21', 'NEED_MOVIE_ID', 'NO_MATCH_NOT_IN_CINE21', 'MATCH_ERROR')
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_fetch_candidates_with_movie_id(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE COALESCE(cine21_movie_id, '') <> ''
          AND (COALESCE(match_status, '') IN ('', 'NEED_FETCH', 'MATCH_ERROR')
               OR (match_status='MATCHED' AND critic_rating IS NULL AND audience_rating IS NULL))
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def get_status_counts(conn):
    init_cine21_schema(conn)
    rows = conn.execute("""
        SELECT COALESCE(match_status, ''), COUNT(*)
        FROM cine21_matches
        GROUP BY COALESCE(match_status, '')
        ORDER BY COUNT(*) DESC
    """).fetchall()
    return [(str(status or ""), int(count or 0)) for status, count in rows]

def match_cine21_movie_ids(conn, limit=20, timeout=8, progress_cb=None, total=None, base_done=0, abort_cb=None):
    _runtime_web_block_v2377r1("match_cine21_movie_ids")
    return {"checked": 0, "matched": 0, "no_match": 0, "ambiguous": 0, "error": 0, "blocked_v2377r1": 1}


_FLOAT_RE = re.compile(r"([0-9]+(?:\.[0-9]+)?)")
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t\r\n]+")


def fetch_and_save_rating(conn, rating_key, cine21_movie_id, timeout=8):
    _runtime_web_block_v2377r1("fetch_and_save_rating")
    raise RuntimeError("Cine21 runtime web disabled v2377R1")


def fetch_cine21_ratings_for_candidates(conn, limit=5, timeout=6, progress_cb=None, total=None, base_done=0, abort_cb=None):
    _runtime_web_block_v2377r1("fetch_cine21_ratings_for_candidates")
    return {"candidates": 0, "fetched_ok": 0, "fetched_error": 0, "blocked_v2377r1": 1}

