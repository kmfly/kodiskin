# -*- coding: utf-8 -*-
"""Movie recommendation data helpers for Plex KM.

This module is data-only: SQL fragments, country-bucket lookup, and section-id
helpers used by default.py recommendation index queries.  It does not touch
Kodi WindowXML focus, navigation, playback, or UI flow.
"""
from __future__ import absolute_import, unicode_literals


def recommend_row_columns_sql(prefix="i"):
    p = (str(prefix or "").strip() + ".") if str(prefix or "").strip() else ""
    # Keep this tuple shape aligned with the pre-split default.py helper and
    # the DB-backed recommendation item conversion path.  Do not add columns
    # that are not present in the items table, such as view_offset.
    return ", ".join([
        p + "rating_key",
        p + "section_id",
        p + "plex_type",
        "'' AS kodi_type",
        p + "title",
        "'' AS original_title",
        "COALESCE(" + p + "sort_title," + p + "title) AS sort_title",
        p + "year",
        p + "summary",
        p + "duration",
        p + "added_at",
        p + "updated_at",
        p + "thumb",
        p + "art",
        p + "media_file",
        p + "part_key",
        p + "view_count",
        p + "last_viewed_at",
        p + "show_title",
        p + "season",
        p + "episode",
        p + "parent_rating_key",
        p + "grandparent_rating_key",
    ])


def recommend_exclude_clause(alias, exclude_keys, args):
    keys = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    if not keys:
        return ""
    ph = ",".join(["?"] * len(keys))
    args.extend(keys)
    return " AND %s.rating_key NOT IN (%s)" % ((alias or "i"), ph)


def movie_section_ids_from_db(conn):
    try:
        rows = conn.execute(
            "SELECT DISTINCT section_id FROM items WHERE plex_type='movie' ORDER BY CAST(section_id AS INTEGER), section_id"
        ).fetchall()
        return [str(r[0]) for r in rows if str(r[0] or "").strip()]
    except Exception:
        return []


def section_country_bucket_from_db(conn, section_id, plex_type, min_ratio=0.60):
    """Return dominant coarse country bucket for a section: 한국 / 외국 / ''.

    Uses item_countries only; no library-title or section-name matching.
    """
    sid = str(section_id or "").strip()
    ptype = str(plex_type or "").strip()
    if not sid or not ptype:
        return ""
    try:
        rows = conn.execute("""
            SELECT c.country, COUNT(DISTINCT c.rating_key) AS cnt
            FROM item_countries c
            JOIN items i ON i.rating_key=c.rating_key
            WHERE c.section_id=?
              AND i.section_id=?
              AND i.plex_type=?
              AND c.country IN ('한국','외국')
            GROUP BY c.country
        """, (sid, sid, ptype)).fetchall()
    except Exception:
        rows = []
    counts, total = {}, 0
    for row in rows or []:
        try:
            country = str(row[0] or "").strip()
            cnt = int(row[1] or 0)
            if country in ("한국", "외국") and cnt > 0:
                counts[country] = counts.get(country, 0) + cnt
                total += cnt
        except Exception:
            continue
    if total <= 0:
        return ""
    bucket, cnt = max(counts.items(), key=lambda kv: kv[1])
    try:
        if float(cnt) / float(total) >= float(min_ratio or 0.60):
            return bucket
    except Exception:
        pass
    return ""


def recommend_rows_thumb_stats(rows):
    total = len(rows or [])
    thumb_ready = 0
    art_ready = 0
    try:
        for r in rows or []:
            t = tuple(r)
            if len(t) > 12 and str(t[12] or "").strip():
                thumb_ready += 1
            if len(t) > 13 and str(t[13] or "").strip():
                art_ready += 1
    except Exception:
        pass
    return total, thumb_ready, art_ready

def recommend_widget_result_log_message(kind, section_id, rows, want, elapsed, source="db_local", result="ok", extra=""):
    """Build the stable recommendation-widget result log message.

    Data-only helper: computes row/thumb/art counts and returns the exact log
    message string used by default.py.  It does not call Kodi APIs.
    """
    total, thumb_ready, art_ready = recommend_rows_thumb_stats(rows)
    try:
        return "[PKM_INDEX] recommend_widget_result kind=%s section=%s rows=%d want=%d thumb_ready=%d art_ready=%d metadata_fetch=0 source=%s ms=%d result=%s%s" % (
            kind, section_id, total, int(want or 0), thumb_ready, art_ready, source, int(elapsed or 0), result, (" " + extra) if extra else ""
        )
    except Exception:
        return "[PKM_INDEX] recommend_widget_result kind=%s section=%s rows=%d want=%s thumb_ready=%d art_ready=%d metadata_fetch=0 source=%s ms=%s result=%s%s" % (
            kind, section_id, total, want, thumb_ready, art_ready, source, elapsed, result, (" " + extra) if extra else ""
        )



def db_row_person_name(rows):
    """Return recommendation person-name appended after the stable wall row tuple.

    Data-only helper used by the WindowXML home window when naming movie
    director/actor extra rows.  It does not touch Kodi UI state.
    """
    try:
        if rows and len(tuple(rows[0])) > 23:
            return str(tuple(rows[0])[-1] or "").strip()
    except Exception:
        pass
    return ""


def db_row_art_stats(rows):
    """Return (total, thumb_ready, art_ready) for DB-backed wall rows."""
    return recommend_rows_thumb_stats(rows)


def clean_float(value):
    try:
        txt = str(value if value is not None else "").strip()
        if not txt:
            return None
        return float(txt)
    except Exception:
        return None


def movie_extra_rating_values(node):
    """Return (audienceRating, rating, userRating, best_score) from a Plex node.

    Data-only helper.  Score priority is unchanged from the pre-split window
    helper: audienceRating -> rating -> userRating.
    """
    try:
        get_value = getattr(node, "get", None)
        audience = clean_float(get_value("audienceRating") if get_value else None)
        rating = clean_float(get_value("rating") if get_value else None)
        user = clean_float(get_value("userRating") if get_value else None)
        score = audience if audience is not None else (rating if rating is not None else user)
        return audience, rating, user, score
    except Exception:
        return None, None, None, None


def movie_extra_score_threshold():
    """Current movie extra recommendation score threshold.

    Kept as a helper so the value has one data-only owner while the WindowXML
    class keeps its existing method wrapper.
    """
    return 6.5


# ---------------------------------------------------------------------------
# R143: Korean-first recommendation rows (Netflix-style classification).
# Pure SQL helpers; callers pass an open sqlite3 connection.
# ---------------------------------------------------------------------------
import random as _random_r143

GEM_MIN_SCORE_R143 = 7.5
# Genres that are too broad (or confusable with TV dramas) to make a row title.
_GENRE_ROW_SKIP_R143 = ("드라마", "음악", "TV 영화", "단편", "다큐멘터리", "뉴스", "리얼리티", "토크쇼")


def _unwatched_sql_r143(alias="i"):
    return " AND COALESCE(%s.view_count,0)=0" % alias


def _fetch_r143(conn, sql, args):
    try:
        return conn.execute(sql, args).fetchall()
    except Exception:
        return []


def _taste_rows_r143(conn, sid, country, want, excluded, score_min=None, genre=None,
                     year_lo=None, year_hi=None, order="RANDOM()", pool=None, unwatched=True):
    """One DB pass for a taste row; country is '한국', '외국' or None (any)."""
    cols = recommend_row_columns_sql("i")
    args = []
    join = ""
    if country:
        join = " JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=? "
        args.append(country)
    where = " WHERE i.section_id=? AND i.plex_type='movie' "
    args.append(str(sid))
    if unwatched:
        where += _unwatched_sql_r143("i")
    if score_min is not None:
        where += " AND COALESCE(r.score,-1) >= ?"
        args.append(float(score_min))
    if genre:
        where += " AND EXISTS (SELECT 1 FROM item_genres ig WHERE ig.rating_key=i.rating_key AND ig.genre=?)"
        args.append(str(genre))
    if year_lo is not None:
        where += " AND COALESCE(i.year,0) BETWEEN ? AND ?"
        args.extend([int(year_lo), int(year_hi)])
    where += recommend_exclude_clause("i", excluded, args)
    sql = ("SELECT %s FROM items i %s LEFT JOIN item_ratings r ON r.rating_key=i.rating_key %s "
           "GROUP BY i.rating_key ORDER BY %s LIMIT ?") % (cols, join, where, order)
    args.append(int(pool or want))
    return _fetch_r143(conn, sql, args)


def _fill_r143(conn, sid, country, want, excluded, score_min, **kw):
    """Strict (unwatched + score) first, then relax score, then allow watched."""
    rows = _taste_rows_r143(conn, sid, country, want, excluded, score_min=score_min, **kw)
    if len(rows) < want and score_min is not None:
        rows = _taste_rows_r143(conn, sid, country, want, excluded, score_min=None, **kw)
    if len(rows) < want:
        kw2 = dict(kw)
        kw2["unwatched"] = False
        rows = _taste_rows_r143(conn, sid, country, want, excluded, score_min=None, **kw2)
    return rows


def query_taste_rows_r143(conn, sid, kind, want=12, exclude_keys=None, min_score=6.5):
    """Return rows for kind in: korean, foreign, korean_top, gems."""
    want = max(10, int(want or 10))
    excluded = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    if kind == "korean":
        return _fill_r143(conn, sid, "한국", want, excluded, min_score)
    if kind == "foreign":
        return _fill_r143(conn, sid, "외국", want, excluded, min_score)
    if kind == "korean_top":
        rows = _taste_rows_r143(conn, sid, "한국", want, excluded, score_min=min_score,
                                order="COALESCE(r.score,0) DESC, i.year DESC", pool=want * 4)
        if len(rows) < want:
            return _fill_r143(conn, sid, "한국", want, excluded, None)
        rows = list(rows)
        _random_r143.shuffle(rows)
        return rows[:want]
    if kind == "gems":
        gem_min = max(float(min_score or 0), GEM_MIN_SCORE_R143)
        rows = _taste_rows_r143(conn, sid, None, want, excluded, score_min=gem_min)
        if len(rows) < want:
            rows = _taste_rows_r143(conn, sid, None, want, excluded, score_min=float(min_score or 0))
        return rows
    return []


def watched_genre_weights_r143(conn, sid):
    """genre -> number of watched movies (the user's actual taste)."""
    out = {}
    for g, n in _fetch_r143(conn, """
            SELECT ig.genre, COUNT(DISTINCT i.rating_key)
            FROM items i JOIN item_genres ig ON ig.rating_key=i.rating_key
            WHERE i.section_id=? AND i.plex_type='movie' AND COALESCE(i.view_count,0)>0
            GROUP BY ig.genre""", (str(sid),)):
        out[str(g)] = int(n or 0)
    return out


def query_korean_genre_rows_r143(conn, sid, want=12, exclude_keys=None, min_score=6.5, max_rows=2):
    """[(label, rows)] -- up to max_rows '한국 <장르>' rows, weighted by watch history."""
    want = max(10, int(want or 10))
    excluded = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    cands = _fetch_r143(conn, """
            SELECT ig.genre, COUNT(DISTINCT i.rating_key) AS n
            FROM items i
            JOIN item_countries c ON c.rating_key=i.rating_key AND c.country='한국'
            JOIN item_genres ig ON ig.rating_key=i.rating_key
            WHERE i.section_id=? AND i.plex_type='movie' AND COALESCE(i.view_count,0)=0
            GROUP BY ig.genre HAVING n>=?""", (str(sid), want))
    cands = [(str(g), int(n)) for g, n in cands if str(g) and str(g) not in _GENRE_ROW_SKIP_R143]
    if not cands:
        return []
    weights = watched_genre_weights_r143(conn, sid)
    out = []
    pool = list(cands)
    used = set(str(x) for x in excluded)
    while pool and len(out) < int(max_rows):
        w = [1 + weights.get(g, 0) for g, _n in pool]
        pick = _random_r143.choices(range(len(pool)), weights=w, k=1)[0]
        genre = pool.pop(pick)[0]
        rows = _taste_rows_r143(conn, sid, "한국", want, list(used), score_min=min_score, genre=genre)
        if len(rows) < want:
            rows = _taste_rows_r143(conn, sid, "한국", want, list(used), score_min=None, genre=genre)
        if len(rows) < min(10, want):
            continue
        for r in rows:
            used.add(str(r[0]))
        out.append(("한국 %s" % genre, rows))
    return out


def query_korean_decade_row_r143(conn, sid, want=12, exclude_keys=None, min_score=6.5):
    """('2000년대 한국영화', rows) for a random decade that can fill a row, or None."""
    want = max(10, int(want or 10))
    excluded = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    decs = _fetch_r143(conn, """
            SELECT (i.year/10)*10 AS dec, COUNT(DISTINCT i.rating_key) AS n
            FROM items i JOIN item_countries c ON c.rating_key=i.rating_key AND c.country='한국'
            WHERE i.section_id=? AND i.plex_type='movie' AND COALESCE(i.view_count,0)=0 AND COALESCE(i.year,0)>=1950
            GROUP BY dec HAVING n>=?""", (str(sid), want))
    decs = [int(d) for d, _n in decs if d]
    if not decs:
        return None
    dec = _random_r143.choice(decs)
    rows = _taste_rows_r143(conn, sid, "한국", want, excluded, score_min=min_score, year_lo=dec, year_hi=dec + 9)
    if len(rows) < want:
        rows = _taste_rows_r143(conn, sid, "한국", want, excluded, score_min=None, year_lo=dec, year_hi=dec + 9)
    if len(rows) < min(10, want):
        return None
    return ("%d년대 한국영화" % dec, rows)


def query_because_watched_row_r143(conn, sid, want=12, exclude_keys=None, min_score=6.5):
    """('<제목> 감독작 시청하셨다면'-style row) -> ('<seed> 재밌게 보셨다면', rows) or None.

    Seed = one of the most recently watched movies. Candidates are unwatched movies that share
    genres (and director/country) with the seed, with a score at least min_score."""
    want = max(10, int(want or 10))
    excluded = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    seeds = _fetch_r143(conn, """
            SELECT rating_key, title FROM items
            WHERE section_id=? AND plex_type='movie' AND COALESCE(view_count,0)>0 AND COALESCE(title,'')<>''
            ORDER BY COALESCE(last_viewed_at,0) DESC LIMIT 8""", (str(sid),))
    seeds = list(seeds)
    _random_r143.shuffle(seeds)
    cols = recommend_row_columns_sql("i")
    for seed_key, seed_title in seeds:
        genres = [g for (g,) in _fetch_r143(conn, "SELECT genre FROM item_genres WHERE rating_key=?", (str(seed_key),))
                  if g and g not in _GENRE_ROW_SKIP_R143]
        if not genres:
            continue
        gph = ",".join("?" * len(genres))
        for smin in (float(min_score or 0), None):
            args = [str(seed_key), str(seed_key)] + genres + [str(sid)]
            where = (" WHERE i.section_id=? AND i.plex_type='movie' AND COALESCE(i.view_count,0)=0 "
                     " AND i.rating_key<>? ")
            args = genres + [str(seed_key), str(sid), str(seed_key)]
            if smin is not None:
                where += " AND COALESCE(r.score,-1) >= ?"
                args.append(smin)
            where += recommend_exclude_clause("i", excluded, args)
            sql = ("SELECT %s FROM items i "
                   "JOIN (SELECT rating_key, COUNT(*) AS shared FROM item_genres WHERE genre IN (%s) GROUP BY rating_key) sg "
                   "ON sg.rating_key=i.rating_key "
                   "LEFT JOIN item_ratings r ON r.rating_key=i.rating_key "
                   "LEFT JOIN item_countries sc ON sc.rating_key=i.rating_key AND sc.country IN "
                   "(SELECT country FROM item_countries WHERE rating_key=?) "
                   "%s GROUP BY i.rating_key "
                   "ORDER BY sg.shared DESC, (sc.country IS NOT NULL) DESC, RANDOM() LIMIT ?") % (cols, gph, where)
            # arg order: genres (IN), seed (country subselect), then WHERE args
            args2 = genres + [str(seed_key), str(sid), str(seed_key)]
            if smin is not None:
                args2.append(smin)
            args2 = args2[:len(genres) + 1] + args2[len(genres) + 1:]
            tail = []
            recommend_exclude_clause("i", excluded, tail)
            args2 = args2 + tail + [want * 3]
            rows = _fetch_r143(conn, sql, args2)
            if len(rows) >= min(10, want):
                rows = list(rows)[:want]
                return ("%s 재밌게 보셨다면" % seed_title, rows)
    return None
