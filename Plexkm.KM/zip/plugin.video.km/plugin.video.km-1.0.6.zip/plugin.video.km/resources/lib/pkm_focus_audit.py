# -*- coding: utf-8 -*-
"""Low-noise, window-scoped focus/action diagnostics for PKM v1961.

The v1956 tracer queried a single global list of control ids against every
WindowXML/Dialog instance. Kodi logs "Non-Existent Control" before Python can
catch the exception, so that approach polluted logs and could obscure the real
focus transition.  v1961 only queries controls declared for the current class.
Unknown classes are still traced, but only their focus id and active window are
recorded.
"""
import json
import threading
import time
import weakref

import xbmc
import xbmcgui

PREFIX = "[plugin.video.km][FOCUS_TRACE_V1961]"

# Only ids that actually belong to each WindowXML/Dialog class are inspected.
# Keep this conservative: missing an optional diagnostic field is safer than
# asking Kodi for a control that does not belong to the window.
CLASS_CONTROLS = {
    "PlexKMHomeWindow": (
        9000, 9001, 5001, 5002, 5003, 5004, 5005, 5006, 5007, 5008, 5009,
        5711, 5712, 5713, 5721, 5722, 5724, 5725, 5726,
        6100, 6110, 6210, 6220, 6310, 6320, 6330,
        8410, 8610, 9410, 9420, 9430, 9440,
    ),
    "PlexKMPlaybackLoadingWindow": (),
    "PlexKMHomeExitConfirmDialog": (300, 301),
    "PlexKMWallWindow": (50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60),
    "PlexKMSearchWindow": (100, 200, 300, 400, 500),
    "PKMProgressDialog": (100, 200, 201, 300),
    "PKMSyncProgressDialog": (100, 200, 201, 300),
    "PKMTokenImportDialog": (100, 200, 201, 202, 203, 300, 301),
    "PKMSubtitleSelectDialog": (100, 200, 300, 400, 500, 600),
    "PKMAudioSelectDialog": (100, 200, 300, 400, 500, 600),
    "PKMVideoSelectDialog": (100, 200, 300, 400, 500, 600),
}

PROPS = (
    "PlexKM.Info.InlineActive", "PlexKM.Info.IsTV", "PlexKM.Info.TVMode", "PlexKM.Info.Type",
    "PlexKM.LibraryMode", "PlexKM.Window.IsHome", "PlexKM.Search.Active",
    "PlexKM.Playback.ReturnInline.Pending", "PlexKM.Playback.Active",
    "PlexKM.Sync.Active", "PlexKM.Focus.MenuReadyV1954",
)


def _safe_focus(win):
    if win is None:
        return -1
    try:
        return int(win.getFocusId())
    except Exception:
        return -1


def _safe_selected(win, cid):
    """Read list position only for an id known to belong to this window."""
    try:
        control = win.getControl(int(cid))
    except Exception:
        return -1, -1
    try:
        pos = int(control.getSelectedPosition())
    except Exception:
        pos = -1
    try:
        size = int(control.size())
    except Exception:
        size = -1
    return pos, size


def _visible(cid):
    try:
        return bool(xbmc.getCondVisibility("Control.IsVisible(%d)" % int(cid)))
    except Exception:
        return False


def _enabled(cid):
    try:
        return bool(xbmc.getCondVisibility("Control.IsEnabled(%d)" % int(cid)))
    except Exception:
        return False


def _props():
    out = {}
    try:
        window = xbmcgui.Window(10000)
        for key in PROPS:
            value = window.getProperty(key)
            if value:
                out[key] = value
    except Exception:
        pass
    return out


def _class_name(win, extra):
    supplied = extra.get("class_name") or extra.get("tag")
    if supplied:
        return str(supplied)
    try:
        return win.__class__.__name__ if win is not None else "Global"
    except Exception:
        return "Unknown"


def _controls_for(win, extra):
    name = _class_name(win, extra)
    # Exact class first. For subclasses/legacy names, use conservative tokens.
    if name in CLASS_CONTROLS:
        return CLASS_CONTROLS[name]
    lower = name.lower()
    if "exit" in lower and "confirm" in lower:
        return (300, 301)
    if "homewindow" in lower:
        return CLASS_CONTROLS["PlexKMHomeWindow"]
    if "search" in lower:
        return CLASS_CONTROLS["PlexKMSearchWindow"]
    # Unknown dialogs: never probe arbitrary ids.
    return ()


def audit_event(win, event, **extra):
    try:
        focus = _safe_focus(win)
        try:
            active = int(xbmcgui.getCurrentWindowId())
        except Exception:
            active = -1

        controls = {}
        known_ids = _controls_for(win, extra)
        for cid in known_ids:
            visible = _visible(cid)
            if cid != focus and not visible:
                continue
            pos, size = _safe_selected(win, cid)
            controls[str(cid)] = {
                "v": int(visible),
                "e": int(_enabled(cid)),
                "p": pos,
                "n": size,
            }

        payload = {
            "event": str(event),
            "focus": focus,
            "active_window": active,
            "window_class": _class_name(win, extra),
            "controls": controls,
            "props": _props(),
        }
        payload.update(extra)
        xbmc.log(PREFIX + " " + json.dumps(payload, ensure_ascii=False, sort_keys=True), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(PREFIX + " audit_error event=%s error=%s" % (event, exc), xbmc.LOGERROR)


_monitors = {}


def start_focus_monitor(win, tag):
    """Continuous focus polling removed.

    The diagnostic worker survived after modal dialogs had closed and kept the
    owning default.py interpreter alive during Kodi shutdown. One-shot
    audit_event() calls remain available, but no background monitor thread is
    created.
    """
    return


def stop_focus_monitor(win, tag=""):
    return
