# -*- coding: utf-8 -*-
"""Plex HTTP/API helpers for plugin.video.km.

This module is intentionally independent from default.py.  Callers may pass an
env dict containing the already-bound ADDON/log objects, but the module never
imports default.py so Kodi script/plugin initialization order is not affected.
"""
from __future__ import absolute_import, unicode_literals

import xml.etree.ElementTree as ET
import time
import threading
import re

from urllib.parse import urlencode, quote, urlsplit
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"

_TRACE_COUNTS = {}
_PLEX_NOTICE_LAST = {}
_PLEX_LAST_OK_TS = 0

# v1937: short-lived GET response cache plus same-request in-flight coalescing.
# Cache raw immutable bytes only; every caller parses its own XML Element tree.
_REQUEST_LOCK_V1937 = threading.RLock()
_REQUEST_CACHE_V1937 = {}
_REQUEST_INFLIGHT_V1937 = {}
_REQUEST_CACHE_MAX_V1937 = 128


class _RequestFlightV1937(object):
    __slots__ = ("event", "data", "error", "started")

    def __init__(self):
        self.event = threading.Event()
        self.data = None
        self.error = None
        self.started = time.time()


def _request_cache_ttl_v1937(url, method="GET"):
    if str(method or "GET").upper() != "GET":
        return 0.0
    try:
        path = str(urlsplit(str(url or "")).path or "").rstrip("/")
    except Exception:
        path = ""
    if path == "/library/sections":
        return 5.0
    if path == "/library/onDeck":
        return 2.0
    if re.match(r"^/library/metadata/[^/]+$", path or ""):
        return 4.0
    return 0.0


def _request_cache_prune_locked_v1937(now):
    stale = [key for key, value in _REQUEST_CACHE_V1937.items() if float(value[0] or 0.0) <= now]
    for key in stale:
        _REQUEST_CACHE_V1937.pop(key, None)
    if len(_REQUEST_CACHE_V1937) > _REQUEST_CACHE_MAX_V1937:
        ordered = sorted(_REQUEST_CACHE_V1937.items(), key=lambda item: float(item[1][0] or 0.0), reverse=True)
        keep = dict(ordered[:_REQUEST_CACHE_MAX_V1937])
        _REQUEST_CACHE_V1937.clear()
        _REQUEST_CACHE_V1937.update(keep)


def _urlopen_bytes_coalesced_v1937(req, url, timeout, method="GET", env=None):
    """Run one GET per exact URL and share the immutable response bytes.

    Only /library/sections, /library/onDeck, and one-item metadata responses get
    a very short TTL. All other GETs are coalesced only while in flight.
    """
    method = str(method or "GET").upper()
    if method != "GET":
        with urlopen(req, timeout=timeout) as resp:
            return resp.read()

    key = "%s %s" % (method, str(url or ""))
    ttl = _request_cache_ttl_v1937(url, method=method)
    now = time.time()
    with _REQUEST_LOCK_V1937:
        _request_cache_prune_locked_v1937(now)
        cached = _REQUEST_CACHE_V1937.get(key)
        if cached and float(cached[0] or 0.0) > now:
            _trace(env, "request_cache_hit_v1937", "path=%s ttl_ms=%d" % (
                _short_path(urlsplit(str(url or "")).path), int(max(0.0, float(cached[0]) - now) * 1000)
            ), limit=30)
            return bytes(cached[1] or b"")
        flight = _REQUEST_INFLIGHT_V1937.get(key)
        if flight is None:
            flight = _RequestFlightV1937()
            _REQUEST_INFLIGHT_V1937[key] = flight
            owner = True
        else:
            owner = False

    if not owner:
        _trace(env, "request_coalesce_wait_v1937", "path=%s" % _short_path(urlsplit(str(url or "")).path), limit=30)
        if not flight.event.wait(max(0.5, float(timeout or 0.0) + 1.0)):
            raise RuntimeError("Plex coalesced request wait timeout")
        if flight.error is not None:
            raise flight.error
        return bytes(flight.data or b"")

    try:
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read()
        flight.data = bytes(data or b"")
        if ttl > 0.0:
            with _REQUEST_LOCK_V1937:
                _REQUEST_CACHE_V1937[key] = (time.time() + ttl, flight.data)
                _request_cache_prune_locked_v1937(time.time())
        _trace(env, "request_coalesce_owner_v1937", "path=%s bytes=%d ttl_ms=%d" % (
            _short_path(urlsplit(str(url or "")).path), len(flight.data), int(ttl * 1000)
        ), limit=30)
        return flight.data
    except Exception as exc:
        flight.error = exc
        raise
    finally:
        with _REQUEST_LOCK_V1937:
            _REQUEST_INFLIGHT_V1937.pop(key, None)
            flight.event.set()


def _now_ts():
    try:
        return int(time.time())
    except Exception:
        return 0


def _mark_plex_ok(env=None, path=""):
    """Remember that Plex was reachable and clear sticky offline notices."""
    global _PLEX_LAST_OK_TS
    try:
        _PLEX_LAST_OK_TS = _now_ts()
        _set_plex_offline_state(env, False, reason="plex_ok")
    except Exception:
        pass
    try:
        fn = env.get("pkm_notice_clear_if_title") if env else None
        if callable(fn):
            try:
                fn(["Plex 연결 실패"], force=True)
            except TypeError:
                fn(["Plex 연결 실패"])
    except Exception:
        pass


def _has_recent_plex_ok(window_sec=30):
    try:
        last = int(_PLEX_LAST_OK_TS or 0)
        now = _now_ts()
        return bool(last and now and now - last <= int(window_sec or 30))
    except Exception:
        return False


def _playback_active_v1931():
    """Do not convert a control-plane timeout into a global offline state while media is opening/playing."""
    try:
        if xbmc.getCondVisibility("Player.HasMedia") or xbmc.getCondVisibility("Player.HasVideo"):
            return True
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        for prop in (
            "PlexKM.Playback.OpeningActive",
            "PlexKM.Playback.NativeOpening.Pending",
            "PlexKM.Playback.NativeOpening",
            "PlexKM.MainPlaybackStarting",
            "PlexKM.SeekQuick.Committing",
        ):
            if win.getProperty(prop) == "1":
                return True
    except Exception:
        pass
    return False


def _optional_plex_path_v1931(path):
    """Metadata/art/timeline misses are not proof that the Plex server is offline."""
    try:
        text = str(path or "").split("?", 1)[0].rstrip("/").lower()
        return bool(
            text.startswith("/library/metadata/")
            or text.startswith("/photo/:/transcode")
            or text.startswith("/:/timeline")
            or text.endswith("/thumb")
            or text.endswith("/art")
        )
    except Exception:
        return False


def _disconnect_notice_suppress_reason_v1931(path, recent_ok_window=30):
    if _playback_active_v1931():
        return "playback_active_v1931"
    if _optional_plex_path_v1931(path):
        return "optional_request_v1931"
    if _has_recent_plex_ok(recent_ok_window):
        return "recent_success_v1931"
    return "non_authoritative_probe_v1931"


def _should_emit_plex_disconnect_notice(path, recent_ok_window=30):
    """Emit global offline state only from authoritative connectivity probes.

    A metadata/timeline timeout, especially while video is already playing, is
    not a Plex disconnect. Only /identity and /library/sections may establish
    offline state after the recent-success window has expired.
    """
    try:
        if _playback_active_v1931():
            return False
        if _optional_plex_path_v1931(path):
            return False
        if _has_recent_plex_ok(recent_ok_window):
            return False
        text = str(path or "").split("?", 1)[0].rstrip("/").lower()
        return text in ("/identity", "/library/sections")
    except Exception:
        return False


def _log_plex_notice_suppressed(env, path, error, reason="recent_ok"):
    try:
        _log(env, "PLEX_CONNECTION_NOTICE_SUPPRESS reason=%s path=%s error=%s last_ok_age_recent=%s" % (
            str(reason or ""), _short_path(path), str(error or ""), "1" if _has_recent_plex_ok(30) else "0"
        ), xbmc.LOGINFO)
    except Exception:
        pass


def _trace(env, key, msg, level=xbmc.LOGINFO, limit=5):
    """Small diagnostic logger for split-module verification.

    INFO level is intentional so the user can confirm module routing even when
    Kodi debug logging is disabled.  The per-key limit prevents request-heavy
    Home/Sync paths from flooding kodi.log.
    """
    try:
        count = int(_TRACE_COUNTS.get(key, 0))
        if count >= int(limit):
            return
        _TRACE_COUNTS[key] = count + 1
        suffix = " sample=%s/%s" % (_TRACE_COUNTS[key], limit) if limit > 1 else ""
        _log(env, "PLEX_CLIENT_SPLIT_TRACE key=%s%s %s" % (key, suffix, msg), level)
    except Exception:
        pass


def _short_path(path):
    try:
        text = str(path or "")
        if len(text) > 180:
            return text[:177] + "..."
        return text
    except Exception:
        return ""


def _addon(env=None):
    if env and env.get("addon") is not None:
        return env.get("addon")
    return xbmcaddon.Addon(id=ADDON_ID)


def _runtime_setting_v1732(env, setting_id, property_name):
    """Read the authoritative current-run Plex setting.

    A non-empty value cached by an older ``xbmcaddon.Addon`` wrapper must not win
    after the settings dialog changes the server.  The settings flow marks its
    Window(10000) bridge authoritative for the current process, including an
    explicit empty value after ``Plex 연결 초기화``.  This removes the old-server
    request observed immediately after a successful new-server probe.
    """
    addon = _addon(env)
    try:
        win = xbmcgui.Window(10000)
        authoritative = win.getProperty("PlexKM.Runtime.PlexAuthAuthoritative") == "1"
        runtime_value = (win.getProperty(property_name) or "").strip()
    except Exception:
        authoritative = False
        runtime_value = ""

    if authoritative:
        try:
            current = (addon.getSetting(setting_id) or "").strip()
        except Exception:
            current = ""
        if current != runtime_value:
            try:
                addon.setSetting(setting_id, runtime_value)
            except Exception:
                pass
            _trace(env, "runtime_setting_authoritative_%s" % setting_id,
                   "repaired=1 empty=%s source=global_window" % ("1" if not runtime_value else "0"), limit=8)
        return runtime_value

    try:
        value = (addon.getSetting(setting_id) or "").strip()
    except Exception:
        value = ""
    if value:
        return value
    if runtime_value:
        try:
            addon.setSetting(setting_id, runtime_value)
        except Exception:
            pass
        _trace(env, "runtime_setting_bridge_%s" % setting_id,
               "repaired=1 source=global_window", limit=3)
        return runtime_value
    # Last fallback: a newly created wrapper normally sees the just-persisted
    # settings even when an older wrapper did not refresh its in-memory snapshot.
    try:
        fresh = xbmcaddon.Addon(id=ADDON_ID)
        fresh_value = (fresh.getSetting(setting_id) or "").strip()
    except Exception:
        fresh_value = ""
    if fresh_value:
        try:
            addon.setSetting(setting_id, fresh_value)
        except Exception:
            pass
        _trace(env, "runtime_setting_fresh_%s" % setting_id,
               "repaired=1 source=fresh_addon", limit=3)
        return fresh_value
    return ""


def _addon_name(env=None):
    if env and env.get("addon_name"):
        return env.get("addon_name")
    try:
        return _addon(env).getAddonInfo("name")
    except Exception:
        return "Plex KM"


def _addon_version(env=None):
    try:
        return _addon(env).getAddonInfo("version")
    except Exception:
        return ""


def _log(env, msg, level=xbmc.LOGINFO):
    try:
        log_func = env.get("log") if env else None
        if log_func:
            log_func(msg, level)
            return
    except Exception:
        pass
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _set_plex_offline_state(env, offline, reason="", line1="", line2=""):
    """Expose Plex connectivity state to service/Home/sync code."""
    try:
        win = xbmcgui.Window(10000)
        if offline:
            win.setProperty("PlexKM.PlexOffline", "1")
            win.setProperty("PlexKM.PlexOfflineReason", str(reason or "offline"))
            win.setProperty("PlexKM.PlexOfflineLine1", str(line1 or "Plex 서버 응답 없음"))
            win.setProperty("PlexKM.PlexOfflineLine2", str(line2 or "서버 상태와 네트워크를 확인해주세요"))
            win.setProperty("PlexKM.PlexOfflineAt", str(int(time.time())))
        else:
            win.clearProperty("PlexKM.PlexOffline")
            win.clearProperty("PlexKM.PlexOfflineReason")
            win.clearProperty("PlexKM.PlexOfflineLine1")
            win.clearProperty("PlexKM.PlexOfflineLine2")
            win.clearProperty("PlexKM.PlexOfflineAt")
        _log(env, "PLEX_OFFLINE_STATE_SET offline=%s reason=%s" % ("1" if offline else "0", str(reason or "")), xbmc.LOGINFO if not offline else xbmc.LOGWARNING)
        return True
    except Exception:
        return False


def plex_offline_state_active():
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1"
    except Exception:
        return False


def clean_server_url(env=None):
    url = _runtime_setting_v1732(env, "plex_url", "PlexKM.Runtime.PlexURL")
    clean = url.rstrip("/")
    _trace(env, "clean_server_url", "server_configured=%s" % ("1" if clean else "0"), limit=1)
    return clean


def plex_token(env=None):
    token = _runtime_setting_v1732(env, "plex_token", "PlexKM.Runtime.PlexToken")
    _trace(env, "plex_token", "token_configured=%s" % ("1" if token else "0"), limit=1)
    return token


def token_masked(env=None):
    token = plex_token(env=env)
    if not token:
        return ""
    return token[:3] + "***" + token[-3:]


def append_token(url, env=None):
    token = plex_token(env=env)
    if not token:
        return url
    sep = "&" if "?" in url else "?"
    return url + sep + "X-Plex-Token=" + quote(token)


def plex_url(path, params=None, include_token=True, env=None):
    server = clean_server_url(env=env)
    if not server:
        raise RuntimeError("Plex Server URL is empty")
    if path.startswith("http://") or path.startswith("https://"):
        url = path
    else:
        if not path.startswith("/"):
            path = "/" + path
        url = server + path
    params = params or {}
    if params:
        url += ("&" if "?" in url else "?") + urlencode(params)
    if include_token:
        url = append_token(url, env=env)
    return url


def _safe_url(url, env=None):
    token = plex_token(env=env)
    return url.replace(token, token_masked(env=env)) if token else url


def _emit_plex_connection_notice(env, reason, line1, line2="", throttle_sec=45):
    """Show a persistent Plex connectivity problem through the PKM notice area.

    PKM depends on Plex connectivity, so a real offline/auth/server failure is
    sticky and must not auto-disappear. It is cleared only by a later successful
    Plex request or an explicit force clear.
    """
    try:
        key = str(reason or "plex")
        now = _now_ts()
    except Exception:
        now = 0
        key = str(reason or "plex")
    try:
        last = int(_PLEX_NOTICE_LAST.get(key, 0) or 0)
        if last and now and now - last < int(throttle_sec or 45):
            return False
        _PLEX_NOTICE_LAST[key] = now
    except Exception:
        pass
    title = "Plex 연결 실패"
    line1 = str(line1 or "Plex 서버에 연결할 수 없습니다")
    line2 = str(line2 or "서버 상태와 네트워크를 확인해주세요")
    _set_plex_offline_state(env, True, reason=key, line1=line1, line2=line2)
    try:
        fn = env.get("pkm_notice_set") if env else None
        if callable(fn):
            try:
                fn(title, line1, line2, sticky=True, force_replace=True)
            except TypeError:
                fn(title, line1, line2)
            _log(env, "PLEX_CONNECTION_NOTICE_STICKY_SET reason=%s line1=%s line2=%s" % (key, line1, line2), xbmc.LOGWARNING)
            return True
    except Exception:
        pass
    try:
        fn = env.get("pkm_show_notice") if env else None
        if callable(fn):
            # Last-resort fallback only; normal path above is persistent.
            return bool(fn(title, line1, line2, ms=24 * 60 * 60 * 1000))
    except Exception:
        pass
    _log(env, "PKM_PLEX_NOTICE_FALLBACK_LOG_ONLY reason=%s line1=%s line2=%s" % (key, line1, line2), xbmc.LOGWARNING)
    return False


def _plex_headers(env=None):
    return {
        "Accept": "application/xml",
        "X-Plex-Client-Identifier": "plex-km-kodi",
        "X-Plex-Product": _addon_name(env=env),
        "X-Plex-Version": _addon_version(env=env),
    }


def probe_server_identity_explicit(server_url, timeout=3.5, env=None):
    """Validate a candidate PMS endpoint before it is persisted.

    This probe deliberately bypasses add-on settings and the offline-state
    notifier.  A typo must remain an editable candidate, not become the active
    server or a sticky global offline state.
    """
    server = str(server_url or "").strip().rstrip("/")
    if not server:
        raise RuntimeError("Plex Server URL is empty")
    if "://" not in server:
        server = "http://" + server
    url = server + "/identity"
    _trace(env, "explicit_identity_probe_start", "server=%s timeout=%s" % (server, timeout), limit=20)
    req = Request(url, headers=_plex_headers(env=env))
    try:
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read()
        root = ET.fromstring(data)
        _trace(env, "explicit_identity_probe_ok", "server=%s bytes=%s tag=%s" % (
            server, len(data), getattr(root, "tag", "")
        ), limit=20)
        return root
    except Exception as exc:
        _trace(env, "explicit_identity_probe_fail", "server=%s error=%s" % (server, exc), xbmc.LOGWARNING, limit=20)
        raise RuntimeError("Plex candidate identity probe failed for %s: %s" % (server, exc))


def plex_request_xml(path, params=None, timeout=20, log_failures=True, env=None):
    url = plex_url(path, params=params, include_token=True, env=env)
    safe_url = _safe_url(url, env=env)
    _log(env, "GET %s" % safe_url, xbmc.LOGDEBUG)
    _trace(env, "xml_request_start", "path=%s timeout=%s" % (_short_path(path), timeout), limit=12)
    req = Request(url, headers=_plex_headers(env=env))
    try:
        data = _urlopen_bytes_coalesced_v1937(req, url, timeout, method="GET", env=env)
    except HTTPError as e:
        _trace(env, "xml_request_http_error", "path=%s code=%s" % (_short_path(path), e.code), xbmc.LOGWARNING, limit=20)
        try:
            code = int(getattr(e, "code", 0) or 0)
            if code in (401, 403):
                _emit_plex_connection_notice(env, "auth", "Plex 인증 실패", "토큰 또는 권한을 확인해주세요", throttle_sec=60)
            elif code >= 500 and _should_emit_plex_disconnect_notice(path):
                _emit_plex_connection_notice(env, "server_http", "Plex 서버 응답 오류", "잠시 후 다시 시도해주세요", throttle_sec=60)
        except Exception:
            pass
        raise RuntimeError("Plex HTTP error %s for %s" % (e.code, safe_url))
    except URLError as e:
        _trace(env, "xml_request_url_error", "path=%s error=%s" % (_short_path(path), e), xbmc.LOGWARNING, limit=20)
        if _should_emit_plex_disconnect_notice(path):
            _emit_plex_connection_notice(env, "offline", "Plex 서버 응답 없음", "서버 상태와 네트워크를 확인해주세요", throttle_sec=45)
        else:
            _log_plex_notice_suppressed(env, path, e, reason=_disconnect_notice_suppress_reason_v1931(path))
        raise RuntimeError("Plex connection error for %s: %s" % (safe_url, e))
    except Exception as e:
        if log_failures:
            _log(env, "PLEX_REQUEST_FAIL url=%s error=%s timeout=%s" % (safe_url, e, timeout), xbmc.LOGWARNING)
        _trace(env, "xml_request_fail", "path=%s error=%s" % (_short_path(path), e), xbmc.LOGWARNING, limit=20)
        if _should_emit_plex_disconnect_notice(path):
            _emit_plex_connection_notice(env, "request", "Plex 요청 실패", "서버 상태와 네트워크를 확인해주세요", throttle_sec=45)
        else:
            _log_plex_notice_suppressed(env, path, e, reason=_disconnect_notice_suppress_reason_v1931(path))
        raise RuntimeError("Plex request failed for %s: %s" % (safe_url, e))
    try:
        root = ET.fromstring(data)
        _mark_plex_ok(env, path)
        _trace(env, "xml_request_ok", "path=%s bytes=%s tag=%s" % (_short_path(path), len(data), getattr(root, "tag", "")), limit=20)
        return root
    except Exception as e:
        _trace(env, "xml_parse_fail", "path=%s error=%s" % (_short_path(path), e), xbmc.LOGWARNING, limit=20)
        raise RuntimeError("Plex XML parse failed: %s" % e)


def plex_request(path, params=None, timeout=8, method="GET", env=None):
    """Send a lightweight Plex API request and return the raw response bytes."""
    url = plex_url(path, params=params, include_token=True, env=env)
    safe_url = _safe_url(url, env=env)
    _log(env, "%s %s" % (method, safe_url), xbmc.LOGDEBUG)
    _trace(env, "raw_request_start", "method=%s path=%s timeout=%s" % (method, _short_path(path), timeout), limit=12)
    req = Request(url, headers=_plex_headers(env=env), method=method)
    try:
        data = _urlopen_bytes_coalesced_v1937(req, url, timeout, method=method, env=env)
        _mark_plex_ok(env, path)
        _trace(env, "raw_request_ok", "method=%s path=%s bytes=%s" % (method, _short_path(path), len(data)), limit=20)
        return data
    except HTTPError as e:
        _trace(env, "raw_request_http_error", "method=%s path=%s code=%s" % (method, _short_path(path), e.code), xbmc.LOGWARNING, limit=20)
        try:
            code = int(getattr(e, "code", 0) or 0)
            if code in (401, 403):
                _emit_plex_connection_notice(env, "auth", "Plex 인증 실패", "토큰 또는 권한을 확인해주세요", throttle_sec=60)
            elif code >= 500 and _should_emit_plex_disconnect_notice(path):
                _emit_plex_connection_notice(env, "server_http", "Plex 서버 응답 오류", "잠시 후 다시 시도해주세요", throttle_sec=60)
        except Exception:
            pass
        raise RuntimeError("Plex HTTP error %s for %s" % (e.code, safe_url))
    except URLError as e:
        _trace(env, "raw_request_url_error", "method=%s path=%s error=%s" % (method, _short_path(path), e), xbmc.LOGWARNING, limit=20)
        if _should_emit_plex_disconnect_notice(path):
            _emit_plex_connection_notice(env, "offline", "Plex 서버 응답 없음", "서버 상태와 네트워크를 확인해주세요", throttle_sec=45)
        else:
            _log_plex_notice_suppressed(env, path, e, reason=_disconnect_notice_suppress_reason_v1931(path))
        raise RuntimeError("Plex connection error for %s: %s" % (safe_url, e))
    except Exception as e:
        _log(env, "PLEX_REQUEST_RAW_FAIL url=%s error=%s timeout=%s" % (safe_url, e, timeout), xbmc.LOGWARNING)
        _trace(env, "raw_request_fail", "method=%s path=%s error=%s" % (method, _short_path(path), e), xbmc.LOGWARNING, limit=20)
        if _should_emit_plex_disconnect_notice(path):
            _emit_plex_connection_notice(env, "request", "Plex 요청 실패", "서버 상태와 네트워크를 확인해주세요", throttle_sec=45)
        else:
            _log_plex_notice_suppressed(env, path, e, reason=_disconnect_notice_suppress_reason_v1931(path))
        raise RuntimeError("Plex request failed for %s: %s" % (safe_url, e))


def art_url(path, width=1920, height=1920, env=None):
    if not path:
        return ""
    addon = _addon(env)
    mode = (addon.getSetting("art_mode") or "direct").strip()
    _trace(env, "art_url", "mode=%s width=%s height=%s path=%s" % (mode, width, height, _short_path(path)), limit=8)
    if mode == "transcode" and not path.startswith("http"):
        transcode_path = "/photo/:/transcode"
        params = {
            "width": width,
            "height": height,
            "minSize": 1,
            "upscale": 0,
            "url": path,
        }
        return plex_url(transcode_path, params=params, include_token=True, env=env)
    return plex_url(path, include_token=True, env=env)
