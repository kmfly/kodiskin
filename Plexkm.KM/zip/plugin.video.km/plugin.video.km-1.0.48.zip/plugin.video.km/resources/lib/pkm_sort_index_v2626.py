# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import sqlite3
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import pkm_library_sort

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)

_MOVIE_KEYS = tuple(k for k, _ in pkm_library_sort.MOVIE_SORT_OPTIONS)
_TV_KEYS = tuple(k for k, _ in pkm_library_sort.TV_SORT_OPTIONS)
_INDEX_LOCK = threading.RLock()
_PREWARM_LOCK = threading.RLock()
_PREWARM_QUEUE = []
_PREWARM_RUNNING = False
_SCHEMA_READY = False


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] %s" % msg, level)
    except Exception:
        pass


def _profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    try:
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)
    except Exception:
        pass
    return path


def _main_db_path():
    return os.path.join(_profile_dir(), "plex_km.db")


def _sort_db_path():
    return os.path.join(_profile_dir(), "library_sort_index_v2626.db")


def _main_conn():
    conn = sqlite3.connect(_main_db_path(), timeout=5.0)
    try:
        conn.execute("PRAGMA busy_timeout=5000")
    except Exception:
        pass
    return conn


def _sort_conn():
    conn = sqlite3.connect(_sort_db_path(), timeout=5.0)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA busy_timeout=5000")
    except Exception:
        pass
    return conn


def _ensure_schema():
    global _SCHEMA_READY
    if _SCHEMA_READY:
        return True
    with _INDEX_LOCK:
        if _SCHEMA_READY:
            return True
        main = _main_conn()
        try:
            main.executescript("""
                CREATE TABLE IF NOT EXISTS pkm_sort_generation_v2626 (
                    section_id TEXT PRIMARY KEY,
                    generation INTEGER NOT NULL DEFAULT 0,
                    updated_at INTEGER NOT NULL DEFAULT 0
                );
                CREATE TRIGGER IF NOT EXISTS trg_pkm_sort_items_insert_v2626
                AFTER INSERT ON items
                WHEN COALESCE(NEW.section_id,'')<>''
                BEGIN
                    INSERT INTO pkm_sort_generation_v2626(section_id,generation,updated_at)
                    VALUES(NEW.section_id,1,CAST(strftime('%s','now') AS INTEGER))
                    ON CONFLICT(section_id) DO UPDATE SET generation=generation+1,updated_at=excluded.updated_at;
                END;
                CREATE TRIGGER IF NOT EXISTS trg_pkm_sort_items_delete_v2626
                AFTER DELETE ON items
                WHEN COALESCE(OLD.section_id,'')<>''
                BEGIN
                    INSERT INTO pkm_sort_generation_v2626(section_id,generation,updated_at)
                    VALUES(OLD.section_id,1,CAST(strftime('%s','now') AS INTEGER))
                    ON CONFLICT(section_id) DO UPDATE SET generation=generation+1,updated_at=excluded.updated_at;
                END;
                CREATE TRIGGER IF NOT EXISTS trg_pkm_sort_items_update_old_v2626
                AFTER UPDATE OF section_id,plex_type,title,sort_title,year,added_at,updated_at,view_count,last_viewed_at,raw_json,grandparent_rating_key,season,episode ON items
                WHEN COALESCE(OLD.section_id,'')<>''
                BEGIN
                    INSERT INTO pkm_sort_generation_v2626(section_id,generation,updated_at)
                    VALUES(OLD.section_id,1,CAST(strftime('%s','now') AS INTEGER))
                    ON CONFLICT(section_id) DO UPDATE SET generation=generation+1,updated_at=excluded.updated_at;
                END;
                CREATE TRIGGER IF NOT EXISTS trg_pkm_sort_items_update_new_v2626
                AFTER UPDATE OF section_id,plex_type,title,sort_title,year,added_at,updated_at,view_count,last_viewed_at,raw_json,grandparent_rating_key,season,episode ON items
                WHEN COALESCE(NEW.section_id,'')<>'' AND COALESCE(NEW.section_id,'')<>COALESCE(OLD.section_id,'')
                BEGIN
                    INSERT INTO pkm_sort_generation_v2626(section_id,generation,updated_at)
                    VALUES(NEW.section_id,1,CAST(strftime('%s','now') AS INTEGER))
                    ON CONFLICT(section_id) DO UPDATE SET generation=generation+1,updated_at=excluded.updated_at;
                END;
            """)
            # V2628: provider rating sorts are part of the same 24-key KPI contract.
            # Keep live provider tables authoritative, but add indexes so a cold
            # provider sort never has to do an unindexed 20k-row join scan.
            try:
                tables_v2628 = {str(r[0]) for r in main.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
                if "item_ratings" in tables_v2628:
                    main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_item_ratings_rk_v2628 ON item_ratings(rating_key)")
                    try:
                        main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_item_ratings_score_v2628 ON item_ratings(COALESCE(score,rating,audience_rating,user_rating,0),rating_key)")
                    except Exception:
                        pass
                if "cine21_matches" in tables_v2628:
                    main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_cine21_rk_v2628 ON cine21_matches(rating_key)")
                    try:
                        main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_cine21_score_v2628 ON cine21_matches(COALESCE(critic_rating,audience_rating,0),rating_key)")
                    except Exception:
                        pass
                if "watcha_ratings" in tables_v2628:
                    main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_watcha_rk_v2628 ON watcha_ratings(rating_key)")
                    try:
                        main.execute("CREATE INDEX IF NOT EXISTS idx_pkm_sort_watcha_score_v2628 ON watcha_ratings(COALESCE(watcha_rating,0),rating_key)")
                    except Exception:
                        pass
            except Exception as exc_v2628:
                _log("SORT_PROVIDER_INDEX_PREP_FAILED_V2628 error=%s" % exc_v2628, xbmc.LOGWARNING)
            main.commit()
        finally:
            main.close()
        idx = _sort_conn()
        try:
            idx.executescript("""
                CREATE TABLE IF NOT EXISTS sort_rows (
                    section_id TEXT NOT NULL,
                    media_kind TEXT NOT NULL,
                    rating_key TEXT NOT NULL,
                    title_key TEXT NOT NULL DEFAULT '',
                    added_num INTEGER NOT NULL DEFAULT 0,
                    year_num INTEGER NOT NULL DEFAULT 0,
                    release_num INTEGER NOT NULL DEFAULT 0,
                    progress_num REAL NOT NULL DEFAULT 0,
                    viewed_num INTEGER NOT NULL DEFAULT 0,
                    resolution_num INTEGER NOT NULL DEFAULT 0,
                    bitrate_num REAL NOT NULL DEFAULT 0,
                    watched_num INTEGER NOT NULL DEFAULT 0,
                    first_air_num INTEGER NOT NULL DEFAULT 0,
                    recent_air_num INTEGER NOT NULL DEFAULT 0,
                    tmdb_num REAL NOT NULL DEFAULT 0,
                    unwatched_num INTEGER NOT NULL DEFAULT 0,
                    seasons_num INTEGER NOT NULL DEFAULT 0,
                    status_num INTEGER NOT NULL DEFAULT 0,
                    episode_count INTEGER NOT NULL DEFAULT 0,
                    watched_count INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(section_id,media_kind,rating_key)
                );
                CREATE TABLE IF NOT EXISTS sort_state (
                    section_id TEXT NOT NULL,
                    media_kind TEXT NOT NULL,
                    generation INTEGER NOT NULL DEFAULT -1,
                    row_count INTEGER NOT NULL DEFAULT 0,
                    built_at INTEGER NOT NULL DEFAULT 0,
                    build_ms INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(section_id,media_kind)
                );
                CREATE INDEX IF NOT EXISTS idx_sort_title_v2626 ON sort_rows(section_id,media_kind,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_added_v2626 ON sort_rows(section_id,media_kind,added_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_year_v2626 ON sort_rows(section_id,media_kind,year_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_release_v2626 ON sort_rows(section_id,media_kind,release_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_progress_v2626 ON sort_rows(section_id,media_kind,progress_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_viewed_v2626 ON sort_rows(section_id,media_kind,viewed_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_resolution_v2626 ON sort_rows(section_id,media_kind,resolution_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_bitrate_v2626 ON sort_rows(section_id,media_kind,bitrate_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_firstair_v2626 ON sort_rows(section_id,media_kind,first_air_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_recentair_v2626 ON sort_rows(section_id,media_kind,recent_air_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_tmdb_v2626 ON sort_rows(section_id,media_kind,tmdb_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_unwatched_v2626 ON sort_rows(section_id,media_kind,unwatched_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_seasons_v2626 ON sort_rows(section_id,media_kind,seasons_num,title_key,rating_key);
                CREATE INDEX IF NOT EXISTS idx_sort_status_v2626 ON sort_rows(section_id,media_kind,status_num,title_key,rating_key);
            """)
            idx.commit()
        finally:
            idx.close()
        _SCHEMA_READY = True
        _log("SORT_INDEX_SCHEMA_READY_V2626 db=%s" % _sort_db_path())
        return True


def _generation(main, sid):
    _ensure_schema()
    row = main.execute("SELECT generation FROM pkm_sort_generation_v2626 WHERE section_id=?", (str(sid),)).fetchone()
    if row is None:
        main.execute("INSERT OR IGNORE INTO pkm_sort_generation_v2626(section_id,generation,updated_at) VALUES(?,0,?)", (str(sid), int(time.time())))
        main.commit()
        return 0
    return int(row[0] or 0)


def _infer_media(main, sid):
    show_count = int((main.execute("SELECT COUNT(*) FROM items WHERE section_id=? AND plex_type='show'", (str(sid),)).fetchone() or [0])[0] or 0)
    if show_count > 0:
        return "tv"
    return "movie"


def _state_ready(sid, media_kind):
    _ensure_schema()
    main = _main_conn()
    idx = _sort_conn()
    try:
        gen = _generation(main, sid)
        row = idx.execute("SELECT generation,row_count,build_ms FROM sort_state WHERE section_id=? AND media_kind=?", (str(sid), str(media_kind))).fetchone()
        return bool(row and int(row[0] if row[0] is not None else -1) == gen and int(row[1] or 0) >= 0), gen, (int(row[1] or 0) if row else 0), (int(row[2] or 0) if row else 0)
    finally:
        main.close()
        idx.close()


def _date_num(value):
    text = str(value or "").strip()
    digits = "".join(ch for ch in text[:10] if ch.isdigit())
    try:
        return int(digits[:8] or 0)
    except Exception:
        return 0


def _raw_values(raw_json):
    try:
        data = json.loads(raw_json or "{}")
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    release_num = _date_num(data.get("originallyAvailableAt") or data.get("year") or 0)
    resolution = str(data.get("videoResolution") or "").strip().lower()
    try:
        height = int(float(data.get("height") or 0))
    except Exception:
        height = 0
    if "4k" in resolution or "2160" in resolution:
        resolution_num = 2160
    elif "1080" in resolution:
        resolution_num = 1080
    elif "720" in resolution:
        resolution_num = 720
    elif "480" in resolution:
        resolution_num = 480
    else:
        resolution_num = height
    try:
        bitrate_num = float(data.get("bitrate") or 0)
    except Exception:
        bitrate_num = 0.0
    rating_num = 0.0
    for key in ("audienceRating", "rating", "userRating"):
        if data.get(key) not in (None, ""):
            try:
                rating_num = float(data.get(key) or 0)
            except Exception:
                rating_num = 0.0
            break
    status = str(data.get("status") or data.get("showStatus") or "").strip().lower()
    if any(tok in status for tok in ("returning", "continuing", "in production", "planned", "airing", "방영")):
        status_num = 2
    elif any(tok in status for tok in ("ended", "cancel", "canceled", "cancelled", "종영", "완결")):
        status_num = 1
    else:
        status_num = 0
    return release_num, resolution_num, bitrate_num, rating_num, status_num


def _resume_map():
    out = {}
    profile = _profile_dir()
    continue_path = os.path.join(profile, "playstate_continue_preload.json")
    resume_path = os.path.join(profile, "playstate_resume.json")
    try:
        with open(continue_path, "r", encoding="utf-8") as f:
            payload = json.load(f) or {}
        for item in payload.get("items") or []:
            if not isinstance(item, dict):
                continue
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                continue
            try:
                off = max(0, int(float(item.get("view_offset") or 0)))
                dur = max(0, int(float(item.get("resume_duration_ms") or item.get("duration") or 0)))
            except Exception:
                off = dur = 0
            pct = int(round((float(off) * 100.0) / float(dur))) if dur > 0 else 0
            if 0 < pct < 90:
                out[rk] = {
                    "pct": pct, "view_offset": off, "duration": dur,
                    "updated": int(float(item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at") or 0)),
                    "source": str(item.get("resume_source") or "plex_ondeck_preload"),
                }
    except Exception:
        pass
    try:
        with open(resume_path, "r", encoding="utf-8") as f:
            states = json.load(f) or {}
        if isinstance(states, dict):
            for rk, item in states.items():
                item = item or {}
                key = str(item.get("rating_key") or rk or "").strip()
                if not key:
                    continue
                try:
                    off = max(0, int(float(item.get("time") or 0)))
                    dur = max(0, int(float(item.get("duration") or 0)))
                    updated = max(0, int(float(item.get("updated_at") or 0)))
                except Exception:
                    off = dur = updated = 0
                pct = int(round((float(off) * 100.0) / float(dur))) if dur > 0 else 0
                if not (0 < pct < 90):
                    continue
                old = out.get(key) or {}
                if not old or updated >= int(old.get("updated") or 0):
                    out[key] = {"pct": pct, "view_offset": off, "duration": dur, "updated": updated, "source": "kodi_local"}
    except Exception:
        pass
    return out


def _build_movie(main, sid):
    """Build movie sort values without Python raw_json parsing on the hot prewarm path.

    V2627 uses SQLite JSON1 (native C) when available.  The previous V2626 loop
    json.loads()'d every movie and could hold the Python worker/GIL for seconds on
    20k-row sections.  A compatibility fallback preserves the old semantics.
    """
    resume = _resume_map()
    native_json = True
    try:
        rows = main.execute("""
            SELECT rating_key,
                   COALESCE(sort_title,title,''),
                   COALESCE(added_at,0),
                   COALESCE(year,0),
                   COALESCE(last_viewed_at,0),
                   COALESCE(view_count,0),
                   CASE WHEN json_valid(COALESCE(raw_json,''))
                        THEN CAST(REPLACE(SUBSTR(COALESCE(json_extract(raw_json,'$.originallyAvailableAt'), CAST(year AS TEXT), ''),1,10),'-','') AS INTEGER)
                        ELSE COALESCE(year,0) END AS release_num,
                   CASE WHEN json_valid(COALESCE(raw_json,'')) THEN
                        CASE
                          WHEN LOWER(COALESCE(json_extract(raw_json,'$.videoResolution'),'')) LIKE '%4k%'
                            OR LOWER(COALESCE(json_extract(raw_json,'$.videoResolution'),'')) LIKE '%2160%' THEN 2160
                          WHEN LOWER(COALESCE(json_extract(raw_json,'$.videoResolution'),'')) LIKE '%1080%' THEN 1080
                          WHEN LOWER(COALESCE(json_extract(raw_json,'$.videoResolution'),'')) LIKE '%720%' THEN 720
                          WHEN LOWER(COALESCE(json_extract(raw_json,'$.videoResolution'),'')) LIKE '%480%' THEN 480
                          ELSE CAST(COALESCE(json_extract(raw_json,'$.height'),0) AS INTEGER)
                        END ELSE 0 END AS resolution_num,
                   CASE WHEN json_valid(COALESCE(raw_json,''))
                        THEN CAST(COALESCE(json_extract(raw_json,'$.bitrate'),0) AS REAL)
                        ELSE 0 END AS bitrate_num
            FROM items
            WHERE section_id=? AND plex_type='movie'
        """, (str(sid),)).fetchall()
    except Exception:
        native_json = False
        rows = main.execute(
            "SELECT rating_key,COALESCE(sort_title,title,''),COALESCE(added_at,0),COALESCE(year,0),COALESCE(last_viewed_at,0),COALESCE(view_count,0),COALESCE(raw_json,'') "
            "FROM items WHERE section_id=? AND plex_type='movie'", (str(sid),)
        ).fetchall()
    out = []
    if native_json:
        iterator = rows
    else:
        converted = []
        for rk, title, added, year, viewed, view_count, raw_json in rows:
            release_num, resolution_num, bitrate_num, _rating_num, _status_num = _raw_values(raw_json)
            converted.append((rk, title, added, year, viewed, view_count, release_num, resolution_num, bitrate_num))
        iterator = converted
    for rk, title, added, year, viewed, view_count, release_num, resolution_num, bitrate_num in iterator:
        state = resume.get(str(rk)) or {}
        watched = 1 if int(view_count or 0) > 0 else 0
        progress_num = 1000.0 if watched else float(state.get("pct") or 0)
        out.append((
            str(sid), "movie", str(rk), str(title or "").casefold(), int(added or 0), int(year or 0), int(release_num or 0),
            float(progress_num), int(viewed or 0), int(resolution_num or 0), float(bitrate_num or 0), watched,
            0,0,0.0,0,0,0,0,0
        ))
    _log("SORT_INDEX_EXTRACT_V2627 section=%s media=movie rows=%d native_json=%d" % (str(sid), len(out), 1 if native_json else 0))
    return out

def _release_num_udf(raw_json):
    try:
        data = json.loads(raw_json or "{}")
        return _date_num((data or {}).get("originallyAvailableAt") or (data or {}).get("year") or 0)
    except Exception:
        return 0


def _build_tv(main, sid):
    """Build show aggregates with native SQLite JSON extraction when possible.

    V2626 registered a Python UDF and invoked it across every episode in the
    GROUP BY.  Large 50k-70k episode sections therefore competed with GUI Python.
    JSON1 keeps date extraction inside SQLite C code; fallback keeps compatibility.
    """
    show_rows = main.execute(
        "SELECT rating_key,COALESCE(sort_title,title,''),COALESCE(added_at,0),COALESCE(year,0),COALESCE(last_viewed_at,0),COALESCE(view_count,0),COALESCE(raw_json,'') "
        "FROM items WHERE section_id=? AND plex_type='show'", (str(sid),)
    ).fetchall()
    native_json = True
    try:
        agg_rows = main.execute("""
            SELECT grandparent_rating_key,
                   COUNT(*) AS episode_count,
                   SUM(CASE WHEN COALESCE(view_count,0)>0 THEN 1 ELSE 0 END) AS watched_count,
                   MAX(COALESCE(added_at,0)) AS latest_added,
                   MAX(COALESCE(last_viewed_at,0)) AS latest_viewed,
                   MAX(COALESCE(year,0)) AS latest_year,
                   COUNT(DISTINCT CASE WHEN COALESCE(season,0)>0 THEN season END) AS season_count,
                   MAX(CASE WHEN json_valid(COALESCE(raw_json,''))
                            THEN CAST(REPLACE(SUBSTR(COALESCE(json_extract(raw_json,'$.originallyAvailableAt'),''),1,10),'-','') AS INTEGER)
                            ELSE 0 END) AS recent_air,
                   MIN(CASE WHEN json_valid(COALESCE(raw_json,''))
                                 AND COALESCE(json_extract(raw_json,'$.originallyAvailableAt'),'')<>''
                            THEN CAST(REPLACE(SUBSTR(json_extract(raw_json,'$.originallyAvailableAt'),1,10),'-','') AS INTEGER)
                            ELSE NULL END) AS first_episode_air
            FROM items
            WHERE section_id=? AND plex_type='episode' AND COALESCE(grandparent_rating_key,'')<>''
            GROUP BY grandparent_rating_key
        """, (str(sid),)).fetchall()
    except Exception:
        native_json = False
        main.create_function("pkm_v2626_release_num", 1, _release_num_udf)
        agg_rows = main.execute("""
            SELECT grandparent_rating_key,
                   COUNT(*) AS episode_count,
                   SUM(CASE WHEN COALESCE(view_count,0)>0 THEN 1 ELSE 0 END) AS watched_count,
                   MAX(COALESCE(added_at,0)) AS latest_added,
                   MAX(COALESCE(last_viewed_at,0)) AS latest_viewed,
                   MAX(COALESCE(year,0)) AS latest_year,
                   COUNT(DISTINCT CASE WHEN COALESCE(season,0)>0 THEN season END) AS season_count,
                   MAX(pkm_v2626_release_num(raw_json)) AS recent_air,
                   MIN(CASE WHEN pkm_v2626_release_num(raw_json)>0 THEN pkm_v2626_release_num(raw_json) END) AS first_episode_air
            FROM items
            WHERE section_id=? AND plex_type='episode' AND COALESCE(grandparent_rating_key,'')<>''
            GROUP BY grandparent_rating_key
        """, (str(sid),)).fetchall()
    agg = {}
    for rk, count, watched, latest_added, latest_viewed, latest_year, seasons, recent_air, first_episode_air in agg_rows:
        agg[str(rk)] = (int(count or 0), int(watched or 0), int(latest_added or 0), int(latest_viewed or 0), int(latest_year or 0), int(seasons or 0), int(recent_air or 0), int(first_episode_air or 0))
    out = []
    for rk, title, added, year, viewed, view_count, raw_json in show_rows:
        release_num, _resolution_num, _bitrate_num, tmdb_num, status_num = _raw_values(raw_json)
        ep_count, watched_count, latest_added, latest_viewed, latest_year, seasons, recent_air, first_episode_air = agg.get(str(rk), (0,0,0,0,0,0,0,0))
        progress = (float(watched_count) / float(ep_count)) if ep_count > 0 else 0.0
        unwatched = max(0, ep_count - watched_count)
        out.append((
            str(sid), "tv", str(rk), str(title or "").casefold(), int(latest_added or added or 0), int(year or latest_year or 0), 0,
            float(progress), int(latest_viewed or viewed or 0), 0,0.0, 1 if (ep_count > 0 and watched_count >= ep_count) else int(view_count or 0),
            int(release_num or first_episode_air or 0), int(recent_air or 0), float(tmdb_num or 0), int(unwatched), int(seasons), int(status_num), int(ep_count), int(watched_count)
        ))
    _log("SORT_INDEX_EXTRACT_V2627 section=%s media=tv shows=%d groups=%d native_json=%d" % (str(sid), len(out), len(agg), 1 if native_json else 0))
    return out

def build_section(section_id, media_kind=None, force=False):
    sid = str(section_id or "").strip()
    if not sid:
        return False
    _ensure_schema()
    started = time.perf_counter()
    with _INDEX_LOCK:
        main = _main_conn()
        idx = _sort_conn()
        try:
            media = str(media_kind or "").strip().lower() or _infer_media(main, sid)
            gen_start = _generation(main, sid)
            state = idx.execute("SELECT generation FROM sort_state WHERE section_id=? AND media_kind=?", (sid, media)).fetchone()
            if not force and state and int(state[0] if state[0] is not None else -1) == gen_start:
                return True
            _log("SORT_INDEX_BUILD_BEGIN_V2626 section=%s media=%s generation=%d" % (sid, media, gen_start))
            payload = _build_tv(main, sid) if media == "tv" else _build_movie(main, sid)
            gen_end = _generation(main, sid)
            if gen_end != gen_start:
                _log("SORT_INDEX_BUILD_STALE_V2626 section=%s media=%s generation_start=%d generation_end=%d action=discard_retry" % (sid, media, gen_start, gen_end), xbmc.LOGWARNING)
                return False
            idx.execute("BEGIN")
            idx.execute("DELETE FROM sort_rows WHERE section_id=? AND media_kind=?", (sid, media))
            if payload:
                idx.executemany(
                    "INSERT OR REPLACE INTO sort_rows(section_id,media_kind,rating_key,title_key,added_num,year_num,release_num,progress_num,viewed_num,resolution_num,bitrate_num,watched_num,first_air_num,recent_air_num,tmdb_num,unwatched_num,seasons_num,status_num,episode_count,watched_count) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", payload
                )
            elapsed_ms = int(round((time.perf_counter() - started) * 1000.0))
            idx.execute(
                "INSERT OR REPLACE INTO sort_state(section_id,media_kind,generation,row_count,built_at,build_ms) VALUES(?,?,?,?,?,?)",
                (sid, media, gen_start, len(payload), int(time.time()), elapsed_ms)
            )
            idx.commit()
            _log("SORT_INDEX_BUILD_DONE_V2626 section=%s media=%s generation=%d rows=%d build_ms=%d" % (sid, media, gen_start, len(payload), elapsed_ms))
            return True
        except Exception as exc:
            try:
                idx.rollback()
            except Exception:
                pass
            _log("SORT_INDEX_BUILD_FAILED_V2626 section=%s media=%s error=%s" % (sid, media_kind or "", exc), xbmc.LOGWARNING)
            return False
        finally:
            main.close()
            idx.close()


def _prewarm_quiet_yield_v2627(min_ms=650, max_hot_ms=4000):
    """Yield between section builds so index maintenance never owns navigation."""
    try:
        xbmc.sleep(max(0, int(min_ms)))
    except Exception:
        time.sleep(max(0, int(min_ms)) / 1000.0)
    deadline = time.time() + (max(0, int(max_hot_ms)) / 1000.0)
    while time.time() < deadline:
        hot = False
        try:
            win = xbmcgui.Window(10000)
            hot = (
                win.getProperty("PlexKM.Sidebar.Browsing") == "1"
                or win.getProperty("PlexKM.WallRapidScrollV2581") == "1"
                or int(float(win.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0)) > int(time.time() * 1000)
            )
        except Exception:
            hot = False
        if not hot:
            return
        try:
            xbmc.sleep(120)
        except Exception:
            time.sleep(0.12)

def _prewarm_worker():
    global _PREWARM_RUNNING
    try:
        while True:
            with _PREWARM_LOCK:
                if not _PREWARM_QUEUE:
                    _PREWARM_RUNNING = False
                    return
                sid = _PREWARM_QUEUE.pop(0)
            try:
                build_section(sid)
            except Exception as exc:
                _log("SORT_INDEX_PREWARM_SECTION_FAILED_V2626 section=%s error=%s" % (sid, exc), xbmc.LOGWARNING)
            _prewarm_quiet_yield_v2627(min_ms=650, max_hot_ms=4000)
    finally:
        with _PREWARM_LOCK:
            _PREWARM_RUNNING = False


def prewarm_async(section_ids, priority_section=None, reason=""):
    global _PREWARM_RUNNING
    ids = []
    for value in list(section_ids or []):
        sid = str(value or "").strip()
        if sid and sid not in ids:
            ids.append(sid)
    priority = str(priority_section or "").strip()
    if priority:
        ids = [priority] + [sid for sid in ids if sid != priority]
    if not ids:
        return False
    _ensure_schema()
    with _PREWARM_LOCK:
        if priority and priority in _PREWARM_QUEUE:
            try:
                _PREWARM_QUEUE.remove(priority)
            except Exception:
                pass
            _PREWARM_QUEUE.insert(0, priority)
        for sid in ids:
            if sid not in _PREWARM_QUEUE:
                _PREWARM_QUEUE.append(sid)
        if priority and priority in _PREWARM_QUEUE and _PREWARM_QUEUE[0] != priority:
            try:
                _PREWARM_QUEUE.remove(priority)
                _PREWARM_QUEUE.insert(0, priority)
            except Exception:
                pass
        if _PREWARM_RUNNING:
            _log("SORT_INDEX_PREWARM_QUEUE_V2626 reason=%s queued=%d running=1 priority=%s" % (reason or "", len(_PREWARM_QUEUE), priority or "-"))
            return True
        _PREWARM_RUNNING = True
        t = threading.Thread(target=_prewarm_worker, name="PKMSortIndexV2626", daemon=True)
        t.start()
    _log("SORT_INDEX_PREWARM_START_V2626 reason=%s sections=%s priority=%s foreground_wait=0" % (reason or "", ",".join(ids), priority or "-"))
    return True


def _genre_key_set(main, sid, genre, media):
    if not genre:
        return None
    if media == "movie":
        rows = main.execute("SELECT rating_key FROM item_genres WHERE section_id=? AND genre=?", (sid, str(genre))).fetchall()
        return set(str(r[0]) for r in rows)
    rows = main.execute("""
        SELECT DISTINCT CASE WHEN i.plex_type='show' THEN i.rating_key ELSE i.grandparent_rating_key END
        FROM items i
        JOIN item_genres g ON g.rating_key=i.rating_key AND g.section_id=i.section_id
        WHERE i.section_id=? AND g.genre=? AND i.plex_type IN ('show','episode')
          AND COALESCE(CASE WHEN i.plex_type='show' THEN i.rating_key ELSE i.grandparent_rating_key END,'')<>''
    """, (sid, str(genre))).fetchall()
    return set(str(r[0]) for r in rows)


def _progress_case(resume):
    if not resume:
        return "CAST(0 AS REAL)", []
    parts = []
    args = []
    for rk, state in list(resume.items())[:300]:
        parts.append("WHEN ? THEN ?")
        args.extend([str(rk), int(state.get("pct") or 0)])
    return "CASE rating_key %s ELSE 0 END" % " ".join(parts), args


def _ordered_keys(sid, media, sort_key, sort_dir, limit, offset, genre=None, random_seed=None):
    ready, generation, row_count, build_ms = _state_ready(sid, media)
    if not ready:
        prewarm_async([sid], priority_section=sid, reason="query_miss_%s_%s" % (media, sort_key))
        _log("SORT_INDEX_MISS_V2626 section=%s media=%s sort=%s generation=%d action=core_fallback" % (sid, media, sort_key, generation))
        return None, {"ready": 0, "generation": generation, "row_count": row_count, "build_ms": build_ms}
    direction = "DESC" if str(sort_dir).lower() == "desc" else "ASC"
    title_dir = "DESC" if (sort_key == "progress" and direction == "DESC" and media == "movie") else "ASC"
    field_map_movie = {
        "title": "title_key", "added": "added_num", "year": "year_num", "release": "release_num",
        "progress": "progress_num", "viewed": "viewed_num", "resolution": "resolution_num", "bitrate": "bitrate_num",
    }
    field_map_tv = {
        "title": "title_key", "added": "added_num", "year": "year_num", "first_air": "first_air_num",
        "recent_air": "recent_air_num", "tmdb": "tmdb_num", "progress": "progress_num", "unwatched": "unwatched_num",
        "viewed": "viewed_num", "seasons": "seasons_num", "status": "status_num",
    }
    idx = _sort_conn()
    main = _main_conn()
    try:
        allowed = _genre_key_set(main, sid, genre, media)
        args = [sid, media]
        extra_where = ""
        if media == "movie" and sort_key == "viewed":
            extra_where = " AND watched_num>0"
        if sort_key == "random":
            seed = int(random_seed or 0) & 0x7fffffff
            order = "(((CAST(rating_key AS INTEGER) * 1103515245) + %d) & 2147483647) ASC, rating_key ASC" % seed
        elif media == "movie" and sort_key == "progress":
            resume = _resume_map()
            case_expr, case_args = _progress_case(resume)
            # watched rows stay above partial rows for DESC and below them for ASC.
            order = "watched_num %s, %s %s, title_key %s, rating_key ASC" % (direction, case_expr, direction, title_dir)
            args.extend(case_args)
        else:
            field = (field_map_tv if media == "tv" else field_map_movie).get(sort_key)
            if not field:
                return None, {"ready": 1, "generation": generation, "row_count": row_count, "build_ms": build_ms, "unsupported": 1}
            order = "%s %s, title_key ASC, rating_key ASC" % (field, direction)
        req_limit = int(limit or 0)
        req_offset = max(0, int(offset or 0))
        full_query = req_limit <= 0
        if allowed is None:
            if full_query:
                sql = "SELECT rating_key FROM sort_rows WHERE section_id=? AND media_kind=?%s ORDER BY %s" % (extra_where, order)
                rows = idx.execute(sql, list(args)).fetchall()
                if req_offset:
                    rows = rows[req_offset:]
            else:
                sql = "SELECT rating_key FROM sort_rows WHERE section_id=? AND media_kind=?%s ORDER BY %s LIMIT ? OFFSET ?" % (extra_where, order)
                rows = idx.execute(sql, list(args) + [req_limit, req_offset]).fetchall()
            return [str(r[0]) for r in rows], {"ready": 1, "generation": generation, "row_count": row_count, "build_ms": build_ms, "full_query": 1 if full_query else 0}
        # Category sort: preserve global sort order, then intersect against current genre.
        wanted_start = req_offset
        wanted_end = None if full_query else wanted_start + req_limit
        out = []
        scan_offset = 0
        chunk = 512
        while wanted_end is None or len(out) < wanted_end:
            sql = "SELECT rating_key FROM sort_rows WHERE section_id=? AND media_kind=?%s ORDER BY %s LIMIT ? OFFSET ?" % (extra_where, order)
            rows = idx.execute(sql, list(args) + [chunk, scan_offset]).fetchall()
            if not rows:
                break
            for row in rows:
                rk = str(row[0])
                if rk in allowed:
                    out.append(rk)
                    if wanted_end is not None and len(out) >= wanted_end:
                        break
            scan_offset += len(rows)
            if len(rows) < chunk:
                break
        result = out[wanted_start:] if wanted_end is None else out[wanted_start:wanted_end]
        return result, {"ready": 1, "generation": generation, "row_count": row_count, "build_ms": build_ms, "genre": 1, "full_query": 1 if full_query else 0}
    finally:
        idx.close()
        main.close()


def _fetch_movie_rows(main, keys):
    """Fetch ordered movie rows without exceeding SQLite host-parameter limits.

    V2627 restored limit<=0 full-query semantics, which can return thousands of
    rating keys.  Passing all keys through one IN (...) statement exceeded the
    Windows SQLite variable limit.  V2628 fetches in bounded chunks and then
    restores the authoritative sort-key order in Python.
    """
    if not keys:
        return []
    rows = []
    step_v2628 = 400
    for start_v2628 in range(0, len(keys), step_v2628):
        chunk_v2628 = list(keys[start_v2628:start_v2628 + step_v2628])
        marks = ",".join("?" for _ in chunk_v2628)
        rows.extend(main.execute(
            "SELECT rating_key, section_id, plex_type, '' AS kodi_type, title, '' AS original_title, title AS sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode, parent_rating_key, grandparent_rating_key, 0,0,0,'',raw_json "
            "FROM items WHERE rating_key IN (%s)" % marks, tuple(chunk_v2628)
        ).fetchall())
    by_key = {str(r[0]): tuple(r) for r in rows}
    resume = _resume_map()
    out = []
    for key in keys:
        row = list(by_key.get(str(key)) or ())
        if not row:
            continue
        while len(row) < 28:
            row.append("")
        state = resume.get(str(key)) or {}
        row[23] = int(state.get("view_offset") or 0)
        row[24] = int(state.get("duration") or 0)
        row[25] = int(state.get("updated") or 0)
        row[26] = str(state.get("source") or "")
        out.append(tuple(row))
    return out


def _fetch_tv_rows(main, sid, keys):
    """Fetch ordered TV show rows in chunks for full-query/index builds."""
    if not keys:
        return []
    base_rows = []
    meta_rows = []
    step_v2628 = 400
    for start_v2628 in range(0, len(keys), step_v2628):
        chunk_v2628 = list(keys[start_v2628:start_v2628 + step_v2628])
        marks = ",".join("?" for _ in chunk_v2628)
        base_rows.extend(main.execute(
            "SELECT rating_key, section_id, 'show' AS plex_type, 'tvshow' AS kodi_type, title, original_title, sort_title, year, summary, 0, added_at, updated_at, thumb, art, '', '', view_count, last_viewed_at, title, 0,0,'','',0,0,0,'',raw_json "
            "FROM items WHERE section_id=? AND plex_type='show' AND rating_key IN (%s)" % marks,
            tuple([sid] + chunk_v2628)
        ).fetchall())
    base = {str(r[0]): tuple(r) for r in base_rows}
    idx = _sort_conn()
    try:
        for start_v2628 in range(0, len(keys), step_v2628):
            chunk_v2628 = list(keys[start_v2628:start_v2628 + step_v2628])
            marks = ",".join("?" for _ in chunk_v2628)
            meta_rows.extend(idx.execute(
                "SELECT rating_key,added_num,viewed_num,seasons_num,recent_air_num,episode_count,watched_count,tmdb_num,status_num,first_air_num FROM sort_rows WHERE section_id=? AND media_kind='tv' AND rating_key IN (%s)" % marks,
                tuple([sid] + chunk_v2628)
            ).fetchall())
    finally:
        idx.close()
    meta_map = {str(r[0]): r for r in meta_rows}
    out = []
    for key in keys:
        row = base.get(str(key))
        if not row:
            continue
        m = meta_map.get(str(key)) or (key,0,0,0,0,0,0,0.0,0,0)
        episode_count = int(m[5] or 0)
        watched_count = int(m[6] or 0)
        try:
            _raw_meta = json.loads((row[27] if len(row) > 27 else "") or "{}")
            if not isinstance(_raw_meta, dict):
                _raw_meta = {}
        except Exception:
            _raw_meta = {}
        meta = {
            "episode_count": episode_count,
            "watched_count": watched_count,
            "unwatched_count": max(0, episode_count - watched_count),
            "progress_percent": int(round((float(watched_count) * 100.0) / float(episode_count))) if episode_count > 0 else 0,
            "is_watched": bool(episode_count > 0 and watched_count >= episode_count),
            "latest_added_at": int(m[1] or 0),
            "latest_viewed_at": int(m[2] or 0),
            "season_count": int(m[3] or 0),
            "latest_air_date_num": int(m[4] or 0),
            "first_air_date": str(_raw_meta.get("originallyAvailableAt") or m[9] or ""),
            "tmdb_rating": float(m[7] or 0),
            "status": str(_raw_meta.get("status") or _raw_meta.get("showStatus") or ""),
            "status_rank": int(m[8] or 0),
            "v2626_sort_index": 1,
        }
        out.append(tuple(row[:28]) + (json.dumps(meta, ensure_ascii=False),))
    return out


def _movie_rating_query(main, sid, sort_key, sort_dir, limit, offset, genre=None):
    direction = "DESC" if str(sort_dir).lower() == "desc" else "ASC"
    join = ""
    score = "0"
    try:
        if sort_key == "cine21" and main.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cine21_matches'").fetchone():
            join = " LEFT JOIN cine21_matches r ON r.rating_key=i.rating_key "
            score = "COALESCE(r.critic_rating,r.audience_rating,0)"
        elif sort_key == "watcha" and main.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='watcha_ratings'").fetchone():
            join = " LEFT JOIN watcha_ratings r ON r.rating_key=i.rating_key "
            score = "COALESCE(r.watcha_rating,0)"
        elif sort_key == "imdb" and main.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='item_ratings'").fetchone():
            join = " LEFT JOIN item_ratings r ON r.rating_key=i.rating_key "
            score = "COALESCE(r.rating,r.score,r.audience_rating,r.user_rating,0)"
    except Exception:
        join = ""
        score = "0"
    where = ["i.section_id=?", "i.plex_type='movie'"]
    args = [sid]
    if genre:
        where.append("EXISTS (SELECT 1 FROM item_genres ig WHERE ig.section_id=i.section_id AND ig.rating_key=i.rating_key AND ig.genre=?)")
        args.append(str(genre))
    req_limit = int(limit or 0)
    req_offset = max(0, int(offset or 0))
    if req_limit <= 0:
        sql = (
            "SELECT i.rating_key,i.section_id,i.plex_type,'' AS kodi_type,i.title,'' AS original_title,i.title AS sort_title,i.year,i.summary,i.duration,i.added_at,i.updated_at,i.thumb,i.art,i.media_file,i.part_key,i.view_count,i.last_viewed_at,i.show_title,i.season,i.episode,i.parent_rating_key,i.grandparent_rating_key,0,0,0,'',i.raw_json "
            "FROM items i %s WHERE %s ORDER BY %s %s, i.sort_title COLLATE NOCASE ASC, i.rating_key ASC" % (join, " AND ".join(where), score, direction)
        )
        rows = main.execute(sql, tuple(args)).fetchall()
        if req_offset:
            rows = rows[req_offset:]
    else:
        sql = (
            "SELECT i.rating_key,i.section_id,i.plex_type,'' AS kodi_type,i.title,'' AS original_title,i.title AS sort_title,i.year,i.summary,i.duration,i.added_at,i.updated_at,i.thumb,i.art,i.media_file,i.part_key,i.view_count,i.last_viewed_at,i.show_title,i.season,i.episode,i.parent_rating_key,i.grandparent_rating_key,0,0,0,'',i.raw_json "
            "FROM items i %s WHERE %s ORDER BY %s %s, i.sort_title COLLATE NOCASE ASC, i.rating_key ASC LIMIT ? OFFSET ?" % (join, " AND ".join(where), score, direction)
        )
        rows = main.execute(sql, tuple(args + [req_limit, req_offset])).fetchall()
    keys = [str(r[0]) for r in rows]
    return _fetch_movie_rows(main, keys)


def query_movie(section_id, sort_key, sort_dir, limit, offset, genre=None, random_seed=None):
    sid = str(section_id or "").strip()
    sort_key = pkm_library_sort.normalize_sort_key(sort_key, media_kind="movie")
    sort_dir = pkm_library_sort.normalize_sort_dir(sort_dir or pkm_library_sort.default_sort_dir(sort_key))
    t0 = time.perf_counter()
    main = _main_conn()
    try:
        if sort_key in ("cine21", "watcha", "imdb"):
            rows = _movie_rating_query(main, sid, sort_key, sort_dir, limit, offset, genre=genre)
            ms = (time.perf_counter() - t0) * 1000.0
            _log("SORT_MATRIX_QUERY_V2626 media=movie section=%s sort=%s dir=%s source=native_rating_join index_ready=na rows=%d query_ms=%.1f" % (sid, sort_key, sort_dir, len(rows), ms))
            return rows
        keys, meta = _ordered_keys(sid, "movie", sort_key, sort_dir, limit, offset, genre=genre, random_seed=random_seed)
        if keys is None:
            return None
        rows = _fetch_movie_rows(main, keys)
        ms = (time.perf_counter() - t0) * 1000.0
        _log("SORT_MATRIX_QUERY_V2626 media=movie section=%s sort=%s dir=%s source=materialized_index index_ready=1 generation=%s rows=%d query_ms=%.1f" % (sid, sort_key, sort_dir, meta.get("generation",0), len(rows), ms))
        return rows
    finally:
        main.close()


def query_tv(section_id, sort_key, sort_dir, limit, offset, genre=None, random_seed=None):
    sid = str(section_id or "").strip()
    sort_key = pkm_library_sort.normalize_sort_key(sort_key, media_kind="tv")
    sort_dir = pkm_library_sort.normalize_sort_dir(sort_dir or pkm_library_sort.default_sort_dir(sort_key))
    t0 = time.perf_counter()
    keys, meta = _ordered_keys(sid, "tv", sort_key, sort_dir, limit, offset, genre=genre, random_seed=random_seed)
    if keys is None:
        return None
    main = _main_conn()
    try:
        rows = _fetch_tv_rows(main, sid, keys)
    finally:
        main.close()
    ms = (time.perf_counter() - t0) * 1000.0
    _log("SORT_MATRIX_QUERY_V2626 media=tv section=%s sort=%s dir=%s source=materialized_index index_ready=1 generation=%s rows=%d query_ms=%.1f" % (sid, sort_key, sort_dir, meta.get("generation",0), len(rows), ms))
    return rows


def coverage_status(section_ids):
    _ensure_schema()
    out = []
    for sid in [str(x or "").strip() for x in (section_ids or []) if str(x or "").strip()]:
        main = _main_conn()
        try:
            media = _infer_media(main, sid)
        finally:
            main.close()
        ready, gen, rows, build_ms = _state_ready(sid, media)
        out.append((sid, media, 1 if ready else 0, gen, rows, build_ms))
    return out


try:
    _log("PKM_PATCH_ACTIVE v2627 full_sort_matrix_native_index_quiet_fullquery_fix")
    _log("PKM_PATCH_ACTIVE v2628 sort_fullquery_chunk_provider_index")
    _log("SORT_FULLQUERY_CHUNK_POLICY_V2628 sqlite_in_chunk=400 movie_tv=1 limit0_fullquery=1 provider_rating_indexes=1")
except Exception:
    pass
