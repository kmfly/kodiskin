# -*- coding: utf-8 -*-
"""R108 content-source wizard (first run, and Settings > 콘텐츠 소스 > 추가).

Steps
  source      Plex 서버 / Kodi 라이브러리 cards
  kodi_found  Kodi library already has items -> 이대로 사용 / 폴더 추가
  browse      PKM folder browser (Kodi video sources, drives, storage)
  content     영화 / 드라마·TV
  scan        register folder (TMDB ko-KR) + Kodi library scan with live count

run_wizard() returns:
  {"choice": "plex"}                         -> caller opens the Plex connection flow
  {"choice": "kodi", "content": ..., "path": ...}
  None                                       -> closed with back
"""
from __future__ import absolute_import, unicode_literals

import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import pkm_sources

ADDON = xbmcaddon.Addon("plugin.video.km")
XML_NAME = "plexkm_pkm_source_wizard_r108.xml"
MEDIA = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r97s/"

ACTION_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)

CARD_PLEX, CARD_KODI = 401, 402
BTN_USE, BTN_ADD = 501, 502
LIST_BROWSE = 600
BTN_MOVIES, BTN_TV = 701, 702
BTN_SCAN_DONE = 801
BTN_EXIT = 403   # R113: first-run "나가기" -> Kodi main menu


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.km] PKM_SOURCE_WIZARD_R108 %s" % msg, level)


def _fmt(n):
    try:
        return "{:,}".format(int(n))
    except Exception:
        return str(n)


def _browse_roots():
    rows, seen = [], set()

    def add(label, path, sub):
        key = (path or "").rstrip("/\\").lower()
        if not path or key in seen:
            return
        seen.add(key)
        rows.append({"kind": "dir", "label": label, "path": path, "sub": sub})

    for src in pkm_sources.kodi_video_sources():
        add(src.get("label") or src.get("file"), src.get("file") or "", "Kodi 비디오 소스")
    try:
        from resources.lib import pkm_settings_flow as sf
        for label, path in sf._kodi_file_sources_v1700():
            add(label, path, "Kodi 소스")
        for label, path in sf._local_storage_roots_v1700():
            if path.startswith("special://"):
                continue
            add(label, path, "이 기기")
    except Exception:
        _log("roots_fallback err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return rows


def _join(path, name):
    base = pkm_sources.normalize_folder(path)
    sep = "\\" if base.endswith("\\") else "/"
    return base + name.rstrip("/\\") + sep


def _list_dirs(path):
    dirs, _files = xbmcvfs.listdir(pkm_sources.normalize_folder(path))
    names = sorted([str(d).rstrip("/\\") for d in (dirs or []) if str(d).strip() and not str(d).startswith(".")],
                   key=lambda s: s.lower())
    return [{"kind": "dir", "label": n, "path": _join(path, n), "sub": ""} for n in names]


class SourceWizardDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.mode = kwargs.pop("mode", "first_run")
        self.result = None
        self._step = "source"
        self._history = []
        self._browse_stack = []      # visited folder paths ("" = roots)
        self._rows = []
        self._content_path = ""
        self._scan_thread = None
        self._scan_stop = threading.Event()
        self._closing = False
        super(SourceWizardDialog, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- setup
    def onInit(self):
        try:
            self.setProperty("PlexKM.Wiz.Header", "PKM 시작 설정" if self.mode == "first_run" else "콘텐츠 소스 추가")
            self.setProperty("PlexKM.Wiz.SourceTitle", "어디에서 콘텐츠를 불러올까요?" if self.mode == "first_run"
                             else "어떤 소스를 추가할까요?")
            self.setProperty("PlexKM.Wiz.SourceHint", "나중에 설정 › 콘텐츠 소스에서 다른 소스를 추가할 수 있습니다"
                             if self.mode == "first_run" else "추가한 소스는 홈과 검색에 함께 나옵니다")
            self.setProperty("PlexKM.Wiz.PlexConnected", "1" if (pkm_sources.has_plex() and pkm_sources.plex_credentials_ready()) else "")
            self.setProperty("PlexKM.Wiz.KodiConnected", "1" if pkm_sources.has_kodi() else "")
            self.setProperty("PlexKM.Wiz.CanExit", "1" if self.mode == "first_run" else "")
            # Adding from Settings: the already-connected Plex card is not the likely target.
            first = CARD_KODI if (self.mode != "first_run" and self.getProperty("PlexKM.Wiz.PlexConnected") == "1") else CARD_PLEX
            self._goto("source", push=False, focus=first)
            _log("open mode=%s plex=%s kodi=%s" % (self.mode, self.getProperty("PlexKM.Wiz.PlexConnected") or "0",
                                                  self.getProperty("PlexKM.Wiz.KodiConnected") or "0"))
        except Exception:
            _log("init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            self.close()

    def _goto(self, step, push=True, focus=None):
        if push and self._step != step:
            self._history.append(self._step)
        self._step = step
        dot = {"source": 1, "kodi_found": 2, "browse": 2, "content": 2, "scan": 3}.get(step, 1)
        self.setProperty("PlexKM.Wiz.Dot", str(dot))
        self.setProperty("PlexKM.Wiz.Step", step)
        target = focus or {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                           "content": BTN_MOVIES, "scan": BTN_SCAN_DONE}.get(step)
        if step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            xbmc.sleep(10)
            self.setFocusId(target)
        except Exception:
            pass

    def _refocus(self):
        target = {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                  "content": BTN_MOVIES, "scan": BTN_SCAN_DONE}.get(self._step, CARD_PLEX)
        if self._step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            self.setFocusId(target)
            _log("refocus step=%s control=%d" % (self._step, target))
        except Exception:
            pass

    def _back(self):
        if self._step == "scan":
            return  # the scan step only closes through its button
        if self._step == "browse" and self._browse_stack:
            self._browse_stack.pop()
            self._show_browse(self._browse_stack[-1] if self._browse_stack else "", push=False)
            return
        if self._history:
            prev = self._history.pop()
            self._goto(prev, push=False)
            return
        self._close(None)

    def _close(self, result):
        self.result = result
        self._closing = True
        self._scan_stop.set()
        self.close()

    # ---------------------------------------------------------------- input
    def onAction(self, action):
        try:
            if action.getId() in ACTION_BACK:
                self._back()
                return
            # Focus lost (e.g. a mouse move over empty space): any key restores it.
            if action.getId() not in (107, 100, 101, 102, 103, 104, 105, 106) and not self.getFocusId():
                self._refocus()
        except Exception:
            _log("action_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def onClick(self, controlId):
        try:
            if controlId == BTN_EXIT:
                _log("choice=exit_to_kodi")
                self._close({"choice": "exit"})
                return
            if controlId == CARD_PLEX:
                _log("choice=plex")
                self._close({"choice": "plex"})
            elif controlId == CARD_KODI:
                self._show_kodi_found()
            elif controlId == BTN_USE:
                pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_LIBRARY, "", label="Kodi 라이브러리",
                                            reason="wizard_use_existing")
                self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_LIBRARY, "path": ""})
            elif controlId == BTN_ADD:
                self._browse_stack = []
                self._show_browse("", push=True)
            elif controlId == LIST_BROWSE:
                self._browse_click()
            elif controlId in (BTN_MOVIES, BTN_TV):
                content = pkm_sources.KODI_CONTENT_MOVIES if controlId == BTN_MOVIES else pkm_sources.KODI_CONTENT_TVSHOWS
                self._start_scan(content)
            elif controlId == BTN_SCAN_DONE:
                self._close(getattr(self, "_scan_result", None))
        except Exception:
            _log("click_failed control=%s %s" % (controlId, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)

    # ---------------------------------------------------------------- kodi
    def _show_kodi_found(self):
        movies, shows = pkm_sources.kodi_library_counts()
        has = (movies + shows) > 0
        self.setProperty("PlexKM.Wiz.FoundHasItems", "1" if has else "")
        if has:
            parts = []
            if movies:
                parts.append("영화 %s편" % _fmt(movies))
            if shows:
                parts.append("드라마 %s개" % _fmt(shows))
            self.setProperty("PlexKM.Wiz.FoundTitle", "Kodi 라이브러리를 찾았습니다")
            self.setProperty("PlexKM.Wiz.FoundSub", " · ".join(parts) + "\n이대로 쓰거나 폴더를 더 추가할 수 있습니다")
            self.setProperty("PlexKM.Wiz.FoundUse", "이대로 사용")
        else:
            self.setProperty("PlexKM.Wiz.FoundTitle", "영상 폴더를 추가하세요")
            self.setProperty("PlexKM.Wiz.FoundSub", "영화나 드라마가 들어 있는 폴더를 고르면\n정보와 포스터를 자동으로 가져옵니다")
        _log("kodi_found movies=%d shows=%d" % (movies, shows))
        self._goto("kodi_found")

    def _show_browse(self, path, push=False):
        self.setProperty("PlexKM.Wiz.Busy", "1")
        rows = []
        try:
            if not path:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", "저장소")
                rows = _browse_roots()
                rows.append({"kind": "manual", "label": "네트워크 경로 직접 입력", "path": "",
                             "sub": "smb:// · nfs://"})
            else:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", path)
                rows = [{"kind": "select", "label": "이 폴더 선택", "path": path, "sub": ""},
                        {"kind": "up", "label": "상위 폴더", "path": "", "sub": ""}]
                try:
                    rows += _list_dirs(path)
                except Exception:
                    rows.append({"kind": "none", "label": "폴더를 열 수 없습니다", "path": "", "sub": ""})
        finally:
            self.setProperty("PlexKM.Wiz.Busy", "")
        self._rows = rows
        items = []
        for row in rows:
            li = xbmcgui.ListItem(label=row["label"], label2=row.get("sub", ""))
            icon = {"select": "check_32.png", "up": "up_32.png", "manual": "cat_server_48.png"}.get(row["kind"], "cat_folder_48.png")
            li.setArt({"icon": MEDIA + icon})
            items.append(li)
        lst = self.getControl(LIST_BROWSE)
        lst.reset()
        lst.addItems(items)
        if self._step != "browse":
            self._goto("browse", push=push)
        else:
            self.setFocusId(LIST_BROWSE)
        lst.selectItem(0)

    def _browse_click(self):
        try:
            pos = int(self.getControl(LIST_BROWSE).getSelectedPosition())
            row = self._rows[pos]
        except Exception:
            return
        kind = row.get("kind")
        if kind == "dir":
            self._browse_stack.append(row["path"])
            self._show_browse(row["path"])
        elif kind == "up":
            self._back()
        elif kind == "manual":
            self._manual_path()
        elif kind == "select":
            self._content_path = pkm_sources.normalize_folder(row["path"])
            self.setProperty("PlexKM.Wiz.ContentPath", self._content_path)
            self._goto("content")

    def _manual_path(self):
        """smb:// or nfs:// share typed by the user (PKM-skinned Kodi keyboard)."""
        last = getattr(self, "_manual_last", "") or "smb://"
        try:
            text = xbmcgui.Dialog().input("네트워크 경로 (예: smb://192.168.0.10/video)", last,
                                          type=xbmcgui.INPUT_ALPHANUM)
        except Exception:
            text = ""
        text = str(text or "").strip()
        if not text or text in ("smb://", "nfs://"):
            self.setFocusId(LIST_BROWSE)
            return
        if "://" not in text:
            text = "smb://" + text.lstrip("/\\")
        self._manual_last = text
        path = pkm_sources.normalize_folder(text)
        ok = False
        try:
            dirs, files = xbmcvfs.listdir(path)
            ok = bool(dirs or files) or xbmcvfs.exists(path)
        except Exception:
            ok = False
        if not ok:
            _log("manual_path_unreachable")
            try:
                from resources.lib import pkm_notify
                pkm_notify.pkm_show_notice("폴더 추가", "그 경로를 열 수 없습니다",
                                           "주소와 공유 폴더 권한을 확인하세요", ms=3200)
            except Exception:
                pass
            self.setFocusId(LIST_BROWSE)
            return
        _log("manual_path_ok scheme=%s" % path.split("://", 1)[0])
        self._browse_stack.append(path)
        self._show_browse(path)

    # ---------------------------------------------------------------- scan
    def _start_scan(self, content):
        path = self._content_path
        label = path.rstrip("/\\").replace("\\", "/").split("/")[-1] or path
        pkm_sources.add_kodi_source(content, path, label=label, reason="wizard_folder")
        registered = pkm_sources.kodi_register_path(path, content)
        kind = "영화" if content == pkm_sources.KODI_CONTENT_MOVIES else "드라마"
        self._scan_result = {"choice": "kodi", "content": content, "path": path}
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
        self.setProperty("PlexKM.Wiz.ScanSub", "%s\n창을 닫아도 스캔은 계속됩니다" % label)
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        if not registered:
            self._scan_finish(kind, 0, failed=True)
            return
        before = pkm_sources.kodi_library_counts()
        pkm_sources.kodi_scan(path)
        self._scan_stop.clear()
        self._scan_thread = threading.Thread(target=self._scan_watch, args=(kind, content, before),
                                             name="PKMSourceWizardScanR108")
        self._scan_thread.daemon = True
        self._scan_thread.start()

    def _scan_watch(self, kind, content, before):
        idx = 0 if content == pkm_sources.KODI_CONTENT_MOVIES else 1
        started = False
        t0 = time.time()
        monitor = xbmc.Monitor()
        added = 0
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            scanning = pkm_sources.kodi_scanning()
            started = started or scanning
            now = pkm_sources.kodi_library_counts()
            added = max(0, now[idx] - before[idx])
            unit = "편" if idx == 0 else "개"
            if scanning:
                self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
                self.setProperty("PlexKM.Wiz.ScanSub", "지금까지 %s %s%s 추가됨\n창을 닫아도 스캔은 계속됩니다" % (kind, _fmt(added), unit))
            if (started and not scanning) or (not started and time.time() - t0 > 8):
                break
            if monitor.waitForAbort(1.0):
                return
        if not self._scan_stop.is_set():
            self._scan_finish(kind, added)

    def _scan_finish(self, kind, added, failed=False):
        unit = "편" if kind == "영화" else "개"
        self.setProperty("PlexKM.Wiz.ScanDone", "1")
        if failed:
            self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 등록하지 못했습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "Kodi 비디오 데이터베이스를 열 수 없습니다")
        elif added:
            self.setProperty("PlexKM.Wiz.ScanTitle", "%s %s%s%s 추가했습니다" % (kind, _fmt(added), unit, "을" if unit == "편" else "를"))
            self.setProperty("PlexKM.Wiz.ScanSub", "")
        else:
            self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "새로 찾은 %s가 없습니다\n폴더 이름이 작품 제목과 같은지 확인하세요" % kind)
        self.setProperty("PlexKM.Wiz.ScanButton", "완료")
        _log("scan_done kind=%s added=%d failed=%s" % (kind, added, "1" if failed else "0"))


def run_wizard(mode="first_run"):
    dlg = None
    try:
        dlg = SourceWizardDialog(XML_NAME, ADDON.getAddonInfo("path"), "Default", "1080i", mode=mode)
        dlg.doModal()
        result = dlg.result
        _log("closed mode=%s result=%s" % (mode, (result or {}).get("choice", "none")))
        return result
    except Exception:
        _log("run_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass
