# -*- coding: utf-8 -*-
"""Lightweight entry point for PKM quick seek keymap.

This file is intentionally tiny.  FullscreenVideo LEFT/RIGHT launches this
script instead of the heavy default.py router, so the quick-seek property is set
as early as possible and the full VideoOSD is suppressed quickly.
"""
from __future__ import absolute_import, unicode_literals

import sys
import traceback

import xbmc

ADDON_ID = "plugin.video.km"


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][seek_quick] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _parse_args(argv):
    params = {}
    for arg in argv[1:]:
        if arg is None:
            continue
        text = str(arg)
        if text.startswith('?'):
            text = text[1:]
        for part in text.split('&'):
            part = part.strip()
            if not part:
                continue
            if '=' in part:
                k, v = part.split('=', 1)
                params[k.strip()] = v.strip()
            else:
                params[part.strip()] = '1'
    return params


def main():
    params = _parse_args(sys.argv)
    try:
        import pkm_seek_quick
        if str(params.get("mode", "")).lower() in ("preread", "pre_read", "cache", "precache") or str(params.get("preread", "")) == "1":
            _log("PKM_MANUAL_PREREAD_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
            pkm_seek_quick.manual_preread(params)
            return

        if params.get("menu") or params.get("step_menu"):
            _log("PKM_SEEK_STEP_MENU_ENTRY_DISPATCH_V1460 params=%s argv=%s" % (params, sys.argv))
            if hasattr(pkm_seek_quick, "show_step_menu"):
                pkm_seek_quick.show_step_menu(params)
            return

        if params.get("key") or params.get("action"):
            _log("PKM_PLAYER_KEY_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
            pkm_seek_quick.handle_player_key(params)
            return

        # R287: hold-to-speed for remotes without FF/REW keys.  A held key arrives as
        # repeated *_short events 0.2-1.0 s apart (RunScript start-up jitter), so:
        #  - the first same-direction repeat within 0.8 s starts Kodi's native FF/REW;
        #    that script instance stays alive as the "release watcher";
        #  - later repeats only refresh a heartbeat; the speed ramps by HELD TIME
        #    (2x, then 4x/8x/16x after 1.0/2.0/3.2 s), never by the number of queued events;
        #  - no event for 0.85 s = released: back to normal speed;
        #  - late queued repeats arriving right after release are swallowed (no seek,
        #    no restart), so nothing "accumulates" after the finger is lifted;
        #  - a separate tap while speeding returns to normal speed (no seek).
        try:
            src_r283 = str(params.get("source", ""))
            if src_r283.endswith("_short") and params.get("delta"):
                import time as _t287
                import xbmcgui
                w287 = xbmcgui.Window(10000)

                def _f287(key):
                    try:
                        return float(w287.getProperty(key) or 0)
                    except Exception:
                        return 0.0

                d287 = "fwd" if float(params.get("delta") or 0) > 0 else "rew"
                cmd287 = "Forward" if d287 == "fwd" else "Rewind"
                now287 = _t287.time()
                last287 = _f287("PlexKM.HoldChain.Last")
                prev287 = w287.getProperty("PlexKM.HoldChain.Dir")
                active287 = w287.getProperty("PlexKM.HoldChain.Active") == "1"
                ended287 = _f287("PlexKM.HoldChain.EndedAt")
                if active287:
                    if prev287 == d287 and now287 - last287 <= 1.3:
                        w287.setProperty("PlexKM.HoldChain.Last", repr(now287))
                        held_for = now287 - _f287("PlexKM.HoldChain.Start")
                        target = 1 + (1 if held_for >= 1.0 else 0) + (1 if held_for >= 2.0 else 0) + (1 if held_for >= 3.2 else 0)
                        lvl = int(_f287("PlexKM.HoldChain.Level"))
                        while lvl < target and lvl < 4:
                            xbmc.executebuiltin("PlayerControl(%s)" % cmd287)
                            lvl += 1
                            xbmc.sleep(60)
                        w287.setProperty("PlexKM.HoldChain.Level", str(lvl))
                        return
                    # separate tap / other direction while speeding: back to normal speed
                    w287.setProperty("PlexKM.HoldChain.Active", "0")
                    w287.setProperty("PlexKM.HoldChain.EndedAt", repr(now287))
                    w287.setProperty("PlexKM.HoldChain.Last", repr(now287))
                    if xbmc.getCondVisibility("Player.Forwarding | Player.Rewinding"):
                        xbmc.executebuiltin("PlayerControl(Play)")
                    _log("PKM_HOLD_TAP_STOP_R287 dir=%s" % d287)
                    return
                if ended287 > 0 and prev287 == d287 and 0 <= now287 - ended287 <= 1.5:
                    _log("PKM_HOLD_LATE_REPEAT_SWALLOWED_R287 dir=%s late_ms=%d" % (d287, int((now287 - ended287) * 1000)))
                    return
                held287 = (prev287 == d287 and 0 < now287 - last287 <= 0.8)
                w287.setProperty("PlexKM.HoldChain.Dir", d287)
                w287.setProperty("PlexKM.HoldChain.Last", repr(now287))
                if held287 and not xbmc.getCondVisibility("Player.Forwarding | Player.Rewinding"):
                    w287.setProperty("PlexKM.HoldChain.Active", "1")
                    w287.setProperty("PlexKM.HoldChain.Start", repr(now287))
                    w287.setProperty("PlexKM.HoldChain.Level", "1")
                    xbmc.executebuiltin("PlayerControl(%s)" % cmd287)
                    _log("PKM_HOLD_START_R287 dir=%s source=%s gap_ms=%d" % (d287, src_r283, int((now287 - last287) * 1000)))
                    # release watcher: this instance lives until the heartbeat stops
                    t_stop287 = now287 + 120.0
                    while _t287.time() < t_stop287:
                        xbmc.sleep(100)
                        if w287.getProperty("PlexKM.HoldChain.Active") != "1":
                            return
                        if _t287.time() - _f287("PlexKM.HoldChain.Last") > 0.85:
                            break
                    if w287.getProperty("PlexKM.HoldChain.Active") == "1":
                        w287.setProperty("PlexKM.HoldChain.Active", "0")
                        w287.setProperty("PlexKM.HoldChain.EndedAt", repr(_t287.time()))
                        if xbmc.getCondVisibility("Player.Forwarding | Player.Rewinding"):
                            xbmc.executebuiltin("PlayerControl(Play)")
                        _log("PKM_HOLD_END_R287 dir=%s held_ms=%d level=%d" % (
                            d287, int((_t287.time() - now287) * 1000), int(_f287("PlexKM.HoldChain.Level"))))
                    return
        except Exception:
            _log("PKM_HOLD_FAILED_R287\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        # Seek-only path: keep VideoOSD from staying on top if Kodi opened it
        # for a fullscreen arrow key.  Do not close the real VideoOSD when the
        # request came from a VideoOSD button; buttons must remain alive after
        # quick seek and long jump clicks.
        if str(params.get("use_videoosd", "")) != "1":
            try:
                xbmc.executebuiltin('Dialog.Close(videoosd,true)')
            except Exception:
                pass
        _log("PKM_SEEK_QUICK_ENTRY_DISPATCH params=%s argv=%s" % (params, sys.argv))
        pkm_seek_quick.request(params)
    except Exception:
        _log("PKM_SEEK_QUICK_ENTRY_FAILED params=%s\n%s" % (params, traceback.format_exc()), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
