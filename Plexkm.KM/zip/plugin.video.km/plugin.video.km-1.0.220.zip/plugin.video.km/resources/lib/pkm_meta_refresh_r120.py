# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""R120: fill in missing metadata for ONE movie/show through its agent.

User-triggered only (card menu).  Runs entirely on a worker thread: it never
touches a ListItem; the caller applies the returned item to the card.

Plex item  -> ask the Plex server's agent, but NEVER apply a guess:
              plex_candidates() searches with title + year (GET .../matches) and
              changes nothing; the user picks the right one in a list; only then
              plex_apply() fixes the match (PUT .../match, or .../refresh when the
              pick is the current match), polls the item and rewrites just that
              row.  No pick / cancel = the item stays exactly as it was.
Kodi item  -> VideoLibrary.RefreshMovie / RefreshTVShow (the configured
              scraper), poll, then pkm_kodi_source.sync_one().

refresh() returns {"ok", "code", "message", "item", "filled", "action"}.
"""

import re
import sqlite3
import threading
import time
import traceback
try:
    from urllib.parse import quote
except Exception:  # pragma: no cover
    from urllib import quote

try:
    import xbmc
except Exception:  # unit tests run outside Kodi
    xbmc = None

COOLDOWN_SEC = 30
MAX_CANDIDATES = 6
POLL_INTERVAL = 2.0
POLL_TIMEOUT = 30.0
SETTLE_SEC = 3.0
_FIELDS = ("title", "year", "summary", "thumb")

_lock = threading.Lock()
_last = {}        # rating_key -> monotonic time of the last request
_running = set()  # rating keys with a request in flight


def _log(msg, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log("[plugin.video.km] META_REFRESH_R120 %s" % msg, xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


# ------------------------------------------------------------------ cooldown
def begin(rating_key):
    """-> (True, 0) and marks the item busy, or (False, seconds_left)."""
    rk = str(rating_key)
    now = time.time()
    with _lock:
        if rk in _running:
            return False, COOLDOWN_SEC
        left = COOLDOWN_SEC - (now - _last.get(rk, 0.0))
        if left > 0:
            return False, int(left) + 1
        _running.add(rk)
        _last[rk] = now
        return True, 0


def end(rating_key):
    with _lock:
        _running.discard(str(rating_key))
        _last[str(rating_key)] = time.time()


# ------------------------------------------------------------------ helpers
def _norm(text):
    return re.sub(r"[\W_]+", "", str(text or "").lower(), flags=re.U)


def _int(value):
    try:
        return int(float(value or 0))
    except Exception:
        return 0


def _snapshot(item):
    return tuple(str(item.get(k) or "") for k in _FIELDS)


def _filled(before, after):
    """Fields that were empty (or, for the title, different) and now have a value."""
    out = []
    for key in _FIELDS:
        b, a = str(before.get(key) or ""), str(after.get(key) or "")
        if key == "year":
            b, a = ("" if _int(b) <= 0 else b), ("" if _int(a) <= 0 else a)
        if a and a != b and (key == "title" or not b):
            out.append(key)
    return out


def _fail(code, message):
    return {"ok": False, "code": code, "message": message, "item": None, "filled": [], "action": ""}


def _classify(exc):
    text = str(exc)
    if "HTTP error 401" in text or "HTTP error 403" in text:
        return _fail("auth", "Plex 편집 권한이 없습니다")
    if "HTTP error 404" in text:
        return _fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다")
    if "connection error" in text or "timed out" in text or "request failed" in text:
        return _fail("network", "Plex 서버에 연결하지 못했습니다")
    return _fail("error", "메타 갱신에 실패했습니다")


def _row(conn, rating_key):
    r = conn.execute("SELECT rating_key, section_id, plex_type, title, year, summary, thumb, raw_json, original_title "
                     "FROM items WHERE rating_key=?", (str(rating_key),)).fetchone()
    if not r:
        return None
    guid = ""
    try:
        import json
        guid = str((json.loads(r[7] or "{}")).get("guid") or "")
    except Exception:
        pass
    return {"rating_key": r[0], "section_id": str(r[1] or ""), "plex_type": r[2], "title": r[3] or "",
            "year": r[4] or 0, "summary": r[5] or "", "thumb": r[6] or "", "guid": guid,
            "original_title": r[8] or ""}


# ------------------------------------------------------------------ Plex
def needs_match(guid, summary="", thumb=""):
    """An item the agent never matched: local guid, no agent, or nothing filled in."""
    g = str(guid or "").lower()
    if not g or g.startswith("local://") or "agents.none" in g:
        return True
    return not str(summary or "").strip() and not str(thumb or "").strip()


def pick_match(results, title, year):
    """results: [{"guid","name","year","score"}] -> the one safe candidate or None.

    Safe = same title (ignoring case/spaces/punctuation) AND same year.  When
    several qualify, the highest agent score wins.  Anything looser is left
    to the user (Plex's own Fix Match), never applied automatically.
    """
    want_t, want_y = _norm(title), _int(year)
    if not want_t or want_y <= 0:
        return None
    best = None
    for r in results or []:
        if _norm(r.get("name")) != want_t or _int(r.get("year")) != want_y or not r.get("guid"):
            continue
        if best is None or _int(r.get("score")) > _int(best.get("score")):
            best = r
    return best


def _plex_node(core, rating_key):
    root = core.plex_request_xml("/library/metadata/%s" % rating_key, params={"skipRefresh": 1},
                                 timeout=10, log_failures=False, bypass_cache=True)
    for child in list(root):
        if child.tag in ("Video", "Directory"):
            return child
    return None


def _plex_agent(core, section_id, plex_type="", guid=""):
    """The section's metadata agent.  /library/sections lists it per Directory
    (the single-section response does not); fall back to the new Plex agent
    for the item's type when the item already carries a plex:// guid."""
    try:
        root = core.plex_request_xml("/library/sections", timeout=8, log_failures=False)
        for child in list(root):
            if str(child.get("key") or "") == str(section_id) and child.get("agent"):
                return child.get("agent")
    except Exception:
        pass
    if str(guid or "").startswith("plex://"):
        return {"movie": "tv.plex.agents.movie", "show": "tv.plex.agents.series"}.get(str(plex_type), "")
    return ""


def _param_variants(agent):
    """Parameter sets for GET .../matches, most specific first.  Plex answers an
    unsuitable language/agent combination with an EMPTY list (not an error), so
    the next looser variant is tried before giving up."""
    out = []
    if agent:
        out.append({"agent": agent, "language": "ko-KR"})
        out.append({"agent": agent})
    out.append({"language": "ko-KR"})
    out.append({})
    return out


def _title_variants(title, original_title, year):
    """(title, year) pairs to search, best first, without duplicates."""
    t = str(title or "").strip()
    base = re.sub(r"\s*[\(\[]\s*(19|20)\d{2}\s*[\)\]]\s*$", "", t)           # "제목 (2019)"
    base = re.sub(r"\s*(시즌|season)\s*\d+\s*$", "", base, flags=re.I | re.U)      # "제목 시즌 2"
    head = re.split(r"\s*[:：\-–]\s*", base, maxsplit=1)[0] if re.search(r"[:：]", base) else ""
    y = _int(year)
    cands = [(t, y), (t, 0), (base, y), (head, y), (str(original_title or "").strip(), y), (str(original_title or "").strip(), 0)]
    seen, out = set(), []
    for name, yy in cands:
        key = (_norm(name), yy)
        if name and key not in seen:
            seen.add(key)
            out.append((name, yy))
    return out


def _plex_matches_once(core, rating_key, title, year, variant):
    params = {"manual": 1, "title": title}
    if _int(year) > 0:
        params["year"] = _int(year)
    params.update(variant)
    root = core.plex_request_xml("/library/metadata/%s/matches" % rating_key, params=params,
                                 timeout=20, log_failures=False, bypass_cache=True)
    res = [{"guid": n.get("guid", ""), "name": n.get("name", ""), "year": n.get("year", ""), "score": n.get("score", "0")}
           for n in list(root) if n.tag == "SearchResult"]
    _log("MATCH_TRY rating_key=%s title=%r year=%s variant=%s results=%d root=%s children=%s" % (
        rating_key, title, params.get("year", "-"), ",".join(sorted(variant)) or "bare", len(res),
        getattr(root, "tag", ""), ",".join(sorted(set(n.tag for n in list(root)))) or "-"))
    return res


def _plex_matches(core, rating_key, title, year, agent, original_title=""):
    """Try title/parameter variants until the agent returns candidates."""
    variants = _param_variants(agent)
    for name, yy in _title_variants(title, original_title, year):
        for v in variants:
            res = _plex_matches_once(core, rating_key, name, yy, v)
            if res:
                return res
    return []


# ------------------------------------------------------------------ TMDB (primary)
_TMDB_PROPS = ["title", "originaltitle", "year", "plot", "art", "thumbnail", "uniqueid"]
_TMDB_PREFIX = "tmdb:"


def _tmdb_poster(item):
    art = item.get("art") or {}
    url = ""
    if isinstance(art, dict):
        url = art.get("poster") or art.get("thumb") or ""
    url = url or item.get("thumbnail") or ""
    url = str(url or "")
    return url if url.startswith("http") else ""


def _tmdb_search_once(dir_fn, tmdb_type, title, year):
    directory = "plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=%s&query=%s" % (
        tmdb_type, quote(str(title or ""), safe=""))
    if _int(year) > 0:
        directory += "&year=%d" % _int(year)
    try:
        items, lang = dir_fn(directory, _TMDB_PROPS, 41120)
    except Exception as exc:
        _log("TMDB_TRY title=%r year=%s type=%s error=%s" % (title, year or "-", tmdb_type, exc))
        return []
    res = []
    for it in items or []:
        tid = str(((it.get("uniqueid") or {}).get("tmdb")) or "")
        if not tid or not it.get("title"):
            continue
        res.append({"guid": _TMDB_PREFIX + tid, "tmdb_id": tid, "name": str(it.get("title") or ""),
                    "original_title": str(it.get("originaltitle") or ""), "year": _int(it.get("year")) or "",
                    "summary": str(it.get("plot") or ""), "thumb": _tmdb_poster(it), "score": "0"})
    _log("TMDB_TRY title=%r year=%s type=%s lang=%s results=%d" % (title, year or "-", tmdb_type, lang, len(res)))
    return res


def tmdb_matches(dir_fn, plex_type, title, original_title, year):
    """TMDB candidates through TMDb Helper (Korean).  Same title/year variants as the agent search."""
    tmdb_type = "tv" if str(plex_type) == "show" else "movie"
    for name, yy in _title_variants(title, original_title, year):
        res = _tmdb_search_once(dir_fn, tmdb_type, name, yy)
        if res:
            return res
    return []


def _tmdb_apply(core, row, candidate):
    """Local-only: write the chosen TMDB title/year/plot/poster into plex_km.db for this one row."""
    rk = str(row["rating_key"])
    conn = core.init_db()
    try:
        cur = _row(conn, rk)
        if not cur:
            return _fail("not_found", "항목을 찾지 못했습니다")
        before = dict(cur)
        item = dict(cur)
        item["title"] = candidate.get("name") or cur["title"]
        item["year"] = _int(candidate.get("year")) or cur["year"]
        item["summary"] = candidate.get("summary") or cur["summary"]
        item["thumb"] = candidate.get("thumb") or cur["thumb"]
        item["original_title"] = candidate.get("original_title") or cur.get("original_title") or ""
        conn.execute("UPDATE items SET title=?, year=?, summary=?, thumb=?, original_title=? WHERE rating_key=?",
                     (item["title"], _int(item["year"]), item["summary"], item["thumb"], item["original_title"], rk))
        conn.commit()
    finally:
        conn.close()
    try:
        sc = sqlite3.connect(core.search_db_path(), timeout=5.0)
        try:
            core.upsert_search_index_item(sc, item, section_title="")
            sc.commit()
        finally:
            sc.close()
    except Exception:
        pass
    filled = _filled(before, item)
    _log("TMDB_APPLY rating_key=%s tmdb=%s filled=%s" % (rk, candidate.get("tmdb_id"), ",".join(filled)))
    return {"ok": True, "code": "updated" if filled else "unchanged", "action": "tmdb", "item": item, "filled": filled,
            "message": ("TMDB 메타를 적용했습니다 · " + _label(filled)) if filled else "TMDB 메타가 이미 같은 값입니다"}


def plex_candidates(core, rating_key, dir_fn=None):
    """Search the item's agent with its title and year.  Applies NOTHING.

    -> {"ok", "row", "guid", "candidates": [...], "message"}; each candidate is
    {"guid","name","year","score","exact","current"} (best first, at most MAX_CANDIDATES).
    The caller shows them and only plex_apply() changes anything, after the user picked one.
    """
    try:
        conn = core.init_db()
        try:
            row = _row(conn, rating_key)
        finally:
            conn.close()
        if not row:
            return dict(_fail("not_found", "항목을 찾지 못했습니다"), candidates=[], row=None, guid="")
        node = _plex_node(core, rating_key)
        if node is None:
            return dict(_fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다"), candidates=[], row=row, guid="")
        guid = node.get("guid") or ""
        title = row["title"] or node.get("title") or ""
        year = row["year"] or node.get("year")
        raw = []
        if dir_fn is not None:  # TMDB is the primary source
            raw = tmdb_matches(dir_fn, row.get("plex_type"), title, row.get("original_title"), year)
        if not raw:  # the Plex agent is only an optional fallback
            agent = _plex_agent(core, row["section_id"], row.get("plex_type"), guid)
            _log("CANDIDATE_SEARCH rating_key=%s title=%r year=%s agent=%s" % (rating_key, title, year, agent or "-"))
            try:
                raw = _plex_matches(core, rating_key, title, year, agent, row.get("original_title"))
            except Exception:
                _log("AGENT_FALLBACK_FAILED rating_key=%s" % rating_key)
                raw = []
        safe = pick_match(raw, title, year)
        out = []
        for r in raw:
            if not r.get("guid"):
                continue
            c = dict(r)
            c["exact"] = _norm(r.get("name")) == _norm(title) and _int(r.get("year")) == _int(year) > 0
            c["current"] = r["guid"] == guid
            out.append(c)
        out.sort(key=lambda c: (not c["exact"], -_int(c.get("score"))))
        out = out[:MAX_CANDIDATES]
        _log("CANDIDATES rating_key=%s found=%d shown=%d exact=%s" % (rating_key, len(raw), len(out), "1" if safe else "0"))
        return {"ok": True, "code": "candidates" if out else "no_candidates", "row": row, "guid": guid,
                "candidates": out, "message": "" if out else "TMDB·에이전트 모두 후보를 찾지 못했습니다"}
    except Exception as exc:
        _log("CANDIDATES_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace("\n", " | ")))
        return dict(_classify(exc), candidates=[], row=None, guid="")


def plex_apply(core, row, candidate, base_guid="", sleep=time.sleep, clock=time.time):
    """The user confirmed ``candidate``: fix the match (or just refresh when it is the
    current match), wait for the server, rewrite only this item's row."""
    rk, sid = row["rating_key"], row["section_id"]
    section_type = row["plex_type"]
    if str(candidate.get("guid") or "").startswith(_TMDB_PREFIX):
        try:
            return _tmdb_apply(core, row, candidate)
        except Exception as exc:
            _log("TMDB_APPLY_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
            return _fail("error", "메타 갱신에 실패했습니다")
    try:
        node = _plex_node(core, rk)
        if node is None:
            return _fail("not_found", "Plex 서버에서 항목을 찾지 못했습니다")
        base = core.extract_item(node, sid, section_type)
        base_sig = _snapshot(base) + (node.get("guid") or "", node.get("updatedAt") or "")
        if candidate["guid"] == (node.get("guid") or base_guid):
            action = "refresh"
            core.plex_request("/library/metadata/%s/refresh" % rk, params={"force": 1}, timeout=20, method="PUT")
        else:
            action = "match"
            core.plex_request("/library/metadata/%s/match" % rk,
                              params={"guid": candidate["guid"], "name": candidate["name"], "year": candidate["year"]},
                              timeout=20, method="PUT")
        deadline = clock() + POLL_TIMEOUT
        item, changed_at = None, None
        while clock() < deadline:
            sleep(POLL_INTERVAL)
            node = _plex_node(core, rk)
            if node is None:
                continue
            cur = core.extract_item(node, sid, section_type)
            sig = _snapshot(cur) + (node.get("guid") or "", node.get("updatedAt") or "")
            if sig != base_sig:
                item = cur
                if changed_at is None:
                    changed_at = clock()
                elif clock() - changed_at >= SETTLE_SEC:
                    break
            elif changed_at is not None:
                break
        if item is None:
            return {"ok": True, "code": "unchanged", "action": action, "item": None, "filled": [],
                    "message": "갱신 요청을 보냈지만 변화가 없습니다"}
        _store_plex(core, row, item)
        filled = _filled(base, item)
        return {"ok": True, "code": "updated" if filled else "unchanged", "action": action, "item": item,
                "filled": filled,
                "message": ("메타를 갱신했습니다 · " + _label(filled)) if filled else "메타가 갱신됐지만 빈 항목은 그대로입니다"}
    except Exception as exc:
        _log("PLEX_APPLY_FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
        return _classify(exc)


def _store_plex(core, row, item):
    conn = core.init_db()
    try:
        core.upsert_item(conn, item)
        conn.commit()
    finally:
        conn.close()
    try:  # search index follows the (possibly new) title
        sc = sqlite3.connect(core.search_db_path(), timeout=5.0)
        try:
            core.upsert_search_index_item(sc, item, section_title="")
            sc.commit()
        finally:
            sc.close()
    except Exception:
        pass


# ------------------------------------------------------------------ Kodi
def _kodi_signature(item):
    return _snapshot(item)


def _kodi_refresh(rating_key, sleep=time.sleep, clock=time.time, src=None):
    if src is None:
        from resources.lib import pkm_kodi_source as src
    kind, num = src.kodi_id(rating_key)
    if kind == "movie":
        method, idkey = "VideoLibrary.RefreshMovie", "movieid"
    elif kind == "show":
        method, idkey = "VideoLibrary.RefreshTVShow", "tvshowid"
    else:
        return _fail("unsupported", "이 항목은 새로고침할 수 없습니다")
    try:
        before = _kodi_read(src, kind, num)
        if before is None:
            return _fail("not_found", "Kodi 라이브러리에서 항목을 찾지 못했습니다")
        if src._jsonrpc(method, {idkey: num, "ignorenfo": False}) is None:
            return _fail("kodi_unavailable", "Kodi 스크레이퍼 새로고침을 시작하지 못했습니다")
        deadline = clock() + POLL_TIMEOUT
        item, changed_at = None, None
        while clock() < deadline:
            sleep(POLL_INTERVAL)
            cur = _kodi_read(src, kind, num)
            if cur is None:
                continue
            if _kodi_signature(cur) != _kodi_signature(before):
                item = cur
                if changed_at is None:
                    changed_at = clock()
                elif clock() - changed_at >= SETTLE_SEC:
                    break
            elif changed_at is not None:
                break
        if item is None:
            return {"ok": True, "code": "unchanged", "action": "refresh", "item": None, "filled": [],
                    "message": "새로 받은 메타가 없습니다 (Kodi 스크레이퍼 설정을 확인하세요)"}
        stored = src.sync_one(rating_key) or item
        filled = _filled(before, stored)
        return {"ok": True, "code": "updated" if filled else "unchanged", "action": "refresh", "item": stored,
                "filled": filled,
                "message": ("메타를 갱신했습니다 · " + _label(filled)) if filled else "메타가 갱신됐지만 빈 항목은 그대로입니다"}
    except Exception:
        _log("KODI_FAILED rating_key=%s err=%s" % (rating_key, traceback.format_exc().replace("\n", " | ")))
        return _fail("error", "메타 갱신에 실패했습니다")


def _kodi_read(src, kind, num):
    if kind == "movie":
        res = src._jsonrpc("VideoLibrary.GetMovieDetails", {"movieid": num, "properties": src.MOVIE_PROPS}) or {}
        det, build = res.get("moviedetails"), src._movie_rows
    else:
        res = src._jsonrpc("VideoLibrary.GetTVShowDetails", {"tvshowid": num, "properties": src.SHOW_PROPS}) or {}
        det, build = res.get("tvshowdetails"), src._show_rows
    return build(det)[0] if det else None


# ------------------------------------------------------------------ entry
_LABELS = {"title": "제목", "year": "연도", "summary": "줄거리", "thumb": "포스터"}


def _label(fields):
    return "·".join(_LABELS.get(f, f) for f in fields)


def refresh(core, rating_key):
    """Kodi worker entry (scraper refresh).  Plex items go through plex_candidates()
    + plex_apply() so the user confirms the match first."""
    rk = str(rating_key)
    try:
        res = _kodi_refresh(rk) if rk.startswith("k:") else _fail("unsupported", "이 항목은 후보 확인이 필요합니다")
    except Exception:
        _log("FAILED rating_key=%s err=%s" % (rk, traceback.format_exc().replace("\n", " | ")))
        res = _fail("error", "메타 갱신에 실패했습니다")
    _log("DONE rating_key=%s code=%s action=%s filled=%s" % (rk, res.get("code"), res.get("action"), ",".join(res.get("filled") or [])))
    return res
