# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import time
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import pkm_cine21_import
from resources.lib import pkm_watcha_import

ADDON_ID = "plugin.video.km"
STATE_NAME = "ratings_service_bridge.json"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] [RATINGS_SERVICE_BRIDGE_V2374] %s" % (ADDON_ID, msg), level)


def _profile():
    p = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


def _state_path():
    return os.path.join(_profile(), STATE_NAME)


def _read_state():
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            x = json.load(f)
        return x if isinstance(x, dict) else {}
    except Exception:
        return {}


def _write_state(data):
    p = _state_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def _service_state():
    win = xbmcgui.Window(10000)
    state_file = win.getProperty("PKM.Ratings.StateFile") or ""
    if not state_file or not os.path.isfile(state_file):
        state_file = xbmcvfs.translatePath(
            "special://profile/addon_data/service.pkm.ratings/state.json"
        )
    try:
        with open(state_file, "r", encoding="utf-8") as f:
            state = json.load(f)
        return state if isinstance(state, dict) else {}
    except Exception:
        return {}


def _items_ready(conn):
    try:
        has = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='items'"
        ).fetchone()
        if not has:
            return False
        row = conn.execute(
            "SELECT COUNT(*) FROM items WHERE "
            "(plex_type='movie' OR kodi_type='movie')"
        ).fetchone()
        return bool(row and int(row[0] or 0) > 0)
    except Exception:
        try:
            row = conn.execute("SELECT COUNT(*) FROM items").fetchone()
            return bool(row and int(row[0] or 0) > 0)
        except Exception:
            return False


def sync_if_needed(core):
    """Import/rematch only when the service master fingerprint changes."""
    remote = _service_state()
    dbs = remote.get("databases") or {}
    if not dbs:
        return {"status": "service_not_ready"}

    conn = None
    try:
        conn = core.init_db()
        if not _items_ready(conn):
            return {"status": "library_not_ready"}

        local = _read_state()
        applied = local.get("applied") or {}
        result = {"status": "ok", "changed": False, "providers": {}}

        cine = dbs.get("cine21") or {}
        cine_path = cine.get("path") or ""
        cine_sha = cine.get("sha256") or ""
        if cine_path and os.path.isfile(cine_path) and cine_sha and applied.get("cine21") != cine_sha:
            started = time.time()
            stats = pkm_cine21_import.run_import_and_match(conn, cine_path, progress_cb=None)
            applied["cine21"] = cine_sha
            result["changed"] = True
            result["providers"]["cine21"] = stats
            _log("CINE21_APPLIED sha=%s elapsed=%.2fs stats=%s" % (
                cine_sha[:12], time.time() - started, stats
            ))

        watcha = dbs.get("watcha") or {}
        watcha_path = watcha.get("path") or ""
        watcha_sha = watcha.get("sha256") or ""
        if watcha_path and os.path.isfile(watcha_path) and watcha_sha and applied.get("watcha") != watcha_sha:
            started = time.time()
            stats = pkm_watcha_import.run_import_watcha_build_db(conn, watcha_path, progress_cb=None)
            applied["watcha"] = watcha_sha
            result["changed"] = True
            result["providers"]["watcha"] = stats
            _log("WATCHA_APPLIED sha=%s elapsed=%.2fs stats=%s" % (
                watcha_sha[:12], time.time() - started, stats
            ))

        local["schema"] = 1
        local["applied"] = applied
        local["last_checked_at"] = int(time.time())
        _write_state(local)
        return result

    except Exception:
        _log("SYNC_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
        return {"status": "error", "error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def status_snapshot():
    remote = _service_state()
    local = _read_state()
    return {
        "remote": remote,
        "local": local,
    }
