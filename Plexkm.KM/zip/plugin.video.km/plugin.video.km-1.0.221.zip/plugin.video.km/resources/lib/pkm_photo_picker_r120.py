# -*- coding: utf-8 -*-
"""R120c: PKM photo picker (배우 사진 / 포스터 / 배경 고르기).

open_photo_picker(title, sub, urls, current="", wide=False) -> index into urls,
-2 for the first "자동(원래대로)" cell, or -1 (Back).
"""
import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
PANEL_ID = 500
_KEEP = []

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] PHOTO_PICKER_R120 %s" % msg, level)
    except Exception:
        pass


class _Picker(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.urls = list(kwargs.get("urls") or [])
        self.current = str(kwargs.get("current") or "")
        self.panel_id = 501 if kwargs.get("wide") else PANEL_ID
        self.result = -1
        self._items = []

    def onInit(self):
        try:
            panel = self.getControl(self.panel_id)
            panel.reset()
            items = []
            auto = xbmcgui.ListItem(label="자동 (원래대로)")
            auto.setProperty("auto", "1")
            items.append(auto)
            focus = 0
            for i, url in enumerate(self.urls):
                li = xbmcgui.ListItem(label="")
                li.setArt({"thumb": url})
                if self.current and url == self.current:
                    li.setProperty("current", "1")
                    focus = i + 1
                items.append(li)
            self._items = items
            panel.addItems(items)
            panel.selectItem(focus)
            self.setFocusId(self.panel_id)
        except Exception:
            _log("INIT_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)

    def onClick(self, control_id):
        if control_id == self.panel_id:
            try:
                pos = int(self.getControl(self.panel_id).getSelectedPosition())
            except Exception:
                pos = -1
            self.result = -2 if pos == 0 else (pos - 1 if pos > 0 else -1)
            self.close()

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.result = -1
            self.close()


def open_photo_picker(title, sub, urls, current="", wide=False):
    win = xbmcgui.Window(10000)
    dlg = None
    try:
        win.setProperty("PlexKM.PhotoPicker.Title", str(title or ""))
        win.setProperty("PlexKM.PhotoPicker.Sub", str(sub or ""))
        win.setProperty("PlexKM.PhotoPicker.Wide", "1" if wide else "")
        dlg = _Picker("plexkm_photo_picker_r120.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                      "Default", "1080i", urls=urls, current=current, wide=wide)
        dlg.doModal()
        return int(dlg.result)
    except Exception:
        _log("OPEN_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
        return -1
    finally:
        _KEEP[:] = [dlg] if dlg is not None else []
        dlg = None
        for k in ("Title", "Sub", "Wide"):
            win.clearProperty("PlexKM.PhotoPicker.%s" % k)
