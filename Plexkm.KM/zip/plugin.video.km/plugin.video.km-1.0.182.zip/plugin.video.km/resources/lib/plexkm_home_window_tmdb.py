# -*- coding: utf-8 -*-
"""PKM home window part (R73): TMDB 줄거리·스틸 보완.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartTmdbR73
    def _home_tmdb_rating_value(self, rating):
        """Return the Plex/TMDB numeric score used only by Home TV layouts."""
        return self._home_imdb_rating_value(rating)

    def _tmdb_plot_cache_path_r35(self):
        try:
            return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/tmdb_episode_plot_r35.json")
        except Exception:
            return ""

    def _tmdb_plot_cache_load_r35(self):
        cache = getattr(self, "_tmdb_plot_cache_r35", None)
        if isinstance(cache, dict):
            return cache
        # R39: the GUI row builder and the worker can both arrive here first.
        with self._TMDB_PLOT_LOAD_LOCK_R39:
            cache = getattr(self, "_tmdb_plot_cache_r35", None)
            if isinstance(cache, dict):
                return cache
            return self._tmdb_plot_cache_load_file_r39()

    def _tmdb_plot_cache_load_file_r39(self):
        cache = {}
        try:
            path = self._tmdb_plot_cache_path_r35()
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if isinstance(data, dict):
                    cache = data
        except Exception:
            cache = {}
        self._tmdb_plot_cache_r35 = cache
        return cache

    def _tmdb_plot_cache_save_r35(self):
        try:
            path = self._tmdb_plot_cache_path_r35()
            if not path:
                return
            cache = self._tmdb_plot_cache_load_r35()
            # R39: drop expired per-episode entries so the file stays small.
            try:
                now_r39 = time.time()
                for k_r39 in [k for k, v in list(cache.items())
                              if k.startswith(("ep:", "it:", "epmiss:", "thumbmiss:", "still:", "stillnone:")) and (not isinstance(v, dict)
                                  or now_r39 - float(v.get("t") or 0) >= float(v.get("ttl") or self._TMDB_PLOT_CACHE_TTL_R35))]:
                    cache.pop(k_r39, None)
            except Exception:
                pass
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(cache, fh, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception as exc:
            _log("TMDB_EPISODE_PLOT_CACHE_SAVE_FAILED_R35 err=%s" % exc, xbmc.LOGWARNING)

    @staticmethod
    def _tmdb_title_key_r35(value):
        try:
            import unicodedata as _ud_r35
            text = _ud_r35.normalize("NFKC", str(value or "").strip()).casefold()
            return "".join(ch for ch in text if ch.isalnum())
        except Exception:
            return ""

    @staticmethod
    def _tmdb_season_r35(season):
        """Map PKM/Plex season indexes to TMDb.  Custom 4K copies use 501 etc."""
        s = _safe_int(season, -1)
        if s >= 100:
            s = s % 100
        return s

    def _tmdb_helper_dir_r35(self, directory, properties, request_id):
        request = {
            "jsonrpc": "2.0", "id": int(request_id), "method": "Files.GetDirectory",
            "params": {"directory": directory, "media": "files", "properties": list(properties)},
        }
        raw = xbmc.executeJSONRPC(json.dumps(request, ensure_ascii=False))
        payload = json.loads(raw or "{}")
        if payload.get("error"):
            raise RuntimeError("JSON-RPC %s" % payload.get("error"))
        return list(((payload.get("result") or {}).get("files") or []))

    def _tmdb_show_identity_r35(self, show_rk):
        """(title, original_title, year, tmdb_id_from_guid) from the local DB."""
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return "", "", "", ""
            conn = _pkm_ro_connect(dbp, timeout=0.5)
            try:
                row = conn.execute(
                    "SELECT title, original_title, year, raw_json FROM items WHERE rating_key=? LIMIT 1",
                    (str(show_rk),)).fetchone()
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
            if not row:
                return "", "", "", ""
            tmdb_guid = ""
            try:
                from resources.lib import pkm_media_versions as _pmv_r35
                tmdb_guid = str(_pmv_r35.tmdb_id(row[3] or "") or "")
            except Exception:
                tmdb_guid = ""
            return str(row[0] or ""), str(row[1] or ""), str(row[2] or ""), tmdb_guid
        except Exception:
            return "", "", "", ""

    def _tmdb_resolve_show_r35(self, show_rk, title, original_title, year, tmdb_guid):
        cache = self._tmdb_plot_cache_load_r35()
        key = "show:%s" % show_rk
        now = time.time()
        rec = cache.get(key) if isinstance(cache.get(key), dict) else None
        if rec:
            ttl = self._TMDB_PLOT_CACHE_TTL_R35 if rec.get("tmdb") else self._TMDB_PLOT_NEG_TTL_R35
            if now - float(rec.get("t") or 0) < ttl:
                return str(rec.get("tmdb") or ""), "cache"
        if tmdb_guid:
            cache[key] = {"tmdb": tmdb_guid, "t": now, "src": "guid"}
            return tmdb_guid, "guid"
        wanted = set(k for k in (self._tmdb_title_key_r35(title), self._tmdb_title_key_r35(original_title)) if k)
        y = _safe_int(year, 0)
        found = ""
        if wanted:
            directory = "plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=tv&query=%s" % quote(title, safe="")
            if y:
                directory += "&year=%d" % y
            try:
                results_r42 = self._tmdb_helper_dir_r35(directory, ["title", "originaltitle", "year", "uniqueid"], 35001)
            except Exception:
                # R42: Helper answers an empty search with a JSON-RPC error.
                results_r42 = []
            for item in results_r42:
                names = set(k for k in (self._tmdb_title_key_r35(item.get("title")),
                                        self._tmdb_title_key_r35(item.get("originaltitle"))) if k)
                iy = _safe_int(item.get("year"), 0)
                tid = str(((item.get("uniqueid") or {}).get("tmdb")) or "")
                if tid and (names & wanted) and (not y or not iy or abs(iy - y) <= 1):
                    found = tid
                    break
        cache[key] = {"tmdb": found, "t": now, "src": "search" if found else "no_match"}
        return found, ("search" if found else "no_match")

    def _tmdb_plot_for_rk_r39(self, rating_key):
        """R39: Korean TMDb plot already fetched for this episode, or "".

        GUI-safe (memory + one small JSON read on first use, no network).
        Used by the episode ListItem builder so every rail build -- first
        Info entry, re-entry, A/B rebuilds and the next Kodi start -- gets the
        Korean plot on its first frame instead of waiting for the worker.
        """
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return ""
            rec = self._tmdb_plot_cache_load_r35().get("ep:" + rk)
            if not isinstance(rec, dict):
                return ""
            if time.time() - float(rec.get("t") or 0) >= self._TMDB_PLOT_CACHE_TTL_R35:
                return ""
            plot = str(rec.get("p") or "").strip()
            if plot and self._HANGUL_RE_R38.search(plot):
                return plot
        except Exception:
            pass
        return ""

    def _tmdb_fill_rec_r41(self, key):
        try:
            rec = self._tmdb_plot_cache_load_r35().get(key)
            if not isinstance(rec, dict):
                return None
            ttl = float(rec.get("ttl") or self._TMDB_PLOT_CACHE_TTL_R35)
            if time.time() - float(rec.get("t") or 0) >= ttl:
                return None
            if key.startswith("it:") and int(rec.get("v") or 1) < 2:
                return None
            return rec
        except Exception:
            return None

    def _tmdb_resolve_movie_r41(self, rk, title, original_title, year, tmdb_guid):
        cache = self._tmdb_plot_cache_load_r35()
        key = "movie:%s" % rk
        now = time.time()
        rec = cache.get(key) if isinstance(cache.get(key), dict) else None
        if rec:
            ttl = self._TMDB_PLOT_CACHE_TTL_R35 if rec.get("tmdb") else self._TMDB_PLOT_NEG_TTL_R35
            if now - float(rec.get("t") or 0) < ttl:
                return str(rec.get("tmdb") or ""), "cache"
        if tmdb_guid:
            cache[key] = {"tmdb": tmdb_guid, "t": now, "src": "guid"}
            return tmdb_guid, "guid"
        wanted = set(k for k in (self._tmdb_title_key_r35(title), self._tmdb_title_key_r35(original_title)) if k)
        y = _safe_int(year, 0)
        found = ""
        if wanted:
            directory = "plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=movie&query=%s" % quote(title, safe="")
            if y:
                directory += "&year=%d" % y
            try:
                results_r42 = self._tmdb_helper_dir_r35(directory, ["title", "originaltitle", "year", "uniqueid"], 41002)
            except Exception:
                results_r42 = []
            for item in results_r42:
                names = set(k for k in (self._tmdb_title_key_r35(item.get("title")),
                                        self._tmdb_title_key_r35(item.get("originaltitle"))) if k)
                iy = _safe_int(item.get("year"), 0)
                tid = str(((item.get("uniqueid") or {}).get("tmdb")) or "")
                if tid and (names & wanted) and (not y or not iy or abs(iy - y) <= 1):
                    found = tid
                    break
        cache[key] = {"tmdb": found, "t": now, "src": "search" if found else "no_match"}
        return found, ("search" if found else "no_match")

    def _tmdb_fill_plex_db_r41(self, rk):
        """Worker: Plex summary + rating already in the local DB for one item."""
        plot = rating = ""
        try:
            dbp = self._profile_db_path()
            if not dbp or not os.path.exists(dbp):
                return "", ""
            conn = _pkm_ro_connect(dbp, timeout=0.5)
            try:
                row = conn.execute("SELECT summary FROM items WHERE rating_key=? LIMIT 1", (str(rk),)).fetchone()
                plot = str((row or [""])[0] or "").strip()
                try:
                    r = conn.execute("SELECT rating, audience_rating FROM item_ratings WHERE rating_key=? LIMIT 1", (str(rk),)).fetchone()
                    for v in (r or []):
                        if v and float(v) > 0:
                            rating = "%.1f" % float(v)
                            break
                except Exception:
                    rating = ""
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        except Exception:
            pass
        return plot, rating

    def _tmdb_fill_item_job_r41(self, rk, tmdb_type):
        cache = self._tmdb_plot_cache_load_r35()
        now = time.time()
        rec = {"t": now, "type": tmdb_type, "v": 2}
        pplot, prating = self._tmdb_fill_plex_db_r41(rk)
        if pplot:
            rec["pplot"] = pplot
        if prating:
            rec["prating"] = prating
        title, original_title, year, tmdb_guid = self._tmdb_show_identity_r35(rk)
        why = ""
        if not title:
            why = "not_in_db"
            rec["ttl"] = self._TMDB_FILL_MISS_TTL_R41
        else:
            if tmdb_type == "tv":
                tmdb_id, id_src = self._tmdb_resolve_show_r35(rk, title, original_title, year, tmdb_guid)
            else:
                tmdb_id, id_src = self._tmdb_resolve_movie_r41(rk, title, original_title, year, tmdb_guid)
            if not tmdb_id:
                why = "no_exact_tmdb_match"
                rec["ttl"] = self._TMDB_FILL_MISS_TTL_R41
            else:
                rec["tmdb"] = tmdb_id
                directory = ("plugin://plugin.video.themoviedb.helper/?info=details&tmdb_type=%s&tmdb_id=%s&fanarttv=false"
                             % (tmdb_type, quote(str(tmdb_id), safe="")))
                items, lang = self._tmdb_helper_dir_korean_r38(
                    directory, ["title", "plot", "rating", "genre", "art", "uniqueid", "year"], 41001)
                if lang != "ko":
                    why = "helper_" + lang
                    rec["ttl"] = self._TMDB_FILL_NOHELPER_TTL_R41
                else:
                    pick = None
                    for item in items:
                        if str(((item.get("uniqueid") or {}).get("tmdb")) or "") == str(tmdb_id):
                            pick = item
                            break
                    if pick is None and items:
                        pick = items[0]
                    pick = pick or {}
                    plot = str(pick.get("plot") or "").strip()
                    if plot and self._HANGUL_RE_R38.search(plot):
                        rec["plot"] = plot
                    try:
                        r = float(pick.get("rating") or 0)
                        if r > 0:
                            rec["rating"] = "%.1f" % r
                    except Exception:
                        pass
                    genre = pick.get("genre") or []
                    if isinstance(genre, (list, tuple)):
                        genre = " / ".join(str(g).strip() for g in genre if str(g).strip())
                    if str(genre or "").strip():
                        rec["genre"] = str(genre).strip()
                    for art_key_r42 in ("poster", "fanart"):
                        try:
                            art_url_r42 = str(((pick.get("art") or {}).get(art_key_r42)) or "").strip()
                            if art_url_r42 and not art_url_r42.casefold().startswith("plugin://"):
                                rec[art_key_r42] = _clean_external_image_url(art_url_r42) or art_url_r42
                        except Exception:
                            pass
                    if not pick:
                        why = "no_details"
        cache["it:%s" % rk] = rec
        _log("TMDB_FILL_ITEM_R41 rk=%s type=%s tmdb=%s plot=%d pplot=%d rating=%s prating=%s genre=%d poster=%d why=%s" % (
            rk, tmdb_type, rec.get("tmdb") or "-", 1 if rec.get("plot") else 0, 1 if pplot else 0,
            rec.get("rating") or "-", prating or "-", 1 if rec.get("genre") else 0,
            1 if rec.get("poster") else 0, why or "ok"))

    def _tmdb_fill_episode_job_r41(self, ep_rk, show_rk, season, episode):
        cache = self._tmdb_plot_cache_load_r35()
        now = time.time()
        plot = ""
        why = ""
        ttl = self._TMDB_FILL_MISS_TTL_R41
        title, original_title, year, tmdb_guid = self._tmdb_show_identity_r35(show_rk)
        if not title:
            why = "show_not_in_db"
        else:
            tmdb_id, _src = self._tmdb_resolve_show_r35(show_rk, title, original_title, year, tmdb_guid)
            s = self._tmdb_season_r35(season)
            e = _safe_int(episode, -1)
            if not tmdb_id:
                why = "no_exact_tmdb_match"
            elif s < 0 or e < 0:
                why = "no_index"
            else:
                plots, plot_src = self._tmdb_season_plots_r35(tmdb_id, s)
                plot = str(plots.get(str(e)) or "")
                if not plot:
                    why = "no_korean_plot"
                    if str(plot_src).startswith("helper_"):
                        ttl = self._TMDB_FILL_NOHELPER_TTL_R41
        if plot:
            cache["ep:%s" % ep_rk] = {"p": plot, "t": now}
            cache.pop("epmiss:%s" % ep_rk, None)
        else:
            cache["epmiss:%s" % ep_rk] = {"t": now, "ttl": ttl}
        _log("TMDB_FILL_EPISODE_R41 rk=%s show=%s s=%s e=%s plot=%d why=%s" % (
            ep_rk, show_rk, season, episode, 1 if plot else 0, why or "ok"))

    def _tmdb_fill_enqueue_r41(self, jobs, reason="", front=True):
        if not jobs:
            return 0
        added = 0
        start = False
        with self._TMDB_FILL_QLOCK_R41:
            queue = getattr(self, "_tmdb_fill_queue_r41", None)
            if queue is None:
                queue = []
                self._tmdb_fill_queue_r41 = queue
            keys = getattr(self, "_tmdb_fill_keys_r41", None)
            if keys is None:
                keys = set()
                self._tmdb_fill_keys_r41 = keys
            insert_at_r43 = 0
            for job in jobs:
                key = "%s:%s" % (job[0], job[1])
                if key in keys:
                    if front:
                        # R43: already queued as prefetch -> move it forward.
                        for qi_r43, queued_r43 in enumerate(queue):
                            if "%s:%s" % (queued_r43[0], queued_r43[1]) == key:
                                if qi_r43 > insert_at_r43:
                                    queue.insert(insert_at_r43, queue.pop(qi_r43))
                                insert_at_r43 += 1
                                break
                    continue
                keys.add(key)
                if front:
                    queue.insert(insert_at_r43, job)
                    insert_at_r43 += 1
                else:
                    queue.append(job)
                added += 1
            if added and not getattr(self, "_tmdb_fill_running_r41", False):
                self._tmdb_fill_running_r41 = True
                start = True
        if added and front:
            _log("TMDB_FILL_ENQUEUE_R41 jobs=%s reason=%s" % (
                ",".join("%s:%s" % (j[0], j[1]) for j in jobs), reason or ""))
        if start:
            threading.Thread(target=self._tmdb_fill_worker_r41, name="PKMTmdbFillR41", daemon=True).start()
        return added

    def _tmdb_fill_worker_r41(self):
        clean_exit = False
        try:
            # Stay clear of the focus/Info-entry frame.
            if self._closing_event_v1841.wait(0.6):
                return
            while not self._closing_event_v1841.is_set():
                with self._TMDB_FILL_QLOCK_R41:
                    queue = getattr(self, "_tmdb_fill_queue_r41", None) or []
                    if not queue:
                        self._tmdb_fill_running_r41 = False
                        clean_exit = True
                        return
                    job = queue.pop(0)
                key = "%s:%s" % (job[0], job[1])
                t0 = time.time()
                try:
                    with self._TMDB_PLOT_LOCK_R35:
                        if job[0] == "it":
                            self._tmdb_fill_item_job_r41(job[1], job[2])
                        elif job[0] == "ep":
                            self._tmdb_fill_episode_job_r41(job[1], job[2], job[3], job[4])
                        self._tmdb_plot_cache_save_r35()
                except Exception:
                    _log("TMDB_FILL_JOB_FAILED_R41 job=%s err=%s" % (
                        key, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
                    try:
                        with self._TMDB_PLOT_LOCK_R35:
                            neg_key_r42 = ("it:%s" % job[1]) if job[0] == "it" else ("epmiss:%s" % job[1])
                            self._tmdb_plot_cache_load_r35()[neg_key_r42] = {
                                "t": time.time(), "ttl": self._TMDB_FILL_NOHELPER_TTL_R41, "v": 2, "why": "error"}
                            self._tmdb_plot_cache_save_r35()
                    except Exception:
                        pass
                finally:
                    with self._TMDB_FILL_QLOCK_R41:
                        try:
                            self._tmdb_fill_keys_r41.discard(key)
                        except Exception:
                            pass
                _log("TMDB_FILL_JOB_DONE_R41 job=%s elapsed_ms=%d" % (key, int((time.time() - t0) * 1000)))
                self._tmdb_fill_ready_r41 = True
                if not self._closing_event_v1841.is_set():
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
        finally:
            if not clean_exit:
                with self._TMDB_FILL_QLOCK_R41:
                    self._tmdb_fill_running_r41 = False

    def _tmdb_fill_plan_r41(self, ctx, cur_summary, cur_rating, cur_genre, episode_plot=False):
        """Return (updates, jobs) for one item.  Cache-only; never blocks."""
        upd = {}
        jobs = []
        ptype = str(ctx.get("type") or "").lower()
        rk = str(ctx.get("rk") or "")
        show = str(ctx.get("show") or "")
        if ptype == "movie":
            owner, owner_type = rk, "movie"
        elif ptype == "show":
            owner, owner_type = rk, "tv"
        elif ptype in ("episode", "season"):
            owner, owner_type = show, "tv"
        else:
            return upd, jobs
        it = self._tmdb_fill_rec_r41("it:%s" % owner) if owner else None
        if owner and it is None:
            jobs.append(("it", owner, owner_type))
        owner_plot = str((it or {}).get("pplot") or (it or {}).get("plot") or "")
        owner_checked = (it is not None) or not owner
        if ptype == "episode" and episode_plot and ctx.get("own_empty"):
            ep_plot = self._tmdb_plot_for_rk_r39(rk)
            ep_checked = bool(ep_plot) or (self._tmdb_fill_rec_r41("epmiss:%s" % rk) is not None)
            if not ep_checked and rk and show:
                jobs.append(("ep", rk, show, str(ctx.get("season") or ""), str(ctx.get("episode") or "")))
            if ep_plot:
                if str(cur_summary or "").strip() != ep_plot:
                    upd["summary"] = ep_plot
            elif not str(cur_summary or "").strip():
                if owner_plot:
                    upd["summary"] = owner_plot
                elif ep_checked and owner_checked:
                    upd["no_plot"] = True
        elif not str(cur_summary or "").strip():
            if owner_plot:
                upd["summary"] = owner_plot
            elif owner_checked:
                upd["no_plot"] = True
        if owner_type == "tv" and not str(cur_rating or "").strip():
            r = str((it or {}).get("prating") or (it or {}).get("rating") or "")
            if r:
                upd["rating"] = r
        elif owner_type == "movie" and not str(cur_rating or "").strip():
            # R42: movies show TMDb next to Cine21/Watcha/IMDb (TMDb only, never
            # the Plex rating, which already feeds the IMDb slot).
            r = str((it or {}).get("rating") or "")
            if r:
                upd["rating"] = r
        if (it or {}).get("fanart"):
            upd["fanart"] = str(it.get("fanart"))
        if not str(cur_genre or "").strip() and (it or {}).get("genre"):
            upd["genre"] = str(it.get("genre"))
        return upd, jobs

    def _tmdb_fill_ctx_set_r41(self, li):
        """GUI: remember what the Home hero item is so worker/enrich paths can fill it."""
        try:
            rk = str(li.getProperty("PlexKM.RatingKey") or "")
            if not rk:
                return None
            ptype = str(li.getProperty("PlexKM.Type") or "").lower()
            show = str(li.getProperty("PlexKM.GrandparentRatingKey") or "")
            if ptype == "season":
                show = str(li.getProperty("PlexKM.ParentRatingKey") or show)
            ctx = {
                "rk": rk, "type": ptype, "show": show,
                "season": str(li.getProperty("PlexKM.Season") or ""),
                "episode": str(li.getProperty("PlexKM.Episode") or ""),
                "own_empty": not str(li.getProperty("PlexKM.Summary") or "").strip(),
            }
            store = getattr(self, "_tmdb_fill_ctx_r41", None)
            if not isinstance(store, dict) or len(store) > 2000:
                store = {}
                self._tmdb_fill_ctx_r41 = store
            store[rk] = ctx
            return ctx
        except Exception:
            return None

    def _tmdb_fill_prefetch_lis_r43(self, lis, reason=""):
        """GUI: queue TMDb jobs for cards not yet on the hero (low priority)."""
        jobs = []
        for li in lis:
            try:
                ctx = self._tmdb_fill_ctx_set_r41(li)
                if not ctx:
                    continue
                _upd, item_jobs = self._tmdb_fill_plan_r41(
                    ctx, li.getProperty("PlexKM.Summary") or "", "",
                    li.getProperty("PlexKM.Genre") or "", episode_plot=True)
                jobs.extend(item_jobs)
            except Exception:
                continue
        if jobs:
            added = self._tmdb_fill_enqueue_r41(jobs, reason="prefetch:%s" % (reason or ""), front=False)
            if added:
                _log("TMDB_FILL_PREFETCH_R43 queued=%d reason=%s" % (added, reason or ""))

    def _tmdb_fill_prefetch_focus_r43(self, reason=""):
        """GUI: warm the cache for the cards around the focused one."""
        try:
            fid = int(self._safe_focus_id() or 0)
            if not (self._is_home_row_control(fid) or fid in SECTION_RECOMMEND_ALL_ROW_IDS or fid == WALL_ID):
                return
            ctrl = self.getControl(fid)
            size = int(ctrl.size())
            pos = int(ctrl.getSelectedPosition())
            lis = []
            for i in range(max(0, pos - 1), min(size, pos + 7)):
                if i != pos:
                    try:
                        lis.append(ctrl.getListItem(i))
                    except Exception:
                        pass
            self._tmdb_fill_prefetch_lis_r43(lis, reason="focus_%s" % fid)
            if not getattr(self, "_tmdb_fill_rows_prefetched_r43", False) and self._is_home_row_control(fid):
                self._tmdb_fill_rows_prefetched_r43 = True
                row_lis = []
                for cid in HOME_ROW_IDS:
                    try:
                        rc = self.getControl(cid)
                        for i in range(min(int(rc.size()), 8)):
                            row_lis.append(rc.getListItem(i))
                    except Exception:
                        continue
                self._tmdb_fill_prefetch_lis_r43(row_lis, reason="home_rows")
        except Exception:
            pass

    def _tmdb_fill_home_apply_r41(self, rating_key="", reason=""):
        """Fill empty Home hero fields for the item still on screen (any thread)."""
        try:
            win = xbmcgui.Window(10000)
            current = str(win.getProperty("PlexKM.Home.RatingKey") or "")
            rk = str(rating_key or current)
            if not rk or rk != current:
                return False
            ctx = (getattr(self, "_tmdb_fill_ctx_r41", None) or {}).get(rk)
            if not ctx:
                return False
            ptype = str(ctx.get("type") or "").lower()
            upd, jobs = self._tmdb_fill_plan_r41(
                ctx,
                win.getProperty("PlexKM.Home.Summary"),
                win.getProperty("PlexKM.Home.TmdbRating"),
                win.getProperty("PlexKM.Home.Genre"),
                episode_plot=True,
            )
            props = {}
            if upd.get("summary"):
                text = upd["summary"]
                display = self._home_summary_display_text_v2179(text)
                props["Summary"] = text
                props["SummaryDisplay"] = display
                props["SummaryLineCount"] = str(self._home_summary_line_count_v2240(display))
            elif upd.get("no_plot") and not win.getProperty("PlexKM.Home.SummaryDisplay"):
                props["SummaryDisplay"] = self._TMDB_NO_PLOT_R41
                props["SummaryLineCount"] = str(self._home_summary_line_count_v2240(self._TMDB_NO_PLOT_R41))
            if upd.get("rating"):
                props["TmdbRating"] = self._home_tmdb_rating_value(upd["rating"])
                if ptype != "movie" and not win.getProperty("PlexKM.Home.Rating"):
                    props["Rating"] = upd["rating"]
            if upd.get("genre"):
                props["Genre"] = upd["genre"]
                props["GenreLine"] = self._genre_display_text(upd["genre"])
            if str(win.getProperty("PlexKM.Home.RatingKey") or "") != rk:
                return False
            for k, v in props.items():
                win.setProperty("PlexKM.Home.%s" % k, str(v or ""))
            if jobs:
                self._tmdb_fill_enqueue_r41(jobs, reason="home:%s" % (reason or ""))
            if props:
                _log("TMDB_FILL_HOME_R41 rk=%s type=%s fields=%s reason=%s" % (
                    rk, ptype, ",".join(sorted(props)), reason or ""))
            return bool(props)
        except Exception:
            _log("TMDB_FILL_HOME_FAILED_R41 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _tmdb_fill_home_fanart_r42(self, rating_key="", reason=""):
        """GUI: Plex has no hero art for this item -> use the TMDb backdrop."""
        try:
            win = xbmcgui.Window(10000)
            current = str(win.getProperty("PlexKM.Home.RatingKey") or "")
            rk = str(rating_key or current)
            if not rk or rk != current or win.getProperty("PlexKM.Home.Fanart"):
                return False
            ctx = (getattr(self, "_tmdb_fill_ctx_r41", None) or {}).get(rk)
            if not ctx:
                return False
            upd, jobs = self._tmdb_fill_plan_r41(ctx, "-", "-", "-")
            if jobs:
                self._tmdb_fill_enqueue_r41(jobs, reason="fanart:%s" % (reason or ""))
            url = str(upd.get("fanart") or "")
            if not url:
                return False
            self._set_home_fanart_smooth(url, reason="tmdb_fanart_r42")
            _log("TMDB_FILL_HOME_FANART_R42 rk=%s reason=%s" % (rk, reason or ""))
            return True
        except Exception:
            return False

    def _tmdb_fill_info_apply_r41(self, reason=""):
        """Fill empty Info header fields (summary / TV rating / genre)."""
        try:
            win = xbmcgui.Window(10000)
            rk = str(win.getProperty("PlexKM.Info.RatingKey") or "")
            if not rk:
                return False
            ptype = str(win.getProperty("PlexKM.Info.Type") or "").lower()
            is_tv = ptype in ("episode", "show", "season") or win.getProperty("PlexKM.Info.IsTV") == "1"
            if ptype not in ("movie", "episode", "show", "season"):
                ptype = "show" if is_tv else ""
            if not ptype:
                return False
            show = str(win.getProperty("PlexKM.Info.GrandparentRatingKey") or "")
            if ptype == "season":
                show = str(win.getProperty("PlexKM.Info.ParentRatingKey") or show)
            props = {}
            cur_rating = "-"
            if is_tv:
                cur_rating = str(win.getProperty("PlexKM.Info.Rating") or "")
                if not cur_rating:
                    # Home already showed a TMDB score for this title: keep it after
                    # the entry hold ends instead of letting the slot go blank.
                    held = str(win.getProperty("PlexKM.Info.EntryHomeTVRatingV2512") or "")
                    if held:
                        props["PlexKM.Info.Rating"] = held
                        cur_rating = held
            if not is_tv:
                cur_rating = ""
            ctx = {"rk": rk, "type": ptype, "show": show}
            upd, jobs = self._tmdb_fill_plan_r41(
                ctx, win.getProperty("PlexKM.Info.Summary"), cur_rating,
                win.getProperty("PlexKM.Info.Genre"), episode_plot=False)
            movie_tmdb_r42 = ""
            if not is_tv and upd.get("rating"):
                movie_tmdb_r42 = self._home_tmdb_rating_value(upd.pop("rating"))
            if str(win.getProperty("PlexKM.Info.TmdbRating") or "") != movie_tmdb_r42:
                props["PlexKM.Info.TmdbRating"] = movie_tmdb_r42
            if upd.get("summary"):
                text = upd["summary"]
                props["PlexKM.Info.Summary"] = text
                props["PlexKM.Info.SummaryDisplay"] = (
                    self._home_summary_display_text_v2179(text) if is_tv else self._summary_display_text(text))
            elif upd.get("no_plot") and not win.getProperty("PlexKM.Info.SummaryDisplay"):
                props["PlexKM.Info.SummaryDisplay"] = self._TMDB_NO_PLOT_R41
            if upd.get("rating"):
                props["PlexKM.Info.Rating"] = self._home_tmdb_rating_value(upd["rating"])
            if upd.get("genre"):
                props["PlexKM.Info.Genre"] = upd["genre"]
                props["PlexKM.Info.GenreLine"] = self._genre_display_text(upd["genre"])
            if str(win.getProperty("PlexKM.Info.RatingKey") or "") != rk:
                return False
            for k, v in props.items():
                self._info_set_property_all(k, str(v or ""))
            if jobs:
                self._tmdb_fill_enqueue_r41(jobs, reason="info:%s" % (reason or ""))
            if props:
                _log("TMDB_FILL_INFO_R41 rk=%s type=%s fields=%s reason=%s" % (
                    rk, ptype, ",".join(sorted(k.split(".")[-1] for k in props)), reason or ""))
            return bool(props)
        except Exception:
            _log("TMDB_FILL_INFO_FAILED_R41 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _tmdb_fill_commit_r41(self):
        """GUI ping: a TMDb job finished -> refill whatever is on screen."""
        if not getattr(self, "_tmdb_fill_ready_r41", False):
            return False
        self._tmdb_fill_ready_r41 = False
        done = False
        try:
            if xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                done = self._tmdb_fill_info_apply_r41(reason="ping") or done
        except Exception:
            pass
        done = self._tmdb_fill_home_apply_r41(reason="ping") or done
        done = self._tmdb_fill_home_fanart_r42(reason="ping") or done
        return done

    def _tmdb_helper_dir_korean_r38(self, directory, properties, request_id):
        """R38: TMDb Helper language is one global setting (default English).

        Episode plots must be Korean, so the request runs under the same
        Helper language lock the actor profile uses: switch to Korean, query,
        then restore the user's original value.  Returns (items, lang).
        """
        try:
            helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        except Exception:
            return [], "no_helper"
        with self._actor_profile_tmdb_lock_v2454:
            original = ""
            switched = False
            try:
                original = str(helper.getSetting("language") or "").strip()
                korean_value, _korean_label = self._actor_profile_helper_korean_value_v2454(helper)
                if not korean_value:
                    return [], "no_korean_option"
                if original != korean_value:
                    helper.setSetting("language", korean_value)
                    switched = True
                    if str(helper.getSetting("language") or "").strip() != korean_value:
                        xbmc.sleep(120)
                return list(self._tmdb_helper_dir_r35(directory, properties, request_id) or []), "ko"
            finally:
                if switched:
                    try:
                        helper.setSetting("language", original)
                    except Exception:
                        pass

    def _tmdb_season_plots_r35(self, tmdb_id, season):
        cache = self._tmdb_plot_cache_load_r35()
        # R38: Korean-only key; R35 entries (English) are ignored and age out.
        key = "tmdb:%s:s%d:ko" % (tmdb_id, season)
        now = time.time()
        rec = cache.get(key) if isinstance(cache.get(key), dict) else None
        if rec and now - float(rec.get("t") or 0) < self._TMDB_PLOT_CACHE_TTL_R35:
            return dict(rec.get("plots") or {}), "cache"
        directory = ("plugin://plugin.video.themoviedb.helper/?info=episodes&tmdb_type=tv&tmdb_id=%s&season=%d"
                     % (quote(str(tmdb_id), safe=""), int(season)))
        plots = {}
        non_korean = 0
        items, lang = self._tmdb_helper_dir_korean_r38(directory, ["title", "plot", "episode", "season"], 35002)
        for item in items:
            ep = _safe_int(item.get("episode"), -1)
            plot = str(item.get("plot") or "").strip()
            if ep < 0 or not plot:
                continue
            # TMDb falls back to the original language when a Korean overview is
            # missing.  Leave those empty so the R35 show-summary fallback shows.
            if not self._HANGUL_RE_R38.search(plot):
                non_korean += 1
                continue
            plots[str(ep)] = plot
        _log("TMDB_EPISODE_PLOT_LANG_R38 tmdb=%s season=%d lang=%s korean=%d non_korean_dropped=%d" % (
            tmdb_id, int(season), lang, len(plots), non_korean))
        if lang != "ko":
            return plots, "helper_" + lang
        cache[key] = {"plots": plots, "t": now}
        return plots, "helper"

    def _episode_still_r63(self, rating_key):
        try:
            rec = self._tmdb_plot_cache_load_r35().get("still:%s" % rating_key)
            if isinstance(rec, dict) and time.time() - float(rec.get("t") or 0) < self._STILL_TTL_R63:
                return str(rec.get("u") or "")
        except Exception:
            pass
        return ""

    @staticmethod
    def _tmdb_still_url_r63(item):
        try:
            art = item.get("art") or {}
            raw = str(art.get("thumb") or item.get("thumbnail") or "").strip()
        except Exception:
            raw = ""
        if not raw:
            return ""
        if raw.startswith("image://"):
            raw = unquote(raw[len("image://"):])
            if raw.endswith("/"):
                raw = raw[:-1]
        if "image.tmdb.org" not in raw:
            return ""
        return raw.replace("/t/p/original/", "/t/p/w500/")

    def _tmdb_episode_still_schedule_r63(self, control_id, reason=""):
        """GUI thread: snapshot the bank, then look up TMDb stills off-thread."""
        try:
            ctrl = self.getControl(int(control_id))
            size = int(ctrl.size())
        except Exception:
            return False
        eps = []
        show_rk = ""
        for i in range(max(0, size)):
            try:
                li = ctrl.getListItem(i)
            except Exception:
                continue
            if str(li.getProperty("PlexKM.Type") or "") != "episode":
                continue
            rk = str(li.getProperty("PlexKM.RatingKey") or "")
            show_rk = show_rk or str(li.getProperty("PlexKM.GrandparentRatingKey") or "")
            if not rk:
                continue
            # R64: only the five visible cards are pre-downloaded; the rest
            # keep the remote Plex URL.  Remember it so the worker can probe
            # it (a 404 there showed an empty card after scrolling).
            thumb_url = str(li.getArt("thumb") or "")
            probe = thumb_url if thumb_url.lower().startswith(("http://", "https://")) and "image.tmdb.org" not in thumb_url else ""
            if probe or not self._episode_still_r63(rk) or self._episode_thumb_miss_r63(rk):
                eps.append((rk, str(li.getProperty("PlexKM.Season") or ""), str(li.getProperty("PlexKM.Episode") or ""), probe))
        if not eps or not show_rk:
            return False
        try:
            xbmcaddon.Addon("plugin.video.themoviedb.helper")
        except Exception:
            return False
        token = int(getattr(self, "_tmdb_still_token_r63", 0) or 0) + 1
        self._tmdb_still_token_r63 = token

        def _season_stills(tmdb_id, tmdb_season):
            """TMDb stills for one season; empty results are remembered 7 days."""
            neg_key = "stillnone:%s:s%d" % (tmdb_id, tmdb_season)
            try:
                rec = self._tmdb_plot_cache_load_r35().get(neg_key)
                if isinstance(rec, dict) and time.time() - float(rec.get("t") or 0) < 7 * 86400:
                    return {}, "negative_cache"
            except Exception:
                pass
            directory = ("plugin://plugin.video.themoviedb.helper/?info=episodes&tmdb_type=tv&tmdb_id=%s&season=%d"
                         % (quote(str(tmdb_id), safe=""), int(tmdb_season)))
            stills = {}
            for item in self._tmdb_helper_dir_r35(directory, ["episode", "season", "art", "thumbnail"], 63001):
                ep = _safe_int(item.get("episode"), -1)
                url = self._tmdb_still_url_r63(item)
                if ep >= 0 and url:
                    stills[str(ep)] = url
            if not stills:
                with self._THUMB_LOCK_R63:
                    self._tmdb_plot_cache_load_r35()[neg_key] = {"t": time.time()}
            return stills, "helper"

        def _tmdb_lookup(result):
            """Resolve the show once and fetch stills for every season in the bank."""
            locked = False
            try:
                # Serialise with the TMDb plot worker (shared resolve cache).
                locked = self._TMDB_PLOT_LOCK_R35.acquire(timeout=8.0)
                title, original_title, year, tmdb_guid = self._tmdb_show_identity_r35(show_rk)
                tmdb_id = ""
                if title:
                    tmdb_id, _src = self._tmdb_resolve_show_r35(show_rk, title, original_title, year, tmdb_guid)
                if not tmdb_id:
                    _log("TMDB_EPISODE_STILL_SKIP_R63 show=%s reason=no_tmdb_match" % show_rk)
                    return
                by_season = {}
                for rk, season, episode, _probe in eps:
                    by_season.setdefault(self._tmdb_season_r35(season), []).append((rk, episode))
                now = time.time()
                for tmdb_season, rows in by_season.items():
                    if tmdb_season < 0 or self._closing_event_v1841.is_set():
                        continue
                    try:
                        stills, src = _season_stills(tmdb_id, tmdb_season)
                    except Exception as exc:
                        _log("TMDB_EPISODE_STILL_DIR_FAILED_R63 show=%s season=%d err=%s" % (show_rk, tmdb_season, exc), xbmc.LOGWARNING)
                        continue
                    with self._THUMB_LOCK_R63:
                        cache = self._tmdb_plot_cache_load_r35()
                        for rk, episode in rows:
                            url = stills.get(str(_safe_int(episode, -1)))
                            if url:
                                cache["still:%s" % rk] = {"t": now, "u": url}
                                result[rk] = url
                    _log("TMDB_EPISODE_STILL_SEASON_R63 show=%s tmdb=%s season=%d stills=%d src=%s" % (
                        show_rk, tmdb_id, tmdb_season, len(stills), src))
            except Exception:
                _log("TMDB_EPISODE_STILL_FAILED_R63 show=%s err=%s" % (
                    show_rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            finally:
                if locked:
                    try:
                        self._TMDB_PLOT_LOCK_R35.release()
                    except Exception:
                        pass

        def _commit(ready, stage):
            if ready and not self._closing_event_v1841.is_set() \
                    and token == int(getattr(self, "_tmdb_still_token_r63", 0) or 0):
                pending = dict(getattr(self, "_tmdb_still_ready_r63", None) or {})
                pending.update(ready)
                self._tmdb_still_ready_r63 = pending
                xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                _log("TMDB_EPISODE_STILL_READY_R66 show=%s stage=%s items=%d stills=%d elapsed_ms=%d" % (
                    show_rk, stage, len(ready), len([u for u in ready.values() if u]),
                    int((time.time() - t0) * 1000)))

        t0 = time.time()

        def _worker():
            # R66: no fixed 2.5 s wait, parallel probes, TMDb in parallel when
            # a 404 is already known, and a first commit (empty cards + badge)
            # before TMDb answers.  Typical first-open fill: ~1 s instead of ~6 s.
            tmdb_result = {}
            tmdb_thread = None
            try:
                if self._closing_event_v1841.wait(0.15):
                    return
                if token != int(getattr(self, "_tmdb_still_token_r63", 0) or 0):
                    return
                if any(self._episode_thumb_miss_r63(e[0]) and not self._episode_still_r63(e[0]) for e in eps):
                    tmdb_thread = threading.Thread(target=_tmdb_lookup, args=(tmdb_result,),
                                                   name="PKMTmdbEpisodeStillLookupR66", daemon=True)
                    tmdb_thread.start()

                def _probe(job):
                    rk, _season, _episode, probe = job
                    try:
                        req = Request(probe, headers={"User-Agent": "Kodi-PKM/1.0", "Range": "bytes=0-1023"})
                        resp = urlopen(req, timeout=2.0)
                        try:
                            resp.read(1024)
                        finally:
                            resp.close()
                        return rk, False
                    except Exception as exc:
                        return rk, int(getattr(exc, "code", 0) or 0) in (404, 410)

                jobs = [e for e in eps if e[3] and not self._episode_thumb_miss_r63(e[0])]
                if jobs:
                    with ThreadPoolExecutor(max_workers=min(6, len(jobs))) as ex:
                        for rk, dead in ex.map(_probe, jobs):
                            if dead:
                                self._episode_thumb_miss_mark_r63(rk)
                    _log("EPISODE_THUMB_PROBE_R64 show=%s probed=%d parallel=%d elapsed_ms=%d" % (
                        show_rk, len(jobs), min(6, len(jobs)), int((time.time() - t0) * 1000)))

                missing = [e[0] for e in eps if self._episode_thumb_miss_r63(e[0])]
                if not missing:
                    return
                first = {rk: self._episode_still_r63(rk) for rk in missing}
                _commit(first, "probe")
                need_tmdb = [rk for rk in missing if not first.get(rk)]
                if not need_tmdb:
                    return
                if tmdb_thread is None:
                    tmdb_thread = threading.Thread(target=_tmdb_lookup, args=(tmdb_result,),
                                                   name="PKMTmdbEpisodeStillLookupR66", daemon=True)
                    tmdb_thread.start()
                tmdb_thread.join(12.0)
                second = {rk: tmdb_result[rk] for rk in need_tmdb if tmdb_result.get(rk)}
                try:
                    self._tmdb_plot_cache_save_r35()
                except Exception:
                    pass
                _commit(second, "tmdb")
            except Exception:
                _log("TMDB_EPISODE_STILL_FAILED_R63 show=%s err=%s" % (
                    show_rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

        threading.Thread(target=_worker, name="PKMTmdbEpisodeStillR63", daemon=True).start()
        return True

    def _tmdb_episode_still_commit_r63(self):
        ready = getattr(self, "_tmdb_still_ready_r63", None)
        if not ready:
            return False
        self._tmdb_still_ready_r63 = None
        filled = 0
        for cid in (5712, 5713):
            try:
                ctrl = self.getControl(cid)
                size = int(ctrl.size())
            except Exception:
                continue
            for i in range(max(0, size)):
                try:
                    li = ctrl.getListItem(i)
                    rk_c = str(li.getProperty("PlexKM.RatingKey") or "")
                    if rk_c not in ready:
                        continue
                    url = ready.get(rk_c) or ""
                    if not url and str(li.getProperty("PlexKM.ThumbFallbackR63") or "") == "tmdb_still":
                        continue
                    li.setArt({"thumb": url, "icon": url})
                    li.setProperty("PlexKM.Thumb", url)
                    li.setProperty("PlexKM.EpisodeThumb", url)
                    li.setProperty("PlexKM.ThumbFallbackR63", "tmdb_still" if url else "none")
                    li.setProperty("PlexKM.OverlayReadyR56", "1")
                    filled += 1
                except Exception:
                    continue
        _log("TMDB_EPISODE_STILL_COMMIT_R63 filled=%d ready=%d" % (filled, len(ready)))
        return filled > 0

    def _tmdb_episode_plot_schedule_r35(self, control_id, reason=""):
        """GUI thread: collect empty-summary episodes of one bank, then go async."""
        try:
            ctrl = self.getControl(int(control_id))
            size = int(ctrl.size())
        except Exception:
            return False
        wanted = []
        show_rk = ""
        for i in range(max(0, size)):
            try:
                li = ctrl.getListItem(i)
            except Exception:
                continue
            if str(li.getProperty("PlexKM.Type") or "") != "episode":
                continue
            if str(li.getProperty("PlexKM.Summary") or "").strip():
                continue
            rk = str(li.getProperty("PlexKM.RatingKey") or "")
            show_rk = show_rk or str(li.getProperty("PlexKM.GrandparentRatingKey") or "")
            if rk:
                wanted.append((rk, str(li.getProperty("PlexKM.Season") or ""), str(li.getProperty("PlexKM.Episode") or "")))
        if not wanted or not show_rk:
            return False
        try:
            xbmcaddon.Addon("plugin.video.themoviedb.helper")
        except Exception:
            _log("TMDB_EPISODE_PLOT_SKIP_R35 show=%s reason=tmdb_helper_missing empty=%d" % (show_rk, len(wanted)))
            return False
        token = int(getattr(self, "_tmdb_plot_token_r35", 0) or 0) + 1
        self._tmdb_plot_token_r35 = token
        _log("TMDB_EPISODE_PLOT_ARM_R35 show=%s control=%s empty=%d reason=%s" % (show_rk, control_id, len(wanted), reason or ""))

        def _worker():
            t0 = time.time()
            locked_r35 = False
            try:
                # Stay clear of the Info entry/action-bar animation window.
                if self._closing_event_v1841.wait(1.2):
                    return
                if token != int(getattr(self, "_tmdb_plot_token_r35", 0) or 0):
                    return
                self._TMDB_PLOT_LOCK_R35.acquire()
                locked_r35 = True
                title, original_title, year, tmdb_guid = self._tmdb_show_identity_r35(show_rk)
                if not title:
                    _log("TMDB_EPISODE_PLOT_SKIP_R35 show=%s reason=show_not_in_db" % show_rk)
                    return
                tmdb_id, id_src = self._tmdb_resolve_show_r35(show_rk, title, original_title, year, tmdb_guid)
                if not tmdb_id:
                    self._tmdb_plot_cache_save_r35()
                    _log("TMDB_EPISODE_PLOT_SKIP_R35 show=%s title=%s year=%s reason=no_exact_tmdb_match" % (
                        show_rk, _short_log_value(title, 60), year))
                    return
                ready = {}
                seasons = {}
                for rk, season, episode in wanted:
                    seasons.setdefault(self._tmdb_season_r35(season), []).append((rk, episode))
                for tmdb_season, eps in seasons.items():
                    if tmdb_season < 0 or self._closing_event_v1841.is_set():
                        continue
                    plots, plot_src = self._tmdb_season_plots_r35(tmdb_id, tmdb_season)
                    for rk, episode in eps:
                        plot = plots.get(str(_safe_int(episode, -1)))
                        if plot:
                            ready[rk] = plot
                            try:
                                self._tmdb_plot_cache_load_r35()["ep:%s" % rk] = {"p": plot, "t": time.time()}
                            except Exception:
                                pass
                    _log("TMDB_EPISODE_PLOT_SEASON_R35 show=%s tmdb=%s season=%d plots=%d src=%s" % (
                        show_rk, tmdb_id, tmdb_season, len(plots), plot_src))
                self._tmdb_plot_cache_save_r35()
                if token != int(getattr(self, "_tmdb_plot_token_r35", 0) or 0):
                    return
                self._tmdb_plot_ready_r35 = dict(ready)
                _log("TMDB_EPISODE_PLOT_READY_R35 show=%s tmdb=%s id_src=%s filled=%d empty=%d elapsed_ms=%d" % (
                    show_rk, tmdb_id, id_src, len(ready), len(wanted), int((time.time() - t0) * 1000)))
                if ready and not self._closing_event_v1841.is_set():
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
            except Exception:
                _log("TMDB_EPISODE_PLOT_FAILED_R35 show=%s err=%s" % (
                    show_rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            finally:
                if locked_r35:
                    try:
                        self._TMDB_PLOT_LOCK_R35.release()
                    except Exception:
                        pass

        threading.Thread(target=_worker, name="PKMTmdbEpisodePlotR35", daemon=True).start()
        return True

    def _tmdb_episode_plot_commit_r35(self):
        """GUI ping: write ready TMDb plots into still-empty episode ListItems."""
        ready = getattr(self, "_tmdb_plot_ready_r35", None)
        if not ready:
            return False
        self._tmdb_plot_ready_r35 = None
        filled = 0
        for cid in (5712, 5713):
            try:
                ctrl = self.getControl(cid)
                size = int(ctrl.size())
            except Exception:
                continue
            for i in range(max(0, size)):
                try:
                    li = ctrl.getListItem(i)
                    rk = str(li.getProperty("PlexKM.RatingKey") or "")
                    plot = ready.get(rk)
                    if not plot or str(li.getProperty("PlexKM.Summary") or "").strip():
                        continue
                    li.setProperty("PlexKM.Summary", plot)
                    li.setProperty("PlexKM.Summary3", self._info_tv_episode_summary_display_text_v2327(plot))
                    li.setProperty("PlexKM.SummarySourceR35", "tmdb")
                    filled += 1
                except Exception:
                    continue
        focused_r39 = ""
        try:
            sel_r39 = self.getControl(self._info_tv_active_episode_control_id()).getSelectedItem()
            if sel_r39 is not None:
                focused_r39 = "%s:%s" % (sel_r39.getProperty("PlexKM.RatingKey") or "",
                                         "ko" if str(sel_r39.getProperty("PlexKM.Summary") or "").strip() else "empty")
        except Exception:
            pass
        _log("TMDB_EPISODE_PLOT_COMMIT_R35 filled=%d ready=%d focused=%s" % (filled, len(ready), focused_r39 or "-"))
        return filled > 0
