# -*- coding: utf-8 -*-
"""R302: SubDL Korean subtitle download with release-name matching.

Pure helpers (parse/score) are Kodi-free so they can be unit tested.
Network/Kodi pieces are used only from the subtitle popup.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import os
import re
import traceback
import zipfile

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen
    from urllib import urlencode

API_URL = "https://api.subdl.com/api/v1/subtitles"
DL_BASE = "https://dl.subdl.com"
UA = "PKM-Kodi/1.0"

_SRC = (("remux", "remux"), ("bluray", "bluray"), ("blu-ray", "bluray"), ("bdrip", "bluray"),
        ("brrip", "bluray"), ("web-dl", "webdl"), ("webdl", "webdl"), ("webrip", "webrip"),
        ("web", "webdl"), ("hdtv", "hdtv"), ("hdrip", "hdrip"), ("dvdrip", "dvd"))
_RES = ("2160p", "1080p", "720p", "480p")
_CODEC = (("x265", "hevc"), ("h265", "hevc"), ("h.265", "hevc"), ("hevc", "hevc"),
          ("x264", "avc"), ("h264", "avc"), ("h.264", "avc"), ("avc", "avc"))
_OTT = ("nf", "amzn", "dsnp", "atvp", "hmax", "max", "hulu", "tving", "wavve", "cpl", "coupang")
_TAIL = re.compile(r"-([A-Za-z0-9]{2,15})(?:\.[A-Za-z0-9]{2,4})?$")


def parse_release(name):
    """Extract comparable release tags from a file or release name."""
    text = os.path.basename(str(name or "")).lower()
    text = re.sub(r"\.(mkv|mp4|avi|srt|ass|zip)$", "", text)
    info = {"src": "", "res": "", "codec": "", "ott": "", "group": "", "tokens": set()}
    flat = re.sub(r"[\s_\[\]\(\)]+", ".", text)
    toks = set(t for t in re.split(r"[.\-]+", flat) if t)
    info["tokens"] = toks
    for key, val in _SRC:
        if key in flat:
            info["src"] = val
            break
    for r in _RES:
        if r in flat:
            info["res"] = r
            break
    for key, val in _CODEC:
        if key in flat:
            info["codec"] = val
            break
    for o in _OTT:
        if o in toks:
            info["ott"] = o
            break
    m = _TAIL.search(flat)
    if m:
        info["group"] = m.group(1)
    return info


def score_release(video_name, sub_release):
    """Higher is a better sync candidate.  0 means nothing in common."""
    a = parse_release(video_name)
    b = parse_release(sub_release)
    score = 0
    if a["group"] and a["group"] == b["group"]:
        score += 50
    for key, pts in (("src", 25), ("res", 10), ("codec", 8), ("ott", 12)):
        if a[key] and a[key] == b[key]:
            score += pts
        elif a[key] and b[key] and key == "src":
            score -= 10
    common = a["tokens"] & b["tokens"]
    score += min(10, len(common))
    return score


def _get_json(params, timeout=15):
    url = API_URL + "?" + urlencode(params)
    req = Request(url, headers={"User-Agent": UA})
    raw = urlopen(req, timeout=timeout).read()
    return json.loads(raw.decode("utf-8", "replace"))


def search(api_key, video_name, title="", year="", tmdb_id="", season=None, episode=None, log=None):
    """Return Korean subtitle candidates sorted by release match score."""
    params = {"api_key": api_key, "languages": "KO", "subs_per_page": "30"}
    if tmdb_id:
        params["tmdb_id"] = tmdb_id
    elif title:
        params["film_name"] = title
    if year and not season:
        params["year"] = str(year)
    if season:
        params["type"] = "tv"
        params["season_number"] = str(season)
        if episode:
            params["episode_number"] = str(episode)
    else:
        params["type"] = "movie"
    data = _get_json(params)
    if log:
        log("subdl search status=%s subs=%s" % (data.get("status"), len(data.get("subtitles") or [])))
    if not data.get("status"):
        raise RuntimeError(str(data.get("error") or "SubDL error"))
    out = []
    for s in data.get("subtitles") or []:
        url = s.get("url") or ""
        if not url:
            continue
        rel = s.get("release_name") or s.get("name") or ""
        if season and episode:
            try:
                lo = int(s.get("episode_from") or s.get("episode") or 0)
                hi = int(s.get("episode_end") or lo or 0)
                if lo and not s.get("full_season") and not (lo <= int(episode) <= max(hi, lo)):
                    continue
            except Exception:
                pass
        out.append({"url": url, "release": rel, "name": s.get("name") or rel,
                    "author": s.get("author") or "", "fps": s.get("fps"), "score": score_release(video_name, rel),
                    "full_season": bool(s.get("full_season"))})
    out.sort(key=lambda x: (-x["score"], x["full_season"]))
    return out


def _decode(data):
    for enc in ("utf-8-sig", "cp949", "euc-kr", "utf-16"):
        try:
            return data.decode(enc)
        except Exception:
            continue
    return data.decode("utf-8", "replace")


def download_srt(cand, dest_dir, video_name, season=None, episode=None):
    """Download zip, pick best subtitle file, save as UTF-8 .srt, return path."""
    url = cand["url"]
    if not url.startswith("http"):
        url = DL_BASE + (url if url.startswith("/") else "/" + url)
    req = Request(url, headers={"User-Agent": UA})
    raw = urlopen(req, timeout=30).read()
    zf = zipfile.ZipFile(io.BytesIO(raw))
    names = [n for n in zf.namelist() if n.lower().endswith((".srt", ".smi"))]
    if not names:
        raise RuntimeError("zip에 자막 파일이 없습니다")
    ep_pat = None
    if season and episode:
        ep_pat = re.compile(r"s0*%d[\s._-]*e0*%d(?!\d)|(?<!\d)%dx0*%d(?!\d)|(?<!\d)e0*%d(?!\d)" % (
            int(season), int(episode), int(season), int(episode), int(episode)), re.I)
        hit = [n for n in names if ep_pat.search(os.path.basename(n))]
        if hit:
            names = hit
        elif len(names) > 1:
            raise RuntimeError("시즌 묶음에서 해당 회차를 찾지 못했습니다")
    names.sort(key=lambda n: (n.lower().endswith(".srt"), score_release(video_name, os.path.basename(n))), reverse=True)
    pick = names[0]
    text = _decode(zf.read(pick))
    if not os.path.isdir(dest_dir):
        os.makedirs(dest_dir)
    base = re.sub(r"[^\w.\-]+", "_", os.path.splitext(os.path.basename(video_name))[0])[:80] or "subdl"
    path = os.path.join(dest_dir, base + ".ko" + os.path.splitext(pick)[1].lower())
    with io.open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    return path, pick


def plex_context(rating_key):
    """Read file name / title / tmdb id / season / episode from Plex."""
    from resources.lib.pkm_plex_client import plex_request_xml
    root = plex_request_xml("/library/metadata/%s" % rating_key)
    vid = root.find("Video")
    if vid is None:
        raise RuntimeError("Plex 메타데이터 없음")
    ctx = {"file": "", "title": vid.get("title") or "", "year": vid.get("year") or "",
           "tmdb": "", "season": None, "episode": None}
    part = vid.find("Media/Part")
    ctx["duration"] = 0
    ctx["fps"] = 0.0
    ctx["streams"] = []
    try:
        ctx["duration"] = int(vid.get("duration") or 0)
    except Exception:
        pass
    med = vid.find("Media")
    if med is not None:
        ctx["fps"] = _fps_from_plex(med.get("videoFrameRate"))
    if part is not None:
        ctx["file"] = part.get("file") or ""
        for st in part.findall("Stream"):
            if st.get("streamType") == "3":
                ctx["streams"].append({"id": st.get("id") or "", "key": st.get("key") or "",
                                       "codec": (st.get("codec") or "").lower(),
                                       "lang": (st.get("languageCode") or "").lower()})
    if vid.get("type") == "episode":
        ctx["title"] = vid.get("grandparentTitle") or ctx["title"]
        ctx["season"] = vid.get("parentIndex")
        ctx["episode"] = vid.get("index")
        gp = vid.get("grandparentRatingKey")
        if gp:
            try:
                sroot = plex_request_xml("/library/metadata/%s" % gp)
                sd = sroot.find("Directory")
                if sd is not None:
                    ctx["year"] = sd.get("year") or ctx["year"]
                    for g in sd.findall("Guid"):
                        m = re.match(r"tmdb://(\d+)", g.get("id") or "")
                        if m:
                            ctx["tmdb"] = m.group(1)
            except Exception:
                pass
    else:
        for g in vid.findall("Guid"):
            m = re.match(r"tmdb://(\d+)", g.get("id") or "")
            if m:
                ctx["tmdb"] = m.group(1)
    return ctx


# ---------------------------------------------------------------------------
# R303: smart sync (duration check, fps scale, existing-subtitle alignment,
# remembered offsets).  Everything below is Kodi-free except fetch helpers.
# ---------------------------------------------------------------------------
_TIME_SRT = re.compile(r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)")
_TIME_ASS = re.compile(r"Dialogue:\s*\d+,(\d+):(\d+):(\d+)\.(\d+),(\d+):(\d+):(\d+)\.(\d+)")
_TEXT_CODECS = ("srt", "subrip", "ass", "ssa", "mov_text", "webvtt", "text")


def _fps_from_plex(val):
    v = str(val or "").lower()
    if v in ("pal", "25p"):
        return 25.0
    if v in ("24p", "ntsc"):
        return 23.976
    m = re.match(r"(\d+(?:\.\d+)?)", v)
    return float(m.group(1)) if m else 0.0


def _ms(h, m, s, f):
    f = (f + "00")[:3] if len(f) < 3 else f[:3]
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(f)


def parse_cues(text):
    """Return [(start_ms, end_ms)] from SRT/VTT or ASS/SSA text; [] if unknown."""
    cues = []
    for m in _TIME_SRT.finditer(text):
        g = m.groups()
        cues.append((_ms(g[0], g[1], g[2], g[3]), _ms(g[4], g[5], g[6], g[7])))
    if not cues:
        for m in _TIME_ASS.finditer(text):
            g = m.groups()
            cues.append((_ms(g[0], g[1], g[2], g[3] + "0"), _ms(g[4], g[5], g[6], g[7] + "0")))
    cues.sort()
    return cues


def duration_fit(cues, duration_ms):
    """Ratio of last cue end to video length; ~0.6-1.0 is healthy."""
    if not cues or not duration_ms:
        return None
    return float(cues[-1][1]) / float(duration_ms)


def fit_ok(ratio):
    return ratio is None or 0.45 <= ratio <= 1.02


def estimate_offset(existing_starts, new_starts, window_ms=30000, bin_ms=100):
    """Offset to ADD to new cues so they line up with existing ones.

    Returns (offset_ms, confidence 0..1) or (0, 0.0).  Pairwise start-time
    differences are histogrammed; the strongest peak wins.
    """
    a = sorted(existing_starts)
    b = sorted(new_starts)
    if len(a) < 10 or len(b) < 10:
        return 0, 0.0
    hist = {}
    j0 = 0
    for x in a:
        while j0 < len(b) and b[j0] < x - window_ms:
            j0 += 1
        j = j0
        while j < len(b) and b[j] <= x + window_ms:
            k = int(round((x - b[j]) / float(bin_ms)))
            hist[k] = hist.get(k, 0) + 1
            j += 1
    if not hist:
        return 0, 0.0
    best_k, best_v = None, -1
    for k in hist:
        v = hist.get(k - 1, 0) + hist[k] + hist.get(k + 1, 0)
        if v > best_v:
            best_k, best_v = k, v
    diffs = []
    lo = (best_k - 3) * bin_ms
    hi = (best_k + 3) * bin_ms
    j0 = 0
    for x in a:
        while j0 < len(b) and b[j0] < x - window_ms:
            j0 += 1
        j = j0
        while j < len(b) and b[j] <= x + window_ms:
            d = x - b[j]
            if lo <= d <= hi:
                diffs.append(d)
            j += 1
    diffs.sort()
    off = diffs[len(diffs) // 2] if diffs else best_k * bin_ms
    conf = min(1.0, best_v / float(min(len(a), len(b))))
    return int(off), conf


def shift_text(text, offset_ms=0, scale=1.0):
    """Shift/scale all SRT timestamps (cue times only)."""
    def fmt(t):
        t = max(0, int(round(t)))
        return "%02d:%02d:%02d,%03d" % (t // 3600000, t // 60000 % 60, t // 1000 % 60, t % 1000)

    def rep(m):
        g = m.groups()
        a = _ms(g[0], g[1], g[2], g[3]) * scale + offset_ms
        b = _ms(g[4], g[5], g[6], g[7]) * scale + offset_ms
        return "%s --> %s" % (fmt(a), fmt(b))
    return _TIME_SRT.sub(rep, text)


def fps_scale(sub_fps, video_fps):
    try:
        sf = float(sub_fps or 0)
        vf = float(video_fps or 0)
    except Exception:
        return 1.0
    if sf <= 0 or vf <= 0:
        return 1.0
    r = sf / vf
    if abs(r - 1.0) < 0.003 or not (0.9 < r < 1.1):
        return 1.0
    return r


def fetch_existing_cues(ctx, log=None):
    """Download the Plex/embedded Korean (else any) text subtitle, return cues."""
    from resources.lib.pkm_plex_client import plex_url
    streams = [s for s in ctx.get("streams") or [] if s["codec"] in _TEXT_CODECS or s["key"]]
    streams.sort(key=lambda s: (s["lang"] not in ("kor", "ko"), s["key"] == ""))
    for st in streams[:3]:
        path = st["key"] or ("/library/streams/%s" % st["id"])
        if not path or path == "/library/streams/":
            continue
        try:
            url = plex_url(path, include_token=True)
            raw = urlopen(Request(url, headers={"User-Agent": UA}), timeout=15).read()
            cues = parse_cues(_decode(raw))
            if len(cues) >= 10:
                if log:
                    log("subdl existing_sub stream=%s lang=%s cues=%d" % (st["id"], st["lang"], len(cues)))
                return cues
        except Exception as e:
            if log:
                log("subdl existing_sub_failed stream=%s err=%s" % (st["id"], e))
    return []


def _offsets_path(dest_dir):
    return os.path.join(dest_dir, "offsets.json")


def offset_key(ctx, release):
    g = parse_release(release)["group"] or "any"
    return "%s|%s|%s" % (ctx.get("tmdb") or ctx.get("title") or "", ctx.get("season") or "", g)


def load_offset(dest_dir, key):
    try:
        with io.open(_offsets_path(dest_dir), encoding="utf-8") as fh:
            return int(json.load(fh).get(key, 0))
    except Exception:
        return 0


def save_offset(dest_dir, key, offset_ms):
    try:
        data = {}
        try:
            with io.open(_offsets_path(dest_dir), encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            pass
        data[key] = int(offset_ms)
        with io.open(_offsets_path(dest_dir), "w", encoding="utf-8") as fh:
            fh.write(json.dumps(data, ensure_ascii=False))
    except Exception:
        pass


def smart_fix(path, cand, ctx, dest_dir, log=None):
    """Apply fps scale + alignment to the downloaded SRT in place.

    Returns a short Korean status string and the duration-fit ratio.
    """
    if not path.lower().endswith(".srt"):
        return "smi는 자동 보정 대상이 아님", None
    with io.open(path, encoding="utf-8") as fh:
        text = fh.read()
    cues = parse_cues(text)
    if not cues:
        return "", None
    notes = []
    scale = fps_scale(cand.get("fps"), ctx.get("fps"))
    if scale != 1.0:
        text = shift_text(text, 0, scale)
        cues = parse_cues(text)
        notes.append("프레임레이트 보정")
    offset = 0
    key = offset_key(ctx, cand.get("release") or "")
    existing = fetch_existing_cues(ctx, log)
    if existing:
        off, conf = estimate_offset([c[0] for c in existing], [c[0] for c in cues])
        if log:
            log("subdl align offset=%d conf=%.2f" % (off, conf))
        if conf >= 0.25 and abs(off) >= 150:
            offset = off
            save_offset(dest_dir, key, off)
            notes.append("기존 자막 기준 싱크 %+.1f초" % (off / 1000.0))
        elif conf >= 0.25:
            notes.append("싱크 일치")
    else:
        saved = load_offset(dest_dir, key)
        if saved:
            offset = saved
            notes.append("이전 회차 싱크 %+.1f초 적용" % (saved / 1000.0))
    if offset:
        text = shift_text(text, offset, 1.0)
        cues = parse_cues(text)
    if scale != 1.0 or offset:
        with io.open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
    return ", ".join(notes), duration_fit(cues, ctx.get("duration") or 0)
