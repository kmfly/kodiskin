# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import os
import sys
import traceback
import xbmc

ADDON_ID = "plugin.video.km"


def _ensure_addon_root_v2127():
    """Make package imports deterministic for direct RunScript entry points."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        addon_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
        if addon_root and addon_root not in sys.path:
            sys.path.insert(0, addon_root)
        return addon_root
    except Exception:
        return ""


def main():
    try:
        addon_root = _ensure_addon_root_v2127()
        from resources.lib import pkm_video_select
        ok = bool(pkm_video_select.cycle_view_mode(show_toast=True))
        xbmc.log(
            "[%s][video_mode_cycle] VIDEO_MODE_CYCLE_DISPATCH_V2127 ok=%s addon_root=%s"
            % (ADDON_ID, "1" if ok else "0", addon_root),
            xbmc.LOGINFO if ok else xbmc.LOGWARNING,
        )
    except Exception:
        xbmc.log("[%s][video_mode_cycle] failed_v2127\n%s" % (ADDON_ID, traceback.format_exc()), xbmc.LOGERROR)


if __name__ == "__main__":
    main()
