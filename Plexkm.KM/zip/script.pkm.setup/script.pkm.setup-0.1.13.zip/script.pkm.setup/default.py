# -*- coding: utf-8 -*-
import sys

import xbmcaddon

_PATH = xbmcaddon.Addon().getAddonInfo("path")
if _PATH not in sys.path:
    sys.path.insert(0, _PATH)

from resources.lib import wizard

if __name__ == "__main__":
    wizard.run(start=5 if len(sys.argv) > 1 and sys.argv[1] == "taste" else 1)
