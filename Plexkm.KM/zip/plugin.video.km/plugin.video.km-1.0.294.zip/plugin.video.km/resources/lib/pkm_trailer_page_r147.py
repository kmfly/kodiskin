# -*- coding: utf-8 -*-
"""R147: dedicated "related videos" page for the Info trailer button.

Collects official trailers / teasers / making-of / interviews / movie
introductions for a title, shows them as cards with filter chips, and plays the
chosen one full screen (1080p via the YouTube add-on).  Back from the player
returns to this page; Back on the page returns to the Info page.
"""
import os
import re
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui

XML_NAME = "plexkm_trailer_page_r147.xml"
CHIP_IDS = (7501, 7502, 7503, 7504, 7505)
LIST_ID = 7510
KINDS = ("all", "trailer", "teaser", "making", "intro")
CHIP_TEXT = {"all": "전체", "trailer": "예고편", "teaser": "티저", "making": "메이킹 / 인터뷰", "intro": "영화 소개"}
KIND_LABEL = {"trailer": "예고편", "teaser": "티저", "making": "메이킹", "intro": "영화 소개"}
_TTL = 6 * 3600


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] TRAILERPAGE_R147 " + msg, level)
    except Exception:
        pass


def _addon_path():
    try:
        return xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")
    except Exception:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _norm(s):
    return re.sub(r"[\s\W_]+", "", str(s or "").lower())


def _classify(title):
    t = str(title or "").lower()
    if any(w in t for w in ("메이킹", "making", "인터뷰", "interview", "비하인드", "behind", "제작", "featurette", "촬영")):
        return "making"
    if any(w in t for w in ("티저", "teaser", "ティザー")):
        return "teaser"
    if any(w in t for w in ("예고", "trailer", "予告", "预告", "預告")):
        return "trailer"
    if any(w in t for w in ("영화 소개", "소개", "줄거리 없이", "스포 없이", "스포없이", "리뷰 없이", "movie intro")):
        return "intro"
    return ""


_NOISE = ("공식", "official", "예고편", "예고", "trailer", "teaser", "티저", "메인", "main", "hd", "4k", "final", "최종",
          "개봉", "영화", "movie", "한국어", "자막", "더빙", "국내", "해외", "신작", "넷플릭스", "netflix", "드라마", "시리즈",
          "series", "메이킹", "making", "인터뷰", "interview", "비하인드", "behind", "제작", "촬영", "소개", "스포", "없이",
          "클립", "영상", "스페셜", "special", "새로운", "new", "공개", "오리지널", "original", "디렉터스컷", "디렉터스", "컷",
          "무삭제판", "무삭제", "예고영상", "한글", "korean", "the", "of", "and", "in", "to", "theatrical", "international",
          "vhs", "hq", "full", "version", "extended", "restored", "remastered", "uhd", "tv", "spot", "short", "featurette")


def _rest(t, title):
    x = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", str(t or "").lower())
    x = re.sub(r"\b(19|20)\d{2}\b", " ", x)
    x = x.replace(str(title or "").lower(), " ")
    for w in sorted(_NOISE, key=len, reverse=True):
        x = x.replace(w, " ")
    return re.sub(r"[\s\W_\d]+", "", x)


def _dur_sec(d):
    try:
        parts = [int(p) for p in str(d or "").split(":")]
    except Exception:
        return 0
    sec = 0
    for p in parts:
        sec = sec * 60 + p
    return sec


_ORIG_CACHE = {}


def orig_title_for(rating_key):
    """Original title of a Plex item (Info cards do not always carry it)."""
    rk = str(rating_key or "").strip()
    if not rk:
        return ""
    if rk in _ORIG_CACHE:
        return _ORIG_CACHE[rk]
    out = ""
    try:
        import sqlite3
        import xbmcvfs
        dbp = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "plex_km.db")
        conn = sqlite3.connect(dbp, timeout=2.0)
        try:
            row = conn.execute("SELECT plex_type, original_title, grandparent_rating_key, parent_rating_key "
                               "FROM items WHERE rating_key=? LIMIT 1", (rk,)).fetchone()
            if row:
                out = str(row[1] or "").strip()
                if not out and str(row[0] or "") in ("episode", "season"):
                    # Continue-watching cards carry the episode key: use the show's original title.
                    for pk in (row[2], row[3]):
                        if pk:
                            r2 = conn.execute("SELECT original_title FROM items WHERE rating_key=? LIMIT 1", (str(pk),)).fetchone()
                            out = str((r2 or [""])[0] or "").strip()
                            if out:
                                break
        finally:
            conn.close()
    except Exception as exc:
        _log("orig_lookup_fail rk=%s err=%r" % (rk, exc), xbmc.LOGWARNING)
    _ORIG_CACHE[rk] = out
    return out



_TMDB_CACHE = {}


def tmdb_original_for(rating_key, is_tv=False, title="", year="", exclude=()):
    """R148: TMDB original title via TMDb Helper, for items whose Plex original title is
    empty or wrong (e.g. Plex 'A Story of Derry' vs TMDB 'IT: Welcome to Derry')."""
    rk = str(rating_key or "").strip()
    if not rk:
        return ""
    if rk in _TMDB_CACHE:
        return _TMDB_CACHE[rk]
    out = ""
    try:
        import json
        import sqlite3
        import xbmcvfs
        dbp = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"), "plex_km.db")
        conn = sqlite3.connect(dbp, timeout=2.0)
        tid, ttype = "", "tv" if is_tv else "movie"
        try:
            keys = [rk]
            row = conn.execute("SELECT plex_type, raw_json, grandparent_rating_key FROM items WHERE rating_key=? LIMIT 1", (rk,)).fetchone()
            while row:
                m = re.search(r"tmdb://(\d+)", str(row[1] or ""))
                if m:
                    tid = m.group(1)
                    break
                if str(row[0] or "") in ("episode", "season") and row[2] and str(row[2]) not in keys:
                    keys.append(str(row[2]))
                    row = conn.execute("SELECT plex_type, raw_json, grandparent_rating_key FROM items WHERE rating_key=? LIMIT 1", (str(row[2]),)).fetchone()
                    continue
                break
        finally:
            conn.close()
        def _dir(url):
            req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
                "directory": url, "media": "video", "properties": ["title", "originaltitle", "year"]}}
            res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            return (res.get("result") or {}).get("files") or []
        if tid:
            for it in _dir("plugin://plugin.video.themoviedb.helper/?info=details&tmdb_type=%s&tmdb_id=%s" % (ttype, tid)):
                out = str(it.get("originaltitle") or "").strip()
                if out:
                    break
        elif title:
            # Plex ids here come from a Korean agent (no TMDB id): search TMDB by title + year.
            from urllib.parse import quote
            excl = {_norm(x) for x in list(exclude) + [title]}
            qs_ = [title]
            head = re.split(r"\s*[:：]\s+", title, maxsplit=1)[0].strip()
            if head and head != title:
                qs_.append(head)
            for q in qs_:
                for tt in (ttype, "tv" if ttype == "movie" else "movie"):
                    for it in _dir("plugin://plugin.video.themoviedb.helper/?info=search&tmdb_type=%s&query=%s" % (tt, quote(q))):
                        try:
                            ok = (not year) or abs(int(it.get("year") or 0) - int(year)) <= 1
                        except Exception:
                            ok = True
                        o = str(it.get("originaltitle") or "").strip()
                        if ok and o and _norm(o) not in excl:
                            out = o
                            break
                    if out:
                        break
                if out:
                    break
        _log("tmdb_original rk=%s tmdb=%s orig=%r" % (rk, tid, out))
    except Exception as exc:
        _log("tmdb_original_fail rk=%s err=%r" % (rk, exc), xbmc.LOGWARNING)
    _TMDB_CACHE[rk] = out
    return out


def collect(title, year="", is_tv=False, extra="", orig="", rating_key="", _alt=""):
    """Return a list of card dicts (best first), filtered to this title."""
    from resources.lib import pkm_youtube as yt
    from resources.lib import pkm_trailer_r145 as t145
    title = str(title or "").strip()
    if not title:
        return []
    orig = str(orig or "").strip() or orig_title_for(rating_key)
    if _norm(orig) == _norm(title):
        orig = ""
    names = [n for n in (title, orig, _alt) if n]
    # long titles with a subtitle are usually uploaded with only the main part
    for n in list(names):
        head = re.split(r"\s*[:：\-–—]\s+", n, maxsplit=1)[0].strip()
        if head and head != n and len(_norm(head)) >= 3 and head not in names:
            names.append(head)
    main_q = names[-1] if len(names) > 2 else (orig or title)
    _log("collect names=%s rk=%s" % (names, rating_key))
    key = "trailerpage_r147:%s:%s:%d" % (_norm(title), year or "", 1 if is_tv else 0)
    cache = t145._cache_load(yt)
    ent = cache.get(key)
    if isinstance(ent, dict) and (time.time() - float(ent.get("t") or 0)) < _TTL and ent.get("v"):
        return ent["v"]
    qs = ["%s %s 공식 예고편" % (title, year or ""), "%s 티저 예고편" % title, "%s 메이킹 인터뷰" % title,
          "%s 영화 소개 스포 없이" % title, "%s official trailer" % main_q]
    if orig:
        qs.append("%s trailer %s" % (orig, year or ""))
    if orig and re.search(r"[\u3040-\u30ff\u4e00-\u9fff]", orig):
        qs.append("%s 予告編" % orig)
    if is_tv:
        qs[0] = "%s 드라마 공식 예고편" % title
    results = {}

    def run(q):
        try:
            results[q] = yt.it_search(q.strip()).get("videos") or []
        except Exception as exc:
            _log("search_err q=%s err=%r" % (q, exc), xbmc.LOGWARNING)
            results[q] = []
    ths = [threading.Thread(target=run, args=(q,), daemon=True) for q in qs]
    for t in ths:
        t.start()
    for t in ths:
        t.join(timeout=14)
    if not any(results.get(q) for q in qs):
        # parallel burst got nothing (rate limit / hiccup): retry once, one by one
        for q in qs[:3]:
            run(q)
            if results.get(q):
                break
    _log("search_counts %s" % [len(results.get(q) or []) for q in qs])
    seen, out = set(), []
    for q in qs:
        for it in (results.get(q) or [])[:20]:
            vid = str(it.get("id") or "")
            if it.get("kind") != "video" or it.get("live") or not vid or vid in seen:
                continue
            ttl = str(it.get("title") or "")
            tl = ttl.lower()
            if not any(_norm(n) in _norm(ttl) for n in names):
                continue
            if any(b in tl for b in t145._BAD) and not any(g in tl for g in ("스포 없이", "스포없이")):
                continue
            kind = _classify(ttl)
            if not kind:
                continue
            if min(len(_rest(ttl, n)) for n in names) >= 5:
                continue  # about another work (spin-off / series / different film)
            sec = _dur_sec(it.get("duration"))
            if sec and (sec < 20 or sec > 1500):
                continue
            ch = str(it.get("channel") or "")
            chl = ch.lower()
            official = ("공식" in tl or "official" in tl or any(o in chl for o in t145._DOMESTIC)
                        or any(o.lower() in chl for o in t145._OFFICIAL))
            other = re.findall(r"\b(?:19|20)\d{2}\b", ttl)
            if year and other and str(year) not in other:
                continue
            seen.add(vid)
            sc = (20 if official else 0) + {"trailer": 6, "teaser": 4, "making": 2, "intro": 1}[kind]
            if any(o in chl for o in t145._DOMESTIC):
                sc += 8
            if _norm(title) in _norm(ttl):
                sc += 4  # Korean-title upload ranks above the foreign one
            out.append({"id": vid, "title": ttl, "channel": ch, "duration": str(it.get("duration") or ""),
                        "thumb": str(it.get("thumb") or ""), "kind": kind, "official": official, "score": sc})
    if not out and not _alt:
        o2 = tmdb_original_for(rating_key or title, is_tv, title, year, [orig])
        if o2 and _norm(o2) not in (_norm(title), _norm(orig)):
            return collect(title, year, is_tv, extra, o2, rating_key, _alt=orig)
    out.sort(key=lambda d: -d["score"])
    out = out[:24]
    cache[key] = {"t": time.time(), "v": out}
    t145._cache_save(yt, cache)
    return out


class PKMTrailerPage(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.title_text = kwargs.pop("title_text", "")
        self.subtitle = kwargs.pop("subtitle", "")
        self.fanart = kwargs.pop("fanart", "")
        self.cards = list(kwargs.pop("cards", []) or [])
        self.kind = "all"
        self.pending = None
        self.started = False
        self.cancel = False
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def _chips(self):
        for k in KINDS:
            t = CHIP_TEXT[k]
            self.setProperty("PKM.TP.Chip.%s" % k, ("[COLOR FFF5C400]%s[/COLOR]" % t) if k == self.kind else t)

    def _fill(self, focus_first=True):
        self._chips()
        ctrl = self.getControl(LIST_ID)
        ctrl.reset()
        items = []
        for c in self.cards:
            if self.kind != "all" and c["kind"] != self.kind:
                continue
            li = xbmcgui.ListItem(label=c["title"])
            li.setArt({"thumb": c["thumb"]})
            li.setProperty("vid", c["id"])
            li.setProperty("dur", c["duration"])
            li.setProperty("official", "1" if c["official"] else "")
            li.setProperty("kindlabel", KIND_LABEL.get(c["kind"], ""))
            li.setProperty("channel", c["channel"])
            items.append(li)
        if items:
            ctrl.addItems(items)
        self.setProperty("PKM.TP.Count", str(len(items)))
        return len(items)

    def onInit(self):
        try:
            self.setProperty("PKM.TP.Title", self.title_text)
            self.setProperty("PKM.TP.Sub", self.subtitle)
            self.setProperty("PKM.TP.Fanart", self.fanart)
            present = {c["kind"] for c in self.cards}
            for k, cid in zip(KINDS, CHIP_IDS):
                self.setProperty("PKM.TP.Has.%s" % k, "1" if (k == "all" or k in present) else "")
            self.setProperty("PKM.TP.Kind", "all")
            self._fill()
            self.setFocusId(LIST_ID)
        except Exception:
            _log("init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
            self.close()

    def _start_play(self):
        from resources.lib import pkm_ytstream_r146 as ys
        from resources.lib import pkm_notify
        p = self.pending
        _log("play id=%s" % p["id"])
        try:
            ys.play_in_kodi(p["id"], p["title"])
        except Exception:
            _log("play_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        player = xbmc.Player()
        t0 = time.time()
        while time.time() - t0 < 25 and not self.cancel and not player.isPlayingVideo():
            xbmc.sleep(150)
        if self.cancel:
            return
        if player.isPlayingVideo():
            self.started = True
            _log("started after %.1fs" % (time.time() - t0))
            self.close()
            return
        _log("start_timeout")
        self.pending = None
        self.clearProperty("PKM.TP.Loading")
        pkm_notify.pkm_show_notice("예고편", "영상을 재생하지 못했습니다")

    def onAction(self, action):
        try:
            aid = int(action.getId())
        except Exception:
            aid = -1
        if aid in (9, 10, 92, 216) and self.pending and not self.started:
            # Back while the spinner shows: cancel the start, stay on the page
            self.cancel = True
            self.pending = None
            self.clearProperty("PKM.TP.Loading")
            try:
                xbmc.Player().stop()
            except Exception:
                pass
            return
        xbmcgui.WindowXMLDialog.onAction(self, action)

    def onClick(self, control_id):
        try:
            cid = int(control_id)
            if cid in CHIP_IDS:
                self.kind = KINDS[CHIP_IDS.index(cid)]
                self.setProperty("PKM.TP.Kind", self.kind)
                self._fill()
                return
            if cid == LIST_ID:
                if self.pending:
                    return
                li = self.getControl(LIST_ID).getSelectedItem()
                if li is not None:
                    self.pending = {"id": li.getProperty("vid"), "title": li.getLabel()}
                    self.cancel = False
                    self.setProperty("PKM.TP.Loading", "1")  # ring fades in after 350 ms
                    threading.Thread(target=self._start_play, daemon=True).start()
        except Exception:
            _log("click_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def open_page(title, year="", is_tv=False, extra="", fanart="", orig="", rating_key=""):
    """Blocking: show the page; each chosen video plays full screen and returns here."""
    from resources.lib import pkm_notify
    from resources.lib import pkm_ytstream_r146 as ys
    cards = collect(title, year, is_tv, extra, orig, rating_key)
    _log("collected n=%d title=%s" % (len(cards), title))
    if not cards:
        pkm_notify.pkm_show_notice("예고편", "관련 영상을 찾지 못했습니다")
        return False
    sub = " · ".join(x for x in (str(year or ""), "드라마" if is_tv else "영화") if x)
    while True:
        win = PKMTrailerPage(XML_NAME, _addon_path(), "Default", "1080i", title_text=title, subtitle=sub,
                             fanart=fanart, cards=cards)
        win.doModal()
        started = win.started
        del win
        if not started:
            return True
        player = xbmc.Player()
        while player.isPlayingVideo():
            xbmc.sleep(300)
        xbmc.sleep(400)
