# -*- coding: utf-8 -*-
"""상위 폴더 자동 감지: 고른 폴더 아래의 영화/드라마 폴더를 이름과 파일로 나눈다."""
import re

import xbmcvfs

VIDEO_EXT = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".wmv", ".ts", ".m2ts", ".flv", ".webm", ".mpg", ".mpeg", ".iso")
_MOVIE_WORDS = ("영화", "movie", "movies", "film", "films", "시네마")
_TV_WORDS = ("드라마", "tv", "series", "show", "shows", "시리즈", "예능", "애니", "anime")
_EP_RE = re.compile(r"(s\d{1,2}\s?e\d{1,3}|\b\d{1,2}x\d{2,3}\b|ep\.?\s?\d{1,3}\b|\d{1,3}\s?화)", re.I)
_SEASON_RE = re.compile(r"^(season\s*\d+|s\d{1,2}|시즌\s*\d+)$", re.I)


def _join(base, name):
    return base if base.endswith(("/", "\\")) and not name else (base.rstrip("/\\") + "/" + name + "/")


def _list(path):
    try:
        return xbmcvfs.listdir(path)
    except Exception:
        return [], []


def _videos(files):
    return [f for f in files if f.lower().endswith(VIDEO_EXT)]


def _name_hint(name):
    low = name.lower()
    if any(w in low for w in _TV_WORDS):
        return "tvshows"
    if any(w in low for w in _MOVIE_WORDS):
        return "movies"
    return ""


def _content_kind(path, depth=2, budget=None):
    """파일 이름으로 판단: 회차 표시/시즌 폴더가 있으면 드라마, 영상만 있으면 영화, 없으면 ''."""
    budget = budget if budget is not None else {"n": 40}
    dirs, files = _list(path)
    vids = _videos(files)
    if any(_EP_RE.search(v) for v in vids):
        return "tvshows"
    if any(_SEASON_RE.match(d) for d in dirs):
        return "tvshows"
    found_video = bool(vids)
    if depth > 0:
        for d in dirs[:12]:
            if budget["n"] <= 0:
                break
            budget["n"] -= 1
            k = _content_kind(_join(path, d), depth - 1, budget)
            if k == "tvshows":
                return "tvshows"
            if k == "movies":
                found_video = True
    return "movies" if found_video else ""


def _is_container(path):
    """하위 폴더 안에 또 폴더(작품 폴더)가 있으면 라이브러리 폴더로 본다."""
    dirs, _files = _list(path)
    return bool(dirs)


def detect(root):
    """[(path, label, kind)] — kind: movies | tvshows. 못 나누면 [] ."""
    dirs, files = _list(root)
    containers = [d for d in dirs if _is_container(_join(root, d))]
    out = []
    if containers:
        for d in containers:
            p = _join(root, d)
            kind = _name_hint(d) or _content_kind(p)
            if kind:
                out.append((p, d, kind))
        return out
    kind = _name_hint(root.rstrip("/\\").replace("\\", "/").split("/")[-1]) or _content_kind(root)
    if kind:
        out.append((root, root.rstrip("/\\").replace("\\", "/").split("/")[-1] or root, kind))
    return out
