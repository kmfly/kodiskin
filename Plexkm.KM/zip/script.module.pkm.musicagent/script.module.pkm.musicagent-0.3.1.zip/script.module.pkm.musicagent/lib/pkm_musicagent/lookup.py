# -*- coding: utf-8 -*-
"""온라인 조회(4단계 시작): iTunes(한국 스토어) -> Deezer. 후보 목록과 일치 점수.
Kodi 없이 동작. 네트워크는 http_get(url)->dict 를 바꿔 끼울 수 있다(시험·캐시용)."""
import json
import re
import time
import unicodedata
import urllib.parse
import urllib.request
from difflib import SequenceMatcher

from . import parser as P

_UA = "PlexKM-musicagent/0.2 (kodi addon)"
_last = {}
ERRORS = [0]        # 호출 실패 횟수(결과 없음과 구분하려고 센다)


def http_get(url, timeout=12, tries=3):
    """일시적인 실패(연결 오류, 429/5xx, Deezer 호출 한도 오류)는 잠깐 쉬고 다시 시도한다."""
    host = urllib.parse.urlparse(url).netloc
    gap = 3.2 if "itunes" in host else 0.4       # iTunes 는 분당 약 20회
    last = None
    for n in range(tries):
        wait = _last.get(host, 0) + gap - time.time()
        if wait > 0:
            time.sleep(wait)
        _last[host] = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _UA})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
            err = d.get("error") if isinstance(d, dict) else None
            if err and isinstance(err, dict) and err.get("code") in (4, 100):   # Deezer: 호출 한도
                time.sleep(5.0 * (n + 1))
                last = RuntimeError("quota")
                continue
            return d
        except Exception as e:
            last = e
            time.sleep(1.0 * (n + 1))
    raise last


def _nfc(x):
    """파일명의 한글이 낱자로 풀린 형태(NFD)면 서버 검색이 맞지 않는다. 검색어는 항상 NFC 로."""
    return unicodedata.normalize("NFC", x or "")


def _big(url):
    return re.sub(r"/\d+x\d+(bb)?\.", "/600x600bb.", url or "")


ITUNES_BUDGET = [300]     # 한 번의 조회 실행에서 iTunes 를 부를 수 있는 횟수(분당 약 20회 제한 때문)


def itunes(artist, title, get=http_get, country="kr", entities=("song",)):
    out = []
    term = urllib.parse.quote(_nfc(artist + " " + title).strip())
    for ent in entities:
        if ITUNES_BUDGET[0] <= 0:
            break
        ITUNES_BUDGET[0] -= 1
        try:
            d = get("https://itunes.apple.com/search?term=%s&country=%s&entity=%s&limit=10" % (term, country, ent))
        except Exception:
            ERRORS[0] += 1
            continue
        for r in d.get("results", []):
            out.append({"source": "itunes", "type": ent, "artist": r.get("artistName", ""),
                        "title": r.get("trackName", ""), "album": r.get("collectionName", ""),
                        "year": int(str(r.get("releaseDate", "0"))[:4] or 0),
                        "cover": _big(r.get("artworkUrl100", "")), "url": r.get("trackViewUrl", ""),
                        "genre": r.get("primaryGenreName", "")})
    return out


def deezer(artist, title, get=http_get):
    out = []
    artist, title = _nfc(artist), _nfc(title)
    qs = ['artist:"%s" track:"%s"' % (artist, title), "%s %s" % (artist, title)]
    for q in qs:
        try:
            d = get("https://api.deezer.com/search?limit=10&q=" + urllib.parse.quote(q))
        except Exception:
            ERRORS[0] += 1
            continue
        for r in d.get("data", []):
            al = r.get("album", {}) or {}
            out.append({"source": "deezer", "type": "song", "artist": (r.get("artist") or {}).get("name", ""),
                        "title": r.get("title", ""), "album": al.get("title", ""), "year": 0,
                        "cover": al.get("cover_xl") or al.get("cover_big", ""), "url": r.get("link", "")})
        if out:
            break
    return out


def _sim(a, b):
    return SequenceMatcher(None, a, b).ratio() if a and b else 0.0


def score(c, artist, title):
    """0~1. 아티스트와 제목 이름 변형(한글/영문 병기, feat, 버전 표기 제거)을 모두 비교한다."""
    av, tv = P.name_variants(artist), P.title_variants(title)
    ca, ct = P.name_variants(c["artist"]), P.title_variants(c["title"])
    sa = max([1.0 if x == y else 0.9 if (x in y or y in x) and min(len(x), len(y)) >= 3 else _sim(x, y)
              for x in av for y in ca] or [0])
    st = max([1.0 if x == y else 0.9 if (x in y or y in x) and min(len(x), len(y)) >= 3 else _sim(x, y)
              for x in tv for y in ct] or [0])
    return round(0.45 * sa + 0.55 * st, 3)


def _artist_forms(artist):
    """'Girls' Generation(소녀시대)' -> ['Girls' Generation', '소녀시대'] (영문 먼저). 괄호 없이 검색해야 잘 나온다."""
    before, inner = P._split_trailing_paren(_nfc(artist))
    forms = [x for x in (before, inner) if x] or [artist or ""]
    if len(forms) == 1 and re.search(r"[A-Za-z]", forms[0]) and re.search(r"[가-힣]", forms[0]):
        # 'TAEYEON 태연' -> ['TAEYEON', '태연']
        en = re.sub(r"[가-힣]+", " ", forms[0]).strip()
        ko = re.sub(r"[A-Za-z0-9&.\- ]+", " ", forms[0]).strip()
        forms = [x for x in (en, ko) if x] or forms
    forms.sort(key=lambda x: 0 if re.search(r"[A-Za-z]", x) else 1)
    return forms[:2]


def _title_forms(title):
    title = _nfc(title)
    core = re.sub(r"\s*[\(\[][^)\]]*[\)\]]", " ", title or "").strip()
    core = re.sub(r"\s+", " ", core)
    out = [title or ""]
    if core and core != title:
        out.append(core)
    return out


def candidates(artist, title, get=http_get, sources=("deezer", "itunes"), stop_at=0.93, max_tries=3):
    """빠른 출처(Deezer)부터. 충분히 확신하면 뒤 출처는 부르지 않는다. -> 점수순 후보"""
    res, seen = [], set()
    for s in sources:
        tries = 0
        for a in _artist_forms(artist):
            for t in _title_forms(title):
                if tries >= max_tries:
                    break
                tries += 1
                for c in (itunes if s == "itunes" else deezer)(a, t, get):
                    k = (c["source"], c["artist"], c["title"], c["album"])
                    if k not in seen:
                        seen.add(k)
                        c["score"] = score(c, artist, title)
                        res.append(c)
                if res and max(c["score"] for c in res) >= stop_at:
                    break
            if res and max(c["score"] for c in res) >= stop_at:
                break
        if res and max(c["score"] for c in res) >= stop_at:
            break
    res.sort(key=lambda c: (-c["score"], c["source"] != "deezer"))
    return res
