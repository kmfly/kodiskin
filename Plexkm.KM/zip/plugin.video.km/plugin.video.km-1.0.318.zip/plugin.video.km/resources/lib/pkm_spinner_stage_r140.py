# -*- coding: utf-8 -*-
"""R140: PlexKM 공통 링 스피너의 색 단계(Stage) — "재생까지 얼마나 남았나".

11-16 사용자 정리: 색은 기다린 시간이 아니라 **준비 상태**를 보여 준다.
빨강/주황(재생하기 힘든 단계)에서 시작해 준비가 될수록 노랑 → 흰색으로 바뀌고,
흰색이 되면 곧 재생된다.
  slow 주황 : 아직 파일을 못 열었음(PKM 준비·서버 응답 대기)
  wait 노랑 : 파일은 열렸고 영상·음성 준비/버퍼 채우는 중
  ""   흰색  : 곧 재생 (버퍼 거의 참)
스킨은 Window(10000) PlexKM.Spinner.Stage 를 보고 색을 바꾼다(바뀔 때 0.4s 겹침).
재생 시작 외의 화면 로딩 스피너(GlobalBusy 등)는 흰색 그대로.
"""
from __future__ import absolute_import, unicode_literals  # noqa

import threading
import time

import xbmc
import xbmcgui

PROP = "PlexKM.Spinner.Stage"
WAIT_AFTER_S = 1.5
SLOW_AFTER_S = 6.0
CLEAR_AFTER_S = 0.2
POLL_S = 0.1

ANY_SPINNER = (
    "Player.Caching | Player.Seeking"
    " | String.IsEqual(Window(home).Property(PlexKM.SeekQuick.Committing),1)"
    " | String.IsEqual(Window(home).Property(PlexKM.SeekQuick.SeekWaitSpinner),1)"
    " | String.IsEqual(Window(home).Property(PlexKM.Trick.Seeking),1)"
    " | String.IsEqual(Window(10000).Property(PlexKM.Playback.NativeOpening.SpinnerVisible),1)"
    " | String.IsEqual(Window(10000).Property(PlexKM.Playback.NativeOpening),1)"
    " | String.IsEqual(Window(10000).Property(PlexKM.GlobalBusy.Visible),1)"
    " | String.IsEqual(Window(10000).Property(PlexKM.Settings.SyncHandoffCoverV1747),1)"
)

_ORDER = {"": 0, "wait": 1, "slow": 2}
_started = [False]
_hint = [""]


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] %s" % msg, level)
    except Exception:
        pass


def hint(stage):
    """예전 호환용(사용 안 함)."""
    return


def _cache_level():
    try:
        return int(float(xbmc.getInfoLabel("Player.CacheLevel") or -1))
    except Exception:
        return -1


def _want():
    """None = 스피너 없음."""
    try:
        if not xbmc.getCondVisibility(ANY_SPINNER):
            return None
        if xbmc.getCondVisibility("String.IsEqual(Window(10000).Property(PlexKM.Playback.NativeOpening),1)"):
            # 쉴드 실측: 재생 전엔 CacheLevel 이 0 이라 진행률로 못 씀 → 단계로 판단
            if xbmc.getCondVisibility("String.IsEqual(Window(10000).Property(PlexKM.Playback.ResolverPhaseV1547),avstarted)"):
                return ""      # 영상·음성 시작됨(첫 화면 준비 중) → 흰색: 곧 보임
            if not xbmc.getCondVisibility("Player.HasMedia"):
                return "slow"  # 아직 파일을 못 엶 (PKM 준비·서버 연결)
            return "wait"      # 파일 열림, 버퍼 채우는 중
        if xbmc.getCondVisibility("Player.Caching | Player.Seeking"
                                  " | String.IsEqual(Window(home).Property(PlexKM.Trick.Seeking),1)"
                                  " | String.IsEqual(Window(home).Property(PlexKM.SeekQuick.SeekWaitSpinner),1)"
                                  " | String.IsEqual(Window(home).Property(PlexKM.SeekQuick.Committing),1)"):
            lv = _cache_level()
            if lv < 0:
                return "wait"
            return "slow" if lv < 30 else ("wait" if lv < 70 else "")
        return ""
    except Exception:
        return ""


def _run():
    monitor = xbmc.Monitor()
    win = xbmcgui.Window(10000)
    cur = None
    since = None
    while not monitor.abortRequested():
        if monitor.waitForAbort(POLL_S):
            break
        want = _want()
        now = time.time()
        if want is None:
            if cur is not None:
                if since is None:
                    since = now
                if now - since >= CLEAR_AFTER_S:
                    cur = None
                    since = None
                    win.clearProperty(PROP)
            continue
        since = None
        if cur is None:
            cur = want
            win.setProperty(PROP, cur)
            _log("PKM_SPINNER_STAGE_R140 start=%s" % (cur or "white"))
            continue
        # 준비가 될수록 흰색 쪽으로만 감 (주황 -> 노랑 -> 흰색), 되돌아가며 깜빡이지 않음
        if _ORDER[want] < _ORDER[cur]:
            cur = want
            win.setProperty(PROP, cur)
            _log("PKM_SPINNER_STAGE_R140 stage=%s" % (cur or "white"))


def start():
    if _started[0]:
        return
    _started[0] = True
    try:
        xbmcgui.Window(10000).clearProperty(PROP)
        th = threading.Thread(target=_run, name="PKMSpinnerStageR140")
        th.daemon = True
        th.start()
    except Exception:
        _started[0] = False
