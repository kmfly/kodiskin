# PKM_PATCH_ACTIVE v2015 settings_operation_origin_focus_restore_all_pages
# -*- coding: utf-8 -*-
"""
plugin.video.km
Minimal Plex library browser/cache plugin for Kodi skins.

Skin content examples:
  Recommended: resolve Plex library by title so section id changes do not break the skin.
  plugin://plugin.video.km/?action=library&section_title=영화&sort=title
  plugin://plugin.video.km/?action=library&section_title=영화&sort=added
  plugin://plugin.video.km/?action=sync&section_title=영화

  section_id is still supported, but section_title is safer for skin XML.
"""
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_shutdown_v2039 import install_fast_shutdown_policy
install_fast_shutdown_policy()
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import os
import sys
import time
import json
import re
import sqlite3
import traceback
import shutil
import threading
from urllib.parse import urlencode, parse_qsl, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import pkm_notify
from resources.lib import pkm_library_sort
from resources.lib.pkm_video_info import apply_video_info
try:
    from resources.lib import pkm_movie_recommend
except Exception:
    pkm_movie_recommend = None

# Kodi can execute this file from WindowXML via RunScript(file.py, ...),
# where xbmcaddon.Addon() has no implicit add-on context.  Always bind to
# this add-on id explicitly so PKM settings/actions work in script mode too.
ADDON_ID = "plugin.video.km"
try:
    xbmc.log("[plugin.video.km] PKM_PATCH_ACTIVE v2048 initial_sync_exit_prompt_single_window_no_transition_flash", xbmc.LOGINFO)
    xbmc.log("[plugin.video.km] PKM_PATCH_ACTIVE v2054 search_atomic_surface_first_down_control9000_final_fix", xbmc.LOGINFO)
except Exception:
    pass
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")

def _safe_kodi_handle():
    try:
        return int(sys.argv[1]) if len(sys.argv) > 1 else -1
    except Exception:
        # RunScript(default.py, action=...) passes arguments in sys.argv[1:]
        # instead of a plugin handle.  Treat that mode as script execution.
        return -1


HANDLE = _safe_kodi_handle()
# NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
# All movie/episode playback must start as a fully-qualified
# plugin://plugin.video.km/?action=play... URL and be resolved by
# pkm_playback.play_item() with xbmcplugin.setResolvedUrl().
# Do NOT replace this with xbmc.Player().play(), direct http file.mkv playback,
# proxy streaming, pipe headers, or a Python-owned player start path.
#
# WindowXML imports this module outside a normal plugin invocation, where
# sys.argv[0] may be empty or a relative query prefix.  Relative playback URLs
# such as ?action=play cannot be opened by Kodi VideoPlayer, so the base is
# permanently forced to a fully-qualified plugin:// URL.
PLUGIN_BASE_URL = "plugin://%s/" % ADDON_ID
BASE_PLUGIN_URL = sys.argv[0] if (sys.argv and str(sys.argv[0]).startswith("plugin://")) else PLUGIN_BASE_URL

PLEX_TYPE_MOVIE = "movie"
PLEX_TYPE_SHOW = "show"
PLEX_TYPE_EPISODE = "episode"

PLEX_TYPE_TO_NUM = {
    PLEX_TYPE_MOVIE: "1",
    PLEX_TYPE_SHOW: "2",
    PLEX_TYPE_EPISODE: "4",
}

LAST_FETCH_SECTION_STATS = {"movie": 0, "show": 0, "episode": 0}

# v948: init_db() is used by Home ListItem/progress helpers as a lightweight
# read connection factory.  Re-running the whole schema/index bootstrap and
# DB_HEALTH logging for every poster item delayed Home widget paint.  Keep the
# first schema validation, then open later connections as fast read/write handles.
_MAIN_DB_SCHEMA_READY = False
_MAIN_DB_HEALTH_LAST_LOG = {}
_MAIN_DB_JOURNAL_MODE_SET = False


def setting_bool(key, default=False):
    value = ADDON.getSetting(key)
    if value == "":
        return default
    return value.lower() == "true"


def setting_int(key, default=0, min_value=None, max_value=None):
    try:
        value = int(ADDON.getSetting(key))
    except Exception:
        value = int(default)
    if min_value is not None:
        value = max(min_value, value)
    if max_value is not None:
        value = min(max_value, value)
    return value


def debug_enabled():
    return setting_bool("debug_log", True)


def perf_enabled():
    return setting_bool("perf_log", True)


def perf_log(msg):
    if perf_enabled():
        log("PERF " + msg, xbmc.LOGINFO)


def log(msg, level=xbmc.LOGINFO):
    if level == xbmc.LOGDEBUG and not debug_enabled():
        return
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


_KODI_DISPLAY_TRANSLATE = {
    ord("\u007C"): "|",
    ord("\u00A6"): "|",
    ord("\u01C0"): "|",
    ord("\u2016"): "|",
    ord("\u2223"): "|",
    ord("\u2225"): "|",
    ord("\u23AA"): "|",
    ord("\u23D0"): "|",
    ord("\u2502"): "|",
    ord("\u2503"): "|",
    ord("\u2758"): "|",
    ord("\u2759"): "|",
    ord("\u275A"): "|",
    ord("\u3163"): "|",
    ord("\u4E28"): "|",
    ord("\uFF5C"): "|",
    ord("\uFFE8"): "|",
}

def display_text_for_kodi(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")

def display_library_title(value):
    return display_text_for_kodi(value)


def pkm_player_has_video():
    """True while Kodi video playback, OSD, or PKM Home trailer preview is active.

    PKM status notices and background library/Cine21 writes must not intrude on
    playback.  Home trailer preview uses Kodi video playback in a Home video
    window, so its preparing/active flags are treated the same as normal movie
    playback for background-task blocking.  This is a passive state check only;
    it does not control Kodi UI focus/actions.
    """
    try:
        if xbmc.Player().isPlayingVideo():
            return True
    except Exception:
        pass
    try:
        if bool(
            xbmc.getCondVisibility("Player.HasVideo")
            or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
            or xbmc.getCondVisibility("Window.IsActive(videoosd)")
        ):
            return True
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Playback.PriorityV2118") == "1"
            or win.getProperty("PlexKM.Playback.OpeningActive") == "1"
            or win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
            or win.getProperty("PlexKM.Home.TrailerPreparing") == "1"
            or win.getProperty("PlexKM.Home.TrailerActive") == "1"
            or win.getProperty("PlexKM.Home.TrailerFadeHold") == "1"
        )
    except Exception:
        return False


def notify(message, heading=ADDON_NAME, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    """Small PKM in-window notice.

    Avoid Kodi's native notification popup because it is positioned by the
    active skin and appears away from the PKM UI.  PKM renders notice text
    through the WindowXML overlay at the top-right.
    """
    try:
        if pkm_show_notice(heading, message, "", ms=ms):
            return
    except Exception:
        pass
    try:
        log("PKM_NOTICE_NATIVE_SUPPRESSED title=%s message=%s" % (str(heading or ""), str(message or "")), xbmc.LOGINFO)
    except Exception:
        pass


def pkm_notice_set(title, line1="", line2="", token="", sticky=False, force_replace=False):
    return pkm_notify.pkm_notice_set(title, line1, line2, token=token, sticky=sticky, force_replace=force_replace)


def pkm_notice_clear(expected_token="", force=False):
    return pkm_notify.pkm_notice_clear(expected_token=expected_token, force=force)


def pkm_notice_clear_later(expected_token="", ms=1800):
    return pkm_notify.pkm_notice_clear_later(expected_token=expected_token, ms=ms)


def pkm_notice_clear_if_title(prefixes, expected_token="", force=False):
    return pkm_notify.pkm_notice_clear_if_title(prefixes, expected_token=expected_token, force=force)


def pkm_show_notice(title, line1="", line2="", ms=2600):
    return pkm_notify.pkm_show_notice(title, line1, line2, ms=ms)


def _format_startup_sync_notice(stats):
    return pkm_notify.format_startup_sync_notice(stats)

def addon_profile_dir():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return profile


def db_path():
    return os.path.join(addon_profile_dir(), "plex_km.db")


def _safe_file_size(path):
    try:
        if path and os.path.exists(path):
            return int(os.path.getsize(path))
    except Exception:
        pass
    return -1


def _remove_sqlite_sidecar(path, suffix):
    sidecar = "%s%s" % (path, suffix)
    try:
        if os.path.exists(sidecar):
            os.remove(sidecar)
            log("DB_SIDECAR_REMOVED path=%s" % sidecar, xbmc.LOGWARNING)
            return True
    except Exception:
        log("DB_SIDECAR_REMOVE_FAILED path=%s\n%s" % (sidecar, traceback.format_exc()), xbmc.LOGWARNING)
    return False


def _repair_zero_byte_main_db(path, reason="init_db"):
    """Repair the PKM main cache DB when only a zero-byte file is present.

    A valid PKM DB must contain the SQLite header and at least the core schema.
    If the main file is 0 bytes, sqlite3 will happily open it as an empty DB,
    which makes Cine21/settings actions look like they are working against the
    wrong cache.  Remove orphan WAL sidecars first, then let init_db recreate
    the schema in the real plex_km.db file.
    """
    try:
        if not path:
            return False
        exists = os.path.exists(path)
        size = _safe_file_size(path)
        wal_exists = os.path.exists("%s-wal" % path)
        shm_exists = os.path.exists("%s-shm" % path)
        if exists and size == 0:
            log("DB_ZERO_BYTE_DETECTED reason=%s path=%s wal=%s shm=%s" % (reason, path, int(wal_exists), int(shm_exists)), xbmc.LOGWARNING)
            # A zero-byte main file with only SHM/WAL sidecars is not a stable
            # PKM cache.  Remove sidecars so sqlite creates a clean DB file.
            _remove_sqlite_sidecar(path, "-wal")
            _remove_sqlite_sidecar(path, "-shm")
            try:
                os.remove(path)
                log("DB_ZERO_BYTE_REMOVED reason=%s path=%s" % (reason, path), xbmc.LOGWARNING)
            except Exception:
                log("DB_ZERO_BYTE_REMOVE_FAILED reason=%s path=%s\n%s" % (reason, path, traceback.format_exc()), xbmc.LOGWARNING)
            return True
    except Exception:
        log("DB_ZERO_BYTE_REPAIR_CHECK_FAILED reason=%s path=%s\n%s" % (reason, path, traceback.format_exc()), xbmc.LOGWARNING)
    return False


def _connect_main_db(reason="init_db"):
    global _MAIN_DB_JOURNAL_MODE_SET
    path = db_path()
    _repair_zero_byte_main_db(path, reason=reason)
    conn = sqlite3.connect(path, timeout=8.0)
    try:
        conn.execute("PRAGMA busy_timeout=8000")
    except Exception:
        pass
    try:
        # v1775: WAL is required because PKM has concurrent UI readers and
        # background metadata writers. The mode is persistent, so set it only
        # once per process; repeated journal-mode changes can themselves lock.
        if not _MAIN_DB_JOURNAL_MODE_SET:
            conn.execute("PRAGMA journal_mode=WAL")
            _MAIN_DB_JOURNAL_MODE_SET = True
    except Exception:
        log("DB_JOURNAL_MODE_WAL_FAILED path=%s\n%s" % (path, traceback.format_exc()), xbmc.LOGWARNING)
    try:
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")
        conn.execute("PRAGMA temp_store=MEMORY")
    except Exception:
        pass
    return conn


def _log_main_db_health(conn=None, reason="init_db"):
    try:
        # v948: DB_HEALTH is diagnostic only.  On Home startup init_db() can be
        # called hundreds of times by progress/rating helpers; logging every call
        # itself delays the UI and floods kodi.log.
        now = time.time()
        key = str(reason or "")
        last = float(_MAIN_DB_HEALTH_LAST_LOG.get(key) or 0.0)
        if last and (now - last) < 60.0:
            return
        _MAIN_DB_HEALTH_LAST_LOG[key] = now
        path = db_path()
        size = _safe_file_size(path)
        tables = []
        if conn is not None:
            rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name LIMIT 12").fetchall()
            tables = [str(r[0]) for r in rows]
        log("DB_HEALTH reason=%s path=%s size=%s tables=%s" % (reason, path, size, ",".join(tables)), xbmc.LOGINFO)
    except Exception:
        log("DB_HEALTH_FAILED reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)


def state_path():
    return os.path.join(addon_profile_dir(), "state.json")


def sync_lock_path():
    return os.path.join(addon_profile_dir(), "sync.lock")


def playstate_resume_path():
    return os.path.join(addon_profile_dir(), "playstate_resume.json")


def playstate_continue_preload_path():
    # Service-startup prefetch cache used by WindowXML Home so Home does not
    # block on /library/onDeck after the window opens.
    return os.path.join(addon_profile_dir(), "playstate_continue_preload.json")




def _search_index_module():
    from resources.lib import pkm_search_index
    return pkm_search_index


def _search_index_env():
    return {
        "addon_profile_dir": addon_profile_dir,
        "search_db_path": search_db_path,
        "init_db": init_db,
        "selected_sections_state": selected_sections_state,
        "create_progress": _create_pkm_sync_progress,
        "progress_create": progress_create,
        "addon_name": ADDON_NAME,
        "log": log,
    }


def search_db_path():
    """Separate local DB for Plex KM search index.

    The search DB is intentionally separate from plex_km.db so search schema can
    be rebuilt without touching the recommendation DB.  It is populated from the
    already-synced local items table, not by Plex HTTP search.
    """
    return _search_index_module().search_db_path(addon_profile_dir)


def normalize_search_text(value):
    return _search_index_module().normalize_search_text(value)


def hangul_chosung(value):
    return _search_index_module().hangul_chosung(value)


def is_chosung_query(value):
    return _search_index_module().is_chosung_query(value)


def init_search_db(conn=None):
    return _search_index_module().init_search_db(conn, db_path=search_db_path())


def _search_index_payload_from_item(item, section_title=""):
    return _search_index_module().search_index_payload_from_item(item, section_title=section_title)


def upsert_search_index_item(search_conn, item, section_title=""):
    return _search_index_module().upsert_search_index_item(search_conn, item, section_title=section_title)


def delete_search_index_keys(keys):
    return _search_index_module().delete_search_index_keys(keys, _search_index_env())


def ensure_search_db_from_items(force=False, show_progress=False):
    return _search_index_module().ensure_search_db_from_items(force=force, show_progress=show_progress, env=_search_index_env())


def query_search_index(query, limit=80, scope="all"):
    return _search_index_module().query_search_index(query, limit=limit, scope=scope, env=_search_index_env())

def _playstate_pct(time_ms, duration_ms):
    try:
        t = max(0, int(float(time_ms or 0)))
        d = max(0, int(float(duration_ms or 0)))
        if d <= 0:
            return "0.00"
        return "%.2f" % ((float(t) / float(d)) * 100.0)
    except Exception:
        return "0.00"

def _read_local_resume_states():
    try:
        path = playstate_resume_path()
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_local_resume_states(data):
    try:
        path = playstate_resume_path()
        tmp = path + ".tmp"
        entries = len(data or {})
        keys = ",".join(list((data or {}).keys())[:8])
        log("PLAYSTATE_LOCAL_RESUME_WRITE_BEGIN path=%s entries=%s keys=%s" % (path, entries, keys), xbmc.LOGINFO)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data or {}, f, ensure_ascii=False, indent=2, sort_keys=True)
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        os.replace(tmp, path)
        try:
            size = os.path.getsize(path) if os.path.exists(path) else -1
        except Exception:
            size = -1
        log("PLAYSTATE_LOCAL_RESUME_WRITE_DONE path=%s entries=%s size=%s" % (path, entries, size), xbmc.LOGINFO)
        return True
    except Exception as exc:
        log("PLAYSTATE_LOCAL_RESUME_WRITE_FAILED path=%s error=%s" % (locals().get("path", ""), exc), xbmc.LOGWARNING)
        return False


def _safe_int(value, default=0):
    try:
        return int(float(value or 0))
    except Exception:
        return default


def _write_continue_preload_items(items, reason="startup"):
    """Persist a small Continue Watching prefetch produced before Home opens."""
    try:
        path = playstate_continue_preload_path()
        tmp = path + ".tmp"
        safe = []
        for item in list(items or []):
            if not isinstance(item, dict):
                continue
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                continue
            safe.append({
                "rating_key": rk,
                "section_id": str(item.get("section_id") or ""),
                "plex_type": str(item.get("plex_type") or ""),
                "kodi_type": str(item.get("kodi_type") or ""),
                "title": str(item.get("title") or ""),
                "original_title": str(item.get("original_title") or ""),
                "sort_title": str(item.get("sort_title") or item.get("title") or ""),
                "year": _safe_int(item.get("year"), 0),
                "summary": str(item.get("summary") or ""),
                "duration": _safe_int(item.get("duration"), 0),
                "added_at": _safe_int(item.get("added_at"), 0),
                "updated_at": _safe_int(item.get("updated_at"), 0),
                "thumb": str(item.get("thumb") or ""),
                "art": str(item.get("art") or ""),
                "media_file": str(item.get("media_file") or ""),
                "part_key": str(item.get("part_key") or ""),
                "view_count": _safe_int(item.get("view_count"), 0),
                "last_viewed_at": _safe_int(item.get("last_viewed_at"), 0),
                "show_title": str(item.get("show_title") or ""),
                "season": _safe_int(item.get("season"), 0),
                "episode": _safe_int(item.get("episode"), 0),
                "parent_rating_key": str(item.get("parent_rating_key") or ""),
                "grandparent_rating_key": str(item.get("grandparent_rating_key") or ""),
                "view_offset": _safe_int(item.get("view_offset"), 0),
                "resume_duration_ms": _safe_int(item.get("resume_duration_ms"), 0),
                "resume_updated_at": _safe_int(item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at"), 0),
                "resume_source": str(item.get("resume_source") or "plex_ondeck_preload"),
            })
        payload = {"version": 1, "reason": str(reason or ""), "saved_at": int(time.time()), "items": safe}
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        os.replace(tmp, path)
        log("PLAYSTATE_CONTINUE_PRELOAD_WRITE_DONE reason=%s rows=%d path=%s" % (reason, len(safe), path), xbmc.LOGINFO)
        return True
    except Exception as exc:
        log("PLAYSTATE_CONTINUE_PRELOAD_WRITE_FAILED reason=%s error=%s" % (reason, exc), xbmc.LOGWARNING)
        return False


def _read_continue_preload_items(max_age=180):
    try:
        path = playstate_continue_preload_path()
        if not os.path.exists(path):
            return [], 0
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        saved_at = _safe_int((payload or {}).get("saved_at"), 0)
        age = int(time.time()) - saved_at if saved_at else 999999
        if max_age and age > int(max_age):
            log("PLAYSTATE_CONTINUE_PRELOAD_STALE age=%s max_age=%s path=%s" % (age, max_age, path), xbmc.LOGINFO)
            return [], age
        items = (payload or {}).get("items") or []
        if not isinstance(items, list):
            return [], age
        return [i for i in items if isinstance(i, dict)], age
    except Exception as exc:
        log("PLAYSTATE_CONTINUE_PRELOAD_READ_FAILED error=%s" % exc, xbmc.LOGWARNING)
        return [], 0


def record_local_resume_state(rating_key, time_ms=0, duration_ms=0, reason="playback_stopped"):
    """Keep Kodi Continue Watching immediate even when PMS onDeck delays/thresholds it."""
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    try:
        t = max(0, int(float(time_ms or 0)))
    except Exception:
        t = 0
    try:
        d = max(0, int(float(duration_ms or 0)))
    except Exception:
        d = 0
    data = _read_local_resume_states()
    pct = _playstate_pct(t, d)
    # Do not keep entries that are too short or effectively finished.
    finished = bool(d and t >= int(d * 0.90))
    log("PLAYSTATE_LOCAL_RESUME_DECISION rating_key=%s time=%s duration=%s pct=%s finished=%s too_short=%s reason=%s path=%s" % (rk, t, d, pct, "1" if finished else "0", "1" if t < 60000 else "0", reason, playstate_resume_path()), xbmc.LOGINFO)
    if finished or t < 60000:
        if rk in data:
            data.pop(rk, None)
            _write_local_resume_states(data)
        log("PLAYSTATE_LOCAL_RESUME_CLEAR rating_key=%s time=%s duration=%s reason=%s" % (rk, t, d, reason), xbmc.LOGINFO)
        return True
    # Keep the sidecar tiny and recent.
    data[rk] = {"rating_key": rk, "time": t, "duration": d, "updated_at": int(time.time()), "reason": str(reason or "")}
    try:
        cutoff = int(time.time()) - 60 * 60 * 24 * 14
        for key in list(data.keys()):
            if int((data.get(key) or {}).get("updated_at") or 0) < cutoff:
                data.pop(key, None)
    except Exception:
        pass
    ok = _write_local_resume_states(data)
    verify = _read_local_resume_states()
    saved = verify.get(rk) or {}
    log("PLAYSTATE_LOCAL_RESUME_SAVE rating_key=%s time=%s duration=%s pct=%s reason=%s ok=%s verify=%s saved_time=%s saved_duration=%s path=%s" % (rk, t, d, pct, reason, "1" if ok else "0", "1" if rk in verify else "0", saved.get("time", ""), saved.get("duration", ""), playstate_resume_path()), xbmc.LOGINFO)
    return ok


def clear_local_resume_state(rating_key, reason="watched"):
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    data = _read_local_resume_states()
    if rk in data:
        data.pop(rk, None)
        _write_local_resume_states(data)
        log("PLAYSTATE_LOCAL_RESUME_CLEAR rating_key=%s reason=%s" % (rk, reason), xbmc.LOGINFO)
    return True




_SYNC_MODULE_LOGGED = False

def _sync_module():
    from resources.lib import pkm_sync
    global _SYNC_MODULE_LOGGED
    if not _SYNC_MODULE_LOGGED:
        log("SYNC_SPLIT_ACTIVE module=resources.lib.pkm_sync", xbmc.LOGINFO)
        _SYNC_MODULE_LOGGED = True
    return pkm_sync

def _sync_env():
    return {
        "ADDON_NAME": ADDON_NAME,
        "PLEX_TYPE_MOVIE": PLEX_TYPE_MOVIE,
        "PLEX_TYPE_SHOW": PLEX_TYPE_SHOW,
        "PLEX_TYPE_EPISODE": PLEX_TYPE_EPISODE,
        "PLEX_TYPE_TO_NUM": PLEX_TYPE_TO_NUM,
        "log": log,
        "setting_bool": setting_bool,
        "setting_int": setting_int,
        "addon_profile_dir": addon_profile_dir,
        "sync_lock_path": sync_lock_path,
        "load_state": load_state,
        "save_state": save_state,
        "clean_server_url": clean_server_url,
        "plex_token": plex_token,
        "pkm_player_has_video": pkm_player_has_video,
        "pkm_notice_set": pkm_notice_set,
        "pkm_notice_clear": pkm_notice_clear,
        "pkm_notice_clear_later": pkm_notice_clear_later,
        "pkm_notice_clear_if_title": pkm_notice_clear_if_title,
        "pkm_show_notice": pkm_show_notice,
        "signal_home_data_refresh": _signal_home_data_refresh,
        "_format_startup_sync_notice": _format_startup_sync_notice,
        "_create_pkm_sync_progress": _create_pkm_sync_progress,
        "progress_create": progress_create,
        "progress_update": progress_update,
        "fetch_sections": fetch_sections,
        "apply_section_order": apply_section_order,
        "fetch_section_items": fetch_section_items,
        "repair_tv_art_cache_integrity": repair_tv_art_cache_integrity,
        "init_db": init_db,
        "extract_item": extract_item,
        "upsert_item": upsert_item,
        "search_db_path": search_db_path,
        "init_search_db": init_search_db,
        "upsert_search_index_item": upsert_search_index_item,
        # v1330: startup partial sync must persist the same movie/TV detail
        # indexes that Info reads from DB.  Without these env hooks, partial
        # sync only inserted the items row and left item_people/item_genres/
        # item_ratings empty, so the next startup fast-skip treated a sparse
        # newest item as complete.
        "update_recommend_index_from_live_xml": update_recommend_index_from_live_xml,
        "save_tv_show_tag_index": _save_tv_show_tag_index,
        "plex_request_xml": plex_request_xml,
        "xml_attr_int": xml_attr_int,
        "get_last_fetch_section_stats": lambda: dict(LAST_FETCH_SECTION_STATS or {}),
        # v2348: startup membership reconciliation owns deletion of Plex-missing
        # items/sections across every local cache keyed by ratingKey.
        "purge_rating_keys_local_v2348": purge_rating_keys_local_v2348,
        "purge_sections_local_v2348": purge_sections_local_v2348,
    }

def autosync_request_lock_path():
    return _sync_module().autosync_request_lock_path(env=_sync_env())

def _read_lock_timestamp(path):
    return _sync_module()._read_lock_timestamp(path, env=_sync_env())

def is_sync_locked(max_age_sec=1800):
    return _sync_module().is_sync_locked(max_age_sec, env=_sync_env())

def acquire_sync_lock(max_age_sec=1800, label="sync"):
    return _sync_module().acquire_sync_lock(max_age_sec, label, env=_sync_env())

def release_sync_lock():
    return _sync_module().release_sync_lock(env=_sync_env())

def acquire_autosync_request_lock(cooldown_sec=120):
    return _sync_module().acquire_autosync_request_lock(cooldown_sec, env=_sync_env())

def initial_sync_done():
    return _sync_module().initial_sync_done(env=_sync_env())

def set_initial_sync_done(value=True):
    return _sync_module().set_initial_sync_done(value, env=_sync_env())

def last_auto_sync_at():
    return _sync_module().last_auto_sync_at(env=_sync_env())

def set_last_auto_sync_at(value=None):
    return _sync_module().set_last_auto_sync_at(value, env=_sync_env())

def _remote_total_for_path(path, params=None):
    return _sync_module()._remote_total_for_path(path, params, env=_sync_env())

def remote_section_counts(section):
    return _sync_module().remote_section_counts(section, env=_sync_env())

def remote_section_total(section):
    return _sync_module().remote_section_total(section, env=_sync_env())

def _remote_section_latest_items(section, limit=10):
    return _sync_module()._remote_section_latest_items(section, limit, env=_sync_env())

def _local_section_latest_items(section_id, plex_type=None, limit=10):
    return _sync_module()._local_section_latest_items(section_id, plex_type, limit, env=_sync_env())

def _latest_item_keys(rows):
    return _sync_module()._latest_item_keys(rows, env=_sync_env())

def verify_section_latest_for_fast_skip(section, limit=10):
    return _sync_module().verify_section_latest_for_fast_skip(section, limit, env=_sync_env())

def local_section_counts(section_id):
    return _sync_module().local_section_counts(section_id, env=_sync_env())

def local_tv_tag_index_missing_for_section(section_id):
    return _sync_module().local_tv_tag_index_missing_for_section(section_id, env=_sync_env())

def local_section_count(section_id):
    return _sync_module().local_section_count(section_id, env=_sync_env())

def update_section_count(section_id, count_value):
    return _sync_module().update_section_count(section_id, count_value, env=_sync_env())

def load_local_section_meta_map():
    return _sync_module().load_local_section_meta_map(env=_sync_env())

def load_sync_state_map():
    return _sync_module().load_sync_state_map(env=_sync_env())

def update_sync_state(section_id, remote_updated_at=0, remote_count=0, synced=False):
    return _sync_module().update_sync_state(section_id, remote_updated_at, remote_count, synced, env=_sync_env())

def _pkm_service_abort_requested():
    return _sync_module()._pkm_service_abort_requested(env=_sync_env())

def startup_prehome_authority_gate_v2349():
    return _sync_module().startup_prehome_authority_gate_v2349(env=_sync_env())

def ensure_startup_cache_ready(show_progress=True, notice_progress=False, caller="startup", precreated_progress=None):
    return _sync_module().ensure_startup_cache_ready(
        show_progress=show_progress,
        notice_progress=notice_progress,
        caller=caller,
        precreated_progress=precreated_progress,
        env=_sync_env(),
    )

def auto_sync_due():
    return _sync_module().auto_sync_due(env=_sync_env())

def maybe_trigger_background_auto_sync(caller="library"):

    audit_event(None, "sync_maybe_trigger_background_auto_sync_enter")
    return _sync_module().maybe_trigger_background_auto_sync(caller, env=_sync_env())


def large_wall_focus_state_path():
    return os.path.join(addon_profile_dir(), "large_wall_focus_state.json")


def large_wall_prepare_lock_path(section_id):
    safe = str(section_id or "").replace(os.sep, "_").replace("/", "_").replace("\\", "_")
    return os.path.join(addon_profile_dir(), "large_wall_prepare_%s.lock" % safe)












def load_state():
    path = state_path()
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def save_state(state):
    try:
        with open(state_path(), "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log("state save failed: %s" % e, xbmc.LOGWARNING)


def _section_id_list(sections):
    return [str(s.get("section_id", "")) for s in sections if str(s.get("section_id", ""))]


def get_section_order():
    try:
        order = load_state().get("section_order", [])
        if isinstance(order, list):
            return [str(x) for x in order if str(x)]
    except Exception:
        pass
    return []


def set_section_order(order):
    state = load_state()
    state["section_order"] = [str(x) for x in order if str(x)]
    state["section_order_updated_at"] = int(time.time())
    save_state(state)


def apply_section_order(sections, save_merged=False):
    """Apply user-defined sidebar library order. New Plex libraries are appended."""
    sections = list(sections or [])
    by_id = {}
    for section in sections:
        sid = str(section.get("section_id", ""))
        if sid:
            by_id[sid] = section
    order = get_section_order()
    ordered = []
    used = set()
    for sid in order:
        if sid in by_id and sid not in used:
            ordered.append(by_id[sid])
            used.add(sid)
    for section in sections:
        sid = str(section.get("section_id", ""))
        if sid and sid not in used:
            ordered.append(section)
            used.add(sid)
    merged_order = _section_id_list(ordered)
    if save_merged and merged_order != order:
        set_section_order(merged_order)
    return ordered


def selected_sections_state():
    state = load_state()
    values = state.get("selected_sections", [])
    if not isinstance(values, list):
        values = []
    selected = [str(x) for x in values if str(x)]
    configured = bool(state.get("selected_sections_configured", False))
    return selected, configured


def selected_sections_startup_state_v1975():
    """Read startup library-selection state without silently converting errors.

    Returns (selected, configured, status), where status is one of:
      ok            valid persisted state
      missing       state file does not exist
      invalid       JSON/schema is invalid
      read_error    state file exists but could not be read

    This function never writes or repairs user state. Startup callers use the
    status only to choose a safe surface and must not turn an error into an
    explicit empty selection.
    """
    path = state_path()
    if not os.path.exists(path):
        return [], False, "missing"
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        log("LIBRARY_SELECTION_STARTUP_STATE_READ_FAILED_V1975 path=%s err=%s" % (
            path, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGERROR)
        return [], False, "read_error"
    if not isinstance(state, dict):
        log("LIBRARY_SELECTION_STARTUP_STATE_INVALID_V1975 reason=not_object path=%s" % path, xbmc.LOGERROR)
        return [], False, "invalid"
    values = state.get("selected_sections", [])
    configured_value = state.get("selected_sections_configured", False)
    if not isinstance(values, list) or not isinstance(configured_value, bool):
        log("LIBRARY_SELECTION_STARTUP_STATE_INVALID_V1975 reason=schema path=%s" % path, xbmc.LOGERROR)
        return [], False, "invalid"
    selected = []
    seen = set()
    for value in values:
        sid = str(value or "")
        if sid and sid not in seen:
            selected.append(sid)
            seen.add(sid)
    return selected, bool(configured_value), "ok"


def selected_section_ids():
    selected, configured = selected_sections_state()
    return selected if configured else []


def section_selection_configured():
    return bool(selected_sections_state()[1])


def _selected_section_filter_context_v1458():
    """v1458: selected libraries are a visibility filter, including Continue Watching.

    Cached rows for unchecked libraries are intentionally retained for fast
    re-enable, but they must not appear in Home/Continue/Search-visible flows.
    """
    try:
        selected, configured = selected_sections_state()
        selected_set = set([str(x) for x in (selected or []) if str(x)])
        return bool(configured), selected_set
    except Exception:
        return False, set()


def _section_visible_by_selection_v1458(section_id, configured=None, selected_set=None):
    """Return True only when the item belongs to an explicitly selected library.

    Library selection is the visibility source of truth.  An unconfigured or
    empty selection therefore owns no Plex content; it is never interpreted as
    "all libraries".  This rule applies equally to live Plex responses and
    local/cache rows.
    """
    if configured is None or selected_set is None:
        configured, selected_set = _selected_section_filter_context_v1458()
    if not configured or not selected_set:
        return False
    return str(section_id or "") in selected_set



def save_selected_sections(section_ids):
    state = load_state()
    clean = []
    seen = set()
    for sid in section_ids or []:
        sid = str(sid or "")
        if sid and sid not in seen:
            clean.append(sid)
            seen.add(sid)
    old = [str(x) for x in state.get("selected_sections", []) if str(x)] if isinstance(state.get("selected_sections", []), list) else []
    state["selected_sections"] = clean
    state["selected_sections_configured"] = True
    state["selected_sections_updated_at"] = int(time.time())
    save_state(state)
    added = [x for x in clean if x not in old]
    removed = [x for x in old if x not in clean]
    log("LIBRARY_SELECTION_SAVE selected=%s added=%s removed=%s" % (",".join(clean), ",".join(added), ",".join(removed)), xbmc.LOGINFO)
    return added, removed


def filter_selected_sections(sections):
    sections = list(sections or [])
    selected, configured = selected_sections_state()
    selected_set = set([str(x) for x in selected if str(x)])
    if not configured or not selected_set:
        log("LIBRARY_SELECTION_SCOPE_V1979 configured=%d selected=0 before=%d after=0 rule=selection_intersection" % (1 if configured else 0, len(sections)), xbmc.LOGINFO)
        return []
    filtered = [s for s in sections if str(s.get("section_id", "")) in selected_set]
    log("LIBRARY_SELECTION_FILTER configured=1 before=%d after=%d selected=%s" % (len(sections), len(filtered), ",".join(selected)), xbmc.LOGDEBUG)
    return filtered


def purge_unselected_library_data(keep_section_ids):
    keep = [str(x) for x in keep_section_ids or [] if str(x)]
    placeholders = ",".join(["?"] * len(keep))
    conn = init_db()
    removed_items = 0
    try:
        if keep:
            removed_items = conn.execute("DELETE FROM items WHERE section_id NOT IN (%s)" % placeholders, keep).rowcount
            conn.execute("DELETE FROM sync_state WHERE section_id NOT IN (%s)" % placeholders, keep)
        else:
            removed_items = conn.execute("DELETE FROM items").rowcount
            conn.execute("DELETE FROM sync_state")
        conn.commit()
    finally:
        conn.close()
    try:
        sconn = sqlite3.connect(search_db_path())
        init_search_db(sconn)
        try:
            if keep:
                sconn.execute("DELETE FROM search_items WHERE section_id NOT IN (%s)" % placeholders, keep)
            else:
                sconn.execute("DELETE FROM search_items")
            sconn.execute("UPDATE search_index_state SET source_count=0, search_count=(SELECT COUNT(*) FROM search_items), source_max_synced_at=0, indexed_at=?, last_error='' WHERE id=1", (int(time.time()),))
            sconn.commit()
        finally:
            sconn.close()
    except Exception:
        log("LIBRARY_SELECTION_SEARCH_PURGE_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    log("LIBRARY_SELECTION_PURGE keep=%s removed_items=%s" % (",".join(keep), removed_items), xbmc.LOGINFO)
    return removed_items





# Settings dialogs were split out of default.py in v632.
# Keep these wrapper names for existing call sites and WindowXML RunScript actions.
# v636: import the split modules lazily so Home/Section startup does not load
# settings-only WindowXMLDialog code until a settings action is actually used.
def _settings_flow_module():
    from resources.lib import pkm_settings_flow
    return pkm_settings_flow


def _library_selection_flow_module():
    from resources.lib import pkm_library_selection_flow
    return pkm_library_selection_flow


def _open_pkm_confirm_dialog(title, message, yes_label="예", no_label="아니요", **kwargs):
    return _settings_flow_module().open_pkm_confirm_dialog(
        title, message, yes_label=yes_label, no_label=no_label, **kwargs
    )


def _open_pkm_message_dialog(title, message, ok_label="확인", icon1="", icon2=""):
    return _settings_flow_module().open_pkm_message_dialog(title, message, ok_label=ok_label, icon1=icon1, icon2=icon2)


def _open_pkm_list_dialog(title, labels, multiselect=False, preselect=None):
    return _settings_flow_module().open_pkm_list_dialog(title, labels, multiselect=multiselect, preselect=preselect)


def _open_pkm_settings_flow_dialog():
    return _settings_flow_module().open_pkm_settings_flow_dialog()



def _signal_home_data_refresh(reason="sync"):


    audit_event(None, "sync__signal_home_data_refresh_enter")
    """Signal a data refresh without mutating WindowXML controls off the GUI thread.

    v1554: the token alone could be missed when Home was opening/closing, and some
    successful sync paths did not leave a durable dirty state.  Persist a global
    dirty + pending flag together with the token.  PlexKMHomeWindow consumes it
    only from Kodi GUI-thread callbacks (onAction/onFocus/menu entry).
    """
    try:
        token = "%d" % int(time.time() * 1000)
        reason_s = str(reason or "sync")
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Home.DataRefreshToken", token)
        win.setProperty("PlexKM.Home.DataRefreshReason", reason_s)
        if not reason_s.startswith("cine21_"):
            win.setProperty("PlexKM.PlexUpdate.Dirty", "1")
            win.setProperty("PlexKM.Home.SyncRefreshPendingV1554", "1")
            win.setProperty("PlexKM.Home.SyncRefreshPendingTokenV1554", token)
            win.setProperty("PlexKM.Home.SyncRefreshPendingReasonV1554", reason_s)
            win.setProperty("PlexKM.PlexUpdate.Time", str(int(time.time())))
        log("HOME_DATA_REFRESH_SIGNAL_V1554 reason=%s token=%s dirty=%s gui_mutation=0" % (
            reason_s, token, "0" if reason_s.startswith("cine21_") else "1"
        ), xbmc.LOGINFO)
        return token
    except Exception:
        log("HOME_DATA_REFRESH_SIGNAL_FAILED reason=%s\n%s" % (reason or "sync", traceback.format_exc()), xbmc.LOGWARNING)
        return ""

def _section_local_cache_count(section_id):
    try:
        return int(local_section_count(str(section_id or "")) or 0)
    except Exception:
        return 0


def _verify_selected_library_cache_after_selection(precreated_progress=None, show_progress=True):
    return ensure_startup_cache_ready(
        show_progress=bool(show_progress),
        notice_progress=False,
        caller="library_selection",
        precreated_progress=precreated_progress,
    )


def _show_library_selection_notice(title, line1="", line2="", ms=3000):
    try:
        pkm_show_notice(title, line1, line2, ms=ms)
    except Exception:
        try:
            notify("%s %s" % (line1 or "", line2 or ""), heading=title or ADDON_NAME, ms=ms)
        except Exception:
            pass


def _library_selection_env():
    return {
        "addon_name": ADDON_NAME,
        "clean_server_url": clean_server_url,
        "plex_token": plex_token,
        "notify": notify,
        "fetch_sections": fetch_sections,
        "apply_section_order": apply_section_order,
        "selected_sections_state": selected_sections_state,
        "save_selected_sections": save_selected_sections,
        "purge_unselected_library_data": purge_unselected_library_data,
        "local_section_count": _section_local_cache_count,
        "verify_selected_library_cache": _verify_selected_library_cache_after_selection,
        "show_notice": _show_library_selection_notice,
        "open_confirm": _open_pkm_confirm_dialog,
        "open_message": _open_pkm_message_dialog,
        "open_list": _open_pkm_list_dialog,
        "set_initial_sync_done": set_initial_sync_done,
        "initial_sync_done": initial_sync_done,
        "sync_all_sections": sync_all_sections,
        "signal_home_data_refresh": _signal_home_data_refresh,
        "prearm_sync_progress": _prearm_sync_progress_v1747,
        "progress_complete_and_wait": progress_complete_and_wait,
        "log": log,
    }


def _library_selection_rows(live_required=False):
    return _library_selection_flow_module().library_selection_rows(_library_selection_env(), live_required=live_required)


def _apply_library_selection(all_sections, chosen, force=False, auth_initial=False):
    return _library_selection_flow_module().apply_library_selection(_library_selection_env(), all_sections, chosen, force=force, auth_initial=auth_initial)


def choose_libraries_dialog(force=False):
    return _library_selection_flow_module().choose_libraries_dialog(_library_selection_env(), force=force)




# Add-on setting helpers live in resources/lib/pkm_settings_flow.py.
def _addon_get_bool(setting_id, default=False):
    return _settings_flow_module().addon_get_bool(setting_id, default=default)


def _addon_set_bool(setting_id, value):
    return _settings_flow_module().addon_set_bool(setting_id, value)


def _addon_get_int(setting_id, default=0):
    return _settings_flow_module().addon_get_int(setting_id, default=default)


def _addon_set_int(setting_id, value):
    return _settings_flow_module().addon_set_int(setting_id, value)


def _mask_secret(value):
    return _settings_flow_module().mask_secret(value)


def _short_setting_value(value, max_len=34):
    return _settings_flow_module().short_setting_value(value, max_len=max_len)


def _bool_label(value):
    return _settings_flow_module().bool_label(value)


def _pkm_setting_input(label, current, hidden=False):
    return _settings_flow_module().pkm_setting_input(label, current, hidden=hidden)


def _pkm_setting_number(label, current, minimum=None, maximum=None):
    return _settings_flow_module().pkm_setting_number(label, current, minimum=minimum, maximum=maximum)


def _pkm_setting_file_browse(title, current_value=""):
    return _settings_flow_module().pkm_setting_file_browse(title, current_value=current_value)


def _open_pkm_addon_settings_dialog():
    return _settings_flow_module().open_pkm_addon_settings_dialog(handle=HANDLE)


def open_pkm_settings_dialog():
    action = _open_pkm_settings_flow_dialog()
    if action == "cine21_update":
        cine21_update_from_settings({})
    elif action == "restart_exit":
        log("PKM_SETTINGS_FLOW_RESTART_EXIT_V2090 action=hold_current_surface_until_quit home_reopen=0", xbmc.LOGINFO)
        return
    elif action == "open_home":
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.Home.PostResetLogoPendingV2008")
        except Exception:
            pass
        # Settings is modal over the persistent Home window. Do not create a
        # second Home instance. Only open Home when settings was launched with
        # no PKM Home window present.
        if not xbmc.getCondVisibility("Window.IsVisible(13000)"):
            open_window_home({"index": "home", "sort": "added", "source": "pkm_settings_home_button"})
        else:
            log("PKM_SETTINGS_FLOW_HOME_APPLY action=keep_existing_home reopen=0", xbmc.LOGINFO)
        return
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def move_section_in_order(section_id, direction):
    section_id = str(section_id or "")
    if not section_id:
        notify("Library id is missing", icon=xbmcgui.NOTIFICATION_WARNING)
        return False
    sections = apply_section_order(fetch_sections(refresh=True), save_merged=True)
    order = _section_id_list(sections)
    if section_id not in order:
        notify("Library not found", icon=xbmcgui.NOTIFICATION_WARNING)
        return False
    idx = order.index(section_id)
    if direction == "up":
        if idx <= 0:
            notify("Already at the top")
            return False
        swap = idx - 1
    elif direction == "down":
        if idx >= len(order) - 1:
            notify("Already at the bottom")
            return False
        swap = idx + 1
    else:
        notify("Unknown move direction", icon=xbmcgui.NOTIFICATION_WARNING)
        return False
    order[idx], order[swap] = order[swap], order[idx]
    set_section_order(order)
    notify("Library order updated")
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return True















































def _progress_dialog_module():
    from resources.lib import pkm_progress_dialog
    return pkm_progress_dialog


def _create_pkm_sync_progress(caller_modal_v1927=False):
    return _progress_dialog_module().create_pkm_sync_progress(
        caller_modal_v1927=bool(caller_modal_v1927)
    )


# v1964: visible sync UI is platform-neutral PKM WindowXML.
PKM_SYNC_UI_UNIFIED_V1965 = True


def progress_create(progress, heading, message=""):
    return _progress_dialog_module().progress_create(progress, heading, message)


def progress_update(progress, percent, message=""):
    return _progress_dialog_module().progress_update(progress, percent, message)


def progress_complete_and_wait(progress, heading, message="", exit_on_confirm=False, button_label="확인", action_hint="확인 후 홈으로 이동"):
    return _progress_dialog_module().progress_complete_and_wait(
        progress, heading, message,
        exit_on_confirm=exit_on_confirm,
        button_label=button_label,
        action_hint=action_hint,
    )


def _prearm_sync_progress_v1747(heading, message="싱크 준비 중"):
    """Create and initialize the real progress window before confirm closes.

    v1747 applies this to both uncached full sync and cached-library verification.
    It first gives window 13032 a short chance to finish onInit behind the
    confirmation dialog. If Kodi defers the nested modal until confirmation
    closes, the parent settings window displays an opaque sync-preparing cover
    until progress onInit clears it, so the library-selection page cannot flash.
    """
    progress = None
    started = time.perf_counter()
    try:
        try:
            base_id = xbmcgui.getCurrentWindowId()
            dialog_id = xbmcgui.getCurrentWindowDialogId()
        except Exception:
            base_id, dialog_id = -1, -1
        log("PKM_SYNC_PROGRESS_PREARM_BEGIN_V1747 base=%s dialog=%s vis13031=%d vis13032=%d" % (
            base_id, dialog_id,
            1 if xbmc.getCondVisibility("Window.IsVisible(13031)") else 0,
            1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0,
        ), xbmc.LOGINFO)
        # v1964: prearm the same caller-owned PKM WindowXML on every platform.
        # It is opened by sync_all_sections() only after the confirmation stack
        # has closed, so Windows and Android share one GUI ownership model.
        progress = _create_pkm_sync_progress(caller_modal_v1927=True)
        if progress is None:
            return None
        progress_create(progress, heading or ADDON_NAME, message or "싱크 준비 중")
        if bool(getattr(progress, "_caller_modal_v1927", False)):
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            log(
                "PKM_SYNC_PROGRESS_PREARM_READY_V1927 android_caller_modal=1 "
                "helper_windowxml_thread=0 accepted=1 elapsed_ms=%.1f" % elapsed_ms,
                xbmc.LOGINFO,
            )
            return progress
        monitor = xbmc.Monitor()
        visible = False
        initialized = False
        deadline = time.perf_counter() + 0.25
        while time.perf_counter() < deadline and not monitor.abortRequested():
            try:
                visible = bool(xbmc.getCondVisibility("Window.IsVisible(13032)"))
            except Exception:
                visible = False
            try:
                initialized = bool(getattr(progress, "_init_event", None) and progress._init_event.is_set())
            except Exception:
                initialized = False
            if visible and initialized:
                break
            xbmc.sleep(5)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        try:
            base_id = xbmcgui.getCurrentWindowId()
            dialog_id = xbmcgui.getCurrentWindowDialogId()
        except Exception:
            base_id, dialog_id = -1, -1
        try:
            modal_thread = getattr(progress, "_modal_thread", None)
            thread_alive = bool(modal_thread is not None and modal_thread.is_alive())
            closed = bool(getattr(progress, "_closed", False))
        except Exception:
            thread_alive = False
            closed = True
        accepted = bool((visible and initialized) or (thread_alive and not closed))
        log("PKM_SYNC_PROGRESS_PREARM_READY_V1747 visible=%d initialized=%d thread_alive=%d closed=%d accepted=%d elapsed_ms=%.1f base=%s dialog=%s vis13031=%d vis13032=%d cover=1" % (
            1 if visible else 0, 1 if initialized else 0, 1 if thread_alive else 0, 1 if closed else 0,
            1 if accepted else 0, elapsed_ms, base_id, dialog_id,
            1 if xbmc.getCondVisibility("Window.IsVisible(13031)") else 0,
            1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0,
        ), xbmc.LOGINFO if accepted else xbmc.LOGWARNING)
        if not accepted:
            try:
                progress.close()
            except Exception:
                pass
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.Settings.SyncHandoffCoverV1747")
            except Exception:
                pass
            return None
        return progress
    except Exception:
        log("PKM_SYNC_PROGRESS_PREARM_FAILED_V1747\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        return None



_PLEX_CLIENT_MODULE_LOGGED = False


def _plex_client_module():
    from resources.lib import pkm_plex_client
    global _PLEX_CLIENT_MODULE_LOGGED
    if not _PLEX_CLIENT_MODULE_LOGGED:
        log("PLEX_CLIENT_SPLIT_ACTIVE module=resources.lib.pkm_plex_client", xbmc.LOGINFO)
        _PLEX_CLIENT_MODULE_LOGGED = True
    return pkm_plex_client


def _plex_client_env():
    return {
        "addon": ADDON,
        "addon_name": ADDON_NAME,
        "log": log,
        "pkm_show_notice": pkm_show_notice,
        "pkm_notice_set": pkm_notice_set,
        "pkm_notice_clear": pkm_notice_clear,
        "pkm_notice_clear_later": pkm_notice_clear_later,
        "pkm_notice_clear_if_title": pkm_notice_clear_if_title,
    }


def clean_server_url():
    return _plex_client_module().clean_server_url(env=_plex_client_env())


def plex_token():
    return _plex_client_module().plex_token(env=_plex_client_env())


def token_masked():
    return _plex_client_module().token_masked(env=_plex_client_env())


def append_token(url):
    return _plex_client_module().append_token(url, env=_plex_client_env())


def plex_url(path, params=None, include_token=True):
    return _plex_client_module().plex_url(path, params=params, include_token=include_token, env=_plex_client_env())


def plex_request_xml(path, params=None, timeout=20, log_failures=True, bypass_cache=False):
    return _plex_client_module().plex_request_xml(
        path,
        params=params,
        timeout=timeout,
        log_failures=log_failures,
        env=_plex_client_env(),
        bypass_cache=bypass_cache,
    )


def plex_request(path, params=None, timeout=8, method="GET"):
    return _plex_client_module().plex_request(
        path,
        params=params,
        timeout=timeout,
        method=method,
        env=_plex_client_env(),
    )


def art_url(path, width=1920, height=1920):
    return _plex_client_module().art_url(path, width=width, height=height, env=_plex_client_env())

_PLAYBACK_MODULE_LOGGED = False

def _playback_module():
    from resources.lib import pkm_playback
    global _PLAYBACK_MODULE_LOGGED
    if not _PLAYBACK_MODULE_LOGGED:
        log("PLAYBACK_SPLIT_ACTIVE module=resources.lib.pkm_playback", xbmc.LOGINFO)
        _PLAYBACK_MODULE_LOGGED = True
    return pkm_playback


def _clear_continue_preload_items_v1989():
    """Remove persisted Continue Watching preload while library activation is incomplete."""
    removed = False
    for path in (playstate_continue_preload_path(), playstate_continue_preload_path() + ".tmp"):
        try:
            if path and os.path.exists(path):
                os.remove(path)
                removed = True
        except Exception:
            pass
    return removed


def _playback_env():
    return {
        "addon": ADDON,
        "addon_name": ADDON_NAME,
        "handle": HANDLE,
        "log": log,
        "perf_log": perf_log,
        "notify": notify,
        "extract_item": extract_item,
        "init_db": init_db,
        "upsert_item": upsert_item,
        "write_continue_preload_items": _write_continue_preload_items,
        "clear_continue_preload_items": _clear_continue_preload_items_v1989,
        "initial_sync_done": initial_sync_done,
    }


def build_plugin_url(params):
    base = BASE_PLUGIN_URL if str(BASE_PLUGIN_URL).startswith("plugin://") else PLUGIN_BASE_URL
    if not base.endswith("/"):
        base += "/"
    return base + "?" + urlencode(params)


def get_params():
    # v1316: Split real plugin invocation from RunScript invocation explicitly.
    # Plugin mode: sys.argv = [plugin://..., handle, ?query].
    # RunScript mode: sys.argv = [default.py, action=..., delta=..., source=...].
    # v1315 checked sys.argv[2] first, so RunScript(default.py, action=seek_quick,
    # delta=10, ...) parsed only "delta=10" and fell back to the root action.
    # That made LEFT/RIGHT start expensive library loading instead of PKM seek.
    if HANDLE != -1 and len(sys.argv) >= 3 and sys.argv[2]:
        return dict(parse_qsl(sys.argv[2].lstrip("?")))
    if len(sys.argv) > 1:
        raw_parts = []
        for x in sys.argv[1:]:
            s = str(x).strip()
            if not s:
                continue
            # Be defensive if Kodi passes a leading comma/space or a plugin-style query.
            s = s.lstrip("?, ")
            if s:
                raw_parts.append(s)
        raw = "&".join(raw_parts)
        return dict(parse_qsl(raw)) if raw else {}
    return {}

















def plex_timeline(rating_key, state="playing", time_ms=0, duration_ms=0, context="playback"):
    return _playback_module().plex_timeline(
        rating_key,
        state=state,
        time_ms=time_ms,
        duration_ms=duration_ms,
        context=context,
        env=_playback_env(),
    )
def plex_scrobble(rating_key, reason="playback_ended"):
    return _playback_module().plex_scrobble(rating_key, reason=reason, env=_playback_env())
def plex_unscrobble(rating_key, reason="playback_resume"):
    return _playback_module().plex_unscrobble(rating_key, reason=reason, env=_playback_env())
def refresh_item_state_from_plex(rating_key, reason="playstate"):
    return _playback_module().refresh_item_state_from_plex(rating_key, reason=reason, env=_playback_env())
def sync_play_state_from_plex_light(reason="startup", limit=120):
    return _playback_module().sync_play_state_from_plex_light(reason=reason, limit=limit, env=_playback_env())
def _actor_thumb_origin_v2148(url, plex_host=""):
    """Classify the actor artwork URL already stored in item_people.

    Diagnostic only: no network request, cache write, or metadata mutation.
    """
    value = str(url or "").strip()
    if not value:
        return "missing", ""
    low = value.lower()
    if low.startswith("/"):
        return "plex_internal", "relative"
    try:
        parsed = urlparse(value)
        host = str(parsed.netloc or "").split("@")[-1].split(":")[0].lower().strip()
    except Exception:
        host = ""
    if plex_host and host and host == plex_host:
        return "plex_internal", host
    if host.endswith("plex.tv") or host.endswith("plex.direct"):
        return "plex_metadata_cdn", host
    if "daumcdn.net" in host or host.endswith("daum.net"):
        return "daum", host
    if "tmdb.org" in host or "themoviedb.org" in host:
        return "tmdb", host
    if "thetvdb.com" in host or host.endswith("tvdb.com"):
        return "tvdb", host
    if low.startswith("http://") or low.startswith("https://"):
        return "other_external", host or "unknown_http_host"
    return "other", host or "non_http"


def _actor_thumb_sync_report_v2148(phase="library_core", section_ids=None):
    """Log actor-thumb availability immediately after library construction.

    This intentionally reads only plex_km.db.  It never fetches an actor image,
    never opens Info, and never repairs metadata.  The report tells us whether
    Role.thumb already exists during sync, before any Info page is visited.
    """
    conn = None
    try:
        conn = init_db()
        ids = [str(x).strip() for x in (section_ids or []) if str(x).strip()]
        params = []
        where = "WHERE p.person_type='actor'"
        if ids:
            where += " AND p.section_id IN (%s)" % ",".join(["?"] * len(ids))
            params.extend(ids)
        rows = conn.execute("""
            SELECT p.section_id,
                   COALESCE(s.section_type,''),
                   COALESCE(p.person_name,''),
                   COALESCE(p.person_thumb,'')
            FROM item_people p
            LEFT JOIN sections s ON s.section_id=p.section_id
            %s
            ORDER BY p.section_id, p.rating_key, p.sort_order
        """ % where, tuple(params)).fetchall()

        try:
            base = str(clean_server_url() or "").strip()
            plex_host = str(urlparse(base).netloc or "").split("@")[-1].split(":")[0].lower().strip()
        except Exception:
            plex_host = ""

        def summarize(subrows):
            counts = {
                "plex_internal": 0,
                "plex_metadata_cdn": 0,
                "daum": 0,
                "tmdb": 0,
                "tvdb": 0,
                "other_external": 0,
                "other": 0,
                "missing": 0,
            }
            names = set()
            thumbs = set()
            hosts = {}
            missing_names = []
            for _sid, _stype, name, thumb in subrows:
                norm_name = str(name or "").strip().casefold()
                if norm_name:
                    names.add(norm_name)
                origin, host = _actor_thumb_origin_v2148(thumb, plex_host=plex_host)
                counts[origin] = int(counts.get(origin, 0)) + 1
                clean_thumb = str(thumb or "").strip()
                if clean_thumb:
                    thumbs.add(clean_thumb)
                elif name and len(missing_names) < 8:
                    missing_names.append(str(name).replace("|", "/")[:48])
                if host and origin != "missing":
                    hosts[host] = int(hosts.get(host, 0)) + 1
            return counts, names, thumbs, hosts, missing_names

        groups = [("all", rows)]
        groups.append(("movie", [r for r in rows if str(r[1] or "") == PLEX_TYPE_MOVIE]))
        groups.append(("show", [r for r in rows if str(r[1] or "") == PLEX_TYPE_SHOW]))
        for media, subrows in groups:
            counts, names, thumbs, hosts, missing_names = summarize(subrows)
            thumb_rows = len(subrows) - int(counts.get("missing", 0))
            log(
                "ACTOR_THUMB_SYNC_REPORT_V2148 phase=%s media=%s rows=%d unique_actors=%d thumb_rows=%d missing=%d unique_thumb_urls=%d plex_internal=%d plex_metadata_cdn=%d daum=%d tmdb=%d tvdb=%d other_external=%d other=%d info_open_required=0 network_fetch=0" % (
                    phase, media, len(subrows), len(names), thumb_rows, int(counts.get("missing", 0)), len(thumbs),
                    int(counts.get("plex_internal", 0)), int(counts.get("plex_metadata_cdn", 0)),
                    int(counts.get("daum", 0)), int(counts.get("tmdb", 0)), int(counts.get("tvdb", 0)),
                    int(counts.get("other_external", 0)), int(counts.get("other", 0)),
                ),
                xbmc.LOGINFO,
            )
            if hosts:
                top_hosts = sorted(hosts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
                log("ACTOR_THUMB_SYNC_HOSTS_V2148 phase=%s media=%s hosts=%s" % (
                    phase, media, ",".join(["%s:%d" % (host, count) for host, count in top_hosts])
                ), xbmc.LOGINFO)
            if missing_names:
                log("ACTOR_THUMB_SYNC_MISSING_SAMPLE_V2148 phase=%s media=%s names=%s" % (
                    phase, media, "|".join(missing_names)
                ), xbmc.LOGINFO)
        return True
    except Exception:
        log("ACTOR_THUMB_SYNC_REPORT_FAILED_V2148 phase=%s err=%s" % (
            phase, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return False
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def init_db():
    global _MAIN_DB_SCHEMA_READY
    conn = _connect_main_db(reason="init_db")
    if _MAIN_DB_SCHEMA_READY:
        return conn
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sections (
            section_id TEXT PRIMARY KEY,
            title TEXT,
            section_type TEXT,
            thumb TEXT,
            art TEXT,
            scanned_at INTEGER DEFAULT 0,
            item_count INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sync_state (
            section_id TEXT PRIMARY KEY,
            remote_updated_at INTEGER DEFAULT 0,
            remote_count INTEGER DEFAULT 0,
            last_checked_at INTEGER DEFAULT 0,
            last_synced_at INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            rating_key TEXT PRIMARY KEY,
            section_id TEXT,
            plex_type TEXT,
            kodi_type TEXT,
            title TEXT,
            original_title TEXT,
            sort_title TEXT,
            year INTEGER,
            summary TEXT,
            duration INTEGER,
            added_at INTEGER,
            updated_at INTEGER,
            checksum TEXT,
            thumb TEXT,
            art TEXT,
            media_file TEXT,
            part_key TEXT,
            view_count INTEGER,
            last_viewed_at INTEGER,
            parent_rating_key TEXT,
            grandparent_rating_key TEXT,
            show_title TEXT,
            season INTEGER,
            episode INTEGER,
            raw_json TEXT,
            synced_at INTEGER
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_section_sort ON items(section_id, sort_title COLLATE NOCASE)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_section_added ON items(section_id, added_at DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_section_updated ON items(section_id, updated_at DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_type ON items(section_id, plex_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_episode_show_progress ON items(plex_type, grandparent_rating_key, view_count)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_file ON items(media_file)")
    # v472: TV recommendation rows bulk-resolve show -> first episode by
    # section/type/grandparent/season/episode.  Keep this in the DB schema so
    # large TV libraries do not scan the episode table during side-menu moves.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_items_tv_first_episode ON items(section_id, plex_type, grandparent_rating_key, season, episode, rating_key)")
    init_recommend_index_schema(conn)
    conn.commit()
    _MAIN_DB_SCHEMA_READY = True
    try:
        if _safe_file_size(db_path()) <= 0:
            log("DB_MAIN_FILE_STILL_ZERO_AFTER_SCHEMA path=%s" % db_path(), xbmc.LOGERROR)
        else:
            _log_main_db_health(conn, reason="init_db_after_schema")
    except Exception:
        pass
    return conn



# -----------------------------------------------------------------------------
# Recommendation index DB (v213 test)
# -----------------------------------------------------------------------------

_RECOMMEND_SCHEMA_READY = False
_RECOMMEND_INDEX_SOURCE_VERSION = "plex_db_v227_kr_foreign_main_actor_widgets"
_RECOMMEND_INDEX_API_SOURCE_VERSION = "plex_api_sync_v1736"
LAST_PLEX_DB_COPY_BENCH = {}
LAST_RECOMMEND_DB_IMPORT_BENCH = {}
LAST_FETCH_RECOMMEND_BENCH = {}
_KOREA_COUNTRY_NAMES = set([
    "한국", "대한민국", "남한", "코리아",
    "korea", "south korea", "republic of korea", "korean",
    "kr", "kor", "대한 민국", "大韓民国", "韓国",
])


def init_recommend_index_schema(conn):
    """Extend the existing plex_km.db with recommendation index tables.

    These tables are intentionally stored in the same DB as items, so 1~3 rows
    and future recommendation rows can share rating_key/thumb/art data.
    """
    global _RECOMMEND_SCHEMA_READY
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_people (
            rating_key TEXT,
            section_id TEXT,
            person_type TEXT,
            person_name TEXT,
            role TEXT,
            person_thumb TEXT,
            tag_id TEXT,
            sort_order INTEGER DEFAULT 0,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0,
            PRIMARY KEY(rating_key, person_type, person_name, sort_order)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_genres (
            rating_key TEXT,
            section_id TEXT,
            genre TEXT,
            tag_id TEXT,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0,
            PRIMARY KEY(rating_key, genre)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_countries (
            rating_key TEXT,
            section_id TEXT,
            country TEXT,
            tag_id TEXT,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0,
            PRIMARY KEY(rating_key, country)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_ratings (
            rating_key TEXT PRIMARY KEY,
            section_id TEXT,
            rating REAL,
            audience_rating REAL,
            user_rating REAL,
            score REAL,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0
        )
    """)
    # v471: TV show studio/network tags are stored in the main cache DB so
    # section recommendation rows never need Plex live scans during sidebar moves.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_studios (
            rating_key TEXT,
            section_id TEXT,
            studio_type TEXT,
            studio_name TEXT,
            tag_id TEXT,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0,
            PRIMARY KEY(rating_key, studio_type, studio_name)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_recommend_index_state (
            section_id TEXT PRIMARY KEY,
            source TEXT DEFAULT '',
            indexed_at INTEGER DEFAULT 0,
            item_count INTEGER DEFAULT 0,
            people_count INTEGER DEFAULT 0,
            genre_count INTEGER DEFAULT 0,
            country_count INTEGER DEFAULT 0,
            rating_count INTEGER DEFAULT 0,
            last_error TEXT DEFAULT ''
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_type_name ON item_people(person_type, person_name)")
    # v2351: actor identity expansion also probes Plex Role tag_id/thumb aliases.
    # Without matching indexes SQLite can fall back to a full item_people scan for
    # each of the first three actors, which is visible as ~0.7-0.8 s per actor on
    # large libraries.  Build these with the normal DB schema/index bootstrap, not
    # inside the Info click path.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_type_tag ON item_people(person_type, tag_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_type_thumb ON item_people(person_type, person_thumb)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_section_type ON item_people(section_id, person_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_type_name_rating ON item_people(person_type, person_name, rating_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_genres_section ON item_genres(section_id, genre)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_countries_section ON item_countries(section_id, country)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_countries_country_section ON item_countries(country, section_id, rating_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_ratings_score ON item_ratings(section_id, score DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_studios_section_type_name ON item_studios(section_id, studio_type, studio_name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_studios_type_name_rating ON item_studios(studio_type, studio_name, rating_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_studios_rating_type ON item_studios(rating_key, studio_type, studio_name)")
    # v226: recommendation widgets must be as fast as normal rows.  These
    # indexes keep the DB-local path from scanning large movie/person tables
    # while building director/actor/country widgets.
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_items_section_type_key ON items(section_id, plex_type, rating_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_items_type_section_key ON items(plex_type, section_id, rating_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_items_episode_show_progress ON items(plex_type, grandparent_rating_key, view_count)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_items_thumb_key ON items(rating_key, thumb, art)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_items_tv_first_episode ON items(section_id, plex_type, grandparent_rating_key, season, episode, rating_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_rating_type ON item_people(rating_key, person_type, person_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_actor_main ON item_people(person_type, sort_order, person_name, rating_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_item_people_name_order ON item_people(person_type, person_name, sort_order, rating_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_item_ratings_key_score ON item_ratings(rating_key, score DESC)")
    except Exception:
        pass
    _RECOMMEND_SCHEMA_READY = True


def _recommend_index_conn():
    conn = init_db()
    return conn


def _db_columns(conn, table):
    try:
        return set(str(r[1]) for r in conn.execute("PRAGMA table_info(%s)" % table).fetchall())
    except Exception:
        return set()


def _db_has_table(conn, table):
    try:
        row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        return bool(row)
    except Exception:
        return False


def _float_or_none(value):
    try:
        if value in (None, ""):
            return None
        return float(value)
    except Exception:
        return None


def _score_from_values(rating=None, audience=None, user=None):
    # Prefer Plex audienceRating for recommendations, then rating, then userRating.
    for v in (audience, rating, user):
        fv = _float_or_none(v)
        if fv is not None:
            return fv
    return None


def _normalize_tag_name(value):
    try:
        value = (value or "").strip()
        if not value:
            return ""
        return value.replace("\x00", "").strip()
    except Exception:
        return ""


def _split_possible_tag_text(value):
    """Best-effort parser for Plex metadata_items tags_* text columns if present."""
    value = _normalize_tag_name(value)
    if not value:
        return []
    # Plex builds differ: these columns may contain comma text, pipe text or ids.
    parts = []
    for sep in ("|", ","):
        if sep in value:
            parts = [p.strip() for p in value.split(sep)]
            break
    if not parts:
        parts = [value]
    out = []
    for p in parts:
        p = _normalize_tag_name(p)
        if not p:
            continue
        # If the column is just a tag id list, do not treat ids as names.
        if p.isdigit():
            continue
        out.append(p)
    return out


def _is_korea_country_name(value):
    name = _normalize_tag_name(value).lower()
    if not name:
        return False
    compact = name.replace(".", " ").replace("_", " ").replace("-", " ")
    compact = " ".join(compact.split())
    if compact in _KOREA_COUNTRY_NAMES:
        return True
    # Plex country strings sometimes arrive as longer localized labels.
    if compact in ("south korea", "republic of korea"):
        return True
    return False


def _country_bucket_from_candidates(candidates):
    """Store only one country bucket per item: 한국 or 외국.

    The recommendation UI only needs Korean-vs-foreign separation. Saving every
    Plex country/tag value made item_countries explode when Plex tag_type mapping
    differed by DB version, so keep this table deliberately coarse.
    """
    korea = False
    sources = []
    for it in candidates or []:
        name = it.get("name", "") if isinstance(it, dict) else str(it or "")
        if name:
            sources.append(name)
        if _is_korea_country_name(name):
            korea = True
            break
    bucket = "한국" if korea else "외국"
    return [{
        "name": bucket,
        "tag_id": "",
        "role": "",
        "thumb": "",
        "sort_order": 0,
        "source": "country_bucket:korea" if korea else "country_bucket:foreign",
    }]


# Common Plex tag_type mapping seen in the user's Plex library DB.
# Country must NOT be inferred from taggings tag_type 6/8: those types are very
# high-volume in this schema and caused 10~20 false countries per movie.  Use
# metadata_items.tags_country only until a verified country tag_type is logged.
_GENRE_TAG_TYPES = set([1])
_DIRECTOR_TAG_TYPES = set([3])
_ACTOR_TAG_TYPES = set([5, 7])
_COUNTRY_TAG_TYPES = set([])


def plex_db_copy_setting():
    # v1925: Recommendation metadata is built from the normal Plex API sync.
    # Ignore any legacy copied-Plex-DB path that may remain in addon_data.
    return ""


def recommend_index_source_enabled():
    # v1925: Recommendation widgets are a core PKM feature, not an optional
    # user toggle. Keep their local index synchronized on every library sync.
    return True


def _copy_plex_db_to_temp(src_path):
    global LAST_PLEX_DB_COPY_BENCH
    LAST_PLEX_DB_COPY_BENCH = {"ok": False, "elapsed_ms": 0.0, "bytes": 0, "method": "none", "src": str(src_path or "")}
    if not src_path:
        return ""
    src_path = xbmcvfs.translatePath(src_path) if src_path.startswith("special://") else src_path
    profile = addon_profile_dir()
    tmp_dir = os.path.join(profile, "tmp")
    if not xbmcvfs.exists(tmp_dir):
        xbmcvfs.mkdirs(tmp_dir)
    dst_path = os.path.join(tmp_dir, "plex_library_import_copy.db")
    try:
        if xbmcvfs.exists(dst_path):
            xbmcvfs.delete(dst_path)
    except Exception:
        pass
    t0 = time.perf_counter()
    ok = False
    copy_method = "none"
    try:
        if os.path.exists(src_path):
            shutil.copy2(src_path, dst_path)
            ok = True
            copy_method = "shutil_local"
        else:
            ok = bool(xbmcvfs.copy(src_path, dst_path))
            if ok:
                copy_method = "xbmcvfs_copy"
            if not ok:
                src_handle = None
                try:
                    src_handle = xbmcvfs.File(src_path, "rb")
                    with open(dst_path, "wb") as dst_handle:
                        while True:
                            chunk = src_handle.read(4 * 1024 * 1024)
                            if not chunk:
                                break
                            if isinstance(chunk, str):
                                chunk = chunk.encode("latin-1", "ignore")
                            dst_handle.write(chunk)
                    ok = bool(os.path.exists(dst_path) and os.path.getsize(dst_path) > 0)
                    copy_method = "xbmcvfs_stream_4m"
                    log("[PKM_INDEX] plex_db_vfs_stream_copy_v1700 src=%s ok=%s bytes=%s" % (src_path, "1" if ok else "0", os.path.getsize(dst_path) if os.path.exists(dst_path) else 0), xbmc.LOGINFO)
                finally:
                    try:
                        if src_handle:
                            src_handle.close()
                    except Exception:
                        pass
    except Exception:
        log("[PKM_INDEX] plex_db_copy_failed path=%s\n%s" % (src_path, traceback.format_exc()), xbmc.LOGWARNING)
        ok = False
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    if not ok or not xbmcvfs.exists(dst_path):
        LAST_PLEX_DB_COPY_BENCH = {"ok": False, "elapsed_ms": elapsed_ms, "bytes": 0, "method": copy_method, "src": src_path}
        log("[PKM_INDEX] plex_db_copy_failed path=%s elapsed=%.1fms" % (src_path, elapsed_ms), xbmc.LOGWARNING)
        log("[PKM_BENCH] RECOMMEND_DB_COPY_DONE mode=plex_db result=failed method=%s elapsed_ms=%.1f bytes=0" % (copy_method, elapsed_ms), xbmc.LOGINFO)
        return ""
    try:
        size = xbmcvfs.Stat(dst_path).st_size()
    except Exception:
        size = 0
    LAST_PLEX_DB_COPY_BENCH = {"ok": True, "elapsed_ms": elapsed_ms, "bytes": int(size or 0), "method": copy_method, "src": src_path, "dst": dst_path}
    log("[PKM_INDEX] plex_db_copy_done src=%s dst=%s bytes=%s elapsed=%.1fms" % (src_path, dst_path, size, elapsed_ms), xbmc.LOGINFO)
    log("[PKM_BENCH] RECOMMEND_DB_COPY_DONE mode=plex_db result=success method=%s elapsed_ms=%.1f bytes=%d" % (copy_method, elapsed_ms, int(size or 0)), xbmc.LOGINFO)
    return dst_path

def _local_movie_items_for_sections(section_ids=None):
    conn = init_db()
    try:
        if section_ids:
            ids = [str(x) for x in section_ids if str(x)]
            if not ids:
                return []
            placeholders = ",".join(["?"] * len(ids))
            sql = """
                SELECT rating_key, section_id, updated_at, title
                FROM items
                WHERE plex_type='movie' AND section_id IN (%s)
            """ % placeholders
            rows = conn.execute(sql, ids).fetchall()
        else:
            rows = conn.execute("""
                SELECT rating_key, section_id, updated_at, title
                FROM items
                WHERE plex_type='movie'
            """).fetchall()
        return [(str(r[0]), str(r[1]), int(r[2] or 0), r[3] or "") for r in rows if r and r[0]]
    finally:
        conn.close()


def _recommend_index_current_for_items(local_items, reason=""):
    """Return True when the current local movie item set is already indexed by v222.

    This prevents re-importing 18k+ rows from the Plex DB on every Kodi/PKM run.
    A new source version intentionally invalidates older test imports such as
    plex_db/plex_db_v221 so fixes like country mapping can be applied once.
    """
    if not local_items:
        return False
    counts = {}
    for _rk, sid, _updated, _title in local_items:
        sid = str(sid)
        counts[sid] = counts.get(sid, 0) + 1
    conn = init_db()
    try:
        init_recommend_index_schema(conn)
        for sid, expected in counts.items():
            row = conn.execute(
                "SELECT source, item_count, people_count, genre_count, country_count, rating_count, indexed_at FROM item_recommend_index_state WHERE section_id=?",
                (sid,),
            ).fetchone()
            if not row:
                log("[PKM_INDEX] import_needed reason=no_state section=%s expected=%d trigger=%s" % (sid, expected, reason), xbmc.LOGINFO)
                return False
            source, item_count, people_count, genre_count, country_count, rating_count, indexed_at = row
            if source != _RECOMMEND_INDEX_SOURCE_VERSION:
                log("[PKM_INDEX] import_needed reason=source_mismatch section=%s source=%s expected_source=%s trigger=%s" % (sid, source, _RECOMMEND_INDEX_SOURCE_VERSION, reason), xbmc.LOGINFO)
                return False
            if int(item_count or 0) != int(expected):
                log("[PKM_INDEX] import_needed reason=item_count_mismatch section=%s db=%s expected=%s trigger=%s" % (sid, item_count, expected, reason), xbmc.LOGINFO)
                return False
            if int(indexed_at or 0) <= 0:
                log("[PKM_INDEX] import_needed reason=not_indexed section=%s trigger=%s" % (sid, reason), xbmc.LOGINFO)
                return False
            # Guard against the old false-country imports.  A sane movie country
            # index should normally be well below 5 countries per item.
            if int(country_count or 0) > int(expected) * 5:
                log("[PKM_INDEX] import_needed reason=country_count_suspicious section=%s countries=%s expected_items=%s trigger=%s" % (sid, country_count, expected, reason), xbmc.LOGINFO)
                return False
            if not _recommend_index_section_is_physically_valid(conn, sid, expected_items=expected, reason=reason):
                log("[PKM_INDEX] import_needed reason=physical_rows_missing section=%s expected=%s trigger=%s" % (sid, expected, reason), xbmc.LOGINFO)
                return False
        log("[PKM_INDEX] import_skip reason=index_current source=%s sections=%d items=%d trigger=%s" % (_RECOMMEND_INDEX_SOURCE_VERSION, len(counts), len(local_items), reason), xbmc.LOGINFO)
        try:
            log_recommend_index_summary(reason="index_current:%s" % reason)
        except Exception:
            pass
        return True
    except Exception:
        log("[PKM_INDEX] import_current_check_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass



def log_recommend_index_summary(reason=""):
    """Diagnostic summary proving recommendation index contents and country bucketing."""
    conn = init_db()
    try:
        init_recommend_index_schema(conn)
        state_rows = conn.execute(
            "SELECT section_id, source, item_count, people_count, genre_count, country_count, rating_count, indexed_at FROM item_recommend_index_state ORDER BY CAST(section_id AS INTEGER), section_id"
        ).fetchall()
        log("[PKM_INDEX] summary_state reason=%s sections=%d source_expected=%s|%s" % (
            reason, len(state_rows), _RECOMMEND_INDEX_SOURCE_VERSION, _RECOMMEND_INDEX_API_SOURCE_VERSION
        ), xbmc.LOGINFO)
        for row in state_rows:
            sid, source, item_count, people_count, genre_count, country_count, rating_count, indexed_at = row
            country_rows = conn.execute(
                "SELECT country, COUNT(DISTINCT rating_key) FROM item_countries WHERE section_id=? GROUP BY country ORDER BY country",
                (str(sid),),
            ).fetchall()
            country_summary = ",".join(["%s:%s" % (str(c[0]), int(c[1] or 0)) for c in country_rows])
            people_rows = conn.execute(
                "SELECT person_type, COUNT(DISTINCT rating_key), COUNT(DISTINCT person_name) FROM item_people WHERE section_id=? GROUP BY person_type ORDER BY person_type",
                (str(sid),),
            ).fetchall()
            people_summary = ",".join(["%s:items=%s,names=%s" % (str(r[0]), int(r[1] or 0), int(r[2] or 0)) for r in people_rows])
            log(
                "[PKM_INDEX] summary_section reason=%s section=%s source=%s items=%s people=%s genres=%s countries=%s ratings=%s country_bucket=%s people_bucket=%s indexed_at=%s" % (
                    reason, sid, source, item_count, people_count, genre_count, country_count, rating_count, country_summary, people_summary, indexed_at
                ),
                xbmc.LOGINFO,
            )
    except Exception:
        log("[PKM_INDEX] summary_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass



def _recommend_index_physical_counts(conn, section_id):
    """Return physical recommendation rows for one library section.

    The state table can say a section is complete even when the actual index
    rows were cleared or never written.  Recommendation widgets depend on the
    physical rows, so state-only validation is not enough.
    """
    sid = str(section_id)
    try:
        row = conn.execute("""
            SELECT
                (SELECT COUNT(*) FROM item_people WHERE section_id=?),
                (SELECT COUNT(*) FROM item_people WHERE section_id=? AND person_type='actor'),
                (SELECT COUNT(*) FROM item_people WHERE section_id=? AND person_type='director'),
                (SELECT COUNT(*) FROM item_genres WHERE section_id=?),
                (SELECT COUNT(*) FROM item_countries WHERE section_id=?),
                (SELECT COUNT(*) FROM item_ratings WHERE section_id=?)
        """, (sid, sid, sid, sid, sid, sid)).fetchone()
        if not row:
            return {"people": 0, "actors": 0, "directors": 0, "genres": 0, "countries": 0, "ratings": 0}
        return {
            "people": int(row[0] or 0),
            "actors": int(row[1] or 0),
            "directors": int(row[2] or 0),
            "genres": int(row[3] or 0),
            "countries": int(row[4] or 0),
            "ratings": int(row[5] or 0),
        }
    except Exception:
        log("[PKM_INDEX] physical_count_failed section=%s\n%s" % (sid, traceback.format_exc()), xbmc.LOGWARNING)
        return {"people": 0, "actors": 0, "directors": 0, "genres": 0, "countries": 0, "ratings": 0}


def _recommend_index_section_is_physically_valid(conn, section_id, expected_items=0, reason=""):
    counts = _recommend_index_physical_counts(conn, section_id)
    expected = int(expected_items or 0)
    # Movie recommendation widgets need at least actors and at least one of
    # genre/country/rating rows.  Keep the threshold intentionally low to avoid
    # false rebuilds for tiny test libraries, but catch the broken state where
    # section 43 has items while people/genres/countries are zero.
    valid = True
    if expected > 0 and counts.get("actors", 0) <= 0:
        valid = False
    if expected > 0 and counts.get("genres", 0) <= 0 and counts.get("countries", 0) <= 0 and counts.get("ratings", 0) <= 0:
        valid = False
    log("[PKM_INDEX] physical_check section=%s expected=%d valid=%s actors=%d directors=%d genres=%d countries=%d ratings=%d trigger=%s" % (
        section_id, expected, "1" if valid else "0", counts.get("actors", 0), counts.get("directors", 0), counts.get("genres", 0), counts.get("countries", 0), counts.get("ratings", 0), reason
    ), xbmc.LOGINFO)
    return valid


def _clear_recommend_index_sections(conn, section_ids, reason=""):
    ids = [str(x) for x in (section_ids or []) if str(x)]
    if not ids:
        return
    q = ",".join(["?"] * len(ids))
    for table in ("item_people", "item_genres", "item_countries", "item_ratings", "item_recommend_index_state"):
        conn.execute("DELETE FROM %s WHERE section_id IN (%s)" % (table, q), ids)
    log("[PKM_INDEX] repair_clear_sections reason=%s sections=%s" % (reason, ",".join(ids)), xbmc.LOGWARNING)

def _fetch_plex_metadata_rows(plex_conn, rating_keys):
    if not rating_keys:
        return {}
    cols = _db_columns(plex_conn, "metadata_items")
    if "metadata_items" and not cols:
        return {}
    select_cols = ["id"]
    for c in ("library_section_id", "metadata_type", "title", "rating", "audience_rating", "user_rating", "tags_genre", "tags_director", "tags_star", "tags_country"):
        if c in cols:
            select_cols.append(c)
    out = {}
    batch_size = 700
    ids = [str(k) for k in rating_keys]
    for i in range(0, len(ids), batch_size):
        batch = ids[i:i + batch_size]
        placeholders = ",".join(["?"] * len(batch))
        try:
            cur = plex_conn.execute("SELECT %s FROM metadata_items WHERE id IN (%s)" % (",".join(select_cols), placeholders), batch)
            for row in cur.fetchall():
                data = dict(zip(select_cols, row))
                out[str(data.get("id"))] = data
        except Exception:
            log("[PKM_INDEX] plex_metadata_rows_failed batch=%d\n%s" % (i, traceback.format_exc()), xbmc.LOGWARNING)
    return out


def _fetch_plex_taggings(plex_conn, rating_keys):
    if not rating_keys or not (_db_has_table(plex_conn, "taggings") and _db_has_table(plex_conn, "tags")):
        return {}, {}
    tag_cols = _db_columns(plex_conn, "tags")
    tagging_cols = _db_columns(plex_conn, "taggings")
    thumb_expr = "''"
    if "user_thumb_url" in tag_cols:
        thumb_expr = "COALESCE(t.user_thumb_url,'')"
    elif "thumb_url" in tag_cols:
        thumb_expr = "COALESCE(t.thumb_url,'')"
    text_expr = "''"
    if "text" in tagging_cols:
        text_expr = "COALESCE(tg.text,'')"
    order_expr = "0"
    for possible in ("index", "tagging_index", "order_index"):
        if possible in tagging_cols:
            # Plex DB may use reserved SQL keywords such as taggings.index.
            # Always quote the column name so the local SQLite parser accepts it.
            safe_col = possible.replace('"', '""')
            order_expr = 'COALESCE(tg."%s",0)' % safe_col
            break
    out = {}
    type_counts = {}
    batch_size = 700
    ids = [str(k) for k in rating_keys]
    for i in range(0, len(ids), batch_size):
        batch = ids[i:i + batch_size]
        placeholders = ",".join(["?"] * len(batch))
        try:
            sql = """
                SELECT CAST(tg.metadata_item_id AS TEXT), COALESCE(t.tag_type,-1), COALESCE(t.tag,''), %s, CAST(t.id AS TEXT), %s, %s
                FROM taggings tg
                JOIN tags t ON t.id = tg.tag_id
                WHERE CAST(tg.metadata_item_id AS TEXT) IN (%s)
            """ % (text_expr, thumb_expr, order_expr, placeholders)
            for mid, tag_type, tag, text, tag_id, thumb, sort_order in plex_conn.execute(sql, batch).fetchall():
                try:
                    tag_type = int(tag_type)
                except Exception:
                    tag_type = -1
                type_counts[tag_type] = type_counts.get(tag_type, 0) + 1
                out.setdefault(str(mid), []).append({
                    "tag_type": tag_type,
                    "tag": _normalize_tag_name(tag),
                    "text": _normalize_tag_name(text),
                    "tag_id": str(tag_id or ""),
                    "thumb": thumb or "",
                    "sort_order": int(sort_order or 0),
                })
        except Exception:
            log("[PKM_INDEX] plex_taggings_failed batch=%d\n%s" % (i, traceback.format_exc()), xbmc.LOGWARNING)
    return out, type_counts


def _classify_plex_tags(meta, tag_rows):
    directors, actors, genres, country_candidates = [], [], [], []
    # Direct columns if present and textual.
    for name in _split_possible_tag_text(meta.get("tags_genre")):
        genres.append({"name": name, "tag_id": "", "role": "", "thumb": "", "sort_order": 0, "source": "metadata_items.tags_genre"})
    for name in _split_possible_tag_text(meta.get("tags_director")):
        directors.append({"name": name, "tag_id": "", "role": "", "thumb": "", "sort_order": 0, "source": "metadata_items.tags_director"})
    for name in _split_possible_tag_text(meta.get("tags_star")):
        actors.append({"name": name, "tag_id": "", "role": "", "thumb": "", "sort_order": 0, "source": "metadata_items.tags_star"})
    for name in _split_possible_tag_text(meta.get("tags_country")):
        country_candidates.append({"name": name, "tag_id": "", "role": "", "thumb": "", "sort_order": 0, "source": "metadata_items.tags_country"})

    for r in tag_rows or []:
        name = r.get("tag") or ""
        if not name:
            continue
        t = r.get("tag_type")
        item = {"name": name, "tag_id": r.get("tag_id", ""), "role": r.get("text", ""), "thumb": r.get("thumb", ""), "sort_order": r.get("sort_order", 0), "source": "taggings:%s" % t}
        if t in _GENRE_TAG_TYPES:
            genres.append(item)
        elif t in _DIRECTOR_TAG_TYPES:
            directors.append(item)
        elif t in _ACTOR_TAG_TYPES:
            actors.append(item)
        elif t in _COUNTRY_TAG_TYPES:
            # Do not save raw country/tag rows. Only use them as evidence for
            # Korean-vs-foreign bucketing below.
            country_candidates.append(item)
    def dedupe(items):
        seen = set(); out = []
        for it in items:
            key = (it.get("name", ""), it.get("sort_order", 0))
            if key in seen:
                continue
            seen.add(key); out.append(it)
        return out
    countries = _country_bucket_from_candidates(country_candidates)
    return dedupe(directors), dedupe(actors), dedupe(genres), countries


def _save_recommend_index_rows(local_conn, rating_key, section_id, meta, directors, actors, genres, countries, source=_RECOMMEND_INDEX_SOURCE_VERSION):
    now = int(time.time())
    local_conn.execute("DELETE FROM item_people WHERE rating_key=?", (str(rating_key),))
    local_conn.execute("DELETE FROM item_genres WHERE rating_key=?", (str(rating_key),))
    local_conn.execute("DELETE FROM item_countries WHERE rating_key=?", (str(rating_key),))
    rating = _float_or_none(meta.get("rating"))
    audience = _float_or_none(meta.get("audience_rating"))
    user = _float_or_none(meta.get("user_rating"))
    score = _score_from_values(rating=rating, audience=audience, user=user)
    local_conn.execute("""
        INSERT INTO item_ratings(rating_key, section_id, rating, audience_rating, user_rating, score, source, indexed_at)
        VALUES(?,?,?,?,?,?,?,?)
        ON CONFLICT(rating_key) DO UPDATE SET
            section_id=excluded.section_id,
            rating=excluded.rating,
            audience_rating=excluded.audience_rating,
            user_rating=excluded.user_rating,
            score=excluded.score,
            source=excluded.source,
            indexed_at=excluded.indexed_at
    """, (str(rating_key), str(section_id), rating, audience, user, score, source, now))
    for idx, it in enumerate(directors):
        local_conn.execute("""
            INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, person_thumb, tag_id, sort_order, source, indexed_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
        """, (str(rating_key), str(section_id), "director", it.get("name"), it.get("role", ""), it.get("thumb", ""), it.get("tag_id", ""), idx, it.get("source", source), now))
    for idx, it in enumerate(actors):
        local_conn.execute("""
            INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, person_thumb, tag_id, sort_order, source, indexed_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
        """, (str(rating_key), str(section_id), "actor", it.get("name"), it.get("role", ""), it.get("thumb", ""), it.get("tag_id", ""), idx, it.get("source", source), now))
    for it in genres:
        local_conn.execute("""
            INSERT OR REPLACE INTO item_genres(rating_key, section_id, genre, tag_id, source, indexed_at)
            VALUES(?,?,?,?,?,?)
        """, (str(rating_key), str(section_id), it.get("name"), it.get("tag_id", ""), it.get("source", source), now))
    for it in countries:
        local_conn.execute("""
            INSERT OR REPLACE INTO item_countries(rating_key, section_id, country, tag_id, source, indexed_at)
            VALUES(?,?,?,?,?,?)
        """, (str(rating_key), str(section_id), it.get("name"), it.get("tag_id", ""), it.get("source", source), now))
    return {
        "directors": len(directors), "actors": len(actors), "genres": len(genres), "countries": len(countries),
        "rating": rating, "audience": audience, "user": user, "score": score,
    }



def _recommend_row_columns_sql(prefix="i"):
    if pkm_movie_recommend:
        return pkm_movie_recommend.recommend_row_columns_sql(prefix)
    p = (str(prefix or "").strip() + ".") if str(prefix or "").strip() else ""
    return ", ".join([
        p + "rating_key",
        p + "section_id",
        p + "plex_type",
        "'' AS kodi_type",
        p + "title",
        "'' AS original_title",
        "COALESCE(" + p + "sort_title," + p + "title) AS sort_title",
        p + "year",
        p + "summary",
        p + "duration",
        p + "added_at",
        p + "updated_at",
        p + "thumb",
        p + "art",
        p + "media_file",
        p + "part_key",
        p + "view_count",
        p + "last_viewed_at",
        p + "show_title",
        p + "season",
        p + "episode",
        p + "parent_rating_key",
        p + "grandparent_rating_key",
    ])


def _recommend_exclude_clause(alias, exclude_keys, args):
    if pkm_movie_recommend:
        return pkm_movie_recommend.recommend_exclude_clause(alias, exclude_keys, args)
    keys = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    if not keys:
        return ""
    ph = ",".join(["?"] * len(keys))
    args.extend(keys)
    return " AND %s.rating_key NOT IN (%s)" % ((alias or "i"), ph)


def _movie_section_ids_from_db(conn):
    if pkm_movie_recommend:
        return pkm_movie_recommend.movie_section_ids_from_db(conn)
    try:
        rows = conn.execute("SELECT DISTINCT section_id FROM items WHERE plex_type='movie' ORDER BY CAST(section_id AS INTEGER), section_id").fetchall()
        return [str(r[0]) for r in rows if str(r[0] or "").strip()]
    except Exception:
        return []


def _selected_movie_section_ids_from_db_v1613(conn, preferred_sid=""):
    """Return only PKM-selected movie section ids for cross-library widgets.

    v1613: recommendation rows may use a movie-wide pool, but "movie-wide" must
    mean the libraries selected in PKM settings, not every movie section still
    present in the local cache/index DB. Cached data for unchecked libraries is
    intentionally retained for fast re-enable; it is never a visible source.
    """
    all_ids = [str(x) for x in (_movie_section_ids_from_db(conn) or []) if str(x or "").strip()]
    preferred = str(preferred_sid or "").strip()
    try:
        selected, configured = selected_sections_state()
        selected_set = set(str(x) for x in (selected or []) if str(x or "").strip())
        if not configured or not selected_set:
            log("[PKM_INDEX] recommend_selected_library_pool_v1979 configured=%d preferred=%s all=%s selected= filtered=" % (
                1 if configured else 0, preferred, ",".join(all_ids)
            ), xbmc.LOGINFO)
            return []
        if configured:
            filtered = [sid for sid in all_ids if sid in selected_set]
            if preferred and preferred in selected_set and preferred in filtered:
                filtered = [preferred] + [sid for sid in filtered if sid != preferred]
            log("[PKM_INDEX] recommend_selected_library_pool_v1613 configured=1 preferred=%s all=%s selected=%s filtered=%s" % (
                preferred, ",".join(all_ids), ",".join(str(x) for x in (selected or [])), ",".join(filtered)
            ), xbmc.LOGINFO)
            return filtered
    except Exception:
        log("[PKM_INDEX] recommend_selected_library_pool_v1613_failed preferred=%s\n%s" % (preferred, traceback.format_exc()), xbmc.LOGWARNING)
    if preferred and preferred in all_ids:
        all_ids = [preferred] + [sid for sid in all_ids if sid != preferred]
    return all_ids



def _recommend_rows_thumb_stats(rows):
    if pkm_movie_recommend:
        return pkm_movie_recommend.recommend_rows_thumb_stats(rows)
    total = len(rows or [])
    thumb_ready = 0
    art_ready = 0
    try:
        for r in rows or []:
            t = tuple(r)
            # stable wall-light row tuple: index 12=thumb, 13=art
            if len(t) > 12 and str(t[12] or "").strip():
                thumb_ready += 1
            if len(t) > 13 and str(t[13] or "").strip():
                art_ready += 1
    except Exception:
        pass
    return total, thumb_ready, art_ready

def _log_recommend_widget_result(kind, section_id, rows, want, elapsed, source="db_local", result="ok", extra=""):
    try:
        if pkm_movie_recommend:
            log(pkm_movie_recommend.recommend_widget_result_log_message(kind, section_id, rows, want, elapsed, source=source, result=result, extra=extra), xbmc.LOGINFO)
            return
    except Exception:
        pass
    total, thumb_ready, art_ready = _recommend_rows_thumb_stats(rows)
    try:
        log("[PKM_INDEX] recommend_widget_result kind=%s section=%s rows=%d want=%d thumb_ready=%d art_ready=%d metadata_fetch=0 source=%s ms=%d result=%s%s" % (kind, section_id, total, want, thumb_ready, art_ready, source, elapsed, result, (" " + extra) if extra else ""), xbmc.LOGINFO)
    except Exception:
        pass



def _section_country_bucket_from_db(conn, section_id, plex_type, min_ratio=0.60):
    if pkm_movie_recommend:
        return pkm_movie_recommend.section_country_bucket_from_db(conn, section_id, plex_type, min_ratio=min_ratio)
    sid = str(section_id or "").strip()
    ptype = str(plex_type or "").strip()
    if not sid or not ptype:
        return ""
    try:
        rows = conn.execute("""
            SELECT c.country, COUNT(DISTINCT c.rating_key) AS cnt
            FROM item_countries c
            JOIN items i ON i.rating_key=c.rating_key
            WHERE c.section_id=?
              AND i.section_id=?
              AND i.plex_type=?
              AND c.country IN ('한국','외국')
            GROUP BY c.country
        """, (sid, sid, ptype)).fetchall()
    except Exception:
        rows = []
    counts, total = {}, 0
    for row in rows or []:
        try:
            country = str(row[0] or "").strip()
            cnt = int(row[1] or 0)
            if country in ("한국", "외국") and cnt > 0:
                counts[country] = counts.get(country, 0) + cnt
                total += cnt
        except Exception:
            continue
    if total <= 0:
        return ""
    bucket, cnt = max(counts.items(), key=lambda kv: kv[1])
    try:
        if float(cnt) / float(total) >= float(min_ratio or 0.60):
            return bucket
    except Exception:
        pass
    return ""

def query_recommend_index_rows(section_id, kind="korean", limit=10, exclude_keys=None, min_score=6.5, min_person_items=10):
    """Fast DB-backed rows for movie recommendation widgets.

    kind:
      - korean / foreign: current section only, rating + random.
      - director / actor: all movie sections, random person with >=10 works.
    Returns the same tuple shape as query_items_wall_light(), with an extra
    trailing display_name for director/actor widgets.
    """
    start_ms = int(time.time() * 1000)
    sid = str(section_id or "").strip()
    kind = str(kind or "").strip().lower()
    want = max(10, int(limit or 10))
    score_min = _float_or_none(min_score)
    excluded = [str(x) for x in (exclude_keys or []) if str(x or "").strip()]
    conn = init_db()
    try:
        init_recommend_index_schema(conn)
        section_bucket = _section_country_bucket_from_db(conn, sid, PLEX_TYPE_MOVIE)
        cols = _recommend_row_columns_sql("i")
        if kind in ("korean", "foreign"):
            bucket = "한국" if kind == "korean" else "외국"
            args = [sid, bucket]
            score_clause = ""
            if score_min is not None:
                score_clause = " AND COALESCE(r.score, -1) >= ?"
                args.append(float(score_min))
            excl = _recommend_exclude_clause("i", excluded, args)
            sql = """
                SELECT %s
                FROM items i
                JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=?
                LEFT JOIN item_ratings r ON r.rating_key=i.rating_key
                WHERE i.section_id=? AND i.plex_type=? %s %s
                GROUP BY i.rating_key
                ORDER BY RANDOM()
                LIMIT ?
            """ % (cols, score_clause, excl)
            # SQL order is section_id? no: c.country then section_id. Rebuild args safely.
            args = [bucket, sid, PLEX_TYPE_MOVIE]
            if score_min is not None:
                args.append(float(score_min))
            for x in excluded:
                args.append(x)
            args.append(want)
            rows = conn.execute(sql, args).fetchall()
            strict_rows = len(rows)
            relaxed_used = 0
            # If rating data is sparse, keep country rule and relax score to fill 10.
            if len(rows) < want and score_min is not None:
                relaxed_used = 1
                args2 = [bucket, sid, PLEX_TYPE_MOVIE]
                excl2 = _recommend_exclude_clause("i", excluded, args2)
                sql2 = """
                    SELECT %s
                    FROM items i
                    JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=?
                    WHERE i.section_id=? AND i.plex_type=? %s
                    GROUP BY i.rating_key
                    ORDER BY RANDOM()
                    LIMIT ?
                """ % (cols, excl2)
                args2.append(want)
                rows = conn.execute(sql2, args2).fetchall()
            elapsed = int(time.time() * 1000) - start_ms
            try:
                pool_total = conn.execute("""
                    SELECT COUNT(DISTINCT i.rating_key)
                    FROM items i
                    JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=?
                    WHERE i.section_id=? AND i.plex_type=?
                """, (bucket, sid, PLEX_TYPE_MOVIE)).fetchone()[0]
            except Exception:
                pool_total = -1
            result = "ok" if len(rows) >= min(10, want) else "short"
            log("[PKM_INDEX] recommend_query kind=%s section=%s country=%s rows=%d want=%d min_score=%s strict_rows=%d relaxed=%d pool=%s ms=%d source=db_local result=%s metadata_fetch=0" % (kind, sid, bucket, len(rows), want, score_min, strict_rows, relaxed_used, pool_total, elapsed, result), xbmc.LOGINFO)
            _log_recommend_widget_result(kind, sid, rows, want, elapsed, source="db_local", result=result, extra="country=%s pool=%s" % (bucket, pool_total))
            return rows[:want]

        if kind in ("director", "actor"):
            ptype = "director" if kind == "director" else "actor"
            # v1613: use only PKM-selected libraries for cross-library person
            # recommendation pools. Do not fall back to an unchecked section
            # merely because its cached rows still exist in plex_km.db.
            section_ids = _selected_movie_section_ids_from_db_v1613(conn, preferred_sid=sid)
            if not section_ids:
                log("[PKM_INDEX] recommend_query_skip_v1613 kind=%s section=%s reason=no_selected_movie_sections" % (kind, sid), xbmc.LOGINFO)
                return []
            ph = ",".join(["?"] * len(section_ids))
            # Pick a random person that can actually fill a 10-item row.
            country_join = ""
            country_params = []
            if section_bucket in ("한국", "외국"):
                country_join = " JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=? "
                country_params = [section_bucket]
            candidates = conn.execute("""
                SELECT p.person_name, COUNT(DISTINCT p.rating_key) AS cnt
                FROM item_people p
                JOIN items i ON i.rating_key=p.rating_key
                %s
                WHERE p.person_type=? AND i.plex_type=? AND i.section_id IN (%s)
                  AND (? != 'actor' OR COALESCE(p.sort_order,999) BETWEEN 0 AND 2)
                GROUP BY p.person_name
                HAVING cnt >= ?
                ORDER BY RANDOM()
                LIMIT 12
            """ % (country_join, ph), country_params + [ptype, PLEX_TYPE_MOVIE] + section_ids + [ptype, max(1, int(min_person_items or 10))]).fetchall()
            if not candidates:
                candidates = conn.execute("""
                    SELECT p.person_name, COUNT(DISTINCT p.rating_key) AS cnt
                    FROM item_people p
                    JOIN items i ON i.rating_key=p.rating_key
                    %s
                    WHERE p.person_type=? AND i.plex_type=? AND i.section_id IN (%s)
                      AND (? != 'actor' OR COALESCE(p.sort_order,999) BETWEEN 0 AND 2)
                    GROUP BY p.person_name
                    HAVING cnt >= 2
                    ORDER BY cnt DESC, RANDOM()
                    LIMIT 12
                """ % (country_join, ph), country_params + [ptype, PLEX_TYPE_MOVIE] + section_ids + [ptype]).fetchall()
            best_rows = []
            best_name = ""
            candidate_sample = []
            for cand in candidates or []:
                try:
                    candidate_sample.append("%s:%s" % (str(cand[0] or ""), int(cand[1] or 0)))
                except Exception:
                    pass
                name = str(cand[0] or "").strip()
                if not name:
                    continue
                args = []
                row_country_join = ""
                if section_bucket in ("한국", "외국"):
                    row_country_join = " JOIN item_countries c ON c.rating_key=i.rating_key AND c.country=? "
                    args.append(section_bucket)
                args.extend([ptype, name, PLEX_TYPE_MOVIE] + section_ids)
                excl = _recommend_exclude_clause("i", excluded, args)
                sql = """
                    SELECT %s, ? AS recommend_person_name
                    FROM items i
                    JOIN item_people p ON p.rating_key=i.rating_key
                    %s
                    WHERE p.person_type=? AND p.person_name=? AND i.plex_type=? AND i.section_id IN (%s) %s
                      AND (? != 'actor' OR COALESCE(p.sort_order,999) BETWEEN 0 AND 2)
                    GROUP BY i.rating_key
                    ORDER BY RANDOM()
                    LIMIT ?
                """ % (cols, row_country_join, ph, excl)
                # First selected column after item cols is display name.
                args = [name]
                if section_bucket in ("한국", "외국"):
                    args.append(section_bucket)
                args.extend([ptype, name, PLEX_TYPE_MOVIE] + section_ids)
                for x in excluded:
                    args.append(x)
                args.append(ptype)
                args.append(want)
                rows = conn.execute(sql, args).fetchall()
                if len(rows) > len(best_rows):
                    best_rows = rows
                    best_name = name
                if len(rows) >= want:
                    break
            elapsed = int(time.time() * 1000) - start_ms
            result = "ok" if len(best_rows) >= min(10, want) else "short"
            log("[PKM_INDEX] recommend_query kind=%s section=%s country_bucket=%s person=%s rows=%d want=%d candidates=%d min_person_items=%s sections=%d ms=%d source=db_local result=%s candidate_sample=%s actor_main_only=%d actor_order_range=1-3 metadata_fetch=0" % (kind, sid, section_bucket or "mixed", best_name, len(best_rows), want, len(candidates or []), int(min_person_items or 10), len(section_ids), elapsed, result, "|".join(candidate_sample[:6]), 1 if kind == "actor" else 0), xbmc.LOGINFO)
            _log_recommend_widget_result(kind, sid, best_rows, want, elapsed, source="db_local", result=result, extra="country_bucket=%s person=%s candidates=%d sections=%d actor_main_only=%d actor_order_range=1-3" % (section_bucket or "mixed", best_name, len(candidates or []), len(section_ids), 1 if kind == "actor" else 0))
            return best_rows[:want]
        return []
    except Exception:
        log("[PKM_INDEX] recommend_query_failed kind=%s section=%s\n%s" % (kind, sid, traceback.format_exc()), xbmc.LOGWARNING)
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _live_recommend_items_from_xml(xml, item):
    directors, actors, genres, country_candidates = [], [], [], []
    try:
        for d in xml.findall("Director"):
            name = _normalize_tag_name(d.get("tag") or d.get("title") or d.get("name") or "")
            if name:
                directors.append({"name": name, "tag_id": d.get("id", "") or "", "role": "", "thumb": d.get("thumb", "") or "", "sort_order": 0, "source": "plex_api:Director"})
        for r in xml.findall("Role"):
            name = _normalize_tag_name(r.get("tag") or r.get("title") or r.get("name") or "")
            if name:
                actors.append({"name": name, "tag_id": r.get("id", "") or "", "role": r.get("role", "") or "", "thumb": r.get("thumb", "") or "", "sort_order": 0, "source": "plex_api:Role"})
        for g in xml.findall("Genre"):
            name = _normalize_tag_name(g.get("tag") or g.get("title") or g.get("name") or "")
            if name:
                genres.append({"name": name, "tag_id": g.get("id", "") or "", "role": "", "thumb": "", "sort_order": 0, "source": "plex_api:Genre"})
        for c in xml.findall("Country"):
            name = _normalize_tag_name(c.get("tag") or c.get("title") or c.get("name") or "")
            if name:
                country_candidates.append({"name": name, "tag_id": c.get("id", "") or "", "role": "", "thumb": "", "sort_order": 0, "source": "plex_api:Country"})
        meta = {
            "rating": xml.get("rating"),
            "audience_rating": xml.get("audienceRating"),
            "user_rating": xml.get("userRating"),
        }
        return directors, actors, genres, _country_bucket_from_candidates(country_candidates), meta
    except Exception:
        return [], [], [], _country_bucket_from_candidates([]), {}


def recommend_index_has_bootstrap_state(conn=None):
    own = conn is None
    if own:
        conn = init_db()
    try:
        init_recommend_index_schema(conn)
        row = conn.execute(
            "SELECT COUNT(*) FROM item_recommend_index_state "
            "WHERE item_count > 0 AND (source LIKE 'plex_db_%' OR source LIKE 'plex_api_sync_%')"
        ).fetchone()
        return bool(row and int(row[0] or 0) > 0)
    except Exception:
        return False
    finally:
        if own:
            try:
                conn.close()
            except Exception:
                pass


def finalize_recommend_index_from_api_sync(section_ids=None, progress=None):
    """Commit the recommendation-widget DB state built during Plex API sync.

    Movie detail side tables are populated inside ``fetch_section_items`` while
    the normal library progress bar is advancing.  When no Plex server SQLite
    path is configured, this final pass validates/counts those local rows and
    records a real bootstrap state.  Home is not released until this function
    has committed successfully.
    """
    bench_t0_v1738 = time.perf_counter()
    movie_items = _local_movie_items_for_sections(section_ids=section_ids)
    log("[PKM_BENCH] RECOMMEND_API_FINALIZE_BEGIN mode=plex_api sections=%s items=%d" % (
        ",".join([str(x) for x in (section_ids or []) if str(x)]) or "all", len(movie_items)
    ), xbmc.LOGINFO)
    if not movie_items:
        log("[PKM_INDEX] api_sync_finalize_skip reason=no_movie_items sections=%s" % ",".join([str(x) for x in (section_ids or []) if str(x)]), xbmc.LOGINFO)
        elapsed_ms_v1738 = (time.perf_counter() - bench_t0_v1738) * 1000.0
        log("[PKM_BENCH] RECOMMEND_API_FINALIZE_DONE mode=plex_api result=skip sections=0 items=0 elapsed_ms=%.1f" % elapsed_ms_v1738, xbmc.LOGINFO)
        return {"sections": 0, "items": 0, "elapsed_ms": elapsed_ms_v1738}

    expected = {}
    for _rk, sid, _updated, _title in movie_items:
        sid = str(sid or "")
        if sid:
            expected[sid] = expected.get(sid, 0) + 1

    conn = init_db()
    try:
        init_recommend_index_schema(conn)
        total_sections = max(1, len(expected))
        now = int(time.time())
        total_items = 0
        for index, sid in enumerate(sorted(expected.keys(), key=lambda x: (int(x) if str(x).isdigit() else 999999999, str(x))), start=1):
            if progress:
                progress_update(
                    progress,
                    min(99, 88 + int((float(index - 1) / float(total_sections)) * 10.0)),
                    "추천 위젯 DB 생성 중\n영화 라이브러리 %d / %d" % (index, total_sections),
                )
            item_count = int(expected.get(sid, 0) or 0)
            people_count = int(conn.execute("SELECT COUNT(*) FROM item_people WHERE section_id=?", (sid,)).fetchone()[0] or 0)
            genre_count = int(conn.execute("SELECT COUNT(*) FROM item_genres WHERE section_id=?", (sid,)).fetchone()[0] or 0)
            country_count = int(conn.execute("SELECT COUNT(*) FROM item_countries WHERE section_id=?", (sid,)).fetchone()[0] or 0)
            rating_count = int(conn.execute("SELECT COUNT(*) FROM item_ratings WHERE section_id=?", (sid,)).fetchone()[0] or 0)
            if not _recommend_index_section_is_physically_valid(
                conn, sid, expected_items=item_count, reason="api_sync_finalize_v1736"
            ):
                raise RuntimeError("recommendation index validation failed for section %s" % sid)
            conn.execute("""
                INSERT INTO item_recommend_index_state(section_id, source, indexed_at, item_count, people_count, genre_count, country_count, rating_count, last_error)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(section_id) DO UPDATE SET
                    source=excluded.source,
                    indexed_at=excluded.indexed_at,
                    item_count=excluded.item_count,
                    people_count=excluded.people_count,
                    genre_count=excluded.genre_count,
                    country_count=excluded.country_count,
                    rating_count=excluded.rating_count,
                    last_error=''
            """, (sid, _RECOMMEND_INDEX_API_SOURCE_VERSION, now, item_count, people_count, genre_count, country_count, rating_count, ""))
            total_items += item_count
            log("[PKM_INDEX] api_sync_section_done section=%s items=%d people=%d genres=%d countries=%d ratings=%d source=%s" % (
                sid, item_count, people_count, genre_count, country_count, rating_count, _RECOMMEND_INDEX_API_SOURCE_VERSION
            ), xbmc.LOGINFO)
        conn.commit()
        if progress:
            progress_update(progress, 99, "추천 위젯 DB 생성 완료\n%d개 영화 항목" % total_items)
        elapsed_ms_v1738 = (time.perf_counter() - bench_t0_v1738) * 1000.0
        log("[PKM_INDEX] api_sync_finalize_done sections=%d items=%d source=%s" % (
            len(expected), total_items, _RECOMMEND_INDEX_API_SOURCE_VERSION
        ), xbmc.LOGINFO)
        log("[PKM_BENCH] RECOMMEND_API_FINALIZE_DONE mode=plex_api result=success sections=%d items=%d elapsed_ms=%.1f items_per_sec=%.2f" % (
            len(expected), total_items, elapsed_ms_v1738, (float(total_items) * 1000.0 / elapsed_ms_v1738) if elapsed_ms_v1738 > 0 else 0.0
        ), xbmc.LOGINFO)
        try:
            log_recommend_index_summary(reason="api_sync_finalize_v1736")
        except Exception:
            pass
        return {"sections": len(expected), "items": total_items, "elapsed_ms": elapsed_ms_v1738}
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        elapsed_ms_v1738 = (time.perf_counter() - bench_t0_v1738) * 1000.0
        log("[PKM_INDEX] api_sync_finalize_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        log("[PKM_BENCH] RECOMMEND_API_FINALIZE_DONE mode=plex_api result=failed elapsed_ms=%.1f" % elapsed_ms_v1738, xbmc.LOGINFO)
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass


# -----------------------------------------------------------------------------
# TV show actor / studio cache index (v471)
# -----------------------------------------------------------------------------
_TV_TAG_INDEX_SOURCE_VERSION = "plex_api_tv_tags_v471"
_TV_CREW_ROLE_MAP = {
    "연출": "director", "감독": "director", "director": "director",
    "극본": "writer", "각본": "writer", "작가": "writer", "writer": "writer",
    "기획": "producer", "제작": "producer", "producer": "producer", "creator": "producer",
}


def _tv_normalize_tag(value):
    return " ".join(str(value or "").strip().split())


def _tv_people_type_from_role(role):
    text = _tv_normalize_tag(role).lower()
    if not text:
        return "actor"
    compact = text.replace(" ", "")
    if compact in _TV_CREW_ROLE_MAP:
        return _TV_CREW_ROLE_MAP[compact]
    return "actor"


def _tv_detail_xml_for_item(rating_key, fallback_xml=None, timeout=6):
    rk = str(rating_key or "").strip()
    if not rk:
        return fallback_xml
    try:
        root = plex_request_xml("/library/metadata/%s" % rk, timeout=timeout)
        for child in list(root or []):
            if getattr(child, "tag", "") in ("Directory", "Video"):
                return child
    except Exception:
        log("[PKM_TV_TAGS] metadata_detail_failed rating_key=%s\n%s" % (rk, traceback.format_exc()), xbmc.LOGWARNING)
    return fallback_xml


def _extract_tv_show_tags_from_xml(xml):
    people = []
    studios = []
    if xml is None:
        return people, studios

    def _append_studio(studio_type, name, tag_id="", source=""):
        label = _tv_normalize_tag(name)
        if not label:
            return
        key = (str(studio_type or "studio"), label.lower())
        for row in studios:
            if row.get("_key") == key:
                return
        studios.append({
            "studio_type": str(studio_type or "studio"),
            "studio_name": label,
            "tag_id": str(tag_id or ""),
            "source": source or _TV_TAG_INDEX_SOURCE_VERSION,
            "_key": key,
        })

    try:
        for idx, role_node in enumerate(list(xml.findall("Role") or [])):
            name = _tv_normalize_tag(role_node.get("tag") or role_node.get("title") or role_node.get("name"))
            if not name:
                continue
            role = _tv_normalize_tag(role_node.get("role") or "")
            people.append({
                "person_type": _tv_people_type_from_role(role),
                "person_name": name,
                "role": role,
                "person_thumb": role_node.get("thumb", "") or "",
                "tag_id": str(role_node.get("id") or ""),
                "sort_order": idx,
                "source": _TV_TAG_INDEX_SOURCE_VERSION,
            })
    except Exception:
        pass

    try:
        _append_studio("studio", xml.get("studio"), source="studio_attribute")
        _append_studio("network", xml.get("network"), source="network_attribute")
    except Exception:
        pass
    try:
        for node in list(xml.findall("Studio") or []):
            _append_studio("studio", node.get("tag") or node.get("title"), tag_id=node.get("id") or "", source="studio_child")
    except Exception:
        pass
    try:
        for node in list(xml.findall("Network") or []):
            _append_studio("network", node.get("tag") or node.get("title"), tag_id=node.get("id") or "", source="network_child")
    except Exception:
        pass
    for row in studios:
        row.pop("_key", None)
    return people, studios


def _tv_tag_index_missing(conn, rating_key):
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    try:
        people_count = conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=?", (rk,)).fetchone()[0]
    except Exception:
        people_count = 0
    try:
        studio_count = conn.execute("SELECT COUNT(*) FROM item_studios WHERE rating_key=?", (rk,)).fetchone()[0]
    except Exception:
        studio_count = 0
    return int(people_count or 0) <= 0 and int(studio_count or 0) <= 0


def _save_tv_show_tag_index(conn, item, xml, reason="sync"):
    if not item or str(item.get("plex_type") or "") != PLEX_TYPE_SHOW:
        return False
    rk = str(item.get("rating_key") or "").strip()
    sid = str(item.get("section_id") or "").strip()
    if not rk or not sid:
        return False
    detail_xml = _tv_detail_xml_for_item(rk, fallback_xml=xml)
    people, studios = _extract_tv_show_tags_from_xml(detail_xml)
    now = int(time.time())
    conn.execute("DELETE FROM item_people WHERE rating_key=?", (rk,))
    conn.execute("DELETE FROM item_studios WHERE rating_key=?", (rk,))
    for idx, row in enumerate(people or []):
        conn.execute("""
            INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, person_thumb, tag_id, sort_order, source, indexed_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
        """, (
            rk, sid, row.get("person_type") or "actor", row.get("person_name") or "", row.get("role") or "",
            row.get("person_thumb") or "", row.get("tag_id") or "", int(row.get("sort_order") if row.get("sort_order") is not None else idx),
            row.get("source") or _TV_TAG_INDEX_SOURCE_VERSION, now,
        ))
    for row in studios or []:
        conn.execute("""
            INSERT OR REPLACE INTO item_studios(rating_key, section_id, studio_type, studio_name, tag_id, source, indexed_at)
            VALUES(?,?,?,?,?,?,?)
        """, (
            rk, sid, row.get("studio_type") or "studio", row.get("studio_name") or "", row.get("tag_id") or "",
            row.get("source") or _TV_TAG_INDEX_SOURCE_VERSION, now,
        ))
    actor_count = len([x for x in people or [] if x.get("person_type") == "actor"])
    crew_count = max(0, len(people or []) - actor_count)
    log("[PKM_TV_TAGS] indexed reason=%s rating_key=%s section=%s title=%s actors=%d crew=%d studios=%d source=%s" % (
        reason, rk, sid, item.get("title", ""), actor_count, crew_count, len(studios or []), _TV_TAG_INDEX_SOURCE_VERSION
    ), xbmc.LOGINFO)
    return True

def _movie_detail_index_missing(conn, rating_key):
    """Return True only when the movie detail side tables were never built.

    The items row alone is not enough for PKM Info.  Movie Info reads actor/
    director/genre/rating from item_people, item_genres and item_ratings.
    v1325/v1329 startup partial sync could upsert items but skip these side
    tables, which made newly-added movies open with no cast/genre/director even
    though Plex had them.  item_ratings is counted as a completion marker so
    movies that genuinely have no people/genres do not get repaired forever.
    """
    rk = str(rating_key or "").strip()
    if not rk or conn is None:
        return False
    try:
        people_count = int((conn.execute("SELECT COUNT(*) FROM item_people WHERE rating_key=?", (rk,)).fetchone() or [0])[0] or 0)
    except Exception:
        people_count = 0
    try:
        genre_count = int((conn.execute("SELECT COUNT(*) FROM item_genres WHERE rating_key=?", (rk,)).fetchone() or [0])[0] or 0)
    except Exception:
        genre_count = 0
    try:
        rating_count = int((conn.execute("SELECT COUNT(*) FROM item_ratings WHERE rating_key=?", (rk,)).fetchone() or [0])[0] or 0)
    except Exception:
        rating_count = 0
    return (people_count + genre_count + rating_count) <= 0


def update_recommend_index_from_live_xml(xml, item, reason="sync", conn=None, bootstrap_ready=None, log_skips=False):
    """After the Plex-DB bootstrap, keep new/changed movie items current from live Plex API XML.

    v228: this function must never spam per-item skip logs during the first library sync.
    The caller should pre-check bootstrap state once per section and pass bootstrap_ready.
    """
    try:
        if not item or str(item.get("plex_type") or "") != PLEX_TYPE_MOVIE:
            if log_skips:
                try:
                    log("[PKM_INDEX] live_item_skip reason=%s cause=not_movie plex_type=%s" % (reason, str((item or {}).get("plex_type") if item else "")), xbmc.LOGDEBUG)
                except Exception:
                    pass
            return False
        rk = str(item.get("rating_key") or "").strip()
        sid = str(item.get("section_id") or "").strip()
        if not rk or not sid:
            if log_skips:
                log("[PKM_INDEX] live_item_skip reason=%s cause=missing_key section=%s rating_key=%s" % (reason, sid, rk), xbmc.LOGDEBUG)
            return False
        own_conn = conn is None
        if own_conn:
            conn = init_db()
        try:
            if bootstrap_ready is None:
                bootstrap_ready = recommend_index_has_bootstrap_state(conn)
            if not bootstrap_ready:
                if log_skips:
                    log("[PKM_INDEX] live_item_skip reason=%s cause=no_bootstrap_state section=%s rating_key=%s" % (reason, sid, rk), xbmc.LOGDEBUG)
                return False
            directors, actors, genres, countries, meta = _live_recommend_items_from_xml(xml, item)
            saved = _save_recommend_index_rows(conn, rk, sid, meta, directors, actors, genres, countries, source="plex_api_live_v228")
            if own_conn:
                conn.commit()
            log("[PKM_INDEX] live_item_indexed reason=%s rating_key=%s section=%s directors=%d actors=%d genres=%d countries=%d score=%s source=plex_api_live_v228" % (
                reason, rk, sid, saved.get("directors", 0), saved.get("actors", 0), saved.get("genres", 0), saved.get("countries", 0), saved.get("score", "")
            ), xbmc.LOGINFO)
            return True
        finally:
            if own_conn:
                try:
                    conn.close()
                except Exception:
                    pass
    except Exception:
        log("[PKM_INDEX] live_item_update_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return False


def import_recommend_index_from_plex_db(section_ids=None, show_progress=True, limit=0, reason="manual", progress=None):
    """Import recommendation index data from a user supplied Plex library DB copy.

    Initial bulk import only. Subsequent incremental update can continue using PMS API.
    """
    global LAST_RECOMMEND_DB_IMPORT_BENCH
    bench_total_t0_v1738 = time.perf_counter()
    LAST_RECOMMEND_DB_IMPORT_BENCH = {"result": "not_started", "copy_ms": 0.0, "import_ms": 0.0, "total_ms": 0.0, "items": 0, "errors": 0, "sections": 0}
    src = plex_db_copy_setting()
    if not src:
        log("[PKM_INDEX] import_skip reason=no_plex_db_path", xbmc.LOGINFO)
        return False
    if not recommend_index_source_enabled():
        log("[PKM_INDEX] import_skip reason=setting_disabled", xbmc.LOGINFO)
        return False
    local_items = _local_movie_items_for_sections(section_ids=section_ids)
    log("[PKM_BENCH] RECOMMEND_BEGIN mode=plex_db reason=%s items=%d sections=%s" % (
        reason, len(local_items), ",".join([str(x) for x in (section_ids or []) if str(x)]) or "all"
    ), xbmc.LOGINFO)
    if limit:
        local_items = local_items[:int(limit)]
    force_import = str(reason or "").lower() in ("manual", "force", "rebuild")
    if not force_import and _recommend_index_current_for_items(local_items, reason=reason):
        total_ms_v1738 = (time.perf_counter() - bench_total_t0_v1738) * 1000.0
        LAST_RECOMMEND_DB_IMPORT_BENCH = {"result": "skip_current", "copy_ms": 0.0, "import_ms": 0.0, "total_ms": total_ms_v1738, "items": len(local_items), "errors": 0, "sections": 0}
        log("[PKM_BENCH] RECOMMEND_DONE mode=plex_db result=skip_current copy_ms=0.0 import_ms=0.0 post_library_ms=%.1f items=%d items_per_sec=0.00" % (total_ms_v1738, len(local_items)), xbmc.LOGINFO)
        return True
    tmp = _copy_plex_db_to_temp(src)
    copy_bench_v1738 = dict(LAST_PLEX_DB_COPY_BENCH or {})
    copy_ms_v1738 = float(copy_bench_v1738.get("elapsed_ms", 0.0) or 0.0)
    if not tmp:
        notify("Plex DB copy failed. Check path.", icon=xbmcgui.NOTIFICATION_WARNING, ms=5000)
        return False
    external_progress = progress is not None
    progress = progress if progress is not None else (_create_pkm_sync_progress() if show_progress else None)
    try:
        if progress:
            if external_progress:
                progress_update(progress, 0, "추천 DB 업데이트 중")
            else:
                progress_create(progress, ADDON_NAME, "추천 DB 업데이트 중")
        t_all = time.perf_counter()
        plex_conn = sqlite3.connect(tmp)
        plex_conn.execute("PRAGMA query_only=ON")
        local_conn = init_db()
        try:
            local_conn.execute("PRAGMA journal_mode=WAL")
            local_conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        init_recommend_index_schema(local_conn)
        try:
            if not (_db_has_table(plex_conn, "metadata_items") and _db_has_table(plex_conn, "taggings") and _db_has_table(plex_conn, "tags")):
                log("[PKM_INDEX] import_schema_missing metadata_items=%s taggings=%s tags=%s" % (
                    _db_has_table(plex_conn, "metadata_items"), _db_has_table(plex_conn, "taggings"), _db_has_table(plex_conn, "tags")
                ), xbmc.LOGWARNING)
                return False
            try:
                log("[PKM_INDEX] import_schema_ok metadata_items_cols=%s taggings_cols=%s tags_cols=%s" % (
                    json.dumps(_db_columns(plex_conn, "metadata_items"), ensure_ascii=False),
                    json.dumps(_db_columns(plex_conn, "taggings"), ensure_ascii=False),
                    json.dumps(_db_columns(plex_conn, "tags"), ensure_ascii=False),
                ), xbmc.LOGINFO)
            except Exception:
                pass
            total = len(local_items)
            section_ids_seen = sorted(set([str(x[1]) for x in local_items if x and str(x[1])]))
            try:
                complete_rows = local_conn.execute(
                    "SELECT section_id, item_count, source FROM item_recommend_index_state WHERE source=?",
                    (_RECOMMEND_INDEX_SOURCE_VERSION,)
                ).fetchall()
                complete = {str(r[0]): int(r[1] or 0) for r in complete_rows}
                expected = {}
                for _rk, _sid, _upd, _title in local_items:
                    expected[str(_sid)] = expected.get(str(_sid), 0) + 1
                stale_sections = []
                for sid, cnt in expected.items():
                    if complete.get(sid, -1) >= cnt and not _recommend_index_section_is_physically_valid(local_conn, sid, expected_items=cnt, reason=reason):
                        stale_sections.append(str(sid))
                if force_import:
                    _clear_recommend_index_sections(local_conn, expected.keys(), reason="force_%s" % reason)
                    local_conn.commit()
                elif stale_sections:
                    _clear_recommend_index_sections(local_conn, stale_sections, reason="stale_physical_rows_%s" % reason)
                    local_conn.commit()
                elif expected and all(complete.get(sid, -1) >= cnt for sid, cnt in expected.items()):
                    log("[PKM_INDEX] import_skip reason=already_complete_verified source=%s items=%d sections=%d" % (_RECOMMEND_INDEX_SOURCE_VERSION, total, len(expected)), xbmc.LOGINFO)
                    return True
            except Exception:
                log("[PKM_INDEX] already_complete_check_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            log("[PKM_INDEX] import_from_plex_db_start reason=%s items=%d path=%s source=%s country_mode=kr_foreign" % (reason, total, src, _RECOMMEND_INDEX_SOURCE_VERSION), xbmc.LOGINFO)
            section_stats = {}
            ok_count = err_count = 0
            batch_size = 800
            for start in range(0, total, batch_size):
                if progress and progress.iscanceled():
                    log("[PKM_INDEX] import_canceled done=%d total=%d" % (start, total), xbmc.LOGWARNING)
                    break
                batch_items = local_items[start:start + batch_size]
                keys = [x[0] for x in batch_items]
                key_to_section = {x[0]: x[1] for x in batch_items}
                t_batch = time.time()
                metas = _fetch_plex_metadata_rows(plex_conn, keys)
                taggings, type_counts = _fetch_plex_taggings(plex_conn, keys)
                log("[PKM_INDEX] tag_type_counts batch_start=%d counts=%s country_source=metadata_items.tags_country ignored_country_tag_types=[6,8]" % (start, json.dumps(type_counts, sort_keys=True)), xbmc.LOGINFO)
                for rk in keys:
                    meta = metas.get(str(rk))
                    if not meta:
                        err_count += 1
                        continue
                    sid = key_to_section.get(str(rk), "")
                    directors, actors, genres, countries = _classify_plex_tags(meta, taggings.get(str(rk), []))
                    saved = _save_recommend_index_rows(local_conn, rk, sid, meta, directors, actors, genres, countries, source=_RECOMMEND_INDEX_SOURCE_VERSION)
                    st = section_stats.setdefault(str(sid), {"items": 0, "directors": 0, "actors": 0, "genres": 0, "countries": 0, "ratings": 0})
                    st["items"] += 1
                    st["directors"] += saved["directors"]
                    st["actors"] += saved["actors"]
                    st["genres"] += saved["genres"]
                    st["countries"] += saved["countries"]
                    st["ratings"] += 1 if saved["score"] is not None else 0
                    ok_count += 1
                    if ok_count <= 20 or ok_count % 1000 == 0:
                        log("[PKM_INDEX] item_indexed rating_key=%s section=%s directors=%d actors=%d genres=%d countries=%d rating=%s audience=%s user=%s score=%s" % (
                            rk, sid, saved["directors"], saved["actors"], saved["genres"], saved["countries"],
                            saved["rating"], saved["audience"], saved["user"], saved["score"]
                        ), xbmc.LOGINFO)
                local_conn.commit()
                elapsed_ms = (time.time() - t_batch) * 1000.0
                log("[PKM_INDEX] chunk_index_done start=%d size=%d ok=%d errors=%d elapsed=%.1fms" % (start, len(batch_items), ok_count, err_count, elapsed_ms), xbmc.LOGINFO)
                if progress and total:
                    progress_update(progress, int(min(99, (float(min(start + batch_size, total)) / float(total)) * 100.0)), "Importing recommendation DB\n%d / %d" % (min(start + batch_size, total), total))
            now = int(time.time())
            for sid, st in section_stats.items():
                local_conn.execute("""
                    INSERT INTO item_recommend_index_state(section_id, source, indexed_at, item_count, people_count, genre_count, country_count, rating_count, last_error)
                    VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(section_id) DO UPDATE SET
                        source=excluded.source,
                        indexed_at=excluded.indexed_at,
                        item_count=excluded.item_count,
                        people_count=excluded.people_count,
                        genre_count=excluded.genre_count,
                        country_count=excluded.country_count,
                        rating_count=excluded.rating_count,
                        last_error=''
                """, (sid, _RECOMMEND_INDEX_SOURCE_VERSION, now, st["items"], st["directors"] + st["actors"], st["genres"], st["countries"], st["ratings"], ""))
                log("[PKM_INDEX] section_index_done section=%s items=%d directors=%d actors=%d genres=%d countries=%d ratings=%d" % (
                    sid, st["items"], st["directors"], st["actors"], st["genres"], st["countries"], st["ratings"]
                ), xbmc.LOGINFO)
            local_conn.commit()
            total_ms = (time.perf_counter() - t_all) * 1000.0
            total_with_copy_ms_v1738 = (time.perf_counter() - bench_total_t0_v1738) * 1000.0
            LAST_RECOMMEND_DB_IMPORT_BENCH = {"result": "success", "copy_ms": copy_ms_v1738, "import_ms": total_ms, "total_ms": total_with_copy_ms_v1738, "items": ok_count, "errors": err_count, "sections": len(section_stats), "bytes": int(copy_bench_v1738.get("bytes", 0) or 0), "method": str(copy_bench_v1738.get("method", ""))}
            log("[PKM_INDEX] import_done ok=%d errors=%d sections=%d total_ms=%.1f source=%s country_mode=kr_foreign bootstrap=plex_db" % (ok_count, err_count, len(section_stats), total_ms, _RECOMMEND_INDEX_SOURCE_VERSION), xbmc.LOGINFO)
            log("[PKM_BENCH] RECOMMEND_DB_IMPORT_DONE mode=plex_db result=success import_ms=%.1f items=%d errors=%d sections=%d items_per_sec=%.2f" % (
                total_ms, ok_count, err_count, len(section_stats), (float(ok_count) * 1000.0 / total_ms) if total_ms > 0 else 0.0
            ), xbmc.LOGINFO)
            log("[PKM_BENCH] RECOMMEND_DONE mode=plex_db result=success copy_ms=%.1f import_ms=%.1f post_library_ms=%.1f items=%d errors=%d items_per_sec=%.2f" % (
                copy_ms_v1738, total_ms, total_with_copy_ms_v1738, ok_count, err_count,
                (float(ok_count) * 1000.0 / total_with_copy_ms_v1738) if total_with_copy_ms_v1738 > 0 else 0.0
            ), xbmc.LOGINFO)
            try:
                log_recommend_index_summary(reason="import_done")
            except Exception:
                pass
            if progress:
                progress_update(progress, 100, "Recommendation DB import complete\n%d items" % ok_count)
            notify("Recommendation DB imported: %d items" % ok_count, icon=xbmcgui.NOTIFICATION_INFO, ms=4000)
            return True
        finally:
            try:
                local_conn.close()
            except Exception:
                pass
            try:
                plex_conn.close()
            except Exception:
                pass
    except Exception:
        failed_total_ms_v1738 = (time.perf_counter() - bench_total_t0_v1738) * 1000.0
        LAST_RECOMMEND_DB_IMPORT_BENCH = {"result": "failed", "copy_ms": float((LAST_PLEX_DB_COPY_BENCH or {}).get("elapsed_ms", 0.0) or 0.0), "import_ms": 0.0, "total_ms": failed_total_ms_v1738, "items": 0, "errors": 1, "sections": 0}
        log("[PKM_INDEX] import_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        log("[PKM_BENCH] RECOMMEND_DONE mode=plex_db result=failed copy_ms=%.1f post_library_ms=%.1f" % (LAST_RECOMMEND_DB_IMPORT_BENCH["copy_ms"], failed_total_ms_v1738), xbmc.LOGINFO)
        notify("Recommendation DB import failed. See kodi.log", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return False
    finally:
        if progress and not external_progress:
            try:
                progress.close()
            except Exception:
                pass

def xml_attr_int(xml, key, default=0):
    try:
        value = xml.get(key)
        return int(value) if value not in (None, "") else default
    except Exception:
        return default


def plex_date_to_int(value, default=0):
    try:
        s = str(value or "").strip()
        if not s:
            return int(default or 0)
        m = re.match(r"^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?", s)
        if not m:
            return int(default or 0)
        y = int(m.group(1) or 0)
        mo = int(m.group(2) or 1)
        d = int(m.group(3) or 1)
        return y * 10000 + mo * 100 + d
    except Exception:
        return int(default or 0)


def plex_type_from_xml(xml, section_type=None):
    value = xml.get("type") or section_type or ""
    if value in ("movie", "show", "episode"):
        return value
    return section_type or value


def kodi_type_from_plex_type(plex_type):
    if plex_type == PLEX_TYPE_MOVIE:
        return "movie"
    if plex_type == PLEX_TYPE_SHOW:
        return "tvshow"
    if plex_type == PLEX_TYPE_EPISODE:
        return "episode"
    return "video"


def find_first_part(xml):
    part = xml.find(".//Part")
    if part is None:
        return "", ""
    return part.get("file", ""), part.get("key", "")


def extract_item(xml, section_id, section_type):
    plex_type = plex_type_from_xml(xml, section_type)
    media_file, part_key = find_first_part(xml)
    title = xml.get("title") or xml.get("grandparentTitle") or "Missing Title"
    sort_title = xml.get("titleSort") or title
    updated_at = xml_attr_int(xml, "updatedAt", xml_attr_int(xml, "addedAt", 0))
    added_at = xml_attr_int(xml, "addedAt", 0)
    rating_key = xml.get("ratingKey") or xml.get("key") or ""
    checksum = "%s:%s" % (rating_key, updated_at or added_at)
    media_node = xml.find(".//Media")
    media_bitrate = ""
    media_height = ""
    media_width = ""
    media_resolution = ""
    try:
        if media_node is not None:
            media_bitrate = media_node.get("bitrate") or ""
            media_height = media_node.get("height") or ""
            media_width = media_node.get("width") or ""
            media_resolution = media_node.get("videoResolution") or media_node.get("resolution") or ""
    except Exception:
        pass
    raw = {
        "ratingKey": rating_key,
        "key": xml.get("key"),
        "guid": xml.get("guid") or "",
        "type": plex_type,
        "title": title,
        "titleSort": sort_title,
        # v2122: persist authoritative Plex hierarchy metadata for TV copy
        # identity. Alternate encodes can live under a separate season node
        # (for example Plex index 102 titled "시즌 2 4K"). Future syncs keep
        # that parent season identity in raw_json so media-version matching does
        # not depend on the Info screen having fetched /children first.
        "parentTitle": xml.get("parentTitle") or "",
        "parentIndex": xml.get("parentIndex") or "",
        "parentRatingKey": xml.get("parentRatingKey") or "",
        "grandparentTitle": xml.get("grandparentTitle") or "",
        "grandparentRatingKey": xml.get("grandparentRatingKey") or "",
        "year": xml.get("year"),
        "originallyAvailableAt": xml.get("originallyAvailableAt") or "",
        "rating": xml.get("rating") or "",
        "audienceRating": xml.get("audienceRating") or "",
        "userRating": xml.get("userRating") or "",
        "status": xml.get("status") or "",
        "leafCount": xml.get("leafCount") or "",
        "viewedLeafCount": xml.get("viewedLeafCount") or "",
        "childCount": xml.get("childCount") or "",
        "thumb": xml.get("thumb"),
        "parentThumb": xml.get("parentThumb") or "",
        "grandparentThumb": xml.get("grandparentThumb") or "",
        "art": xml.get("art"),
        "parentArt": xml.get("parentArt") or "",
        "grandparentArt": xml.get("grandparentArt") or "",
        "file": media_file,
        "part_key": part_key,
        "videoResolution": media_resolution,
        "height": media_height,
        "width": media_width,
        "bitrate": media_bitrate,
    }
    return {
        "rating_key": rating_key,
        "section_id": str(section_id),
        "plex_type": plex_type,
        "kodi_type": kodi_type_from_plex_type(plex_type),
        "title": title,
        "original_title": xml.get("originalTitle", ""),
        "sort_title": sort_title,
        "year": xml_attr_int(xml, "year", 0),
        "summary": xml.get("summary", ""),
        "duration": xml_attr_int(xml, "duration", 0) // 1000,
        "added_at": added_at,
        "updated_at": updated_at,
        "checksum": checksum,
        # Episodes should use show-level poster/fanart in PKM Home/section rows.
        # allLeaves can expose season/episode art first; using that for Home hero
        # makes newly added TV shows lose their Plex show fanart until Info opens.
        # Prefer grandparent/show images for episode cards, keep movie/show behavior unchanged.
        "thumb": art_url((xml.get("grandparentThumb") if plex_type == PLEX_TYPE_EPISODE else "") or xml.get("thumb") or xml.get("parentThumb") or xml.get("grandparentThumb") or "", width=720, height=1080),
        "art": art_url((xml.get("grandparentArt") if plex_type == PLEX_TYPE_EPISODE else "") or xml.get("art") or xml.get("parentArt") or xml.get("grandparentArt") or "", width=1920, height=1080),
        "media_file": media_file,
        "part_key": part_key,
        "view_count": xml_attr_int(xml, "viewCount", 0),
        "last_viewed_at": xml_attr_int(xml, "lastViewedAt", 0),
        # Live resume position from Plex onDeck/timeline. Stored in milliseconds.
        "view_offset": xml_attr_int(xml, "viewOffset", 0),
        "parent_rating_key": xml.get("parentRatingKey", ""),
        "grandparent_rating_key": xml.get("grandparentRatingKey", ""),
        "show_title": xml.get("grandparentTitle", ""),
        "season": xml_attr_int(xml, "parentIndex", 0),
        "episode": xml_attr_int(xml, "index", 0),
        "raw_json": json.dumps(raw, ensure_ascii=False),
        "synced_at": int(time.time()),
    }


def upsert_section(conn, section):
    conn.execute("""
        INSERT INTO sections(section_id, title, section_type, thumb, art, scanned_at, item_count)
        VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(section_id) DO UPDATE SET
            title=excluded.title,
            section_type=excluded.section_type,
            thumb=excluded.thumb,
            art=excluded.art,
            scanned_at=excluded.scanned_at,
            item_count=excluded.item_count
    """, (
        str(section["section_id"]), section["title"], section["section_type"],
        section.get("thumb", ""), section.get("art", ""),
        section.get("scanned_at", int(time.time())), section.get("item_count", 0)
    ))


def upsert_item(conn, item):
    columns = [
        "rating_key", "section_id", "plex_type", "kodi_type", "title", "original_title",
        "sort_title", "year", "summary", "duration", "added_at", "updated_at",
        "checksum", "thumb", "art", "media_file", "part_key", "view_count",
        "last_viewed_at", "parent_rating_key", "grandparent_rating_key", "show_title",
        "season", "episode", "raw_json", "synced_at"
    ]
    placeholders = ",".join(["?"] * len(columns))
    update = ",".join(["%s=excluded.%s" % (c, c) for c in columns if c != "rating_key"])
    sql = "INSERT INTO items(%s) VALUES(%s) ON CONFLICT(rating_key) DO UPDATE SET %s" % (
        ",".join(columns), placeholders, update
    )
    conn.execute(sql, [item.get(c) for c in columns])




def _purge_rating_keys_with_connections_v2348(conn, search_conn, section_id, rating_keys, reason="sync"):
    """Remove Plex-local rows for rating keys that are no longer authoritative.

    v2348 invariant: an ``items`` row is content only while the same ratingKey is
    present in the current Plex library membership snapshot.  Every cache table
    keyed by that ratingKey is deleted in the same transaction boundary so Home,
    Search, actor-work/recommendation indexes, and Cine21 per-item mappings cannot
    resurrect a server-missing item after the main row has been removed.
    """
    sid = str(section_id or "").strip()
    keys = []
    seen = set()
    for value in rating_keys or []:
        key = str(value or "").strip()
        if key and key not in seen:
            keys.append(key)
            seen.add(key)
    result = {"total": 0, "movie": 0, "show": 0, "episode": 0}
    if not keys:
        return result

    batch_size = 350
    now = int(time.time())
    for i in range(0, len(keys), batch_size):
        batch = keys[i:i + batch_size]
        ph = ",".join(["?"] * len(batch))
        try:
            rows = conn.execute(
                "SELECT plex_type, COUNT(*) FROM items WHERE rating_key IN (%s) GROUP BY plex_type" % ph,
                batch,
            ).fetchall()
            for plex_type, count in rows:
                key = str(plex_type or "")
                if key in result:
                    result[key] += int(count or 0)
                result["total"] += int(count or 0)
        except Exception:
            pass

        # Main-DB side tables. Some tables are optional on older profiles, so
        # each delete is deliberately independent.
        for table in (
            "item_people", "item_genres", "item_countries", "item_ratings",
            "item_studios", "cine21_matches", "cine21_expert_reviews",
        ):
            try:
                conn.execute("DELETE FROM %s WHERE rating_key IN (%s)" % (table, ph), batch)
            except Exception:
                pass
        conn.execute("DELETE FROM items WHERE rating_key IN (%s)" % ph, batch)

        if search_conn is not None:
            try:
                search_conn.execute("DELETE FROM search_items WHERE rating_key IN (%s)" % ph, batch)
            except Exception:
                pass

    if sid:
        try:
            conn.execute(
                "UPDATE sections SET item_count=(SELECT COUNT(*) FROM items WHERE section_id=?) WHERE section_id=?",
                (sid, sid),
            )
        except Exception:
            pass
        # Keep recommendation readiness counters consistent instead of leaving
        # counts that still describe deleted Plex items.
        try:
            conn.execute(
                "UPDATE item_recommend_index_state SET "
                "item_count=(SELECT COUNT(*) FROM items WHERE section_id=?), "
                "people_count=(SELECT COUNT(*) FROM item_people WHERE section_id=?), "
                "genre_count=(SELECT COUNT(*) FROM item_genres WHERE section_id=?), "
                "country_count=(SELECT COUNT(*) FROM item_countries WHERE section_id=?), "
                "rating_count=(SELECT COUNT(*) FROM item_ratings WHERE section_id=?), "
                "indexed_at=? WHERE section_id=?",
                (sid, sid, sid, sid, sid, now, sid),
            )
        except Exception:
            pass

    try:
        conn.commit()
    except Exception:
        pass
    try:
        if search_conn is not None:
            search_conn.execute(
                "UPDATE search_index_state SET search_count=(SELECT COUNT(*) FROM search_items), indexed_at=? WHERE id=1",
                (now,),
            )
            search_conn.commit()
    except Exception:
        pass

    log("PKM_SERVER_AUTH_PURGE_V2348 section=%s reason=%s removed=%d movie=%d show=%d episode=%d" % (
        sid, str(reason or "sync"), int(result.get("total", 0) or 0),
        int(result.get("movie", 0) or 0), int(result.get("show", 0) or 0),
        int(result.get("episode", 0) or 0)
    ), xbmc.LOGINFO)
    return result


def purge_rating_keys_local_v2348(section_id, rating_keys, reason="sync"):
    """Open DB handles and apply the v2348 server-authoritative purge."""
    conn = init_db()
    search_conn = None
    try:
        try:
            search_conn = sqlite3.connect(search_db_path(), timeout=8.0)
            init_search_db(search_conn)
        except Exception:
            search_conn = None
        return _purge_rating_keys_with_connections_v2348(
            conn, search_conn, section_id, rating_keys, reason=reason
        )
    finally:
        try:
            if search_conn is not None:
                search_conn.close()
        except Exception:
            pass
        conn.close()


def purge_sections_local_v2348(section_ids, reason="plex_section_removed"):
    """Purge caches for Plex library sections that no longer exist on the server."""
    ids = []
    seen = set()
    for value in section_ids or []:
        sid = str(value or "").strip()
        if sid and sid not in seen:
            ids.append(sid)
            seen.add(sid)
    total = {"total": 0, "movie": 0, "show": 0, "episode": 0, "sections": 0}
    if not ids:
        return total
    conn = init_db()
    search_conn = None
    try:
        try:
            search_conn = sqlite3.connect(search_db_path(), timeout=8.0)
            init_search_db(search_conn)
        except Exception:
            search_conn = None
        for sid in ids:
            rows = conn.execute("SELECT rating_key FROM items WHERE section_id=?", (sid,)).fetchall()
            keys = [str(r[0]) for r in rows if r and r[0] is not None]
            stats = _purge_rating_keys_with_connections_v2348(
                conn, search_conn, sid, keys, reason=reason
            )
            for key in ("total", "movie", "show", "episode"):
                total[key] += int(stats.get(key, 0) or 0)
            # Clean any old side rows that predate the items row itself.
            for table in ("item_people", "item_genres", "item_countries", "item_ratings", "item_studios"):
                try:
                    conn.execute("DELETE FROM %s WHERE section_id=?" % table, (sid,))
                except Exception:
                    pass
            try:
                conn.execute("DELETE FROM cine21_matches WHERE pkm_section_id=?", (sid,))
            except Exception:
                pass
            try:
                conn.execute("DELETE FROM item_recommend_index_state WHERE section_id=?", (sid,))
            except Exception:
                pass
            conn.execute("DELETE FROM sync_state WHERE section_id=?", (sid,))
            conn.execute("DELETE FROM sections WHERE section_id=?", (sid,))
            if search_conn is not None:
                try:
                    search_conn.execute("DELETE FROM search_items WHERE section_id=?", (sid,))
                except Exception:
                    pass
            total["sections"] += 1
        conn.commit()
        if search_conn is not None:
            try:
                search_conn.execute(
                    "UPDATE search_index_state SET search_count=(SELECT COUNT(*) FROM search_items), indexed_at=? WHERE id=1",
                    (int(time.time()),),
                )
                search_conn.commit()
            except Exception:
                pass
        log("PKM_SERVER_AUTH_SECTION_PURGE_V2348 reason=%s sections=%d removed=%d ids=%s" % (
            str(reason or "plex_section_removed"), int(total.get("sections", 0) or 0),
            int(total.get("total", 0) or 0), ",".join(ids)
        ), xbmc.LOGWARNING)
        return total
    finally:
        try:
            if search_conn is not None:
                search_conn.close()
        except Exception:
            pass
        conn.close()


def fetch_sections(refresh=True, selected_only=True, persist=True):
    # v2367: a pre-Home authority snapshot can be read directly from Plex without
    # opening/writing SQLite.  Normal callers keep the historical persist=True
    # behavior.
    conn = init_db() if (not refresh or persist) else None
    sections = []
    if refresh:
        root = plex_request_xml("/library/sections")
        now = int(time.time())
        for d in list(root):
            if d.tag != "Directory":
                continue
            section_type = d.get("type", "")
            if section_type not in (PLEX_TYPE_MOVIE, PLEX_TYPE_SHOW):
                continue
            section_updated_at = xml_attr_int(d, "updatedAt", now)
            section = {
                "section_id": d.get("key", ""),
                "title": d.get("title", ""),
                "section_type": section_type,
                "thumb": art_url(d.get("thumb", ""), width=720, height=1080),
                "art": art_url(d.get("art", ""), width=1920, height=1080),
                "scanned_at": section_updated_at,
                "updated_at": section_updated_at,
                "item_count": 0,
            }
            sections.append(section)
            if persist and conn is not None:
                upsert_section(conn, section)
        if persist and conn is not None:
            conn.commit()
    else:
        rows = conn.execute("SELECT section_id, title, section_type, thumb, art, scanned_at, item_count FROM sections ORDER BY title COLLATE NOCASE").fetchall()
        for row in rows:
            sections.append({
                "section_id": row[0], "title": row[1], "section_type": row[2],
                "thumb": row[3], "art": row[4], "scanned_at": row[5], "item_count": row[6]
            })
    if conn is not None:
        conn.close()
    if selected_only:
        sections = filter_selected_sections(sections)
    return sections


def normalize_section_title(value):
    return display_library_title(value).strip().lower().replace(" ", "")


def find_section(section_id=None, section_title=None, refresh=True):
    """Resolve a Plex library section.

    Skins should prefer section_title over section_id because Plex section ids can
    change when libraries are recreated. Exact title match is attempted first,
    followed by a whitespace/case-insensitive match.
    """
    if section_id:
        conn = init_db()
        row = conn.execute(
            "SELECT section_id, title, section_type, thumb, art, scanned_at, item_count FROM sections WHERE section_id=?",
            (str(section_id),)
        ).fetchone()
        conn.close()
        if row:
            section = {
                "section_id": row[0], "title": row[1], "section_type": row[2],
                "thumb": row[3], "art": row[4], "scanned_at": row[5], "item_count": row[6]
            }
            if section_selection_configured() and str(section.get("section_id", "")) not in set(selected_section_ids()):
                return None
            return section

    sections = fetch_sections(refresh=True if refresh else False)

    if section_id:
        for section in sections:
            if str(section.get("section_id")) == str(section_id):
                return section

    if section_title:
        target = section_title.strip()
        for section in sections:
            if section.get("title", "") == target:
                return section
        target_norm = normalize_section_title(target)
        for section in sections:
            if normalize_section_title(section.get("title", "")) == target_norm:
                return section

    return None


def section_ref_from_params(params):
    return {
        "section_id": params.get("section_id") or params.get("id") or "",
        "section_title": params.get("section_title") or params.get("section") or params.get("library") or params.get("title") or "",
    }


def get_section(section_id=None, section_title=None):
    return find_section(section_id=section_id, section_title=section_title, refresh=True)


def _pkm_full_reset_in_progress_v2149():
    try:
        win_v2150 = xbmcgui.Window(10000)
        return bool(win_v2150.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win_v2150.getProperty("PlexKM.FullResetInProgressV2149") == "1")
    except Exception:
        return False


def fetch_section_items(section_id, section_type, progress=None, prune_missing=False, force_all=False):
    chunk_size = setting_int("chunk_size", 200, min_value=1, max_value=1000)
    max_items = 0 if force_all else setting_int("max_sync_items", 0, min_value=0)
    endpoints = []
    endpoint = "/library/sections/%s/all" % section_id
    params_base = {
        "checkFiles": 0,
        "includeExtras": 0,
        "includeReviews": 0,
        "includeRelated": 0,
        "skipRefresh": 1,
    }
    if section_type in (PLEX_TYPE_MOVIE, PLEX_TYPE_SHOW):
        params_base["type"] = PLEX_TYPE_TO_NUM.get(section_type, "")
    endpoints.append((endpoint, dict(params_base), "primary"))
    if section_type == PLEX_TYPE_SHOW:
        # TV libraries must sync episodes at startup too.  The show list alone
        # leaves stale/incomplete episode rows such as 5/8 episodes in Info.
        ep_params = {
            "checkFiles": 0, "includeExtras": 0, "includeReviews": 0,
            "includeRelated": 0, "skipRefresh": 1,
        }
        endpoints.append(("/library/sections/%s/allLeaves" % section_id, ep_params, "episodes"))

    conn = init_db()
    search_conn = None
    try:
        search_conn = sqlite3.connect(search_db_path())
        init_search_db(search_conn)
    except Exception:
        search_conn = None
        log("SEARCH_INDEX_SYNC_OPEN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    # v228: Live recommendation updates are useful only after the initial
    # Plex-DB bootstrap exists.  Check once per section, not once per item.
    rec_live_bootstrap_ready = False
    rec_live_update_enabled = False
    rec_live_skipped_changed = 0
    try:
        rec_live_update_enabled = bool(recommend_index_source_enabled() and str(section_type or "") == PLEX_TYPE_MOVIE)
        if rec_live_update_enabled:
            rec_live_bootstrap_ready = recommend_index_has_bootstrap_state(conn)
            if not rec_live_bootstrap_ready:
                log("[PKM_INDEX] live_section_update_skip section=%s reason=no_bootstrap_state mode=skip_per_item_update" % (section_id,), xbmc.LOGINFO)
    except Exception:
        rec_live_update_enabled = False
        rec_live_bootstrap_ready = False
    start = 0
    fetched = 0
    seen_keys = set()
    # v2173: TV sections are fetched through two Plex endpoints: show rows
    # (/all?type=show) followed by all episode rows (/allLeaves).  Previously
    # total_size started with only the first endpoint count, so the visible
    # progress denominator changed from e.g. 2163 to 69566 midway through the
    # same library.  Preflight only the episode total (one tiny size=1 query);
    # the show total comes from the first normal /all response.  This avoids a
    # redundant show-count request while still giving the final show+episode
    # denominator from the first progress update.
    episode_total_preflight_v2173 = 0
    progress_total_preflight_ready_v2173 = False
    if progress is not None and str(section_type or "") == PLEX_TYPE_SHOW:
        try:
            episode_total_preflight_v2173 = int(_remote_total_for_path(
                "/library/sections/%s/allLeaves" % section_id
            ) or 0)
            progress_total_preflight_ready_v2173 = True
            log("SYNC_TV_PROGRESS_EPISODE_TOTAL_PREFLIGHT_V2173 section=%s episode=%d" % (
                section_id, episode_total_preflight_v2173
            ), xbmc.LOGINFO)
        except Exception:
            episode_total_preflight_v2173 = 0
            progress_total_preflight_ready_v2173 = False
            log("SYNC_TV_PROGRESS_EPISODE_TOTAL_PREFLIGHT_FAILED_V2173 section=%s err=%s" % (
                section_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
    total_size = None
    changed_by_type = {"movie": 0, "show": 0, "episode": 0}
    added_by_type = {"movie": 0, "show": 0, "episode": 0}
    tv_tag_indexed = 0
    tv_tag_failed = 0
    t0 = time.time()
    rec_bench_t0_v1738 = time.perf_counter()
    rec_api_inline_ms_v1738 = 0.0
    rec_api_inline_calls_v1738 = 0
    rec_api_inline_indexed_v1738 = 0
    aborted_full_reset_v2149 = False
    try:
        for endpoint, base_params, source_name in endpoints:
            if _pkm_full_reset_in_progress_v2149():
                aborted_full_reset_v2149 = True
                log("SYNC_SECTION_ABORT_V2149 section=%s stage=endpoint_begin reason=full_reset" % section_id, xbmc.LOGINFO)
                break
            start = 0
            source_total = None
            while True:
                if _pkm_full_reset_in_progress_v2149():
                    aborted_full_reset_v2149 = True
                    log("SYNC_SECTION_ABORT_V2149 section=%s stage=before_request source=%s start=%d reason=full_reset" % (
                        section_id, source_name, start
                    ), xbmc.LOGINFO)
                    break
                params = dict(base_params)
                params["X-Plex-Container-Start"] = start
                params["X-Plex-Container-Size"] = chunk_size
                root = plex_request_xml(endpoint, params=params, timeout=30)
                if _pkm_full_reset_in_progress_v2149():
                    aborted_full_reset_v2149 = True
                    log("SYNC_SECTION_ABORT_V2149 section=%s stage=after_request source=%s start=%d reason=full_reset" % (
                        section_id, source_name, start
                    ), xbmc.LOGINFO)
                    break
                if source_total is None:
                    source_total = xml_attr_int(root, "totalSize", 0)
                    if (str(section_type or "") == PLEX_TYPE_SHOW
                            and progress_total_preflight_ready_v2173):
                        if source_name == "primary":
                            total_size = int(source_total or 0) + int(episode_total_preflight_v2173 or 0)
                            log("SYNC_TV_PROGRESS_TOTAL_READY_V2173 section=%s show=%d episode=%d total=%d" % (
                                section_id, int(source_total or 0), int(episode_total_preflight_v2173 or 0), int(total_size or 0)
                            ), xbmc.LOGINFO)
                        # episodes were already included by the preflight hint.
                    else:
                        # Movie/single-endpoint and preflight-failure paths keep
                        # the original per-endpoint accumulation behavior.
                        total_size = int(total_size or 0) + int(source_total or 0)
                children = [x for x in list(root) if x.tag in ("Video", "Directory")]
                if not children:
                    break
                for child in children:
                    if _pkm_full_reset_in_progress_v2149():
                        aborted_full_reset_v2149 = True
                        log("SYNC_SECTION_ABORT_V2149 section=%s stage=item_loop source=%s fetched=%d reason=full_reset" % (
                            section_id, source_name, fetched
                        ), xbmc.LOGINFO)
                        break
                    item = extract_item(child, section_id, section_type)
                    if item["rating_key"]:
                        seen_keys.add(str(item["rating_key"]))
                        old_checksum = None
                        old_row = None
                        try:
                            old_row = conn.execute("SELECT checksum FROM items WHERE rating_key=?", (str(item.get("rating_key") or ""),)).fetchone()
                            old_checksum = old_row[0] if old_row else None
                        except Exception:
                            old_checksum = None
                        if old_checksum != item.get("checksum"):
                            key = str(item.get("plex_type") or "")
                            if key in changed_by_type:
                                changed_by_type[key] += 1
                        if old_row is None:
                            key = str(item.get("plex_type") or "")
                            if key in added_by_type:
                                added_by_type[key] += 1
                        upsert_item(conn, item)
                        try:
                            if search_conn is not None:
                                upsert_search_index_item(search_conn, item, section_title="")
                        except Exception:
                            log("SEARCH_INDEX_SYNC_UPSERT_FAILED rating_key=%s\n%s" % (item.get("rating_key", ""), traceback.format_exc()), xbmc.LOGWARNING)
                        try:
                            movie_detail_missing = False
                            try:
                                movie_detail_missing = (str(item.get("plex_type") or "") == PLEX_TYPE_MOVIE and _movie_detail_index_missing(conn, item.get("rating_key")))
                            except Exception:
                                movie_detail_missing = False
                            if str(item.get("plex_type") or "") == PLEX_TYPE_MOVIE and (old_checksum != item.get("checksum") or movie_detail_missing):
                                # v1330: Info depends on these side tables.  Full sync must
                                # repair them even when the item checksum is unchanged but
                                # item_people/item_genres/item_ratings are empty from an older
                                # partial sync.  This is DB sync, not Info-time network repair.
                                rec_call_t0_v1738 = time.perf_counter()
                                rec_result_v1738 = update_recommend_index_from_live_xml(
                                    child, item,
                                    reason="sync_missing_detail" if movie_detail_missing and old_checksum == item.get("checksum") else "sync_changed",
                                    conn=conn, bootstrap_ready=True, log_skips=False
                                )
                                rec_api_inline_ms_v1738 += (time.perf_counter() - rec_call_t0_v1738) * 1000.0
                                rec_api_inline_calls_v1738 += 1
                                if rec_result_v1738:
                                    rec_api_inline_indexed_v1738 += 1
                            elif old_checksum != item.get("checksum") and rec_live_update_enabled:
                                rec_live_skipped_changed += 1
                        except Exception:
                            log("[PKM_INDEX] live_update_after_upsert_failed rating_key=%s\n%s" % (item.get("rating_key", ""), traceback.format_exc()), xbmc.LOGWARNING)
                        try:
                            if str(item.get("plex_type") or "") == PLEX_TYPE_SHOW and (old_checksum != item.get("checksum") or _tv_tag_index_missing(conn, item.get("rating_key"))):
                                if _save_tv_show_tag_index(conn, item, child, reason="section_sync_changed" if old_checksum != item.get("checksum") else "section_sync_missing"):
                                    tv_tag_indexed += 1
                        except Exception:
                            tv_tag_failed += 1
                            log("[PKM_TV_TAGS] sync_index_failed rating_key=%s\n%s" % (item.get("rating_key", ""), traceback.format_exc()), xbmc.LOGWARNING)
                        fetched += 1
                        if max_items and fetched >= max_items:
                            break
                conn.commit()
                try:
                    if search_conn is not None:
                        search_conn.commit()
                except Exception:
                    pass
                if progress and total_size:
                    percent = int(min(100, (float(fetched) / float(total_size)) * 100.0))
                    progress_update(progress, percent, "Syncing %s\n%d / %d" % (section_id, fetched, total_size))
                    if progress.iscanceled():
                        break
                log("sync section=%s source=%s start=%d chunk=%d fetched=%d source_total=%s total=%s" % (section_id, source_name, start, len(children), fetched, source_total, total_size), xbmc.LOGDEBUG)
                if aborted_full_reset_v2149:
                    break
                if max_items and fetched >= max_items:
                    break
                start += len(children)
                if source_total and start >= source_total:
                    break
                if len(children) < chunk_size:
                    break
            if aborted_full_reset_v2149:
                break
            if max_items and fetched >= max_items:
                break
        if prune_missing and not aborted_full_reset_v2149:
            # v2348: Plex membership is authoritative. A full/manual sync and the
            # startup membership reconciler must use the exact same purge path so
            # stale rows cannot survive in Search, actor/recommend side indexes,
            # or Cine21 per-item caches after the main item disappears.
            existing_rows = conn.execute("SELECT rating_key FROM items WHERE section_id=?", (str(section_id),)).fetchall()
            existing_keys = set(str(r[0]) for r in existing_rows if r and r[0] is not None)
            current_keys = set(str(k) for k in seen_keys)
            stale_keys = sorted(existing_keys - current_keys)
            if stale_keys:
                purge_stats_v2348 = _purge_rating_keys_with_connections_v2348(
                    conn, search_conn, str(section_id), stale_keys, reason="full_sync_prune_v2348"
                )
                log("STARTUP_SYNC_FULL_PRUNE_V2348 section=%s candidates=%d removed=%d server_authoritative=1" % (
                    section_id, len(stale_keys), int((purge_stats_v2348 or {}).get("total", 0) or 0)
                ), xbmc.LOGINFO)
        if not aborted_full_reset_v2149:
            now = int(time.time())
            conn.execute("UPDATE sections SET scanned_at=?, item_count=(SELECT COUNT(*) FROM items WHERE section_id=?) WHERE section_id=?", (now, str(section_id), str(section_id)))
            conn.commit()
        else:
            log("SYNC_SECTION_ABORT_COMMIT_SKIP_V2149 section=%s fetched=%d prune=0 scanned_at_update=0" % (section_id, fetched), xbmc.LOGINFO)
    finally:
        try:
            if search_conn is not None:
                search_conn.commit()
                search_conn.close()
        except Exception:
            pass
        conn.close()
    elapsed = time.time() - t0
    if tv_tag_indexed or tv_tag_failed:
        log("[PKM_TV_TAGS] section_sync_summary section=%s indexed=%d failed=%d changed_show=%d elapsed=%.1fs" % (
            section_id, tv_tag_indexed, tv_tag_failed, int(changed_by_type.get("show", 0) or 0), elapsed
        ), xbmc.LOGINFO)
    if rec_live_update_enabled and not rec_live_bootstrap_ready and rec_live_skipped_changed:
        log("[PKM_INDEX] live_section_update_skip_summary section=%s changed_items=%d reason=no_bootstrap_state" % (section_id, rec_live_skipped_changed), xbmc.LOGINFO)
    try:
        global LAST_FETCH_SECTION_STATS, LAST_FETCH_RECOMMEND_BENCH
        # Startup notifications describe content added since the previous local
        # snapshot. Metadata-only updates must not be reported as new movies or
        # episodes.
        LAST_FETCH_SECTION_STATS = dict(added_by_type)
        LAST_FETCH_RECOMMEND_BENCH = {
            "section_id": str(section_id),
            "section_type": str(section_type or ""),
            "inline_ms": float(rec_api_inline_ms_v1738),
            "calls": int(rec_api_inline_calls_v1738),
            "indexed": int(rec_api_inline_indexed_v1738),
            "section_elapsed_ms": float(elapsed * 1000.0),
            "fetched": int(fetched),
        }
        if str(section_type or "") == PLEX_TYPE_MOVIE:
            config_mode_v1738 = "plex_db" if plex_db_copy_setting() else "plex_api"
            log("[PKM_BENCH] RECOMMEND_API_INLINE_SECTION_DONE config_mode=%s section=%s calls=%d indexed=%d elapsed_ms=%.1f section_elapsed_ms=%.1f items_per_sec=%.2f" % (
                config_mode_v1738, section_id, rec_api_inline_calls_v1738, rec_api_inline_indexed_v1738,
                rec_api_inline_ms_v1738, elapsed * 1000.0,
                (float(rec_api_inline_indexed_v1738) * 1000.0 / rec_api_inline_ms_v1738) if rec_api_inline_ms_v1738 > 0 else 0.0
            ), xbmc.LOGINFO)
    except Exception:
        pass
    return fetched, total_size or fetched, elapsed



def repair_tv_art_cache_integrity(section_id, section_title="", fetch_remote=True, reason="startup"):
    """Normalize TV show/episode poster and fanart cache for Home/section rows.

    This is a data-only cache repair.  It does not open windows, move focus,
    navigate, or touch playback.  The goal is that startup sync guarantees
    local DB art quality, so Home can keep using cached rows without live Plex
    calls for every focus change.
    """
    sid = str(section_id or "").strip()
    if not sid:
        return 0
    repaired = 0
    remote_seen = 0
    remote_updated = 0
    t0 = time.time()

    def _nonempty(v):
        return str(v or "").strip()

    conn = init_db()
    try:
        # Optional lightweight remote show pass: only show rows, never allLeaves.
        # This fixes stale/missing show art even when startup count/latest checks say no_change.
        if fetch_remote:
            try:
                chunk_size = setting_int("chunk_size", 200, min_value=1, max_value=1000)
                start = 0
                source_total = None
                while True:
                    params = {
                        "type": PLEX_TYPE_TO_NUM.get(PLEX_TYPE_SHOW, "2"),
                        "checkFiles": 0,
                        "includeExtras": 0,
                        "includeReviews": 0,
                        "includeRelated": 0,
                        "skipRefresh": 1,
                        "X-Plex-Container-Start": start,
                        "X-Plex-Container-Size": chunk_size,
                    }
                    root = plex_request_xml("/library/sections/%s/all" % sid, params=params, timeout=20)
                    if source_total is None:
                        source_total = xml_attr_int(root, "totalSize", 0)
                    children = [x for x in list(root) if x.tag in ("Directory", "Video")]
                    if not children:
                        break
                    for child in children:
                        item = extract_item(child, sid, PLEX_TYPE_SHOW)
                        rk = _nonempty(item.get("rating_key"))
                        if not rk:
                            continue
                        remote_seen += 1
                        old = conn.execute("SELECT COALESCE(thumb,''), COALESCE(art,'') FROM items WHERE rating_key=?", (rk,)).fetchone()
                        old_thumb = old[0] if old else ""
                        old_art = old[1] if old else ""
                        new_thumb = _nonempty(item.get("thumb"))
                        new_art = _nonempty(item.get("art"))
                        if (new_thumb and new_thumb != old_thumb) or (new_art and new_art != old_art) or not old:
                            upsert_item(conn, item)
                            remote_updated += 1
                    conn.commit()
                    start += len(children)
                    if source_total and start >= source_total:
                        break
                    if len(children) < chunk_size:
                        break
            except Exception:
                log("TV_ART_CACHE_REMOTE_CHECK_FAILED section=%s title=%s reason=%s err=%s" % (
                    sid, section_title or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        # Local integrity repair: episode cards must inherit show poster/fanart when show rows have them.
        # This fixes pre-existing caches that were created with episode/season art priority.
        show_rows = conn.execute(
            "SELECT rating_key, COALESCE(title,''), COALESCE(thumb,''), COALESCE(art,'') "
            "FROM items WHERE section_id=? AND plex_type=?",
            (sid, PLEX_TYPE_SHOW)
        ).fetchall()
        for show_key, title, show_thumb, show_art in show_rows:
            show_key = _nonempty(show_key)
            show_thumb = _nonempty(show_thumb)
            show_art = _nonempty(show_art)
            if not show_key:
                continue
            if not show_thumb and not show_art:
                log("TV_ART_CACHE_CHECK section=%s show=%s title=%s status=missing_show_art" % (sid, show_key, title or ""), xbmc.LOGINFO)
                continue
            sets = []
            args = []
            if show_thumb:
                sets.append("thumb=?")
                args.append(show_thumb)
            if show_art:
                sets.append("art=?")
                args.append(show_art)
            if not sets:
                continue
            sets.append("synced_at=?")
            args.append(int(time.time()))
            args.extend([sid, PLEX_TYPE_EPISODE, show_key])
            where_extra = []
            if show_thumb:
                where_extra.append("COALESCE(thumb,'')<>?")
                args.append(show_thumb)
            if show_art:
                where_extra.append("COALESCE(art,'')<>?")
                args.append(show_art)
            sql = (
                "UPDATE items SET %s WHERE section_id=? AND plex_type=? AND grandparent_rating_key=?" % ",".join(sets)
            )
            if where_extra:
                sql += " AND (" + " OR ".join(where_extra) + ")"
            cur = conn.execute(sql, tuple(args))
            n = int(getattr(cur, "rowcount", 0) or 0)
            if n > 0:
                repaired += n
                if title == "참교육" or show_key == "9478911":
                    log("TV_ART_CACHE_REPAIR section=%s show=%s title=%s episodes=%d source=show_db_art art=%s" % (
                        sid, show_key, title or "", n, "yes" if show_art else "no"
                    ), xbmc.LOGINFO)
        if repaired:
            conn.commit()
            # Search DB mirrors art/thumb for search cards.  Best effort only.
            try:
                sc = sqlite3.connect(search_db_path())
                try:
                    init_search_db(sc)
                    sc.execute(
                        "UPDATE search_items SET thumb=(SELECT i.thumb FROM items i WHERE i.rating_key=search_items.rating_key), "
                        "art=(SELECT i.art FROM items i WHERE i.rating_key=search_items.rating_key), indexed_at=? "
                        "WHERE section_id=? AND plex_type=? AND rating_key IN (SELECT rating_key FROM items WHERE section_id=? AND plex_type=?)",
                        (int(time.time()), sid, PLEX_TYPE_EPISODE, sid, PLEX_TYPE_EPISODE)
                    )
                    sc.commit()
                finally:
                    sc.close()
            except Exception:
                log("TV_ART_CACHE_SEARCH_MIRROR_FAILED section=%s err=%s" % (sid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            try:
                win = xbmcgui.Window(10000)
                win.setProperty("PlexKM.PlexUpdate.Dirty", "1")
                win.setProperty("PlexKM.PlexUpdate.Sections", sid)
                win.setProperty("PlexKM.PlexUpdate.Time", str(int(time.time())))
                win.setProperty("PlexKM.ArtCacheRepaired", "1")
            except Exception:
                pass
        log("TV_ART_CACHE_CHECK section=%s title=%s reason=%s remote_seen=%d remote_updated=%d repaired=%d ms=%d" % (
            sid, section_title or "", reason or "", remote_seen, remote_updated, repaired, int((time.time() - t0) * 1000.0)
        ), xbmc.LOGINFO)
        return repaired + remote_updated
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        log("TV_ART_CACHE_REPAIR_FAILED section=%s title=%s reason=%s err=%s" % (
            sid, section_title or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return 0
    finally:
        try:
            conn.close()
        except Exception:
            pass


def sync_section(section_id=None, section_title=None, show_progress=True):


    audit_event(None, "sync_sync_section_enter")
    section = get_section(section_id=section_id, section_title=section_title)
    if not section:
        ref = section_title or section_id
        raise RuntimeError("Section not found: %s" % ref)
    progress = None
    if show_progress:
        progress = _create_pkm_sync_progress()
        progress_create(progress, ADDON_NAME, "Syncing Plex library: %s" % display_library_title(section.get("title", str(section_id))))
    try:
        fetched, total, elapsed = fetch_section_items(section["section_id"], section["section_type"], progress=progress)
        if recommend_index_source_enabled() and plex_db_copy_setting() and section.get("section_type") == PLEX_TYPE_MOVIE:
            try:
                import_recommend_index_from_plex_db(section_ids=[section["section_id"]], show_progress=False, reason="sync_section")
            except Exception:
                log("[PKM_INDEX] import_after_section_sync_failed section=%s\n%s" % (section.get("section_id"), traceback.format_exc()), xbmc.LOGWARNING)
        mark_large_wall_prepared_after_sync(section, sort="added")
        refresh_token_v1554 = _signal_home_data_refresh(reason="manual_section_sync_committed_v1554")
        log("SYNC_WIDGET_REFRESH_SIGNAL_V1554 scope=section section=%s token=%s fetched=%d" % (
            section.get("section_id", ""), refresh_token_v1554, fetched
        ), xbmc.LOGINFO)
        msg = "Synced %d items in %.1f sec" % (fetched, elapsed)
        log(msg)
        notify(msg)
        return fetched, total, elapsed
    finally:
        if progress:
            progress.close()


class _WeightedSectionProgress(object):
    def __init__(self, progress, start_percent, span_percent, section_index, total_sections, section_title):
        self.progress = progress
        self.start_percent = int(start_percent or 0)
        self.span_percent = max(1, int(span_percent or 1))
        self.section_index = int(section_index or 1)
        self.total_sections = max(1, int(total_sections or 1))
        self.section_title = section_title or ""

    def update(self, percent, message=""):
        pct = max(0, min(100, int(percent or 0)))
        combined = self.start_percent + int((float(pct) / 100.0) * float(self.span_percent))
        combined = max(0, min(99, combined))
        parts = [x for x in str(message or "").split("\n") if x is not None]
        detail = parts[-1] if parts else ""
        progress_update(
            self.progress,
            combined,
            "Syncing section %d / %d\n%s\n%s" % (self.section_index, self.total_sections, self.section_title, detail),
        )

    def iscanceled(self):
        try:
            return bool(self.progress and self.progress.iscanceled())
        except Exception:
            return False


class _WeightedStageProgress(object):
    """Map a child stage's 0..100 progress into one parent progress range."""
    def __init__(self, progress, start_percent, span_percent):
        self.progress = progress
        self.start_percent = int(start_percent or 0)
        self.span_percent = max(1, int(span_percent or 1))

    def update(self, percent, message=""):
        pct = max(0, min(100, int(percent or 0)))
        combined = self.start_percent + int((float(pct) / 100.0) * float(self.span_percent))
        progress_update(self.progress, max(0, min(99, combined)), message)

    def iscanceled(self):
        try:
            return bool(self.progress and self.progress.iscanceled())
        except Exception:
            return False


def sync_all_sections(show_prompt=False, show_progress=True, mark_auto_sync=True, lock_already_held=False, section_ids=None, progress_title=None, completion_confirm=False, precreated_progress=None):


    audit_event(None, "sync_sync_all_sections_enter")
    """Run every visible sync with one caller-owned PKM modal on all platforms.

    v2014 keeps the same PKM WindowXMLDialog and XML on Windows/Android and
    removes close-opacity transitions from the confirm/progress handoff.

    v1964 removes the Android-only/native and Windows/helper-thread split.  Any
    sync with ``show_progress=True`` performs prompts on the caller thread,
    runs network/database work on a worker, and keeps PKM WindowXMLDialog
    ``doModal()`` on the caller thread.  Background syncs keep ``show_progress``
    false and therefore open no dialog.
    """
    if not show_progress:
        return _sync_all_sections_impl_v1927(
            show_prompt=show_prompt,
            show_progress=False,
            mark_auto_sync=mark_auto_sync,
            lock_already_held=lock_already_held,
            section_ids=section_ids,
            progress_title=progress_title,
            completion_confirm=completion_confirm,
            precreated_progress=None,
        )

    # Prompts are GUI work and must never run in the sync worker.
    if show_prompt:
        ok_v1964 = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            "Plex libraries need to be synced before browsing.\nSync all movie/show libraries now?",
        )
        log(
            "PKM_SYNC_PROMPT_RESULT_V1965 accepted=%d platform_android=%d"
            % (
                1 if ok_v1964 else 0,
                1 if xbmc.getCondVisibility("System.Platform.Android") else 0,
            ),
            xbmc.LOGINFO,
        )
        if not ok_v1964:
            return 0
        show_prompt = False

    progress_v1964 = precreated_progress
    if not bool(getattr(progress_v1964, "_caller_modal_v1927", False)):
        try:
            if progress_v1964 is not None:
                progress_v1964.close()
        except Exception:
            pass
        try:
            progress_v1964 = _create_pkm_sync_progress(caller_modal_v1927=True)
        except Exception:
            log(
                "PKM_SYNC_DIALOG_FATAL_V1965 platform_android=%d "
                "native_fallback=0 sync_started=0 caller=sync_all_sections\n%s"
                % (
                    1 if xbmc.getCondVisibility("System.Platform.Android") else 0,
                    traceback.format_exc(),
                ),
                xbmc.LOGERROR,
            )
            return 0

    if not bool(getattr(progress_v1964, "_caller_modal_v1927", False)):
        log(
            "PKM_SYNC_DIALOG_FATAL_V1965 platform_android=%d "
            "native_fallback=0 sync_started=0 reason=invalid_progress_object"
            % (1 if xbmc.getCondVisibility("System.Platform.Android") else 0),
            xbmc.LOGERROR,
        )
        return 0

    result_v1964 = {"value": 0, "error": None}

    def _sync_worker_v1964():
        try:
            # v1982: do not begin Plex scanning until the PKM progress XML has
            # actually entered onInit.  Object construction/prearm alone is not
            # a visible progress window.
            init_event_v1982 = getattr(progress_v1964, "_init_event", None)
            if init_event_v1982 is not None:
                init_event_v1982.wait(3.0)
            if not bool(init_event_v1982 is not None and init_event_v1982.is_set()):
                raise RuntimeError("PKM sync progress did not become visible")
            log("PKM_SYNC_PROGRESS_VISIBLE_BEFORE_SCAN_V1982 visible=%d initialized=1" % (
                1 if xbmc.getCondVisibility("Window.IsVisible(13032)") else 0
            ), xbmc.LOGINFO)
            result_v1964["value"] = _sync_all_sections_impl_v1927(
                show_prompt=False,
                show_progress=True,
                mark_auto_sync=mark_auto_sync,
                lock_already_held=lock_already_held,
                section_ids=section_ids,
                progress_title=progress_title,
                completion_confirm=completion_confirm,
                precreated_progress=progress_v1964,
            )
        except Exception as exc:
            result_v1964["error"] = exc
            log("PKM_SYNC_WORKER_FAILED_V1965\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            try:
                progress_v1964.close()
            except Exception:
                pass

    # v2170: pre-arm the PKM sync progress properties on the caller thread
    # before the worker starts.  show_caller_modal_v1927() used to wait up to
    # 1.5s for the worker to call progress_create(), while the worker itself
    # waited for the dialog onInit event (v1982).  That circular handshake made
    # the library-selection Enter key look unresponsive for ~1.5s.  Pre-arming
    # here sets the caller-create-ready event immediately; the modal can paint
    # at once, and the worker still preserves the v1982 rule that Plex scanning
    # begins only after the progress XML has actually entered onInit.
    try:
        progress_create(progress_v1964, progress_title or ADDON_NAME, "라이브러리 싱크 준비 중")
        log("PKM_SYNC_PROGRESS_PREARM_IMMEDIATE_V2170 caller_thread=1 worker_scan_before_visible=0", xbmc.LOGINFO)
    except Exception:
        log("PKM_SYNC_PROGRESS_PREARM_FAILED_V2170\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            progress_v1964.close()
        except Exception:
            pass
        return 0

    worker_v1964 = threading.Thread(
        target=_sync_worker_v1964,
        name="PlexKMUnifiedSyncWorkerV1964",
        daemon=False,
    )
    log(
        "PKM_SYNC_CALLER_MODAL_START_V1965 platform_android=%d "
        "dialog=PKM worker_scan=1 helper_windowxml_thread=0"
        % (1 if xbmc.getCondVisibility("System.Platform.Android") else 0),
        xbmc.LOGINFO,
    )
    worker_v1964.start()
    try:
        progress_v1964.show_caller_modal_v1927()
    finally:
        monitor_v1964 = xbmc.Monitor()
        while worker_v1964.is_alive() and not monitor_v1964.abortRequested():
            worker_v1964.join(0.05)
    log(
        "PKM_SYNC_CALLER_MODAL_DONE_V1965 platform_android=%d worker_alive=%d"
        % (
            1 if xbmc.getCondVisibility("System.Platform.Android") else 0,
            1 if worker_v1964.is_alive() else 0,
        ),
        xbmc.LOGINFO,
    )
    if result_v1964.get("error") is not None:
        raise result_v1964["error"]
    return result_v1964.get("value", 0)


def _sync_all_sections_impl_v1927(show_prompt=False, show_progress=True, mark_auto_sync=True, lock_already_held=False, section_ids=None, progress_title=None, completion_confirm=False, precreated_progress=None):


    audit_event(None, "sync__sync_all_sections_impl_v1927_enter")
    lock_acquired_here = False
    progress = precreated_progress
    initial_setup_ready_v1736 = False
    bench_initial_t0_v1738 = time.perf_counter()
    bench_library_ms_v1738 = 0.0
    bench_inline_ms_v1738 = 0.0
    bench_inline_calls_v1738 = 0
    bench_inline_items_v1738 = 0
    bench_mode_v1738 = "plex_db" if plex_db_copy_setting() else "plex_api"
    bench_recommend_post_ms_v1738 = 0.0
    bench_recommend_work_ms_v1738 = 0.0
    try:
        if completion_confirm:
            try:
                setup_win_v1736 = xbmcgui.Window(10000)
                setup_win_v1736.clearProperty("PlexKM.InitialSetupReadyV1736")
                setup_win_v1736.setProperty("PlexKM.InitialSetupSyncActiveV1736", "1")
            except Exception:
                pass
        if not lock_already_held:
            lock_acquired_here = acquire_sync_lock(label="sync-all")
            if not lock_acquired_here:
                log("sync_all_sections skipped because another sync is running", xbmc.LOGINFO)
                return 0

        explicit_section_filter = section_ids is not None
        sections = fetch_sections(refresh=True, selected_only=not explicit_section_filter)
        target_ids = set()
        if explicit_section_filter:
            target_ids = set(str(x) for x in (section_ids or []) if str(x))
            sections = [s for s in sections if str(s.get("section_id", "")) in target_ids]
            log("SYNC_SECTION_FILTER mode=explicit target=%s matched=%d" % (",".join(sorted(target_ids)), len(sections)), xbmc.LOGINFO)
        else:
            selected, configured = selected_sections_state()
            log("SYNC_SECTION_FILTER mode=%s target=%s matched=%d" % ("selected" if configured else "unconfigured_empty", ",".join(selected), len(sections)), xbmc.LOGINFO)
        if not sections:
            notify("No Plex libraries found", icon=xbmcgui.NOTIFICATION_WARNING)
            return 0

        if show_prompt:
            ok = xbmcgui.Dialog().yesno(
                ADDON_NAME,
                "Plex libraries need to be synced before browsing.\nSync all movie/show libraries now?",
            )
            if not ok:
                return 0

        if show_progress:
            if progress is None:
                progress = _create_pkm_sync_progress()
            else:
                log("PKM_SYNC_PROGRESS_REUSE_PREARMED_V1747 window=13032", xbmc.LOGINFO)
        else:
            progress = None
        if progress:
            progress_create(progress, progress_title or ADDON_NAME, "라이브러리 싱크 준비 중")

        total_fetched = 0
        total_sections = len(sections)
        log("[PKM_BENCH] INITIAL_SYNC_BEGIN mode=%s sections=%d section_filter=%s completion_confirm=%d" % (
            bench_mode_v1738, total_sections, ",".join(sorted(target_ids)) if explicit_section_filter else "selected_or_all", 1 if completion_confirm else 0
        ), xbmc.LOGINFO)
        bench_library_t0_v1738 = time.perf_counter()
        sync_span_percent = 88 if completion_confirm else 100
        for index, section in enumerate(sections, start=1):
            if progress and progress.iscanceled():
                break
            base_percent = int((float(index - 1) / max(1, total_sections)) * sync_span_percent)
            progress_update(
                progress,
                base_percent,
                "Syncing section %d / %d\n%s" % (index, total_sections, display_library_title(section.get("title", "")))
            )
            section_span = max(1, int(float(sync_span_percent) / float(max(1, total_sections))))
            section_progress = _WeightedSectionProgress(progress, base_percent, section_span, index, total_sections, display_library_title(section.get("title", ""))) if progress else None
            # v1983: an initial install and an explicitly re-selected library
            # are authoritative Plex refreshes.  Existing DB rows are reusable
            # comparison data only; they never suppress the Plex scan.  Fetch
            # the complete current section, upsert new/changed rows, and prune
            # rows no longer present on Plex.  Routine background refreshes keep
            # their existing bounded behavior.
            authoritative_refresh_v1983 = bool(explicit_section_filter or completion_confirm or (not initial_sync_done()))
            fetched, total, elapsed = fetch_section_items(
                section["section_id"],
                section["section_type"],
                progress=section_progress,
                prune_missing=authoritative_refresh_v1983,
                force_all=authoritative_refresh_v1983,
            )
            log(
                "SYNC_SECTION_AUTHORITATIVE_V1983 section=%s explicit=%d initial=%d completion=%d "
                "db_reuse=1 plex_full_scan=%d prune_missing=%d fetched=%d total=%s"
                % (
                    section.get("section_id", ""),
                    1 if explicit_section_filter else 0,
                    1 if not initial_sync_done() else 0,
                    1 if completion_confirm else 0,
                    1 if authoritative_refresh_v1983 else 0,
                    1 if authoritative_refresh_v1983 else 0,
                    int(fetched or 0),
                    str(total),
                ),
                xbmc.LOGINFO,
            )
            total_fetched += fetched
            # v1967: a selected Plex library becomes sidebar-visible only after
            # its own sync pass has completed. Selection is merely the user's
            # requested target set; it must not publish unfinished libraries.
            try:
                update_sync_state(
                    section["section_id"],
                    int(section.get("updated_at") or section.get("scanned_at") or 0),
                    int(total or 0),
                    synced=True,
                )
                log("SYNC_SECTION_SIDEBAR_READY_V1967 section=%s title=%s total=%s" % (
                    section.get("section_id", ""), section.get("title", ""), int(total or 0)
                ), xbmc.LOGINFO)
            except Exception:
                log("SYNC_SECTION_SIDEBAR_READY_FAILED_V1967 section=%s err=%s" % (
                    section.get("section_id", ""), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            try:
                fetch_rec_bench_v1738 = dict(LAST_FETCH_RECOMMEND_BENCH or {})
                if str(fetch_rec_bench_v1738.get("section_id", "")) == str(section.get("section_id", "")):
                    bench_inline_ms_v1738 += float(fetch_rec_bench_v1738.get("inline_ms", 0.0) or 0.0)
                    bench_inline_calls_v1738 += int(fetch_rec_bench_v1738.get("calls", 0) or 0)
                    bench_inline_items_v1738 += int(fetch_rec_bench_v1738.get("indexed", 0) or 0)
            except Exception:
                pass
            mark_large_wall_prepared_after_sync(section, sort="added")
            log("synced section=%s title=%s fetched=%d total=%s elapsed=%.1f" % (section["section_id"], section["title"], fetched, total, elapsed))

        if progress and progress.iscanceled():
            set_initial_sync_done(False)
            log("SYNC_ALL_CANCELED_V1736 fetched=%d sections=%d" % (total_fetched, total_sections), xbmc.LOGINFO)
            return 0

        bench_library_ms_v1738 = (time.perf_counter() - bench_library_t0_v1738) * 1000.0
        log("[PKM_BENCH] LIBRARY_SYNC_DONE mode=%s elapsed_ms=%.1f items=%d sections=%d recommend_inline_ms=%.1f recommend_inline_calls=%d recommend_inline_items=%d" % (
            bench_mode_v1738, bench_library_ms_v1738, total_fetched, total_sections,
            bench_inline_ms_v1738, bench_inline_calls_v1738, bench_inline_items_v1738
        ), xbmc.LOGINFO)
        # v2148 diagnostic: prove whether actor Role.thumb values already exist
        # immediately after the Plex library construction pass, before Info is
        # ever opened and before the post-sync recommendation-index stage.
        _actor_thumb_sync_report_v2148(
            phase="library_core",
            section_ids=[str(sec.get("section_id") or "") for sec in sections],
        )
        progress_update(progress, sync_span_percent, "라이브러리 싱크 완료\n추천 위젯 DB를 확인합니다")
        set_initial_sync_done(True)
        if mark_auto_sync:
            set_last_auto_sync_at()
        # v776d: Cine21 is movie-only.  During interactive initial/full/selected
        # Plex sync, automatically build/fill Cine21 DB after movie libraries are
        # synced, with visible progress.  Non-movie syncs skip this entirely.
        # Background/service sync paths keep using the small post-sync updater and
        # never run this long full update without a progress dialog.
        try:
            has_movie_section = any(str(sec.get("section_type") or "") == PLEX_TYPE_MOVIE for sec in sections)
        except Exception:
            has_movie_section = False
        if has_movie_section and progress is not None:
            # Cine21 v774 uses a prebuilt/imported ratings DB and explicit settings action.
            # Do not run the old title-search/detail-fetch updater automatically after sync;
            # Wall/Info must never wait for Cine21 network work.
            log("[PKM_CINE21] sync_after_update_skip reason=import_db_mode", xbmc.LOGINFO)
        elif not has_movie_section:
            log("[PKM_CINE21] sync_after_skip reason=no_movie_section", xbmc.LOGINFO)

        recommend_items_v1736 = 0
        bench_recommend_stage_t0_v1738 = time.perf_counter()
        log("[PKM_BENCH] RECOMMEND_STAGE_BEGIN mode=%s inline_ms=%.1f inline_items=%d" % (
            bench_mode_v1738, bench_inline_ms_v1738, bench_inline_items_v1738
        ), xbmc.LOGINFO)
        if recommend_index_source_enabled():
            index_section_ids = sorted(target_ids) if explicit_section_filter else None
            try:
                if plex_db_copy_setting():
                    log("[PKM_INDEX] bootstrap_after_sync_start reason=sync_all total_items=%d section_filter=%s" % (total_fetched, ",".join(index_section_ids or [])), xbmc.LOGINFO)
                    index_progress = _WeightedStageProgress(progress, 88, 11) if completion_confirm and progress else progress
                    imported = import_recommend_index_from_plex_db(
                        section_ids=index_section_ids,
                        show_progress=show_progress,
                        reason="sync_all",
                        progress=index_progress,
                    )
                    if not imported:
                        raise RuntimeError("recommendation DB import did not complete")
                    recommend_items_v1736 = len(_local_movie_items_for_sections(section_ids=index_section_ids))
                    db_bench_v1738 = dict(LAST_RECOMMEND_DB_IMPORT_BENCH or {})
                    bench_recommend_post_ms_v1738 = float(db_bench_v1738.get("total_ms", 0.0) or 0.0)
                else:
                    summary_v1736 = finalize_recommend_index_from_api_sync(
                        section_ids=index_section_ids,
                        progress=progress if completion_confirm else None,
                    )
                    recommend_items_v1736 = int((summary_v1736 or {}).get("items", 0) or 0)
                    bench_recommend_post_ms_v1738 = float((summary_v1736 or {}).get("elapsed_ms", 0.0) or 0.0)
            except Exception:
                log("[PKM_INDEX] import_after_sync_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
                if completion_confirm:
                    set_initial_sync_done(False)
                    raise
        if bench_recommend_post_ms_v1738 <= 0.0:
            bench_recommend_post_ms_v1738 = (time.perf_counter() - bench_recommend_stage_t0_v1738) * 1000.0
        bench_recommend_work_ms_v1738 = bench_inline_ms_v1738 + bench_recommend_post_ms_v1738
        log("[PKM_BENCH] RECOMMEND_STAGE_DONE mode=%s post_library_ms=%.1f inline_ms=%.1f total_work_ms=%.1f items=%d inline_items=%d" % (
            bench_mode_v1738, bench_recommend_post_ms_v1738, bench_inline_ms_v1738,
            bench_recommend_work_ms_v1738, recommend_items_v1736, bench_inline_items_v1738
        ), xbmc.LOGINFO)
        # v2148 second snapshot: if counts change here, the recommendation DB
        # stage rather than the core library pass supplied/changed actor thumbs.
        _actor_thumb_sync_report_v2148(
            phase="post_recommend",
            section_ids=[str(sec.get("section_id") or "") for sec in sections],
        )
        bench_processing_ms_v1738 = (time.perf_counter() - bench_initial_t0_v1738) * 1000.0
        log("[PKM_BENCH] INITIAL_SYNC_DONE mode=%s processing_ms=%.1f library_ms=%.1f recommend_post_ms=%.1f recommend_work_ms=%.1f items=%d sections=%d user_confirm_wait_excluded=1" % (
            bench_mode_v1738, bench_processing_ms_v1738, bench_library_ms_v1738,
            bench_recommend_post_ms_v1738, bench_recommend_work_ms_v1738, total_fetched, total_sections
        ), xbmc.LOGINFO)
        # v2048: initial sync is committed locally, then the current completion window exits Kodi.
        # Runtime Home composition after initial sync is intentionally not attempted.
        if completion_confirm and progress:
            try:
                setup_win_v1736 = xbmcgui.Window(10000)
                setup_win_v1736.setProperty("PlexKM.InitialSetupReadyV1736", "1")
                setup_win_v1736.clearProperty("PlexKM.Home.SettingsRequired")
                setup_win_v1736.clearProperty("PlexKM.StartupSettingsIncomplete")
            except Exception:
                pass
            initial_setup_ready_v1736 = True
        if completion_confirm and progress:
            recommend_line_v1736 = "추천 위젯 DB 생성 완료" if recommend_items_v1736 > 0 else "추천 위젯 DB 대상 확인 완료"
            bench_confirm_t0_v1738 = time.perf_counter()
            confirmed_v1736 = progress_complete_and_wait(
                progress,
                "KODI 재시작 필요",
                "라이브러리 설정이 완료되었습니다.\n\n설정을 PKM에 반영하려면 KODI를 재시작해야 합니다.\n아래 [KODI 종료]를 누른 후 KODI를 다시 실행해주세요.",
                exit_on_confirm=True,
                button_label="KODI 종료",
                action_hint="",
            )
            log("PKM_SYNC_COMPLETION_MODAL_RETURN_V1740 confirmed=%d" % (1 if confirmed_v1736 else 0), xbmc.LOGINFO)
            if not confirmed_v1736:
                set_initial_sync_done(False)
                initial_setup_ready_v1736 = False
                return 0
            log("TOKEN_AUTH_INITIAL_COMPLETION_CONFIRMED_V1736 fetched=%d recommend_items=%d" % (total_fetched, recommend_items_v1736), xbmc.LOGINFO)
            log("[PKM_BENCH] INITIAL_SYNC_CONFIRM_DONE mode=%s confirmed=1 wait_ms=%.1f" % (
                bench_mode_v1738, (time.perf_counter() - bench_confirm_t0_v1738) * 1000.0
            ), xbmc.LOGINFO)
            log("INITIAL_SYNC_EXIT_PROMPT_ACTIVE_V2092 fetched=%d button=KODI_EXIT explicit_restart_instruction=1 runtime_home_prepare=0" % total_fetched, xbmc.LOGINFO)
        else:
            progress_update(progress, 100, "%s 완료\n%d items" % (progress_title or "Plex library sync", total_fetched))
            if progress:
                try:
                    xbmc.sleep(900)
                except Exception:
                    pass
            notify("Synced %d items" % total_fetched)
        return total_fetched
    finally:
        if progress:
            progress.close()
        if completion_confirm:
            try:
                setup_win_v1736 = xbmcgui.Window(10000)
                setup_win_v1736.clearProperty("PlexKM.InitialSetupSyncActiveV1736")
                if not initial_setup_ready_v1736:
                    setup_win_v1736.clearProperty("PlexKM.InitialSetupReadyV1736")
            except Exception:
                pass
        if lock_acquired_here:
            release_sync_lock()


def ensure_initial_sync(interactive=True):


    audit_event(None, "sync_ensure_initial_sync_enter")
    if initial_sync_done():
        return True
    if not clean_server_url() or not plex_token():
        return False
    # v1985: DB rows are cache only. They can never promote an incomplete or
    # canceled selection to an active synchronized installation.
    log("INITIAL_SYNC_DB_INFERENCE_DISABLED_V1985", xbmc.LOGINFO)
    if not interactive:
        return False
    if not section_selection_configured():
        # v1981: only an explicit user action may create a library selection.
        # Existing DB/cache rows are content data, never selection authority.
        if not choose_libraries_dialog(force=False):
            return False
        if initial_sync_done():
            return True
    if not acquire_sync_lock(label="initial-sync"):
        notify("Plex KM sync is already running", icon=xbmcgui.NOTIFICATION_INFO, ms=2500)
        return False
    try:
        return bool(sync_all_sections(show_prompt=True, show_progress=True, mark_auto_sync=True, lock_already_held=True))
    finally:
        release_sync_lock()


def maybe_auto_sync(force=False, background=False, caller="manual"):


    audit_event(None, "sync_maybe_auto_sync_enter")
    """Keep the local cache aligned with current PMS libraries."""
    if not initial_sync_done():
        return False
    if not clean_server_url() or not plex_token():
        return False
    if not force and not auto_sync_due():
        return False
    if not acquire_sync_lock(label="auto-sync:%s" % caller):
        return False
    show_progress = (not background) and setting_bool("auto_sync_show_progress", True)
    log("auto sync started; force=%s background=%s caller=%s last=%s" % (force, background, caller, last_auto_sync_at()))
    try:
        sync_all_sections(show_prompt=False, show_progress=show_progress, mark_auto_sync=True, lock_already_held=True)
        return True
    except Exception:
        log("auto sync failed:\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        if not background:
            notify("Auto sync failed. See kodi.log", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return False
    finally:
        release_sync_lock()


def section_has_items(section_id):
    conn = init_db()
    row = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=?", (str(section_id),)).fetchone()
    conn.close()
    return bool(row and row[0] > 0)


def count_items(section_id, plex_type=None, genre=None):
    conn = init_db()
    try:
        if plex_type:
            row = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=? AND plex_type=?", (str(section_id), plex_type)).fetchone()
        else:
            row = conn.execute("SELECT COUNT(*) FROM items WHERE section_id=?", (str(section_id),)).fetchone()
        return int(row[0] if row else 0)
    finally:
        conn.close()


def query_items(section_id, sort="title", limit=0, offset=0, plex_type=None):
    try:
        sort = str(sort or "title").strip().lower()
    except Exception:
        sort = "title"
    try:
        sort_dir = str(sort_dir or "").strip().lower()
    except Exception:
        sort_dir = ""
    desc = sort_dir in ("desc", "descending", "down")
    d = "DESC" if desc else "ASC"
    rev = "ASC" if desc else "DESC"
    order_map = {
        "title": "sort_title COLLATE NOCASE %s" % d,
        "name": "sort_title COLLATE NOCASE %s" % d,
        "added": "added_at %s, sort_title COLLATE NOCASE ASC" % d,
        "dateadded": "added_at %s, sort_title COLLATE NOCASE ASC" % d,
        "updated": "updated_at %s, sort_title COLLATE NOCASE ASC" % d,
        "year": "year %s, sort_title COLLATE NOCASE ASC" % d,
        "release": "pkm_sort_num(raw_json,'release') %s, year %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "rating": "pkm_sort_num(raw_json,'rating') %s, sort_title COLLATE NOCASE ASC" % d,
        "viewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "lastviewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "recentlyviewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "resolution": "pkm_sort_num(raw_json,'resolution') %s, sort_title COLLATE NOCASE ASC" % d,
        "bitrate": "pkm_sort_num(raw_json,'bitrate') %s, sort_title COLLATE NOCASE ASC" % d,
        "random": "RANDOM()",
    }
    order_by = order_map.get(sort, order_map["title"])
    where = ["section_id=?"]
    args = [str(section_id)]
    if sort in ("viewed", "lastviewed", "recentlyviewed"):
        # v299: "최근 본" rows must mean Plex fully-watched items only.
        # Plex marks completed playback with view_count > 0.  last_viewed_at can
        # exist for resume/partial playback in some sync states, so do not use it
        # by itself here.
        where.append("view_count > 0")
    if plex_type:
        where.append("plex_type=?")
        args.append(plex_type)
    if genre:
        where.append("EXISTS (SELECT 1 FROM item_genres ig WHERE ig.rating_key=items.rating_key AND ig.section_id=items.section_id AND ig.genre=?)")
        args.append(str(genre))
    sql = "SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode FROM items WHERE %s ORDER BY %s" % (" AND ".join(where), order_by)
    progress_python_sort_v1915 = (sort == "progress")
    if limit and limit > 0 and not progress_python_sort_v1915:
        sql += " LIMIT ? OFFSET ?"
        args.extend([int(limit), int(offset)])
    conn = init_db()
    _register_wall_sort_sql_functions(conn, sort=sort, section_id=section_id)
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return rows


def _sort_raw_json_number(raw_json, key):
    try:
        data = json.loads(raw_json or "{}")
        key = str(key or "").strip().lower()
        if key == "rating":
            for k in ("audienceRating", "rating", "userRating"):
                v = data.get(k)
                if v not in (None, ""):
                    return float(v)
            return 0.0
        if key == "release":
            return float(plex_date_to_int(data.get("originallyAvailableAt") or data.get("year") or 0, 0))
        if key == "resolution":
            v = str(data.get("videoResolution") or "").strip().lower()
            if "4k" in v or "2160" in v:
                return 2160.0
            if "1080" in v:
                return 1080.0
            if "720" in v:
                return 720.0
            if "480" in v:
                return 480.0
            try:
                h = float(data.get("height") or 0)
                if h > 0:
                    return h
            except Exception:
                pass
            return 0.0
        if key == "bitrate":
            try:
                return float(data.get("bitrate") or 0)
            except Exception:
                return 0.0
        if key == "status":
            value = str(data.get("status") or data.get("showStatus") or "").strip().lower()
            if any(token in value for token in ("returning", "continuing", "in production", "planned", "airing", "방영")):
                return 2.0
            if any(token in value for token in ("ended", "cancel", "canceled", "cancelled", "종영", "완결")):
                return 1.0
            return 0.0
    except Exception:
        return 0.0
    return 0.0


def _sort_raw_json_text(raw_json, key):
    try:
        data = json.loads(raw_json or "{}")
        name = str(key or "").strip().lower()
        if name == "status":
            return str(data.get("status") or data.get("showStatus") or "").strip().lower()
        return str(data.get(name) or "").strip().lower()
    except Exception:
        return ""


def _register_wall_sort_sql_functions(conn, sort="", section_id=""):
    """Register only the SQL helpers required by the active wall sort.

    v1841: the previous implementation materialized all Cine21, Watcha and
    IMDb rows into three Python dictionaries for every wall page, even for
    ordinary title/added/year/category queries.  On a large library that made
    every 48-item append rescan the complete rating database.  Keep the cheap
    scalar helpers, but load at most the one provider selected by the user and
    limit that map to the current section (plus legacy rows with no section).
    """
    try:
        active_sort = pkm_library_sort.normalize_sort_key(sort)
    except Exception:
        active_sort = str(sort or "").strip().lower()
    section_id = str(section_id or "").strip()

    try:
        conn.create_function("pkm_sort_num", 2, _sort_raw_json_number)
    except Exception:
        pass
    try:
        conn.create_function("pkm_sort_text", 2, _sort_raw_json_text)
    except Exception:
        pass

    def _table_exists(name):
        try:
            return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())
        except Exception:
            return False

    def _table_has_column(table, column):
        try:
            return any(str(row[1]) == str(column) for row in conn.execute("PRAGMA table_info(%s)" % table))
        except Exception:
            return False

    def _score_map(sql, args=()):
        out = {}
        try:
            for rk, val in conn.execute(sql, tuple(args or ())):
                try:
                    out[str(rk)] = float(val or 0)
                except Exception:
                    out[str(rk)] = 0.0
        except Exception:
            pass
        return out

    provider_scores = {}
    # Register the selected provider UDF even when its optional table is absent.
    # SQLite still resolves the function name in ORDER BY; an empty map must
    # therefore return 0 instead of failing the complete wall query.
    provider_name = active_sort if active_sort in ("cine21", "watcha", "imdb") else ""
    if provider_name == "cine21" and _table_exists("cine21_matches"):
        sql = "SELECT rating_key, COALESCE(critic_rating,audience_rating,0) FROM cine21_matches"
        args = ()
        if section_id and _table_has_column("cine21_matches", "pkm_section_id"):
            sql += " WHERE pkm_section_id=? OR COALESCE(pkm_section_id,'')=''"
            args = (section_id,)
        provider_scores = _score_map(sql, args)
    elif provider_name == "watcha" and _table_exists("watcha_ratings"):
        sql = "SELECT rating_key, COALESCE(watcha_rating,0) FROM watcha_ratings"
        args = ()
        if section_id and _table_has_column("watcha_ratings", "section_id"):
            sql += " WHERE section_id=? OR COALESCE(section_id,'')=''"
            args = (section_id,)
        provider_scores = _score_map(sql, args)
    elif provider_name == "imdb" and _table_exists("item_ratings"):
        sql = "SELECT rating_key, COALESCE(rating,score,audience_rating,user_rating,0) FROM item_ratings"
        args = ()
        if section_id and _table_has_column("item_ratings", "section_id"):
            sql += " WHERE section_id=? OR COALESCE(section_id,'')=''"
            args = (section_id,)
        provider_scores = _score_map(sql, args)

    try:
        if provider_name == "cine21":
            conn.create_function("pkm_cine21_score", 1, lambda rk: float(provider_scores.get(str(rk), 0.0)))
        elif provider_name == "watcha":
            conn.create_function("pkm_watcha_score", 1, lambda rk: float(provider_scores.get(str(rk), 0.0)))
        elif provider_name == "imdb":
            conn.create_function("pkm_imdb_score", 1, lambda rk: float(provider_scores.get(str(rk), 0.0)))

        def _content_rank(raw):
            try:
                data = json.loads(raw or "{}")
                v = str(data.get("contentRating") or data.get("content_rating") or "").lower()
                if "전체" in v or v in ("all", "g", "tv-g"): return 0
                if "7" in v: return 7
                if "12" in v: return 12
                if "15" in v: return 15
                if "18" in v or "청불" in v or "r" == v: return 18
            except Exception:
                pass
            return 999
        conn.create_function("pkm_content_rating_rank", 1, _content_rank)
    except Exception:
        pass



def _tv_show_wall_order_by(sort, sort_dir, random_seed=None):
    """Return a show-level ORDER BY expression for TV Library mode."""
    sort = pkm_library_sort.normalize_sort_key(sort, media_kind="tv")
    direction = pkm_library_sort.normalize_sort_dir(
        sort_dir if sort_dir not in (None, "") else pkm_library_sort.default_sort_dir(sort)
    )
    d = "DESC" if direction == "desc" else "ASC"
    title_expr = "COALESCE(NULLIF(s.sort_title,''),NULLIF(s.title,''),NULLIF(ep.show_title,''),ep.title) COLLATE NOCASE"
    order_map = {
        "title": "%s %s" % (title_expr, d),
        "added": "COALESCE(g.latest_added_at,s.added_at,0) %s, %s ASC" % (d, title_expr),
        "year": "COALESCE(NULLIF(s.year,0),g.latest_year,0) %s, %s ASC" % (d, title_expr),
        "first_air": "pkm_sort_num(COALESCE(NULLIF(s.raw_json,''),ep.raw_json),'release') %s, %s ASC" % (d, title_expr),
        "recent_air": "COALESCE(g.latest_air_num,0) %s, %s ASC" % (d, title_expr),
        "tmdb": "pkm_sort_num(COALESCE(NULLIF(s.raw_json,''),ep.raw_json),'rating') %s, %s ASC" % (d, title_expr),
        "progress": "CASE WHEN COALESCE(g.episode_count,0)>0 THEN CAST(COALESCE(g.watched_count,0) AS REAL)/CAST(g.episode_count AS REAL) ELSE 0 END %s, %s ASC" % (d, title_expr),
        "unwatched": "MAX(COALESCE(g.episode_count,0)-COALESCE(g.watched_count,0),0) %s, %s ASC" % (d, title_expr),
        "viewed": "COALESCE(g.latest_viewed_at,s.last_viewed_at,0) %s, %s ASC" % (d, title_expr),
        "seasons": "COALESCE(g.season_count,0) %s, %s ASC" % (d, title_expr),
        "status": "pkm_sort_num(COALESCE(NULLIF(s.raw_json,''),ep.raw_json),'status') %s, %s ASC" % (d, title_expr),
    }
    if sort == "random":
        seed = int(random_seed or 0) & 0x7fffffff
        return "(((CAST(k.show_key AS INTEGER) * 1103515245) + %d) & 2147483647) ASC, k.show_key ASC" % seed
    return order_map.get(sort, order_map["title"])


def _tv_show_genre_clause(genre=None):
    if not genre:
        return "", []
    clause = """
        AND EXISTS (
            SELECT 1
            FROM item_genres ig
            WHERE ig.section_id=k.section_id
              AND ig.genre=?
              AND (
                    ig.rating_key=k.show_key
                 OR ig.rating_key IN (
                        SELECT ge.rating_key
                        FROM items ge
                        WHERE ge.section_id=k.section_id
                          AND ge.plex_type='episode'
                          AND ge.grandparent_rating_key=k.show_key
                    )
              )
        )
    """
    return clause, [str(genre)]


def query_tv_shows_count(section_id, genre=None):
    """Return one visible Library card per TV series."""
    conn = init_db()
    try:
        genre_sql, genre_args = _tv_show_genre_clause(genre=genre)
        sql = """
            WITH show_keys AS (
                SELECT section_id, rating_key AS show_key
                FROM items
                WHERE section_id=? AND plex_type='show'
                UNION
                SELECT section_id, grandparent_rating_key AS show_key
                FROM items
                WHERE section_id=? AND plex_type='episode'
                  AND COALESCE(grandparent_rating_key,'')<>''
                GROUP BY section_id, grandparent_rating_key
            )
            SELECT COUNT(*)
            FROM show_keys k
            WHERE 1=1 %s
        """ % genre_sql
        args = [str(section_id), str(section_id)] + list(genre_args)
        row = conn.execute(sql, args).fetchone()
        count = int((row[0] if row else 0) or 0)
        log("TV_SHOW_WALL_COUNT_V1911 section=%s genre=%s count=%d" % (
            section_id, genre or "", count
        ))
        return count
    finally:
        conn.close()


def query_tv_shows_wall_light(section_id, sort="title", sort_dir=None,
                               limit=0, offset=0, random_seed=None,
                               genre=None):
    """Return one local-cache-only Library row per TV series.

    Episode aggregates provide latest-added time, recent air date, progress,
    unwatched count, last watched date and season count without a Plex request.
    """
    sort = pkm_library_sort.normalize_sort_key(sort, media_kind="tv")
    if sort_dir is None or str(sort_dir or "").strip() == "":
        sort_dir = pkm_library_sort.default_sort_dir(sort)
    else:
        sort_dir = pkm_library_sort.normalize_sort_dir(sort_dir)
    conn = init_db()
    try:
        _register_wall_sort_sql_functions(conn, sort=sort, section_id=section_id)
        order_by = _tv_show_wall_order_by(sort, sort_dir, random_seed=random_seed)
        genre_sql, genre_args = _tv_show_genre_clause(genre=genre)
        sql = """
            WITH show_keys AS (
                SELECT section_id, rating_key AS show_key
                FROM items
                WHERE section_id=? AND plex_type='show'
                UNION
                SELECT section_id, grandparent_rating_key AS show_key
                FROM items
                WHERE section_id=? AND plex_type='episode'
                  AND COALESCE(grandparent_rating_key,'')<>''
                GROUP BY section_id, grandparent_rating_key
            ), episode_groups AS (
                SELECT
                    section_id,
                    grandparent_rating_key AS show_key,
                    COUNT(*) AS episode_count,
                    SUM(CASE WHEN COALESCE(view_count,0)>0 THEN 1 ELSE 0 END) AS watched_count,
                    MAX(COALESCE(added_at,0)) AS latest_added_at,
                    MAX(COALESCE(updated_at,0)) AS latest_updated_at,
                    MAX(COALESCE(last_viewed_at,0)) AS latest_viewed_at,
                    MAX(COALESCE(year,0)) AS latest_year,
                    MAX(COALESCE(pkm_sort_num(raw_json,'release'),0)) AS latest_air_num,
                    COUNT(DISTINCT CASE WHEN COALESCE(season,0)>0 THEN season END) AS season_count
                FROM items
                WHERE section_id=? AND plex_type='episode'
                  AND COALESCE(grandparent_rating_key,'')<>''
                GROUP BY section_id, grandparent_rating_key
            )
            SELECT
                k.show_key AS rating_key,
                k.section_id,
                'show' AS plex_type,
                'tvshow' AS kodi_type,
                COALESCE(NULLIF(s.title,''),NULLIF(ep.show_title,''),ep.title) AS title,
                COALESCE(s.original_title,'') AS original_title,
                COALESCE(NULLIF(s.sort_title,''),NULLIF(s.title,''),NULLIF(ep.show_title,''),ep.title) AS sort_title,
                COALESCE(NULLIF(s.year,0),g.latest_year,0) AS year,
                COALESCE(NULLIF(s.summary,''),ep.summary,'') AS summary,
                0 AS duration,
                COALESCE(g.latest_added_at,s.added_at,0) AS added_at,
                COALESCE(g.latest_updated_at,s.updated_at,0) AS updated_at,
                COALESCE(NULLIF(s.thumb,''),ep.thumb,'') AS thumb,
                COALESCE(NULLIF(s.art,''),ep.art,'') AS art,
                '' AS media_file,
                '' AS part_key,
                CASE WHEN COALESCE(g.episode_count,0)>0 AND COALESCE(g.watched_count,0)>=g.episode_count THEN 1 ELSE 0 END AS view_count,
                COALESCE(g.latest_viewed_at,s.last_viewed_at,0) AS last_viewed_at,
                COALESCE(NULLIF(s.title,''),NULLIF(ep.show_title,''),ep.title) AS show_title,
                0 AS season,
                0 AS episode,
                '' AS parent_rating_key,
                '' AS grandparent_rating_key,
                0 AS pkm_view_offset,
                0 AS pkm_resume_duration_ms,
                0 AS pkm_resume_updated_at,
                '' AS pkm_resume_source,
                COALESCE(NULLIF(s.raw_json,''),ep.raw_json,'') AS pkm_sort_raw_json,
                COALESCE(g.episode_count,0) AS pkm_episode_count,
                COALESCE(g.watched_count,0) AS pkm_watched_count,
                COALESCE(g.latest_added_at,s.added_at,0) AS pkm_latest_added_at,
                COALESCE(g.latest_viewed_at,s.last_viewed_at,0) AS pkm_latest_viewed_at,
                COALESCE(g.season_count,0) AS pkm_season_count,
                COALESCE(g.latest_air_num,0) AS pkm_latest_air_num
            FROM show_keys k
            LEFT JOIN items s
              ON s.section_id=k.section_id
             AND s.rating_key=k.show_key
             AND s.plex_type='show'
            LEFT JOIN episode_groups g
              ON g.section_id=k.section_id AND g.show_key=k.show_key
            LEFT JOIN items ep
              ON ep.rating_key=(
                    SELECT e2.rating_key
                    FROM items e2
                    WHERE e2.section_id=k.section_id
                      AND e2.plex_type='episode'
                      AND e2.grandparent_rating_key=k.show_key
                    ORDER BY COALESCE(e2.season,0) ASC,
                             COALESCE(e2.episode,0) ASC,
                             e2.rating_key ASC
                    LIMIT 1
                 )
            WHERE 1=1 %s
            ORDER BY %s
        """ % (genre_sql, order_by)
        args = [str(section_id), str(section_id), str(section_id)] + list(genre_args)
        if limit and int(limit) > 0:
            sql += " LIMIT ? OFFSET ?"
            args.extend([int(limit), int(offset or 0)])
        raw_rows = conn.execute(sql, args).fetchall()
        rows = []
        for row in raw_rows:
            base = tuple(row[:28])
            raw_json = row[27] if len(row) > 27 else ""
            try:
                raw = json.loads(raw_json or "{}")
                if not isinstance(raw, dict):
                    raw = {}
            except Exception:
                raw = {}
            try:
                episode_count = int(row[28] or 0)
                watched_count = int(row[29] or 0)
                latest_added_at = int(row[30] or 0)
                latest_viewed_at = int(row[31] or 0)
                season_count = int(row[32] or 0)
                latest_air_num = int(float(row[33] or 0))
            except Exception:
                episode_count = watched_count = latest_added_at = latest_viewed_at = season_count = latest_air_num = 0
            rating = ""
            for key in ("rating", "audienceRating", "userRating"):
                if raw.get(key) not in (None, ""):
                    rating = raw.get(key)
                    break
            meta = {
                "episode_count": episode_count,
                "watched_count": watched_count,
                "unwatched_count": max(0, episode_count - watched_count),
                "progress_percent": int(round((float(watched_count) * 100.0) / float(episode_count))) if episode_count > 0 else 0,
                "is_watched": bool(episode_count > 0 and watched_count >= episode_count),
                "latest_added_at": latest_added_at,
                "latest_viewed_at": latest_viewed_at,
                "season_count": season_count,
                "latest_air_date_num": latest_air_num,
                "first_air_date": str(raw.get("originallyAvailableAt") or ""),
                "tmdb_rating": rating,
                "status": str(raw.get("status") or raw.get("showStatus") or ""),
            }
            rows.append(base + (json.dumps(meta, ensure_ascii=False),))
        try:
            first_key = rows[0][0] if rows else ""
            first_title = rows[0][4] if rows else ""
            log("TV_SHOW_WALL_QUERY_V1911 section=%s sort=%s dir=%s limit=%s offset=%s genre=%s rows=%d first_key=%s first_title=%s" % (
                section_id, sort, sort_dir, limit, offset, genre or "", len(rows),
                first_key, first_title
            ))
        except Exception:
            pass
        return rows
    finally:
        conn.close()




_PKM_WALL_RESUME_MAP_CACHE_V1915 = {"signature": None, "items": {}}


def _pkm_wall_resume_map_v1915():
    """Return latest resume state keyed strictly by rating_key.

    Library wall queries are local/cache-only.  Merge the service-startup Plex
    onDeck preload with Kodi's local sidecar without title/year deduplication.
    File mtimes are used as a cheap cache signature so repeated wall appends do
    not reread JSON for every poster.
    """
    paths = (playstate_continue_preload_path(), playstate_resume_path())
    signature = []
    for path in paths:
        try:
            signature.append((path, os.path.getmtime(path), os.path.getsize(path)))
        except Exception:
            signature.append((path, 0, 0))
    signature = tuple(signature)
    cached = _PKM_WALL_RESUME_MAP_CACHE_V1915
    if cached.get("signature") == signature:
        return dict(cached.get("items") or {})

    merged = {}

    def _store(rk, offset=0, duration=0, resume_duration_ms=0, updated_at=0, source=""):
        rk = str(rk or "").strip()
        if not rk:
            return
        try:
            offset = max(0, int(float(offset or 0)))
        except Exception:
            offset = 0
        try:
            duration = max(0, int(float(duration or 0)))
        except Exception:
            duration = 0
        try:
            resume_duration_ms = max(0, int(float(resume_duration_ms or 0)))
        except Exception:
            resume_duration_ms = 0
        try:
            updated_at = max(0, int(float(updated_at or 0)))
        except Exception:
            updated_at = 0
        try:
            _off_ms, _dur_ms, pct = _pkm_progress_pair(offset, duration, resume_duration_ms)
        except Exception:
            _off_ms, _dur_ms, pct = 0, 0, 0
        if not (0 < pct < 90):
            return
        old = merged.get(rk) or {}
        if not old or updated_at >= int(old.get("resume_updated_at") or 0):
            merged[rk] = {
                "view_offset": _off_ms,
                "resume_duration_ms": _dur_ms,
                "resume_updated_at": updated_at,
                "resume_source": source,
                "resume_percent": pct,
            }

    try:
        items, _age = _read_continue_preload_items(max_age=0)
        for item in items or []:
            if not isinstance(item, dict):
                continue
            _store(
                item.get("rating_key"),
                item.get("view_offset"),
                item.get("duration"),
                item.get("resume_duration_ms"),
                item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at"),
                item.get("resume_source") or "plex_ondeck_preload",
            )
    except Exception:
        pass

    try:
        for rk, state in (_read_local_resume_states() or {}).items():
            state = state or {}
            _store(
                state.get("rating_key") or rk,
                state.get("time"),
                0,
                state.get("duration"),
                state.get("updated_at"),
                "kodi_local",
            )
    except Exception:
        pass

    cached["signature"] = signature
    cached["items"] = dict(merged)
    return dict(merged)


def _pkm_wall_attach_resume_v1915(rows, sort="title", sort_dir="asc"):
    """Append per-rating_key resume fields to DB wall rows.

    Different rating_key values are intentionally preserved even when title and
    year match.  For progress sorting, use the resolved resume percentage rather
    than last_viewed_at/duration.
    """
    resume_map = _pkm_wall_resume_map_v1915()
    enriched = []
    for row in rows or []:
        values = list(tuple(row or ()))
        while len(values) < 28:
            values.append("")
        rk = str(values[0] or "")
        state = resume_map.get(rk) or {}
        values[23] = state.get("view_offset", 0)
        values[24] = state.get("resume_duration_ms", 0)
        values[25] = state.get("resume_updated_at", 0)
        values[26] = state.get("resume_source", "")
        enriched.append(tuple(values))
    if pkm_library_sort.normalize_sort_key(sort) == "progress":
        reverse = pkm_library_sort.normalize_sort_dir(sort_dir) == "desc"
        def _progress_key(row):
            rk = str((row[0] if row else "") or "")
            state = resume_map.get(rk) or {}
            watched = 1 if int((row[16] if len(row) > 16 else 0) or 0) > 0 else 0
            pct = int(state.get("resume_percent") or 0)
            title = str((row[6] if len(row) > 6 else row[4] if len(row) > 4 else "") or "").casefold()
            return (watched, pct, title)
        enriched.sort(key=_progress_key, reverse=reverse)
    return enriched


def query_items_wall_light(section_id, sort="title", sort_dir=None, limit=0, offset=0, plex_type=None, random_seed=None, genre=None):
    """Wall-mode fast query for WindowXML Home.

    Keep the query local/cache-only, but return cached summary, duration and
    16:9 art as well. The HTPC-style Home needs hero metadata/fanart for the
    first/focused poster, and these columns are already in the local cache so
    this does not add PMS round-trips.
    """
    sort = pkm_library_sort.normalize_sort_key(sort)
    # v1325: Do not default omitted Home/Recommend sort_dir to ASC.
    # Recent rows call this function with sort="added" and no explicit dir;
    # those rows must match Plex HTPC "Recently Added" semantics, i.e. newest
    # first.  Keep an explicit caller-supplied "asc" valid for manual toggles.
    if sort_dir is None or str(sort_dir or "").strip() == "":
        sort_dir = pkm_library_sort.default_sort_dir(sort)
    else:
        sort_dir = pkm_library_sort.normalize_sort_dir(sort_dir)
    # v772: Sort ORDER BY calculation moved to data-only pkm_library_sort.
    order_by = pkm_library_sort.order_by(sort, sort_dir)
    if sort == "random" and random_seed is not None:
        # v1644: RANDOM()+OFFSET reshuffles every append and skips/duplicates
        # records.  Use a per-Kodi-run deterministic permutation instead.
        seed = int(random_seed or 0) & 0x7fffffff
        order_by = "(((CAST(rating_key AS INTEGER) * 1103515245) + %d) & 2147483647) ASC, rating_key ASC" % seed
    # v1916: v1915 referenced this flag after the query without defining it
    # in query_items_wall_light().  That raised NameError for every movie core
    # row (recently viewed / recently added), leaving only Continue Watching.
    progress_python_sort_v1915 = (sort == "progress")
    where = ["section_id=?"]
    args = [str(section_id)]
    if sort in ("viewed", "lastviewed", "recentlyviewed"):
        # v299: "최근 본" rows must mean Plex fully-watched items only.
        # Plex marks completed playback with view_count > 0.  last_viewed_at can
        # exist for resume/partial playback in some sync states, so do not use it
        # by itself here.
        where.append("view_count > 0")
    if plex_type:
        where.append("plex_type=?")
        args.append(plex_type)
    if genre:
        where.append("EXISTS (SELECT 1 FROM item_genres ig WHERE ig.rating_key=items.rating_key AND ig.section_id=items.section_id AND ig.genre=?)")
        args.append(str(genre))
    sql = (
        "SELECT rating_key, section_id, plex_type, '' AS kodi_type, "
        "title, '' AS original_title, title AS sort_title, year, "
        "summary, duration, added_at, updated_at, thumb, art, "
        "media_file, part_key, view_count, last_viewed_at, "
        "show_title, season, episode, parent_rating_key, grandparent_rating_key, "
        "0 AS pkm_view_offset, 0 AS pkm_resume_duration_ms, "
        "0 AS pkm_resume_updated_at, '' AS pkm_resume_source, raw_json "
        "FROM items WHERE %s ORDER BY %s" % (" AND ".join(where), order_by)
    )
    if limit and limit > 0:
        sql += " LIMIT ? OFFSET ?"
        args.extend([int(limit), int(offset)])
    conn = init_db()
    _register_wall_sort_sql_functions(conn, sort=sort, section_id=section_id)
    rows = conn.execute(sql, args).fetchall()
    rows = _pkm_wall_attach_resume_v1915(rows, sort=sort, sort_dir=sort_dir)
    if progress_python_sort_v1915 and limit and limit > 0:
        rows = rows[int(offset):int(offset) + int(limit)]
    try:
        first_key = rows[0][0] if rows else ""
        first_title = rows[0][4] if rows else ""
        log("WALL_LIGHT_QUERY section=%s sort=%s dir=%s order=%s limit=%s offset=%s rows=%d first_key=%s first_title=%s" % (
            section_id, sort, sort_dir, order_by, limit, offset, len(rows), first_key, first_title))
    except Exception:
        pass
    conn.close()
    return rows



def query_section_genres(section_id):
    """Return Plex-style category cards from the local synchronized genre index."""
    conn = init_db()
    try:
        rows = conn.execute(
            """
            SELECT g.genre, COUNT(DISTINCT g.rating_key) AS item_count,
                   COALESCE((SELECT i.art FROM items i JOIN item_genres gx ON gx.rating_key=i.rating_key
                             WHERE gx.section_id=g.section_id AND gx.genre=g.genre AND IFNULL(i.art,'')<>''
                             ORDER BY i.added_at DESC LIMIT 1), ''),
                   COALESCE((SELECT i.thumb FROM items i JOIN item_genres gx ON gx.rating_key=i.rating_key
                             WHERE gx.section_id=g.section_id AND gx.genre=g.genre AND IFNULL(i.thumb,'')<>''
                             ORDER BY i.added_at DESC LIMIT 1), '')
            FROM item_genres g
            WHERE g.section_id=? AND IFNULL(g.genre,'')<>''
            GROUP BY g.genre
            ORDER BY g.genre COLLATE NOCASE
            """, (str(section_id),)
        ).fetchall()
        log("SECTION_GENRE_QUERY_V1822 section=%s rows=%d" % (section_id, len(rows)))
        return rows
    finally:
        conn.close()


def _wall_light_row_from_item_dict(item):
    """Return the same tuple shape as query_items_wall_light()."""
    # v1210: store the optional continue-progress pair in normalized milliseconds.
    # Plex onDeck can provide duration in seconds while viewOffset is milliseconds
    # (e.g. offset=70070, duration=6220).  Keeping the mixed pair lets XML/Home
    # progress helpers draw a full bar.  Normalizing here makes every consumer
    # receive one safe pair.
    try:
        _off_ms, _dur_ms, _pct = _pkm_progress_pair(item.get("view_offset", 0), item.get("duration", 0), item.get("resume_duration_ms", 0))
    except Exception:
        _off_ms, _dur_ms, _pct = 0, 0, 0
    if _pct <= 0:
        _off_ms = 0
        _dur_ms = 0
    return (
        item.get("rating_key", ""),
        str(item.get("section_id", "")),
        item.get("plex_type", ""),
        "",
        item.get("title", ""),
        "",
        item.get("sort_title", "") or item.get("title", ""),
        item.get("year", 0),
        item.get("summary", ""),
        item.get("duration", 0),
        item.get("added_at", 0),
        item.get("updated_at", 0),
        item.get("thumb", ""),
        item.get("art", ""),
        item.get("media_file", ""),
        item.get("part_key", ""),
        item.get("view_count", 0),
        item.get("last_viewed_at", 0),
        item.get("show_title", ""),
        item.get("season", 0),
        item.get("episode", 0),
        item.get("parent_rating_key", ""),
        item.get("grandparent_rating_key", ""),
        # Extra optional fields after the stable DB row shape. Old callers slice
        # row[:21], so this does not affect wall/list cache compatibility.
        _off_ms,
        _dur_ms,
        item.get("resume_updated_at", 0),
        item.get("resume_source", ""),
        item.get("raw_json", ""),
    )


def _query_continue_watching_wall_preloaded(limit=24, max_age=180):
    # v1985: Home content exists only after an atomic successful initial sync.
    if not initial_sync_done():
        log("PLAYSTATE_CONTINUE_BLOCKED_V1985 source=preload reason=initial_sync_incomplete", xbmc.LOGINFO)
        return []
    """Return Continue Watching rows from service-startup preload + local sidecar only.

    This is intentionally network-free. It prevents WindowXML Home from waiting
    on Plex /library/onDeck after Home opens, while playback-stop dirty refreshes
    can bypass this cache and query Plex directly.
    """
    max_rows = int(limit or 24)
    items, age = _read_continue_preload_items(max_age=max_age)
    if not items:
        return []

    candidates = {}
    configured_v1458, selected_set_v1458 = _selected_section_filter_context_v1458()
    filter_stats_v1458 = {"skipped": 0}

    def _candidate_ts(item):
        return _safe_int(item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at"), 0)

    def _store_candidate(item, source):
        try:
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                return False
            if not _section_visible_by_selection_v1458(item.get("section_id", ""), configured_v1458, selected_set_v1458):
                filter_stats_v1458["skipped"] = int(filter_stats_v1458.get("skipped") or 0) + 1
                return False
            if not item.get("part_key") and item.get("plex_type") in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE):
                return False
            if item.get("plex_type") in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE) and not _pkm_is_valid_continue_progress(item):
                try:
                    off_ms, dur_ms, pct = _pkm_progress_pair(item.get("view_offset", 0), item.get("duration", 0), item.get("resume_duration_ms", 0))
                    log("PLAYSTATE_CONTINUE_CANDIDATE_SKIP rating_key=%s source=%s reason=invalid_or_complete_progress offset=%s duration=%s pct=%s title=%s" % (rk, source, off_ms, dur_ms, pct, item.get("title", "")), xbmc.LOGINFO)
                except Exception:
                    pass
                return False
            item["resume_source"] = source
            old = candidates.get(rk)
            if old is None or _candidate_ts(item) > _candidate_ts(old):
                candidates[rk] = item
            return True
        except Exception:
            return False

    preload_seen = 0
    for item in list(items or []):
        if _store_candidate(dict(item), str(item.get("resume_source") or "plex_ondeck_preload")):
            preload_seen += 1

    local_seen = 0
    try:
        states = _read_local_resume_states()
        keys = [str(st.get("rating_key") or rk or "").strip() for rk, st in states.items() if str(st.get("rating_key") or rk or "").strip()]
        keys = list(dict.fromkeys(keys))[:max(200, max_rows)]
        if keys:
            conn = init_db()
            try:
                placeholders = ",".join(["?"] * len(keys))
                sql = (
                    "SELECT rating_key, section_id, plex_type, '' AS kodi_type, "
                    "title, '' AS original_title, title AS sort_title, year, "
                    "summary, duration, added_at, updated_at, thumb, art, "
                    "media_file, part_key, view_count, last_viewed_at, "
                    "show_title, season, episode, parent_rating_key, grandparent_rating_key "
                    "FROM items WHERE rating_key IN (%s)" % placeholders
                )
                db_rows = {str(r[0]): r for r in conn.execute(sql, keys).fetchall()}
            finally:
                conn.close()
            for rk, st in states.items():
                rk = str(st.get("rating_key") or rk or "").strip()
                row = db_rows.get(rk)
                if not row:
                    continue
                item = {
                    "rating_key": row[0], "section_id": row[1], "plex_type": row[2], "kodi_type": row[3],
                    "title": row[4], "original_title": row[5], "sort_title": row[6], "year": row[7],
                    "summary": row[8], "duration": row[9], "added_at": row[10], "updated_at": row[11],
                    "thumb": row[12], "art": row[13], "media_file": row[14], "part_key": row[15],
                    "view_count": row[16], "last_viewed_at": row[17], "show_title": row[18],
                    "season": row[19], "episode": row[20], "parent_rating_key": row[21], "grandparent_rating_key": row[22],
                    "view_offset": _safe_int(st.get("time"), 0),
                    "resume_duration_ms": _safe_int(st.get("duration"), 0),
                    "resume_updated_at": _safe_int(st.get("updated_at"), 0),
                }
                if _store_candidate(item, "kodi_local_preload"):
                    local_seen += 1
    except Exception as exc:
        log("PLAYSTATE_CONTINUE_PRELOAD_LOCAL_MERGE_SKIP error=%s" % exc, xbmc.LOGDEBUG)

    ordered = sorted(candidates.values(), key=lambda item: _candidate_ts(item), reverse=True)
    rows = [_wall_light_row_from_item_dict(item) for item in ordered[:max_rows]]
    try:
        if configured_v1458:
            log("PLAYSTATE_CONTINUE_SELECTION_FILTER_V1458 source=preload selected=%s skipped=%s rows=%s" % (",".join(sorted(selected_set_v1458)), int(filter_stats_v1458.get("skipped") or 0), len(rows)), xbmc.LOGINFO)
    except Exception:
        pass
    log("PLAYSTATE_CONTINUE_PRELOAD_HIT rows=%s preload_seen=%s local_seen=%s age=%s limit=%s path=%s" % (len(rows), preload_seen, local_seen, age, max_rows, playstate_continue_preload_path()), xbmc.LOGINFO)
    return rows


def query_continue_watching_wall_light(limit=24, prefer_preload=False):
    """Fast Plex Home 'Continue Watching' source.

    Progress bars must represent the latest playback position, regardless of
    whether the most recent playback happened in Kodi or in another Plex client.
    Therefore Plex onDeck and Kodi's local sidecar are merged by timestamp, not
    by a fixed Plex-first or Kodi-first priority.
    """
    # v1985: selected ids are pending until the complete sync transaction commits.
    # Never query Plex onDeck or local resume sidecars while activation is incomplete.
    if not initial_sync_done():
        log("PLAYSTATE_CONTINUE_BLOCKED_V1985 source=live reason=initial_sync_incomplete", xbmc.LOGINFO)
        return []

    max_rows = int(limit or 24)
    if prefer_preload:
        rows = _query_continue_watching_wall_preloaded(limit=max_rows, max_age=180)
        if rows:
            return rows
        log("PLAYSTATE_CONTINUE_PRELOAD_MISS limit=%s path=%s" % (max_rows, playstate_continue_preload_path()), xbmc.LOGINFO)
    log("PLAYSTATE_CONTINUE_QUERY_BEGIN limit=%s local_path=%s" % (max_rows, playstate_resume_path()), xbmc.LOGINFO)

    candidates = {}
    configured_v1458, selected_set_v1458 = _selected_section_filter_context_v1458()
    filter_stats_v1458 = {"skipped": 0}
    local_seen = 0
    plex_seen = 0

    def _candidate_ts(item):
        try:
            return int(item.get("resume_updated_at") or item.get("last_viewed_at") or item.get("updated_at") or 0)
        except Exception:
            return 0

    def _store_candidate(item, source):
        try:
            rk = str(item.get("rating_key") or "").strip()
            if not rk:
                return False
            if not _section_visible_by_selection_v1458(item.get("section_id", ""), configured_v1458, selected_set_v1458):
                filter_stats_v1458["skipped"] = int(filter_stats_v1458.get("skipped") or 0) + 1
                return False
            if not item.get("part_key") and item.get("plex_type") in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE):
                return False
            if item.get("plex_type") in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE) and not _pkm_is_valid_continue_progress(item):
                try:
                    off_ms, dur_ms, pct = _pkm_progress_pair(item.get("view_offset", 0), item.get("duration", 0), item.get("resume_duration_ms", 0))
                    log("PLAYSTATE_CONTINUE_CANDIDATE_SKIP rating_key=%s source=%s reason=invalid_or_complete_progress offset=%s duration=%s pct=%s title=%s" % (rk, source, off_ms, dur_ms, pct, item.get("title", "")), xbmc.LOGINFO)
                except Exception:
                    pass
                return False
            item["resume_source"] = source
            new_ts = _candidate_ts(item)
            old = candidates.get(rk)
            if old is None:
                candidates[rk] = item
                log("PLAYSTATE_RESUME_SOURCE_SELECT rating_key=%s source=%s ts=%s offset=%s duration=%s title=%s" % (rk, source, new_ts, item.get("view_offset", 0), item.get("resume_duration_ms", 0) or item.get("duration", 0), item.get("title", "")), xbmc.LOGINFO)
                return True
            old_ts = _candidate_ts(old)
            if new_ts > old_ts:
                candidates[rk] = item
                log("PLAYSTATE_RESUME_SOURCE_REPLACE rating_key=%s old_source=%s old_ts=%s new_source=%s new_ts=%s offset=%s duration=%s title=%s" % (rk, old.get("resume_source", ""), old_ts, source, new_ts, item.get("view_offset", 0), item.get("resume_duration_ms", 0) or item.get("duration", 0), item.get("title", "")), xbmc.LOGINFO)
            else:
                log("PLAYSTATE_RESUME_SOURCE_KEEP rating_key=%s keep_source=%s keep_ts=%s skip_source=%s skip_ts=%s" % (rk, old.get("resume_source", ""), old_ts, source, new_ts), xbmc.LOGINFO)
            return True
        except Exception:
            return False

    # 1) Plex onDeck: current PMS resume state from every Plex client.
    try:
        root = plex_request_xml("/library/onDeck", params={"X-Plex-Container-Start": 0, "X-Plex-Container-Size": max_rows * 2}, timeout=8)
        for node in list(root):
            if node.tag not in ("Video", "Directory"):
                continue
            try:
                section_id = node.get("librarySectionID") or node.get("librarySectionKey") or ""
                section_type = node.get("librarySectionType") or node.get("type") or ""
                item = extract_item(node, section_id, section_type)
                # Plex timestamps are epoch seconds.  Use lastViewedAt as the
                # timestamp for Plex-side progress freshness.
                item["resume_updated_at"] = int(item.get("last_viewed_at") or item.get("updated_at") or 0)
                # Keep row duration in seconds for Kodi metadata display; progress
                # code will normalize it.
                item["resume_duration_ms"] = 0
                if _store_candidate(item, "plex_ondeck"):
                    plex_seen += 1
            except Exception:
                continue
    except Exception as exc:
        log("continue watching Plex onDeck skipped: %s" % exc, xbmc.LOGDEBUG)

    # 2) Kodi local sidecar: only wins if it is newer than Plex for the same key
    # or if Plex has not echoed the item yet.
    try:
        states = _read_local_resume_states()
        recent = sorted(states.values(), key=lambda x: int(x.get("updated_at") or 0), reverse=True)
        for st in recent:
            rk = str(st.get("rating_key") or "").strip()
            if not rk:
                continue
            try:
                root = plex_request_xml("/library/metadata/%s" % rk, timeout=5)
                for node in list(root):
                    if node.tag not in ("Video", "Directory"):
                        continue
                    section_id = node.get("librarySectionID") or node.get("librarySectionKey") or ""
                    section_type = node.get("librarySectionType") or node.get("type") or ""
                    item = extract_item(node, section_id, section_type)
                    item["view_offset"] = int(st.get("time") or 0)
                    item["resume_duration_ms"] = int(st.get("duration") or 0)
                    item["resume_updated_at"] = int(st.get("updated_at") or 0)
                    if _store_candidate(item, "kodi_local"):
                        local_seen += 1
                    break
            except Exception as exc:
                log("PLAYSTATE_LOCAL_RESUME_MERGE_SKIP rating_key=%s error=%s" % (rk, exc), xbmc.LOGDEBUG)
    except Exception:
        pass

    ordered = sorted(candidates.values(), key=lambda item: _candidate_ts(item), reverse=True)
    rows = []
    for item in ordered[:max_rows]:
        rows.append(_wall_light_row_from_item_dict(item))
        try:
            log("PLAYSTATE_RESUME_ROW rating_key=%s source=%s ts=%s offset=%s duration=%s title=%s" % (item.get("rating_key", ""), item.get("resume_source", ""), _candidate_ts(item), item.get("view_offset", 0), item.get("resume_duration_ms", 0) or item.get("duration", 0), item.get("title", "")), xbmc.LOGINFO)
        except Exception:
            pass

    try:
        if configured_v1458:
            log("PLAYSTATE_CONTINUE_SELECTION_FILTER_V1458 source=live selected=%s skipped=%s rows=%s" % (",".join(sorted(selected_set_v1458)), int(filter_stats_v1458.get("skipped") or 0), len(rows)), xbmc.LOGINFO)
    except Exception:
        pass
    log("PLAYSTATE_CONTINUE_QUERY_DONE rows=%s local_seen=%s plex_seen=%s local_path=%s" % (len(rows), local_seen, plex_seen, playstate_resume_path()), xbmc.LOGINFO)
    return rows



# ============================================================
# PKC-style large wall policy
# ============================================================
# The Plex metadata is synchronized into the local SQLite DB. For very large
# libraries the remaining bottleneck is Kodi creating/accepting thousands of
# plugin ListItems at once. PKC avoids this by using native Kodi DB nodes. This
# independent plugin keeps the XML/plugin approach, so it safely caps very large
# wall views by default while still allowing an explicit full-load URL.

def param_bool(params, key, default=False):
    value = str(params.get(key, "")).strip().lower()
    if value == "":
        return bool(default)
    return value in ("1", "true", "yes", "on", "y")


def param_int(params, key, default=0, min_value=None, max_value=None):
    try:
        value = int(params.get(key, default) or default)
    except Exception:
        value = int(default)
    if min_value is not None:
        value = max(min_value, value)
    if max_value is not None:
        value = min(max_value, value)
    return value




def large_wall_focus_preload_enabled():
    return setting_bool("large_wall_focus_preload", True)



def large_wall_show_full_after_prepare():
    return setting_bool("large_wall_show_full_after_prepare", True)


def _load_large_wall_focus_state():
    path = large_wall_focus_state_path()
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
    except Exception as e:
        log("large wall focus state load failed: %s" % e, xbmc.LOGWARNING)
    return {}


def _save_large_wall_focus_state(state):
    path = large_wall_focus_state_path()
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state or {}, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception as e:
        log("large wall focus state save failed: %s" % e, xbmc.LOGWARNING)


def _large_wall_state_key(section_id, sort="added", plex_type=None):
    return "%s|%s|%s" % (str(section_id or ""), str(sort or "added"), str(plex_type or ""))


def _section_db_stamp(section_id):
    conn = init_db()
    try:
        row = conn.execute(
            "SELECT scanned_at, item_count FROM sections WHERE section_id=?",
            (str(section_id),)
        ).fetchone()
        if row:
            return int(row[0] or 0), int(row[1] or 0)
    except Exception:
        pass
    finally:
        conn.close()
    return 0, count_items(section_id)


def is_large_wall_prepared(section_id, sort="added", plex_type=None, total_count=None, log_reason=False, caller=""):
    key = _large_wall_state_key(section_id, sort, plex_type)
    prefix = "FOCUS_PREPARED_CHECK caller=%s section=%s sort=%s type=%s key=%s" % (
        caller or "unknown", section_id, sort, plex_type or "", key
    )
    if not large_wall_show_full_after_prepare():
        if log_reason:
            perf_log("%s result=false reason=setting_disabled" % prefix)
        return False
    entry = _load_large_wall_focus_state().get(key)
    if not isinstance(entry, dict):
        if log_reason:
            perf_log("%s result=false reason=no_state_entry" % prefix)
        return False
    scanned_at, item_count = _section_db_stamp(section_id)
    entry_scanned_at = int(entry.get("scanned_at") or 0)
    entry_total_count = int(entry.get("total_count") or 0)
    entry_item_count = int(entry.get("item_count") or 0)
    # scanned_at changes on every Plex auto-sync, even when the section item count
    # and the cached local DB rows are unchanged. Do not invalidate the prepared
    # full-wall state just because scanned_at changed; use count changes as the
    # real invalidation criteria. Keep the scanned_at delta visible in logs.
    scanned_at_changed = entry_scanned_at != int(scanned_at or 0)
    if total_count is not None and entry_total_count != int(total_count or 0):
        if log_reason:
            perf_log("%s result=false reason=total_count_changed entry=%d current=%d" % (
                prefix, entry_total_count, int(total_count or 0)
            ))
        return False
    if entry_item_count != int(item_count or 0):
        if log_reason:
            perf_log("%s result=false reason=item_count_changed entry=%d current=%d" % (
                prefix, entry_item_count, int(item_count or 0)
            ))
        return False
    prepared = bool(entry.get("prepared"))
    if log_reason:
        perf_log("%s result=%s reason=valid prepared_at=%s row_count=%s total_count=%s item_count=%s scanned_at=%s current_scanned_at=%s scanned_at_changed=%s" % (
            prefix, str(prepared).lower(), entry.get("prepared_at", ""),
            entry.get("row_count", ""), entry_total_count, entry_item_count,
            entry_scanned_at, int(scanned_at or 0), str(scanned_at_changed).lower()
        ))
    return prepared

def mark_large_wall_prepared(section_id, section_title, sort="added", plex_type=None, total_count=0, row_count=0):
    scanned_at, item_count = _section_db_stamp(section_id)
    state = _load_large_wall_focus_state()
    state[_large_wall_state_key(section_id, sort, plex_type)] = {
        "prepared": True,
        "section_id": str(section_id or ""),
        "section_title": section_title or "",
        "sort": sort or "added",
        "plex_type": plex_type or "",
        "total_count": int(total_count or 0),
        "row_count": int(row_count or 0),
        "item_count": int(item_count or 0),
        "scanned_at": int(scanned_at or 0),
        "prepared_at": int(time.time()),
    }
    _save_large_wall_focus_state(state)
    perf_log("FOCUS_PREPARED_MARK section=%s title=%s sort=%s type=%s total=%d row_count=%d item_count=%d scanned_at=%d state_file=%s" % (
        section_id, section_title, sort or "added", plex_type or "", int(total_count or 0),
        int(row_count or 0), int(item_count or 0), int(scanned_at or 0), large_wall_focus_state_path()
    ))


def mark_large_wall_prepared_after_sync(section, sort="added", plex_type=None):
    """Refresh the large-wall prepared state after PMS sync finishes.

    Auto-sync updates sections.scanned_at. Without this, a valid prepared full
    wall could fall back to the 30-item preview until another focus-prepare runs.
    The local DB already contains all rows, so mark it prepared immediately.
    """
    try:
        section_id = str(section.get("section_id", ""))
        title = display_library_title(section.get("title", "") or section_id)
        if not section_id:
            return False
        total_count = count_items(section_id, plex_type=plex_type)
        if total_count <= large_wall_threshold():
            return False
        mark_large_wall_prepared(
            section_id,
            title,
            sort=sort or "added",
            plex_type=plex_type,
            total_count=total_count,
            row_count=total_count,
        )
        perf_log("FOCUS_PREPARED_AFTER_SYNC section=%s title=%s sort=%s total=%d" % (
            section_id, title, sort or "added", total_count
        ))
        return True
    except Exception:
        log("mark prepared after sync failed section=%s\n%s" % (
            section.get("section_id", ""), traceback.format_exc()
        ), xbmc.LOGWARNING)
        return False


def _current_home_focused_section_id():
    # v2053: custom control 9000 is owned by PlexKMHomeWindow only.
    # External scripts read the state published by that window instead of
    # probing Control/Container before the XML exists.
    try:
        return xbmcgui.Window(10000).getProperty("PlexKM.Home.FocusedSectionId") or ""
    except Exception:
        return ""


def prepare_large_wall_for_focus(params):
    if not large_wall_focus_preload_enabled():
        log("large wall focus preload disabled", xbmc.LOGINFO)
        return False
    section_id = str(params.get("section_id") or "")
    sort = params.get("sort", "added") or "added"
    plex_type = params.get("type") or None
    expected = str(params.get("expected_section_id") or section_id)
    perf_log("FOCUS_PREPARE_START section=%s expected=%s sort=%s type=%s background=%s params=%s" % (
        section_id, expected, sort, plex_type or "", params.get("background", ""), params
    ))

    # The service calls this immediately when a Plex library item receives sidebar focus.
    # Verify focus again so quick pass-through focus does not trigger a full prepare.
    current = _current_home_focused_section_id()
    perf_log("FOCUS_PREPARE_FOCUS_CHECK section=%s expected=%s current=%s active_home=%s focus9000=%s" % (
        section_id, expected, current,
        xbmc.getCondVisibility("Window.IsActive(home)"),
        bool(current)
    ))
    if expected and current and str(current) != str(expected):
        log("large wall focus prepare skipped; focus changed expected=%s current=%s" % (expected, current), xbmc.LOGINFO)
        return False

    if not section_id:
        log("large wall focus prepare skipped; missing section_id", xbmc.LOGWARNING)
        return False

    if is_sync_locked():
        # Auto-sync will mark large sections as prepared as each section finishes.
        # Avoid a second full SQLite prepare competing with the sync transaction.
        log("large wall focus prepare deferred; sync running section=%s" % section_id, xbmc.LOGINFO)
        return False

    lock = large_wall_prepare_lock_path(section_id)
    now = int(time.time())
    try:
        if os.path.exists(lock):
            ts = _read_lock_timestamp(lock)
            if ts and now - ts < 900:
                log("large wall focus prepare skipped; lock exists section=%s" % section_id, xbmc.LOGINFO)
                return False
            try:
                os.remove(lock)
            except Exception:
                return False
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, ("%d|%s|large-wall-prepare" % (now, os.getpid())).encode("utf-8"))
        finally:
            os.close(fd)
    except Exception as e:
        log("large wall focus prepare lock failed section=%s error=%s" % (section_id, e), xbmc.LOGWARNING)
        return False

    t0 = time.time()
    try:
        section = find_section(section_id=section_id, refresh=False)
        if not section:
            log("large wall focus prepare skipped; section missing section=%s" % section_id, xbmc.LOGWARNING)
            return False
        total_count = count_items(section_id, plex_type=plex_type)
        if total_count <= large_wall_threshold():
            log("large wall focus prepare skipped; small section=%s total=%d" % (section_id, total_count), xbmc.LOGINFO)
            return False
        if is_large_wall_prepared(section_id, sort=sort, plex_type=plex_type, total_count=total_count, log_reason=True, caller="prepare_focus_wall"):
            perf_log("FOCUS_PREPARE_SKIP_ALREADY_PREPARED section=%s title=%s sort=%s total=%d" % (
                section_id, section.get("title", ""), sort, total_count
            ))
            return True

        # Invisible background prepare: read the full sorted row set from local SQLite.
        # PMS is not queried here. This warms SQLite/OS caches and records that this
        # section is allowed to open uncapped on later list calls.
        perf_log("FOCUS_PREPARE_QUERY_START section=%s title=%s sort=%s total=%d source=local_sqlite limit=0" % (
            section_id, section.get("title", ""), sort, total_count
        ))
        q0 = time.time()
        rows = query_items(section_id, sort=sort, limit=0, offset=0, plex_type=plex_type)
        perf_log("FOCUS_PREPARE_QUERY_DONE section=%s title=%s rows=%d elapsed=%.3fms" % (
            section_id, section.get("title", ""), len(rows), (time.time() - q0) * 1000.0
        ))
        mark_large_wall_prepared(
            section_id,
            section.get("title", ""),
            sort=sort,
            plex_type=plex_type,
            total_count=total_count,
            row_count=len(rows),
        )
        elapsed = (time.time() - t0) * 1000.0
        perf_log("FOCUS_PREPARED section=%s title=%s sort=%s rows=%d total=%d elapsed=%.3fms" % (
            section_id, section.get("title", ""), sort, len(rows), total_count, elapsed
        ))
        return True
    except Exception:
        log("large wall focus prepare failed section=%s\n%s" % (section_id, traceback.format_exc()), xbmc.LOGERROR)
        return False
    finally:
        try:
            if os.path.exists(lock):
                os.remove(lock)
        except Exception:
            pass

def large_wall_auto_limit_enabled():
    return setting_bool("large_wall_auto_limit", True)


def large_wall_threshold():
    return setting_int("large_wall_threshold", 1000, min_value=100, max_value=100000)


def large_wall_initial_limit():
    return setting_int("large_wall_initial_limit", 1000, min_value=100, max_value=10000)


def large_wall_preview_limit():
    # First paint count for a large library wall.
    # This keeps the right-side wall from appearing empty while the full list is prepared in the background.
    return setting_int("large_wall_preview_limit", 30, min_value=1, max_value=500)


def large_wall_show_more_item():
    # Focus-load mode: never add a visible "next page" folder item.
    return False


def is_uncapped_request(params):
    return (
        param_bool(params, "full", False)
        or param_bool(params, "all", False)
        or param_bool(params, "uncapped", False)
        or param_bool(params, "force_full", False)
    )


def set_wall_window_properties(section, total_count, loaded_count, capped, effective_limit, offset):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.LastSectionId", str(section.get("section_id", "")))
        win.setProperty("PlexKM.LastSectionTitle", display_library_title(section.get("title", "")))
        win.setProperty("PlexKM.LastTotalCount", str(int(total_count or 0)))
        win.setProperty("PlexKM.LastLoadedCount", str(int(loaded_count or 0)))
        win.setProperty("PlexKM.LastLimit", str(int(effective_limit or 0)))
        win.setProperty("PlexKM.LastOffset", str(int(offset or 0)))
        win.setProperty("PlexKM.LastCapped", "true" if capped else "false")
    except Exception:
        pass


def wall_request_id(section_id):
    try:
        return "%s-%d-%s" % (str(section_id or ""), int(time.time() * 1000), os.getpid())
    except Exception:
        return "%s-%d" % (str(section_id or ""), int(time.time() * 1000))


def set_wall_stage_properties(request_id, section, stage, rows=0, total=0, elapsed_ms=0.0, note=""):
    section_id = str(section.get("section_id", "") if isinstance(section, dict) else "")
    title = display_library_title(section.get("title", "") if isinstance(section, dict) else "")
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Wall.RequestId", str(request_id or ""))
        win.setProperty("PlexKM.Wall.SectionId", section_id)
        win.setProperty("PlexKM.Wall.SectionTitle", display_library_title(title))
        win.setProperty("PlexKM.Wall.Stage", str(stage or ""))
        win.setProperty("PlexKM.Wall.Rows", str(int(rows or 0)))
        win.setProperty("PlexKM.Wall.Total", str(int(total or 0)))
        win.setProperty("PlexKM.Wall.ElapsedMs", "%.3f" % float(elapsed_ms or 0.0))
        win.setProperty("PlexKM.Wall.Note", str(note or ""))
    except Exception:
        pass
    perf_log("WALL_STAGE request=%s stage=%s section=%s title=%s rows=%s total=%s elapsed=%.3fms note=%s" % (
        request_id, stage, section_id, title, int(rows or 0), int(total or 0), float(elapsed_ms or 0.0), note
    ))


def make_more_item(params, section, sort, effective_limit, offset, total_count, plex_type):
    next_offset = int(offset or 0) + int(effective_limit or 0)
    if next_offset >= int(total_count or 0):
        return None
    q = dict(params)
    q["action"] = "library"
    q["section_id"] = str(section.get("section_id", ""))
    q.pop("section_title", None)
    q["sort"] = sort
    q["limit"] = str(effective_limit)
    q["offset"] = str(next_offset)
    q["profile"] = params.get("profile", "plex_side_wall_page")
    if plex_type:
        q["type"] = plex_type
    url = build_plugin_url(q)
    label = "[B]다음 항목 더 보기[/B]  %d - %d / %d" % (
        next_offset + 1,
        min(next_offset + int(effective_limit or 0), int(total_count or 0)),
        int(total_count or 0),
    )
    li = xbmcgui.ListItem(label=label, path=url)
    li.setArt({"thumb": "DefaultFolder.png", "poster": "DefaultFolder.png", "icon": "DefaultFolder.png"})
    li.setProperty("IsPlayable", "false")
    li.setProperty("PlexKM.MoreItem", "true")
    return (url, li, True)


def query_episodes_for_show(section_id, show_rating_key):
    sql = """
        SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title,
               year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key,
               view_count, last_viewed_at, show_title, season, episode,
               parent_rating_key, grandparent_rating_key, view_offset,
               resume_duration_ms, resume_updated_at, resume_source,
               raw_json
        FROM items
        WHERE section_id=? AND plex_type=? AND grandparent_rating_key=?
        ORDER BY season ASC, episode ASC, sort_title COLLATE NOCASE ASC
    """
    conn = init_db()
    rows = conn.execute(sql, (str(section_id), PLEX_TYPE_EPISODE, str(show_rating_key))).fetchall()
    conn.close()
    return rows


def row_from_item_dict(item):
    return (
        item.get("rating_key"), item.get("section_id"), item.get("plex_type"), item.get("kodi_type"),
        item.get("title"), item.get("original_title"), item.get("sort_title"), item.get("year"),
        item.get("summary"), item.get("duration"), item.get("added_at"), item.get("updated_at"),
        item.get("thumb"), item.get("art"), item.get("media_file"), item.get("part_key"),
        item.get("view_count"), item.get("last_viewed_at"), item.get("show_title"),
        item.get("season"), item.get("episode"),
        item.get("parent_rating_key", ""), item.get("grandparent_rating_key", ""),
        item.get("view_offset", 0), item.get("resume_duration_ms", 0),
        item.get("resume_updated_at", 0), item.get("resume_source", ""),
        item.get("raw_json", "")
    )


def fetch_show_episodes(show_rating_key, section_id, upsert=True, timeout=30):
    """Fetch all episodes under a Plex show.

    Plex TV libraries expose show items in /library/sections/{id}/all.
    Opening a show requires a second request. /library/metadata/{show}/allLeaves
    returns episode Video nodes directly, which is ideal for this plugin.
    """
    root = plex_request_xml("/library/metadata/%s/allLeaves" % show_rating_key, params={"skipRefresh": 1}, timeout=float(timeout or 30))
    items = []
    conn = init_db() if upsert else None
    try:
        for child in list(root):
            if child.tag != "Video":
                continue
            item = extract_item(child, section_id, PLEX_TYPE_EPISODE)
            # Some Plex responses omit grandparentRatingKey on allLeaves; keep the clicked show as owner.
            if not item.get("grandparent_rating_key"):
                item["grandparent_rating_key"] = str(show_rating_key)
            if item.get("rating_key"):
                items.append(item)
                if conn:
                    upsert_item(conn, item)
        if conn:
            conn.commit()
    finally:
        if conn:
            conn.close()
    return items


def list_show(params):
    rating_key = params.get("rating_key") or ""
    section_id = params.get("section_id") or ""
    if not rating_key or not section_id:
        raise RuntimeError("show rating_key and section_id are required")

    rows = query_episodes_for_show(section_id, rating_key)
    if not rows:
        log("show rating_key=%s section=%s episode cache empty; fetching allLeaves" % (rating_key, section_id))
        items = fetch_show_episodes(rating_key, section_id, upsert=True)
        rows = [row_from_item_dict(x) for x in items]
    log("show rating_key=%s section=%s episodes=%d" % (rating_key, section_id, len(rows)))

    xbmcplugin.setContent(HANDLE, "episodes")
    for _sort_name in ("SORT_METHOD_EPISODE", "SORT_METHOD_LABEL_IGNORE_THE", "SORT_METHOD_TITLE", "SORT_METHOD_DATEADDED"):
        _sort_method = getattr(xbmcplugin, _sort_name, None)
        if _sort_method is not None:
            xbmcplugin.addSortMethod(HANDLE, _sort_method)

    t_build = time.time()
    directory_items = []
    wall_light = (profile_tag == "plex_side_wall" and requested_limit == 0)
    if wall_light:
        perf_log("WALL_LIGHT_MODE section=%s title=%s rows=%d: strict title/year ListItems for cached Home wall" % (section_id, section.get("title", ""), len(rows)))
    for row in rows:
        li, is_playable = make_listitem_from_row(row, wall_light=wall_light)
        directory_items.append((li.getPath(), li, not is_playable))
    build_ms = (time.time() - t_build) * 1000.0

    t_add = time.time()
    xbmcplugin.addDirectoryItems(HANDLE, directory_items, len(directory_items))
    add_ms = (time.time() - t_add) * 1000.0

    t_end = time.time()
    # Focus-driven Home wall paths must be re-evaluated after background prepare.
    # If Kodi caches the 30-item preview directory to disk, moving away/back can keep
    # showing 30 forever. Keep regular plugin browsing cacheable, but disable disk
    # cache for Home focus walls.
    cache_to_disc = not (params.get("focus_load") == "1" or str(profile_tag).startswith("plex_side_wall"))
    perf_log("WALL_END_DIRECTORY section=%s profile=%s focus_load=%s cacheToDisc=%s rows=%d dir_items=%d" % (
        section_id, profile_tag, params.get("focus_load", ""), str(cache_to_disc).lower(), len(rows), len(directory_items)
    ))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache_to_disc)
    end_ms = (time.time() - t_end) * 1000.0
    perf_log("SHOW rating_key=%s section=%s rows=%d build=%.3fms add=%.3fms end=%.3fms total=%.3fms" % (
        rating_key, section_id, len(rows), build_ms, add_ms, end_ms, build_ms + add_ms + end_ms
    ))

def timestamp_to_kodi_date(ts):
    try:
        ts = int(ts)
        if ts <= 0:
            return ""
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
    except Exception:
        return ""



# -----------------------------------------------------------------------------
# PKM common progress helpers
# -----------------------------------------------------------------------------
_PROGRESS_STATE_CACHE = {}
_PROGRESS_STATE_MISS = set()


def _pkm_common_progress_state_for_show(show_key):
    """Return (total, watched) for one TV show without blocking Home startup.

    v710 prefetched all show progress rows at the first Home item.  The log showed
    3148 show rows and 3857ms before the first poster could be built.  This is
    not acceptable for initial Home display.  Use targeted, cached lookup only
    for the show currently being rendered; the DB index keeps the query bounded.
    """
    show_key = str(show_key or "").strip()
    if not show_key:
        return (0, 0)
    if show_key in _PROGRESS_STATE_CACHE:
        return _PROGRESS_STATE_CACHE.get(show_key) or (0, 0)
    if show_key in _PROGRESS_STATE_MISS:
        return (0, 0)
    t0 = time.time()
    try:
        conn = init_db()
        row = conn.execute("""
            SELECT COUNT(*),
                   SUM(CASE WHEN COALESCE(view_count,0) > 0 THEN 1 ELSE 0 END)
            FROM items
            WHERE plex_type=? AND grandparent_rating_key=?
        """, (PLEX_TYPE_EPISODE, show_key)).fetchone()
        total = int((row[0] if row else 0) or 0)
        watched = int((row[1] if row else 0) or 0)
        if total <= 0:
            _PROGRESS_STATE_MISS.add(show_key)
            return (0, 0)
        _PROGRESS_STATE_CACHE[show_key] = (total, watched)
        try:
            ms = int((time.time() - t0) * 1000.0)
            if ms >= 50:
                log("PKM_COMMON_PROGRESS_TARGET_DONE show=%s total=%s watched=%s ms=%d" % (show_key, total, watched, ms))
        except Exception:
            pass
        return (total, watched)
    except Exception as exc:
        _PROGRESS_STATE_MISS.add(show_key)
        try:
            log("PKM_COMMON_PROGRESS_TARGET_FAILED show=%s error=%s" % (show_key, exc), xbmc.LOGWARNING)
        except Exception:
            pass
        return (0, 0)


def _pkm_to_ms(value):
    """Best-effort standalone ms conversion.

    Keep this conservative.  Context-aware progress conversion is handled by
    _pkm_progress_pair(), because Plex/Kodi sources may mix viewOffset in ms
    with duration in ms/seconds.
    """
    try:
        value = int(float(value or 0))
    except Exception:
        value = 0
    if value <= 0:
        return 0
    return value if value > 86400 else value * 1000


def _pkm_duration_to_ms(duration=0, resume_duration_ms=0):
    try:
        rd = int(float(resume_duration_ms or 0))
    except Exception:
        rd = 0
    try:
        d = int(float(duration or 0))
    except Exception:
        d = 0
    if rd > 0:
        return rd if rd > 86400 else rd * 1000
    if d > 0:
        return d if d > 86400 else d * 1000
    return 0


def _pkm_offset_to_ms(view_offset=0, dur_ms=0):
    """Normalize resume offset with duration context.

    v1207 used a standalone <=86400 seconds heuristic.  Plex viewOffset can be
    70969 (milliseconds) while duration is 6558000 (milliseconds).  Multiplying
    that offset by 1000 makes it larger than duration and removes the item from
    Continue Watching.  Use duration context to distinguish ms/seconds and repair
    the one-run x1000 pollution already written to local/preload files.
    """
    try:
        raw = int(float(view_offset or 0))
    except Exception:
        raw = 0
    try:
        dur = int(float(dur_ms or 0))
    except Exception:
        dur = 0
    if raw <= 0:
        return 0
    if dur > 86400:
        # Repair values produced by the v1207 heuristic, e.g.
        # 70969000 vs 6558000 should become 70969.
        if raw > int(float(dur) * 3.0) and int(raw / 1000) > 0 and int(raw / 1000) <= dur:
            return int(raw / 1000)
        # If the raw value already fits inside an ms duration, it is ms.
        if raw <= dur:
            return raw
        # Small offset with ms duration can still be seconds, e.g. 120 sec.
        if raw <= 86400 and raw * 1000 <= dur:
            return raw * 1000
        return raw
    # Duration itself looks like seconds.
    if raw <= dur:
        return raw * 1000
    if raw > 86400:
        return raw
    return raw * 1000


def _pkm_progress_pair(view_offset=0, duration=0, resume_duration_ms=0):
    """Normalize PKM progress values to a safe percent.

    All PKM progress users must call this one pair function so Home/Wall/Search/
    Info agree on the same resume/progress state.
    Returns (off_ms, dur_ms, pct). pct is 0 when the pair is invalid.
    """
    try:
        dur_ms = _pkm_duration_to_ms(duration, resume_duration_ms)
        off_ms = _pkm_offset_to_ms(view_offset, dur_ms)
        if dur_ms <= 0 or off_ms <= 0:
            return 0, dur_ms, 0
        if off_ms >= int(float(dur_ms) * 1.05):
            return off_ms, dur_ms, 0
        pct = int(max(0, min(100, round((float(off_ms) * 100.0) / float(dur_ms)))))
        return off_ms, dur_ms, pct
    except Exception:
        return 0, 0, 0


def _pkm_is_valid_continue_progress(item):
    try:
        off_ms, dur_ms, pct = _pkm_progress_pair(
            item.get("view_offset", 0),
            item.get("duration", 0),
            item.get("resume_duration_ms", 0),
        )
        # v1506: align Continue/Info with the local resume sidecar policy.
        # Do not show 이어서 재생 for tiny offsets that will effectively start
        # from the beginning, and do not show it for completed items.
        if off_ms < 60000 or dur_ms <= 0 or pct <= 0:
            return False
        if pct >= 90:
            return False
        return True
    except Exception:
        return False


def _pkm_resume_progress_props_v2330(percent):
    """Return resume-progress state without any runtime fill implementation.

    v2330: every visible resume bar is one precomposed rounded PNG containing
    both the neutral track and yellow progress. Kodi only scales one image;
    there is no separate fill layer and no pixel-width progress property.
    """
    try:
        percent = int(max(0, min(100, round(float(percent or 0)))))
    except Exception:
        percent = 0
    step2 = int(max(0, min(100, ((percent + 1) // 2) * 2)))
    if percent > 0 and step2 <= 0:
        step2 = 2
    tex350 = (
        "special://home/addons/plugin.video.km/resources/skins/Default/media/progress/resume_composite_350x10_step2/progress_%03d.png" % step2
        if step2 > 0 else ""
    )
    tex370 = (
        "special://home/addons/plugin.video.km/resources/skins/Default/media/progress/resume_composite_370x10_step2/progress_%03d.png" % step2
        if step2 > 0 else ""
    )
    return {
        "ResumePercent": str(percent if percent > 0 else ""),
        "ResumeProgressComposite350x10": tex350,
        "ResumeProgressComposite370x10": tex370,
    }

def pkm_common_progress_props(rating_key="", plex_type="", grandparent_rating_key="", view_count=0, view_offset=0, duration=0, resume_duration_ms=0):
    """Return PKM common progress properties.

    TV posters on Home/Wall/Search represent the show-level state.  A single
    watched episode must contribute to the series progress bar, but it must not
    make the whole show poster display the completed check mark.  The completed
    check is shown for TV only when every known episode in the show is watched.
    """
    plex_type = str(plex_type or "").strip()
    rating_key = str(rating_key or "").strip()
    grandparent_rating_key = str(grandparent_rating_key or "").strip()
    pct = 0
    off_ms, dur_ms, media_pct = _pkm_progress_pair(view_offset, duration, resume_duration_ms)
    is_watched = "1" if int(view_count or 0) > 0 else ""
    if plex_type in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE) and 0 < media_pct < 90:
        is_watched = ""
    try:
        show_key = ""
        if plex_type == PLEX_TYPE_SHOW:
            show_key = rating_key
        elif plex_type == PLEX_TYPE_EPISODE:
            show_key = grandparent_rating_key
        if show_key:
            total, watched = _pkm_common_progress_state_for_show(show_key)
            if total > 0:
                watched_units = float(watched)
                if plex_type == PLEX_TYPE_EPISODE and not int(view_count or 0):
                    off_ms, dur_ms, _episode_pct = _pkm_progress_pair(view_offset, duration, resume_duration_ms)
                    if dur_ms > 0 and off_ms > 0:
                        watched_units += max(0.0, min(1.0, float(off_ms) / float(dur_ms)))
                pct = int(max(0, min(100, round((watched_units * 100.0) / float(total)))))
                # TV show/episode cards use show-level semantics: only the full
                # show completion displays the check badge.  Partial episode
                # completion remains a progress bar only.
                is_watched = "1" if watched >= total else ""
                props = _pkm_resume_progress_props_v2330(pct)
                props["IsWatched"] = is_watched
                return props
    except Exception as exc:
        try:
            log("PKM_COMMON_PROGRESS_FAILED rating_key=%s type=%s error=%s" % (rating_key, plex_type, exc), xbmc.LOGWARNING)
        except Exception:
            pass
    try:
        pct = media_pct
    except Exception:
        pct = 0
    props = _pkm_resume_progress_props_v2330(pct)
    props["IsWatched"] = is_watched
    return props

def make_listitem_from_row(row, wall_light=False):
    # v1907: wall-light rows may append resume/sort display fields after the
    # stable 21 DB columns. Legacy directory rendering consumes only the stable
    # prefix and must not fail on those optional trailing values.
    row = tuple(row or ())
    (rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year,
     summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count,
     last_viewed_at, show_title, season, episode) = row[:21]

    is_playable = plex_type in (PLEX_TYPE_MOVIE, PLEX_TYPE_EPISODE) and bool(part_key)
    if is_playable:
        url = build_plugin_url({"action": "play", "rating_key": rating_key, "part_key": part_key})
    elif plex_type == PLEX_TYPE_SHOW:
        url = build_plugin_url({"action": "show", "rating_key": rating_key, "section_id": section_id})
    else:
        url = build_plugin_url({"action": "noop"})

    li = xbmcgui.ListItem(label=title, path=url)

    if wall_light:
        # Strict wall mode: title + year metadata only. Artwork/play path is kept
        # because the poster wall and playback need it, but no heavy video info,
        # plot, genre, director, cast, duration, fanart, or context menu is set.
        li.setArt({
            "thumb": thumb or "",
            "poster": thumb or "",
            "icon": thumb or "",
        })
        li.setProperty("PlexKM.Title", title or "")
        li.setProperty("PlexKM.Year", str(year or ""))
        li.setProperty("PlexKM.RatingKey", str(rating_key))
        try:
            for _k, _v in pkm_common_progress_props(rating_key, plex_type, "", view_count, 0, duration, 0).items():
                li.setProperty("PlexKM.%s" % _k, str(_v or ""))
        except Exception:
            pass
        if is_playable:
            li.setProperty("IsPlayable", "true")
        return li, is_playable

    info = {
        "title": title,
        "sorttitle": sort_title or title,
        "originaltitle": original_title or "",
        "year": int(year or 0),
        "plot": summary or "",
        "duration": int(duration or 0),
        "dateadded": timestamp_to_kodi_date(added_at),
        "mediatype": kodi_type or "video",
    }
    if plex_type == PLEX_TYPE_EPISODE:
        info.update({"tvshowtitle": show_title or "", "season": int(season or 0), "episode": int(episode or 0)})
    apply_video_info(li, info)
    li.setArt({
        "thumb": thumb or "",
        "poster": thumb or "",
        "icon": thumb or "",
        "fanart": art or "",
    })
    li.setProperty("PlexKM.RatingKey", str(rating_key))
    li.setProperty("PlexKM.SectionId", str(section_id))
    li.setProperty("PlexKM.Type", plex_type or "")
    li.setProperty("PlexKM.File", media_file or "")
    li.setProperty("PlexKM.Thumb", thumb or "")
    li.setProperty("PlexKM.Art", art or "")
    li.setProperty("PlexKM.Year", str(year or ""))
    li.setProperty("PlexKM.Title", title or "")
    try:
        for _k, _v in pkm_common_progress_props(rating_key, plex_type, "", view_count, 0, duration, 0).items():
            li.setProperty("PlexKM.%s" % _k, str(_v or ""))
    except Exception:
        pass
    if is_playable:
        li.setProperty("IsPlayable", "true")
    context = [
        ("Sync this Plex section", "RunPlugin(%s)" % build_plugin_url({"action": "sync", "section_id": section_id})),
        ("Open Plex KM settings", "RunPlugin(%s)" % build_plugin_url({"action": "pkm_settings"})),
    ]
    li.addContextMenuItems(context)
    return li, is_playable



def list_sections_menu(params):
    """Return Plex libraries as skin sidebar items. Dynamic: no hard-coded library names."""
    ok_config = bool(clean_server_url() and plex_token())
    if not ok_config:
        li = xbmcgui.ListItem(label="Plex 서버 설정 필요")
        li.setProperty("defaultID", "plexkm_settings")
        li.setArt({"icon": "DefaultAddonProgram.png", "thumb": "DefaultAddonProgram.png"})
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "settings"}), li, True)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return

    ensure_initial_sync(interactive=False)
    # Always serve from local DB; never block the sidebar on a PMS HTTP request.
    # Section list changes only after sync, which runs in background.
    try:
        sections = fetch_sections(refresh=False)
        if not sections:
            # First run or empty DB: try live fetch once.
            sections = fetch_sections(refresh=True)
    except Exception:
        log("sections_menu fetch failed:\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        sections = []

    sections = apply_section_order(sections, save_merged=True)
    sort = params.get("sort", "added") or "added"
    limit = params.get("limit", "") or ""
    offset = params.get("offset", "0") or "0"

    # Fixed Home entry for the skin sidebar.
    # Keep Plex library SectionIndex starting from 0; Home is not part of the Plex section index.
    home_li = xbmcgui.ListItem(label="홈")
    home_li.setProperty("defaultID", "home_home")
    home_li.setProperty("PlexKM.SectionIndex", "")
    home_li.setProperty("PlexKM.SectionId", "")
    home_li.setProperty("PlexKM.SectionTitle", "홈")
    home_li.setProperty("PlexKM.SectionType", "home")
    home_li.setProperty("PlexKM.TargetPath", build_plugin_url({"action": "noop"}))
    home_li.setArt({"thumb": "DefaultFolder.png", "icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "noop"}), home_li, True)

    for idx, section in enumerate(sections):
        section_id = str(section.get("section_id", ""))
        title = display_library_title(section.get("title", "") or section_id)
        section_type = section.get("section_type", "")
        try:
            total_count = int(section.get("item_count") or 0)
        except Exception:
            total_count = 0
        if total_count <= 0:
            total_count = count_items(section_id)

        # Large library is determined dynamically from the current Plex item count.
        # Do not hard-code library names or fixed section indexes in the skin.
        large_prepared = True
        is_large = total_count > large_wall_threshold()

        # Stable index-based target. Home wall reads full content from local cache only.
        target = build_plugin_url({
            "action": "library_index",
            "index": str(idx),
            "sort": sort,
            "profile": "plex_side_wall",
        })

        li = xbmcgui.ListItem(label=display_library_title(title))
        li.setProperty("defaultID", "plexkm_section")
        li.setProperty("PlexKM.SectionIndex", str(idx))
        li.setProperty("PlexKM.SectionId", section_id)
        li.setProperty("PlexKM.SectionTitle", display_library_title(title))
        li.setProperty("PlexKM.SectionType", section_type)
        li.setProperty("PlexKM.ItemCount", str(total_count))
        li.setProperty("PlexKM.SectionItemCount", str(total_count))
        li.setProperty("PlexKM.IsLarge", "true" if is_large else "false")
        li.setProperty("PlexKM.LargePrepared", "true" if large_prepared else "false")
        li.setProperty("PlexKM.TargetPath", target)
        if is_large:
            perf_log("SECTIONS_MENU_LARGE section=%s index=%s title=%s total=%d is_large=true prepared=%s target=%s" % (
                section_id, idx, title, total_count, str(large_prepared).lower(), target
            ))
        li.setArt({"thumb": section.get("thumb", "") or "DefaultVideo.png", "icon": section.get("thumb", "") or "DefaultVideo.png", "fanart": section.get("art", "")})
        context = [
            ("위로 이동", "RunPlugin(%s)" % build_plugin_url({"action": "move_section", "section_id": section_id, "direction": "up"})),
            ("아래로 이동", "RunPlugin(%s)" % build_plugin_url({"action": "move_section", "section_id": section_id, "direction": "down"})),
            ("라이브러리 싱크", "RunPlugin(%s)" % build_plugin_url({"action": "sync", "section_id": section_id})),
            ("Plex KM 설정", "RunPlugin(%s)" % build_plugin_url({"action": "pkm_settings"})),
        ]
        li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(HANDLE, target, li, True)

    # Fixed utility entries. They are intentionally not part of the reorderable Plex library list.
    settings_items = [
        ("설정", "plexkm_kodi_settings", "DefaultAddonProgram.png", build_plugin_url({"action": "kodi_settings"})),
        ("Plex KM 설정", "plexkm_addon_settings", "DefaultAddonProgram.png", build_plugin_url({"action": "settings"})),
    ]
    for label, default_id, icon, target in settings_items:
        li = xbmcgui.ListItem(label=label)
        li.setProperty("defaultID", default_id)
        li.setProperty("PlexKM.SectionIndex", "")
        li.setProperty("PlexKM.SectionId", "")
        li.setProperty("PlexKM.SectionTitle", label)
        li.setProperty("PlexKM.SectionType", "settings")
        li.setProperty("PlexKM.TargetPath", target)
        li.setArt({"thumb": icon, "icon": icon})
        xbmcplugin.addDirectoryItem(HANDLE, target, li, True)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def list_library_index(params):
    """Open a library by its current sidebar index.

    This is intentionally index-based so skin XML can use a static plugin URL in
    <content>. Kodi does not reliably re-evaluate dynamic $INFO[...] content URLs
    when the sidebar focus changes.
    """
    ensure_initial_sync(interactive=False)
    try:
        idx = int(params.get("index", "0") or 0)
    except Exception:
        idx = 0
    # Use cached section list only; sidebar already has the current list from sections_menu.
    sections = apply_section_order(fetch_sections(refresh=False), save_merged=False)
    if idx < 0 or idx >= len(sections):
        log("library_index out of range index=%s sections=%d" % (idx, len(sections)), xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    section = sections[idx]
    q = dict(params)
    q["section_id"] = str(section.get("section_id", ""))
    q.pop("index", None)

    log("library_index index=%d section=%s title=%s" % (idx, q.get("section_id"), section.get("title")))
    list_library(q)



def list_home_widget(params):
    """Lightweight Plex widgets for the skin Home item.

    The Kodi local library can be empty because this skin is driven by Plex KM.
    Home widgets therefore must not depend on Library.HasContent(movies/tvshows).
    This action returns a small widget list from a Plex section by current
    SectionIndex, while the actual library wall still uses full lists.
    """
    try:
        idx = int(params.get("index", "0") or 0)
    except Exception:
        idx = 0
    try:
        limit = int(params.get("limit", "24") or 24)
    except Exception:
        limit = 24
    if limit <= 0:
        limit = 24

    q = dict(params)
    q["index"] = str(idx)
    q["limit"] = str(limit)
    q["offset"] = params.get("offset", "0") or "0"
    q["sort"] = params.get("sort", "added") or "added"
    q["profile"] = params.get("profile", "plex_home_widget") or "plex_home_widget"
    list_library_index(q)

def list_root():
    ok_config = bool(clean_server_url() and plex_token())
    if not ok_config:
        li = xbmcgui.ListItem(label="Plex KM settings required")
        li.setArt({"icon": "DefaultAddonProgram.png"})
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "settings"}), li, True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # First run: sync all Plex movie/show libraries up front so each folder opens from cache.
    if ensure_initial_sync(interactive=True):
        maybe_auto_sync(force=False, background=False, caller="root")

    try:
        sections = fetch_sections(refresh=True)
    except Exception as e:
        log(traceback.format_exc(), xbmc.LOGERROR)
        pkm_notice_set("Plex 연결 실패", "Plex 서버 응답 없음", "서버 상태와 네트워크를 확인해주세요", sticky=True)
        sections = fetch_sections(refresh=False)

    manage_li = xbmcgui.ListItem(label="[설정] 라이브러리 선택/관리")
    manage_li.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "select_libraries"}), manage_li, False)

    sync_li = xbmcgui.ListItem(label="[Sync] 선택 Plex 라이브러리")
    sync_li.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "sync_all"}), sync_li, False)

    auto_li = xbmcgui.ListItem(label="[Sync] Check PMS updates now")
    auto_li.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "auto_sync"}), auto_li, False)

    idx_li = xbmcgui.ListItem(label="[추천 DB] Plex DB 복사본에서 구축")
    idx_li.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({"action": "rebuild_recommend_index"}), idx_li, False)

    for section in sections:
        label = "%s (%s, id=%s)" % (display_library_title(section["title"]), section["section_type"], section["section_id"])
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": section.get("thumb", ""), "fanart": section.get("art", "")})
        li.addContextMenuItems([
            ("Sync section", "RunPlugin(%s)" % build_plugin_url({"action": "sync", "section_title": section["title"]})),
            ("Latest order", "Container.Update(%s)" % build_plugin_url({"action": "library", "section_title": section["title"], "sort": "added"})),
        ])
        url = build_plugin_url({"action": "library", "section_title": section["title"], "sort": "title"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_prewarm(params):
    """Background startup prewarm used by service.py.

    It must not build Kodi ListItems and must not trigger auto-sync. It only
    warms the local SQLite/cache path so later wall openings use hot DB pages.
    """
    t_all = time.time()
    sort = params.get("sort", "added") or "added"
    if not clean_server_url() or not plex_token():
        log("prewarm skipped; Plex URL/token missing", xbmc.LOGINFO)
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return
    if not initial_sync_done():
        log("prewarm skipped; initial sync not done", xbmc.LOGINFO)
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return

    try:
        sections = fetch_sections(refresh=False)
        if not sections:
            sections = fetch_sections(refresh=True)
        sections = apply_section_order(sections, save_merged=True)  # persist merged order so sidebar is instant
        log("prewarm start sections=%d sort=%s" % (len(sections), sort), xbmc.LOGINFO)
        for section in sections:
            section_id = str(section.get("section_id", ""))
            if not section_id:
                continue
            t0 = time.time()
            try:
                total_count = count_items(section_id)
                rows = query_items(section_id, sort=sort, limit=0, offset=0, plex_type=None)
                prewarm_mode = "full"
                elapsed_ms = (time.time() - t0) * 1000.0
                log("prewarm section=%s title=%s mode=%s rows=%d total=%d elapsed=%.3fms" % (
                    section_id, section.get("title", ""), prewarm_mode, len(rows), total_count, elapsed_ms
                ), xbmc.LOGINFO)
            except Exception:
                log("prewarm section failed section=%s title=%s\n%s" % (
                    section_id, section.get("title", ""), traceback.format_exc()
                ), xbmc.LOGWARNING)
        log("prewarm end elapsed=%.3fms" % ((time.time() - t_all) * 1000.0), xbmc.LOGINFO)
    except Exception:
        log("prewarm failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    finally:
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def list_library(params):
    ref = section_ref_from_params(params)
    ensure_initial_sync(interactive=False)
    section = find_section(section_id=ref["section_id"], section_title=ref["section_title"], refresh=False)
    if not section:
        section = find_section(section_id=ref["section_id"], section_title=ref["section_title"], refresh=True)
    if not section:
        raise RuntimeError("section is required or not found: %s" % (ref["section_title"] or ref["section_id"]))

    section_id = str(section["section_id"])
    sort = params.get("sort", "added") or "added"
    requested_limit = param_int(params, "limit", 0, min_value=0, max_value=100000)
    offset = param_int(params, "offset", 0, min_value=0, max_value=1000000)
    plex_type = params.get("type") or None
    profile_tag = params.get("profile") or ("limited" if requested_limit else "full")
    total_count = count_items(section_id, plex_type=plex_type)

    # v040: active wall mode is strict light mode: only title/year metadata.
    wall_light = (profile_tag == "plex_side_wall" and requested_limit == 0)

    t_total = time.time()
    t_query = time.time()
    if wall_light:
        rows = query_items_wall_light(section_id, sort=sort, limit=requested_limit, offset=offset, plex_type=plex_type)
    else:
        rows = query_items(section_id, sort=sort, limit=requested_limit, offset=offset, plex_type=plex_type)
    query_ms = (time.time() - t_query) * 1000.0

    mode = "WIDGET" if requested_limit else ("SMALL_FULL" if len(rows) <= 500 else "WALL_FULL")
    set_wall_window_properties(section, total_count, len(rows), False, requested_limit, offset)
    perf_log("WALL_DECISION_SIMPLE section=%s title=%s sort=%s total=%d limit=%d offset=%d profile=%s rows=%d query=%.3fms wall_light=%s" % (
        section_id, section.get("title", ""), sort, total_count, requested_limit, offset, profile_tag, len(rows), query_ms, str(wall_light).lower()
    ))
    if wall_light:
        perf_log("WALL_LIGHT_MODE section=%s title=%s rows=%d: strict title/year ListItems active" % (
            section_id, section.get("title", ""), len(rows)
        ))

    xbmcplugin.setContent(HANDLE, "tvshows" if section.get("section_type") == PLEX_TYPE_SHOW else "movies")
    for _sort_name in ("SORT_METHOD_TITLE", "SORT_METHOD_LABEL_IGNORE_THE", "SORT_METHOD_DATEADDED", "SORT_METHOD_YEAR", "SORT_METHOD_VIDEO_YEAR"):
        _sort_method = getattr(xbmcplugin, _sort_name, None)
        if _sort_method is not None:
            xbmcplugin.addSortMethod(HANDLE, _sort_method)

    t_build = time.time()
    directory_items = []
    playable_count = 0
    folder_count = 0
    for row in rows:
        li, is_playable = make_listitem_from_row(row, wall_light=wall_light)
        if is_playable:
            playable_count += 1
        else:
            folder_count += 1
        directory_items.append((li.getPath(), li, not is_playable))

    build_ms = (time.time() - t_build) * 1000.0
    t_add = time.time()
    xbmcplugin.addDirectoryItems(HANDLE, directory_items, len(directory_items))
    add_ms = (time.time() - t_add) * 1000.0
    t_end = time.time()
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    end_ms = (time.time() - t_end) * 1000.0
    total_ms = (time.time() - t_total) * 1000.0
    perf_log("LIB_END mode=%s section=%s title=%s rows=%d total=%d query=%.3fms build=%.3fms add=%.3fms end=%.3fms total=%.3fms" % (
        mode, section_id, section.get("title", ""), len(rows), total_count, query_ms, build_ms, add_ms, end_ms, total_ms
    ))



def play_item(params):
    # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
    # This is the only resolver entry for action=play.  It must stay as
    # Kodi plugin playback: default.py -> pkm_playback.play_item() ->
    # xbmcplugin.setResolvedUrl().  Never start movie/episode playback here
    # with xbmc.Player().play() or a direct Plex http URL.
    return _playback_module().play_item(params, env=_playback_env())
def clear_cache():
    path = db_path()
    try:
        if os.path.exists(path):
            os.remove(path)
        for suffix in ("-wal", "-shm"):
            p = path + suffix
            if os.path.exists(p):
                os.remove(p)
        set_initial_sync_done(False)
        set_last_auto_sync_at(0)
        notify("Plex KM cache cleared")
    except Exception as e:
        notify("Clear cache failed: %s" % e, icon=xbmcgui.NOTIFICATION_ERROR)


def open_settings():
    # PKM settings entry. Uses the PKM single-dialog flow, not Kodi stock add-on settings.
    open_pkm_settings_dialog()


def open_kodi_settings():
    try:
        xbmc.executebuiltin("ActivateWindow(settings)")
    except Exception:
        pass
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)




def _log_home_sidebar_state(tag):
    try:
        home = xbmcgui.Window(10000)
        focus_id = -1
        selected_label = ""
        selected_index = ""
        selected_default = ""
        try:
            focus_id = home.getFocusId()
        except Exception:
            pass
        # v1957: never query custom control 9000 through xbmcgui.Window(10000).
        # Before PlexKMHomeWindow is constructed that control does not exist, and
        # Kodi emits a noisy Non-Existent Control error even when Python catches it.
        # Selection details are emitted by PlexKMHomeWindow's own scoped tracer.
        # v2053: never evaluate global visibility/focus conditions for custom
        # control 9000 outside its owning WindowXML. Kodi logs an exception
        # before the XML control tree exists even when Python catches it.
        visible_9000 = False
        has_focus_9000 = False
        log("HOME_SIDEBAR_STATE tag=%s focus_id=%s visible9000=%s focus9000=%s label=%s index=%s defaultID=%s active=%s opening=%s transition=%s return=%s" % (
            tag, focus_id, str(visible_9000).lower(), str(has_focus_9000).lower(),
            selected_label, selected_index, selected_default,
            home.getProperty("PlexKM.WindowWallActive"),
            home.getProperty("PlexKM.WindowWallOpening"),
            home.getProperty("PlexKM.WindowWallTransition"),
            home.getProperty("PlexKM.WindowWallReturn"),
        ), xbmc.LOGINFO)
    except Exception:
        try:
            log("HOME_SIDEBAR_STATE_FAILED tag=%s\n%s" % (tag, traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass




def open_window_search(params=None):
    """Open Plex KM local DB search WindowXML."""
    params = params or {}
    try:
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        lib_path = os.path.join(addon_path, "resources", "lib")
        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)
        try:
            sys.modules["default"] = sys.modules.get(__name__, sys.modules.get("__main__"))
        except Exception:
            pass
        from plexkm_search_window import PlexKMSearchWindow
        log("WINDOW_SEARCH_OPEN_REQUEST", xbmc.LOGINFO)
        win = PlexKMSearchWindow("plexkm_search_window.xml", addon_path, "Default", "1080i")
        try:
            win.doModal()
        finally:
            del win
    except Exception:
        log("WINDOW_SEARCH_OPEN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("Plex KM Search open failed. See kodi.log", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)


def playback_failure_dialog_v2228(params=None):
    """Show a PKM-skinned playback failure when Kodi gives up without one.

    Some HTTP timeout paths never open Kodi's own DialogConfirm.  V2224 then
    had no dialog-unload event to finish the failed opening.  Use Kodi's normal
    confirmation dialog here so skin.plex.km/DialogConfirm.xml supplies the PKM
    visuals and its existing onunload recovery hook remains the single owner.
    """
    params = params or {}
    try:
        home = xbmcgui.Window(10000)
        candidate = home.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
        definitive_v2229 = home.getProperty("PlexKM.Playback.DefinitiveFailureV2229") == "1"
        phase = home.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
        opening = (
            home.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
            or home.getProperty("PlexKM.Playback.OpeningActive") == "1"
        )
        try:
            video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
        except Exception:
            video_active = False
        valid_phase_v2229 = phase in ("handoff_stop_blocked", "definitive_failed")
        if video_active or not candidate or not opening or not valid_phase_v2229:
            log("PLAYBACK_FAILURE_DIALOG_SKIP_V2229 video=%s candidate=%s definitive=%s opening=%s phase=%s" % (
                "1" if video_active else "0", "1" if candidate else "0",
                "1" if definitive_v2229 else "0", "1" if opening else "0", phase or "-"
            ), xbmc.LOGINFO)
            return
        if home.getProperty("PlexKM.Playback.FailureDialogShownV2228") == "1":
            return
        home.setProperty("PlexKM.Playback.FailureDialogShownV2228", "1")
        source = str(params.get("source") or "playback_failure")
        log("PLAYBACK_FAILURE_DIALOG_SHOW_V2229 source=%s phase=%s definitive=%s style=skin_dialogconfirm" % (source, phase, "1" if definitive_v2229 else "0"), xbmc.LOGINFO)
        try:
            xbmcgui.Dialog().ok("재생 실패", "이 항목을 재생하지 못했습니다.\nPlex 서버 또는 미디어 상태를 확인해 주세요.")
        finally:
            # DialogConfirm.xml onunload normally owns this.  Keep a fallback
            # for skins/platforms that do not deliver that unload action.
            try:
                home.clearProperty("PlexKM.Playback.FailureDialogShownV2228")
            except Exception:
                pass
            playback_failure_home_request_v2224({"source": "pkm_dialog_closed_v2228"})
    except Exception:
        log("PLAYBACK_FAILURE_DIALOG_FAILED_V2228 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)


def playback_failure_home_request_v2224(params=None):
    """Request the live PKM Home WindowXML to recover a failed pre-AV opening.

    The Kodi playback-failure DialogConfirm owns the user's OK/Back key. Its
    skin onunload calls this route after the dialog has actually closed. We then
    send one Back to the already-live PKM WindowXML; its GUI-thread onAction
    performs the real state cleanup and Home transition.
    """
    params = params or {}
    try:
        home = xbmcgui.Window(10000)
        candidate = home.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
        definitive_v2229 = home.getProperty("PlexKM.Playback.DefinitiveFailureV2229") == "1"
        opening = (
            home.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
            or home.getProperty("PlexKM.Playback.OpeningActive") == "1"
        )
        phase = home.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
        try:
            video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
        except Exception:
            video_active = False
        if video_active:
            home.clearProperty("PlexKM.Playback.OpenFailureCandidateV2224")
            home.clearProperty("PlexKM.Playback.OpenFailureCandidateAtMsV2224")
            home.clearProperty("PlexKM.Playback.FailureHomeRequestV2224")
            log("PLAYBACK_FAILURE_HOME_REQUEST_CANCEL_V2224 reason=video_active phase=%s" % phase, xbmc.LOGINFO)
            return
        valid_phase_v2229 = phase in ("handoff_stop_blocked", "definitive_failed")
        if not candidate or not opening or not valid_phase_v2229:
            log("PLAYBACK_FAILURE_HOME_REQUEST_SKIP_V2229 candidate=%s definitive=%s opening=%s phase=%s" % (
                "1" if candidate else "0", "1" if definitive_v2229 else "0", "1" if opening else "0", phase or "-"
            ), xbmc.LOGINFO)
            return
        source = str(params.get("source") or "dialog_closed")
        home.setProperty("PlexKM.Playback.FailureHomeRequestV2224", "1")
        home.setProperty("PlexKM.Playback.FailureHomeRequestSourceV2224", source)
        log("PLAYBACK_FAILURE_HOME_REQUEST_V2224 source=%s action=back_to_live_home_window" % source, xbmc.LOGINFO)
        # DialogConfirm onunload and RunPlugin can overlap by one GUI tick.
        xbmc.sleep(90)
        xbmc.executebuiltin("Action(Back)")
    except Exception:
        log("PLAYBACK_FAILURE_HOME_REQUEST_FAILED_V2224 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)


def open_window_home(params):
    """Open full Plex KM WindowXML home."""
    try:
        home = xbmcgui.Window(10000)
        if home.getProperty("PlexKM.HomeWindowOpening") == "true" or home.getProperty("PlexKM.HomeWindowActive") == "true":
            log("WINDOW_HOME_OPEN_SKIP reason=already_open_or_opening params=%s" % params, xbmc.LOGINFO)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
            return
        home.setProperty("PlexKM.HomeWindowOpening", "true")
        index = params.get("index", params.get("section_index", "home"))
        sort = params.get("sort", "added") or "added"
        startup_autostart = str(params.get("autostart", "")).lower() in ("1", "true", "yes") or str(params.get("no_interactive_sync", "")).lower() in ("1", "true", "yes")
        if clean_server_url() and plex_token():
            # v1975: startup never opens a library chooser and never mutates the
            # user's selection merely to reach Home.  Existing installations may
            # bootstrap from their populated DB; fresh/unconfigured/error states
            # are resolved by WindowXML as a safe empty Home surface.
            try:
                _sel1975, _cfg1975, _state1975 = selected_sections_startup_state_v1975()
            except Exception:
                _sel1975, _cfg1975, _state1975 = ([], False, "read_error")
                log("WINDOW_HOME_SELECTION_STATE_EXCEPTION_V1975 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            if _state1975 == "ok" and (not _cfg1975):
                # v1981: unconfigured means no selected libraries. Never infer
                # selection from DB/cache contents and never mutate state here.
                log("WINDOW_HOME_UNCONFIGURED_ROUTE_V1981 autostart=%s selected=0 modal_open=0 mutation=0 db_bootstrap=0" % (
                    "1" if startup_autostart else "0"
                ), xbmc.LOGINFO)
            elif _state1975 != "ok":
                log("WINDOW_HOME_SELECTION_STATE_SAFE_ROUTE_V1975 autostart=%s state=%s modal_open=0 mutation=0" % (
                    "1" if startup_autostart else "0", _state1975
                ), xbmc.LOGWARNING)
            elif _cfg1975 and not _sel1975:
                log("WINDOW_HOME_EXPLICIT_EMPTY_ROUTE_V1975 autostart=%s selected=0 modal_open=0 mutation=0" % (
                    "1" if startup_autostart else "0"
                ), xbmc.LOGINFO)
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        lib_path = os.path.join(addon_path, "resources", "lib")
        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)
        # Make default.py core API discoverable for WindowXML modules even when
        # Kodi opens the window through service/autostart RunScript contexts.
        try:
            sys.modules["default"] = sys.modules.get(__name__, sys.modules.get("__main__"))
        except Exception:
            pass
        from plexkm_home_window import PlexKMHomeWindow
        # v2119 diagnostic boundary: never inspect custom control 9000 here.
        # It belongs to the new WindowXML and does not exist until onInit.
        try:
            home.clearProperty("PlexKM.Home.XmlControlsReadyV2119")
        except Exception:
            pass
        log("WINDOW_HOME_OPEN_REQUEST index=%s sort=%s" % (index, sort), xbmc.LOGINFO)
        log("WINDOW_HOME_CONSTRUCT_BEGIN_V2119 xml_controls_ready=0 control9000_probe=0", xbmc.LOGINFO)
        win = PlexKMHomeWindow("plexkm_home_window.xml", addon_path, "Default", "1080i", start_index=index, sort=sort)
        log("WINDOW_HOME_CONSTRUCT_DONE_V2119 xml_controls_ready=0 control9000_probe=0", xbmc.LOGINFO)
        try:
            win.doModal()
        finally:
            del win
    except Exception:
        log("WINDOW_HOME_OPEN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("Plex KM Home open failed. See kodi.log", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
    finally:
        try:
            home = xbmcgui.Window(10000)
            home.clearProperty("PlexKM.HomeWindowOpening")
            home.clearProperty("PlexKM.HomeWindowActive")
        except Exception:
            pass
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def open_window_wall(params):
    """Open Plex KM right-side WindowXML lazy wall from Home sidebar.

    Home sidebar remains the only sidebar. The old Home XML wall is not used
    for Plex KM library browsing. OK/Info inside the WindowXML wall opens the
    normal video information dialog for the focused item.
    """
    try:
        home = xbmcgui.Window(10000)
        # v1961: no custom-control probe before the owning WindowXML is active.
        if home.getProperty("PlexKM.WindowWallOpening") == "true" or home.getProperty("PlexKM.WindowWallActive") == "true":
            log("WINDOW_WALL_OPEN_SKIP reason=already_open_or_opening params=%s" % params, xbmc.LOGINFO)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
            return
        index = params.get("index", params.get("section_index", ""))
        section_id = params.get("section_id", params.get("id", ""))
        section_title = params.get("section_title", params.get("title", ""))
        sort = params.get("sort", "added") or "added"

        # Keep a Home-side visual copy of the selected sidebar item while
        # WindowXML owns focus. Kodi may report Control(9000) as invisible
        # once a modal WindowXML is active, so the skin overlay reads these
        # properties instead of relying on focused ListItem state.
        home.setProperty("PlexKM.SidebarOverlayLabel", section_title)
        home.setProperty("PlexKM.SidebarOverlayIndex", str(index))
        home.setProperty("PlexKM.SidebarOverlaySectionId", str(section_id))
        home.setProperty("PlexKM.SidebarOverlaySort", sort)
        home.setProperty("PlexKM.WindowWallOpening", "true")
        # Keep the Home preview visible behind the transparent WindowXML during open.
        # Do not set WindowWallTransition or WindowWallActive here; those properties
        # hide/dim the Home preview and caused a visible black frame before the
        # dialog finished drawing. WindowWallOpening remains true for the sidebar overlay.
        # v2054: no fixed wait before opening the owning WindowXML.

        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        lib_path = os.path.join(addon_path, "resources", "lib")
        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)

        from plexkm_wall_window import PlexKMWallWindow

        initial = param_int(params, "initial", 180, min_value=1, max_value=2000)
        batch = param_int(params, "batch", 240, min_value=1, max_value=2000)

        log("WINDOW_WALL_OPEN_REQUEST index=%s section=%s title=%s sort=%s initial=%s batch=%s" % (
            index, section_id, section_title, sort, initial, batch
        ), xbmc.LOGINFO)

        win = PlexKMWallWindow(
            "plexkm_right_wall.xml",
            addon_path,
            "Default",
            "1080i",
            section_index=index,
            section_id=section_id,
            section_title=section_title,
            sort=sort,
            initial=initial,
            batch=batch,
        )
        try:
            win.doModal()
            _log_home_sidebar_state("after_dialog_closed_before_return")
            try:
                # No return overlay/delay. Keep the Home preview visible continuously
                # so closing the transparent WindowXML does not flash black.
                home.setProperty("PlexKM.WindowWallReturn", "true")
            except Exception:
                pass
        finally:
            del win
    except Exception:
        log("WINDOW_WALL_OPEN_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("Window wall open failed. See kodi.log", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
    finally:
        try:
            home = xbmcgui.Window(10000)
            home.clearProperty("PlexKM.WindowWallOpening")
            home.clearProperty("PlexKM.WindowWallTransition")
            home.clearProperty("PlexKM.WindowWallReturn")
            home.clearProperty("PlexKM.WindowWallActive")
            home.clearProperty("PlexKM.SidebarOverlayLabel")
            home.clearProperty("PlexKM.SidebarOverlayIndex")
            home.clearProperty("PlexKM.SidebarOverlaySectionId")
            home.clearProperty("PlexKM.SidebarOverlaySort")
            _log_home_sidebar_state("finally_after_clear")
        except Exception:
            pass
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def move_section(params):
    move_section_in_order(params.get("section_id", ""), params.get("direction", ""))
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def build_cine21_db_seed(params):
    """Manual Cine21 DB seed action.

    v774c keeps this out of startup/Home/sync paths so initial screen speed
    remains aligned with the v772 baseline.  This action only creates tables
    and pending rows from the existing items cache; it does not fetch Cine21.
    """
    conn = None
    try:
        limit = param_int(params, "limit", 0, min_value=0, max_value=1000000)
        conn = init_db()
        from resources.lib import pkm_cine21
        count = pkm_cine21.build_pending_seed_rows(conn, limit=limit)
        try:
            status_counts = ", ".join(["%s=%s" % (k or "none", v) for k, v in pkm_cine21.get_status_counts(conn)])
        except Exception:
            status_counts = ""
        log("[PKM_CINE21] manual_seed_done count=%s limit=%s status=%s" % (count, limit, status_counts), xbmc.LOGINFO)
        notify("씨네21 DB 준비", "후보 %s개 추가" % count, icon=xbmcgui.NOTIFICATION_INFO, ms=4000)
    except Exception:
        log("[PKM_CINE21] manual_seed_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 DB 준비 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)



def fetch_cine21_rating_manual(params):
    """Manual Cine21 rating fetch for one selected movie.

    v775 intentionally requires rating_key + movie_id so no title parsing or bulk
    network scan can slow Home/startup.  Wall/Info still read no Cine21 values.
    """
    conn = None
    try:
        rating_key = params.get("rating_key", "") or params.get("key", "")
        movie_id = params.get("movie_id", "") or params.get("cine21_movie_id", "")
        timeout = param_int(params, "timeout", 8, min_value=3, max_value=30)
        if not rating_key or not movie_id:
            notify("씨네21 평점 저장 실패", "rating_key와 movie_id가 필요합니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            log("[PKM_CINE21] manual_fetch_missing_params rating_key=%s movie_id=%s" % (rating_key, movie_id), xbmc.LOGWARNING)
            return
        conn = init_db()
        from resources.lib import pkm_cine21
        result = pkm_cine21.fetch_and_save_rating(conn, rating_key, movie_id, timeout=timeout)
        title = "씨네21 평점 저장"
        line = "전문가 %s / 관객 %s" % (result.get("critic_rating"), result.get("audience_rating"))
        notify(title, line, icon=xbmcgui.NOTIFICATION_INFO, ms=5000)
        log("[PKM_CINE21] manual_fetch_done rating_key=%s movie_id=%s critic=%s audience=%s experts=%s" % (
            rating_key, movie_id, result.get("critic_rating"), result.get("audience_rating"), result.get("expert_count")
        ), xbmc.LOGINFO)
    except Exception:
        log("[PKM_CINE21] manual_fetch_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 평점 저장 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)






def _cine21_progress_cancelled(progress):
    try:
        return bool(progress and progress.iscanceled())
    except Exception:
        return False


def _run_cine21_update_with_progress(conn, progress, params=None, source="settings"):
    """Build/match/fetch Cine21 movie ratings with visible current/total progress.

    Data-only.  It touches only the Cine21 DB tables and network fetches.  It
    does not open Home, change focus, or navigate Kodi windows.  Cine21 is
    movie-only, so non-movie items are excluded at SQL level.
    """
    params = params or {}
    from resources.lib import pkm_cine21

    seed_chunk = param_int(params, "seed_chunk", 1000, min_value=50, max_value=5000)
    match_chunk = param_int(params, "match_chunk", 25, min_value=1, max_value=100)
    fetch_chunk = param_int(params, "fetch_chunk", 25, min_value=1, max_value=100)
    timeout = param_int(params, "timeout", 6, min_value=3, max_value=30)
    allow_full = str(params.get("allow_full", "1")).lower() not in ("0", "false", "no")

    total_movies = int(pkm_cine21.count_total_movie_items(conn) or 0)
    already_ok_start = int(pkm_cine21.count_ok_ratings(conn) or 0)
    progress_update(progress, 1, "씨네21 DB 상태 확인 중\n영화 %d개 / 저장완료 %d개" % (total_movies, already_ok_start))

    # 1) Register movie candidates.  Existing Cine21 rows, including ok rows,
    # are skipped by INSERT OR IGNORE in pkm_cine21.build_pending_seed_rows().
    total_seed = int(pkm_cine21.count_seed_candidates(conn) or 0)
    seeded_total = 0
    if total_seed > 0:
        while seeded_total < total_seed:
            if _cine21_progress_cancelled(progress):
                return {"cancelled": True, "stage": "seed", "seeded": seeded_total}
            count = int(pkm_cine21.build_pending_seed_rows(conn, limit=seed_chunk) or 0)
            if count <= 0:
                break
            seeded_total += count
            pct = 5 + min(10, int((float(seeded_total) / float(max(1, total_seed))) * 10.0))
            progress_update(progress, pct, "씨네21 후보 등록 중\n%d / %d | 저장완료 스킵 %d" % (seeded_total, total_seed, already_ok_start))
    else:
        progress_update(progress, 15, "씨네21 후보 등록 완료\n추가 후보 없음 | 저장완료 스킵 %d" % already_ok_start)

    # 2) Match Cine21 movie_id for rows still lacking movie_id.  Rows already ok,
    # no_match, ambiguous, or match_error are not selected again, so reruns skip
    # already processed/problem-free rows and continue remaining work.
    match_total = int(pkm_cine21.count_match_candidates_without_movie_id(conn) or 0)
    match_done = 0
    matched_total = 0
    no_match_total = 0
    ambiguous_total = 0
    match_error_total = 0

    def _match_cb(batch_stats, done, total, rating_key):
        pct = 15 + min(55, int((float(done) / float(max(1, total))) * 55.0))
        progress_update(
            progress,
            pct,
            "씨네21 movie_id 매칭 중\n%d / %d | 확정 %d, 없음 %d, 보류 %d" % (
                done,
                total,
                matched_total + int(batch_stats.get("matched", 0) or 0),
                no_match_total + int(batch_stats.get("no_match", 0) or 0),
                ambiguous_total + int(batch_stats.get("ambiguous", 0) or 0),
            ),
        )

    if match_total > 0:
        while match_done < match_total:
            if _cine21_progress_cancelled(progress):
                return {"cancelled": True, "stage": "match", "seeded": seeded_total, "match_checked": match_done, "matched": matched_total}
            todo = min(match_chunk, match_total - match_done)
            if todo <= 0:
                break
            mstats = pkm_cine21.match_cine21_movie_ids(
                conn,
                limit=todo,
                timeout=timeout,
                progress_cb=_match_cb,
                total=match_total,
                base_done=match_done,
            )
            checked = int(mstats.get("checked", 0) or 0)
            if checked <= 0:
                break
            match_done += checked
            matched_total += int(mstats.get("matched", 0) or 0)
            no_match_total += int(mstats.get("no_match", 0) or 0)
            ambiguous_total += int(mstats.get("ambiguous", 0) or 0)
            match_error_total += int(mstats.get("error", 0) or 0)
            if not allow_full:
                break
    progress_update(progress, 72, "씨네21 movie_id 매칭 완료\n%d / %d | 확정 %d, 없음 %d, 오류 %d" % (
        match_done, match_total, matched_total, no_match_total + ambiguous_total, match_error_total
    ))

    # 3) Fetch ratings only for rows with trusted movie_id.  ok rows are skipped
    # by pkm_cine21.fetch_cine21_ratings_for_candidates().
    fetch_total = int(pkm_cine21.count_fetch_candidates_with_movie_id(conn) or 0)
    fetch_done = 0
    fetched_ok = 0
    fetched_error = 0

    def _fetch_cb(batch_stats, done, total, rating_key):
        pct = 72 + min(25, int((float(done) / float(max(1, total))) * 25.0))
        progress_update(
            progress,
            pct,
            "씨네21 평점 저장 중\n%d / %d | 성공 %d, 실패 %d, 기존완료 스킵 %d" % (
                done,
                total,
                fetched_ok + int(batch_stats.get("fetched_ok", 0) or 0),
                fetched_error + int(batch_stats.get("fetched_error", 0) or 0),
                already_ok_start,
            ),
        )

    if fetch_total > 0:
        while fetch_done < fetch_total:
            if _cine21_progress_cancelled(progress):
                return {"cancelled": True, "stage": "fetch", "seeded": seeded_total, "match_checked": match_done, "matched": matched_total, "fetched_ok": fetched_ok}
            todo = min(fetch_chunk, fetch_total - fetch_done)
            if todo <= 0:
                break
            fstats = pkm_cine21.fetch_cine21_ratings_for_candidates(
                conn,
                limit=todo,
                timeout=timeout,
                progress_cb=_fetch_cb,
                total=fetch_total,
                base_done=fetch_done,
            )
            candidates = int(fstats.get("candidates", 0) or 0)
            if candidates <= 0:
                break
            fetch_done += candidates
            fetched_ok += int(fstats.get("fetched_ok", 0) or 0)
            fetched_error += int(fstats.get("fetched_error", 0) or 0)
            if not allow_full:
                break
    already_ok_end = int(pkm_cine21.count_ok_ratings(conn) or 0)
    status_counts = ""
    try:
        status_counts = ", ".join(["%s=%s" % (k or "none", v) for k, v in pkm_cine21.get_status_counts(conn)])
    except Exception:
        pass
    progress_update(progress, 100, "씨네21 DB 업데이트 완료\n영화 %d개 | 저장완료 %d개 | 이번 저장 %d개" % (
        total_movies, already_ok_end, fetched_ok
    ))
    return {
        "seeded": seeded_total,
        "match_total": match_total,
        "match_checked": match_done,
        "matched": matched_total,
        "no_match": no_match_total,
        "ambiguous": ambiguous_total,
        "match_error": match_error_total,
        "fetch_total": fetch_total,
        "fetch_checked": fetch_done,
        "fetched_ok": fetched_ok,
        "fetched_error": fetched_error,
        "ok_start": already_ok_start,
        "ok_end": already_ok_end,
        "total_movies": total_movies,
        "status_counts": status_counts,
    }


def cine21_update_from_settings(params=None):
    """User-initiated Cine21 DB update from PKM settings.

    Shows current/total progress while the settings dialog remains open.
    Already ok rows are skipped on every re-run.  This is data-only Python;
    no Home focus/navigation/playback flow is controlled here.
    """
    params = params or {}
    conn = None
    progress = None
    try:
        conn = init_db()
        progress = _create_pkm_sync_progress()
        progress_create(progress, str(params.get("progress_title") or "씨네21 평점 DB 업데이트"), "씨네21 DB 상태 확인 중")
        stats = _run_cine21_update_with_progress(conn, progress, params=params, source=str(params.get("source") or "settings"))
        if stats.get("cancelled"):
            log("[PKM_CINE21] settings_update_cancelled stage=%s stats=%s" % (stats.get("stage", ""), stats), xbmc.LOGINFO)
            notify("씨네21 평점 DB", "업데이트를 취소했습니다", icon=xbmcgui.NOTIFICATION_INFO, ms=3500)
            return stats
        log("[PKM_CINE21] settings_update_done seeded=%s match_checked=%s/%s matched=%s no_match=%s ambiguous=%s match_error=%s fetch_checked=%s/%s fetched_ok=%s fetched_error=%s ok_skip_start=%s ok_total=%s status=%s" % (
            stats.get("seeded", 0), stats.get("match_checked", 0), stats.get("match_total", 0), stats.get("matched", 0),
            stats.get("no_match", 0), stats.get("ambiguous", 0), stats.get("match_error", 0),
            stats.get("fetch_checked", 0), stats.get("fetch_total", 0), stats.get("fetched_ok", 0), stats.get("fetched_error", 0),
            stats.get("ok_start", 0), stats.get("ok_end", 0), stats.get("status_counts", "")
        ), xbmc.LOGINFO)
        try:
            time.sleep(0.45)
        except Exception:
            pass
        notify("씨네21 평점 DB", "저장완료 %d개 / 이번 저장 %d개" % (int(stats.get("ok_end", 0) or 0), int(stats.get("fetched_ok", 0) or 0)), icon=xbmcgui.NOTIFICATION_INFO, ms=4200)
        return stats
    except Exception:
        log("[PKM_CINE21] settings_update_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 평점 DB 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return {"error": traceback.format_exc()}
    finally:
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def _cine21_import_percent(value, total):
    try:
        return (100.0 * float(value) / float(max(1, int(total or 0))))
    except Exception:
        return 0.0


def _cine21_import_percent_label(value, total):
    value = _cine21_import_percent(value, total)
    text = ("%.2f" % value).rstrip("0").rstrip(".")
    return "%s%%" % (text or "0")


def _external_rating_match_notice(provider_label, total, matched, ms=6000):
    """Show one consistent import-completion notice for both rating providers.

    The denominator is always the current PKM movie-item count.  This avoids
    comparing a provider build DB row count with the current PKM library count.
    """
    try:
        total = max(0, int(total or 0))
        matched = min(max(0, int(matched or 0)), total)
        pkm_show_notice(
            "%s 평점 DB" % str(provider_label or "외부"),
            "전체 %d개 | 평점매칭 %d개" % (total, matched),
            "평점매칭률 %s" % _cine21_import_percent_label(matched, total),
            ms=int(ms or 6000),
        )
        return True
    except Exception:
        log("[PKM_EXTERNAL_RATING] completion_notice_failed provider=%s\n%s" % (str(provider_label or ""), traceback.format_exc()), xbmc.LOGWARNING)
        return False


def _cine21_import_summary_values(stats):
    """Return the four user-facing Cine21 status values.

    `평점 확인` is the number of PKM movies connected to a Cine21 row that
    actually contains at least one critic or audience rating.  Older match
    summaries do not have RATING_CONFIRMED, so MATCHED is retained only as a
    compatibility fallback until the next import/rebuild.
    """
    total = int(stats.get("PKM_MOVIE_ROWS", 0) or 0)
    if "RATING_CONFIRMED" in stats:
        confirmed = int(stats.get("RATING_CONFIRMED", 0) or 0)
    else:
        confirmed = int(stats.get("MATCHED", 0) or 0)
    confirmed = min(max(0, confirmed), max(0, total))
    unconfirmed = max(0, total - confirmed)
    return total, confirmed, unconfirmed


def _cine21_import_summary_text(stats):
    """Simple vertical Cine21 status used by progress and notifications."""
    total, confirmed, unconfirmed = _cine21_import_summary_values(stats)
    return (
        "전체 영화 : %d개\n"
        "평점 확인 : %d개\n"
        "평점 미확인 : %d개\n"
        "매칭율 : %s"
    ) % (
        total,
        confirmed,
        unconfirmed,
        _cine21_import_percent_label(confirmed, total),
    )


def _cine21_import_status_detail_text(stats):
    """Settings status: exactly four vertically stacked values."""
    return _cine21_import_summary_text(stats)


def _pkm_expected_build_db_name(path_value, expected_name):
    try:
        actual = str(path_value or "").replace("\\", "/").rsplit("/", 1)[-1].strip().lower()
        return actual == str(expected_name or "").strip().lower()
    except Exception:
        return False


def _pkm_prepare_sqlite_db_source_v2371(path_value, expected_name):
    """Return a local filesystem path SQLite can open plus the original VFS path.

    Kodi's file browser may return smb://, nfs://, webdav:// or special:// paths.
    sqlite3 cannot open those VFS URLs directly.  Local/special paths are used in
    place; remote VFS files are copied to an addon-profile cache before import.
    """
    original = str(path_value or "").strip()
    if not original:
        return "", original

    translated = xbmcvfs.translatePath(original)
    try:
        if translated and os.path.isfile(translated):
            return translated, original
    except Exception:
        pass

    exists_vfs = False
    try:
        exists_vfs = bool(xbmcvfs.exists(original))
    except Exception:
        exists_vfs = False
    if not exists_vfs and translated and translated != original:
        try:
            exists_vfs = bool(xbmcvfs.exists(translated))
        except Exception:
            exists_vfs = False
    if not exists_vfs:
        return "", original

    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    cache_dir = os.path.join(profile_dir, "external_rating_db_cache")
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    local_name = str(expected_name or "rating_build.db").strip() or "rating_build.db"
    local_path = os.path.join(cache_dir, local_name)
    try:
        if os.path.exists(local_path):
            os.remove(local_path)
    except Exception:
        pass

    copied = False
    try:
        copied = bool(xbmcvfs.copy(original, local_path))
    except Exception:
        copied = False
    if not copied and translated and translated != original:
        try:
            copied = bool(xbmcvfs.copy(translated, local_path))
        except Exception:
            copied = False
    if not copied or not os.path.isfile(local_path):
        try:
            if os.path.exists(local_path):
                os.remove(local_path)
        except Exception:
            pass
        return "", original

    log("[PKM_RATING_DB_VFS] materialized_v2371 source=%s local=%s" % (original, local_path), xbmc.LOGINFO)
    return local_path, original


def cine21_import_ratings_db_from_settings(params=None):
    """Import existing cine21_rate_build.db and build cine21_matches.

    Data-only Python. Uses Kodi file-browser-selected DB path from settings flow.
    No Wall/Info network calls and no UI focus/navigation control.
    """
    params = params or {}
    conn = None
    progress = None
    try:
        ratings_source = params.get("ratings_db", "") or ADDON.getSetting("cine21_ratings_db_path")
        ratings_source = str(ratings_source or "").strip()
        if not ratings_source:
            notify("씨네21 DB 가져오기 실패", "cine21_rate_build.db 파일을 선택하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "ratings_db_not_found", "ratings_db": ratings_source}
        if not _pkm_expected_build_db_name(ratings_source, "cine21_rate_build.db"):
            notify("씨네21 DB 가져오기 실패", "파일명은 cine21_rate_build.db 이어야 합니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "unexpected_cine21_build_db_name", "ratings_db": ratings_source}
        ratings_db, ratings_source = _pkm_prepare_sqlite_db_source_v2371(ratings_source, "cine21_rate_build.db")
        if not ratings_db:
            notify("씨네21 DB 가져오기 실패", "cine21_rate_build.db 파일을 선택하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "ratings_db_not_found", "ratings_db": ratings_source}
        conn = init_db()
        progress = _create_pkm_sync_progress()
        progress_create(progress, "씨네21 평점 DB 가져오기", "파일 확인 중\n%s" % ratings_source)
        from resources.lib import pkm_cine21_import

        def _progress_cb(percent, message):
            progress_update(progress, int(percent or 0), message)

        stats = pkm_cine21_import.run_import_and_match(conn, ratings_db, progress_cb=_progress_cb)
        progress_update(progress, 100, "씨네21 평점 DB 가져오기 완료\n%s" % _cine21_import_summary_text(stats))
        ADDON.setSetting("cine21_ratings_db_path", ratings_source)
        log("[PKM_CINE21_IMPORT] import_done ratings_source=%s sqlite_path=%s stats=%s" % (ratings_source, ratings_db, stats), xbmc.LOGINFO)
        try:
            time.sleep(0.45)
        except Exception:
            pass
        total_movies, rating_matched, _rating_unmatched = _cine21_import_summary_values(stats)
        _external_rating_match_notice("씨네21", total_movies, rating_matched, ms=6000)
        return stats
    except Exception:
        log("[PKM_CINE21_IMPORT] import_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 DB 가져오기 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return {"error": traceback.format_exc()}
    finally:
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def cine21_generate_ratings_db_from_settings(params=None):
    """Generate cine21_rate_build.db from Cine21 point-list pages, then import/match.

    Long-running explicit settings action only.  It displays a progress dialog and
    may take more than 2 hours.  It is never called from Wall/Info/Home drawing.
    """
    params = params or {}
    conn = None
    progress = None
    try:
        profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
        if not os.path.exists(profile_dir):
            os.makedirs(profile_dir)
        out_db = os.path.join(profile_dir, "cine21_rate_build.db")
        progress = _create_pkm_sync_progress()
        progress_create(progress, "씨네21 평점 DB 새로 생성", "2시간 이상 걸릴 수 있습니다\n취소하려면 취소 버튼을 누르세요")
        from resources.lib import pkm_cine21_import

        def _progress_cb(percent, message):
            progress_update(progress, int(percent or 0), message)

        def _cancel_cb():
            return _cine21_progress_cancelled(progress)

        gen = pkm_cine21_import.generate_ratings_db_from_web(out_db, progress_cb=_progress_cb, cancel_cb=_cancel_cb, timeout=10)
        if gen.get("cancelled"):
            log("[PKM_CINE21_IMPORT] generate_cancelled stats=%s" % gen, xbmc.LOGINFO)
            notify("씨네21 평점 DB", "새로 생성을 취소했습니다", icon=xbmcgui.NOTIFICATION_INFO, ms=4000)
            return gen
        conn = init_db()
        stats = pkm_cine21_import.run_import_and_match(conn, out_db, progress_cb=_progress_cb)
        ADDON.setSetting("cine21_ratings_db_path", out_db)
        progress_update(progress, 100, "씨네21 평점 DB 생성/가져오기 완료\n%s" % _cine21_import_summary_text(stats))
        log("[PKM_CINE21_IMPORT] generate_done out_db=%s gen=%s stats=%s" % (out_db, gen, stats), xbmc.LOGINFO)
        try:
            time.sleep(0.45)
        except Exception:
            pass
        total_movies, rating_matched, _rating_unmatched = _cine21_import_summary_values(stats)
        _external_rating_match_notice("씨네21", total_movies, rating_matched, ms=6000)
        return stats
    except Exception:
        log("[PKM_CINE21_IMPORT] generate_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 DB 새로 생성 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return {"error": traceback.format_exc()}
    finally:
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass




# -----------------------------------------------------------------------------
# Watcha Pedia rating DB import/settings actions
# -----------------------------------------------------------------------------
def _watcha_import_percent(value, total):
    try:
        return (100.0 * float(value) / float(max(1, int(total or 0))))
    except Exception:
        return 0.0


def _watcha_import_summary_text(stats):
    try:
        from resources.lib import pkm_watcha_import
        return pkm_watcha_import.summary_text(stats or {})
    except Exception:
        total = int((stats or {}).get("total", 0) or 0)
        matched = int((stats or {}).get("MATCHED", 0) or 0)
        no_match = int((stats or {}).get("NO_MATCH", 0) or 0)
        missing = int((stats or {}).get("RATING_MISSING", 0) or 0)
        return "전체 %d개 | 평점매칭 %d개 %.2f%% | 평점없음 %d | 실패 %d" % (total, matched, _watcha_import_percent(matched, total), missing, no_match)


def watcha_import_build_db_from_settings(params=None):
    """Import a prebuilt watcha_rate_build.db into PKM plex_km.db.

    This is equivalent to the Cine21 file-import flow.  It is local DB work only:
    no Watcha network/crawling is performed in Wall/Info/Home drawing.
    """
    params = params or {}
    conn = None
    progress = None
    try:
        build_source = params.get("build_db", "") or ADDON.getSetting("watcha_build_db_path")
        build_source = str(build_source or "").strip()
        if not build_source:
            notify("왓챠피디아 DB 가져오기 실패", "watcha_rate_build.db 파일을 선택하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "watcha_rate_build_db_not_found", "build_db": build_source}
        if not _pkm_expected_build_db_name(build_source, "watcha_rate_build.db"):
            notify("왓챠피디아 DB 가져오기 실패", "파일명은 watcha_rate_build.db 이어야 합니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "unexpected_watcha_build_db_name", "build_db": build_source}
        build_db, build_source = _pkm_prepare_sqlite_db_source_v2371(build_source, "watcha_rate_build.db")
        if not build_db:
            notify("왓챠피디아 DB 가져오기 실패", "watcha_rate_build.db 파일을 선택하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
            return {"error": "watcha_rate_build_db_not_found", "build_db": build_source}
        conn = init_db()
        progress = _create_pkm_sync_progress()
        progress_create(progress, "왓챠피디아 평점 DB 가져오기", "파일 확인 중\n%s" % build_source)
        from resources.lib import pkm_watcha_import

        def _progress_cb(percent, message):
            progress_update(progress, int(percent or 0), message)

        stats = pkm_watcha_import.run_import_watcha_build_db(conn, build_db, progress_cb=_progress_cb)
        current_total, current_matched, current_unmatched = _watcha_current_movie_status_fast(conn)
        current_status_text = (
            "전체 영화 : %d개\n"
            "평점 확인 : %d개\n"
            "평점 미확인 : %d개\n"
            "매칭율 : %s"
        ) % (
            current_total,
            current_matched,
            current_unmatched,
            _cine21_import_percent_label(current_matched, current_total),
        )
        progress_update(progress, 100, "왓챠피디아 평점 DB 가져오기 완료\n%s" % current_status_text)
        ADDON.setSetting("watcha_build_db_path", build_source)
        stats = dict(stats or {})
        stats["PKM_MOVIE_ROWS"] = current_total
        stats["RATING_CONFIRMED_CURRENT"] = current_matched
        stats["RATING_UNCONFIRMED_CURRENT"] = current_unmatched
        stats["CURRENT_MATCH_PERCENT"] = _cine21_import_percent(current_matched, current_total)
        log("[PKM_WATCHA_IMPORT] import_done build_source=%s sqlite_path=%s stats=%s" % (build_source, build_db, stats), xbmc.LOGINFO)
        try:
            time.sleep(0.45)
        except Exception:
            pass
        _external_rating_match_notice("왓챠피디아", current_total, current_matched, ms=6000)
        return stats
    except Exception:
        log("[PKM_WATCHA_IMPORT] import_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("왓챠피디아 DB 가져오기 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return {"error": traceback.format_exc()}
    finally:
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def _watcha_percent_label(value, total):
    try:
        percent = 100.0 * float(value or 0) / float(max(1, int(total or 0)))
    except Exception:
        percent = 0.0
    text = ("%.2f" % percent).rstrip("0").rstrip(".")
    return "%s%%" % (text or "0")


def _watcha_status_title_key(value):
    """Normalize a title exactly like the Home Watcha display lookup."""
    try:
        import re
        import unicodedata
        s = unicodedata.normalize("NFKC", str(value or "").strip().lower())
        if not s:
            return ""
        return re.sub(r"[\s\-_:;,.!?\'\"~`·•()\[\]{}]+", "", s)
    except Exception:
        return ""


def _watcha_current_movie_status_fast(conn):
    """Count movies that can actually display a Watcha rating on Home/Info.

    v1585 counted only an exact rating_key join.  The imported watcha_build.db
    was built from an older Plex snapshot, so most current Plex rating keys are
    different even though Home correctly finds the rating by normalized
    title+year.  This routine now mirrors the real display lookup:
      1) exact rating_key
      2) normalized current title/original title + year
         against Watcha source title/original title/Watcha title + year

    It bulk-loads only positive Watcha rows and current movie identity columns;
    no network access and no per-movie SQL query.
    """
    started = time.time()
    total = 0
    confirmed = 0
    exact_count = 0
    title_year_count = 0
    try:
        cols = set([str(r[1]) for r in conn.execute("PRAGMA table_info(items)").fetchall()])
        if "plex_type" in cols:
            movie_where = "plex_type='movie'"
        elif "kodi_type" in cols:
            movie_where = "kodi_type='movie'"
        else:
            movie_where = "1=1"

        watcha_rows = conn.execute("""
            SELECT rating_key, title, original_title, watcha_title, year
            FROM watcha_ratings
            WHERE watcha_rating IS NOT NULL AND CAST(watcha_rating AS REAL) > 0
        """).fetchall()
        by_rk = set()
        by_title_year = set()
        for row in watcha_rows:
            rk = str(row[0] or "").strip()
            if rk:
                by_rk.add(rk)
            year = str(row[4] or "").strip()
            if not year:
                continue
            for name in (row[1], row[2], row[3]):
                key = _watcha_status_title_key(name)
                if key:
                    by_title_year.add((key, year))

        item_rows = conn.execute(
            "SELECT rating_key, title, original_title, year FROM items WHERE %s" % movie_where
        ).fetchall()
        total = len(item_rows)
        for row in item_rows:
            rk = str(row[0] or "").strip()
            if rk and rk in by_rk:
                confirmed += 1
                exact_count += 1
                continue
            year = str(row[3] or "").strip()
            if not year:
                continue
            matched = False
            for name in (row[1], row[2]):
                key = _watcha_status_title_key(name)
                if key and (key, year) in by_title_year:
                    matched = True
                    break
            if matched:
                confirmed += 1
                title_year_count += 1
    except Exception:
        log("[PKM_WATCHA_IMPORT] fast_status_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    confirmed = min(max(0, confirmed), max(0, total))
    log(
        "[PKM_WATCHA_IMPORT] display_equivalent_status elapsed=%.3f total=%d confirmed=%d exact_rk=%d title_year=%d watcha_positive=%d" % (
            time.time() - started,
            total,
            confirmed,
            exact_count,
            title_year_count,
            len(watcha_rows) if 'watcha_rows' in locals() else 0,
        ),
        xbmc.LOGINFO,
    )
    return total, confirmed, max(0, total - confirmed)


def _watcha_status_vertical_text(total, confirmed, unconfirmed):
    return (
        "전체 영화 : %d개\n"
        "평점 확인 : %d개\n"
        "평점 미확인 : %d개\n"
        "매칭율 : %s"
    ) % (total, confirmed, unconfirmed, _watcha_percent_label(confirmed, total))


def watcha_show_match_summary_from_settings(params=None):
    conn = None
    started = time.time()
    try:
        conn = init_db()
        from resources.lib import pkm_watcha_import
        pkm_watcha_import.init_watcha_schema(conn)
        row = conn.execute("SELECT COUNT(*) FROM watcha_ratings").fetchone()
        imported = int(row[0] or 0) if row else 0
        if imported <= 0:
            _open_pkm_message_dialog(
                "왓챠피디아 평점 DB",
                "watcha_ratings 테이블이 비어 있습니다.\n\n먼저 watcha_rate_build.db 가져오기를 실행해 주세요.",
                ok_label="닫기",
            )
            return {"error": "watcha_not_ready"}
        total, confirmed, unconfirmed = _watcha_current_movie_status_fast(conn)
        text = _watcha_status_vertical_text(total, confirmed, unconfirmed)
        _open_pkm_message_dialog("왓챠피디아 평점 DB 상태", text, ok_label="닫기")
        stats = {
            "PKM_MOVIE_ROWS": total,
            "RATING_CONFIRMED": confirmed,
            "RATING_UNCONFIRMED": unconfirmed,
            "matched_percent": (100.0 * confirmed / total) if total else 0.0,
            "imported_rows": imported,
        }
        log("[PKM_WATCHA_IMPORT] fast_summary elapsed=%.3f stats=%s" % (time.time() - started, stats), xbmc.LOGINFO)
        return stats
    except Exception:
        log("[PKM_WATCHA_IMPORT] summary_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            _open_pkm_message_dialog("왓챠피디아 평점 DB 상태 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        except Exception:
            pass
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def _pkm_recent_movie_rows(conn, limit=100):
    try:
        limit = max(1, min(500, int(limit or 100)))
    except Exception:
        limit = 100
    cols = set([str(r[1]) for r in conn.execute("PRAGMA table_info(items)").fetchall()])
    if "rating_key" not in cols or "title" not in cols:
        return []
    movie_where = "plex_type='movie'" if "plex_type" in cols else "kodi_type='movie'" if "kodi_type" in cols else "1=1"
    original_expr = "original_title" if "original_title" in cols else "'' AS original_title"
    year_expr = "year" if "year" in cols else "'' AS year"
    added_expr = "COALESCE(added_at,0)" if "added_at" in cols else "0"
    return conn.execute(
        "SELECT rating_key,title,%s,%s,%s AS added_at FROM items WHERE %s ORDER BY %s DESC, rating_key DESC LIMIT ?" % (
            original_expr, year_expr, added_expr, movie_where, added_expr
        ),
        (limit,),
    ).fetchall()


def _watcha_positive_maps(conn):
    rows = conn.execute(
        "SELECT rating_key,title,original_title,watcha_title,year,watcha_year,watcha_rating,watcha_count FROM watcha_ratings WHERE watcha_rating IS NOT NULL AND CAST(watcha_rating AS REAL)>0"
    ).fetchall()
    by_rk = {}
    by_title_year = {}
    for row in rows:
        rk = str(row[0] or "").strip()
        if rk and rk not in by_rk:
            by_rk[rk] = row
        source_years = []
        for y in (row[4], row[5]):
            ys = str(y or "").strip()
            if ys and ys not in source_years:
                source_years.append(ys)
        for name in (row[1], row[2], row[3]):
            key = _watcha_status_title_key(name)
            if not key:
                continue
            for ys in source_years:
                by_title_year.setdefault((key, ys), row)
    return by_rk, by_title_year


def _watcha_match_recent_row(item_row, by_rk, by_title_year):
    rk = str(item_row[0] or "").strip()
    if rk and rk in by_rk:
        return by_rk[rk]
    year = str(item_row[3] or "").strip()
    if not year:
        return None
    for name in (item_row[1], item_row[2]):
        key = _watcha_status_title_key(name)
        if key and (key, year) in by_title_year:
            return by_title_year[(key, year)]
    return None


def watcha_show_recent_target_summary_from_settings(params=None):
    conn = None
    started = time.time()
    try:
        conn = init_db()
        from resources.lib import pkm_watcha_import
        pkm_watcha_import.init_watcha_schema(conn)
        by_rk, by_title_year = _watcha_positive_maps(conn)
        items = _pkm_recent_movie_rows(conn, limit=100)
        total = len(items)
        confirmed = sum(1 for item in items if _watcha_match_recent_row(item, by_rk, by_title_year))
        unconfirmed = max(0, total - confirmed)
        text = (
            "최근 추가 영화 : %d개\n"
            "평점 확인 : %d개\n"
            "평점 미확인 : %d개\n"
            "매칭율 : %s"
        ) % (total, confirmed, unconfirmed, _watcha_percent_label(confirmed, total))
        _open_pkm_message_dialog("왓챠피디아 최근 추가 영화", text, ok_label="닫기")
        result = {"RECENT_MOVIES": total, "RATING_CONFIRMED": confirmed, "RATING_UNCONFIRMED": unconfirmed}
        log("[PKM_WATCHA_IMPORT] recent_target_fast elapsed=%.3f stats=%s" % (time.time() - started, result), xbmc.LOGINFO)
        return result
    except Exception:
        log("[PKM_WATCHA_IMPORT] target_summary_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        _open_pkm_message_dialog("왓챠피디아 최근 추가 영화 확인 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def watcha_show_recent_match_test_from_settings(params=None):
    conn = None
    try:
        conn = init_db()
        from resources.lib import pkm_watcha_import
        pkm_watcha_import.init_watcha_schema(conn)
        by_rk, by_title_year = _watcha_positive_maps(conn)
        samples = []
        for item in _pkm_recent_movie_rows(conn, limit=180):
            match = _watcha_match_recent_row(item, by_rk, by_title_year)
            if not match:
                continue
            rating = ("%.2f" % float(match[6])).rstrip("0").rstrip(".")
            try:
                count = int(float(match[7] or 0))
            except Exception:
                count = 0
            samples.append({
                "title": str(item[1] or "제목 없음"),
                "year": str(item[3] or ""),
                "rating": rating,
                "count": count,
            })
            if len(samples) >= 3:
                break
        if not samples:
            _open_pkm_message_dialog("왓챠피디아 매칭 테스트", "최근 추가 영화 중 왓챠피디아 평점 확인 항목이 없습니다.", ok_label="닫기")
            return {}
        lines = ["최근 추가 영화 중 왓챠피디아 평점 확인 항목", ""]
        for idx, sample in enumerate(samples, 1):
            suffix = " (%s)" % sample["year"] if sample["year"] else ""
            lines.append("%d. %s%s" % (idx, sample["title"], suffix))
            lines.append("   평점 %s  평가 %s명" % (sample["rating"], format(sample["count"], ",")))
            if idx < len(samples):
                lines.append("")
        _open_pkm_message_dialog("왓챠피디아 매칭 테스트", "\n".join(lines), ok_label="닫기")
        log("[PKM_WATCHA_IMPORT] recent_match_test samples=%s" % samples, xbmc.LOGINFO)
        return {"samples": samples}
    except Exception:
        log("[PKM_WATCHA_IMPORT] recent_match_test_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        _open_pkm_message_dialog("왓챠피디아 매칭 테스트 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def watcha_show_build_script_notice_from_settings(params=None):
    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    lines = []
    lines.append("왓챠피디아 빌드 스크립트")
    lines.append("")
    lines.append("Kodi 내부에서는 Playwright 크롤링을 실행하지 않습니다.")
    lines.append("외부 PC/NAS에서 plex_km.db와 함께 아래 스크립트를 실행해 watcha_rate_build.db를 만든 뒤, 왓챠피디아 평점 DB 가져오기를 실행하세요.")
    lines.append("")
    lines.append("포함 스크립트:")
    lines.append("resources/lib/pkm_watcha_build_fix11.py")
    lines.append("")
    lines.append("권장 결과 파일명:")
    lines.append("watcha_rate_build.db")
    lines.append("")
    lines.append("가져오면 PKM plex_km.db 안의 watcha_ratings 테이블로 저장됩니다.")
    lines.append("파일명이 watcha_rate_build.db가 아니면 가져오지 않습니다.")
    try:
        _open_pkm_message_dialog("왓챠피디아 수집 및 갱신 안내", "\n".join(lines), ok_label="닫기")
    except Exception:
        pass
    return {"profile": profile_dir}

def _cine21_count_new_match_candidates(conn):
    """Count PKM movie rows that do not have a cine21_matches row yet."""
    try:
        cols = set([str(r[1]) for r in conn.execute("PRAGMA table_info(items)").fetchall()])
        if "rating_key" not in cols:
            return 0
        movie_where = "i.plex_type='movie'" if "plex_type" in cols else "i.kodi_type='movie'" if "kodi_type" in cols else "1=1"
        row = conn.execute("""
            SELECT COUNT(*)
            FROM items i
            LEFT JOIN cine21_matches cm
              ON CAST(cm.rating_key AS TEXT)=CAST(i.rating_key AS TEXT)
            WHERE %s
              AND cm.rating_key IS NULL
        """ % movie_where).fetchone()
        return int(row[0] or 0)
    except Exception:
        return -1


def _cine21_match_measure_popup_text(stats, elapsed_sec, before_new, after_new):
    total, confirmed, unconfirmed = _cine21_import_summary_values(stats)
    per_item = (float(elapsed_sec) / float(total)) if total else 0.0
    speed = (float(total) / float(elapsed_sec)) if elapsed_sec > 0 else 0.0
    lines = []
    lines.append("씨네21 매칭 DB 생성/갱신 시간 측정 완료")
    lines.append("")
    lines.append("소요 시간: %.2f초" % float(elapsed_sec))
    lines.append("처리 속도: %.0f개/초, %.4f초/개" % (speed, per_item))
    lines.append("")
    lines.append("전체 영화 : %d개" % total)
    lines.append("평점 확인 : %d개" % confirmed)
    lines.append("평점 미확인 : %d개" % unconfirmed)
    lines.append("매칭율 : %s" % _cine21_import_percent_label(confirmed, total))
    lines.append("")
    lines.append("측정 전 미매칭DB 후보: %s개" % (before_new if before_new >= 0 else "확인불가"))
    lines.append("측정 후 미매칭DB 후보: %s개" % (after_new if after_new >= 0 else "확인불가"))
    lines.append("")
    if elapsed_sec <= 10.0:
        lines.append("판단: 전체 매칭은 짧은 편입니다. 그래도 시작 시 자동 실행은 보류하고 설정 수동 실행으로 먼저 안정화가 맞습니다.")
    elif elapsed_sec <= 60.0:
        lines.append("판단: 시작 시 자동 실행은 체감 지연 가능성이 있습니다. 설정 수동 실행 우선이 맞습니다.")
    else:
        lines.append("판단: 시작 시 자동 실행 금지. 설정 수동 실행만 권장합니다.")
    return "\n".join(lines)


def cine21_measure_match_db_from_settings(params=None):
    """Measure Cine21 match-table rebuild time using local DB only.

    This is an explicit settings action. It does not touch Wall/Info, does not
    call Cine21 network, and does not run on Kodi startup. The purpose is to
    decide later whether incremental updates can be started automatically or
    should remain settings-only.
    """
    conn = None
    progress = None
    started = time.time()
    try:
        from resources.lib import pkm_cine21_import
        conn = init_db()
        status = pkm_cine21_import.get_db_status(conn)
        if int(status.get("ratings_count", 0) or 0) <= 0:
            _open_pkm_message_dialog(
                "씨네21 매칭 DB 시간 측정",
                "cine21_ratings 테이블이 없습니다.\n\n먼저 cine21_rate_build.db 가져오기 또는 씨네21 평점 DB 새로 생성을 실행해 주세요.",
                ok_label="닫기",
            )
            log("[PKM_CINE21_IMPORT] match_measure_not_ready status=%s" % status, xbmc.LOGINFO)
            return {"error": "ratings_not_ready"}

        before_new = _cine21_count_new_match_candidates(conn)
        progress = _create_pkm_sync_progress()
        progress_create(progress, "씨네21 매칭 DB 시간 측정", "로컬 DB 기준 매칭 테이블 생성 준비 중\n네트워크 호출 없음")

        def _progress_cb(percent, message):
            progress_update(progress, int(percent or 0), message)

        log("[PKM_CINE21_IMPORT] match_measure_begin status=%s" % status, xbmc.LOGINFO)
        t0 = time.time()
        stats = pkm_cine21_import.build_matches(conn, progress_cb=_progress_cb)
        elapsed = max(0.0, time.time() - t0)
        after_new = _cine21_count_new_match_candidates(conn)
        now_text = time.strftime("%Y-%m-%d %H:%M:%S")
        try:
            with conn:
                conn.execute("INSERT OR REPLACE INTO cine21_match_summary(key,value,updated_at) VALUES(?,?,?)", ("MATCH_BUILD_LAST_ELAPSED_SEC", "%.3f" % elapsed, now_text))
                conn.execute("INSERT OR REPLACE INTO cine21_match_summary(key,value,updated_at) VALUES(?,?,?)", ("MATCH_BUILD_LAST_AT", now_text, now_text))
                conn.execute("INSERT OR REPLACE INTO cine21_match_summary(key,value,updated_at) VALUES(?,?,?)", ("MATCH_BUILD_LAST_NEW_CANDIDATES_BEFORE", str(before_new), now_text))
                conn.execute("INSERT OR REPLACE INTO cine21_match_summary(key,value,updated_at) VALUES(?,?,?)", ("MATCH_BUILD_LAST_NEW_CANDIDATES_AFTER", str(after_new), now_text))
        except Exception:
            log("[PKM_CINE21_IMPORT] match_measure_summary_save_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)

        text = _cine21_match_measure_popup_text(stats, elapsed, before_new, after_new)
        progress_update(progress, 100, "씨네21 매칭 DB 시간 측정 완료\n소요 %.2f초" % elapsed)
        try:
            time.sleep(0.35)
        except Exception:
            pass
        log("[PKM_CINE21_IMPORT] match_measure_done elapsed=%.3f stats=%s before_new=%s after_new=%s" % (elapsed, stats, before_new, after_new), xbmc.LOGINFO)
        _open_pkm_message_dialog("씨네21 매칭 DB 시간 측정", text, ok_label="닫기")
        return dict(stats, elapsed_sec=elapsed, new_candidates_before=before_new, new_candidates_after=after_new, total_elapsed_sec=max(0.0, time.time() - started))
    except Exception:
        log("[PKM_CINE21_IMPORT] match_measure_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            _open_pkm_message_dialog("씨네21 매칭 DB 시간 측정 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        except Exception:
            pass
        return {"error": traceback.format_exc()}
    finally:
        try:
            if progress is not None:
                progress.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

def cine21_show_match_summary_from_settings(params=None):
    conn = None
    try:
        conn = init_db()
        from resources.lib import pkm_cine21_import
        db_status = pkm_cine21_import.get_db_status(conn)
        stats = db_status.get("summary") or {}
        if not db_status.get("is_built") or not stats:
            ratings = int(db_status.get("ratings_count", 0) or 0)
            matches = int(db_status.get("matches_count", 0) or 0)
            message = (
                "씨네21 평점 DB가 아직 생성되지 않았습니다.\n\n"
                "먼저 아래 중 하나를 실행해 주세요.\n"
                "- cine21_rate_build.db 가져오기\n"
                "- 씨네21 평점 DB 새로 생성 (2시간 이상)\n\n"
                "현재 상태: ratings %d개 / matches %d개"
            ) % (ratings, matches)
            _open_pkm_message_dialog("씨네21 평점 DB", message, ok_label="닫기")
            log("[PKM_CINE21_IMPORT] summary_not_built status=%s" % db_status, xbmc.LOGINFO)
            return {}
        try:
            row = conn.execute("""
                SELECT COUNT(*)
                FROM cine21_matches
                WHERE match_status='MATCHED'
                  AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
            """).fetchone()
            stats = dict(stats)
            stats["RATING_CONFIRMED"] = int(row[0] or 0) if row else 0
        except Exception:
            pass
        text = _cine21_import_status_detail_text(stats)
        _open_pkm_message_dialog("씨네21 평점 DB 상태", text, ok_label="닫기")
        log("[PKM_CINE21_IMPORT] summary stats=%s status=%s" % (stats, db_status), xbmc.LOGINFO)
        return stats
    except Exception:
        log("[PKM_CINE21_IMPORT] summary_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        notify("씨네21 DB 상태 확인 실패", "kodi.log를 확인하세요", icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass



def cine21_show_recent_target_summary_from_settings(params=None):
    conn = None
    try:
        conn = init_db()
        from resources.lib import pkm_cine21_import
        status = pkm_cine21_import.get_db_status(conn)
        if not status.get("is_built"):
            _open_pkm_message_dialog(
                "씨네21 최근 추가 영화",
                "씨네21 평점 DB가 준비되지 않았습니다.\n\n먼저 cine21_rate_build.db 가져오기를 실행해 주세요.",
                ok_label="닫기",
            )
            return {}
        items = _pkm_recent_movie_rows(conn, limit=100)
        total = len(items)
        keys = [str(row[0] or "").strip() for row in items if str(row[0] or "").strip()]
        confirmed_keys = set()
        if keys:
            for start in range(0, len(keys), 400):
                part = keys[start:start + 400]
                q = ",".join(["?"] * len(part))
                rows = conn.execute(
                    "SELECT rating_key FROM cine21_matches WHERE rating_key IN (%s) AND match_status='MATCHED' AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)" % q,
                    part,
                ).fetchall()
                confirmed_keys.update(str(r[0] or "").strip() for r in rows)
        confirmed = sum(1 for row in items if str(row[0] or "").strip() in confirmed_keys)
        unconfirmed = max(0, total - confirmed)
        text = (
            "최근 추가 영화 : %d개\n"
            "평점 확인 : %d개\n"
            "평점 미확인 : %d개\n"
            "매칭율 : %s"
        ) % (total, confirmed, unconfirmed, _cine21_import_percent_label(confirmed, total))
        _open_pkm_message_dialog("씨네21 최근 추가 영화", text, ok_label="닫기")
        return {"RECENT_MOVIES": total, "RATING_CONFIRMED": confirmed, "RATING_UNCONFIRMED": unconfirmed}
    except Exception:
        log("[PKM_CINE21_IMPORT] recent_target_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        _open_pkm_message_dialog("씨네21 최근 추가 영화 확인 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


CINE21_LOGO_ICON = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/cine21/cine21_logo_meta.png"
CINE21_CRITIC_ICON = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/cine21/cine21_critic_meta.png"
CINE21_AUDIENCE_ICON = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/cine21/cine21_audience_meta.png"

def _cine21_rating_sample_popup_text(samples):
    """Fallback text for Kodi OK dialog only."""
    lines = []
    lines.append("최근 추가 영화 중 씨네21 평점 매칭 항목")
    lines.append("")
    for idx, item in enumerate(samples or [], 1):
        row = _cine21_rating_sample_popup_row(item, idx)
        lines.append("%s  전문가 %s / 관객 %s" % (row.get("title", ""), row.get("critic", "-"), row.get("audience", "-")))
    return "\n".join(lines)


def _cine21_rating_sample_popup_row(item, idx):
    title = item.get("title") or item.get("cine21_title") or "제목 없음"
    year = item.get("year") or ""
    cine_title = item.get("cine21_title") or ""
    critic = item.get("critic_rating")
    audience = item.get("audience_rating")
    critic = "-" if critic is None or critic == "" else str(critic)
    audience = "-" if audience is None or audience == "" else str(audience)
    suffix = " (%s)" % year if year else ""
    return {
        "title": "%d. %s%s" % (idx, title, suffix),
        "cine_title": cine_title,
        "critic": critic,
        "audience": audience,
    }


def _cine21_rating_sample_popup_rows(samples):
    return [_cine21_rating_sample_popup_row(item, idx) for idx, item in enumerate(samples or [], 1)]

def _pkm_main_db_ready_for_cine21(conn):
    try:
        path = db_path()
        size = _safe_file_size(path)
        item_cols = set([str(r[1]) for r in conn.execute("PRAGMA table_info(items)").fetchall()])
        match_cols = set([str(r[1]) for r in conn.execute("PRAGMA table_info(cine21_matches)").fetchall()])
        item_count = 0
        match_count = 0
        if "rating_key" in item_cols:
            item_count = int(conn.execute("SELECT COUNT(*) FROM items").fetchone()[0] or 0)
        if "rating_key" in match_cols:
            match_count = int(conn.execute("SELECT COUNT(*) FROM cine21_matches").fetchone()[0] or 0)
        ready = bool(size > 0 and item_count > 0 and match_count > 0)
        return ready, {"path": path, "size": size, "item_count": item_count, "match_count": match_count}
    except Exception:
        return False, {"path": db_path(), "size": _safe_file_size(db_path()), "error": traceback.format_exc()}


def _cine21_recent_match_test_samples(conn, limit=3):
    """Return a few recent movie match samples from local DB only.

    v785: Use the tuple-safe helper in pkm_cine21_import.  This path is
    SELECT-only and bounded by LIMIT 3. It never rebuilds matches, never calls
    Cine21 network, and never updates Home/Info.
    """
    from resources.lib import pkm_cine21_import
    status = pkm_cine21_import.get_db_status(conn)
    if not status.get("is_built"):
        return None, status
    samples = pkm_cine21_import.get_recent_matched_samples(conn, limit=limit)
    return samples, status

def cine21_show_recent_match_test_from_settings(params=None):
    """Show recent Cine21 match samples as a settings-local popup only.

    Root-cause fix for v778 freeze: no progress window, no PKM notification,
    no background rebuild, no network, no Home notice.  It only checks existing
    cine21_matches with a bounded SELECT and opens the same close-button popup
    used by settings status.
    """
    conn = None
    try:
        t0 = time.time()
        log("[PKM_CINE21_IMPORT] recent_match_test_begin mode=select_only", xbmc.LOGINFO)
        conn = init_db()
        db_ready, db_health = _pkm_main_db_ready_for_cine21(conn)
        if not db_ready:
            log("[PKM_CINE21_IMPORT] recent_match_test_db_not_ready health=%s" % db_health, xbmc.LOGWARNING)
            _open_pkm_message_dialog(
                "씨네21 매칭 테스트",
                "PKM 메인 DB가 아직 준비되지 않았습니다.\n\n"
                "plex_km.db 크기: %s bytes\n"
                "PKM items: %s개 / cine21_matches: %s개\n\n"
                "먼저 PKM 라이브러리 싱크와 씨네21 DB 가져오기를 다시 실행해 주세요."
                % (db_health.get("size", -1), db_health.get("item_count", 0), db_health.get("match_count", 0)),
                ok_label="닫기",
            )
            return {"error": "main_db_not_ready", "health": db_health}
        samples, status = _cine21_recent_match_test_samples(conn, limit=3)
        log("[PKM_CINE21_IMPORT] recent_match_test_select_done elapsed_ms=%.1f samples=%s status_built=%s" % ((time.time() - t0) * 1000.0, len(samples or []), bool(status.get("is_built"))), xbmc.LOGINFO)
        if samples is None:
            ratings = int(status.get("ratings_count", 0) or 0)
            matches = int(status.get("matches_count", 0) or 0)
            message = (
                "씨네21 평점 DB가 아직 생성되지 않았습니다.\n\n"
                "먼저 아래 중 하나를 실행해 주세요.\n"
                "- cine21_rate_build.db 가져오기\n"
                "- 씨네21 평점 DB 새로 생성 (2시간 이상)\n\n"
                "현재 상태: ratings %d개 / matches %d개"
            ) % (ratings, matches)
            _open_pkm_message_dialog("씨네21 매칭 테스트", message, ok_label="닫기")
            log("[PKM_CINE21_IMPORT] recent_match_test_not_built status=%s" % status, xbmc.LOGINFO)
            return {}
        if not samples:
            _open_pkm_message_dialog("씨네21 매칭 테스트", "최근 추가 영화 중 씨네21 평점 매칭 항목이 없습니다.", ok_label="닫기")
            log("[PKM_CINE21_IMPORT] recent_match_test_empty", xbmc.LOGINFO)
            return {}
        text = _cine21_rating_sample_popup_text(samples)
        try:
            _settings_flow_module().open_pkm_cine21_match_dialog(
                "씨네21 매칭 테스트",
                _cine21_rating_sample_popup_rows(samples),
                ok_label="닫기",
                logo_icon=CINE21_LOGO_ICON,
                critic_icon=CINE21_CRITIC_ICON,
                audience_icon=CINE21_AUDIENCE_ICON,
            )
        except Exception:
            log("[PKM_CINE21_IMPORT] recent_match_test_custom_dialog_failed fallback_ok\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            xbmcgui.Dialog().ok("씨네21 매칭 테스트", text)
        log("[PKM_CINE21_IMPORT] recent_match_test samples=%s" % samples, xbmc.LOGINFO)
        return {"samples": samples}
    except Exception:
        log("[PKM_CINE21_IMPORT] recent_match_test_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            _open_pkm_message_dialog("씨네21 매칭 테스트 실패", "kodi.log를 확인하세요.", ok_label="닫기")
        except Exception:
            pass
        return {"error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass



def pkm_seek_quick_action(params=None):
    """v1315/v1316: keymap-driven fullscreen LEFT/RIGHT seek request.

    The action only updates shared seek target properties; service.py commits
    the latest target with Player.seekTime().  Never stop/pause/play here.
    """
    try:
        try:
            log("PKM_SEEK_QUICK_ACTION_DISPATCH params=%s argv=%s" % (params or {}, sys.argv), xbmc.LOGINFO)
        except Exception:
            pass
        from resources.lib import pkm_seek_quick
        return pkm_seek_quick.request(params or {})
    except Exception:
        log("PKM_SEEK_QUICK_ACTION_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False

class PKMReturnFadeOverlayWindowV1505(xbmcgui.WindowXMLDialog):
    """v1557/v1505 top-layer fade over the live Kodi video surface.

    This dialog is deliberately visual-only.  It does not pause, seek, stop,
    rebuild Home, or mutate playback state from a worker thread.  Its single
    black image fades in above the still-running DXVA video surface.
    """
    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        return

    def onClick(self, control_id):
        audit_event(self, "onClick", control_id=control_id)
        return


def _pkm_open_return_video_fade_overlay_v1557(token=""):
    overlay = None
    try:
        addon_path = ADDON.getAddonInfo("path")
        overlay = PKMReturnFadeOverlayWindowV1505(
            "plexkm_return_fade_overlay_v1505.xml",
            addon_path,
            "Default",
            "1080i",
        )
        overlay.show()
        # v1944: one short frame is sufficient; do not hold live playback.
        xbmc.sleep(20)
        log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_OPENED_V1557 token=%s layer=WindowXMLDialog over_live_video=1" % (token or ""), xbmc.LOGINFO)
        return overlay
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_OPEN_FAILED_V1557 token=%s\n%s" % (token or "", traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass
        try:
            if overlay:
                overlay.close()
        except Exception:
            pass
        return None


def _pkm_wait_return_home_ready_v1557(max_ms=1800):
    """Wait until Kodi has left the real video surface before dialog close.

    The old v1501 crash risk came from closing the dynamic dialog while DXVA
    FullscreenVideo was still being torn down.  The stabilized v1505 rule is
    retained: keep the dialog fully black until both Player.HasMedia and the
    fullscreen window are gone, with a bounded timeout.
    """
    try:
        start = int(time.time() * 1000)
        while int(time.time() * 1000) - start < int(max_ms):
            if (not xbmc.getCondVisibility("Player.HasMedia")) and (not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")):
                return True
            xbmc.sleep(60)
    except Exception:
        pass
    return False


def _pkm_close_return_video_fade_overlay_v1557(overlay, token=""):
    if not overlay:
        return
    try:
        overlay.close()
        xbmc.sleep(20)
        log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_CLOSED_V1557 token=%s close_mode=instant_after_home_cover" % (token or ""), xbmc.LOGINFO)
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_DIALOG_CLOSE_FAILED_V1557 token=%s\n%s" % (token or "", traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass


def _pkm_clear_return_video_fade_state_v1557(token="", include_back_stop=True):
    try:
        w = xbmcgui.Window(10000)
        active_token = w.getProperty("PlexKM.Playback.ReturnFade.Token") or ""
        if token and active_token and active_token != token:
            return
        keys = [
            "PlexKM.Playback.ReturnFade",
            "PlexKM.Playback.ReturnFade.Stopping",
            "PlexKM.Playback.ReturnFade.Token",
            "PlexKM.Playback.ReturnFade.Source",
            "PlexKM.Playback.ReturnFade.StartedAtMs",
            "PlexKM.Playback.ReturnFade.FadeStartedAtMs",
            "PlexKM.Playback.ReturnFade.PauseHold",
            "PlexKM.Playback.ReturnFade.SuppressPreread",
            "PlexKM.Playback.ReturnFade.DialogMode",
            "PlexKM.Playback.ReturnFade.DialogActive",
            "PlexKM.Playback.ReturnFade.TopLayer",
            "PlexKM.Playback.ReturnFade.HomeCoverReady",
            "PlexKM.Playback.ReturnInfoReadyV1939",
        ]
        if include_back_stop:
            keys.append("PlexKM.Playback.BackStopRequested")
        for key in keys:
            try:
                w.clearProperty(key)
            except Exception:
                pass
    except Exception:
        pass


def pkm_playback_return_fade_stop(params=None):
    """v1557: restore the proven v1505 live-video fade, then native Stop.

    Visible sequence:
      live video continues -> black WindowXMLDialog fades over that video ->
      fully black -> one PlayerControl(Stop) -> Home cover is primed ->
      dialog closes only after FullscreenVideo teardown -> Home cover clears.

    There is no Action(Pause), no seek, no direct HTTP playback change, no
    onInit stop heuristic, and no background-thread GUI mutation.
    """
    params = params or {}
    source = str(params.get("source") or "fullscreen_back")
    token = "%s:%d" % (source, int(time.time() * 1000))
    # v1944: fast return.  Keep only a short cover to prevent a raw video/home
    # frame flash; do not reuse the much longer cinematic fade used previously.
    fade_start_delay_ms = 0
    fade_ms = 180
    post_fade_hold_ms = 0
    stop_settle_max_ms = 1100
    home_cover_prime_ms = 20
    # v2125: once the restored PKM surface reports Ready, keep the fully black
    # top layer for a small native-bind margin before starting the Home/Info
    # cover fade.  This prevents fanart (texture-ready first) from becoming
    # visible a frame before its metadata labels.
    return_surface_settle_hold_ms_v2125 = 120
    home_fadeout_ms = 0
    overlay = None
    win = None
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Playback.ReturnFade.Stopping") == "1":
            log("PLAYBACK_RETURN_VIDEO_FADE_SKIP_V1557 reason=already_stopping source=%s" % source, xbmc.LOGINFO)
            return True
        inline_return_pending_v1939 = win.getProperty("PlexKM.Playback.ReturnInline.Pending") == "1"

        # Mark stop before any delay so leaked Back and preread workers cannot
        # start a second exit path while the visible fade is running.
        win.setProperty("PlexKM.Playback.ReturnFade.Stopping", "1")
        win.setProperty("PlexKM.Playback.ReturnFade.Token", token)
        win.setProperty("PlexKM.Playback.ReturnFade.Source", source)
        win.setProperty("PlexKM.Playback.ReturnFade.StartedAtMs", str(int(time.time() * 1000)))
        win.clearProperty("PlexKM.Playback.ReturnFade.PauseHold")
        win.setProperty("PlexKM.Playback.ReturnFade.SuppressPreread", "1")
        win.setProperty("PlexKM.Playback.ReturnFade.DialogMode", "1")
        win.clearProperty("PlexKM.Playback.ReturnFade.DialogActive")
        win.clearProperty("PlexKM.Playback.ReturnFade.TopLayer")
        win.clearProperty("PlexKM.Playback.ReturnFade.HomeCoverReady")
        win.clearProperty("PlexKM.Playback.ReturnInfoReadyV1939")
        win.setProperty("PlexKM.Playback.BackStopRequested", "1")

        try:
            from resources.lib import pkm_seek_quick as _pkm_return_sq
            if hasattr(_pkm_return_sq, "cancel_manual_preread"):
                _pkm_return_sq.cancel_manual_preread(reason="ReturnVideoFadeStopNoPauseV1557")
                log("PLAYBACK_RETURN_VIDEO_FADE_CANCEL_PREREAD_V1557 source=%s token=%s" % (source, token), xbmc.LOGINFO)
        except Exception:
            try:
                log("PLAYBACK_RETURN_VIDEO_FADE_CANCEL_PREREAD_FAILED_V1557 source=%s token=%s\n%s" % (source, token, traceback.format_exc()), xbmc.LOGWARNING)
            except Exception:
                pass

        was_playing = bool(xbmc.getCondVisibility("Player.Playing"))
        was_paused = bool(xbmc.getCondVisibility("Player.Paused"))
        log("PLAYBACK_RETURN_VIDEO_FADE_BEGIN_V1557 source=%s token=%s was_playing=%s was_paused=%s live_video_continues=1 forced_pause=0 seek=0 fade_start_delay_ms=%d fade_ms=%d dialog_overlay=1 stop_after_black=1" % (
            source, token,
            "1" if was_playing else "0",
            "1" if was_paused else "0",
            fade_start_delay_ms, fade_ms
        ), xbmc.LOGINFO)

        # Keep the movie running.  The black image itself fades over the real
        # FullscreenVideo/DXVA frame, which is the v1505 PASS architecture.
        xbmc.sleep(fade_start_delay_ms)
        overlay = _pkm_open_return_video_fade_overlay_v1557(token=token)
        if overlay is None:
            # Never leave playback stuck merely because the visual dialog failed.
            try:
                xbmc.executebuiltin("PlayerControl(Stop)")
            except Exception:
                pass
            log("PLAYBACK_RETURN_VIDEO_FADE_FALLBACK_NATIVE_STOP_V1557 source=%s token=%s reason=dialog_open_failed" % (source, token), xbmc.LOGWARNING)
            _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
            return False

        try:
            w = xbmcgui.Window(10000)
            if w.getProperty("PlexKM.Playback.ReturnFade.Token") == token:
                w.setProperty("PlexKM.Playback.ReturnFade.DialogActive", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.TopLayer", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.FadeStartedAtMs", str(int(time.time() * 1000)))
        except Exception:
            pass

        # Stop only after the live video has become fully black.
        xbmc.sleep(fade_ms + post_fade_hold_ms)
        try:
            xbmc.executebuiltin("PlayerControl(Stop)")
        except Exception:
            pass
        log("PLAYBACK_RETURN_VIDEO_FADE_STOP_AFTER_BLACK_V1557 source=%s token=%s command=PlayerControl(Stop) forced_pause=0" % (source, token), xbmc.LOGINFO)

        # Prime the Home/Info black cover underneath the dialog.  The dynamic
        # dialog stays fully black while Kodi tears down FullscreenVideo.
        try:
            w = xbmcgui.Window(10000)
            if w.getProperty("PlexKM.Playback.ReturnFade.Token") == token:
                w.clearProperty("PlexKM.Playback.ReturnFade.DialogMode")
                w.setProperty("PlexKM.Playback.ReturnFade", "1")
                w.setProperty("PlexKM.Playback.ReturnFade.HomeCoverReady", "1")
        except Exception:
            pass

        settled = _pkm_wait_return_home_ready_v1557(max_ms=stop_settle_max_ms)

        # v1939: Inline Info is rebuilt only after FullscreenVideo teardown.
        # Keep the fully black top-layer dialog until that completed Info surface
        # is atomically published; closing it earlier exposed one Home frame.
        info_ready_v1939 = False
        info_wait_ms_v1939 = 0
        if inline_return_pending_v1939:
            wait_start_v1939 = int(time.time() * 1000)
            max_info_wait_ms_v1939 = 1500
            while int(time.time() * 1000) - wait_start_v1939 < max_info_wait_ms_v1939:
                try:
                    if win.getProperty("PlexKM.Playback.ReturnInfoReadyV1939") == "1":
                        info_ready_v1939 = True
                        break
                except Exception:
                    pass
                xbmc.sleep(20)
            info_wait_ms_v1939 = int(time.time() * 1000) - wait_start_v1939
            log("PLAYBACK_RETURN_INFO_COVER_WAIT_V1939 token=%s pending=1 ready=%s waited_ms=%d max_ms=%d" % (
                token, "1" if info_ready_v1939 else "0", info_wait_ms_v1939, max_info_wait_ms_v1939
            ), xbmc.LOGINFO)
        else:
            xbmc.sleep(home_cover_prime_ms)

        # v2125: readiness is a logical commit boundary; Kodi still needs a few
        # frames to bind the final labels/textures.  Hold black briefly so the
        # first revealed frame is a complete fanart+metadata surface.
        if return_surface_settle_hold_ms_v2125 > 0:
            xbmc.sleep(return_surface_settle_hold_ms_v2125)
            log("PLAYBACK_RETURN_SURFACE_SETTLE_HOLD_V2125 token=%s hold_ms=%d inline_pending=%s info_ready=%s" % (
                token, return_surface_settle_hold_ms_v2125,
                "1" if inline_return_pending_v1939 else "0",
                "1" if info_ready_v1939 else "0"
            ), xbmc.LOGINFO)

        _pkm_close_return_video_fade_overlay_v1557(overlay, token=token)
        overlay = None

        # Clear only after the restored Info surface is ready (or the bounded
        # fallback timeout expires), so neither Home nor a blank frame can flash.
        _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
        log("PLAYBACK_RETURN_VIDEO_FAST_DONE_V1944 source=%s token=%s settled=%s inline_pending=%s info_ready=%s info_wait_ms=%d home_cover_fadeout_ms=%d" % (
            source, token, "1" if settled else "0",
            "1" if inline_return_pending_v1939 else "0",
            "1" if info_ready_v1939 else "0",
            info_wait_ms_v1939, home_fadeout_ms
        ), xbmc.LOGINFO)
        xbmc.sleep(home_fadeout_ms)
        return True
    except Exception:
        try:
            log("PLAYBACK_RETURN_VIDEO_FADE_FAILED_V1557 source=%s token=%s\n%s" % (source, token, traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass
        try:
            if overlay:
                overlay.close()
        except Exception:
            pass
        try:
            xbmc.executebuiltin("PlayerControl(Stop)")
        except Exception:
            pass
        _pkm_clear_return_video_fade_state_v1557(token=token, include_back_stop=True)
        return False

def open_subtitle_select(params=None):
    try:
        from resources.lib import pkm_subtitle_select
        return pkm_subtitle_select.open_subtitle_select()
    except Exception:
        log("SUBTITLE_SELECT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            notify("자막 선택창을 열지 못했습니다.", heading="PKM 자막", icon=xbmcgui.NOTIFICATION_ERROR, ms=3000)
            log("SUBTITLE_SELECT_FAILED_NOTICE mode=pkm_notify_native_suppressed", xbmc.LOGINFO)
        except Exception:
            try:
                log("SUBTITLE_SELECT_FAILED_NOTICE_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            except Exception:
                pass
        return False

def open_audio_select(params=None):
    try:
        from resources.lib import pkm_audio_select
        return pkm_audio_select.open_audio_select()
    except Exception:
        log("AUDIO_SELECT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            notify("오디오 선택창을 열지 못했습니다", heading="PKM 오디오", icon=xbmcgui.NOTIFICATION_ERROR, ms=3000)
            log("AUDIO_SELECT_FAILED_NOTICE mode=pkm_notify_native_suppressed", xbmc.LOGINFO)
        except Exception:
            pass
        return False

def open_video_select(params=None):
    try:
        from resources.lib import pkm_video_select
        return pkm_video_select.open_video_select()
    except Exception:
        log("VIDEO_SELECT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            notify("비디오 선택창을 열지 못했습니다", heading="PKM 비디오", icon=xbmcgui.NOTIFICATION_ERROR, ms=3000)
        except Exception:
            pass
        return False

def open_video_stream_info(params=None):
    try:
        from resources.lib import pkm_video_select
        return pkm_video_select.open_video_stream_info()
    except Exception:
        log("VIDEO_STREAM_INFO_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        try:
            notify("비디오 정보를 열지 못했습니다", heading="PKM 비디오", icon=xbmcgui.NOTIFICATION_ERROR, ms=3000)
        except Exception:
            pass
        return False

def run():
    params = get_params()
    action = params.get("action", "root")
    log("action=%s params=%s" % (action, params), xbmc.LOGDEBUG)
    try:
        if action in ("root", ""):
            list_root()
        elif action in ("settings", "pkm_settings"):
            open_settings()
        elif action == "select_libraries":
            choose_libraries_dialog(force=False)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "addon_settings":
            _open_pkm_addon_settings_dialog()
        elif action == "kodi_settings":
            open_kodi_settings()
        elif action == "move_section":
            move_section(params)
        elif action == "sections":
            list_root()
        elif action == "sections_menu":
            list_sections_menu(params)
        elif action == "library_index":
            list_library_index(params)
        elif action == "home_widget":
            list_home_widget(params)
        elif action == "ensure_startup_cache":
            background = params.get("background", "0").lower() in ("1", "true", "yes")
            ensure_startup_cache_ready(show_progress=not background)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "prewarm":
            list_prewarm(params)
        elif action == "prepare_focus_wall":
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "library":
            list_library(params)
        elif action == "show":
            list_show(params)
        elif action == "sync":
            ref = section_ref_from_params(params)
            sync_section(section_id=ref["section_id"], section_title=ref["section_title"], show_progress=True)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "sync_all":
            sync_all_sections(show_prompt=False, show_progress=True, mark_auto_sync=True)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "auto_sync":
            background = params.get("background", "0").lower() in ("1", "true", "yes")
            maybe_auto_sync(force=True, background=background, caller=params.get("caller", "auto_sync"))
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "rebuild_recommend_index":
            import_recommend_index_from_plex_db(show_progress=True, reason="manual")
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action in ("build_cine21_db", "cine21_build_seed"):
            build_cine21_db_seed(params)
        elif action in ("cine21_fetch_rating", "fetch_cine21_rating", "cine21_save_rating"):
            fetch_cine21_rating_manual(params)
        elif action in ("cine21_import_ratings_db", "cine21_import_db"):
            cine21_import_ratings_db_from_settings(params)
        elif action in ("cine21_generate_ratings_db", "cine21_generate_db"):
            cine21_generate_ratings_db_from_settings(params)
        elif action in ("cine21_match_measure", "cine21_measure_match_db"):
            cine21_measure_match_db_from_settings(params)
        elif action in ("cine21_match_summary", "cine21_summary"):
            cine21_show_match_summary_from_settings(params)
        elif action in ("cine21_recent_target", "cine21_target_summary"):
            cine21_show_recent_target_summary_from_settings(params)
        elif action in ("cine21_recent_match_test", "cine21_match_test"):
            cine21_show_recent_match_test_from_settings(params)
        elif action in ("cine21_auto_update", "update_cine21_db"):
            cine21_import_ratings_db_from_settings(params)
        elif action in ("watcha_import_build_db", "watcha_import_db"):
            watcha_import_build_db_from_settings(params)
        elif action in ("watcha_match_summary", "watcha_summary"):
            watcha_show_match_summary_from_settings(params)
        elif action in ("watcha_recent_target", "watcha_target_summary"):
            watcha_show_recent_target_summary_from_settings(params)
        elif action in ("watcha_recent_match_test", "watcha_match_test"):
            watcha_show_recent_match_test_from_settings(params)
        elif action in ("watcha_build_script_notice", "watcha_script_notice"):
            watcha_show_build_script_notice_from_settings(params)
        elif action == "playback_failure_home_v2224":
            playback_failure_home_request_v2224(params)
        elif action == "playback_failure_dialog_v2228":
            playback_failure_dialog_v2228(params)
        elif action in ("open_window_home", "window_home", "plex_home"):
            open_window_home(params)
        elif action in ("open_window_wall", "open_lazy_wall", "window_wall", "open_right_wall"):
            open_window_wall(params)
        elif action in ("open_window_search", "window_search", "search_window"):
            open_window_search(params)
        elif action in ("subtitle_select", "open_subtitle_select", "pkm_subtitle_select"):
            open_subtitle_select(params)
        elif action in ("audio_select", "open_audio_select", "pkm_audio_select"):
            open_audio_select(params)
        elif action in ("video_select", "open_video_select", "pkm_video_select"):
            open_video_select(params)
        elif action in ("video_stream_info", "open_video_stream_info", "pkm_video_stream_info"):
            open_video_stream_info(params)
        elif action in ("seek_quick", "pkm_seek_quick", "seek_preview"):
            pkm_seek_quick_action(params)
        elif action in ("playback_return_fade_stop", "pkm_playback_return_fade_stop"):
            pkm_playback_return_fade_stop(params)
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "clear_cache":
            clear_cache()
            if HANDLE != -1:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        elif action == "play":
            # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
            # Kodi PlayMedia(plugin://...action=play...) enters here and is
            # resolved by setResolvedUrl inside pkm_playback.py.
            play_item(params)
        elif action == "noop":
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        else:
            notify("Unknown action: %s" % action, icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    except Exception as e:
        log(traceback.format_exc(), xbmc.LOGERROR)
        notify(str(e), icon=xbmcgui.NOTIFICATION_ERROR, ms=7000)
        if HANDLE != -1:
            try:
                if str(action or "").lower() == "play":
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                    log("PLAYBACK_RESOLVER_FAILSAFE_V2380 action=play resolved=0")
                else:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            except Exception:
                pass


if __name__ == "__main__":
    run()

# PKM_PATCH_ACTIVE v1585 watcha_status_same_as_cine21_fast_indexed_counts
# PKM_PATCH_ACTIVE v1586 watcha_status_display_equivalent_ratingkey_titleyear_fast
