# -*- coding: utf-8 -*-
"""R319: PKM 메모리 사용량 측정/로그 (Windows·Android·Linux 공통).

기존 진단 로그는 Windows에서 rss_mb=-1 이라 메모리를 볼 수 없었다.
- snapshot(): 현재 프로세스 사용 메모리(MB)
- tag(): 로그 한 줄에 붙일 짧은 문자열
- start_ticker(): 주기 기록(변화가 크거나 60초마다)
"""
import gc
import os
import sys
import threading
import time

import xbmc

_PREFIX = "[plugin.video.km] "


def _win_counters():
    import ctypes
    from ctypes import wintypes

    class PMC(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
            ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
            ("PrivateUsage", ctypes.c_size_t),
        ]

    pmc = PMC()
    pmc.cb = ctypes.sizeof(PMC)
    k32 = ctypes.windll.kernel32
    k32.GetCurrentProcess.restype = wintypes.HANDLE
    psapi = ctypes.windll.psapi
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
    ok = psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
    if not ok:
        return None
    mb = 1048576.0
    return {"rss": pmc.WorkingSetSize / mb, "peak": pmc.PeakWorkingSetSize / mb, "private": pmc.PrivateUsage / mb}


def _linux_counters():
    """Linux/Android(쉴드): /proc 기반. PSS는 smaps_rollup 가능할 때만."""
    out = {}
    with open("/proc/self/status", "r") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                out["rss"] = float(line.split()[1]) / 1024.0
            elif line.startswith("VmHWM:"):
                out["peak"] = float(line.split()[1]) / 1024.0
            elif line.startswith("VmData:"):
                out["private"] = float(line.split()[1]) / 1024.0
    try:
        with open("/proc/self/smaps_rollup", "r") as f:
            for line in f:
                if line.startswith("Pss:"):
                    out["pss"] = float(line.split()[1]) / 1024.0
                    break
    except Exception:
        pass
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    out["sys_avail"] = float(line.split()[1]) / 1024.0
                elif line.startswith("MemTotal:"):
                    out["sys_total"] = float(line.split()[1]) / 1024.0
    except Exception:
        pass
    return out or None


def _win_system():
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
        ms = MS()
        ms.dwLength = ctypes.sizeof(MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms)):
            return {"sys_avail": ms.ullAvailPhys / 1048576.0, "sys_total": ms.ullTotalPhys / 1048576.0}
    except Exception:
        pass
    return {}


def snapshot():
    """{'rss','peak','private'} MB 또는 None."""
    try:
        if os.name == "nt":
            d = _win_counters()
            if d is not None:
                d.update(_win_system())
            return d
        return _linux_counters()
    except Exception:
        return None


def tag():
    s = snapshot()
    if not s:
        return "mem=n/a"
    t = "rss_mb=%.0f peak_mb=%.0f private_mb=%.0f" % (s.get("rss", -1), s.get("peak", -1), s.get("private", -1))
    if "pss" in s:
        t += " pss_mb=%.0f" % s["pss"]
    if "sys_avail" in s:
        t += " sys_avail_mb=%.0f/%.0f" % (s["sys_avail"], s.get("sys_total", -1))
    return t


def log_mark(label):
    """작업 시작/끝 지점에 메모리 한 줄."""
    try:
        xbmc.log("%sPKM_MEM_R319 mark=%s %s threads=%d" % (_PREFIX, label, tag(), threading.active_count()), xbmc.LOGINFO)
    except Exception:
        pass


def _loop(stop_event):
    last = None
    last_t = 0.0
    while not (stop_event is not None and stop_event.is_set()):
        try:
            s = snapshot()
            now = time.time()
            if s:
                rss = s.get("rss", 0.0)
                if last is None or abs(rss - last) >= 25.0 or now - last_t >= 60.0:
                    xbmc.log("%sPKM_MEM_R319 tick %s delta_mb=%.0f threads=%d gc=%s" % (
                        _PREFIX, tag(), 0.0 if last is None else rss - last,
                        threading.active_count(), ",".join(str(x) for x in gc.get_count())), xbmc.LOGINFO)
                    last, last_t = rss, now
        except Exception:
            pass
        if stop_event is not None:
            if stop_event.wait(5.0):
                break
        else:
            time.sleep(5.0)


def start_ticker(stop_event=None):
    t = threading.Thread(target=_loop, args=(stop_event,), name="pkm-mem-r319", daemon=True)
    t.start()
    return t
