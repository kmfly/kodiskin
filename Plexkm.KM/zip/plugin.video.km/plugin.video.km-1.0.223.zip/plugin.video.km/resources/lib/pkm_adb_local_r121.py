# -*- coding: utf-8 -*-
"""R121: launch an Android activity with real boolean extras through the
device's own adb daemon (127.0.0.1:5555, "network debugging").

Why: Kodi 21 StartAndroidActivity() drops boolean extras ("Intent extras data
type (boolean) not implemented").  The YouTube TV app only finishes on the
first BACK (returning to Kodi) when it gets finish_on_ended=true as a boolean.
`am start` run by Kodi itself is refused (SecurityException: package
com.android.shell does not belong to uid), but `am start` through adbd runs as
the shell user and works.

Pure Python (no extra modules): RSA key generation/signing with pow(), the adb
wire protocol over a local TCP socket.  The key lives in the addon profile
root (device-wide, not per Plex user).  The first connection makes Android
show "Allow USB debugging?" once; the user ticks "Always allow".

Every failure returns a reason string; callers fall back to the normal Kodi
builtin, so devices without adb behave exactly as before.
"""
import base64
import hashlib
import json
import os
import random
import socket
import struct
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.km"
SETTING_ID = "yt_adb_back_r121"
KEY_FILE = "adb_local_key_r121.json"
HOST = "127.0.0.1"
PORT = 5555

A_CNXN = 0x4e584e43
A_AUTH = 0x48545541
A_OPEN = 0x4e45504f
A_OKAY = 0x59414b4f
A_CLSE = 0x45534c43
A_WRTE = 0x45545257
A_VERSION = 0x01000001
MAX_DATA = 256 * 1024
AUTH_TOKEN = 1
AUTH_SIGNATURE = 2
AUTH_RSAPUBLICKEY = 3

# DER DigestInfo prefix for SHA-1 (adb signs the 20-byte token as a SHA-1 digest)
_SHA1_PREFIX = bytes.fromhex("3021300906052b0e03021a05000414")

_LOCK = threading.RLock()
_KEY = {"key": None, "gen": None}
# authorized: None = unknown, True = this key is accepted by adbd,
# False = refused / no answer / no adb (this Kodi session; not retried).
_STATE = {"last_fail": "", "last_fail_at": 0.0, "authorized": None, "pairing": False}


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] ADB_LOCAL_R121 %s" % msg, level)
    except Exception:
        pass


def enabled():
    try:
        return str(xbmcaddon.Addon(ADDON_ID).getSetting(SETTING_ID) or "").strip().lower() != "false"
    except Exception:
        return True


def set_enabled(on):
    try:
        xbmcaddon.Addon(ADDON_ID).setSetting(SETTING_ID, "true" if on else "false")
    except Exception:
        pass


# ------------------------------------------------------------------ RSA

_SMALL_PRIMES = [p for p in range(3, 2000, 2) if all(p % q for q in range(3, int(p ** 0.5) + 1, 2))]


def _is_probable_prime(n, rounds=24):
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    rng = random.SystemRandom()
    for _ in range(rounds):
        a = rng.randrange(2, n - 2)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits):
    rng = random.SystemRandom()
    while True:
        c = rng.getrandbits(bits) | (1 << (bits - 1)) | (1 << (bits - 2)) | 1
        if c % 65537 == 1:
            continue
        if _is_probable_prime(c):
            return c


def _gen_key():
    e = 65537
    while True:
        p = _gen_prime(1024)
        q = _gen_prime(1024)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != 2048:
            continue
        phi = (p - 1) * (q - 1)
        try:
            d = pow(e, -1, phi)
        except ValueError:
            continue
        if p < q:
            p, q = q, p
        return {"n": n, "e": e, "d": d, "p": p, "q": q,
                "dp": d % (p - 1), "dq": d % (q - 1), "qinv": pow(q, -1, p)}


def _key_path():
    base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
    if not os.path.isdir(base):
        os.makedirs(base, exist_ok=True)
    return os.path.join(base, KEY_FILE)


def _load_key():
    with _LOCK:
        if _KEY["key"]:
            return _KEY["key"]
        try:
            with open(_key_path(), "r", encoding="utf-8") as f:
                raw = json.load(f)
            key = {k: int(raw[k], 16) for k in ("n", "e", "d", "p", "q", "dp", "dq", "qinv")}
            _KEY["key"] = key
            return key
        except Exception:
            return None


def _gen_worker():
    t0 = time.time()
    try:
        key = _gen_key()
        path = _key_path()
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({k: "%x" % v for k, v in key.items()}, f)
        os.replace(tmp, path)
        with _LOCK:
            _KEY["key"] = key
        _log("KEY_GENERATED ms=%d" % int((time.time() - t0) * 1000))
    except Exception as exc:
        _log("KEY_GEN_FAILED err=%s" % exc, xbmc.LOGWARNING)
    finally:
        with _LOCK:
            _KEY["gen"] = None


def prepare_async():
    """Make sure a key exists (generated once, in the background)."""
    if not enabled() or not _is_android():
        return
    if _load_key():
        return
    with _LOCK:
        if _KEY["gen"] is not None:
            return
        th = threading.Thread(target=_gen_worker, name="pkm_adb_keygen_r121")
        th.daemon = True
        _KEY["gen"] = th
    th.start()


def _wait_key(timeout):
    end = time.time() + timeout
    while time.time() < end:
        key = _load_key()
        if key:
            return key
        with _LOCK:
            gen = _KEY["gen"]
        if gen is None:
            prepare_async()
        time.sleep(0.1)
    return _load_key()


def _sign(key, token):
    k = 256
    t = _SHA1_PREFIX + token
    em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    m = int.from_bytes(em, "big")
    # CRT
    m1 = pow(m, key["dp"], key["p"])
    m2 = pow(m, key["dq"], key["q"])
    h = (key["qinv"] * (m1 - m2)) % key["p"]
    s = m2 + h * key["q"]
    return s.to_bytes(k, "big")


def _android_pubkey(key):
    n, e = key["n"], key["e"]
    words = 64
    r32 = 1 << 32
    n0inv = (-pow(n % r32, -1, r32)) % r32
    rr = pow(2, 4096, n)
    buf = struct.pack("<II", words, n0inv)
    buf += n.to_bytes(256, "little")
    buf += rr.to_bytes(256, "little")
    buf += struct.pack("<I", e)
    return base64.b64encode(buf) + b" pkm@kodi\x00"


# ------------------------------------------------------------------ wire

def _is_android():
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        return False


def _send(sock, cmd, a0, a1, data=b""):
    chk = sum(data) & 0xffffffff
    sock.sendall(struct.pack("<6I", cmd, a0, a1, len(data), chk, cmd ^ 0xffffffff) + data)


def _recv_exact(sock, n):
    out = b""
    while len(out) < n:
        chunk = sock.recv(n - len(out))
        if not chunk:
            raise IOError("closed")
        out += chunk
    return out


def _recv(sock):
    hdr = _recv_exact(sock, 24)
    cmd, a0, a1, ln, _chk, _magic = struct.unpack("<6I", hdr)
    data = _recv_exact(sock, ln) if ln else b""
    return cmd, a0, a1, data


class NotAuthorized(IOError):
    pass


def _connect(key, approve_timeout, on_prompt=None, allow_prompt=True):
    sock = socket.create_connection((HOST, PORT), timeout=0.6)
    sock.settimeout(4.0)
    _send(sock, A_CNXN, A_VERSION, MAX_DATA, b"host::\x00")
    sent_sig = False
    while True:
        cmd, a0, _a1, data = _recv(sock)
        if cmd == A_CNXN:
            return sock
        if cmd != A_AUTH or a0 != AUTH_TOKEN:
            sock.close()
            raise IOError("unexpected cmd 0x%x" % cmd)
        if not sent_sig:
            _send(sock, A_AUTH, AUTH_SIGNATURE, 0, _sign(key, data))
            sent_sig = True
            continue
        if not allow_prompt:
            sock.close()
            raise NotAuthorized("key not authorized")
        # signature not accepted yet -> offer our public key; Android shows
        # "Allow USB debugging?" and answers CNXN once the user accepts.
        _log("AUTH_PROMPT waiting=%ds" % int(approve_timeout))
        if on_prompt:
            try:
                on_prompt()
            except Exception:
                pass
        _send(sock, A_AUTH, AUTH_RSAPUBLICKEY, 0, _android_pubkey(key))
        sock.settimeout(approve_timeout)
        cmd, a0, _a1, data = _recv(sock)
        if cmd == A_CNXN:
            _log("AUTH_APPROVED")
            return sock
        sock.close()
        raise IOError("not approved cmd=0x%x" % cmd)


def shell(command, approve_timeout=45.0, on_prompt=None, key_wait=4.0, allow_prompt=True):
    """Run `command` through adbd's shell service.  -> (ok, output_or_reason)."""
    if not _is_android():
        return False, "not_android"
    if not enabled():
        return False, "disabled"
    key = _wait_key(key_wait)
    if not key:
        return False, "no_key"
    t0 = time.time()
    try:
        sock = _connect(key, approve_timeout, on_prompt=on_prompt, allow_prompt=allow_prompt)
        _STATE["authorized"] = True
    except NotAuthorized:
        _log("NOT_AUTHORIZED (no prompt at play time)")
        return False, "not_authorized"
    except Exception as exc:
        reason = "connect:%s" % exc
        _STATE["last_fail"] = reason
        _STATE["last_fail_at"] = time.time()
        _log("CONNECT_FAILED ms=%d err=%s" % (int((time.time() - t0) * 1000), exc))
        return False, reason
    out = b""
    try:
        sock.settimeout(8.0)
        local_id = 1
        _send(sock, A_OPEN, local_id, 0, ("shell:%s" % command).encode("utf-8") + b"\x00")
        remote_id = 0
        while True:
            cmd, a0, a1, data = _recv(sock)
            if cmd == A_OKAY:
                remote_id = a0
            elif cmd == A_WRTE:
                out += data
                _send(sock, A_OKAY, local_id, a0)
            elif cmd == A_CLSE:
                if remote_id:
                    _send(sock, A_CLSE, local_id, remote_id)
                break
    except Exception as exc:
        _log("SHELL_FAILED err=%s out=%s" % (exc, out[:200]))
        if not out:
            return False, "shell:%s" % exc
    finally:
        try:
            sock.close()
        except Exception:
            pass
    text = out.decode("utf-8", "replace")
    _log("SHELL_OK ms=%d out=%s" % (int((time.time() - t0) * 1000), text.strip().replace("\n", " | ")[:200]))
    return True, text


def pair_async(on_prompt=None, approve_timeout=60.0):
    """R121: run the one-time "Allow debugging?" handshake in the background
    (YouTube screen open), so playback never waits for it.  Once per Kodi
    session when it fails (no adb, refused, no answer)."""
    if not enabled() or not _is_android():
        return
    if _STATE["authorized"] is not None or _STATE["pairing"]:
        return
    _STATE["pairing"] = True

    def worker():
        try:
            key = _wait_key(20.0)
            if not key:
                _STATE["authorized"] = False
                return
            try:
                sock = _connect(key, approve_timeout, on_prompt=on_prompt, allow_prompt=True)
                sock.close()
                _STATE["authorized"] = True
                _log("PAIR_OK")
            except Exception as exc:
                _STATE["authorized"] = False
                _log("PAIR_FAILED err=%s" % exc)
        finally:
            _STATE["pairing"] = False

    th = threading.Thread(target=worker, name="pkm_adb_pair_r121")
    th.daemon = True
    th.start()


def is_ready():
    return _STATE["authorized"] is not False


def _q(s):
    return "'" + str(s).replace("'", "'\\''") + "'"


def start_view(package, uri, bool_extras=None, on_prompt=None):
    """am start -a VIEW -d uri -p package --ez k v ...  -> (ok, reason)."""
    parts = ["am", "start", "-a", "android.intent.action.VIEW", "-d", _q(uri), "-p", _q(package)]
    for k, v in (bool_extras or {}).items():
        parts += ["--ez", _q(k), "true" if v else "false"]
    if _STATE["authorized"] is False:
        return False, "unavailable_this_session"
    ok, out = shell(" ".join(parts), on_prompt=on_prompt, allow_prompt=False, key_wait=0.5)
    if not ok:
        return False, out
    if "Error" in out or "Exception" in out:
        return False, "am:%s" % out.strip()[:160]
    return True, "ok"
