# -*- coding: utf-8 -*-
"""Fail-open watchdog for PKM's one-shot WindowXML startup owner.

The *independent Kodi built-in timer* in the skin remains the absolute deadline.
This watchdog improves early failure handling; it cannot disable the skin timer.
"""
import threading
import time
import xbmc
import xbmcgui


def start_watchdog(monitor, home_thread, logger):
    def log(message, level=xbmc.LOGINFO):
        try:
            logger("[plugin.video.km] " + message, level)
        except Exception:
            pass

    def run():
        started = time.monotonic()
        modal_since = None
        log("STARTUP_GUARD_R2_ARM soft_timeout_s=75 native_deadline_s=90")
        while not monitor.abortRequested():
            if monitor.waitForAbort(0.40):
                return
            try:
                w = xbmcgui.Window(10000)
                if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    # Prevent a stale 90s alarm from overlaying a later reset.
                    for alarm in ("PKM_R2_RecoveryArm", "PKM_R2_ReleaseSplash", "PKM_R2_FocusNative", "PKM_R2_RecoveryFocus"):
                        try:
                            xbmc.executebuiltin("CancelAlarm(%s,silent)" % alarm)
                        except Exception:
                            pass
                    log("STARTUP_GUARD_R2_DISARM reason=home_ready elapsed_ms=%d" %
                        int((time.monotonic() - started) * 1000))
                    return
                if w.getProperty("PlexKM.Startup.RecoveryArmedR2") == "1":
                    log("STARTUP_GUARD_R2_DISARM reason=native_guard_triggered")
                    return
                if w.getProperty("PlexKM.FullResetInProgressV2150") == "1":
                    return
                try:
                    if xbmc.Player().isPlayingVideo():
                        return
                except Exception:
                    pass
                elapsed = time.monotonic() - started
                # A user-visible setup dialog is not an infinite *logo* screen.
                # It may stay open for interaction, but is NOT trusted forever:
                # the native timer still exposes escape controls after 90 sec.
                try:
                    modal = bool(xbmc.getCondVisibility("System.HasModalDialog") or
                                 xbmc.getCondVisibility("Window.IsActive(addonsettings)"))
                except Exception:
                    modal = False
                if modal:
                    if modal_since is None:
                        modal_since = time.monotonic()
                    if elapsed < 75.0:
                        continue
                else:
                    modal_since = None

                worker_dead = not home_thread.is_alive()
                if not (elapsed >= 75.0 or (worker_dead and elapsed >= 8.0)):
                    continue
                # R79: timeout and UI-worker exit are diagnostic, not proof of
                # corrupt data or a requirement to repeat initial setup.
                # Never arm the destructive-looking recovery surface for these.
                reason = "worker_ended" if worker_dead else "home_not_ready"
                log("STARTUP_GUARD_R79_DIAGNOSTIC reason=%s elapsed_ms=%d recovery=SUPPRESSED" %
                    (reason, int(elapsed * 1000)), xbmc.LOGWARNING)
                return
            except Exception as exc:
                log("STARTUP_GUARD_R2_POLL_FAIL %s" % exc, xbmc.LOGWARNING)

    thread = threading.Thread(target=run, name="PKMStartupWatchdogR2", daemon=True)
    thread.start()
    return thread
