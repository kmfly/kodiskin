# -*- coding: utf-8 -*-
"""User-confirmed PKM repository update flow (v2169).

Flow:
- Protect PKM from Kodi's silent automatic install while checking for a PKM update.
- Wait until the PKM Home is visibly ready.
- Check the KM repository manifest without touching the installed add-ons.
- Show the existing PKM top-right notice, then a PKM confirmation dialog.
- "나중에", Back, or 10 seconds without input: do nothing this process; ask next Kodi start.
- "업데이트": temporarily enable Kodi's native repository auto-update only for the
  user-confirmed transaction, refresh repositories, observe the requested Plugin/Skin
  target versions, restore the user's original add-on update mode, then show 3-2-1
  and quit Kodi.

Kodi's InstallAddon(id) built-in is install-only for an already absent add-on and
returns without updating an add-on that is already installed. Existing PKM add-ons
therefore use Kodi's RepositoryUpdater auto-update path after explicit user consent.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
try:
    from urllib.request import Request, urlopen
except Exception:
    from urllib2 import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None

ADDON_ID = "plugin.video.km"
SKIN_ID = "skin.plex.km"
REMOTE_MANIFEST_URL = "https://raw.githubusercontent.com/kmfly/kodiskin/master/Plexkm.KM/addon_list.xml"
STATE_FILE = "special://profile/addon_data/plugin.video.km/pkm_update_flow_v2169.json"
CONFIRM_XML = "plexkm_pkm_confirm_no_default_dialog.xml"
PROGRESS_XML = "plexkm_update_progress_v2169.xml"
RESTART_XML = "plexkm_update_restart_v2169.xml"

NOTICE_SECONDS = 3.0
PROMPT_TIMEOUT_SECONDS = 10.0
REPO_SETTLE_SECONDS = 4.0
REPO_RETRY_SECONDS = 20.0
INSTALL_TIMEOUT_SECONDS = 120.0
HOME_READY_FALLBACK_SECONDS = 35.0


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return path


def _ensure_parent(path):
    parent = os.path.dirname(_translate(path))
    if not parent:
        return
    try:
        if not xbmcvfs.exists(parent):
            xbmcvfs.mkdirs(parent)
    except Exception:
        try:
            if not os.path.isdir(parent):
                os.makedirs(parent)
        except Exception:
            pass


def _read_state():
    path = _translate(STATE_FILE)
    try:
        if not xbmcvfs.exists(path):
            return {}
        fh = xbmcvfs.File(path, "r")
        raw = fh.read()
        fh.close()
        data = json.loads(raw or "{}")
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        _log("PKM_UPDATE_STATE_READ_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        return {}


def _write_state(data):
    path = _translate(STATE_FILE)
    tmp = path + ".tmp"
    _ensure_parent(path)
    payload = json.dumps(data or {}, ensure_ascii=False, sort_keys=True, indent=2)
    try:
        fh = xbmcvfs.File(tmp, "w")
        fh.write(payload)
        fh.close()
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass
        if not xbmcvfs.rename(tmp, path):
            fh = xbmcvfs.File(path, "w")
            fh.write(payload)
            fh.close()
            try:
                xbmcvfs.delete(tmp)
            except Exception:
                pass
        return True
    except Exception as exc:
        _log("PKM_UPDATE_STATE_WRITE_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        return False


def _delete_state():
    try:
        path = _translate(STATE_FILE)
        if xbmcvfs.exists(path):
            return bool(xbmcvfs.delete(path))
    except Exception:
        pass
    return False


def _jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 2169, "method": method}
    if params is not None:
        req["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(req))
        data = json.loads(raw or "{}")
        if isinstance(data, dict) and "error" not in data:
            return data.get("result")
    except Exception as exc:
        _log("PKM_UPDATE_JSONRPC_FAILED_V2169 method=%s err=%s" % (method, exc), xbmc.LOGWARNING)
    return None


def _get_setting_value(setting):
    result = _jsonrpc("Settings.GetSettingValue", {"setting": setting})
    if isinstance(result, dict) and "value" in result:
        return result.get("value")
    return None


def _set_setting_value(setting, value):
    result = _jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})
    return result is True


def _addon_version_runtime(addon_id):
    try:
        return str(xbmcaddon.Addon(addon_id).getAddonInfo("version") or "")
    except Exception:
        return ""


def _addon_version_disk(addon_id):
    """Read the on-disk addon.xml version, bypassing AddonManager runtime cache.

    During plugin.video.km self-update Kodi can replace addon.xml before the
    current Python service instance is recycled. xbmcaddon.Addon(...).version
    can therefore remain stale for the remainder of that service instance.
    The update transaction must use the newest authoritative view so it can
    advance instead of remaining stuck on the Plugin install stage.
    """
    try:
        path = _translate("special://home/addons/%s/addon.xml" % addon_id)
        if not path or not xbmcvfs.exists(path):
            return ""
        fh = xbmcvfs.File(path, "r")
        raw = fh.read()
        fh.close()
        root = ET.fromstring(raw or "")
        return str(root.attrib.get("version") or "")
    except Exception:
        return ""


def _addon_version(addon_id):
    runtime = _addon_version_runtime(addon_id)
    disk = _addon_version_disk(addon_id)
    if runtime and disk and runtime != disk:
        chosen = disk if _version_tuple(disk) >= _version_tuple(runtime) else runtime
        _log("PKM_UPDATE_VERSION_VIEW_V2317 addon=%s runtime=%s disk=%s chosen=%s" % (addon_id, runtime, disk, chosen))
        return chosen
    return disk or runtime or ""


def current_versions():
    return {"plugin": _addon_version(ADDON_ID), "skin": _addon_version(SKIN_ID)}


def _version_tuple(value):
    return tuple(int(x) for x in re.findall(r"\d+", str(value or ""))) or (0,)


def _is_newer(value, baseline):
    return _version_tuple(value) > _version_tuple(baseline)


def _at_least(value, target):
    return _version_tuple(value) >= _version_tuple(target)


def _target_reached(current, target):
    return _at_least((current or {}).get("plugin"), (target or {}).get("plugin")) and \
        _at_least((current or {}).get("skin"), (target or {}).get("skin"))


def _parse_manifest_versions(raw):
    root = ET.fromstring(raw)
    versions = {}
    nodes = [root] if root.tag == "addon" else list(root.findall(".//addon"))
    for node in nodes:
        addon_id = str(node.attrib.get("id") or "")
        if addon_id == ADDON_ID:
            versions["plugin"] = str(node.attrib.get("version") or "")
        elif addon_id == SKIN_ID:
            versions["skin"] = str(node.attrib.get("version") or "")
    return versions


def _fetch_remote_versions():
    request = Request(REMOTE_MANIFEST_URL, headers={"User-Agent": "PlexKM/2169 Kodi"})
    response = urlopen(request, timeout=5.0)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    return _parse_manifest_versions(raw)


def _set_confirm_props(title, message, yes_label, no_label):
    try:
        win = xbmcgui.Window(10000)
        for key, value in (
            ("PlexKM.Confirm.Title", title),
            ("PlexKM.Confirm.Message", message),
            ("PlexKM.Confirm.Yes", yes_label),
            ("PlexKM.Confirm.No", no_label),
            ("PlexKM.Confirm.Icon1", ""),
            ("PlexKM.Confirm.Icon2", ""),
            ("PlexKM.Confirm.HasIcons", ""),
            ("PlexKM.Confirm.WindowedVideo", ""),
            ("PlexKM.Confirm.HasCine21Rows", ""),
        ):
            win.setProperty(key, str(value or ""))
    except Exception:
        pass


def _clear_confirm_props():
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Confirm.Title", "PlexKM.Confirm.Message", "PlexKM.Confirm.Yes", "PlexKM.Confirm.No",
            "PlexKM.Confirm.Icon1", "PlexKM.Confirm.Icon2", "PlexKM.Confirm.HasIcons",
            "PlexKM.Confirm.WindowedVideo", "PlexKM.Confirm.HasCine21Rows",
        ):
            win.clearProperty(key)
    except Exception:
        pass


class PKMUpdateConfirmDialogV2169(xbmcgui.WindowXMLDialog):
    YES_ID = 300
    NO_ID = 301
    # Kodi/Windows can deliver remote/keyboard OK to WindowXMLDialog only as
    # onAction(), without following it with onClick() for the focused button.
    # Keep the same select/enter set already used by PKM's proven completion UI.
    SELECT_ACTION_IDS = (7, 79, 100, 135)
    BACK_ACTION_IDS = (9, 10, 92, 216, 247)

    def __init__(self, *args, **kwargs):
        self.choice = None
        self.closed_by_user = False
        super(PKMUpdateConfirmDialogV2169, self).__init__(*args, **kwargs)

    def _focus_id(self):
        try:
            return int(self.getFocusId())
        except Exception:
            return -1

    def onInit(self):
        _log("PKM_UPDATE_CONFIRM_READY_V2316 focus=%s default=later" % self._focus_id())

    def _commit_choice(self, value, source, action_id=None, control_id=None):
        if self.choice is not None:
            return
        focus_id = self._focus_id()
        self.choice = bool(value)
        self.closed_by_user = True
        _log(
            "PKM_UPDATE_CONFIRM_CHOICE_V2316 choice=%s source=%s action=%s control=%s focus=%s"
            % (
                "update" if value else "later",
                source or "unknown",
                "" if action_id is None else action_id,
                "" if control_id is None else control_id,
                focus_id,
            )
        )
        try:
            self.close()
        except Exception:
            pass

    def onClick(self, control_id):
        try:
            cid = int(control_id)
        except Exception:
            cid = -1
        if cid == self.YES_ID:
            self._commit_choice(True, "onclick", control_id=cid)
        elif cid == self.NO_ID:
            self._commit_choice(False, "onclick", control_id=cid)

    def onAction(self, action):
        try:
            aid = int(action.getId())
        except Exception:
            aid = -1
        if aid in self.SELECT_ACTION_IDS:
            # v2316 root fix: commit the actually focused visible button when
            # Kodi supplies SELECT/ENTER as onAction() without onClick().
            focus_id = self._focus_id()
            if focus_id == self.YES_ID:
                self._commit_choice(True, "onaction", action_id=aid, control_id=focus_id)
                return
            if focus_id == self.NO_ID:
                self._commit_choice(False, "onaction", action_id=aid, control_id=focus_id)
                return
            _log("PKM_UPDATE_CONFIRM_SELECT_IGNORED_V2316 action=%s focus=%s" % (aid, focus_id), xbmc.LOGWARNING)
            return
        if aid in self.BACK_ACTION_IDS:
            self._commit_choice(False, "back", action_id=aid, control_id=self._focus_id())


class PKMUpdateProgressDialogV2169(xbmcgui.WindowXMLDialog):
    def onInit(self):
        # The visible bar is XML slice-owned (same deterministic strategy as
        # plexkm_sync_progress.xml v2040). Keep this log to prove the custom
        # update surface, not Kodi's native progress UI, owns rendering.
        _log("PKM_UPDATE_PROGRESS_READY_V2317 renderer=xml_percent_slices no_property_progress_info=1")

    def onAction(self, action):
        return

    def onClick(self, control_id):
        return


def _set_progress(title="Plex KM 업데이트", line1="", line2="", percent=0):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.UpdateV2169.Title", str(title or "Plex KM 업데이트"))
        win.setProperty("PlexKM.UpdateV2169.Line1", str(line1 or ""))
        win.setProperty("PlexKM.UpdateV2169.Line2", str(line2 or ""))
        win.setProperty("PlexKM.UpdateV2169.Percent", str(max(0, min(100, int(percent or 0)))))
    except Exception:
        pass


def _clear_progress():
    try:
        win = xbmcgui.Window(10000)
        for key in ("PlexKM.UpdateV2169.Title", "PlexKM.UpdateV2169.Line1", "PlexKM.UpdateV2169.Line2", "PlexKM.UpdateV2169.Percent"):
            win.clearProperty(key)
    except Exception:
        pass


def _set_restart(old_versions, new_versions, count=None, line=""):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.UpdateRestart.TitleV2169", "Plex KM 업데이트 완료")
        win.setProperty(
            "PlexKM.UpdateRestart.VersionV2169",
            "Plugin %s → %s    Skin %s → %s" % (
                (old_versions or {}).get("plugin") or "-", (new_versions or {}).get("plugin") or "-",
                (old_versions or {}).get("skin") or "-", (new_versions or {}).get("skin") or "-",
            ),
        )
        win.setProperty("PlexKM.UpdateRestart.LineV2169", str(line or ""))
        win.setProperty("PlexKM.UpdateRestart.CountV2169", "" if count is None else str(count))
    except Exception:
        pass


def _clear_restart():
    try:
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.UpdateRestart.TitleV2169", "PlexKM.UpdateRestart.VersionV2169",
            "PlexKM.UpdateRestart.LineV2169", "PlexKM.UpdateRestart.CountV2169",
        ):
            win.clearProperty(key)
    except Exception:
        pass


def _show_countdown(old_versions, new_versions, monitor=None):
    detail = "Plex KM 업데이트가 완료되었습니다."
    return request_kodi_exit_v2171(
        reason="pkm_update_complete_v2171",
        title="Kodi 종료",
        detail=detail,
        monitor=monitor,
    )


class PKMUpdateFlowV2169(object):
    """Non-blocking update state machine called from the PKM service loop."""

    def __init__(self, request_service_stop=None):
        self.request_service_stop = request_service_stop
        self.started_at = time.time()
        self.protection_ready = False
        self.protection_retry_at = 0.0
        self.state = _read_state()
        self.deferred_this_run = False
        self.check_started = False
        self.check_done = False
        self.check_result = None
        self.check_error = None
        self.check_lock = threading.Lock()
        self.notice_token = ""
        self.notice_until = 0.0
        self.prompt = None
        self.prompt_started_at = 0.0
        self.progress = None
        self.finished = False
        self.install_invoked_at = 0.0
        self.install_retry_count = 0
        self.repo_refresh_invoked_at = 0.0
        self.phase_started_at = 0.0
        self.process_token = self._process_token_v2317()
        _log("PKM_PATCH_ACTIVE v2319 existing_addon_repo_auto_handoff_no_installaddon")
        self._resume_or_seed_state()

    def _process_token_v2317(self):
        """Return a Kodi-process token that survives add-on service reload only.

        Window(10000) properties survive plugin service self-restart but are
        cleared by a real Kodi process restart. This lets the updater distinguish
        the two boundaries and prevents a plugin self-update from being mistaken
        for the requested Kodi restart.
        """
        try:
            win = xbmcgui.Window(10000)
            key = "PlexKM.Update.ProcessTokenV2317"
            token = str(win.getProperty(key) or "")
            if not token:
                token = "%d_%d" % (int(time.time() * 1000), id(self))
                win.setProperty(key, token)
            return token
        except Exception:
            return "%d_%d" % (int(time.time() * 1000), id(self))

    def _resume_or_seed_state(self):
        current = current_versions()
        target = self.state.get("target") if isinstance(self.state.get("target"), dict) else None
        phase = str(self.state.get("phase") or "")
        origin_process = str(self.state.get("origin_process_token") or "")
        try:
            self.phase_started_at = float(self.state.get("phase_started_epoch") or 0.0)
        except Exception:
            self.phase_started_at = 0.0
        if target and _target_reached(current, target):
            if origin_process and origin_process == self.process_token:
                # The plugin updated and Kodi recycled only this service inside the
                # same process. That is NOT the requested Kodi restart boundary.
                # Re-enter finalize so the completion/quit flow still runs.
                self.state["phase"] = "finalize"
                self.state["phase_started_epoch"] = time.time()
                self.state["updated_at"] = int(time.time())
                _write_state(self.state)
                self.phase_started_at = float(self.state.get("phase_started_epoch") or time.time())
                _log("PKM_UPDATE_RESUME_SELF_RESTART_COMPLETE_V2317 process=same plugin=%s skin=%s" % (current.get("plugin"), current.get("skin")))
            else:
                # Window properties were cleared, so Kodi itself restarted. The
                # requested restart boundary has genuinely been crossed.
                _log("PKM_UPDATE_RESUME_AFTER_KODI_RESTART_V2317 plugin=%s skin=%s" % (current.get("plugin"), current.get("skin")))
                original = self.state.get("original_addonupdates")
                self.state = {"schema": 1, "phase": "guard", "original_addonupdates": original}
                _write_state(self.state)
        elif phase == "repo_auto_install" or phase.startswith("install_") or phase in ("repo_refresh", "finalize"):
            _log("PKM_UPDATE_RESUME_ACTIVE_V2319 phase=%s target=%s process_same=%d explicit=%d" % (
                phase, target, 1 if origin_process and origin_process == self.process_token else 0,
                1 if self.state.get("explicit_update") else 0,
            ))

    def _protect_from_silent_auto_update(self):
        if self.protection_ready:
            return True
        now = time.time()
        if now < self.protection_retry_at:
            return False
        mode = _get_setting_value("general.addonupdates")
        if mode is None:
            self.protection_retry_at = now + 1.0
            return False
        try:
            mode = int(mode)
        except Exception:
            self.protection_retry_at = now + 2.0
            return False

        phase = str(self.state.get("phase") or "")
        explicit_active = bool(self.state.get("explicit_update")) and phase in (
            "repo_auto_install", "repo_refresh", "install_skin", "install_plugin", "finalize"
        )
        if explicit_active:
            # The user already confirmed this persisted transaction. Keep Kodi's
            # native auto-update path enabled across plugin service self-restarts
            # until both requested PKM versions are observed or the transaction fails.
            if mode != 0:
                if not _set_setting_value("general.addonupdates", 0):
                    self.protection_retry_at = now + 1.0
                    return False
                _log("PKM_UPDATE_AUTO_MODE_V2319 changed=%s_to_0 reason=explicit_transaction_resume" % mode)
            self.protection_ready = True
            return True

        if "original_addonupdates" not in self.state or self.state.get("original_addonupdates") is None:
            self.state["schema"] = 1
            self.state["phase"] = self.state.get("phase") or "guard"
            self.state["original_addonupdates"] = mode
            _write_state(self.state)
        # 0 is Kodi automatic install; 1 is notify only. Keep 2 (never) untouched.
        if mode == 0:
            if not _set_setting_value("general.addonupdates", 1):
                self.protection_retry_at = now + 1.0
                return False
            _log("PKM_UPDATE_AUTO_GUARD_V2169 changed=0_to_1 scope=until_pkm_check_or_restart")
        else:
            _log("PKM_UPDATE_AUTO_GUARD_V2169 changed=0 current_mode=%s" % mode)
        self.protection_ready = True
        return True

    def _restore_original_update_mode_value(self):
        """Restore the user's pre-PKM add-on update mode without deleting transaction state."""
        original = self.state.get("original_addonupdates")
        try:
            original = int(original)
        except Exception:
            original = None
        if original is None:
            return None
        current = _get_setting_value("general.addonupdates")
        try:
            current = int(current)
        except Exception:
            current = None
        if current is not None and current != original:
            if _set_setting_value("general.addonupdates", original):
                _log("PKM_UPDATE_AUTO_MODE_RESTORE_V2319 mode=%s" % original)
            else:
                _log("PKM_UPDATE_AUTO_MODE_RESTORE_FAILED_V2319 mode=%s current=%s" % (original, current), xbmc.LOGWARNING)
        return original

    def _restore_original_update_mode(self):
        self._restore_original_update_mode_value()
        self.state = {}
        _delete_state()

    def _home_ready(self):
        try:
            win = xbmcgui.Window(10000)
            return bool(
                win.getProperty("PlexKM.Home.StartupReadyV1619") == "1"
                and win.getProperty("PlexKM.Window.IsHome") == "1"
                and win.getProperty("PlexKM.Info.InlineActive") != "1"
            )
        except Exception:
            return False

    def _blocked(self):
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win.getProperty("PlexKM.FullResetInProgressV2149") == "1":
                return True
        except Exception:
            pass
        try:
            if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                return True
        except Exception:
            pass
        return False

    def _start_remote_check(self):
        if self.check_started:
            return
        self.check_started = True

        def worker():
            result = None
            error = None
            try:
                result = _fetch_remote_versions()
            except Exception as exc:
                error = str(exc)
            with self.check_lock:
                self.check_result = result
                self.check_error = error
                self.check_done = True

        thread = threading.Thread(target=worker, name="PKMUpdateCheckV2169", daemon=True)
        thread.daemon = True
        thread.start()
        _log("PKM_UPDATE_REMOTE_CHECK_START_V2169")

    def _available_target(self):
        with self.check_lock:
            remote = dict(self.check_result or {})
        current = current_versions()
        target = dict(current)
        available = False
        if remote.get("plugin") and _is_newer(remote.get("plugin"), current.get("plugin")):
            target["plugin"] = remote.get("plugin")
            available = True
        if remote.get("skin") and _is_newer(remote.get("skin"), current.get("skin")):
            target["skin"] = remote.get("skin")
            available = True
        return available, current, target

    def _show_notice(self, current, target):
        self.notice_until = time.time() + NOTICE_SECONDS
        if pkm_notify:
            try:
                self.notice_token = pkm_notify.pkm_notice_set(
                    "PKM 업데이트",
                    "새 버전이 있습니다.",
                    "Plugin %s  Skin %s" % (target.get("plugin") or "-", target.get("skin") or "-"),
                    token="pkm_update_v2169_%d" % int(time.time() * 1000),
                    sticky=False,
                    force_replace=False,
                )
            except Exception as exc:
                _log("PKM_UPDATE_NOTICE_FAILED_V2169 err=%s" % exc, xbmc.LOGWARNING)
        _log("PKM_UPDATE_AVAILABLE_NOTICE_V2169 current=%s target=%s" % (current, target))

    def _clear_notice(self):
        if pkm_notify and self.notice_token:
            try:
                pkm_notify.pkm_notice_clear(expected_token=self.notice_token, force=False)
            except Exception:
                pass
        self.notice_token = ""

    def _open_prompt(self):
        if self.prompt is not None:
            return
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        _set_confirm_props("PKM 업데이트", "업데이트를 진행하겠습니까?", "업데이트", "나중에")
        self.prompt = PKMUpdateConfirmDialogV2169(CONFIRM_XML, addon_path, "Default", "1080i")
        self.prompt.show()
        self.prompt_started_at = time.time()
        _log("PKM_UPDATE_CONFIRM_OPEN_V2169 timeout_sec=%s default=later" % PROMPT_TIMEOUT_SECONDS)

    def _close_prompt(self):
        try:
            if self.prompt is not None:
                self.prompt.close()
        except Exception:
            pass
        self.prompt = None
        self.prompt_started_at = 0.0
        _clear_confirm_props()

    def _show_progress(self):
        if self.progress is not None:
            return
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        self.progress = PKMUpdateProgressDialogV2169(PROGRESS_XML, addon_path, "Default", "1080i")
        self.progress.show()
        _log("PKM_UPDATE_PROGRESS_OPEN_V2317 renderer=xml_percent_slices")

    def _close_progress(self):
        try:
            if self.progress is not None:
                self.progress.close()
        except Exception:
            pass
        self.progress = None
        _clear_progress()

    def _save_active(self, phase, current, target):
        original = self.state.get("original_addonupdates")
        now = time.time()
        self.state = {
            "schema": 2,
            "phase": phase,
            "explicit_update": 1,
            "original_addonupdates": original,
            "before": dict(current or {}),
            "target": dict(target or {}),
            "origin_process_token": self.process_token,
            "phase_started_epoch": now,
            "refresh_requested_epoch": 0.0,
            "updated_at": int(now),
        }
        _write_state(self.state)
        self.phase_started_at = now
        self.install_invoked_at = 0.0
        self.install_retry_count = 0
        self.repo_refresh_invoked_at = 0.0

    def _begin_update(self, current, target):
        _log("PKM_UPDATE_BEGIN_V2319 before=%s target=%s" % (current, target))
        self._close_prompt()
        self._save_active("repo_auto_install", current, target)
        self._show_progress()
        _set_progress("Plex KM 업데이트", "업데이트 정보를 준비합니다.", "Kodi 저장소에서 새 버전을 확인하고 있습니다.", 10)

        # InstallAddon(id) cannot update an add-on that is already installed.
        # After explicit user confirmation, temporarily switch Kodi to native
        # auto-update mode and let RepositoryUpdater call the internal update path.
        previous = _get_setting_value("general.addonupdates")
        try:
            previous = int(previous)
        except Exception:
            previous = None
        if previous != 0:
            if not _set_setting_value("general.addonupdates", 0):
                self._fail("Kodi 자동 업데이트 모드를 전환하지 못했습니다.")
                return
        _log("PKM_UPDATE_AUTO_MODE_V2319 original=%s temporary=0 reason=user_confirmed" % (
            self.state.get("original_addonupdates") if self.state.get("original_addonupdates") is not None else "-"
        ))
        try:
            xbmc.executebuiltin("UpdateAddonRepos")
        except Exception as exc:
            self._fail("저장소 업데이트를 시작하지 못했습니다.", exc)
            return
        now = time.time()
        self.repo_refresh_invoked_at = now
        self.state["refresh_requested_epoch"] = now
        self.state["updated_at"] = int(now)
        _write_state(self.state)
        _log("PKM_UPDATE_REPO_REFRESH_V2319 reason=user_confirmed current=%s target=%s" % (current_versions(), target))

    def _fail(self, message, error=None):
        _log("PKM_UPDATE_FAILED_V2169 message=%s err=%s" % (message, error or ""), xbmc.LOGERROR)
        self._close_progress()
        self._restore_original_update_mode()
        if pkm_notify:
            try:
                pkm_notify.pkm_notice_set(
                    "PKM 업데이트 실패", message, "다음 Kodi 실행 때 다시 시도할 수 있습니다.",
                    token="pkm_update_fail_v2169_%d" % int(time.time() * 1000), force_replace=True,
                )
            except Exception:
                pass
        self.deferred_this_run = True


    def _tick_active_update(self, monitor=None):
        phase = str(self.state.get("phase") or "")
        target = self.state.get("target") if isinstance(self.state.get("target"), dict) else {}
        before = self.state.get("before") if isinstance(self.state.get("before"), dict) else current_versions()
        if not target:
            self._fail("업데이트 대상 버전 정보를 찾지 못했습니다.")
            return False

        # v2319 migration: a transaction persisted by the former InstallAddon
        # implementation is converted to the repository auto-update transaction
        # only when it was explicitly confirmed in this schema.
        if phase != "repo_auto_install":
            if self.state.get("explicit_update"):
                phase = "repo_auto_install"
                self.state["phase"] = phase
                self.state["phase_started_epoch"] = time.time()
                self.state["refresh_requested_epoch"] = 0.0
                self.state["updated_at"] = int(time.time())
                _write_state(self.state)
                self.phase_started_at = float(self.state.get("phase_started_epoch") or time.time())
                self.repo_refresh_invoked_at = 0.0
                _log("PKM_UPDATE_PHASE_MIGRATE_V2319 phase=repo_auto_install")
            else:
                self._fail("이전 업데이트 상태를 안전하게 재개할 수 없습니다.")
                return False

        current = current_versions()
        if _target_reached(current, target):
            _log("PKM_UPDATE_TARGET_REACHED_V2319 current=%s target=%s phase=%s" % (current, target, phase))
            self._show_progress()
            _set_progress("Plex KM 업데이트", "업데이트가 완료되었습니다.", "Kodi를 다시 시작해 적용합니다.", 100)
            # Restore the user's setting before leaving Kodi. The transaction state
            # itself is kept until the restart countdown has been committed.
            original = self._restore_original_update_mode_value()
            if monitor is not None:
                monitor.waitForAbort(0.6)
            else:
                xbmc.sleep(600)
            self._close_progress()
            self.state = {"schema": 2, "phase": "guard", "original_addonupdates": original}
            _write_state(self.state)
            try:
                if callable(self.request_service_stop):
                    self.request_service_stop("pkm_update_complete_v2171")
            except Exception:
                pass
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.App.Quitting", "1")
            except Exception:
                pass
            _log("PKM_UPDATE_KODI_EXIT_V2171 action=common_countdown")
            _show_countdown(before, current, monitor=monitor)
            self.finished = True
            return True

        self._show_progress()
        now = time.time()
        if self.phase_started_at <= 0:
            try:
                self.phase_started_at = float(self.state.get("phase_started_epoch") or 0.0)
            except Exception:
                self.phase_started_at = 0.0
        if self.phase_started_at <= 0:
            self.phase_started_at = now
            self.state["phase_started_epoch"] = now
            _write_state(self.state)

        elapsed = now - self.phase_started_at
        if elapsed > INSTALL_TIMEOUT_SECONDS:
            pending = []
            if not _at_least(current.get("skin"), target.get("skin")):
                pending.append("Skin")
            if not _at_least(current.get("plugin"), target.get("plugin")):
                pending.append("Plugin")
            self._fail("%s 업데이트 시간이 초과되었습니다." % (" / ".join(pending) or "PKM"))
            return False

        skin_pending = not _at_least(current.get("skin"), target.get("skin"))
        plugin_pending = not _at_least(current.get("plugin"), target.get("plugin"))
        if skin_pending:
            _set_progress("Plex KM 업데이트", "Skin을 업데이트합니다.", "Kodi 저장소에서 새 버전을 설치하고 있습니다.", 40)
        elif plugin_pending:
            _set_progress("Plex KM 업데이트", "Plugin을 업데이트합니다.", "Kodi 저장소에서 새 버전을 설치하고 있습니다.", 75)
        else:
            _set_progress("Plex KM 업데이트", "설치 결과를 확인합니다.", "새 버전을 적용하고 있습니다.", 95)

        try:
            refresh_epoch = float(self.state.get("refresh_requested_epoch") or 0.0)
        except Exception:
            refresh_epoch = 0.0
        last_refresh = max(self.repo_refresh_invoked_at or 0.0, refresh_epoch)
        if last_refresh <= 0.0 or (now - last_refresh) >= REPO_RETRY_SECONDS:
            mode = _get_setting_value("general.addonupdates")
            try:
                mode = int(mode)
            except Exception:
                mode = None
            if mode != 0:
                if not _set_setting_value("general.addonupdates", 0):
                    self._fail("Kodi 자동 업데이트 모드를 유지하지 못했습니다.")
                    return False
                _log("PKM_UPDATE_AUTO_MODE_V2319 changed=%s_to_0 reason=active_transaction" % mode)
            try:
                xbmc.executebuiltin("UpdateAddonRepos")
            except Exception as exc:
                self._fail("저장소 업데이트를 다시 요청하지 못했습니다.", exc)
                return False
            self.repo_refresh_invoked_at = now
            self.state["refresh_requested_epoch"] = now
            self.state["updated_at"] = int(now)
            _write_state(self.state)
            _log("PKM_UPDATE_REPO_REFRESH_V2319 reason=retry elapsed=%.1f current=%s target=%s" % (elapsed, current, target))

        # Low-rate observation log for diagnosing repository/install lifecycle.
        last_obs = float(self.state.get("last_observe_epoch") or 0.0) if self.state.get("last_observe_epoch") else 0.0
        if last_obs <= 0.0 or (now - last_obs) >= 10.0:
            self.state["last_observe_epoch"] = now
            self.state["updated_at"] = int(now)
            _write_state(self.state)
            _log("PKM_UPDATE_WAIT_V2319 elapsed=%.1f current=%s target=%s mode=%s" % (
                elapsed, current, target, _get_setting_value("general.addonupdates")
            ))
        return False

    def tick(self, monitor=None):
        if self.finished:
            return True

        if not self._protect_from_silent_auto_update():
            return False

        phase = str(self.state.get("phase") or "")
        if phase in ("repo_auto_install", "repo_refresh", "install_plugin", "install_skin", "finalize"):
            return self._tick_active_update(monitor=monitor)

        if self.deferred_this_run or self._blocked():
            return False

        home_ready = self._home_ready()
        if not home_ready:
            if (time.time() - self.started_at) < HOME_READY_FALLBACK_SECONDS:
                return False
            _log("PKM_UPDATE_HOME_READY_FALLBACK_V2169 waited_sec=%d" % int(time.time() - self.started_at), xbmc.LOGWARNING)

        if not self.check_started:
            self._start_remote_check()
            return False
        if not self.check_done:
            return False

        if self.check_error:
            _log("PKM_UPDATE_REMOTE_CHECK_FAILED_V2169 err=%s" % self.check_error, xbmc.LOGWARNING)
            self._restore_original_update_mode()
            self.deferred_this_run = True
            return False

        available, current, target = self._available_target()
        if not available:
            _log("PKM_UPDATE_NONE_V2169 plugin=%s skin=%s" % (current.get("plugin") or "-", current.get("skin") or "-"))
            self._restore_original_update_mode()
            self.deferred_this_run = True
            return False

        if not self.notice_until and self.prompt is None:
            self._show_notice(current, target)
            return False

        if self.notice_until:
            if time.time() < self.notice_until:
                return False
            self._clear_notice()
            self.notice_until = 0.0
            self._open_prompt()
            return False

        if self.prompt is not None:
            choice = self.prompt.choice
            if choice is True:
                self._begin_update(current, target)
                return False
            if choice is False:
                self._close_prompt()
                self.deferred_this_run = True
                _log("PKM_UPDATE_DEFER_V2169 source=user next_kodi_start=1")
                # Intentionally keep global add-on mode guarded this session; restoring automatic
                # mode would allow the pending PKM version to install silently after "나중에".
                return False
            if (time.time() - self.prompt_started_at) >= PROMPT_TIMEOUT_SECONDS:
                self._close_prompt()
                self.deferred_this_run = True
                _log("PKM_UPDATE_DEFER_V2169 source=timeout timeout_sec=%s next_kodi_start=1" % PROMPT_TIMEOUT_SECONDS)
                return False

        return False
