# -*- coding: utf-8 -*-
"""R119: PKM favorites store (per Plex profile).

Stores movie/show rating keys only.  Episodes and seasons are mapped to their
show by the caller.  The file lives in the addon profile directory and is
parked/restored per Plex user by pkm_profile_r82 (PER_USER_FILES).
"""
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.km"
FAVORITES_FILE = "favorites_r119.json"
_LOCK = threading.RLock()
_CACHE = {"mtime": None, "items": None, "ext": None}


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] FAVORITES_R119 %s" % msg, level)
    except Exception:
        pass


def _path():
    base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
    if not os.path.isdir(base):
        os.makedirs(base, exist_ok=True)
    return os.path.join(base, FAVORITES_FILE)


def _load_locked():
    path = _path()
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        mtime = None
    if _CACHE["items"] is not None and _CACHE["mtime"] == mtime:
        return _CACHE["items"]
    items = []
    ext = []
    if mtime is not None:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for it in list((data or {}).get("items") or []):
                if isinstance(it, dict) and str(it.get("rating_key") or "").strip():
                    items.append(it)
            for it in list((data or {}).get("ext") or []):
                if isinstance(it, dict) and str(it.get("key") or "").strip():
                    ext.append(it)
        except Exception as exc:
            _log("LOAD_FAILED err=%s" % exc, xbmc.LOGWARNING)
    _CACHE["items"] = items
    _CACHE["ext"] = ext
    _CACHE["mtime"] = mtime
    return items


def _ext_locked():
    _load_locked()
    return _CACHE["ext"] if _CACHE["ext"] is not None else []


def _save_locked(items, ext=None):
    if ext is None:
        ext = list(_CACHE["ext"] or [])
    path = _path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"version": 2, "items": items, "ext": ext}, f, ensure_ascii=False)
    os.replace(tmp, path)
    try:
        _CACHE["mtime"] = os.path.getmtime(path)
    except Exception:
        _CACHE["mtime"] = None
    _CACHE["items"] = items
    _CACHE["ext"] = ext


def list_items():
    """Newest first."""
    with _LOCK:
        return [dict(it) for it in _load_locked()]


def keys():
    with _LOCK:
        return [str(it.get("rating_key")) for it in _load_locked()]


def is_favorite(rating_key):
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    with _LOCK:
        return any(str(it.get("rating_key")) == rk for it in _load_locked())


def set_favorite(rating_key, on, plex_type="", title=""):
    """Returns True when the stored state is now ``on``."""
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    with _LOCK:
        items = [it for it in _load_locked() if str(it.get("rating_key")) != rk]
        if on:
            items.insert(0, {
                "rating_key": rk,
                "plex_type": str(plex_type or ""),
                "title": str(title or ""),
                "added_at": int(time.time()),
            })
        try:
            _save_locked(items)
        except Exception as exc:
            _log("SAVE_FAILED rating_key=%s err=%s" % (rk, exc), xbmc.LOGERROR)
            return not on
        _log("SET rating_key=%s on=%d type=%s count=%d" % (rk, 1 if on else 0, plex_type, len(items)))
        return bool(on)


def toggle(rating_key, plex_type="", title=""):
    return set_favorite(rating_key, not is_favorite(rating_key), plex_type=plex_type, title=title)


# ------------------------------------------------------------------ R121 external
# YouTube (and later OTT plugin) favorites.  key = "<source>:<kind>:<id>",
# e.g. "yt:video:abc", "yt:channel:UC..", "yt:playlist:PL..".  The record keeps
# what the 즐겨찾기 screen needs to draw and open it without a network call.

def ext_key(source, kind, iid):
    return "%s:%s:%s" % (source, kind, iid)


def ext_list(source=None):
    """Newest first."""
    with _LOCK:
        return [dict(it) for it in _ext_locked() if not source or it.get("source") == source]


def ext_keys(source=None):
    with _LOCK:
        return [str(it.get("key")) for it in _ext_locked() if not source or it.get("source") == source]


def ext_is_favorite(key):
    key = str(key or "")
    with _LOCK:
        return any(str(it.get("key")) == key for it in _ext_locked())


def ext_set(key, on, rec=None):
    """rec: source, kind, id, title, thumb, fanart, channel, channel_id, meta."""
    key = str(key or "").strip()
    if not key:
        return False
    with _LOCK:
        items = list(_load_locked())
        ext = [it for it in _ext_locked() if str(it.get("key")) != key]
        if on:
            row = dict(rec or {})
            row["key"] = key
            row["added_at"] = int(time.time())
            ext.insert(0, row)
        try:
            _save_locked(items, ext)
        except Exception as exc:
            _log("EXT_SAVE_FAILED key=%s err=%s" % (key, exc), xbmc.LOGERROR)
            return not on
        _log("EXT_SET key=%s on=%d count=%d" % (key, 1 if on else 0, len(ext)))
        return bool(on)


def any_favorites():
    with _LOCK:
        return bool(_load_locked()) or bool(_ext_locked())


def signature():
    """Changes whenever any favorite (Plex or external) is added/removed."""
    with _LOCK:
        return tuple(str(it.get("rating_key")) for it in _load_locked()) + tuple(
            str(it.get("key")) for it in _ext_locked())
