# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import pkm_cine21_import
from resources.lib import pkm_watcha_import

ADDON_ID = "plugin.video.km"
STATE_NAME = "ratings_service_bridge.json"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] [RATINGS_SERVICE_BRIDGE_V2374] %s" % (ADDON_ID, msg), level)


def _profile():
    p = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


def _state_path():
    return os.path.join(_profile(), STATE_NAME)


def _read_state():
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            x = json.load(f)
        return x if isinstance(x, dict) else {}
    except Exception:
        return {}


def _write_state(data):
    p = _state_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)




def _service_install_snapshot_v2375():
    try:
        addon = xbmcaddon.Addon("service.pkm.ratings")
        return {
            "installed": True,
            "version": str(addon.getAddonInfo("version") or ""),
        }
    except Exception:
        return {"installed": False, "version": ""}

def _service_state():
    win = xbmcgui.Window(10000)
    state_file = win.getProperty("PKM.Ratings.StateFile") or ""
    if not state_file or not os.path.isfile(state_file):
        state_file = xbmcvfs.translatePath(
            "special://profile/addon_data/service.pkm.ratings/state.json"
        )
    try:
        with open(state_file, "r", encoding="utf-8") as f:
            state = json.load(f)
        return state if isinstance(state, dict) else {}
    except Exception:
        return {}


def _items_ready(conn):
    try:
        has = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='items'"
        ).fetchone()
        if not has:
            return False
        row = conn.execute(
            "SELECT COUNT(*) FROM items WHERE "
            "(plex_type='movie' OR kodi_type='movie')"
        ).fetchone()
        return bool(row and int(row[0] or 0) > 0)
    except Exception:
        try:
            row = conn.execute("SELECT COUNT(*) FROM items").fetchone()
            return bool(row and int(row[0] or 0) > 0)
        except Exception:
            return False


def sync_if_needed(core):
    """Apply service Master DBs and locally rematch changed PKM movie rows.

    v2377 authority rules:
      * Cine21 runtime web lookup is forbidden.
      * service.pkm.ratings Master DB is the only Cine21 ratings source.
      * a changed Master SHA performs a full import+match.
      * an unchanged Master with changed local movie rows performs a local-only
        incremental rematch against the already imported ``cine21_ratings`` table.
    """
    install = _service_install_snapshot_v2375()
    if not install.get("installed"):
        _log("RATINGS_SERVICE_MISSING_V2375 status=dependency_missing", xbmc.LOGWARNING)
        return {"status": "service_missing"}
    remote = _service_state()
    dbs = remote.get("databases") or {}
    if not dbs:
        _log("RATINGS_MASTER_WAIT_V2375 service_version=%s" % (install.get("version") or "-"))
        return {"status": "service_not_ready", "service_version": install.get("version") or ""}

    conn = None
    try:
        conn = core.init_db()
        if not _items_ready(conn):
            return {"status": "library_not_ready"}

        local = _read_state()
        applied = local.get("applied") or {}
        signatures = local.get("library_signatures") or {}
        result = {"status": "ok", "changed": False, "providers": {}}

        cine = dbs.get("cine21") or {}
        cine_path = cine.get("path") or ""
        cine_sha = cine.get("sha256") or ""
        cine_ready = bool(cine_path and os.path.isfile(cine_path) and cine_sha)
        if cine_ready:
            # v2377 one-time authority cleanup: even when SHA did not change,
            # re-import once so any rows previously mutated by the legacy
            # post-reveal cine21.com crawler are discarded. Thereafter the
            # Master SHA is authoritative and local library changes are rematched
            # without network access.
            authority_ready = bool(local.get("cine21_master_authority_v2377"))
            full_import_needed = (applied.get("cine21") != cine_sha) or (not authority_ready)
            if full_import_needed:
                started = time.time()
                stats = pkm_cine21_import.run_import_and_match(conn, cine_path, progress_cb=None)
                applied["cine21"] = cine_sha
                local["cine21_master_authority_v2377"] = True
                signatures["cine21"] = pkm_cine21_import.local_movie_signature(conn)
                result["changed"] = True
                result["providers"]["cine21"] = stats
                _log("CINE21_MASTER_AUTHORITY_APPLIED_V2377 sha=%s reason=%s elapsed=%.2fs stats=%s network=0" % (
                    cine_sha[:12], "master_sha_changed" if authority_ready else "legacy_web_cleanup_once",
                    time.time() - started, stats
                ))
            else:
                current_sig = pkm_cine21_import.local_movie_signature(conn)
                previous_sig = signatures.get("cine21") or {}
                if current_sig != previous_sig:
                    started = time.time()
                    stats = pkm_cine21_import.refresh_matches_from_local_master(conn, progress_cb=None)
                    signatures["cine21"] = current_sig
                    if int(stats.get("changed", 0) or 0) > 0:
                        result["changed"] = True
                    result["providers"]["cine21_local_rematch"] = stats
                    _log("CINE21_LOCAL_REMATCH_V2377 sha=%s elapsed=%.2fs signature_changed=1 stats=%s network=0" % (
                        cine_sha[:12], time.time() - started, stats
                    ))

        watcha = dbs.get("watcha") or {}
        watcha_path = watcha.get("path") or ""
        watcha_sha = watcha.get("sha256") or ""
        if watcha_path and os.path.isfile(watcha_path) and watcha_sha and applied.get("watcha") != watcha_sha:
            started = time.time()
            stats = pkm_watcha_import.run_import_watcha_build_db(conn, watcha_path, progress_cb=None)
            applied["watcha"] = watcha_sha
            result["changed"] = True
            result["providers"]["watcha"] = stats
            _log("WATCHA_APPLIED sha=%s elapsed=%.2fs stats=%s" % (
                watcha_sha[:12], time.time() - started, stats
            ))

        local["schema"] = 2
        local["applied"] = applied
        local["library_signatures"] = signatures
        local["last_checked_at"] = int(time.time())
        _write_state(local)
        return result

    except Exception:
        _log("SYNC_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
        return {"status": "error", "error": traceback.format_exc()}
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def status_snapshot():
    remote = _service_state()
    local = _read_state()
    install = _service_install_snapshot_v2375()
    if not install.get("installed"):
        status = "service_missing"
    elif remote.get("databases"):
        status = "ready"
    else:
        status = "service_not_ready"
    return {
        "status": status,
        "service": install,
        "remote": remote,
        "local": local,
    }
