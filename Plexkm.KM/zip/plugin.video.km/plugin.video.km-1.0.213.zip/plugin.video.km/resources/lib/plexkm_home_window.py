# SIDEBAR_FAST_WIDGET_V2703R1 local_continue=1 cold_hold=160 settle=80 max_hold=1800
# PKM_PATCH_ACTIVE v2642 plex_cast_visual_parity
# INFO_CAST_POLICY_V2642 plex_role_thumb=direct_kodi_bind missing_role_thumb=placeholder plex_visual_parity=1 no_actor_name_hardcode=1 no_title_hardcode=1
# PKM_PATCH_ACTIVE v2660 uhd3_home_sidebar_hotpath
# PKM_PATCH_ACTIVE v2641 sidebar_scene_outlier_trace
# SIDEBAR_KPI_POLICY_V2641 no_clamp=1 no_threshold_filter=1 no_behavior_change=1 correlate_scene_token=1 visual_vs_completion_proof=1
# PKM_PATCH_ACTIVE v2639 global_sidebar_destination_ready
# SIDEBAR_POLICY_V2639 common_ready_contract=1 initial_build=1 add_remove=1 movie_tv_common=1 post_home_first_focus_rebuild=0 spinner_hide_only=0
# PKM_PATCH_ACTIVE v2638 startup_destination_barrier_restore
# STARTUP_POLICY_V2638 selection_or_content_change=prepare_before_home_ready harmless_maintenance=defer_allowed post_home_sidebar_rebuild=0
# PKM_PATCH_ACTIVE v2637r2 cast_firstframe_structural
# INFO_CAST_POLICY_V2637R2 plex_role_direct=1 reuse_direct=1 atomic_hold=0 sync_localize_firstframe=0
# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import sys
import time
import importlib
import traceback
import threading
import weakref
import os
import json
import random
import unicodedata
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import re
from io import BytesIO
from urllib.request import Request, urlopen
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit, quote, unquote
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from resources.lib import pkm_notify
from resources.lib import pkm_info_data
from resources.lib import pkm_recommend_data
from resources.lib import pkm_tv_recommend
from resources.lib import pkm_movie_recommend
from resources.lib import pkm_library_sort
from resources.lib import pkm_sort_index_v2626
from resources.lib import pkm_transition_manager
from resources.lib import pkm_global_busy
from resources.lib import pkm_artwork_scheduler
from resources.lib import pkm_uhd_diag_v2600
from resources.lib import pkm_ott
from resources.lib import pkm_media_versions
from resources.lib import pkm_media_version_select
from resources.lib import pkm_episode_flow_v2222
from resources.lib.pkm_video_info import apply_video_info
from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171



# ==== PKM_RO_DB_POOL_U4_20261011 - bounded thread-local read-only SQLite helper ====
import sqlite3 as _pkm_ro_sqlite3
import threading as _pkm_ro_threading
import weakref as _pkm_ro_weakref
import os as _pkm_ro_os
from collections import OrderedDict as _pkm_ro_OrderedDict

_PKM_RO_TLS_U4 = _pkm_ro_threading.local()
_PKM_RO_POOL_LIMIT_U4 = 4

class _PKMPooledReadConnU4(object):
    __slots__ = ("_conn", "_cursors")

    def __init__(self, conn):
        self._conn = conn
        self._cursors = []

    def execute(self, *args, **kwargs):
        cur = self._conn.execute(*args, **kwargs)
        self._cursors.append(_pkm_ro_weakref.ref(cur))
        return cur

    def close(self):
        # Complete statements before another writer or cache rebuild accesses DB.
        for ref in self._cursors:
            cur = ref()
            if cur is not None:
                try:
                    cur.close()
                except Exception:
                    pass
        self._cursors[:] = []

    def __getattr__(self, attr):
        return getattr(self._conn, attr)

def _pkm_ro_connect(path, *args, **kwargs):
    # Fall back for special SQLite paths; U4 modifies only verified read-only sites.
    if args or not isinstance(path, str) or not path or path.startswith(":") or path.startswith("file:"):
        return _pkm_ro_sqlite3.connect(path, *args, **kwargs)
    try:
        stat = _pkm_ro_os.stat(path)
    except OSError:
        return _pkm_ro_sqlite3.connect(path, *args, **kwargs)
    path = _pkm_ro_os.path.normcase(_pkm_ro_os.path.abspath(path))
    identity = (stat.st_dev, stat.st_ino)
    try:
        timeout_ms = max(0, int(float(kwargs.get("timeout", 5.0)) * 1000))
    except (TypeError, ValueError):
        return _pkm_ro_sqlite3.connect(path, *args, **kwargs)
    pool = getattr(_PKM_RO_TLS_U4, "pool", None)
    if pool is None:
        pool = _pkm_ro_OrderedDict()
        _PKM_RO_TLS_U4.pool = pool
    entry = pool.get(path)
    if entry is not None and entry[0] != identity:
        # A DB swapped via os.replace must never reuse the old handle.
        pool.pop(path, None)
        try:
            entry[2].close()
        except Exception:
            pass
        entry = None
    if entry is None:
        conn = _pkm_ro_sqlite3.connect(path, **kwargs)
        pool[path] = (identity, timeout_ms, conn)
    else:
        conn = entry[2]
        if entry[1] != timeout_ms:
            # sqlite3.connect(timeout=...) varies at the call sites (80ms..5s).
            # Without this step a pooled GUI call could unexpectedly wait 5s.
            conn.execute("PRAGMA busy_timeout=%d" % timeout_ms).close()
            pool[path] = (identity, timeout_ms, conn)
        pool.move_to_end(path)
    while len(pool) > _PKM_RO_POOL_LIMIT_U4:
        _, stale = pool.popitem(last=False)
        try:
            stale[2].close()
        except Exception:
            pass
    return _PKMPooledReadConnU4(conn)

# ==== end PKM_RO_DB_POOL_U4_20261011 ====

def _is_android_platform_v1931():
    """Return Kodi's real Android platform flag without model guessing."""
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        return False


# PKM_PATCH_ACTIVE v2595 uhd_runtime_minimal_disable_focus_audit
# pkm_focus_audit is diagnostic-only.  On the weak Android target every
# onAction/onFocus audit write competes with Kodi's GUI/input thread, so keep
# the hooks on desktop but make them true no-ops on Android.
_PKM_ANDROID_RUNTIME_V2595 = _is_android_platform_v1931()
if _PKM_ANDROID_RUNTIME_V2595:
    def audit_event(*args, **kwargs):
        return None
    def start_focus_monitor(*args, **kwargs):
        return None


def _pkm_full_reset_active_v2150():
    try:
        win = xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.FullResetInProgressV2150") == "1"
            or win.getProperty("PlexKM.FullResetInProgressV2149") == "1"
            or win.getProperty("PlexKM.Home.BackgroundAbortV2150") == "1"
        )
    except Exception:
        return False


def _pkm_playback_active_v1411():
    """True while video playback is opening or active.

    v1450: Kodi can spend 10+ seconds between PKM handoff and usable video.
    During that interval Player.HasVideo is not reliable yet, but Home cast
    prewarm/search workers can still keep issuing Plex HTTP requests. Treat the
    native-opening spinner/pending handoff properties as playback-active too so
    background network jobs stop immediately when the user presses Play.
    """
    if _pkm_full_reset_active_v2150():
        return True
    try:
        if xbmc.getCondVisibility("Player.HasVideo"):
            return True
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        # v2118: the user's Play command is a priority boundary before Kodi has
        # a Player.HasVideo surface.  Background Plex/artwork/prewarm workers
        # must yield from the click itself, not several seconds later at AVStarted.
        if win.getProperty("PlexKM.Playback.PriorityV2118") == "1":
            return True
        if win.getProperty("PlexKM.SeekQuick.Committing") == "1":
            return True
        if win.getProperty("PlexKM.Playback.OpeningActive") == "1":
            return True
        if win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1":
            return True
        if win.getProperty("PlexKM.Playback.NativeOpening") == "1":
            return True
        if win.getProperty("PlexKM.MainPlaybackStarting") == "1":
            return True
    except Exception:
        pass
    return False

def _load_core_module():
    """Resolve default.py core functions reliably.

    WindowXML can be opened through RunScript/autostart where __main__ is not
    always plugin.video.km/default.py.  Do not trust __main__ unless it
    actually exposes the Plex KM core API.
    """
    try:
        mod = sys.modules.get("__main__")
        if mod is not None and hasattr(mod, "fetch_sections") and hasattr(mod, "query_items_wall_light"):
            return mod
    except Exception:
        pass
    try:
        addon_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        if addon_dir and addon_dir not in sys.path:
            sys.path.insert(0, addon_dir)
    except Exception:
        pass
    try:
        mod = sys.modules.get("default")
        if mod is not None and hasattr(mod, "fetch_sections"):
            return mod
    except Exception:
        pass
    return importlib.import_module("default")


def _ensure_core():
    global core
    try:
        if core is not None and hasattr(core, "fetch_sections") and hasattr(core, "query_items_wall_light"):
            return core
    except Exception:
        pass
    core = _load_core_module()
    return core



def _pkm_play_params(rating_key="", part_key="", mode="start", view_offset="", duration_ms="", audio_stream_index=""):
    """Central PKM playback policy.

    Kodi's stock resume dialog is not part of PKM UX.  Every PKM playback URL
    must carry an explicit start policy.

    mode=start/play/default -> start=0 + noresume=1
    mode=resume             -> resume_offset=<Plex ms offset>, only when available
    """
    params = {"action": "play", "rating_key": rating_key or "", "part_key": part_key or ""}
    if str(audio_stream_index if audio_stream_index is not None else "").strip() not in ("", "-1"):
        params["audio_stream_index"] = str(audio_stream_index).strip()
    m = str(mode or "start").lower()
    if m == "resume" and str(view_offset or "").strip():
        params["resume_offset"] = str(view_offset or "").strip()
        try:
            _dur_ms = max(0, int(float(duration_ms or 0)))
        except Exception:
            _dur_ms = 0
        if _dur_ms > 0:
            params["resume_duration_ms"] = str(_dur_ms)
        params["pkm_resume_policy"] = "resume"
    else:
        params["start"] = "0"
        params["noresume"] = "1"
        params["pkm_resume_policy"] = "start"
    return params


def _pkm_play_url(rating_key="", part_key="", mode="start", view_offset="", duration_ms="", audio_stream_index=""):
    return _ensure_core().build_plugin_url(_pkm_play_params(rating_key, part_key, mode=mode, view_offset=view_offset, duration_ms=duration_ms, audio_stream_index=audio_stream_index))


def _pkm_no_resume_url(url):
    """Append start=0 to old PKM play URLs that do not yet contain a start policy.

    This protects every remaining PlayMedia() handoff path from re-enabling
    Kodi's native resume popup if a stale PlexKM.PlayUrl property was created by
    an older code path.
    """
    u = str(url or "")
    if not u:
        return u
    low = u.lower()
    if "plugin.video.km" not in low or "action=play" not in low:
        return u
    if "resume_offset=" in low:
        return u
    if "start=" in low:
        if "noresume=" in low:
            return u
        sep = "&" if "?" in u else "?"
        return u + sep + "noresume=1&pkm_resume_policy=start"
    sep = "&" if "?" in u else "?"
    return u + sep + "start=0&noresume=1&pkm_resume_policy=start"

try:
    core = _load_core_module()
except Exception:
    core = None

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_SELECT_ITEM = 7
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_CONTEXT_MENU = 117
ACTION_SHOW_INFO = 11
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
# Kodi remote/page actions. Some builds do not expose named constants to Python; keep local numeric guards.
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
# Kodi mouse actions. Mouse hover/wheel can change a native list selection while
# WindowXML briefly reports focus_id=0, so they must participate in sidebar
# selection/content ownership reconciliation.
ACTION_MOUSE_WHEEL_UP = 104
ACTION_MOUSE_WHEEL_DOWN = 105
ACTION_MOUSE_MOVE = 107

MENU_ID = 9000
MENU_COLLAPSED_ID = 9001
SIDEBAR_COMMIT_PING_ID_V2595 = 100
# V2800: verified-image-format memo for TV Info episode stills (info_tv.py reads this global)
_INFO_TV_PROBE_MEMO_V2800 = {}
# R29: one presentation fingerprint computation at a time (see
# _persistent_presentation_fingerprint_v2487).
_R29_PRESENTATION_FP_LOCK = threading.Lock()
# V2801: ten writers of the section/library prepared-cache JSON shared one fixed
# "<path>.tmp" name; concurrent GUI + worker stores failed in os.replace with
# FileNotFoundError (kodi.log 2026-11-11 16:07:48). Serialize them here.
_PKM_CACHE_JSON_WRITE_LOCK_V2801 = threading.Lock()


def _pkm_write_cache_json_v2801(path, entries):
    """Atomically write {"version": 2471, "entries": entries} to path. Raises on failure."""
    tmp = path + ".tmp"
    with _PKM_CACHE_JSON_WRITE_LOCK_V2801:
        # dict() snapshot: other threads may add keys while json.dump iterates.
        payload = {"version": 2471, "entries": dict(entries or {})}
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, path)


def _pkm_modal_over_home_v2804():
    """True while a modal dialog (e.g. the PKM update confirm) is above Home.

    executebuiltin("Action(Right)") goes to the topmost window, so Home's
    automatic sidebar folds moved the update dialog's focus 300 -> 301.
    Same modal test as default.py R86.
    """
    try:
        if xbmc.getCondVisibility("System.HasModalDialog"):
            return True
        return int(xbmcgui.getCurrentWindowDialogId()) not in (0, -1, 9999)
    except Exception:
        return False
# PKM_PATCH_ACTIVE v2595r2 sidebar_debounce_bootstrap_control100_no_xml_dependency
SEARCH_FIXED_ID = 8990
WALL_ID = 9100
HOME_ROW_IDS = tuple(range(9410, 9610, 10))  # 9410~9600: Home rows for Continue Watching + all sidebar libraries
# v1617: one canonical physical row schema for both A/B banks.
# Kodi XML controls are static, so the section landing page uses the same explicit
# 20-row capacity as Home. Every Python loop derives from this registry and a
# runtime schema check prevents silent truncation if XML and Python ever diverge.
SECTION_RECOMMEND_ROW_CAPACITY = 20
SECTION_RECOMMEND_ROW_IDS_A = tuple(range(8410, 8410 + SECTION_RECOMMEND_ROW_CAPACITY * 10, 10))
SECTION_RECOMMEND_ROW_IDS_B = tuple(range(8610, 8610 + SECTION_RECOMMEND_ROW_CAPACITY * 10, 10))
SECTION_RECOMMEND_ROW_IDS = SECTION_RECOMMEND_ROW_IDS_A  # legacy/default alias
SECTION_RECOMMEND_PREV_ROW_IDS = SECTION_RECOMMEND_ROW_IDS_B  # v1555 Home refresh still borrows hidden bank B
SECTION_RECOMMEND_ALL_ROW_IDS = SECTION_RECOMMEND_ROW_IDS_A + SECTION_RECOMMEND_ROW_IDS_B
RECOMMEND_BUILD_CONTEXT_V1616 = threading.local()  # data-only movie compose worker context


class PKMPrepareAbortR103(BaseException):
    """R103: raised at a checkpoint of a data-only sidebar prepare when the user
    asked for another section (BaseException so broad `except Exception`
    fallbacks inside the row builders do not swallow it)."""


SIDEBAR_PREFETCH_DWELL_MS_R103 = 650  # R103: sidebar focus must rest this long before a section prefetch starts


INFO_MOVIE_WIDGET_ROW_IDS = (6210, 6220, 6230)  # v2433: movie actor-work parity restored to three declared rows.
INFO_TV_ACTOR_WIDGET_ROW_IDS = (6310, 6320, 6330)  # v2066 TV Info: same actor-work rows, isolated from movie layout
INFO_ACTOR_WORK_ROW_IDS_V2082 = INFO_MOVIE_WIDGET_ROW_IDS + INFO_TV_ACTOR_WIDGET_ROW_IDS
HOME_LIKE_ROW_IDS = HOME_ROW_IDS + SECTION_RECOMMEND_ALL_ROW_IDS + INFO_MOVIE_WIDGET_ROW_IDS + INFO_TV_ACTOR_WIDGET_ROW_IDS
HOME_ROW_COUNT = len(HOME_ROW_IDS)
# v2393: Home/Section hero lower block is moved up 20px as one fixed layout (summary Y=340, widget Y=520).
# This stays item-independent to avoid focus-to-focus vertical jitter.
# v2275: Home/Section widget rows share one physical XML geometry.  The number
# of populated recommendation rows is dynamic, but every logical row is exactly
# one 447px block (52 title + 4 gap + 390 panel + 1 bottom reserve).  Keep the
# Python visual-stack anchor unit identical to XML so any number of rows stays
# pinned to the same viewport position while Kodi XML owns directional focus.
WIDGET_ROW_PITCH_V2275 = 447
WIDGET_PANEL_TOP_V2275 = 56
WIDGET_PANEL_HEIGHT_V2275 = 390
HOME_WIDGET_OUTER_TOP_V2275 = 520
SECTION_WIDGET_OUTER_TOP_V2275 = 520
HOME_ROW_VIEWPORT_ID = 9298
HOME_ROW_STACK_ID = 9297
SECTION_RECOMMEND_ROW_VIEWPORT_ID = 8298
SECTION_RECOMMEND_ROW_STACK_ID = 8297
SECTION_RECOMMEND_ROW_STACK_ID_B = 8397
HOME_ROW_ANCHOR_SCOPE = "home"
SECTION_ROW_ANCHOR_SCOPE = "section"
HOME_ROW_ITEM_LIMIT = 24
# R154: only Section > Recommend rows are capped. Home and Library stay unchanged.
SECTION_RECOMMEND_DEFAULT_LIMIT_R154 = 12
SECTION_RECOMMEND_RESUME_REWATCH_LIMIT_R154 = 20
SECTION_RECOMMEND_POLICY_R154 = "section20_12_v1"
# v1341: cast photo prewarm prioritizes continue/taste rows and high-quality placeholders.
# v1342: continue/duplicate-title cast thumbs use Plex/DB sibling metadata and profile fallback before placeholder.
# v1343: continue-row cast source follows the same canonical library metadata used by recommendation widgets; placeholder art has no baked-in border.
# v1344: continue/onDeck actor photos use recommendation-key source first.
# v1876: missing Role thumbs never trigger Plex people-name network searches; reuse local indexed actor art or placeholder.
# v1877: Search visible posters outrank speculative cast work; reuse disk poster cache and use foreground texture loading.
# The previous v1339 42-entry enqueue was still too broad and could push the
# item the user actually clicks behind unrelated section rows.  Keep the first
# two visible/partly-visible rows and one right-scroll page per row only:
# 2 rows * (7 visible + 7 right-buffer) = 28.  Other libraries are warmed
# later with a small idle budget and negative-cache failures are skipped.
CAST_PREWARM_VISIBLE_COLS_V1339 = 7
CAST_PREWARM_RIGHT_BUFFER_COLS_V1339 = 7
CAST_PREWARM_ROWS_V1339 = 2
CAST_PREWARM_VISIBLE_LIMIT_V1339 = CAST_PREWARM_ROWS_V1339 * (CAST_PREWARM_VISIBLE_COLS_V1339 + CAST_PREWARM_RIGHT_BUFFER_COLS_V1339)
CAST_PREWARM_WORKERS_V1340 = 2  # desktop; V2659 clamps Android to 1
CAST_PREWARM_NEGATIVE_TTL_MS_V1340 = 30 * 60 * 1000
WALL_ITEM_WIDTH_ID = 9191
WALL_WIDTH_ID = 9192
TITLE_ID = 9200
COUNT_ID = 9101
SECTION_TAB_RECOMMEND_ID = 7710
SECTION_TAB_LIBRARY_ID = 7720
SECTION_TAB_CATEGORY_ID = 7725
SECTION_CATEGORY_PANEL_ID = 9150
SECTION_SORT_BUTTON_ID = 7730
SECTION_INDEX_ID = 7740
# R107: sorts that get a right-side index (all but 무작위; title has its own # A ㄱ index).
_INDEX_SORTS_R107 = ("added", "year", "release", "first_air", "viewed", "recent_air", "tmdb",
                     "cine21", "watcha", "imdb", "progress", "unwatched", "seasons", "status",
                     "resolution", "bitrate")
SECTION_SORT_ITEM_IDS = tuple(range(7741, 7753))
# v1911: the 12 native buttons are reused, but their keys/labels are resolved
# from the active section type (movie or TV) at runtime.
EMPTY_HOME_SETTINGS_BUTTON_ID = 5858

# Inline search panel controls (only active after OK on the Search sidebar item).
SEARCH_QUERY_LABEL_ID = 2100
SEARCH_MODE_LABEL_ID = 2101
SEARCH_KEYBOARD_ID = 3000
SEARCH_RESULTS_ID = 4000
SEARCH_BEST_ID = 4200
SEARCH_HISTORY_ID = 4300
SEARCH_HISTORY_CLEAR_ID = 4301
SEARCH_EMPTY_LABEL_ID = 4100
SEARCH_SCOPE_TOGGLE_ID = 2110
# 통합 검색: 탭(전체/영화/드라마/YouTube), 가로 줄(row)과 탭 전체보기(grid) 패널
SEARCH_TAB_SCOPES = {2110: "all", 2111: "movie", 2112: "tv", 2113: "youtube"}
SEARCH_RESULT_IDS = (4200, 4000, 4010, 4020, 4001, 4011, 4021)
SEARCH_YT_IDS = (4020, 4021)
SEARCH_ALL_ROW_LIMIT = 8  # R90: 전체 탭의 영화/드라마 줄은 8개 + "+N 더 보기" 타일
SEARCH_ALL_YT_LIMIT = 3  # R96: 넓은 썸네일 3개 + "+N 모두 보기" 타일 (화면 폭 1756)
SEARCH_QUERY_PILL_ID = 2105  # R96: 상단 검색창(누르면 키보드 서랍이 열림)
SEARCH_SUG_IDS = tuple(range(2121, 2129)) + tuple(range(2141, 2147))  # R96: 추천 검색어 칩

# v306: Home movie trailer preview.  A focused movie poster must stay focused
# for 3 seconds before we start the preview in the fanart rectangle.
HOME_TRAILER_FOCUS_DELAY_MS = 3000
# v307: If Plex Extras has no trailer, use YouTube addon playable URL as fallback.
HOME_TRAILER_ENABLE_YOUTUBE_FALLBACK = True
# v1243: temporarily disable PKM Home trailer playback during Plex 16:9 UI alignment work.
# Re-enable later by setting this to False or removing the early return in _schedule_home_trailer_preview.
HOME_TRAILER_TEMP_DISABLED = True


# R7 passive KPI telemetry: no database, network or GUI traversal.
_PKM_R7_START_MONO = time.monotonic()
_PKM_R7_LAST_MILESTONE = {}
_PKM_R7_LAST_FOCUS = [0, 0.0]
_PKM_R7_MILESTONE_PREFIXES = (
    "SIDEBAR_UI_LIBRARY_VISIBLE", "KPI_LIBRARY_VISIBLE", "SECTION_TRUE_AB_",
    "SIDEBAR_SELECTION_OWNER_DRIFT", "SECTION_CONTINUE_RENDER_INVARIANT",
    "INFO_TV_VERSION_GROUPS", "INFO_MOVIE_VERSION", "INFO_TV_VERSION",
    "ACTOR_PROFILE", "ACTOR_FILMOGRAPHY", "ACTOR_CAST", "CAST_TRACE",
    "STARTUP_", "FIRST_SETUP_", "HOME_READY", "HOME_PUBLISH",
    "LIBRARY_STARTUP", "SECTION_STARTUP", "INFO_ENTER", "INFO_OPEN",
    "PLEX_CLIENT_SPLIT_TRACE", "SECTION_RENDER_SNAPSHOT", "LIBRARY_RENDER_SNAPSHOT",
)

def _pkm_r7_milestone(msg):
    try:
        head = str(msg or '').split(' ', 1)[0]
        if not head.startswith(_PKM_R7_MILESTONE_PREFIXES):
            return
        now = time.monotonic()
        prev = _PKM_R7_LAST_MILESTONE.get(head)
        _PKM_R7_LAST_MILESTONE[head] = now
        # Direct core.log avoids recursive _log calls. One line per milestone;
        # suppress very frequent identical events to protect Shield flash/CPU.
        if prev is None or now - prev >= 0.25:
            core.log('WINDOW_HOME KPI_R7 milestone=%s uptime_ms=%d since_same_ms=%d' % (
                head, int((now - _PKM_R7_START_MONO) * 1000),
                int((now - prev) * 1000) if prev is not None else -1), xbmc.LOGINFO)
    except Exception:
        pass

def _pkm_r7_focus(control_id, section):
    try:
        now = time.monotonic()
        cid = int(control_id or 0)
        if cid == _PKM_R7_LAST_FOCUS[0] and now - _PKM_R7_LAST_FOCUS[1] < 0.5:
            return
        elapsed = int((now - _PKM_R7_LAST_FOCUS[1]) * 1000) if _PKM_R7_LAST_FOCUS[1] else -1
        _PKM_R7_LAST_FOCUS[:] = [cid, now]
        core.log('WINDOW_HOME KPI_R7 focus=%d section=%s since_focus_ms=%d uptime_ms=%d' % (
            cid, str(section or '')[:48], elapsed,
            int((now - _PKM_R7_START_MONO) * 1000)), xbmc.LOGINFO)
    except Exception:
        pass

def _log(msg, level=xbmc.LOGINFO):
    try:
        text_v2584 = str(msg or "")
        if level == xbmc.LOGINFO:
            if "PKM_PATCH_ACTIVE" in text_v2584:
                return
            # V2595: release navigation telemetry must never become part of the
            # navigation workload on Android flash storage. Keep milestone/error
            # logs, but suppress high-frequency per-key/per-item INFO chatter.
            if _PKM_ANDROID_RUNTIME_V2595 and text_v2584.startswith((
                "MENU_FOCUS_OBSERVE ",
                "SIDEBAR_MENU_BROWSING_SET ",
                "SIDEBAR_NATIVE_NAV_COMMIT_TIMING_V2173 ",
                "LIBRARY_SELECTION_OWNER_V2070 ",
                "SECTION_INDEX_ACTIVE_V1494 ",
                "HOME_META_TIMING ",
                "PERSISTENT_POSTER_LOCAL_BIND_BYPASS_V2498 ",
                "WALL_FIRST_KEY_SYNC ",
                "ROW_VERTICAL_NATIVE_ONLY_V2385 ",
                "WALL_NAV_INPUT_ONLY_V2600 ",
                "LIBRARY_NATIVE_COLUMN_TRACE_V2073 ",
                "LIBRARY_POSTER_AHEAD_PREFETCH_SUPPRESS_V1865 ",
                "LIBRARY_NAV_CAST_PREWARM_SUPPRESS_V2576 ",
                "WALL_TRACK_NO_HARDCODE ",
                "ROW_XML_NAV ",
                "WIDGET_NAV_FOREGROUND_ONLY_V2599 ",
                "WIDGET_ONFOCUS_FOREGROUND_ONLY_V2599 ",
                "WIDGET_META_ARM_V2600 ",
                "WIDGET_META_REPLACE_V2600 ",
                "SIDEBAR_POST_V2599 ",
                "LIBRARY_APPEND_REQUEST_V2077 ",
                "LIBRARY_APPEND_COMMIT_DEFER_TO_TRACK_V2579 ",
                "LIBRARY_APPEND_IDLE_DEFER_V2600 ",
            )):
                return
            # V2584: these are per-item diagnostic floods, not state transitions.
            # Dropping them while the splash is up removes hundreds of Android
            # log writes without hiding the startup PERF/BUDGET markers.
            try:
                startup_pending_v2584 = xbmcgui.Window(10000).getProperty("PlexKM.Home.StartupReadyV1619") != "1"
            except Exception:
                startup_pending_v2584 = False
            if startup_pending_v2584 and text_v2584.startswith((
                "HOME_RECENT_SKIP_",
                "PERSISTENT_POSTER_LOCAL_BIND_BYPASS_",
                "HOME_ROW_BLOCK_METRIC",
                "HOME_ROW_POSTER_METRIC",
                "HOME_ROW_BLOCK_GEOMS",
                "RESUME_PROGRESS_",
                "SECTION_STARTUP_DATA_READY_",
                "LIBRARY_STARTUP_DATA_READY_",
                "SECTION_RENDER_SNAPSHOT_PREBUILD_",
                "LIBRARY_RENDER_SNAPSHOT_PREBUILD_",
            )):
                return
        _pkm_r7_milestone(text_v2584)
        core.log("WINDOW_HOME " + text_v2584, level)
    except Exception:
        xbmc.log("[plugin.video.km] WINDOW_HOME " + str(msg or ""), level)


# v2151: every Python worker created by the live Home module is registered so
# destructive full reset can prove that no recommendation/cast/poster/sync
# worker remains alive before the profile directory is deleted.  The subclass
# is behavior-compatible with threading.Thread; it only adds weak registration.
_PKM_HOME_THREADS_V2151_LOCK = threading.RLock()
_PKM_HOME_THREADS_V2151 = weakref.WeakSet()
_PKM_HOME_FULL_RESET_STOP_V2151 = threading.Event()


# PKM_PATCH_ACTIVE v2591 uhd3_foreground_isolation_worker_gate
_PKM_UHD3_SPECULATIVE_THREAD_PREFIXES_V2591 = (
    "PKMCanonicalMovieIndexV1942",
    "PlexKMWatchaPreloadV1642",
    "PlexKMCine21PostRevealV1645",
    "PlexKMRecommendPrewarm",
    "PlexKMAllSectionPrewarmV1649",
    "PlexKMLibraryAutoSnapshotV2476",
    "PlexKMSearchIndexRefresh",
    "PlexKMCastPrewarmV1340",
    "PKMMovieMediaPrewarmV2106",
    "PKMTVMediaVersionV2112",
    # PKM_PATCH_ACTIVE v2593 uhd3_hard_minimal_navigation_worker_expansion
    # These jobs are all post-visible/decorative.  They may prepare lower rows,
    # indexes or richer metadata, but none is allowed to compete with remote-key
    # navigation on the 2.75 GB Android target.
    "PKMLibraryIndexV2585",
    "PlexKMStartupRecentSync",
    "PlexKMTVDynamicRows",
    "PlexKMTVStudioMore",
    "PlexKMMovieExtraRows",
    "PlexKMTVCastAfterRowsV1792",
)


def _pkm_uhd3_speculative_worker_blocked_v2591(thread_name):
    """Return True only for Android speculative work while foreground must win."""
    try:
        if not xbmc.getCondVisibility("System.Platform.Android"):
            return False
        name = str(thread_name or "")
        if not any(name.startswith(prefix) for prefix in _PKM_UHD3_SPECULATIVE_THREAD_PREFIXES_V2591):
            return False
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.Home.StartupReadyV1619") != "1":
            return True
        if win.getProperty("PlexKM.Sidebar.Browsing") == "1":
            return True
        if win.getProperty("PlexKM.WallRapidScrollV2581") == "1":
            return True
        until_epoch = int(float(win.getProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386") or 0))
        return bool(until_epoch and int(time.time() * 1000) < until_epoch)
    except Exception:
        return False


class _PKMHomeThreadV2151(threading.Thread):
    def __init__(self, *args, **kwargs):
        threading.Thread.__init__(self, *args, **kwargs)
        try:
            with _PKM_HOME_THREADS_V2151_LOCK:
                _PKM_HOME_THREADS_V2151.add(self)
        except Exception:
            pass

    def run(self):
        # V2591: speculative DB/network work may exist, but it must not execute
        # while Android is starting Home or while remote-control navigation is hot.
        # This gate never owns focus and never delays the caller/input callback.
        try:
            name = str(getattr(self, "name", "") or "")
            if any(name.startswith(prefix) for prefix in _PKM_UHD3_SPECULATIVE_THREAD_PREFIXES_V2591):
                started = _pkm_speed_ms()
                logged = False
                mon = xbmc.Monitor()
                while _pkm_uhd3_speculative_worker_blocked_v2591(name):
                    if not logged:
                        _log("UHD3_FOREGROUND_WORKER_YIELD_V2591 name=%s reason=startup_or_navigation" % name)
                        logged = True
                    if (_pkm_speed_ms() - started) >= (8000 if _PKM_ANDROID_RUNTIME_V2595 else 120000):
                        _log("UHD3_FOREGROUND_WORKER_DROP_V2659 name=%s waited_ms=%d action=drop_stale_speculative" % (name, _pkm_speed_ms() - started))
                        return
                    if mon.waitForAbort(0.12) or _PKM_HOME_FULL_RESET_STOP_V2151.is_set():
                        return
                if logged:
                    _log("UHD3_FOREGROUND_WORKER_RESUME_V2591 name=%s waited_ms=%d" % (name, _pkm_speed_ms() - started))
        except Exception:
            pass
        return threading.Thread.run(self)


def _pkm_home_live_threads_v2151(exclude=None):
    out = []
    try:
        with _PKM_HOME_THREADS_V2151_LOCK:
            items = list(_PKM_HOME_THREADS_V2151)
    except Exception:
        items = []
    for t in items:
        try:
            if t is exclude or not t.is_alive():
                continue
            out.append(t)
        except Exception:
            continue
    return out


# v1642: Watcha rows are immutable for a DB mtime.  Keep one process-wide map
# so WindowXML recreation after playback does not re-read 16k+ rows on the GUI path.
_HOME_WATCHA_SHARED_CACHE_V1642 = {
    "lock": threading.Lock(),
    "db_path": "",
    "db_mtime": None,
    "cache": None,
    "loaded_at": 0.0,
}



# v1632: completed Home/section scenes must outlive one WindowXML instance.
# Kodi closes and recreates PlexKMHomeWindow when entering some native windows
# (notably Settings).  v1620-v1622 kept revisit state only on ``self``, so the
# new instance forgot every completed scene and treated a revisit as cold.
# Keep a small atomic pickle in addon_data, but bind it to a token stored on
# Window(10000).  The token disappears on a real Kodi restart, which deletes the
# stale file and preserves the intended first-start spinner behavior.
_HOME_SESSION_CACHE_LOCK_V1632 = threading.RLock()


# v1904: real startup milestones own the visible logo fill.  The image control
# advances through the existing user-provided frames, rather than playing a
# fixed-duration multiimage sequence that can finish too early or restart.
_STARTUP_PROGRESS_ANIM_LOCK_V1891 = threading.RLock()
_STARTUP_PROGRESS_ANIM_EVENT_V1891 = threading.Event()
_STARTUP_PROGRESS_ANIM_THREAD_V1891 = None
_STARTUP_PROGRESS_TARGET_V1891 = 0.0
_STARTUP_PROGRESS_REASON_V1891 = ""
_STARTUP_PROGRESS_STEP_SEC_V1891 = 0.020
_STARTUP_PROGRESS_CONTROL_V1894 = None
_STARTUP_PROGRESS_IMAGE_CONTROL_V1904 = None
_STARTUP_PROGRESS_FRAME_INDEX_V1904 = -1
_STARTUP_PROGRESS_FRAME_COUNT_V1904 = 240
_STARTUP_PROGRESS_FRAME_ROOT_V1904 = "special://home/addons/skin.plex.km/media/startup/plexkm_loading_v3_pfirst_frames"
# v2378R8: real visual completion handshake. The Home reveal waits for the
# startup image worker to publish frame 119; Home readiness itself remains
# state-driven and has no timeout.
_STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8 = threading.Event()


def _startup_progress_frame_path_v1904(value):
    value = max(0.0, min(100.0, float(value)))
    index = int(round((value / 100.0) * (_STARTUP_PROGRESS_FRAME_COUNT_V1904 - 1)))
    return index, "%s/frame_%03d.png" % (_STARTUP_PROGRESS_FRAME_ROOT_V1904, index)


def _startup_progress_publish_display_v1891(value, reason=""):
    global _STARTUP_PROGRESS_FRAME_INDEX_V1904
    try:
        value = max(0.0, min(100.0, float(value)))
        text = ("%.2f" % value).rstrip("0").rstrip(".")
        why = str(reason or "")
        win = xbmcgui.Window(10000)
        if win.getProperty('PlexKM.Startup.LinearLogoToken'):
            # R80: actual preparation milestones are diagnostic only.
            return
        win.setProperty("PlexKM.Startup.DisplayProgressV1891", text)
        win.setProperty("PlexKM.Startup.DisplayReasonV1891", why)
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.DisplayProgressV1891,%s,home)" % text)
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.DisplayReasonV1891,%s,home)" % why.replace(",", " "))
        control = _STARTUP_PROGRESS_CONTROL_V1894
        if control is not None:
            try:
                control.setPercent(float(value))
            except Exception:
                pass
        image_control = _STARTUP_PROGRESS_IMAGE_CONTROL_V1904
        frame_index, frame_path = _startup_progress_frame_path_v1904(value)
        # v2388: mirror the current real frame path to the skin Startup.xml
        # binding as well. This keeps the pre-Home splash and WindowXML cover
        # on the same monotonic logo fill with no frame_000 reset.
        win.setProperty("PlexKM.Startup.BootFramePathV2388", frame_path)
        xbmc.executebuiltin("SetProperty(PlexKM.Startup.BootFramePathV2388,%s,home)" % frame_path)
        if image_control is not None and frame_index != int(_STARTUP_PROGRESS_FRAME_INDEX_V1904):
            try:
                image_control.setImage(frame_path, False)
                _STARTUP_PROGRESS_FRAME_INDEX_V1904 = frame_index
                win.setProperty("PlexKM.Startup.DisplayFrameV1904", str(frame_index))
                if frame_index >= (_STARTUP_PROGRESS_FRAME_COUNT_V1904 - 1):
                    _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.set()
                    win.setProperty("PlexKM.Startup.FinalFrameReadyV2378R8", "1")
                    _log("STARTUP_LOGO_FINAL_FRAME_READY_V2378R8 frame=%d progress=%.2f" % (
                        frame_index, value
                    ))
            except Exception:
                pass
        elif frame_index >= (_STARTUP_PROGRESS_FRAME_COUNT_V1904 - 1):
            # The control can already be on frame 119 when the same 100% value
            # is republished. Preserve the completion handshake.
            _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.set()
            win.setProperty("PlexKM.Startup.FinalFrameReadyV2378R8", "1")
    except Exception:
        pass


def _startup_progress_animation_worker_v1891():
    global _STARTUP_PROGRESS_ANIM_THREAD_V1891
    try:
        monitor = xbmc.Monitor()
        last_logged = -1
        while not monitor.abortRequested():
            if _PKM_HOME_FULL_RESET_STOP_V2151.is_set() or _pkm_full_reset_active_v2150():
                _log("STARTUP_LOGO_WORKER_STOP_V2151 reason=full_reset")
                break
            with _STARTUP_PROGRESS_ANIM_LOCK_V1891:
                target = float(_STARTUP_PROGRESS_TARGET_V1891)
                reason = str(_STARTUP_PROGRESS_REASON_V1891 or "")
            # SHIELD startup logo is driven by the service's 4-second linear clock.
            # Do not race or accelerate its 120 frames using data milestones.
            linear_win = xbmcgui.Window(10000)
            linear_token = linear_win.getProperty('PlexKM.Startup.LinearLogoToken')
            if linear_token:
                # R80: service owns visible frames; home only observes completion.
                if (linear_win.getProperty('PlexKM.Startup.LinearLogoCompleteR80') == '1'
                        and linear_win.getProperty('PlexKM.Startup.DisplayFrameV1904') == '239'):
                    _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.set()
                    linear_win.setProperty('PlexKM.Startup.FinalFrameReadyV2378R8', '1')
                if monitor.waitForAbort(0.05):
                    break
                continue
            # V2702R3: Android changes cadence only; it never forces 100%.
            fast_startup_logo = bool(xbmc.getCondVisibility("System.Platform.Android"))
            if fast_startup_logo and not reason:
                reason = "fast_startup_logo_v2702r3"
            try:
                win = xbmcgui.Window(10000)
                current = float(win.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0")
            except Exception:
                current = 0.0
            if current + 0.001 < target:
                # V2516: a verified fast startup must still *show* the logo reaching
                # 100%. V2500 jumped directly from the current visible frame to frame
                # 119 in one worker tick, which made a healthy startup look as if the
                # yellow fill had been cut off. Keep the real milestone ownership,
                # but let the already-rendering worker traverse the remaining frames
                # quickly and monotonically. No Home/data work is added here.
                fast_final_tail_v2516 = bool(
                    target >= 99.999
                    and (
                        "v2500_ready_fast" in reason
                        or "v2558r3_initial_fast" in reason
                    )
                )
                gap = max(0.0, target - current)
                # v2118: the target is still owned only by real startup
                # milestones, but visible catch-up is adaptive.  v1996 advanced
                # at roughly one frame every 20ms, creating an artificial ~2.6s
                # minimum even when Home was already ready.  When the real target
                # is far ahead we traverse several existing frames per tick; as
                # the display approaches the milestone it automatically returns
                # to one-frame steps. Slow preparation therefore still holds at
                # the real milestone, while a fast local startup finishes fast.
                frame_percent = 100.0 / float(max(1, _STARTUP_PROGRESS_FRAME_COUNT_V1904 - 1))
                if fast_startup_logo:
                    # V2702R3 / U+ KPI: one visual frame per tick; no jump.
                    step = min(gap, frame_percent)
                    current = min(target, current + step)
                    _startup_progress_publish_display_v1891(current, reason=reason)
                    current_int = int(current)
                    if current_int in (1, 10, 25, 50, 75, 90, 92, 100) and current_int != last_logged:
                        last_logged = current_int
                        _log("STARTUP_LOGO_SMOOTH_V2702R3 display=%.2f target=%.2f" % (current, target))
                    if monitor.waitForAbort(0.008):
                        break
                    continue
                frames_behind = gap / max(0.001, frame_percent)
                if fast_final_tail_v2516:
                    # About 0.25-0.35s for the typical 55-60 -> 100 final catch-up:
                    # fast enough to feel immediate, slow enough to visibly fill.
                    if frames_behind >= 22.0:
                        frames_per_tick = 5.0
                    elif frames_behind >= 8.0:
                        frames_per_tick = 3.0
                    else:
                        frames_per_tick = 2.0
                elif frames_behind >= 72.0:
                    frames_per_tick = 6.0
                elif frames_behind >= 36.0:
                    frames_per_tick = 4.0
                elif frames_behind >= 18.0:
                    frames_per_tick = 3.0
                elif frames_behind >= 8.0:
                    frames_per_tick = 2.0
                else:
                    frames_per_tick = 1.0
                step = min(gap, frame_percent * 0.92 * frames_per_tick)
                current = min(target, current + step)
                _startup_progress_publish_display_v1891(current, reason=reason)
                current_int = int(current)
                if current_int in (1, 10, 25, 50, 75, 90, 100) and current_int != last_logged:
                    last_logged = current_int
                    _log("STARTUP_LOGO_REAL_PROGRESS_V1904 display=%.2f target=%.2f reason=%s" % (current, target, reason))
                if monitor.waitForAbort(_STARTUP_PROGRESS_STEP_SEC_V1891):
                    break
                continue
            _STARTUP_PROGRESS_ANIM_EVENT_V1891.clear()
            if monitor.waitForAbort(0.05):
                break
    except Exception:
        _log("STARTUP_LOGO_REAL_PROGRESS_WORKER_FAILED_V1904 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    finally:
        with _STARTUP_PROGRESS_ANIM_LOCK_V1891:
            _STARTUP_PROGRESS_ANIM_THREAD_V1891 = None


def _startup_progress_set_target_v1891(value, reason=""):
    global _STARTUP_PROGRESS_ANIM_THREAD_V1891, _STARTUP_PROGRESS_TARGET_V1891, _STARTUP_PROGRESS_REASON_V1891
    try:
        value = max(0.0, min(100.0, float(value)))
        with _STARTUP_PROGRESS_ANIM_LOCK_V1891:
            if value > float(_STARTUP_PROGRESS_TARGET_V1891):
                _STARTUP_PROGRESS_TARGET_V1891 = value
                _STARTUP_PROGRESS_REASON_V1891 = str(reason or "")
            thread = _STARTUP_PROGRESS_ANIM_THREAD_V1891
            if thread is None or not thread.is_alive():
                thread = _PKMHomeThreadV2151(target=_startup_progress_animation_worker_v1891, name="PKMStartupLogoFillV1904", daemon=True)
                thread.daemon = True
                _STARTUP_PROGRESS_ANIM_THREAD_V1891 = thread
                thread.start()
        _STARTUP_PROGRESS_ANIM_EVENT_V1891.set()
    except Exception:
        pass


def _startup_progress_reset_v1904(reason=""):
    """Re-arm the Home-owned progress worker without rewinding visible startup."""
    global _STARTUP_PROGRESS_TARGET_V1891, _STARTUP_PROGRESS_REASON_V1891, _STARTUP_PROGRESS_FRAME_INDEX_V1904
    try:
        win = xbmcgui.Window(10000)
        preserve_service_progress_v2378r8 = (
            win.getProperty("PlexKM.SkinStartupSplash") == "1"
        )
        if preserve_service_progress_v2378r8:
            try:
                visible_v2378r8 = max(
                    0.0,
                    min(
                        100.0,
                        float(win.getProperty("PlexKM.Startup.DisplayProgressV1891") or "0"),
                    ),
                )
            except Exception:
                visible_v2378r8 = 0.0
        else:
            visible_v2378r8 = 0.0

        _STARTUP_PROGRESS_FINAL_FRAME_EVENT_V2378R8.clear()
        win.clearProperty("PlexKM.Startup.FinalFrameReadyV2378R8")
        with _STARTUP_PROGRESS_ANIM_LOCK_V1891:
            _STARTUP_PROGRESS_TARGET_V1891 = float(visible_v2378r8)
            _STARTUP_PROGRESS_REASON_V1891 = str(reason or "")

        base_progress_v2378r8 = int(visible_v2378r8)
        win.setProperty("PlexKM.Startup.ProgressV1845", str(base_progress_v2378r8))
        win.setProperty("PlexKM.Startup.ProgressReasonV1845", str(reason or ""))

        if preserve_service_progress_v2378r8:
            # The service already displayed frame 3/8 before opening Home.
            # Keep that frame and continue forward; never visibly rewind to 0.
            _startup_progress_publish_display_v1891(
                visible_v2378r8,
                reason="home_bind_preserve:%s" % (reason or ""),
            )
            _log(
                "STARTUP_PROGRESS_PRESERVE_V2378R8 display=%.2f base=%d reason=%s"
                % (visible_v2378r8, base_progress_v2378r8, reason or "")
            )
        else:
            _STARTUP_PROGRESS_FRAME_INDEX_V1904 = -1
            _startup_progress_publish_display_v1891(0.0, reason=reason)
    except Exception:
        pass

def _startup_progress_v1845(value, reason="", force=False):
    """Publish real startup progress; 100 is reserved for verified visual readiness."""
    try:
        value = max(0, min(100, int(value)))
        why_guard_v2052 = str(reason or "")
        # V2501: keep V2052's fail-closed 100% guard, but explicitly authorize
        # the V2500 unchanged-start fast-final token because it is emitted only
        # after the exact same full Home/data/texture visual-readiness contract
        # has already passed. V2500 introduced a new verified reason string but
        # V2052 only whitelisted the legacy literal, which clamped 100 -> 99 and
        # left the final-frame event unreachable. Do not broaden this to a prefix
        # match: only these two exact verified tokens may ever publish 100%.
        allowed_100_reasons_v2501 = (
            "startup_visual_ready_verified_v2052",
            "startup_visual_ready_verified_v2500_ready_fast",
            "startup_visual_ready_verified_v2558r3_initial_fast",
        )
        if value >= 100 and why_guard_v2052 not in allowed_100_reasons_v2501:
            value = 99
            force = False
            _log("STARTUP_PROGRESS_100_BLOCKED_V2052 reason=%s action=clamp99" % why_guard_v2052, xbmc.LOGWARNING)
        elif value >= 100 and why_guard_v2052 == "startup_visual_ready_verified_v2500_ready_fast":
            _log("STARTUP_PROGRESS_100_ACCEPTED_V2501 reason=%s contract=verified_visual_ready exact_allowlist=1" % why_guard_v2052)
        win = xbmcgui.Window(10000)
        current = int(win.getProperty("PlexKM.Startup.ProgressV1845") or "0")
        if force or value > current:
            text = str(value)
            why = str(reason or "")
            win.setProperty("PlexKM.Startup.ProgressV1845", text)
            win.setProperty("PlexKM.Startup.ProgressReasonV1845", why)
            # v1847: Window.setProperty from the WindowXML worker updates storage,
            # but Kodi's progress control may keep its first cached value.  The
            # builtin home-property path invalidates the skin info label on the GUI
            # thread, so every real startup milestone visibly advances the bar.
            xbmc.executebuiltin("SetProperty(PlexKM.Startup.ProgressV1845,%s,home)" % text)
            xbmc.executebuiltin("SetProperty(PlexKM.Startup.ProgressReasonV1845,%s,home)" % why.replace(",", " "))
            _log("STARTUP_PROGRESS_V1847 value=%d reason=%s gui_invalidate=1" % (value, why))
            _startup_progress_set_target_v1891(value, reason=why)
        else:
            _startup_progress_set_target_v1891(value, reason=str(reason or ""))
    except Exception:
        pass

def _remove_legacy_home_session_cache_v2034():
    """Delete the removed V1632 persistent scene cache if an older build left it behind."""
    try:
        profile = xbmcaddon.Addon("plugin.video.km").getAddonInfo("profile") or ""
        profile = xbmcvfs.translatePath(profile)
        for name in ("pkm_home_session_cache_v1632.pkl", "pkm_home_session_cache_v1632.pkl.tmp"):
            path = os.path.join(profile, name)
            if os.path.isfile(path):
                os.remove(path)
        win = xbmcgui.Window(10000)
        for key in (
            "PlexKM.Home.SessionCacheTokenV1632",
            "PlexKM.Home.SessionCacheRestoredV1632",
            "PlexKM.Home.SessionCacheRestoredAtV1632",
            "PlexKM.Home.SessionCacheSavedAtV1632",
        ):
            win.clearProperty(key)
    except Exception:
        pass

def _short_log_value(value, limit=180):
    try:
        text = str(value or "")
    except Exception:
        text = ""
    if len(text) > limit:
        return text[:limit] + "..."
    return text


def _pkm_speed_ms():
    try:
        return int(time.perf_counter() * 1000)
    except Exception:
        return int(time.time() * 1000)


def _speed_log(event, **kwargs):
    try:
        parts = ["[PKM_SPEED]", str(event)]
        for key in sorted(kwargs.keys()):
            try:
                value = kwargs.get(key)
                parts.append("%s=%s" % (key, _short_log_value(value, 120)))
            except Exception:
                pass
        _log(" ".join(parts))
    except Exception:
        pass


def _display_library_title(value):
    """Return a Kodi-WindowXML-safe display title for Plex library names.

    Root cause: Plex can render several vertical-line lookalikes as a pipe with
    its own font/fallback stack, while Kodi WindowXML renders the exact Unicode
    code point using the active skin font only.  If the raw title contains an
    unsupported vertical-line code point, Kodi shows a missing-glyph square.
    Normalize only those equivalent vertical separators to ASCII '|'.
    """
    text = str(value or "")
    try:
        table = {
            ord("\u2223"): "|",  # DIVIDES
            ord("\u2758"): "|",  # LIGHT VERTICAL BAR
            ord("\u2759"): "|",  # MEDIUM VERTICAL BAR
            ord("\u275A"): "|",  # HEAVY VERTICAL BAR
            ord("\uFFE8"): "|",  # HALFWIDTH FORMS LIGHT VERTICAL
            ord("\uFF5C"): "|",  # FULLWIDTH VERTICAL LINE
            ord("\u2502"): "|",  # BOX DRAWINGS LIGHT VERTICAL
            ord("\u2503"): "|",  # BOX DRAWINGS HEAVY VERTICAL
            ord("\u23AA"): "|",  # CURLY BRACKET EXTENSION
            ord("\u23D0"): "|",  # VERTICAL LINE EXTENSION
            ord("\u2016"): "|",  # DOUBLE VERTICAL LINE
            ord("\u01C0"): "|",  # LATIN LETTER DENTAL CLICK
            ord("\u00A6"): "|",  # BROKEN BAR
            ord("\u4E28"): "|",  # CJK UNIFIED IDEOGRAPH vertical stroke
            ord("\u3163"): "|",  # HANGUL LETTER I
        }
        display = text.translate(table)
        if display != text:
            try:
                cps = " ".join("U+%04X" % ord(ch) for ch in text)
                _log("LIBRARY_TITLE_DISPLAY_NORMALIZED raw=%s display=%s cps=%s" % (_short_log_value(text, 120), _short_log_value(display, 120), cps))
            except Exception:
                pass
        return display
    except Exception:
        return text


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _join_tags(node, tag_name):
    try:
        vals = []
        for child in node.findall(tag_name):
            value = child.get("tag") or child.get("title") or child.get("name") or ""
            if value and value not in vals:
                vals.append(value)
        return " / ".join(vals)
    except Exception:
        return ""


def _extract_cast_slots(node, max_count=8):
    """Return Plex role entries for the info dialog credit rail.

    This function only reads actor name/role/thumb attributes from the Plex
    metadata response.  v181 logs every step so we can see whether the failure
    is Plex metadata, Kodi native cast container, or DialogVideoInfo fallback.
    """
    slots = []
    try:
        if node is None:
            _log("CAST_TRACE extract_start result=no_node", xbmc.LOGWARNING)
            return slots
        roles = node.findall("Role")
        try:
            role_count = len(roles)
        except Exception:
            role_count = -1
        _log("CAST_TRACE extract_start max_count=%d plex_role_count=%s" % (max_count, role_count))
        for child in roles:
            raw_name = child.get("tag") or child.get("title") or child.get("name") or ""
            name = raw_name.strip() if hasattr(raw_name, "strip") else raw_name
            role = child.get("role") or child.get("character") or ""
            raw_thumb = child.get("thumb") or child.get("art") or ""
            thumb = _plex_art(raw_thumb, width=320, height=320)
            if not name:
                _log("CAST_TRACE extract_skip reason=empty_name raw_thumb=%s" % _short_log_value(raw_thumb), xbmc.LOGWARNING)
                continue
            slot_index = len(slots) + 1
            _log(
                "CAST_TRACE slot%d name=%s role=%s raw_thumb=%s resolved_thumb=%s" % (
                    slot_index,
                    _short_log_value(name, 80),
                    _short_log_value(role, 80),
                    _short_log_value(raw_thumb),
                    _short_log_value(thumb),
                )
            )
            slots.append({
                "Name": name,
                "Role": role,
                "Thumb": thumb,
                "RawThumb": raw_thumb,
            })
            if len(slots) >= max_count:
                _log("CAST_TRACE extract_limit_reached count=%d" % len(slots))
                break
    except Exception:
        _log("CAST_TRACE extract_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    _log("CAST_TRACE extract_done slot_count=%d" % len(slots))
    return slots




def _kodi_cast_from_slots(slots):
    """Build Kodi native cast data for DialogVideoInfo container 50.

    In v181 we keep the current visual behavior but log exactly what is sent to
    Kodi.  If Kodi shows images in container 50, this step tells us whether the
    thumbnail came from the supplied cast thumbnail or from Kodi's own cache.
    """
    cast_items = []
    try:
        _log("CAST_TRACE kodi_cast_build_start slot_count=%d" % len(slots or []))
        for slot in slots or []:
            name = str(slot.get("Name") or "").strip()
            if not name:
                _log("CAST_TRACE kodi_cast_skip reason=empty_name", xbmc.LOGWARNING)
                continue
            role = str(slot.get("Role") or "").strip()
            thumb = _clean_external_image_url(str(slot.get("Thumb") or "").strip())
            item = {"name": name}
            if role:
                item["role"] = role
            if thumb:
                item["thumbnail"] = thumb
                thumb_source = "supplied_thumb"
            else:
                thumb_source = "none_kodi_may_resolve"
            cast_items.append(item)
            _log("CAST_TRACE kodi_cast_item index=%d name=%s role=%s thumb_source=%s thumb=%s" % (
                len(cast_items),
                _short_log_value(name, 80),
                _short_log_value(role, 80),
                thumb_source,
                _short_log_value(thumb),
            ))
    except Exception:
        _log("CAST_TRACE kodi_cast_build_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
    _log("CAST_TRACE kodi_cast_build_done count=%d" % len(cast_items))
    return cast_items


def _first_metadata_node(root):
    if root is None:
        return None
    for name in ("Video", "Directory"):
        node = root.find("./" + name)
        if node is not None:
            return node
    try:
        children = list(root)
        return children[0] if children else None
    except Exception:
        return None


def _clean_external_image_url(value):
    """Return a display-safe external image URL.

    Plex art paths such as /library/metadata/... need X-Plex-Token, but TMDb
    actor photos are already public https URLs. Passing those through
    core.art_url() appends the Plex token to image.tmdb.org, which can make
    Kodi's image loader fail. Keep external image URLs untouched and strip any
    stale Plex token that may have been attached by older builds.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    lower = text.lower()
    if lower.startswith("http://") or lower.startswith("https://"):
        for marker in ("?X-Plex-Token=", "&X-Plex-Token=", "?x-plex-token=", "&x-plex-token="):
            idx = text.find(marker)
            if idx >= 0:
                return text[:idx]
        return text
    return text


def _plex_art(value, width=1280, height=720):
    if not value:
        return ""
    try:
        cleaned = _clean_external_image_url(value)
        if cleaned.lower().startswith(("http://", "https://")):
            # v1038: rows cached before/through Plex may contain absolute PMS image
            # URLs without X-Plex-Token.  Kodi then requests them as-is and PMS
            # returns 401, which makes TV episode cards black.  Normalize only
            # URLs that point to the configured Plex server; external actor/CDN
            # images must remain untouched.
            try:
                server = (core.clean_server_url() if hasattr(core, "clean_server_url") else "") or ""
            except Exception:
                server = ""
            try:
                token = (core.plex_token() if hasattr(core, "plex_token") else "") or ""
            except Exception:
                token = ""
            if server and token and cleaned.startswith(server) and "X-Plex-Token=" not in cleaned:
                sep = "&" if "?" in cleaned else "?"
                return cleaned + sep + "X-Plex-Token=" + token
            return cleaned
        return core.art_url(cleaned, width=width, height=height)
    except Exception:
        return _clean_external_image_url(value)


def _cast_remote_display_url_v2608(value, width=342):
    """Fast visible actor-photo URL without PKM's local-file download gate.

    Plex Role metadata often already contains a public TMDb portrait URL.  The
    old Info path refused to expose that URL until PKM had downloaded its own
    local copy, so a 20-40ms metadata lookup could become a 1-3s photo wait.
    For visible Info we let Kodi own the image fetch/cache and only shrink TMDb
    originals to a bounded portrait size.  Plex-relative/server artwork still
    goes through the normal authenticated art URL helper.
    """
    try:
        text = _clean_external_image_url(value)
        if not text:
            return ""
        lower = text.lower()
        if lower.startswith(("http://", "https://")):
            if "image.tmdb.org/t/p/" in lower:
                text = re.sub(r"/t/p/(?:original|w\d+)/", "/t/p/w342/", text, count=1, flags=re.I)
            return _plex_art(text, width=width, height=width)
        return _plex_art(text, width=width, height=width)
    except Exception:
        return _clean_external_image_url(value)


def _pkm_info_image_url(value, width=1920, height=1080):
    """Return a Kodi texture URL safe for the inline Info screen.

    v1331: Info publishes Window.Property(PlexKM.Info.Art/Thumb) directly to
    skin image controls.  Some DB/ListItem rows contain absolute Plex library
    art URLs without X-Plex-Token, unlike Home fanart which already goes
    through _home_fanart_display_url().  Kodi then loads PMS artwork
    anonymously and the Info screen background fails with HTTP 401.  Normalize
    only Plex/server paths while leaving local/special/external URLs intact.
    """
    try:
        text = str(value or "").strip()
    except Exception:
        text = str(value or "")
    if not text:
        return ""
    lower = text.lower()
    if lower.startswith(("special://", "resource://", "image://", "plugin://", "file://")):
        return text
    try:
        # Windows local paths such as C:\... must not be routed through Plex.
        if len(text) >= 3 and text[1] == ":" and text[2] in ("\\", "/"):
            return text
    except Exception:
        pass
    if lower.startswith(("http://", "https://")) or text.startswith("/"):
        return _plex_art(text, width=width, height=height)
    return text


class PKMHomeExitConfirmDialog(xbmcgui.WindowXMLDialog):
    """Small PKM-styled center confirmation dialog for Home Back exit."""
    YES_ID = 300
    NO_ID = 301

    def __init__(self, *args, **kwargs):
        self.result = False
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        # v1938: the exit dialog must settle on 종료.  The XML already declares
        # control 300 as the always-default control; do not override it to 취소
        # after the first frame, which caused the visible focus snap reported on Android.
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        # v1969: XML defaultcontrol=300 owns initial focus.  Do not issue a
        # second Python focus write after the first frame; that visible snap is
        # indistinguishable from an automatic button move on Android remotes.
        _log("HOME_EXIT_CONFIRM_XML_FOCUS_OWNER_V1969 defaultcontrol=300 python_focus_write=0")

    def onClick(self, controlId):
        audit_event(self, "onClick", control_id=controlId)
        if controlId == self.YES_ID:
            self.result = True
            # v2187: keep the opaque PKM confirm dialog alive underneath the
            # countdown until Kodi itself quits.  The old path closed this modal
            # first and only then started the countdown from _show_home_exit_confirm;
            # that exposed the previous Home/Info surface for one render frame.
            # Start the common 3-2-1 dialog while this full-screen surface still
            # owns the screen.  No focus/navigation ownership is changed.
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.App.Quitting", "1")
            except Exception:
                pass
            try:
                pkm_notify.pkm_notice_clear(force=True)
            except Exception:
                pass
            if not getattr(self, "_exit_countdown_started_v2187", False):
                try:
                    self._exit_countdown_started_v2187 = True
                    t_v2187 = _PKMHomeThreadV2151(
                        target=request_kodi_exit_v2171,
                        kwargs={
                            "reason": "home_exit_confirm_v2187",
                            "title": "Kodi 종료",
                            "detail": "",
                        },
                        name="PKMHomeExitCountdownV2187",
                        daemon=True,
                    )
                    t_v2187.daemon = True
                    t_v2187.start()
                    _log("HOME_EXIT_COUNTDOWN_PREMODAL_HANDOFF_V2187 confirm_stays_open=1 previous_surface_exposed=0")
                    return
                except Exception:
                    self._exit_countdown_started_v2187 = False
                    _log("HOME_EXIT_COUNTDOWN_PREMODAL_HANDOFF_FAILED_V2187 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            # Emergency fallback only: let the legacy caller continue if the
            # countdown worker itself could not be started.
            self.close()
        elif controlId == self.NO_ID:
            self.result = False
            self.close()

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        try:
            aid = action.getId()
        except Exception:
            aid = 0
        if aid in (9, ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 216, 247):
            self.result = False
            self.close()


def _home_exit_confirm_prop_keys():
    keys = [
        "PlexKM.Confirm.Title",
        "PlexKM.Confirm.Message",
        "PlexKM.Confirm.Yes",
        "PlexKM.Confirm.No",
        "PlexKM.Confirm.Icon1",
        "PlexKM.Confirm.Icon2",
        "PlexKM.Confirm.HasIcons",
        "PlexKM.Confirm.HasCine21Rows",
        "PlexKM.Confirm.Cine21LogoIcon",
        "PlexKM.Confirm.Cine21CriticIcon",
        "PlexKM.Confirm.Cine21AudienceIcon",
        "PlexKM.Confirm.BackdropColor",
        "PlexKM.Confirm.PanelBgColor",
        "PlexKM.Confirm.FadeOverlayColor",
        "PlexKM.Confirm.AppQuittingCoverColor",
        "PlexKM.Confirm.BlurArt",
    ]
    for idx in range(1, 4):
        keys.extend([
            "PlexKM.Confirm.Cine21.Row%d.Title" % idx,
            "PlexKM.Confirm.Cine21.Row%d.Critic" % idx,
            "PlexKM.Confirm.Cine21.Row%d.Audience" % idx,
            "PlexKM.Confirm.Cine21.Row%d.Visible" % idx,
        ])
    return keys


def _clear_home_exit_confirm_props():
    try:
        win = xbmcgui.Window(10000)
        for key in _home_exit_confirm_prop_keys():
            win.clearProperty(key)
    except Exception:
        pass


def _home_exit_confirm_normalize_argb_v2211(value, default="FF111214"):
    try:
        text = str(value or "").strip().upper().replace("#", "")
        if len(text) == 6:
            text = "FF" + text
        if len(text) != 8:
            return str(default or "FF111214")
        int(text, 16)
        return text
    except Exception:
        return str(default or "FF111214")


def _home_exit_confirm_color_props_v2211():
    try:
        win = xbmcgui.Window(10000)
        base = (
            win.getProperty("PlexKM.Info.DynamicBgColor")
            or win.getProperty("PlexKM.Home.DynamicBgColor")
            or "FF111214"
        )
        base = _home_exit_confirm_normalize_argb_v2211(base, default="FF111214")
        rgb = base[-6:].upper()
        return {
            "PlexKM.Confirm.BackdropColor": "FF" + rgb,
            "PlexKM.Confirm.PanelBgColor": "F2050607" if rgb == "111214" else ("F2" + rgb),
            "PlexKM.Confirm.FadeOverlayColor": "FF" + rgb,
            "PlexKM.Confirm.AppQuittingCoverColor": "FF" + rgb,
        }
    except Exception:
        return {
            "PlexKM.Confirm.BackdropColor": "FF111214",
            "PlexKM.Confirm.PanelBgColor": "F2050607",
            "PlexKM.Confirm.FadeOverlayColor": "FF111214",
            "PlexKM.Confirm.AppQuittingCoverColor": "FF111214",
        }


def _exit_blur_backdrop_url_r97():
    """R97I: blurred copy of the visible fanart for the exit card backdrop.

    Uses the Plex photo transcoder (blur=) on the same /library/metadata art
    the Home/Info hero shows.  Returns "" when there is no Plex fanart; the
    card then falls back to a plain dark overlay."""
    try:
        from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
        home = xbmcgui.Window(10000)
        src = ""
        try:
            if home.getProperty("PlexKM.Info.InlineActive") == "1":
                src = home.getProperty("PlexKM.Info.Art") or ""
        except Exception:
            src = ""
        if not src:
            try:
                src = xbmcgui.Window(13000).getProperty("PlexKM.Home.DisplayFanart") or ""
            except Exception:
                src = ""
        parts = urlsplit(src)
        if not (parts.scheme in ("http", "https") and parts.netloc):
            return ""
        query = dict(parse_qsl(parts.query, keep_blank_values=True))
        path = parts.path or ""
        if path.rstrip("/") == "/photo/:/transcode":
            path = query.get("url") or ""
        if not path.startswith("/library/"):
            return ""
        tq = {"width": "480", "height": "270", "minSize": "1", "upscale": "1",
              "blur": "36", "format": "jpg", "url": path}
        for k, v in query.items():
            if str(k or "").lower() == "x-plex-token":
                tq[k] = v
        return urlunsplit((parts.scheme, parts.netloc, "/photo/:/transcode", urlencode(tq), ""))
    except Exception:
        return ""


def _set_home_exit_confirm_props():
    try:
        win = xbmcgui.Window(10000)
        for key in _home_exit_confirm_prop_keys():
            win.clearProperty(key)
        win.setProperty("PlexKM.Confirm.Title", "Kodi를 종료할까요?")
        win.setProperty("PlexKM.Confirm.Message", "이어보기와 시청 기록은 그대로 남습니다")
        win.clearProperty("PlexKM.Confirm.Danger")
        win.setProperty("PlexKM.Confirm.BlurArt", _exit_blur_backdrop_url_r97())
        win.setProperty("PlexKM.Confirm.Yes", "종료")
        win.setProperty("PlexKM.Confirm.No", "취소")
        for _k_v2211, _v_v2211 in (_home_exit_confirm_color_props_v2211() or {}).items():
            try:
                win.setProperty(_k_v2211, str(_v_v2211 or ""))
            except Exception:
                pass
        win.setProperty("PlexKM.Confirm.HasIcons", "")
        win.setProperty("PlexKM.Confirm.HasCine21Rows", "")
    except Exception:
        _log("HOME_EXIT_CONFIRM_PROP_SET_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)


def open_pkm_home_exit_confirm_dialog():
    """Return True only when the user explicitly chooses 종료."""
    dlg = None
    try:
        _set_home_exit_confirm_props()
        addon_path = xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")
        dlg = PKMHomeExitConfirmDialog(
            "plexkm_pkm_card_confirm_dialog.xml",  # R97D: exit card (mockup X1)
            addon_path,
            "Default",
            "1080i",
        )
        dlg.doModal()
        return bool(getattr(dlg, "result", False))
    except Exception:
        _log("HOME_EXIT_CONFIRM_OPEN_FAILED no_kodi_fallback err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        return False
    finally:
        try:
            _clear_home_exit_confirm_props()
        except Exception:
            pass
        try:
            del dlg
        except Exception:
            pass


class _PKMRenderSnapshotItemV2476:
    """Pure-Python ListItem-shaped sink used only to serialize render state.

    It intentionally implements only the methods touched by _li_from_row().
    No Kodi native object/control is created or retained.
    """
    def __init__(self, label="", path=""):
        self._label = str(label or "")
        self._path = str(path or "")
        self._props = {}
        self._art = {}

    def setPath(self, value):
        self._path = str(value or "")

    def getPath(self):
        return self._path

    def setProperty(self, key, value):
        self._props[str(key)] = str(value or "")

    def getProperty(self, key):
        return str(self._props.get(str(key), "") or "")

    def setArt(self, values):
        for key, value in dict(values or {}).items():
            self._art[str(key)] = str(value or "")

    def getArt(self, key):
        return str(self._art.get(str(key), "") or "")

    def getLabel(self):
        return self._label


# FRAME_DIAG_CANONICAL
# Renderer-aware transition diagnostics. System.FPS is used only when Kodi
# actually exposes a numeric value. Scheduler-gap metrics are explicitly
# labelled as a proxy and are never reported as renderer FPS.
_FRAME_DIAG_LOCK = threading.Lock()
_FRAME_DIAG_TOKEN = 0

def _frame_diag_float(value):
    try:
        s = str(value or "").strip().replace("fps", "").strip()
        v = float(s)
        return v if v > 0.0 else None
    except Exception:
        return None

def _frame_diag_start(reason, window_ms=650):
    global _FRAME_DIAG_TOKEN
    try:
        with _FRAME_DIAG_LOCK:
            _FRAME_DIAG_TOKEN += 1
            token = int(_FRAME_DIAG_TOKEN)
        def _sample():
            started = time.monotonic()
            deadline = started + (max(250, int(window_ms)) / 1000.0)
            last = started
            gaps = []
            fps_values = []
            over_16 = over_33 = over_50 = 0
            while time.monotonic() < deadline:
                time.sleep(0.008)
                now = time.monotonic()
                gap_ms = (now - last) * 1000.0
                last = now
                gaps.append(gap_ms)
                if gap_ms > 16.7: over_16 += 1
                if gap_ms > 33.3: over_33 += 1
                if gap_ms > 50.0: over_50 += 1
                try:
                    fps = _frame_diag_float(xbmc.getInfoLabel("System.FPS"))
                    if fps is not None:
                        fps_values.append(fps)
                except Exception:
                    pass
            if not gaps:
                return
            ordered = sorted(gaps)
            p95 = ordered[min(len(ordered)-1, int(len(ordered) * 0.95))]
            max_gap = max(gaps)
            avg_gap = sum(gaps) / float(len(gaps))
            elapsed_ms = int((time.monotonic() - started) * 1000.0)
            if fps_values:
                fps_text = "source=System.FPS samples=%d min=%.1f avg=%.1f max=%.1f" % (
                    len(fps_values), min(fps_values), sum(fps_values)/float(len(fps_values)), max(fps_values))
            else:
                fps_text = "source=unavailable renderer_fps=not_exposed"
            _log("FRAME_DIAG_END token=%d reason=%s elapsed_ms=%d scheduler_proxy=1 sample_ms=8 samples=%d gap_avg_ms=%.2f gap_p95_ms=%.2f gap_max_ms=%.2f gap_over_16_7=%d gap_over_33_3=%d gap_over_50=%d %s" % (
                token, reason, elapsed_ms, len(gaps), avg_gap, p95, max_gap,
                over_16, over_33, over_50, fps_text))
        _log("FRAME_DIAG_BEGIN token=%d reason=%s window_ms=%d actual_renderer_fps=probe_System.FPS scheduler_proxy_separate=1" % (
            token, reason, int(window_ms)))
        t = threading.Thread(target=_sample, name="PKMFrameDiag", daemon=True)
        t.start()
        return token
    except Exception:
        try:
            _log("FRAME_DIAG_FAILED reason=%s err=%s" % (reason, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        except Exception:
            pass
        return 0


# R57: initial "초기 화면 구성" overlay (first run, library selection change,
# poster cache wiped).  Focus sits on a self-navigating dummy button.
_R57_INITIAL_COMPOSE_CAUSES = ("first_bootstrap", "selection_changed", "cache_wiped_r57")
_R57_OVERLAY_FOCUS_ID = 7957

class PlexKMHomeWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        # v2119: WindowXML control tree does not exist during Python __init__.
        # Keep an explicit lifecycle barrier so no helper can probe dynamic
        # sidebar control 9000 before Kodi has loaded plexkm_home_window.xml
        # and entered onInit().  getControl() logs Non-Existent Control in Kodi
        # before Python can catch the exception, so prevention is required.
        session_cache_v1632 = self._init_step1(kwargs)
        # v2492: persistent cache owns the restart-safe render snapshot. Startup
        # hydrates all selected destinations and GUI-prebuilds every snapshot that
        # is already complete, so normal sidebar/tab focus performs no DB/rating I/O.
        self._init_step2()
        self._init_step3()
        self._init_step4()
        self._init_step5()
        self._init_step6(args, session_cache_v1632)

    def _init_step1(self, kwargs):
        """Step 1 of __init__ (R76 split, moved verbatim)."""
        self._xml_controls_ready_v2119 = False
        _remove_legacy_home_session_cache_v2034()
        session_cache_v1632 = {}
        # v1841: every background task belongs to this WindowXML lifetime.
        # Kodi native objects become invalid as soon as the window closes, so
        # workers must be able to abandon queued/in-flight results without ever
        # applying them to a later/recreated window.
        self._closing_event_v1841 = threading.Event()
        self._lifecycle_monitor_v1841 = xbmc.Monitor()
        self._lifecycle_generation_v1841 = int(time.time() * 1000)
        self._startup_scene_composed_event_v1841 = threading.Event()
        self._startup_ready_event_v1841 = threading.Event()
        self._startup_texture_candidates_snapshot_v1841 = ()
        self._section_data_cache_lock_v1841 = threading.RLock()
        self._session_cache_restored_v1632 = bool(session_cache_v1632)
        self.start_index = kwargs.get("start_index", "home")
        # v2119 root fix: constructor-time sort normalization must be data-only.
        # _normalize_section_sort() may resolve the active section type through
        # _current_section_menu_item() -> getControl(9000), but WindowXML XML
        # controls are not instantiated until doModal()/onInit.  That indirect
        # probe was the recurring cold-start/settings-return
        # "EXCEPTION: Non-Existent Control 9000".  Accept every canonical
        # movie/TV sort key here; once a real section is active, normal runtime
        # code re-normalizes against that section's media kind.
        _requested_sort_v2119 = kwargs.get("sort", "title") or "title"
        self.sort = pkm_library_sort.normalize_sort_key(_requested_sort_v2119, media_kind=None)
        self.sort_dir = pkm_library_sort.default_sort_dir(self.sort)
        self.sections = []
        self.menu_ready = False
        self.active_menu_index = -999
        self.active_section_id = ""
        self.wall_offset = 0
        self.wall_total = 0
        self.wall_loading = False
        self._last_rendered_section_id = ""
        self._last_section_show_ms = 0
        self._append_guard = set()
        self._section_rows_cache = dict(session_cache_v1632.get("section_rows_cache") or {})
        self._section_total_cache = dict(session_cache_v1632.get("section_total_cache") or {})
        # v1868/v2147: one atomic first-viewport scene per library/sort/filter key.
        # Store only ordered rating keys and verified local poster paths; never
        # retain native Kodi ListItems across wall resets.
        self._library_first12_scene_cache_v1868 = {}
        # v2147: poster files are never decoded/resized by Python. Plex server-small
        # JPEGs (or an already-valid local source) are handed directly to Kodi; the
        # 240x360 XML control owns final visual geometry on every platform.
        self._tv_season_first12_prewarm_lock_v1871 = threading.RLock()
        self._tv_season_first12_prewarm_state_v1871 = {}
        # v1844: Kodi can re-enter sidebar callbacks during hidden-bank render
        # sleeps. Only the newest transaction may mutate each physical A/B bank.
        self._section_bank_render_serial_v1844 = 0
        self._section_bank_render_owner_v1844 = {"A": "", "B": ""}
        # v1906: Kodi may dispatch a new native sidebar selection while a prior
        # callback is inside a render-frame sleep.  Never re-enter the section
        # builder in that nested callback.  Coalesce to the newest native menu
        # selection and let the outer callback drain it after the stale renderer
        # has exited.  This state does not intercept or delay direction keys.
        self._menu_refresh_tx_active_v1906 = False
        self._menu_refresh_pending_v1906 = False
        self._menu_refresh_pending_force_v1906 = False
        self._menu_refresh_reselect_v1906 = False
        self._menu_refresh_generation_v1906 = 0
        # v1489: Plex-style right alphabet/title index for Section Library wall.
        # Data-only cache keyed by section_id; no addon.xml/search/playback changes.
        self._section_index_cache = {}
        self._section_index_active_key = ""
        self._section_index_last_section_id = ""
        self._section_index_slice_active = False
        # v1491: remember the wall item selected by the last right-index jump so
        # LEFT from the index returns to the intended poster, not to Kodi's
        # nearest/right-edge fallback.
        self._section_index_last_wall_jump_rel = -1
        self._section_index_last_wall_jump_key = ""
        # v675: remember the last active tab per Plex library section.
        # This is state-only data used by menu re-entry/OK activation so a
        # section returns to 추천 or 라이브러리 exactly as the user left it.
        self._section_last_tab_by_sid = dict(session_cache_v1632.get("section_last_tab_by_sid") or {})
        self._active_genre_filter = ""
        self._active_genre_section_id = ""
        # v1635: visited is a first-class session state independent of the
        # render-bank instance. A completed library cannot become visually cold
        # merely because Kodi recreated WindowXML or a dirty signal arrived.
        self._section_visited_keys_v1635 = set(
            str(x) for x in (session_cache_v1632.get("section_visited_keys_v1635") or []) if str(x or "")
        )
        # v474: TV recommendation rows keep 24 items, so avoid re-running the
        # same GROUP BY/RANDOM queries while the user moves through side-menu
        # libraries in the current Kodi session.  This is data-cache only; no
        # XML/focus/navigation flow is changed.
        self._tv_show_key_cache = {}
        self._tv_actor_name_pool_cache = {}
        self._tv_studio_name_pool_cache = {}
        self._tv_actor_show_key_cache = {}
        self._tv_studio_show_key_cache = {}
        # v477: TV actor/studio dynamic rows can use a lightweight genre-family
        # section pool, similar to movie-wide actor/director rows, while keeping
        # the fast deferred worker path.  Keys are cached per current Kodi run.
        self._tv_group_section_ids_cache = {}
        # v192: per-window random nonce so movie recommendation pools change
        # across Kodi runs instead of staying fixed for a whole day.
        self._movie_extra_random_nonce = "%s:%s" % (int(time.time() * 1000), random.randint(0, 999999))
        self._home_rows_cache = session_cache_v1632.get("home_rows_cache") if isinstance(session_cache_v1632.get("home_rows_cache"), list) else None
        self._home_wall_ready = bool(self._home_rows_cache)
        # v1642: Home is a two-phase commit.  The first two visible rows are
        # published immediately; all remaining rows are appended without resetting
        # those controls.  This generation token prevents stale workers from
        # touching a later Home/section scene.
        self._home_progressive_generation_v1642 = 0
        self._home_progressive_running_v1642 = False
        self._home_first_paint_critical_v1642 = False
        self._home_watcha_preload_started_v1642 = False
        self._home_watcha_preload_event_v1642 = threading.Event()
        self._cast_focus_idle_token_v1642 = 0
        self._post_startup_background_started_v1643 = False
        # v1644: the startup splash is a real snapshot-build barrier.  Every
        # selected sidebar scene is fully composed before Home is revealed.
        self._startup_sidebar_build_running_v1644 = False
        self._startup_sidebar_build_done_v1644 = False
        self._section_full_rows_ready_v1644 = set()
        self._section_texture_ready_v1644 = set()
        self._section_prebuilt_listitems_v1644 = {}
        self._section_prebuilt_titles_v1644 = {}
        self._section_prebuilt_meta_v1644 = {}
        self._section_prebuilt_rating_v1644 = {}
        # v2467: process-restart-safe, derived UI caches.  These never replace
        # Plex/DB authority; every entry is bound to the synchronized local
        # recommendation-index fingerprint (plus playstate file state where
        # relevant).  A changed authority fingerprint automatically rejects it.
        self._persistent_authority_fp_v2467 = ""
        # v2487: persistent cache validity is split into two independent domains.
        # Content authority follows synchronized Plex/local-library membership and
        # metadata only. Rating providers are presentation data and must never
        # masquerade as a Plex library mutation or discard immutable row caches.
        self._persistent_authority_db_fp_v2468 = ""
        self._persistent_presentation_fp_v2487 = ""
        self._persistent_plex_items_fp_v2487 = ""
        self._persistent_legacy_authority_fp_v2487 = ""
        # v2489: startup scene authority is section-scoped.  A change in one
        # Plex library must not invalidate prepared Recommendation/Library
        # snapshots belonging to every other selected section.
        self._persistent_section_authority_map_v2489 = None
        self._persistent_section_items_stats_v2489 = None
        self._startup_changed_section_ids_v2489 = set()
        self._startup_items_changed_section_ids_v2489 = set()
        self._startup_content_reject_keys_v2487 = set()
        self._startup_presentation_stale_keys_v2487 = set()
        self._startup_legacy_migration_keys_v2487 = set()
        self._startup_prepare_cause_v2487 = ""
        self._section_persistent_cache_v2467 = None
        self._section_persistent_hit_keys_v2467 = set()
        # v2469: persistent sidebar scenes are hydrated into GUI-safe ListItems
        # during the startup gate, before the user can move the sidebar.  Menu
        # focus then performs only a one-frame hidden-bank bind + A/B swap.
        self._section_startup_hydrated_keys_v2469 = set()
        self._section_startup_prebuilt_keys_v2469 = set()
        # v2470: Library tabs follow the same restart-safe prepared-scene rule as
        # Recommendation.  Disk entries contain immutable first-runway rows and
        # index data only; native ListItems are rebuilt under the opaque startup
        # gate and retained only for this WindowXML lifetime.
        self._library_persistent_cache_v2470 = None
        self._library_persistent_hit_keys_v2470 = set()
        self._library_startup_hydrated_keys_v2470 = set()
        self._library_prebuilt_listitems_v2470 = {}
        self._library_prebuilt_indexitems_v2470 = {}
        # V2801: let the diag sampler drop these accelerators before Android LMK kills Kodi.
        pkm_uhd_diag_v2600.set_low_memory_handler(self._pkm_low_memory_trim_v2801)
        # v2492: persisted Recommendation + remembered Library destinations are
        # restored together before Home reveal. Native ListItems are process-local
        # accelerators only; persisted snapshots remain the restart-safe authority.
        self._library_post_reveal_data_warm_keys_v2472 = set()
        self._post_reveal_library_data_warm_running_v2472 = False
        self._post_reveal_library_data_warm_done_v2472 = False
        return session_cache_v1632

    def _init_step2(self):
        """Step 2 of __init__ (R76 split, moved verbatim)."""
        self._section_render_snapshots_v2473 = {}
        self._library_render_snapshots_v2473 = {}
        self._suppress_item_diag_v2473 = True
        # v2476: build restart-safe render snapshots for every selected section
        # after Home is visible, without requiring the user to visit each sidebar
        # entry. The worker creates no native xbmcgui.ListItem objects.
        self._auto_snapshot_running_v2476 = False
        self._auto_snapshot_done_v2476 = False
        self._auto_snapshot_lock_v2476 = threading.RLock()
        # v2477: when the persistent render set is incomplete, keep the startup
        # logo opaque and finish the whole selected-library snapshot set before
        # Home is exposed. This is a one-time/mutation bootstrap, not a normal
        # post-reveal user-navigation dependency.
        self._startup_prepare_required_v2477 = False
        self._startup_prepare_running_v2477 = False
        self._startup_prepare_done_event_v2477 = threading.Event()
        self._startup_prepare_result_v2477 = {}
        self._startup_prepare_reason_v2477 = ""
        # v2492: the startup cover is released only after the selected destination
        # snapshot set is complete. This is selective after the one-time bootstrap:
        # changed/missing sections repair under the cover; unchanged sections reuse.
        self._startup_native_prebuild_done_v2492 = False
        self._startup_native_prebuild_stats_v2492 = {}
        self._startup_texture_prewarm_done_v2492 = False
        self._startup_texture_prewarm_stats_v2492 = {}
        # v2493: startup Home must remain locally publishable even when the
        # optional /identity health probe races with an already-successful
        # section request.  Texture readiness is scanned in one DB batch.
        self._startup_local_home_publishable_v2493 = False
        self._connection_recovery_bypass_logged_v2493 = False
        # v2479: every full PKM scene handoff follows one invariant:
        # keep source visible, finish target while hidden, wait one GUI frame,
        # then commit only the visibility/owner property.  The explicit action
        # anchor also prevents a Recommend-tab click from inheriting stale sidebar
        # focus time for the V2482 1000ms scene-spinner threshold.
        self._section_action_anchor_key_v2479 = ""
        self._section_action_anchor_started_v2479 = 0
        self._pkm_swap_seq_v2479 = 0
        # v2482: one meaningful spinner policy for PKM scene/page transitions.
        # The source A/B surface remains visible for the first second.  Only a
        # target still pending after that point may promote the shared broker.
        # Playback opening/buffering/seek indicators keep their independent
        # media-state semantics and are intentionally outside this scene policy.
        self._scene_busy_lock_v2482 = threading.RLock()
        self._scene_busy_seq_v2482 = 0
        self._scene_busy_gates_v2482 = {}
        self._scene_busy_latest_by_scope_v2482 = {}
        self._startup_prepare_display_text_v2482 = ""
        # v2484: startup empty/nonempty authority comes only from the synchronized
        # local DB.  Plex section metadata item_count/total may be a placeholder
        # zero and must never release Home or suppress a required snapshot rebuild.
        self._startup_section_counts_v2484 = None
        # v2471: the selected top tab is user UI state, not a WindowXML-lifetime
        # cache.  Persist it per Plex section across Kodi process restarts.
        # Library sort direction is remembered separately for the unfiltered
        # Library tab so a restored Library can resolve the same prepared key.
        self._section_tab_state_loaded_v2471 = False
        self._section_last_library_state_by_sid_v2471 = {}
        self._info_prepared_cache_v2467 = None
        self._actor_page_prepared_cache_v2467 = None
        # v1644 wall poster guarantee: keep random paging stable for one Kodi
        # run and prefetch the current/next viewport into a bounded local cache.
        self._wall_random_seed_v1644 = int(time.time() * 1000) & 0x7fffffff
        self._wall_poster_prefetch_queue_v1644 = []
        self._wall_poster_prefetch_seen_v1644 = set()
        self._wall_poster_prefetch_attempts_v1644 = {}
        self._wall_poster_prefetch_running_v1644 = False
        self._wall_poster_prefetch_worker_count_v1644 = 0
        self._wall_poster_prefetch_lock_v1644 = threading.RLock()
        self._wall_poster_prefetch_max_queue_v1841 = 192
        self._wall_poster_prefetch_max_seen_v1841 = 768
        # V2621: session-local authority map for wall poster runway.  Background
        # workers resolve either an existing Kodi Textures13 portrait file or a
        # PKM 240x360 small-poster file before the card reaches the viewport.
        # The GUI/key path performs dictionary lookups only; no SQLite/network.
        self._library_texture_runway_local_v2621 = {}
        self._library_texture_runway_lock_v2621 = threading.RLock()
        self._library_texture_commit_lock_v2621 = threading.RLock()
        self._library_texture_commit_pending_v2621 = False
        self._library_texture_commit_active_v2621 = False
        # V2622: TV wall cold-runway state. One background chain keeps two 48-row
        # pages ahead so slow TV aggregate sorts do not start only when the cursor
        # is already at the physical edge. This state never owns GUI selection.
        self._library_deep_prefetch_active_v2622 = set()
        self._library_deep_prefetch_lock_v2622 = threading.RLock()
        # V2624: poster priority authority is the real Kodi viewport, never the
        # append/data frontier.  GUI callbacks publish these primitive values;
        # poster workers read them without touching Kodi controls.
        self._library_texture_viewport_sid_v2624 = ""
        self._library_texture_viewport_start_v2624 = 0
        self._library_texture_viewport_end_v2624 = 18
        self._library_texture_visible_missing_v2624 = 0
        self._library_texture_viewport_stamp_v2624 = 0
        self._wall_poster_cache_dir_v1644 = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.km/wall_poster_cache_v1644'
        )
        self._playstate_home_refresh_pending_v1632 = False
        self._sync_refresh_defer_log_ms_v1632 = 0
        self._home_bootstrap_in_progress_v1632 = False
        self._suspend_refresh_until_ms = 0
        # v2077: Library scrolling uses a real native runway, not a just-in-time
        # two-row append.  Only 12 posters are visible, but 66 native items are
        # bound initially (11 rows). Local DB reads fetch 48 raw rows ahead; UI
        # publication is split into 24-item (4-row) binds so native rebind work
        # stays bounded while another 24 rows remain ready in memory.
        self.initial = 66
        self.batch = 24
        self._playback_opening = False
        self._last_activate_ms = 0
        self._last_info_activate_ms = 0
        self._info_dialog_active = False
        self._main_playback_requested = False
        self._last_focus_id = MENU_ID
        self._last_wall_pos = 0
        self._last_menu_pos = 0
        self._last_info_rating_key = ""
        self._inline_info_item = None
        # v449: Inline Info is a drill-down layer over the focused Home/section row.
        # Back must close only that layer and restore the exact poster/widget that
        # opened it, instead of treating the episode rail as Home content.
        self._inline_info_origin_focus_id = 0
        self._inline_info_origin_pos = -1
        self._inline_info_origin_rating_key = ""
        # v2085: Info opened from an actor-work poster is a nested navigation
        # step, not a replacement for the parent Info surface.  Keep a stable
        # detached parent snapshot plus the exact actor-work return identity so
        # Back can reconstruct the parent Info first and only then return focus.
        self._inline_info_history_v2085 = []
        self._inline_info_history_restore_v2085 = False
        # v2152: actor-work drill-down keeps exactly one previous Info page.
        # After that one-step Back restore, another Back is an explicit PKM exit
        # request instead of walking an arbitrarily deep poster history.
        self._inline_info_chain_exit_after_back_v2152 = False
        # v2454: Actor profile is a right-side view layered over the current Info.
        # The parent Info remains fully composed underneath so Back is an instant
        # actor-profile -> original Info restore with no rebuild/flicker.
        self._actor_profile_active_v2454 = False
        self._actor_profile_return_control_v2454 = 0
        self._actor_profile_return_pos_v2454 = -1
        self._actor_profile_return_name_v2454 = ""
        self._actor_profile_open_guard_ms_v2454 = 0
        self._actor_profile_work_open_guard_ms_v2454 = 0
        self._actor_profile_work_open_v2454 = False
        self._actor_profile_parent_origin_v2454 = None
        self._actor_profile_memory_cache_v2454 = {}
        self._actor_profile_tmdb_lock_v2454 = threading.RLock()
        # v2541: selected TMDb actor portraits are localized as soon as Person
        # Images chooses the alternate portrait.  Foreground/open paths join the
        # same per-URL transaction instead of starting a duplicate download.
        self._actor_portrait_download_lock_v2541 = threading.RLock()
        self._actor_portrait_download_inflight_v2541 = {}
        # v2481: actor-page cold intent prewarm is scoped to the cast item that
        # actually owns focus.  It never scans all actors and it never touches
        # Kodi controls from the worker thread.  A foreground click can cancel a
        # different pending actor and same-actor fetches reuse the locked cache.
        self._actor_profile_prewarm_token_v2481 = 0
        self._actor_profile_prewarm_actor_v2481 = ""
        self._actor_profile_prewarm_source_rk_v2481 = ""
        self._actor_profile_prewarm_running_v2481 = False
        self._actor_profile_foreground_actor_v2481 = ""
        # v2522: stable cast focus may precompute actor filmography rows using
        # SQLite only.  The cache contains immutable tuples; worker threads never
        # read Kodi controls or create xbmcgui.ListItems.
        self._actor_profile_local_rows_cache_v2522 = {}
        self._actor_profile_local_rows_lock_v2522 = threading.RLock()
        self._actor_page_prepared_lock_v2481 = threading.RLock()
        # v2526: a complete actor page is published into a short-lived in-memory
        # session cache BEFORE the expensive persistent authority fingerprint/write.
        # Media-level cast prewarm can therefore finish the actor page ahead of a
        # click, and the click consumes immutable local data only.
        self._actor_page_session_ready_v2526 = {}

    def _init_step3(self):
        """Step 3 of __init__ (R76 split, moved verbatim)."""
        self._actor_page_session_ready_lock_v2526 = threading.RLock()
        self._actor_profile_prewarm_inflight_v2526 = False
        self._actor_profile_prewarm_started_ms_v2526 = 0
        self._actor_profile_prewarm_ready_event_v2526 = threading.Event()
        # v2543: distinguish speculative direction prewarm from authoritative
        # media-ahead/foreground work.  A click may steal a direction worker
        # while it is still in its settle/local-only phase, before it owns the
        # global TMDb Helper language transaction.
        self._actor_profile_prewarm_reason_v2543 = ""
        self._actor_profile_prewarm_helper_started_ms_v2543 = 0
        # v2506: persisting a freshly composed Info target must never sit on the
        # foreground reveal path. The immutable snapshot is captured on the GUI
        # thread; authority hashing + JSON I/O are serialized in this worker lock.
        self._info_prepared_store_lock_v2506 = threading.RLock()
        self._info_prepared_store_seq_v2506 = 0
        # v2507: startup presentation refresh may update many section snapshots,
        # but persistence is committed only after the whole batch is composed.
        # This changes disk-write cadence only; snapshot completeness, A/B source
        # hold, native prebuild and texture gates remain unchanged.
        self._startup_persist_batch_active_v2507 = False
        self._startup_section_cache_dirty_v2507 = False
        self._startup_library_cache_dirty_v2507 = False
        # v2508: stable Home/section focus can prepare the two remaining bounded
        # movie Info data queries before the click.  Only plain Python/SQLite data
        # is stored here; no Kodi ListItem/control object crosses into the worker.
        self._info_focus_prewarm_lock_v2508 = threading.RLock()
        self._info_focus_prewarm_cache_v2508 = {}
        # v2609: focus-time atomic Info assets use plain Python events only.
        # Workers may fetch/cache data, but never touch Kodi controls.  The click
        # path can join an already-running prime for a very short bounded window.
        self._info_atomic_asset_lock_v2609 = threading.RLock()
        self._info_cast_lead_events_v2609 = {}
        self._info_tv_prewarm_events_v2609 = {}
        self._cast_placeholder_thumb_cached_v2508 = ""
        # v2510: fresh Home/section Info uses the current item's own UpdatedAt
        # identity before any section/presentation DB fingerprint.  Content-only
        # prepared metadata can therefore be consumed without foreground SQLite.
        # TV rail payloads remain stricter: they are reused only after the full
        # section authority matches because another episode/season can change.
        self._info_prepared_tv_payload_v2510 = None
        self._info_tv_rows = []
        self._info_tv_seasons = []
        self._info_tv_selected_season = ""
        # v2404: sorting is a header action. Keep the episode the user came from
        # as a logical sort anchor, while the rail itself may select the left-most
        # visible card to create the Plex-style 3-full + 1/3 teaser composition.
        self._info_tv_sort_anchor_rk_v2404 = ""
        self._info_tv_sort_user_rail_focus_v2404 = False
        self._suppress_back_until_ms = 0
        self._last_action_id = 0
        self._last_action_ms = 0
        self._last_left_from_wall_ms = 0
        self._last_left_from_wall_pos = -1
        self._allow_menu_focus_until_ms = 0
        # Logical cursor used because Kodi Panel.getSelectedPosition() can report 0
        # even after the visible focus has moved to the 2nd/3rd poster.
        self._logical_wall_pos = 0
        self._suppress_next_wall_right_logical = False
        # v145: no-hardcode wall-left handling. Track the first visible/data item
        # and the last confirmed focused item by identity, not by column count.
        self._wall_first_key = ""
        self._wall_tracked_key = ""
        self._wall_tracked_pos = 0
        self._library_native_owner_section_v2070 = ""
        self._library_append_prefetch_lock_v2070 = threading.RLock()
        self._library_append_prefetch_rows_v2070 = {}
        self._library_append_prefetch_inflight_v2070 = set()
        self._library_append_request_v2070 = False
        # v2071: no second selection owner is introduced. This state belongs only
        # to append scheduling; Kodi Panel 9100 remains the selection owner.
        self._library_append_post_native_only_v2071 = True
        self._info_playback_watcher_running = False
        self._info_playback_watcher_token = ""
        self._home_meta_enriching = set()
        self._home_meta_enrich_cache = {}
        self._home_meta_enrich_fail_until = {}
        # Large walls can deliver focus events faster than Plex can answer a
        # metadata request.  Only the item that remains focused is allowed to
        # start a remote request, and never run more than one such request at a
        # time.
        self._home_meta_nav_generation_v1837 = 0
        self._home_meta_remote_lock_v1837 = threading.Lock()
        # v211: metadata fetch remains keyed by the focused ratingKey, but sparse
        # PMS responses are resolved using stable item hints and same-section
        # exact-title fallback candidates.
        self._home_meta_hint_cache = {}
        # v206: focus-time prewarm state.  Plex HTPC feels instant because
        # metadata/cast artwork is prepared while the poster is focused, not
        # after the info button is pressed.
        self._info_prewarm_token = 0
        self._info_prewarm_active = set()
        self._info_prewarm_done = set()
        # v1336: cast artwork must be prepared before Info is opened, not by
        # the Info dialog itself. This queue warms Plex Role thumbs and local
        # circular PNGs while rows are visible/focused so the Info path only
        # reads local files. It is strictly background work.
        self._info_cast_prewarm_cache = {}
        self._info_cast_prewarm_queue = []
        self._info_cast_prewarm_seen = {}
        self._info_cast_prewarm_running = set()
        self._info_cast_prewarm_worker_running = False
        self._info_cast_prewarm_worker_count = 0
        self._info_cast_prewarm_negative = {}
        self._info_cast_prewarm_lock = threading.Lock()
        # v2606: native-first Info may reveal with stable placeholders, then
        # fill Plex-backed portraits in place after visible without resetting the
        # cast control or stealing focus. Worker threads only prepare/cache data;
        # the existing SendClick GUI ping owns ListItem mutation.
        self._info_cast_late_fill_token_v2606 = 0
        self._info_cast_late_fill_pending_v2606 = None
        # v2106: movie media-version detail discovery is prewarmed after the Info
        # surface is published.  The popup click path must be cache-only in the
        # normal case, while generation/inflight guards prevent stale workers from
        # republishing data after Info has closed or switched to another title.
        self._info_movie_media_prewarm_lock_v2106 = threading.RLock()
        self._info_movie_media_prewarm_inflight_v2106 = set()
        self._info_movie_media_prewarm_generation_v2106 = 0
        # v2209: exact Media/Part/Stream metadata is cached by ratingKey and
        # fetched on a short bounded budget.  The popup must stay fast even when
        # one Plex metadata call is slow; local DB fallback rows still appear.
        self._info_media_metadata_cache_v2209 = {}
        self._info_media_metadata_cache_lock_v2209 = threading.RLock()
        self._info_media_variant_timeout_v2209 = 1.60
        # v2112: TV detailed media-version state is isolated from the movie popup.
        self._info_tv_media_cache_v2112 = {}
        self._info_tv_media_choice_v2112 = {}
        # v2123: one authoritative current-TV-version snapshot backs both the
        # action-bar label and native plugin playback handoff.  Container
        # ListItem properties are still mirrored for compatibility, but skin
        # rendering no longer depends on Kodi repainting a mutated ListItem.
        self._info_tv_version_choice_v2099 = {}
        self._info_tv_selected_version_state_v2123 = {}
        self._info_tv_media_prewarm_lock_v2112 = threading.RLock()
        self._info_tv_media_prewarm_inflight_v2112 = set()
        self._info_tv_media_prewarm_generation_v2112 = 0
        self._info_tv_media_popup_rows_v2112 = []
        self._info_tv_media_popup_origin_v2112 = 0
        # v2237: show-level next-episode fallback timing popup. Editing is
        # draft-only until the user presses 확인; Back discards the draft.
        self._info_tv_next_timing_popup_origin_v2236 = 0
        self._info_tv_next_timing_show_key_v2236 = ""
        self._info_tv_next_timing_draft_v2237 = None
        self._info_tv_next_timing_draft_default_v2237 = True
        self._info_tv_next_timing_default_v2237 = 45
        self._info_tv_next_timing_show_title_v2237 = ""
        self._info_tv_next_timing_duration_v2237 = 0
        # v283: keep focus/meta labels instant, but debounce the visible hero fanart.
        # This prevents fanart texture churn during fast left/right/up/down movement
        # and lets Kodi cross-fade only the final focused item.
        self._home_fanart_token = 0
        self._home_fanart_current = ""
        self._home_fanart_delay_ms = 180
        # v293: fanart-aware Home background tint. Keep v291 instant speed, also tint the sidebar.
        self._home_bg_token = 0
        self._home_bg_current_fanart = ""
        self._home_bg_color_cache = {}
        self._home_bg_default = "FF222324"
        # v151: smooth color transition only for background tint properties.
        # This never touches poster focus, row navigation, meta sync, or fanart selection.
        self._home_bg_display_color = ""
        self._home_bg_apply_token = 0
        # v2315: serialize visible dynamic-background commits with target
        # invalidation.  A focus move may arrive while an older lerp worker is
        # between its token check and property publish; the lock closes that
        # race so the previous target can never repaint after cancellation.
        self._home_bg_apply_lock_v2315 = threading.RLock()
        # v2314: dynamic Home/library tint must not chase every key press.
        # A focused item has to remain selected for a short dwell period before
        # its color is allowed to become visible.  Once committed, the tint
        # eases slowly so rapid widget movement does not produce flashing hues.
        self._home_bg_lerp_steps = 24  # R81: slower, calmer tint glide (~1.2s)

    def _init_step4(self):
        """Step 4 of __init__ (R76 split, moved verbatim). Logs: PKM_PATCH_ACTIVE, INFO_CAST_POLICY_V2637, INFO_CAST_POLICY_V2636, INFO_CAST_POLICY_V2635."""
        self._home_bg_lerp_sleep_ms = 50
        self._home_bg_focus_dwell_ms_v2314 = 450
        self._home_bg_target_fanart_v2314 = ""
        self._home_bg_target_since_ms_v2314 = 0
        # v2140: one shared debounced sampler owns Home dynamic-color detection
        # across Windows/Android and fast row/wall navigation.  Rapid focus moves
        # replace one pending request instead of spawning an image worker per key.
        self._home_bg_probe_lock_v2140 = threading.Lock()
        self._home_bg_probe_pending_v2140 = None
        self._home_bg_probe_worker_running_v2140 = False
        self._home_bg_probe_active_token_v2314 = 0
        # Info has an independent dynamic-color owner.  Fanart A/B staging and
        # background tint A/B staging share the same target bank so Home's last
        # color can never leak into a different-title Info after commit.
        self._info_bg_probe_lock_v2140 = threading.Lock()
        self._info_bg_probe_pending_v2140 = None
        self._info_bg_probe_worker_running_v2140 = False
        self._info_bg_display_color_v2140 = ""
        # v091: Home widgets are XML horizontal list rows, not Python grid items.
        self._home_row_memory = {}
        # v118: previous stable row position before the latest Kodi-native move.
        # This prevents one LEFT key from doing both pos 1->0 and pos 0->menu.
        self._home_row_prev_memory = {}
        # v881: common widget-stack smooth reveal.  This is used by Home recommendation
        # rows and per-library recommendation rows whenever the visible widget stack
        # is replaced.  It is not a focus delay; rows are populated first, then XML
        # reveals the stack with a short fade/slide.
        self._widget_transition_token = 0
        self._widget_transition_active = False
        # v126: startup must land on the Home sidebar item.  Kodi can briefly
        # lose focus while WindowXML rows are populated, so keep a short
        # startup guard that only restores focus when it is invalid/lost.
        self._startup_focus_lock_until_ms = 0
        self._startup_focus_guard_running = False
        # Inline search: opened only by OK/Enter on the Search sidebar item.
        # Directional navigation inside search is XML-only.
        self._search_inline_active = False
        # v2284 Search -> Info -> owning-library keeps the complete Info scene
        # visible until the destination's existing A/B/ready commit is complete.
        self._search_info_sidebar_ab_hold_v2284 = None
        self._search_query = ""
        self._search_query_tokens = []
        self._search_mode = "KO"
        self._search_shift = False
        self._search_last_ms = 0
        self._search_results = []
        self._search_history = []
        self._search_history_loaded = False
        # v1881: Search poster visibility instrumentation. Kodi does not expose a
        # per-texture render callback, so PKM measures the closest reliable point:
        # the remote URL has a real file in Textures13 and remains complete for a
        # short render-settle window after the result panel was attached.
        self._search_poster_render_token_v1881 = ""
        self._search_poster_render_seq_v1881 = 0
        self._home_row_items_cache = []
        # v338: dynamic row-anchor scroll state.  Row count/order is Plex-data dependent,
        # so anchor by the actual visible row order, never by fixed control id.
        self._home_visible_row_controls = []
        self._section_visible_row_controls = []
        self._section_transition_prev_rows = []
        self._section_transition_prev_token = 0
        self._row_anchor_scroll_index = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
        # v343: visual y-position is tracked separately from logical row index.
        # onFocus and onAction can both observe the same Kodi XML move; logical
        # index is committed immediately so the second observer becomes a no-op,
        # while current_y lets a later request continue from the actual in-flight
        # animation position instead of jumping from the previous row.
        self._row_anchor_current_y = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
        _log("PKM_PATCH_ACTIVE v2637 plex_cast_firstframe_direct")
        _log("INFO_CAST_POLICY_V2637 plex_role_direct=1 resolved_reuse_direct=1 atomic_hold=0 sync_localize=0 missing_repair=background tmdb_firstframe=0")
        _log("PKM_PATCH_ACTIVE v2636 info_cast_real_thumb_publish")
        _log("INFO_CAST_POLICY_V2636 resolved_http_thumb=publish_direct placeholder=missing_only kodi_texture_owner=1")
        _log("PKM_PATCH_ACTIVE v2635 info_cast_plex_direct_no_atomic_hold")
        _log("INFO_CAST_POLICY_V2635 plex_role_thumb=direct_kodi_bind atomic_hold=0 missing_repair=background tmdb_firstframe_dependency=0")
        _log("PKM_PATCH_ACTIVE v2178 row_anchor_logical_physical_invariant_no_focus_write")
        _log("PKM_PATCH_ACTIVE v2275 dynamic_widget_count_row_anchor_447_xml_parity")
        _log("PKM_PATCH_ACTIVE v2281 info_sidebar_all_entry_search_renderer_suppressed")
        _log("PKM_PATCH_ACTIVE v2283 search_info_sidebar_routes_to_owning_library_back_keeps_search")
        _log("PKM_PATCH_ACTIVE v2284 search_info_sidebar_true_ab_hold_until_target_commit")
        _log("PKM_PATCH_ACTIVE v2285 search_info_sidebar_ab_hold_retarget_latest_native_menu_selection")
        _log("PKM_PATCH_ACTIVE v2286 search_info_sidebar_native_selection_retires_source_then_normal_ab")
        _log("PKM_PATCH_ACTIVE v2287 search_info_sidebar_target_first_latest_native_ab_commit_then_source_retire")
        _log("PKM_PATCH_ACTIVE v2288 search_info_sidebar_detach_to_normal_sidebar_pipeline_no_search_hold")
        _log("PKM_PATCH_ACTIVE v2297 wall_mode_v2268_clean_restore_basic_click_info")
        _log("PKM_PATCH_ACTIVE v2298 cast_current_role_then_local_library_reuse_no_people_wait")
        _log("PKM_PATCH_ACTIVE v2393 home_common_summary_y340_widget_stack_y520_fixed_24px_gap")
        _log("PKM_PATCH_ACTIVE v2185 actor_info_precompose_spinner_source_art_hidden_scroll_settle")
        _log("PKM_PATCH_ACTIVE v2186 actor_info_target_art_transition_no_source_fanart_linger")
        _log("PKM_PATCH_ACTIVE v2187 home_exit_countdown_premodal_handoff_no_previous_surface_flash")
        _log("PKM_PATCH_ACTIVE v2189 cast_role_local_plex_people_fallback")
        _log("PKM_PATCH_ACTIVE v2190 actor_info_full_page_atomic_reveal_scroll_compensation")
        _log("PKM_PATCH_ACTIVE v2191 info_fanart_home_geometry_atomic_spinner_reveal")
        _log("PKM_PATCH_ACTIVE v2194 info_fanart_exact_home_visible_texture_owner")
        _log("PKM_PATCH_ACTIVE v2206 widget_title_focus_gap_all_home_section_rows")
        _log("PKM_PATCH_ACTIVE v2207 cast_direct_light_metadata_single_owner_no_short_prewarm_poison")
        _log("PKM_PATCH_ACTIVE v2208 cast_global_library_plex_role_reuse_tag_identity_persist")
        _log("PKM_PATCH_ACTIVE v2466 actor_all_person_images_profile_first_original_left_round")
        _log("PKM_PATCH_ACTIVE v2467 persistent_ready_cache_sidebar_info_actor_no_repeat_spinner")
        _log("PKM_PATCH_ACTIVE v2468 persistent_cache_stable_authority_restart_ab_no_spinner")
        _log("PKM_PATCH_ACTIVE v2469 startup_hydrate_sidebar_native_prebuild_one_frame_ab_no_focus_io")
        _log("PKM_PATCH_ACTIVE v2470 recommend_to_library_startup_hydrate_one_frame_swap_no_focus_io")
        _log("PKM_PATCH_ACTIVE v2472 remembered_tab_only_startup_hydrate_opposite_idle_data_warm")
        _log("PKM_PATCH_ACTIVE v2570 uhd3_home_quiet_prehome_destinations_no_visible_home_background")
        _log("PKM_PATCH_ACTIVE v2591 uhd3_foreground_isolation_home_partial_bind_watcha_point_canonical_defer")
        _log("PKM_PATCH_ACTIVE v2593 uhd3_library_rapid_poster_runway_spinner_hard_minimal")
        _log("UHD3_LIBRARY_RAPID_POLICY_V2593 ahead_posters=6 scheduler_lane=1 local_bind_first_row=1 gate_budget_ms=300 naked_blank=0 delayed_spinner_ms=180")
        _log("PKM_PATCH_ACTIVE v2594 plex_like_sidebar_spinner_wall_scroll_input_first")
        _log("UHD_PLEX_REFERENCE_POLICY_V2594 sidebar_spinner_ms=220 wall_rapid_spinner=0 placeholder_allowed=1 viewport_posters=6 stale_inflight_cancel=1 input_first=1")
        _log("UHD_RUNTIME_MINIMAL_V2595 sidebar_native_focus_first=1 render_debounce_ms=90 sidebar_scrolltime=0 hidden_mirror_per_key=0 focus_audit=0 dynamic_bg_navigation=0 artwork_lanes_navigation=1 home_refresh_poll_ms=1000 imdb_full_bulk=0 sidebar_count_sql=0")
        _log("PKM_PATCH_ACTIVE v2596 uhd_tv_wall_fast_show_rows_widget_focus_debounce")
        _log("UHD_WIDGET_NAV_POLICY_V2596 stable_ms=80 gui_meta_commit=1 art_preload=0 trailer=0 cast_prewarm=0 native_focus_first=1\nSIDEBAR_NATIVE_ONLY_POLICY_V2598 mover=xml_control9000 python_select=0 python_focus=0 same_action_scene_refresh=0 collapsed_mirror_per_key=0 settle_ms=90\nSIDEBAR_ZERO_WAIT_POLICY_V2599 mover=xml_control9000 python_select=0 python_focus=0 scene_commit=next_gui_callback settle_ms=0 worker=0")
        _log("PKM_PATCH_ACTIVE v2659 uhd3_workload_budget_v2 cast_drop_nav=1 cast_workers=1 stale_worker_drop_ms=8000 nav_quiet_ms=5000 library_index_lazy=1 sort_index_lazy=1")
        _log("UHD_TV_WALL_POLICY_V2596 firstpaint_show_rows_only=1 episode_group_scan_foreground=0 exact_episode_aggregate_deferred=1")
        _log("PKM_PATCH_ACTIVE v2473 all_tab_data_hydrate_lazy_render_snapshot_fast_authority_no_spinner")
        _log("PKM_PATCH_ACTIVE v2474 delayed_spinner_for_data_only_on_demand_render_native_ready_only_no_spinner")
        _log("PKM_PATCH_ACTIVE v2475 sidebar_spinner_policy_superseded_by_v2482_v2492_1000ms_actual_visible_commit")
        _log("PKM_PATCH_ACTIVE v2476 auto_persistent_render_snapshot_all_sections_no_manual_visit_library_tab_action_anchor_spinner_1000ms_v2492")
        _log("PKM_PATCH_ACTIVE v2477 first_prepare_under_logo_all_section_snapshots_before_home_release")
        _log("PKM_PATCH_ACTIVE v2478 persistent_snapshot_foreground_zero_enrich_no_rating_canonical_db")
        _log("PKM_PATCH_ACTIVE v2479 universal_scene_ab_swap_no_prepared_persist_write_tab_action_spinner_1000ms_v2492")
        _log("PKM_PATCH_ACTIVE v2480 actor_profile_tv_only_compact_startup_cache_hydrate_focus_commit")
        _log("PKM_PATCH_ACTIVE v2481 actor_profile_final_geometry_focus_intent_prewarm_no_post_commit_motion")
        _log("PKM_PATCH_ACTIVE v2482 global_scene_spinner_1000ms_no_flash_prepared_slow_fallback_startup_complete_barrier")
        _log("PKM_SCENE_SPINNER_POLICY_V2482 threshold_ms=1000 scope=scene_transitions source_hold=1 short_wait_spinner=0 prepared_slow_fallback=1 playback_buffering_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2483 restart_authority_reject_failclosed_snapshot_prepare_no_sidebar_cold")
        _log("STARTUP_SNAPSHOT_READINESS_POLICY_V2483 unknown_total_is_not_empty=1 authority_reject_requires_rebuild=1 home_release_only_exact_snapshot_or_authoritative_empty=1")
        _log("PKM_PATCH_ACTIVE v2484 startup_local_db_only_empty_authority_no_section_metadata_placeholder_zero")
        _log("STARTUP_SNAPSHOT_READINESS_POLICY_V2484 count_authority=local_db_only section_metadata_item_count_ignored=1 section_metadata_total_ignored=1 empty_requires_indexed_local_zero=1 inconsistent_local_state_fail_closed=1")
        _log("PKM_PATCH_ACTIVE v2485 actor_cold_spinner_policy_superseded_by_v2492_tmdb_portrait_local_texture_prime_atomic_reveal")
        _log("ACTOR_PROFILE_REVEAL_POLICY_V2485 cold_network_spinner_immediate=0 prepared_spinner_threshold_ms=1000 portrait_remote_never_visible=1 portrait_local_before_active=1 texture_prime_before_commit=1 works_bound_before_reveal=1 superseded_spinner=v2492")
        _log("PKM_PATCH_ACTIVE v2486 actor_profile_left_edge_no_sidebar_back_only_return")
        _log("ACTOR_PROFILE_NAV_POLICY_V2486 left_edge=noop sidebar_entry=blocked back=parent_info exact_cast_restore=1")
        _log("PKM_PATCH_ACTIVE v2487 content_authority_rating_presentation_split_exact_startup_reason_snapshot_only_refresh")
        _log("PERSISTENT_AUTHORITY_POLICY_V2487 content=plex_local_items_index_no_ratings presentation=item_ratings_cine21_watcha rating_change_content_invalidate=0 library_change_text_only_plex_items=1")
        _log("STARTUP_STATUS_POLICY_V2487 first=first_run selection=library_prepare content_changed=library_changes_apply presentation=screen_info_refresh cache_gap=screen_prepare addon_update_separate=1")
        _log("PKM_PATCH_ACTIVE v2489 startup_section_scoped_authority_selective_snapshot_invalidation")
        _log("PERSISTENT_SECTION_AUTHORITY_POLICY_V2489 scope=section changed_section_only=1 unchanged_snapshot_reuse=1 recommend_and_library=1 legacy_v2487_migrate_if_global_match=1 legacy_global_mismatch_one_time_rebuild=1")
        _log("STARTUP_CHANGE_DIAGNOSTIC_POLICY_V2489 per_section_old_new_count_updated_added=1 library_change_text_only_when_items_stats_changed=1")
        _log("PKM_PATCH_ACTIVE v2490 first_snapshot_bootstrap_once_restart_never_full_foreground_rebuild")
        _log("STARTUP_BOOTSTRAP_POLICY_V2490 first_heavy_only_after_initial_library_selection=1 durable_snapshot_bootstrap_marker=1 state_file_missing_not_first=1 later_startup_global_snapshot_barrier=0 changed_section_background_repair=0 unchanged_snapshot_reuse=1 superseded_repair=v2492_selective_foreground")
        _log("PERSISTENT_SNAPSHOT_PRESERVE_POLICY_V2490 section_invalidation_keeps_bootstrap_marker=1 section_invalidation_keeps_authority_baseline=1 patch_update_keeps_snapshots=1")
        _log("PKM_PATCH_ACTIVE v2491 section_poster_texture_ready_failclosed_no_blank_swap")
        _log("SECTION_POSTER_REVEAL_POLICY_V2491 persistent_data_ready_not_texture_ready=1 first_viewport=10 hidden_bank_texture_gate=1 cached_fast_path=1 incomplete_prime_hidden=1 timeout_swap=0 source_hold=1")
        _log("PKM_PATCH_ACTIVE v2492 startup_all_destination_restore_delayed_status_unified_scene_spinner")
        _log("STARTUP_DESTINATION_POLICY_V2492 home_release_requires_complete_selected_snapshots=1 recommend_and_library=1 unchanged_reuse=1 changed_section_selective_foreground=1 post_reveal_snapshot_repair=0 native_prebuild_existing=1 first_viewport_texture_prewarm_all=1 sidebar_focus_io=0")
        _log("STARTUP_STATUS_DELAY_POLICY_V2492 delay_ms=3000 fast_start_text=0 initial_library_text=라이브러리를 구성 중입니다 exact_cause_after_delay=1")
        _log("SCENE_SPINNER_UNIFIED_POLICY_V2492 threshold_ms=1000 sidebar=1 tabs=1 info=1 actor=1 search=1 short_wait_spinner=0 source_hold=1")
        _log("PKM_PATCH_ACTIVE v2493 startup_deadlock_fix_batched_texture_probe_reliable_slow_status")
        _log("STARTUP_TEXTURE_PREWARM_POLICY_V2493 texture_db_batch_scan=1 serial_destination_db_open=0 all_destinations_preserved=1 fail_closed_blank_publish=0")
        _log("STARTUP_AUTHORITY_POLICY_V2493 full_items_group_scan=0 sections_table_count=1 indexed_max_updated_added=1 per_section_selective_fingerprint=1")
        _log("STARTUP_CONNECTION_POLICY_V2493 identity_probe_advisory=1 recent_section_success_suppresses_offline=1 startup_local_snapshot_home_never_blocked=1")
        _log("STARTUP_STATUS_HINT_POLICY_V2493 first_bootstrap_requires_no_marker_no_completed_state_no_snapshot_cache=1 delayed_text_owner=service_monotonic_guard")
        _log("PKM_PATCH_ACTIVE v2494 exact_indexed_section_count_v2489_compat_v2493_zero_count_rescue")
        _log("STARTUP_AUTHORITY_POLICY_V2494 count_source=items_indexed_exact sections_item_count_ignored=1 max_updated_added_indexed=1 v2489_fingerprint_compatible=1 unproven_empty_fail_closed=1")
        _log("STARTUP_V2493_POISON_RESCUE_POLICY_V2494 zero_count_fp_inplace_migrate=1 unchanged_max_required=1 row_rebuild=0 state_baseline_repair=1")
        _log("STARTUP_STATUS_FALLBACK_POLICY_V2494 threshold_ms=12000 home_owner_overdue_fallback=1 fast_start_text=0")
        _log("PKM_PATCH_ACTIVE v2494r3 startup_acceptance_single_line_pass_fail_diagnostics")
        _log("STARTUP_ACCEPTANCE_POLICY_V2494R3 pass=home_release_all_contracts fail=prepare_fatal_or_release_exception watchdog_established_30s=1 first_bootstrap_wait_allowed=1 diagnostic_only=1")
        _log("PKM_PATCH_ACTIVE v2495 startup_texture_local_cache_truth_safe_bind_total_elapsed_slow_reason")
        _log("STARTUP_TEXTURE_POLICY_V2495 kodi_texture_or_pkm_local_small=ready missing_download_dedup=1 gui_bind_after_worker=1 transient_fetch_missing_not_placeholder=1 all_destination_before_home=1")
        _log("STARTUP_SLOW_STATUS_POLICY_V2495 threshold_ms=12000 token_loss_not_cancel=1 home_gate_elapsed_fallback=1 acceptance_total_startup_elapsed=1 exact_reason_update=1")
        _log("STARTUP_ACCEPTANCE_POLICY_V2495 pass_requires_snapshot_native_texture_home_slow_reason=1 total_elapsed_from_home_gate=1 one_line_final=1")
        _log("PKM_PATCH_ACTIVE v2496 library_firstpaint_18_local_materialize_failclosed_no_progressive_publish")
        _log("PKM_PATCH_ACTIVE v2575 playback_local_pre_ui_commit_global_progress_authority_visible_surface_reclassify")
        _log("LIBRARY_POSTER_REVEAL_POLICY_V2496 firstpaint=18 actual_local_path_required=1 textures13_boolean_not_sufficient=1 kodi_cached_file_rebind=1 hidden_target_source_hold=1 unresolved_publish=0 transient_fetch_placeholder=0")
        _log("PKM_PATCH_ACTIVE v2497 continue_watching_canonical_poster_authority_local_db_first_no_still_fallback")
        _log("HOME_CONTINUE_POSTER_POLICY_V2497 resume_source=plex_ondeck poster_source=local_library_exact_first movie=items_thumb episode=show_items_thumb canonical_endpoint_fallback=1 landscape_art_as_poster=0 network_probe=0")
        _log("PKM_PATCH_ACTIVE v2498 poster_provenance_role_separation_no_fanart_materialize_snapshot_poison_bypass")
        _log("POSTER_AUTHORITY_POLICY_V2498 portrait_card_source=poster_only fallback_art_excluded=1 textures13_exact_url_priority=1 cached_file_portrait_required=1 persisted_v2496_local_bind_bypass=1 library_firstpaint_fail_closed=1 home_widget_poster_only=1")
        _log("PKM_PATCH_ACTIVE v2499 unchanged_start_home_snapshot_native_reuse_batch_add_under3s_target")

    def _init_step5(self):
        """Step 5 of __init__ (R76 split, moved verbatim). Logs: STARTUP_HOME_FASTPATH_POLICY_V2499, PKM_PATCH_ACTIVE, STARTUP_HOME_FASTPATH_POLICY_V2500, STARTUP_FINAL_PROGRESS_POLICY_V2501."""
        _log("STARTUP_HOME_FASTPATH_POLICY_V2499 scope=cause_ready_only persistent_section_render_snapshot_reuse=1 current_playstate_overlay=1 home_full_209_no_rating_canonical_recompute=1 batch_additems=1 changed_or_presentation_fallback=original target_ms=3000")
        _log("PKM_PATCH_ACTIVE v2500 unchanged_ready_persistent_home_render_verified_poster_local_cache_fast_final_logo")
        _log("STARTUP_HOME_FASTPATH_POLICY_V2500 scope=cause_ready_only home_render_snapshot_persistent=1 current_membership_live=1 current_playstate_overlay=1 verified_poster_local_cache=authority_exact_content_fp_bound final_logo_ready_fast=1 first_v2500_run_warms_cache=1 target_ms=3000")
        _log("PKM_PATCH_ACTIVE v2501 v2500_verified_fast_final_v2052_exact_allowlist_deadlock_fix")
        _log("STARTUP_FINAL_PROGRESS_POLICY_V2501 v2052_failclosed_preserved=1 exact_verified_reasons=legacy_v2052,v2500_ready_fast unverified_100_clamp99=1 final_frame_event_reachable=1 cache_preserved=1")
        _log("PKM_PATCH_ACTIVE v2488 actor_biography_korean_first_original_fallback_fixed_round_3line_box")
        _log("PKM_PATCH_ACTIVE v2703 actor_master_local_db_biography_authority_and_trace")
        _log("ACTOR_PROFILE_BIO_POLICY_V2488 language_priority=korean_first fallback=original box=518x184 padding=12 max_lines=3 ellipsis=1 source=tmdb_helper superseded_layout=v2504")
        _log("PKM_PATCH_ACTIVE v2504 actor_profile_fast_feedback_gap_seal_wide_box_fit")
        _log("ACTOR_PROFILE_ENTRY_POLICY_V2504 cold_spinner_ms=180 warm_spinner_ms=500 portrait_prime_ms=96 source_info_hold=1 actor_fade_ms=180 superseded_feedback=v2505")
        _log("PKM_PATCH_ACTIVE v2505 focused_info_cast_safe_prewarm_info_750ms_cold_actor_sync_feedback")
        _log("INFO_ENTRY_FEEDBACK_POLICY_V2505 stable_focus_cast_prewarm_ms=250 immutable_snapshot=1 background_listitem_access=0 info_spinner_ms=750 cold_actor_spinner=sync warm_actor_spinner_ms=500 atomic_first_paint=1")
        _log("PKM_PATCH_ACTIVE v2506 info_reveal_before_persistent_authority_hash_async_store")
        _log("INFO_PERSIST_POLICY_V2506 reveal_before_authority_hash=1 immutable_gui_snapshot=1 worker_listitem_access=0 serialized_json_write=1")
        _log("PKM_PATCH_ACTIVE v2507 startup_snapshot_batch_flush_info_section_authority")
        _log("STARTUP_PERSIST_POLICY_V2507 presentation_snapshot_semantics=unchanged section_json_flush=once_per_batch library_json_flush=once_per_batch texture_gate=unchanged native_gate=unchanged ab_source_hold=unchanged")
        _log("INFO_AUTHORITY_POLICY_V2507 new_cache=content_section_v2489 legacy_global_cache=fast_reject_no_global_scan first_rebuild=local_only persistent_store=async")
        _log("PKM_PATCH_ACTIVE v2508 focused_movie_info_data_prewarm_placeholder_path_cache")
        _log("INFO_FOCUS_PREWARM_POLICY_V2508 stable_focus_ms=250 movie_versions=sqlite_background actor_work_rows=sqlite_background immutable_focus_snapshot=1 gui_control_mutation=0 click_atomic_complete_unchanged=1")
        _log("CAST_PLACEHOLDER_POLICY_V2508 resolve_resource_path_once_per_window=1 repeated_translate_exists=0 no_image_semantics=unchanged")
        _log("PKM_PATCH_ACTIVE v2509 info_actor_work_lightweight_batch_bind")
        _log("INFO_ACTOR_WORK_BIND_POLICY_V2509 builder=lightweight_native_identity poster=preserved video_info=minimal ratings_sql=0 wall_sort_sql=0 row_bind=addItems_once per_item_bind_log=0 child_info_local_enrich=unchanged atomic_reveal=unchanged")
        _log("PKM_PATCH_ACTIVE v2510 home_info_foreground_reuse_tv_rail_batch")
        _log("INFO_HOME_ENTRY_POLICY_V2510 prepared_item_updatedat_fast_match=1 presentation_fingerprint_foreground=0 home_meta_memory_before_sqlite=1 local_db_skip_only_if_complete=1 movie_tv_common=1 atomic_reveal=unchanged")
        _log("PKM_PATCH_ACTIVE v2511 home_info_left_meta_summary_pixel_stationary")
        _log("INFO_HOME_VISUAL_PARITY_V2511 title=TitleDisplay movie_meta=fixed_slots cine21_logo_gap=home_exact summary=home_exact_text_and_color tv_episode_summary=home_740px_wrap atomic_swap=unchanged")
        _log("PKM_PATCH_ACTIVE v2512 home_info_true_visual_hold_tv_rating_episode_y_background_continuity")
        _log("INFO_HOME_VISUAL_HOLD_POLICY_V2512 exact_home_display_props=1 home_dynamic_bg_first_frame=1 tv_episode_title_y196=1 tv_rating_row_y306=1 info_common_geometry=home_exact atomic_swap=unchanged")
        _log("PKM_PATCH_ACTIVE v2513 first_info_scene_transparent_prime_no_cold_first_render")
        _log("INFO_FIRST_SCENE_PRIME_POLICY_V2513 prepared_cache_startup_warm=1 arm_after_home_bootstrap=1 inline_active=0 transparent_visible_group=1 consume_on_first_real_info=1 first_click_file_io=0 first_click_wait=0 network=0 db=0")
        _log("PKM_PATCH_ACTIVE v2514 rollback_v2513_visible_group_prime_restore_home_surface")
        _log("INFO_FIRST_SCENE_PRIME_ROLLBACK_POLICY_V2514 sceneprime_visible_group=disabled startup_cache_warm=preserved home_visibility_authority=restored inlineactive_only=1 control5599_prime=0")
        _log("PKM_PATCH_ACTIVE v2515 first_info_movie_version_index_click_priority")
        _log("INFO_FIRST_MOVIE_POLICY_V2515 version_lookup_index=plex_type_year_section year_cast=0 focus_prewarm_cancel_on_click=1 worker_sql_interruptible=1 foreground_duplicate_scan=0 atomic_reveal=unchanged no_wait_required=1")
        _log("PKM_PATCH_ACTIVE v2516 startup_logo_visible_full_fill_before_home_reason_text_real_wait_only")
        _log("STARTUP_LOGO_POLICY_V2516 fast_ready=accelerated_monotonic_fill_to_100 final_frame_visible_hold_ms=40 instant_jump=0 slow_text_threshold_ms=3000 slow_text_suppressed_only_after_real_work_ready=1 home_atomic_gate=unchanged")
        _log("PKM_PATCH_ACTIVE v2518 first_info_sidebar_empty_state_canonical_collapsed_before_reveal")
        _log("INFO_SIDEBAR_FIRST_FRAME_POLICY_V2518 info_empty_expanded=0 previsible_content_entry_expanded=0 explicit_sidebar_focus_only_expands=1 inline_commit_after_geometry=1 horizontal_delta_first_frame=0")
        _log("PKM_PATCH_ACTIVE v2522 actor_profile_fast_parallel_local_lightweight_prepaint_focus")
        _log("ACTOR_PROFILE_FAST_POLICY_V2522 prewarm_local_rows_ms=250 cold_tmdb_semantics=unchanged local_works_parallel_profile_fetch=1 work_listitem_builder=v2509_lightweight first_focus_prepaint=1 helper_restore_wait_ms=0 portrait_atomic_gate=unchanged actor_visible_fade_ms=180 outgoing_180_hidden=0")
        _log("PKM_PATCH_ACTIVE v2523 actor_profile_cold_helper_focus_prewarm_join")
        _log("ACTOR_PROFILE_PREWARM_POLICY_V2523 stable_focus_ms=250 cold_helper_background=1 gui_control_access=0 foreground_same_actor_joins=1 duplicate_helper_transaction=0 cancellation_between_helper_stages=1 atomic_actor_reveal=unchanged")
        _log("PKM_PATCH_ACTIVE v2524 actor_profile_bounded_cold_open_background_enrich")
        _log("ACTOR_PROFILE_COLD_OPEN_POLICY_V2524 superseded_by=v2526 incomplete_cold_reveal_disabled=1")
        _log("PKM_PATCH_ACTIVE v2525 actor_profile_cold_live_metadata_apply_robust_cast_local")
        _log("PKM_PATCH_ACTIVE v2526 actor_profile_media_ahead_complete_session_ready_atomic_click")
        _log("ACTOR_PROFILE_INSTANT_POLICY_V2526 fetch_before_actor_click=stable_media_cast_actor0 session_ready_before_persist=1 same_actor_prewarm_dedupe=1 existing_cast_portrait_reuse=1 person_images_skip_when_local=1 exact_retry_only_if_birthday_missing=1 incomplete_actor_reveal=0 late_current_page_enrich=0 cold_fallback=parent_info_hold_complete atomic_complete_reveal=1 superseded_portrait_policy=v2539")
        _log("PKM_PATCH_ACTIVE v2527 actor_profile_cold_spinner_immediate_before_join_wait")
        _log("ACTOR_PROFILE_SPINNER_POLICY_V2527 cold_cache_miss_threshold_ms=0 arm_before_media_ahead_join=1 synchronous_promote=1 prepared_or_local_threshold_ms=500 source_info_hold=1 actor_atomic_reveal=unchanged")
        _log("PKM_PATCH_ACTIVE v2528 actor_profile_split_hero_compact_filmography_layout")
        _log("ACTOR_PROFILE_LAYOUT_POLICY_V2528 portrait=360x540 top=90 info_right=1 bio=1100x184 filmography_compact=1 movie_first=1 tv_on_down=1 hero_static_on_tv_focus=1 outgoing_fade=0")
        _log("PKM_PATCH_ACTIVE v2529 actor_profile_in_library_single_mixed_year_layout_wide_bio_round_spinner_plate")
        _log("ACTOR_PROFILE_LAYOUT_POLICY_V2529 portrait=360x540 top=90 info_left=430 bio=1340x385 inner=1316x361 boxfit=actual_width_height fixed_char_limit=0 works=single_in_library movie_tv_mixed=1 order=year_desc rail_left=55 second_rail=0 spinner_plate=slight_round_corners")
        _log("PKM_PATCH_ACTIVE v2532 actor_profile_balanced_hero_local_library_rail_spacing")
        _log("PKM_PATCH_ACTIVE v2533 actor_profile_my_library_credits_label_startup_reason_phase_truth")
        _log("PKM_PATCH_ACTIVE v2534 startup_selective_snapshot_fast_compose_shutdown_timing")
        _log("STARTUP_PERF_POLICY_V2534 unchanged_or_selective_snapshot_reuse=1 changed_sections_fallback_only=1 final_texture_gate_unchanged=1 snapshot_authority_validation=unchanged shutdown_wait_added=0")
        _log("PKM_PATCH_ACTIVE v2535 startup_current_home_only_text_whitelist_6s_abnormal_budget")
        _log("PKM_PATCH_ACTIVE v2535r2 current_home_only_no_offscreen_startup_gate_text_whitelist")
        _log("PKM_PATCH_ACTIVE v2558 fresh_install_initial_surface_direct_release_tmdb_dependency_startup_notice_guard")
        _log("PKM_PATCH_ACTIVE v2558r2 fresh_install_direct_release_win_scope_root_fix")
        _log("PKM_PATCH_ACTIVE v2558r3 initial_surface_logo_full_fill_before_reveal")
        _log("STARTUP_INITIAL_SURFACE_POLICY_V2558 fresh_install_immediate=1 selected_sections_zero_nonwidget_gate_bypass=1 settings_required_no_snapshot_wait=1 slow_problem_text_suppressed=1 tmdb_helper_required=1")
        _log("PKM_PATCH_ACTIVE v2536 sidebar_section_spinner_antiflash_1500ms")
        _log("SIDEBAR_SECTION_SPINNER_POLICY_V2536 threshold_ms=1500 same_section_required=1 pending_gate_required=1 source_hold=1 fast_switch_no_spinner=1 other_scene_thresholds_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2537 actor_profile_round_portrait_compact_bio_bottom_align")
        _log("ACTOR_PROFILE_LAYOUT_POLICY_V2537 portrait=320x480 top=90 radius_px=16 bio_top=225 bio=1100x345 inner=1076x321 bio_bottom=570 portrait_bottom=570 rail_label_top=600 rail_top=660")
        _log("PKM_PATCH_ACTIVE v2538 actor_profile_round_corner_cover_parent_cast_prefocus_back")
        _log("ACTOR_PROFILE_RETURN_POLICY_V2538 parent_cast_prefocus_before_actor_retire=1 movie_cast_6100_zero_motion=1 tv_cast_6110_history_pin=1 fallback_after_reveal_only_on_prefocus_failure=1 portrait_corner_cover=1 radius_px=20")
        _log("PKM_PATCH_ACTIVE v2539 actor_profile_tmdb_person_images_alt_portrait_restore")
        _log("ACTOR_PROFILE_PORTRAIT_POLICY_V2539 person_images_query_even_with_cast_local=1 primary_excluded=1 prefer_second_distinct_after_primary=1 typical_rank=3 fallback_rank=2 then_details_primary=1 cast_local_last=1 focus_prewarm=1 persistent_cache_migrate=1")
        _log("PKM_PATCH_ACTIVE v2540 actor_profile_portrait_fetch_timing_diagnostic_no_behavior_change")
        _log("ACTOR_PROFILE_PORTRAIT_TIMING_POLICY_V2540 phases=person_images_query,image_download,photo_ready cache_hit_logged=1 selection_to_download_gap_logged=1 network_sum_logged=1 behavior_change=0")
        _log("PKM_PATCH_ACTIVE v2541 actor_profile_portrait_parallel_download_dedupe")
        _log("ACTOR_PROFILE_PORTRAIT_PARALLEL_POLICY_V2541 start_after_person_images_select=1 overlap_biography_fallback=1 per_url_download_dedupe=1 foreground_join_inflight=1 actor_atomic_reveal=unchanged portrait_rank_policy=unchanged")
        _log("PKM_PATCH_ACTIVE v2542 actor_profile_complete_page_latency_under2s_pipeline")
        _log("ACTOR_PROFILE_COMPLETE_FAST_POLICY_V2542 early_actor0_before_cast_download=1 direction_thrash_settle_ms=600 helper_language_fixed_sleep_ms=0 readback_retry_ms=120 person_images_query_parallel_with_bio_fallback=1 photo_download_parallel=1 complete_atomic_reveal=1 no_blank_portrait=1 late_bio_eventual=1 target_normal_ms=2000")
        _log("PKM_PATCH_ACTIVE v2543 actor_profile_foreground_priority_remove_stale_prewarm_wait")
        _log("ACTOR_PROFILE_FOREGROUND_PRIORITY_POLICY_V2543 direction_settle_ms=1500 click_steals_unstarted_same_direction_prewarm=1 different_direction_prewarm_cancel_immediate_before_helper=1 helper_transaction_atomic=1 no_profile_content_change=1")
        _log("PKM_PATCH_ACTIVE v2544 actor_profile_info_portrait_first_tmdb_soft_upgrade_cache")
        _log("PKM_PATCH_ACTIVE v2545 actor_profile_biography_lean_original_fallback_fastpath")
        _log("ACTOR_PROFILE_BIO_FAST_POLICY_V2545 korean_details_unchanged=1 original_fallback_detailed_false=1 exact_tmdb_id=1 full_retry_on_error_identity_or_empty_bio=1 late_bio_eventual=1 atomic_reveal=unchanged photo_v2544=unchanged")
        _log("PKM_PATCH_ACTIVE v2546 actor_profile_biography_plex_discover_parallel_fallback")
        _log("ACTOR_PROFILE_BIO_FAST_POLICY_V2546 korean_tmdb_authoritative=1 plex_discover_prefetch_parallel_with_korean=1 plex_summary_used_only_when_korean_bio_empty=1 plex_wait_grace_ms=120 original_tmdb_lean_fallback_after_plex_miss=1 lean_empty_no_redundant_full_retry=1 full_retry_only_error_or_identity=1 late_bio_eventual=1 atomic_reveal=unchanged photo_v2544=unchanged")
        _log("PKM_PATCH_ACTIVE v2547 actor_profile_biography_korean_lean_first_no_failed_plex_wait")
        _log("ACTOR_PROFILE_BIO_FAST_POLICY_V2547 korean_query_detailed_false_first=1 korean_full_retry_only_error_or_missing_identity=1 birthday_missing_exact_repair_preserved=1 plex_discover_runtime_disabled=1 original_bio_lean_json_minimal=1 original_tmdb_fallback_preserved=1 late_bio_eventual=1 atomic_reveal=unchanged photo_v2544=unchanged")
        _log("PKM_PATCH_ACTIVE v2547r2 actor_bio_korean_lean_plus_section_firstpaint_atomic_hold")
        _log("SECTION_FIRSTPAINT_POLICY_V2547R2 scope=all_section_recommend_ab_swaps exact_texture_not_visible_proof=1 post_active_hidden_settle_ms=80 source_bank_hold=1 target_bank_alpha_percent=1 poster_overlay_same_reveal=1 no_network_change=1 no_placeholder=1")
        _log("PKM_PATCH_ACTIVE v2548 actor_profile_tmdb_upgrade_visible_overlay_commit")
        _log("PKM_PATCH_ACTIVE v2550 actor_profile_hero_geometry_stage1_reference_match")
        _log("ACTOR_PROFILE_LAYOUT_POLICY_V2550 portrait=320x420@0,55 name_left=375 name_top=80 name_font=56 english_top=150 birthday_top=205 bio=1340x210@375,280 inner=1316x186 rail_unchanged=1 v2548_speed_path_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2551 actor_profile_reference_border_calendar_bio_outline")
        _log("ACTOR_PROFILE_VISUAL_DETAIL_POLICY_V2551 portrait_outline=local_png_320x420 calendar_icon=local_png_24 bio_outline=local_png_1340x210 geometry_unchanged=1 network_added=0 critical_path_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2552 actor_profile_focused_work_fanart_geometry_spacing_fix")
        _log("PKM_PATCH_ACTIVE v2553 actor_profile_home_diffuse_roundclip_compact_bio_spacing")
        _log("ACTOR_PROFILE_VISUAL_POLICY_V2553 fanart=home_bingie_diffuse_1220x680 no_fullscreen_fanart=1 portrait_exact_round_mask=320x420 scalediffuse_false=1 bio=1100x210 inner=1076x186 birthday_top=228 actor_entry_network_unchanged=1")
        _log("ACTOR_PROFILE_VISUAL_POLICY_V2552 focused_work_fanart=container6500_native_art background_async=1 portrait_image_inset_px=2 bio_fill_inset_px=2 name_english_gap_px=10 birthday_icon_baseline_group=1 works_title_top=530 works_panel_top=615 critical_path_added=0 network_gate_added=0")
        _log("ACTOR_PROFILE_PORTRAIT_VISUAL_POLICY_V2548 first_visible=info_or_cached upgrade_overlay_xml_bound=1 upgrade_texture_local=1 soft_fade_ms=260 finalize_base_thumb_after_ms=320 overlay_clear_after_base_bind_ms=48 same_actor_guard=1 late_worker_no_current_page_mutation=1 biography_pipeline=v2547_unchanged")
        _log("ACTOR_PROFILE_PORTRAIT_UPGRADE_POLICY_V2544 first_visible=info_cast_local cached_tmdb_alt_first=1 person_images_on_critical_path=0 tmdb_alt_after_visible=1 soft_crossfade_ms=260 persistent_actor_cache=1 reuse_across_movies=1 late_worker_actor_guard=1")
        _log("STARTUP_BUDGET_POLICY_V2535 unchanged_target_ms=3000 new_content_target_ms=6000 abnormal_ms=6000 watchdog_ms=12000 established_current_home_only=1 first_bootstrap_full_destination_gate=1 offscreen_destination_repair=post_home text_whitelist=new_content,pkm_update,problem")
        _log("ACTOR_PROFILE_LAYOUT_POLICY_V2532 portrait=320x480 top=90 aspect=scale_preserve hero_title_top=95 birthday_top=163 bio_top=225 bio=1340x325 inner=1316x301 rail_label=내_라이브러리_출연작 label_top=600 rail_top=660 bottom_clearance=30 focused_label_gap=24")
        _log("PKM_PATCH_ACTIVE v2530 startup_unresolved_poster_bounded_session_placeholder_no_deadlock")
        _log("PKM_PATCH_ACTIVE v2531 startup_unresolved_poster_source_truth_diagnostic_no_behavior_change")
        _log("STARTUP_POSTER_DIAG_POLICY_V2531 authority_source_count=1 synthesized_ratingkey_thumb_identified=1 token_redacted=1 fetch_behavior_unchanged=1 v2530_failsoft_unchanged=1")
        _log("STARTUP_TEXTURE_FAILSOFT_POLICY_V2530 bounded_fetch_passes=2 unresolved_after_retry=session_only_missing_card persistent_negative_cache=0 live_popin=0 blank_publish=0 home_release=1 next_rebuild_retry=1")
        _log("ACTOR_PROFILE_COLD_ENRICH_POLICY_V2525 superseded_by=v2526 late_current_page_enrich_disabled=1")
        _log("INFO_TV_RAIL_POLICY_V2510 episode_bind=addItems_once persisted_rows=section_authority_only persisted_season_cards=section_authority_only cold_fallback_unchanged=1 no_progressive_publish=1")
        _log("ACTOR_PROFILE_BIO_POLICY_V2528 language_priority=korean_first fallback=original box=1100x184 padding=12 inner=1076x160 max_lines=box_height ellipsis=box_fit fixed_char_limit=0")
        _log("ACTOR_PROFILE_GAP_SEAL_V2504 collapsed=70-112 expanded=410-441 info_resolution_crescent_hidden=1 content_geometry_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2481 actor_profile_final_geometry_atomic_focus_intent_prewarm_cold_timing")
        _log("PKM_SWAP_CONTRACT_V2479 rule=source_hold_hidden_target_one_gui_frame_atomic_commit surfaces=home,section_recommend,section_library,section_category,search,info,actor_profile,actor_work_info existing_atomic_paths_preserved=1")
        _log("PKM_PATCH_ACTIVE v2471 section_tab_persist_exact_library_key_db_authority_no_repeat_spinner")
        _log("PKM_PATCH_ACTIVE v2209 media_version_popup_fanart_tint_fast_metadata_budget")
        _log("PKM_PATCH_ACTIVE v2211 exit_confirm_previous_fanart_tint")
        _log("PKM_PATCH_ACTIVE v2213 vivid_dominant_color_clean_fanart")
        _log("PKM_PATCH_ACTIVE v2215 edge_weighted_background_color")
        _log("PKM_PATCH_ACTIVE v2216 edge_area_first_fanart_background_color")
        _log("PKM_PATCH_ACTIVE v2217 left_blend_edge_fanart_color")
        _log("PKM_PATCH_ACTIVE v2218 fanart_diffuse_seam_band_color_match")
        _log("PKM_PATCH_ACTIVE v2214 widget_fanart_tint_fast_follow_cache_direct_short_probe")
        _log("PKM_PATCH_ACTIVE v2210 media_version_popup_white_tint_base_fix")
        # v352: Plex-like sidebar re-entry memory. LEFT to menu keeps the current
        # widget stack/row position; RIGHT from the same menu returns to the
        # last focused Home/section recommendation row. Changing the sidebar
        # menu clears this memory so the newly selected menu starts from row1.
        self._menu_reentry_last_row = {HOME_ROW_ANCHOR_SCOPE: 0, SECTION_ROW_ANCHOR_SCOPE: 0}
        self._home_active_row = 0
        # PKM_PATCH_ACTIVE v2595 uhd_sidebar_debounce_no_bounce_runtime_minimal
        # Kodi's list owns visual focus immediately.  Right-side scene work is
        # coalesced separately so rapid DOWN never executes one full render per key.
        self._sidebar_debounce_lock_v2595 = threading.RLock()
        self._sidebar_debounce_pending_v2595 = None
        self._sidebar_debounce_commit_v2595 = None
        self._sidebar_debounce_worker_running_v2595 = False
        self._sidebar_commit_posted_v2599 = False
        self._sidebar_focus_commit_token_v1815 = int(getattr(self, "_sidebar_focus_commit_token_v1815", 0) or 0)
        # V2596: Home/section widget navigation is native-first on UHD.
        # Expensive hero/property publication is coalesced after stable focus.
        self._widget_focus_debounce_lock_v2596 = threading.RLock()
        self._widget_focus_pending_v2596 = None
        self._widget_focus_commit_v2596 = None
        self._widget_focus_worker_running_v2596 = False
        self._widget_focus_posted_v2599 = False
        self._widget_focus_token_v2596 = 0
        self._actor_profile_enrich_lock_v2599 = threading.RLock()
        self._actor_profile_enrich_pending_v2599 = None
        _log("UHD_RUNTIME_MINIMAL_POLICY_V2595 sidebar_debounce_ms=90 sidebar_scrolltime=0 collapsed_mirror_per_key=0 audit=0 android_workers=bounded bg_tint_navigation=0 update_poll_navigation=0")
        _log("PKM_PATCH_ACTIVE v2599 foreground_zero_wait_tv_actor_sidebar_widget")
        _log("FOREGROUND_ZERO_WAIT_POLICY_V2599 tv_show_only_all_platforms=1 sidebar_delay_ms=0 sidebar_python_move=0 widget_delay_ms=0 actor_tmdb_before_visible=0 actor_local_rows_wait_ms=120 actor_late_enrich=1")
        _log("PKM_PATCH_ACTIVE v2600 uhd_hard_minimal_full_event_diag")
        _log("PKM_PATCH_ACTIVE v2661 tab_intent_wins_no_postvisible_library_spinner_overlay_off")
        _log("UHD_HARD_MINIMAL_POLICY_V2600 android_old_diag_200ms=0 diag_sampler_ms=1000 diag_event_queue=1 gui_hotpath_diag_io=0 art_lanes=1 dynamic_bg_network=0 dynamic_bg_decode=0 dynamic_bg_lerp=0 widget_meta_stable_ms=140 wall_meta_stable_ms=160 sidebar_xml_only=1 sidebar_scene_stable_ms=120 actor_tmdb_idle_only=1 actor_portrait_upgrade_network=0 library_initial_bound=30 append_rebind_idle_or_edge=1")
        _log("GLOBAL_NAV_LIGHT_POLICY widget_settle_ms=120 wall_settle_ms=160 android_focus_cast_prewarm=0 android_wall_cast_prewarm=0 kodi_native_move_only=1 python_direction_step=0")
        _log("UHD_INFO_NATIVE_FIRST_POLICY_V2601 sidebar_spinner=0 info_spinner=0 info_cast_network_before_visible=0 info_actor_widgets_before_visible=0 tv_episode_network_before_visible=0 tv_missing_rows=late_async actor_preclick_tmdb=0 actor_visible_enrich_idle=1 source_hold=1")
        _log("PKM_PATCH_ACTIVE v2602 uhd_info_foreground_zero_sql_actor_no_busy_append_quiet")
        _log("UHD_INFO_FOREGROUND_ZERO_SQL_POLICY_V2602 movie_version_sql_before_visible=0 movie_media_prewarm_before_visible=0 actor_global_busy=0 actor_action_block=0 library_append_sql_during_info=0 postvisible_version_sql=1")
        _log("PKM_PATCH_ACTIVE v2603 info_actor_three_rows_restore_partial_commit_guard")
        _log("INFO_ACTOR_THREE_ROWS_POLICY_V2603 movie_actor_limit=3 cache_namespace=v2603 partial_native_bind_is_not_complete=1 reuse_requires_complete_rows=1")
        _log("KPI_LOG_POLICY_V2604 desktop_overlay_values_to_log=1 exact_info_actor_sidebar_events=1 pc_target_profile=uhd_proxy_r1 log_interval_ms=1000 screen_capture_required=0")
        _log("KPI_PROXY_POLICY_V2605 desktop_diag_only=1 android_native_first_info_path=1 movie_version_previsible_sql=0 movie_media_prewarm_previsible=0 cast_network_previsible=0 tv_network_previsible=0 actor_busy=0 actor_ratings_join=0 library_append_foreground=0")
        _log("INFO_CAST_LATE_FILL_POLICY_V2606 first_frame_local_only=1 postvisible_plex_prewarm=1 gui_inplace_cast_item_update=1 control_reset=0 focus_write=0 stale_title_guard=1")
        _log("KPI_LIBRARY_TRANSITION_POLICY_V2606 visible_ms_property=1 pass_ms=500 warn_ms=1000 spinner_observe=1")
        _log("PKM_PATCH_ACTIVE v2607 info_cast_focus_prime_fast_click_guaranteed_late_fill")
        _log("INFO_CAST_IMMEDIATE_POLICY_V2607 stable_focus_prime_ms=120 android_post_meta_prime=1 movie_late_fallback_ms=80 tv_late_fallback_ms=120 late_watch_ms=12000 first_visible_network_wait=0 fast_click_late_fill_required=1")
        _log("PKM_PATCH_ACTIVE v2608 info_cast_direct_plex_role_url_tv_late_rows_snapshot")
        _log("INFO_CAST_DIRECT_PLEX_POLICY_V2608 role_url_first_frame=1 tmdb_remote_size=w342 local_download_gate=0 fast_metadata_prime=1 fast_click_remote_commit=1 missing_portrait_fallback_async=1 tv_late_rows_snapshot_commit=1")
        _log("PKM_PATCH_ACTIVE v2609 info_atomic_complete_cast_lead_texture_tv_episode_prewarm_library_runway")
        _log("INFO_ATOMIC_COMPLETE_POLICY_V2609 source_hold=1 cast_role_metadata_previsible_bounded=120ms cast_lead_texture_prime=3 cast_join_budget_ms=80 tv_focus_allleaves_prewarm=1 tv_cold_atomic_fetch_timeout_ms=600 tv_loading_shell=0 postvisible_episode_popin_normal=0 library_android_low_watermark_rows=4 library_android_prefetch=36")
        _log("PKM_PATCH_ACTIVE v2610 actor_info_thumb_handoff_profile_upgrade_sort_actor_kpi")
        _log("ACTOR_PROFILE_PORTRAIT_HANDOFF_POLICY_V2610 info_cast_remote_or_local_first=1 placeholder_if_info_photo=0 postvisible_tmdb_upgrade=1 android_idle_gate=1 session_ready_not_portrait_ready=1")

    def _init_step6(self, args, session_cache_v1632):
        """Step 6 of __init__ (R76 split, moved verbatim). Logs: SORT_KPI_POLICY_V2610, ACTOR_KPI_POLICY_V2610, UHD_LIBRARY_PROXY_POLICY_V2610, PKM_PATCH_ACTIVE."""
        _log("SORT_KPI_POLICY_V2610 movie_tv_all_sort_keys=1 warm_pass_ms=250 warm_warn_ms=400 cold_pass_ms=500 cold_warn_ms=1000 spinner_fail=1 cache_reuse_on_sort=1")
        _log("ACTOR_KPI_POLICY_V2610 first_visible_pass_ms=200 complete_pass_ms=250 info_cast_placeholder_violation=0 portrait_upgrade_event=1 works_ready_event=1")
        _log("UHD_LIBRARY_PROXY_POLICY_V2610 desktop_diag_uses_android_runway=1 initial_bound=30 low_watermark_rows=4 prefetch=36 append=12")
        _log("PKM_PATCH_ACTIVE v2611 actor_postvisible_tmdb_enrich_completion_fix")
        _log("ACTOR_PROFILE_ENRICH_POLICY_V2611 previsible_tmdb=0 postvisible_idle_tmdb=1 incomplete_session_resume=1 incomplete_cache_resume=1 input_block=0 spinner=0 page_change_cancel=1 persistent_complete_profile=1")
        _log("PKM_POLICY_ACTIVE search_remote_input_back=1 actor_nav_hotpath=1 actor_focus_retry_light=1 actor_intent_settle_uhd_ms=180")
        _log("POSTER_PROGRESS_ATOMIC_POLICY_V2716 progress_visible_requires_widget_poster_ready=1 sidebar_gate=progress_cards_only ordinary_cards_zero_wait_v2715=1 spinner_threshold_unchanged_1500ms=1")
        _log("ACTOR_PROFILE_UHD3_POLICY_V2670 first_portrait=parent_info tmdb_portrait=postvisible_idle bio=late_local_or_cache works=mandatory source_work_fallback=1 rail_fanart=off_android navigation=poster_only")
        _log("ACTOR_KPI_META_POLICY_V2611 metadata_ready_event=1 meta_ready_ms=1 meta_status=1 actor_complete_updates_after_meta=1 proxy_target_ms=2500_5000")
        _log("PKM_PATCH_ACTIVE v2612 actor_foreground_authority_bypass_reentrant_latest_only_kpi_na_fix")
        _log("ACTOR_PROFILE_FOREGROUND_POLICY_V2612 proxy_persistent_authority_scan_previsible=0 session_memory_first=1 profile_cache_local=1 local_works_current=1 reentrant_latest_publish_only=1")
        _log("KPI_ACCURACY_POLICY_V2612 actor_stale_reentrant_publish=0 sort_zero_sample=NA actor_open_seq=1")
        _log("PKM_PATCH_ACTIVE v2613 pc_reference_runtime_restore_android_uplus_only_reduction")
        _log("PC_REFERENCE_POLICY_V2613 desktop_full_function=1 desktop_kpi_observe_only=1 runtime_proxy_default=0 uhd_reduction_android_only=1 actor_tmdb_preclick_desktop=1 actor_portrait_prewarm_desktop=1 actor_postvisible_delay_desktop_ms=0 direction_settle_desktop_ms=250")
        _log("PKM_PATCH_ACTIVE v2614 pc_actor_zero_authority_speculative_lock_priority_portrait_overlap")
        _log("PC_ACTOR_REFERENCE_POLICY_V2614 foreground_authority_scan=0 actor_busy=0 direction_tmdb_settle_desktop_ms=750 clicked_actor_priority=1 reentry_guard=1 portrait_parallel_after_identity=1 android_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2615 pc_actor_exact_direction_intent_helper_cache_fastpath")
        _log("PC_ACTOR_REFERENCE_POLICY_V2615 direction_target=postmove_current_item desktop_intent_settle_ms=80 helper_cacheonly_probe=1 korean_cache_first=1 original_cache_first=1 clicked_actor_priority=1 android_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2616 pc_info_direct_cast_actor_remote_profile_fastpath")
        _log("PC_REFERENCE_FASTPATH_POLICY_V2616 info_cast_click_download=0 info_remote_role_first=1 info_pc_lead_wait_ms=0 actor_helper_double_probe=0 actor_first_slot_visible_prewarm=1 actor_remote_upgrade_first=1 actor_local_cache_backfill=1 android_bounded_lead_preserved=1")
        _log("PKM_PATCH_ACTIVE v2617 replacement_nonactor_kpi_info_fast_heartbeat_accuracy")
        _log("PC_NONACTOR_KPI_POLICY_V2617 actor_pipeline_unchanged=1 info_movie_version_sql_previsible=0 info_missing_cast_local_scan_previsible=0 info_direct_role_or_placeholder_atomic=1 android_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2619 pc_wall_native_small_progress_append_fastpath")
        _log("PC_WALL_POSTER_FASTPATH_POLICY_V2619 desktop_append_gate_wait_ms=0 canonical_small_remote_bind=1 desktop_python_append_poster_fetch=0 progress_rating_prewarm=background_before_ready kodi_texture_owner=1 android_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2620 pc_wall_continuous_down_light_runway")
        _log("PC_WALL_CONTINUOUS_DOWN_POLICY_V2620 live_append_light_builder=1 progress_rows_publish_before_rating_warm=1 rapid_publish_full_prefetch=1 canonical_meta_bulk_in_append=0 kodi_small_remote=1 android_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2621 wall_texture_runway_local_before_visible")
        _log("WALL_TEXTURE_RUNWAY_POLICY_V2621 prefetch_rows=48 first12_priority=visible remainder_priority=ahead_background kodi_textures13_reuse=1 pkm_small_cache=1 post_key_local_rebind=map_only foreground_wait_ms=0 android_single_network_lane=1 remote_fallback=1")
        _log("PKM_PATCH_ACTIVE v2622 tv_wall_cold_runway_deep_prefetch_visible_promotion_compact_append")
        _log("TV_WALL_COLD_RUNWAY_POLICY_V2622 data_pages_ahead=2 texture_visible_rows=18 stale_queue_purge=1 visible_priority_promote=1 tv_append_compact_batch_properties=1 section_stale_selection_clamp=1 foreground_wait_ms=0 android_network_lane_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2623 tv_wall_poster_deadline_runway")
        _log("TV_WALL_POSTER_DEADLINE_POLICY_V2623 current_download_window=24 deep1_download_window=18 deep2_data_only=1 cached_reserve_rearm=1 initial_tv_priority=visible download_success_gui_commit=1 android_network_lane_unchanged=1 movie_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2624 tv_wall_viewport_authority_poster_preemption")
        _log("TV_WALL_VIEWPORT_POSTER_POLICY_V2624 priority_owner=actual_kodi_viewport append_frontier_not_visible=1 visible_rows=18 near_ahead_rows=24 far_future_queue=defer active_future_preempt_on_visible_miss=1 passed_transfer_cancel=1 android_network_lane_unchanged=1 movie_policy_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2625 movie_tv_wall_viewport_authority_common_poster_preemption")
        _log("LIBRARY_WALL_VIEWPORT_POSTER_POLICY_V2625 priority_owner=actual_kodi_viewport media=movie+tv visible_rows=18 near_ahead_rows=24 far_future_queue=defer active_future_preempt_on_visible_miss=1 passed_transfer_cancel=1 tv_data_runway_unchanged=1 movie_db_append_unchanged=1 android_network_lane_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2626r2 full_movie_tv_sort_matrix_materialized_index_info_experience_kpi")
        _log("LIBRARY_SORT_MATRIX_POLICY_V2626 movie_keys=12 tv_keys=12 foreground_raw_json_udf=0 foreground_tv_episode_group=0 persistent_materialized_index=1 startup_background_prewarm=1 library_visible_priority_prewarm=1 rating_provider_native_join=1 cold_warm_per_key_kpi=1")
        _log("INFO_EXPERIENCE_KPI_POLICY_V2626 movie_tv_split=1 cold_warm_split=1 required_ready=1 visible=1 interactive=1 spinner_zero=1 core_nogo=1")
        _log("PKM_PATCH_ACTIVE v2627 sort_index_quiet_native_json_fullquery_info_cold_fastpath")
        _log("SORT_INDEX_POLICY_V2627 native_json_extract=1 python_episode_udf_hotpath=0 prewarm_yield_navigation=1 limit0_fullquery=1 v2626_matrix_preserved=1")
        _log("INFO_COLD_FASTPATH_POLICY_V2627 watcha_point_lookup=1 watcha_bulk_click=0 cast_local_first=1 portrait_network_previsible=0 identity_network_max_ms=350 postvisible_portrait_latefill=1")
        _log("PKM_PATCH_ACTIVE v2628 sort_fullquery_chunk_sorthead_poster_intent_prewarm")
        _log("SORT_COLD_FIRSTPAINT_POLICY_V2628 dropdown_focus_intent_prewarm=1 visible_posters=12 directional_neighbors=3 sqlite_fullquery_chunk=400 provider_index=1 foreground_wait_added=0 v2625_viewport_scheduler_unchanged=1")
        _log("PKM_PATCH_ACTIVE v2629 info_cast_local_texture_atomic_reveal_no_placeholder_popin")
        _log("INFO_CAST_ATOMIC_TEXTURE_POLICY_V2629 first_frame_remote_url_not_ready=1 local_texture_only=1 placeholder_replacement_visible=0 sequential_popin=0 panel_hold_until_atomic=1 stable_focus_all8_prewarm=1 postvisible_atomic_commit=1 info_body_wait_added=0 movie_tv_common=1")
        _log("PKM_PATCH_ACTIVE v2630 info_cold_point_rating_actor_family_no_bulk_cast_unknown_safe")
        _log("INFO_COLD_PIPELINE_POLICY_V2630 cast_unknown_not_missing=1 cast_unknown_retry_postvisible=1 canonical_full_bulk_previsible=0 actor_work_family_row_signature=1 imdb_point_lookup=1 atomic_v2629_preserved=1 info_body_wait_added=0")
        _log("PKM_PATCH_ACTIVE v2631 recommend_cold_common_index_seek_cast_reuse_atomic")
        _log("PKM_PATCH_ACTIVE v2632 actor_visible_zero_prime_deferred_append_refill")
        _log("KPI_HOTPATH_POLICY_V2632 actor_texture_prime_wait_ms=0 append_next_prefetch_postcallback=1 append_foreground_refill_start=0 info_fastpath_unchanged=1 recommend_v2631_unchanged=1")
        _log("RECOMMEND_COLD_COMMON_POLICY_V2631 library_specific=0 section_id_hardcode=0 tv_base_first_episode_map=index_seek movie_existing_async_compose=preserved cached_revisit=unchanged ab_swap=unchanged")
        _log("INFO_CAST_LOCAL_REUSE_POLICY_V2631 local_actor_reuse_remote_is_valid_source=1 localize_before_atomic=1 plex_current_role_missing_can_reuse_other_library_role=1 confirmed_missing_only_after_reuse_miss=1")
        # v103: navigation trace only.  Do not move focus from Python; only log
        # Kodi's before/after focus result so row/list behavior can be verified.
        self._home_nav_trace_seq = 0
        # v246: sidebar library order edit mode.  Only Plex library section rows
        # are movable; Home/Search/Settings stay fixed.
        self._menu_reorder_mode = False
        self._menu_reorder_sid = ""
        self._menu_reorder_dirty = False
        # v306: Home trailer preview state.  This is independent from normal
        # movie playback, so it must never set MainPlaybackStarting or use the
        # plugin action=play resolver.
        self._home_trailer_token = 0
        self._home_trailer_rating_key = ""
        self._home_trailer_playing = False
        self._home_trailer_url = ""
        # v311: stopping a YouTube/inputstream preview can block for many seconds
        # if we call xbmc.Player().stop() directly from the focus/navigation path.
        # Keep stop requests non-blocking so the next poster focus/meta path stays fast.
        self._home_trailer_stop_in_progress = False
        self._home_trailer_last_stop_ms = 0
        # v307: cache lookup result per ratingKey to avoid repeated Plex/YouTube requests.
        self._home_trailer_lookup_cache = {}
        # v695: selective poster fallback probe.  Keep v691 primary poster path fast;
        # only when the Plex thumb endpoint fails and the item art endpoint works,
        # set a ListItem property that lets XML overlay the art fallback.  This is
        # data-only background checking: no focus/navigation/playback flow control.
        self._poster_fallback_probe_cache = {}
        self._poster_fallback_probe_queue = []
        self._poster_fallback_probe_running = False
        self._poster_fallback_probe_lock = threading.Lock()
        self._poster_texture_cache = {}
        # v784: Cine21 Home meta ratings are read from local cine21_matches only.
        # No network, no matching/rebuild, no UI-flow control on poster focus.
        self._home_cine21_cache = {}
        self._home_cine21_db_mtime = None
        # v1220: Watcha Pedia Home meta ratings are also local DB only.
        # Keep them in light caches so Home poster movement stays responsive.
        self._home_watcha_cache = {}
        self._home_watcha_db_mtime = None
        self._poster_probe_timeout_sec = 2.0
        self._poster_probe_max_per_window = 80
        self._poster_probe_count = 0
        # v006: background Plex library-change watcher.  It only polls light
        # section metadata and updates a small recent-items slice when a section
        # changed.  It never repaints the current screen directly; it only sets
        # dirty flags so Home/section cache reuse is skipped on the next entry.
        self._plex_update_watch_running = False
        self._plex_update_watch_stop = False
        self._plex_update_snapshot = {}
        self._plex_update_dirty_home = False
        self._plex_update_dirty_sections = set()
        self._plex_update_last_notify_ms = 0
        self._plex_update_poll_interval_sec = 120
        self._home_data_refresh_watch_running = False
        self._home_data_refresh_token = ""
        # v1555: sync completion is consumed only on Kodi GUI-thread callbacks.
        # Visible Home rows are never reset naked: the existing visual-only
        # previous-row buffer covers the row stack until the replacement rows
        # are fully populated, so a committed sync cannot flash a blank widget
        # frame.  Unsafe focus/scroll states remain pending for the next safe
        # Home entry instead of forcing a visible rebuild.
        self._sync_widget_refresh_applying_v1555 = False
        # v1556: sidebar library focus changes are a GUI-thread atomic swap.
        # The current Home/section widgets remain visible while target rows are
        # prepared; no skeleton placeholder or widget fade is used.
        self._sidebar_widget_atomic_hold_v1556 = False
        # v1612: true two-bank section widget staging. The visible bank is never
        # reset while a sidebar target is being prepared. The inactive bank is
        # populated completely and then both XML groups swap visibility once.
        self._section_active_bank_v1612 = "A"
        self._section_bank_cache_key_v1612 = {"A": "", "B": ""}
        # v1619: startup and section scenes are composed completely off-screen.
        # Startup stays behind one opaque spinner gate until Home rows, hero and
        # visible poster textures have settled. Section transitions capture the
        # target metadata without publishing it, then flip metadata + A/B bank in
        # one tight GUI transaction so no intermediate title/poster state is seen.
        self._startup_gate_token_v1619 = ""
        self._startup_gate_release_running_v1619 = False
        self._home_meta_capture_only_v1619 = False
        self._home_meta_snapshot_v1619 = None
        # v1620/v1883: one-time scene preparation per sidebar section. Cold
        # sections keep the previous completed scene visible. Readiness is a
        # logical gate; the single global broker owns delayed spinner display.
        self._section_scene_cache_v1620 = dict(session_cache_v1632.get("section_scene_cache") or {})
        self._section_first_visit_gate_token_v1620 = ""
        self._section_first_visit_gate_key_v1620 = ""
        self._section_first_visit_gate_release_running_v1620 = False
        # The actual A/B publish signal owns readiness. No feature-specific
        # spinner delay exists here; pkm_global_busy.DEFAULT_DELAY_MS is the one
        # global threshold for every normal foreground wait.
        self._section_first_visit_timeout_ms_v1794 = 15000
        self._section_first_visit_gate_visible_token_v1622 = ""
        self._section_first_visit_gate_published_token_v1795 = ""
        self._section_first_visit_gate_state_lock_v1622 = threading.RLock()
        # v1863/v1883: Library-wall preparation keeps its own readiness token,
        # but not its own visual or timer. The previous complete surface remains
        # visible and pkm_global_busy owns the shared delayed spinner.
        self._library_wall_gate_lock_v1863 = threading.RLock()
        self._library_viewport_poster_active_v1866 = threading.Event()
        self._library_wall_gate_token_v1863 = ""
        self._library_wall_gate_sid_v1863 = ""
        self._library_wall_gate_visible_token_v1863 = ""
        self._library_wall_gate_started_ms_v1863 = 0
        self._section_render_lock_v1620 = threading.RLock()
        # v581: Home must be a normal WindowXML, not WindowXMLDialog.
        # WindowXMLDialog remains an active modal dialog and Kodi refuses
        # fullscreenvideo activation while it is open. A normal WindowXML can
        # stay underneath the player, so PKM does not need to close and the
        # active skin Home is not exposed during playback.
        xbmcgui.WindowXML.__init__(self, *args)

    def _full_reset_stop_live_workers_v2151(self, token=""):
        """Hard-stop every worker owned by this live Home instance.

        The reset-control sentinel is intentionally the only survivor until the
        post-delete in-memory purge is acknowledged.  No DB/network work is done
        here; this is cancellation + drain only.
        """
        win = xbmcgui.Window(10000)
        try:
            _PKM_HOME_FULL_RESET_STOP_V2151.set()
            self._closing_event_v1841.set()
            try:
                pkm_sort_index_v2626.shutdown_u3()
                pkm_artwork_scheduler.shutdown_u3()
            except Exception:
                pass
            self._plex_update_watch_stop = True
            self._home_data_refresh_watch_running = False
            for event_name in (
                "_startup_scene_composed_event_v1841", "_startup_ready_event_v1841",
                "_home_watcha_preload_event_v1642",
            ):
                try:
                    ev = getattr(self, event_name, None)
                    if ev is not None and hasattr(ev, "set"):
                        ev.set()
                except Exception:
                    pass
            # Invalidate every delayed apply/publish owner before waiting.
            for attr in (
                "_home_progressive_generation_v1642", "_home_meta_nav_generation_v1837",
                "_home_fanart_token", "_home_bg_token", "_home_bg_apply_token",
                "_info_prewarm_token", "_menu_refresh_generation_v1906",
                "_section_bank_render_serial_v1844",
            ):
                try:
                    setattr(self, attr, int(getattr(self, attr, 0) or 0) + 1)
                except Exception:
                    pass
            self._library_wall_gate_token_v1863 = ""
            self._library_wall_gate_sid_v1863 = ""
            self._library_wall_gate_visible_token_v1863 = ""
            self._home_bg_probe_pending_v2140 = None
            try:
                with self._wall_poster_prefetch_lock_v1644:
                    self._wall_poster_prefetch_queue_v1644[:] = []
                    self._wall_poster_prefetch_seen_v1644.clear()
                    self._wall_poster_prefetch_attempts_v1644.clear()
            except Exception:
                pass
            try:
                with self._poster_fallback_probe_lock:
                    self._poster_fallback_probe_queue[:] = []
            except Exception:
                pass
            try:
                with self._info_cast_prewarm_lock:
                    self._info_cast_prewarm_queue[:] = []
                    self._info_cast_prewarm_seen.clear()
            except Exception:
                pass
            try:
                pkm_global_busy.cancel_all(reason="full_reset_home_v2151")
            except Exception:
                pass
            try:
                if hasattr(pkm_artwork_scheduler, "request_full_reset_stop_v2150"):
                    pkm_artwork_scheduler.request_full_reset_stop_v2150()
            except Exception:
                pass
        except Exception:
            _log("PKM_FULL_RESET_HOME_STOP_SIGNAL_FAILED_V2151 token=%s err=%s" % (
                token or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        current = threading.current_thread()
        waited_ms = 0
        pending = []
        while waited_ms < 20000:
            pending = []
            for t in _pkm_home_live_threads_v2151(exclude=current):
                try:
                    # A second reset-control sentinel should never exist, but do
                    # not deadlock reset if Kodi re-enters onInit unexpectedly.
                    if str(t.name or "").startswith("PlexKMFullResetControlV2151"):
                        continue
                    pending.append(t)
                except Exception:
                    pass
            if not pending:
                break
            xbmc.sleep(25)
            waited_ms += 25
        names = [str(getattr(t, "name", "") or "") for t in pending]
        ok = not bool(pending)
        try:
            win.setProperty("PlexKM.Home.FullResetWorkersStoppedV2151", str(token or "") if ok else "")
            win.setProperty("PlexKM.Home.FullResetWorkersPendingV2151", " | ".join(names[:12]))
        except Exception:
            pass
        _log("PKM_FULL_RESET_HOME_WORKER_DRAIN_V2151 token=%s waited_ms=%d active=%d pending=%s ok=%d" % (
            token or "", waited_ms, len(pending), " | ".join(names[:12]) if names else "-", 1 if ok else 0
        ), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        if ok:
            _log("PKM_FULL_RESET_HOME_ZERO_PENDING_CONTINUE_V2166 token=%s waited_ms=%d action=continue_immediately" % (
                token or "", waited_ms
            ), xbmc.LOGINFO)
        return ok

    def _start_full_reset_control_v2151(self):
        try:
            if getattr(self, "_full_reset_control_started_v2151", False):
                return
            self._full_reset_control_started_v2151 = True
            win = xbmcgui.Window(10000)

            def _watch():
                try:
                    monitor = xbmc.Monitor()
                    stop_token = ""
                    purge_token = ""
                    while not monitor.abortRequested():
                        requested = win.getProperty("PlexKM.FullResetRequestedAtV2150") or win.getProperty("PlexKM.FullResetRequestedAtV2149") or ""
                        active = win.getProperty("PlexKM.FullResetInProgressV2150") == "1" or win.getProperty("PlexKM.FullResetInProgressV2149") == "1"
                        if active and requested and requested != stop_token:
                            stop_token = requested
                            win.clearProperty("PlexKM.Home.FullResetWorkersStoppedV2151")
                            win.clearProperty("PlexKM.Home.FullResetWorkersPendingV2151")
                            self._full_reset_stop_live_workers_v2151(stop_token)
                        requested_purge = win.getProperty("PlexKM.Home.FullResetPurgeRequestV2151") or ""
                        if requested_purge and requested_purge != purge_token:
                            purge_token = requested_purge
                            self._full_reset_purge_live_home_v2151(purge_token)
                            return
                        if monitor.waitForAbort(0.025):
                            return
                except Exception:
                    _log("PKM_FULL_RESET_HOME_CONTROL_FAILED_V2151 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

            _PKMHomeThreadV2151(target=_watch, name="PlexKMFullResetControlV2151", daemon=True).start()
            _log("PKM_FULL_RESET_HOME_CONTROL_START_V2151")
        except Exception:
            _log("PKM_FULL_RESET_HOME_CONTROL_START_FAILED_V2151 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _worker_alive_v1841(self, generation=None):
        """Return False once this WindowXML lifetime has ended."""
        try:
            if self._closing_event_v1841.is_set():
                return False
            if generation is not None and int(generation) != int(self._lifecycle_generation_v1841):
                return False
            monitor = getattr(self, "_lifecycle_monitor_v1841", None)
            return not (monitor.abortRequested() if monitor is not None else xbmc.Monitor().abortRequested())
        except Exception:
            return False

    def _initial_compose_r57_begin(self, cause="", reason=""):
        if bool(getattr(self, "_initial_compose_r57_active", False)):
            return
        self._initial_compose_r57_active = True
        self._initial_compose_r57_pct = 0
        self._initial_compose_r57_started = time.monotonic()
        self._initial_compose_r59_last_progress = time.monotonic()
        self._initial_compose_r59_last_text = ""
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.Startup.InitialComposeTextR57", "라이브러리 화면 구성 중")
            win.setProperty("PlexKM.Startup.InitialComposePctR57", "0")
            win.setProperty("PlexKM.Startup.InitialComposeR57", "1")
        except Exception:
            pass
        try:
            self.setFocusId(_R57_OVERLAY_FOCUS_ID)
        except Exception:
            pass
        _log("STARTUP_R57_INITIAL_COMPOSE_BEGIN cause=%s reason=%s" % (cause or "", reason or ""))
        generation = int(getattr(self, "_lifecycle_generation_v1841", 0) or 0)

        def _watchdog():
            # Fail open: never leave the user stuck behind the overlay.
            while bool(getattr(self, "_initial_compose_r57_active", False)):
                if self._closing_event_v1841.wait(0.5):
                    break
                if not self._worker_alive_v1841(generation):
                    break
                # R59: the overlay belongs to the prepare worker and closes when
                # it finishes (Shield first run: 5.5 min).  Fail open only if
                # progress stalls for 150 s, or after 20 min in total.
                now_r59 = time.monotonic()
                stall_r59 = now_r59 - float(getattr(self, "_initial_compose_r59_last_progress", now_r59) or now_r59)
                total_r59 = now_r59 - float(getattr(self, "_initial_compose_r57_started", 0) or 0)
                if stall_r59 >= 150.0 or total_r59 >= 1200.0:
                    _log("STARTUP_R57_INITIAL_COMPOSE_WATCHDOG stall_s=%d total_s=%d action=fail_open" % (
                        int(stall_r59), int(total_r59)), xbmc.LOGWARNING)
                    break
                try:
                    if self.getFocusId() != _R57_OVERLAY_FOCUS_ID:
                        self.setFocusId(_R57_OVERLAY_FOCUS_ID)
                except Exception:
                    pass
            if bool(getattr(self, "_initial_compose_r57_active", False)):
                self._initial_compose_r57_end(reason="watchdog_or_close")

        _PKMHomeThreadV2151(target=_watchdog, name="PlexKMInitialComposeR57", daemon=True).start()

    def _initial_compose_r57_progress(self, text=None, pct=None):
        if not bool(getattr(self, "_initial_compose_r57_active", False)):
            return
        try:
            win = xbmcgui.Window(10000)
            if text:
                if str(text) != str(getattr(self, "_initial_compose_r59_last_text", "") or ""):
                    self._initial_compose_r59_last_text = str(text)
                    self._initial_compose_r59_last_progress = time.monotonic()
                win.setProperty("PlexKM.Startup.InitialComposeTextR57", str(text))
            if pct is not None:
                pct = max(int(getattr(self, "_initial_compose_r57_pct", 0) or 0), max(0, min(100, int(pct))))
                if pct != int(getattr(self, "_initial_compose_r57_pct", 0) or 0):
                    self._initial_compose_r59_last_progress = time.monotonic()
                self._initial_compose_r57_pct = pct
                win.setProperty("PlexKM.Startup.InitialComposePctR57", str(pct))
        except Exception:
            pass

    def _initial_compose_r57_end(self, reason=""):
        if not bool(getattr(self, "_initial_compose_r57_active", False)):
            return
        self._initial_compose_r57_active = False
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.Startup.InitialComposePctR57", "100")
            for name in ("PlexKM.Startup.InitialComposeR57",
                         "PlexKM.Startup.InitialComposeTextR57",
                         "PlexKM.Startup.InitialComposePctR57"):
                win.clearProperty(name)
        except Exception:
            pass
        try:
            if self.getFocusId() == _R57_OVERLAY_FOCUS_ID:
                self.setFocusId(9000)
        except Exception:
            pass
        _log("STARTUP_R57_INITIAL_COMPOSE_END reason=%s elapsed_ms=%d" % (
            reason or "", int((time.monotonic() - float(getattr(self, "_initial_compose_r57_started", 0) or 0)) * 1000)))

    _R70_THUMB_RE = re.compile(r"^(https?://[^/?#]+)/library/metadata/(\d+)/(thumb|art)(?:/\d+)?(\?[^#]*)?$")

    _R71_DEAD_TTL_S = 6 * 3600

    def _derived_cache_path_v2467(self, filename):
        try:
            dbp = self._profile_db_path()
            root = os.path.dirname(dbp) if dbp else xbmcvfs.translatePath(
                "special://profile/addon_data/plugin.video.km/"
            )
            if root and not os.path.isdir(root):
                os.makedirs(root, exist_ok=True)
            return os.path.join(root, str(filename or ""))
        except Exception:
            return ""

    def _json_safe_v2467(self, value):
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (tuple, list)):
            return [self._json_safe_v2467(v) for v in value]
        if isinstance(value, dict):
            out = {}
            for k, v in value.items():
                try:
                    out[str(k)] = self._json_safe_v2467(v)
                except Exception:
                    continue
            return out
        return str(value)

    # PKM_PATCH_ACTIVE v2562 first_install_lifecycle_authority
    def _pkm_initial_setup_completed_v2562(self):
        """True after first library setup; survives re-auth/server changes."""
        try:
            c = _ensure_core()
            if hasattr(c, "initial_setup_completed"):
                return bool(c.initial_setup_completed())
            # Compatibility fallback for a partially-upgraded code set.
            return bool(c.initial_sync_done())
        except Exception:
            return False

    def onInit(self):
        # U3: new Home instance may follow an earlier WindowXML close.
        try:
            pkm_sort_index_v2626.resume_u3()
            pkm_artwork_scheduler.resume_u3()
            pkm_sort_index_v2626.note_navigation_u3(sidebar=True)
            pkm_artwork_scheduler.note_navigation_u3(sidebar=True)
        except Exception:
            pass
        # v2119: onInit is the first point at which XML-declared controls are
        # guaranteed to exist.  From here, scoped access to 9000 is allowed.
        self._xml_controls_ready_v2119 = True
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Home.XmlControlsReadyV2119", "1")
        except Exception:
            pass
        _log("HOME_XML_CONTROLS_READY_V2119 control9000_access=allowed focus=%s" % self._safe_focus_id())
        self._start_full_reset_control_v2151()
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        global _STARTUP_PROGRESS_CONTROL_V1894, _STARTUP_PROGRESS_IMAGE_CONTROL_V1904, _STARTUP_PROGRESS_FRAME_INDEX_V1904
        try:
            _STARTUP_PROGRESS_CONTROL_V1894 = self.getControl(19000)
        except Exception:
            _STARTUP_PROGRESS_CONTROL_V1894 = None
        # PKM_STARTUP_19001_SKIP_R33: control 19001 no longer exists in
        # plexkm_home_window.xml (the logo cover is image 16926).  Asking
        # Kodi for it raised "Non-Existent Control 19001" and a formatted
        # traceback inside onInit on every launch (~110 ms on SHIELD).  The
        # result was always None/-1, so keep exactly that outcome without the
        # exception.
        _STARTUP_PROGRESS_IMAGE_CONTROL_V1904 = None
        _STARTUP_PROGRESS_FRAME_INDEX_V1904 = -1
        self._onInit_step1()
        try:
            _home_win_v1635 = xbmcgui.Window(10000)
            _home_win_v1635.setProperty("PlexKM.HomeWindowActive", "true")
            if _home_win_v1635.getProperty("PlexKM.Home.LibraryApplyBusyV1754") == "1":
                self._sync_legacy_library_apply_global_busy_v1883(
                    active=True, reason="home_oninit_existing_apply"
                )
            if _home_win_v1635.getProperty("PlexKM.Home.PostPlaybackSectionNoSpinnerV1635") == "1":
                self._section_first_visit_gate_token_v1620 = ""
                self._section_first_visit_gate_key_v1620 = ""
                self._section_first_visit_gate_release_running_v1620 = False
                self._section_first_visit_gate_visible_token_v1622 = ""
                for _target_v1635 in (self, _home_win_v1635):
                    try:
                        _target_v1635.clearProperty("PlexKM.Section.FirstVisitGateV1620")
                        _target_v1635.clearProperty("PlexKM.Section.FirstVisitGateKeyV1620")
                        _target_v1635.clearProperty("PlexKM.Section.FirstVisitGateTokenV1620")
                    except Exception:
                        pass
                _log("POST_PLAYBACK_SECTION_GATE_CLEAR_V1635 reason=home_oninit spinner=0")
            try:
                bank_v1612 = self._section_bank_name_v1612()
                self.setProperty("PlexKM.Section.ActiveBankV1612", bank_v1612)
                xbmcgui.Window(10000).setProperty("PlexKM.Section.ActiveBankV1612", bank_v1612)
                _log("PKM_PATCH_ACTIVE v1617 section_ab_canonical_20row_schema_no_silent_truncation bank=%s" % bank_v1612)
                _log("PKM_PATCH_ACTIVE v1619 startup_atomic_spinner_section_atomic_meta_bank_publish_no_cover bank=%s" % bank_v1612)
                _log("PKM_PATCH_ACTIVE v1620 startup_once_first_visit_spinner_completed_scene_cache_fast_revisit bank=%s" % bank_v1612)
                _log("PKM_PATCH_ACTIVE v1621 section_spinner_over_previous_scene_session_immutable_fast_revisit bank=%s" % bank_v1612)
                _log("PKM_PATCH_ACTIVE v1622 section_delayed_spinner_superseded_v2492_1000ms_fast_first_visit_no_spinner bank=%s" % bank_v1612)
                _log("PKM_PATCH_ACTIVE v1632 playback_return_session_scene_cache_no_live_sync_rebuild restored=%d home_rows=%d scenes=%d" % (
                    1 if self._session_cache_restored_v1632 else 0,
                    len(self._home_rows_cache or []), len(self._section_scene_cache_v1620 or {})
                ))
                _log("PKM_PATCH_ACTIVE v1635 postplayback_section_stale_while_compose_visited_registry spinner=0")
                _log("PKM_PATCH_ACTIVE v1642 home_two_phase_progressive_no_reset_shared_watcha_stable_focus_cast_only")
                _log("PKM_PATCH_ACTIVE v1644 startup_plex_snapshot_all_sidebar_full_scene_before_reveal_runtime_updates_off_wall_poster_ahead")
                _log("PKM_PATCH_ACTIVE v1645 startup_no_cine21_post_reveal_idle_small_batch_next_start_apply")
                _log("PKM_PATCH_ACTIVE v1646 startup_atomic_release_worker_scope_fix_cursor_hidden_home_flash_block")
                _log("PKM_PATCH_ACTIVE v1647 local_home_under3s_network_and_sidebar_post_reveal_pointer_off")
                _log("PKM_PATCH_ACTIVE v1649 post_reveal_dynamic_all_sidebar_sections_local_scene_prewarm")
                _log("PKM_PATCH_ACTIVE v1650 sidebar_real_ui_visible_timing_and_transparent_pointer")
                _log("PKM_PATCH_ACTIVE v1651 dynamic_new_plex_library_sidebar_discovery_auto_select")
                _log("PKM_PATCH_ACTIVE v1654 xml_navigation_owner_blocks_stale_widget_focus_until_atomic_scene_ready_no_python_focus_repair")
                self._validate_section_ab_row_schema_v1617()
            except Exception:
                pass
            # v1643: keep the skin-level user splash armed. The plugin Home uses
            # the same image as its startup gate, and only the completed current
            # Home scene is allowed to clear both covers.
            # v1549: WindowXML.onInit can be called again while Kodi is still
            # opening or already playing the real video session.  ReturnInline.Pending
            # only means that this Info page must be restored after playback ends; it
            # is not proof that the user pressed Back.  Older builds treated this
            # callback as a Back return after 2.5 seconds and issued PlayerControl(Stop),
            # which stopped a valid session and exposed Info before a retry.
            # Preserve the existing surface and let Kodi/service callbacks own playback.
            try:
                _w = xbmcgui.Window(10000)
                _pending_inline_return = _w.getProperty("PlexKM.Playback.ReturnInline.Pending") == "1"
                _video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                _opening = (
                    _w.getProperty("PlexKM.MainPlaybackStarting") == "1"
                    or _w.getProperty("PlexKM.InfoDirectPlaybackStarting") == "1"
                    or _w.getProperty("PlexKM.Playback.OpeningActive") == "1"
                    or _w.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                )
                if _pending_inline_return and (_video_active or _opening):
                    _saved_at = _safe_int(_w.getProperty("PlexKM.Playback.ReturnInline.SavedAt"), 0)
                    _now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
                    _age_ms = (_now_ms - _saved_at) if _saved_at else 0
                    _log("INLINE_PLAYBACK_RETURN_ONINIT_ACTIVE_SESSION_PRESERVE_V1549 reason=no_auto_stop video_active=%s opening=%s age_ms=%d attempt_seq=%s token=%s" % (
                        "1" if _video_active else "0",
                        "1" if _opening else "0",
                        _age_ms,
                        _w.getProperty("PlexKM.Playback.ActiveAttemptSeqV1545") or "",
                        _w.getProperty("PlexKM.Playback.NativeOpening.Token") or _w.getProperty("PlexKM.Playback.ResolverTokenV1547") or "",
                    ))
                    return
            except Exception:
                _log("INLINE_PLAYBACK_RETURN_ONINIT_ACTIVE_SESSION_CHECK_FAILED_V1549 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            # v1619: no fixed-time cinematic reveal. XML is already covered by
            # one opaque spinner; release is driven only by completed Home data
            # plus visible texture settle.
            # R59: arm the first-install preparation overlay before Home loads
            # sections or starts any potentially expensive snapshot work.
            # Re-entry after playback is already returned above.
            try:
                _r59_first = False  # R115: obsolete preparation overlay permanently disabled
                _r59_win = xbmcgui.Window(10000)
                if _r59_first:
                    _r59_win.setProperty("PlexKM.Startup.InitialPrepareActiveCumulative", "1")
                    _r59_win.setProperty("PlexKM.Startup.InitialPrepareMessageCumulative",
                                         "시작 화면을 준비 중입니다")
                    # R72: never open a modal dialog during the logo.  Defer it
                    # until the final yellow frame has been displayed and the
                    # splash visibility property has actually been cleared.
                    self._r69_prepare_started = None
                    self._r69_prepare_dialog = None
                    _log('R72_PREP_DIALOG_DEFER stage=logo_active')
                    _log("R68_PREP_UI_ARM stage=home_oninit unconditional=1 message=starting_home_preparation visual_confirmation=requires_device")
                else:
                    _r59_win.clearProperty("PlexKM.Startup.InitialPrepareActiveCumulative")
                    _r59_win.clearProperty("PlexKM.Startup.InitialPrepareMessageCumulative")
            except Exception:
                _log("R59_INITIAL_PREPARE_UI_ARM_FAILED err=%s" % (
                    traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            # R118: shared service animation continues when this
            # WindowXML is actually displayed, not when service.py starts its
            # separate 4-second bookkeeping clock. Never reveal before the
            # visible animation has had its full four seconds.
            _log("R118_SHARED_LOGO_WINDOW_ATTACHED service_frame=%s" % (xbmcgui.Window(10000).getProperty("PlexKM.Startup.DisplayProgressV1891") or "0"))
            self._r121_native_logo_start = time.monotonic()
            _log("R123_HOME_NATIVE_LOGO_GATE duration_ms=4800 source=window_oninit_conservative")
            self._start_startup_gate_v1619(reason="oninit")
            try:
                _w1642 = xbmcgui.Window(10000)
                if not self._session_cache_restored_v1632:
                    _w1642.clearProperty("PlexKM.Home.ProgressiveModeV1642")
                    _w1642.clearProperty("PlexKM.Home.ProgressiveReadyV1642")
            except Exception:
                pass
            # v580: recover stale playback-hide flag only when no video is active.
            try:
                if not xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility("Player.HasVideo"):
                    xbmcgui.Window(10000).clearProperty("PlexKM.Playback.HidePKMUI")
                    xbmcgui.Window(10000).clearProperty("PlexKM.Playback.HideSkinHome")
            except Exception:
                pass
            self._clear_home_trailer_preview(reason="oninit", stop_player=False)
            # v464/v618: The library/Home side menu is dynamically populated from Plex/user order.
            # Search is a fixed XML button above MENU_ID, so MENU_ID pos 0 is Home.
            # XML keeps bootstrap defaultcontrol=100 with always=true; after
            # _build_menu() makes dynamic list 9000 focusable, perform one
            # initial Home selection/focus sync only.
            # No delayed focus guard, retry loop, or background focus repair.
            self._startup_focus_lock_until_ms = 0
            self._startup_collapse_arm_r87()
            # v600: do not special-case Kodi playback from Home onInit.
            # Playback is owned by Kodi; PKM must not skip/bootstrap differently
            # based on player state because that leaves stale Home/Menu/Info state.
            self._set_home_dynamic_bg_color(self._home_bg_default, reason="init")
            if not self._pkm_initial_setup_completed_v2562():
                self._set_empty_home_settings_state(True, reason="oninit_first_install_incomplete_v2562")
                self.sections = []
                try:
                    self._home_reset_row_controls()
                except Exception:
                    pass
                self._build_menu()
                self._start_home_data_refresh_watcher(reason="empty_home_settings_required")
                # v2561: initial setup has no sidebar. Control 5858 is visible as
                # soon as SettingsRequired is armed, so it owns initial focus.
                try:
                    self.setFocusId(EMPTY_HOME_SETTINGS_BUTTON_ID)
                    _log("PKM_PATCH_ACTIVE v2561 initial_setup_focus_settings_cta_5858")
                    _log("OPEN_EMPTY_HOME_SETTINGS_REQUIRED_V2561 sections=0 focus=settings_cta_5858 sidebar=hidden")
                except Exception:
                    _log("INITIAL_SETUP_CTA_FOCUS_FAILED_V2561 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                _log("OPEN_EMPTY_HOME_SETTINGS_REQUIRED sections=0 start=%s sort=%s focus=settings_cta_5858 sidebar=hidden" % (self.start_index, self.sort))
                self._force_startup_gate_release_v1619(reason="settings_required_surface_ready")
                return
            self._set_empty_home_settings_state(False, reason="oninit_initial_setup_complete_v2562")
            try:
                if xbmcgui.Window(10000).getProperty("PlexKM.Home.ServerSwitchPending") == "1":
                    self._start_home_data_refresh_watcher(reason="server_switch_pending_oninit_v1310")
                    self._apply_server_switch_pending_view_v1310("server_switch_pending_oninit_v1310", "")
                    # v2051: A server-switch pending surface is not a completed
                    # Home scene. Keep the startup logo/gate active while the
                    # authoritative library sync and Home widget composition run.
                    # The normal completed-scene path will advance real progress
                    # to 100 and release the logo only after widgets are ready.
                    _log("STARTUP_SERVER_SWITCH_PENDING_GATE_HOLD_V2051 reason=await_sync_and_home_widgets progress_force100=0")
                    _log("PKM_PATCH_ACTIVE v2052 startup_progress_100_only_after_visual_home_ready_no_timeout_no_force_final")
                    _log("PKM_PATCH_ACTIVE v2066 git_base_tv_info_movie_cast_photo_actor_widgets_isolated")
                    return
            except Exception:
                pass
            # v1975 startup state matrix. This block is read-only: startup
            # must never save or clear library choices merely to reach Home.
            try:
                _c1975 = _ensure_core()
                if hasattr(_c1975, "selected_sections_startup_state_v1975"):
                    _selected1975, _configured1975, _state1975 = _c1975.selected_sections_startup_state_v1975()
                else:
                    _selected1975, _configured1975 = _c1975.selected_sections_state()
                    _state1975 = "ok"
            except Exception:
                _selected1975, _configured1975, _state1975 = ([], False, "read_error")
                _log("STARTUP_SELECTION_STATE_EXCEPTION_V1975 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)

            # v1981: selection authority is explicit user choice only.
            # A populated DB/cache never implies that any library is selected.
            # This startup path is read-only and performs no selection mutation.
            if _state1975 == "ok" and not bool(_configured1975):
                _log("STARTUP_SELECTION_UNCONFIGURED_V1981 selected=0 mutation=0 db_bootstrap=0")

            _log("PKM_PATCH_ACTIVE v1981 explicit_selection_only_no_db_bootstrap")
            _log("PKM_PATCH_ACTIVE v1982 real_startup_barrier_progress_explicit_added_full_sync_visible_progress_home_focus_handoff")

            _empty_reason1975 = ""
            if _state1975 != "ok":
                _empty_reason1975 = "state_%s" % _state1975
            elif not bool(_configured1975):
                _empty_reason1975 = "unconfigured"
            elif not list(_selected1975 or []):
                _empty_reason1975 = "explicit_empty"

            if _empty_reason1975:
                self.sections = []
                try:
                    self._home_reset_row_controls()
                except Exception:
                    pass
                try:
                    self._build_menu()
                    self._show_home_wall()
                    # v1980: an empty Home has no widget row that can take focus.
                    # After dynamic menu 9000 is populated, make its Home item the
                    # one deterministic initial focus owner. This is a one-time
                    # startup handoff, not a timer, retry loop, or focus repair.
                    self._force_home_menu_focus("oninit_after_dynamic_menu_build_empty_v1980", select_home=True)
                    _log("EMPTY_HOME_INITIAL_FOCUS_V1980 control=9000 pos=0 focus=%s reason=%s" % (
                        self._safe_focus_id(), _empty_reason1975
                    ))
                except Exception:
                    _log("EMPTY_HOME_SURFACE_BUILD_FAILED_V1975 reason=%s err=%s" % (
                        _empty_reason1975, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGERROR)
                _log("STARTUP_EMPTY_HOME_V1975 reason=%s configured=%d selected=%d modal_open=0 mutation=0 sections=0 widgets=0 sidebar_libraries=0" % (
                    _empty_reason1975, 1 if _configured1975 else 0, len(_selected1975 or [])
                ))
                self._force_startup_gate_release_v1619(reason="startup_empty_home_ready_v1975_%s" % _empty_reason1975)
                return

            _log("STARTUP_NORMAL_HOME_V1975 configured=1 selected=%d state=ok" % len(_selected1975 or []))
            # v1978 operational fail-open policy. Source/import/syntax defects are
            # build-time failures and are never handled here. Only runtime state
            # failures (missing/corrupt DB, unavailable server, invalid token or
            # interrupted sync state) are converted to a usable PKM Home surface.
            try:
                self._load_sections()
            except Exception:
                _runtime_error1978 = traceback.format_exc().replace(chr(10), " | ")
                self.sections = []
                try:
                    self._home_reset_row_controls()
                except Exception:
                    pass
                try:
                    self._build_menu()
                    self._show_home_wall()
                    self._force_home_menu_focus("oninit_after_dynamic_menu_build_operational_empty_v1980", select_home=True)
                    _log("OPERATIONAL_EMPTY_HOME_INITIAL_FOCUS_V1980 control=9000 pos=0 focus=%s" % self._safe_focus_id())
                except Exception:
                    _log("STARTUP_OPERATIONAL_EMPTY_HOME_BUILD_FAILED_V1978 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
                try:
                    self._start_home_data_refresh_watcher(reason="startup_operational_failure_v1978")
                except Exception:
                    pass
                _log("STARTUP_OPERATIONAL_EMPTY_HOME_V1978 reason=local_data_unavailable mutation=0 modal_open=0 sections=0 widgets=0 sidebar_libraries=0 err=%s" % _runtime_error1978, xbmc.LOGERROR)
                self._force_startup_gate_release_v1619(reason="startup_operational_empty_home_ready_v1978")
                return
            # v1644 snapshot policy: service synchronizes Plex before opening this
            # WindowXML.  During the Kodi run the widget snapshot is immutable;
            # no 120-second poll, dirty rebuild or post-reveal prewarm is started.
            self._onInit_step2()
            if not bool(getattr(self, "_fast_reveal_v2584", False)):
                self._startup_hydrate_actor_caches_v2480(reason="normal_home_oninit_existing_actor_pages")
                self._r71_prepare_progress(85, "배우 데이터 준비")
            else:
                _log("UHD3_STARTUP_ACTOR_CACHE_BYPASS_V2584 disk_io=0 first_actor_open_lazy=1")
            # v1984: settings reset and explicit connection changes can happen
            # while this normal Home WindowXML instance is already open.  The
            # refresh watcher is therefore part of every Home lifetime, not only
            # empty/error startup paths.  It observes state-change tokens only;
            # it never infers or mutates library selection.
            self._start_home_data_refresh_watcher(reason="normal_home_oninit_v1984")
            _log("PKM_PATCH_ACTIVE v1984 live_home_connection_reset_atomic_empty_surface")
            # v604: If Kodi re-enters this WindowXML after native playback, do not
            # run the normal Home/menu bootstrap first.  The saved inline Info
            # snapshot is the current page state; restoring it before Home refresh
            # prevents playback return from falling back to PKM Home or skin Home.
            # This does not control playback.  Kodi still owns PlayMedia/player;
            # PKM only restores its own WindowXML state after Kodi returns.
            # v607: Kodi can call WindowXML.onInit while native fullscreen video is
            # still active.  In that state PKM must not run Home/menu bootstrap,
            # because selecting the sidebar resets menu pos 1->0 and clears the
            # inline episode Info page underneath the player.  Playback remains
            # fully Kodi-native; this only preserves the current skin state that
            # is already under fullscreenvideo until Kodi closes the player.
            try:
                _pending_inline_return = xbmcgui.Window(10000).getProperty("PlexKM.Playback.ReturnInline.Pending") == "1"
            except Exception:
                _pending_inline_return = False
            try:
                _video_active = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
            except Exception:
                _video_active = False
            if _pending_inline_return and _video_active:
                # v1549 defensive fallback: an active video session is never stopped
                # from onInit.  The explicit leaked-Back handler in onAction remains
                # the only WindowXML path allowed to issue the native Stop command.
                try:
                    _win10000 = xbmcgui.Window(10000)
                    _saved_at = _safe_int(_win10000.getProperty("PlexKM.Playback.ReturnInline.SavedAt"), 0)
                    _now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
                    _age_ms = (_now_ms - _saved_at) if _saved_at else 0
                    _log("INLINE_PLAYBACK_RETURN_ONINIT_FALLBACK_PRESERVE_V1549 reason=video_active_no_auto_stop age_ms=%d attempt_seq=%s" % (
                        _age_ms,
                        _win10000.getProperty("PlexKM.Playback.ActiveAttemptSeqV1545") or "",
                    ))
                except Exception:
                    _log("INLINE_PLAYBACK_RETURN_ONINIT_FALLBACK_CHECK_FAILED_V1549 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                _log("OPEN sections=%d start=%s sort=%s focus=%s" % (len(self.sections), self.start_index, self.sort, "native_playback_preserve_inline_no_stop_v1549"))
                return

            restored_inline = False
            try:
                restored_inline = self._restore_inline_info_after_playback_return(reason="oninit_after_native_playback")
            except Exception:
                restored_inline = False
                _log("INLINE_PLAYBACK_RETURN_ONINIT_FAILED %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            if not restored_inline:
                self._home_bootstrap_in_progress_v1632 = True
                try:
                    # v2513: the first call to _info_prepared_cache_apply_v2467()
                    # lazily loads/parses the persistent JSON. The supplied trace
                    # shows 85ms before first open_begin vs 10ms on the next open.
                    # Pay that one-time local-file cost under the startup splash,
                    # never after the user's first Info click. No DB/network call.
                    if not bool(getattr(self, "_fast_reveal_v2584", False)):
                        try:
                            _info_cache_warm_t0_v2513 = self._now_ms()
                            _info_cache_warm_v2513 = self._info_prepared_cache_load_v2467()
                            _log("INFO_PREPARED_CACHE_STARTUP_WARM_V2513 entries=%d elapsed_ms=%d first_click_file_io=0 network=0 db=0" % (
                                len(_info_cache_warm_v2513 or {}),
                                max(0, self._now_ms() - _info_cache_warm_t0_v2513)
                            ))
                        except Exception:
                            _log("INFO_PREPARED_CACHE_STARTUP_WARM_FAILED_V2513 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                    else:
                        _log("UHD3_STARTUP_INFO_CACHE_BYPASS_V2584 disk_io=0 first_info_open_lazy=1")
                    self._force_home_menu_focus("oninit_after_dynamic_menu_build", select_home=True)
                    self._refresh_for_menu_focus(force=True)
                    # v2514 rollback: NEVER make Info group 5599 visible while Home
                    # is the owner. The call only clears stale V2513 prime properties.
                    self._info_first_scene_prime_arm_v2513(reason="fresh_home_bootstrap_rollback_v2514")
                finally:
                    self._home_bootstrap_in_progress_v1632 = False
            _log("OPEN sections=%d start=%s sort=%s focus=%s" % (len(self.sections), self.start_index, self.sort, "inline_info_return" if restored_inline else "dynamic_menu_home"))
        except Exception:
            _log("INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _onInit_step1(self):
        """Step 1 of onInit (R76 split, moved verbatim). Logs: STARTUP_LOGO_IMAGE_CONTROL_SKIP_R33, PKM_PATCH_ACTIVE, LIBRARY_WALL_POLICY_V2593."""
        _log("STARTUP_LOGO_IMAGE_CONTROL_SKIP_R33 id=19001 reason=control_removed_from_xml cover=16926")
        try:
            pkm_global_busy.cancel_all(reason="home_oninit_v1883")
        except Exception:
            pass
        try:
            _log("PKM_PATCH_ACTIVE v1931 android_single_wall_atomic_server_small_cast_raw_focus_notice_guard")
            _log("PKM_PATCH_ACTIVE v1932 library_wall_initial_18_ahead_buffer_cast_circle_diffuse")
            _log("PKM_PATCH_ACTIVE v1934 control9000_bootstrap_focus_and_library_wall_18_all_paths")
            _log("PKM_PATCH_ACTIVE v1937 plezy_nonseek_shared_artwork_scheduler_request_coalescing_row_ahead")
            _log("PKM_PATCH_ACTIVE v1938 playback_return_resume_no_spinner_exit_focus_cast_inset")
            _log("PKM_PATCH_ACTIVE v1939 cast_true_circle_scaled_diffuse_and_playback_return_info_cover_handshake")
            _log("PKM_PATCH_ACTIVE v1940 playback_video_surface_immediate_opening_spinner_clear")
            _log("PKM_PATCH_ACTIVE v1941 playback_opening_spinner_delayed_only_when_needed_450ms")
            _log("PKM_PATCH_ACTIVE v1942 sidebar_stale_index_background_refresh_visual_path_unchanged")
            _log("PKM_PATCH_ACTIVE v1943 videoosd_enter_no_pause_idle3s_smooth_close_and_quit_fade")
            _log("PKM_PATCH_ACTIVE v1944 native_osd_enter_play_focus_one_shot_idle_close_fast_info_return_quit_black_hold")
            _log("PKM_PATCH_ACTIVE v1945 native_osd_open_select_leak_guard_child_dialog_overlay_hold")
            _log("PKM_PATCH_ACTIVE v1946 videoosd_native_second_enter_playpause_no_python_cold_load_diagnosis")
            _log("PKM_PATCH_ACTIVE v1947 videoosd_native_second_enter_single_autoclose_owner_cold_preload_child_overlay")
            _log("PKM_PATCH_ACTIVE v2095 playback_return_primary_play_focus_after_back")
            _log("PKM_PATCH_ACTIVE v2096 resolution_first_compact_focus_pill_primary_play_default")
            _log("PKM_PATCH_ACTIVE v2097 action_pill_equal_icon_label_gap_trim_width")
            _log("PKM_PATCH_ACTIVE v2098 tv_episode_actionbar_movie_parity_restart_watched_pills")
            _log("PKM_PATCH_ACTIVE v2099 tv_episode_versions_same_show_same_episode_selected_libraries_no_refresh")
            _log("PKM_PATCH_ACTIVE v2428 tv_info_first_paint_defer_whole_rail_versions_no_fast_fallback_spinner_promote")
            _log("PKM_PATCH_ACTIVE v2429 info_actor_works_previsible_complete_no_postvisible_popin")
            _log("PKM_PATCH_ACTIVE v2431 info_actor_works_local_index_previsible_no_plex_reprobe")
            _log("PKM_PATCH_ACTIVE v2432 actor_works_exact_index_lookup_no_identity_expansion_spinner_plate_lighter")
            _log("PKM_PATCH_ACTIVE v2433 movie_actor_works_three_rows_render_parity")
            _log("PKM_PATCH_ACTIVE v2437 info_ui_consistency_search_info_sidebar_route_restore")
            _log("PKM_PATCH_ACTIVE v2445 info_entry_atomic_prepared_surface_swap_no_visible_fade")
            _log("PKM_PATCH_ACTIVE v2101 movie_media_version_square_singleline_no_check_right_popup_exact_part")
            _log("PKM_PATCH_ACTIVE v2104 media_version_inline_no_modal_no_saturation_codec_group_pkm_square_select")
            _log("PKM_PATCH_ACTIVE v2105 media_version_hq_exact_aspect_focus_pill")
            _log("PKM_PATCH_ACTIVE v2106 movie_media_version_post_info_prewarm_first_click_cache")
            _log("PKM_PATCH_ACTIVE v2107 media_version_popup_icon_anchor_right_down_cast_overlay")
            _log("PKM_PATCH_ACTIVE v2108 media_version_popup_above_cast_no_connector_line")
            _log("PKM_PATCH_ACTIVE v2109 media_version_native_63px_pill_no_scale")
            _log("PKM_PATCH_ACTIVE v2112 tv_media_version_isolated_popup_safe_skin")
            _log("PKM_PATCH_ACTIVE v2113 tv_action_geometry_movie_parity_alt_season_media_versions")
            _log("PKM_PATCH_ACTIVE v2114 media_identity_plex_guid_full_codec_hdr_audio_stream_canonical_home")
            _log("PKM_PATCH_ACTIVE v2115 tv_current_episode_owner_and_plex_season_metadata_identity")
            _log("PKM_PATCH_ACTIVE v2303 tv_info_logical_seasons_only_hide_media_version_folders")
            _log("PKM_PATCH_ACTIVE v2304 tv_info_collapse_hidden_season_slot_actor_work_up")
            _log("PKM_PATCH_ACTIVE v2305 tv_info_hidden_season_actor_row_focus_title_anchor")
            _log("PKM_PATCH_ACTIVE v2306 tv_info_no_season_unified_cast_actorwork_scroll_stack")
            _log("PKM_PATCH_ACTIVE v2309 history_back_safe_rebuild_hold_child_surface_no_spinner_no_cover")
            _log("PKM_PATCH_ACTIVE v2310 history_back_exact_position_sidebar_tint_static_prime_no_native_reuse")
            _log("PKM_PATCH_ACTIVE v2311 history_back_sidebar_tint_no_inlineactive_gap_exact_parent_pin")
            _log("PKM_PATCH_ACTIVE v2312 history_back_sidebar_tint_commit_order_exact_target_color_atomic_ready")
            _log("PKM_PATCH_ACTIVE v2313 home_info_hero_title_meta_exact_geometry_no_return_nudge")
            _log("PKM_PATCH_ACTIVE v2314 home_library_bg_focus_dwell_slow_latest_only_transition")
            _log("PKM_PATCH_ACTIVE v2315 home_bg_platform_shared_atomic_transition_cancel_guard")
            _log("PKM_PATCH_ACTIVE v2325 tv_media_version_thumb_follows_selected_target_all_shows")
            _log("PKM_PATCH_ACTIVE v2330 resume_progress_single_composite_no_fill_all_pkm_surfaces")
            _log("PKM_PATCH_ACTIVE v2332 pkm_full_page_ready_before_visible_no_blank_no_postvisible_mutation")
            _log("PKM_PATCH_ACTIVE v2333 info_actor_works_language_independent_identity_tag_thumb_alias")
            _log("PKM_PATCH_ACTIVE v2334 movie_actor_works_three_rows_tv_parity")
            _log("PKM_PATCH_ACTIVE v2397 actor_works_canonical_family_dedup")
            _log("PKM_PATCH_ACTIVE v2398 movie_more_cue_explicit_actor_work_state")
            _log("PKM_PATCH_ACTIVE v2399 tv_episode_sort_toggle_no_dim_overlay_nav_safe")
            _log("PKM_PATCH_ACTIVE v2400 episode_sort_focusable_tv_labels_card_edge")
            _log("PKM_PATCH_ACTIVE v2401 tv_info_spacing_sort_visible_thumb_prefetch")
            _log("PKM_PATCH_ACTIVE v2706 sidebar_same_bank_fullfill_no_second_ab_swap_tv_show_thumb_revision_authority")
            _log("PKM_PATCH_ACTIVE v2707 sidebar_chunk_fill_startup_indexed_authority_short_crossfade")
            _log("PKM_PATCH_ACTIVE v2404 tv_episode_three_full_one_third_native_progress_sidebar_stale_info_retire")
            _log("PKM_PATCH_ACTIVE v2405 tv_episode_100pct_native_edge_sidebar_left_retire_startup3s_verified")
            _log("PKM_PATCH_ACTIVE v2406 tv_action_below_episode_initial_next_focus_three_plus_peek_100pct")
            _log("PKM_PATCH_ACTIVE v2407 tv_info_five_across_entry_episode_sidebar_hold_fast_startup")
            _log("PKM_PATCH_ACTIVE v2408 info_sidebar_geometry_single_owner_no_stale_329_gap")
            _log("PKM_PATCH_ACTIVE v2409 control_focus_zero_invalid_target_missing6230_visible_episode_only")
            _log("PKM_PATCH_ACTIVE v2336 tv_info_button_row_director_clear_credit_settings_icon_parity")
            _log("PKM_PATCH_ACTIVE v2342 actor_work_authoritative_metadata_stale_404_no_poster_fail_closed")
            _log("PKM_PATCH_ACTIVE v2351 info_reentry_actor_rows_tv_rows_version_cache_short_probe")
            _log("PKM_PATCH_ACTIVE v2355 tv_episode_thumb_raw_plex_priority_cache_image_validation_fallback_chain")
            _log("PKM_PATCH_ACTIVE v2356 tv_episode_thumb_full_decode_cache_format")
            _log("PKM_PATCH_ACTIVE v2352 startup_metadata_false_dirty_guard")
            _log("PKM_PATCH_ACTIVE v2357 native_kodi_horizontal_rails_restore_no_physical_clip_override")
            _log("PKM_PATCH_ACTIVE v2358 atomic_info_persistent_actor_rows_startup_fast_proof_reuse")
            _log("PKM_PATCH_ACTIVE v2359 actor_work_native_offscreen_runway_home_parity")
            _log("PKM_PATCH_ACTIVE v2360 actor_rail_parent_100pct_native_kodi_no_fixed_runway")
            _log("PKM_PATCH_ACTIVE v2361 all_home_info_widget_rails_parent_100pct_native_kodi")
            _log("PKM_PATCH_ACTIVE v2363 geometry_lock_hq_round_mask_only_no_spacing_nav_change")
            _log("PKM_PATCH_ACTIVE v2364 info_recommend_poster_2x3_geometry_safe")
            _log("PKM_PATCH_ACTIVE v2365 startup_slow_notice_5s_reason_text_no_ellipsis")
            _log("PKM_PATCH_ACTIVE v2384 restore_pre_v2382_row_anchor_exact_focus_owner")
            _log("PKM_PATCH_ACTIVE v2385 native_grouplist_vertical_owner_home_focus_lightweight_no_cast")
            _log("PKM_PATCH_ACTIVE v2386 home_focus_cache_only_idle_background_no_runtime_nav_io")
            _log("PKM_PATCH_ACTIVE v2383 info_firstpaint_defer_actor_rows_remove_widget_dim")
            _log("PKM_PATCH_ACTIVE v2387 info_sidebar_focus_hold_until_native_menu_change_target_first")
            _log("PKM_PATCH_ACTIVE v2367 startup_parallel_combined_authority_probe_zero_final_logo_hold")
            _log("PKM_PATCH_ACTIVE v2378R8 startup_logo_complete_before_home_state_handshake_no_rewind")
            _log("PKM_PATCH_ACTIVE v2368 startup_bulk_local_authority_parallel_membership_pages")
            _log("PKM_PATCH_ACTIVE v2343 info_entry_visible_focus_owner_movie_tv_actor_chain")
            _log("PKM_PATCH_ACTIVE v2344 superseded_by_v2407_tv_episode_entry_owner")
            _log("PKM_PATCH_ACTIVE v2347 plex_authoritative_named_season_editions_previsible_no_numeric_inference")
            _log("PKM_PATCH_ACTIVE v2346 tv_season_folder_same_season_instant_focus_slow_switch_busy_atomic_no_blank")
            _log("PKM_PATCH_ACTIVE v2327 tv_episode_replay_resume_progress_uniform_thumbs_summary_box_width3line")
            _log("PKM_PATCH_ACTIVE v2077 library_wall_native_runway66_reserve48_publish24_no_down_wrap")
            _log("LIBRARY_WALL_POLICY_V2593 initial=%d visible=%d ahead=%d append=%d prefetch=%d platform_android=%d artwork_limit=%d" % (
                self._library_wall_initial_bound_count_v2077(), self._library_wall_viewport_count_v1865(),
                max(0, self._library_wall_initial_bound_count_v2077() - self._library_wall_viewport_count_v1865()),
                self._library_wall_append_count_v1932(), self._library_wall_prefetch_count_v2077(),
                1 if self._is_android_v2591() else 0, int(pkm_artwork_scheduler.MAX_ACTIVE_DOWNLOADS)
            ))
        except Exception:
            pass

    def _onInit_step2(self):
        """Step 2 of onInit (R76 split, moved verbatim). Logs: RUNTIME_WIDGET_UPDATE_DISABLED_V1644, R68_PREP_UI_KEEP, INITIAL_PREPARATION_LAYER_STATE_FAILED, R133_STARTUP_FASTPATH_POLICY."""
        _log("RUNTIME_WIDGET_UPDATE_DISABLED_V1644 reason=oninit next_refresh=kodi_restart")
        self._build_menu()
        try:
            _first_prepare = False  # R115: obsolete preparation overlay permanently disabled
            _home_window = xbmcgui.Window(10000)
            if _first_prepare:
                _home_window.setProperty("PlexKM.Startup.InitialPrepareActiveCumulative", "1")
                _log("R68_PREP_UI_KEEP stage=after_menu_build active=1")
                _home_window.setProperty("PlexKM.Startup.InitialPrepareMessageCumulative",
                                         "시작 화면을 준비 중입니다")
            else:
                _home_window.clearProperty("PlexKM.Startup.InitialPrepareActiveCumulative")
        except Exception:
            _log("INITIAL_PREPARATION_LAYER_STATE_FAILED err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
        # V2584: only the visible Home owns the splash.  Persistent sidebar
        # Recommendation/Library snapshots are useful for first-focus latency,
        # but hydrating ~1k rows and materializing hundreds of native ListItems
        # before Home costs far more on UHD3 than a later on-demand fill.
        try:
            # V2657: the durable snapshot marker is an optimization artifact,
            # not a prerequisite for showing Home.  Fresh library imports often
            # have a committed DB before this marker exists; requiring both made
            # first restart hydrate/prebuild every off-screen destination.
            fast_reveal_v2584 = (
                xbmcgui.Window(10000).getProperty("PlexKM.Startup.FastLocalFirstV2582") == "1"
            )
        except Exception:
            fast_reveal_v2584 = False
        # R133: R70 forced full off-screen preparation on every unchanged
        # restart, overriding the existing V2584 local-first path. Restore
        # that path only when the persistent initial preparation is verified.
        # Fresh setup, changed content and cache repair remain on the normal
        # fail-closed preparation policy below.
        _r133_initial_verified = bool(self._startup_initial_prepare_verified_cumulative())
        self._r70_full_prepare_required = not (fast_reveal_v2584 and _r133_initial_verified)
        fast_reveal_v2584 = bool(fast_reveal_v2584 and _r133_initial_verified)
        _log("R133_STARTUP_FASTPATH_POLICY local_first=%d initial_verified=%d full_prepare=%d" % (
            1 if fast_reveal_v2584 else 0, 1 if _r133_initial_verified else 0,
            1 if self._r70_full_prepare_required else 0))
        # R6: first library setup must hydrate destination caches before Home.
        # Reuse the existing startup preparation path; never touch Kodi GUI
        # controls from a new background worker.
        try:
            first_snapshot_r6 = (
                self._pkm_initial_setup_completed_v2562()
                and not self._startup_snapshot_bootstrap_marker_load_v2490()
                and not self._startup_prepare_state_load_v2477()
            )
        except Exception:
            first_snapshot_r6 = False
        if first_snapshot_r6:
            fast_reveal_v2584 = False
            _log("FIRST_SETUP_PREPARE_R6 hydrate_sections=1 hydrate_library=1 native_prebuild=1 actor_cache=1 before_home=1")
        # Restrict the local/instance fast-reveal values together.
        # First launch after the full sync must prove its initial snapshot.
        fast_reveal_v2584 = bool(
            fast_reveal_v2584 and self._startup_initial_prepare_verified_cumulative()
        )
        self._fast_reveal_v2584 = fast_reveal_v2584
        if fast_reveal_v2584:
            _log("UHD3_STARTUP_OFFSCREEN_HYDRATE_BYPASS_V2584 section_hydrate=0 library_hydrate=0 native_prebuild=0 actor_cache=0 info_cache=0 current_home_only=1 target_uhd_ms=5000")
        else:
            # v2492: delayed startup text receives a truthful phase before any
            # potentially-heavy hydrate. The 3-second guard still owns visibility.
            self._startup_publish_early_status_hint_v2492()
            self._startup_hydrate_persistent_sections_v2469(reason="normal_home_oninit_all_tab_data_v2492")
            self._r71_prepare_progress(15, "위젯 데이터 준비")
            self._startup_force_slow_notice_if_due_v2494()
            self._startup_hydrate_persistent_library_tabs_v2470(reason="normal_home_oninit_all_tab_data_v2492")
            self._r71_prepare_progress(30, "라이브러리 준비")
            self._startup_force_slow_notice_if_due_v2494()
            self._startup_prebuild_all_native_v2492(reason="normal_home_oninit_all_destinations")
            self._r71_prepare_progress(50, "전체 위젯 구성")
            self._startup_force_slow_notice_if_due_v2494()
        self._startup_established_current_home_only_v2535 = False
        self._arm_startup_prepare_policy_v2477(reason="normal_home_oninit_before_home_release")
        self._startup_acceptance_watchdog_v2494r3()
        self._startup_force_slow_notice_if_due_v2494(
            str(getattr(self, "_startup_prepare_display_text_v2482", "") or ""),
            "prepare_" + str(getattr(self, "_startup_prepare_cause_v2487", "") or "startup")
        )
        if not bool(getattr(self, "_startup_prepare_required_v2477", False)):
            if bool(getattr(self, "_startup_established_current_home_only_v2535", False)):
                # V2535: do not make every off-screen Recommendation/Library
                # poster a startup dependency. Kodi is already rendering the
                # current Home behind the opaque splash; the existing atomic
                # release worker verifies the first two visible Home rows.
                self._startup_local_home_publishable_v2493 = bool(getattr(self, "sections", None))
                # R98: R97 skipped this entire producer on established sessions.
                # Run the existing bounded all-destination local poster resolver.
                _log("R98_TEXTURE_PRODUCER_BEGIN mode=established sections=%d" % len(self.sections or []))
                # R99: avoid repeating an already successful producer within
                # this Home instance. Never skip when no valid handoff exists.
                _r99_paths = tuple(getattr(self, "_r97_startup_texture_paths", ()) or ())
                _r99_stats = getattr(self, "_startup_texture_prewarm_stats_v2492", {}) or {}
                _r99_reuse = bool(getattr(self, "_startup_texture_prewarm_done_v2492", False)
                                  and _r99_paths and int(_r99_stats.get("checked") or 0) > 0)
                if _r99_reuse:
                    _r98_ok = True
                    _log("R99_TEXTURE_PRODUCER_REUSED paths=%d checked=%d" % (
                        len(_r99_paths), int(_r99_stats.get("checked") or 0)))
                else:
                    _r98_ok = self._startup_prewarm_all_destination_textures_v2492(reason="r98_established_all_selected")
                _log("R98_TEXTURE_PRODUCER_END ready=%d paths=%d" % (
                    1 if _r98_ok else 0, len(getattr(self, "_r97_startup_texture_paths", ()) or ())))
            else:
                _texture_ready_v2493 = self._startup_prewarm_all_destination_textures_v2492(reason="normal_home_oninit_all_destinations")
                self._startup_local_home_publishable_v2493 = bool(_texture_ready_v2493 and getattr(self, "sections", None))
                _log("STARTUP_LOCAL_HOME_PUBLISHABLE_V2493 ready=%d sections=%d offline_advisory_only=1" % (
                    1 if self._startup_local_home_publishable_v2493 else 0, len(self.sections or [])
                ))

    def _apply_server_switch_pending_view_v1310(self, reason="", token=""):
        """Hide stale widgets while a changed Plex server is being validated/synced."""
        try:
            win = xbmcgui.Window(10000)
            # Keep pending properties mirrored on the WindowXML instance because the
            # XML uses both Window.Property and Window(10000).Property in places.
            line1 = win.getProperty("PlexKM.Home.ServerSwitchPendingLine1") or "새 Plex 서버 연결 확인 중"
            line2 = win.getProperty("PlexKM.Home.ServerSwitchPendingLine2") or "기존 서버 위젯을 숨기고 있습니다"
            for key, value in (
                ("PlexKM.Home.ServerSwitchPending", "1"),
                ("PlexKM.Home.ServerSwitchPendingLine1", line1),
                ("PlexKM.Home.ServerSwitchPendingLine2", line2),
            ):
                try:
                    self.setProperty(key, value)
                except Exception:
                    pass
                try:
                    win.setProperty(key, value)
                except Exception:
                    pass

            try:
                self._section_placeholder_clear_v1305(reason="server_switch_pending_v1310")
            except Exception:
                pass
            try:
                self._home_reset_row_controls()
            except Exception:
                pass
            try:
                self._section_reset_recommend_row_controls()
            except Exception:
                pass
            try:
                self._section_clear_prev_recommend_row_controls(clear_visible=True)
            except Exception:
                pass
            try:
                self.getControl(WALL_ID).reset()
            except Exception:
                pass
            try:
                self._home_rows_cache = None
                self._home_wall_ready = False
                self._section_rows_cache.clear()
                self._section_total_cache.clear()
                self._library_first12_scene_cache_v1868.clear()
                self._home_cine21_cache.clear()
            except Exception:
                pass
            try:
                self.sections = []
                self.active_section_id = "__server_switch_pending__"
                self._build_menu()
            except Exception:
                pass
            try:
                for prop in (
                    "PlexKM.Window.HomeLayout",
                    "PlexKM.Window.IsSectionRecommend",
                    "PlexKM.Window.IsSectionWall",
                    "PlexKM.Window.IsHome",
                    "PlexKM.Window.Title",
                    "PlexKM.Window.CountLabel",
                ):
                    try:
                        self.clearProperty(prop)
                    except Exception:
                        pass
                    try:
                        win.clearProperty(prop)
                    except Exception:
                        pass
            except Exception:
                pass
            # v1314: when Plex connection validation fails or is pending, the
            # visible background must not keep stale fanart from the previous
            # server/item.  Keep only the neutral PKM dark background and the
            # top-right notice.
            try:
                self._set_home_fanart_smooth("", reason="server_switch_pending_clear_fanart_v1314")
            except Exception:
                pass
            try:
                for prop in ("PlexKM.Home.Fanart", "PlexKM.Home.DisplayFanart", "PlexKM.Home.DisplayFanartRaw"):
                    try:
                        self.clearProperty(prop)
                    except Exception:
                        pass
                    try:
                        win.clearProperty(prop)
                    except Exception:
                        pass
                self._home_fanart_current = ""
                self._home_bg_current_fanart = ""
                self._home_bg_target_fanart_v2314 = ""
                self._home_bg_target_since_ms_v2314 = 0
                _log("HOME_SERVER_SWITCH_FANART_CLEAR_V1314 reason=%s" % (reason or ""))
            except Exception:
                pass
            try:
                self._set_home_dynamic_bg_color(self._home_bg_default, reason="server_switch_pending_v1314")
            except Exception:
                pass
            try:
                win.setProperty("PlexKM.Home.DataRefreshAppliedToken", str(token or ""))
                win.setProperty("PlexKM.Home.DataRefreshAppliedReason", str(reason or ""))
                win.setProperty("PlexKM.Home.DataRefreshAppliedAt", str(int(time.time() * 1000)))
            except Exception:
                pass
            try:
                self._force_connection_settings_focus_v1381("server_switch_pending_apply")
                self._schedule_connection_settings_focus_guard_v1381("server_switch_pending_apply")
            except Exception:
                pass
            _log("HOME_SERVER_SWITCH_PENDING_APPLY_V1310 reason=%s token=%s line1=%s" % (reason or "", token or "", line1))
            return True
        except Exception:
            _log("HOME_SERVER_SWITCH_PENDING_APPLY_FAILED_V1310 reason=%s token=%s err=%s" % (reason or "", token or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    # R26: Kodi delivers WindowXML callbacks to Python one at a time.  While
    # one handler blocks (opening Info, a sync wait, a modal), every key the
    # user presses is queued and then replayed back-to-back once the handler
    # returns.  Such replayed callbacks start almost immediately after a long
    # handler ends.  Directional moves are always passed through (Kodi XML
    # already moved focus natively, Python must stay in sync).
    #
    # R29: R26 dropped *every* replayed commit key, so a press made during a
    # freeze was lost and the user had to press again ("한 번에 진입 안 됨"),
    # and it also dropped PKM's own SendClick(100) GUI-commit pings.  Now:
    # - control 100 (internal commit ping) is never judged or dropped;
    # - the first replayed click on a *different* control than the one whose
    #   handler blocked runs: it was captured by Kodi at press time, so it is
    #   the user's new intent (e.g. a wall item pressed while the sidebar
    #   switch froze).  Repeats on the same control, Back and action-only
    #   commits queued behind a long handler are still dropped;
    # - one physical Select reaches Python as onClick then onAction(select)
    #   (order seen in SHIELD logs); the onAction follows the onClick decision.
    # R77: season-title suffixes that mean "same season, other media version".
    # R78: Info action-row controls Kodi may land on by itself while the TV
    # episode rail is still binding (never a user choice without a key press).
    _R78_TV_ENTRY_AUTO_FOCUS_IDS = (5721, 5722, 5724, 5725, 5726, 5727, 5728, 5729, 5730)
    _R77_MEDIA_SEASON_TOKENS = frozenset((
        "4k", "uhd", "2160p", "1080p", "720p", "hdr", "hdr10", "hdr10+", "dv", "dovi",
        "dolby", "vision", "mvc", "3d", "sbs", "hsbs", "ou", "hou", "remux", "hevc",
        "h265", "x265", "h264", "x264", "avc", "atmos", "sdr", "fhd", "hd",
    ))
    _R26_LONG_HANDLER_S = 0.35
    _R26_REPLAY_GAP_S = 0.10
    _R26_PAIR_GAP_S = 0.06
    _R26_COMMIT_ACTIONS = (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_PREVIOUS_MENU,
                           ACTION_NAV_BACK, ACTION_CONTEXT_MENU, ACTION_SHOW_INFO, 92, 216, 117, 11)

    def _r26_opening_active(self):
        try:
            w = xbmcgui.Window(10000)
            return (w.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                    or w.getProperty("PlexKM.Playback.OpeningActive") == "1"
                    or w.getProperty("PlexKM.Playback.FailureHomeRequestV2224") == "1")
        except Exception:
            return False

    def _r26_run(self, kind, detail, commit, impl, arg, select_press=False):
        # R36: Kodi delivers queued WindowXML callbacks re-entrantly while a
        # handler sits in xbmc.sleep()/waitForAbort.  The SAME OK press's paired
        # onAction(SELECT) therefore ran *inside* a long onClick (actor-work
        # 6500: click 1640-2774 ms, nested SELECT 459-1293 ms) and opened the
        # same Info twice (써치, 무빙).  R29 pairing only records the press after
        # the click returns, so it never saw this.  While a click handler is
        # running, drop a nested SELECT action and a nested click on the same
        # control.  Pings (control 100) never reach this wrapper.
        running_r36 = getattr(self, "_r26_running_click_r36", None)
        if running_r36 is not None and (
                (kind == "action" and select_press)
                or (kind == "click" and str(detail) == str(running_r36))):
            _log("INPUT_NESTED_DROP_R36 kind=%s detail=%s running_click=%s" % (kind, detail, running_r36))
            return None
        now = time.monotonic()
        # Partner callback of a Select press already decided.
        if select_press and kind == "action":
            press = getattr(self, "_r29_press", None)
            self._r29_press = None
            if isinstance(press, dict) and 0.0 <= (now - float(press.get("end") or 0.0)) <= self._R26_PAIR_GAP_S:
                if press.get("decision") == "dropped":
                    self._r26_last_end = time.monotonic()
                    _log("INPUT_REPLAY_DROP_R26 kind=%s detail=%s reason=paired_select_dropped" % (kind, detail))
                    return None
                commit = False  # same press as the one that just ran
        replayed, gap = self._r26_is_replayed(now)
        if replayed and commit and not self._r26_opening_active():
            keep_r29 = (kind == "click"
                        and not getattr(self, "_r29_burst_commit_used", False)
                        and str(detail) != str(getattr(self, "_r29_long_ctrl", "")))
            if keep_r29:
                self._r29_burst_commit_used = True
                _log("INPUT_REPLAY_KEEP_FIRST_R29 kind=%s detail=%s blocked_ctrl=%s gap_ms=%d prev_handler_ms=%d" % (
                    kind, detail, getattr(self, "_r29_long_ctrl", ""), int(gap * 1000),
                    int(float(getattr(self, "_r26_last_dur", 0.0) or 0.0) * 1000)))
            else:
                self._r26_chain = True
                self._r26_last_end = time.monotonic()
                self._r26_dropped = int(getattr(self, "_r26_dropped", 0) or 0) + 1
                _log("INPUT_REPLAY_DROP_R26 kind=%s detail=%s gap_ms=%d prev_handler_ms=%d dropped_total=%d" % (
                    kind, detail, int(gap * 1000), int(float(getattr(self, "_r26_last_dur", 0.0) or 0.0) * 1000),
                    self._r26_dropped))
                if select_press and kind == "click":
                    self._r29_press = {"end": self._r26_last_end, "decision": "dropped"}
                return None
        elif not replayed:
            self._r29_burst_commit_used = False
        # A replayed directional key keeps the chain alive so a commit key
        # queued behind it is still recognised as stale.
        self._r26_chain = bool(replayed)
        if kind == "click":
            ctrl_r29 = detail
        else:
            try:
                ctrl_r29 = self._safe_focus_id()
            except Exception:
                ctrl_r29 = ""
        started = time.monotonic()
        outer_click_r36 = kind == "click" and getattr(self, "_r26_running_click_r36", None) is None
        if outer_click_r36:
            self._r26_running_click_r36 = detail
        _wd_v2800 = self._stack_watchdog_arm_v2800(kind, detail)
        try:
            return impl(arg)
        finally:
            try:
                if _wd_v2800 is not None:
                    _wd_v2800["done"] = True
                    _wd_v2800["timer"].cancel()
            except Exception:
                pass
            if outer_click_r36:
                self._r26_running_click_r36 = None
            ended = time.monotonic()
            dur = ended - started
            if dur >= self._R26_LONG_HANDLER_S:
                self._r26_last_dur = dur
                self._r26_chain = False
                # A long handler opens a new burst.
                self._r29_burst_commit_used = False
                self._r29_long_ctrl = ctrl_r29
                try:
                    _log("INPUT_LONG_HANDLER_R26 kind=%s detail=%s elapsed_ms=%d" % (kind, detail, int(dur * 1000)))
                except Exception:
                    pass
            elif not self._r26_chain:
                self._r26_last_dur = dur
            self._r26_last_end = ended
            if select_press and kind == "click":
                self._r29_press = {"end": ended, "decision": "ran"}

    def _stack_watchdog_arm_v2800(self, kind, detail):
        """V2800 (F): dump the GUI thread's Python stack while a handler is slow.

        A timer fires at 0.7s / 2.1s / 5.1s into a handler that has not returned
        and logs HANDLER_STACK_V2800 with the innermost frames of the GUI thread,
        so the next Shield log shows exactly which call is stuck (including the
        multi-second whole-process stalls).  Disable: window property
        PlexKM.Diag.StackOff=1.  Cost: one cancelled timer per handler.
        """
        try:
            if xbmcgui.Window(10000).getProperty("PlexKM.Diag.StackOff") == "1":
                return None
        except Exception:
            pass
        try:
            gui_ident = threading.get_ident()
            t0 = time.monotonic()
            state = {"done": False, "n": 0, "timer": None}
            delays = (0.7, 1.4, 3.0)

            def _fire():
                try:
                    if state["done"]:
                        return
                    frame = sys._current_frames().get(gui_ident)
                    if frame is not None:
                        parts = []
                        for fs in traceback.extract_stack(frame)[-12:]:
                            parts.append("%s:%d:%s" % (os.path.basename(fs.filename), fs.lineno, fs.name))
                        _log("HANDLER_STACK_V2800 kind=%s detail=%s running_ms=%d stack=%s" % (
                            kind, detail, int((time.monotonic() - t0) * 1000), " > ".join(parts)))
                    state["n"] += 1
                    if state["n"] < len(delays) and not state["done"]:
                        nt = threading.Timer(delays[state["n"]], _fire)
                        nt.daemon = True
                        state["timer"] = nt
                        nt.start()
                except Exception:
                    pass

            tm = threading.Timer(delays[0], _fire)
            tm.daemon = True
            state["timer"] = tm
            tm.start()
            return state
        except Exception:
            return None

    def onAction(self, action):
        try:
            aid = int(action.getId())
        except Exception:
            aid = -1
        # R101: Shield emits ACTION_SCROLL_UP/DOWN (111/112) about once a second
        # with no key pressed.  Each one ran the full Python action path
        # (400-500 ms there), so a real OK arriving right after was judged a
        # replay and dropped (sidebar Home click ignored) and the GUI callback
        # queue stayed busy.  Kodi already applies the action natively; PKM has
        # no handler for these ids, so return before any Python work.
        if aid in (111, 112):
            return None
        # R82: sidebar profile row (virtual focus above search).
        try:
            if self._profile_virtual_nav_r82(aid):
                return None
        except Exception:
            pass
        select_r29 = aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK)
        # R78: count real user keys. The internal SendClick(100) commit ping
        # arrives as SELECT on control 100 and is not a user key.
        try:
            if not (select_r29 and int(self.getFocusId()) == int(SIDEBAR_COMMIT_PING_ID_V2595)):
                self._pkm_user_key_seq_r78 = int(getattr(self, "_pkm_user_key_seq_r78", 0) or 0) + 1
        except Exception:
            pass
        return self._r26_run("action", aid, aid in self._R26_COMMIT_ACTIONS, self._on_action_impl_r26, action,
                             select_press=select_r29)

    def onClick(self, control_id):
        try:
            if int(control_id) == int(SIDEBAR_COMMIT_PING_ID_V2595):
                # Internal GUI-thread commit ping (SendClick from workers).
                return self._on_click_impl_r26(control_id)
        except Exception:
            pass
        return self._r26_run("click", control_id, True, self._on_click_impl_r26, control_id, select_press=True)

    def onFocus(self, control_id):
        return self._r26_run("focus", control_id, False, self._on_focus_impl_r26, control_id)

    def _stack_geom_for_log(self, scope):
        try:
            l = self._row_anchor_layout_for_scope(scope)
            return (
                "id=%s type=inner_group viewport_id=%s outer_id=%s "
                "outer=(%s,%s) viewport=(%s,%s,%s,%s) row_height=%s panel_top=%s panel_height=%s"
            ) % (
                l.get("stack_id"), l.get("viewport_id"), l.get("outer_id"),
                l.get("outer_left"), l.get("outer_top"),
                l.get("viewport_left"), l.get("viewport_top"), l.get("viewport_width"), l.get("viewport_height"),
                l.get("row_height"), l.get("panel_top"), l.get("panel_height")
            )
        except Exception as exc:
            return "stack_geom_error=%s" % exc

    def close(self):
        global _STARTUP_PROGRESS_CONTROL_V1894, _STARTUP_PROGRESS_IMAGE_CONTROL_V1904, _STARTUP_PROGRESS_FRAME_INDEX_V1904
        _close_started_v2534 = _pkm_speed_ms()
        _log("HOME_CLOSE_BEGIN_V2534 worker_wait_ms=0 action=cancel_tokens_then_native_close")
        # U3: no sort index / artwork work may outlive the Home window.
        try:
            pkm_sort_index_v2626.shutdown_u3()
            pkm_artwork_scheduler.shutdown_u3()
        except Exception:
            pass
        _STARTUP_PROGRESS_CONTROL_V1894 = None
        _STARTUP_PROGRESS_IMAGE_CONTROL_V1904 = None
        _STARTUP_PROGRESS_FRAME_INDEX_V1904 = -1
        # v1841: invalidate workers before saving state or touching Kodi window
        # properties. Network calls may finish later, but their generation is no
        # longer allowed to publish results into native controls/ListItems.
        try:
            self._closing_event_v1841.set()
            self._lifecycle_generation_v1841 = int(self._lifecycle_generation_v1841) + 1
            self._startup_scene_composed_event_v1841.set()
            self._startup_ready_event_v1841.set()
            self._home_watcha_preload_event_v1642.set()
            self._plex_update_watch_stop = True
            self._home_progressive_generation_v1642 += 1
            self._home_meta_nav_generation_v1837 += 1
            self._home_fanart_token += 1
            self._home_bg_token += 1
            self._home_bg_cancel_apply_v2315()
            self._info_prewarm_token += 1
            self._library_wall_gate_token_v1863 = ""
            self._library_wall_gate_sid_v1863 = ""
            self._library_wall_gate_visible_token_v1863 = ""
        except Exception:
            pass
        try:
            # v2482: cancel delayed scene gates that have not reached the broker
            # yet; cancel_all() can only see tokens already begun/promoted.
            with self._scene_busy_lock_v2482:
                for _rec_v2482 in list(self._scene_busy_gates_v2482.values()):
                    if isinstance(_rec_v2482, dict):
                        _rec_v2482["active"] = False
                self._scene_busy_gates_v2482.clear()
                self._scene_busy_latest_by_scope_v2482.clear()
            pkm_global_busy.cancel_all(reason="home_close_v2482")
        except Exception:
            pass
        try:
            with self._wall_poster_prefetch_lock_v1644:
                self._wall_poster_prefetch_queue_v1644[:] = []
                self._wall_poster_prefetch_seen_v1644.clear()
                self._wall_poster_prefetch_attempts_v1644.clear()
        except Exception:
            pass
        try:
            with self._poster_fallback_probe_lock:
                self._poster_fallback_probe_queue[:] = []
        except Exception:
            pass
        try:
            with self._info_cast_prewarm_lock:
                self._info_cast_prewarm_queue[:] = []
                self._info_cast_prewarm_seen.clear()
        except Exception:
            pass
        try:
            win_v1841 = xbmcgui.Window(10000)
            win_v1841.clearProperty("PlexKM.HomeWindowActive")
            win_v1841.clearProperty("PlexKM.HomeWindowOpening")
            win_v1841.clearProperty("PlexKM.Section.FirstVisitGateV1620")
            win_v1841.clearProperty("PlexKM.Section.FirstVisitGateKeyV1620")
            win_v1841.clearProperty("PlexKM.Section.FirstVisitGateTokenV1620")
            win_v1841.clearProperty("PlexKM.Home.XmlControlsReadyV2119")
        except Exception:
            pass
        # v2119: close the lifecycle boundary before native controls are reset.
        self._xml_controls_ready_v2119 = False
        _log("HOME_CLOSE_NATIVE_HANDOFF_V2534 elapsed_ms=%d worker_wait_ms=0" % (_pkm_speed_ms() - _close_started_v2534))
        xbmcgui.WindowXML.close(self)
        _log("HOME_CLOSE_END_V2534 elapsed_ms=%d worker_wait_ms=0" % (_pkm_speed_ms() - _close_started_v2534))

    def _r155_rating_record(self, li, props):
        """Remember displayed local scores, reusable in every PKM surface."""
        try:
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            ptype = str(li.getProperty("PlexKM.Type") or "").lower()
            if not rk or ptype not in ("movie", "show", "episode", "season"):
                return
            title = str(li.getProperty("PlexKM.Title") or li.getLabel() or "")
            original_title = str(li.getProperty("PlexKM.OriginalTitle") or "")
            year = str(li.getProperty("PlexKM.Year") or "")
            lookup_key = str(li.getProperty("PlexKM.GrandparentRatingKey") or
                             li.getProperty("PlexKM.ParentRatingKey") or rk) if ptype != "movie" else rk
            values = {k: str(props.get(k) or "") for k in (
                "Rating", "Cine21CriticRating", "Cine21AudienceRating",
                "WatchaRating", "WatchaCount", "WatchaDisplay") if props.get(k)}
            if not values:
                return
            cache = getattr(self, "_r155_rating_positive_cache", None)
            if not isinstance(cache, dict):
                cache = {}
                self._r155_rating_positive_cache = cache
            key = (ptype, lookup_key, title, original_title, year)
            prior = cache.get(key) or {}
            prior.update(values)
            cache[key] = prior
        except Exception:
            pass

    def _r155_rating_schedule(self, li, reason=""):
        """R155: read absent scores from the SAME local DB for Home + Section.

        Background: only SQLite/local CPU. Kodi ListItems and window properties
        are touched exclusively by the existing GUI SendClick callback.
        """
        try:
            if li is None or self._closing_event_v1841.is_set():
                return False
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Info.InlineActive") == "1":
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            ptype = str(li.getProperty("PlexKM.Type") or "").lower()
            if not rk or ptype not in ("movie", "show", "episode", "season"):
                return False
            if str(win.getProperty("PlexKM.Home.RatingKey") or "") != rk:
                return False
            title = str(li.getProperty("PlexKM.Title") or li.getLabel() or "")
            original_title = str(li.getProperty("PlexKM.OriginalTitle") or "")
            year = str(li.getProperty("PlexKM.Year") or "")
            lookup_key = str(li.getProperty("PlexKM.GrandparentRatingKey") or
                             li.getProperty("PlexKM.ParentRatingKey") or rk) if ptype != "movie" else rk
            existing = {
                "Rating": str(li.getProperty("PlexKM.Rating") or ""),
                "Cine21CriticRating": str(li.getProperty("PlexKM.Cine21CriticRating") or ""),
                "Cine21AudienceRating": str(li.getProperty("PlexKM.Cine21AudienceRating") or ""),
                "WatchaRating": str(li.getProperty("PlexKM.WatchaRating") or ""),
            }
            if existing["Rating"] and (ptype != "movie" or (
                    (existing["Cine21CriticRating"] or existing["Cine21AudienceRating"])
                    and existing["WatchaRating"])):
                return False
            # Positive cache is keyed by Plex ratingKey AND canonical title/year.
            cache_key = (ptype, lookup_key, title, original_title, year)
            found = getattr(self, "_r155_rating_positive_cache", {}).get(cache_key)
            retry_after = getattr(self, "_r155_rating_retry_after", {}).get(cache_key, 0)
            if not isinstance(found, dict) and float(retry_after or 0) > time.monotonic():
                return False
            if isinstance(found, dict):
                self._r155_rating_pending = (rk, found)
                self._r155_rating_commit()
                return True
            self._r155_rating_generation = int(getattr(self, "_r155_rating_generation", 0) or 0) + 1
            token = self._r155_rating_generation

            def _worker():
                try:
                    if self._closing_event_v1841.wait(0.24):
                        return
                    if token != int(getattr(self, "_r155_rating_generation", -1)):
                        return
                    vals = {}
                    if not existing["Rating"]:
                        vals["Rating"] = self._home_db_imdb_rating_value(lookup_key) or ""
                    if ptype == "movie":
                        if not existing["Cine21CriticRating"] and not existing["Cine21AudienceRating"]:
                            cine = self._home_cine21_rating_props(
                                rk, title=title, original_title=original_title, year=year) or {}
                            vals["Cine21CriticRating"] = str(cine.get("CriticRating") or "")
                            vals["Cine21AudienceRating"] = str(cine.get("AudienceRating") or "")
                        if not existing["WatchaRating"]:
                            watcha = self._info_watcha_point_props_v2627(
                                rk, title=title, original_title=original_title, year=year) or {}
                            vals["WatchaRating"] = str(watcha.get("Rating") or "")
                            vals["WatchaCount"] = str(watcha.get("Count") or "")
                            vals["WatchaDisplay"] = str(watcha.get("Display") or "")
                    if token != int(getattr(self, "_r155_rating_generation", -1)):
                        return
                    # Avoid hammering a DB that legitimately has no matching score.
                    retry_map = getattr(self, "_r155_rating_retry_after", None)
                    if not isinstance(retry_map, dict):
                        retry_map = {}
                        self._r155_rating_retry_after = retry_map
                    retry_map[cache_key] = time.monotonic() + 20.0
                    if any(vals.values()):
                        cache = getattr(self, "_r155_rating_positive_cache", None)
                        if not isinstance(cache, dict):
                            cache = {}
                            self._r155_rating_positive_cache = cache
                        cache[cache_key] = vals
                        self._r155_rating_pending = (rk, vals)
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    _log("R155_RATING_WORKER_FAILED key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            _PKMHomeThreadV2151(target=_worker, name="PKMRatingPointR155", daemon=True).start()
            return True
        except Exception:
            return False

    def _r155_rating_commit(self):
        """GUI-thread: enrich ONLY the same currently displayed ratingKey."""
        pending = getattr(self, "_r155_rating_pending", None)
        self._r155_rating_pending = None
        if not pending:
            return False
        try:
            rk, vals = pending
            win = xbmcgui.Window(10000)
            if str(win.getProperty("PlexKM.Home.RatingKey") or "") != str(rk):
                return False
            if win.getProperty("PlexKM.Info.InlineActive") == "1":
                return False
            fid = int(self._safe_focus_id() or 0)
            li = (self._focused_wall_item() if fid == WALL_ID else
                  self._home_focused_item(fid) if self._is_home_row_control(fid) else None)
            if li is None or str(li.getProperty("PlexKM.RatingKey") or "") != str(rk):
                return False
            for key, value in vals.items():
                if not value:
                    continue
                li.setProperty("PlexKM.%s" % key, str(value))
                self.setProperty("PlexKM.Home.%s" % key, str(value))
                win.setProperty("PlexKM.Home.%s" % key, str(value))
            ptype = str(li.getProperty("PlexKM.Type") or "").lower()
            rating = str(li.getProperty("PlexKM.Rating") or "")
            cine = {"CriticRating": li.getProperty("PlexKM.Cine21CriticRating") or "",
                    "AudienceRating": li.getProperty("PlexKM.Cine21AudienceRating") or ""}
            watcha = {"Rating": li.getProperty("PlexKM.WatchaRating") or "",
                      "Count": li.getProperty("PlexKM.WatchaCount") or "",
                      "Display": li.getProperty("PlexKM.WatchaDisplay") or ""}
            if ptype == "movie":
                computed = {
                    "ImdbRating": self._home_imdb_rating_value(rating),
                    "Cine21BarDisplay": self._home_cine21_bar_display(cine),
                    "WatchaBarDisplay": self._home_watcha_bar_display(watcha),
                    "RatingBarDisplay": self._home_rating_bar_display(cine, watcha, self._home_imdb_rating_value(rating)),
                }
            else:
                computed = {"TmdbRating": self._home_tmdb_rating_value(rating)}
            for key, value in computed.items():
                # R41: the row ListItem may not carry the score Home already shows
                # (TV rating lives on the show).  Empty must not erase it.
                if not str(value or "") and win.getProperty("PlexKM.Home.%s" % key):
                    continue
                self.setProperty("PlexKM.Home.%s" % key, str(value or ""))
                win.setProperty("PlexKM.Home.%s" % key, str(value or ""))
            _log("R155_RATING_SYNC section=%s rk=%s type=%s rating=%s cine21=%s/%s watcha=%s" % (
                self.active_section_id, rk, ptype, rating,
                cine["CriticRating"], cine["AudienceRating"], watcha["Rating"]))
            return True
        except Exception:
            _log("R155_RATING_COMMIT_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _set_header(self, title, count_text=""):
        title = _display_library_title(title)
        count_text = _display_library_title(count_text)
        try:
            # TITLE_ID is the HTPC hero metadata title. Do not overwrite it
            # with menu/header labels such as "홈"; hero title is synced
            # from the first/selected media item in _set_home_meta_from_item().
            self.getControl(COUNT_ID).setLabel(count_text or "")
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            is_home = "1" if (self.active_section_id == "__home__" or (title or "") == "홈") else "0"
            hidden_home_v2479 = bool(is_home == "1" and getattr(self, "_home_target_hidden_v2479", False))
            win.setProperty("PlexKM.Window.Title", title or "")
            win.setProperty("PlexKM.Window.CountLabel", count_text or "")
            if not hidden_home_v2479:
                win.setProperty("PlexKM.Window.IsHome", is_home)
            try:
                self.setProperty("PlexKM.Window.Title", title or "")
                self.setProperty("PlexKM.Window.CountLabel", count_text or "")
                if not hidden_home_v2479:
                    self.setProperty("PlexKM.Window.IsHome", is_home)
            except Exception:
                pass
            # v2479: a Home target being composed under another PKM scene must
            # remain hidden until its row controls are complete.
            if is_home == "1" and hidden_home_v2479:
                _log("HOME_HEADER_STAGE_HIDDEN_V2479 title=%s count=%s source_held=1" % (
                    _short_log_value(title), _short_log_value(count_text)
                ))
            # v2121: when Home itself is the published surface, clear the
            # section owner used by XML's zero-lag sidebar RIGHT gate.
            if is_home == "1" and not hidden_home_v2479:
                self._set_published_section_id_v2121("", reason="home_header:%s" % (title or ""))
        except Exception:
            pass

    # PKM_PATCH_ACTIVE v2503 recommend_to_library_sequential_widget_fade_no_overlap
# PKM_PATCH_ACTIVE v2502 unified_scene_crossfade_source_hold_hidden_library_decode_stage
    # Visual policy: source remains complete until target is ready; scene surfaces
    # then overlap through short XML fade-out/fade-in animations with no blank frame.

    def _pkm_surface_mode_v2479(self):
        """Best-effort name of the currently visible PKM full scene."""
        try:
            win = xbmcgui.Window(10000)
            if self._actor_profile_is_active_v2454():
                return "actor_profile"
            if (self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or win.getProperty("PlexKM.Info.InlineActive") == "1"):
                return "info"
            if (self.getProperty("PlexKM.Search.InlineActive") == "1"
                    or win.getProperty("PlexKM.Search.InlineActive") == "1"):
                return "search"
            if (self.getProperty("PlexKM.Window.IsSectionWall") == "1"
                    or win.getProperty("PlexKM.Window.IsSectionWall") == "1"):
                return "section_library"
            if (self.getProperty("PlexKM.Window.IsSectionCategory") == "1"
                    or win.getProperty("PlexKM.Window.IsSectionCategory") == "1"):
                return "section_category"
            if (self.getProperty("PlexKM.Window.IsSectionRecommend") == "1"
                    or win.getProperty("PlexKM.Window.IsSectionRecommend") == "1"):
                return "section_recommend"
            return "home"
        except Exception:
            return "unknown"

    def _pkm_swap_settle_v2479(self, source="", target="", reason="", wait_ms=16):
        """One GUI-frame hidden-target barrier used by PKM full-scene swaps."""
        try:
            self._pkm_swap_seq_v2479 = int(getattr(self, "_pkm_swap_seq_v2479", 0) or 0) + 1
            token = "%d:%d" % (self._pkm_swap_seq_v2479, self._now_ms())
            win = xbmcgui.Window(10000)
            for obj in (self, win):
                obj.setProperty("PlexKM.Swap.PendingV2479", "1")
                obj.setProperty("PlexKM.Swap.SourceV2479", str(source or ""))
                obj.setProperty("PlexKM.Swap.TargetV2479", str(target or ""))
                obj.setProperty("PlexKM.Swap.TokenV2479", token)
            xbmc.sleep(max(0, int(wait_ms or 0)))
            _log("PKM_SWAP_HIDDEN_TARGET_READY_V2479 token=%s source=%s target=%s wait_ms=%d reason=%s source_held=1 target_hidden=1" % (
                token, source or "", target or "", int(wait_ms or 0), reason or ""
            ))
            return token
        except Exception:
            return ""

    def _pkm_swap_finish_v2479(self, token="", source="", target="", reason=""):
        try:
            win = xbmcgui.Window(10000)
            for obj in (self, win):
                obj.clearProperty("PlexKM.Swap.PendingV2479")
                obj.clearProperty("PlexKM.Swap.SourceV2479")
                obj.clearProperty("PlexKM.Swap.TargetV2479")
                obj.clearProperty("PlexKM.Swap.TokenV2479")
            _log("PKM_SWAP_ATOMIC_COMMIT_V2479 token=%s source=%s target=%s reason=%s zero_blank=1 source_retired_after_target_ready=1" % (
                token or "", source or "", target or "", reason or ""
            ))
            return True
        except Exception:
            return False

    _SEARCH_KEYS_KO_NORMAL = [
        # 6-column Plex-like keyboard. Keep the character key order, but move
        # editing/function keys to the bottom so Space/Delete/Clear never sit
        # in the middle of the Hangul rows.
        "ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ",
        "ㅅ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ",
        "ㅍ", "ㅎ", "ㅏ", "ㅐ", "ㅑ", "ㅓ",
        "ㅔ", "ㅕ", "ㅗ", "ㅛ", "ㅜ", "ㅠ",
        "ㅡ", "ㅣ", "영문", "숫자", "Del", "Space",
        "Clear", "Shift", "완료", "기호",
    ]
    _SEARCH_KEYS_KO_SHIFT = [
        # Shift page: double consonants, compound vowels, and compound finals.
        "ㄲ", "ㄸ", "ㅃ", "ㅆ", "ㅉ", "ㅒ",
        "ㅖ", "ㅘ", "ㅙ", "ㅚ", "ㅝ", "ㅞ",
        "ㅟ", "ㅢ", "ㄳ", "ㄵ", "ㄶ", "ㄺ",
        "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ",
        "ㅄ", "기본", "영문", "숫자", "Del", "Space",
        "Clear", "Shift", "완료", "기호",
    ]
    _SEARCH_KEYS = {
        "EN": list("ABCDEFGHIJKLMNOPQRSTUVWX") + ["Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Del", "Space", "Clear", "Shift", "완료", "한글", "숫자", "기호"],
        "NUM": list("1234567890") + ["-", ".", ":", "/", "(", ")", "Del", "Space", "Clear", "Shift", "완료", "한글", "영문", "기호"],
        "SYM": ["!", "?", "@", "#", "%", "&", "+", "=", "_", "'", '"', ",", ".", ":", "/", "-", "(", ")", "[", "]", "Del", "Space", "Clear", "Shift", "완료", "한글", "영문", "숫자"],
    }
    _SEARCH_KEY_DISPLAY_LABELS = {
        "Del": "Delete",
        "완료": "결과▶",
    }
    _SEARCH_KO_CONSONANTS = set("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
    _SEARCH_KO_VOWELS = set("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
    _SEARCH_CHO = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
    _SEARCH_JUNG = ["ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ", "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ", "ㅡ", "ㅢ", "ㅣ"]
    _SEARCH_JONG = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]
    _SEARCH_VOWEL_COMBINE = {
        ("ㅗ", "ㅏ"): "ㅘ", ("ㅗ", "ㅐ"): "ㅙ", ("ㅗ", "ㅣ"): "ㅚ",
        ("ㅜ", "ㅓ"): "ㅝ", ("ㅜ", "ㅔ"): "ㅞ", ("ㅜ", "ㅣ"): "ㅟ",
        ("ㅡ", "ㅣ"): "ㅢ",
    }
    _SEARCH_JONG_COMBINE = {
        ("ㄱ", "ㅅ"): "ㄳ", ("ㄴ", "ㅈ"): "ㄵ", ("ㄴ", "ㅎ"): "ㄶ",
        ("ㄹ", "ㄱ"): "ㄺ", ("ㄹ", "ㅁ"): "ㄻ", ("ㄹ", "ㅂ"): "ㄼ",
        ("ㄹ", "ㅅ"): "ㄽ", ("ㄹ", "ㅌ"): "ㄾ", ("ㄹ", "ㅍ"): "ㄿ",
        ("ㄹ", "ㅎ"): "ㅀ", ("ㅂ", "ㅅ"): "ㅄ",
    }
    _SEARCH_JONG_SPLIT = {v: k for k, v in _SEARCH_JONG_COMBINE.items()}
    _SEARCH_CHO_COMBINE = {
        ("ㄱ", "ㄱ"): "ㄲ", ("ㄷ", "ㄷ"): "ㄸ", ("ㅂ", "ㅂ"): "ㅃ",
        ("ㅅ", "ㅅ"): "ㅆ", ("ㅈ", "ㅈ"): "ㅉ",
    }

    def _now_ms(self):
        return int(time.time() * 1000)

    def _duration_text(self, duration):
        return pkm_info_data.duration_text(duration)

    def _remaining_time_props(self, duration_raw, view_offset_raw):
        return pkm_info_data.remaining_time_props(duration_raw, view_offset_raw)

    def _text_has_cyrillic(self, text):
        return pkm_info_data.text_needs_open_sans(text)

    def _normalize_meta_title(self, value):
        try:
            text = str(value or "").strip().lower()
            text = re.sub(r"\s+", " ", text)
            return text
        except Exception:
            return str(value or "").strip().lower()

    def _meta_props_useful(self, props):
        try:
            if not props:
                return False
            plex_type = str(props.get("PlexType") or props.get("Type") or "").lower()
            if plex_type == "episode":
                # TV episodes must not be accepted as complete when only a title
                # or summary exists.  The Info screen needs the show title plus
                # episode identity and at least one show-level detail; otherwise
                # InfoLoaded=1 can freeze a title-only screen.
                has_title = bool(props.get("Title") or props.get("ShowTitle"))
                has_episode = bool(props.get("EpisodeTitle") or props.get("Season") or props.get("Episode"))
                has_body = bool(props.get("Summary") or props.get("DurationText") or props.get("Duration"))
                has_detail = bool(
                    props.get("Genre") or props.get("Director") or props.get("ContentRating") or
                    props.get("Rating") or props.get("CastSlots") or props.get("Premiered") or props.get("MetaLine")
                )
                return bool(has_title and has_episode and has_body and has_detail)
            # v212: Actor-only data is not valid Info metadata.
            return bool(
                props.get("Summary") or props.get("Genre") or props.get("Director") or
                props.get("ContentRating") or props.get("Rating") or props.get("CastSlots")
            )
        except Exception:
            return False

    def _metadata_type_code(self, plex_type):
        plex_type = str(plex_type or "").lower()
        if plex_type == "movie":
            return "1"
        if plex_type == "show":
            return "2"
        if plex_type == "season":
            return "3"
        if plex_type == "episode":
            return "4"
        return ""

    def _remember_meta_hint(self, rating_key, title="", year="", section_id="", plex_type=""):
        try:
            rk = str(rating_key or "").strip()
            if not rk:
                return
            old = self._home_meta_hint_cache.get(rk, {}) or {}
            self._home_meta_hint_cache[rk] = {
                "title": str(title or old.get("title") or "").strip(),
                "year": str(year or old.get("year") or "").strip(),
                "section_id": str(section_id or old.get("section_id") or "").strip(),
                "type": str(plex_type or old.get("type") or "").strip(),
            }
        except Exception:
            pass

    def _candidate_metadata_nodes(self, rating_key, hint=None):
        hint = hint or {}
        title_hint = str(hint.get("title") or "").strip()
        year_hint = str(hint.get("year") or "").strip()
        section_id = str(hint.get("section_id") or "").strip()
        plex_type = str(hint.get("type") or "").strip()
        wanted_title = self._normalize_meta_title(title_hint)
        yielded = set()

        def _nodes(root, source_label):
            try:
                if root is None:
                    return
                for node in list(root):
                    if getattr(node, "tag", "") not in ("Video", "Directory"):
                        continue
                    rk = str(node.get("ratingKey") or node.get("key") or "").strip()
                    dedupe = "%s:%s" % (source_label, rk or id(node))
                    if dedupe in yielded:
                        continue
                    yielded.add(dedupe)
                    node_title = node.get("title") or node.get("grandparentTitle") or node.get("parentTitle") or ""
                    if wanted_title and self._normalize_meta_title(node_title) != wanted_title:
                        continue
                    node_year = str(node.get("year") or "").strip()
                    if year_hint and node_year and node_year != year_hint:
                        continue
                    yield source_label, node
            except Exception:
                return

        try:
            type_code = self._metadata_type_code(plex_type)
            if section_id and title_hint:
                params = {"title": title_hint, "includeGuids": 1}
                if type_code:
                    params["type"] = type_code
                root = core.plex_request_xml("/library/sections/%s/all" % section_id, params=params, timeout=6)
                for item in _nodes(root, "section_title"):
                    yield item
        except Exception:
            _log("META_CANONICAL section_title_failed rating_key=%s\n%s" % (rating_key, traceback.format_exc()), xbmc.LOGWARNING)

        try:
            if title_hint:
                root = core.plex_request_xml("/search", params={"query": title_hint, "includeCollections": 0, "includeGuids": 1}, timeout=6)
                for item in _nodes(root, "global_search"):
                    yield item
        except Exception:
            _log("META_CANONICAL global_search_failed rating_key=%s\n%s" % (rating_key, traceback.format_exc()), xbmc.LOGWARNING)

    def _find_canonical_metadata_props(self, rating_key, reason=""):
        try:
            hint = self._home_meta_hint_cache.get(str(rating_key or ""), {}) or {}
            if not hint.get("title"):
                return None
            best = None
            best_score = -1
            for source_label, node in self._candidate_metadata_nodes(rating_key, hint=hint):
                props = self._home_meta_props_from_node(node, rating_key=rating_key, reason=reason, request_label="canonical_%s" % source_label)
                if not self._meta_props_useful(props):
                    _log("META_CANONICAL reject_sparse rating_key=%s source=%s node_key=%s title=%s" % (
                        rating_key, source_label, node.get("ratingKey") or "", _short_log_value(node.get("title") or "", 80)), xbmc.LOGWARNING)
                    continue
                score = 0
                if props.get("Summary"):
                    score += 8
                if props.get("Genre"):
                    score += 4
                if props.get("Director"):
                    score += 4
                if props.get("ContentRating"):
                    score += 2
                if props.get("Rating"):
                    score += 2
                try:
                    score += min(len(props.get("CastSlots") or []), 8)
                except Exception:
                    pass
                if score > best_score:
                    best_score = score
                    best = props
                    best["_CanonicalSource"] = source_label
                    best["_CanonicalRatingKey"] = node.get("ratingKey") or ""
            if best:
                _log("META_CANONICAL accepted rating_key=%s source=%s canonical_key=%s score=%s title=%s" % (
                    rating_key, best.get("_CanonicalSource") or "", best.get("_CanonicalRatingKey") or "", best_score, _short_log_value(best.get("Title") or "", 80)))
            return best
        except Exception:
            _log("META_CANONICAL failed rating_key=%s\n%s" % (rating_key, traceback.format_exc()), xbmc.LOGWARNING)
            return None

    def _lerp_rgb_hex(self, start_rgb, end_rgb, ratio):
        try:
            start_rgb = str(start_rgb or "").strip().upper()[-6:]
            end_rgb = str(end_rgb or "").strip().upper()[-6:]
            ratio = max(0.0, min(1.0, float(ratio)))
            sr = int(start_rgb[0:2], 16); sg = int(start_rgb[2:4], 16); sb = int(start_rgb[4:6], 16)
            er = int(end_rgb[0:2], 16); eg = int(end_rgb[2:4], 16); eb = int(end_rgb[4:6], 16)
            rr = int(round(sr + (er - sr) * ratio))
            rg = int(round(sg + (eg - sg) * ratio))
            rb = int(round(sb + (eb - sb) * ratio))
            return "%02X%02X%02X" % (rr, rg, rb)
        except Exception:
            return str(end_rgb or self._home_bg_default)[-6:].upper()


    def _normalize_argb_color(self, value):
        try:
            text = str(value or "").strip().upper().replace("#", "")
            if len(text) == 6:
                text = "FF" + text
            if len(text) != 8:
                return ""
            int(text, 16)
            return text
        except Exception:
            return ""

    def _average_image_rgb_with_pillow(self, data):
        """Pick the color of the *actual fanart-to-solid diffuse seam*.

        v2218 mirrors the Home hero mask instead of sampling a broad arbitrary
        left region.  ``new_bingie_spotlight_diffuse1_home.png`` fades from
        transparent to opaque across roughly the first 16-17% of the fanart.
        That is the only region whose color needs to agree with the solid PKM
        field for the join to look continuous.

        The strongest weight is placed around the middle of that fade, where
        both fanart and solid background are simultaneously visible.  Color is
        chosen by occupied area, not by saturation, so a narrow red scarf/window
        cannot beat a broad blue-gray wall or sky.  True neutral wall colors are
        also allowed instead of being replaced by PKM's generic gray.
        """
        try:
            from PIL import Image
            import colorsys
            im = Image.open(BytesIO(data)).convert("RGB")
            im.thumbnail((160, 90))
            width, height = im.size
            raw_pixels = list(im.getdata())
            if not raw_pixels or width <= 0 or height <= 0:
                return None

            # The physical diffuse reaches full opacity at ~16.7% of its width.
            # Sample only that same seam band.  A tiny 1% inset avoids edge/crop
            # artifacts where the source image itself may contain a border.
            seam_start = max(0, int(round(width * 0.010)))
            seam_end = max(seam_start + 1, int(round(width * 0.175)))
            seam_end = min(width, seam_end)
            seam_span = max(1, seam_end - seam_start)

            hue_bins = [{} for _ in range(24)]       # 15-degree chromatic bins
            neutral_bin = {"area": 0.0, "pixels": []}
            candidates = []
            total_area = 0.0

            for y in range(height):
                ny = (float(y) + 0.5) / float(height)
                # The hero's bottom has its own alpha fade and is covered by rows;
                # do not let that secondary fade define the horizontal seam color.
                if ny < 0.035 or ny > 0.82:
                    continue
                vertical_weight = 0.96 + 0.04 * (1.0 - abs(ny - 0.43) / 0.43 if ny <= 0.86 else 0.0)
                vertical_weight = max(0.92, min(1.0, vertical_weight))

                for x in range(seam_start, seam_end):
                    p = raw_pixels[(y * width) + x]
                    r, g, b = [int(vv) for vv in p]
                    mx = max(r, g, b)
                    mn = min(r, g, b)
                    chroma = mx - mn
                    luma = (r * 299 + g * 587 + b * 114) / 1000.0
                    if luma < 5 or luma > 252 or mx <= 0:
                        continue

                    # Approximate alpha*(1-alpha): the perceptually important part
                    # of a crossfade is its middle, not the fully transparent or
                    # fully opaque endpoint.  A sine arch is a stable mask-agnostic
                    # approximation to the real diffuse ramp.
                    t = (float(x - seam_start) + 0.5) / float(seam_span)
                    import math
                    seam_weight = max(0.08, math.sin(math.pi * max(0.0, min(1.0, t))))
                    weight = seam_weight * vertical_weight
                    total_area += weight

                    h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
                    hue_deg = (h * 360.0) % 360.0

                    # Low-saturation scene colors are valid seam colors.  Keep a
                    # real neutral bucket rather than inventing a saturated hue.
                    if s < 0.060 or chroma < 11:
                        neutral_bin["area"] += weight
                        neutral_bin["pixels"].append((weight, p, s, v, x))
                        continue

                    idx = int(hue_deg // 15.0) % 24
                    bucket = hue_bins[idx]
                    bucket["area"] = float(bucket.get("area", 0.0)) + weight
                    bucket["count"] = int(bucket.get("count", 0)) + 1
                    candidates.append((h, s, v, weight, p, idx, x))

            chromatic_area = sum(float(b.get("area", 0.0)) for b in hue_bins)
            neutral_area = float(neutral_bin.get("area", 0.0))
            if chromatic_area <= 0.0 and neutral_area <= 0.0:
                _log("DYNAMIC_BG_RGB_PICK_V2218 mode=diffuse_seam fallback=neutral reason=no_valid_seam_pixels")
                return (23, 25, 27)

            # Find the largest chromatic area with neighboring bins folded in.
            best_idx = 0
            best_chromatic_score = -1.0
            for idx in range(24):
                own = float(hue_bins[idx].get("area", 0.0))
                prev_a = float(hue_bins[(idx - 1) % 24].get("area", 0.0))
                next_a = float(hue_bins[(idx + 1) % 24].get("area", 0.0))
                score = own + 0.52 * (prev_a + next_a)
                if score > best_chromatic_score:
                    best_chromatic_score = score
                    best_idx = idx

            # A genuinely neutral wall/sky may own the seam.  Require a modest
            # margin so a few gray pixels cannot suppress a coherent hue.
            use_neutral = neutral_area > max(0.0, best_chromatic_score * 1.12)
            picked = []
            mode = "neutral_area" if use_neutral else "chromatic_area"
            if use_neutral:
                picked = list(neutral_bin.get("pixels") or [])
            else:
                center_h = ((best_idx * 15.0) + 7.5) % 360.0
                for h, s, v, weight, p, idx, x in candidates:
                    deg = (h * 360.0) % 360.0
                    dist = abs(deg - center_h)
                    dist = min(dist, 360.0 - dist)
                    if dist <= 23.0:
                        picked.append((weight, p, s, v, x))

            if not picked:
                # Conservative fallback: all valid seam pixels from the winning
                # type, never a completely unrelated global fanart color.
                if candidates:
                    picked = [(w, p, s, v, x) for h, s, v, w, p, idx, x in candidates]
                    mode = "all_chromatic_fallback"
                else:
                    picked = list(neutral_bin.get("pixels") or [])
                    mode = "all_neutral_fallback"

            # Robust weighted RGB mean.  Clip only extreme luminance outliers so
            # a small lamp/window does not drag the seam toward orange/white.
            lum_items = []
            for w, p, s, v, x in picked:
                lum = (p[0] * 299 + p[1] * 587 + p[2] * 114) / 1000.0
                lum_items.append((lum, w, p, s, v, x))
            lum_items.sort(key=lambda z: z[0])
            total_pick_w = sum(z[1] for z in lum_items) or 1.0
            lo_cut = total_pick_w * 0.05
            hi_cut = total_pick_w * 0.95
            running = 0.0
            trimmed = []
            for item in lum_items:
                running += item[1]
                if running >= lo_cut and running <= hi_cut:
                    trimmed.append(item)
            if not trimmed:
                trimmed = lum_items

            total_w = sum(z[1] for z in trimmed) or 1.0
            r = int(round(sum(z[1] * z[2][0] for z in trimmed) / total_w))
            g = int(round(sum(z[1] * z[2][1] for z in trimmed) / total_w))
            b = int(round(sum(z[1] * z[2][2] for z in trimmed) / total_w))
            _log("DYNAMIC_BG_RGB_PICK_V2218 rgb=(%d,%d,%d) mode=%s seam_px=%d-%d width=%d neutral_area=%.1f chromatic_area=%.1f picked=%d mask_match=1" % (
                r, g, b, mode, seam_start, seam_end, width, neutral_area, chromatic_area, len(trimmed)
            ))
            return (r, g, b)
        except Exception:
            _log("DYNAMIC_BG_RGB_PICK_FAILED_V2218 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return None

    def _canonical_movie_duplicate_meta_v1816(self, rating_key, title="", original_title="", year="", duration=""):
        """Resolve duplicate-library movie metadata from the v1817 bulk index."""
        rk = str(rating_key or "").strip()
        title_s = str(title or "").strip()
        original_s = str(original_title or "").strip()
        year_s = str(year or "").strip()
        duration_i = _safe_int(duration, 0)
        if not (rk and year_s and (title_s or original_s)):
            return {"Rating": "", "ContentRating": "", "SourceKey": ""}
        cache = getattr(self, "_canonical_movie_duplicate_meta_cache_v1816", None)
        if not isinstance(cache, dict):
            cache = {}
            self._canonical_movie_duplicate_meta_cache_v1816 = cache
        ck = (rk, title_s.casefold(), original_s.casefold(), year_s, duration_i)
        if ck in cache:
            return cache.get(ck) or {"Rating": "", "ContentRating": "", "SourceKey": ""}
        result = {"Rating": "", "ContentRating": "", "SourceKey": ""}
        try:
            index = self._canonical_movie_duplicate_index_v1817()
            candidates = []
            seen = set()
            for name in (title_s, original_s):
                key = (str(name or "").strip().casefold(), year_s)
                for rr in index.get(key, []) if key[0] else []:
                    source_key = str(rr[0] or "").strip()
                    if source_key and source_key != rk and source_key not in seen:
                        seen.add(source_key)
                        candidates.append(rr)
            candidates.sort(key=lambda rr: abs(_safe_int(rr[1], 0) - duration_i) if duration_i > 0 and _safe_int(rr[1], 0) > 0 else 0)
            for rr in candidates:
                source_key = str(rr[0] or "").strip()
                source_duration = _safe_int(rr[1], 0)
                if duration_i > 0 and source_duration > 0 and abs(duration_i - source_duration) > 900:
                    continue
                rating_val = ""
                for value in rr[3:7]:
                    rating_val = self._home_imdb_rating_value(value)
                    if rating_val:
                        break
                content_val = ""
                raw = rr[2] if len(rr) > 2 else ""
                if raw:
                    try:
                        node = json.loads(raw) if isinstance(raw, str) else raw
                        if isinstance(node, dict):
                            content_val = pkm_info_data.localize_content_rating(
                                node.get("contentRating") or node.get("content_rating") or node.get("mpaa") or ""
                            )
                    except Exception:
                        content_val = ""
                if rating_val or content_val:
                    result = {"Rating": rating_val, "ContentRating": content_val, "SourceKey": source_key}
                    break
            cache[ck] = result
            if (result.get("Rating") or result.get("ContentRating")) and not bool(getattr(self, "_suppress_item_diag_v2473", False)):
                _log("CANONICAL_MOVIE_META_INHERIT_V1817 rating_key=%s source_key=%s title=%s year=%s rating=%s content_rating=%s" % (
                    rk, result.get("SourceKey") or "", _short_log_value(title_s, 80), year_s,
                    result.get("Rating") or "", result.get("ContentRating") or ""
                ))
            return result
        except Exception:
            cache[ck] = result
            _log("CANONICAL_MOVIE_META_ERROR_V1817 rating_key=%s err=%s" % (
                rk, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return result

    def _plex_offline_active(self):
        try:
            return xbmcgui.Window(10000).getProperty("PlexKM.PlexOffline") == "1"
        except Exception:
            return False

    def _is_android_v2591(self):
        try:
            return bool(xbmc.getCondVisibility("System.Platform.Android"))
        except Exception:
            return False

    def _node_tag_candidates(self, node, tag_name):
        """Return all usable Plex tag/filter candidates for Director/Role/etc.

        v199: actor/director recommendation rows should not always lock to the
        first Role/Director item.  Collect all candidates from the selected base
        movie and shuffle them before selecting a person.
        """
        out = []
        seen = set()
        try:
            tag = str(tag_name or "").strip()
            if node is None or not tag:
                return []
            for child in list(node.findall(tag) or []):
                name = str(child.get("tag") or child.get("title") or "").strip()
                ident = str(child.get("id") or child.get("filter") or "").strip()
                if "=" in ident:
                    ident = ident.split("=", 1)[1].strip()
                if not name or not ident:
                    continue
                key = "%s:%s" % (name.lower(), ident)
                if key in seen:
                    continue
                seen.add(key)
                out.append((name, ident))
            try:
                random.SystemRandom().shuffle(out)
            except Exception:
                random.shuffle(out)
        except Exception:
            return []
        return out

    def _node_country_names(self, node):
        names = []
        try:
            for child in list(node or []):
                if getattr(child, "tag", "") == "Country":
                    name = str(child.get("tag") or child.get("title") or "").strip()
                    if name:
                        names.append(name)
        except Exception:
            pass
        return names

    def _node_is_korean_movie(self, node):
        try:
            country_text = " ".join(self._node_country_names(node)).lower()
            if any(x in country_text for x in ("korea", "south korea", "대한민국", "한국")):
                return True
            original_title = str((node.get("originalTitle") if node is not None else "") or "")
            # Conservative fallback: Korean original title usually means Korean content.
            # Do not use localized title because foreign movies can have Korean titles.
            if original_title and re.search(r"[가-힣]", original_title):
                return True
        except Exception:
            pass
        return False

    def _movie_extra_rating_values(self, node):
        return pkm_movie_recommend.movie_extra_rating_values(node)

    def _movie_extra_score_threshold(self):
        return pkm_movie_recommend.movie_extra_score_threshold()

    def _movie_full_compose_group_titles_v1616(self, rows_cache):
        titles = []
        last_id = None
        try:
            for entry in rows_cache or []:
                if not isinstance(entry, dict):
                    continue
                rid = entry.get("row_id") or entry.get("row_title") or "row"
                if rid == last_id:
                    continue
                last_id = rid
                titles.append(_display_library_title(entry.get("row_title", "") or ""))
        except Exception:
            pass
        return titles

    def _movie_full_compose_titles_valid_v1616(self, titles, require_extra=False):
        values = [_display_library_title(x or "") for x in (titles or [])]
        try:
            recent_idx = values.index("최근 추가됨")
        except ValueError:
            return False
        extra_indexes = []
        for idx, value in enumerate(values):
            if value.startswith("취향 ") or value.endswith(" 감독작") or value.endswith(" 출연작") or value in ("감독작", "배우작"):
                extra_indexes.append(idx)
        if extra_indexes and recent_idx > min(extra_indexes):
            return False
        if require_extra and not extra_indexes:
            return False
        return True

    # PKM_SHIELD_POSTLOG_GUI_OWNER_GUARD
    def _pkm_gui_window_owned_postlog(self):
        """A delayed background callback may not touch Kodi Settings or dialogs."""
        try:
            if self._closing_event_v1841.is_set():
                return False
            owner = int(self.getId())
            active = int(xbmcgui.getCurrentWindowId())
            modal = int(xbmcgui.getCurrentWindowDialogId())
            if owner <= 0 or active != owner or modal not in (0, 9999, owner):
                return False
            return True
        except Exception:
            # Unknown ownership is not permission to change Kodi GUI focus.
            return False

    # PKM_WINDOW_OWNED_R34: xbmcgui.Window has no getId() in Kodi 21 (only
    # Action.getId exists), so _pkm_gui_window_owned_postlog() raised inside its
    # try and returned False on every call.  That silently disabled the TV Info
    # episode focus (INLINE_INFO_TV_FOCUS_SKIP reason=window_not_active on 8/8
    # opens).  The old method is left untouched on purpose: its other callers
    # have effectively been dead code and are not revived here.
    _INFO_FOCUS_IDS_R34 = frozenset((
        5001, 5002, 5004, 5005, 5006, 5007, 5008, 5009, 5708, 5711, 5712, 5713,
        5721, 5722, 5724, 5725, 5726, 5727, 5728, 5729, 5730,
        6100, 6110, 6210, 6220, 6230, 6310, 6320, 6330, 6340,
    ))
    _ACTOR_FOCUS_IDS_R34 = frozenset((6500, 6510, 6486, 6487))  # R92: 6486 = 더보기, R93: 6487 = 소개 팝업
    _SEARCH_FOCUS_IDS_R36 = frozenset((2110, 2111, 2112, 2113, 3000, 4000, 4001, 4010, 4011, 4020, 4021, 4200, 4300, 4301))

    def _pkm_window_owned_r34(self):
        try:
            if self._closing_event_v1841.is_set():
                return False
            active = int(xbmcgui.getCurrentWindowId())
            owner = int(getattr(self, "_pkm_window_id_r34", 0) or 0)
            if owner <= 0:
                if not xbmc.getCondVisibility("Window.IsActive(plexkm_home_window.xml)"):
                    return False
                owner = active
                self._pkm_window_id_r34 = active
            if active != owner:
                return False
            modal = int(xbmcgui.getCurrentWindowDialogId())
            return modal in (0, 9999, owner)
        except Exception:
            return False

    def _image_dimensions_no_decode_v2498(self, path):
        """Read JPEG/PNG/WebP dimensions without image decode or PIL transforms."""
        try:
            raw = str(path or "").strip()
            translated = xbmcvfs.translatePath(raw) if raw.lower().startswith("special://") else raw
            if not translated or not os.path.exists(translated):
                return (0, 0)
            with open(translated, "rb") as fh:
                head = fh.read(64)
            if head.startswith(b"\xff\xd8\xff"):
                return self._jpeg_dimensions_no_pil_v1931(translated)
            if head.startswith(b"\x89PNG\r\n\x1a\n") and len(head) >= 24:
                return (int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big"))
            if len(head) >= 30 and head[:4] == b"RIFF" and head[8:12] == b"WEBP":
                kind = head[12:16]
                if kind == b"VP8X" and len(head) >= 30:
                    return (1 + int.from_bytes(head[24:27], "little"), 1 + int.from_bytes(head[27:30], "little"))
                if kind == b"VP8L" and len(head) >= 25 and head[20:21] == b"/":
                    bits = int.from_bytes(head[21:25], "little")
                    return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
                if kind == b"VP8 " and len(head) >= 30:
                    marker = head.find(b"\x9d\x01\x2a", 20)
                    if marker >= 0 and marker + 7 <= len(head):
                        width = int.from_bytes(head[marker + 3:marker + 5], "little") & 0x3FFF
                        height = int.from_bytes(head[marker + 5:marker + 7], "little") & 0x3FFF
                        return (width, height)
        except Exception:
            pass
        return (0, 0)

    def _jpeg_dimensions_no_pil_v1931(self, path):
        """Read JPEG dimensions from markers without decoding the image."""
        try:
            with open(str(path or ""), "rb") as fh:
                if fh.read(2) != b"\xff\xd8":
                    return (0, 0)
                while True:
                    marker_start = fh.read(1)
                    if not marker_start:
                        break
                    if marker_start != b"\xff":
                        continue
                    marker = fh.read(1)
                    while marker == b"\xff":
                        marker = fh.read(1)
                    if not marker or marker in (b"\xd8", b"\xd9"):
                        continue
                    if marker == b"\xda":
                        break
                    length_raw = fh.read(2)
                    if len(length_raw) != 2:
                        break
                    length = int.from_bytes(length_raw, "big")
                    if length < 2:
                        break
                    marker_id = marker[0]
                    if marker_id in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                        payload = fh.read(5)
                        if len(payload) != 5:
                            break
                        height = int.from_bytes(payload[1:3], "big")
                        width = int.from_bytes(payload[3:5], "big")
                        return (width, height)
                    fh.seek(length - 2, os.SEEK_CUR)
        except Exception:
            pass
        return (0, 0)

    # ==== PKM_TMDB_EPISODE_PLOT_R35 ===========================================
    # Plex is authoritative.  Only episodes whose Plex summary is EMPTY are filled
    # from TMDb (via the installed TMDb Helper add-on, same channel the actor
    # profile already uses).  Never on the first frame: worker thread + GUI ping.
    # Show identity: TMDb id from the Plex GUID when present, otherwise a TMDb
    # Helper TV search that must match the exact normalized title AND year (+-1).
    # No match -> nothing is filled (better empty than another show's text).
    _TMDB_PLOT_CACHE_TTL_R35 = 30 * 86400
    _TMDB_PLOT_LOCK_R35 = threading.RLock()
    _TMDB_PLOT_NEG_TTL_R35 = 3 * 86400

    _TMDB_PLOT_LOAD_LOCK_R39 = threading.Lock()

    _HANGUL_RE_R38 = re.compile(u"[가-힣]")

    # ==== PKM_TMDB_FILL_R41 ===================================================
    # Plex stays authoritative.  Only EMPTY fields are filled, from one cache:
    #   summary : movie/show -> Plex DB summary -> TMDb Korean overview
    #             episode (Home) -> TMDb Korean episode plot (R39 store) -> show
    #   rating  : TV only -> Plex show rating -> TMDb vote average
    #   genre   : TMDb genres
    # When every source was checked and nothing exists, the synopsis box shows
    # _TMDB_NO_PLOT_R41.  TMDb work runs on one background worker through TMDb
    # Helper (Korean language lock, R38).  GUI paths only read the cache.
    _TMDB_NO_PLOT_R41 = u"줄거리 정보가 없습니다"
    _HOME_KEEP_FILLED_R41 = frozenset((
        "Summary", "SummaryDisplay", "SummaryLineCount", "Rating", "TmdbRating",
        "Genre", "GenreLine", "ContentRating", "ImdbRating",
    ))
    _TMDB_FILL_MISS_TTL_R41 = 3 * 86400
    _TMDB_FILL_NOHELPER_TTL_R41 = 86400
    _TMDB_FILL_QLOCK_R41 = threading.Lock()

    # ------------------------------------------------------------------
    # R63: episode thumbnail fallback (Plex 404 -> TMDb still -> show art)
    # ------------------------------------------------------------------
    _THUMB_MISS_TTL_R63 = 6 * 3600
    _STILL_TTL_R63 = 30 * 86400
    _THUMB_LOCK_R63 = threading.RLock()

    # ------------------------------------------------------------------
    # R68: Korean Wikipedia biography for actors whose TMDb / Actor Master
    # biography is empty or a one-liner ("...는 한국의 배우입니다.").
    # Page first, then a background lookup (~0.6 s per request); cached.
    # ------------------------------------------------------------------
    _WIKI_BIO_SHORT_R68 = 120
    _WIKI_BIO_TTL_R68 = 30 * 86400
    _WIKI_BIO_NEG_TTL_R68 = 7 * 86400
    _WIKI_BIO_LOCK_R68 = threading.RLock()
    _WIKI_UA_R68 = "PKM-Kodi/1.0 (plugin.video.km; personal media center)"

    def _plex_people_candidate_matches_item(self, candidate_key, rating_key):
        """Verify a Plex people-search candidate belongs to the current item.

        Plex global people search can return the wrong person for common Korean
        names.  v197 only accepts a people fallback if Plex gives us a key that
        can be queried and the current ratingKey appears in that result set.
        If verification is not possible, we reject the candidate rather than
        showing a wrong actor photo.
        """
        candidate_key = str(candidate_key or "").strip()
        rating_key = str(rating_key or "").strip()
        if not candidate_key or not rating_key:
            return False
        try:
            root = core.plex_request_xml(candidate_key, params={"limit": 50}, timeout=0.9)
        except Exception:
            try:
                root = core.plex_request_xml(candidate_key, params=None, timeout=0.9)
            except Exception:
                _log("CAST_FALLBACK plex_people_verify_failed key=%s rating_key=%s error=%s" % (
                    _short_log_value(candidate_key, 120), rating_key, _short_log_value(traceback.format_exc(), 220)), xbmc.LOGWARNING)
                return False
        try:
            for node in root.iter():
                rk = (node.get("ratingKey") or node.get("key") or "").strip()
                prk = (node.get("parentRatingKey") or "").strip()
                grk = (node.get("grandparentRatingKey") or "").strip()
                if rating_key in (rk, prk, grk):
                    return True
        except Exception:
            pass
        return False

    def _schedule_info_cast_prewarm_for_data_v1339(self, data_items, reason="", limit=CAST_PREWARM_VISIBLE_LIMIT_V1339, priority=False):
        """Queue cast prewarm from DB row data without touching Kodi controls."""
        # v1642: section/startup background queues are speculative and can saturate
        # Plex/DB while Home is being used.  Only explicit stable-focus priority
        # work is allowed.
        if not priority:
            try:
                _log("CAST_PREWARM_DATA_DEFER_V1642 reason=%s policy=stable_focus_only" % (reason or ""))
            except Exception:
                pass
            return 0
        try:
            if self._settings_quiet_active_v1457():
                _log("CAST_PREWARM_SKIP_V1457 reason=settings_quiet request_reason=%s mode=data" % (reason or ""))
                return 0
            if _pkm_playback_active_v1411():
                _log("CAST_PREWARM_SKIP_PLAYBACK_ACTIVE_V1411 reason=%s mode=data" % (reason or ""))
                return 0
            items = []
            seen = set()
            for data in list(data_items or []):
                if not isinstance(data, dict):
                    continue
                rk = str(data.get("rating_key") or "").strip()
                if not rk or rk in seen:
                    continue
                seen.add(rk)
                data = dict(data)
                data["reason"] = reason or data.get("reason") or ""
                data["priority"] = bool(priority)
                items.append(data)
                if len(items) >= max(1, int(limit or 1)):
                    break
            if not items:
                return 0
            added = 0
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            with self._info_cast_prewarm_lock:
                for data in items:
                    if self._info_cast_prewarm_enqueue_locked_v1340(data, priority=priority, now_ms=now_ms):
                        added += 1
                if added > 0:
                    self._start_info_cast_prewarm_workers_locked_v1340()
            if added > 0:
                _log("CAST_PREWARM_QUEUE_V1340 reason=%s added=%d candidates=%d limit=%d priority=%s mode=data" % (
                    reason or "", added, len(items), int(limit or 0), "1" if priority else "0"))
            return added
        except Exception:
            _log("CAST_PREWARM_QUEUE_FAILED_V1339 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return 0

    def _apply_plex_metadata_repair_to_li(self, li, reason="", update_visual=True, timeout=8, cast_fast_v2207=False):
        """Canonical episode+show repair for sparse local DB/cache Info.

        This is not a timing delay: it fetches the same Plex metadata that Plex UI
        already has and merges the episode node with its grandparent show node.
        It repairs stale DB rows immediately while startup partial sync is fixed for
        future items.
        """
        start = time.time()
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            try:
                _repair_timeout = float(timeout or 8)
            except Exception:
                _repair_timeout = 8
            # v2207: cast repair does not need collections/guids.  Use the
            # plain metadata URL for the foreground cast-only repair so it is
            # both cheaper on PMS and, critically, does not coalesce onto the
            # 1.6s background cast-prewarm request for the richer URL.  The
            # foreground caller therefore keeps its own 2.4s timeout budget.
            _repair_params_v2207 = None if cast_fast_v2207 else {"includeGuids": 1, "includeCollections": 1}
            # v2380: timeout is a total foreground budget, not a per-request
            # allowance. Episode repair may need both episode and show metadata;
            # they must share one deadline so Info cannot stack two full waits.
            _repair_deadline_v2380 = time.time() + max(0.15, _repair_timeout)
            root = core.plex_request_xml(
                "/library/metadata/%s" % rk,
                params=_repair_params_v2207,
                timeout=max(0.15, _repair_deadline_v2380 - time.time()),
                log_failures=False
            )
            node = _first_metadata_node(root)
            if node is None:
                return False
            props = self._home_meta_props_from_node(node, rating_key=rk, reason=reason or "direct_repair", request_label="direct_repair")
            plex_type = str(node.get("type") or "")
            show_key = str(node.get("grandparentRatingKey") or li.getProperty("PlexKM.GrandparentRatingKey") or "").strip()
            if plex_type == "episode" and show_key:
                try:
                    _repair_remaining_v2380 = _repair_deadline_v2380 - time.time()
                    if _repair_remaining_v2380 <= 0.15:
                        raise RuntimeError("info_repair_budget_exhausted_v2380")
                    show_root = core.plex_request_xml(
                        "/library/metadata/%s" % show_key,
                        params=_repair_params_v2207,
                        timeout=max(0.15, _repair_remaining_v2380),
                        log_failures=False
                    )
                    show_node = _first_metadata_node(show_root)
                    if show_node is not None:
                        show_props = self._home_meta_props_from_node(show_node, rating_key=show_key, reason=reason or "direct_repair", request_label="direct_repair_show")
                        props = self._merge_episode_with_show_metadata_props(props, show_props, reason="direct_repair")
                except Exception:
                    _log("INFO_DIRECT_PLEX_REPAIR_SHOW_FAILED rating_key=%s show_key=%s err=%s" % (
                        rk, show_key, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            props.pop("_Sparse", None)
            props.pop("_RequestLabel", None)
            props.pop("_SourceRatingKey", None)
            props.pop("_CanonicalSource", None)
            props.pop("_CanonicalRatingKey", None)
            try:
                direct_slots = props.get("CastSlots") or []
                if not direct_slots:
                    existing_slots = self._cast_slots_from_li_properties(li, max_count=8)
                    if existing_slots:
                        props["CastSlots"] = existing_slots
                        props["Cast"] = " / ".join([s.get("Name") or "" for s in existing_slots if s.get("Name")])
                        _log("INFO_DIRECT_PLEX_REPAIR_PRESERVE_CAST reason=%s rating_key=%s existing_names=%d action=keep_names_when_plex_roles_empty" % (
                            reason or "", rk, len(existing_slots)
                        ), xbmc.LOGWARNING)
            except Exception:
                pass
            self._store_home_meta_enrich_cache(rk, props, reason="plex_direct_%s" % (reason or ""), drop_name_only_cast=False)
            ok = self._apply_cached_info_to_li(li, reason="plex_direct_%s" % (reason or ""), update_visual=update_visual)
            if ok:
                try:
                    li.setProperty("PlexKM.InfoPlexDirectRepairDoneRatingKey", rk)
                except Exception:
                    pass
            _log("INFO_DIRECT_PLEX_REPAIR rating_key=%s show_key=%s ok=%s mode=%s title=%s episode=%s summary=%s genre=%s cast=%d timeout=%.1fs elapsed=%.1fms source=%s" % (
                rk, show_key, "1" if ok else "0", "cast_light_v2207" if cast_fast_v2207 else "rich",
                _short_log_value(props.get("Title") or "", 80),
                _short_log_value(props.get("EpisodeTitle") or "", 80),
                "1" if props.get("Summary") else "0",
                "1" if props.get("Genre") else "0",
                len(props.get("CastSlots") or []),
                _repair_timeout,
                (time.time() - start) * 1000.0,
                reason or ""
            ))
            return ok
        except Exception:
            _log("INFO_DIRECT_PLEX_REPAIR_FAILED source=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False


# R73: PlexKMHomeWindow methods live in topic part modules next to this file.
# They are adopted here with this module's globals, so behaviour is identical
# to the single-file class (same MRO, same globals, same function objects API).
from resources.lib.plexkm_home_window_startup import PlexKMHomeWindow as _PKMHomePartStartupR73
from resources.lib.plexkm_home_window_home import PlexKMHomeWindow as _PKMHomePartHomeR73
from resources.lib.plexkm_home_window_section import PlexKMHomeWindow as _PKMHomePartSectionR73
from resources.lib.plexkm_home_window_library import PlexKMHomeWindow as _PKMHomePartLibraryR73
from resources.lib.plexkm_home_window_info import PlexKMHomeWindow as _PKMHomePartInfoR73
from resources.lib.plexkm_home_window_info_tv import PlexKMHomeWindow as _PKMHomePartInfoTvR73
from resources.lib.plexkm_home_window_actor import PlexKMHomeWindow as _PKMHomePartActorR73
from resources.lib.plexkm_home_window_tmdb import PlexKMHomeWindow as _PKMHomePartTmdbR73
from resources.lib.plexkm_home_window_search import PlexKMHomeWindow as _PKMHomePartSearchR73
from resources.lib.plexkm_home_window_nav import PlexKMHomeWindow as _PKMHomePartNavR73
from resources.lib.plexkm_home_window_playback import PlexKMHomeWindow as _PKMHomePartPlaybackR73
import types as _pkm_hw_types_r73


def _pkm_hw_adopt_parts_r73(cls, parts):
    """Copy part functions onto cls, rebound to this module's globals."""
    module_globals = globals()
    adopted = 0
    for part in parts:
        for name, raw in list(vars(part).items()):
            is_static = isinstance(raw, staticmethod)
            fn = raw.__func__ if is_static else raw
            if not isinstance(fn, _pkm_hw_types_r73.FunctionType):
                if name.startswith("__") and name.endswith("__"):
                    continue  # class bookkeeping (__module__, __dict__, __firstlineno__ ...)
                raise TypeError("R73 part %s.%s is not a function" % (part.__name__, name))
            if name in cls.__dict__:
                raise RuntimeError("R73 duplicate method %s from %s" % (name, part.__name__))
            new_fn = _pkm_hw_types_r73.FunctionType(
                fn.__code__, module_globals, fn.__name__, fn.__defaults__, fn.__closure__)
            new_fn.__kwdefaults__ = fn.__kwdefaults__
            new_fn.__doc__ = fn.__doc__
            new_fn.__dict__.update(fn.__dict__)
            new_fn.__qualname__ = "%s.%s" % (cls.__name__, fn.__name__)
            new_fn.__module__ = cls.__module__
            setattr(cls, name, staticmethod(new_fn) if is_static else new_fn)
            adopted += 1
    return adopted


_PKM_HW_ADOPTED_R73 = _pkm_hw_adopt_parts_r73(PlexKMHomeWindow, (
    _PKMHomePartStartupR73,
    _PKMHomePartHomeR73,
    _PKMHomePartSectionR73,
    _PKMHomePartLibraryR73,
    _PKMHomePartInfoR73,
    _PKMHomePartInfoTvR73,
    _PKMHomePartActorR73,
    _PKMHomePartTmdbR73,
    _PKMHomePartSearchR73,
    _PKMHomePartNavR73,
    _PKMHomePartPlaybackR73,
))
