# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM settings screen for the OTT add-ons (R112).

Replaces Kodi's stock Addon.OpenSettings for the add-ons PKM shows in its
sidebar (TVING, wavve, Watcha, Coupang, Disney+, SPOTV, Naver Sports,
broadcast).  The add-on's own resources/settings.xml (version 1 or the old
flat format) is read and drawn as a PKM card: toggles, option pickers, number
and text entry with a PKM keyboard (no Kodi keyboard), and action buttons
(logout etc.) after a PKM confirm.  Values are written with the add-on's own
xbmcaddon.Addon(...).setSetting, exactly where Kodi's dialog would write them.
"""

import os
import re
import threading
import traceback

from xml.etree import ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui

XML_NAME = "plexkm_ott_settings_r112.xml"
LIST_ID = 300
VALUE_ID = 401
KEYS_ID = 410

ACTION_LEFT = 1
ACTION_RIGHT = 2
BACK_ACTIONS = (9, 10, 92)
ACTION_SELECT = 7
ACTION_MOUSE_LEFT = 100
NAV_IDS = (1, 2, 3, 4, 5, 6, 107)

_SYMBOLS = list("!@#$%^&*()-_.+=?/:~")


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.km] OTT_SETTINGS_R112 %s" % msg, level)


# ------------------------------------------------------------ settings.xml

def _strings(addon_path):
    """#id -> text from the add-on's strings.po (Korean first, then English)."""
    out = {}
    for lang in ("resource.language.en_gb", "resource.language.ko_kr"):
        path = os.path.join(addon_path, "resources", "language", lang, "strings.po")
        try:
            with open(path, "r", encoding="utf-8") as f:
                po = f.read()
        except Exception:
            continue
        for ctx, mid, mstr in re.findall(
                r'msgctxt\s+"#(\d+)"\s*\n\s*msgid\s+"((?:[^"\\]|\\.)*)"\s*\n\s*msgstr\s+"((?:[^"\\]|\\.)*)"', po):
            text = mstr or mid
            if text:
                out[ctx] = text.replace('\\"', '"')
    return out


def _label(strings, raw):
    raw = str(raw or "").strip()
    if raw.isdigit():
        return strings.get(raw) or raw
    return raw


def parse_settings(addon_id):
    """-> [entry]; entry: {id, kind, label, ...}.  kind: bool | options |
    number | text | action.  Pure apart from reading the add-on's files."""
    addon = xbmcaddon.Addon(addon_id)
    path = addon.getAddonInfo("path")
    strings = _strings(path)
    root = ET.parse(os.path.join(path, "resources", "settings.xml")).getroot()
    entries = []
    for s in root.iter("setting"):
        sid = s.get("id")
        stype = (s.get("type") or "").lower()
        label = _label(strings, s.get("label"))
        if not sid or not label or stype in ("sep", "lsep"):
            continue
        if (s.findtext("visible") or "").strip().lower() == "false":
            continue
        try:
            if int(s.findtext("level") or 0) >= 4:
                continue
        except Exception:
            pass
        ctl = s.find("control")
        ctype = ctl.get("type") if ctl is not None else ""
        e = {"id": sid, "label": label}
        if stype in ("boolean", "bool"):
            e["kind"] = "bool"
        elif stype == "enum" or (stype == "integer" and ctype in ("spinner", "list")):
            opts = []
            for o in s.iter("option"):
                opts.append((str(o.text or "").strip(), _label(strings, o.get("label")) or str(o.text or "")))
            if not opts and s.get("lvalues"):
                opts = [(str(i), _label(strings, v)) for i, v in enumerate(s.get("lvalues").split("|"))]
            if not opts and s.get("values"):
                opts = [(str(i), v) for i, v in enumerate(s.get("values").split("|"))]
            if not opts:
                continue
            e["kind"], e["options"] = "options", opts
        elif stype in ("integer", "number", "slider"):
            e["kind"] = "number"
            try:
                cons = s.find("constraints")
                e["min"] = int((cons.findtext("minimum") if cons is not None else None) or s.get("range", "0,1,0").split(",")[0])
                e["max"] = int((cons.findtext("maximum") if cons is not None else None) or 999999)
            except Exception:
                e["min"], e["max"] = 0, 999999
        elif ctype == "button" or stype == "action":
            data = (ctl.findtext("data") if ctl is not None else "") or s.get("action") or ""
            if not data:
                continue
            e["kind"], e["data"] = "action", data.strip()
        elif stype in ("string", "text"):
            e["kind"] = "text"
            e["hidden"] = bool(
                (ctl is not None and (ctl.findtext("hidden") or "").strip().lower() == "true")
                or s.get("option") == "hidden" or sid.lower() in ("pw", "password", "passwd"))
        else:
            continue
        entries.append(e)
    return entries


# ------------------------------------------------------------ dialog

class PKMOttSettingsDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._addon_id = kwargs.pop("addon_id")
        self._title = kwargs.pop("title", "")
        self._extra = list(kwargs.pop("extra", None) or [])
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self._addon = xbmcaddon.Addon(self._addon_id)
        self._entries = []
        self._edit = None          # entry being edited
        self._buf = ""
        self._upper = False
        self._reveal = False
        self.changed = False

    # -------------------------------------------------- list

    def onInit(self):
        try:
            self._entries = parse_settings(self._addon_id) + self._extra
        except Exception:
            _log("PARSE_FAILED addon=%s err=%s" % (self._addon_id, traceback.format_exc().replace("\n", " | ")),
                 xbmc.LOGWARNING)
            self._entries = list(self._extra)
        self.setProperty("PKMOS.Title", "%s 설정" % self._title)
        try:
            ver = self._addon.getAddonInfo("version")
            self.setProperty("PKMOS.Sub", "%s  ·  v%s" % (self._addon.getAddonInfo("name"), ver))
        except Exception:
            pass
        self._bind(0)
        _log("OPEN addon=%s entries=%d" % (self._addon_id, len(self._entries)))

    def _value_text(self, e):
        kind = e["kind"]
        if kind == "action":
            return ""
        raw = self._addon.getSetting(e["id"]) if not e.get("virtual") else ""
        if kind == "bool":
            return "켜짐" if raw.lower() == "true" else "꺼짐"
        if kind == "options":
            for v, lab in e["options"]:
                if v == raw:
                    return lab
            return e["options"][0][1] if e["options"] else raw
        if kind == "text":
            if not raw:
                return "설정 안 됨"
            return "•" * min(len(raw), 12) if e.get("hidden") else raw
        return raw or "0"

    def _bind(self, pos):
        ctl = self.getControl(LIST_ID)
        ctl.reset()
        items = []
        for e in self._entries:
            li = xbmcgui.ListItem(label=e["label"])
            li.setProperty("value", self._value_text(e))
            li.setProperty("kind", e["kind"])
            if e["kind"] == "bool":
                li.setProperty("on", "1" if self._addon.getSetting(e["id"]).lower() == "true" else "")
            items.append(li)
        ctl.addItems(items)
        if items:
            ctl.selectItem(max(0, min(pos, len(items) - 1)))
        self.setFocusId(LIST_ID)

    def _refresh_row(self, pos):
        try:
            e = self._entries[pos]
            li = self.getControl(LIST_ID).getListItem(pos)
            li.setProperty("value", self._value_text(e))
            if e["kind"] == "bool":
                li.setProperty("on", "1" if self._addon.getSetting(e["id"]).lower() == "true" else "")
        except Exception:
            pass

    def _set(self, e, value):
        self._addon.setSetting(e["id"], str(value))
        self.changed = True
        _log("SET addon=%s id=%s kind=%s" % (self._addon_id, e["id"], e["kind"]))

    def _cycle(self, pos, step):
        e = self._entries[pos]
        opts = e["options"]
        raw = self._addon.getSetting(e["id"])
        idx = next((i for i, (v, _) in enumerate(opts) if v == raw), 0)
        self._set(e, opts[(idx + step) % len(opts)][0])
        self._refresh_row(pos)

    def onClick(self, control_id):
        _log("CLICK id=%s edit=%s focus=%s" % (control_id, bool(self._edit), self.getFocusId()))
        if control_id == LIST_ID:
            pos = self.getControl(LIST_ID).getSelectedPosition()
            if not (0 <= pos < len(self._entries)):
                return
            e = self._entries[pos]
            kind = e["kind"]
            if kind == "bool":
                cur = self._addon.getSetting(e["id"]).lower() == "true"
                self._set(e, "false" if cur else "true")
                self._refresh_row(pos)
            elif kind == "options":
                self._cycle(pos, 1)
            elif kind in ("text", "number"):
                self._start_edit(e)
            elif kind == "action":
                self._run_action(e)
            return
        if control_id == VALUE_ID:
            self._finish_edit(save=True)
            return
        if control_id == KEYS_ID:
            try:
                key = self.getControl(KEYS_ID).getSelectedItem().getProperty("key")
            except Exception:
                return
            self._key(key)

    def onAction(self, action):
        aid = action.getId()
        if self._edit is not None:
            if aid in BACK_ACTIONS:
                self._finish_edit(save=False)
                return
            if aid in (ACTION_SELECT, ACTION_MOUSE_LEFT) or aid in NAV_IDS:
                return          # Enter/arrows drive the PKM keys, not the buffer
            phys = _decode_key(action)
            if phys:
                kind, ch = phys
                if kind == "char":
                    if self._edit["kind"] == "number" and not ch.isdigit():
                        return
                    self._buf += ch.upper() if self._upper else ch
                    self._render_buf()
                elif kind == "backspace":
                    self._buf = self._buf[:-1]
                    self._render_buf()
                elif kind == "save":
                    self._finish_edit(save=True)
            return
        if aid in BACK_ACTIONS:
            self.close()
            return
        if aid in (ACTION_LEFT, ACTION_RIGHT) and self.getFocusId() == LIST_ID:
            pos = self.getControl(LIST_ID).getSelectedPosition()
            if 0 <= pos < len(self._entries) and self._entries[pos]["kind"] == "options":
                self._cycle(pos, -1 if aid == ACTION_LEFT else 1)

    def _run_action(self, e):
        try:
            from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
            ok = open_pkm_confirm_dialog(e["label"], "%s 을(를) 실행할까요?" % e["label"],
                                         yes_label="실행", no_label="취소", default_focus="no")
        except Exception:
            ok = True
        if not ok:
            return
        _log("ACTION addon=%s id=%s" % (self._addon_id, e["id"]))
        self.changed = True
        if callable(e.get("data")):
            e["data"]()
        else:
            xbmc.executebuiltin(e["data"])

    # -------------------------------------------------- PKM keyboard

    def _keys(self):
        if self._edit["kind"] == "number":
            base = list("1234567890")
        else:
            letters = "abcdefghijklmnopqrstuvwxyz"
            base = list(letters.upper() if self._upper else letters) + list("1234567890") + _SYMBOLS
            base += ["소문자" if self._upper else "대문자", "공백"]
            if self._edit.get("hidden"):
                base.append("숨기기" if self._reveal else "보기")
        return base + ["삭제", "지우기", "저장", "취소"]

    def _bind_keys(self, keep=None):
        ctl = self.getControl(KEYS_ID)
        pos = ctl.getSelectedPosition() if keep else 0
        ctl.reset()
        items = []
        for k in self._keys():
            li = xbmcgui.ListItem(label=k)
            li.setProperty("key", k)
            li.setProperty("wide", "1" if len(k) > 1 else "")
            items.append(li)
        ctl.addItems(items)
        ctl.selectItem(max(0, pos))

    def _render_buf(self):
        e = self._edit
        if not self._buf:
            text = "[COLOR 66FFFFFF]입력하세요[/COLOR]"
        elif e.get("hidden") and not self._reveal:
            text = "•" * len(self._buf)
        else:
            text = self._buf
        self.setProperty("PKMOS.EditValue", text)

    def _start_edit(self, e):
        self._edit = e
        self._buf = self._addon.getSetting(e["id"]) or ""
        self._upper = False
        self._reveal = False
        self.setProperty("PKMOS.EditTitle", e["label"])
        self._render_buf()
        self._bind_keys()
        self.setProperty("PKMOS.Edit", "1")
        self.setFocusId(KEYS_ID)

    def _finish_edit(self, save):
        _log("FINISH_EDIT save=%s" % save)
        e, self._edit = self._edit, None
        self.setProperty("PKMOS.Edit", "")
        if e is not None and save:
            val = self._buf
            if e["kind"] == "number":
                try:
                    n = int(val or 0)
                    n = max(e.get("min", 0), min(e.get("max", 999999), n))
                    val = str(n)
                except Exception:
                    val = self._addon.getSetting(e["id"])
            self._set(e, val)
        pos = self._entries.index(e) if e in self._entries else 0
        self._refresh_row(pos)
        self.setFocusId(LIST_ID)
        self.getControl(LIST_ID).selectItem(pos)

    def _key(self, key):
        if key == "저장":
            self._finish_edit(save=True)
            return
        if key == "취소":
            self._finish_edit(save=False)
            return
        if key == "삭제":
            self._buf = self._buf[:-1]
        elif key == "지우기":
            self._buf = ""
        elif key in ("대문자", "소문자"):
            self._upper = not self._upper
            self._bind_keys(keep=True)
        elif key in ("보기", "숨기기"):
            self._reveal = not self._reveal
            self._bind_keys(keep=True)
        elif key == "공백":
            self._buf += " "
        else:
            self._buf += key
        self._render_buf()


class PKMOttInputDialog(PKMOttSettingsDialog):
    """R112: PKM text query entry (Korean/English/number/symbol pages) for the
    OTT search; same card as the settings entry, no Kodi keyboard."""

    def __init__(self, *args, **kwargs):
        self._query_title = kwargs.pop("query_title", "검색")
        value = kwargs.pop("value", "")
        kwargs.setdefault("addon_id", "plugin.video.km")
        PKMOttSettingsDialog.__init__(self, *args, **kwargs)
        from resources.lib.pkm_search_keyboard import SearchKeyboard
        self._kb = SearchKeyboard()
        self._kb.set_text(value or "")
        self.result = None

    def onInit(self):
        self.setProperty("PKMOS.Title", self._query_title)
        self.setProperty("PKMOS.Sub", "")
        self.setProperty("PKMOS.EditTitle", "검색어")
        self._edit = {"kind": "query", "label": self._query_title}
        self._render_query()
        self._bind_query_keys(0)
        self.setProperty("PKMOS.Edit", "1")
        self.setFocusId(KEYS_ID)

    def _render_query(self):
        q = self._kb.query
        self.setProperty("PKMOS.EditValue", q if q else "[COLOR 66FFFFFF]검색어를 입력하세요[/COLOR]")

    def _bind_query_keys(self, pos):
        ctl = self.getControl(KEYS_ID)
        ctl.reset()
        items = []
        for k in self._kb.keys():
            lab = {"Del": "삭제", "Space": "공백", "Clear": "지우기", "Shift": "쌍자음"}.get(k, k)
            li = xbmcgui.ListItem(label=lab)
            li.setProperty("key", k)
            li.setProperty("wide", "1" if len(lab) > 1 else "")
            items.append(li)
        ctl.addItems(items)
        ctl.selectItem(max(0, min(pos, len(items) - 1)))

    def _key(self, key):
        res = self._kb.press(key)
        if res == "done":
            self.result = self._kb.query.strip()
            self.close()
            return
        if res == "page":
            self._bind_query_keys(self.getControl(KEYS_ID).getSelectedPosition())
        self._render_query()

    def onClick(self, control_id):
        if control_id == VALUE_ID:
            self.result = self._kb.query.strip()
            self.close()
            return
        PKMOttSettingsDialog.onClick(self, control_id)

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK_ACTIONS:
            self.result = None
            self.close()
            return
        if aid in (ACTION_SELECT, ACTION_MOUSE_LEFT) or aid in NAV_IDS:
            return
        phys = _decode_key(action)
        if phys:
            kind, ch = phys
            if kind == "char":
                self._kb.tokens.append(ch)
                from resources.lib.pkm_search_keyboard import recompose
                self._kb.query = recompose(self._kb.tokens)
                self._render_query()
            elif kind == "backspace":
                self._kb.press("Del")
                self._render_query()
            elif kind == "save":
                self.result = self._kb.query.strip()
                self.close()


def open_query(title, value=""):
    """PKM text entry for a search query.  Returns the text or None."""
    path = xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")
    dlg = PKMOttInputDialog(XML_NAME, path, "Default", "1080i", query_title=title, value=value)
    try:
        dlg.doModal()
        return dlg.result
    finally:
        del dlg


def _decode_key(action):
    """Physical keyboard -> ('char', c) / ('backspace', '') / ('save', '')."""
    try:
        from resources.lib.pkm_settings_flow import PKMTextInputDialog
        return PKMTextInputDialog._decode_physical_key_v1704(action)
    except Exception:
        return None


def open_settings(addon_id, title, extra=None):
    """Modal PKM settings for one OTT add-on.  Returns True if anything changed."""
    path = xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")
    dlg = PKMOttSettingsDialog(XML_NAME, path, "Default", "1080i",
                               addon_id=addon_id, title=title, extra=extra)
    try:
        dlg.doModal()
        return bool(dlg.changed)
    finally:
        del dlg
