# -*- coding: utf-8 -*-
"""Plex KM search index / Hangul chosung helpers.

Split from default.py in v644.  This module is intentionally independent from
``default.py`` to avoid reverse imports and duplicate plugin initialization.
Callers pass the few default.py callbacks it needs through an env dict.
"""
from __future__ import absolute_import, unicode_literals

import os
import re
import sqlite3
import time
import traceback
import unicodedata

import xbmc


_HANGUL_CHO = ("ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ")
_HANGUL_CHO_JAMO = ("ᄀ", "ᄁ", "ᄂ", "ᄃ", "ᄄ", "ᄅ", "ᄆ", "ᄇ", "ᄈ", "ᄉ", "ᄊ", "ᄋ", "ᄌ", "ᄍ", "ᄎ", "ᄏ", "ᄐ", "ᄑ", "ᄒ")
_HANGUL_CHO_SET = set(_HANGUL_CHO)
_HANGUL_CHO_JAMO_TO_COMPAT = dict(zip(_HANGUL_CHO_JAMO, _HANGUL_CHO))
_SEARCHABLE_PLEX_TYPES = ("movie", "show")


def _noop_log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] %s" % msg, level)
    except Exception:
        pass


def _env_log(env):
    try:
        return (env or {}).get("log") or _noop_log
    except Exception:
        return _noop_log


def search_db_path(addon_profile_dir):
    """Separate local DB for Plex KM search index."""
    return os.path.join(addon_profile_dir(), "plex_km_search.db")


def _compat_hangul_jamo(value):
    """Convert Unicode choseong jamo back to compatibility jamo.

    Python/Kodi can turn ㄱ/ㄴ/ㅅ into ᄀ/ᄂ/ᄉ during normalization or input.
    The search DB stores compatibility initials like ㄱㅅㅊ, so queries and
    index values must be normalized back to the same form before LIKE matching.
    """
    return "".join(_HANGUL_CHO_JAMO_TO_COMPAT.get(ch, ch) for ch in str(value or ""))


def normalize_search_text(value):
    raw = _compat_hangul_jamo(str(value or ""))
    try:
        value = unicodedata.normalize("NFKC", raw)
    except Exception:
        value = raw
    value = _compat_hangul_jamo(value)
    value = value.lower().strip()
    value = re.sub(r"\s+", " ", value)
    return value


def hangul_chosung(value):
    """Return Korean initial-consonant index for Hangul syllables.

    Examples: 기생충 -> ㄱㅅㅊ, ㄱㅅ -> ㄱㅅ.  Non-Hangul letters/digits are kept
    in normalized form so mixed titles remain searchable.
    """
    text = normalize_search_text(value)
    out = []
    for ch in text:
        code = ord(ch)
        if 0xAC00 <= code <= 0xD7A3:
            out.append(_HANGUL_CHO[(code - 0xAC00) // 588])
        elif ch in _HANGUL_CHO_SET:
            out.append(ch)
        elif ch.isspace():
            # Keep word boundaries out of the compact chosung key.
            continue
        else:
            out.append(ch)
    return "".join(out)


def is_chosung_query(value):
    q = normalize_search_text(value).replace(" ", "")
    return bool(q) and all(ch in _HANGUL_CHO_SET for ch in q)


def _ensure_performance_indexes(conn):
    """Create movie/show composite indexes outside foreground Search queries.

    Upgrading an old 270k-row index can take seconds. Query paths therefore use
    the existing base indexes immediately; the deferred post-Search refresh first
    removes episode/season rows, then creates these smaller composite indexes.
    """
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_title_norm ON search_items(plex_type, title_norm)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_original_norm ON search_items(plex_type, original_title_norm)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_sort_norm ON search_items(plex_type, sort_title_norm)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_title_chosung ON search_items(plex_type, title_chosung)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_original_chosung ON search_items(plex_type, original_title_chosung)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type_sort_chosung ON search_items(plex_type, sort_title_chosung)")


def init_search_db(conn=None, db_path=None, performance_indexes=False):
    own = conn is None
    if conn is None:
        if not db_path:
            raise ValueError("db_path is required when conn is not provided")
        conn = sqlite3.connect(db_path, timeout=8.0)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS search_items (
                rating_key TEXT PRIMARY KEY,
                section_id TEXT,
                section_title TEXT,
                plex_type TEXT,
                kodi_type TEXT,
                title TEXT,
                original_title TEXT,
                sort_title TEXT,
                title_norm TEXT,
                original_title_norm TEXT,
                sort_title_norm TEXT,
                title_chosung TEXT,
                original_title_chosung TEXT,
                sort_title_chosung TEXT,
                year INTEGER,
                summary TEXT,
                duration INTEGER,
                added_at INTEGER,
                updated_at INTEGER,
                thumb TEXT,
                art TEXT,
                media_file TEXT,
                part_key TEXT,
                view_count INTEGER,
                last_viewed_at INTEGER,
                show_title TEXT,
                season INTEGER,
                episode INTEGER,
                parent_rating_key TEXT,
                grandparent_rating_key TEXT,
                source_synced_at INTEGER DEFAULT 0,
                indexed_at INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS search_index_state (
                id INTEGER PRIMARY KEY CHECK(id=1),
                source_count INTEGER DEFAULT 0,
                search_count INTEGER DEFAULT 0,
                source_max_synced_at INTEGER DEFAULT 0,
                indexed_at INTEGER DEFAULT 0,
                last_error TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_title_norm ON search_items(title_norm)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_title_chosung ON search_items(title_chosung)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_type ON search_items(plex_type, section_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_added ON search_items(added_at DESC)")
        if performance_indexes:
            _ensure_performance_indexes(conn)
        if own:
            conn.commit()
        return conn
    finally:
        if own:
            conn.close()


def search_index_payload_from_item(item, section_title=""):
    title = item.get("title", "") or ""
    original_title = item.get("original_title", "") or ""
    sort_title = item.get("sort_title", "") or title
    return {
        "rating_key": str(item.get("rating_key", "") or ""),
        "section_id": str(item.get("section_id", "") or ""),
        "section_title": section_title or "",
        "plex_type": item.get("plex_type", "") or "",
        "kodi_type": item.get("kodi_type", "") or "",
        "title": title,
        "original_title": original_title,
        "sort_title": sort_title,
        "title_norm": normalize_search_text(title),
        "original_title_norm": normalize_search_text(original_title),
        "sort_title_norm": normalize_search_text(sort_title),
        "title_chosung": hangul_chosung(title),
        "original_title_chosung": hangul_chosung(original_title),
        "sort_title_chosung": hangul_chosung(sort_title),
        "year": int(item.get("year", 0) or 0),
        "summary": item.get("summary", "") or "",
        "duration": int(item.get("duration", 0) or 0),
        "added_at": int(item.get("added_at", 0) or 0),
        "updated_at": int(item.get("updated_at", 0) or 0),
        "thumb": item.get("thumb", "") or "",
        "art": item.get("art", "") or "",
        "media_file": item.get("media_file", "") or "",
        "part_key": item.get("part_key", "") or "",
        "view_count": int(item.get("view_count", 0) or 0),
        "last_viewed_at": int(item.get("last_viewed_at", 0) or 0),
        "show_title": item.get("show_title", "") or "",
        "season": int(item.get("season", 0) or 0),
        "episode": int(item.get("episode", 0) or 0),
        "parent_rating_key": item.get("parent_rating_key", "") or "",
        "grandparent_rating_key": item.get("grandparent_rating_key", "") or "",
        "source_synced_at": int(item.get("synced_at", 0) or 0),
        "indexed_at": int(time.time()),
    }


def upsert_search_index_item(search_conn, item, section_title=""):
    if not item or not item.get("rating_key"):
        return False
    rating_key = str(item.get("rating_key") or "")
    plex_type = str(item.get("plex_type") or "").lower()
    # v1883: the inline Search UI exposes only movies and TV shows. Never let
    # episode/season rows re-enter the dedicated search DB during normal sync.
    if plex_type not in _SEARCHABLE_PLEX_TYPES:
        try:
            search_conn.execute("DELETE FROM search_items WHERE rating_key=?", (rating_key,))
        except Exception:
            pass
        return False
    data = search_index_payload_from_item(item, section_title=section_title)
    cols = [
        "rating_key", "section_id", "section_title", "plex_type", "kodi_type", "title", "original_title", "sort_title",
        "title_norm", "original_title_norm", "sort_title_norm", "title_chosung", "original_title_chosung", "sort_title_chosung",
        "year", "summary", "duration", "added_at", "updated_at", "thumb", "art", "media_file", "part_key", "view_count", "last_viewed_at",
        "show_title", "season", "episode", "parent_rating_key", "grandparent_rating_key", "source_synced_at", "indexed_at"
    ]
    update = ",".join(["%s=excluded.%s" % (c, c) for c in cols if c != "rating_key"])
    search_conn.execute(
        "INSERT INTO search_items(%s) VALUES(%s) ON CONFLICT(rating_key) DO UPDATE SET %s" % (",".join(cols), ",".join(["?"] * len(cols)), update),
        [data.get(c) for c in cols]
    )
    return True


def delete_search_index_keys(keys, env):
    log = _env_log(env)
    keys = [str(k) for k in (keys or []) if str(k or "").strip()]
    if not keys:
        return 0
    conn = sqlite3.connect((env or {}).get("search_db_path")(), timeout=8.0)
    try:
        init_search_db(conn)
        total = 0
        for i in range(0, len(keys), 400):
            batch = keys[i:i + 400]
            conn.execute("DELETE FROM search_items WHERE rating_key IN (%s)" % ",".join(["?"] * len(batch)), batch)
            total += len(batch)
        conn.commit()
        log("SEARCH_INDEX_DELETE keys=%d" % total, xbmc.LOGINFO)
        return total
    except Exception:
        log("SEARCH_INDEX_DELETE_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        return 0
    finally:
        conn.close()


def ensure_search_db_from_items(force=False, show_progress=False, env=None):
    """Build/update the separate search DB from local plex_km.db.

    This never calls Plex search. It reads local items only, so first install
    cost is tied to the existing sync loop and later openings are usually a
    fast state check.
    """
    env = env or {}
    log = _env_log(env)
    t0 = time.time()
    main = env.get("init_db")()
    sconn = sqlite3.connect(env.get("search_db_path")(), timeout=8.0)
    progress = None
    try:
        init_search_db(sconn, performance_indexes=False)
        # v1883 one-time/runtime hygiene: old builds indexed episodes and seasons.
        # Remove them transactionally before any state comparison, otherwise a
        # fast-return would roll the cleanup back when the connection closes.
        prune_cur = sconn.execute("DELETE FROM search_items WHERE COALESCE(plex_type,'') NOT IN ('movie','show')")
        pruned = max(0, int(getattr(prune_cur, "rowcount", 0) or 0))
        if pruned:
            sconn.commit()
            log("SEARCH_INDEX_PRUNE_NON_UI_V1883 removed=%d" % pruned, xbmc.LOGINFO)
        # Create composite indexes only after pruning the legacy episode/season
        # population. This work runs from the deferred post-Search refresh, never
        # from a foreground query.
        _ensure_performance_indexes(sconn)
        sconn.commit()
        log("SEARCH_INDEX_COMPOSITE_READY_V1883 foreground_query=0", xbmc.LOGINFO)
        row = main.execute("SELECT COUNT(*), COALESCE(MAX(synced_at),0) FROM items WHERE COALESCE(plex_type,'') IN ('movie','show')").fetchone()
        source_count = int(row[0] or 0) if row else 0
        source_max = int(row[1] or 0) if row else 0
        srow = sconn.execute("SELECT COUNT(*), COALESCE(MAX(source_synced_at),0) FROM search_items").fetchone()
        search_count = int(srow[0] or 0) if srow else 0
        search_max = int(srow[1] or 0) if srow else 0
        if (not force) and source_count == search_count and search_max >= source_max:
            log("SEARCH_INDEX_READY source_count=%d search_count=%d ms=%d" % (source_count, search_count, int((time.time()-t0)*1000)), xbmc.LOGINFO)
            return search_count
        if (not force) and source_count == search_count and source_max > search_max:
            changed = main.execute("""
                SELECT i.rating_key, i.section_id, COALESCE(s.title,''), i.plex_type, i.kodi_type, i.title, i.original_title, i.sort_title,
                       i.year, i.summary, i.duration, i.added_at, i.updated_at, i.thumb, i.art, i.media_file, i.part_key,
                       i.view_count, i.last_viewed_at, i.parent_rating_key, i.grandparent_rating_key, i.show_title, i.season, i.episode, i.synced_at
                FROM items i LEFT JOIN sections s ON s.section_id=i.section_id
                WHERE i.rating_key IS NOT NULL AND i.rating_key!=''
                  AND COALESCE(i.plex_type,'') IN ('movie','show')
                  AND i.synced_at>?
                ORDER BY i.synced_at ASC
            """, (search_max,)).fetchall()
            for r in changed:
                item = {
                    "rating_key": r[0], "section_id": r[1], "plex_type": r[3], "kodi_type": r[4], "title": r[5], "original_title": r[6], "sort_title": r[7],
                    "year": r[8], "summary": r[9], "duration": r[10], "added_at": r[11], "updated_at": r[12], "thumb": r[13], "art": r[14], "media_file": r[15], "part_key": r[16],
                    "view_count": r[17], "last_viewed_at": r[18], "parent_rating_key": r[19], "grandparent_rating_key": r[20], "show_title": r[21], "season": r[22], "episode": r[23], "synced_at": r[24]
                }
                upsert_search_index_item(sconn, item, section_title=r[2])
            # An equal total before the update does not prove membership is equal:
            # one removed item and one newly added item can keep the same count.
            # Verify the real post-upsert cardinality before publishing a READY
            # state. A mismatch falls through to the replace rebuild below so no
            # stale title can survive in Search.
            actual_count = int((sconn.execute("SELECT COUNT(*) FROM search_items").fetchone() or [0])[0] or 0)
            if actual_count == source_count:
                sconn.execute("INSERT OR REPLACE INTO search_index_state(id, source_count, search_count, source_max_synced_at, indexed_at, last_error) VALUES(1,?,?,?,?, '')", (source_count, actual_count, source_max, int(time.time())))
                sconn.commit()
                log("SEARCH_INDEX_INCREMENTAL_V1883 changed=%d source_count=%d search_count=%d old_max=%d new_max=%d ms=%d" % (
                    len(changed), source_count, actual_count, search_max, source_max, int((time.time()-t0)*1000)
                ), xbmc.LOGINFO)
                return actual_count
            log("SEARCH_INDEX_INCREMENTAL_COUNT_MISMATCH_V1883 changed=%d source_count=%d actual_count=%d action=replace_rebuild" % (
                len(changed), source_count, actual_count
            ), xbmc.LOGWARNING)
            sconn.rollback()
        if show_progress:
            try:
                progress = env.get("create_progress")()
                env.get("progress_create")(progress, env.get("addon_name") or "Plex KM", "검색 DB 구성 중")
            except Exception:
                progress = None
        log("SEARCH_INDEX_REBUILD_BEGIN force=%s source_count=%d search_count=%d source_max=%d search_max=%d scope=movie_show_only_v1883" % (force, source_count, search_count, source_max, search_max), xbmc.LOGINFO)
        # Rebuild means replace, not merge. Count mismatches can include deleted
        # Plex items, so retaining old rows would keep stale search results.
        sconn.execute("DELETE FROM search_items")
        rows = main.execute("""
            SELECT i.rating_key, i.section_id, COALESCE(s.title,''), i.plex_type, i.kodi_type, i.title, i.original_title, i.sort_title,
                   i.year, i.summary, i.duration, i.added_at, i.updated_at, i.thumb, i.art, i.media_file, i.part_key,
                   i.view_count, i.last_viewed_at, i.parent_rating_key, i.grandparent_rating_key, i.show_title, i.season, i.episode, i.synced_at
            FROM items i LEFT JOIN sections s ON s.section_id=i.section_id
            WHERE i.rating_key IS NOT NULL AND i.rating_key!=''
              AND COALESCE(i.plex_type,'') IN ('movie','show')
            ORDER BY i.synced_at ASC
        """)
        done = 0
        batch_commit = 500
        for r in rows:
            item = {
                "rating_key": r[0], "section_id": r[1], "plex_type": r[3], "kodi_type": r[4], "title": r[5], "original_title": r[6], "sort_title": r[7],
                "year": r[8], "summary": r[9], "duration": r[10], "added_at": r[11], "updated_at": r[12], "thumb": r[13], "art": r[14], "media_file": r[15], "part_key": r[16],
                "view_count": r[17], "last_viewed_at": r[18], "parent_rating_key": r[19], "grandparent_rating_key": r[20], "show_title": r[21], "season": r[22], "episode": r[23], "synced_at": r[24]
            }
            upsert_search_index_item(sconn, item, section_title=r[2])
            done += 1
            if done % batch_commit == 0:
                sconn.commit()
                if progress:
                    try:
                        pct = int(min(99, (float(done) / float(max(1, source_count))) * 100.0))
                        progress.update(pct, "검색 DB 구성 중\n%d / %d" % (done, source_count))
                        if progress.iscanceled():
                            break
                    except Exception:
                        pass
        sconn.execute("INSERT OR REPLACE INTO search_index_state(id, source_count, search_count, source_max_synced_at, indexed_at, last_error) VALUES(1,?,?,?,?, '')", (source_count, done, source_max, int(time.time())))
        sconn.commit()
        if progress:
            try:
                progress.update(100, "검색 DB 구성 완료\n%d 항목" % done)
                xbmc.sleep(250)
            except Exception:
                pass
        log("SEARCH_INDEX_REBUILD_DONE rows=%d source=%d ms=%d" % (done, source_count, int((time.time()-t0)*1000)), xbmc.LOGINFO)
        return done
    except Exception as exc:
        try:
            sconn.execute("INSERT OR REPLACE INTO search_index_state(id, last_error, indexed_at) VALUES(1, ?, ?)", (str(exc), int(time.time())))
            sconn.commit()
        except Exception:
            pass
        log("SEARCH_INDEX_REBUILD_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return 0
    finally:
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        main.close()
        sconn.close()


def query_search_index(query, limit=80, scope="all", env=None):
    env = env or {}
    log = _env_log(env)
    scope = str(scope or "all").lower()
    if scope not in ("movie", "tv", "all"):
        scope = "all"
    t0 = time.time()
    q_raw = _compat_hangul_jamo(str(query or "")).lower().strip()
    q_norm = normalize_search_text(query)
    q_compact = q_norm.replace(" ", "")
    q_raw_compact = normalize_search_text(q_raw).replace(" ", "")
    if not q_compact and not q_raw_compact:
        return []
    # Search input must never rebuild the DB synchronously.
    use_cho = is_chosung_query(q_norm) or is_chosung_query(q_raw)
    q_cho = q_compact if use_cho else hangul_chosung(q_norm)
    if not q_cho and q_raw_compact:
        q_cho = q_raw_compact
    like_norm = "%%%s%%" % q_norm
    like_compact = "%%%s%%" % q_compact
    like_cho = "%%%s%%" % q_cho
    prefix_norm = "%s%%" % q_norm
    prefix_cho = "%s%%" % q_cho
    args = []
    if use_cho and q_cho:
        # v702: Pure chosung input such as "ㄱ"/"ㄱㅅ" used to run broad
        # contains-LIKE queries across every normalized title field.  On large
        # libraries this can block the Kodi UI thread for seconds.  Chosung
        # search is intended as a title-start shortcut, so use index-friendly
        # prefix matching on chosung columns only.
        clauses = ["title_chosung LIKE ?", "original_title_chosung LIKE ?", "sort_title_chosung LIKE ?"]
        args.extend([prefix_cho, prefix_cho, prefix_cho])
    else:
        clauses = [
            "title_norm LIKE ?", "original_title_norm LIKE ?", "sort_title_norm LIKE ?",
            "REPLACE(title_norm,' ','') LIKE ?", "REPLACE(original_title_norm,' ','') LIKE ?", "REPLACE(sort_title_norm,' ','') LIKE ?"
        ]
        args.extend([like_norm, like_norm, like_norm, like_compact, like_compact, like_compact])
        if q_cho:
            clauses.extend(["title_chosung LIKE ?", "original_title_chosung LIKE ?", "sort_title_chosung LIKE ?"])
            args.extend([like_cho, like_cho, like_cho])
    conn = sqlite3.connect(env.get("search_db_path")(), timeout=8.0)
    try:
        init_search_db(conn)
        try:
            # All normalized Latin text is stored lowercase. This lets SQLite use
            # the prefix indexes for chosung/title-start queries instead of a full scan.
            conn.execute("PRAGMA case_sensitive_like=ON")
        except Exception:
            pass
        try:
            srow = conn.execute("SELECT COUNT(*), COALESCE(MAX(source_synced_at),0) FROM search_items").fetchone()
            search_count = int(srow[0] or 0) if srow else 0
            search_max = int(srow[1] or 0) if srow else 0
        except Exception:
            search_count = 0
            search_max = 0
        where_sql = " OR ".join(clauses)
        where_args = list(args)
        selected_filter = []
        try:
            selected, configured = env.get("selected_sections_state")()
            selected_filter = [str(x) for x in (selected or []) if str(x)]
            if not configured or not selected_filter:
                log("SEARCH_QUERY_FAST query=%s raw=%s norm=%s compact=%s chosung=%s use_chosung=%s rows=0 search_count=%d search_max=%d ms=%d rebuild=0 selected_filter=empty configured=%d rule=selection_intersection_v1979" % (query, q_raw, q_norm, q_compact, q_cho, 1 if use_cho else 0, search_count, search_max, int((time.time() - t0) * 1000), 1 if configured else 0), xbmc.LOGINFO)
                return []
            where_sql = "(%s) AND section_id IN (%s)" % (where_sql, ",".join(["?"] * len(selected_filter)))
            where_args.extend(selected_filter)
        except Exception:
            log("SEARCH_QUERY_SELECTION_STATE_FAILED_V1979 rows=0 rule=selection_intersection", xbmc.LOGWARNING)
            return []
        # v1775: apply media scope in SQL before LIMIT. Post-filtering a mixed
        # 240-row result starved TV shows for broad chosung queries because
        # movie rows consumed the entire limit first.
        if scope == "movie":
            where_sql = "(%s) AND plex_type=?" % where_sql
            where_args.append("movie")
        elif scope == "tv":
            where_sql = "(%s) AND plex_type=?" % where_sql
            where_args.append("show")
        sql = """
            SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year,
                   summary, duration, added_at, updated_at, thumb, art, media_file, part_key,
                   view_count, last_viewed_at, show_title, season, episode, parent_rating_key, grandparent_rating_key,
                   section_title,
                   CASE
                     WHEN title_norm=? THEN 0
                     WHEN title_norm LIKE ? THEN 1
                     WHEN title_chosung=? THEN 2
                     WHEN title_chosung LIKE ? THEN 3
                     WHEN REPLACE(title_norm,' ','') LIKE ? THEN 4
                     WHEN title_norm LIKE ? THEN 5
                     WHEN title_chosung LIKE ? THEN 6
                     ELSE 9
                   END AS rank
            FROM search_items
            WHERE %s
            ORDER BY rank ASC, plex_type ASC, added_at DESC, title_norm COLLATE NOCASE ASC
            LIMIT ?
        """ % where_sql
        rank_args = [q_norm, prefix_norm, q_cho, prefix_cho, like_compact, like_norm, like_cho]
        rows = conn.execute(sql, rank_args + where_args + [int(limit or 80)]).fetchall()
        elapsed = int((time.time() - t0) * 1000)
        log("SEARCH_QUERY_FAST query=%s raw=%s norm=%s compact=%s chosung=%s use_chosung=%s rows=%d search_count=%d search_max=%d ms=%d rebuild=0 mode=%s scope=%s" % (query, q_raw, q_norm, q_compact, q_cho, 1 if use_cho else 0, len(rows), search_count, search_max, elapsed, "chosung_prefix" if use_cho and q_cho else "normal", scope), xbmc.LOGINFO)
        return rows
    except Exception:
        log("SEARCH_QUERY_FAILED query=%s\n%s" % (query, traceback.format_exc()), xbmc.LOGERROR)
        return []
    finally:
        conn.close()
