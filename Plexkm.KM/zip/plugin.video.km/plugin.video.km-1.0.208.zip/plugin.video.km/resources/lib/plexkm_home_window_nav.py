# -*- coding: utf-8 -*-
"""PKM home window part (R73): 사이드바/포커스/키 입력/종료.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartNavR73
    def _search_busy_passthrough_r95(self):
        """R95: a Search query is a background read.  Its spinner must never
        swallow the next keyboard/tab press (Shield cold query 31s dropped keys);
        the newer input simply supersedes the running query."""
        try:
            if not getattr(self, "_search_inline_active", False):
                return False
            return ":search_query:" in str(pkm_global_busy.current_reason() or "") or str(pkm_global_busy.current_reason() or "").startswith("search_query:")
        except Exception:
            return False

    def _sidebar_gate_renew_if_same_owner_cumulative(self, cache_key, prior_token, bank, render_token):
        """Recover a timed-out logical gate for a valid staged A/B bank.

        This is *not* an extra 15-second data wait: data-only work already
        runs off-GUI. A fresh token allows completing an otherwise good bank.
        Poster/progress atomic checks and stale-generation checks are unchanged.
        """
        if not prior_token or self._section_gate_token_valid_v1794(cache_key, prior_token):
            return prior_token
        try:
            if str(getattr(self, 'active_section_id', '') or '') != str(cache_key or ''):
                return prior_token
            menu_item = self._selected_menu_item()
            if not menu_item or str(menu_item.getProperty('kind') or '') != 'section':
                return prior_token
            if 'recommend:%s' % str(menu_item.getProperty('section_id') or '').strip() != str(cache_key or ''):
                return prior_token
            if not self._section_bank_render_owned_v1844(bank, render_token):
                return prior_token
            # If a newer transaction already owns the gate, do NOT reclaim it.
            active_token = str(getattr(self, '_section_first_visit_gate_token_v1620', '') or '')
            if active_token and active_token != str(prior_token):
                return prior_token
            new_token = self._section_first_visit_gate_begin_v1620(
                cache_key, reason='same_owner_staged_bank_publish',
                force_ui_wait_v1796=True, force_delayed_spinner_v2474=True
            )
            if new_token and self._section_gate_token_valid_v1794(cache_key, new_token):
                _log('SECTION_GATE_SAME_OWNER_RENEW section=%s bank=%s stale_work=0' % (
                    cache_key, bank
                ), xbmc.LOGWARNING)
                return new_token
        except Exception:
            _log('SECTION_GATE_SAME_OWNER_RENEW_FAILED err=%s' % (
                traceback.format_exc().replace(chr(10), ' | ')
            ), xbmc.LOGWARNING)
        return prior_token

    def _focus_pkm_settings_menu_item(self, reason=""):
        try:
            menu = self.getControl(MENU_ID)
            target = -1
            try:
                size = int(menu.size())
            except Exception:
                size = 0
            for pos in range(size):
                try:
                    if menu.getListItem(pos).getProperty("kind") == "addon_settings":
                        target = pos
                        break
                except Exception:
                    pass
            if target < 0:
                target = max(0, size - 1)
            if size > 0:
                menu.selectItem(target)
                self._last_menu_pos = target
                try:
                    self._sync_collapsed_menu_selection()
                except Exception:
                    pass
            self._focus_menu_control_v1993(reason="direct_menu_handoff_v1993")
            self._last_focus_id = MENU_ID
            _log("EMPTY_HOME_FOCUS_PKM_SETTINGS_MENU reason=%s pos=%s" % (reason or "", target))
            return True
        except Exception:
            _log("EMPTY_HOME_FOCUS_PKM_SETTINGS_MENU_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _is_connection_settings_focus_required_v1381(self):
        """True only when there is genuinely no local Home surface to publish.

        v2493: PlexOffline is advisory during startup.  A short /identity timeout
        must never suppress a complete local snapshot/Home render.  Connection
        recovery owns focus only when no local/cached surface exists, or during
        an explicit server-switch transaction.
        """
        try:
            win = xbmcgui.Window(10000)
            if self.getProperty("PlexKM.Home.ServerSwitchPending") == "1" or win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
                return True
            if str(getattr(self, "active_section_id", "") or "") == "__server_switch_pending__":
                return True
            offline = bool(win.getProperty("PlexKM.PlexOffline") == "1" or self.getProperty("PlexKM.PlexOffline") == "1")
            if offline:
                startup_pending = win.getProperty("PlexKM.Home.StartupReadyV1619") != "1"
                local_surface = bool(
                    getattr(self, "sections", None)
                    or getattr(self, "_home_rows_cache", None)
                    or getattr(self, "_section_rows_cache", None)
                    or getattr(self, "_startup_local_home_publishable_v2493", False)
                    or self._home_has_visible_or_cached_rows_v1477()
                )
                if startup_pending and local_surface:
                    if not getattr(self, "_connection_recovery_bypass_logged_v2493", False):
                        self._connection_recovery_bypass_logged_v2493 = True
                        _log("CONNECTION_RECOVERY_STARTUP_LOCAL_BYPASS_V2493 offline=1 startup_pending=1 local_surface=1 action=allow_home_render settings_focus=0")
                    return False
                if local_surface:
                    return False
                return True
        except Exception:
            pass
        return False

    def _force_connection_settings_focus_v1381(self, reason=""):
        """v1381: keep sidebar focus usable when Plex connection fails.

        Select the Plex KM settings row, expand the sidebar, and focus list 9000.
        This is intentionally not used during normal online browsing.
        """
        try:
            try:
                self.setProperty("PlexKM.Sidebar.Expanded", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.Sidebar.Expanded", "1")
            except Exception:
                pass
            ok = self._focus_pkm_settings_menu_item(reason="connection_recovery_" + str(reason or ""))
            _log("CONNECTION_RECOVERY_FOCUS_SETTINGS_V1381 reason=%s ok=%s focus_id=%s" % (reason or "", "1" if ok else "0", self._safe_focus_id()))
            return ok
        except Exception:
            _log("CONNECTION_RECOVERY_FOCUS_SETTINGS_FAILED_V1381 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _schedule_connection_settings_focus_guard_v1381(self, reason=""):
        try:
            def _guard():
                try:
                    monitor = xbmc.Monitor()
                    for delay in (80, 260, 650, 1200):
                        xbmc.sleep(delay)
                        if monitor.abortRequested():
                            return
                        try:
                            if not xbmcgui.Window(10000).getProperty("PlexKM.HomeWindowActive"):
                                return
                        except Exception:
                            pass
                        if not self._is_connection_settings_focus_required_v1381():
                            return
                        fid = self._safe_focus_id()
                        if fid <= 0 or fid == 100:
                            self._force_connection_settings_focus_v1381("guard_" + str(reason or ""))
                except Exception:
                    _log("CONNECTION_RECOVERY_FOCUS_GUARD_FAILED_V1381 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            _PKMHomeThreadV2151(target=_guard, name="PlexKMConnectionFocusGuardV1381", daemon=True).start()
        except Exception:
            pass

    def _focus_menu_control_v1993(self, pos=None, reason=""):
        """Focus the populated sidebar list by control object, never by raw id.

        Kodi can expose WindowXML before control 9000 is instantiated and can
        transiently report focus 0 after mouse movement.  Raw setFocusId(9000)
        in those windows either raises Non-Existent Control or leaves focus on
        bootstrap control 100.  Resolve the actual control, verify it contains
        items, select the intended item, then hand focus to that object.
        """
        try:
            menu = self.getControl(MENU_ID)
            size = int(menu.size() or 0)
            if size <= 0:
                return False
            if pos is None:
                try:
                    pos = int(menu.getSelectedPosition())
                except Exception:
                    pos = int(getattr(self, "_last_menu_pos", 0) or 0)
            pos = max(0, min(int(pos), size - 1))
            menu.selectItem(pos)
            try:
                collapsed = self.getControl(MENU_COLLAPSED_ID)
                if int(collapsed.size() or 0) > pos:
                    collapsed.selectItem(pos)
            except Exception:
                pass
            self._last_menu_pos = pos
            self.setFocus(menu)
            self._last_focus_id = MENU_ID
            return self._safe_focus_id() == MENU_ID
        except Exception:
            _log("FOCUS_MENU_CONTROL_V1993_FAILED reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _recover_lost_focus_on_key_r155(self, aid):
        """R155: ONE key-triggered lost-focus repair. Never override valid focus.

        Kodi handles normal navigation in the XML. This runs only when Kodi
        reports no focus owner, after the PKM scene is ready and no modal/video
        owns the keys. We do not infer a lost focus from a missing white border.
        """
        if aid not in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP,
                       ACTION_MOVE_DOWN, ACTION_SELECT_ITEM):
            return False
        try:
            focus_before_r155 = int(self.getFocusId() or 0)
            # ID 100 is PKM's 1x1 offscreen internal ping button, not a
            # user-visible focus target once Home is ready.
            if (focus_before_r155 > 0 and focus_before_r155 != SIDEBAR_COMMIT_PING_ID_V2595
                    and not self._focus_on_retired_surface_r34(focus_before_r155)):
                return False
            if self._closing_event_v1841.is_set():
                return False
            win = xbmcgui.Window(10000)
            if (win.getProperty("PlexKM.Home.StartupReadyV1619") != "1"
                    or win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                    or win.getProperty("PlexKM.Playback.OpeningActive") == "1"
                    or _pkm_full_reset_active_v2150()):
                return False
            if xbmc.getCondVisibility("System.HasModalDialog") or xbmc.getCondVisibility("Player.HasVideo"):
                return False
            # R36: Kodi assigns Python window ids in sequence (13000, 13001...),
            # so the hardcoded 13000 silently disabled recovery after any other
            # add-on window had been opened first.
            if not self._pkm_window_owned_r34():
                return False
            prior = int(getattr(self, "_r155_last_valid_focus", 0) or 0)
            candidates = []
            inline = (self.getProperty("PlexKM.Info.InlineActive") == "1"
                      or win.getProperty("PlexKM.Info.InlineActive") == "1")
            if inline and not self._actor_profile_is_active_v2454():
                # R34: on TV Info the canonical focus owner is the visible
                # episode thumbnail rail (same proven-visible path as entry).
                is_tv_r34 = (self.getProperty("PlexKM.Info.IsTV") == "1"
                             or win.getProperty("PlexKM.Info.IsTV") == "1")
                if is_tv_r34:
                    try:
                        target_r34 = int(self._info_tv_active_episode_control_id())
                        if target_r34 in (5712, 5713) and self._info_tv_focus_panel(target_r34, reason="r155_lost_focus_r34"):
                            self._r155_last_valid_focus = target_r34
                            self._last_focus_id = target_r34
                            _log("R155_LOST_FOCUS_RECOVER action=%s from=%s to=%d scene=info_tv_episodes_r34" % (
                                aid, focus_before_r155, target_r34))
                            return True
                    except Exception:
                        pass
            if inline and not self._actor_profile_is_active_v2454():
                if prior in (5001, 5002, 5003, 5004, 5005, 5006, 5007,
                             5008, 5009, 5711, 5712, 5713, 5721, 5722,
                             5724, 5725, 5726, 5727, 5728, 5729, 5730,
                             6100, 6110, 6310, 6320, 6330, 6340):
                    candidates.append(prior)
                is_tv = (self.getProperty("PlexKM.Info.IsTV") == "1"
                         or win.getProperty("PlexKM.Info.IsTV") == "1")
                candidates.append(5721 if is_tv else 5001)
            elif self._actor_profile_is_active_v2454():
                if prior in (6500, 6510, 6486, 6487):
                    candidates.append(prior)
                candidates.append(6500)
            elif getattr(self, "_search_inline_active", False):
                if prior in SEARCH_RESULT_IDS or prior in SEARCH_TAB_SCOPES or prior in (SEARCH_KEYBOARD_ID, SEARCH_QUERY_PILL_ID):
                    candidates.append(prior)
                candidates.extend((SEARCH_BEST_ID, SEARCH_RESULTS_ID, 4010, 4020, 4001, 4011, 4021, SEARCH_KEYBOARD_ID))
            elif self.getProperty("PlexKM.Window.IsSectionWall") == "1":
                if prior in (WALL_ID, SECTION_INDEX_ID, SECTION_SORT_BUTTON_ID) or prior in SECTION_SORT_ITEM_IDS:
                    candidates.append(prior)
                candidates.append(WALL_ID)
            else:
                if prior == MENU_ID or self._is_home_row_control(prior):
                    candidates.append(prior)
                candidates.append(MENU_ID)
            for target in candidates:
                try:
                    ctrl = self.getControl(int(target))
                    if not ctrl.isVisible():
                        continue
                    self.setFocusId(int(target))
                    actual = int(self.getFocusId() or 0)
                    if actual == int(target):
                        self._r155_last_valid_focus = int(target)
                        _log("R155_LOST_FOCUS_RECOVER action=%s from=0 to=%d scene=%s" % (
                            aid, actual, self.active_section_id or ""))
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def _on_action_impl_r26(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        aid = action.getId()
        # R106: a key after a sidebar ENTER restores the instantly-folded card
        # (it is only meant to hide the menu while the ENTER commit runs).
        if aid not in (7, 100) and self.getProperty("PlexKM.Sidebar.EnterFoldR106"):
            self._sidebar_enter_fold_r106(False, reason="key_%s" % aid)
        if bool(getattr(self, "_initial_compose_r57_active", False)):
            # R57: Home is hidden under the initial-compose overlay; keys must not
            # move focus or open anything underneath it.
            try:
                if self.getFocusId() != _R57_OVERLAY_FOCUS_ID:
                    self.setFocusId(_R57_OVERLAY_FOCUS_ID)
            except Exception:
                pass
            return
        # V2600 diagnostics: input callback is counter-only. No logging, DB,
        # network or control traversal beyond the already-read focus id is done.
        try:
            pkm_uhd_diag_v2600.note_input(
                aid, focus_id=self._safe_focus_id(),
                surface=str(getattr(self, "active_section_id", "") or "")
            )
        except Exception:
            pass
        # v2386: publish a passive user-activity timestamp for DATA workers only.
        # This property never consumes/delays a key and never writes Kodi focus.
        # Background DB/network workers use it to stay out of the navigation path.
        self._last_input_mono_r85 = time.monotonic()
        try:
            _nav_now_epoch_v2386 = int(time.time() * 1000)
            _nav_win_v2386 = xbmcgui.Window(10000)
            _nav_win_v2386.setProperty("PlexKM.Home.LastUserActionEpochMsV2386", str(_nav_now_epoch_v2386))
            _nav_quiet_v2591 = 5000 if xbmc.getCondVisibility("System.Platform.Android") else 1800
            _nav_win_v2386.setProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386", str(_nav_now_epoch_v2386 + _nav_quiet_v2591))
            if _nav_quiet_v2591 != 1800:
                _nav_win_v2386.setProperty("PlexKM.UHD3.ForegroundIsolationV2591", "1")
        except Exception:
            pass
        # U2: use monotonic timestamp for same-bank background admission.
        # The existing WindowXML navigation remains the sole focus mover.
        if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
                   ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self._section_fill_last_nav_mono_u2 = time.monotonic()
        # R157: only a visible rail near its loaded edge may bypass U2 idle gating.
        # Never move Kodi focus and never request a full-rail foreground bind.
        if aid in (ACTION_MOVE_RIGHT, ACTION_MOVE_DOWN):
            self._section_tail_nav_hint_r157(aid)
        # PKM_UHD_NAV_GUARD_U3_20261011: fast cancellation boundary for all *optional* prewarmers.
        # Exactly one cheap signal per user input; foreground images remain allowed.
        try:
            _u3_sidebar = int(self._safe_focus_id() or 0) == int(MENU_ID)
            pkm_sort_index_v2626.note_navigation_u3(sidebar=_u3_sidebar)
            pkm_artwork_scheduler.note_navigation_u3(sidebar=_u3_sidebar)
        except Exception:
            pass
        # v2512: the exact Home display is only the entry continuity owner.
        # Once the user starts navigating inside Info, retire that hold so TV
        # episode A/B metadata can follow the native selection normally.
        try:
            if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN):
                _w_v2512 = xbmcgui.Window(10000)
                if (
                    _w_v2512.getProperty("PlexKM.Info.InlineActive") == "1"
                    and _w_v2512.getProperty("PlexKM.Info.EntryHomeVisualHoldV2512") == "1"
                ):
                    self._info_clear_property_all("PlexKM.Info.EntryHomeVisualHoldV2512")
                    _log("INFO_HOME_VISUAL_HOLD_RELEASE_V2512 action=%s reason=first_info_navigation" % aid)
        except Exception:
            pass

        # v2224: Back during a pre-AV opening is a user cancellation. If Kodi's
        # playback-failure dialog has just closed, its onunload route sets an
        # explicit Home request and sends this same Back to the live WindowXML.
        # Handle it before global-busy/input ownership so a dead opening spinner
        # can never swallow the user's escape route.
        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
            try:
                win_v2224 = xbmcgui.Window(10000)
                request_v2224 = win_v2224.getProperty("PlexKM.Playback.FailureHomeRequestV2224") == "1"
                opening_v2224 = (
                    win_v2224.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
                    or win_v2224.getProperty("PlexKM.Playback.OpeningActive") == "1"
                )
                try:
                    video_v2224 = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                except Exception:
                    video_v2224 = False
                if request_v2224 or (opening_v2224 and not video_v2224):
                    source_v2224 = win_v2224.getProperty("PlexKM.Playback.FailureHomeRequestSourceV2224") or ("user_back" if not request_v2224 else "failure_request")
                    self._recover_failed_opening_to_home_v2224(reason=source_v2224)
                    return
            except Exception:
                _log("PLAYBACK_FAILURE_BACK_RECOVERY_FAILED_V2224 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        # v2151: after destructive reset this live Home is a local first-run
        # shell only.  Native XML may still move focus, but Python must not
        # consume dirty flags, query DB state, prewarm, or rebuild media rows.
        if _pkm_full_reset_active_v2150():
            return
        # v1887: v1885 removed the external modal dialog, therefore a Python
        # return cannot block Kodi's native XML list movement.  Treating it as an
        # input lock caused the sidebar selection to move while active_menu_index
        # and the published A/B scene stayed on the previous library.  Kodi XML
        # remains the sole navigation owner; sidebar movement is allowed through
        # the common busy surface and immediately supersedes stale section work.
        try:
            if pkm_global_busy.should_block_action(aid) and not self._search_busy_passthrough_r95():
                _busy_focus_v2067 = self._safe_focus_id()
                # v2067: the busy surface is visual feedback only; it must never
                # own directional focus. Kodi XML remains the sole navigation
                # owner on menu, tabs and content. A user move therefore always
                # supersedes stale visual work instead of being swallowed.
                _native_nav_v2067 = aid in (
                    ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
                    ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_MOUSE_WHEEL_UP,
                    ACTION_MOUSE_WHEEL_DOWN, ACTION_MOUSE_MOVE,
                )
                if _native_nav_v2067:
                    _log("GLOBAL_BUSY_NATIVE_NAV_CONTINUE_V2067 window=home action=%s reason=%s focus=%s active_menu_index=%s" % (
                        aid, pkm_global_busy.current_reason(), _busy_focus_v2067,
                        getattr(self, "active_menu_index", -1),
                    ))
                else:
                    _log("GLOBAL_BUSY_ACTION_BLOCK_V2067 window=home action=%s reason=%s focus=%s" % (
                        aid, pkm_global_busy.current_reason(), _busy_focus_v2067
                    ))
                    return
        except Exception:
            pass
        # v1645: post-reveal Cine21 work yields to every real user action.
        # This timestamp is data-worker ownership state only; it does not move
        # focus, suppress keys, or delay UI navigation.
        try:
            self._last_action_ms = _pkm_speed_ms()
        except Exception:
            self._last_action_ms = int(time.time() * 1000)
        # V2671: directional navigation is a pure Kodi-native hot path.
        # Do not even poll deferred sync/playstate properties for every repeat key;
        # those states are consumed on non-directional actions / natural Home entry.
        _nav_only_v2671 = aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN)
        if not _nav_only_v2671:
            try:
                self._consume_sync_widget_refresh_gui_v1555(reason="onAction")
            except Exception:
                pass
            try:
                self._consume_playstate_dirty(reason="onAction")
            except Exception:
                pass

        # v093: Home widgets are XML row lists.  Handle their navigation before
        # Kodi can fall back to the old flattened panel behavior.
        try:
            fid0 = self.getFocusId()
        except Exception:
            fid0 = -1
        # R155: only a *missing* Kodi focus owner can trigger recovery.
        # A valid control ID is never corrected/overridden by Python.
        # R34: focus on a control of a surface that is no longer up counts as lost.
        if (int(fid0 or 0) in (0, -1, SIDEBAR_COMMIT_PING_ID_V2595) or self._focus_on_retired_surface_r34(fid0)) and self._recover_lost_focus_on_key_r155(aid):
            return
        # V2591: preserve XML navigation ownership. Only ensure a small runway
        # exists before Kodi moves RIGHT beyond the Android startup bind cap.
        if aid == ACTION_MOVE_RIGHT and fid0 in HOME_ROW_IDS:
            try:
                _ctrl_v2591 = self.getControl(fid0)
                _size_v2591 = int(_ctrl_v2591.size() or 0)
                _pos_v2591 = int(_ctrl_v2591.getSelectedPosition() or 0)
                if _size_v2591 > 0 and _pos_v2591 >= max(0, _size_v2591 - 2):
                    self._home_lazy_append_row_v2591(fid0, chunk=6)
            except Exception:
                pass
        # v2481: native LEFT/RIGHT inside one cast panel may not fire onFocus
        # again. Capture the exact next actor before Kodi advances selection, then
        # debounce all slow work off the GUI thread.
        if fid0 in (6100, 6110) and aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
            try:
                self._schedule_actor_profile_direction_target_v2481(
                    fid0, aid, reason="cast_direction_v2481"
                )
            except Exception:
                pass

        # v2383: if post-visible actor data became ready while focus remained on
        # the cast row, bind the still-offscreen rows before Kodi processes the
        # same native UP/DOWN action. This never runs the DB query on the GUI thread.
        if aid in (ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            try:
                # ActorProfile owns 6500/6510 natively. Running the parent
                # Info actor-row commit on the same DOWN frame can bind rows/textures
                # while Kodi is animating the actor rail, producing the U+ frame drop.
                if not self._actor_profile_is_active_v2454():
                    self._info_widget_rebuild_try_commit_v2082(
                        focus_id=fid0, reason="onaction_pre_native_v2383"
                    )
                else:
                    _log("ACTOR_PROFILE_NAV_HOTPATH action=%s focus=%s info_row_commit=0 python_focus_write=0" % (aid, fid0))
            except Exception:
                pass

        # v2454 Actor Profile is a view layered over the current Info. Back always
        # removes only this view and returns to the exact cast item on the unchanged
        # parent Info. Selecting a work discards Actor Profile and uses normal Info.
        if self._actor_profile_is_active_v2454():
            # R93: the biography overlay owns Back/OK while it is open.
            if self._actor_profile_bio_popup_is_open_r93():
                if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                    self._actor_profile_close_bio_popup_r93()
                    return
                if aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                    return  # onClick(6487) closes it
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                self._actor_profile_close_to_parent_info_v2454(reason="back")
                return
            if aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                if fid0 in (6500, 6510):
                    self._actor_profile_open_selected_work_v2454(reason="action_select_work")
                    return
                if fid0 == 6486:
                    # R92: 더보기 is a native button; onClick opens the popup.
                    return
            # Sidebar navigation remains Kodi/XML-owned; no actor-specific
            # directional movement is implemented in Python.

        # Kodi platforms do not all deliver panel activation through onClick.
        # Accept SELECT on the movie/TV cast panel as the same actor-page action.
        if (not self._actor_profile_is_active_v2454()
                and fid0 in (6100, 6110)
                and aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK)
                and (self.getProperty("PlexKM.Info.InlineActive") == "1"
                     or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1")):
            self._actor_profile_open_from_cast_v2454(fid0, reason="action_select_cast")
            return

        # v2237: show-level next-episode fallback chooser is draft-until-confirm.
        # Back closes only this popup and restores its action icon.
        try:
            if self.getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1":
                if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                    self._info_tv_close_next_timing_v2236(restore_focus=True, reason="back_discard")
                    return
        except Exception:
            pass

        # v2112: TV media-version popup has its own list/property and never
        # changes the movie popup/include visibility graph.
        try:
            if self.getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1":
                if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                    self._info_tv_close_media_versions_v2112(restore_focus=True, reason="back")
                    return
        except Exception:
            pass

        # v2104: movie media-version chooser is an inline list owned by this
        # Home WindowXML.  Back closes only the small popup and returns focus to
        # its action icon; no modal window, dim layer, or background replacement
        # is ever created.
        try:
            if self.getProperty("PlexKM.Info.MediaVersionPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.MediaVersionPopupOpen") == "1":
                if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                    self._info_movie_close_media_versions_v2104(restore_focus=True, reason="back")
                    return
        except Exception:
            pass

        # v1860: the in-window sort menu is twelve real Kodi button controls.
        # Direction keys and Enter are therefore handled by Kodi XML/onClick with
        # an unambiguous control id. Python only closes the menu on Back here.
        if self.getProperty("PlexKM.Section.SortDropdownOpen") == "1":
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                self._close_section_sort_inline(restore_focus=True, reason="back_v1860")
                return

        # v1654: cold-section RIGHT ownership lives in the XML navigation graph.
        # Do not intercept the action here and never force focus back from a stale
        # widget bank; that post-navigation repair caused focus/bank ownership races.

        try:
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                    self._inline_info_diag_log(phase="action", reason=self._home_action_name(aid), action_id=aid)
        except Exception:
            pass

        # v2086: onClick(actor-work) synchronously composes the child Info, then
        # Kodi delivers the same SELECT to onAction. By that time InlineActive is
        # already the child surface while native focus can still be the source row.
        # The legacy v1886 Home-row recovery below would issue a second entry-focus
        # request. That splits ownership across two callbacks and exposes the exact
        # stale-focus frame seen in the runtime log. The reentrant transaction already
        # owns the one legitimate entry-focus handoff, so consume only this matching
        # trailing SELECT/INFO action.
        try:
            _reentrant_actor_select_v2086 = (
                fid0 in INFO_ACTOR_WORK_ROW_IDS_V2082
                and aid in (ACTION_SHOW_INFO, ACTION_CONTEXT_MENU, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK)
                and (
                    xbmcgui.Window(10000).getProperty("PlexKM.Info.EntrySwapV2087") == "1"
                )
            )
            if _reentrant_actor_select_v2086:
                _log("INLINE_INFO_REFOCUS_SKIP_V2087 reason=actor_work_select_owned_by_common_entry_pipeline from=%s action=%s target=%s" % (
                    fid0, self._home_action_name(aid), self._inline_info_focus_target_v1886()
                ))
                return
        except Exception:
            pass

        # v1331: after opening movie Info, Kodi can briefly keep focus on the
        # originating Home row until the inline include finishes becoming visible.
        # A quick second OK then re-enters _show_info() and trips duplicate_guard,
        # which makes the Info screen feel broken.  While Info is active, a row
        # SELECT/INFO action must be treated as a focus recovery into Info, not as
        # another request to open Info over itself.
        try:
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                if (self._is_home_row_control(fid0) or fid0 == WALL_ID) and aid in (ACTION_SHOW_INFO, ACTION_CONTEXT_MENU, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                    # v1886 root fix: episode Info may publish buffer B (5713).
                    # The old v1331 recovery always requested 5712, which is hidden
                    # whenever B is active. Kodi then logged "can't focus" and
                    # eventually fell back to Home control 100, leaving no visible
                    # Info focus. Resolve the actual visible A/B panel instead.
                    # v2344: a trailing SELECT/INFO from the source Home row
                    # must recover to the visible top play control, never to the
                    # selected episode rail. The rail selection is already staged
                    # and DOWN from 5721 enters it natively.
                    _is_tv_refocus_v2344 = (
                        self.getProperty("PlexKM.Info.IsTV") == "1"
                        or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
                    )
                    # v2407: the trailing SELECT/INFO delivered after a TV Info open
                    # must recover to the already-published episode A/B rail, not to
                    # the play button.  V2406 already selected resume > first unwatched
                    # > first episode in the hidden bank; this is the one visible-owner
                    # handoff that prevents legacy v2344 from stealing focus back.
                    if _is_tv_refocus_v2344:
                        _tv_rows_empty_v2407 = (
                            self.getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                            or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVRowsEmpty") == "1"
                        )
                        _target = 5721 if _tv_rows_empty_v2407 else int(self._info_tv_active_episode_control_id())
                    else:
                        _target = self._inline_info_focus_target_v1886()
                    _focus_ok = False
                    try:
                        self.setFocusId(_target)
                        self._last_focus_id = _target
                        _focus_ok = True
                    except Exception:
                        _focus_ok = False
                    try:
                        _active_buffer_v1886 = (
                            self.getProperty("PlexKM.Info.TVActiveBuffer")
                            or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVActiveBuffer")
                            or ""
                        )
                    except Exception:
                        _active_buffer_v1886 = ""
                    _log("INLINE_INFO_REFOCUS_FROM_ROW_V2407 reason=%s from=%s target=%s active_buffer=%s ok=%d tv_episode_owner=%d" % (
                        self._home_action_name(aid), fid0, _target,
                        _active_buffer_v1886 or "-", 1 if _focus_ok else 0,
                        1 if _is_tv_refocus_v2344 else 0
                    ))
                    return
        except Exception:
            pass

        # v2074: Info action-row DOWN must focus the same cast control that the
        # population path owns. Movie uses 6100; TV uses isolated 6110. The old
        # v915 hardcoded 6100 after _populate_info_cast_panel() had populated 6110
        # for TV, producing a visible focus loss (Kodi: control 6100 can't focus).
        # Keep this as a single source of truth via _info_cast_control_id_v2074().
        try:
            if (self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1") and aid == ACTION_MOVE_DOWN:
                if fid0 in (5001, 5002, 5004, 5005, 5006, 5007):
                    added = self._populate_info_cast_panel(cast_items=None, reason="down_from_action_v2074")
                    if added > 0:
                        cast_focus_id_v2074 = self._info_cast_control_id_v2074()
                        try:
                            self.setFocusId(cast_focus_id_v2074, 0)
                        except TypeError:
                            self.setFocusId(cast_focus_id_v2074)
                        _log("CAST_PANEL_FOCUS_V2074 reason=down_from_action added=%d from=%s target=%s" % (
                            added, fid0, cast_focus_id_v2074
                        ))
                        return
        except Exception:
            _log("CAST_PANEL_FOCUS_FAILED_V2074 reason=down_from_action err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        # v600: no playback action shield/back-stop interception here.
        # Kodi fullscreen player owns remote keys during playback.  PKM Home
        # must not swallow navigation/select or convert Back into Player.stop().

        # Inline search owns only open/close/click behavior.  Directional movement
        # inside keyboard/results is left to Kodi XML, not Python.
        if getattr(self, "_search_inline_active", False):
            try:
                # R101: Kodi delivers queued actions re-entrantly while
                # _open_inline_search waits in the A/B swap.  The flag is set
                # before the InlineActive property, so such a nested action saw
                # "flag on, property off" and switched Search off for good: on
                # Shield every keyboard OK did nothing and Back opened the exit
                # dialog.  Never reset while Search is still opening.
                if (self.getProperty("PlexKM.Search.InlineActive") != "1"
                        and not getattr(self, "_search_opening_r101", False)):
                    self._search_inline_active = False
                    _log("INLINE_SEARCH_STATE_RESET_R101 aid=%s reason=property_cleared" % aid)
            except Exception:
                pass
        if getattr(self, "_search_inline_active", False):
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, 92, 216):
                # Android/U+ commonly reports remote Back as 92/216.
                # Search must consume those ids before the Home exit path sees them.
                # v1778: Search remains active underneath inline Info so that
                # Info Back can restore the exact search control/item.  The old
                # ordering closed Search first whenever both overlays were active,
                # then the later Info Back handler had no search surface left and
                # fell back to Home.  Let the dedicated inline-Info Back path below
                # own this key while Info is visible; close Search only when Search
                # itself is the topmost surface.
                _info_active_v1778 = (
                    self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
                )
                if not _info_active_v1778:
                    if self.getProperty("PlexKM.Search.KbOpen") == "1" and self.getProperty("PlexKM.Search.HasResults") == "1":
                        self._search_kb_set_r96(False, reason="back")
                        return
                    self._close_inline_search(reason="back")
                    return
                _log("INLINE_SEARCH_BACK_DEFER_TO_INFO_V1778 focus=%s query=%s" % (
                    self._safe_focus_id(),
                    _short_log_value(getattr(self, "_search_query", "") or "", 80),
                ))
            else:
                # v1771: Kodi does not consistently emit WindowXML.onClick() for
                # panel item activation on every platform.  Handle OK/Enter and
                # mouse click at the action boundary while the focused control is
                # one of the two search-result panels.  Directional navigation
                # remains XML-owned.
                if aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                    search_focus_id = self._safe_focus_id()
                    # Some Android/U+ builds move/select the virtual keyboard
                    # without emitting WindowXML.onClick(). Treat SELECT on the
                    # keyboard as the same key activation, but do not move focus in Python.
                    if search_focus_id == SEARCH_KEYBOARD_ID:
                        if not self._search_select_begin_r74(search_focus_id, "action"):
                            return
                        self._search_handle_key_click()
                        self._search_select_end_r74(search_focus_id, "action")
                        _log("INLINE_SEARCH_KEY_ACTION focus=%s action=%s route=keyboard_click" % (search_focus_id, aid))
                        return
                    if search_focus_id == SEARCH_QUERY_PILL_ID or search_focus_id in SEARCH_SUG_IDS:
                        if not self._search_select_begin_r74(search_focus_id, "action"):
                            return
                        if search_focus_id == SEARCH_QUERY_PILL_ID:
                            self._search_kb_set_r96(True, reason="pill_action")
                        else:
                            self._search_apply_suggestion_r96(search_focus_id)
                        self._search_select_end_r74(search_focus_id, "action")
                        return
                    if search_focus_id in SEARCH_TAB_SCOPES:
                        if not self._search_select_begin_r74(search_focus_id, "action"):
                            return
                        self._search_set_scope(SEARCH_TAB_SCOPES[search_focus_id], reason="tab_action")
                        self._search_select_end_r74(search_focus_id, "action")
                        return
                    if search_focus_id == SEARCH_HISTORY_ID:
                        if not self._search_select_begin_r74(search_focus_id, "action"):
                            return
                        self._search_handle_history_click()
                        self._search_select_end_r74(search_focus_id, "action")
                        return
                    if search_focus_id == SEARCH_HISTORY_CLEAR_ID:
                        if not self._search_select_begin_r74(search_focus_id, "action"):
                            return
                        self._search_clear_history(reason="action_clear")
                        self._search_select_end_r74(search_focus_id, "action")
                        return
                    if search_focus_id in SEARCH_RESULT_IDS:
                        self._search_open_selected_result_info(control_id=search_focus_id, reason="action_select_v1771")
                        return
                # v1883: Kodi XML still owns the directional move. Python does not
                # predict or move focus; it only debounces the final actual selection
                # and prepares actor images after the user has stopped navigating.
                if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN):
                    search_focus_id = self._safe_focus_id()
                    if search_focus_id in SEARCH_RESULT_IDS:
                        self._search_schedule_direction_target_cast_v1878(search_focus_id, aid)
                # Search owns the overlay while active.  Prevent Home lost-focus
                # recovery/sidebar logic from running underneath it.
                return

        # v756: Sort button short click cycles sort type through onClick().
        # Long press OK / context menu toggles ascending/descending on the current sort.
        if fid0 == SECTION_SORT_BUTTON_ID and aid == ACTION_CONTEXT_MENU:
            self._toggle_section_sort_dir(reason="context_or_longpress")
            return


        # v126: if Kodi loses focus during/after startup row construction,
        # restore to Home menu before interpreting the key.
        # v457: Inline Info is an overlay with its own focus targets.  When Kodi
        # briefly reports focus_id<=0 during TV panel visibility changes, do not
        # fall back to the Home sidebar because that makes the sidebar visibly
        # jump over the Info screen.  Restore only the current Info entry target.
        if fid0 <= 0:
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                # v458: Do not repair TV focus from Python.  The root cause was
                # attempting to focus 5711/5712 before the inline Info group was
                # visible.  If focus is temporarily invalid while Info is active,
                # let Back handling continue; swallow only non-back actions so Home
                # row/menu recovery cannot run underneath the Info overlay.
                if aid not in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                    _log("INLINE_INFO_LOST_FOCUS_IGNORE reason=inline_active aid=%s" % aid)
                    return
            else:
                # v1381: when Plex is offline/server-switch-pending there are no
                # poster rows to recover to.  Restoring Home here makes the sidebar
                # look alive but immediately rebuilds an empty Home and users cannot
                # reach settings.  Recover directly to Plex KM 설정 instead.
                if self._is_connection_settings_focus_required_v1381():
                    if self._force_connection_settings_focus_v1381("onaction_lost_focus_connection_recovery"):
                        return
                # v1850 root ownership split: Kodi XML is the sole owner of
                # sidebar focus and selected position during normal navigation.
                # WindowXML.onAction can observe focus_id=0 for one render frame
                # after the native list has already moved (for example pos 1 -> 2).
                # The old Python recovery selected Home and called setFocusId(),
                # overwriting Kodi's valid result and consuming the user's next key.
                # Runtime invalid-focus samples are therefore observational only.
                # Python may seed Home focus only while the startup focus lock is
                # still active or before the dynamic menu is ready.
                startup_lock_active_v1850 = False
                try:
                    startup_lock_active_v1850 = (
                        not bool(getattr(self, "menu_ready", False))
                        or self._now_ms() < int(getattr(self, "_startup_focus_lock_until_ms", 0) or 0)
                    )
                except Exception:
                    startup_lock_active_v1850 = not bool(getattr(self, "menu_ready", False))
                if startup_lock_active_v1850:
                    if self._force_home_menu_focus("startup_only_invalid_focus_v1850", select_home=True):
                        return
                else:
                    # v1993: ACTION_MOUSE_MOVE can clear Kodi's focus after the
                    # startup/reset handoff even though list 9000 remains populated.
                    # Re-focus the actual list control object once on that event;
                    # this is event-driven, not a timer/guard loop.
                    if aid == ACTION_MOUSE_MOVE:
                        try:
                            menu_v1993 = self.getControl(MENU_ID)
                            size_v1993 = int(menu_v1993.size() or 0)
                            if size_v1993 > 0:
                                pos_v1993 = int(menu_v1993.getSelectedPosition())
                                if self._focus_menu_control_v1993(
                                        pos=pos_v1993, reason="mouse_move_invalid_focus_v1993"):
                                    return
                        except Exception:
                            pass
                    # v1887: focus_id=0 is observational, but the native list's
                    # selected position is still authoritative.  Mouse hover,
                    # wheel input, or a direction action received during the
                    # active-window busy surface may have moved it already.
                    if self._sync_sidebar_selection_owner_v1887(
                            aid=aid, reason="runtime_invalid_focus_v1887"):
                        return
                    try:
                        menu_v1850 = self.getControl(MENU_ID)
                        size_v1850 = int(menu_v1850.size() or 0)
                        pos_v1850 = int(menu_v1850.getSelectedPosition()) if size_v1850 > 0 else -1
                        label_v1850 = ""
                        if 0 <= pos_v1850 < size_v1850:
                            label_v1850 = menu_v1850.getListItem(pos_v1850).getLabel() or ""
                        _log("SIDEBAR_XML_OWNS_RUNTIME_FOCUS_V1850 aid=%s focus_id=%s pos=%s size=%s label=%s active_menu_index=%s no_python_focus_write=1" % (
                            aid, fid0, pos_v1850, size_v1850, _short_log_value(label_v1850),
                            getattr(self, "active_menu_index", -1),
                        ))
                    except Exception:
                        _log("SIDEBAR_XML_OWNS_RUNTIME_FOCUS_LOG_FAILED_V1850 aid=%s err=%s" % (
                            aid, traceback.format_exc().replace(chr(10), " | "),
                        ), xbmc.LOGWARNING)
                    # Back remains handled below. All other actions are left to
                    # Kodi's native XML/navigation state without any selectItem()
                    # or setFocusId() call from Python.
                    if aid not in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                        return

        # v246: sidebar order edit mode.  Long-press OK / context menu on a
        # library section enters edit mode; UP/DOWN moves that selected section;
        # OK commits the order.  Keep normal Kodi native menu movement untouched
        # when edit mode is not active.
        if fid0 == MENU_ID and getattr(self, "_menu_reorder_mode", False):
            if aid == ACTION_MOVE_UP:
                self._move_menu_reorder_item(-1)
                return
            if aid == ACTION_MOVE_DOWN:
                self._move_menu_reorder_item(1)
                return
            if aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_CONTEXT_MENU):
                self._finish_menu_reorder(save=True, reason="select_commit")
                return
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
                self._finish_menu_reorder(save=False, reason="back_cancel")
                return

        if fid0 == MENU_ID and aid == ACTION_CONTEXT_MENU:
            if self._start_menu_reorder():
                return

        # v1852: Directional movement in the section header is handled only by
        # Kodi XML.  Do not return from onAction here: returning at the Python
        # boundary left the header in an intermediate state on some platforms.
        # Python only observes the action; Kodi resolves onleft/onright/onup/ondown.
        if fid0 in (SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID, SECTION_TAB_CATEGORY_ID):
            if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
                       ACTION_PAGE_UP, ACTION_PAGE_DOWN):
                _log("SECTION_HEADER_KODI_NAV_V1852 aid=%s focus=%s python_move=0" % (aid, fid0))

        if self.active_section_id == "__home__":
            # v116: Home menu RIGHT is handled by XML only:
            # <onright>SetFocus(9410,0,absolute)</onright>.
            if self._is_home_row_control(fid0) and aid in (ACTION_SHOW_INFO, ACTION_CONTEXT_MENU, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
                self._show_info()
                return
            # v120: Home row directional LEFT is XML-only. Python only handles SELECT/INFO.

        # v118: Kodi already moves the sidebar list selection by itself.
        # v117 also performed a Python selection write here, so one key press became
        # Kodi native 1 step + Python 1 step = 2-step jumps.  Keep Kodi as
        # the only mover; Python only observes the current selected position
        # and refreshes the right-side recommendation widgets.
        if fid0 == MENU_ID and aid in (ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
            try:
                self._refresh_menu_selection_after_native_action(aid)
                return
            except Exception:
                _log("MENU_FOCUS_OBSERVE_FAILED aid=%s\n%s" % (aid, traceback.format_exc()), xbmc.LOGERROR)
                return

        # v847: Movie Info play -> actor row -> genre row directional movement is
        # defined only by XML onup/ondown actions. Do not intercept those keys in
        # WindowXML Python; Kodi remains the single native focus mover.

        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                # v606: Kodi-native playback return guard.
                # When Back is pressed in Kodi fullscreen video, Kodi stops the
                # player and may leak the same Back action to the underlying
                # PKM WindowXML.  That second delivery is not a user request to
                # close inline Info; closing it here is what returned to PKM
                # Home instead of the episode/movie Info page.  Playback remains
                # fully owned by Kodi; this only ignores the one leaked UI Back
                # after a native PlayMedia handoff.
                try:
                    win10000 = xbmcgui.Window(10000)
                    if win10000.getProperty("PlexKM.NativePlayback.SuppressNextInlineBack") == "1":
                        win10000.clearProperty("PlexKM.NativePlayback.SuppressNextInlineBack")
                        self.setProperty("PlexKM.NativePlayback.SuppressNextInlineBack", "")
                        # v1886: native playback return must restore the visible
                        # A/B episode panel, not assume buffer A (5712).
                        focus_target = self._inline_info_focus_target_v1886()
                        try:
                            _still_video = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                        except Exception:
                            _still_video = False
                        if _still_video and win10000.getProperty("PlexKM.Playback.BackStopRequested") != "1":
                            try:
                                self._request_playback_native_stop_v1545(reason="suppressed_back_but_video_active", focus_target=focus_target)
                                _log("INLINE_INFO_BACK_NATIVE_STOP_V1545 reason=suppressed_back_but_video_active focus=%s" % focus_target)
                            except Exception:
                                _log("INLINE_INFO_BACK_NATIVE_STOP_FAILED_V1483 %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                        try:
                            if focus_target in (5711, 5712, 5713):
                                self._info_tv_focus_panel(
                                    focus_target, reason="native_playback_return_v1886"
                                )
                            else:
                                self.setFocusId(focus_target)
                        except Exception:
                            pass
                        _log("INLINE_INFO_BACK_SUPPRESS_V1886 reason=native_playback_return focus=%s active_buffer=%s video_active=%s" % (
                            focus_target,
                            self.getProperty("PlexKM.Info.TVActiveBuffer") or win10000.getProperty("PlexKM.Info.TVActiveBuffer") or "-",
                            "1" if _still_video else "0"
                        ))
                        return
                except Exception:
                    pass
                # v2152: actor-work chains have a one-step Back contract. Once
                # that immediate parent has been restored, another Back asks to
                # exit PKM/Kodi instead of traversing older Info posters.
                # R85: a short Back never asks to quit (only a long Back does).
                # The second Back after an actor-work chain now simply closes
                # Info like any other Back.
                if getattr(self, "_inline_info_chain_exit_after_back_v2152", False):
                    self._inline_info_chain_exit_after_back_v2152 = False
                    _log("INLINE_INFO_CHAIN_BACK_CLOSE_R85 rating_key=%s action=close_info_no_exit_confirm" % (
                        getattr(self, "_last_info_rating_key", "") or ""
                    ))
                # If a child Info was opened from actor works, that parent restore
                # takes precedence over TV's local episode->season Back mode.
                if getattr(self, "_inline_info_history_v2085", None):
                    self._close_inline_info_to_previous_step(reason="back")
                    return
                if self._info_tv_back_to_seasons_if_needed(reason="back"):
                    return
                self._close_inline_info_to_previous_step(reason="back")
                return
            # After DialogVideoInfo closes, Kodi can leak the same Back key to
            # this WindowXML dialog. Swallow it so one Back returns directly to
            # the same wall item instead of requiring a second Back or jumping
            # to the left menu.
            try:
                now_ms = self._now_ms()
                if now_ms < int(self._suppress_back_until_ms or 0):
                    _log("BACK_SUPPRESSED reason=post_info elapsed_ms=%d" % (int(self._suppress_back_until_ms or 0) - now_ms))
                    return
            except Exception:
                pass
            # Home Back is an explicit PKM/Kodi exit request.
            # Keep Back behavior for overlays above this point: inline search closes,
            # inline Info closes, and sidebar reorder cancels.  Once the user is on
            # normal PKM Home content/sidebar, show the PKM-styled center confirm
            # instead of leaking to Kodi's underlying windows.
            self._show_home_exit_confirm(reason="home_back")
            return
        if aid in (ACTION_SHOW_INFO, ACTION_CONTEXT_MENU):
            if self.getFocusId() == WALL_ID:
                self._show_info()
                return
        if aid in (ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK):
            fid = self.getFocusId()
            if fid == MENU_ID:
                # Kodi already dispatches list activation through onClick(MENU_ID).
                # Do not activate here as well; otherwise one OK/click opens
                # Settings twice via onAction + onClick.
                _log("MENU_SELECT_ACTION_IGNORED reason=onclick_owns_menu_activation")
                return
            if fid == WALL_ID:
                self._show_info()
                return
        # v120: Wall directional LEFT is XML-only; the XML <onleft> relation is the single source of truth.

        if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
            # v453: XML-only navigation for TV Info season/episode panels.
            # Do not observe, sleep, correct, set focus, or otherwise participate
            # when focus is on 5711/5712. Kodi XML owns LEFT/RIGHT/UP/DOWN there.
            try:
                fid_before_nav_guard = self._safe_focus_id()
            except Exception:
                fid_before_nav_guard = -1
            if fid_before_nav_guard in (5712, 5713):
                if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
                    self._info_tv_episode_nav_schedule_r20a(fid_before_nav_guard, aid)
                    try:
                        self._info_tv_resolution_follow_nav_r98(fid_before_nav_guard, aid)
                    except Exception:
                        pass
                return
            if fid_before_nav_guard == 5711:
                return
            # v2385: Home/section widget vertical movement is 100% Kodi XML/grouplist.
            # Do not read the post-action focus, move any row stack, or republish
            # metadata from this onAction callback. The destination row's onFocus
            # is the single authoritative vertical-focus callback.
            if self._is_home_row_control(fid_before_nav_guard) and aid in (
                    ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
                _log("ROW_VERTICAL_NATIVE_ONLY_V2385 action=%s focus_before=%s python_focus_write=0 python_position_write=0 metadata_write=0" % (
                    self._home_action_name(aid), fid_before_nav_guard
                ))
                return
            # v143: XML-first navigation. Do not steer sidebar/home-row/wall focus
            # from Python. Python only observes the final selected item after Kodi
            # has moved focus/selection, then refreshes metadata from that real item.
            # This is required because moving within the same XML list/wraplist does
            # not always fire onFocus(control_id) again.
            if fid_before_nav_guard == WALL_ID or self._is_home_row_control(fid_before_nav_guard):
                # v2073: never wait/sleep in a native directional callback. Kodi's
                # Python ControlList addItem/addItems API ultimately sends
                # GUI_MSG_LABEL_BIND, and Kodi handles that message by Reset() +
                # SelectItem(0).  The real invariant is therefore not a guessed
                # "post-native" delay: every live Library rebind must be one atomic
                # bind+same-native-position transaction.  The append gate below
                # snapshots the current 9100 position and restores that exact numeric
                # position immediately after the single bind; no logical/rating-key
                # owner participates. Native XML navigation remains the only source
                # of directional movement.
                try:
                    fid_after_nav_guard = self._safe_focus_id()
                except Exception:
                    fid_after_nav_guard = -1
                if fid_after_nav_guard == WALL_ID:
                    # V2621: schedule a GUI-thread, map-only poster handoff after
                    # the native key callback returns.  This never queries SQLite,
                    # touches the network, or moves focus/selection.
                    self._schedule_library_texture_runway_commit_v2621()
                    # V2600 Android hard-minimal: the directional callback is a
                    # transport-only path. Kodi XML/panel 9100 owns movement.
                    # Python does not read ListItem metadata, run DB/network,
                    # rebuild containers, sync index state, or write a log here.
                    if self._is_android_v2591():
                        if aid in (ACTION_MOVE_DOWN, ACTION_PAGE_DOWN):
                            self._wall_rapid_scroll_mark_v2581(aid)
                        else:
                            self._wall_rapid_scroll_active_v2581()
                        self._schedule_wall_meta_commit_v2600()
                        self._schedule_library_append_commit_v2600()
                    else:
                        rapid_wall_v2581 = False
                        if aid in (ACTION_MOVE_DOWN, ACTION_PAGE_DOWN):
                            rapid_wall_v2581 = self._wall_rapid_scroll_mark_v2581(aid)
                            self._request_library_append_v2070(reason="wall_down_v2581")
                            _log("LIBRARY_APPEND_COMMIT_DEFER_TO_TRACK_V2579 section=%s action=%s single_owner=post_selection" % (
                                self.active_section_id, self._home_action_name(aid)
                            ))
                        else:
                            rapid_wall_v2581 = self._wall_rapid_scroll_active_v2581()
                        self._remember_focus_position()
                        wall_li = self._focused_wall_item()
                        if rapid_wall_v2581:
                            self._track_wall_selection("wall_xml_nav_rapid_v2581")
                            _log("WALL_RAPID_SCROLL_SUPPRESS_V2581 section=%s action=%s art_preload=0 trailer=0 index_sync=0 telemetry=0 fanart=0" % (
                                self.active_section_id, self._home_action_name(aid)
                            ))
                        else:
                            self._info_art_preload_v2136(wall_li, reason="wall_xml_nav")
                            self._set_home_meta_from_item(wall_li, reason="wall_xml_nav")
                            self._schedule_home_trailer_preview(wall_li, reason="wall_xml_nav")
                            self._track_wall_selection("wall_xml_nav")
                            self._sync_library_selection_telemetry_v2070("wall_xml_nav")
                        try:
                            _v2073_pos = int(self.getControl(WALL_ID).getSelectedPosition())
                            _v2073_cols = max(1, int(self._wall_column_count() or 6))
                            _log("LIBRARY_NATIVE_COLUMN_TRACE_V2073 action=%s pos=%d column=%d columns=%d size=%d selection_write=0 reason=wall_xml_nav" % (
                                self._home_action_name(aid), _v2073_pos, (_v2073_pos % _v2073_cols if _v2073_pos >= 0 else -1),
                                _v2073_cols, int(self.getControl(WALL_ID).size())
                            ))
                        except Exception:
                            pass
                        if not rapid_wall_v2581:
                            self._section_index_sync_for_item(wall_li, reason="wall_xml_nav")
                        _log("LIBRARY_POSTER_AHEAD_PREFETCH_SUPPRESS_V1865 section=%s reason=wall_xml_nav next_chunk=on_down" % self.active_section_id)
                        _log("LIBRARY_NAV_CAST_PREWARM_SUPPRESS_V2576 section=%s reason=wall_xml_nav foreground_priority=1" % self.active_section_id)
                elif self._is_home_row_control(fid_after_nav_guard):
                    try:
                        # Row focus movement is XML-only.  Do not call setFocusId()
                        # from Python for UP/DOWN, because repeated key presses can
                        # race with Kodi focus resolution and make rows stick.
                        self._apply_dynamic_row_anchor_scroll(fid_after_nav_guard, reason="xml_nav")
                        row_idx = self._home_row_index_for_control(fid_after_nav_guard)
                        pos = self._home_row_selected_position(row_idx, control_id=fid_after_nav_guard)
                        self._home_active_row = max(0, row_idx)
                        if row_idx >= 0:
                            old_pos = int(self._home_row_memory.get(row_idx, max(0, pos)))
                            self._home_row_prev_memory[row_idx] = old_pos
                            self._home_row_memory[row_idx] = max(0, pos)
                        self._last_focus_id = fid_after_nav_guard
                        self._remember_row_reentry_focus(fid_after_nav_guard, reason="xml_nav")
                    except Exception:
                        pass
                    _log("ROW_XML_NAV action=%s before=%s after=%s state=[%s]" % (self._home_action_name(aid), fid_before_nav_guard, fid_after_nav_guard, self._home_row_state_for_log(fid_after_nav_guard)))
                    home_li = self._home_focused_item(fid_after_nav_guard)
                    # V2599: same native-first path on every platform. PC and UHD
                    # must exercise the same interaction contract.
                    self._schedule_widget_focus_commit_v2596(fid_after_nav_guard, settle_ms=0)
                    _log("WIDGET_NAV_FOREGROUND_ONLY_V2599 action=%s focus=%s art_preload=0 meta_now=0 trailer=0 cast_prewarm=0 platform_split=0" % (
                        self._home_action_name(aid), fid_after_nav_guard
                    ))
            return





    def _startup_collapse_arm_r87(self):
        """R87: start Home with the sidebar collapsed.

        Event driven (no polling): wait once for the startup-ready event, then
        send one commit ping so _startup_collapse_r87 runs on the GUI thread.
        Kill switch: set window property PlexKM.Startup.R87CollapseOff=1.
        """
        try:
            ev = getattr(self, "_startup_ready_event_v1841", None)
            if ev is None:
                return

            def _wait_r87():
                try:
                    if not ev.wait(90.0):
                        return
                    if self._closing_event_v1841.is_set():
                        return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            t = threading.Thread(target=_wait_r87, name="PKMStartupCollapseR87", daemon=True)
            t.start()
        except Exception:
            pass

    def _startup_scene_cache_prewarm_r111(self):
        """R111: the first sidebar ENTER into a Library parsed the 3.6 MB
        library_wall_prepared_cache JSON on the click path (170-210 ms on
        SHIELD; 2-3 ms afterwards).  Load both scene caches once, after the
        reveal, while nothing is being navigated."""
        if getattr(self, "_scene_cache_prewarm_started_r111", False):
            return
        self._scene_cache_prewarm_started_r111 = True

        def _run():
            try:
                if self._closing_event_v1841.wait(2.5):
                    return
                waited = 0
                while waited < 30000 and self._tmdb_fill_foreground_busy_r105():
                    if self._closing_event_v1841.wait(0.2):
                        return
                    waited += 200
                t0 = _pkm_speed_ms()
                lib = self._library_persistent_cache_load_v2470() or {}
                t1 = _pkm_speed_ms()
                sec = self._section_persistent_cache_load_v2467() or {}
                t2 = _pkm_speed_ms()
                _log("SCENE_CACHE_PREWARM_R111 library_entries=%d library_ms=%d section_entries=%d section_ms=%d waited_ms=%d" % (
                    len(lib), t1 - t0, len(sec), t2 - t1, waited))
            except Exception:
                _log("SCENE_CACHE_PREWARM_R111_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        threading.Thread(target=_run, name="PKMSceneCachePrewarmR111", daemon=True).start()

    def _startup_collapse_r87(self):
        """R87 GUI-thread one-shot: leave the menu and enter the first row.

        Focus on menu 9000 keeps the sidebar expanded by design (XML shows the
        card while 9000 has focus), so collapsing at start means moving focus
        into the content the same way the user would: Action(Right) runs the
        normal XML onright logic.  Skipped (and logged) when anything else
        owns the screen.
        """
        try:
            if getattr(self, "_startup_collapse_done_r87", False):
                return False
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Startup.R87CollapseOff") == "1":
                self._startup_collapse_done_r87 = True
                return False
            if win.getProperty("PlexKM.Home.StartupReadyV1619") != "1":
                return False
            self._startup_collapse_done_r87 = True
            self._startup_scene_cache_prewarm_r111()
            focus = self._safe_focus_id()
            blockers = [
                n for n in ("PlexKM.Info.InlineActive", "PlexKM.ActorProfile.Active", "PlexKM.Search.InlineActive")
                if win.getProperty(n) == "1" or self.getProperty(n) == "1"
            ]
            rows = list(getattr(self, "_home_visible_row_controls", None) or [])
            on_home = str(getattr(self, "active_section_id", "") or "") == "__home__"
            if focus != MENU_ID or blockers or not rows or not on_home:
                _log("STARTUP_COLLAPSE_SKIP_R87 focus=%s blockers=%s rows=%d on_home=%d" % (
                    focus, ",".join(blockers), len(rows), 1 if on_home else 0))
                return False
            self._set_sidebar_expanded_state(False, reason="startup_collapse_r87")
            xbmc.executebuiltin("Action(Right)")
            _log("STARTUP_COLLAPSE_R87 focus=%s rows=%d action=right" % (focus, len(rows)))

            # R108: the first row can still be fading in when the reveal and this
            # one-shot land in the same frame ("Control 9410 ... can't focus"),
            # leaving focus on the menu.  Re-check shortly and retry a few times.
            def _verify_r108():
                mon = xbmc.Monitor()
                for attempt in range(1, 5):
                    if mon.waitForAbort(0.25):
                        return
                    cur = self._safe_focus_id()
                    if cur not in (MENU_ID, 100):
                        if attempt > 1:
                            _log("STARTUP_COLLAPSE_RETRY_R108 ok focus=%s attempts=%d" % (cur, attempt - 1))
                        return
                    if str(getattr(self, "active_section_id", "") or "") != "__home__":
                        return
                    if any(xbmcgui.Window(10000).getProperty(n) == "1" for n in (
                            "PlexKM.Info.InlineActive", "PlexKM.ActorProfile.Active", "PlexKM.Search.InlineActive")):
                        return
                    if cur == 100:
                        xbmc.executebuiltin("SetFocus(%d)" % MENU_ID)
                    xbmc.executebuiltin("Action(Right)")
                    _log("STARTUP_COLLAPSE_RETRY_R108 attempt=%d focus=%s" % (attempt, cur))
            threading.Thread(target=_verify_r108, name="PKMStartupCollapseVerifyR108", daemon=True).start()
            return True
        except Exception:
            self._startup_collapse_done_r87 = True
            return False

    def _commit_ring_v2800(self):
        """Run the pre-Info commits under a GUI time budget.

        Returns True when work was deferred (caller must stop for this ping, a
        follow-up ping is already scheduled).  Returns False when every commit
        ran (caller continues with the Info tail).  Budget (ms) is 20 within
        300ms of a key press, otherwise 60; window property
        PlexKM.Commit.BudgetMs overrides, 0 restores the old unbounded run.
        """
        def _safe(fn):
            def _run():
                try:
                    return fn()
                except Exception:
                    return None
            return _run

        ring = (
            ("tmdb_episode_plot_commit_r35", _safe(self._tmdb_episode_plot_commit_r35)),
            ("tmdb_episode_still_commit_r63", _safe(self._tmdb_episode_still_commit_r63)),
            ("actor_wiki_bio_commit_r68", _safe(self._actor_wiki_bio_commit_r68)),
            ("tmdb_fill_commit_r41", _safe(self._tmdb_fill_commit_r41)),
            ("info_tv_async_retry_commit_cumulative", self._info_tv_async_retry_commit_cumulative),
            ("pkm_tv_focus_after_window_active_vnext", self._pkm_tv_focus_after_window_active_vnext),
            ("section_same_bank_full_fill_commit_v2707", self._section_same_bank_full_fill_commit_v2707),
            ("widget_focus_commit_ping_v2596", self._widget_focus_commit_ping_v2596),
            ("wall_meta_commit_ping_v2600", self._wall_meta_commit_ping_v2600),
            ("r155_rating_commit", self._r155_rating_commit),
            ("library_texture_runway_commit_v2621", self._library_texture_runway_commit_v2621),
            ("library_append_commit_ping_v2600", self._library_append_commit_ping_v2600),
            ("actor_profile_enrich_commit_v2599", self._actor_profile_enrich_commit_v2599),
        )
        try:
            raw = xbmcgui.Window(10000).getProperty("PlexKM.Commit.BudgetMs")
            override = int(raw) if str(raw or "").strip() != "" else None
        except Exception:
            override = None
        if override == 0:
            for name, fn in ring:
                self._r86_timed(name, fn)
            return False
        last = int(getattr(self, "_last_action_ms", 0) or 0)
        age = (_pkm_speed_ms() - last) if last > 0 else 100000
        budget = override if override is not None else (20 if age < 300 else 60)
        n = len(ring)
        cursor = int(getattr(self, "_commit_ring_cursor_v2800", 0) or 0) % n
        left = int(getattr(self, "_commit_ring_left_v2800", 0) or 0)
        own_reping = bool(getattr(self, "_commit_reping_origin_v2800", False))
        self._commit_reping_origin_v2800 = False
        if left <= 0 or not own_reping:
            # new cycle, or an external ping (new pending work) mid-cycle:
            # every commit must get a turn again.
            left = n
        t0 = self._now_ms()
        done = 0
        while done < left:
            name, fn = ring[(cursor + done) % n]
            self._r86_timed(name, fn)
            done += 1
            if done < left and (self._now_ms() - t0) >= budget:
                break
        left -= done
        self._commit_ring_cursor_v2800 = (cursor + done) % n
        self._commit_ring_left_v2800 = left
        if left <= 0:
            self._commit_ring_left_v2800 = 0
            return False
        _log("COMMIT_RING_DEFER_V2800 left=%d/%d budget_ms=%d spent_ms=%d input_age_ms=%d" % (
            left, n, budget, self._now_ms() - t0, age))
        if not getattr(self, "_commit_reping_pending_v2800", False):
            self._commit_reping_pending_v2800 = True

            def _reping_v2800():
                self._commit_reping_pending_v2800 = False
                try:
                    if self._closing_event_v1841.is_set():
                        return
                except Exception:
                    pass
                try:
                    self._commit_reping_origin_v2800 = True
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass
            t = threading.Timer(0.04 if age < 300 else 0.02, _reping_v2800)
            t.daemon = True
            t.start()
        return True

    def _r86_timed(self, name, fn):
        """R86 measurement: run a GUI-thread commit and log it when it is slow.

        Logs R86_COMMIT_SLOW when a commit takes >= 4ms (PlexKM.Info.R86LogMs
        overrides, 0 logs every call).  input_age_ms is the time since the
        last remote key (small value = commit ran during scrolling),
        since_visible_ms the time since Info became visible (-1 if none).
        """
        t0 = self._now_ms()
        try:
            return fn()
        finally:
            try:
                dt = self._now_ms() - t0
                try:
                    raw = xbmcgui.Window(10000).getProperty("PlexKM.Info.R86LogMs")
                    thr = int(raw) if str(raw or "").strip() != "" else 4
                except Exception:
                    thr = 4
                if dt >= thr:
                    last = int(getattr(self, "_last_action_ms", 0) or 0)
                    # _last_action_ms uses the perf_counter clock (_pkm_speed_ms),
                    # not wall time: compare on the same clock.
                    age = (_pkm_speed_ms() - last) if last > 0 else -1
                    stamp = int(getattr(self, "_info_visible_stamp_r86", 0) or 0)
                    since = (t0 - stamp) if stamp > 0 else -1
                    _log("R86_COMMIT_SLOW name=%s ms=%d input_age_ms=%d since_visible_ms=%d" % (name, dt, age, since))
            except Exception:
                pass

    def _info_staged_commits_r86(self):
        """R86b: run Info post-visible commits one per ping after the fade.

        Returns True when a stage did work and a follow-up ping was scheduled
        (the caller must stop for this ping).  Returns False when staging is
        finished or not applicable, so the caller runs the normal full path.
        Window property PlexKM.Info.R86StageMs overrides the gap (default 50,
        0 disables staging).
        """
        try:
            stamp = int(getattr(self, "_info_visible_stamp_r86", 0) or 0)
            if stamp <= 0:
                return False
            try:
                raw = xbmcgui.Window(10000).getProperty("PlexKM.Info.R86StageMs")
                gap_ms = int(raw) if str(raw or "").strip() != "" else 50
            except Exception:
                gap_ms = 50
            if gap_ms <= 0:
                return False
            if getattr(self, "_info_stage_stamp_r86", 0) != stamp:
                self._info_stage_stamp_r86 = stamp
                self._info_stage_cursor_r86 = 0
            stages = (
                self._info_tv_late_rows_commit_v2601,
                self._info_movie_versions_postvisible_commit_v2602,
                self._info_cast_late_fill_commit_v2606,
                lambda: bool(self._info_widget_rebuild_try_commit_v2082(
                    focus_id=self._safe_focus_id(), reason="v2601_ping_staged_r86"
                )) or self._r88_rebuild_in_progress(),
            )
            cursor = int(getattr(self, "_info_stage_cursor_r86", 0) or 0)
            while cursor < len(stages):
                fn = stages[cursor]
                cursor += 1
                self._info_stage_cursor_r86 = cursor
                did = False
                try:
                    did = bool(self._r86_timed("stage%d" % cursor, fn))
                except Exception:
                    did = False
                if did and cursor >= len(stages):
                    # last stage did work (or is mid-rebuild, which re-pings
                    # itself): this ping is done, do not run the full path too.
                    return True
                if did and cursor < len(stages):
                    def _reping_stage_r86():
                        try:
                            if self._closing_event_v1841.is_set():
                                return
                        except Exception:
                            pass
                        try:
                            xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        except Exception:
                            pass
                    t = threading.Timer(gap_ms / 1000.0, _reping_stage_r86)
                    t.daemon = True
                    t.start()
                    _log("INFO_STAGED_COMMIT_R86 stage=%d/%d gap_ms=%d" % (cursor, len(stages), gap_ms))
                    return True
            return False
        except Exception:
            return False

    def _info_fade_hold_r86(self):
        """R86: True while the Info fade-in is still playing (ping must wait).

        Window property PlexKM.Info.R86DeferMs overrides the hold (default 300,
        0 disables) so it can be tuned on a device without a rebuild.
        """
        try:
            stamp = int(getattr(self, "_info_visible_stamp_r86", 0) or 0)
            if stamp <= 0:
                return False
            try:
                raw = xbmcgui.Window(10000).getProperty("PlexKM.Info.R86DeferMs")
                hold_ms = int(raw) if str(raw or "").strip() != "" else 300
            except Exception:
                hold_ms = 300
            if hold_ms <= 0:
                return False
            remain = hold_ms - (self._now_ms() - stamp)
            if remain <= 0:
                return False
            if getattr(self, "_info_fade_hold_timer_r86", False):
                return True
            self._info_fade_hold_timer_r86 = True

            def _reping_r86():
                self._info_fade_hold_timer_r86 = False
                try:
                    if self._closing_event_v1841.is_set():
                        return
                except Exception:
                    pass
                try:
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            t = threading.Timer(max(0.02, remain / 1000.0) + 0.01, _reping_r86)
            t.daemon = True
            t.start()
            _log("INFO_FADE_HOLD_R86 remain_ms=%d" % int(remain))
            return True
        except Exception:
            self._info_fade_hold_timer_r86 = False
            return False

    def _on_click_impl_r26(self, control_id):
        audit_event(self, "onClick", control_id=control_id)
        # R151: ignore clicks on internal fixedlist scroll padding.
        if control_id == MENU_ID:
            try:
                menu_r151 = self.getControl(MENU_ID)
                pos_r151 = int(menu_r151.getSelectedPosition())
                limit_r151 = int(getattr(self, "_sidebar_real_count_r151", menu_r151.size()))
                if pos_r151 >= limit_r151:
                    menu_r151.selectItem(max(0, limit_r151 - 1))
                    return
            except Exception:
                pass
        # V2595: worker only schedules SendClick(); the actual scene transaction
        # stays on Kodi's WindowXML callback thread.
        if int(control_id or 0) == SIDEBAR_COMMIT_PING_ID_V2595:
            self._startup_collapse_r87()
            self._r86_timed("sidebar_focus_commit_ping_v2595", self._sidebar_focus_commit_ping_v2595)
            if not self._sidebar_enter_replay_r34():
                self._sidebar_prepare_ready_commit()
            # V2800 (A): the ~13 commits below used to run back to back on the GUI
            # thread (1.8s bursts on Shield).  They now run as a ring under a
            # per-ping time budget; when the budget is spent the rest is
            # re-pinged later so Kodi can render and dispatch keys in between.
            if self._commit_ring_v2800():
                return
            # R86: hold Info post-visible GUI work until the Info fade-in ends.
            # The pending records stay queued; a single timer re-pings later.
            if self._info_fade_hold_r86():
                return
            self._r86_timed("info_tv_episode_nav_commit_r20a", self._info_tv_episode_nav_commit_r20a)
            # R86b: right after the fade the pending commits are run one stage
            # per ping (re-pinged ~50ms apart) so Kodi can render frames in
            # between instead of one long GUI-thread burst.
            if self._info_staged_commits_r86():
                return
            self._r86_timed("tv_late_rows", self._info_tv_late_rows_commit_v2601)
            self._r86_timed("versions", self._info_movie_versions_postvisible_commit_v2602)
            self._r86_timed("cast_fill", self._info_cast_late_fill_commit_v2606)
            try:
                self._r86_timed("widget_rebuild", lambda: self._info_widget_rebuild_try_commit_v2082(
                    focus_id=self._safe_focus_id(), reason="v2601_ping"
                ))
            except Exception:
                pass
            return
        if _pkm_full_reset_active_v2150():
            if control_id == EMPTY_HOME_SETTINGS_BUTTON_ID:
                self._open_empty_home_pkm_settings()
                return
            if control_id == MENU_ID:
                try:
                    item_v2151 = self._selected_menu_item()
                    kind_v2151 = item_v2151.getProperty("kind") if item_v2151 else ""
                except Exception:
                    kind_v2151 = ""
                if kind_v2151 in ("addon_settings", "kodi_settings"):
                    self._activate_menu_item()
                return
            return
        try:
            if pkm_global_busy.is_visible() and not self._search_busy_passthrough_r95():
                _nav_click_v2067 = control_id in (
                    MENU_ID, SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID,
                    SECTION_TAB_CATEGORY_ID,
                )
                if _nav_click_v2067:
                    # Navigation is an ownership change, never a blocked action.
                    # Retire any stale section gate before activating the new target.
                    try:
                        self._section_first_visit_gate_cancel_v1620(
                            reason="navigation_click_v2067"
                        )
                    except Exception:
                        pass
                    _log("GLOBAL_BUSY_NAV_CLICK_CONTINUE_V2067 window=home control=%s reason=%s focus=%s" % (
                        control_id, pkm_global_busy.current_reason(), self._safe_focus_id()
                    ))
                else:
                    _log("GLOBAL_BUSY_CLICK_BLOCK_V2067 window=home control=%s reason=%s focus=%s" % (
                        control_id, pkm_global_busy.current_reason(), self._safe_focus_id()
                    ))
                    return
        except Exception:
            pass
        if control_id in (6100, 6110) and (
                self.getProperty("PlexKM.Info.InlineActive") == "1"
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
            self._actor_profile_open_from_cast_v2454(control_id, reason="onclick_cast")
            return
        if control_id in (6500, 6510) and self._actor_profile_is_active_v2454():
            self._actor_profile_open_selected_work_v2454(reason="onclick_work")
            return
        if control_id == 6486 and self._actor_profile_is_active_v2454():
            # R92: ActorProfile "더보기" -> full biography popup.
            self._actor_profile_open_bio_dialog_r92()
            return
        if control_id == 6487:
            # R93: OK inside the biography overlay closes it.
            self._actor_profile_close_bio_popup_r93()
            return
        if control_id == EMPTY_HOME_SETTINGS_BUTTON_ID:
            self._open_empty_home_pkm_settings()
            return
        if (control_id == SEARCH_QUERY_PILL_ID or control_id in SEARCH_SUG_IDS) and getattr(self, "_search_inline_active", False):
            if not self._search_select_begin_r74(control_id, "click"):
                return
            if control_id == SEARCH_QUERY_PILL_ID:
                self._search_kb_set_r96(True, reason="pill_click")
            else:
                self._search_apply_suggestion_r96(control_id)
            self._search_select_end_r74(control_id, "click")
            return
        if control_id in SEARCH_TAB_SCOPES and getattr(self, "_search_inline_active", False):
            if not self._search_select_begin_r74(control_id, "click"):
                return
            self._search_set_scope(SEARCH_TAB_SCOPES[control_id], reason="tab_click")
            self._search_select_end_r74(control_id, "click")
            return
        if control_id == SEARCH_KEYBOARD_ID and getattr(self, "_search_inline_active", False):
            if not self._search_select_begin_r74(control_id, "click"):
                return
            self._search_handle_key_click()
            self._search_select_end_r74(control_id, "click")
            return
        if control_id in SEARCH_RESULT_IDS and getattr(self, "_search_inline_active", False):
            self._search_open_selected_result_info(control_id=control_id)
            return
        if control_id == SEARCH_HISTORY_ID and getattr(self, "_search_inline_active", False):
            if not self._search_select_begin_r74(control_id, "click"):
                return
            self._search_handle_history_click()
            self._search_select_end_r74(control_id, "click")
            return
        if control_id == SEARCH_HISTORY_CLEAR_ID and getattr(self, "_search_inline_active", False):
            if not self._search_select_begin_r74(control_id, "click"):
                return
            self._search_clear_history(reason="fixed_clear_button")
            self._search_select_end_r74(control_id, "click")
            return
        if control_id == 5708 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_toggle_episode_sort_v2399(reason="episode_sort_click")
            return
        if control_id == 5711 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_select_focused_season(reason="season_click")
            return
        if control_id in (5712, 5713) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # R155: clicking a partly watched episode must use its Plex offset;
            # explicit '처음부터 재생' (5722) remains start=0.
            self._info_tv_play_focused_episode(play_mode="resume")
            return
        if control_id == 5726 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v2099: TV episode resolution action mirrors movie Info.  It cycles
            # the already-discovered local playback targets in place and never
            # rebuilds the episode rail or Info surface.
            self._info_tv_cycle_version_v2099(reason="action_click_5726")
            return
        if control_id == 5721 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v1558: TV primary action is one dynamic 재생/이어서 재생 slot.
            # Request resume unconditionally; the URL builder falls back to start
            # when the selected episode has no safe Plex resume offset.
            self._info_tv_play_focused_episode(play_mode="resume")
            return
        if control_id == 5722 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v2098: TV resume-state action row matches movie Info.
            # Restart uses the same selected episode but explicitly starts at 0.
            self._info_tv_play_focused_episode(play_mode="start")
            return
        if control_id == 5723 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # Legacy hidden TV action id remains disabled.
            return
        if control_id in (5724, 5725) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_mark_focused_episode_watched()
            return
        if control_id in (5727, 5728) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_open_media_versions_v2112(control_id=control_id, reason="action_click_%s" % control_id)
            return
        if control_id in (5729, 5730) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_open_next_timing_v2236(control_id=control_id, reason="action_click_%s" % control_id)
            return
        if control_id == 7432 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_adjust_next_timing_v2236(-5, reason="minus_5")
            return
        if control_id == 7433 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_adjust_next_timing_v2236(5, reason="plus_5")
            return
        # R97B(2): episode-settings sheet = visible choices, OK saves at once (per drama).
        if 7440 <= control_id <= 7445 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_sheet_pick_timing_r97((None, 15, 30, 60, 90, 120)[control_id - 7440])
            return
        if 7450 <= control_id <= 7452 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_sheet_pick_intro_r97(("off", "button", "auto")[control_id - 7450])
            return
        if control_id == 7436 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_close_next_timing_v2236(restore_focus=True, reason="sheet_close_r97")
            return
        if control_id == 7435 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_confirm_next_timing_v2237(reason="confirm")
            return
        if control_id in (5001, 5002, 5003) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            if control_id == 5001:
                # v1085: 5001 is the primary action. When the Info item has a
                # progress offset, the visible button is "이어서 재생" and must
                # use the Plex resume offset. v1075 accidentally mapped it to
                # start=0 while still logging offset, so Continue rows started
                # from the beginning.
                try:
                    _win = xbmcgui.Window(10000)
                    _vo = _win.getProperty("PlexKM.Info.ViewOffset") or "0"
                    _dur = _win.getProperty("PlexKM.Info.Duration") or "0"
                    _rd = _win.getProperty("PlexKM.Info.ResumeDurationMs") or "0"
                    mode = "resume" if self._resume_offset_ms_for_ui(_vo, _dur, _rd) > 0 else "play"
                except Exception:
                    mode = "play"
            else:
                mode = "start" if control_id == 5002 else "resume"
            self._info_movie_play(mode=mode)
            return
        if control_id in (5005, 5006) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v2093: playback version is a single end-of-row resolution icon.
            # Enter/click advances directly through the available real versions;
            # there is no dropdown and therefore no secondary focus owner.
            self._info_movie_cycle_version_v2094(reason="action_click_%s" % control_id)
            return
        if control_id == 7410 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_movie_select_media_version_inline_v2104(reason="inline_list_click")
            return
        if control_id == 7420 and self.getProperty("PlexKM.Info.InlineActive") == "1":
            self._info_tv_select_media_version_inline_v2112(reason="inline_list_click_tv")
            return
        if control_id in (5008, 5009) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v2104: detailed movie codec chooser is an inline Home list.  This
            # remains independent of the quick resolution cycle and never
            # rebuilds, recolors, dims, or replaces the Info surface.
            self._info_movie_open_media_versions_v2100(
                control_id=control_id, reason="action_click_%s" % control_id
            )
            return
        if control_id in (5004, 5007) and self.getProperty("PlexKM.Info.InlineActive") == "1":
            # v2096: watched uses a separate resume-state focus id so the hitbox
            # stays aligned after inserting the resolution action at the first slot.
            self._info_movie_mark_watched()
            return
        if control_id == SECTION_CATEGORY_PANEL_ID:
            self._section_category_click(reason="category_click")
            return
        if control_id == SECTION_INDEX_ID:
            self._section_index_click(reason="index_click")
            return
        if control_id == SECTION_SORT_BUTTON_ID:
            self._open_section_sort_inline(reason="button_click_v1860")
            return
        if control_id in SECTION_SORT_ITEM_IDS:
            media_kind_v1911 = self._section_sort_media_kind()
            key_by_control_v1911, _control_by_key_v1911 = self._section_sort_control_maps(
                media_kind=media_kind_v1911
            )
            selected_sort_v1911 = key_by_control_v1911.get(control_id)
            if selected_sort_v1911:
                # R99 L3: in the sort sheet, OK on the current sort flips asc/desc; another option switches the sort.
                _cur_r99 = pkm_library_sort.normalize_sort_key(getattr(self, "sort", "title"), media_kind=media_kind_v1911)
                if selected_sort_v1911 == _cur_r99:
                    self._close_section_sort_inline(restore_focus=True, reason="selected_v1860")
                    self._toggle_section_sort_dir(reason="sheet_same_r99")
                    try:
                        self.setFocusId(SECTION_SORT_BUTTON_ID)
                    except Exception:
                        pass
                else:
                    self._apply_section_sort_key(
                        selected_sort_v1911,
                        reason="fixed_button_%s_v1911" % control_id,
                    )
            return
        if control_id == SEARCH_FIXED_ID:
            # R82: the profile row is a virtual focus stop above search (8990).
            if self.getProperty("PlexKM.Sidebar.ProfileFocus") == "1":
                self._open_profile_picker_r82()
                return
            self._open_inline_search()
        elif control_id == MENU_ID:
            self._activate_menu_item()
        elif control_id == SECTION_TAB_RECOMMEND_ID:
            self._focus_section_recommend_tab(reason="recommend_tab_kodi_click_v1852")
        elif control_id == SECTION_TAB_LIBRARY_ID:
            self._focus_section_library_tab(reason="library_tab_kodi_click_v1852")
        elif control_id == SECTION_TAB_CATEGORY_ID:
            self._focus_section_category_tab(reason="category_tab_kodi_click_v1852")
        elif control_id == WALL_ID or self._is_home_row_control(control_id):
            self._show_info()

    def _on_focus_impl_r26(self, control_id):
        # R46: a prescroll bounce (see _row_prescroll_bounce_r46) briefly
        # moves real Kodi focus onto a row control and straight back to the
        # sidebar purely so the outer row grouplist repositions its scroll
        # before the user ever presses RIGHT. Nothing about navigation state
        # actually changes -- the sidebar never really lost focus -- so both
        # onFocus events from that bounce are no-ops here.
        try:
            if (self.getProperty("PlexKM.Row.PrescrollBounceR46") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Row.PrescrollBounceR46") == "1"):
                return
        except Exception:
            pass
        if _pkm_full_reset_active_v2150():
            try:
                if int(control_id or 0) == MENU_ID:
                    self._sync_collapsed_menu_selection()
            except Exception:
                pass
            return
        # v2121: Kodi can queue an onFocus(control_id) callback and deliver it
        # after native XML navigation has already moved focus somewhere else.
        # The callback id is therefore an event snapshot, not always the current
        # focus owner.  A stale MENU_ID callback used to start a new section
        # transaction while the user was already moving inside the visible row,
        # eventually hiding the control that actually owned focus.  Reject only
        # a definitive positive mismatch; focus<=0 remains observational because
        # Kodi can transiently report zero during valid XML navigation.
        try:
            _actual_focus_v2121 = int(self._safe_focus_id() or 0)
            _callback_focus_v2121 = int(control_id or 0)
        except Exception:
            _actual_focus_v2121 = 0
            _callback_focus_v2121 = 0
        if (_actual_focus_v2121 > 0 and _callback_focus_v2121 > 0
                and _actual_focus_v2121 != _callback_focus_v2121):
            _log("STALE_ONFOCUS_DROP_V2121 callback=%s actual=%s active_section=%s active_menu_index=%s python_focus_write=0 content_mutation=0" % (
                _callback_focus_v2121, _actual_focus_v2121,
                getattr(self, "active_section_id", "") or "",
                getattr(self, "active_menu_index", -1),
            ), xbmc.LOGWARNING)
            return
        prev_focus = self._on_focus_impl_r26_step1(control_id)

        # R96: drawer controls (keyboard / recent / drawer chips) must never hold
        # focus while the drawer is hidden -- open it whatever path led here.
        if getattr(self, "_search_inline_active", False) and (
                control_id in (SEARCH_KEYBOARD_ID, SEARCH_HISTORY_ID, SEARCH_HISTORY_CLEAR_ID) or 2141 <= int(control_id or 0) <= 2146):
            try:
                if self.getProperty("PlexKM.Search.KbOpen") != "1":
                    self.setProperty("PlexKM.Search.KbOpen", "1")
                    _log("INLINE_SEARCH_KB_AUTO_OPEN_R96 focus=%s" % control_id)
            except Exception:
                pass
        # R90: 검색 탭은 포커스가 옮겨 가는 즉시 해당 탭으로 전환된다 (◀ ▶ 탭 전환).
        if getattr(self, "_search_inline_active", False) and control_id in SEARCH_TAB_SCOPES:
            try:
                self._search_set_scope(SEARCH_TAB_SCOPES[control_id], reason="tab_focus_r90")
            except Exception:
                _log("INLINE_SEARCH_TAB_FOCUS_FAILED_R90 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        # v1883: Search result publication does no actor work. Entering a
        # result panel and moving within it both feed the same single debounce
        # worker. That worker reads Kodi's actual selected item after 650ms;
        # onFocus never starts a second actor worker and never moves focus.
        if getattr(self, "_search_inline_active", False) and control_id in SEARCH_RESULT_IDS:
            self._last_focus_id = control_id
            self._search_schedule_direction_target_cast_v1878(control_id, 0)
            return
        # v122: never bounce menu focus from Python. If XML sends focus to the
        # sidebar/menu, accept it.  This keeps LEFT/menu transitions XML-only.
        if control_id in (SEARCH_FIXED_ID, MENU_ID, WALL_ID, SECTION_SORT_BUTTON_ID, SECTION_INDEX_ID) or self._is_home_row_control(control_id):
            self._last_focus_id = control_id
        if control_id == SEARCH_FIXED_ID:
            _log("HOME_FOCUS_CHANGE target=SEARCH_FIXED prev=%s wall_pos=%s active_section=%s" % (prev_focus, self._wall_selected_position(), self.active_section_id))
            if self._is_connection_settings_focus_required_v1381():
                # v1382: In offline/server-switch-pending mode, merely focusing
                # the search icon must not rebuild Home, query onDeck, or run a
                # search index refresh.  Settings navigation has priority and
                # must stay instant.
                self._remember_focus_position()
                self._clear_home_trailer_preview(reason="search_fixed_offline_fast_v1382", stop_player=True)
                _log("SEARCH_FIXED_FOCUS_SKIP_V1382 reason=connection_recovery_no_network")
                return
            try:
                self._search_schedule_index_refresh(reason="search_fixed_focus")
            except Exception:
                _log("INLINE_SEARCH_INDEX_FOCUS_PREP_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            try:
                self._search_prewarm_db_r95(reason="search_fixed_focus")
            except Exception:
                pass
            if getattr(self, "_search_inline_active", False):
                # R95: LEFT from the Search keyboard lands here.  Search stays
                # the visible scene; do not run Home hero/meta work behind it.
                self._remember_focus_position()
                _log("SEARCH_FIXED_FOCUS_WHILE_SEARCH_R95 keep_scene=1 home_meta=0")
                return
            self._remember_focus_position()
            self._clear_home_trailer_preview(reason="search_fixed_focus", stop_player=True)
            # R56: sidebar is click-only (R53 policy).  Merely focusing the fixed
            # Search button rebuilt the whole Home behind a section (laptop log:
            # 906ms GUI block, 87 items) -- keep the current scene; the search
            # overlay still opens on OK/Enter.
            if self.active_section_id == "__home__" and self._home_wall_ready:
                self._set_home_meta_from_item(reason="search_fixed_focus")
            else:
                _log("SEARCH_FIXED_FOCUS_KEEP_SCENE_R56 active_section=%s rebuild=0" % self.active_section_id)
        elif control_id == MENU_ID:
            try:
                _menu_item_v2053 = self.getControl(9000).getSelectedItem()
                _focused_sid_v2053 = (_menu_item_v2053.getProperty("PlexKM.SectionId") if _menu_item_v2053 else "") or ""
                xbmcgui.Window(10000).setProperty("PlexKM.Home.FocusedSectionId", str(_focused_sid_v2053))
            except Exception:
                pass
            _log("HOME_FOCUS_CHANGE target=MENU prev=%s prev_state=[%s] menu_state=[%s] wall_pos=%s tracked_pos=%s logical_pos=%s active_section=%s" % (prev_focus, self._home_row_state_for_log(prev_focus), self._home_row_state_for_log(MENU_ID), self._wall_selected_position(), self._wall_tracked_pos, self._logical_wall_pos, self.active_section_id))
            _frame_diag_start("content_to_sidebar", window_ms=650)
            # v2573 phase 2: Kodi can emit repeated MENU focus callbacks for the
            # exact same selected sidebar item.  V2572 already published the first
            # widget metadata atomically when a real section changes; replaying
            # _refresh_for_menu_focus()+META_SYNC for the same position only rewrites
            # dozens of Window properties and invalidates the GUI on UHD3.
            try:
                _repeat_pos_v2573 = int(self.getControl(MENU_ID).getSelectedPosition())
                _repeat_same_v2573 = bool(
                    prev_focus == MENU_ID
                    and _repeat_pos_v2573 == int(getattr(self, "active_menu_index", -999))
                    and not bool(getattr(self, "_menu_refresh_tx_active_v1906", False))
                    and not bool(getattr(self, "_menu_refresh_pending_v1906", False))
                )
            except Exception:
                _repeat_pos_v2573 = -1
                _repeat_same_v2573 = False
            if _repeat_same_v2573:
                _log("MENU_REPEAT_FOCUS_NOOP_V2573 pos=%s active_section=%s action=skip_refresh_skip_meta property_writes=0 network=0 db=0" % (
                    _repeat_pos_v2573, str(getattr(self, "active_section_id", "") or "")
                ))
                return
            if prev_focus == SECTION_CATEGORY_PANEL_ID:
                try:
                    menu = self.getControl(MENU_ID)
                    origin_pos = int(getattr(self, "_category_origin_menu_pos", -1))
                    origin_sid = str(getattr(self, "_category_origin_section_id", "") or "")
                    if origin_pos < 0 or origin_pos >= menu.size() or str(menu.getListItem(origin_pos).getProperty("section_id") or "") != origin_sid:
                        origin_pos = -1
                        for idx in range(menu.size()):
                            if str(menu.getListItem(idx).getProperty("section_id") or "") == origin_sid:
                                origin_pos = idx
                                break
                    if origin_pos >= 0:
                        menu.selectItem(origin_pos)
                        try:
                            self.getControl(MENU_COLLAPSED_ID).selectItem(origin_pos)
                        except Exception:
                            pass
                        self.active_menu_index = origin_pos
                        self._last_menu_pos = origin_pos
                        _log("CATEGORY_RETURN_SIDEBAR_V1829 section=%s pos=%s" % (origin_sid, origin_pos))
                except Exception:
                    _log("CATEGORY_RETURN_SIDEBAR_FAILED_V1829 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            try:
                if self._is_home_row_control(prev_focus) or prev_focus == WALL_ID or prev_focus in (SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID, SECTION_TAB_CATEGORY_ID):
                    self._mark_sidebar_menu_browsing("focus_menu", self.getControl(MENU_ID).getSelectedPosition())
            except Exception:
                pass
            self._remember_focus_position()
            # R38: Search -> result -> Info no longer detaches Search on sidebar
            # focus (old v2437/v2288 route jumped to the owning library and retired
            # Search, so Back could not return to the results).  It is focus-only
            # like every other Info; Search is retired when a sidebar ENTER commits
            # a destination (R18 Home / R35 section).
            # v2407: LEFT into the sidebar is a focus-owner change only. Keep the
            # live Info page on the right exactly as V2387 did. A real native UP/DOWN
            # menu selection change is handled later by the V2404 branch, which retires
            # stale Info before rendering the new destination. RIGHT therefore returns
            # directly to the still-live Info page with no mixed scene.
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                try:
                    self._info_sidebar_hold_arm_v2387(reason="menu_focus_from_info_v2407")
                except Exception:
                    _log("INFO_SIDEBAR_HOLD_ARM_FAILED_V2407 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
                self._clear_home_trailer_preview(reason="menu_focus_info_hold_v2407", stop_player=True)
                _log("INFO_SIDEBAR_MENU_ENTRY_KEEP_V2407 action=focus_only right_scene=info content_mutation=0 python_focus_write=0")
                return
            self._clear_home_trailer_preview(reason="menu_focus", stop_player=True)
            # v1864: LEFT from a section surface into its already-selected sidebar
            # item must keep the exact right-side mode and metadata.  Focus entry
            # itself is not a sidebar selection change.  Only a later native
            # UP/DOWN action may preview another menu item.
            preserve_view_v1864 = self._sidebar_entry_preserve_current_section_view_v1864(prev_focus)
            # v351: Do not reset Home/section row-anchor scroll when LEFT returns
            # from a deep widget row (for example 8470) to the sidebar.
            # Kodi XML owns the LEFT focus move, and resetting here makes the
            # entire widget stack jump back to row1 before the menu receives
            # focus.  Keep the stack position while the menu is focused; when
            # RIGHT enters row1 again, _apply_dynamic_row_anchor_scroll() moves
            # the stack back to the first widget naturally.
            if not preserve_view_v1864:
                # R134: entering sidebar never commits the highlighted item.
                _log("R134_MENU_FOCUS_PREVIEW_ONLY committed=%s" % getattr(self, "active_section_id", ""))
        elif control_id == WALL_ID:
            if prev_focus == MENU_ID:
                _frame_diag_start("sidebar_to_library_wall", window_ms=650)
            if self._is_android_v2591():
                # V2600: entering the wall is also native-first.  Do not decode
                # art, enrich metadata, start trailers/cast work, or traverse
                # the selected item synchronously on the GUI focus callback.
                self._last_focus_id = control_id
                self._schedule_wall_meta_commit_v2600()
                self._schedule_library_append_commit_v2600()
            else:
                _log("FOCUS_WALL prev=%s wall_pos=%s" % (prev_focus, self._wall_selected_position()))
                self._remember_focus_position()
                wall_li = self._focused_wall_item()
                self._info_art_preload_v2136(wall_li, reason="wall_focus")
                self._set_home_meta_from_item(wall_li, reason="wall_focus")
                self._schedule_home_trailer_preview(wall_li, reason="wall_focus")
                self._track_wall_selection("wall_focus")
                self._sync_library_selection_telemetry_v2070("wall_focus")
                self._section_index_sync_for_item(wall_li, reason="wall_focus")
                _log("LIBRARY_POSTER_AHEAD_PREFETCH_SUPPRESS_V1865 section=%s reason=wall_focus next_chunk=on_down" % self.active_section_id)
                self._schedule_info_cast_prewarm_around_focus(wall_li, reason="wall_focus_v2505")
        elif control_id == SECTION_TAB_RECOMMEND_ID:
            # v1852: onFocus must never rebuild or hide content. Kodi first
            # establishes focus, then XML onfocus sends a click that activates
            # the tab through onClick. This avoids destroying the focused state
            # while Kodi is still completing the focus transition.
            self._last_focus_id = control_id
            _log("FOCUS_SECTION_TAB_V1852 target=recommend prev=%s active_section=%s mutation=0" % (prev_focus, self.active_section_id))
        elif control_id == SECTION_TAB_LIBRARY_ID:
            self._last_focus_id = control_id
            _log("FOCUS_SECTION_TAB_V1852 target=library prev=%s active_section=%s mutation=0" % (prev_focus, self.active_section_id))
        elif control_id == SECTION_TAB_CATEGORY_ID:
            self._last_focus_id = control_id
            _log("FOCUS_SECTION_TAB_V1852 target=category prev=%s active_section=%s mutation=0" % (prev_focus, self.active_section_id))
        elif control_id == SECTION_CATEGORY_PANEL_ID:
            self._last_focus_id = control_id
            try:
                panel = self.getControl(SECTION_CATEGORY_PANEL_ID)
                li = panel.getSelectedItem() if panel and panel.size() else None
                if li:
                    self.setProperty("PlexKM.Section.CategoryFocused", li.getProperty("PlexKM.Genre") or li.getLabel())
            except Exception:
                pass
        elif control_id == SECTION_INDEX_ID:
            self._last_focus_id = control_id
            _log("FOCUS_SECTION_INDEX prev=%s active_section=%s active_key=%s" % (prev_focus, self.active_section_id, getattr(self, "_section_index_active_key", "")))
            try:
                self._section_index_select_active(reason="focus_index")
            except Exception:
                pass
        elif self._is_home_row_control(control_id):
            self._apply_dynamic_row_anchor_scroll(control_id, reason="onFocus")
            row_idx = self._home_row_index_for_control(control_id)
            pos = self._home_row_selected_position(row_idx, control_id=control_id)
            self._home_active_row = max(0, row_idx)
            if row_idx >= 0:
                old_pos = int(self._home_row_memory.get(row_idx, max(0, pos)))
                self._home_row_prev_memory[row_idx] = old_pos
                self._home_row_memory[row_idx] = max(0, pos)
            self._remember_row_reentry_focus(control_id, reason="onFocus")
            _log("HOME_FOCUS_CHANGE target=ROW prev=%s state=[%s]" % (prev_focus, self._home_row_state_for_log(control_id)))
            if prev_focus == MENU_ID:
                _frame_diag_start("sidebar_to_widget", window_ms=650)
            home_li = self._home_focused_item(control_id)
            # V2599: onFocus follows the same all-platform foreground contract as
            # directional onAction. Kodi owns focus; metadata is next-callback only.
            self._schedule_widget_focus_commit_v2596(control_id, settle_ms=0)
            _log("WIDGET_ONFOCUS_FOREGROUND_ONLY_V2599 focus=%s art_preload=0 meta_now=0 trailer=0 cast_prewarm=0 platform_split=0" % control_id)

    def _on_focus_impl_r26_step1(self, control_id):
        """Step 1 of _on_focus_impl_r26 (R76 split, moved verbatim). Logs: SETTINGS_HOME_XML_FOCUS_CONSUMED, INFO_ENTRY_PIPELINE_TARGET_FOCUS_FAILED_V2087, INFO_ENTRY_PIPELINE_TARGET_FOCUS_V2087, INFO_WIDGET_REBUILD_ONFOCUS_FAILED_V2083."""
        audit_event(self, "onFocus", control_id=control_id)
        # R155: keep the last real native focus. No correction is done here.
        try:
            if int(control_id or 0) > 0 and int(control_id) != SIDEBAR_COMMIT_PING_ID_V2595:
                self._r155_last_valid_focus = int(control_id)
        except Exception:
            pass
        _pkm_r7_focus(control_id, getattr(self, "active_section_id", ""))
        # PKM_UHD_NAV_GUARD_U3_20261011: when Kodi gives control 9000 focus, background remains
        # suspended even if no further remote key is pressed.
        try:
            _u3_side = int(control_id or 0) == int(MENU_ID)
            pkm_sort_index_v2626.note_navigation_u3(sidebar=_u3_side)
            pkm_artwork_scheduler.note_navigation_u3(sidebar=_u3_side)
        except Exception:
            pass
        try:
            if int(control_id or 0) in SECTION_SORT_ITEM_IDS:
                self._sort_head_prewarm_schedule_v2628(control_id, reason="sort_option_focus_v2628")
        except Exception:
            pass
        if control_id == MENU_ID:
            try:
                _xml_focus_v2023 = xbmcgui.Window(10000)
                if _xml_focus_v2023.getProperty("PlexKM.Home.SettingsXmlFocusV2023") == "1":
                    _xml_focus_v2023.clearProperty("PlexKM.Home.SettingsXmlFocusV2023")
                    self.clearProperty("PlexKM.Home.SettingsXmlFocusV2023")
                    _log("SETTINGS_HOME_XML_FOCUS_CONSUMED control=9000")
            except Exception:
                pass
        try:
            self._sync_legacy_library_apply_global_busy_v1883(reason="home_onfocus")
        except Exception:
            pass
        try:
            self._consume_sync_widget_refresh_gui_v1555(reason="onFocus")
        except Exception:
            pass
        try:
            self._consume_playstate_dirty(reason="onFocus")
        except Exception:
            pass
        prev_focus = self._last_focus_id
        self._sync_sidebar_state_from_focus(control_id, reason="onfocus")

        try:
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                self._inline_info_diag_log(phase="focus", reason="control_%s" % control_id)
        except Exception:
            pass
        # v2404: remember only that Kodi's native episode panel has owned focus
        # since the previous sort. No directional key is intercepted or corrected.
        try:
            if control_id in (5712, 5713) and (
                    self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
                self._info_tv_sort_user_rail_focus_v2404 = True
        except Exception:
            pass
        # v2123: action-bar UI and playback consume the same Window snapshot.
        # Publishing on action-row entry also captures Kodi-native left/right
        # episode selection without intercepting any directional key.
        try:
            if control_id in (5721, 5722, 5724, 5725, 5726, 5727, 5728, 5729, 5730):
                if self.getProperty("PlexKM.Info.IsTV") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1":
                    _selected_tv_item_v2123 = self._info_tv_selected_episode_item()
                    self._info_tv_publish_selected_version_state_v2123(
                        _selected_tv_item_v2123, reason="action_focus_%s" % control_id
                    )
                    self._info_tv_schedule_media_prewarm_v2112(_selected_tv_item_v2123, reason="action_focus_%s" % control_id)
        except Exception:
            pass
        # v2087: every inline -> different-title Info uses one entry pipeline.
        # The observed target onFocus proves native focus ownership has reached the
        # new page, but it does NOT release the scroll reset here. The existing
        # transition manager already owns a two-frame target-bind barrier; that is
        # the single release point so the reused 55961 animation state gets at
        # least one real render boundary while hidden.
        try:
            _entry_swap_v2087 = (
                xbmcgui.Window(10000).getProperty("PlexKM.Info.EntrySwapV2087") == "1"
            )
            if _entry_swap_v2087:
                _is_tv_v2087 = (
                    self.getProperty("PlexKM.Info.IsTV") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
                )
                # v2343: same-surface entry ownership must land on a target-page
                # control with a visible focus state. TV episode mode therefore
                # accepts 5721 instead of the movie-only 5001 anchor.
                _entry_focus_v2087 = control_id in ((5721, 5711, 5712, 5713) if _is_tv_v2087 else (5001,))
                if _entry_focus_v2087:
                    self._info_mark_entry_target_focus_ready_v2123(
                        control_id, reason="onfocus_target_v2123"
                    )
                    _log("INFO_ENTRY_PIPELINE_TARGET_FOCUS_V2087 focus=%s is_tv=%d action=hold_top_lock_until_transition_render_barrier" % (
                        control_id, 1 if _is_tv_v2087 else 0
                    ))
        except Exception:
            _log("INFO_ENTRY_PIPELINE_TARGET_FOCUS_FAILED_V2087 control=%s err=%s" % (
                control_id, traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGWARNING)
        try:
            self._info_widget_rebuild_try_commit_v2082(
                focus_id=control_id, reason="onfocus_control_%s_v2083" % control_id
            )
        except Exception:
            _log("INFO_WIDGET_REBUILD_ONFOCUS_FAILED_V2083 control=%s err=%s" % (
                control_id, traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGWARNING)
        # v2481: when the real Info cast panel owns focus, prewarm only the
        # actor the user actually rests on.  The GUI thread captures immutable
        # strings here; the worker never reads controls.
        if control_id in (6100, 6110):
            try:
                if (self.getProperty("PlexKM.Info.InlineActive") == "1"
                        or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
                    self._schedule_actor_profile_focus_prewarm_v2481(
                        control_id, reason="info_cast_focus_v2481"
                    )
            except Exception:
                pass
        return prev_focus

    def _log_menu_transition(self, reason="", from_control=None, extra=""):
        """Log the exact focused poster/control state immediately before focus moves to menu."""
        try:
            fid = self._safe_focus_id() if from_control is None else int(from_control)
        except Exception:
            fid = -1
        try:
            state = self._home_row_state_for_log(fid)
        except Exception:
            state = "state_error"
        try:
            wall_pos = self._wall_selected_position()
        except Exception:
            wall_pos = -1
        try:
            tracked = int(self._wall_tracked_pos or 0)
        except Exception:
            tracked = -1
        try:
            logical = int(self._logical_wall_pos or 0)
        except Exception:
            logical = -1
        try:
            active = self.active_section_id
        except Exception:
            active = ""
        try:
            _log("NAV_TO_MENU_TRACE reason=%s from_control=%s from_state=[%s] active_section=%s wall_pos=%s tracked_pos=%s logical_pos=%s extra=%s" % (
                reason, fid, state, active, wall_pos, tracked, logical, extra or ""))
        except Exception:
            pass

    def _safe_focus_id(self):
        try:
            return self.getFocusId()
        except Exception:
            return 0

    def _set_sidebar_expanded_state(self, expanded, reason=""):
        """Keep sidebar visual state explicit instead of deriving it from focus.

        Empty XML state is treated as expanded so first PKM Home paint starts open.
        After user navigation, this property records whether the sidebar should
        remain expanded or collapsed when dialogs/settings temporarily cover Home.
        This only updates skin properties; it never moves focus.
        """
        try:
            value = "1" if expanded else "0"
            old = self.getProperty("PlexKM.Sidebar.Expanded")
            if old == value:
                return
            self.setProperty("PlexKM.Sidebar.Expanded", value)
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.Sidebar.Expanded", value)
            except Exception:
                pass
            _log("SIDEBAR_STATE_SET expanded=%s reason=%s focus=%s" % (value, reason or "", self._safe_focus_id()))
        except Exception:
            _log("SIDEBAR_STATE_SET_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _sync_sidebar_state_from_focus(self, control_id, reason="focus"):
        """Update remembered sidebar state from Kodi-native focus transitions.

        Sidebar/search focus means the drawer is open. Right-side content focus
        means the drawer is collapsed.  No SetFocus or navigation action is used.
        """
        try:
            if control_id in (SEARCH_FIXED_ID, MENU_ID):
                self._set_sidebar_expanded_state(True, reason="%s_sidebar_focus_%s" % (reason, control_id))
            elif control_id in (WALL_ID, SECTION_CATEGORY_PANEL_ID, SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID, SECTION_TAB_CATEGORY_ID, 5001, 5711, 5712, 5713, 7709) or self._is_home_row_control(control_id):
                if self._is_android_v2591():
                    self._sync_collapsed_menu_selection(force=True)
                self._set_sidebar_expanded_state(False, reason="%s_content_focus_%s" % (reason, control_id))
                # v2408: Sidebar.Expanded is the only horizontal-geometry owner.
                # V2387's Info.SidebarOpen is only a temporary logical hold while
                # menu 9000 owns focus. It is written to Window 10000, Window 13000
                # and self, so a current-window-only XML ClearProperty can leave the
                # Window(10000) copy stale. Clear every scope at the actual content
                # focus boundary and release the hold without retiring Info.
                try:
                    if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                        self._info_clear_property_all("PlexKM.Info.SidebarOpen")
                        if self._info_sidebar_hold_active_v2387():
                            self._info_sidebar_hold_release_v2387(
                                reason="content_focus_return_v2408_%s" % control_id,
                                clear_info=False,
                            )
                        _log("INFO_SIDEBAR_GEOMETRY_RESET_V2408 focus=%s expanded=0 sidebar_open_all=0 right_scene=info clear_info=0" % control_id)
                except Exception:
                    _log("INFO_SIDEBAR_GEOMETRY_RESET_FAILED_V2408 focus=%s err=%s" % (
                        control_id, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
        except Exception:
            pass

    def _remember_focus_position(self):
        try:
            fid = self._safe_focus_id()
            if fid == SEARCH_FIXED_ID:
                self._last_focus_id = SEARCH_FIXED_ID
            elif fid == MENU_ID:
                self._last_menu_pos = max(0, self.getControl(MENU_ID).getSelectedPosition())
                self._last_focus_id = MENU_ID
            elif fid == WALL_ID:
                self._last_wall_pos = max(0, self._wall_selected_position())
                self._last_focus_id = WALL_ID
                self._track_wall_selection("remember_focus")
            elif self._is_home_row_control(fid):
                row_idx = self._home_row_index_for_control(fid)
                pos = self._home_row_selected_position(row_idx, control_id=fid)
                if row_idx >= 0 and pos >= 0:
                    old_pos = int(self._home_row_memory.get(row_idx, pos))
                    self._home_row_prev_memory[row_idx] = old_pos
                    self._home_row_memory[row_idx] = pos
                    self._home_active_row = row_idx
                    self._last_wall_pos = pos
                    self._last_focus_id = fid
        except Exception:
            pass


    def _sidebar_order_path(self):
        try:
            c = _ensure_core()
            base = c.ADDON.getAddonInfo("profile")
            try:
                base = c.xbmcvfs.translatePath(base)
            except Exception:
                pass
        except Exception:
            base = "special://profile/addon_data/plugin.video.km/"
        try:
            if base and not os.path.isdir(base):
                os.makedirs(base, exist_ok=True)
        except Exception:
            pass
        return os.path.join(base, "sidebar_order.json")

    def _load_sidebar_order(self):
        try:
            path = self._sidebar_order_path()
            if not os.path.exists(path):
                return []
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            order = data.get("section_order", data if isinstance(data, list) else [])
            return [str(x) for x in (order or []) if str(x or "")]
        except Exception:
            _log("SIDEBAR_ORDER_LOAD_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return []

    def _save_sidebar_order(self):
        try:
            order = [str(sec.get("section_id", "")) for sec in (self.sections or []) if str(sec.get("section_id", ""))]
            path = self._sidebar_order_path()
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "section_order": order}, f, ensure_ascii=False, indent=2)
            _log("SIDEBAR_ORDER_SAVE ok=1 count=%d path=%s" % (len(order), path))
            return True
        except Exception:
            _log("SIDEBAR_ORDER_SAVE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            return False

    def _apply_sidebar_order(self, sections):
        try:
            order = self._load_sidebar_order()
            if not order:
                return sections or []
            by_id = {str(sec.get("section_id", "")): sec for sec in (sections or []) if str(sec.get("section_id", ""))}
            ordered = []
            used = set()
            for sid in order:
                sec = by_id.get(str(sid))
                if sec is not None:
                    ordered.append(sec)
                    used.add(str(sid))
            for sec in (sections or []):
                sid = str(sec.get("section_id", ""))
                if sid not in used:
                    ordered.append(sec)
            _log("SIDEBAR_ORDER_APPLY saved=%d sections=%d" % (len(order), len(ordered)))
            return ordered
        except Exception:
            _log("SIDEBAR_ORDER_APPLY_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return sections or []

    def _set_menu_focus_color_at(self, pos, color):
        """Set focused rounded-bar color for one sidebar row in-place."""
        ok = False
        try:
            color = str(color or "FFFFFFFF")
            for cid in (MENU_ID, MENU_COLLAPSED_ID):
                try:
                    ctrl = self.getControl(cid)
                    if pos < 0 or pos >= int(ctrl.size()):
                        continue
                    li = ctrl.getListItem(pos)
                    li.setProperty("MenuFocusColor", color)
                    ok = True
                except Exception:
                    pass
        except Exception:
            pass
        return ok

    def _set_menu_reorder_focus_color(self, sid=None, color="FFFFC400"):
        """Highlight the active reorder item in yellow without rebuilding menu."""
        try:
            sid = str(sid if sid is not None else getattr(self, "_menu_reorder_sid", "") or "")
            if not sid:
                return False
            pos = self._menu_pos_for_section_sid(sid)
            if pos < 0:
                return False
            return self._set_menu_focus_color_at(pos, color)
        except Exception:
            return False


    def _show_pkm_notice(self, title, line1="", line2="", ms=2600):
        """Show PKM styled notice by setting skin properties only.

        Data-only Python split: delegates to pkm_notify, which only sets
        Window(10000) properties for the existing XML overlay.  It does not
        change focus, navigation, actions, playback, or window flow.
        """
        try:
            return bool(pkm_notify.pkm_show_notice(title, line1, line2, ms=ms))
        except Exception:
            return False

    def _start_menu_reorder(self):
        sid, pos, li = self._selected_menu_section_sid()
        if not sid:
            try:
                label = li.getLabel() if li is not None else ""
            except Exception:
                label = ""
            _log("SIDEBAR_REORDER_START_SKIP reason=not_section pos=%s label=%s" % (pos, label))
            return False
        self._menu_reorder_mode = True
        self._menu_reorder_sid = sid
        self._menu_reorder_dirty = False
        self._set_menu_reorder_focus_color(sid, "FFFFC400")
        try:
            label = li.getLabel()
        except Exception:
            label = sid
        _log("SIDEBAR_REORDER_START sid=%s pos=%s label=%s" % (sid, pos, label))
        try:
            if not self._show_pkm_notice("Plex KM", "상하 이동으로 메뉴 위치 변경", "확인 버튼으로 저장", ms=2600):
                self._show_pkm_notice("Plex KM", "상하 이동으로 메뉴 위치 변경\n확인 버튼으로 저장", "", ms=2600)
        except Exception:
            pass
        return True

    def _move_menu_reorder_item(self, delta):
        try:
            sid = str(getattr(self, "_menu_reorder_sid", "") or "")
            if not sid:
                return False
            idx = -1
            for i, sec in enumerate(self.sections or []):
                if str(sec.get("section_id", "")) == sid:
                    idx = i
                    break
            if idx < 0:
                _log("SIDEBAR_REORDER_MOVE_SKIP reason=sid_not_found sid=%s" % sid, xbmc.LOGWARNING)
                return False
            new_idx = max(0, min(len(self.sections) - 1, idx + int(delta)))
            if new_idx == idx:
                _log("SIDEBAR_REORDER_MOVE_EDGE sid=%s idx=%d delta=%s" % (sid, idx, delta))
                return True
            # v249: do not rebuild the whole sidebar while dragging.  Rebuilding
            # the ControlList on every UP/DOWN causes the white focus bar and the
            # menu rows themselves to jitter.  Swap the backing order and update
            # only the two affected visible list rows in place.
            old_pos = 1 + idx
            new_pos = 1 + new_idx
            sec = self.sections.pop(idx)
            self.sections.insert(new_idx, sec)
            self._menu_reorder_dirty = True
            try:
                self._update_menu_section_item_at(old_pos, self.sections[idx])
            except Exception:
                pass
            try:
                self._update_menu_section_item_at(new_pos, self.sections[new_idx])
            except Exception:
                pass
            # Keep visual reorder state stable: the moved item stays yellow,
            # the row it swapped with returns to normal white.
            try:
                self._set_menu_focus_color_at(old_pos, "FFFFFFFF")
                self._set_menu_focus_color_at(new_pos, "FFFFC400")
            except Exception:
                pass
            pos = new_pos
            if pos >= 0:
                try:
                    self.getControl(MENU_ID).selectItem(pos)
                    self.getControl(MENU_COLLAPSED_ID).selectItem(pos)
                except Exception:
                    pass
                self._last_menu_pos = pos
                self.active_menu_index = pos
            _log("SIDEBAR_REORDER_MOVE_INPLACE sid=%s from=%d to=%d menu_pos=%s" % (sid, idx, new_idx, pos))
            return True
        except Exception:
            _log("SIDEBAR_REORDER_MOVE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            return False

    def _finish_menu_reorder(self, save=True, reason=""):
        try:
            sid = str(getattr(self, "_menu_reorder_sid", "") or "")
            dirty = bool(getattr(self, "_menu_reorder_dirty", False))
            if save and dirty:
                self._save_sidebar_order()
            # Restore focused sidebar bar from yellow back to white when edit ends.
            try:
                self._set_menu_reorder_focus_color(sid, "FFFFFFFF")
            except Exception:
                pass
            self._menu_reorder_mode = False
            self._menu_reorder_sid = ""
            self._menu_reorder_dirty = False
            pos = self._menu_pos_for_section_sid(sid) if sid else -1
            if pos >= 0:
                self.getControl(MENU_ID).selectItem(pos)
                try:
                    self.getControl(MENU_COLLAPSED_ID).selectItem(pos)
                except Exception:
                    pass
                self._focus_menu_control_v1993(reason="direct_menu_handoff_v1993")
                self._last_menu_pos = pos
            _log("SIDEBAR_REORDER_FINISH save=%s dirty=%s reason=%s sid=%s pos=%s" % (str(save).lower(), str(dirty).lower(), reason, sid, pos))
            try:
                if save:
                    line1 = "사이드 메뉴 순서 저장"
                    line2 = "변경된 메뉴 위치가 반영되었습니다"
                else:
                    line1 = "사이드 메뉴 순서 변경 취소"
                    line2 = "기존 메뉴 위치를 유지합니다"
                self._show_pkm_notice("Plex KM", line1, line2, ms=2400)
            except Exception:
                pass
            return True
        except Exception:
            _log("SIDEBAR_REORDER_FINISH_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            self._menu_reorder_mode = False
            return False

    def _menu_icon_name_for(self, label, kind=""):
        try:
            text = label or ""
            up = text.upper()
            if kind == "youtube":
                return "youtube"
            if kind == "home" or text == "홈":
                return "home"
            if kind in ("kodi_settings", "addon_settings") or text == "설정" or "PLEX KM" in up or "PKM" in up:
                return "settings"
            # v1507: match Plex HTPC sidebar family: concert/movie-like sections use filmstrip.
            if "콘서트" in text:
                return "movie"
            if "뮤직" in text or "MV" in up:
                return "mv"
            if "드라마" in text or "방영" in text or "다큐" in text or "TV" in up:
                return "drama"
            if "영화" in text or kind == "section":
                return "movie"
            if kind == "search" or text == "검색":
                return "search"
            return "movie"
        except Exception:
            return "movie"

    def _menu_icon_for(self, label, kind="", state="default"):
        """Return plugin-local sidebar icon texture.

        default  = collapsed rail / non-focused menu icon
        highlight = focused expanded menu icon on the white rounded bar
        """
        try:
            base = "special://home/addons/plugin.video.km/resources/skins/Default/media/navigation/menu/"
            name = self._menu_icon_name_for(label, kind)
            suffix = "highlight" if state == "highlight" else "default"
            if name == "search":
                return base + "search_%s.png" % suffix
            return base + "%s_%s.png" % (name, suffix)
        except Exception:
            return "special://home/addons/plugin.video.km/resources/skins/Default/media/navigation/menu/movie_default.png"

    def _menu_icon_r81_for(self, label, kind="", section_type=""):
        """R81 Plex-style sidebar glyphs (white; the skin tints them on focus).

        Library icons follow the Plex section type: show -> TV, movie -> film,
        a movie library whose title says UHD/4K -> 4K badge."""
        base = "special://home/addons/plugin.video.km/resources/skins/Default/media/navigation/menu/r81/"
        try:
            text = label or ""
            up = text.upper()
            st = str(section_type or "").lower()
            if kind == "youtube":
                name = "sb_youtube"
            elif kind == "home":
                name = "sb_home"
            elif kind in ("kodi_settings", "addon_settings"):
                name = "sb_settings"
            elif kind == "search":
                name = "sb_search"
            elif st == "show":
                name = "sb_tv"
            elif "UHD" in up or "4K" in up:
                name = "sb_uhd"
            elif st == "movie":
                name = "sb_movie"
            elif self._menu_icon_name_for(label, kind) == "drama":
                name = "sb_tv"
            else:
                name = "sb_movie"
            return base + name + ".png"
        except Exception:
            return base + "sb_movie.png"

    def _set_menu_icon(self, li, label, kind=""):
        try:
            try:
                st_r81 = li.getProperty("section_type") or ""
            except Exception:
                st_r81 = ""
            icon_r81 = self._menu_icon_r81_for(label, kind, st_r81)
            li.setProperty("MenuIconDefaultTexture", icon_r81)
            li.setProperty("MenuIconHighlightTexture", icon_r81)
            li.setProperty("MenuIconTexture", icon_r81)
            # v250: focused sidebar rounded bar is normally white, but the
            # item being reordered is yellow while edit mode is active.
            if not li.getProperty("MenuFocusColor"):
                li.setProperty("MenuFocusColor", "FFFFFFFF")
        except Exception:
            pass

    def _clone_menu_item_for_collapsed(self, li):
        try:
            clone = xbmcgui.ListItem(label=li.getLabel())
            for key in ("kind", "index", "section_id", "section_title", "section_type", "total", "MenuIconTexture", "MenuIconDefaultTexture", "MenuIconHighlightTexture", "MenuFocusColor"):
                val = li.getProperty(key)
                if val:
                    clone.setProperty(key, val)
            return clone
        except Exception:
            return li

    def _sync_collapsed_menu_selection(self, force=False):
        try:
            # V2595: 9001 is invisible while expanded 9000 owns focus. Mirroring
            # selectItem() on every key makes Kodi maintain two scrolling lists and
            # is a direct source of midpoint bounce on the weak box. Sync it once
            # when collapsing/initializing instead.
            # V2598: expanded sidebar 9000 is the sole navigation owner on every
            # platform. Never mirror its per-key selection into hidden 9001.
            if not force:
                if self._safe_focus_id() == MENU_ID or self.getProperty("PlexKM.Sidebar.Expanded") == "1":
                    return
            pos = self.getControl(MENU_ID).getSelectedPosition()
            collapsed = self.getControl(MENU_COLLAPSED_ID)
            if collapsed.size() > 0:
                collapsed.selectItem(min(max(0, pos), collapsed.size() - 1))
        except Exception:
            pass

    def _build_menu(self):
        """Build the sidebar without invalidating live menu focus.

        v2042: ControlList.reset() destroys the currently focused list contents.
        During initial-sync Home refresh Kodi then falls back to bootstrap control
        100 until widgets finish rendering.  Build the desired rows first and,
        when menu 9000 already contains rows, mutate that same focused control in
        place instead of resetting it.  This is a data update only: no delayed
        focus write, retry loop, timer, or post-render focus repair.
        """
        desired = []

        home = xbmcgui.ListItem(label="홈")
        home.setProperty("kind", "home")
        self._set_menu_icon(home, "홈", "home")
        desired.append(home)

        seen_section_ids_v1927 = set()
        for idx, section in enumerate(self.sections):
            sid = str(section.get("section_id", ""))
            if not sid or sid in seen_section_ids_v1927:
                _log("SIDEBAR_DUPLICATE_SECTION_SKIP_V1927 section=%s title=%s" % (
                    sid or "-", _short_log_value(section.get("title", "") or "")
                ), xbmc.LOGWARNING)
                continue
            seen_section_ids_v1927.add(sid)
            raw_title = section.get("title", "") or sid
            title = _display_library_title(raw_title)
            total = _safe_int(section.get("item_count"), 0)
            if total <= 0:
                # V2595 UHD runtime-minimal: sidebar labels do not need an exact
                # local DB count to move focus.  Seven synchronous count_items()
                # fallbacks during menu construction are pure startup overhead on
                # the weak Android box; let the section screen resolve totals later.
                if self._is_android_v2591():
                    total = 0
                else:
                    try:
                        total = core.count_items(sid, genre=(getattr(self, "_active_genre_filter", "") or None))
                    except Exception:
                        total = 0
            li = xbmcgui.ListItem(label=title)
            li.setProperty("kind", "section")
            li.setProperty("index", str(idx))
            li.setProperty("section_id", sid)
            li.setProperty("section_title", title)
            li.setProperty("section_title_raw", str(raw_title or ""))
            li.setProperty("section_type", section.get("section_type", ""))
            li.setProperty("total", str(total))
            self._set_menu_icon(li, title, "section")
            # R81: thin divider above the first library row.
            li.setProperty("PlexKM.SidebarDivider", "1" if len(desired) == 1 else "")
            desired.append(li)

        # R79: YouTube sits after the libraries (section reorder keeps using
        # positions 1..N) and before the settings entries.
        yt_r79 = xbmcgui.ListItem(label="유튜브")
        yt_r79.setProperty("kind", "youtube")
        self._set_menu_icon(yt_r79, "유튜브", "youtube")
        desired.append(yt_r79)

        for label, kind in (("Plex KM 설정", "addon_settings"), ("Kodi 설정", "kodi_settings")):
            li = xbmcgui.ListItem(label=label)
            li.setProperty("kind", kind)
            self._set_menu_icon(li, label, kind)
            li.setProperty("PlexKM.SidebarDivider", "1" if kind == "addon_settings" else "")
            desired.append(li)

        # R151: Kodi Omega fixedlist has one symmetric <movement> cursor range.
        # Four inert *visual* tail rows let its real last item stop at row four,
        # rather than slide to the bottom of the 880px viewport. Do not put
        # these in the collapsed mirror or assign them actions/icons/labels.
        real_count_r151 = len(desired)
        self._sidebar_real_count_r151 = real_count_r151
        for pad_idx_r151 in range(4):
            pad_r151 = xbmcgui.ListItem(label="")
            pad_r151.setProperty("kind", "r151_padding")
            pad_r151.setProperty("PlexKM.Sidebar.PaddingR151", "1")
            desired.append(pad_r151)

        menu = self.getControl(MENU_ID)
        try:
            old_size = int(menu.size() or 0)
        except Exception:
            old_size = 0
        try:
            focus_before = int(self.getFocusId())
        except Exception:
            focus_before = -1

        prop_keys = (
            "kind", "index", "section_id", "section_title", "section_title_raw",
            "section_type", "total", "MenuIconTexture", "MenuIconDefaultTexture",
            "MenuIconHighlightTexture", "MenuFocusColor", "PlexKM.Sidebar.PaddingR151",
            "PlexKM.SidebarDivider",
        )

        in_place = old_size > 0
        if in_place:
            try:
                common = min(old_size, len(desired))
                for pos in range(common):
                    dst = menu.getListItem(pos)
                    src = desired[pos]
                    dst.setLabel(src.getLabel())
                    for key in prop_keys:
                        dst.setProperty(key, src.getProperty(key) or "")
                for pos in range(common, len(desired)):
                    menu.addItem(desired[pos])
                for pos in range(old_size - 1, len(desired) - 1, -1):
                    menu.removeItem(pos)
            except Exception:
                in_place = False
                _log("SIDEBAR_INPLACE_BUILD_FAILED_V2042 focus=%s old=%s new=%s err=%s" % (
                    focus_before, old_size, len(desired), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        if not in_place:
            menu.reset()
            for li in desired:
                menu.addItem(li)

        # The collapsed mirror is never the focus owner while the expanded list
        # is visible, so it can be rebuilt independently without affecting 9000.
        try:
            collapsed = self.getControl(MENU_COLLAPSED_ID)
            collapsed.reset()
            for li in desired[:real_count_r151]:
                collapsed.addItem(self._clone_menu_item_for_collapsed(li))
        except Exception:
            _log("SIDEBAR_COLLAPSED_REBUILD_SKIPPED_V2042 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

        self._sidebar_set_user_r81()
        self.menu_ready = True
        self._sidebar_prepare_warmup_later()
        _log("SIDEBAR_BUILD_V2042 mode=%s old=%d new=%d focus_before=%d focus_after=%d" % (
            "in_place" if in_place else "initial_reset", old_size, real_count_r151,
            focus_before, self._safe_focus_id()
        ))

    def _sidebar_set_user_r81(self):
        """R81: profile row of the Plex-style sidebar (name + initial avatar).
        Display only until Plex Home user switching is implemented."""
        try:
            name = (xbmcaddon.Addon("plugin.video.km").getSetting("plex_account_name") or "").strip()
        except Exception:
            name = ""
        if not name:
            # R108: no Plex account (Kodi-library only) -> the Kodi profile name.
            try:
                kodi_profile = (xbmc.getInfoLabel("System.ProfileName") or "").strip()
            except Exception:
                kodi_profile = ""
            name = "Kodi" if (not kodi_profile or kodi_profile.lower() == "master user") else kodi_profile
        try:
            initial = name[:1].upper()
        except Exception:
            initial = ""
        thumb = ""
        try:
            from resources.lib import pkm_profile_r82
            st_r82 = pkm_profile_r82.load_state()
            if str(st_r82.get("title") or "") == name:
                thumb = str(st_r82.get("thumb") or "")
        except Exception:
            thumb = ""
        try:
            self.setProperty("PlexKM.Sidebar.UserName", name)
            self.setProperty("PlexKM.Sidebar.UserInitial", initial)
            self.setProperty("PlexKM.Sidebar.UserThumb", thumb)
        except Exception:
            pass

    # ------------------------------------------------------------ R82 profiles
    def _profile_virtual_nav_r82(self, aid):
        """UP on search (8990) highlights the profile row; DOWN returns to search.
        Kodi focus stays on 8990, so the sidebar expand/collapse model is unchanged.
        Returns True when the key was fully handled here."""
        try:
            fid = int(self.getFocusId())
        except Exception:
            return False
        prof = self.getProperty("PlexKM.Sidebar.ProfileFocus") == "1"
        # Kodi has already applied the navigation when this callback runs, so the
        # UP that *arrives* on search (from the list) must not jump to the profile.
        prev_fid = getattr(self, "_profile_prev_fid_r82", -1)
        self._profile_prev_fid_r82 = fid
        if fid != SEARCH_FIXED_ID:
            if prof:
                self.clearProperty("PlexKM.Sidebar.ProfileFocus")
            return False
        if aid == 3 and prev_fid != SEARCH_FIXED_ID:
            return False
        if aid == 3:  # up
            if not prof:
                self.setProperty("PlexKM.Sidebar.ProfileFocus", "1")
            return True
        if prof:
            if aid == 4:  # down -> back on search
                self.clearProperty("PlexKM.Sidebar.ProfileFocus")
                return True
            if aid in (1, 2, 9, 10, 92, 216, 247):
                self.clearProperty("PlexKM.Sidebar.ProfileFocus")
        return False

    def _open_profile_picker_r82(self):
        # R108: profile switching is Plex Home users; nothing to switch without Plex.
        try:
            from resources.lib import pkm_sources as _pkm_sources_r108
            if not _pkm_sources_r108.plex_credentials_ready():
                try:
                    from resources.lib import pkm_notify as _pkm_notify_r108
                    _pkm_notify_r108.pkm_show_notice("프로필", "Plex 서버를 연결하면 프로필을 전환할 수 있습니다", "", ms=2600)
                except Exception:
                    pass
                return
        except Exception:
            pass
        now_ms = self._now_ms()
        if now_ms - int(getattr(self, "_profile_open_ms_r82", 0) or 0) < 1500:
            return
        self._profile_open_ms_r82 = now_ms
        res = None
        try:
            from resources.lib import pkm_profile_r82
            res = pkm_profile_r82.run_switch_flow(_ensure_core(), home_win=self)
        except Exception:
            _log("PROFILE_FLOW_FAILED_R82 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        self._profile_open_ms_r82 = self._now_ms()
        if res:
            self.clearProperty("PlexKM.Sidebar.ProfileFocus")
            self._after_profile_switch_r82(res)

    def _after_profile_switch_r82(self, res):
        """New profile is published: reload everything that depends on the viewer."""
        from resources.lib import pkm_profile_r82
        name = str((res.get("user") or {}).get("title") or "")
        notice = ""
        try:
            notice = pkm_notify.pkm_notice_set("프로필 전환", "%s 프로필로 전환합니다." % name,
                                               "시청 기록을 불러오는 중…", sticky=True, force_replace=True)
        except Exception:
            pass
        t0 = self._now_ms()
        try:
            pkm_profile_r82.resync_watched(_ensure_core())
        except Exception:
            _log("PROFILE_RESYNC_FAILED_R82 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        self._sidebar_set_user_r81()
        try:
            self._load_sections(refresh=True)
            self._build_menu()
        except Exception:
            _log("PROFILE_MENU_RELOAD_FAILED_R82 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            self._home_rows_cache = None
            self._home_wall_ready = False
            self._plex_update_dirty_home = True
            self._r143_home_built_ms_r52 = 0
            self._profile_go_home_r83()
        except Exception:
            _log("PROFILE_HOME_RELOAD_FAILED_R82 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            if notice:
                pkm_notify.pkm_notice_clear(expected_token=notice, force=True)
            pkm_notify.pkm_show_notice("프로필 전환", "%s 프로필입니다." % name, "", ms=2200)
        except Exception:
            pass
        _log("PROFILE_SWITCH_DONE_R82 name=%s ms=%d" % (name, self._now_ms() - t0))

    def _profile_go_home_r83(self):
        """R83: a profile switch lands on a fresh Home (as Plex does).  R82 only
        redrew Home when Home was the active screen, so a library screen kept
        the previous user's watched marks until the user clicked Home."""
        on_home = str(getattr(self, "active_section_id", "") or "") == "__home__"
        menu = None
        home_pos = -1
        try:
            menu = self.getControl(MENU_ID)
            for i in range(menu.size()):
                if menu.getListItem(i).getProperty("kind") == "home":
                    home_pos = i
                    break
        except Exception:
            menu = None
        if on_home:
            self._show_home_wall(force=True)
        if menu is None or home_pos < 0:
            if not on_home:
                self._show_home_wall(force=True)
            _log("PROFILE_GO_HOME_R83 on_home=%d pos=-1" % int(on_home))
            return
        self.clearProperty("PlexKM.Sidebar.ProfileFocus")
        menu.selectItem(home_pos)
        self.setFocusId(MENU_ID)
        for _i in range(10):
            if self._safe_focus_id() == MENU_ID:
                break
            xbmc.sleep(20)
        if on_home:
            # Same fold-away as a sidebar Home ENTER (R82).
            self._sidebar_enter_collapse_r82("home")
        else:
            # Exactly the sidebar Home ENTER path (transition hold, first row, fold).
            self._activate_menu_item()
        _log("PROFILE_GO_HOME_R83 on_home=%d pos=%d focus=%s" % (int(on_home), home_pos, self._safe_focus_id()))

    def _mark_sidebar_menu_browsing(self, aid, pos=-1):
        try:
            now_ms = self._now_ms()
            _sidebar_quiet_v2591 = 1400 if xbmc.getCondVisibility("System.Platform.Android") else 900
            self._sidebar_menu_browsing_until_ms = now_ms + _sidebar_quiet_v2591
            try:
                _w_v2591 = xbmcgui.Window(10000)
                _w_v2591.setProperty("PlexKM.Home.UserNavigatingUntilEpochMsV2386", str(int(time.time() * 1000) + (5000 if _sidebar_quiet_v2591 > 900 else 1800)))
                if _sidebar_quiet_v2591 > 900:
                    _w_v2591.setProperty("PlexKM.UHD3.ForegroundIsolationV2591", "1")
            except Exception:
                pass
            # v1294: invalidate any delayed clear created by the previous section
            # commit.  v1293 could set SidebarBrowsing for a new native menu move,
            # then an older clear thread from the previous preview commit erased the
            # flag a few ms later.  That reopened the door for stale widget focus /
            # transition work while the user was still only browsing the sidebar.
            self._sidebar_menu_browsing_clear_token = ("mark", now_ms, pos)
            self.setProperty("PlexKM.Sidebar.Browsing", "1")
            xbmcgui.Window(10000).setProperty("PlexKM.Sidebar.Browsing", "1")
            _log("SIDEBAR_MENU_BROWSING_SET aid=%s pos=%s until=%s v1294_clear_guard=1" % (aid, pos, int(self._sidebar_menu_browsing_until_ms)))
        except Exception:
            pass

    def _clear_sidebar_menu_browsing_later(self, reason="", delay_ms=620):
        try:
            token = int(time.time() * 1000)
            self._sidebar_menu_browsing_clear_token = token
            def _clear():
                try:
                    xbmc.sleep(int(delay_ms or 620))
                    if getattr(self, "_sidebar_menu_browsing_clear_token", None) != token:
                        return
                    self.clearProperty("PlexKM.Sidebar.Browsing")
                    xbmcgui.Window(10000).clearProperty("PlexKM.Sidebar.Browsing")
                    _log("SIDEBAR_MENU_BROWSING_CLEAR reason=%s token=%s" % (reason or "", token))
                except Exception:
                    pass
            _PKMHomeThreadV2151(target=_clear, name="PlexKMSidebarBrowsingClear", daemon=True).start()
        except Exception:
            pass

    def _sync_sidebar_selection_owner_v1887(self, aid=0, reason=""):
        """Make content ownership follow Kodi XML's selected sidebar item.

        This performs no selectItem() or setFocusId() on the expanded menu.  It
        only detects selection drift and runs the normal content transaction for
        the item Kodi has already selected.
        """
        try:
            if not bool(getattr(self, "menu_ready", False)):
                return False
            if self.getProperty("PlexKM.Info.InlineActive") == "1":
                return False
            if self.getProperty("PlexKM.Search.InlineActive") == "1":
                return False
            snap = self._sidebar_selection_snapshot_v1887()
            if not snap:
                return False
            try:
                active_pos = int(getattr(self, "active_menu_index", -1))
            except Exception:
                active_pos = -1
            if int(snap["pos"]) == active_pos:
                return False
            _log("SIDEBAR_SELECTION_OWNER_DRIFT_V1887 reason=%s aid=%s selected_pos=%s selected_kind=%s selected_section=%s selected_label=%s active_menu_index=%s active_section=%s action=refresh_selected_no_focus_write" % (
                reason or "", aid, snap["pos"], snap["kind"], snap["sid"],
                _short_log_value(snap["label"]), active_pos,
                getattr(self, "active_section_id", "") or "",
            ), xbmc.LOGWARNING)
            self._refresh_menu_selection_after_native_action(aid)
            return True
        except Exception:
            _log("SIDEBAR_SELECTION_OWNER_SYNC_FAILED_V1887 reason=%s aid=%s err=%s" % (
                reason or "", aid, traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGERROR)
            return False

    def _refresh_menu_selection_after_native_action(self, aid):
        menu = self.getControl(MENU_ID)
        try:
            size = int(menu.size())
        except Exception:
            size = 0
        if size <= 0:
            _log("MENU_FOCUS_OBSERVE_SKIPPED reason=empty")
            return
        try:
            pos = int(menu.getSelectedPosition())
        except Exception:
            pos = 0
        pos = max(0, min(size - 1, pos))
        # R151: keep navigation on the last real item. Tail rows are blank
        # fixedlist geometry, never navigable destinations. Normal UP/DOWN
        # stays wholly native and has no Python focus repair/second movement.
        real_count_r151 = int(getattr(self, "_sidebar_real_count_r151", size) or size)
        if pos >= real_count_r151:
            pos = max(0, real_count_r151 - 1)
            menu.selectItem(pos)
            return
        self._mark_sidebar_menu_browsing(aid, pos)
        # R103: any sidebar move cancels a not-yet-started focus prefetch dwell.
        self._prefetch_dwell_token_r103 = int(getattr(self, "_prefetch_dwell_token_r103", 0) or 0) + 1
        # R134: remove stale queued prefetch entries when native focus changes.
        # An already running worker may finish, but must not publish a scene.
        try:
            lock_r134 = self._sidebar_prepare_state()
            with lock_r134:
                old_r134 = list(self._sidebar_prepare_queue)
                self._sidebar_prepare_queue[:] = []
                for entry_r134 in old_r134:
                    key_r134 = entry_r134[0]
                    self._sidebar_prepare_generation[key_r134] = self._sidebar_prepare_generation.get(key_r134, 0) + 1
                    self._sidebar_prepare_pending.discard(key_r134)
                if old_r134:
                    _log("R134_PREFETCH_QUEUE_CANCEL count=%d" % len(old_r134))
        except Exception:
            pass
        item = None
        try:
            item = menu.getListItem(pos)
        except Exception:
            item = self._selected_menu_item()
        label = item.getLabel() if item else ""
        kind = item.getProperty("kind") if item else ""
        sid = item.getProperty("section_id") if item else ""
        # V2595: spinner timing is anchored to the physical native focus move,
        # even though the expensive right-side render is intentionally debounced.
        if self._is_android_v2591() and kind == "section":
            try:
                self._sidebar_ui_select_started_v1650 = self._now_ms()
                self._sidebar_ui_select_section_v1650 = str(sid or "")
                self._sidebar_ui_select_from_v1650 = str(getattr(self, "active_menu_index", -1))
                self._sidebar_ui_select_to_v1650 = str(pos)
                self._sidebar_ui_select_logged_v1650 = False
            except Exception:
                pass
        _log("MENU_FOCUS_OBSERVE aid=%s pos=%s size=%s kind=%s section=%s label=%s" % (
            aid, pos, size, kind, sid, _short_log_value(label)))
        # v1815: Native sidebar selection may move many times per second while
        # the user holds UP/DOWN or uses PageUp/PageDown.  Do not rebuild/publish
        # the right-side library view for every transient focus.  Keep the
        # currently published scene intact and commit only when the same menu
        # position remains selected for the settle interval.
        # v2173 diagnostic: the native list has already moved at this point.
        # Measure only how long the subsequent right-side scene transaction
        # keeps this Kodi action callback occupied.  No focus/navigation
        # behavior is changed by this instrumentation.
        nav_commit_t0_v2173 = time.perf_counter()
        self._schedule_sidebar_focus_commit_v1815(pos, kind, sid, label, aid)
        try:
            nav_commit_ms_v2173 = (time.perf_counter() - nav_commit_t0_v2173) * 1000.0
            _log("SIDEBAR_NATIVE_NAV_COMMIT_TIMING_V2173 aid=%s pos=%s kind=%s section=%s label=%s elapsed_ms=%.1f active_menu_index=%s" % (
                aid, pos, kind or "-", sid or "-", _short_log_value(label),
                nav_commit_ms_v2173, getattr(self, "active_menu_index", -1),
            ))
        except Exception:
            pass
        return

    def _sidebar_focus_commit_ping_v2595(self):
        """Commit one settled sidebar target on Kodi's GUI callback thread."""
        try:
            if self._closing_event_v1841.is_set():
                return False
            with self._sidebar_debounce_lock_v2595:
                self._sidebar_commit_posted_v2599 = False
                commit = self._sidebar_debounce_commit_v2595
                self._sidebar_debounce_commit_v2595 = None
            if not commit:
                return False
            token, pos, kind, sid, label, aid = commit
            try:
                current_pos = int(self.getControl(MENU_ID).getSelectedPosition())
            except Exception:
                current_pos = -1
            if current_pos != int(pos):
                _log("SIDEBAR_DEBOUNCE_STALE_DROP_V2595 token=%s target=%s current=%s section=%s render=0" % (
                    token, pos, current_pos, sid or ""
                ))
                return False
            _sidebar_settle_v2600 = 40 if self._is_android_v2591() else 0
            _log("SIDEBAR_COMMIT_V2600 token=%s pos=%s kind=%s section=%s settle_ms=%d next_gui_callback=1 worker=%d xml_move_only=1" % (
                token, pos, kind or "-", sid or "-", _sidebar_settle_v2600, 1 if self._is_android_v2591() else 0
            ))
            # R134: native sidebar focus is a preview only. ENTER in onClick(MENU_ID)
            # owns the committed scene. Do not call the old focus refresh here.
            _scene_t0_v2600 = time.perf_counter()
            _log("R134_SIDEBAR_PREVIEW_ONLY pos=%s kind=%s section=%s committed=%s" % (
                pos, kind or "-", sid or "-", getattr(self, "active_section_id", "")))
            # R143: HOME is the sole focus-to-activate sidebar exception.
            # Keep all section entries ENTER-only; use the normal Home scene
            # publisher so XML RIGHT can enter the Home widget rows afterwards.
            if kind == "home":
                try:
                    if self._is_connection_settings_focus_required_v1381():
                        _log("R143_HOME_FOCUS_SKIP reason=connection_settings")
                    elif str(getattr(self, "active_section_id", "") or "") != "__home__" or not bool(getattr(self, "_home_wall_ready", False)):
                        # R53: Home is ENTER-only like every section (user policy).
                        # Focus-to-activate produced a blank right pane while the
                        # source scene was retired before Home rows were ready.
                        # Startup Home is shown by onInit, not by this preview.
                        _log("R143_HOME_FOCUS_PREVIEW_DISABLED_R53 pos=%s committed=%s action=enter_only" % (pos, getattr(self, "active_section_id", "")))
                    else:
                        _log("R143_HOME_FOCUS_ALREADY_ACTIVE pos=%s" % pos)
                except Exception:
                    _log("R143_HOME_FOCUS_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            # Reuse the existing serialized, data-only sidebar prefetch worker.
            # No Kodi control writes, no A/B scene publish before ENTER.
            if kind == "section" and sid:
                try:
                    # R103: prefetch only when the focus rests on the item.
                    # Shield: a pass-through focus on 영화-UHD started a 10.9 s
                    # build that the next ENTER (방영-기타) had to wait behind.
                    self._sidebar_focus_prefetch_dwell_r103(sid, label)
                    _log("R134_FOCUS_PREFETCH section=%s token=%s dwell_ms=%d" % (sid, token, SIDEBAR_PREFETCH_DWELL_MS_R103))
                except Exception:
                    _log("R134_FOCUS_PREFETCH_FAILED section=%s" % sid, xbmc.LOGWARNING)
            _scene_ms_v2600 = (time.perf_counter() - _scene_t0_v2600) * 1000.0
            _log("SIDEBAR_SCENE_COST_V2600 token=%s pos=%s kind=%s section=%s elapsed_ms=%.1f python_focus_write=0 xml_move_only=1" % (
            # V2641_TRACE_SITE: sidebar scene elapsed is completion-observation; correlate token with UI_SELECT/WIDGET_STACK_TRANSITION/LIBRARY_VISIBLE and heartbeat before treating as visual latency.
                token, pos, kind or "-", sid or "-", _scene_ms_v2600
            ))
            try:
                _kpi_win_v2604 = xbmcgui.Window(10000)
                _kpi_win_v2604.setProperty("PlexKM.KPI.SidebarSceneMs", "%.1f" % _scene_ms_v2600)
                _kpi_win_v2604.setProperty("PlexKM.KPI.SidebarStamp", str(self._now_ms()))
            except Exception:
                pass
            try:
                pkm_uhd_diag_v2600.event(
                    "SIDEBAR_SCENE",
                    extra="pos=%s kind=%s section=%s scene_ms=%.1f python_move=0" % (pos, kind or "-", sid or "-", _scene_ms_v2600),
                )
            except Exception:
                pass
            return True
        except Exception:
            _log("SIDEBAR_DEBOUNCE_COMMIT_FAILED_V2595 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            return False

    def _schedule_sidebar_focus_commit_v1815(self, pos, kind, sid, label, aid, settle_ms=250):
        """Kodi XML 9000 is the sole sidebar mover; Python renders content only.

        Desktop keeps V2599 next-GUI commit.  On Android, the visible sidebar
        focus still moves immediately in XML, but expensive right-side scene work
        is coalesced for 120 ms so a rapid UP/DOWN burst does not rebuild every
        intermediate destination and queue remote input.
        """
        try:
            if self._closing_event_v1841.is_set():
                return
            token = int(getattr(self, "_sidebar_focus_commit_token_v1815", 0) or 0) + 1
            self._sidebar_focus_commit_token_v1815 = token
            self._sidebar_focus_pending_pos_v1815 = int(pos)
            self._sidebar_focus_pending_sid_v1815 = str(sid or "")
            commit = (token, int(pos), str(kind or ""), str(sid or ""), str(label or ""), int(aid or 0))
            with self._sidebar_debounce_lock_v2595:
                self._sidebar_debounce_commit_v2595 = commit
                self._sidebar_debounce_pending_v2595 = None
                if self._sidebar_commit_posted_v2599:
                    return
                self._sidebar_commit_posted_v2599 = True

            if not self._is_android_v2591():
                try:
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    with self._sidebar_debounce_lock_v2595:
                        self._sidebar_commit_posted_v2599 = False
                    raise
                return

            def _coalesce_sidebar_v2600():
                posted_v2600 = False
                try:
                    while not self._closing_event_v1841.is_set():
                        with self._sidebar_debounce_lock_v2595:
                            current_v2600 = self._sidebar_debounce_commit_v2595
                        if not current_v2600:
                            break
                        watch_token_v2600 = int(current_v2600[0])
                        if self._closing_event_v1841.wait(0.040):
                            break
                        with self._sidebar_debounce_lock_v2595:
                            latest_v2600 = self._sidebar_debounce_commit_v2595
                        if not latest_v2600:
                            break
                        if int(latest_v2600[0]) != watch_token_v2600:
                            continue
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                        posted_v2600 = True
                        return
                except Exception:
                    pass
                finally:
                    if not posted_v2600:
                        try:
                            with self._sidebar_debounce_lock_v2595:
                                self._sidebar_commit_posted_v2599 = False
                        except Exception:
                            pass

            _PKMHomeThreadV2151(target=_coalesce_sidebar_v2600, name="PKMSidebarSceneV2600", daemon=True).start()
        except Exception:
            _log("SIDEBAR_FOCUS_POST_FAILED_V2600 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)

    def _selected_menu_item(self):
        # v2119 lifecycle barrier: never ask Kodi for custom control 9000 before
        # onInit.  Catching getControl() is too late because Kodi already emits
        # a Non-Existent Control error to kodi.log.
        if not bool(getattr(self, "_xml_controls_ready_v2119", False)):
            return None
        try:
            return self.getControl(MENU_ID).getSelectedItem()
        except Exception:
            return None

    def _clear_sidebar_empty_view(self, reason=""):
        """Clear the content area for sidebar items that do not have a media view.

        This is intentionally limited to non-content menu entries such as
        Kodi settings / Plex KM settings.  It does not alter Home/section row
        layout, row navigation, or metadata enrichment paths.
        """
        try:
            win = xbmcgui.Window(10000)
            window_props = (
                "PlexKM.Window.HomeLayout",
                "PlexKM.Window.IsSectionRecommend",
                "PlexKM.Window.IsSectionWall",
                "PlexKM.Window.IsHome",
                "PlexKM.Window.Title",
                "PlexKM.Window.CountLabel",
            )
            for prop in window_props:
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
                try:
                    self.clearProperty(prop)
                except Exception:
                    pass

            home_keys = (
                "Title", "TitleDisplay", "EpisodeTitle", "Year", "Summary", "SummaryDisplay",
                "Fanart", "DisplayFanart", "Poster", "DurationText", "MetaLine", "Genre",
                "GenreLine", "Director", "DirectorLine", "DirectorLineUseOpenSans",
                "ContentRating", "Rating", "TmdbRating", "Type", "RatingKey", "PlayUrl", "RowType",
                "RemainingText", "RemainingIcon", "RemainingSeconds",
            )
            for key in home_keys:
                prop = "PlexKM.Home.%s" % key
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
                try:
                    self.clearProperty(prop)
                except Exception:
                    pass

            self._clear_home_trailer_preview(reason=(reason or "empty_view") + "_clear", stop_player=True)

            # Cancel any delayed fanart worker from the previously focused item.
            try:
                self._home_fanart_token += 1
                self._home_fanart_current = ""
            except Exception:
                pass

            try:
                self.getControl(TITLE_ID).setLabel("")
            except Exception:
                pass
            try:
                self.getControl(COUNT_ID).setLabel("")
            except Exception:
                pass
            try:
                self.getControl(WALL_ID).reset()
            except Exception:
                pass

            try:
                self._set_home_dynamic_bg_color(self._home_bg_default, reason=(reason or "empty_view") + "_empty")
            except Exception:
                pass
            _log("EMPTY_VIEW_CLEAR reason=%s" % (reason or ""))
        except Exception:
            _log("EMPTY_VIEW_CLEAR_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _sidebar_latest_target_stale_v2574(self, expected_pos, expected_kind="", expected_sid="", stage=""):
        """Abort a stale sidebar target before expensive scene work starts.

        V1906 already cancels an in-flight A/B renderer once a newer generation
        is observed.  On UHD3 a very fast remote key stream can advance Kodi's
        native list selection between the transaction snapshot and the first
        expensive cache/scene call.  Detect that gap here, mark one latest-pass
        drain, and leave the previous complete scene visible.  No focus write and
        no control mutation occur in this guard.
        """
        try:
            pos, kind, sid, label = self._menu_refresh_snapshot_v1906()
            stale = bool(
                int(pos) != int(expected_pos)
                or (str(expected_kind or "") and str(kind or "") != str(expected_kind or ""))
                or (str(expected_sid or "") and str(sid or "") != str(expected_sid or ""))
            )
            if not stale:
                return False
            self._menu_refresh_pending_v1906 = True
            self._menu_refresh_reselect_v1906 = True
            _log("SIDEBAR_LATEST_TARGET_ABORT_V2574 stage=%s expected_pos=%s current_pos=%s expected_kind=%s current_kind=%s expected_section=%s current_section=%s current_label=%s action=drop_stale_before_scene drain_latest=1 previous_scene_kept=1 focus_write=0" % (
                stage or "", expected_pos, pos, expected_kind or "-", kind or "-",
                expected_sid or "-", sid or "-", _short_log_value(label)
            ), xbmc.LOGWARNING)
            return True
        except Exception:
            return False

    def _refresh_for_menu_focus(self, force=False):
        """Latest-selection-only menu refresh; never nest native control builds.

        Kodi XML remains the sole navigation owner.  If Kodi re-enters this
        callback during an A/B texture-settle sleep, the nested call records only
        that a newer native selection exists.  The current renderer observes the
        generation change, abandons its hidden bank without publishing it, and
        this outer callback renders only the final selected menu item.
        """
        try:
            if getattr(self, "_closing_event_v1841", None) is not None and self._closing_event_v1841.is_set():
                return
        except Exception:
            return

        if bool(getattr(self, "_menu_refresh_tx_active_v1906", False)):
            try:
                self._menu_refresh_pending_v1906 = True
                self._menu_refresh_pending_force_v1906 = bool(
                    getattr(self, "_menu_refresh_pending_force_v1906", False) or force
                )
                self._menu_refresh_reselect_v1906 = True
                self._menu_refresh_generation_v1906 = int(
                    getattr(self, "_menu_refresh_generation_v1906", 0) or 0
                ) + 1
                pos, kind, sid, label = self._menu_refresh_snapshot_v1906()
                _log("MENU_REFRESH_COALESCE_V1906 pos=%s kind=%s section=%s label=%s generation=%s action=native_selection_only no_control_mutation=1" % (
                    pos, kind or "-", sid or "-", _short_log_value(label),
                    self._menu_refresh_generation_v1906,
                ))
            except Exception:
                pass
            return

        self._menu_refresh_tx_active_v1906 = True
        try:
            run_force = bool(force)
            pass_count = 0
            while True:
                pass_count += 1
                self._menu_refresh_pending_v1906 = False
                self._menu_refresh_pending_force_v1906 = False
                self._menu_refresh_generation_v1906 = int(
                    getattr(self, "_menu_refresh_generation_v1906", 0) or 0
                ) + 1
                try:
                    self._refresh_for_menu_focus_impl_v1906(force=run_force)
                except Exception:
                    _log("MENU_REFRESH_TRANSACTION_FAILED_V1906 pass=%s generation=%s err=%s previous_scene_kept=1" % (
                        pass_count,
                        getattr(self, "_menu_refresh_generation_v1906", 0),
                        traceback.format_exc().replace(chr(10), " | "),
                    ), xbmc.LOGERROR)

                if not bool(getattr(self, "_menu_refresh_pending_v1906", False)):
                    break
                if pass_count >= 96:
                    # A held key can generate a long stream of native selection
                    # changes.  Do not spin forever in one callback.  Mark the
                    # menu owner unknown so the next normal Kodi focus callback
                    # must refresh the final selected item.
                    self.active_menu_index = -999
                    _log("MENU_REFRESH_COALESCE_LIMIT_V1906 passes=%s generation=%s action=yield_to_kodi next_focus_forced=1 no_control_clear=1" % (
                        pass_count, getattr(self, "_menu_refresh_generation_v1906", 0)
                    ), xbmc.LOGWARNING)
                    break
                run_force = bool(getattr(self, "_menu_refresh_pending_force_v1906", False))
                self._menu_refresh_reselect_v1906 = True
                _log("MENU_REFRESH_DRAIN_LATEST_V1906 pass=%s next_generation=%s force=%d" % (
                    pass_count + 1,
                    int(getattr(self, "_menu_refresh_generation_v1906", 0) or 0) + 1,
                    1 if run_force else 0,
                ))
        finally:
            self._menu_refresh_tx_active_v1906 = False

    def _cancel_sidebar_foreground_owner_v2118(self, reason=""):
        """Retire only the previous sidebar target's foreground wait.

        Native XML selection remains the navigation owner.  This routine never
        writes focus and never opens a spinner.  It clears the old logical
        section gate plus the shared ``sidebar`` busy scope immediately, so a
        new target starts from a clean 1000ms threshold.
        """
        cancelled = 0
        try:
            self._library_rapid_poster_spinner_finish_v2593(reason="sidebar_cancel:%s" % (reason or ""))
        except Exception:
            pass
        try:
            cancelled = int(pkm_global_busy.cancel_scope(
                "sidebar", reason="sidebar_target_changed:%s" % (reason or "")
            ) or 0)
        except Exception:
            cancelled = 0
        try:
            self._section_first_visit_gate_cancel_v1620(
                reason="sidebar_target_changed_v2118:%s" % (reason or "")
            )
        except Exception:
            pass
        try:
            # Stop scheduling new append work while the selected sidebar target
            # changes. Existing DB-only prefetch is allowed to finish and remains
            # guarded by its original owner; do not erase the ready-wall owner,
            # because an instant same-wall revisit must keep native append runway.
            self._library_append_request_v2070 = False
        except Exception:
            pass
        _log("SIDEBAR_FOREGROUND_OWNER_CANCEL_V2118 reason=%s busy_tokens=%d spinner_visible_after=%d python_focus_write=0" % (
            reason or "", cancelled, 1 if pkm_global_busy.is_visible() else 0
        ))
        return cancelled

    def _refresh_for_menu_focus_impl_v1906(self, force=False):
        if not self.menu_ready:
            return
        # v1295: Sidebar browsing must not block menu preview refresh.
        # Row-anchor movement is blocked separately in _apply_dynamic_row_anchor_scroll().
        if not force and self._now_ms() < int(self._suspend_refresh_until_ms or 0):
            _log("REFRESH_SKIPPED reason=suspended")
            return
        # v584: while Kodi player is active/starting from PKM inline Info,
        # Kodi can re-enter this WindowXML and trigger the normal Home/menu
        # bootstrap.  Do not run the menu refresh because it clears the inline
        # episode page and leaves only the black playback handoff cover after Back.
        try:
            if self._is_pkm_playback_handoff_active() and self.getProperty("PlexKM.Info.InlineActive") == "1":
                _log("MENU_FOCUS_REFRESH_SKIP reason=playback_handoff_active inline=1")
                return
        except Exception:
            pass
        menu = self.getControl(MENU_ID)
        pos = menu.getSelectedPosition()
        self._sync_collapsed_menu_selection()
        reselect_v1906 = bool(getattr(self, "_menu_refresh_reselect_v1906", False))
        if not force and pos == self.active_menu_index and not reselect_v1906:
            return
        if reselect_v1906:
            self._menu_refresh_reselect_v1906 = False
        prev_menu_index = self.active_menu_index
        self.active_menu_index = pos
        if prev_menu_index != pos:
            # v352: A different sidebar item means this is a fresh menu entry.
            # Clear row re-entry memory so the target menu starts from its first
            # widget row.  Same-menu LEFT->RIGHT does not pass this branch.
            self._clear_row_reentry_memory(reason="menu_changed_%s_to_%s" % (prev_menu_index, pos))
            # v2288: Search->Info has already been fully detached at the real
            # MENU_ID entry boundary. Sidebar selection changes below are now the
            # exact same path as a session that never opened Search. Keep only a
            # defensive stale-hold cleanup; never retarget or gate normal sidebar
            # rendering with Search state.
            if getattr(self, "_search_info_sidebar_ab_hold_v2284", None):
                try:
                    hold_v2479 = self._search_info_sidebar_ab_hold_v2284
                    keep_v2479 = bool(
                        isinstance(hold_v2479, dict)
                        and hold_v2479.get("v2479_target_first")
                        and str(hold_v2479.get("section_id") or "") == str(self.getControl(MENU_ID).getListItem(pos).getProperty("section_id") or "")
                    )
                except Exception:
                    keep_v2479 = False
                if keep_v2479:
                    _log("SEARCH_INFO_SIDEBAR_HOLD_KEEP_V2479 section=%s pos=%s source_held=1" % (
                        str(hold_v2479.get("section_id") or ""), pos
                    ))
                else:
                    try:
                        self._search_info_sidebar_ab_cancel_v2285(
                            reason="stale_hold_cleanup_v2288_%s_to_%s" % (prev_menu_index, pos),
                            retire_search=False,
                        )
                    except Exception:
                        self._search_info_sidebar_ab_hold_v2284 = None
            _info_hold_target_first_v2387 = bool(self._info_sidebar_hold_active_v2387())
            if self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1":
                if _info_hold_target_first_v2387:
                    # v2479 supersedes v2404: a real sidebar selection change
                    # must NOT clear the visible Info/Actor source first. Build
                    # Home/Section underneath it and retire the source only from
                    # the destination-ready release below.
                    _log("INFO_SIDEBAR_MOVE_HOLD_V2479 from_pos=%s to_pos=%s action=prepare_destination_under_source clear_before_target=0" % (
                        prev_menu_index, pos
                    ))
                else:
                    # Even without the explicit LEFT hold, preserve a visible
                    # Info source for this full-scene transition.
                    self._info_sidebar_hold_arm_v2387(reason="menu_change_target_first_v2479_%s_to_%s" % (prev_menu_index, pos))
                    _info_hold_target_first_v2387 = True
                    _log("INFO_SIDEBAR_MOVE_HOLD_ARM_V2479 from_pos=%s to_pos=%s clear_before_target=0" % (prev_menu_index, pos))
            else:
                _info_hold_target_first_v2387 = False
        else:
            _info_hold_target_first_v2387 = False
        item = self._selected_menu_item()
        if not item:
            return
        kind = item.getProperty("kind")
        # PKM_UHD_NAV_ISOLATION_U2_20261011: sidebar focus owns the entire
        # nonessential same-bank fill lifecycle, including the Settings entries.
        # active_section_id alone is NOT sufficient: it remains the prior
        # section while Settings is focused. Never clear or rebind visible rows.
        if prev_menu_index != pos:
            try:
                self._section_fill_last_nav_mono_u2 = time.monotonic()
                _u2_lock = getattr(self, "_section_same_bank_fill_lock_v2707", None)
                if _u2_lock is not None:
                    with _u2_lock:
                        _u2_old = getattr(self, "_section_same_bank_fill_task_v2707", None)
                        if isinstance(_u2_old, dict):
                            self._section_same_bank_fill_task_v2707 = None
                            self._section_same_bank_fill_token_v2707 = int(getattr(self, "_section_same_bank_fill_token_v2707", 0) or 0) + 1
                            self._section_same_bank_fill_posted_v2707 = False
                            _log("SIDEBAR_TAIL_HARD_CANCEL_U2 old=%s new_kind=%s pos=%d result=cancel_queued_work_keep_visible_bank" % (
                                str(_u2_old.get("key") or "-"), str(kind or "-"), int(pos)))
            except Exception:
                pass
        # v2118: selection change is the spinner ownership boundary.  Clear the
        # old target *before* any cache hit/query for the new target.  If the new
        # target is fast, no spinner appears; if it is genuinely slow it can arm
        # a fresh sidebar token and becomes visible only after the shared 1000ms.
        if prev_menu_index != pos:
            try:
                self._cancel_sidebar_foreground_owner_v2118(
                    reason="%s_to_%s:%s:%s" % (prev_menu_index, pos, kind or "", item.getProperty("section_id") or "")
                )
            except Exception:
                pass
        # v1873: a category genre belongs to the currently published section.
        # Merely entering the sidebar is handled above and keeps the same menu
        # position, so no filter is cleared.  The filter is released only when
        # the native sidebar selection actually changes to Home, settings, or a
        # different section.
        try:
            if prev_menu_index != pos and getattr(self, "_active_genre_filter", ""):
                owner_sid_v1873 = str(getattr(self, "_active_genre_section_id", "") or "")
                target_sid_v1873 = str(item.getProperty("section_id") or "") if kind == "section" else ""
                if kind != "section" or target_sid_v1873 != owner_sid_v1873:
                    old_genre_v1873 = str(self._active_genre_filter or "")
                    self._active_genre_filter = ""
                    self._active_genre_count = 0
                    self._active_genre_section_id = ""
                    self._update_category_wall_summary(reason="sidebar_selection_changed_v1873")
                    _log(
                        "SECTION_GENRE_FILTER_CLEAR_V1873 trigger=sidebar_selection_changed "
                        "owner_section=%s destination_kind=%s destination_section=%s "
                        "from_pos=%s to_pos=%s genre=%s"
                        % (
                            owner_sid_v1873, kind or "", target_sid_v1873,
                            prev_menu_index, pos, old_genre_v1873,
                        )
                    )
        except Exception:
            _log(
                "SECTION_GENRE_FILTER_CLEAR_FAILED_V1873 err=%s"
                % traceback.format_exc().replace(chr(10), " | "),
                xbmc.LOGWARNING,
            )
        # v1620: a cold-section spinner belongs only to its exact menu target.
        # Moving to Home/settings or another section cancels the stale gate, while
        # the old fully rendered scene remains untouched underneath.
        try:
            if kind != "section":
                self._section_first_visit_gate_cancel_v1620(reason="menu_kind_%s" % (kind or ""))
            else:
                target_key_v1620 = "recommend:%s" % str(item.getProperty("section_id") or "")
                gate_key_v1620 = str(self._section_first_visit_gate_key_v1620 or "")
                if gate_key_v1620 and gate_key_v1620 != target_key_v1620:
                    self._section_first_visit_gate_cancel_v1620(reason="menu_target_changed", only_if_key=gate_key_v1620)
        except Exception:
            pass
        if self._is_connection_settings_focus_required_v1381() and kind in ("home", "kodi_settings", "addon_settings"):
            # v1381: offline/pending surface must stay keyboard-operable.
            # Do not call _show_home_wall() here because it fetches Plex/onDeck,
            # resets empty rows, and can steal/lose sidebar focus.  OK/Enter on
            # addon_settings still opens PKM settings through onClick().
            _log("MENU_FOCUS_REFRESH_SKIP_V1381 reason=connection_recovery kind=%s pos=%s focus_id=%s" % (kind, pos, self._safe_focus_id()))
            return
        if kind == "home":
            if self._sidebar_latest_target_stale_v2574(pos, expected_kind="home", stage="before_home_scene"):
                return
            _log("MENU_FOCUS_REFRESH kind=home pos=%s action=show_home_widgets" % pos)
            self._start_widget_stack_transition(reason="menu_focus_home")
            if self._sidebar_latest_target_stale_v2574(pos, expected_kind="home", stage="after_home_transition"):
                return
            self._show_home_wall()
            if _info_hold_target_first_v2387:
                self._info_sidebar_hold_release_v2387(
                    reason="home_ready_pos_%s" % pos, clear_info=True
                )
        elif kind == "section":
            # v675: sidebar focus restores the section's last active tab.
            # Default remains 추천 for never-visited sections, but if the user
            # left this library on 라이브러리, menu re-entry keeps 라이브러리.
            sid = item.getProperty("section_id") or ""
            label = item.getLabel() or ""
            # v1836: A category filter ends when the sidebar selects another
            # library, regardless of which tab that destination restores.
            genre_owner_v1836 = str(getattr(self, "_active_genre_section_id", "") or "")
            if getattr(self, "_active_genre_filter", "") and genre_owner_v1836 != str(sid):
                old_genre_v1836 = str(self._active_genre_filter or "")
                self._active_genre_filter = ""
                self._active_genre_count = 0
                self._active_genre_section_id = ""
                self._update_category_wall_summary(reason="sidebar_section_changed_v1836")
                _log("SECTION_GENRE_FILTER_CLEAR_V1836 owner_section=%s destination_section=%s genre=%s" % (
                    genre_owner_v1836, sid, old_genre_v1836
                ))
            try:
                _select_now_v2595 = self._now_ms()
                _select_started_v2595 = int(getattr(self, "_sidebar_ui_select_started_v1650", 0) or 0)
                _select_sid_v2595 = str(getattr(self, "_sidebar_ui_select_section_v1650", "") or "")
                if (_select_sid_v2595 != str(sid) or _select_started_v2595 <= 0
                        or (_select_now_v2595 - _select_started_v2595) > 1500):
                    self._sidebar_ui_select_started_v1650 = _select_now_v2595
                self._sidebar_ui_select_section_v1650 = str(sid)
                self._sidebar_ui_select_from_v1650 = str(prev_menu_index)
                self._sidebar_ui_select_to_v1650 = str(pos)
                self._sidebar_ui_select_logged_v1650 = False
                _log("SIDEBAR_UI_SELECT_V1650 from_pos=%s to_pos=%s section=%s label=%s t_ms=%s" % (
                    prev_menu_index, pos, sid, _short_log_value(label), self._sidebar_ui_select_started_v1650
                ))
            except Exception:
                pass
            if self._sidebar_latest_target_stale_v2574(pos, expected_kind="section", expected_sid=sid, stage="before_section_scene"):
                return
            self._start_widget_stack_transition(reason="menu_focus_section:%s" % sid)
            if self._sidebar_latest_target_stale_v2574(pos, expected_kind="section", expected_sid=sid, stage="after_section_transition"):
                return
            restored_tab = self._show_section_last_tab(item, force=force, reason="menu_focus_refresh")
            _log("MENU_FOCUS_REFRESH kind=section pos=%s section=%s label=%s action=restore_last_tab tab=%s" % (pos, sid, _short_log_value(label), restored_tab))
            if _info_hold_target_first_v2387:
                self._info_sidebar_hold_release_v2387(
                    reason="section_ready_%s_pos_%s" % (sid, pos), clear_info=True
                )
        elif kind == "kodi_settings":
            # v1457: Settings focus is a navigation target, not a content refresh target.
            # Do NOT rebuild Home widgets or start background prewarm while entering settings.
            self._arm_settings_quiet_v1457(reason="focus_kodi_settings", ms=18000)
            _log("MENU_FOCUS_REFRESH kind=kodi_settings pos=%s action=keep_current_widgets_under_settings_v1457" % pos)
            if _info_hold_target_first_v2387:
                self._info_sidebar_hold_release_v2387(
                    reason="kodi_settings_selected_pos_%s" % pos, clear_info=True
                )
            return
        elif kind == "youtube":
            # R79: YouTube opens on OK/Enter only; focus keeps the current scene.
            _log("MENU_FOCUS_REFRESH kind=youtube pos=%s action=keep_current_scene_r79" % pos)
            return
        elif kind == "addon_settings":
            # v1457: Same for PKM settings. Keep the current Home content underneath
            # and open settings only on OK/Enter. Never start Home rebuild here.
            self._arm_settings_quiet_v1457(reason="focus_addon_settings", ms=18000)
            _log("MENU_FOCUS_REFRESH kind=addon_settings pos=%s action=keep_current_widgets_under_settings_v1457" % pos)
            if _info_hold_target_first_v2387:
                self._info_sidebar_hold_release_v2387(
                    reason="addon_settings_selected_pos_%s" % pos, clear_info=True
                )
            return

    def _cancel_pending_sidebar_commit_v2661(self, reason=""):
        """User tab intent wins over a delayed sidebar scene commit."""
        try:
            with self._sidebar_debounce_lock_v2595:
                pending = self._sidebar_debounce_commit_v2595
                self._sidebar_debounce_commit_v2595 = None
                self._sidebar_debounce_pending_v2595 = None
                self._sidebar_commit_posted_v2599 = False
            self._sidebar_focus_commit_token_v1815 = int(getattr(self, "_sidebar_focus_commit_token_v1815", 0) or 0) + 1
            if pending:
                _log("TAB_INTENT_CANCEL_PENDING_SIDEBAR_V2661 reason=%s pending_token=%s section=%s" % (reason or "", pending[0], pending[3]))
            return True
        except Exception:
            return False

    def _activate_menu_item(self):
        # v2479: never retire Actor/Profile before a full-scene destination.
        # The destination's final A/B commit owns source retirement.
        item = self._selected_menu_item()
        if not item:
            return
        kind = item.getProperty("kind")
        if kind in ("home", "section"):
            # R106: fold the expanded sidebar card on the click itself; the
            # destination commit + R82 collapse can take ~1 s on SHIELD.
            self._sidebar_enter_fold_r106(True, reason="enter_%s" % kind)
        now_ms_v1382 = self._now_ms()
        if kind in ("kodi_settings", "addon_settings"):
            self._arm_settings_quiet_v1457(reason="activate_%s" % kind, ms=22000)
            last_key_v1382 = "_last_%s_open_ms_v1382" % kind
            if now_ms_v1382 - int(getattr(self, last_key_v1382, 0) or 0) < 900:
                _log("SETTINGS_OPEN_DEBOUNCE_V1382 kind=%s ms=%s" % (kind, now_ms_v1382))
                return
            setattr(self, last_key_v1382, now_ms_v1382)
        if self._is_connection_settings_focus_required_v1381() and kind == "home":
            _log("HOME_MENU_ACTIVATE_SKIP_V1382 reason=connection_recovery_no_home_refresh")
            self._sidebar_enter_fold_r106(False, reason="home_skip")
            self._force_connection_settings_focus_v1381("home_activate_skip_v1382")
            return
        if kind == "search":
            if self._is_connection_settings_focus_required_v1381():
                _log("SEARCH_OPEN_SKIP_V1382 reason=connection_recovery_settings_priority")
                self._force_connection_settings_focus_v1381("search_open_skip_v1382")
                return
            self._open_inline_search()
            return
        if kind == "youtube":
            self._open_youtube_r79()
            return
        elif kind == "kodi_settings":
            # v2017: Keep the live PKM Home WindowXML instance in Kodi's window
            # history. Closing it here forced a second Home instance to be built
            # by the return watcher, which replayed sidebar expansion/onInit and
            # could make Kodi Settings look as if it opened twice.
            _log("SETTINGS_OPEN_WINDOW_V2017 source=kodi_settings action=ActivateWindow(settings) keep_home=1 return=native_window_stack trigger=onclick_only")
            try:
                xbmcgui.Window(10000).clearProperty("PlexKM.ReturnHomeAfterSettings")
                xbmcgui.Window(10000).clearProperty("PlexKM.SkipAutoHomeOnce")
            except Exception:
                pass
            xbmc.executebuiltin("ActivateWindow(settings)")
        elif kind == "addon_settings":
            # Add-on settings is already a dialog/modal; keep PKM Home underneath
            # and avoid the return-home watcher so Kodi stock Home is not exposed.
            if self.getProperty("PlexKM.Home.SettingsRequired") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Home.SettingsRequired") == "1":
                _log("SETTINGS_OPEN_MODAL source=addon_settings_empty_home action=pkm_settings_with_refresh_watch keep_home=1")
                self._open_empty_home_pkm_settings()
            else:
                if self._is_connection_settings_focus_required_v1381():
                    _log("SETTINGS_OPEN_MODAL source=addon_settings action=RunScript_pkm_settings keep_home=1 offline_fast_v1382=1")
                else:
                    _log("SETTINGS_OPEN_MODAL source=addon_settings action=RunScript_pkm_settings keep_home=1")
                xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.km/default.py,action=pkm_settings)")
        else:
            if kind == "home":
                # R155: Home ON CLICK is an explicit commit even after browsing
                # another library; Home ON FOCUS is only a live preview/initial
                # selection. Reuse existing rendered Home rows when available.
                _log("R155_SIDEBAR_HOME_ENTER_COMMIT from=%s focus=%s" % (
                    getattr(self, "active_section_id", ""), self._safe_focus_id()))
                self._start_widget_stack_transition(reason="r155_home_enter")
                # R48: row the stack is scrolled to now (before the ENTER reset).
                try:
                    prev_row_r48 = str(self.getProperty("PlexKM.Home.LastFocusRow")
                                       or xbmcgui.Window(10000).getProperty("PlexKM.Home.LastFocusRow") or "")
                except Exception:
                    prev_row_r48 = ""
                try:
                    self._clear_row_reentry_memory(HOME_ROW_ANCHOR_SCOPE, reason="r43_home_enter_pre")
                    self._remember_row_reentry_focus(HOME_ROW_IDS[0], reason="r43_home_enter_pre")
                except Exception:
                    pass
                # R52: the sidebar focus preview (R143) has normally just built
                # this exact Home (field log: built 23.1->24.86s, ENTER at 24.88s
                # rebuilt everything again for 1.16s and the first commit only
                # landed at 26.0s -> "Home pressed once but nothing shown").
                # Reuse it; its pending swap commits by itself.
                _r143_age_r52 = self._now_ms() - int(getattr(self, "_r143_home_built_ms_r52", 0) or 0)
                if (str(getattr(self, "active_section_id", "") or "") == "__home__"
                        and 0 <= _r143_age_r52 < 15000):
                    _log("R155_HOME_ENTER_REUSE_R143_R52 age_ms=%d rebuild=0" % _r143_age_r52)
                else:
                    self._show_home_wall(force=False)
                self._r143_home_built_ms_r52 = 0
                # R42: an explicit Home ENTER is a fresh Home; RIGHT must land on
                # the first widget row (first poster), not the row last visited.
                try:
                    self._clear_row_reentry_memory(HOME_ROW_ANCHOR_SCOPE, reason="r42_home_enter")
                    first_row_r42 = (self._visible_row_controls_for_scope(HOME_ROW_ANCHOR_SCOPE) or [HOME_ROW_IDS[0]])[0]
                    self._remember_row_reentry_focus(first_row_r42, reason="r42_home_enter")
                    # R45: the remembered-row fix alone still lets the 9298
                    # row grouplist glide (300ms) from wherever it was
                    # scrolled to back up to row 0 -- make that one jump
                    # instant.
                    # R48: only hide the stack when it really has to scroll
                    # back (already on the first row -> no blink).
                    if prev_row_r48 and prev_row_r48 != str(first_row_r42):
                        self._row_instant_jump_arm_r45(reason="r45_home_enter")
                    _log("ROW_SLIDE_ENTER_R48 scope=home prev=%s first=%s" % (prev_row_r48 or "-", first_row_r42))
                    try:
                        self.getControl(int(first_row_r42)).selectItem(0)
                    except Exception:
                        pass
                    # R46: also pre-scroll the outer 9299 grouplist itself so
                    # the first row is already visible on ENTER, not only
                    # once RIGHT moves real focus into it.
                    self._row_prescroll_bounce_r46(first_row_r42, reason="r46_home_enter")
                    _log("R43_HOME_ENTER_FIRST_ROW row=%s last=%s" % (
                        first_row_r42, self.getProperty("PlexKM.Home.LastFocusRow") or "-"))
                except Exception:
                    pass
            elif kind == "section":
                sid = item.getProperty("section_id") or ""
                tab = self._section_last_tab(sid, default="recommend")
                _log("SECTION_MENU_ACTIVATE_RESTORE_LAST_TAB section=%s tab=%s label=%s" % (sid, tab, _short_log_value(item.getLabel() or "")))
                # R35: an explicit sidebar ENTER while Info/Actor is on screen is
                # the ONLY trigger allowed to retire that overlay at the section
                # commit (background refreshes must never close Info).
                try:
                    if self._pkm_surface_mode_v2479() in ("info", "actor_profile"):
                        self._section_enter_overlay_r35 = (str(sid), time.monotonic())
                        _log("SECTION_ENTER_FROM_OVERLAY_R35 section=%s" % sid)
                    else:
                        self._section_enter_overlay_r35 = None
                except Exception:
                    pass
                if tab == "library":
                    self._show_section_wall(item, force=True)
                    # R135: ENTER commits the library but retains sidebar focus.
                else:
                    # R142: the first-row preview must be valid before the sidebar
                    # ENTER publish, not only after RIGHT focuses the row panel.
                    # Preserve prepared row data; reset only the viewport anchor.
                    # R44: also clear the remembered re-entry row BEFORE the
                    # recommend rebuild, mirroring the R42/R43 Home fix -- the
                    # rebuild itself can re-assert a stale remembered row if the
                    # clear only happens afterward.
                    try:
                        prev_row_r48 = str(self.getProperty("PlexKM.Section.LastFocusRow")
                                           or xbmcgui.Window(10000).getProperty("PlexKM.Section.LastFocusRow") or "")
                    except Exception:
                        prev_row_r48 = ""
                    try:
                        self._clear_row_reentry_memory(SECTION_ROW_ANCHOR_SCOPE, reason="r44_section_enter_pre")
                        self._remember_row_reentry_focus("8410", reason="r44_section_enter_pre")
                        for _w_r142 in (self, xbmcgui.Window(10000)):
                            _w_r142.setProperty("PlexKM.Section.LastFocusRow", "8410")
                        _log("R142_SIDEBAR_ENTER_ROW_PREVIEW_ANCHOR section=%s row=8410" % sid)
                    except Exception:
                        pass
                    self._show_section_recommend_widgets(item, force=True)
                    # R44: an explicit section-menu ENTER is a fresh recommend
                    # view; RIGHT must land on the first widget row's first
                    # poster, not the row last visited before leaving this
                    # section (mirrors R42/R43 Home-ENTER fix).
                    try:
                        self._clear_row_reentry_memory(SECTION_ROW_ANCHOR_SCOPE, reason="r44_section_enter")
                        first_row_r44 = (self._visible_row_controls_for_scope(SECTION_ROW_ANCHOR_SCOPE) or ["8410"])[0]
                        self._remember_row_reentry_focus(first_row_r44, reason="r44_section_enter")
                        # R45: same reasoning as the Home-ENTER arm above --
                        # the 8298/8398 row grouplist's own 300ms scrolltime
                        # still glides from the previously-scrolled position
                        # back to row 0 even once LastFocusRow is correct.
                        if prev_row_r48 and prev_row_r48 not in ("8410", "8610", str(first_row_r44)):
                            self._row_instant_jump_arm_r45(reason="r45_section_enter")
                        _log("ROW_SLIDE_ENTER_R48 scope=section prev=%s first=%s" % (prev_row_r48 or "-", first_row_r44))
                        try:
                            self.getControl(int(first_row_r44)).selectItem(0)
                        except Exception:
                            pass
                        # R46: also pre-scroll the active bank's outer
                        # grouplist (8298/8398) so the first row is already
                        # visible on ENTER, not only once RIGHT moves real
                        # focus into it.
                        self._row_prescroll_bounce_r46(first_row_r44, reason="r46_section_enter")
                        _log("R44_SECTION_ENTER_FIRST_ROW section=%s row=%s" % (sid, first_row_r44))
                    except Exception:
                        pass
                    # R135: ENTER commits recommend but retains sidebar focus.
            elif self.active_section_id == "__home__" and self._home_row_items_cache:
                _log("R135_HOME_ENTER_KEEP_SIDEBAR")
            else:
                pass
            # R135: an ENTER selection never collapses the sidebar or moves focus.
            # R61: but when the ENTER handler was slow (library first open on
            # SHIELD ~1.8 s), Kodi already moved focus by the user's next keys
            # (RIGHT -> wall, UP -> sort).  Pulling focus back to the sidebar
            # then looked like the sort button "auto-jumped" left.  Keep the
            # user's focus in that case.
            try:
                _fid_r61 = self._safe_focus_id()
                if _fid_r61 not in (MENU_ID, MENU_COLLAPSED_ID, 0, -1, None):
                    self._set_sidebar_expanded_state(False, reason="r61_user_moved_during_enter")
                    self._last_focus_id = _fid_r61
                    _log("R61_MENU_ENTER_USER_FOCUS_KEEP kind=%s focus=%s" % (kind, _fid_r61))
                    self._sidebar_enter_fold_r106(False, reason="r61_user_moved")
                elif kind in ("home", "section"):
                    # R82: ENTER on a library/Home means "show me this" -> the
                    # floating sidebar folds away and focus moves into the content
                    # once the destination has published (focus preview stays as is).
                    self._sidebar_enter_collapse_r82(kind, item.getProperty("section_id") or "")
                else:
                    self._set_sidebar_expanded_state(True, reason="r135_menu_enter")
                    if self._safe_focus_id() != MENU_ID:
                        self.setFocusId(MENU_ID)
                    self._last_focus_id = MENU_ID
                    _log("R135_MENU_ENTER_KEEP_SIDEBAR kind=%s focus=%s" % (kind, self._safe_focus_id()))
            except Exception:
                _log("R135_MENU_ENTER_KEEP_SIDEBAR_FAILED", xbmc.LOGWARNING)
                self._sidebar_enter_fold_r106(False, reason="enter_failed")

    def _sidebar_enter_fold_r106(self, on, reason=""):
        """R106: hide/show the expanded sidebar card independently of focus."""
        try:
            if on:
                stamp_r106 = self._now_ms()
                self._sidebar_enter_fold_ms_r106 = stamp_r106
                self.setProperty("PlexKM.Sidebar.EnterFoldR106", "1")

                def _watchdog_r106():
                    # Safety net: never leave a focused-but-invisible sidebar.
                    xbmc.sleep(32000)
                    if int(getattr(self, "_sidebar_enter_fold_ms_r106", 0) or 0) == stamp_r106:
                        self._sidebar_enter_fold_r106(False, reason="watchdog")
                threading.Thread(target=_watchdog_r106, name="PKMEnterFoldR106", daemon=True).start()
            else:
                if not self.getProperty("PlexKM.Sidebar.EnterFoldR106"):
                    return
                self.clearProperty("PlexKM.Sidebar.EnterFoldR106")
            _log("R106_SIDEBAR_ENTER_FOLD on=%d reason=%s focus=%s" % (1 if on else 0, reason or "", self._safe_focus_id()))
        except Exception:
            pass

    def _sidebar_enter_pending_for_r103(self, sid):
        """R103: True while a sidebar ENTER for sid is queued for replay (R34)."""
        try:
            pending = getattr(self, "_sidebar_enter_pending_r34", None)
            return bool(pending) and str(pending[0]) == str(sid or "")
        except Exception:
            return False

    def _sidebar_enter_collapse_r82(self, kind, sid="", startup=False):
        """R82: after a sidebar ENTER, wait (max 2.5s) until the destination is
        published, then press RIGHT once so the existing 9000 <onright> routing
        moves focus to its first row/wall.  Cancelled if the user moved first.
        R83b startup=True: PKM start -> Home with the sidebar folded and focus on
        the first poster (Plex).  Waits up to 8 s for the menu focus handoff and
        the first Home row; any key the user presses meanwhile cancels it."""
        token = int(getattr(self, "_enter_collapse_token_r82", 0) or 0) + 1
        self._enter_collapse_token_r82 = token

        def _ready():
            try:
                if kind == "home":
                    return (self.getProperty("PlexKM.Window.IsHome") == "1"
                            and bool(self.getProperty("PlexKM.Home.Row0.Title")))
                return self.getProperty("PlexKM.Window.PublishedSectionId") == str(sid)
            except Exception:
                return False

        def _worker():
            try:
                _worker_body()
            finally:
                # R106: whatever happened (moved, cancelled, skipped, RIGHT sent)
                # the instant fold must not outlive this ENTER.
                if token == int(getattr(self, "_enter_collapse_token_r82", 0) or 0):
                    self._sidebar_enter_fold_r106(False, reason="collapse_done")

        def _worker_body():
            try:
                waited = 0
                limit = 8000 if startup else 2500
                ready_r103 = False
                while True:
                    if token != int(getattr(self, "_enter_collapse_token_r82", 0) or 0):
                        return
                    _fid = self._safe_focus_id()
                    if _fid != MENU_ID:
                        # startup: focus is still on the window default (100) until
                        # the 9000 handoff lands; anything else = user moved.
                        if not (startup and _fid in (100, 0, -1, None)):
                            return
                    elif _ready():
                        ready_r103 = True
                        break
                    if waited >= limit:
                        # R103: a section ENTER that is still waiting for its
                        # prepared data (SIDEBAR_ENTER_PENDING_R34) must not be
                        # folded away.  Pressing RIGHT here moved focus into the
                        # OLD scene, and the replay then dropped the ENTER with
                        # reason=focus_moved (Shield: "방영-기타 열리지 않음").
                        if kind == "section" and self._sidebar_enter_pending_for_r103(sid) and waited < 30000:
                            if waited == limit:
                                _log("R103_MENU_ENTER_COLLAPSE_WAIT_PENDING section=%s" % (sid or "-"))
                        else:
                            break
                    xbmc.sleep(50)
                    waited += 50
                if token != int(getattr(self, "_enter_collapse_token_r82", 0) or 0) or self._safe_focus_id() != MENU_ID:
                    return
                if not ready_r103 and kind == "section" and self._sidebar_enter_pending_for_r103(sid):
                    _log("R103_MENU_ENTER_COLLAPSE_SKIP section=%s waited_ms=%d reason=still_pending" % (sid or "-", waited))
                    return
                xbmc.sleep(60)
                xbmc.executebuiltin("Action(Right)")
                # R106: keep the card folded until Kodi has moved focus off 9000.
                for _i_r106 in range(20):
                    if self._safe_focus_id() != MENU_ID:
                        break
                    xbmc.sleep(25)
                _log("R82_MENU_ENTER_COLLAPSE kind=%s section=%s waited_ms=%d startup=%d" % (kind, sid or "-", waited, int(bool(startup))))
            except Exception:
                pass

        _t = threading.Thread(target=_worker, name="PKMEnterCollapseR82", daemon=True)
        _t.start()

    def _open_youtube_r79(self):
        """R79: sidebar "유튜브" ENTER.

        The YouTube screen runs as its own script (RunScript) so this callback
        returns at once.  It covers the content area and redraws the collapsed
        rail from the icons handed over here; LEFT/Back closes it and the
        sidebar (still focused on "유튜브") is shown again.
        """
        try:
            now_ms = self._now_ms()
            if now_ms - int(getattr(self, "_youtube_open_ms_r79", 0) or 0) < 1500:
                _log("YOUTUBE_OPEN_DEBOUNCE_R79")
                return
            self._youtube_open_ms_r79 = now_ms
            icons = []
            pos = 0
            menu = self.getControl(MENU_ID)
            real = int(getattr(self, "_sidebar_real_count_r151", 0) or menu.size())
            sel = menu.getSelectedPosition()
            for i in range(min(real, menu.size())):
                li = menu.getListItem(i)
                icons.append(li.getProperty("MenuIconDefaultTexture") or "")
                if i == sel:
                    pos = i
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.YouTube.RailR79", json.dumps({"icons": icons, "pos": pos}))
            win.setProperty("PlexKM.YouTube.ActiveR79", "1")
            try:
                self._clear_home_trailer_preview(reason="youtube_open_r79", stop_player=False)
            except Exception:
                pass
            _log("YOUTUBE_OPEN_R79 pos=%s icons=%d from=%s" % (pos, len(icons), getattr(self, "active_section_id", "")))
            xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.km/default.py,action=youtube)")
        except Exception:
            _log("YOUTUBE_OPEN_FAILED_R79 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)

    def _settings_or_kodi_settings_active(self):
        try:
            return (
                xbmc.getCondVisibility("Window.IsActive(addonsettings)")
                or xbmc.getCondVisibility("Window.IsActive(settings)")
            )
        except Exception:
            return False

    def _settings_quiet_active_v1457(self):
        """v1457: Settings menu/dialog must not compete with Home background work."""
        try:
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            until = int(getattr(self, "_settings_quiet_until_ms_v1457", 0) or 0)
            if until and now_ms < until:
                return True
            try:
                win = xbmcgui.Window(10000)
                if (win.getProperty("PlexKM.FullResetInProgressV2150") == "1"
                        or win.getProperty("PlexKM.FullResetInProgressV2149") == "1"):
                    return True
                prop_until = int(float(win.getProperty("PlexKM.SettingsQuietUntilMs") or 0))
                if prop_until and now_ms < prop_until:
                    return True
            except Exception:
                pass
            try:
                return bool(self._settings_or_kodi_settings_active())
            except Exception:
                return False
        except Exception:
            return False

    def _arm_settings_quiet_v1457(self, reason="", ms=18000, clear_cast_queue=True):
        """v1457: While entering Kodi/PKM settings, pause Home prewarm/network workers."""
        try:
            now_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
            until = now_ms + max(2000, int(ms or 0))
            self._settings_quiet_until_ms_v1457 = max(int(getattr(self, "_settings_quiet_until_ms_v1457", 0) or 0), until)
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.SettingsQuietUntilMs", str(self._settings_quiet_until_ms_v1457))
            except Exception:
                pass
            if clear_cast_queue:
                try:
                    with self._info_cast_prewarm_lock:
                        qlen = len(getattr(self, "_info_cast_prewarm_queue", []) or [])
                        self._info_cast_prewarm_queue = []
                    _log("SETTINGS_QUIET_ARM_V1457 reason=%s until=%s cleared_cast_queue=%d" % (reason or "", self._settings_quiet_until_ms_v1457, qlen))
                except Exception:
                    _log("SETTINGS_QUIET_ARM_V1457 reason=%s until=%s clear_cast_queue_failed=1" % (reason or "", self._settings_quiet_until_ms_v1457))
            else:
                _log("SETTINGS_QUIET_ARM_V1457 reason=%s until=%s" % (reason or "", self._settings_quiet_until_ms_v1457))
        except Exception:
            _log("SETTINGS_QUIET_ARM_FAILED_V1457 reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _dedup_text_key(self, text):
        try:
            value = unicodedata.normalize("NFKC", str(text or "")).strip().lower()
            return " ".join(value.split())
        except Exception:
            return str(text or "").strip().lower()

    def _movie_extra_unique_key(self, row):
        return pkm_recommend_data.movie_extra_unique_key(row)


    # PKM_SIDEBAR_ASYNC_DATA_PREPARE
    # The worker owns only data construction and local poster URL authority.
    # All A/B ControlList mutations stay on Kodi's WindowXML callback thread.
    def _sidebar_focus_prefetch_dwell_r103(self, sid, label):
        token = int(getattr(self, "_prefetch_dwell_token_r103", 0) or 0)

        def _w():
            try:
                if self._closing_event_v1841.wait(SIDEBAR_PREFETCH_DWELL_MS_R103 / 1000.0):
                    return
                if token != int(getattr(self, "_prefetch_dwell_token_r103", 0) or 0):
                    return
                self._sidebar_prepare_enqueue(sid, label, priority=True)
                _log("R103_FOCUS_PREFETCH_DWELL_START section=%s" % sid)
            except Exception:
                pass

        threading.Thread(target=_w, name="PKMPrefetchDwellR103", daemon=True).start()

    def _prepare_abort_point_r103(self):
        """R103: checkpoint inside data-only row builders (worker thread only)."""
        chk = getattr(RECOMMEND_BUILD_CONTEXT_V1616, "abort_r103", None)
        if chk is not None:
            try:
                hit = bool(chk())
            except Exception:
                hit = False
            if hit:
                raise PKMPrepareAbortR103()

    def _sidebar_prepare_state(self):
        lock = getattr(self, "_sidebar_prepare_lock", None)
        if lock is None:
            lock = threading.RLock()
            self._sidebar_prepare_lock = lock
            self._sidebar_prepare_queue = []
            self._sidebar_prepare_pending = set()
            self._sidebar_prepare_ready = {}
            self._sidebar_prepare_failed = set()
            self._sidebar_prepare_worker_active = False
            self._sidebar_prepare_generation = {}
        return lock

    def _sidebar_prepare_invalidate(self, sid):
        sid = str(sid or "").strip()
        if not sid:
            return
        key = "recommend:%s" % sid
        lock = self._sidebar_prepare_state()
        with lock:
            self._sidebar_prepare_generation[key] = self._sidebar_prepare_generation.get(key, 0) + 1
            self._sidebar_prepare_ready.pop(key, None)
            self._sidebar_prepare_failed.discard(key)
            getattr(self, '_sidebar_prepare_retry_count_cumulative', {}).pop(key, None)
            self._sidebar_prepare_pending.discard(key)
            self._sidebar_prepare_queue[:] = [v for v in self._sidebar_prepare_queue if v[0] != key]

    def _sidebar_prepare_enqueue(self, sid, title, priority=False):
        """Queue one TV section; coalesce duplicates without spawning N threads."""
        sid = str(sid or "").strip()
        if not sid or self._closing_event_v1841.is_set():
            return False
        key = "recommend:%s" % sid
        lock = self._sidebar_prepare_state()
        start_worker = False
        with lock:
            if key in self._sidebar_prepare_ready:
                return True
            if key in self._sidebar_prepare_failed:
                # A new real focus may retry once; never retry repeatedly on a
                # worker completion ping or in an infinite foreground loop.
                retries = getattr(self, '_sidebar_prepare_retry_count_cumulative', None)
                if retries is None:
                    retries = {}
                    self._sidebar_prepare_retry_count_cumulative = retries
                if not priority or retries.get(key, 0) >= 1:
                    return False
                retries[key] = retries.get(key, 0) + 1
                self._sidebar_prepare_failed.discard(key)
                _log('SIDEBAR_PREPARE_RETRY section=%s attempt=%d background_only=1' % (
                    sid, retries[key]
                ), xbmc.LOGWARNING)
            if priority:
                # R85: user-requested (focus/ENTER) jobs never yield.
                if not hasattr(self, "_sidebar_prepare_priority_r85"):
                    self._sidebar_prepare_priority_r85 = set()
                self._sidebar_prepare_priority_r85.add(key)
            if key not in self._sidebar_prepare_pending:
                self._sidebar_prepare_pending.add(key)
                entry = (key, sid, str(title or ""), self._sidebar_prepare_generation.get(key, 0))
                if priority:
                    self._sidebar_prepare_queue.insert(0, entry)
                else:
                    self._sidebar_prepare_queue.append(entry)
            elif priority:
                for i, entry in enumerate(self._sidebar_prepare_queue):
                    if entry[0] == key:
                        self._sidebar_prepare_queue.insert(0, self._sidebar_prepare_queue.pop(i))
                        break
            if priority:
                running_r103 = getattr(self, "_sidebar_prepare_running_r103", None)
                if (running_r103 and running_r103[0] != key
                        and not self._sidebar_enter_pending_for_r103(running_r103[1])
                        and getattr(self, "_sidebar_prepare_abort_key_r103", "") != running_r103[0]):
                    self._sidebar_prepare_abort_key_r103 = running_r103[0]
                    _log("R103_PREPARE_PREEMPT running=%s for=%s" % (running_r103[0], key))
            if not self._sidebar_prepare_worker_active:
                self._sidebar_prepare_worker_active = True
                start_worker = True
        if start_worker:
            _PKMHomeThreadV2151(target=self._sidebar_prepare_worker, name="PKMSidebarData", daemon=True).start()
        return True

    def _sidebar_prepare_worker(self):
        """Serialize large section-local SQLite work off the GUI thread.

        No Kodi controls or focus/visibility properties are touched here.
        """
        clean_exit = False
        try:
            while not self._closing_event_v1841.is_set():
                self._sidebar_prepare_yield_r85()
                lock = self._sidebar_prepare_state()
                with lock:
                    if not self._sidebar_prepare_queue:
                        self._sidebar_prepare_worker_active = False
                        clean_exit = True
                        return
                    key, sid, title, generation = self._sidebar_prepare_queue.pop(0)
                    was_priority_r103 = key in getattr(self, "_sidebar_prepare_priority_r85", set())
                    try:
                        self._sidebar_prepare_priority_r85.discard(key)
                    except Exception:
                        pass
                    if generation != self._sidebar_prepare_generation.get(key, 0):
                        self._sidebar_prepare_pending.discard(key)
                        continue
                    self._sidebar_prepare_running_r103 = (key, sid, title, was_priority_r103)
                    self._sidebar_prepare_abort_key_r103 = ""
                began = time.monotonic()
                rows = []
                success = False
                aborted_r103 = False
                try:
                    # This thread-local flag suppresses GUI-only rating/cast
                    # enrichment inside the existing recommendation row builder.
                    RECOMMEND_BUILD_CONTEXT_V1616.data_only = True
                    RECOMMEND_BUILD_CONTEXT_V1616.abort_r103 = (
                        lambda _k=key: getattr(self, "_sidebar_prepare_abort_key_r103", "") == _k)
                    exclude = set()
                    section_type = self._section_type_for_id(sid)
                    if self._is_tv_recommend_section(sid, section_type):
                        continue_rows = self._section_continue_rows(
                            sid, limit=max(120, HOME_ROW_ITEM_LIMIT), local_first_v2589=True
                        )
                        for row in continue_rows or []:
                            try:
                                exclude.add(str(tuple(row)[0] or ""))
                            except Exception:
                                pass
                        added = self._append_recommend_row_items(
                            None, rows, "이어보기", continue_rows, sid, 0
                        )
                        tv_rows = self._build_tv_requested_rows_cache(
                            sid, title, 6, added, exclude_keys=exclude
                        )
                        rows.extend(tv_rows or [])
                        # This bulk SQL lookup formerly ran while the 14 native
                        # first-paint ListItems were bound on the GUI thread.
                        if rows:
                            self._prime_episode_show_poster_authority_v2706(rows)
                    elif self._is_movie_recommend_section(sid, section_type):
                        rows = list(self._build_movie_full_section_rows_v1616(
                            sid, title, base_rows=None, home_columns=6
                        ) or [])
                    success = bool(rows)
                except PKMPrepareAbortR103:
                    aborted_r103 = True
                except Exception:
                    _log("SIDEBAR_PREPARE_DATA_ERROR section=%s error=%s" % (
                        sid, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    RECOMMEND_BUILD_CONTEXT_V1616.data_only = False
                    RECOMMEND_BUILD_CONTEXT_V1616.abort_r103 = None
                if aborted_r103:
                    requeued_r103 = 0
                    with lock:
                        self._sidebar_prepare_running_r103 = None
                        self._sidebar_prepare_abort_key_r103 = ""
                        self._sidebar_prepare_pending.discard(key)
                        # Background warm-up keeps its place at the tail; an
                        # abandoned focus prefetch is simply dropped.
                        if (not was_priority_r103
                                and generation == self._sidebar_prepare_generation.get(key, 0)
                                and key not in self._sidebar_prepare_ready):
                            self._sidebar_prepare_pending.add(key)
                            self._sidebar_prepare_queue.append((key, sid, title, generation))
                            requeued_r103 = 1
                    _log("R103_PREPARE_ABORTED section=%s elapsed_ms=%d requeued=%d" % (
                        sid, int((time.monotonic() - began) * 1000), requeued_r103))
                    continue
                with lock:
                    self._sidebar_prepare_running_r103 = None
                    self._sidebar_prepare_abort_key_r103 = ""
                with lock:
                    # A Plex dirty signal or sync invalidation while SQLite was
                    # running invalidates the result, not the selected GUI scene.
                    if generation == self._sidebar_prepare_generation.get(key, 0):
                        self._sidebar_prepare_pending.discard(key)
                        if success:
                            self._sidebar_prepare_ready[key] = rows
                            # PKM_CUMULATIVE_STAGE4_MEMORY
                            # Only unconsumed prepared section rows count here.
                            # Persistent per-section snapshot caches remain intact.
                            self._sidebar_prepare_ready_order_cumulative = [
                                k for k in getattr(self, "_sidebar_prepare_ready_order_cumulative", [])
                                if k != key and k in self._sidebar_prepare_ready
                            ] + [key]
                            # There is at most one ready entry per selected
                            # section. Never evict one before its first GUI
                            # consume: doing so recreates the Shield cold wait.
                            # Memory duplication is avoided by moving (not
                            # copying) this list into _section_rows_cache.
                            selected_keys = {
                                "recommend:%s" % str(s.get("section_id") or s.get("id") or s.get("key") or "").strip()
                                for s in (getattr(self, "sections", None) or [])
                                if isinstance(s, dict)
                            }
                            if selected_keys:
                                for stale in list(self._sidebar_prepare_ready):
                                    if stale not in selected_keys:
                                        self._sidebar_prepare_ready.pop(stale, None)
                                        _log("SIDEBAR_PREPARE_MEMORY_DROP section=%s reason=not_selected" % stale)
                                self._sidebar_prepare_ready_order_cumulative = [
                                    k for k in self._sidebar_prepare_ready_order_cumulative
                                    if k in self._sidebar_prepare_ready
                                ]
                        else:
                            self._sidebar_prepare_failed.add(key)
                _log("SIDEBAR_PREPARE_DATA_END section=%s ready=%d rows=%d elapsed_ms=%d gui_block=0" % (
                    sid, 1 if success else 0, len(rows), int((time.monotonic()-began)*1000)
                ))
                if not self._closing_event_v1841.is_set():
                    # Also post failures: the GUI callback restores the original
                    # synchronous fallback instead of leaving a cold target stuck.
                    # No ControlList operation runs on this thread.
                    try:
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                    except Exception:
                        pass
                # Avoid continuous worker CPU pressure during Shield navigation.
                if self._closing_event_v1841.wait(0.12):
                    break
        finally:
            if not clean_exit:
                lock = self._sidebar_prepare_state()
                restart = False
                with lock:
                    self._sidebar_prepare_worker_active = False
                    restart = bool(self._sidebar_prepare_queue) and not self._closing_event_v1841.is_set()
                    if restart:
                        self._sidebar_prepare_worker_active = True
                if restart:
                    _PKMHomeThreadV2151(target=self._sidebar_prepare_worker, name="PKMSidebarData", daemon=True).start()

    def _bg_wait_quiet_r85(self, quiet_ms=1200, max_s=30.0, peek=None):
        """R85: background DB/CPU work waits until the remote has been idle for
        quiet_ms.  On the Shield the warm-up jobs (13 sections, TV key builds,
        rating fingerprint) took the GIL/CPU right when the user started to
        move, so Info open dropped to ~8 fps.  peek() -> True stops waiting
        (a user-requested job is next).  Bounded by max_s."""
        t0 = time.monotonic()
        waited = False
        while not self._closing_event_v1841.is_set():
            last = float(getattr(self, "_last_input_mono_r85", 0.0) or 0.0)
            if (time.monotonic() - last) * 1000.0 >= quiet_ms:
                break
            if peek is not None:
                try:
                    if peek():
                        break
                except Exception:
                    break
            if time.monotonic() - t0 >= max_s:
                break
            waited = True
            if self._closing_event_v1841.wait(0.15):
                break
        return int((time.monotonic() - t0) * 1000) if waited else 0

    def _sidebar_prepare_yield_r85(self):
        def _priority_next():
            lock = self._sidebar_prepare_state()
            with lock:
                q = self._sidebar_prepare_queue
                if not q:
                    return True
                return q[0][0] in getattr(self, "_sidebar_prepare_priority_r85", set())
        waited = self._bg_wait_quiet_r85(peek=_priority_next)
        if waited:
            _log("SIDEBAR_PREPARE_YIELD_R85 waited_ms=%d" % waited)

    def _sidebar_prepare_warmup(self):
        """Queue TV first, then movie; one data-only worker for all sections."""
        try:
            sections = list(getattr(self, "sections", None) or [])
            for desired_kind in ("tv", "movie"):
                for section in sections:
                    sid = str(section.get("id") or section.get("section_id") or "").strip()
                    if not sid:
                        continue
                    section_type = str(section.get("section_type") or "")
                    actual_kind = (
                        "tv" if self._is_tv_recommend_section(sid, section_type)
                        else "movie" if self._is_movie_recommend_section(sid, section_type)
                        else "other"
                    )
                    if actual_kind != desired_kind:
                        continue
                    # Reuse full first-setup snapshots instead of constructing
                    # the same sidebar rows a second time on Shield TV.
                    if getattr(self, "_section_rows_cache", {}).get("recommend:%s" % sid):
                        continue
                    title = _display_library_title(section.get("title") or sid)
                    self._sidebar_prepare_enqueue(sid, title, priority=False)
        except Exception:
            _log("SIDEBAR_PREPARE_WARMUP_ERROR %s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _sidebar_prepare_warmup_later(self):
        """Start only one low-priority TV prewarm lane after Home is exposed."""
        try:
            if getattr(self, "_sidebar_prepare_warmup_scheduled", False):
                return
            self._sidebar_prepare_warmup_scheduled = True
            def _after_home():
                try:
                    # Do not add work to the critical Home-composition interval.
                    if self._closing_event_v1841.wait(3.0):
                        return
                    for _ in range(80):
                        if self._closing_event_v1841.is_set():
                            return
                        _home_win = xbmcgui.Window(10000)
                        if (_home_win.getProperty("PlexKM.Home.StartupReadyV1619") == "1"
                                or (_home_win.getProperty("PlexKM.Window.IsHome") == "1"
                                    and _home_win.getProperty("PlexKM.Home.StartupGateV1619") != "1")):
                            break
                        if self._closing_event_v1841.wait(0.25):
                            return
                    else:
                        return
                    # R59: with the R57 overlay Home is visible while the startup
                    # prepare worker still builds every destination; warming the
                    # same sections in parallel doubled that work (Shield log).
                    waited_r59 = 0.0
                    while (bool(getattr(self, "_startup_prepare_running_v2477", False))
                           or bool(getattr(self, "_initial_compose_r57_active", False))):
                        if self._closing_event_v1841.wait(0.5):
                            return
                        waited_r59 += 0.5
                        if waited_r59 >= 1500:
                            break
                    if waited_r59 > 0:
                        _log("SIDEBAR_PREPARE_WARMUP_AFTER_STARTUP_PREPARE_R59 waited_ms=%d" % int(waited_r59 * 1000))
                    self._sidebar_prepare_warmup()
                except Exception:
                    _log("SIDEBAR_PREPARE_WARMUP_DELAY_ERROR %s" % (
                        traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
            _PKMHomeThreadV2151(target=_after_home, name="PKMSidebarWarm", daemon=True).start()
        except Exception:
            pass

    def _sidebar_prepare_consume(self, sid):
        """GUI thread consumes immutable completed data for canonical A/B code."""
        key = "recommend:%s" % str(sid or "").strip()
        lock = self._sidebar_prepare_state()
        with lock:
            rows = self._sidebar_prepare_ready.get(key)
            failed = key in self._sidebar_prepare_failed
        if rows:
            self._section_rows_cache[key] = rows
            with lock:
                self._sidebar_prepare_ready.pop(key, None)
                self._sidebar_prepare_ready_order_cumulative = [
                    k for k in getattr(self, "_sidebar_prepare_ready_order_cumulative", []) if k != key
                ]
            _log("SIDEBAR_PREPARE_CACHE_HIT section=%s rows=%d native_publish=gui worker_copy_released=1" % (sid, len(rows)))
            return True
        if failed:
            _log("SIDEBAR_PREPARE_FAILED section=%s reason=data_worker_failed no_foreground_db=1" % sid, xbmc.LOGWARNING)
            return False
        return False

    def _focus_on_retired_surface_r34(self, fid):
        """True when Kodi focus sits on a control of a surface that is not up.

        Kodi keeps focus on a control whose parent group was hidden (e.g. actor
        works 6500 after an actor-work Info opened) and Control.IsVisible() only
        reports the control's own flag, so this is decided by surface ownership.
        """
        try:
            fid = int(fid or 0)
        except Exception:
            return False
        if fid <= 0:
            return False
        try:
            win = xbmcgui.Window(10000)
            if fid in self._ACTOR_FOCUS_IDS_R34:
                return not self._actor_profile_is_active_v2454()
            inline = (self.getProperty("PlexKM.Info.InlineActive") == "1"
                      or win.getProperty("PlexKM.Info.InlineActive") == "1")
            if fid in self._INFO_FOCUS_IDS_R34:
                return (not inline) or self._actor_profile_is_active_v2454()
            # R36: the same rule for every other surface that can hide while
            # holding Kodi focus (failed handoffs left focus on 6500 in R34).
            def _p(name):
                return self.getProperty(name) == "1" or win.getProperty(name) == "1"
            if fid in self._SEARCH_FOCUS_IDS_R36:
                return (not _p("PlexKM.Search.InlineActive")) or inline
            if fid in SECTION_SORT_ITEM_IDS:
                return not (_p("PlexKM.Section.SortDropdownOpen") and _p("PlexKM.Window.IsSectionWall"))
            content = (fid in HOME_ROW_IDS or fid in SECTION_RECOMMEND_ALL_ROW_IDS
                       or fid in (WALL_ID, SECTION_INDEX_ID, SECTION_SORT_BUTTON_ID, 9150, 7709,
                                  SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID, SECTION_TAB_CATEGORY_ID))
            if not content:
                return False
            # Group 834 (all Home/section content) is hidden under Info/Actor
            # and under an exclusive Search surface.
            if inline or self._actor_profile_is_active_v2454() or _p("PlexKM.Search.SurfaceExclusiveV2054"):
                return True
            if fid in HOME_ROW_IDS or fid == 7709:
                return not _p("PlexKM.Window.IsHome")
            if fid in SECTION_RECOMMEND_ALL_ROW_IDS:
                return not _p("PlexKM.Window.IsSectionRecommend")
            if fid in (WALL_ID, SECTION_INDEX_ID, SECTION_SORT_BUTTON_ID):
                return not _p("PlexKM.Window.IsSectionWall")
            if fid == 9150:
                return not _p("PlexKM.Window.IsSectionCategory")
            if fid in (SECTION_TAB_RECOMMEND_ID, SECTION_TAB_LIBRARY_ID, SECTION_TAB_CATEGORY_ID):
                return not (_p("PlexKM.Window.IsSectionRecommend") or _p("PlexKM.Window.IsSectionWall")
                            or _p("PlexKM.Window.IsSectionCategory"))
        except Exception:
            return False
        return False

    def _sidebar_prepare_ready_commit(self):
        """GUI ping publishes only if this very section remains selected."""
        try:
            # R47: _pkm_gui_window_owned_postlog() relies on Window.getId(),
            # which Kodi 21 does not have, so it returns False on every call
            # (see PKM_WINDOW_OWNED_R34) and this whole commit path has been
            # dead. Only the movie stuck-core heal below is revived, using the
            # working R34 ownership test; every other case keeps its exact
            # historical (inactive) behaviour.
            legacy_owned_r47 = self._pkm_gui_window_owned_postlog()
            if not legacy_owned_r47 and not self._pkm_window_owned_r34():
                # Never lose queued data; the next actual PKM focus can consume it.
                return False
            if (self.getProperty("PlexKM.Info.InlineActive") == "1"
                    or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"):
                return False
            item = self._selected_menu_item()
            if not item or str(item.getProperty("kind") or "") != "section":
                return False
            sid = str(item.getProperty("section_id") or "").strip()
            key = "recommend:%s" % sid
            lock = self._sidebar_prepare_state()
            with lock:
                ready = key in self._sidebar_prepare_ready
                failed = key in self._sidebar_prepare_failed
            if failed and not ready:
                # Do not redispatch a 15-second synchronous SQL query from GUI.
                _log('SIDEBAR_PREPARE_GUI_FAILED section=%s previous_scene_kept=1' % sid, xbmc.LOGWARNING)
                return False
            if not ready:
                return False
            stuck_core_only_v46 = False
            existing_cached_v46 = self._section_rows_cache.get(key)
            if existing_cached_v46:
                # R46: a core-only placeholder (3 groups) for a movie section
                # must not permanently block this commit path -- otherwise the
                # finished full compose sits unconsumed until the user
                # manually re-enters the section.
                try:
                    section_type_v46 = self._section_type_for_id(sid)
                    if (self._is_movie_recommend_section(sid, section_type_v46)
                            and self._section_rows_group_count(existing_cached_v46) <= 3
                            and self._sidebar_prepare_ready_groups_r47(sid) > 3):
                        stuck_core_only_v46 = True
                except Exception:
                    stuck_core_only_v46 = False
                if not stuck_core_only_v46:
                    return False
            if not legacy_owned_r47 and not stuck_core_only_v46:
                return False
            # Never publish stale results over another menu or tab, including
            # the Library wall or inline Info.
            if str(getattr(self, "active_section_id", "") or "") != key:
                return False
            if stuck_core_only_v46:
                # R47: publish through the exact sidebar-ENTER path, like the
                # R34 replay does. Only while the sidebar still owns focus and
                # the recommend tab is showing -- never rebuild the row banks
                # under a user who already moved into them (the ready data
                # stays queued; the next ENTER heals it instead).
                reason_r47 = ""
                if self._safe_focus_id() != MENU_ID:
                    reason_r47 = "focus_moved:%s" % self._safe_focus_id()
                elif self.getProperty("PlexKM.Search.InlineActive") == "1":
                    reason_r47 = "search_active"
                elif self._section_last_tab(sid, default="recommend") == "library":
                    reason_r47 = "tab_library"
                if reason_r47:
                    _log("SIDEBAR_PREPARE_STUCK_CORE_AUTOHEAL_DEFER_R47 section=%s reason=%s data_kept=1" % (sid, reason_r47))
                    return False
                _log("SIDEBAR_PREPARE_STUCK_CORE_AUTOHEAL_R47 section=%s existing_groups=%s ready_groups=%s" % (
                    sid, self._section_rows_group_count(existing_cached_v46),
                    self._sidebar_prepare_ready_groups_r47(sid)
                ))
                try:
                    for _w_r47 in (self, xbmcgui.Window(10000)):
                        _w_r47.setProperty("PlexKM.Section.LastFocusRow", "8410")
                except Exception:
                    pass
                self._show_section_recommend_widgets(item, force=True)
                try:
                    self._clear_row_reentry_memory(SECTION_ROW_ANCHOR_SCOPE, reason="r47_autoheal")
                    first_row_r47 = (self._visible_row_controls_for_scope(SECTION_ROW_ANCHOR_SCOPE) or ["8410"])[0]
                    self._remember_row_reentry_focus(first_row_r47, reason="r47_autoheal")
                    if self._safe_focus_id() != MENU_ID:
                        self.setFocusId(MENU_ID)
                except Exception:
                    pass
                return True
            _log("SIDEBAR_PREPARE_GUI_COMMIT section=%s selected=1 data_ready=%d fallback=%d" % (
                sid, 1 if ready else 0, 1 if failed else 0
            ))
            self._menu_refresh_reselect_v1906 = True
            self._refresh_for_menu_focus(force=False)
            return True
        except Exception:
            _log("SIDEBAR_PREPARE_COMMIT_ERROR %s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _sidebar_prepare_ready_groups_r47(self, sid):
        """R47: widget-group count of a finished-but-unconsumed prepare result."""
        try:
            key = "recommend:%s" % str(sid or "").strip()
            lock = self._sidebar_prepare_state()
            with lock:
                rows = self._sidebar_prepare_ready.get(key)
            if not rows:
                return 0
            return int(self._section_rows_group_count(rows) or 0)
        except Exception:
            return 0

    def _arm_native_opening_spinner_v1415(self, rating_key="", source=""):
        """v1497: visual-only black + spinner opening overlay while Kodi opens playback.

        It is armed immediately before PlayMedia so no Home/video handoff frame leaks.
        XML shows the user spinner above opaque black; service.py clears it after AVStarted.
        """
        try:
            try:
                self._arm_playback_priority_v2118(rating_key, reason="native_opening_arm")
            except Exception:
                pass
            win = xbmcgui.Window(10000)
            token = "%s-%d" % (str(rating_key or ""), int(time.time() * 1000))
            win.clearProperty("PlexKM.Playback.NativeOpening")
            win.clearProperty("PlexKM.Playback.NativeOpening.SpinnerVisible")
            win.clearProperty("PlexKM.Playback.NativeOpening.HoldClear")
            win.clearProperty("PlexKM.Playback.NativeOpening.WaitResumeV1551")
            win.clearProperty("PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551")
            win.setProperty("PlexKM.Playback.OpeningActive", "1")
            win.setProperty("PlexKM.Playback.OpeningRatingKey", str(rating_key or ""))
            win.setProperty("PlexKM.Playback.NativeOpening.Pending", "1")
            try:
                self._cancel_info_cast_prewarm_for_playback_v1450(reason="native_opening_arm")
            except Exception:
                pass
            win.setProperty("PlexKM.Playback.NativeOpening.RatingKey", str(rating_key or ""))
            win.setProperty("PlexKM.Playback.NativeOpening.Token", token)
            win.setProperty("PlexKM.Playback.NativeOpening.Source", str(source or ""))
            win.setProperty("PlexKM.Playback.NativeOpening.ArmedAtMs", str(int(time.time() * 1000)))
            # v1547: explicitly tag the plugin resolver's pre-AV lifecycle.
            # service.py will not let its placeholder Start/Stop pair enter the
            # real movie session. Resume position/duration are never reset.
            win.setProperty("PlexKM.Playback.ResolverTokenV1547", token)
            win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "armed")
            win.clearProperty("PlexKM.Playback.ResolverHandoffStopAtMsV1547")
            win.clearProperty("PlexKM.Playback.ResolverAVStartedAtMsV1547")
            win.clearProperty("PlexKM.Playback.ResolverTickHoldLoggedV1547")
            # v1941: the opaque handoff cover is immediate, but the animated
            # spinner is delayed. Fast playback starts therefore never flash a
            # spinner; slow starts reveal it only after the shared threshold.
            win.setProperty("PlexKM.Playback.NativeOpening", "1")
            win.clearProperty("PlexKM.Playback.NativeOpening.SpinnerVisible")
            win.clearProperty("PlexKM.Playback.NativeOpening.ShownAtMs")
            spinner_delay_v2069 = int(pkm_global_busy.foreground_delay_ms())
            _log("PLAYBACK_NATIVE_OPENING_SPINNER_ARM_V2069 rating_key=%s source=%s token=%s cover_immediate=1 spinner_immediate=0 spinner_delay_ms=%d policy=global_foreground" % (rating_key or "", source or "", token, spinner_delay_v2069))

            def _delayed_show(_token, _delay_ms):
                try:
                    xbmc.sleep(max(0, int(_delay_ms)))
                    w = xbmcgui.Window(10000)
                    if w.getProperty("PlexKM.Playback.NativeOpening.Token") != _token:
                        return
                    if w.getProperty("PlexKM.Playback.NativeOpening") != "1":
                        return
                    if w.getProperty("PlexKM.Playback.NativeOpening.Pending") != "1":
                        return
                    if w.getProperty("PlexKM.Playback.ResolverPhaseV1547") == "avstarted":
                        return
                    w.setProperty("PlexKM.Playback.NativeOpening.SpinnerVisible", "1")
                    w.setProperty("PlexKM.Playback.NativeOpening.ShownAtMs", str(int(time.time() * 1000)))
                    _log("PLAYBACK_NATIVE_OPENING_SPINNER_SHOW_DELAYED_V2069 token=%s delay_ms=%d needed=1 policy=global_foreground" % (_token, int(_delay_ms)))
                except Exception:
                    pass
            try:
                _PKMHomeThreadV2151(target=_delayed_show, args=(token, spinner_delay_v2069), daemon=True).start()
            except Exception:
                pass

            def _auto_clear(_token):
                try:
                    # v2229: Plex may be backed by rclone/cloud streaming.  A
                    # perfectly valid file can therefore spend well over 15 s
                    # in Kodi's InputStream/opening path.  Time is diagnostic
                    # only: never convert a slow opening into a playback error.
                    # Keep the cover/spinner until AVStarted, an authoritative
                    # terminal player callback, or an explicit user Back.
                    xbmc.sleep(15000)
                    w = xbmcgui.Window(10000)
                    if w.getProperty("PlexKM.Playback.NativeOpening.Token") != _token:
                        return
                    phase_v2229 = w.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
                    candidate_v2229 = w.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
                    try:
                        video_v2229 = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                    except Exception:
                        video_v2229 = False
                    _log("PLAYBACK_NATIVE_OPENING_SLOW_HOLD_V2229 token=%s phase=%s candidate=%s video=%s opening=%s pending=%s elapsed_ms=15000 action=keep_waiting_rclone_safe" % (
                        _token, phase_v2229,
                        "1" if candidate_v2229 else "0",
                        "1" if video_v2229 else "0",
                        w.getProperty("PlexKM.Playback.OpeningActive") or "0",
                        w.getProperty("PlexKM.Playback.NativeOpening.Pending") or "0",
                    ))
                except Exception:
                    pass
            try:
                _PKMHomeThreadV2151(target=_auto_clear, args=(token,), daemon=True).start()
            except Exception:
                pass
        except Exception:
            try:
                _log("PLAYBACK_NATIVE_OPENING_BLACK_COVER_ARM_FAILED_V1496 rating_key=%s err=%s" % (rating_key or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            except Exception:
                pass
