# -*- coding: utf-8 -*-
"""R465: folder scan queue for "이 기기" movie / TV folders.

- Folders are registered first (pending) and scanned later or right away.
- The PlexKM service runs the queue one folder at a time and publishes
  progress on Window(10000) so the wizard, the status chip and notices can
  show "n / total".
- total = video files counted when the folder was picked (movies: files,
  tv: show folders).  done = items Kodi's library holds under that path.
- After a folder finishes, files that did not reach the library are kept as
  "정보 못 찾은 파일" for later handling.

NAS is read-only: nothing is written next to the videos.  All state lives in
the add-on profile (addon_data).
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import threading
import time
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import pkm_sources

QUEUE_FILE = "scan_queue_r465.json"
UNMATCHED_DIR = "unmatched_r465"
VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".wmv", ".ts", ".m2ts", ".mpg", ".mpeg",
             ".iso", ".webm", ".flv", ".vob", ".rmvb", ".divx", ".3gp", ".strm")
SKIP_DIR_WORDS = ("sample", "trailer", "trailers", "extras", "featurettes", "behind the scenes",
                  "deleted scenes", "interviews", "@eadir", "#recycle", "$recycle.bin", ".actors")
SKIP_FILE_WORDS = ("sample", "-trailer", ".trailer", "_trailer")
MAX_DEPTH = 6

PROP_ACTIVE = "PlexKM.Scan.Active"
PROP_PCT = "PlexKM.Scan.Pct"
PROP_CHIP = "PlexKM.Scan.Chip"
PROP_TITLE = "PlexKM.Scan.Title"
PROP_LINE = "PlexKM.Scan.Line"
PROP_ROWS = "PlexKM.Scan.RowsJson"
PROP_DONE = "PlexKM.Scan.DoneToken"
PROP_REQUEST = "PlexKM.Scan.RunRequest"

_LOCK = threading.RLock()


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] PKM_SCANQ_R465 %s" % msg, level)
    except Exception:
        pass


def _path():
    return os.path.join(pkm_sources._profile_dir(), QUEUE_FILE)


def _load():
    try:
        with open(_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get("folders"), list):
            return data
    except Exception:
        pass
    return {"folders": []}


def _save(data):
    p = _path()
    try:
        d = os.path.dirname(p)
        if d and not os.path.isdir(d):
            os.makedirs(d)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        _log("save_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def folder_id(content, path):
    return pkm_sources.kodi_source_id(content, pkm_sources.normalize_folder(path))


def unit(content):
    return "편" if content == pkm_sources.KODI_CONTENT_MOVIES else "작품"


def kind_label(content):
    return "영화" if content == pkm_sources.KODI_CONTENT_MOVIES else "드라마"


def label_of(path):
    p = str(path or "").rstrip("/\\").replace("\\", "/")
    return p.split("/")[-1] or p


# ---------------------------------------------------------------- counting
def _is_video(name):
    low = name.lower()
    if not low.endswith(VIDEO_EXT):
        return False
    return not any(w in low for w in SKIP_FILE_WORDS)


def _skip_dir(name):
    low = name.lower().strip()
    return low.startswith(".") or any(low == w or low.startswith(w + " ") for w in SKIP_DIR_WORDS)


def _join(base, name):
    base = pkm_sources.normalize_folder(base)
    return base + name


import re as _re
_MOVIE_DIR_R465 = _re.compile(r"(\(\s*(19|20)\d{2}\s*\)|\[\s*(19|20)\d{2}\s*\]|\{tmdb[-=]\d+\}|\{imdb[-=]tt\d+\})", _re.I)


def looks_like_title_dir(name):
    """'기생충 (2019)', 'Title [2019]', '... {tmdb-123}' -> one movie / one show folder."""
    return bool(_MOVIE_DIR_R465.search(str(name or "")))


def _listdir(path, strict=False):
    try:
        p = pkm_sources.normalize_folder(path)
        if strict and not xbmcvfs.exists(p):
            raise IOError("folder not reachable")
        dirs, files = xbmcvfs.listdir(p)
        return [str(d).rstrip("/\\") for d in (dirs or []) if str(d).strip()], [str(f) for f in (files or [])]
    except Exception:
        if strict:
            raise
        return [], []


def readable(path):
    try:
        _listdir(path, strict=True)
        return True
    except Exception:
        return False


def list_videos(path, stop=None, depth=0):
    """Movie items under path.  A title folder ('제목 (연도)') counts once without
    being opened (cloud drives answer each folder listing slowly); other folders
    are walked.  Disc folders (VIDEO_TS/BDMV) count once."""
    out = []
    if depth > MAX_DEPTH or (stop is not None and stop.is_set()):
        return out
    dirs, files = _listdir(path)
    upper = [d.upper() for d in dirs]
    if "VIDEO_TS" in upper or "BDMV" in upper:
        return [pkm_sources.normalize_folder(path)]
    for f in files:
        if _is_video(f):
            out.append(_join(path, f))
    for d in dirs:
        if not d or _skip_dir(d):
            continue
        if looks_like_title_dir(d):
            out.append(pkm_sources.normalize_folder(_join(path, d)))
            continue
        out.extend(list_videos(_join(path, d), stop, depth + 1))
    return out


def count_folder(path, content, stop=None):
    """{total, files} for one folder.

    movies: total = movie items (title folders + loose video files).
    tv: total = show folders.  A folder that holds episodes or season folders
    is one show; otherwise each sub-folder is a show (Kodi's TV-root rule).
    """
    # R465: a folder that cannot be read (network/cloud drive down, no
    # permission) is reported as an error instead of a silent "0".
    try:
        dirs, files = _listdir(path, strict=True)
    except Exception as exc:
        _log("count_read_failed err=%s" % exc, xbmc.LOGWARNING)
        return {"total": 0, "files": [], "episodes": 0, "error": "read"}
    if content != pkm_sources.KODI_CONTENT_TVSHOWS:
        files = list_videos(path, stop)
        return {"total": len(files), "files": files, "episodes": 0}
    if any(_is_video(f) for f in files) or any(_re.match(r"(?i)^(season|시즌|s)\s*\d+", d) for d in dirs):
        return {"total": 1, "files": [pkm_sources.normalize_folder(path)], "episodes": 0}
    shows = [pkm_sources.normalize_folder(_join(path, d)) for d in dirs if d and not _skip_dir(d)]
    return {"total": len(shows), "files": shows, "episodes": 0}


# ---------------------------------------------------------------- library
def _rpc(method, params):
    return pkm_sources._jsonrpc(method, params) or {}


def _filter(path):
    return {"field": "path", "operator": "startswith", "value": pkm_sources.normalize_folder(path)}


def done_count(path, content):
    if content == pkm_sources.KODI_CONTENT_TVSHOWS:
        res = _rpc("VideoLibrary.GetTVShows", {"filter": _filter(path), "limits": {"start": 0, "end": 1}})
    else:
        res = _rpc("VideoLibrary.GetMovies", {"filter": _filter(path), "limits": {"start": 0, "end": 1}})
    try:
        return int((res.get("limits") or {}).get("total", 0) or 0)
    except Exception:
        return 0


def episode_count(path):
    res = _rpc("VideoLibrary.GetEpisodes", {"filter": _filter(path), "limits": {"start": 0, "end": 1}})
    try:
        return int((res.get("limits") or {}).get("total", 0) or 0)
    except Exception:
        return 0


def _library_files(path, content):
    if content == pkm_sources.KODI_CONTENT_TVSHOWS:
        res = _rpc("VideoLibrary.GetEpisodes", {"filter": _filter(path), "properties": ["file"]})
        rows = res.get("episodes") or []
    else:
        res = _rpc("VideoLibrary.GetMovies", {"filter": _filter(path), "properties": ["file"]})
        rows = res.get("movies") or []
    have = set()
    for r in rows:
        f = str(r.get("file") or "")
        if f.startswith("stack://"):
            for part in f[len("stack://"):].split(" , "):
                have.add(part.strip().replace("\\", "/").lower())
        else:
            have.add(f.replace("\\", "/").lower())
    return have


def find_unmatched(path, content, files):
    have = _library_files(path, content)
    out = []
    for f in files or []:
        key = f.replace("\\", "/").lower()
        if key in have or (key.endswith("/") and any(h.startswith(key) for h in have)):
            continue
        out.append(f)
    return out


def _unmatched_path(fid):
    safe = "".join(c if c.isalnum() else "_" for c in fid)[-120:]
    return os.path.join(pkm_sources._profile_dir(), UNMATCHED_DIR, safe + ".json")


def save_unmatched(fid, rows):
    p = _unmatched_path(fid)
    try:
        if not os.path.isdir(os.path.dirname(p)):
            os.makedirs(os.path.dirname(p))
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False)
    except Exception:
        _log("unmatched_save_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def load_unmatched(fid):
    try:
        with open(_unmatched_path(fid), "r", encoding="utf-8") as fh:
            return list(json.load(fh) or [])
    except Exception:
        return []


# ---------------------------------------------------------------- queue
def folders():
    with _LOCK:
        return list(_load().get("folders") or [])


def get(fid):
    for f in folders():
        if f.get("id") == fid:
            return f
    return None


def pending():
    return [f for f in folders() if f.get("status") in ("pending", "scanning", "error")]


def add(content, path, total, files=None, label="", single_show=False):
    """Register a folder in Kodi (content + TMDb scraper) and queue it."""
    path = pkm_sources.normalize_folder(path)
    label = label or label_of(path)
    pkm_sources.add_kodi_source(content, path, label=label, reason="r465_queue")
    if not pkm_sources.kodi_register_path(path, content, single_show=single_show):
        _log("register_failed content=%s" % content, xbmc.LOGWARNING)
        return None
    fid = folder_id(content, path)
    with _LOCK:
        data = _load()
        data["folders"] = [f for f in data["folders"] if f.get("id") != fid]
        data["folders"].append({"id": fid, "path": path, "content": content, "label": label,
                                "total": int(total or 0), "status": "pending", "added": 0,
                                "episodes": 0, "unmatched": 0, "queued_at": int(time.time()),
                                "done_at": 0, "single": bool(single_show)})
        _save(data)
    if files is not None:
        try:
            with open(_unmatched_path(fid) + ".files", "w", encoding="utf-8") as fh:
                json.dump(list(files), fh, ensure_ascii=False)
        except Exception:
            pass
    _log("queued content=%s total=%d" % (content, int(total or 0)))
    return fid


def _files_for(fid, path, content):
    try:
        with open(_unmatched_path(fid) + ".files", "r", encoding="utf-8") as fh:
            return list(json.load(fh) or [])
    except Exception:
        return count_folder(path, content).get("files") or []


def _update(fid, **values):
    with _LOCK:
        data = _load()
        for f in data["folders"]:
            if f.get("id") == fid:
                f.update(values)
        _save(data)


def forget(fid):
    with _LOCK:
        data = _load()
        data["folders"] = [f for f in data["folders"] if f.get("id") != fid]
        _save(data)


def request_run(ids=None):
    """Ask the service to scan the given queued folders (all pending if None)."""
    with _LOCK:
        data = _load()
        want = set(ids or [f.get("id") for f in data["folders"] if f.get("status") in ("pending", "scanning", "error")])
        run_id = str(int(time.time() * 1000))
        for f in data["folders"]:
            if f.get("id") in want:
                f["status"] = "pending"
                f.pop("error", None)
                f["run"] = run_id
        data["run"] = run_id
        _save(data)
    xbmcgui.Window(10000).setProperty(PROP_REQUEST, run_id)
    _log("run_request run=%s folders=%d" % (run_id, len(want)))
    return run_id


def run_rows(run_id=None):
    data = _load()
    run_id = run_id or data.get("run") or ""
    return [f for f in data["folders"] if f.get("run") == run_id and run_id]


def progress(rows):
    total = sum(max(0, int(r.get("total") or 0)) for r in rows)
    done = 0
    for r in rows:
        t = max(0, int(r.get("total") or 0))
        if r.get("status") == "error":
            continue
        if r.get("status") == "done":
            done += t
        else:
            done += min(t, int(r.get("added") or 0))
    pct = int(done * 100 / total) if total else 0
    return done, total, pct


# ---------------------------------------------------------------- runner
def _publish(rows, current=None):
    win = xbmcgui.Window(10000)
    done, total, pct = progress(rows)
    idx = 1 + sum(1 for r in rows if r.get("status") == "done")
    n = len(rows)
    win.setProperty(PROP_ACTIVE, "1")
    win.setProperty(PROP_PCT, str(pct))
    win.setProperty(PROP_CHIP, "스캔 중 %d%%" % pct)
    win.setProperty(PROP_TITLE, "라이브러리 스캔 중 · %d/%d 폴더" % (min(idx, n), n))
    if current:
        win.setProperty(PROP_LINE, "%s · %d / %d%s" % (current.get("label") or "",
                                                       min(int(current.get("added") or 0), int(current.get("total") or 0)),
                                                       int(current.get("total") or 0), unit(current.get("content"))))
    win.setProperty(PROP_ROWS, json.dumps([{k: r.get(k) for k in ("id", "label", "content", "total", "added",
                                                                  "status", "episodes", "unmatched")} for r in rows],
                                          ensure_ascii=False))


def _clear_props():
    win = xbmcgui.Window(10000)
    for p in (PROP_ACTIVE, PROP_PCT, PROP_CHIP, PROP_TITLE, PROP_LINE):
        win.clearProperty(p)


def _notice(kind, title, line1="", line2="", busy=False, prog=None):
    try:
        from resources.lib import pkm_notify
        if hasattr(pkm_notify, "pkm_notice_kind"):
            pkm_notify.pkm_notice_kind(kind, title, line1, line2, progress=prog)
        else:
            tok = pkm_notify.pkm_notice_set(title, line1, line2, busy=busy, force_replace=True)
            if not busy and hasattr(pkm_notify, "pkm_notice_clear_later"):
                pkm_notify.pkm_notice_clear_later(tok, ms=6000)
    except Exception:
        pass


def _scan_one(row, rows, monitor, stop):
    fid, path, content = row["id"], row["path"], row["content"]
    _update(fid, status="scanning")
    row["status"] = "scanning"
    # Kodi runs one library scan at a time: wait for any other scan to end.
    t0 = time.time()
    while pkm_sources.kodi_scanning() and time.time() - t0 < 3600:
        if monitor.waitForAbort(2.0) or stop.is_set():
            return False
    if not readable(path):
        row.update({"status": "error"})
        _update(fid, status="error", error="read", done_at=int(time.time()))
        _log("folder_unreadable content=%s" % content, xbmc.LOGWARNING)
        _notice("err", "폴더를 읽지 못했습니다", "%s · 연결 상태를 확인하세요" % (row.get("label") or ""),
                "라이브러리 관리에서 다시 스캔할 수 있습니다")
        return True
    if not pkm_sources.kodi_register_path(path, content, single_show=bool(row.get("single"))):
        row.update({"status": "error"})
        _update(fid, status="error", error="register", done_at=int(time.time()))
        _notice("err", "폴더를 등록하지 못했습니다", "Kodi 비디오 데이터베이스를 열 수 없습니다")
        return True
    if not pkm_sources.kodi_scan(path):
        row.update({"status": "error"})
        _update(fid, status="error", error="scan", done_at=int(time.time()))
        _notice("err", "스캔을 시작하지 못했습니다", row.get("label") or "", "라이브러리 관리에서 다시 스캔할 수 있습니다")
        return True
    started, t0, last = False, time.time(), -1
    while not stop.is_set():
        scanning = pkm_sources.kodi_scanning()
        started = started or scanning
        n = done_count(path, content)
        if n != last:
            last = n
            row["added"] = n
            _update(fid, added=n)
        _publish(rows, row)
        if (started and not scanning) or (not started and time.time() - t0 > 10):
            break
        if monitor.waitForAbort(2.0):
            return False
    n = done_count(path, content)
    eps = episode_count(path) if content == pkm_sources.KODI_CONTENT_TVSHOWS else 0
    files = _files_for(fid, path, content)
    missing = find_unmatched(path, content, files)
    ignored = set(x.get("file") for x in load_unmatched(fid) if x.get("state") == "ignored")
    save_unmatched(fid, [{"file": f, "state": "ignored" if f in ignored else "open"} for f in missing])
    open_n = len([f for f in missing if f not in ignored])
    row.update({"added": n, "episodes": eps, "unmatched": open_n, "status": "done"})
    _update(fid, status="done", added=n, episodes=eps, unmatched=open_n, done_at=int(time.time()))
    try:
        pkm_sources.set_lib_pref(fid, synced_at=int(time.time()))
    except Exception:
        pass
    _log("folder_done content=%s added=%d total=%d unmatched=%d" % (content, n, int(row.get("total") or 0), open_n))
    return True


def _run(run_id, monitor, stop):
    rows = run_rows(run_id)
    if not rows:
        return
    _log("run_start run=%s folders=%d" % (run_id, len(rows)))
    _publish(rows)
    for row in rows:
        if stop.is_set() or monitor.abortRequested():
            return
        if row.get("status") in ("done", "error"):
            continue
        if not _scan_one(row, rows, monitor, stop):
            return
    _publish(rows)
    win = xbmcgui.Window(10000)
    win.setProperty(PROP_DONE, run_id)
    _clear_props()
    added = sum(int(r.get("added") or 0) for r in rows if r.get("content") == pkm_sources.KODI_CONTENT_MOVIES)
    shows = sum(int(r.get("added") or 0) for r in rows if r.get("content") == pkm_sources.KODI_CONTENT_TVSHOWS)
    miss = sum(int(r.get("unmatched") or 0) for r in rows)
    errs = [r for r in rows if r.get("status") == "error"]
    parts = []
    if added:
        parts.append("영화 %s편" % "{:,}".format(added))
    if shows:
        parts.append("드라마 %s작품" % "{:,}".format(shows))
    line1 = (" · ".join(parts) + " 추가") if parts else "새로 추가된 작품이 없습니다"
    line2 = ("정보 못 찾은 파일 %d개" % miss) if miss else ""
    if errs:
        line2 = ("읽지 못한 폴더 %d개 · 라이브러리 관리에서 다시 스캔" % len(errs))
    _notice("err" if errs and not (added or shows) else ("warn" if (miss or errs) else "ok"), "스캔을 마쳤습니다", line1, line2)
    _log("run_done run=%s movies=%d shows=%d unmatched=%d" % (run_id, added, shows, miss))


def start_background(stop_event=None):
    """Service hook.  Runs queued scans; resumes a run interrupted by a restart."""
    stop = stop_event or threading.Event()

    def _loop():
        monitor = xbmc.Monitor()
        if monitor.waitForAbort(8.0):
            return
        win = xbmcgui.Window(10000)
        seen = ""
        data = _load()
        if any(f.get("status") == "scanning" for f in data.get("folders") or []):
            seen = ""
            win.setProperty(PROP_REQUEST, data.get("run") or "")
        while not monitor.abortRequested() and not stop.is_set():
            req = win.getProperty(PROP_REQUEST) or ""
            if req and req != seen:
                seen = req
                try:
                    _run(req, monitor, stop)
                except Exception:
                    _log("run_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                    _clear_props()
            if monitor.waitForAbort(1.0):
                return
    t = threading.Thread(target=_loop, name="PKMScanQueueR465")
    t.daemon = True
    t.start()
    return t
