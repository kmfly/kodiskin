# -*- coding: utf-8 -*-
"""R108 content-source wizard (first run, and Settings > 콘텐츠 소스 > 추가).

Steps
  source      Plex 서버 / Kodi 라이브러리 cards
  kodi_found  Kodi library already has items -> 이대로 사용 / 폴더 추가
  browse      PKM folder browser (Kodi video sources, drives, storage)
  content     영화 / 드라마·TV
  scan        register folder (TMDB ko-KR) + Kodi library scan with live count

run_wizard() returns:
  {"choice": "plex"}                         -> caller opens the Plex connection flow
  {"choice": "kodi", "content": ..., "path": ...}
  None                                       -> closed with back
"""
from __future__ import absolute_import, unicode_literals

import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import pkm_sources

ADDON = xbmcaddon.Addon("plugin.video.km")
XML_NAME = "plexkm_pkm_source_wizard_r108.xml"
MEDIA = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r97s/"

ACTION_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)

CARD_PLEX, CARD_KODI = 401, 402
BTN_USE, BTN_ADD = 501, 502
LIST_BROWSE = 600
BTN_MOVIES, BTN_TV = 701, 702
BTN_SCAN_DONE = 801
BTN_EXIT = 403   # R113: first-run "나가기" -> Kodi main menu
NET_CHIPS, NET_KEYS, NET_CANCEL, NET_OK = 450, 460, 470, 471   # R338: PlexKM network-path input

_NET_SCHEMES = (
    ("smb://", "윈도우·NAS"), ("nfs://", "NFS"), ("sftp://", "SSH"), ("ftp://", "FTP"), ("dav://", "WebDAV"),
    ("davs://", "WebDAV 보안"), ("http://", "웹"), ("https://", "웹 보안"), ("upnp://", "UPnP"), ("", "모두 지움"),
)
_NET_KEY_ROWS = (
    list("1234567890"), list("qwertyuiop"), list("asdfghjkl:"), list("zxcvbnm./@"),
    ["Aa", "-", "_", "~", "!", "#", "&", "%", "공백", "지움"],
)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.km] PKM_SOURCE_WIZARD_R108 %s" % msg, level)


def _fmt(n):
    try:
        return "{:,}".format(int(n))
    except Exception:
        return str(n)


def _browse_roots():
    rows, seen = [], set()

    def add(label, path, sub):
        key = (path or "").rstrip("/\\").lower()
        if not path or key in seen:
            return
        seen.add(key)
        rows.append({"kind": "dir", "label": label, "path": path, "sub": sub})

    for src in pkm_sources.kodi_video_sources():
        add(src.get("label") or src.get("file"), src.get("file") or "", "Kodi 비디오 소스")
    try:
        from resources.lib import pkm_settings_flow as sf
        for label, path in sf._kodi_file_sources_v1700():
            add(label, path, "Kodi 소스")
        for label, path in sf._local_storage_roots_v1700():
            if path.startswith("special://"):
                continue
            add(label, path, "이 기기")
    except Exception:
        _log("roots_fallback err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return rows


def _join(path, name):
    base = pkm_sources.normalize_folder(path)
    sep = "\\" if base.endswith("\\") else "/"
    return base + name.rstrip("/\\") + sep


def _list_dirs(path):
    dirs, _files = xbmcvfs.listdir(pkm_sources.normalize_folder(path))
    names = sorted([str(d).rstrip("/\\") for d in (dirs or []) if str(d).strip() and not str(d).startswith(".")],
                   key=lambda s: s.lower())
    return [{"kind": "dir", "label": n, "path": _join(path, n), "sub": ""} for n in names]


def _real_parent(path):
    """상위 폴더 경로. 저장소 최상위이면 빈 문자열."""
    p = str(path or "").replace("\\", "/").rstrip("/")
    if not p:
        return ""
    head = p.rpartition("/")[0]
    if "://" in p:
        rest = head.split("://", 1)[1] if "://" in head else ""
        return head + "/" if rest.count("/") >= 1 and rest.split("/")[1] != "" else ""
    if head in ("", "/storage", "/storage/emulated", "/mnt"):
        return ""
    return head + "/"


class SourceWizardDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.mode = kwargs.pop("mode", "first_run")
        self.result = None
        self._step = "source"
        self._history = []
        self._browse_stack = []      # visited folder paths ("" = roots)
        self._rows = []
        self._content_path = ""
        self._scan_thread = None
        self._scan_stop = threading.Event()
        self._closing = False
        super(SourceWizardDialog, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- setup
    def onInit(self):
        self._opened_ts = time.time()
        try:
            self.setProperty("PlexKM.Wiz.Header", "PlexKM 시작 설정" if self.mode == "first_run" else "라이브러리 추가")
            self.setProperty("PlexKM.Wiz.SourceTitle", "어디에서 콘텐츠를 불러올까요?" if self.mode == "first_run"
                             else "어떤 라이브러리를 추가할까요?")
            self.setProperty("PlexKM.Wiz.SourceHint", "설정을 마치면 PlexKM설정 › 라이브러리에서 다른 라이브러리를 추가할 수 있습니다"
                             if self.mode == "first_run" else "추가한 라이브러리는 홈과 검색에 함께 나옵니다")
            self.setProperty("PlexKM.Wiz.PlexConnected", "1" if (pkm_sources.has_plex() and pkm_sources.plex_credentials_ready()) else "")
            self.setProperty("PlexKM.Wiz.KodiConnected", "1" if pkm_sources.has_kodi() else "")
            try:  # R256: Plex signed in but no library chosen yet -> not "연결됨"
                from resources.lib import pkm_sync as _sync256
                pend256 = bool(self.getProperty("PlexKM.Wiz.PlexConnected") == "1" and not _sync256.initial_setup_completed())
            except Exception:
                pend256 = False
            self.setProperty("PlexKM.Wiz.PlexPending", "1" if pend256 else "")
            self.setProperty("PlexKM.Wiz.CanExit", "1" if self.mode == "first_run" else "")
            # Adding from Settings: the already-connected Plex card is not the likely target.
            first = CARD_KODI if (self.mode != "first_run" and self.getProperty("PlexKM.Wiz.PlexConnected") == "1") else CARD_PLEX
            if self.mode in ("add_folder", "add_movies", "add_tvshows", "add_videos", "add_auto"):
                # R334: opened from 내 저장소 > 폴더 추가 - straight to the folder browser.
                # R335: from 라이브러리 > 라이브러리 추가 the type is already chosen.
                self.setProperty("PlexKM.Wiz.Header", {"add_movies": "영화 폴더 추가", "add_tvshows": "드라마 폴더 추가", "add_videos": "영상 폴더 추가", "add_auto": "상위 폴더로 추가"}.get(self.mode, "폴더 추가"))
                self._browse_stack = []
                self._show_browse("", push=False)
            else:
                self._goto("source", push=False, focus=first)
            _log("open mode=%s plex=%s kodi=%s" % (self.mode, self.getProperty("PlexKM.Wiz.PlexConnected") or "0",
                                                  self.getProperty("PlexKM.Wiz.KodiConnected") or "0"))
        except Exception:
            _log("init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            self.close()

    def _goto(self, step, push=True, focus=None):
        if push and self._step != step:
            self._history.append(self._step)
        self._step = step
        dot = {"source": 1, "kodi_found": 2, "browse": 2, "content": 2, "netpath": 2, "scan": 3}.get(step, 1)  # R255: step 1 of 3 (Plex path continues in PKM settings: 2, 3)
        self.setProperty("PlexKM.Wiz.Dot", str(dot))
        self.setProperty("PlexKM.Wiz.Step", step)
        target = focus or {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                           "content": BTN_MOVIES, "netpath": NET_KEYS, "scan": BTN_SCAN_DONE}.get(step)
        if step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            xbmc.sleep(10)
            self.setFocusId(target)
        except Exception:
            pass

    def _refocus(self):
        target = {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                  "content": BTN_MOVIES, "netpath": NET_KEYS, "scan": BTN_SCAN_DONE}.get(self._step, CARD_PLEX)
        if self._step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            self.setFocusId(target)
            _log("refocus step=%s control=%d" % (self._step, target))
        except Exception:
            pass

    def _back(self):
        if self._step == "scan":
            return  # the scan step only closes through its button
        if self._step == "browse" and self._browse_stack:
            self._browse_stack.pop()
            self._show_browse(self._browse_stack[-1] if self._browse_stack else "", push=False)
            return
        if self._history:
            prev = self._history.pop()
            self._goto(prev, push=False)
            return
        if self.mode == "first_run":
            # R259: a stray/late Back (e.g. from closing the settings page) closed the first-run
            # wizard within 0.2 s and left PKM Home dead. Leave only via a card or "Kodi 종료".
            # Back on the very first screen has nothing to go back to: ask instead of ignoring.
            # Ignore a stray Back right after opening, and never stack two confirmations.
            if time.time() - float(getattr(self, "_opened_ts", 0) or 0) < 1.5 or getattr(self, "_back_confirm_open", False):
                _log("back_ignored_first_run")
                return
            self._back_confirm_open = True

            def _ask():
                leave = False
                try:
                    from resources.lib import pkm_settings_flow as _psf
                    keep = _psf.open_pkm_confirm_dialog(
                        "설정을 마치지 않았습니다",
                        "지금 나가면 Kodi가 종료됩니다.[CR]설정을 계속할까요?",
                        yes_label="설정 계속", no_label="Kodi 종료")
                    leave = not keep
                except Exception:
                    _log("back_confirm_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                finally:
                    self._back_confirm_open = False
                if leave and not self._closing:
                    _log("back_confirm_exit")
                    self._close({"choice": "exit"})

            threading.Thread(target=_ask, daemon=True).start()
            return
        self._close(None)

    def _close(self, result):
        self.result = result
        self._closing = True
        self._scan_stop.set()
        self.close()

    # ---------------------------------------------------------------- input
    def onAction(self, action):
        try:
            if self._step == "netpath" and self._net_action(action):
                return
            if action.getId() in ACTION_BACK:
                self._back()
                return
            # Focus lost (e.g. a mouse move over empty space): any key restores it.
            if action.getId() not in (107, 100, 101, 102, 103, 104, 105, 106) and not self.getFocusId():
                self._refocus()
        except Exception:
            _log("action_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def onClick(self, controlId):
        try:
            if controlId == BTN_EXIT:
                _log("choice=exit_to_kodi")
                self._close({"choice": "exit"})
                return
            if controlId == CARD_PLEX:
                _log("choice=plex")
                self._close({"choice": "plex"})
            elif controlId == CARD_KODI:
                self._show_kodi_found()
            elif controlId == BTN_USE:
                pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_LIBRARY, "", label="Kodi 라이브러리",
                                            reason="wizard_use_existing")
                self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_LIBRARY, "path": ""})
            elif controlId == BTN_ADD:
                self._browse_stack = []
                self._show_browse("", push=True)
            elif controlId == LIST_BROWSE:
                self._browse_click()
            elif controlId == NET_CHIPS:
                self._net_chip()
            elif controlId == NET_KEYS:
                self._net_key()
            elif controlId == NET_CANCEL:
                self._back()
            elif controlId == NET_OK:
                self._net_confirm()
            elif controlId in (BTN_MOVIES, BTN_TV):
                content = pkm_sources.KODI_CONTENT_MOVIES if controlId == BTN_MOVIES else pkm_sources.KODI_CONTENT_TVSHOWS
                self._start_scan(content)
            elif controlId == BTN_SCAN_DONE:
                self._close(getattr(self, "_scan_result", None))
        except Exception:
            _log("click_failed control=%s %s" % (controlId, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)

    # ---------------------------------------------------------------- kodi
    def _show_kodi_found(self):
        movies, shows = pkm_sources.kodi_library_counts()
        has = (movies + shows) > 0
        self.setProperty("PlexKM.Wiz.FoundHasItems", "1" if has else "")
        if has:
            parts = []
            if movies:
                parts.append("영화 %s편" % _fmt(movies))
            if shows:
                parts.append("드라마 %s개" % _fmt(shows))
            self.setProperty("PlexKM.Wiz.FoundTitle", "Kodi 라이브러리를 찾았습니다")
            self.setProperty("PlexKM.Wiz.FoundSub", " · ".join(parts) + "\n이대로 쓰거나 폴더를 더 추가할 수 있습니다")
            self.setProperty("PlexKM.Wiz.FoundUse", "이대로 사용")
        else:
            self.setProperty("PlexKM.Wiz.FoundTitle", "영상 폴더를 추가하세요")
            self.setProperty("PlexKM.Wiz.FoundSub", "영화나 드라마가 들어 있는 폴더를 고르면\n정보와 포스터를 자동으로 가져옵니다")
        _log("kodi_found movies=%d shows=%d" % (movies, shows))
        self._goto("kodi_found")

    def _show_browse(self, path, push=False):
        self.setProperty("PlexKM.Wiz.Busy", "1")
        rows = []
        try:
            if not path:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영화·드라마 폴더가 모여 있는 폴더를 고르세요" if self.mode == "add_auto" else "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", "저장소")
                rows = _browse_roots()
                rows.append({"kind": "manual", "label": "네트워크 경로 직접 입력", "path": "",
                             "sub": "smb · nfs · ftp · WebDAV 등"})
            else:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영화·드라마 폴더가 모여 있는 폴더를 고르세요" if self.mode == "add_auto" else "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", path)
                rows = [{"kind": "select", "label": "이 폴더 선택", "path": path, "sub": ""},
                        {"kind": "up", "label": "상위 폴더", "path": "", "sub": ""}]
                try:
                    rows += _list_dirs(path)
                except Exception:
                    rows.append({"kind": "none", "label": "폴더를 열 수 없습니다", "path": "", "sub": ""})
        finally:
            self.setProperty("PlexKM.Wiz.Busy", "")
        self._rows = rows
        items = []
        for row in rows:
            li = xbmcgui.ListItem(label=row["label"], label2=row.get("sub", ""))
            icon = {"select": "check_32.png", "up": "up_32.png", "manual": "cat_server_48.png"}.get(row["kind"], "cat_folder_48.png")
            li.setArt({"icon": MEDIA + icon})
            items.append(li)
        lst = self.getControl(LIST_BROWSE)
        lst.reset()
        lst.addItems(items)
        if self._step != "browse":
            self._goto("browse", push=push)
        else:
            self.setFocusId(LIST_BROWSE)
        lst.selectItem(0)

    def _browse_click(self):
        try:
            pos = int(self.getControl(LIST_BROWSE).getSelectedPosition())
            row = self._rows[pos]
        except Exception:
            return
        kind = row.get("kind")
        if kind == "dir":
            self._browse_stack.append(row["path"])
            self._show_browse(row["path"])
        elif kind == "up":
            # R336: 등록된 폴더로 바로 들어온 경우에도 실제 상위 폴더로 올라간다.
            cur = self._browse_stack[-1] if self._browse_stack else ""
            parent = _real_parent(cur) if len(self._browse_stack) == 1 else ""
            if parent:
                self._browse_stack[-1] = parent
                self._show_browse(parent, push=False)
            else:
                self._back()
        elif kind == "manual":
            self._manual_path()
        elif kind == "select":
            self._content_path = pkm_sources.normalize_folder(row["path"])
            self.setProperty("PlexKM.Wiz.ContentPath", self._content_path)
            if self.mode == "add_videos":
                label = self._content_path.rstrip("/\\").replace("\\", "/").split("/")[-1] or self._content_path
                pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_VIDEOS, self._content_path, label=label,
                                            reason="wizard_videos")
                self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_VIDEOS, "path": self._content_path})
                return
            if self.mode == "add_auto":
                self._auto_detect_and_scan(self._content_path)
                return
            preset = {"add_movies": pkm_sources.KODI_CONTENT_MOVIES,
                      "add_tvshows": pkm_sources.KODI_CONTENT_TVSHOWS}.get(self.mode)
            if preset:
                self._goto("scan")
                self._start_scan(preset)
            else:
                self._goto("content")

    def _auto_detect_and_scan(self, root):
        """R336: 고른 상위 폴더 아래의 영화/드라마 폴더를 자동으로 나눠 한 번에 등록한다."""
        from resources.lib import pkm_folder_detect
        from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
        try:
            found = pkm_folder_detect.detect(root)
        except Exception:
            _log("auto_detect_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            found = []
        if not found:
            try:
                from resources.lib import pkm_notify
                pkm_notify.pkm_show_notice("상위 폴더로 추가", "영화·드라마 폴더를 찾지 못했습니다",
                                           "영화 폴더나 드라마 폴더를 직접 골라 추가하세요", ms=4200)
            except Exception:
                pass
            self.setFocusId(LIST_BROWSE)
            return
        movies = [f for f in found if f[2] == "movies"]
        shows = [f for f in found if f[2] == "tvshows"]
        lines = []
        if movies:
            lines.append("영화 %d개    %s" % (len(movies), ", ".join(f[1] for f in movies[:3]) + (" 외" if len(movies) > 3 else "")))
        if shows:
            lines.append("드라마 %d개    %s" % (len(shows), ", ".join(f[1] for f in shows[:3]) + (" 외" if len(shows) > 3 else "")))
        ok = open_pkm_confirm_dialog("이 폴더들을 추가할까요?", "\n".join(lines),
                                     yes_label="추가", no_label="다시 고르기", default_focus="yes")
        if not ok:
            self.setFocusId(LIST_BROWSE)
            return
        for path, label, kind in found:
            pkm_sources.add_kodi_source(kind, path, label=label, reason="wizard_auto")
            pkm_sources.kodi_register_path(path, kind)
        self._scan_result = {"choice": "kodi", "content": "auto", "path": root}
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
        self.setProperty("PlexKM.Wiz.ScanSub", "창을 닫아도 스캔은 계속됩니다")
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        before = pkm_sources.kodi_library_counts()
        pkm_sources.kodi_scan(None)
        self._scan_stop.clear()
        self._scan_thread = threading.Thread(target=self._scan_watch_auto, args=(before,), name="PKMSourceWizardAutoR336")
        self._scan_thread.daemon = True
        self._scan_thread.start()

    def _scan_watch_auto(self, before):
        started = False
        t0 = time.time()
        monitor = xbmc.Monitor()
        am = at = 0
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            scanning = pkm_sources.kodi_scanning()
            started = started or scanning
            now = pkm_sources.kodi_library_counts()
            am, at = max(0, now[0] - before[0]), max(0, now[1] - before[1])
            if scanning:
                self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
                self.setProperty("PlexKM.Wiz.ScanSub", "지금까지 영화 %s편 · 드라마 %s개 추가됨\n창을 닫아도 스캔은 계속됩니다" % (_fmt(am), _fmt(at)))
            if (started and not scanning) or (not started and time.time() - t0 > 8):
                break
            if monitor.waitForAbort(1.0):
                return
        if not self._scan_stop.is_set():
            self.setProperty("PlexKM.Wiz.ScanDone", "1")
            if am or at:
                self.setProperty("PlexKM.Wiz.ScanTitle", "영화 %s편 · 드라마 %s개를 추가했습니다" % (_fmt(am), _fmt(at)))
                self.setProperty("PlexKM.Wiz.ScanSub", "")
            else:
                self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
                self.setProperty("PlexKM.Wiz.ScanSub", "새로 찾은 작품이 없습니다\n폴더 이름이 작품 제목과 같은지 확인하세요")
            self.setProperty("PlexKM.Wiz.ScanButton", "완료")

    # ------------------------------------------------------- network path input (R338)
    def _manual_path(self):
        """smb/nfs/ftp/sftp/dav/... address typed in the PlexKM input step (no Kodi keyboard)."""
        self._net_text = getattr(self, "_manual_last", "") or "smb://"
        self._net_upper = False
        try:
            chips = self.getControl(NET_CHIPS)
            chips.reset()
            for scheme, desc in _NET_SCHEMES:
                it = xbmcgui.ListItem(scheme or "지우기")
                it.setLabel2(desc)
                chips.addItem(it)
            keys = self.getControl(NET_KEYS)
            keys.reset()
            for row in _NET_KEY_ROWS:
                for k in row:
                    keys.addItem(xbmcgui.ListItem(k))
        except Exception:
            _log("netpath_init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self._net_refresh()
        self._goto("netpath")

    def _net_refresh(self):
        text = getattr(self, "_net_text", "")
        shown = text if len(text) <= 56 else text[-56:]
        self.setProperty("PlexKM.Wiz.NetShown", shown + "|")

    def _net_add(self, ch):
        self._net_text = getattr(self, "_net_text", "") + ch
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self._net_refresh()

    def _net_chip(self):
        try:
            pos = int(self.getControl(NET_CHIPS).getSelectedPosition())
            scheme = _NET_SCHEMES[pos][0]
        except Exception:
            return
        text = getattr(self, "_net_text", "")
        if not scheme:
            self._net_text = ""
        else:
            rest = text.split("://", 1)[1] if "://" in text else text
            self._net_text = scheme + rest
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self._net_refresh()

    def _net_key(self):
        try:
            item = self.getControl(NET_KEYS).getSelectedItem()
            label = item.getLabel()
        except Exception:
            return
        if label == "지움":
            self._net_text = getattr(self, "_net_text", "")[:-1]
            self.setProperty("PlexKM.Wiz.NetNote", "")
            self._net_refresh()
        elif label == "공백":
            self._net_add(" ")
        elif label == "Aa":
            self._net_upper = not getattr(self, "_net_upper", False)
            try:
                keys = self.getControl(NET_KEYS)
                for n in range(keys.size()):
                    it = keys.getListItem(n)
                    lab = it.getLabel()
                    if len(lab) == 1 and lab.isalpha():
                        it.setLabel(lab.upper() if self._net_upper else lab.lower())
            except Exception:
                pass
        else:
            self._net_add(label)

    def _net_action(self, action):
        """Physical keyboard in the netpath step. True = handled."""
        try:
            aid, btn = int(action.getId()), int(action.getButtonCode())
        except Exception:
            return False
        if btn == 61448:   # Backspace key (also arrives as nav-back): delete one char, don't leave the step
            self._net_text = getattr(self, "_net_text", "")[:-1]
            self._net_refresh()
            return True
        for code in (aid, btn):
            ch = ""
            if 0xF100 <= code < 0xF200:
                ch = chr(code - 0xF100)
            elif 0xF200 <= code < 0xF400:
                ch = chr(code - 0xF200)
            if ch and ch.isprintable():
                self._net_add(ch)
                return True
        return False

    def _net_confirm(self):
        text = str(getattr(self, "_net_text", "") or "").strip()
        if not text or text in [s for s, _d in _NET_SCHEMES if s]:
            self.setProperty("PlexKM.Wiz.NetNote", "주소를 입력하세요")
            return
        if "://" not in text:
            text = "smb://" + text.lstrip("/\\")
        self._manual_last = text
        path = pkm_sources.normalize_folder(text)
        self.setProperty("PlexKM.Wiz.NetNote", "경로를 확인하는 중입니다")
        ok = False
        try:
            dirs, files = xbmcvfs.listdir(path)
            ok = bool(dirs or files) or xbmcvfs.exists(path)
        except Exception:
            ok = False
        if not ok:
            _log("manual_path_unreachable")
            self.setProperty("PlexKM.Wiz.NetNote", "그 경로를 열 수 없습니다. 주소, 아이디·비밀번호, 공유 권한을 확인하세요")
            return
        _log("manual_path_ok scheme=%s" % path.split("://", 1)[0])
        self.setProperty("PlexKM.Wiz.NetNote", "")
        if self._history and self._history[-1] == "browse":
            self._history.pop()
        self._browse_stack.append(path)
        self._show_browse(path)

    # ---------------------------------------------------------------- scan
    def _start_scan(self, content):
        path = self._content_path
        label = path.rstrip("/\\").replace("\\", "/").split("/")[-1] or path
        pkm_sources.add_kodi_source(content, path, label=label, reason="wizard_folder")
        registered = pkm_sources.kodi_register_path(path, content)
        kind = "영화" if content == pkm_sources.KODI_CONTENT_MOVIES else "드라마"
        self._scan_result = {"choice": "kodi", "content": content, "path": path}
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
        self.setProperty("PlexKM.Wiz.ScanSub", "%s\n창을 닫아도 스캔은 계속됩니다" % label)
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        if not registered:
            self._scan_finish(kind, 0, failed=True)
            return
        before = pkm_sources.kodi_library_counts()
        pkm_sources.kodi_scan(path)
        self._scan_stop.clear()
        self._scan_thread = threading.Thread(target=self._scan_watch, args=(kind, content, before),
                                             name="PKMSourceWizardScanR108")
        self._scan_thread.daemon = True
        self._scan_thread.start()

    def _scan_watch(self, kind, content, before):
        idx = 0 if content == pkm_sources.KODI_CONTENT_MOVIES else 1
        started = False
        t0 = time.time()
        monitor = xbmc.Monitor()
        added = 0
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            scanning = pkm_sources.kodi_scanning()
            started = started or scanning
            now = pkm_sources.kodi_library_counts()
            added = max(0, now[idx] - before[idx])
            unit = "편" if idx == 0 else "개"
            if scanning:
                self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
                self.setProperty("PlexKM.Wiz.ScanSub", "지금까지 %s %s%s 추가됨\n창을 닫아도 스캔은 계속됩니다" % (kind, _fmt(added), unit))
            if (started and not scanning) or (not started and time.time() - t0 > 8):
                break
            if monitor.waitForAbort(1.0):
                return
        if not self._scan_stop.is_set():
            self._scan_finish(kind, added)

    def _scan_finish(self, kind, added, failed=False):
        unit = "편" if kind == "영화" else "개"
        self.setProperty("PlexKM.Wiz.ScanDone", "1")
        if failed:
            self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 등록하지 못했습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "Kodi 비디오 데이터베이스를 열 수 없습니다")
        elif added:
            self.setProperty("PlexKM.Wiz.ScanTitle", "%s %s%s%s 추가했습니다" % (kind, _fmt(added), unit, "을" if unit == "편" else "를"))
            self.setProperty("PlexKM.Wiz.ScanSub", "")
        else:
            self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "새로 찾은 %s가 없습니다\n폴더 이름이 작품 제목과 같은지 확인하세요" % kind)
        self.setProperty("PlexKM.Wiz.ScanButton", "완료")
        _log("scan_done kind=%s added=%d failed=%s" % (kind, added, "1" if failed else "0"))


def run_wizard(mode="first_run"):
    dlg = None
    try:
        dlg = SourceWizardDialog(XML_NAME, ADDON.getAddonInfo("path"), "Default", "1080i", mode=mode)
        dlg.doModal()
        result = dlg.result
        _log("closed mode=%s result=%s" % (mode, (result or {}).get("choice", "none")))
        return result
    except Exception:
        _log("run_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass
