# -*- coding: utf-8 -*-
"""온라인 조회(4단계 시작): iTunes(한국 스토어) -> Deezer. 후보 목록과 일치 점수.
Kodi 없이 동작. 네트워크는 http_get(url)->dict 를 바꿔 끼울 수 있다(시험·캐시용)."""
import json
import re
import time
import urllib.parse
import urllib.request
from difflib import SequenceMatcher

from . import parser as P

_UA = "PlexKM-musicagent/0.2 (kodi addon)"
_last = {}


def http_get(url, timeout=12):
    host = urllib.parse.urlparse(url).netloc
    gap = 3.2 if "itunes" in host else 0.15       # iTunes 는 분당 약 20회
    wait = _last.get(host, 0) + gap - time.time()
    if wait > 0:
        time.sleep(wait)
    _last[host] = time.time()
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _big(url):
    return re.sub(r"/\d+x\d+(bb)?\.", "/600x600bb.", url or "")


def itunes(artist, title, get=http_get, country="kr"):
    out = []
    term = urllib.parse.quote((artist + " " + title).strip())
    for ent in ("musicVideo", "song"):
        try:
            d = get("https://itunes.apple.com/search?term=%s&country=%s&entity=%s&limit=10" % (term, country, ent))
        except Exception:
            continue
        for r in d.get("results", []):
            out.append({"source": "itunes", "type": ent, "artist": r.get("artistName", ""),
                        "title": r.get("trackName", ""), "album": r.get("collectionName", ""),
                        "year": int(str(r.get("releaseDate", "0"))[:4] or 0),
                        "cover": _big(r.get("artworkUrl100", "")), "url": r.get("trackViewUrl", ""),
                        "genre": r.get("primaryGenreName", "")})
    return out


def deezer(artist, title, get=http_get):
    out = []
    qs = ['artist:"%s" track:"%s"' % (artist, title), "%s %s" % (artist, title)]
    for q in qs:
        try:
            d = get("https://api.deezer.com/search?limit=10&q=" + urllib.parse.quote(q))
        except Exception:
            continue
        for r in d.get("data", []):
            al = r.get("album", {}) or {}
            out.append({"source": "deezer", "type": "song", "artist": (r.get("artist") or {}).get("name", ""),
                        "title": r.get("title", ""), "album": al.get("title", ""), "year": 0,
                        "cover": al.get("cover_xl") or al.get("cover_big", ""), "url": r.get("link", "")})
        if out:
            break
    return out


def _sim(a, b):
    return SequenceMatcher(None, a, b).ratio() if a and b else 0.0


def score(c, artist, title):
    """0~1. 아티스트와 제목 이름 변형(한글/영문 병기, feat, 버전 표기 제거)을 모두 비교한다."""
    av, tv = P.name_variants(artist), P.title_variants(title)
    ca, ct = P.name_variants(c["artist"]), P.title_variants(c["title"])
    sa = max([1.0 if x == y else 0.9 if (x in y or y in x) and min(len(x), len(y)) >= 3 else _sim(x, y)
              for x in av for y in ca] or [0])
    st = max([1.0 if x == y else 0.9 if (x in y or y in x) and min(len(x), len(y)) >= 3 else _sim(x, y)
              for x in tv for y in ct] or [0])
    return round(0.45 * sa + 0.55 * st, 3)


def candidates(artist, title, get=http_get, sources=("itunes", "deezer"), stop_at=0.93):
    """앞 출처에서 충분히 확신하면 뒤 출처는 부르지 않는다. -> 점수순 후보"""
    res = []
    for s in sources:
        res += (itunes if s == "itunes" else deezer)(artist, title, get)
        for c in res:
            c["score"] = score(c, artist, title)
        if res and max(c["score"] for c in res) >= stop_at:
            break
    res.sort(key=lambda c: (-c["score"], c["source"] != "itunes", c["type"] != "musicVideo"))
    return res
