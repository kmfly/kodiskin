# -*- coding: utf-8 -*-
"""PKM content source registry (R108).

PKM can read content from more than one source:
  - "plex": a Plex Media Server (credentials stay in plex_url / plex_token settings)
  - "kodi": folders in the Kodi video library (movies / tvshows)

The first-run wizard adds the first source; Settings > Content sources adds the
other one later.  The registry is a small JSON file in the add-on profile so a
full PKM reset (which purges the profile) returns to a fresh install.

R108 step 1 only introduces the registry and migrates existing installs to a
single Plex source.  Startup behaviour for Plex users is unchanged.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
SOURCES_FILE_NAME = "pkm_sources_r108.json"
SCHEMA_VERSION = 1

TYPE_PLEX = "plex"
TYPE_KODI = "kodi"
KODI_CONTENT_MOVIES = "movies"
KODI_CONTENT_TVSHOWS = "tvshows"
KODI_CONTENT_LIBRARY = "library"      # use the existing Kodi video library as-is

# Kodi-library rows are mirrored into plex_km.db with this key prefix so they
# never collide with Plex rating keys (step 3).
KODI_KEY_PREFIX = "k:"

PROP_SOURCES = "PlexKM.SourcesR108"          # "plex", "kodi" or "plex,kodi"
PROP_HAS_PLEX = "PlexKM.Source.PlexR108"
PROP_HAS_KODI = "PlexKM.Source.KodiR108"

_LOCK = threading.RLock()
_CACHE = {"mtime": None, "data": None}


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _addon():
    try:
        return xbmcaddon.Addon(ADDON_ID)
    except Exception:
        return None


def _profile_dir():
    addon = _addon()
    try:
        base = xbmcvfs.translatePath(addon.getAddonInfo("profile")) if addon else ""
    except Exception:
        base = ""
    if not base:
        base = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    return base


def sources_path():
    return os.path.join(_profile_dir(), SOURCES_FILE_NAME)


def _full_reset_active():
    try:
        win = xbmcgui.Window(10000)
        return (win.getProperty("PlexKM.FullResetInProgressV2150") == "1"
                or win.getProperty("PlexKM.FullResetInProgressV2149") == "1")
    except Exception:
        return False


def _setting(key):
    addon = _addon()
    try:
        return str(addon.getSetting(key) or "").strip() if addon else ""
    except Exception:
        return ""


def plex_credentials_ready():
    return bool(_setting("plex_url") and _setting("plex_token"))


def _empty():
    return {"version": SCHEMA_VERSION, "sources": [], "created_at": int(time.time())}


def _read_file():
    path = sources_path()
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        return None, None
    if _CACHE["mtime"] == mtime and _CACHE["data"] is not None:
        return json.loads(json.dumps(_CACHE["data"])), mtime
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or not isinstance(data.get("sources"), list):
            raise ValueError("bad schema")
    except Exception as exc:
        _log("PKM_SOURCES_R108_READ_FAILED path=%s err=%s" % (path, exc), xbmc.LOGWARNING)
        return None, None
    _CACHE["mtime"], _CACHE["data"] = mtime, data
    return json.loads(json.dumps(data)), mtime


def _write_file(data):
    if _full_reset_active():
        _log("PKM_SOURCES_R108_WRITE_SKIP reason=full_reset", xbmc.LOGINFO)
        return False
    path = sources_path()
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
        _CACHE["mtime"], _CACHE["data"] = None, None
        return True
    except Exception as exc:
        _log("PKM_SOURCES_R108_WRITE_FAILED path=%s err=%s" % (path, exc), xbmc.LOGWARNING)
        return False


def _make_plex_source():
    return {"id": TYPE_PLEX, "type": TYPE_PLEX, "added_at": int(time.time())}


def kodi_source_id(content, path):
    return "%s%s:%s" % (KODI_KEY_PREFIX, content, (path or "").rstrip("/\\").lower())


def ensure_migrated(reason=""):
    """Create the registry on first run of R108.

    Existing installs (Plex credentials saved or first setup already completed)
    become a single Plex source, so nothing changes for them.  A fresh install
    gets an empty list, which the first-run wizard fills.
    """
    with _LOCK:
        data, _mtime = _read_file()
        if data is not None:
            # Keep an already-registered Plex source in step with credentials
            # entered through the existing Plex settings flow.
            if plex_credentials_ready() and not any(s.get("type") == TYPE_PLEX for s in data["sources"]):
                data["sources"].insert(0, _make_plex_source())
                _write_file(data)
                _log("PKM_SOURCES_R108_PLEX_ADDED_FROM_SETTINGS reason=%s" % (reason or ""), xbmc.LOGINFO)
            publish_properties(data)
            return data
        data = _empty()
        existing = plex_credentials_ready() or _initial_setup_completed()
        if existing:
            data["sources"].append(_make_plex_source())
            data["migrated_from"] = "plex_settings"
        _write_file(data)
        _log("PKM_SOURCES_R108_MIGRATED existing=%s sources=%s reason=%s" % (
            "1" if existing else "0", ",".join(s["type"] for s in data["sources"]) or "-", reason or ""), xbmc.LOGINFO)
        publish_properties(data)
        return data


def _initial_setup_completed():
    try:
        state_path = os.path.join(_profile_dir(), "state.json")
        with open(state_path, "r", encoding="utf-8") as fh:
            state = json.load(fh) or {}
        return bool(state.get("initial_setup_completed_v2562") or state.get("initial_sync_done"))
    except Exception:
        return False


def load_sources():
    data, _mtime = _read_file()
    if data is None:
        data = ensure_migrated(reason="load")
    return list(data.get("sources") or [])


def source_types():
    seen = []
    for src in load_sources():
        t = src.get("type")
        if t and t not in seen:
            seen.append(t)
    return seen


def has_plex():
    return TYPE_PLEX in source_types()


def has_kodi():
    return TYPE_KODI in source_types()


def kodi_sources():
    return [s for s in load_sources() if s.get("type") == TYPE_KODI]


def is_fresh_install():
    return not load_sources()


def startup_ready():
    """True when Home may start for the configured sources.

    Plex sources need credentials.  Kodi-only Home is enabled in R108 step 3;
    until then a Kodi-only registry is not considered startable.
    """
    types = source_types()
    if TYPE_PLEX in types:
        return plex_credentials_ready()
    if TYPE_KODI in types:
        return kodi_home_supported()
    return plex_credentials_ready()


def kodi_home_supported():
    return True


def add_plex_source(reason=""):
    with _LOCK:
        data, _ = _read_file()
        data = data or _empty()
        if not any(s.get("type") == TYPE_PLEX for s in data["sources"]):
            data["sources"].append(_make_plex_source())
            _write_file(data)
            _log("PKM_SOURCES_R108_ADD type=plex reason=%s" % (reason or ""), xbmc.LOGINFO)
        publish_properties(data)
        return data


def add_kodi_source(content, path, label="", reason=""):
    if content not in (KODI_CONTENT_MOVIES, KODI_CONTENT_TVSHOWS, KODI_CONTENT_LIBRARY):
        raise ValueError("content must be movies, tvshows or library")
    with _LOCK:
        data, _ = _read_file()
        data = data or _empty()
        sid = kodi_source_id(content, path)
        if not any(s.get("id") == sid for s in data["sources"]):
            data["sources"].append({
                "id": sid, "type": TYPE_KODI, "content": content,
                "path": path, "label": label or "", "added_at": int(time.time()),
            })
            _write_file(data)
            _log("PKM_SOURCES_R108_ADD type=kodi content=%s reason=%s" % (content, reason or ""), xbmc.LOGINFO)
        publish_properties(data)
        return data


def remove_source(source_id, reason=""):
    with _LOCK:
        data, _ = _read_file()
        if not data:
            return False
        before = len(data["sources"])
        data["sources"] = [s for s in data["sources"] if s.get("id") != source_id]
        changed = len(data["sources"]) != before
        if changed:
            _write_file(data)
            _log("PKM_SOURCES_R108_REMOVE id=%s reason=%s" % (source_id, reason or ""), xbmc.LOGINFO)
        publish_properties(data)
        return changed


def publish_properties(data=None):
    try:
        if data is None:
            data, _ = _read_file()
        types = []
        for src in (data or {}).get("sources") or []:
            t = src.get("type")
            if t and t not in types:
                types.append(t)
        win = xbmcgui.Window(10000)
        win.setProperty(PROP_SOURCES, ",".join(types))
        win.setProperty(PROP_HAS_PLEX, "1" if TYPE_PLEX in types else "")
        win.setProperty(PROP_HAS_KODI, "1" if TYPE_KODI in types else "")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Kodi video library helpers (used by the wizard and the Kodi source, step 2-3)
# ---------------------------------------------------------------------------

def _jsonrpc(method, params=None, timeout_id=1):
    req = {"jsonrpc": "2.0", "id": timeout_id, "method": method}
    if params is not None:
        req["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(req))
        resp = json.loads(raw or "{}")
    except Exception as exc:
        _log("PKM_SOURCES_R108_JSONRPC_FAILED method=%s err=%s" % (method, exc), xbmc.LOGWARNING)
        return None
    if "error" in resp:
        _log("PKM_SOURCES_R108_JSONRPC_ERROR method=%s err=%s" % (method, resp.get("error")), xbmc.LOGWARNING)
        return None
    return resp.get("result")


def kodi_library_counts():
    """Return (movies, tvshows) already in the Kodi video library."""
    counts = []
    for method, key in (("VideoLibrary.GetMovies", "movies"), ("VideoLibrary.GetTVShows", "tvshows")):
        res = _jsonrpc(method, {"limits": {"start": 0, "end": 1}}) or {}
        try:
            counts.append(int((res.get("limits") or {}).get("total", 0) or 0))
        except Exception:
            counts.append(0)
    return counts[0], counts[1]


def kodi_video_sources():
    """Video sources configured in Kodi (sources.xml), as [{label, file}]."""
    res = _jsonrpc("Files.GetSources", {"media": "video"}) or {}
    return list(res.get("sources") or [])


# ---------------------------------------------------------------------------
# Kodi folder registration + scan (R108 step 2)
# ---------------------------------------------------------------------------
SCRAPER_MOVIES = "metadata.themoviedb.org.python"
SCRAPER_TVSHOWS = "metadata.tvshows.themoviedb.org.python"
_SCRAPER_LANG_SETTING = {SCRAPER_MOVIES: "language", SCRAPER_TVSHOWS: "languageDetails"}


def normalize_folder(path):
    path = str(path or "").strip()
    if not path:
        return ""
    sep = "\\" if ("://" not in path and "\\" in path) else "/"
    if not path.endswith(("/", "\\")):
        path += sep
    return path


def _video_db_path():
    folder = xbmcvfs.translatePath("special://database/")
    best, best_ver = "", -1
    try:
        for name in os.listdir(folder):
            if name.startswith("MyVideos") and name.endswith(".db"):
                try:
                    ver = int(name[len("MyVideos"):-3])
                except Exception:
                    continue
                if ver > best_ver:
                    best, best_ver = os.path.join(folder, name), ver
    except Exception:
        pass
    return best


def _scraper_settings_xml(scraper):
    key = _SCRAPER_LANG_SETTING.get(scraper, "language")
    return '<settings version="2"><setting id="%s">ko-KR</setting></settings>' % key


def kodi_register_path(path, content):
    """Give a folder its content type + TMDB (Korean) scraper in Kodi's video DB.

    Kodi 21 JSON-RPC has no call to set a folder's content, so the path row is
    written directly (same columns Kodi's "Set content" dialog writes).
    """
    import sqlite3
    path = normalize_folder(path)
    if not path or content not in (KODI_CONTENT_MOVIES, KODI_CONTENT_TVSHOWS):
        return False
    scraper = SCRAPER_MOVIES if content == KODI_CONTENT_MOVIES else SCRAPER_TVSHOWS
    recursive = 2147483647 if content == KODI_CONTENT_MOVIES else 0
    db = _video_db_path()
    if not db:
        _log("PKM_SOURCES_R108_VIDEODB_MISSING", xbmc.LOGWARNING)
        return False
    conn = None
    try:
        conn = sqlite3.connect(db, timeout=10.0)
        row = conn.execute("SELECT idPath FROM path WHERE strPath=?", (path,)).fetchone()
        values = (content, scraper, recursive, 0, _scraper_settings_xml(scraper), 0, 0, 0)
        if row:
            conn.execute("UPDATE path SET strContent=?, strScraper=?, scanRecursive=?, useFolderNames=?, "
                         "strSettings=?, noUpdate=?, exclude=?, allAudio=? WHERE idPath=?", values + (row[0],))
        else:
            conn.execute("INSERT INTO path(strPath, strContent, strScraper, scanRecursive, useFolderNames, "
                         "strSettings, noUpdate, exclude, allAudio, dateAdded) VALUES(?,?,?,?,?,?,?,?,?,?)",
                         (path,) + values + (time.strftime("%Y-%m-%d %H:%M:%S"),))
        conn.commit()
        _log("PKM_SOURCES_R108_KODI_PATH_SET content=%s scraper=%s" % (content, scraper), xbmc.LOGINFO)
    except Exception as exc:
        _log("PKM_SOURCES_R108_KODI_PATH_SET_FAILED err=%s" % exc, xbmc.LOGWARNING)
        return False
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass
    _add_kodi_video_source_xml(path)
    return True


def _add_kodi_video_source_xml(path, label=""):
    """Also list the folder under Kodi's Videos sources (sources.xml)."""
    import xml.etree.ElementTree as ET
    src_file = xbmcvfs.translatePath("special://profile/sources.xml")
    try:
        if os.path.exists(src_file):
            tree = ET.parse(src_file)
            root = tree.getroot()
        else:
            root = ET.Element("sources")
            tree = ET.ElementTree(root)
        video = root.find("video")
        if video is None:
            video = ET.SubElement(root, "video")
            ET.SubElement(video, "default", {"pathversion": "1"})
        for node in video.findall("source/path"):
            if normalize_folder(node.text or "").lower() == path.lower():
                return True
        src = ET.SubElement(video, "source")
        name = label or path.rstrip("/\\").replace("\\", "/").split("/")[-1] or path
        ET.SubElement(src, "name").text = name
        ET.SubElement(src, "path", {"pathversion": "1"}).text = path
        ET.SubElement(src, "allowsharing").text = "true"
        tmp = src_file + ".pkm_tmp"
        tree.write(tmp, encoding="utf-8", xml_declaration=True)
        os.replace(tmp, src_file)
        return True
    except Exception as exc:
        _log("PKM_SOURCES_R108_SOURCES_XML_FAILED err=%s" % exc, xbmc.LOGWARNING)
        return False


def kodi_scan(path=None):
    params = {"showdialogs": False}
    if path:
        params["directory"] = normalize_folder(path)
    res = _jsonrpc("VideoLibrary.Scan", params)
    _log("PKM_SOURCES_R108_KODI_SCAN dir=%s ok=%s" % ("1" if path else "all", "1" if res is not None else "0"), xbmc.LOGINFO)
    return res is not None


def kodi_scanning():
    try:
        return bool(xbmc.getCondVisibility("Library.IsScanningVideo"))
    except Exception:
        return False
