# -*- coding: utf-8 -*-
"""R140: 재생 중 FF/REW 배속 탐색 (OSD 없이).

FullscreenVideo 에서 FF/REW(또는 키보드 f/r) 를 누르면 이 스크립트가 뜬다.
  * 영상은 어둡게 덮고 소리만 끈 채 계속 재생(일시정지하면 Kodi 가 초당 10~12번만 그려 끊김),
    바 위 한 줄 알약이 목표 지점을 따라 움직인다.
  * 같은 방향 키 = 2 -> 4 -> 8 -> 16배 (Plex 와 같은 체감 속도), 반대 방향 키 = 한 단계씩 내려가다
    2배에서 한 번 더 누르면 방향이 바뀐다. 좌/우 키도 같은 동작.
  * OK(또는 재생) = 그 지점부터 재생(이동 후 버퍼링 동안 공통 링 스피너),
    BACK/정지 = 취소(보던 영상 그대로 이어서).
부드러움: 움직임은 한 프레임마다 컨트롤 위치/폭만 바꾸고(텍스트 다시 그리기 없음),
시각 글자는 0.1초마다, 그것도 글자가 바뀔 때만 고친다.
"""
from __future__ import absolute_import, unicode_literals

import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
SPEEDS = (2, 4, 8, 16, 32)
# 11-16: 사용자가 찍은 Plex 영상 기준으로 맞춤 — Plex 4x ≈ 초당 2분, 16x ≈ 초당 8~10분 이동.
# R171: 너무 빨라서 절반으로 - 표시 배속 1x 당 초당 8초 (2x=16초/초, 4x=32초/초, 8x=64초/초, 16x=128초/초).
RATE_SCALE = 8.0
BAR_L, BAR_W, BAR_T = 96, 1728, 990
PILL_W = 120
FRAME_S = 1.0 / 60.0

A_LEFT, A_RIGHT, A_SELECT = 1, 2, 7
A_BACKS = (9, 10, 13, 92, 216)          # parent dir, previous menu, stop, nav back, back
A_PLAYS = (12, 68, 79, 229)             # pause, play, player play, playpause
A_FF, A_REW = (77, 14), (78, 15)        # player forward/rewind (+ big step keys)
A_AN_FF, A_AN_REW = (113, 124, 112), (114, 125, 111)  # 게임패드 트리거·범퍼(창 안에선 ScrollDown/Up 으로 옴)(아날로그 앞/뒤): 누르고 있으면 계속 오므로 0.35s 간격으로만 받음

WIN = xbmcgui.Window(10000)


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _fmt(sec, long_fmt):
    sec = max(0, int(sec))
    h, m, s = sec // 3600, (sec % 3600) // 60, sec % 60
    if long_fmt:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


class TrickDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.start_pos = float(kwargs.pop("start_pos", 0.0))
        self.dur = max(1.0, float(kwargs.pop("duration", 1.0)))
        first_dir = kwargs.pop("first_dir", 1)
        super(TrickDialog, self).__init__(*args)
        self.target = self.start_pos
        self.dir = 1 if first_dir >= 0 else -1
        self.idx = 0
        self.result = "cancel"
        self._stop = False
        self._long = self.dur >= 3600
        self._last_time_label = None
        self._last_rem_label = None
        self._th = None
        self._ready = False
        self._frames = 0
        self._slow_frames = 0

    # ----------------------------------------------------------- 화면
    def onInit(self):
        try:
            self.c_fill = self.getControl(101)
            self.c_seg = self.getControl(102)
            self.c_mover = self.getControl(130)
            self.c_pill = self.getControl(110)
            self._pill_dx = None
            self.c_speed = self.getControl(111)
            self.c_pos = self.getControl(120)
            self.c_rem = self.getControl(121)
            fill_w = max(6, int(BAR_W * self.start_pos / self.dur))
            self.c_fill.setWidth(fill_w)
            self.c_pos.setLabel(_fmt(self.start_pos, self._long))
            self._apply_speed_label()
            self._place(self.target, force_label=True)
            self._ready = True
        except Exception as exc:
            _log("TRICKPLAY_INIT_FAILED_R140 err=%s" % exc, xbmc.LOGWARNING)
        self._th = threading.Thread(target=self._loop, name="PKMTrickplayR140")
        self._th.daemon = True
        self._th.start()

    def _apply_speed_label(self):
        WIN.setProperty("PlexKM.Trick.Dir", "fwd" if self.dir > 0 else "rew")
        try:
            self.c_speed.setLabel("%d×" % SPEEDS[self.idx])
        except Exception:
            pass

    def _place(self, t, force_label=False):
        x = BAR_L + int(round(BAR_W * t / self.dur))
        a = BAR_L + int(round(BAR_W * self.start_pos / self.dur))
        lo, hi = (a, x) if x >= a else (x, a)
        self.c_seg.setPosition(lo, BAR_T)
        self.c_seg.setWidth(max(1, hi - lo))
        self._move(x)
        lbl = _fmt(t, self._long)
        if force_label or lbl != self._last_time_label:
            self._last_time_label = lbl
            self.c_pos.setLabel(lbl)  # Plex 처럼 왼쪽 시간도 목표 시각
        rem = "-" + _fmt(self.dur - t, self._long)
        if force_label or rem != self._last_rem_label:
            self._last_rem_label = rem
            self.c_rem.setLabel(rem)

    def _move(self, x):
        # 그룹 하나만 옮김. 알약이 화면 끝에 닿을 때만 그룹 안 위치를 고침(드묾).
        px = min(max(x - PILL_W // 2, 24), 1920 - 24 - PILL_W)
        dx = px - x
        if dx != self._pill_dx:
            self._pill_dx = dx
            self.c_pill.setPosition(dx, BAR_T - 46)
        if x != getattr(self, "_last_x", None):
            self._last_x = x
            self.c_mover.setPosition(x, 0)

    def _loop(self):
        last = time.time()
        label_due = 0.0
        while not self._stop:
            xbmc.sleep(int(FRAME_S * 1000))
            now = time.time()
            dt = now - last
            last = now
            if dt > 0.05:
                self._slow_frames += 1
            self._frames += 1
            # 11-16: 영상이 끝나거나 멈추면 배속 화면도 닫는다(인포 위에 남던 문제).
            if self._frames % 8 == 0:
                try:
                    gone = not xbmc.getCondVisibility("Player.HasVideo")
                except Exception:
                    gone = True
                if gone:
                    self.result = "cancel"
                    _log("TRICKPLAY_PLAYER_GONE_R140 action=close")
                    self._close()
                    break
            if not self._ready:
                continue
            v = self.dir * SPEEDS[self.idx] * RATE_SCALE
            t = self.target + v * dt
            t = min(max(t, 0.0), self.dur - 1.0)
            self.target = t
            try:
                full = now >= label_due
                if full:
                    label_due = now + 0.1
                    self._place(t)
                else:
                    # 프레임마다: 위치만
                    x = BAR_L + int(round(BAR_W * t / self.dur))
                    a = BAR_L + int(round(BAR_W * self.start_pos / self.dur))
                    lo, hi = (a, x) if x >= a else (x, a)
                    self.c_seg.setPosition(lo, BAR_T)
                    self.c_seg.setWidth(max(1, hi - lo))
                    self._move(x)
            except Exception:
                pass

    # ----------------------------------------------------------- 키
    def step(self, want_dir):
        if want_dir == self.dir:
            self.idx = min(self.idx + 1, len(SPEEDS) - 1)
        elif self.idx > 0:
            self.idx -= 1
        else:
            self.dir = want_dir
        self._apply_speed_label()
        _log("TRICKPLAY_SPEED_R140 dir=%s speed=%d target=%.1f" % ("fwd" if self.dir > 0 else "rew", SPEEDS[self.idx], self.target))

    def onAction(self, action):
        aid = action.getId()
        if aid in A_AN_FF or aid in A_AN_REW:
            now = time.time()
            if now - getattr(self, "_last_analog", 0.0) < 0.35:
                return
            self._last_analog = now
            self.step(1 if aid in A_AN_FF else -1)
            return
        if aid in A_FF or aid == A_RIGHT:
            self.step(1)
        elif aid in A_REW or aid == A_LEFT:
            self.step(-1)
        elif aid == A_SELECT or aid in A_PLAYS:
            self.result = "seek"
            self._close()
        elif aid in A_BACKS:
            self.result = "cancel"
            self._close()

    def onClick(self, control_id):
        if control_id == 9999:
            self.result = "seek"
            self._close()

    def _close(self):
        self._stop = True
        self.close()


def _parse(argv):
    out = {}
    for a in argv[1:]:
        for part in str(a).lstrip("?").split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                out[k] = v
    return out


def main():
    params = _parse(sys.argv)
    first_dir = -1 if params.get("dir") == "rew" else 1
    if WIN.getProperty("PlexKM.Trick.Active") == "1":
        return
    if WIN.getProperty("PlexKM.Trailer.Playing"):
        return  # R315: 관련 영상(트레일러) 재생 중에는 배속 탐색 창을 띄우지 않음
    player = xbmc.Player()
    try:
        if not player.isPlayingVideo():
            return
        pos = float(player.getTime())
        dur = float(player.getTotalTime())
    except Exception:
        return
    if dur <= 5 or dur - pos < 3.0:
        return
    WIN.setProperty("PlexKM.Trick.Active", "1")
    try:
        from resources.lib import pkm_tips as _tips_r315
        _tips_r315.mark_used("quick_seek")
    except Exception:
        pass
    was_playing = not xbmc.getCondVisibility("Player.Paused")
    # 11-16: 일시정지하면 Kodi 가 화면을 초당 10~12번만 그려 알약이 끊겨 보임(쉴드 녹화).
    # → 탐색 중엔 영상을 어둡게 덮고 소리만 끈 채 계속 재생(초당 30번 그려져 부드러움).
    muted_by_us = False
    if was_playing and not xbmc.getCondVisibility("Player.Muted"):
        xbmc.executebuiltin("Mute")
        muted_by_us = True
    t0 = time.time()
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        dlg = TrickDialog("plexkm_trickplay_r140.xml", addon.getAddonInfo("path"), "Default", "1080i",
                          start_pos=pos, duration=dur, first_dir=first_dir)
        _log("TRICKPLAY_OPEN_R140 dir=%s pos=%.1f dur=%.1f was_playing=%d open_ms=%d" % (
            "rew" if first_dir < 0 else "fwd", pos, dur, 1 if was_playing else 0, int((time.time() - t0) * 1000)))
        dlg.doModal()
        result, target = dlg.result, dlg.target
        frames, slow = dlg._frames, dlg._slow_frames
        del dlg
        _log("TRICKPLAY_CLOSE_R140 result=%s from=%.1f to=%.1f frames=%d slow_frames=%d" % (result, pos, target, frames, slow))
        if result == "seek" and abs(target - pos) >= 1.0:
            # 이동하는 동안 공통 링 스피너(0.35초 뒤, 색 단계 적용)
            WIN.setProperty("PlexKM.Trick.Seeking", "1")
            t_seek = time.time()
            player.seekTime(target)
            mon = xbmc.Monitor()
            ok = False
            while not mon.abortRequested() and time.time() - t_seek < 60:
                if mon.waitForAbort(0.05):
                    break
                try:
                    if not player.isPlayingVideo():
                        break
                    busy = xbmc.getCondVisibility("Player.Seeking | Player.Caching")
                    near = abs(player.getTime() - target) < 8.0
                except Exception:
                    break
                if near and not busy:
                    ok = True
                    break
            WIN.clearProperty("PlexKM.Trick.Seeking")
            _log("TRICKPLAY_SEEK_DONE_R140 ok=%d wait_ms=%d" % (1 if ok else 0, int((time.time() - t_seek) * 1000)))
        # 취소(BACK): 영상은 계속 재생 중이었으므로 그대로 이어서 봄
    except Exception as exc:
        _log("TRICKPLAY_FAILED_R140 err=%s" % exc, xbmc.LOGWARNING)
    finally:
        if muted_by_us and xbmc.getCondVisibility("Player.Muted"):
            xbmc.executebuiltin("Mute")
        WIN.clearProperty("PlexKM.Trick.Active")
        WIN.clearProperty("PlexKM.Trick.Dir")
        WIN.clearProperty("PlexKM.Trick.Seeking")


if __name__ == "__main__":
    main()
