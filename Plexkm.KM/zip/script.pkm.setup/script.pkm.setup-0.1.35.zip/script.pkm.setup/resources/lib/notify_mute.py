# -*- coding: utf-8 -*-
"""설치 도우미가 열려 있는 동안 코디 기본 설치 알림(토스트)을 끈다.

코디 기본 알림은 현재 스킨 모양이라 애드온 이름이 길면 잘린다.  도우미 화면이 설치
상태를 직접 보여 주므로, 도우미가 끝나면 사용자의 원래 설정으로 되돌린다.
"""
import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

SETTING = "general.addonnotifications"


def _marker():
    p = xbmcvfs.translatePath(xbmcaddon.Addon("script.pkm.setup").getAddonInfo("profile"))
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return os.path.join(p, "notify_restore.json")


def _rpc(method, params):
    try:
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        return json.loads(raw).get("result")
    except Exception:
        return None


def mute():
    """알림을 끄고, 원래 값을 파일에 남긴다(이미 남아 있으면 그 값을 유지)."""
    try:
        marker = _marker()
        if not os.path.exists(marker):
            res = _rpc("Settings.GetSettingValue", {"setting": SETTING})
            if res is None or "value" not in res:
                return
            with open(marker, "w", encoding="utf-8") as f:
                json.dump({"value": bool(res["value"])}, f)
        _rpc("Settings.SetSettingValue", {"setting": SETTING, "value": False})
    except Exception:
        pass


def restore():
    """원래 값으로 되돌리고 표시 파일을 지운다."""
    try:
        marker = _marker()
        if not os.path.exists(marker):
            return
        with open(marker, "r", encoding="utf-8") as f:
            value = bool(json.load(f).get("value", True))
        _rpc("Settings.SetSettingValue", {"setting": SETTING, "value": value})
        os.remove(marker)
    except Exception:
        pass
