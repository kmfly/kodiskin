# -*- coding: utf-8 -*-
"""PlexKM 뮤직비디오: 라이브러리에 등록한 뮤직비디오 폴더를 읽어 사이드메뉴와 목록으로 보여 준다.

이름 읽기·색인·갱신·앨범아트 수집은 script.module.pkm.musicagent(종속 모듈)가 한다. 모듈이 없으면 이 파일은
아무 일도 하지 않고(available() == False) PlexKM 은 그대로 동작한다.
1차 버전: 사이드메뉴 항목 -> 코디 기본 목록(아티스트 -> 영상). 인포 페이지·격자 보기는 시안 확정 뒤.
"""
import os
import threading
import time
import traceback

try:
    from urllib.parse import quote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import xbmcaddon
except Exception:  # pragma: no cover
    xbmcaddon = None

def _load_agent():
    """종속 모듈(script.module.pkm.musicagent)을 불러온다. 코디가 아직 사용 안 함 상태로 둔 모듈이어도, 파일이 있으면 경로를 직접 더해 쓴다."""
    try:
        import pkm_musicagent as mod
        return mod
    except Exception:
        pass
    try:
        import sys
        lib = xbmcvfs.translatePath("special://home/addons/script.module.pkm.musicagent/lib")
        if lib and os.path.isdir(lib):
            if lib not in sys.path:
                sys.path.append(lib)
            import pkm_musicagent as mod
            return mod
    except Exception:
        pass
    return None


_agent = _load_agent()  # 모듈이 아직 설치되지 않은 기기는 None

from resources.lib import pkm_sources as ps

PLUGIN = "plugin://plugin.video.km/"

# 스캔 전에 보여 주는 이름 안내(확인창 글상자는 줄바꿈되지만 잘리지 않게 줄을 짧게 둔다)
GUIDE_TITLE = "뮤직비디오 이름 안내"
GUIDE_BODY = "\n".join([
    "아티스트 - 제목.mp4 로 두면 가장 잘 읽힙니다",
    "음악방송은 날짜 폴더 안에 무대 파일을 둡니다",
    "콘서트·공연은 작품마다 폴더 하나로 둡니다",
    "같은 이름의 .nfo, -poster.jpg 가 있으면 먼저 씁니다",
])
_STORE = [None]
_WATCH = {}


def _log(msg, level=xbmc.LOGINFO):
    try:
        import re as _re
        msg = _re.sub(r"(?<=://)[^/@\s]*@", "***@", msg)
        xbmc.log("[plugin.video.km] MV_R337 " + msg, level)
    except Exception:
        pass


def available():
    global _agent
    if _agent is None:
        _agent = _load_agent()
    return _agent is not None


def _store():
    if _STORE[0] is None:
        base = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
        _STORE[0] = _agent.IndexStore(base)
    return _STORE[0]


# ------------------------------------------------------------------ 소스
def sources():
    return [s for s in ps.kodi_sources() if s.get("content") == ps.KODI_CONTENT_MUSICVIDEOS]


def _root(src):
    return ps.normalize_folder(src.get("path") or "")


def _folder_name(src):
    parts = [x for x in (src.get("path") or "").replace("\\", "/").split("/") if x and not x.endswith(":")]
    return parts[-1] if parts else ""


def display_name(src):
    return ps.lib_pref(src.get("id"), "name", "") or src.get("label") or _folder_name(src) or "뮤직비디오"


def visible_sources():
    return [s for s in sources() if not ps.lib_pref(s.get("id"), "hidden", False)]


def sidebar_sig():
    return tuple((s.get("id"), display_name(s)) for s in visible_sources())


def bump():
    """사이드메뉴가 항목을 다시 만들게 한다(기존 코디 라이브러리 감시 스레드가 이 값을 본다)."""
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.SyncedAtR108", str(time.time()))
    except Exception:
        pass


def summary(src):
    """설정 화면용: (개수, 마지막 스캔 시각)."""
    if not available():
        return 0, 0
    try:
        idx = _store().load(src["id"])
        return len(idx.get("items", [])), int(idx.get("scanned_at") or 0)
    except Exception:
        return 0, 0


# ------------------------------------------------------------------ 스캔
def _listdir_for(root):
    def listdir(rel):
        path = root + (rel + "/" if rel else "")
        dirs, files = xbmcvfs.listdir(path)
        # 느린 네트워크 폴더라 파일마다 Stat 을 부르지 않는다(크기·시각 0). 추가·삭제는 목록 차이로 감지.
        return [(d, True, 0, 0) for d in dirs] + [(f, False, 0, 0) for f in files]
    return listdir


def _reader_for(root):
    def read_text(rel):
        f = xbmcvfs.File(root + rel)
        try:
            return f.read()
        finally:
            f.close()
    return read_text


def scan_source(src, notify=True):
    """백그라운드로 스캔하고, 끝나면 알림 + 사이드메뉴 갱신. 이미 돌고 있으면 False."""
    if not available():
        return False
    sid = src["id"]
    root = _root(src)
    st = _store()
    if not st.scan_async(sid, _listdir_for(root), _reader_for(root), None, default_kind="mv"):
        return False
    name = display_name(src)
    if notify:
        _toast("%s 스캔을 시작했습니다" % name)

    def _watch():
        mon = xbmc.Monitor()
        while not mon.abortRequested():
            state = (st.progress.get(sid) or {}).get("state")
            if state != "running":
                break
            if mon.waitForAbort(1.0):
                return
        res = (st.progress.get(sid) or {})
        if res.get("state") == "done":
            r = res.get("result") or {}
            if int(r.get("total") or 0) <= 0:
                _log("scan_empty sid=%s %s" % (sid, r), xbmc.LOGWARNING)
                if notify:
                    _toast("%s 폴더를 읽지 못했거나 영상이 없습니다. 주소와 접속 정보를 확인해 주세요" % name, ms=6000)
                bump()
                return
            ps.set_lib_pref(sid, synced_at=int(time.time()))
            try:                          # 섹션을 먼저 연다(이미 받은 그림은 바로, 나머지는 받는 대로 바꿔 끼운다)
                mirror_source(src)
            except Exception:
                _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            if notify:
                _toast("%s 정리를 마쳤습니다: %d개\n앨범아트와 곡 정보를 받는 중입니다" % (name, int(r.get("total") or 0)), ms=5000)
            bump()
            _scrape_and_show(src, notify=notify)
            return
        _log("scan_failed sid=%s %s" % (sid, res.get("error", "")), xbmc.LOGWARNING)
        if notify:
            _toast("%s 스캔에 실패했습니다" % name, ms=5000)
        bump()
    threading.Thread(target=_watch, name="PKMMusicVideoScanWatch", daemon=True).start()
    return True


def _scrape_and_show(src, notify=True):
    """수집(모듈) → 단계마다 영화 DB 반영 → 끝나면 가수 배경(느림)을 백그라운드로. 호출한 스레드에서 돈다."""
    name = display_name(src)

    def on_stage(stage):
        try:
            mirror_source(src)
            bump()
        except Exception:
            _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    res = None
    try:
        res = scrape(src, on_stage=on_stage)
    except Exception:
        _log("scrape_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    on_stage("done")
    if notify and res:
        _toast("%s 앨범아트와 곡 정보를 마쳤습니다: %d개 중 %d개" % (name, int(res.get("total") or 0), int(res.get("art") or 0)), ms=5000)
    enrich_artists(src)          # 가수 배경·로고(MusicBrainz·fanart.tv)는 천천히 백그라운드로


def enrich_source(src, notify=True):
    """온라인에서 앨범 자켓·발매 정보를 찾는다(백그라운드, 이어받기). 찾는 대로 목록에 반영된다."""
    if not available() or not hasattr(_agent, "lookup"):
        return False
    sid = src["id"]
    st = _store()
    try:
        _agent.lookup.ITUNES_BUDGET[0] = 300
    except Exception:
        pass
    if not st.enrich_async(sid, _agent.lookup.candidates):
        return False
    key = sid + ":enrich"
    name = display_name(src)
    if notify:
        _toast("%s 앨범 자켓을 찾는 중입니다. 백그라운드로 계속됩니다" % name, ms=5000)

    def _watch():
        mon = xbmc.Monitor()
        last_mirror = time.time()
        while not mon.abortRequested():
            if (st.progress.get(key) or {}).get("state") != "running":
                break
            if mon.waitForAbort(2.0):
                return
            if time.time() - last_mirror >= 90:      # 찾는 대로 자켓이 화면에 나타나게 주기적으로 영화 DB 에 반영
                last_mirror = time.time()
                try:
                    mirror_source(src)
                except Exception:
                    _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        res = st.progress.get(key) or {}
        if res.get("state") == "done":
            r = res.get("result") or {}
            _log("enrich_done sid=%s %s" % (sid, r))
            if notify:
                msg = "%s 앨범 자켓 %d개를 찾았습니다" % (name, int(r.get("hits") or 0))
                if r.get("stopped"):
                    msg += "\n연결이 불안정해 중간에 멈췄습니다. 다음 스캔에서 이어서 찾습니다"
                _toast(msg, ms=6000)
        else:
            _log("enrich_failed sid=%s %s" % (sid, res.get("error", "")), xbmc.LOGWARNING)
        try:
            mirror_source(src)
        except Exception:
            _log("mirror_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        bump()
    threading.Thread(target=_watch, name="PKMMusicVideoEnrichWatch", daemon=True).start()
    return True


def _toast(msg, ms=3500):
    try:
        from resources.lib import pkm_notify
        pkm_notify.pkm_show_notice("뮤직비디오", msg, "", ms=ms)
        return
    except Exception:
        pass
    try:
        xbmcgui.Dialog().notification("PlexKM", msg, xbmcgui.NOTIFICATION_INFO, ms)
    except Exception:
        pass


# ------------------------------------------------------------------ 목록
def view_url(sid, view="", artist=""):
    q = {"action": "musicvideo", "source": sid}
    if view:
        q["view"] = view
    if artist != "":
        q["artist"] = artist
    return PLUGIN + "?" + urlencode(q)


def _thumb(full):
    return "image://video@%s/" % quote(full, safe="")


def _full(root, rel):
    return root + rel


def _merged(it):
    """온라인으로 찾은 정보(meta)로 비어 있는 연도·앨범·장르를 채운 사본."""
    m = it.get("meta") or {}
    if not m:
        return it
    out = dict(it)
    for k in ("year", "album", "genre"):
        if not out.get(k) and m.get(k):
            out[k] = m[k]
    return out


def _art(root, it):
    imgs = it.get("images") or {}
    meta = it.get("meta") or {}
    frame = _thumb(_full(root, it["path"]))
    art = {}
    if imgs.get("thumb"):
        art["thumb"] = _full(root, imgs["thumb"])
    if imgs.get("poster"):
        art["poster"] = _full(root, imgs["poster"])
    if imgs.get("fanart"):
        art["fanart"] = _full(root, imgs["fanart"])
    if it.get("poster") and "poster" not in art:
        art["poster"] = it["poster"]
    if it.get("fanart"):
        art.setdefault("fanart", it["fanart"])
    if meta.get("cover"):                       # 앨범 자켓: 포스터 자리, 프레임은 가로 그림으로
        art.setdefault("poster", meta["cover"])
        art.setdefault("thumb", meta["cover"])
        art["landscape"] = frame
    if "thumb" not in art:
        art["thumb"] = art.get("poster") or frame
    art["icon"] = art["thumb"]
    return art


_CATS = (("mv", "뮤직비디오", ("mv",)), ("broadcast", "음악방송", ("broadcast",)),
         ("concert", "콘서트·공연", ("concert", "disc", "other")))


def _end(handle, items, content="musicvideos"):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def list_view(handle, sid, view="", artist=""):
    src = next((s for s in sources() if s.get("id") == sid), None)
    if src is None or not available():
        _end(handle, [])
        return
    root = _root(src)
    idx = _store().load(sid)
    items = idx.get("items", [])
    if not view:
        cats = [(v, t, [i for i in items if i["kind"] in kinds]) for v, t, kinds in _CATS]
        cats = [c for c in cats if c[2]]
        if len(cats) == 1:
            view = cats[0][0]
        else:
            rows = []
            for v, t, its in cats:
                li = xbmcgui.ListItem(label=t)
                li.setLabel2("%d" % len(its))
                li.setArt({"icon": "DefaultFolder.png"})
                rows.append((view_url(sid, v), li, True))
            _end(handle, rows, "files")
            return
    if view == "mv":
        mv = [i for i in items if i["kind"] == "mv"]
        if artist == "":
            _list_artists(handle, sid, root, mv)
        else:
            _list_artist_videos(handle, root, mv, artist)
    elif view == "broadcast":
        _list_broadcast(handle, root, [i for i in items if i["kind"] == "broadcast"])
    else:
        _list_concerts(handle, root, [i for i in items if i["kind"] in ("concert", "disc", "other")])


def _group_artists(mv):
    """같은 아티스트의 표기 차이(한글/영문 병기 순서, 영문만 등)를 하나로 묶는다. -> [{'name','items'}]"""
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    keys = []
    for it in mv:
        vs = _agent.parser.name_variants(it.get("artist", "")) or ["_"]
        for v in vs[1:]:
            parent[find(v)] = find(vs[0])
        keys.append(vs[0])
    groups = {}
    for it, k in zip(mv, keys):
        groups.setdefault(find(k), []).append(it)
    out = []
    for k, its in groups.items():
        names = {}
        for it in its:
            names[it.get("artist") or ""] = names.get(it.get("artist") or "", 0) + 1
        name = max(names.items(), key=lambda kv: (kv[1], -len(kv[0])))[0]
        out.append({"name": name, "items": its})
    out.sort(key=lambda g: (g["name"] == "", (g["name"] or "~").lower()))
    return out


def _list_artists(handle, sid, root, mv):
    rows = []
    for g in _group_artists(mv):
        li = xbmcgui.ListItem(label=g["name"] or "아티스트를 알 수 없음")
        li.setLabel2("%d" % len(g["items"]))
        li.setArt(_art(root, next((x for x in g["items"] if (x.get("meta") or {}).get("cover")), g["items"][0])))
        rows.append((view_url(sid, "mv", g["name"] or "-"), li, True))
    _end(handle, rows, "artists")


def _list_artist_videos(handle, root, mv, artist):
    name = "" if artist == "-" else artist
    sel = next((g["items"] for g in _group_artists(mv) if g["name"] == name), [])
    sel = sorted(sel, key=lambda i: (-(i.get("year") or 0), (i.get("title") or "").lower()))
    rows = []
    for it in sel:
        label = it.get("title") or os.path.basename(it["path"])
        tags = [t for t in (it.get("tags") or []) if t != "hq"]
        if tags:
            label += " (" + ", ".join(tags) + ")"
        li = xbmcgui.ListItem(label=label)
        li.setArt(_art(root, it))
        _tag(li, _merged(it), "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_broadcast(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("date") or "", i.get("path") or ""), reverse=True)
    rows = []
    for it in items:
        who = it.get("artist") or ""
        what = it.get("title") or os.path.basename(it["path"])
        li = xbmcgui.ListItem(label=("%s - %s" % (who, what)) if who else what)
        li.setLabel2(" ".join(x for x in (it.get("date"), it.get("show")) if x))
        li.setArt(_art(root, it))
        _tag(li, _merged(it), "musicvideo")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows)


def _list_concerts(handle, root, items):
    items = sorted(items, key=lambda i: (i.get("title") or "").lower())
    rows = []
    for it in items:
        li = xbmcgui.ListItem(label=it.get("title") or os.path.basename(it["path"]))
        if it.get("year"):
            li.setLabel2(str(it["year"]))
        li.setArt(_art(root, it))
        _tag(li, it, "video")
        li.setProperty("IsPlayable", "true")
        rows.append((_full(root, it["path"]), li, False))
    _end(handle, rows, "videos")


def _tag(li, it, mediatype):
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        tag.setTitle(it.get("title") or "")
        if it.get("artist") and mediatype == "musicvideo":
            try:
                tag.setArtists([it["artist"]])
            except Exception:
                pass
        if it.get("year"):
            tag.setYear(int(it["year"]))
        if it.get("album"):
            try:
                tag.setAlbum(it["album"])
            except Exception:
                pass
        if it.get("plot"):
            tag.setPlot(it["plot"])
        if it.get("genre"):
            tag.setGenres(list(it["genre"]) if isinstance(it["genre"], (list, tuple)) else [it["genre"]])
        if it.get("duration"):
            tag.setDuration(int(it["duration"]))
    except Exception:
        _log("tag_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


# ------------------------------------------------------------------ 영화 틀로 보여주기(홈 위젯·섹션 화면)
def section_id(src):
    """색인을 영화 DB 에 비춰 넣을 때 쓰는 섹션 id (k: 로 시작해야 Kodi 쪽 재생·사이드메뉴 경로를 탄다)."""
    import hashlib
    return "k:mv:" + hashlib.md5(str(src.get("id")).encode("utf-8")).hexdigest()[:8]


def mirrored_sections():
    """영화 DB 에 비춰진 뮤직비디오 섹션들(보이는 것만, 항목이 있는 것만)."""
    out = []
    if not available():
        return out
    import sqlite3
    from resources.lib import pkm_kodi_source as ks
    try:
        conn = sqlite3.connect(ks.db_path(), timeout=5.0)
        try:
            counts = dict(conn.execute("SELECT section_id, COUNT(*) FROM items WHERE section_id LIKE 'k:mv:%' GROUP BY section_id").fetchall())
        finally:
            conn.close()
    except Exception:
        counts = {}
    for src in visible_sources():
        sid = section_id(src)
        if counts.get(sid):
            out.append({"section_id": sid, "title": display_name(src), "section_type": "movie", "thumb": "", "art": "",
                        "scanned_at": int(time.time()), "item_count": int(counts[sid]), "source": "kodi", "mv_source": src.get("id")})
    return out


def _small(url, px=500):
    """Deezer 이미지는 포스터 칸(약 200px)에 1000px 원본을 받으면 느리다. 500px 로 받는다."""
    if "dzcdn.net/images/" in (url or ""):
        import re as _re
        return _re.sub(r"/1000x1000-", "/%dx%d-" % (px, px), url)
    return url


_FONT_MAP = {"\u02da": "\u00b0", "\u2219": "\u00b7", "\u2027": "\u00b7", "\u2024": ".", "\u3000": " "}


def _font_safe(t):
    """스킨 글꼴에 없는 글자(빈 네모로 보이는 것)를 비슷한 글자로 바꾼다. '11˚' -> '11°'"""
    return "".join(_FONT_MAP.get(c, c) for c in (t or ""))


def _short_title(t):
    """목록 칸에서 잘리지 않게: 곡명 뒤의 (번역 제목)·(feat. …)·(Korean Ver.) 같은 괄호 덩어리를 뺀 짧은 이름.
    전체 이름은 original_title에 남긴다."""
    import re as _re
    s = t
    for _ in range(3):
        n = _re.sub(r"\s*[\(\[][^\(\)\[\]]*[\)\]]\s*$", "", s).strip(" -–_")
        if n == s or len(n) < 2:
            break
        s = n
    return s or t


def mirror_source(src):
    """색인의 영상들을 영화 DB(items)에 넣는다. 영화 섹션 화면·인포·검색이 그대로 읽는다."""
    if not available():
        return 0
    import hashlib, json, sqlite3
    from resources.lib import pkm_kodi_source as ks
    sid = src["id"]
    root = _root(src)
    sec = section_id(src)
    idx = _store().load(sid)
    now = int(time.time())
    _log("mirror_loaded items=%d" % len(idx.get("items", [])))
    rows = []
    for raw in idx.get("items", []):
        it = _merged(raw)
        art = _art(root, it)
        full = _full(root, it["path"])
        rk = "k:mv:" + hashlib.md5((sid + "|" + it["path"]).encode("utf-8")).hexdigest()[:12]
        artist = it.get("artist") or ""
        import unicodedata
        full_title = _font_safe(unicodedata.normalize("NFC", it.get("title") or os.path.splitext(os.path.basename(it["path"]))[0]))
        title = _short_title(full_title)
        kind_ko = {"mv": "뮤직비디오", "broadcast": "음악방송", "concert": "콘서트", "disc": "공연 DVD"}.get(it.get("kind"), "영상")
        ia = _item_art(it)
        summary = " · ".join(x for x in (kind_ko, artist, it.get("album") or ia.get("album") or "") if x)
        cover = ia.get("poster") or ""
        thumb = _small(art.get("poster") or cover or art.get("thumb") or "")
        fan = it.get("fanart") or ia.get("fanart") or art.get("fanart") or ia.get("artist_thumb") or cover or art.get("landscape") or art.get("thumb") or ""
        sc = {"y": ia.get("year"), "d": ia.get("duration"), "g": ia.get("genre")}
        row = {"rating_key": rk, "section_id": sec, "plex_type": "movie", "kodi_type": "musicvideo", "title": title,
               "original_title": full_title if full_title != title else "", "sort_title": title, "year": int(it.get("year") or sc.get("y") or 0), "summary": summary,
               "duration": int(sc.get("d") or 0) * 1000, "added_at": int(it.get("mtime") or idx.get("scanned_at") or now), "updated_at": now,
               "thumb": thumb, "art": fan,
               "media_file": full, "part_key": full, "view_count": 0, "last_viewed_at": 0,
               "parent_rating_key": "", "grandparent_rating_key": "", "show_title": "", "season": 0, "episode": 0,
               "raw_json": json.dumps({"ratingKey": rk, "type": "movie", "source": "kodi", "title": title, "file": full,
                                       "part_key": full, "year": str(it.get("year") or ""), "artist": artist}, ensure_ascii=False)}
        genres = [g.strip() for g in str(it.get("genre") or sc.get("g") or "").split(",") if g.strip()]
        ex = {"genres": genres, "countries": [],
              "people": ([("actor", artist, kind_ko, _small(ia.get("artist_thumb") or ""))] if artist else []), "rating": 0.0, "uniqueid": {}}
        row["checksum"] = hashlib.md5(json.dumps([dict(row, updated_at=0), ex], sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
        rows.append((row, ex))
    _log("mirror_rows_built rows=%d" % len(rows))
    conn = sqlite3.connect(ks.db_path(), timeout=15.0)
    try:
        ks._ensure_schema(conn)
        keep = set(r["rating_key"] for r, _ in rows)
        prev = dict(conn.execute("SELECT rating_key, checksum FROM items WHERE section_id=?", (sec,)).fetchall())
        old = list(prev.keys())
        changed = 0
        for r, ex in rows:
            if prev.get(r["rating_key"]) == r["checksum"]:
                continue                       # 그대로인 행은 다시 쓰지 않는다(정렬 색인·화면 캐시를 흔들지 않게)
            ks._write_row(conn, dict(r, synced_at=now), ex, now)
            changed += 1
        gone = [x for x in old if x not in keep]
        for i in range(0, len(gone), 400):
            b = gone[i:i + 400]
            q = ",".join("?" * len(b))
            for tbl in ("items", "item_genres", "item_people", "item_countries", "item_ratings", "item_ids_r108"):
                conn.execute("DELETE FROM %s WHERE rating_key IN (%s)" % (tbl, q), b)
        conn.commit()
    finally:
        conn.close()
    _log("mirror_done sid=%s rows=%d changed=%d gone=%d" % (sid, len(rows), changed, len(gone)))
    if changed or gone:
        _mark_dirty(sec)
    return len(rows)


def _mark_dirty(sec):
    """화면(홈 창)이 이 섹션의 저장된 라이브러리 격자·추천 화면을 버리고 새로 만들게 알린다(창의 R108 감시 스레드가 읽는다)."""
    try:
        win = xbmcgui.Window(10000)
        cur = [x for x in (win.getProperty("PlexKM.MV.DirtySectionsR341") or "").split(",") if x]
        if sec not in cur:
            cur.append(sec)
        win.setProperty("PlexKM.MV.DirtySectionsR341", ",".join(cur))
    except Exception:
        pass


_MIRROR_ALL_DONE = False


def mirror_all_async():
    """시작할 때 색인은 있는데 영화 DB 에 없는 소스를 한 번 비춘다(백그라운드)."""
    def _run():
        try:
            _log("mirror_all_start sources=%d" % len(visible_sources()))
            have = set(x["section_id"] for x in mirrored_sections())
            _log("mirror_all_have %s" % ",".join(sorted(have)))
            for src in visible_sources():
                idx = _store().load(src["id"])
                if not idx.get("items"):
                    continue
                mirror_source(src)     # 시작할 때마다 색인의 최신 자켓·정보를 영화 DB 에 맞춘다(바뀐 행만 쓴다)
                bump()
                _scrape_and_show(src, notify=False)
        except Exception:
            _log("mirror_all_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
    global _MIRROR_ALL_DONE
    if available() and not _MIRROR_ALL_DONE:
        _MIRROR_ALL_DONE = True
        try:   # 스레드 안에서 처음 import 하면 import 잠금에 걸릴 수 있어 먼저 불러 둔다
            import sqlite3  # noqa: F401
            from resources.lib import pkm_kodi_source  # noqa: F401
        except Exception:
            pass
        threading.Thread(target=_run, name="PKMMusicVideoMirrorAll", daemon=True).start()


# ------------------------------------------------------------------ 가수 사진·팬아트 (TheAudioDB)


# ------------------------------------------------------------------ 앨범아트·가수 사진 수집(모듈 pkm_musicagent.art 가 조회하고, 여기서는 순서와 화면 반영만)
_ART_RUNNING = [False]
_IT_RUNNING = [False]
_art_ready = [False]


def _artmod():
    """모듈의 수집 기능. 캐시 폴더와 로그·종료 확인을 처음 한 번 넘겨 준다."""
    mod = getattr(_agent, "art", None) if _agent else None
    if mod is None:
        return None
    if not _art_ready[0]:
        mon = xbmc.Monitor()
        mod.configure(
            xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/"),
            log=lambda m, warn=False: _log(m, xbmc.LOGWARNING if warn else xbmc.LOGINFO),
            aborted=mon.abortRequested, wait=mon.waitForAbort)
        _art_ready[0] = True
    return mod


def _norm_name(x):
    import re as _re
    return _re.sub(r"[^0-9a-z가-힣]+", "", str(x or "").lower())


def artist_art_cache():
    m = _artmod()
    return m.artist_art_cache() if m else {}


def song_cover_cache():
    m = _artmod()
    return m.song_cover_cache() if m else {}


def _pkey(path):
    m = _artmod()
    return m._pkey(path) if m else ""


def _best_cover(ent, title):
    m = _artmod()
    return m._best_cover(ent, title) if m else ""


def _item_art(it):
    """모듈이 정한 포스터·배경·가수 사진·곡 정보. 모듈이 예전 버전이면 캐시에서 같은 규칙으로 만든다."""
    m = _artmod()
    if m and hasattr(m, "item_art"):
        try:
            return m.item_art(it)
        except Exception:
            pass
    aa = artist_art_cache().get(_norm_name(it.get("artist") or "")) or {}
    sc = song_cover_cache().get(_pkey(it["path"])) or {}
    cover = (it.get("meta") or {}).get("cover") or sc.get("c") or ""
    if not cover:
        try:
            cover = _best_cover(aa, it.get("title") or "")
        except Exception:
            cover = ""
    return {"poster": cover or aa.get("thumb") or "", "fanart": aa.get("fanart") or aa.get("fanart2") or "",
            "artist_thumb": aa.get("thumb") or "", "album": sc.get("a") or "", "year": sc.get("y") or "",
            "genre": sc.get("g") or "", "duration": int(sc.get("d") or 0)}


def scrape(src, on_stage=None):
    """모듈의 전체 수집(곡 → 가수 → 못 찾은 곡 재시도). on_stage(name) 가 단계마다 불려 화면을 갱신한다.
    모듈이 예전 버전이면 예전 순서(가수 → 곡)로 한다."""
    m = _artmod()
    if not m:
        return None
    idx = _store().load(src["id"])
    if hasattr(m, "scrape"):
        return m.scrape(idx, on_stage=on_stage)
    m.enrich_fast(idx)
    if on_stage:
        on_stage("artists")
    m.enrich_songs(idx)
    if on_stage:
        on_stage("songs")
    return None


def enrich_fast(src, progress=None):
    m = _artmod()
    return m.enrich_fast(_store().load(src["id"]), progress) if m else None


def enrich_songs(src, progress=None):
    m = _artmod()
    return m.enrich_songs(_store().load(src["id"]), progress) if m else None


def _after(src, n):
    try:
        mirror_source(src)
        bump()
    except Exception:
        pass


def enrich_artists(src, notify=False):
    """가수 가로 배경·로고(MusicBrainz → fanart.tv, 느림)를 백그라운드로 받는다. 이어받기."""
    m = _artmod()
    if not m or _ART_RUNNING[0]:
        return False
    _ART_RUNNING[0] = True

    def _run():
        try:
            m.enrich_artists(_store().load(src["id"]), tick=lambda n: _after(src, n))
            _after(src, 0)
        except Exception:
            _log("artist_art_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            _ART_RUNNING[0] = False
    threading.Thread(target=_run, name="PKMMusicVideoArtistArt", daemon=True).start()
    return True


def enrich_itunes(src):
    """Deezer 에서 확인하지 못한 가수를 iTunes(미국 스토어)로 보충한다(백그라운드, 느림). 끝나면 곡 단계를 한 번 더 돈다."""
    m = _artmod()
    if not m or _IT_RUNNING[0]:
        return False
    _IT_RUNNING[0] = True

    def _run():
        try:
            m.enrich_itunes(_store().load(src["id"]), tick=lambda n: _after(src, n))
            try:
                m.enrich_songs(_store().load(src["id"]))
            except Exception:
                pass
            _after(src, 0)
        except Exception:
            _log("itunes_failed %s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        finally:
            _IT_RUNNING[0] = False
    threading.Thread(target=_run, name="PKMMusicVideoITunes", daemon=True).start()
    return True
