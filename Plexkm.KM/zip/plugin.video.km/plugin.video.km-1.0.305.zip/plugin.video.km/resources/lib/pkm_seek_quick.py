# -*- coding: utf-8 -*-
"""PKM playback seek coalescer.

v1395: Keep real VideoOSD open during seek, suppress Kodi native OSD, and latch the seek bar/marker
on the PKM target while high-bitrate/DXVA playback catches up. No runtime image drawing.
"""
from __future__ import absolute_import, unicode_literals

import time
import threading
import traceback
import json
import urllib.parse
import urllib.request
import queue

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
try:
    ADDON = xbmcaddon.Addon(id=ADDON_ID)
except Exception:
    ADDON = None

PROP = "PlexKM.SeekQuick."
OSD_PROP = "PlexKM.PlayerOSD."
OSD_NAV_TTL_MS = 3500
OSD_NAV_EXTEND_VISIBLE_MS = 7000
OSD_SEEKBAR_FOCUS_DELAY_MS = 55
OSD_AUTO_CLOSE_MS_V1943 = 3000
OSD_AUTO_CLOSE_FORCE_MS_V1943 = 1000
SEEK_TARGET_HOLD_MS = 6500  # v1395: keep target UI latched while 4K/DXVA catches up
# v1405: dynamic seek step from measured bitrate.  All PKM quick seek keys/buttons
# are debounced, then committed as one absolute seek target.  No pause/play.
DYNAMIC_SEEK_DEBOUNCE_MS = 700
# v2225: the focused VideoOSD progress bar is a scrub preview, not a repeated
# demuxer seek command.  Repeated LEFT/RIGHT only moves the visual target;
# after input has been idle for this interval, commit exactly one native Kodi
# relative Seek() to the final target.  Main +/- seek buttons remain immediate.
# v2230: a held remote/keyboard key can take ~0.7-0.9s before the next
# RunScript instance reaches Python (especially on Android). 700ms therefore
# committed between physical repeats and caused several real seeks. Give a
# continuous scrub enough idle budget to coalesce into one final commit.
SEEKBAR_SCRUB_COMMIT_IDLE_MS_V2225 = 1200
# v2231: seekbar-only acceleration. Discrete taps/restarts begin with a precise
# 10-second preview step; a continuous held/repeated LEFT/RIGHT chain switches
# to 30-second preview steps from the fifth input onward. Only the final visual
# target is committed, so the larger preview step never creates extra decoder
# seeks.
SEEKBAR_SCRUB_SMALL_STEP_SEC_V2231 = 10
SEEKBAR_SCRUB_BIG_STEP_SEC_V2231 = 30
SEEKBAR_SCRUB_BIG_FROM_INPUT_V2231 = 5
# v2226: a real seek is a foreground transaction. Kodi can accept a Seek()
# command while the demuxer is still waiting on the new range. Keep a PKM
# spinner alive until the player clock has actually landed and advances again.
SEEK_WAIT_SPINNER_DELAY_MS_V2226 = 350
SEEK_WAIT_TARGET_TOLERANCE_SEC_V2226 = 2.0
SEEK_WAIT_READY_ADVANCE_SEC_V2226 = 0.15
# v2230: seekbar final commits pause the Kodi clock while the random rclone
# range is being positioned. This prevents audio/video clocks from drifting
# several seconds during a long remote seek and then visibly "catching up" at
# high speed. Intro skip keeps the proven v2226 fast native path unchanged.
SEEK_MANAGED_SETTLE_MS_V2230 = 500
# v2232: the user-visible seek transaction is stricter than Kodi's raw
# Seek() completion. Keep playback paused after landing until Kodi's own cache
# has a useful amount of media AHEAD of the target. Then resume exactly once
# and keep the opaque spinner cover until the playback clock proves a stable
# ~1x cadence. Never pause again after that resume; an unstable catch-up stays
# hidden behind the spinner until it naturally settles.
SEEK_MANAGED_BUFFER_LEAD_SEC_V2232 = 8.0
SEEK_MANAGED_BUFFER_STABLE_MS_V2232 = 700
SEEK_MANAGED_BUFFER_UNKNOWN_STABLE_MS_V2232 = 2200
SEEK_MANAGED_POST_RESUME_VERIFY_MS_V2232 = 1500
SEEK_MANAGED_POST_RESUME_MIN_ADVANCE_SEC_V2232 = 0.80
SEEK_MANAGED_POST_RESUME_MIN_RATE_V2232 = 0.80
SEEK_MANAGED_POST_RESUME_MAX_RATE_V2232 = 1.20
SEEK_MANAGED_POST_RESUME_MIN_LEAD_SEC_V2232 = 2.5
# v2234: do not keep the spinner for a fixed 1.5 s after video has already
# settled. Once the resumed player clock demonstrates a continuous near-1x
# cadence for a short window, reveal immediately. Fast catch-up (>1.35x),
# stalls, seeking/caching, or low cache lead keep the spinner up.
SEEK_MANAGED_POST_RESUME_FAST_STABLE_MS_V2234 = 500
SEEK_MANAGED_POST_RESUME_FAST_MIN_ADVANCE_SEC_V2234 = 0.28
SEEK_MANAGED_POST_RESUME_FAST_MIN_RATE_V2234 = 0.70
SEEK_MANAGED_POST_RESUME_FAST_MAX_RATE_V2234 = 1.30
DYNAMIC_SEEK_MAX_TOTAL_SEC = 60
DYNAMIC_SEEK_HTTP_TIMEOUT_SEC = 1.2
DYNAMIC_SEEK_CACHE_TTL_MS = 4 * 60 * 60 * 1000
LONG_JUMP_STEP_SEC = 30
# v1429: production seek is Kodi native stepback/stepforward; this module no longer owns LEFT/RIGHT seek commits.
# Server-side tests showed cold random reads can be much slower than 3 seconds,
# keep helpers below unused for future measurement-only experiments.  Native seek buttons do not call player.seekTime().
LONG_JUMP_PREWARM_ENABLED = False
LONG_JUMP_PREWARM_DELAY_MS = 0
LONG_JUMP_PREWARM_TIMEOUT_SEC = 1.35
LONG_JUMP_PREWARM_BACK_BYTES = 2 * 1024 * 1024
LONG_JUMP_PREWARM_AHEAD_BYTES = 6 * 1024 * 1024
LONG_JUMP_PREWARM_READ_BYTES = 768 * 1024
# v1459: cachebar smooth/real-byte audit. Pause marker is tiny and marker-only; real HTTP Range bytes are tracked separately so the marker never blocks real cache growth. First 1KB is published immediately for visible activity.
# v1460: seek side menu is PKM logic + skin UI.  Long-press only arms a side selector; selected 10/20/30 still uses Kodi native Seek(seconds).
# v1463: step side menu excludes the currently selected seek step and selecting 10/20/30 becomes the new main seek step. Pre-read startup avoids duplicate bitrate HEAD probes and visible cache ticks grow sooner.
# v1464: pause-start cache display reset.  OnPlayBackPaused must start from the tiny marker and then grow from real bytes; old onAVStarted/pre-seek cache display must not pin the bar at a stale nib.
# v1465: seek side menu is collapsed to two choices beside the main button and 20s icon assets are regenerated as exact-size HQ PNGs.
# v1467: cachebar must show PKM/rclone Range cache only. Remove artificial 12% visual boost and keep cache nib monotonic across pause/seek sequences for the same media.
# v1456: do not allow +/-30s from Kodi label bitrate alone. Kodi labels can exist before PKM has verified Plex HTTP Range/cache readiness.
#        Dynamic main seek is capped to +/-10s unless bitrate comes from a resolved Plex HTTP HEAD/cache source.
#        This prevents low-bitrate labels from exposing 30s on cold plugin:// native playback where seek can stall.
# v1455: native PlayMedia returns plugin:// from Kodi Player.Filename; cache/pre-read must resolve that plugin URL to the real Plex HTTP Range URL internally. Playback itself remains Kodi-native PlayMedia + setResolvedUrl. Do not change Info/main playback to xbmc.Player().play() or direct http.
# v1454: playback handoff audited/locked to Kodi-native PlayMedia(plugin://...) + setResolvedUrl. Do not reintroduce xbmc.Player().play() or direct http file playback for Info/main movie playback. Seek/cache behavior remains v1452.
# v1452: preserve the pale-yellow cache end across +/-30s seeks when the new playback position still overlaps the already-read contiguous range. Cache button remains removed. Playback keeps a stable single linear to-EOF warmer; Pause primes a visible pale-yellow lead marker before any real Range byte arrives. Pause tests a 3-worker contiguous profile. Dynamic seek remains <=10Mbps +/-30s and >10Mbps +/-10s. OSD icons keep the seconds suffix and play-row alignment.
# v1438: Enter/OSD navigation helper restored; production seek still uses Kodi built-in Seek(seconds) directly.
# Keep bitrate-based PKM step table (+10/+5/+3) while delegating the actual seek
# to Kodi's native seek action to avoid PKM absolute target/decoder catch-up stalls.
NATIVE_KODI_SEEK_ENABLED = True
# v1436/v1438/v1438: manual pre-read uses an interactive pause dialog hybrid profile: read the front 1/3 first,
# mark it ready for immediate early-file seek tests, then continue reading the tail
# sequentially to warm the Oracle/Plex/rclone VFS cache.  This does not seek,
# pause, stop, or replay.  It downloads to the Kodi client and discards data;
# the important side effect is server-side rclone VFS cache warming.
MANUAL_PREREAD_ENABLED = True
MANUAL_PREREAD_TIMEOUT_SEC = 6 * 60 * 60.0
MANUAL_PREREAD_SOCKET_TIMEOUT_SEC = 60.0
MANUAL_PREREAD_CHUNK_BYTES = 64 * 1024
MANUAL_PREREAD_FIRST_READ_BYTES = 1024
MANUAL_PREREAD_EARLY_SMOOTH_BYTES = 512 * 1024
# v1467: no fake visual amplification. The visible cachebar follows actual byte-derived nibs only.
# Keep the constants for compatibility/log readability, but do not use them to enlarge the bar.
MANUAL_PREREAD_MIN_BYTES = 64 * 1024 * 1024
MANUAL_PREREAD_LOW_BYTES = 96 * 1024 * 1024
MANUAL_PREREAD_MID_BYTES = 128 * 1024 * 1024
MANUAL_PREREAD_HIGH_BYTES = 192 * 1024 * 1024
# v1470: playback uses one long linear stream. Pause tests 3 contiguous block workers.
# The OSD bar still publishes only contiguous bytes, never out-of-order wire bytes.
MANUAL_PREREAD_TO_EOF_DEFAULT = True
MANUAL_PREREAD_PARALLEL_BLOCK_BYTES = 4 * 1024 * 1024
MANUAL_PREREAD_PARALLEL_WORKERS_PAUSED = 3
MANUAL_PREREAD_PARALLEL_WORKERS_PLAYING = 1
MANUAL_PREREAD_START_AHEAD_SEC = 0.0
MANUAL_PREREAD_SLEEP_MS = 0
# v1411: never probe Plex/HTTP repeatedly while VideoOSD is visible.
# OSD refresh must be display-only; probing is allowed only on actual seek request.


def _win():
    return xbmcgui.Window(10000)


def _now_ms():
    try:
        return int(time.time() * 1000)
    except Exception:
        return 0


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][seek_quick] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _get_prop(name, default=""):
    try:
        return _win().getProperty(PROP + name) or default
    except Exception:
        return default


def _set_prop(name, value):
    try:
        _win().setProperty(PROP + name, str(value))
        return True
    except Exception:
        return False


def _clear_prop(name):
    try:
        _win().clearProperty(PROP + name)
    except Exception:
        pass


def _get_osd_prop(name, default=""):
    try:
        return _win().getProperty(OSD_PROP + name) or default
    except Exception:
        return default


def _set_osd_prop(name, value):
    try:
        _win().setProperty(OSD_PROP + name, str(value))
        return True
    except Exception:
        return False


def _clear_osd_prop(name):
    try:
        _win().clearProperty(OSD_PROP + name)
    except Exception:
        pass


def _get_osd_int(name, default=0):
    try:
        raw = _get_osd_prop(name, "")
        if raw == "":
            return int(default)
        return int(float(raw))
    except Exception:
        return int(default)


def _get_int(name, default=0):
    try:
        raw = _get_prop(name, "")
        if raw == "":
            return int(default)
        return int(float(raw))
    except Exception:
        return int(default)


def _get_float(name, default=0.0):
    try:
        raw = _get_prop(name, "")
        if raw == "":
            return float(default)
        return float(raw)
    except Exception:
        return float(default)


def _player_cache_progress_pct_v2232():
    """Return Kodi's cached-progress percentage without touching Plex.

    Player.ProgressCache / JSON-RPC cachepercentage describes how far the
    player cache extends through the media, not simple cache fullness. v2232
    converts this to seconds AHEAD of Player.Time before deciding to resume.
    """
    try:
        raw = str(xbmc.getInfoLabel("Player.ProgressCache") or "").strip().replace("%", "")
        if raw:
            value = float(raw)
            if 0.0 <= value <= 100.0:
                return value
    except Exception:
        pass
    try:
        active = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 2232, "method": "Player.GetActivePlayers"
        })) or "{}").get("result") or []
        player_id = -1
        for item in active:
            if item.get("type") == "video":
                player_id = int(item.get("playerid"))
                break
        if player_id >= 0:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 2232, "method": "Player.GetProperties",
                "params": {"playerid": player_id, "properties": ["cachepercentage"]},
            })) or "{}").get("result") or {}
            value = float(result.get("cachepercentage"))
            if 0.0 <= value <= 100.0:
                return value
    except Exception:
        pass
    return None


def _player_cache_lead_sec_v2232(current, duration):
    try:
        current = max(0.0, float(current or 0.0))
        duration = max(0.0, float(duration or 0.0))
    except Exception:
        return None, None
    if duration <= 0.5:
        return None, None
    cache_pct = _player_cache_progress_pct_v2232()
    if cache_pct is None:
        return None, None
    current_pct = max(0.0, min(100.0, current * 100.0 / duration))
    # A tiny negative delta is possible from label rounding. A materially
    # negative value means the label semantics are not usable for this frame.
    lead_pct = float(cache_pct) - current_pct
    if lead_pct < -1.0:
        return None, cache_pct
    lead_sec = max(0.0, lead_pct * duration / 100.0)
    return lead_sec, cache_pct


def _managed_required_cache_lead_v2232(current, duration):
    try:
        remaining = max(0.0, float(duration or 0.0) - float(current or 0.0))
    except Exception:
        remaining = 0.0
    if remaining <= 0.0:
        return 0.0
    # Near EOF there simply cannot be 8 seconds ahead. Require most of the
    # remaining tail instead of deadlocking the spinner.
    if remaining < SEEK_MANAGED_BUFFER_LEAD_SEC_V2232 + 1.0:
        return max(0.5, min(SEEK_MANAGED_BUFFER_LEAD_SEC_V2232, remaining * 0.70))
    return SEEK_MANAGED_BUFFER_LEAD_SEC_V2232


def _begin_managed_seek_pause_v2230(source=""):
    """Freeze Kodi's playback clock before a seekbar random seek.

    This is UI/playback synchronization only: it does not create a second HTTP
    reader and it never changes the native PlayMedia -> setResolvedUrl path.
    """
    already_owned = _get_prop("SeekManagedPauseOwnedV2230") == "1"
    try:
        paused = _bool_cond("Player.Paused")
    except Exception:
        paused = False
    _set_prop("SeekManagedPauseV2230", "1")
    _set_prop("SeekManagedResumeIssuedV2230", "0")
    _set_prop("SeekManagedResumeAtMsV2230", "0")
    _set_prop("SeekManagedResumePosSecV2230", "0")
    _set_prop("SeekManagedBufferReadySinceMsV2232", "0")
    _set_prop("SeekManagedUnknownReadySinceMsV2232", "0")
    _set_prop("SeekManagedLastCacheLeadSecV2232", "-1")
    _set_prop("SeekManagedLastCachePctV2232", "-1")
    _set_prop("SeekManagedStableSinceMsV2234", "0")
    _set_prop("SeekManagedStableBasePosSecV2234", "0")
    if already_owned and paused:
        _log("PKM_SEEK_MANAGED_PAUSE_KEEP_V2230 source=%s owned=1 paused=1" % (source or ""), xbmc.LOGINFO)
        return True
    if paused:
        # User was already paused. Never auto-resume a user pause.
        _set_prop("SeekManagedPauseOwnedV2230", "0")
        _log("PKM_SEEK_MANAGED_PAUSE_SKIP_V2230 source=%s reason=already_user_paused" % (source or ""), xbmc.LOGINFO)
        return False
    try:
        _set_prop("SeekManagedPauseOwnedV2230", "1")
        xbmc.executebuiltin("PlayerControl(Play)")
        _log("PKM_SEEK_MANAGED_PAUSE_APPLY_V2230 source=%s method=native_playercontrol" % (source or ""), xbmc.LOGINFO)
        return True
    except Exception:
        _set_prop("SeekManagedPauseOwnedV2230", "0")
        _log("PKM_SEEK_MANAGED_PAUSE_FAILED_V2230 source=%s" % (source or ""), xbmc.LOGWARNING)
        return False


def _clear_managed_seek_props_v2230():
    for name in (
        "SeekManagedPauseV2230", "SeekManagedPauseOwnedV2230",
        "SeekManagedResumeIssuedV2230", "SeekManagedResumeAtMsV2230",
        "SeekManagedResumePosSecV2230", "SeekManagedBufferReadySinceMsV2232",
        "SeekManagedUnknownReadySinceMsV2232", "SeekManagedLastCacheLeadSecV2232",
        "SeekManagedLastCachePctV2232", "SeekManagedStableSinceMsV2234",
        "SeekManagedStableBasePosSecV2234",
    ):
        _clear_prop(name)


def _managed_seek_resume_v2230(source=""):
    if _get_prop("SeekManagedPauseV2230") != "1":
        return False
    if _get_prop("SeekManagedPauseOwnedV2230") != "1":
        return False
    if _get_prop("SeekManagedResumeIssuedV2230") == "1":
        return True
    try:
        player = xbmc.Player()
        pos = float(player.getTime() or 0.0)
        if _bool_cond("Player.Paused"):
            xbmc.executebuiltin("PlayerControl(Play)")
        now = _now_ms()
        _set_prop("SeekManagedResumeIssuedV2230", "1")
        _set_prop("SeekManagedResumeAtMsV2230", now)
        _set_prop("SeekManagedResumePosSecV2230", "%.3f" % pos)
        _set_prop("SeekManagedStableSinceMsV2234", "0")
        _set_prop("SeekManagedStableBasePosSecV2234", "%.3f" % pos)
        _log("PKM_SEEK_MANAGED_RESUME_V2230 source=%s pos=%.3f" % (source or "", pos), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_SEEK_MANAGED_RESUME_FAILED_V2230 source=%s" % (source or ""), xbmc.LOGWARNING)
        return False


def _clear_seek_wait_v2226(reason=""):
    was_active = _get_prop("SeekWaitActive") == "1"
    spinner = _get_prop("SeekWaitSpinner") == "1"
    source = _get_prop("SeekWaitSource", "")
    target = _get_float("SeekWaitTargetSec", 0.0)
    preserve_managed_pause = (
        reason == "superseded_by_scrub_commit" and
        _get_prop("SeekManagedPauseV2230") == "1" and
        _get_prop("SeekManagedPauseOwnedV2230") == "1"
    )
    for name in (
        "SeekWaitActive", "SeekWaitSpinner", "SeekWaitSource", "SeekWaitTargetSec",
        "SeekWaitBeforeSec", "SeekWaitDurationSec", "SeekWaitStartedMs",
        "SeekWaitDirection", "SeekWaitArrived", "SeekWaitArrivedMs",
        "SeekWaitArrivedPosSec", "SeekWaitLastPosSec", "SeekWaitLastPosMs",
    ):
        _clear_prop(name)
    if not preserve_managed_pause:
        _clear_managed_seek_props_v2230()
    if was_active or spinner:
        _log(
            "PKM_SEEK_WAIT_CLEAR_V2226 reason=%s source=%s target=%.3f spinner=%s managed_preserved=%s" % (
                reason or "", source or "", target, "1" if spinner else "0",
                "1" if preserve_managed_pause else "0"
            ),
            xbmc.LOGINFO,
        )


def _arm_seek_wait_v2226(target, before, source="", duration=0.0, managed_pause_v2230=False):
    now = _now_ms()
    if managed_pause_v2230:
        _begin_managed_seek_pause_v2230(source=source)
    else:
        _clear_managed_seek_props_v2230()
    target = float(target or 0.0)
    before = float(before or 0.0)
    duration = float(duration or 0.0)
    direction = 1 if target >= before else -1
    _set_prop("SeekWaitActive", "1")
    _set_prop("SeekWaitSpinner", "0")
    _set_prop("SeekWaitSource", source or "unknown")
    _set_prop("SeekWaitTargetSec", "%.3f" % target)
    _set_prop("SeekWaitBeforeSec", "%.3f" % before)
    _set_prop("SeekWaitDurationSec", "%.3f" % duration)
    _set_prop("SeekWaitStartedMs", now)
    _set_prop("SeekWaitDirection", direction)
    _set_prop("SeekWaitArrived", "0")
    _set_prop("SeekWaitArrivedMs", "0")
    _set_prop("SeekWaitArrivedPosSec", "0")
    _set_prop("SeekWaitLastPosSec", "%.3f" % before)
    _set_prop("SeekWaitLastPosMs", now)
    _log(
        "PKM_SEEK_WAIT_ARM_V2226 source=%s before=%.3f target=%.3f delta=%.3f duration=%.3f spinner_delay_ms=%d" % (
            source or "unknown", before, target, target - before, duration, SEEK_WAIT_SPINNER_DELAY_MS_V2226
        ),
        xbmc.LOGINFO,
    )
    return True


def _seek_wait_tick_v2226(now=None):
    if _get_prop("SeekWaitActive") != "1":
        return False
    now = int(now if now is not None else _now_ms())
    source = _get_prop("SeekWaitSource", "")
    target = _get_float("SeekWaitTargetSec", 0.0)
    started = _get_int("SeekWaitStartedMs", now)
    direction = _get_int("SeekWaitDirection", 1)
    arrived = _get_prop("SeekWaitArrived") == "1"
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            _clear_seek_wait_v2226("not_playing_video")
            return False
        current = float(player.getTime() or 0.0)
    except Exception:
        return True

    age = max(0, now - started)
    last_pos = _get_float("SeekWaitLastPosSec", current)
    _set_prop("SeekWaitLastPosSec", "%.3f" % current)
    _set_prop("SeekWaitLastPosMs", now)

    try:
        paused = _bool_cond("Player.Paused")
        seeking = _bool_cond("Player.Seeking")
        caching = _bool_cond("Player.Caching")
    except Exception:
        paused = False
        seeking = False
        caching = False

    tolerance = SEEK_WAIT_TARGET_TOLERANCE_SEC_V2226
    if direction >= 0:
        reached = current >= (target - tolerance)
    else:
        reached = current <= (target + tolerance)
    if abs(current - target) <= tolerance:
        reached = True

    if reached and not arrived:
        arrived = True
        _set_prop("SeekWaitArrived", "1")
        _set_prop("SeekWaitArrivedMs", now)
        _set_prop("SeekWaitArrivedPosSec", "%.3f" % current)
        _log(
            "PKM_SEEK_WAIT_TARGET_ARRIVED_V2226 source=%s age_ms=%d current=%.3f target=%.3f seeking=%s caching=%s" % (
                source, age, current, target, "1" if seeking else "0", "1" if caching else "0"
            ),
            xbmc.LOGINFO,
        )

    if arrived:
        arrived_pos = _get_float("SeekWaitArrivedPosSec", current)
        arrived_ms = _get_int("SeekWaitArrivedMs", now)
        advanced = abs(current - arrived_pos) >= SEEK_WAIT_READY_ADVANCE_SEC_V2226
        managed_v2230 = _get_prop("SeekManagedPauseV2230") == "1"
        if managed_v2230:
            owned_v2230 = _get_prop("SeekManagedPauseOwnedV2230") == "1"
            resume_issued_v2230 = _get_prop("SeekManagedResumeIssuedV2230") == "1"
            arrived_age_v2230 = max(0, now - arrived_ms)
            scrub_pending_v2230 = (
                _get_prop("Pending") == "1" and
                _get_prop("SeekbarScrubV2225") == "1"
            )
            if scrub_pending_v2230:
                # The user started moving the bar again while this seek was
                # landing. Keep the managed pause and let the new preview own
                # the next target; never resume between chained scrubs.
                return True
            if not owned_v2230:
                # Respect a user-paused session: settle the seek, hide spinner,
                # and leave playback paused exactly as the user had it.
                if paused and not seeking and not caching and arrived_age_v2230 >= SEEK_MANAGED_SETTLE_MS_V2230:
                    spinner_was = _get_prop("SeekWaitSpinner") == "1"
                    _log(
                        "PKM_SEEK_MANAGED_READY_PAUSED_V2230 source=%s age_ms=%d current=%.3f target=%.3f spinner=%s" % (
                            source, age, current, target, "1" if spinner_was else "0"
                        ), xbmc.LOGINFO,
                    )
                    _clear_seek_wait_v2226("managed_user_paused_ready_v2230")
                    return False
            elif not resume_issued_v2230:
                # v2232: landing at the target is NOT enough. rclone may have
                # delivered only the first packets/keyframe while the following
                # range is still cold. Stay paused until Kodi's own cache has a
                # useful lead ahead of the target. This intentionally trades a
                # longer spinner for one clean resume.
                if paused and not seeking and arrived_age_v2230 >= SEEK_MANAGED_SETTLE_MS_V2230:
                    lead_sec_v2232, cache_pct_v2232 = _player_cache_lead_sec_v2232(current, _get_float("SeekWaitDurationSec", 0.0))
                    required_lead_v2232 = _managed_required_cache_lead_v2232(current, _get_float("SeekWaitDurationSec", 0.0))
                    if lead_sec_v2232 is not None:
                        _set_prop("SeekManagedLastCacheLeadSecV2232", "%.3f" % lead_sec_v2232)
                        _set_prop("SeekManagedLastCachePctV2232", "%.3f" % float(cache_pct_v2232 or 0.0))
                        _set_prop("SeekManagedUnknownReadySinceMsV2232", "0")
                        if (not caching) and lead_sec_v2232 >= required_lead_v2232:
                            ready_since_v2232 = _get_int("SeekManagedBufferReadySinceMsV2232", 0)
                            if ready_since_v2232 <= 0:
                                ready_since_v2232 = now
                                _set_prop("SeekManagedBufferReadySinceMsV2232", now)
                                _log(
                                    "PKM_SEEK_MANAGED_BUFFER_READY_ARM_V2232 source=%s current=%.3f target=%.3f cache_pct=%.2f lead_sec=%.2f required_sec=%.2f" % (
                                        source, current, target, float(cache_pct_v2232 or 0.0), lead_sec_v2232, required_lead_v2232
                                    ), xbmc.LOGINFO,
                                )
                            elif now - ready_since_v2232 >= SEEK_MANAGED_BUFFER_STABLE_MS_V2232:
                                _log(
                                    "PKM_SEEK_MANAGED_BUFFER_READY_V2232 source=%s stable_ms=%d current=%.3f target=%.3f cache_pct=%.2f lead_sec=%.2f required_sec=%.2f action=resume_once" % (
                                        source, now - ready_since_v2232, current, target, float(cache_pct_v2232 or 0.0), lead_sec_v2232, required_lead_v2232
                                    ), xbmc.LOGINFO,
                                )
                                _managed_seek_resume_v2230(source=source + "_buffer_ready_v2232")
                        else:
                            if _get_int("SeekManagedBufferReadySinceMsV2232", 0) > 0:
                                _log(
                                    "PKM_SEEK_MANAGED_BUFFER_READY_RESET_V2232 source=%s caching=%s lead_sec=%.2f required_sec=%.2f" % (
                                        source, "1" if caching else "0", lead_sec_v2232, required_lead_v2232
                                    ), xbmc.LOGINFO,
                                )
                            _set_prop("SeekManagedBufferReadySinceMsV2232", "0")
                    else:
                        # Some platforms do not expose cachepercentage. Do not
                        # probe Plex or create a second reader. Fall back to a
                        # longer, continuously non-caching paused settle.
                        _set_prop("SeekManagedBufferReadySinceMsV2232", "0")
                        if not caching:
                            unknown_since_v2232 = _get_int("SeekManagedUnknownReadySinceMsV2232", 0)
                            if unknown_since_v2232 <= 0:
                                _set_prop("SeekManagedUnknownReadySinceMsV2232", now)
                            elif now - unknown_since_v2232 >= SEEK_MANAGED_BUFFER_UNKNOWN_STABLE_MS_V2232:
                                _log(
                                    "PKM_SEEK_MANAGED_BUFFER_UNKNOWN_FALLBACK_V2232 source=%s stable_ms=%d action=resume_once" % (
                                        source, now - unknown_since_v2232
                                    ), xbmc.LOGINFO,
                                )
                                _managed_seek_resume_v2230(source=source + "_cache_unknown_v2232")
                        else:
                            _set_prop("SeekManagedUnknownReadySinceMsV2232", "0")
            else:
                # v2232: after the single resume, never pause again. Keep the
                # opaque spinner cover while Kodi performs any internal A/V
                # catch-up, and reveal only after a sustained near-1x clock.
                resume_ms = _get_int("SeekManagedResumeAtMsV2230", now)
                resume_pos = _get_float("SeekManagedResumePosSecV2230", current)
                resume_age_ms = max(0, now - resume_ms)
                run_advanced = max(0.0, current - resume_pos)
                run_elapsed = max(0.001, float(resume_age_ms) / 1000.0)
                run_rate = run_advanced / run_elapsed
                duration_v2232 = _get_float("SeekWaitDurationSec", 0.0)
                lead_sec_v2232, cache_pct_v2232 = _player_cache_lead_sec_v2232(current, duration_v2232)
                lead_ok_v2232 = (
                    lead_sec_v2232 is None or
                    lead_sec_v2232 >= min(
                        SEEK_MANAGED_POST_RESUME_MIN_LEAD_SEC_V2232,
                        _managed_required_cache_lead_v2232(current, duration_v2232)
                    )
                )
                # v2234: a fixed 1500 ms post-resume hold made the spinner
                # visibly linger even when playback was already normal. Track a
                # short continuous near-1x window instead. If Kodi is still
                # doing fast A/V catch-up, this window resets and the cover stays.
                stable_since_v2234 = _get_int("SeekManagedStableSinceMsV2234", 0)
                stable_base_v2234 = _get_float("SeekManagedStableBasePosSecV2234", current)
                stable_state_v2234 = lead_ok_v2232 and not paused and not seeking and not caching
                if stable_state_v2234:
                    if stable_since_v2234 <= 0:
                        stable_since_v2234 = now
                        stable_base_v2234 = current
                        _set_prop("SeekManagedStableSinceMsV2234", now)
                        _set_prop("SeekManagedStableBasePosSecV2234", "%.3f" % current)
                    stable_ms_v2234 = max(0, now - stable_since_v2234)
                    stable_advanced_v2234 = max(0.0, current - stable_base_v2234)
                    stable_rate_v2234 = stable_advanced_v2234 / max(0.001, float(stable_ms_v2234) / 1000.0) if stable_ms_v2234 > 0 else 0.0
                    # An obvious fast catch-up is not normal playback; start a
                    # fresh stability window from the current clock position.
                    if stable_ms_v2234 >= 180 and stable_rate_v2234 > SEEK_MANAGED_POST_RESUME_FAST_MAX_RATE_V2234:
                        _set_prop("SeekManagedStableSinceMsV2234", now)
                        _set_prop("SeekManagedStableBasePosSecV2234", "%.3f" % current)
                        stable_since_v2234 = now
                        stable_base_v2234 = current
                        stable_ms_v2234 = 0
                        stable_advanced_v2234 = 0.0
                        stable_rate_v2234 = 0.0
                    fast_normal_v2234 = (
                        stable_ms_v2234 >= SEEK_MANAGED_POST_RESUME_FAST_STABLE_MS_V2234 and
                        stable_advanced_v2234 >= SEEK_MANAGED_POST_RESUME_FAST_MIN_ADVANCE_SEC_V2234 and
                        SEEK_MANAGED_POST_RESUME_FAST_MIN_RATE_V2234 <= stable_rate_v2234 <= SEEK_MANAGED_POST_RESUME_FAST_MAX_RATE_V2234
                    )
                else:
                    _set_prop("SeekManagedStableSinceMsV2234", "0")
                    _set_prop("SeekManagedStableBasePosSecV2234", "%.3f" % current)
                    stable_ms_v2234 = 0
                    stable_advanced_v2234 = 0.0
                    stable_rate_v2234 = 0.0
                    fast_normal_v2234 = False

                # Keep the previous v2232 1.5 s aggregate check as a conservative
                # fallback only; the v2234 rolling window normally releases first.
                normal_clock_v2232 = (
                    resume_age_ms >= SEEK_MANAGED_POST_RESUME_VERIFY_MS_V2232 and
                    run_advanced >= SEEK_MANAGED_POST_RESUME_MIN_ADVANCE_SEC_V2232 and
                    SEEK_MANAGED_POST_RESUME_MIN_RATE_V2232 <= run_rate <= SEEK_MANAGED_POST_RESUME_MAX_RATE_V2232
                )
                if fast_normal_v2234 or (normal_clock_v2232 and lead_ok_v2232 and not paused and not seeking and not caching):
                    spinner_was = _get_prop("SeekWaitSpinner") == "1"
                    if fast_normal_v2234:
                        _log(
                            "PKM_SEEK_MANAGED_READY_FAST_V2234 source=%s stable_ms=%d current=%.3f target=%.3f advanced=%.3f rate=%.3f cache_pct=%s lead_sec=%s spinner=%s reveal=normal_playback" % (
                                source, stable_ms_v2234, current, target, stable_advanced_v2234, stable_rate_v2234,
                                "%.2f" % cache_pct_v2232 if cache_pct_v2232 is not None else "-",
                                "%.2f" % lead_sec_v2232 if lead_sec_v2232 is not None else "-",
                                "1" if spinner_was else "0"
                            ), xbmc.LOGINFO,
                        )
                        clear_reason_v2234 = "managed_single_resume_fast_stable_v2234"
                    else:
                        _log(
                            "PKM_SEEK_MANAGED_READY_V2232 source=%s age_ms=%d resume_age_ms=%d current=%.3f target=%.3f advanced=%.3f rate=%.3f cache_pct=%s lead_sec=%s spinner=%s reveal=normal_playback" % (
                                source, age, resume_age_ms, current, target, run_advanced, run_rate,
                                "%.2f" % cache_pct_v2232 if cache_pct_v2232 is not None else "-",
                                "%.2f" % lead_sec_v2232 if lead_sec_v2232 is not None else "-",
                                "1" if spinner_was else "0"
                            ), xbmc.LOGINFO,
                        )
                        clear_reason_v2234 = "managed_single_resume_stable_v2232_fallback"
                    _clear_seek_wait_v2226(clear_reason_v2234)
                    return False
        else:
            # v2226 fast path (intro and non-managed callers): once the target
            # is reached, clock advance proves visible playback resumed.
            ready = (paused and not seeking and not caching) or (advanced and not seeking and not caching)
            if ready:
                spinner_was = _get_prop("SeekWaitSpinner") == "1"
                _log(
                    "PKM_SEEK_WAIT_READY_V2226 source=%s age_ms=%d arrived_age_ms=%d current=%.3f target=%.3f advanced=%.3f paused=%s spinner=%s" % (
                        source, age, max(0, now - arrived_ms), current, target, abs(current - arrived_pos),
                        "1" if paused else "0", "1" if spinner_was else "0"
                    ),
                    xbmc.LOGINFO,
                )
                _clear_seek_wait_v2226("player_clock_advanced")
                return False

    if age >= SEEK_WAIT_SPINNER_DELAY_MS_V2226 and _get_prop("SeekWaitSpinner") != "1":
        _set_prop("SeekWaitSpinner", "1")
        _log(
            "PKM_SEEK_WAIT_SPINNER_SHOW_V2226 source=%s age_ms=%d current=%.3f target=%.3f arrived=%s seeking=%s caching=%s" % (
                source, age, current, target, "1" if arrived else "0",
                "1" if seeking else "0", "1" if caching else "0"
            ),
            xbmc.LOGINFO,
        )
    return True


def request_absolute_native_seek_v2226(target_sec, source="external_v2226"):
    """Issue one Kodi-native relative Seek() to an exact absolute target.

    The caller supplies the authoritative absolute target (for example Plex
    introEnd). PKM converts only to a relative delta at dispatch time; it does
    not alter the target and never starts a second HTTP reader.
    """
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            _log("PKM_ABSOLUTE_NATIVE_SEEK_SKIP_V2226 source=%s reason=not_playing" % source, xbmc.LOGWARNING)
            return False
        before = float(player.getTime() or 0.0)
        duration = float(player.getTotalTime() or 0.0)
        target = float(target_sec or 0.0)
        if duration > 0:
            target = max(0.0, min(target, max(0.0, duration - 0.05)))
        else:
            target = max(0.0, target)
        delta = target - before
        if abs(delta) < 0.05:
            _log("PKM_ABSOLUTE_NATIVE_SEEK_SKIP_V2226 source=%s reason=already_at_target before=%.3f target=%.3f" % (source, before, target), xbmc.LOGINFO)
            return True
        _clear_seek_wait_v2226("superseded_by_new_seek")
        _arm_seek_wait_v2226(target, before, source=source, duration=duration)
        ok = _execute_native_seek_seconds(delta, seq=0, source=source, target=target, duration=duration)
        if not ok:
            _clear_seek_wait_v2226("native_seek_dispatch_failed")
            return False
        _log("PKM_ABSOLUTE_NATIVE_SEEK_DISPATCHED_V2226 source=%s before=%.3f target=%.3f delta=%.3f" % (source, before, target, delta), xbmc.LOGINFO)
        return True
    except Exception:
        _clear_seek_wait_v2226("absolute_native_exception")
        _log("PKM_ABSOLUTE_NATIVE_SEEK_FAILED_V2226 source=%s\n%s" % (source, traceback.format_exc()), xbmc.LOGERROR)
        return False


def _set_dynamic_step_props(back_sec, fwd_sec, bitrate_mbps=0.0, source="", reason=""):
    try:
        back_sec = int(back_sec)
        fwd_sec = int(fwd_sec)
    except Exception:
        back_sec, fwd_sec = 15, 10
    for name, value in (
        ("StepBackSec", back_sec),
        ("StepFwdSec", fwd_sec),
        ("StepBackLabel", "-%ds" % back_sec),
        ("StepFwdLabel", "+%ds" % fwd_sec),
        ("DynamicBitrateMbps", "%.3f" % float(bitrate_mbps or 0.0)),
        ("DynamicBitrateSource", source or "fallback"),
    ):
        _set_prop(name, value)
    if reason:
        _log("PKM_SEEK_DYNAMIC_STEP reason=%s bitrate=%.3f source=%s back=%d fwd=%d" % (reason, float(bitrate_mbps or 0.0), source or "fallback", back_sec, fwd_sec), xbmc.LOGINFO)
    return back_sec, fwd_sec


def _normalize_manual_seek_step(value):
    try:
        v = int(round(float(value or 0)))
    except Exception:
        return 0
    return v if v in (10, 20, 30) else 0


def _manual_seek_step(direction):
    d = str(direction or "").lower()
    name = "ManualStepBackSec" if d in ("back", "left", "rewind", "prev", "-") else "ManualStepFwdSec"
    return _normalize_manual_seek_step(_get_prop(name, ""))


def _apply_manual_seek_step(direction, step, reason=""):
    step_i = _normalize_manual_seek_step(step)
    if step_i <= 0:
        return False
    d = str(direction or "").lower()
    is_back = d in ("back", "left", "rewind", "prev", "-")
    if is_back:
        _set_prop("ManualStepBackSec", step_i)
        _set_prop("StepBackSec", step_i)
        _set_prop("StepBackLabel", "-%ds" % step_i)
        _set_prop("ManualStepBackReason", str(reason or "manual"))
    else:
        _set_prop("ManualStepFwdSec", step_i)
        _set_prop("StepFwdSec", step_i)
        _set_prop("StepFwdLabel", "+%ds" % step_i)
        _set_prop("ManualStepFwdReason", str(reason or "manual"))
    _set_prop("ManualStepUpdatedAtMs", _now_ms())
    _log("PKM_SEEK_MANUAL_STEP_SET_V1463 dir=%s step=%d reason=%s" % ("back" if is_back else "fwd", int(step_i), str(reason or "manual")), xbmc.LOGINFO)
    return True


def _http_content_length(url, token=""):
    if not url or not str(url).lower().startswith(("http://", "https://")):
        return 0, "not_http"
    urls = [str(url)]
    try:
        if token and "X-Plex-Token=" not in url:
            p = urllib.parse.urlparse(url)
            q = urllib.parse.parse_qs(p.query or "", keep_blank_values=True)
            q["X-Plex-Token"] = [token]
            urls.append(urllib.parse.urlunparse(p._replace(query=urllib.parse.urlencode(q, doseq=True))))
    except Exception:
        pass
    last = ""
    for u in urls:
        try:
            req = urllib.request.Request(u, method="HEAD")
            with urllib.request.urlopen(req, timeout=DYNAMIC_SEEK_HTTP_TIMEOUT_SEC) as resp:
                cl = resp.headers.get("Content-Length") or ""
                if cl:
                    return int(cl), "http_head"
                last = "head_no_length"
        except Exception as exc:
            last = "head_%s" % exc.__class__.__name__
        try:
            req = urllib.request.Request(u, method="GET", headers={"Range": "bytes=0-0"})
            with urllib.request.urlopen(req, timeout=DYNAMIC_SEEK_HTTP_TIMEOUT_SEC) as resp:
                try:
                    resp.read(1)
                except Exception:
                    pass
                cr = resp.headers.get("Content-Range") or ""
                cl = resp.headers.get("Content-Length") or ""
                if cr and "/" in cr:
                    total = cr.rsplit("/", 1)[-1].strip()
                    if total.isdigit():
                        return int(total), "http_range"
                if cl and cl.isdigit() and int(cl) > 1:
                    return int(cl), "http_range_length"
                last = "range_no_length"
        except Exception as exc:
            last = "range_%s" % exc.__class__.__name__
    return 0, last or "http_failed"


def _current_playing_url(player=None):
    for getter in (
        lambda: xbmc.getInfoLabel("Player.Filenameandpath"),
        lambda: xbmc.getInfoLabel("Player.Filename"),
        lambda: player.getPlayingFile() if player is not None and hasattr(player, "getPlayingFile") else "",
    ):
        try:
            v = getter() or ""
            if v:
                return str(v)
        except Exception:
            pass
    return ""


def _get_plex_token_from_settings():
    try:
        if ADDON is not None:
            return ADDON.getSetting("plex_token") or ADDON.getSetting("token") or ""
    except Exception:
        pass
    return ""


def _get_plex_server_url_from_settings():
    try:
        if ADDON is not None:
            return (ADDON.getSetting("plex_url") or ADDON.getSetting("server_url") or "").strip().rstrip("/")
    except Exception:
        pass
    return ""


def _resolve_plugin_play_url_to_http(url, reason=""):
    """Resolve Kodi-native plugin playback URL to the real Plex HTTP file URL.

    NATIVE PLAYBACK LOCK v1455 -- DO NOT CHANGE PLAYBACK METHOD:
    Info/Main playback must stay PlayMedia(plugin://...action=play) + setResolvedUrl.
    This helper is ONLY for internal cache/pre-read/bitrate HTTP Range reads.
    Kodi may expose Player.Filename as plugin:// after native handoff, so pre-read
    must parse part_key and build the Plex URL here instead of skipping not_http.
    """
    try:
        u = str(url or "")
        low = u.lower()
        if low.startswith(("http://", "https://")):
            return u, "http_original"
        if not low.startswith("plugin://") or "action=play" not in low:
            return u, "non_plugin"
        parsed = urllib.parse.urlparse(u)
        q = urllib.parse.parse_qs(parsed.query or "", keep_blank_values=True)
        part = ""
        try:
            part = (q.get("part_key") or [""])[0]
        except Exception:
            part = ""
        part = urllib.parse.unquote(part or "")
        if not part:
            return u, "plugin_no_part_key"
        if part.lower().startswith(("http://", "https://")):
            return part, "plugin_part_http"
        if not part.startswith("/"):
            part = "/" + part
        server = _get_plex_server_url_from_settings()
        if not server:
            return u, "plugin_no_server"
        resolved = server + part
        try:
            if reason:
                _log("PKM_NATIVE_PLUGIN_URL_RESOLVED_V1455 reason=%s part_key=%s http=%s" % (str(reason), part[:120], resolved[:180]), xbmc.LOGINFO)
        except Exception:
            pass
        return resolved, "plugin_part_resolved"
    except Exception:
        try:
            _log("PKM_NATIVE_PLUGIN_URL_RESOLVE_FAILED_V1455 reason=%s url=%s\n%s" % (str(reason), str(url or "")[:180], traceback.format_exc()), xbmc.LOGWARNING)
        except Exception:
            pass
        return str(url or ""), "resolve_failed"


def _resolve_preread_http_url(url, reason=""):
    resolved, src = _resolve_plugin_play_url_to_http(url, reason=reason)
    try:
        if resolved and str(resolved).lower().startswith(("http://", "https://")):
            return str(resolved), src
    except Exception:
        pass
    return str(resolved or ""), src


def _detect_bitrate_mbps(player=None, duration=None, reason="", allow_probe=True):
    """Return (bitrate_mbps, source).  Cached by current playback URL.

    v1405 intentionally reads only Content-Length.  It never prefetches video data
    and never changes playback state.
    """
    now = _now_ms()
    raw_url = _current_playing_url(player)
    url, url_src = _resolve_preread_http_url(raw_url, reason=reason or "detect_bitrate_v1455")
    try:
        dur = float(duration if duration is not None else (player.getTotalTime() if player is not None else 0.0) or 0.0)
    except Exception:
        dur = 0.0
    cache_url = _get_prop("DynamicBitrateUrl", "")
    cache_ms = _get_int("DynamicBitrateAtMs", 0)
    cache_br = _get_float("DynamicBitrateMbps", 0.0)
    cache_source = _get_prop("DynamicBitrateSource", "")
    if url and cache_url == url and cache_br > 0.0 and cache_ms > 0 and now > 0 and (now - cache_ms) <= DYNAMIC_SEEK_CACHE_TTL_MS:
        return cache_br, cache_source or "cache"
    # v1411: OSD-visible refresh is called often from skin/window timers.
    # It must never issue HEAD/Range requests; use already cached bitrate only.
    if not allow_probe:
        return 0.0, "fallback_no_probe"
    # Kodi streamdetails bitrate is not reliable for direct Plex URL, but keep a
    # tiny fallback if a skin/player label provides it.
    for label in ("VideoPlayer.VideoBitrate", "Player.VideoBitrate"):
        try:
            raw = xbmc.getInfoLabel(label) or ""
            raw = raw.replace("Mbps", "").replace("Mbit/s", "").replace("kbps", "").strip()
            if raw:
                val = float(raw)
                if val > 1000:
                    val = val / 1000.0
                if val > 0:
                    _set_prop("DynamicBitrateUrl", url)
                    _set_prop("DynamicBitrateAtMs", now)
                    return val, "kodi_label"
        except Exception:
            pass
    if url and dur > 1.0:
        size, src = _http_content_length(url, _get_plex_token_from_settings())
        if size > 0:
            br = (float(size) * 8.0) / float(dur) / 1000000.0
            _set_prop("DynamicBitrateUrl", url)
            _set_prop("DynamicBitrateAtMs", now)
            _set_prop("DynamicBitrateMbps", "%.3f" % br)
            _set_prop("DynamicBitrateSource", src)
            _set_prop("DynamicBitrateSizeBytes", size)
            return br, src
        if reason:
            _log("PKM_SEEK_DYNAMIC_BITRATE_PROBE_FAIL reason=%s url=%s source=%s duration=%.3f" % (reason, url[:180], src, dur), xbmc.LOGWARNING)
    return 0.0, "fallback"


def _steps_from_bitrate(bitrate_mbps, source="", player=None):
    try:
        br = float(bitrate_mbps or 0.0)
    except Exception:
        br = 0.0
    src = str(source or "").lower()

    # v1456 safety rule:
    # 30s main seek is allowed only when the bitrate came from a Plex HTTP
    # length/cache path, not from Kodi's UI bitrate label.  With native
    # PlayMedia, Kodi exposes plugin:// as Player.Filename and a low
    # VideoPlayer.VideoBitrate label can appear before PKM has proven that
    # the actual Plex HTTP Range URL and pre-read path are usable.  Showing
    # a 30s button in that state caused freezes after a single seek.
    trusted_http = False
    try:
        # v1566: Pause pre-read reuses the already verified Plex HTTP file size.
        # In that path v1463 republishes the bitrate source as
        # ``size_duration_fast_v1463_cache``.  It is the same verified size as
        # the pre-pause HTTP result, so do not downgrade the main seek buttons
        # from 30s to the 10s safety fallback merely because the source name is
        # wrapped by the v1463 size/duration fast path.
        trusted_v1463_size_cache = (
            src == "size_duration_fast_v1463_cache"
            or (src.startswith("size_duration_fast_v1463_") and src.endswith("_cache"))
        )
        trusted_http = (
            ("http" in src)
            or ("head" in src)
            or ("content" in src)
            or ("cache" == src)
            or trusted_v1463_size_cache
            or ("plugin_part_resolved" in src)
            or ("plugin_part_http" in src)
        )
    except Exception:
        trusted_http = False

    if br > 0.0 and br <= 10.0 and trusted_http:
        return 30, 30
    return 10, 10


# ---------------------------------------------------------------------------
# R61 adaptive seek step.
#
# Goal: the +/- icon shows the LARGEST jump that Kodi can serve from data it
# already holds, so the jump lands without re-buffering.
#   forward  = media seconds cached AHEAD of the playhead
#              (JSON-RPC cachepercentage - percentage) x duration
#   backward = Kodi keeps 1/4 of filecache.memorysize behind the read
#              position; seconds = bytes x 8 / bitrate, limited to what was
#              actually played since the last out-of-cache jump.
# A fast LAN (fill ratio from PKM network health) also allows a moderate
# forward jump past the cache because the refill is near-instant.
# Icons exist for 5/10/15/20/25/30 s, so values are quantised to those.
# ---------------------------------------------------------------------------
R61_STEPS = (5, 10, 15, 20, 25, 30)
R61_UP_HOLD_MS = 2000
_R61_MEM_MB = {"v": None, "at": 0}


def _r61_jsonrpc(method, params=None):
    try:
        req = {"jsonrpc": "2.0", "id": 61, "method": method}
        if params is not None:
            req["params"] = params
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)) or "{}")
    except Exception:
        return {}


def _r61_kodi_cache_mem_mb():
    now = _now_ms()
    if _R61_MEM_MB["v"] is not None and now - int(_R61_MEM_MB["at"] or 0) < 300000:
        return _R61_MEM_MB["v"]
    value = 20.0
    try:
        res = _r61_jsonrpc("Settings.GetSettingValue", {"setting": "filecache.memorysize"}).get("result") or {}
        v = float(res.get("value"))
        if v > 0:
            value = v
    except Exception:
        pass
    _R61_MEM_MB["v"] = value
    _R61_MEM_MB["at"] = now
    return value


def _r61_player_cache_snapshot():
    """One local JSON-RPC call: playhead, duration and cache end (seconds)."""
    try:
        active = _r61_jsonrpc("Player.GetActivePlayers").get("result") or []
        pid = -1
        for item in active:
            if item.get("type") == "video":
                pid = int(item.get("playerid"))
                break
        if pid < 0:
            return None
        res = _r61_jsonrpc("Player.GetProperties", {
            "playerid": pid,
            "properties": ["percentage", "cachepercentage", "time", "totaltime", "speed"],
        }).get("result") or {}

        def _secs(t):
            t = t or {}
            return (float(t.get("hours", 0)) * 3600.0 + float(t.get("minutes", 0)) * 60.0
                    + float(t.get("seconds", 0)) + float(t.get("milliseconds", 0)) / 1000.0)

        total = _secs(res.get("totaltime"))
        cur = _secs(res.get("time"))
        cache_pct = float(res.get("cachepercentage") or 0.0)
        if total <= 1.0:
            return None
        cache_end = max(0.0, min(total, cache_pct * total / 100.0))
        lead = max(0.0, cache_end - cur)
        return {"cur": cur, "total": total, "cache_end": cache_end, "lead": lead,
                "speed": float(res.get("speed") or 0.0)}
    except Exception:
        return None


def _r61_network_ratio():
    try:
        return max(0.0, float(_win().getProperty("PlexKM.Network.RatioValue") or 0.0))
    except Exception:
        return 0.0


def _r61_file_bitrate_mbps(bitrate_mbps):
    best = 0.0
    try:
        best = float(bitrate_mbps or 0.0)
    except Exception:
        best = 0.0
    try:
        best = max(best, float(_win().getProperty("PlexKM.Network.RequiredValue") or 0.0))
    except Exception:
        pass
    return best


def _r61_quantize(seconds):
    pick = R61_STEPS[0]
    for step in R61_STEPS:
        if step <= seconds:
            pick = step
    return pick


def _seek_osd_show_r172(delta):
    """R172: tiny '+30s / -10s' pill over the video for ~1.3 s (VideoFullScreen skin overlay).
    Repeated presses in the same direction accumulate.  Expiry is handled by the service tick."""
    import time as _t
    win = xbmcgui.Window(10000)
    d = float(delta or 0.0)
    if abs(d) < 0.5:
        return
    direction = "fwd" if d > 0 else "back"
    now = _t.time()
    try:
        until = float(win.getProperty("PlexKM.SeekOsd.Until") or 0.0)
    except Exception:
        until = 0.0
    total = abs(d)
    if win.getProperty("PlexKM.SeekOsd.Active") == "1" and win.getProperty("PlexKM.SeekOsd.Dir") == direction and until > now:
        try:
            total += float(win.getProperty("PlexKM.SeekOsd.Total") or 0.0)
        except Exception:
            pass
    sec = int(round(total))
    if sec >= 60:
        label = "%d분 %d초" % (sec // 60, sec % 60) if sec % 60 else "%d분" % (sec // 60)
    else:
        label = "%d초" % sec
    win.setProperty("PlexKM.SeekOsd.Dir", direction)
    win.setProperty("PlexKM.SeekOsd.Total", "%d" % sec)
    if sec >= 60:
        num, unit = "%d:%02d" % (sec // 60, sec % 60), ""
    else:
        num, unit = "%d" % sec, "초"
    win.setProperty("PlexKM.SeekOsd.Num", num)
    win.setProperty("PlexKM.SeekOsd.Unit", unit)
    win.setProperty("PlexKM.SeekOsd.Label", label)
    win.setProperty("PlexKM.SeekOsd.Until", "%.3f" % (now + 1.3))
    win.setProperty("PlexKM.SeekOsd.Active", "1")
    _log("SEEK_OSD_R172 dir=%s label=%s active=%s" % (direction, label, win.getProperty("PlexKM.SeekOsd.Active")), xbmc.LOGINFO)


def r61_note_seek(delta, before=None):
    """Called on every native seek: keep the back-buffer origin honest."""
    try:
        snap = _r61_player_cache_snapshot()
        if snap is None:
            return
        cur = float(before if before is not None else snap["cur"])
        target = max(0.0, cur + float(delta or 0.0))
        contig = _get_float("R61ContigStartSec", -1.0)
        if contig < 0.0 or contig > cur:
            contig = cur
        back_avail = _r61_back_capacity_sec(_r61_file_bitrate_mbps(_get_float("DynamicBitrateMbps", 0.0)))
        back_avail = min(back_avail, max(0.0, cur - contig))
        in_cache = (
            (float(delta) > 0.0 and float(delta) <= snap["lead"])
            or (float(delta) < 0.0 and abs(float(delta)) <= back_avail)
        )
        if not in_cache:
            _set_prop("R61ContigStartSec", "%.3f" % target)
        else:
            _set_prop("R61InCacheSeekAtMs", _now_ms())
        _log("PKM_SEEK_R61_NOTE delta=%.1f lead=%.1f back_avail=%.1f in_cache=%d" % (
            float(delta or 0.0), snap["lead"], back_avail, 1 if in_cache else 0), xbmc.LOGINFO)
    except Exception:
        pass


def _r61_back_capacity_sec(bitrate_mbps):
    try:
        br = float(bitrate_mbps or 0.0)
    except Exception:
        br = 0.0
    if br <= 0.0:
        return 10.0
    back_bytes = _r61_kodi_cache_mem_mb() * 1024.0 * 1024.0 / 4.0
    return back_bytes * 8.0 / (br * 1000000.0)


def _r61_adaptive_steps(bitrate_mbps=0.0, reason=""):
    """Return (back, fwd, info) or None when the player cache is unknown."""
    snap = _r61_player_cache_snapshot()
    if snap is None:
        return None
    br = _r61_file_bitrate_mbps(bitrate_mbps)
    ratio = _r61_network_ratio()

    lead = float(snap["lead"])
    fwd_safe = lead - max(2.0, lead * 0.10)
    if ratio >= 4.0:
        fwd_safe = max(fwd_safe, 15.0)
    elif ratio >= 2.0:
        fwd_safe = max(fwd_safe, 10.0)

    contig = _get_float("R61ContigStartSec", -1.0)
    # Seekbar / chapter jumps do not pass r61_note_seek: detect a forward
    # discontinuity of the playhead and restart the back-buffer origin.
    now_r61 = _now_ms()
    prev_cur = _get_float("R61PrevCur", -1.0)
    prev_at = _get_int("R61PrevAtMs", 0)
    if prev_cur >= 0.0 and prev_at:
        elapsed = max(0.0, (now_r61 - prev_at) / 1000.0)
        jumped = snap["cur"] - prev_cur > elapsed * 1.6 + 3.0
        noted = now_r61 - _get_int("R61InCacheSeekAtMs", 0) < 4000
        if jumped and not noted:
            contig = snap["cur"]
            _set_prop("R61ContigStartSec", "%.3f" % contig)
    _set_prop("R61PrevCur", "%.3f" % snap["cur"])
    _set_prop("R61PrevAtMs", now_r61)
    if contig < 0.0 or contig > snap["cur"] + 1.0:
        contig = snap["cur"]
        _set_prop("R61ContigStartSec", "%.3f" % contig)
    played = max(0.0, snap["cur"] - contig)
    back_cap = _r61_back_capacity_sec(br)
    back_safe = min(back_cap * 0.8, played) - 1.0

    fwd = _r61_quantize(fwd_safe)
    back = _r61_quantize(back_safe)

    # Hysteresis: go down at once, go up only after the larger value held.
    now = _now_ms()
    out = []
    for name, value in (("Back", back), ("Fwd", fwd)):
        last = _get_int("R61Last%s" % name, 0)
        if last <= 0 or value <= last:
            _set_prop("R61Last%s" % name, value)
            _clear_prop("R61Up%sSinceMs" % name)
            out.append(value)
            continue
        since = _get_int("R61Up%sSinceMs" % name, 0)
        if not since:
            _set_prop("R61Up%sSinceMs" % name, now)
            out.append(last)
        elif now - since >= R61_UP_HOLD_MS:
            _set_prop("R61Last%s" % name, value)
            _clear_prop("R61Up%sSinceMs" % name)
            out.append(value)
        else:
            out.append(last)
    tight = 1 if (lead < 5.0 and ratio < 2.0) else 0
    _set_prop("R61Tight", tight)
    _set_prop("R61LeadSec", "%.1f" % lead)
    _set_prop("R61BackCapSec", "%.1f" % back_cap)
    info = "lead=%.1f back_cap=%.1f played=%.1f bitrate=%.3f ratio=%.2f mem_mb=%.0f tight=%d" % (
        lead, back_cap, played, br, ratio, _r61_kodi_cache_mem_mb(), tight)
    return out[0], out[1], info


def reset_r61_for_new_playback(reason=""):
    for name in ("R61PrevCur", "R61PrevAtMs", "R61InCacheSeekAtMs", "R61ContigStartSec", "R61LastBack", "R61LastFwd", "R61UpBackSinceMs",
                 "R61UpFwdSinceMs", "R61Tight", "R61LeadSec", "R61BackCapSec"):
        _clear_prop(name)


def _publish_dynamic_seek_steps(player=None, duration=None, reason=""):
    reason_s = str(reason or "")
    # v1430: actual seek is Kodi native Seek(seconds), but the second value is
    # still PKM's measured safe table.  OSD refresh must not probe repeatedly;
    # actual seek requests may probe once and cache the bitrate/step.
    allow_probe = not reason_s.startswith("osd_visible")
    br, src = _detect_bitrate_mbps(player=player, duration=duration, reason=reason, allow_probe=allow_probe)
    adaptive_r61 = None
    try:
        adaptive_r61 = _r61_adaptive_steps(bitrate_mbps=br, reason=reason)
    except Exception:
        adaptive_r61 = None
    if adaptive_r61 is not None:
        back_sec, fwd_sec = int(adaptive_r61[0]), int(adaptive_r61[1])
        src = (src or "fallback") + "+cache_r61"
        if reason_s and not reason_s.startswith("osd_visible"):
            _log("PKM_SEEK_ADAPTIVE_R61 reason=%s back=%d fwd=%d %s" % (reason, back_sec, fwd_sec, adaptive_r61[2]), xbmc.LOGINFO)
        elif reason_s.startswith("osd_visible"):
            _last_r61 = _get_int("R61OsdLogAtMs", 0)
            _now_r61 = _now_ms()
            if not _last_r61 or _now_r61 - _last_r61 >= 5000:
                _set_prop("R61OsdLogAtMs", _now_r61)
                _log("PKM_SEEK_ADAPTIVE_R61 reason=%s back=%d fwd=%d %s" % (reason, back_sec, fwd_sec, adaptive_r61[2]), xbmc.LOGINFO)
    else:
        back_sec, fwd_sec = _steps_from_bitrate(br, src, player=player)
    manual_back = _manual_seek_step("back")
    manual_fwd = _manual_seek_step("fwd")
    if manual_back > 0:
        back_sec = manual_back
    if manual_fwd > 0:
        fwd_sec = manual_fwd
    try:
        if manual_back > 0 or manual_fwd > 0:
            src = (src or "fallback") + "+manual_step"
    except Exception:
        pass
    try:
        if float(br or 0.0) > 0.0 and float(br or 0.0) <= 10.0 and int(back_sec) == 10 and str(src or "").lower() in ("kodi_label", "fallback", "fallback_no_probe"):
            if reason_s and not reason_s.startswith("osd_visible"):
                _log("PKM_SEEK_DYNAMIC_30S_CAP_V1456 reason=%s bitrate=%.3f source=%s back=%d fwd=%d rule=untrusted_bitrate_source" % (reason, float(br or 0.0), src or "", int(back_sec), int(fwd_sec)), xbmc.LOGINFO)
    except Exception:
        pass
    # v1411: OSD timer can run every ~0.5s.  Keep labels updated but avoid log spam.
    log_reason = reason
    if reason_s.startswith("osd_visible"):
        last_log = _get_int("DynamicStepOsdLogAtMs", 0)
        now = _now_ms()
        if last_log and now and (now - last_log) < 5000:
            log_reason = ""
        else:
            _set_prop("DynamicStepOsdLogAtMs", now)
    return _set_dynamic_step_props(back_sec, fwd_sec, br, src, reason=log_reason)


def _dynamic_delta_for_dir(direction, player=None, duration=None, reason=""):
    back_sec, fwd_sec = _publish_dynamic_seek_steps(player=player, duration=duration, reason=reason)
    d = str(direction or "").lower()
    if d in ("left", "back", "backward", "prev", "rewind"):
        return -float(back_sec)
    if d in ("right", "fwd", "forward", "next"):
        return float(fwd_sec)
    return 0.0


def _burst_max_for_step(step_abs):
    try:
        step_abs = abs(float(step_abs or 0.0))
    except Exception:
        step_abs = 0.0
    if step_abs <= 0.0:
        return 0.0
    return min(float(DYNAMIC_SEEK_MAX_TOTAL_SEC), step_abs * 3.0)

def _percent_to_nib_index(percent):
    # v1386: 0~100 was too coarse. On a 1:40:36 file, one 10s seek is
    # only about 0.165%, so the old marker stayed on the same index.
    # Use 0~1000 so each 10s seek moves the marker/progress by about 3px.
    try:
        p = float(percent)
    except Exception:
        p = 0.0
    if p < 0.0:
        p = 0.0
    if p > 100.0:
        p = 100.0
    return int(round(p * 10.0))


# R140: VideoOSD 진행바 경량화.  예전엔 노브/목표 채움/미리읽기 채움을 각각
# 1001장 그림으로 깔고 NibIndex 와 같은 한 장만 보이게 했다(컨트롤 4,392개,
# 첫 OSD 로딩 ~1s GUI 멈춤).  이제 그림은 한 장씩만 두고 여기서 위치/너비만 옮긴다.
# 컨트롤 객체는 캐시하지 않는다(창이 다시 읽히면 옛 포인터가 깨질 수 있음).
R140_OSD_WIN_ID = 12901
R140_BAR_W = 1728
R140_NIB_HALF = 28
R140_ID_NIB = 8711
R140_ID_FILL = 8712
R140_ID_FILL_FOCUS = 8713
R140_ID_CACHE = 8714


def _r140_nib_px(idx):
    try:
        i = int(float(idx))
    except Exception:
        i = 0
    i = max(0, min(1000, i))
    return int(round(i * R140_BAR_W / 1000.0))


def _r140_osd_win():
    try:
        return xbmcgui.Window(R140_OSD_WIN_ID)
    except Exception:
        return None


def _r140_apply_cache_geom(cache_idx=None, win=None):
    try:
        if cache_idx is None:
            cache_idx = _get_prop("PreReadCacheNibIndex", "")
        if cache_idx == "" or cache_idx is None:
            return False
        if win is None:
            win = _r140_osd_win()
        if win is None:
            return False
        win.getControl(R140_ID_CACHE).setWidth(_r140_nib_px(cache_idx))
        return True
    except Exception:
        return False


def _r140_apply_nib_geom(idx, win=None):
    try:
        if win is None:
            win = _r140_osd_win()
        if win is None:
            return False
        x = _r140_nib_px(idx)
        win.getControl(R140_ID_NIB).setPosition(x - R140_NIB_HALF, 107)
        win.getControl(R140_ID_FILL).setWidth(x)
        win.getControl(R140_ID_FILL_FOCUS).setWidth(x)
        _r140_apply_cache_geom(None, win)
        return True
    except Exception:
        return False


def _set_osd_nib_index(percent, reason=""):
    idx = _percent_to_nib_index(percent)
    # R140: 그림을 먼저 옮기고 속성을 켠다(처음 보일 때 옛 위치가 번쩍이지 않게).
    _r140_apply_nib_geom(idx)
    _set_osd_prop("NibIndex", idx)
    if reason:
        try:
            pct = float(percent or 0.0)
        except Exception:
            pct = 0.0
        _log("PKM_PLAYER_OSD_NIB_INDEX_SET reason=%s percent=%.3f index=%d" % (reason, pct, idx), xbmc.LOGINFO)
    return idx


def _set_osd_nib_from_player(player=None, duration=None, reason=""):
    try:
        if player is None:
            player = xbmc.Player()
        if duration is None:
            duration = float(player.getTotalTime() or 0.0)
        current = float(player.getTime() or 0.0)
        percent = 0.0
        if duration > 0:
            percent = max(0.0, min(100.0, (current / duration) * 100.0))
        return _set_osd_nib_index(percent, reason=reason)
    except Exception:
        return _set_osd_nib_index(0.0, reason=reason or "player_read_failed")


def _bool_cond(expr):
    try:
        return bool(xbmc.getCondVisibility(expr))
    except Exception:
        return False


def _close_video_osd(reason=""):
    """Close/hide the full player OSD during quick seek.

    This does not touch playback state and does not close custom subtitle/audio
    dialogs unless the native VideoOSD itself was opened by Kodi's arrow-key
    handling.
    """
    was_videoosd = "1" if _bool_cond("Window.IsActive(videoosd)") else "0"
    try:
        xbmc.executebuiltin("Dialog.Close(videoosd,true)")
    except Exception:
        pass
    if was_videoosd == "1":
        _log("PKM_SEEK_QUICK_OSD_CLOSE reason=%s window_videoosd_before=1" % reason)


def _format_time(seconds):
    try:
        s = max(0, int(round(float(seconds))))
    except Exception:
        s = 0
    h = s // 3600
    m = (s % 3600) // 60
    sec = s % 60
    if h > 0:
        return "%d:%02d:%02d" % (h, m, sec)
    return "%d:%02d" % (m, sec)


def _format_seek_target_ko_v2231(seconds):
    """Compact Korean seek target for the bubble above the progress nib.

    Examples: 40초 / 1분20초 / 44분20초 / 1시간25분.
    """
    try:
        total = max(0, int(round(float(seconds or 0))))
    except Exception:
        total = 0
    h = total // 3600
    m = (total % 3600) // 60
    sec = total % 60
    if h > 0:
        # Keep hour-scale labels compact above the nib: 1시간25분.
        text = "%d시간" % h
        if m > 0:
            text += "%d분" % m
        return text
    if m > 0:
        text = "%d분" % m
        if sec > 0:
            text += "%d초" % sec
        return text
    return "%d초" % sec


def _seek_time_bubble_index_v2231(percent):
    """Coarse 0..100 position for a lightweight time label above the nib."""
    try:
        p = max(0.0, min(100.0, float(percent or 0.0)))
    except Exception:
        p = 0.0
    return int(round(p))


def _format_runtime_ko(seconds):
    # v1377: Plex seek meta uses a readable runtime, not Kodi HH:MM:SS.
    try:
        total_min = max(0, int(round(float(seconds or 0) / 60.0)))
    except Exception:
        total_min = 0
    if total_min <= 0:
        return ""
    h = total_min // 60
    m = total_min % 60
    if h > 0 and m > 0:
        return "%d 시간 %d 분" % (h, m)
    if h > 0:
        return "%d 시간" % h
    return "%d 분" % m


def _ensure_player_overlay_meta(player=None, duration=None, reason=""):
    # v1377: when DialogSeekBar is opened directly after quick seek, the
    # playback ListItem owner properties can be empty.  In that case Kodi's
    # fallback prints '2001 • 01:40:36', which is not Plex style.  Rebuild the
    # display properties from Kodi video labels + player duration.
    try:
        win = _win()
    except Exception:
        return False
    try:
        title = win.getProperty("PlexKM.Player.Title") or xbmc.getInfoLabel("VideoPlayer.Title") or xbmc.getInfoLabel("Player.Title") or ""
        year = win.getProperty("PlexKM.Player.Year") or xbmc.getInfoLabel("VideoPlayer.Year") or ""
        dur = duration
        if dur is None:
            try:
                dur = float(player.getTotalTime() or 0.0) if player is not None else 0.0
            except Exception:
                dur = 0.0
        runtime = _format_runtime_ko(dur)
        if title:
            win.setProperty("PlexKM.Player.Title", str(title).strip())
        if year:
            win.setProperty("PlexKM.Player.Year", str(year).strip())
        if runtime:
            win.setProperty("PlexKM.Player.Runtime", runtime)
        parts = []
        if year:
            parts.append(str(year).strip())
        if runtime:
            parts.append(runtime)
        if parts:
            meta = " • ".join(parts)
            old_meta = win.getProperty("PlexKM.Player.Meta") or ""
            if (not old_meta) or (":" in old_meta) or (old_meta != meta):
                win.setProperty("PlexKM.Player.Meta", meta)
                _log("PKM_PLAYER_META_REBUILT reason=%s title=%s meta=%s" % (reason, str(title or ""), meta), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _clamp_target(value, duration):
    try:
        target = float(value)
    except Exception:
        target = 0.0
    try:
        dur = float(duration)
    except Exception:
        dur = 0.0
    if dur > 1.0:
        target = max(0.0, min(target, max(0.0, dur - 0.25)))
    else:
        target = max(0.0, target)
    return target


def _with_plex_token(url, token=""):
    try:
        if token and url and "X-Plex-Token=" not in str(url):
            p = urllib.parse.urlparse(str(url))
            q = urllib.parse.parse_qs(p.query or "", keep_blank_values=True)
            q["X-Plex-Token"] = [token]
            return urllib.parse.urlunparse(p._replace(query=urllib.parse.urlencode(q, doseq=True)))
    except Exception:
        pass
    return str(url or "")


def _get_cached_or_probe_size(url, token=""):
    try:
        cache_url = _get_prop("DynamicBitrateUrl", "")
        cache_size = _get_int("DynamicBitrateSizeBytes", 0)
        if url and cache_url == url and cache_size > 0:
            return int(cache_size), "cache"
    except Exception:
        pass
    try:
        size, src = _http_content_length(url, token)
        if size > 0:
            _set_prop("DynamicBitrateUrl", url)
            _set_prop("DynamicBitrateSizeBytes", int(size))
        return int(size or 0), src
    except Exception:
        return 0, "size_probe_failed"


def _jump_prewarm_worker(url, token, start, end, seq, source):
    st = _now_ms()
    state = "start"
    total = 0
    try:
        u = _with_plex_token(url, token)
        req = urllib.request.Request(u, method="GET", headers={"Range": "bytes=%d-%d" % (int(start), int(end))})
        with urllib.request.urlopen(req, timeout=LONG_JUMP_PREWARM_TIMEOUT_SEC) as resp:
            while total < LONG_JUMP_PREWARM_READ_BYTES:
                try:
                    chunk = resp.read(min(64 * 1024, LONG_JUMP_PREWARM_READ_BYTES - total))
                except Exception:
                    break
                if not chunk:
                    break
                total += len(chunk)
                if _now_ms() - st >= int(LONG_JUMP_PREWARM_TIMEOUT_SEC * 1000):
                    break
        state = "ok" if total > 0 else "empty"
    except Exception as exc:
        state = "failed_%s" % exc.__class__.__name__
    try:
        _set_prop("JumpPrewarmState", state)
        _log("PKM_JUMP_PREWARM_DONE seq=%s state=%s bytes=%d elapsed_ms=%d range=%d-%d source=%s" % (seq, state, total, max(0, _now_ms() - st), int(start), int(end), source), xbmc.LOGINFO if total > 0 else xbmc.LOGWARNING)
    except Exception:
        pass


def _start_jump_prewarm(player, target, duration, seq, source=""):
    try:
        raw_url = _current_playing_url(player)
        url, url_src = _resolve_preread_http_url(raw_url, reason="jump_prewarm_v1455")
        if not url or not str(url).lower().startswith(("http://", "https://")):
            return False
        dur = float(duration or 0.0)
        tgt = float(target or 0.0)
        if dur <= 1.0 or tgt <= 0.0:
            return False
        token = _get_plex_token_from_settings()
        size, size_src = _get_cached_or_probe_size(url, token)
        if size <= 0:
            _log("PKM_JUMP_PREWARM_SKIP seq=%s reason=no_size source=%s size_src=%s" % (seq, source, size_src), xbmc.LOGWARNING)
            return False
        ratio = max(0.0, min(1.0, tgt / dur))
        center = int(float(size) * ratio)
        start = max(0, center - LONG_JUMP_PREWARM_BACK_BYTES)
        end = min(max(0, size - 1), center + LONG_JUMP_PREWARM_AHEAD_BYTES)
        if end <= start:
            return False
        _set_prop("JumpPrewarm", "1")
        _set_prop("JumpPrewarmSeq", seq)
        _set_prop("JumpPrewarmRange", "%d-%d" % (start, end))
        _set_prop("JumpPrewarmState", "scheduled")
        t = threading.Thread(target=_jump_prewarm_worker, args=(url, token, start, end, seq, source), name="PKMJumpPrewarm", daemon=True)
        t.daemon = True
        t.start()
        _log("PKM_JUMP_PREWARM_START seq=%s target=%.3f duration=%.3f ratio=%.5f size=%d size_src=%s range=%d-%d source=%s" % (seq, tgt, dur, ratio, size, size_src, start, end, source), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_JUMP_PREWARM_FAILED seq=%s source=%s\n%s" % (seq, source, traceback.format_exc()), xbmc.LOGWARNING)
        return False




def _manual_preread_pause_player(seq, source):
    """Pause playback and verify it before starting heavy read-ahead."""
    try:
        if xbmc.getCondVisibility("Player.Paused"):
            _log("PKM_MANUAL_PREREAD_PAUSE_SKIP seq=%s reason=already_paused source=%s" % (seq, source), xbmc.LOGINFO)
            return False, True
    except Exception:
        pass
    try:
        xbmc.Player().pause()
    except Exception:
        try:
            xbmc.executebuiltin("PlayerControl(Play)")
        except Exception:
            pass
    confirmed = False
    try:
        for _i in range(12):
            xbmc.sleep(100)
            if xbmc.getCondVisibility("Player.Paused"):
                confirmed = True
                break
    except Exception:
        confirmed = False
    if not confirmed:
        try:
            xbmc.executebuiltin("Action(Pause)")
            xbmc.sleep(180)
            confirmed = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            confirmed = False
    _log("PKM_MANUAL_PREREAD_PAUSE_APPLIED seq=%s confirmed=%s source=%s" % (seq, "1" if confirmed else "0", source), xbmc.LOGINFO if confirmed else xbmc.LOGWARNING)
    return True, confirmed


def _manual_preread_resume_player(seq, source, ready):
    try:
        if xbmc.getCondVisibility("Player.Paused"):
            xbmc.Player().pause()
            xbmc.sleep(120)
            _log("PKM_MANUAL_PREREAD_RESUME_APPLIED seq=%s ready=%s source=%s" % (seq, "1" if ready else "0", source), xbmc.LOGINFO)
            return True
    except Exception:
        pass
    try:
        if xbmc.getCondVisibility("Player.Paused"):
            xbmc.executebuiltin("PlayerControl(Play)")
            _log("PKM_MANUAL_PREREAD_RESUME_APPLIED seq=%s ready=%s source=%s" % (seq, "1" if ready else "0", source), xbmc.LOGINFO)
            return True
    except Exception:
        pass
    return False

def _manual_preread_bytes_for_bitrate(bitrate_mbps):
    try:
        br = float(bitrate_mbps or 0.0)
    except Exception:
        br = 0.0
    if br <= 0.0:
        return MANUAL_PREREAD_LOW_BYTES
    if br <= 10.0:
        return MANUAL_PREREAD_LOW_BYTES
    if br <= 18.0:
        return MANUAL_PREREAD_MID_BYTES
    return MANUAL_PREREAD_HIGH_BYTES


def _manual_preread_tail_worker(url, token, start, end, seq, source, current, duration, bitrate_mbps):
    st = _now_ms()
    total = 0
    state = "start"
    try:
        if end <= start:
            _set_prop("PreReadTailState", "skip_no_tail")
            _log("PKM_MANUAL_PREREAD_TAIL_SKIP seq=%s reason=no_tail range=%d-%d source=%s" % (seq, int(start), int(end), source), xbmc.LOGINFO)
            return
        _set_prop("PreReadTailState", "running")
        _set_prop("PreReadTailBytes", 0)
        _set_prop("PreReadTailRange", "%d-%d" % (int(start), int(end)))
        u = _with_plex_token(url, token)
        req = urllib.request.Request(u, method="GET", headers={"Range": "bytes=%d-%d" % (int(start), int(end))})
        _log("PKM_MANUAL_PREREAD_TAIL_START seq=%s range=%d-%d current=%.3f duration=%.3f bitrate=%.3f source=%s" % (seq, int(start), int(end), float(current or 0.0), float(duration or 0.0), float(bitrate_mbps or 0.0), source), xbmc.LOGINFO)
        with urllib.request.urlopen(req, timeout=MANUAL_PREREAD_SOCKET_TIMEOUT_SEC) as resp:
            last_log = st
            while True:
                if _get_prop("PreReadSeq", "") != str(seq):
                    state = "superseded"
                    break
                try:
                    chunk = resp.read(MANUAL_PREREAD_CHUNK_BYTES)
                except Exception:
                    state = "read_error"
                    break
                if not chunk:
                    state = "ok" if total > 0 else "empty"
                    break
                total += len(chunk)
                _set_prop("PreReadTailBytes", total)
                now = _now_ms()
                if now - last_log >= 30000:
                    last_log = now
                    elapsed = max(1, now - st)
                    speed = (float(total) / 1048576.0) / (float(elapsed) / 1000.0)
                    _log("PKM_MANUAL_PREREAD_TAIL_PROGRESS seq=%s bytes=%d elapsed_ms=%d speed_mbps=%.3f source=%s" % (seq, total, elapsed, speed, source), xbmc.LOGINFO)
                if MANUAL_PREREAD_SLEEP_MS > 0:
                    try:
                        xbmc.sleep(int(MANUAL_PREREAD_SLEEP_MS))
                    except Exception:
                        pass
        if state == "start":
            state = "ok" if total > 0 else "empty"
    except Exception as exc:
        state = "failed_%s" % exc.__class__.__name__
    elapsed = max(0, _now_ms() - st)
    speed = (float(total) / 1048576.0) / (float(elapsed) / 1000.0) if elapsed > 0 and total > 0 else 0.0
    try:
        _set_prop("PreReadTailState", state)
        _set_prop("PreReadTailBytes", total)
        _set_prop("PreReadTailElapsedMs", elapsed)
        _set_prop("PreReadTailSpeedMBps", "%.3f" % speed)
        _log("PKM_MANUAL_PREREAD_TAIL_DONE seq=%s state=%s bytes=%d elapsed_ms=%d speed_mbps=%.3f range=%d-%d source=%s" % (seq, state, total, elapsed, speed, int(start), int(end), source), xbmc.LOGINFO if total > 0 else xbmc.LOGWARNING)
    except Exception:
        pass



def _manual_preread_cache_nib_from_bytes(pos_bytes, size):
    try:
        if int(size or 0) <= 0:
            return 0, 0.0
        pct = max(0.0, min(100.0, (float(pos_bytes or 0) / float(size)) * 100.0))
        nib = int(max(0, min(1000, round(pct * 10.0))))
        return nib, pct
    except Exception:
        return 0, 0.0


def _manual_preread_media_key(url, size):
    try:
        # The full URL can include a token, so keep only a stable, short identity.
        # Size is added because the same path can be replaced by another file.
        u = str(url or "")
        p = urllib.parse.urlparse(u)
        clean = urllib.parse.urlunparse((p.scheme, p.netloc, p.path, "", "", ""))
        return "%s|%s" % (clean[-220:], str(int(size or 0)))
    except Exception:
        return "%s|%s" % (str(url or "")[-220:], str(int(size or 0)))


def _manual_preread_clear_cache_props(reason=""):
    names = (
        "PreReadActive", "PreReadCacheNibIndex", "PreReadTaskNibIndex", "PreReadLabel",
        "PreReadBytes", "PreReadPlannedBytes", "PreReadCacheEndPercent",
        "PreReadCacheEndBytes", "PreReadCacheStartBytes", "PreReadSpeedMBps",
        "PreReadRange", "PreReadFileSize", "PreReadRealCacheEndBytes",
        "PreReadRealCacheEndPercent", "PreReadRealCacheNibIndex",
        "PreReadInstantMarkerActive", "PreReadInstantMarkerNib",
        "PreReadFirstRealByteLoggedSeq", "PreReadCacheDisplaySeq",
        "PreReadFrontReady", "PreReadFrontReadyAtMs", "PreReadFrontReadyBytes",
    )
    for _n in names:
        try:
            _clear_prop(_n)
        except Exception:
            pass
    try:
        if reason:
            _log("PKM_MANUAL_PREREAD_CACHE_PROPS_CLEAR_V1467 reason=%s" % str(reason or ""), xbmc.LOGINFO)
    except Exception:
        pass


def reset_preread_cache_for_new_playback(reason=""):
    """Clear visual/real cache state at a new Kodi playback session boundary.

    v1484: onAVStarted/onPlayBackStarted is a new playback session.  The old
    v1468 monotonic cachebar was correct inside one playback, but when the same
    movie was started again it could inherit PreReadCacheNibIndex or
    PreReadRealCacheEndBytes from the previous run.  That made the first OSD
    show a long cachebar even though the current session had only just started.
    Clear both visual and real pre-read state here; pause/seek restarts still
    keep monotonic behavior.
    """
    try:
        _clear_seek_wait_v2226("new_playback_session_%s" % str(reason or ""))
        _manual_preread_clear_cache_props(reason="new_playback_session_%s" % str(reason or ""))
        try:
            reset_r61_for_new_playback(reason=reason)
        except Exception:
            pass
        try:
            _clear_prop("PreReadMediaKey")
        except Exception:
            pass
        try:
            _set_prop("PreReadNewPlaybackSessionAtMs", str(_now_ms()))
        except Exception:
            pass
        _log("PKM_MANUAL_PREREAD_NEW_PLAYBACK_RESET_V1484 reason=%s" % str(reason or ""), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def _manual_preread_reset_if_media_changed(url, size, source=""):
    try:
        key = _manual_preread_media_key(url, size)
        old = _get_prop("PreReadMediaKey", "")
        if old and old != key:
            _manual_preread_clear_cache_props(reason="media_changed_%s" % str(source or ""))
        if key:
            _set_prop("PreReadMediaKey", key)
        return key
    except Exception:
        return ""


def _manual_preread_preserve_cache_end(candidate_end, size, state="", source=""):
    """Return a cache end that never shrinks during same-playback seek restarts.

    v1452: +/-30s native seeks restart the Range reader from the new current
    position, but the already-read contiguous Plex/HTTP bytes are still useful
    when the new position overlaps that old window.  The VideoOSD cache overlay
    is an absolute end-nib, so preserving the largest known absolute cache end
    keeps the pale-yellow bar visible instead of disappearing on -30s seeks.
    Full stop/end/shutdown clears PreReadCacheEndBytes separately.
    """
    try:
        size_i = int(size or 0)
        cand = int(candidate_end or 0)
        if size_i <= 0:
            return max(0, cand)
        cand = max(0, min(size_i, cand))
        # v1467: once the same media has an actual HTTP Range cache end, do not
        # let pause/seek/new worker sequences publish a smaller end.  rclone cache
        # does not shrink during playback; only Stop/End/Shutdown or a media-key
        # change clears this state.  Preserve only PreReadReal*, never the tiny
        # marker-only display bytes.
        old_raw = _get_prop("PreReadRealCacheEndBytes", "")
        old = int(float(old_raw)) if old_raw not in ("", None) else 0
        # v1468: preserve across terminal worker states too.  v1467 still
        # allowed FRONT_DONE state=superseded to publish a smaller candidate
        # after a restart/resume.  That overwrote PreReadRealCacheEndBytes and
        # made the VideoOSD cachebar drop (for example 54 nib -> 22 nib).
        # Stop/End/Shutdown and media-key change clear props elsewhere, so any
        # ordinary same-media candidate must be monotonic.
        if old > 0 and old <= size_i and old > cand:
            _log("PKM_MANUAL_PREREAD_CACHE_END_PRESERVE_V1468 old_end=%d new_end=%d preserved=%d state=%s source=%s" % (old, cand, old, str(state or ""), str(source or "")), xbmc.LOGINFO)
            return old
        return cand
    except Exception:
        try:
            return int(candidate_end or 0)
        except Exception:
            return 0


def _manual_preread_update_osd_cache(seq, start, total, planned, size, state, source, speed=0.0):
    try:
        size_i = int(size or 0)
        total_i = max(0, int(total or 0))
        start_i = max(0, int(start or 0))
        real_end_pos = start_i + total_i
        real_end_pos = _manual_preread_preserve_cache_end(real_end_pos, size_i, state, source)
        real_nib, real_pct = _manual_preread_cache_nib_from_bytes(real_end_pos, size_i)
        base_nib, _base_pct = _manual_preread_cache_nib_from_bytes(start_i, size_i)

        # v1467: visible cache follows actual byte-derived end only.  The previous
        # v1461 visual booster could publish up to +120 nibbles (12%) after only a
        # few MB, which looked like a fake cache jump on first playback.
        display_nib = int(real_nib)
        display_pct = float(real_pct)
        display_end_pos = int(real_end_pos or 0)
        marker_active = _get_prop("PreReadInstantMarkerActive", "") == "1"
        marker_nib = _get_int("PreReadInstantMarkerNib", 0)
        if marker_active and marker_nib > 0:
            # Marker remains tiny/immediate, but it never writes PreReadReal*.
            display_nib = int(max(display_nib, marker_nib))

        # v1467: rclone cache must not visually shrink during the same media.
        # This is now global across pause/seek worker sequences, not only within
        # one seq.  Media-key changes and real stop/end/shutdown clear it.
        try:
            old_display_nib = _get_int("PreReadCacheNibIndex", 0)
            # v1468: display nib is also monotonic across superseded/cancelled
            # worker endings.  The properties are cleared only on real stop/end
            # or media-key change.
            if old_display_nib > display_nib:
                display_nib = old_display_nib
        except Exception:
            pass

        display_nib = int(max(0, min(1000, display_nib)))
        if size_i > 0:
            display_pct = float(display_nib) / 10.0
            display_end_pos = int((float(size_i) * float(display_nib)) / 1000.0)

        task_pct = int(max(0, min(100, round((float(total_i) / float(planned or 1)) * 100.0)))) if int(planned or 0) > 0 else 0
        active_states = ("instant_pending", "start", "front_running", "front_ready", "ok", "running", "short_read", "empty", "read_error", "timeout")
        active_val = "1" if (state in active_states or display_nib > 0) else "0"
        _set_prop("PreReadActive", active_val)
        _set_prop("PreReadState", state)
        _set_prop("PreReadCacheDisplaySeq", str(seq))
        _r140_apply_cache_geom(int(display_nib))
        _set_prop("PreReadCacheNibIndex", int(display_nib))
        _set_prop("PreReadCacheEndPercent", "%.2f" % float(display_pct))
        _set_prop("PreReadCacheEndBytes", int(display_end_pos or 0))
        _set_prop("PreReadRealCacheNibIndex", int(real_nib))
        _set_prop("PreReadRealCacheEndPercent", "%.4f" % float(real_pct))
        _set_prop("PreReadRealCacheEndBytes", int(real_end_pos or 0))
        try:
            if not _get_prop("PreReadCacheStartBytes", ""):
                _set_prop("PreReadCacheStartBytes", int(start or 0))
        except Exception:
            pass
        _set_prop("PreReadTaskPercent", task_pct)
        _set_prop("PreReadTaskNibIndex", int(max(0, min(100, task_pct))))
        _set_prop("PreReadBytes", total_i)
        _set_prop("PreReadPlannedBytes", int(planned or 0))
        _set_prop("PreReadSpeedMBps", "%.3f" % float(speed or 0.0))
        _set_prop("PreReadLabel", "")
        try:
            if total_i > 0 and _get_prop("PreReadFirstRealByteLoggedSeq", "") != str(seq):
                _set_prop("PreReadFirstRealByteLoggedSeq", str(seq))
                _log("PKM_MANUAL_PREREAD_REAL_CACHE_FIRST_BYTES_V1461 seq=%s bytes=%d real_end=%d real_nib=%d display_nib=%d marker_nib=%d state=%s source=%s" % (str(seq), int(total_i), int(real_end_pos), int(real_nib), int(display_nib), int(marker_nib or 0), str(state or ""), str(source or "")), xbmc.LOGINFO)
        except Exception:
            pass
    except Exception:
        pass


def prime_preread_visible_marker(reason="", extra_nib=1):
    """Show a tiny faint-white cache lead immediately on pause/playback events.

    v1459: marker-only.  It must be visible enough to confirm that pre-read
    started, but it must not write real cache bytes.  Real HTTP Range bytes are
    published separately by _manual_preread_update_osd_cache.
    """
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            return False
        current = float(player.getTime() or 0.0)
        duration = float(player.getTotalTime() or 0.0)
        # v1461: keep the pause marker extremely tiny, 1 nib by default
        # (~2 px on the 1760 px seek bar).  This leaves room to see real cache
        # growth immediately after the first Range bytes arrive.
        if duration <= 0.5:
            nib = int(max(1, min(1000, int(extra_nib or 1))))
            pct = float(nib) / 10.0
        else:
            pct_now = max(0.0, min(100.0, (current / duration) * 100.0))
            now_nib = int(max(0, min(1000, round(pct_now * 10.0))))
            lead_nib = int(max(1, min(2, int(extra_nib or 1))))
            nib = int(max(1, min(1000, now_nib + lead_nib)))
            pct = float(nib) / 10.0
        seq = "prime_%d" % _now_ms()
        _set_prop("PreReadActive", "1")
        _set_prop("PreReadState", "instant_pending")
        _set_prop("PreReadMode", "v1463_faint_white_tiny_marker_real_bytes_smooth")
        _set_prop("PreReadSeq", seq)
        _set_prop("PreReadSource", str(reason or "instant_marker"))
        _set_prop("PreReadCacheDisplaySeq", seq)
        try:
            _size_for_marker = _get_int("PreReadFileSize", 0)
            if _size_for_marker > 0:
                _marker_end = int((float(_size_for_marker) * float(nib)) / 1000.0)
                # v1467: visual marker only.  Do not write CacheEndBytes here;
                # only real Range reads may publish cache end bytes.
                pass
        except Exception:
            pass
        _set_prop("PreReadInstantMarkerActive", "1")
        _set_prop("PreReadInstantMarkerNib", int(nib))
        # v1468: marker is immediate-only and must never shrink an already
        # published real cachebar.  Keep the larger visible nib.
        try:
            old_display_nib = _get_int("PreReadCacheNibIndex", 0)
            display_nib = int(max(int(old_display_nib or 0), int(nib)))
        except Exception:
            display_nib = int(nib)
        _r140_apply_cache_geom(int(display_nib))
        _set_prop("PreReadCacheNibIndex", display_nib)
        _set_prop("PreReadCacheEndPercent", "%.2f" % (float(display_nib) / 10.0))
        _set_prop("PreReadTaskPercent", 0)
        _set_prop("PreReadTaskNibIndex", 0)
        _set_prop("PreReadBytes", 0)
        _set_prop("PreReadPlannedBytes", 0)
        _set_prop("PreReadSpeedMBps", "0.000")
        _set_prop("PreReadLabel", "")
        _log("PKM_MANUAL_PREREAD_INSTANT_MARKER_V1461 reason=%s current=%.3f duration=%.3f nib=%s pct=%.2f marker_only=1" % (str(reason or ""), current, duration, nib, pct), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_MANUAL_PREREAD_INSTANT_MARKER_FAILED_V1461 reason=%s\n%s" % (str(reason or ""), traceback.format_exc()), xbmc.LOGWARNING)
        return False



def _manual_preread_read_front_parallel_contiguous(url, token, start, end, seq, source, current, duration, bitrate_mbps, workers=2):
    """Pause profile: read small blocks with multiple workers but publish only contiguous bytes.

    This is deliberately conservative.  Worker 0/1 may fetch adjacent 4MB
    blocks in parallel, but the OSD cache bar never advances past a gap.  That
    keeps the user's requirement: linear, continuous fill only.
    """
    st = _now_ms()
    start = int(start)
    end = int(end)
    planned = max(0, end - start + 1)
    workers = int(max(1, min(4, int(workers or 2))))
    block_bytes = int(max(1024 * 1024, min(16 * 1024 * 1024, MANUAL_PREREAD_PARALLEL_BLOCK_BYTES)))
    if planned <= 0:
        return "empty", 0, 0
    size = _get_int("PreReadFileSize", 0)
    total_blocks = int((planned + block_bytes - 1) // block_bytes)
    q = queue.Queue()
    for i in range(total_blocks):
        q.put(i)
    lock = threading.Lock()
    completed = {}
    partial = {}
    errors = []
    stop = {"value": False}
    stats = {"wire": 0, "contig": 0, "last_publish": st, "last_log": st, "first_byte": 0}

    def _calc_locked():
        contig = 0
        idx = 0
        while idx in completed:
            contig += int(completed.get(idx) or 0)
            idx += 1
        if idx in partial:
            contig += int(partial.get(idx) or 0)
        wire = 0
        try:
            wire += sum(int(v or 0) for v in completed.values())
            wire += sum(int(v or 0) for v in partial.values())
        except Exception:
            pass
        return max(0, min(planned, wire)), max(0, min(planned, contig))

    def _publish_locked(force=False):
        now = _now_ms()
        wire, contig = _calc_locked()
        stats["wire"] = wire
        stats["contig"] = contig
        if not force and contig <= 0 and now - stats["last_publish"] < 250:
            return
        if force or contig <= MANUAL_PREREAD_CHUNK_BYTES or now - stats["last_publish"] >= 350:
            stats["last_publish"] = now
            elapsed = max(1, now - st)
            speed = (float(contig) / 1048576.0) / (float(elapsed) / 1000.0) if contig > 0 else 0.0
            _manual_preread_update_osd_cache(seq, start, contig, planned, size, "front_running", source, speed)
        if force or now - stats["last_log"] >= 5000:
            stats["last_log"] = now
            elapsed = max(1, now - st)
            speed = (float(contig) / 1048576.0) / (float(elapsed) / 1000.0) if contig > 0 else 0.0
            wire_speed = (float(wire) / 1048576.0) / (float(elapsed) / 1000.0) if wire > 0 else 0.0
            nib = _get_prop("PreReadCacheNibIndex", "0")
            cache_pct = _get_prop("PreReadCacheEndPercent", "0")
            pct = int(max(0, min(100, round((float(contig) / float(planned or 1)) * 100.0))))
            _log("PKM_MANUAL_PREREAD_FRONT_PROGRESS seq=%s percent=%d cache_nib=%s cache_end_percent=%s contig_bytes=%d wire_bytes=%d planned=%d elapsed_ms=%d contig_speed_mbps=%.3f wire_speed_mbps=%.3f workers=%d display=osd_seekbar_overlay mode=v1463_faint_white_fast_start_smooth_parallel_contiguous block_mb=%.1f source=%s" % (seq, pct, nib, cache_pct, int(contig), int(wire), int(planned), int(now - st), speed, wire_speed, int(workers), float(block_bytes) / 1048576.0, source), xbmc.LOGINFO)

    def _worker(worker_id):
        u = _with_plex_token(url, token)
        while not stop.get("value"):
            if _get_prop("PreReadSeq", "") != str(seq):
                stop["value"] = True
                break
            try:
                idx = q.get_nowait()
            except Exception:
                break
            block_start = start + idx * block_bytes
            block_end = min(end, block_start + block_bytes - 1)
            expected = max(0, block_end - block_start + 1)
            got = 0
            try:
                req = urllib.request.Request(u, method="GET", headers={"Range": "bytes=%d-%d" % (int(block_start), int(block_end))})
                with urllib.request.urlopen(req, timeout=MANUAL_PREREAD_SOCKET_TIMEOUT_SEC) as resp:
                    while got < expected and not stop.get("value"):
                        if _get_prop("PreReadSeq", "") != str(seq):
                            stop["value"] = True
                            break
                        now = _now_ms()
                        if now - st >= int(MANUAL_PREREAD_TIMEOUT_SEC * 1000):
                            stop["value"] = True
                            break
                        read_size = MANUAL_PREREAD_FIRST_READ_BYTES if got <= 0 else MANUAL_PREREAD_CHUNK_BYTES
                        chunk = resp.read(min(read_size, expected - got))
                        if not chunk:
                            break
                        got += len(chunk)
                        with lock:
                            partial[idx] = got
                            if not stats.get("first_byte"):
                                stats["first_byte"] = now
                                _log("PKM_MANUAL_PREREAD_FRONT_FIRST_BYTE_V1449 seq=%s worker=%d block=%d first_byte_ms=%d source=%s" % (seq, int(worker_id), int(idx), int(now - st), source), xbmc.LOGINFO)
                            _publish_locked(False)
                with lock:
                    partial.pop(idx, None)
                    completed[idx] = got
                    if got < expected:
                        errors.append("short_block_%d_%d_of_%d" % (idx, got, expected))
                    _publish_locked(True)
            except Exception as exc:
                with lock:
                    partial.pop(idx, None)
                    if got > 0:
                        completed[idx] = got
                    errors.append("block_%d:%s" % (idx, repr(exc)))
                    _publish_locked(True)
                # Do not keep hammering if the first contiguous block times out.
                if idx == 0 and got <= 0:
                    stop["value"] = True
            finally:
                try:
                    q.task_done()
                except Exception:
                    pass

    try:
        _set_prop("PreReadMode", "v1452_parallel_contiguous_pause")
        _set_prop("PreReadSeq", seq)
        _set_prop("PreReadBytes", 0)
        _set_prop("PreReadPlannedBytes", planned)
        _set_prop("PreReadFrontReadyBytes", planned)
        _set_prop("PreReadFrontReady", "0")
        _set_prop("PreReadRange", "%d-%d" % (start, end))
        # Keep the instant marker if it is already ahead of current, but mark active/running.
        _set_prop("PreReadActive", "1")
        _set_prop("PreReadState", "front_running")
        _log("PKM_MANUAL_PREREAD_FRONT_START seq=%s range=%d-%d planned=%d current=%.3f duration=%.3f bitrate=%.3f display=osd_seekbar_overlay mode=v1463_faint_white_fast_start_smooth_parallel_contiguous workers=%d block_mb=%.1f chunk_kb=%d source=%s" % (seq, start, end, planned, float(current or 0.0), float(duration or 0.0), float(bitrate_mbps or 0.0), int(workers), float(block_bytes) / 1048576.0, int(MANUAL_PREREAD_CHUNK_BYTES // 1024), source), xbmc.LOGINFO)
        threads = []
        for i in range(workers):
            t = threading.Thread(target=_worker, args=(i,), name="PKMPreReadContigWorker%d" % i, daemon=True)
            t.daemon = True
            t.start()
            threads.append(t)
        while any(t.is_alive() for t in threads):
            if _get_prop("PreReadSeq", "") != str(seq):
                stop["value"] = True
                break
            if _now_ms() - st >= int(MANUAL_PREREAD_TIMEOUT_SEC * 1000):
                stop["value"] = True
                break
            xbmc.sleep(100)
        for t in threads:
            try:
                t.join(0.2)
            except Exception:
                pass
        with lock:
            _publish_locked(True)
            contig = int(stats.get("contig") or 0)
            wire = int(stats.get("wire") or 0)
        if contig >= planned:
            state = "ok"
        elif stop.get("value") and _get_prop("PreReadSeq", "") != str(seq):
            state = "superseded"
        elif errors:
            state = "read_error" if contig <= 0 else "short_read"
        else:
            state = "short_read" if contig > 0 else "empty"
        elapsed = max(0, _now_ms() - st)
        speed = (float(contig) / 1048576.0) / (float(elapsed) / 1000.0) if elapsed > 0 and contig > 0 else 0.0
        final_state = "front_ready" if state == "ok" else state
        _manual_preread_update_osd_cache(seq, start, contig, planned, size, final_state, source, speed)
        if state == "ok":
            _set_prop("PreReadFrontReady", "1")
            _set_prop("PreReadFrontReadyAtMs", _now_ms())
        _log("PKM_MANUAL_PREREAD_FRONT_DONE seq=%s state=%s bytes=%d wire_bytes=%d planned=%d elapsed_ms=%d contig_speed_mbps=%.3f workers=%d mode=v1463_faint_white_fast_start_smooth_parallel_contiguous errors=%d source=%s" % (seq, state, int(contig), int(wire), int(planned), int(elapsed), float(speed or 0.0), int(workers), len(errors), source), xbmc.LOGINFO if contig > 0 else xbmc.LOGWARNING)
        return state, contig, planned
    except Exception:
        elapsed = max(0, _now_ms() - st)
        _log("PKM_MANUAL_PREREAD_FRONT_FAILED seq=%s elapsed_ms=%d source=%s\n%s" % (seq, elapsed, source, traceback.format_exc()), xbmc.LOGERROR)
        return "failed", int(stats.get("contig") or 0), planned

def _manual_preread_read_front_with_dialog(url, token, start, end, seq, source, current, duration, bitrate_mbps):
    # v1449 playback profile: linear single-stream cache warmer.
    # Pause can use the separate multi-worker contiguous profile; playback remains
    # a single stream to avoid starving Kodi video playback.
    st = _now_ms()
    start = int(start)
    end = int(end)
    planned = max(0, end - start + 1)
    if planned <= 0:
        return "empty", 0, 0
    total = 0
    state = "running"
    last_log = st
    last_publish = st
    size = _get_int("PreReadFileSize", 0)
    try:
        _set_prop("PreReadMode", "v1459_smooth_linear_to_eof_single_osd_bar")
        _set_prop("PreReadSeq", seq)
        _set_prop("PreReadBytes", 0)
        _set_prop("PreReadPlannedBytes", planned)
        _set_prop("PreReadFrontReadyBytes", planned)
        _set_prop("PreReadFrontReady", "0")
        _set_prop("PreReadRange", "%d-%d" % (start, end))
        _manual_preread_update_osd_cache(seq, start, 0, planned, size, "front_running", source, 0.0)
        _log("PKM_MANUAL_PREREAD_FRONT_START seq=%s range=%d-%d planned=%d current=%.3f duration=%.3f bitrate=%.3f display=osd_seekbar_overlay mode=v1463_faint_white_fast_start_smooth_linear_to_eof stream=single chunk_kb=%d source=%s" % (seq, start, end, planned, float(current or 0.0), float(duration or 0.0), float(bitrate_mbps or 0.0), int(MANUAL_PREREAD_CHUNK_BYTES // 1024), source), xbmc.LOGINFO)
        u = _with_plex_token(url, token)
        req = urllib.request.Request(u, method="GET", headers={"Range": "bytes=%d-%d" % (int(start), int(end))})
        with urllib.request.urlopen(req, timeout=MANUAL_PREREAD_SOCKET_TIMEOUT_SEC) as resp:
            while total < planned:
                if _get_prop("PreReadSeq", "") != str(seq):
                    state = "superseded"
                    break
                now = _now_ms()
                if now - st >= int(MANUAL_PREREAD_TIMEOUT_SEC * 1000):
                    state = "timeout"
                    break
                try:
                    read_size = MANUAL_PREREAD_FIRST_READ_BYTES if total <= 0 else MANUAL_PREREAD_CHUNK_BYTES
                    chunk = resp.read(min(read_size, planned - total))
                except Exception:
                    state = "read_error"
                    break
                if not chunk:
                    state = "ok" if total > 0 else "empty"
                    break
                total += len(chunk)
                now = _now_ms()
                elapsed = max(1, now - st)
                speed = (float(total) / 1048576.0) / (float(elapsed) / 1000.0) if total > 0 else 0.0
                # v1459: publish the first 1KB immediately, then keep the early
                # fill smooth before falling back to a light cadence.
                if total <= MANUAL_PREREAD_EARLY_SMOOTH_BYTES or now - last_publish >= 180:
                    last_publish = now
                    _manual_preread_update_osd_cache(seq, start, total, planned, size, "front_running", source, speed)
                pct = int(max(0, min(100, round((float(total) / float(planned or 1)) * 100.0))))
                if now - last_log >= 5000 or pct >= 100:
                    last_log = now
                    _manual_preread_update_osd_cache(seq, start, total, planned, size, "front_running", source, speed)
                    nib = _get_prop("PreReadCacheNibIndex", "0")
                    cache_pct = _get_prop("PreReadCacheEndPercent", "0")
                    _log("PKM_MANUAL_PREREAD_FRONT_PROGRESS seq=%s percent=%d cache_nib=%s cache_end_percent=%s bytes=%d planned=%d elapsed_ms=%d speed_mbps=%.3f workers=1 display=osd_seekbar_overlay mode=v1463_faint_white_fast_start_smooth_linear_to_eof stream=single source=%s" % (seq, pct, nib, cache_pct, int(total), int(planned), int(now - st), speed, source), xbmc.LOGINFO)
                if MANUAL_PREREAD_SLEEP_MS > 0:
                    try:
                        xbmc.sleep(int(MANUAL_PREREAD_SLEEP_MS))
                    except Exception:
                        pass
        if state == "running":
            state = "ok" if total >= planned else "short_read"
        ready = state == "ok" and total >= planned and planned > 0
        final_state = "front_ready" if ready else state
        elapsed = max(0, _now_ms() - st)
        speed = (float(total) / 1048576.0) / (float(elapsed) / 1000.0) if elapsed > 0 and total > 0 else 0.0
        _manual_preread_update_osd_cache(seq, start, total, planned, size, final_state, source, speed)
        if ready:
            _set_prop("PreReadFrontReady", "1")
            _set_prop("PreReadFrontReadyAtMs", _now_ms())
        _log("PKM_MANUAL_PREREAD_FRONT_DONE seq=%s state=%s ready=%s bytes=%d planned=%d elapsed_ms=%d speed_mbps=%.3f range=%d-%d display=osd_seekbar_overlay mode=v1463_faint_white_fast_start_smooth_linear_to_eof stream=single source=%s" % (seq, state, "1" if ready else "0", int(total), int(planned), int(elapsed), float(speed or 0.0), int(start), int(end), source), xbmc.LOGINFO if total > 0 else xbmc.LOGWARNING)
        return state, total, planned
    except Exception:
        elapsed = max(0, _now_ms() - st)
        _log("PKM_MANUAL_PREREAD_FRONT_FAILED seq=%s elapsed_ms=%d source=%s\n%s" % (seq, elapsed, source, traceback.format_exc()), xbmc.LOGERROR)
        return "failed", total, planned

def cancel_manual_preread(reason=""):
    """Cancel the active pre-read.

    v1449 keeps the last pale-yellow cache fill while restarting after seek, but
    clears it on real playback stop/end so the next movie never inherits stale
    cache state.
    """
    try:
        seq = str(_now_ms())
        reason_s = str(reason or "")
        _set_prop("PreReadSeq", "cancel_" + seq)
        _set_prop("PreReadState", "cancelled")
        _set_prop("PreReadCancelReason", reason_s)
        clear_all = any(k in reason_s for k in ("Stopped", "Ended", "Shutdown", "shutdown", "stopped", "ended"))
        if clear_all:
            _manual_preread_clear_cache_props(reason=reason_s)
            try:
                _clear_prop("PreReadMediaKey")
            except Exception:
                pass
        else:
            # v1452: seek/force-restart cancellation only stops the worker. Keep
            # the visual cache overlay alive until the replacement reader publishes
            # a new absolute end.  This prevents the bar from disappearing on -30s.
            _set_prop("PreReadActive", "1")
        _log("PKM_MANUAL_PREREAD_CANCEL reason=%s seq=%s clear=%s" % (reason_s, seq, "1" if clear_all else "0"), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def manual_preread(params=None):
    """Continuous cache warmer.

    v1449: the cache button is gone. Playback start/resume keeps a single
    linear warmer. Pause restarts with a 3-worker contiguous
    profile and an instant visible marker. Seek restarts from the new position.
    No DialogProgress, no text label, no player.seekTime().
    """
    params = params or {}
    source = str(params.get("source", "pause_auto_preread") or "pause_auto_preread")
    try:
        force_restart_arg = str(params.get("force_restart", "0") or "0").lower()
        force_restart = force_restart_arg in ("1", "true", "yes", "on")
    except Exception:
        force_restart = False
    try:
        _w = xbmcgui.Window(10000)
        if (
            _w.getProperty("PlexKM.Playback.ReturnFade.Stopping") == "1"
            or _w.getProperty("PlexKM.Playback.ReturnFade.SuppressPreread") == "1"
            or _w.getProperty("PlexKM.Playback.BackStopRequested") == "1"
        ):
            cancel_manual_preread(reason="ReturnFadeStoppedManualPrereadSkipV1499_%s" % source)
            _log("PKM_MANUAL_PREREAD_SKIP_RETURN_FADE_V1499 source=%s reason=return_fade_stop" % source, xbmc.LOGINFO)
            return False
    except Exception:
        pass
    try:
        _state_now = _get_prop("PreReadState", "")
        _active_now = _get_prop("PreReadActive", "")
        if _active_now == "1" and _state_now in ("instant_pending", "start", "front_running", "running"):
            if force_restart:
                cancel_manual_preread(reason="force_restart_%s" % source)
                prime_preread_visible_marker(reason="force_restart_%s" % source, extra_nib=1)
            else:
                _log("PKM_MANUAL_PREREAD_ALREADY_RUNNING state=%s seq=%s source=%s" % (_state_now, _get_prop("PreReadSeq", ""), source), xbmc.LOGINFO)
                return False
    except Exception:
        pass
    if not MANUAL_PREREAD_ENABLED:
        _log("PKM_MANUAL_PREREAD_SKIP reason=disabled source=%s" % source, xbmc.LOGWARNING)
        return False
    paused_by_pkm = False
    was_paused = False
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            _log("PKM_MANUAL_PREREAD_SKIP reason=not_playing_video source=%s" % source, xbmc.LOGWARNING)
            return False
        current = float(player.getTime() or 0.0)
        duration = float(player.getTotalTime() or 0.0)
        raw_url = _current_playing_url(player)
        url, url_src = _resolve_preread_http_url(raw_url, reason="manual_preread_%s" % source)
        if not url or not str(url).lower().startswith(("http://", "https://")):
            _log("PKM_MANUAL_PREREAD_SKIP reason=not_http_v1455 raw_url=%s resolved_url=%s resolved_src=%s source=%s" % (str(raw_url or "")[:180], str(url or "")[:180], str(url_src), source), xbmc.LOGWARNING)
            return False
        if str(raw_url or "") != str(url or ""):
            _log("PKM_MANUAL_PREREAD_HTTP_RESOLVED_V1455 raw_kind=%s resolved_src=%s http=%s source=%s" % (("plugin" if str(raw_url or "").lower().startswith("plugin://") else "other"), str(url_src), str(url or "")[:180], source), xbmc.LOGINFO)
        token = _get_plex_token_from_settings()
        # v1463: do not do duplicate pre-read probes.  Older code detected
        # bitrate first, then separately probed Content-Length again before
        # starting the Range reader.  That made pause look idle for several
        # seconds on Plex/rclone/GDrive.  Get size once, derive bitrate from
        # size/duration, and start the actual Range read immediately.
        size, size_src = _get_cached_or_probe_size(url, token)
        if duration > 1.0 and size > 0:
            try:
                br = (float(size) * 8.0) / float(duration) / 1000000.0
                br_src = "size_duration_fast_v1463_%s" % str(size_src or "size")
                _set_prop("DynamicBitrateUrl", url)
                _set_prop("DynamicBitrateAtMs", _now_ms())
                _set_prop("DynamicBitrateMbps", "%.3f" % float(br or 0.0))
                _set_prop("DynamicBitrateSource", br_src)
                _set_prop("DynamicBitrateSizeBytes", int(size))
            except Exception:
                br, br_src = _detect_bitrate_mbps(player=player, duration=duration, reason="manual_preread_v1463_fallback", allow_probe=True)
        else:
            br, br_src = _detect_bitrate_mbps(player=player, duration=duration, reason="manual_preread_v1463_fallback", allow_probe=True)
        if duration <= 1.0 or size <= 0:
            _log("PKM_MANUAL_PREREAD_SKIP reason=no_duration_or_size duration=%.3f size=%d br_src=%s size_src=%s source=%s" % (duration, int(size or 0), br_src, size_src, source), xbmc.LOGWARNING)
            return False
        _manual_preread_reset_if_media_changed(url, size, source=source)
        front_ratio = 0.0
        front_bytes_override = 0
        try:
            front_mb_arg = float(params.get("front_mb", params.get("mb", 0)) or 0)
            if front_mb_arg > 0:
                front_bytes_override = int(front_mb_arg * 1024.0 * 1024.0)
        except Exception:
            front_bytes_override = 0
        try:
            # v1441/v1440: keep preread bounded by default.  Older VideoOSD XML passed
            # front_ratio=0.3333, which re-expanded the target to 1/3 of the file.
            # Only honor ratio when explicitly requested with profile=ratio.
            profile_arg = str(params.get("profile", "") or "").lower()
            ratio_arg = float(params.get("front_ratio", params.get("ratio", 0)) or 0)
            if profile_arg in ("ratio", "front_ratio", "full_ratio") and ratio_arg > 0.01 and ratio_arg < 0.95:
                front_ratio = ratio_arg
        except Exception:
            front_ratio = 0.0
        try:
            ahead_sec = float(params.get("ahead", params.get("ahead_sec", MANUAL_PREREAD_START_AHEAD_SEC)) or MANUAL_PREREAD_START_AHEAD_SEC)
        except Exception:
            ahead_sec = MANUAL_PREREAD_START_AHEAD_SEC
        start_time = min(max(0.0, current + max(0.0, ahead_sec)), max(0.0, duration - 1.0))
        start = int(float(size) * (start_time / duration))

        # v1469/v1470: if an earlier same-media Range read already cached farther than
        # the current playback byte, do not re-read the already cached span after
        # Pause.  v1468 was monotonic, but Pause often started at the playback
        # byte (for example 14MB) while onAVStarted had already cached up to a
        # larger absolute end (for example 67MB).  The OSD bar then stayed flat
        # until the new reader caught up to that old end.  Start from the largest
        # known real cache end so the next bytes extend the rclone cache
        # immediately and the cachebar can grow right away.
        try:
            preserved_end = _get_int("PreReadRealCacheEndBytes", 0)
            if preserved_end > int(start) and preserved_end < int(size) - 1:
                old_start = int(start)
                start = int(max(0, min(int(size) - 1, preserved_end)))
                range_time = (float(start) / float(size)) * float(duration) if float(size or 0) > 0 else start_time
                _log("PKM_MANUAL_PREREAD_START_ADVANCE_V1469 old_start=%d new_start=%d preserved_end=%d current=%.3f start_time=%.3f range_time=%.3f old_nib=%d source=%s" % (old_start, int(start), int(preserved_end), float(current or 0.0), float(start_time or 0.0), float(range_time or 0.0), int(_get_int("PreReadCacheNibIndex", 0)), source), xbmc.LOGINFO)
        except Exception:
            pass

        try:
            to_end_arg = str(params.get("to_end", params.get("full", "1")) or "1").lower()
            to_end = to_end_arg not in ("0", "false", "no", "off")
        except Exception:
            to_end = MANUAL_PREREAD_TO_EOF_DEFAULT
        if to_end:
            front_bytes = max(0, int(size) - start)
        elif front_bytes_override > 0:
            front_bytes = int(front_bytes_override)
        elif front_ratio > 0.0:
            front_bytes = int(float(size) * float(front_ratio))
        else:
            front_bytes = int(_manual_preread_bytes_for_bitrate(br))
            front_bytes = int(max(MANUAL_PREREAD_MIN_BYTES, front_bytes))
        if start + front_bytes > int(size):
            front_bytes = max(0, int(size) - start)
        end_front = min(max(0, int(size) - 1), start + max(0, int(front_bytes)) - 1)
        # v1449: one linear continuous range from the current point to EOF. No separate tail thread.
        tail_start = int(size)
        tail_end = 0
        if end_front <= start:
            _log("PKM_MANUAL_PREREAD_SKIP reason=bad_front_range start=%d end=%d size=%d current=%.3f duration=%.3f source=%s" % (start, end_front, int(size), current, duration, source), xbmc.LOGWARNING)
            return False
        seq = str(_now_ms())
        _set_prop("PreReadSeq", seq)
        _set_prop("PreReadSource", source)
        _set_prop("PreReadUrl", str(url)[:240])
        _set_prop("PreReadStartTime", "%.3f" % start_time)
        _set_prop("PreReadCurrentTime", "%.3f" % current)
        _set_prop("PreReadDuration", "%.3f" % duration)
        _set_prop("PreReadFileSize", int(size))
        _log("PKM_MANUAL_PREREAD_START seq=%s mode=v1463_faint_white_fast_start_smooth_linear_to_eof ratio=%.4f current=%.3f start_time=%.3f duration=%.3f bitrate=%.3f br_src=%s size=%d size_src=%s front_range=%d-%d tail_range=%d-%d source=%s" % (seq, float(front_ratio), current, start_time, duration, float(br or 0.0), br_src, int(size), size_src, start, end_front, tail_start, tail_end, source), xbmc.LOGINFO)
        try:
            was_paused = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            was_paused = False
        paused_by_pkm = False
        try:
            # v1446: OSD cache button is removed. Service calls this while already paused; explicit button callers may still request auto_pause.
            pause_arg = str(params.get("pause", params.get("auto_pause", "1")) or "1").lower()
            auto_pause = pause_arg in ("1", "true", "yes", "on")
        except Exception:
            auto_pause = False
        if auto_pause and not was_paused:
            paused_by_pkm, _pause_confirmed = _manual_preread_pause_player(seq, source)
            if not _pause_confirmed:
                _log("PKM_MANUAL_PREREAD_PAUSE_CONFIRM_FAILED seq=%s continue_anyway=1 source=%s" % (seq, source), xbmc.LOGWARNING)
        else:
            _log("PKM_MANUAL_PREREAD_NO_PAUSE seq=%s was_paused=%s source=%s" % (seq, "1" if was_paused else "0", source), xbmc.LOGINFO)
        try:
            paused_now_for_workers = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            paused_now_for_workers = was_paused
        try:
            workers_arg = int(params.get("workers", 0) or 0)
        except Exception:
            workers_arg = 0
        if workers_arg <= 0:
            workers_arg = MANUAL_PREREAD_PARALLEL_WORKERS_PAUSED if paused_now_for_workers else MANUAL_PREREAD_PARALLEL_WORKERS_PLAYING
        workers_arg = int(max(1, min(4, workers_arg)))
        if workers_arg > 1:
            state, read_bytes, planned = _manual_preread_read_front_parallel_contiguous(url, token, start, end_front, seq, source, current, duration, br, workers=workers_arg)
        else:
            state, read_bytes, planned = _manual_preread_read_front_with_dialog(url, token, start, end_front, seq, source, current, duration, br)
        ready = state == "ok" and read_bytes >= planned and planned > 0
        if ready:
            if tail_start <= tail_end:
                try:
                    _set_prop("PreReadState", "front_ready_tail_running")
                    t = threading.Thread(target=_manual_preread_tail_worker, args=(url, token, tail_start, tail_end, seq, source, current, duration, br), name="PKMManualPreReadTail", daemon=True)
                    t.daemon = True
                    t.start()
                except Exception:
                    _log("PKM_MANUAL_PREREAD_TAIL_THREAD_FAILED seq=%s source=%s\n%s" % (seq, source, traceback.format_exc()), xbmc.LOGWARNING)
        try:
            auto_resume_arg = str(params.get("resume", params.get("auto_resume", "1")) or "1").lower()
            auto_resume = auto_resume_arg not in ("0", "false", "no", "off")
        except Exception:
            auto_resume = True
        if auto_resume and paused_by_pkm and player.isPlayingVideo():
            if not _manual_preread_resume_player(seq, source, ready):
                _log("PKM_MANUAL_PREREAD_RESUME_FAILED seq=%s source=%s" % (seq, source), xbmc.LOGWARNING)
        _log("PKM_MANUAL_PREREAD_RETURN seq=%s ready=%s state=%s read=%d planned=%d paused_by_pkm=%s mode=v1463_faint_white_fast_start_smooth_linear_to_eof source=%s" % (seq, "1" if ready else "0", state, int(read_bytes), int(planned), "1" if paused_by_pkm else "0", source), xbmc.LOGINFO)
        return bool(ready)
    except Exception:
        _log("PKM_MANUAL_PREREAD_FAILED source=%s\n%s" % (source, traceback.format_exc()), xbmc.LOGERROR)
        try:
            if paused_by_pkm and xbmc.Player().isPlayingVideo() and xbmc.getCondVisibility("Player.Paused"):
                _manual_preread_resume_player("unknown", source, False)
        except Exception:
            pass
        return False



def _video_osd_subdialog_active_v1943():
    """Return True while a child OSD/settings dialog owns the user's attention."""
    # v1945: PKM's subtitle/audio/video WindowXMLDialog windows are custom
    # plugin dialogs, so Kodi's native Window.IsVisible(osd*settings) names do
    # not detect them.  Their openers publish this explicit session property.
    if _get_osd_prop("ChildDialogActive") == "1":
        return True
    for cond in (
        "Window.IsVisible(SliderDialog)",
        "Window.IsVisible(1110)",
        "Window.IsVisible(osdaudiosettings)",
        "Window.IsVisible(osdvideosettings)",
        "Window.IsVisible(VideoBookmarks)",
        "Window.IsVisible(playerprocessinfo)",
        "Window.IsVisible(osdcmssettings)",
        "Window.IsVisible(PVROSDChannels)",
        "Window.IsVisible(pvrchannelguide)",
    ):
        if _bool_cond(cond):
            return True
    return False


def _video_osd_focus_token_v1943():
    """Small stable token used only to detect real OSD navigation activity."""
    for cid in (87, 602, 612, 617, 613, 611, 614, 615, 620, 621,
                622, 630, 631, 632, 633, 634, 635, 636, 637,
                638, 639, 640, 641):
        try:
            if _bool_cond("Control.HasFocus(%d)" % cid):
                return str(cid)
        except Exception:
            pass
    return ""


def _clear_video_osd_autoclose_v1943(reason=""):
    for name in ("AutoCloseAtMs", "AutoCloseLastMs", "AutoCloseFocus",
                 "AutoClosing", "AutoCloseForceAtMs", "AutoCloseReason",
                 "AutoCloseArmed", "AutoCloseCancelled", "AutoCloseInitialFocus",
                 "NoAutoClose", "ChildReturnPendingV2326",
                 "ChildReturnAutoCloseV2326", "ChildReturnFocusV2326"):
        _clear_osd_prop(name)
    if reason:
        _log("PKM_VIDEOOSD_AUTOCLOSE_CLEAR_V1943 reason=%s" % reason, xbmc.LOGINFO)


def _start_video_osd_autoclose_watchdog_v1961(reason="initial_enter"):
    """Close one untouched OSD session after 3s even if service polling stalls."""
    token = "%d-%d" % (_now_ms(), threading.get_ident())
    _set_osd_prop("AutoCloseSessionV1961", token)
    _set_osd_prop("AutoCloseAtMs", _now_ms() + OSD_AUTO_CLOSE_MS_V1943)
    _log("PKM_VIDEOOSD_AUTOCLOSE_WATCHDOG_ARM_V1961 session=%s reason=%s timeout_ms=%d" % (token, reason, OSD_AUTO_CLOSE_MS_V1943), xbmc.LOGINFO)

    def _worker():
        monitor = xbmc.Monitor()
        if monitor.waitForAbort(float(OSD_AUTO_CLOSE_MS_V1943) / 1000.0):
            return
        try:
            same = _get_osd_prop("AutoCloseSessionV1961") == token
            armed = _get_osd_prop("AutoCloseArmed") == "1"
            cancelled = _get_osd_prop("AutoCloseCancelled") == "1" or _get_osd_prop("NoAutoClose") == "1"
            visible = _is_video_osd_visible()
            child = _video_osd_subdialog_active_v1943() or _get_prop("StepMenuVisible") == "1"
            focus = _video_osd_focus_token_v1943()
            _log("PKM_VIDEOOSD_AUTOCLOSE_WATCHDOG_FIRE_V1961 session=%s same=%d armed=%d cancelled=%d visible=%d child=%d focus=%s" % (token, int(same), int(armed), int(cancelled), int(visible), int(child), focus or "-"), xbmc.LOGINFO)
            if same and armed and not cancelled and visible and not child and (not focus or focus == "602"):
                _close_video_osd_smooth_v1943("initial_enter_idle_3000ms_v1961")
                _log("PKM_VIDEOOSD_AUTOCLOSE_WATCHDOG_CLOSE_V1961 session=%s" % token, xbmc.LOGINFO)
        except Exception:
            _log("PKM_VIDEOOSD_AUTOCLOSE_WATCHDOG_FAILED_V1961 session=%s\n%s" % (token, traceback.format_exc()), xbmc.LOGWARNING)

    threading.Thread(target=_worker, name="PKMVideoOSDAutoCloseV1961", daemon=True).start()
    return token


def _close_video_osd_smooth_v1943(reason="timeout"):
    """Close the real VideoOSD with its WindowClose fade; never touch playback."""
    if _get_osd_prop("AutoClosing") == "1":
        return True
    now = _now_ms()
    _set_osd_prop("AutoClosing", "1")
    _set_osd_prop("AutoCloseForceAtMs", now + OSD_AUTO_CLOSE_FORCE_MS_V1943)
    try:
        # No second 'true' argument: Kodi runs VideoOSD.xml WindowClose animation.
        xbmc.executebuiltin("Dialog.Close(videoosd)")
        _log("PKM_VIDEOOSD_AUTOCLOSE_BEGIN_V1944 reason=%s fade_ms=220 playback_action=none" % reason, xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_VIDEOOSD_AUTOCLOSE_BEGIN_FAILED_V1944 reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
        return False


def _is_video_osd_visible():
    # v1375: Kodi can keep reporting FullscreenVideo while the custom VideoOSD
    # XML is displayed.  VideoOSD.xml now sets this global property on load and
    # clears it on unload, so the dispatcher can decide reliably.
    try:
        if _get_osd_prop("Visible") == "1":
            return True
    except Exception:
        pass
    for cond in (
        "Window.IsActive(videoosd)",
        "Window.IsVisible(videoosd)",
        "Window.IsActive(fullscreeninfo)",
        "Window.IsVisible(fullscreeninfo)",
        "Window.Property(PlexKM.PlayerOSD.Visible)",
    ):
        if _bool_cond(cond):
            return True
    return False


def _clear_seek_suppression_for_osd(reason=""):
    # v1375: after a quick seek, VideoOSD.xml used to stay hidden by
    # PlexKM.SeekQuick.Active/SuppressOsd and Player.HasPerformedSeek.  ENTER
    # must override that immediately so the first ENTER opens the play-button OSD.
    for name in (
        "Pending", "Active", "Committing", "SuppressOsd", "HideAtMs",
        "HideOsdAtMs", "CommitAtMs", "State", "LastError", "UseVideoOSD",
        "TargetSec", "TargetLabel", "TargetSimpleLabelV2231", "TimeBubbleIndexV2231",
        "ScrubStepSecV2231", "ScrubStepModeV2231", "TargetPercent", "CurrentSec", "CurrentLabel",
        "DurationSec", "DurationLabel", "TargetHoldUntilMs",
    ):
        _clear_prop(name)
    if reason:
        _log("PKM_PLAYER_OSD_SEEK_SUPPRESS_CLEAR reason=%s" % reason, xbmc.LOGINFO)


# R36: five call sites (handle_player_key, request, service_tick) referenced
# these two helpers, but neither existed, so each call raised NameError.  In
# handle_player_key (UP/DOWN with the seek overlay up) that aborted the key
# before _execute_action().  Restore them on top of the existing clear set.
def _clear_runtime_props(reason=""):
    _clear_seek_suppression_for_osd(reason=reason or "runtime_clear_r36")


def _clear_target_props(reason=""):
    for name in ("TargetSec", "TargetLabel", "TargetSimpleLabelV2231", "TimeBubbleIndexV2231",
                 "TargetPercent", "TargetHoldUntilMs"):
        _clear_prop(name)
    if reason:
        _log("PKM_SEEK_QUICK_TARGET_CLEAR_R36 reason=%s" % reason, xbmc.LOGINFO)



def _seek_overlay_active():
    try:
        return (_get_prop("Active") == "1") or bool(_get_prop("TargetLabel", "")) or bool(_get_prop("TargetPercent", ""))
    except Exception:
        return False


def _arm_osd_nav(reason="", ttl_ms=None, extend=True):
    now = _now_ms()
    try:
        ttl = int(ttl_ms if ttl_ms is not None else OSD_NAV_TTL_MS)
    except Exception:
        ttl = OSD_NAV_TTL_MS
    old_until = _get_osd_int("NavUntilMs", 0)
    new_until = now + max(900, ttl)
    if not extend and old_until > 0:
        new_until = old_until
    _set_osd_prop("NavMode", "1")
    _set_osd_prop("NavUntilMs", new_until)
    _set_osd_prop("NavLastMs", now)
    if not _get_osd_prop("NavOpenedMs", "") or str(reason or "").startswith("enter_open"):
        _set_osd_prop("NavOpenedMs", now)
    if reason:
        _set_osd_prop("NavReason", reason)
    return True


def _clear_osd_nav(reason=""):
    _clear_osd_prop("NavMode")
    _clear_osd_prop("NavUntilMs")
    _clear_osd_prop("NavLastMs")
    _clear_osd_prop("NavOpenedMs")
    _clear_osd_prop("NavReason")
    if reason:
        _log("PKM_PLAYER_OSD_NAV_CLEAR reason=%s" % reason)


def _is_osd_nav_active():
    now = _now_ms()
    if _is_video_osd_visible():
        return True
    if _get_osd_prop("NavMode") != "1":
        return False
    until = _get_osd_int("NavUntilMs", 0)
    if until > 0 and now > until:
        _clear_osd_nav("expired")
        return False
    return True


def _allow_hidden_osd_nav(key, now=None):
    """Allow nav without visible condition only for the short Enter-open grace.

    Kodi often reports Window.IsActive(videoosd)=0 even while the Plex OSD is
    freshly opened.  v1372 kept that mode for 7 seconds and every RIGHT key
    re-armed it, so fullscreen seek was swallowed.  v1375 keeps only a short
    non-extending grace after ENTER; once it expires, LEFT/RIGHT are seek again.
    """
    now = _now_ms() if now is None else now
    if _get_osd_prop("NavMode") != "1":
        return False
    until = _get_osd_int("NavUntilMs", 0)
    if until > 0 and now > until:
        _clear_osd_nav("hidden_expired")
        return False
    opened = _get_osd_int("NavOpenedMs", 0)
    if opened <= 0:
        return False
    # After ENTER, immediate arrows should move the OSD.  Do not allow this
    # hidden mode to be extended by repeated LEFT/RIGHT, otherwise fullscreen
    # seek never returns.
    if now - opened <= OSD_NAV_TTL_MS:
        return True
    return False


def _action_name(key):
    key = (key or "").lower()
    if key == "left":
        return "Left"
    if key == "right":
        return "Right"
    if key == "up":
        return "Up"
    if key == "down":
        return "Down"
    if key in ("enter", "return", "select"):
        return "Select"
    return ""


def _execute_action(action, reason=""):
    # v1438: restore UI Action() helper dropped in v1436.  Seek itself still uses direct Seek(seconds).
    if not action:
        return False
    try:
        xbmc.executebuiltin("Action(%s)" % action)
        if reason:
            _log("PKM_PLAYER_OSD_ACTION action=%s reason=%s" % (action, reason), xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_PLAYER_OSD_ACTION_FAILED action=%s reason=%s\n%s" % (action, reason, traceback.format_exc()), xbmc.LOGWARNING)
        return False


def _format_seek_action_delta(delta):
    try:
        d = float(delta or 0.0)
    except Exception:
        d = 0.0
    # Kodi built-in Seek(seconds) accepts signed seconds.  Use integer seconds for the
    # measured PKM table (+3/+5/-10).
    if abs(d - round(d)) < 0.001:
        return str(int(round(d)))
    return ("%.3f" % d).rstrip("0").rstrip(".")



def _clear_step_menu(reason=""):
    """Hide the VideoOSD +/-10/20/30 side selector.

    v1460: this is PKM state only; the visible buttons live in skin.plex.km
    VideoOSD.xml.  Selecting a side-menu button clears this state immediately.
    """
    try:
        for name in ("StepMenuVisible", "StepMenuDir", "StepMenuHideAtMs", "StepMenuFocusId", "StepMenuSource", "StepMenuCurrentSec"):
            _clear_prop(name)
        if reason:
            _log("PKM_SEEK_STEP_MENU_CLEAR_V1460 reason=%s" % reason, xbmc.LOGINFO)
    except Exception:
        _log("PKM_SEEK_STEP_MENU_CLEAR_FAILED_V1460 reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)


def show_step_menu(params=None):
    """Show the -10/-20/-30 or +10/+20/+30 selector next to the OSD seek icon.

    This does not change playback and does not use Python Player.play.  It only
    publishes Window(home) properties consumed by skin.plex.km/xml/VideoOSD.xml.
    The final selected button calls request(delta=...), which executes Kodi's
    native Seek(seconds) builtin.
    """
    params = params or {}
    direction_param = str(params.get("dir", params.get("direction", params.get("menu", ""))) or "").lower()
    if direction_param in ("left", "back", "backward", "prev", "rewind", "minus", "-"):
        menu_dir = "back"
        focus_id = "623"  # nearest -10s choice
    elif direction_param in ("right", "fwd", "forward", "next", "plus", "+"):
        menu_dir = "fwd"
        focus_id = "626"  # nearest +10s choice
    else:
        try:
            if _bool_cond("Control.HasFocus(620)"):
                menu_dir = "back"
                focus_id = "623"
            elif _bool_cond("Control.HasFocus(621)"):
                menu_dir = "fwd"
                focus_id = "626"
            else:
                menu_dir = "fwd"
                focus_id = "626"
        except Exception:
            menu_dir = "fwd"
            focus_id = "626"
    now = _now_ms()
    source = str(params.get("source", "step_menu") or "step_menu")
    current_step = _get_int("StepBackSec" if menu_dir == "back" else "StepFwdSec", 10)
    current_step = _normalize_manual_seek_step(current_step) or 10
    # v1463: when long-press opens the selector, do not show a duplicate
    # of the currently selected main seek step.  Focus the nearest visible
    # alternative so +30 opens as +10/+20, +10 opens as +20/+30, etc.
    if menu_dir == "fwd":
        if current_step == 10:
            focus_id = "636"  # v1465: +20 nearest collapsed option
        elif current_step == 20:
            focus_id = "638"  # v1465: +10 nearest collapsed option
        else:
            focus_id = "640"  # v1465: +10 nearest collapsed option
    else:
        if current_step == 10:
            focus_id = "630"  # v1465: -20 nearest collapsed option
        elif current_step == 20:
            focus_id = "632"  # v1465: -10 nearest collapsed option
        else:
            focus_id = "634"  # v1465: -10 nearest collapsed option
    _set_prop("UseVideoOSD", "1")
    _set_prop("StepMenuVisible", "1")
    _set_prop("StepMenuDir", menu_dir)
    _set_prop("StepMenuFocusId", focus_id)
    _set_prop("StepMenuCurrentSec", current_step)
    _set_prop("StepMenuHideAtMs", now + 6500)
    _set_prop("StepMenuSource", source)
    _set_osd_prop("FocusSeekBar", "")
    try:
        _clear_seek_suppression_for_osd("step_menu_show_v1460")
    except Exception:
        pass
    try:
        xbmc.executebuiltin("SetFocus(%s)" % focus_id)
    except Exception:
        pass
    _log("PKM_SEEK_STEP_MENU_SHOW_V1465 dir=%s focus_id=%s current=%s source=%s collapsed=1 hq20=1" % (menu_dir, focus_id, str(current_step), source), xbmc.LOGINFO)
    return True

def _execute_native_seek_seconds(delta, seq=0, source="", target=0.0, duration=0.0):
    action_delta = _format_seek_action_delta(delta)
    if action_delta in ("", "0", "-0"):
        _log("PKM_NATIVE_SEEK_SECONDS_SKIP seq=%s reason=zero_delta source=%s" % (seq, source), xbmc.LOGWARNING)
        return False
    action = "Seek(%s)" % action_delta
    try:
        r61_note_seek(float(delta or 0.0))
    except Exception:
        pass
    st = _now_ms()
    _log("PKM_NATIVE_SEEK_SECONDS_BEGIN seq=%s builtin=%s delta=%s target=%.3f duration=%.3f source=%s" % (seq, action, action_delta, float(target or 0.0), float(duration or 0.0), source), xbmc.LOGINFO)
    ok = False
    try:
        # v1431: Seek(seconds) is a Kodi player built-in, not an Action() wrapper.
        # v1430 used Action(Seek(n)); Kodi accepted the call but did not move playback.
        xbmc.executebuiltin(action)
        _log("PKM_PLAYER_OSD_BUILTIN builtin=%s reason=native_seek_seconds_direct_%s" % (action, source or "unknown"), xbmc.LOGINFO)
        ok = True
    except Exception:
        _log("PKM_PLAYER_OSD_BUILTIN_FAILED builtin=%s reason=native_seek_seconds_direct_%s\n%s" % (action, source or "unknown", traceback.format_exc()), xbmc.LOGWARNING)
        ok = False
    elapsed = max(0, _now_ms() - st)
    _log("PKM_NATIVE_SEEK_SECONDS_DONE seq=%s builtin=%s ok=%s elapsed_ms=%d source=%s" % (seq, action, "1" if ok else "0", elapsed, source), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok


def _focus_seekbar_when_osd_opens(reason=""):
    """Ask VideoOSD.xml to focus the seek bar, then try one direct SetFocus.

    Kodi sometimes reports FullscreenVideo while VideoOSD is visually open.  The
    property is consumed by VideoOSD onload, and the delayed SetFocus covers the
    case where the window opens a few frames after Action(OSD).
    """
    try:
        _set_osd_prop("FocusSeekBar", "1")
        _set_osd_nib_from_player(reason="focus_seekbar_%s" % (reason or "open"))
        xbmc.sleep(OSD_SEEKBAR_FOCUS_DELAY_MS)
        xbmc.executebuiltin("SetFocus(87)")
        if reason:
            _log("PKM_PLAYER_OSD_FOCUS_SEEKBAR reason=%s" % reason, xbmc.LOGINFO)
        return True
    except Exception:
        _log("PKM_PLAYER_OSD_FOCUS_SEEKBAR_FAILED reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
        return False


def handle_player_key(params=None):
    """Dispatch playback keys from FullscreenVideo.

    Kodi often keeps the active window as FullscreenVideo even while the native
    play-button strip is visibly displayed.  Because of that a pure <VideoOSD>
    keymap cannot reliably take over after seek.  This dispatcher arms an OSD
    navigation mode when ENTER opens the OSD; while that mode is active, arrows
    send native navigation actions instead of quick seek.
    """
    params = params or {}
    key = str(params.get("key", params.get("action", "")) or "").lower()
    now = _now_ms()
    try:
        player = xbmc.Player()
        playing_video = player.isPlayingVideo()
    except Exception:
        playing_video = False
    if not playing_video:
        _clear_osd_nav("not_playing_video")
        _log("PKM_PLAYER_KEY_SKIP reason=not_playing_video key=%s params=%s" % (key, params), xbmc.LOGINFO)
        return False
    try:
        _pkm_duration_for_steps = float(player.getTotalTime() or 0.0)
        _ensure_player_overlay_meta(player=player, duration=_pkm_duration_for_steps, reason="player_key")
        _publish_dynamic_seek_steps(player=player, duration=_pkm_duration_for_steps, reason="player_key")
    except Exception:
        pass

    visible = _is_video_osd_visible()
    nav_active = _is_osd_nav_active()
    hidden_nav_allowed = (not visible) and _allow_hidden_osd_nav(key, now)

    if key in ("space", "playpause", "pause", "play"):
        # v1421: Space/PlayPause must keep Kodi's native pause/play behavior,
        # but always bring up the real VideoOSD so the user gets the same Plex
        # style feedback as remote select/enter.  Do not seek, stop, or replay.
        _clear_seek_suppression_for_osd("space_playpause_open_osd")
        _clear_osd_prop("FocusSeekBar")
        _set_osd_prop("NoAutoClose", "1")
        _set_osd_prop("AutoCloseCancelled", "1")
        _clear_osd_prop("AutoCloseArmed")
        _clear_osd_prop("AutoCloseAtMs")
        _arm_osd_nav("space_playpause_open_osd", ttl_ms=OSD_NAV_TTL_MS, extend=True)
        try:
            xbmc.executebuiltin("PlayerControl(Play)")
        except Exception:
            pass
        xbmc.sleep(80)
        _log("PKM_PLAYER_KEY_PLAYPAUSE_OSD_V1421 key=%s visible=%s nav_active=%s" % (key, "1" if visible else "0", "1" if nav_active else "0"), xbmc.LOGINFO)
        return _execute_action("OSD", "space_playpause_open_osd")

    if key in ("longselect", "longenter", "longreturn", "select_longpress", "enter_longpress"):
        if visible and _bool_cond("Control.HasFocus(620)"):
            _log("PKM_PLAYER_KEY_LONGPRESS_STEP_MENU_V1460 key=%s dir=back focus=620" % key, xbmc.LOGINFO)
            return show_step_menu({"dir": "back", "source": "videoosd_longpress_select_back"})
        if visible and _bool_cond("Control.HasFocus(621)"):
            _log("PKM_PLAYER_KEY_LONGPRESS_STEP_MENU_V1460 key=%s dir=fwd focus=621" % key, xbmc.LOGINFO)
            return show_step_menu({"dir": "fwd", "source": "videoosd_longpress_select_fwd"})
        _log("PKM_PLAYER_KEY_LONGPRESS_IGNORED_V1460 key=%s visible=%s focus620=%s focus621=%s" % (key, "1" if visible else "0", "1" if _bool_cond("Control.HasFocus(620)") else "0", "1" if _bool_cond("Control.HasFocus(621)") else "0"), xbmc.LOGINFO)
        return True

    if key in ("enter", "return", "select"):
        # v1375: ENTER in fullscreen must be deterministic.  If the real OSD is
        # already open, ENTER selects the focused OSD button.  If not, clear any
        # quick-seek suppression first and open OSD once.  Do not treat stale
        # hidden nav-grace as an existing OSD, because that made the first ENTER
        # after seek do nothing.
        if visible:
            # v1947: any explicit call reaching this legacy dispatcher while the
            # OSD is already visible is a real user selection. Native VideoOSD
            # ENTER normally bypasses this Python path entirely.
            _arm_osd_nav("select_existing_osd", ttl_ms=OSD_NAV_EXTEND_VISIBLE_MS, extend=True)
            _set_osd_prop("AutoCloseCancelled", "1")
            _clear_osd_prop("AutoCloseArmed")
            _clear_osd_prop("AutoCloseAtMs")
            _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1947 reason=select_existing_osd", xbmc.LOGINFO)
            _log("PKM_PLAYER_KEY_NAV_SELECT_V1947 key=%s visible=1 nav_active=%s hidden_grace=%s" % (key, "1" if nav_active else "0", "1" if hidden_nav_allowed else "0"), xbmc.LOGINFO)
            return _execute_action("Select", "osd_nav_select_v1947")
        if nav_active and not visible:
            _clear_osd_nav("enter_hidden_nav_stale_open_osd")
        _clear_seek_suppression_for_osd("enter_open_osd_v1944")
        _clear_osd_prop("FocusSeekBar")
        _clear_osd_prop("AutoCloseCancelled")
        _clear_osd_prop("NoAutoClose")
        _set_osd_prop("AutoCloseArmed", "1")
        _start_video_osd_autoclose_watchdog_v1961("initial_enter_untouched")
        _arm_osd_nav("enter_open_osd_v1944", ttl_ms=OSD_NAV_TTL_MS, extend=True)
        _log("PKM_PLAYER_KEY_OPEN_OSD_FALLBACK_V1944 key=%s visible=0 focus=602 playback_action=none" % key, xbmc.LOGINFO)
        return _execute_action("OSD", "open_osd_v1944")

    if key in ("up", "down", "left", "right"):
        if visible or hidden_nav_allowed:
            # v1386: when the real VideoOSD progress bar is selected, LEFT/RIGHT
            # must seek, not move to another OSD control.  This is the Plex flow:
            # UP selects bar -> LEFT/RIGHT seek -> DOWN returns to play buttons.
            if visible and key in ("left", "right") and _bool_cond("Control.HasFocus(87)"):
                dir_name = "back" if key == "left" else "fwd"
                _set_prop("UseVideoOSD", "1")
                _set_osd_prop("FocusSeekBar", "1")
                _arm_osd_nav("seekbar_seek_%s" % key, ttl_ms=OSD_NAV_EXTEND_VISIBLE_MS, extend=True)
                _log("PKM_PLAYER_KEY_SEEKBAR_SEEK key=%s dir=%s dynamic=1 visible=1 focus87=1" % (key, dir_name), xbmc.LOGINFO)
                return request({"dir": dir_name, "dynamic": "1", "source": "videoosd_seekbar_%s" % key, "use_videoosd": "1"})
            # Real OSD owns normal navigation.  Clear seek target props only for
            # non-seek navigation so a seek cannot leave a second overlay behind.
            if visible and not (key in ("left", "right") and _bool_cond("Control.HasFocus(87)")):
                if key in ("up", "down"):
                    _clear_runtime_props("real_osd_nav_clear_seek_overlay")
            # Visible OSD can extend navigation.  Hidden/grace mode must not be
            # extended, or fullscreen LEFT/RIGHT becomes permanently blocked.
            _arm_osd_nav("nav_%s" % key, ttl_ms=OSD_NAV_EXTEND_VISIBLE_MS if visible else OSD_NAV_TTL_MS, extend=bool(visible))
            if visible:
                _set_osd_prop("AutoCloseCancelled", "1")
                _clear_osd_prop("AutoCloseArmed")
                _clear_osd_prop("AutoCloseAtMs")
                _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1944 reason=nav_%s" % key, xbmc.LOGINFO)
            action = _action_name(key)
            _log("PKM_PLAYER_KEY_OSD_NAV key=%s action=%s visible=%s nav_active=%s hidden_grace=%s" % (key, action, "1" if visible else "0", "1" if nav_active else "0", "1" if hidden_nav_allowed else "0"), xbmc.LOGINFO)
            return _execute_action(action, "osd_nav_%s" % key)
        if nav_active and not visible:
            _clear_osd_nav("hidden_not_visible_seek_restore")
        if key in ("left", "right"):
            # v1380: fullscreen LEFT/RIGHT should show the same real VideoOSD as
            # ENTER, focus the progress bar, and then seek.  No separate
            # DialogSeekBar transport row is drawn.
            dir_name = "back" if key == "left" else "fwd"
            _set_prop("UseVideoOSD", "1")
            _set_osd_prop("FocusSeekBar", "1")
            _arm_osd_nav("fullscreen_seek_open_osd", ttl_ms=OSD_NAV_EXTEND_VISIBLE_MS, extend=True)
            _execute_action("OSD", "fullscreen_seek_open_osd")
            _focus_seekbar_when_osd_opens("fullscreen_seek_%s" % key)
            _log("PKM_PLAYER_KEY_SEEK_WITH_OSD key=%s dir=%s dynamic=1 visible=%s nav_active=%s hidden_grace=%s" % (key, dir_name, "1" if visible else "0", "1" if nav_active else "0", "1" if hidden_nav_allowed else "0"), xbmc.LOGINFO)
            return request({"dir": dir_name, "dynamic": "1", "source": "videoosd_seekbar_%s" % key, "use_videoosd": "1"})
        if key == "down" and _seek_overlay_active():
            _clear_seek_suppression_for_osd("down_from_seek_open_osd")
            _clear_osd_prop("FocusSeekBar")
            _arm_osd_nav("down_from_seek_open_osd", ttl_ms=OSD_NAV_TTL_MS, extend=True)
            _log("PKM_PLAYER_KEY_OPEN_OSD_FROM_SEEK key=down visible=0 nav_active=%s hidden_grace=%s" % ("1" if nav_active else "0", "1" if hidden_nav_allowed else "0"), xbmc.LOGINFO)
            return _execute_action("OSD", "down_from_seek_open_osd")
        _log("PKM_PLAYER_KEY_NOOP key=%s reason=osd_not_active" % key, xbmc.LOGINFO)
        return True

    _log("PKM_PLAYER_KEY_SKIP reason=unknown_key key=%s params=%s" % (key, params), xbmc.LOGWARNING)
    return False


def request(params=None):
    """Handle PKM seek button/key requests.

    v1432: do not call player.seekTime().  Compute the conservative PKM step, update
    the Plex-style OSD marker/labels, then delegate execution to Kodi native
    direct Kodi built-in Seek(seconds).
    """
    params = params or {}
    now = _now_ms()
    try:
        delta = float(params.get("delta", params.get("step", 0)) or 0)
    except Exception:
        delta = 0.0
    source = str(params.get("source", "keymap") or "keymap")
    direction_param = str(params.get("dir", params.get("direction", "")) or "").lower()
    # v2225: only the actual progress-bar focus (id=87) uses scrub preview.
    # Side +/- buttons keep the established immediate native Seek behavior.
    seekbar_scrub_v2225 = source in ("videoosd_seekbar_left", "videoosd_seekbar_right")
    is_step_menu_source = str(params.get("source", "")).startswith("videoosd_step_menu_")
    step_menu_main_focus_id = None
    if is_step_menu_source:
        _apply_manual_seek_step("back" if delta < 0 else "fwd", abs(delta), reason=str(params.get("source", "step_menu")))
        # v1478: collapse the side selector without flashing through the center
        # play/pause button.  Move focus to the corresponding main seek button
        # immediately after the selected step property is updated and before the
        # now-invisible side-menu control is cleared.
        try:
            _clear_osd_prop("FocusSeekBar")
            step_menu_main_focus_id = "620" if delta < 0 else "621"
            xbmc.executebuiltin("SetFocus(%s)" % step_menu_main_focus_id)
            _log("PKM_SEEK_STEP_MENU_PRE_COLLAPSE_FOCUS_V1478 focus_id=%s source=%s delta=%.3f" % (step_menu_main_focus_id, source, delta), xbmc.LOGINFO)
        except Exception:
            _log("PKM_SEEK_STEP_MENU_PRE_COLLAPSE_FOCUS_FAILED_V1478 source=%s\n%s" % (source, traceback.format_exc()), xbmc.LOGWARNING)
    if str(params.get("hide_step_menu", "")) == "1" or is_step_menu_source:
        _clear_step_menu("selected_%s" % str(params.get("source", "step_menu")))

    jump_requested = (str(params.get("jump", "")) == "1") or (str(params.get("mode", "")).lower() == "jump")
    if jump_requested and abs(delta) < 0.001:
        sign = -1.0 if direction_param in ("left", "back", "backward", "prev", "rewind") else 1.0
        try:
            delta = sign * float(params.get("jump_sec", LONG_JUMP_STEP_SEC) or LONG_JUMP_STEP_SEC)
        except Exception:
            delta = sign * float(LONG_JUMP_STEP_SEC)
    dynamic_requested = (not jump_requested) and ((str(params.get("dynamic", "")) == "1") or direction_param in ("left", "right", "back", "backward", "fwd", "forward", "prev", "next", "rewind"))

    # v1319: capture previous burst state before setting new properties.
    # v1318 overwrote LastInputMs first, so the very first key could be treated
    # as a burst and delayed unnecessarily.
    prev_active = _get_prop("Active") == "1"
    prev_committing = _get_prop("Committing") == "1"
    prev_last_input_ms = _get_int("LastInputMs", 0)
    prev_target_raw = _get_prop("TargetSec", "")
    prev_target = _get_float("TargetSec", 0.0)
    prev_source = _get_prop("Source", "")
    prev_seekbar_scrub_v2225 = _get_prop("SeekbarScrubV2225") == "1"

    # v1380: quick seek uses the real VideoOSD.  Mark early so DialogSeekBar
    # stays hidden, but do not close or suppress VideoOSD.
    _set_prop("Active", "1")
    _set_prop("SuppressOsd", "0")
    _set_prop("UseVideoOSD", "1")
    _set_prop("State", "entry_videoosd")
    _set_prop("HideAtMs", now + SEEK_TARGET_HOLD_MS)
    _set_prop("HideOsdAtMs", now)

    if abs(delta) < 0.001 and not dynamic_requested:
        _log("PKM_SEEK_QUICK_REQUEST_SKIP reason=zero_delta source=%s params=%s" % (source, params), xbmc.LOGWARNING)
        return False

    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            _clear_runtime_props("not_playing_video")
            _log("PKM_SEEK_QUICK_REQUEST_SKIP reason=not_playing_video delta=%.3f source=%s" % (delta, source), xbmc.LOGINFO)
            return False
        if not _bool_cond("Player.SeekEnabled"):
            _log("PKM_SEEK_QUICK_REQUEST_SKIP reason=seek_disabled delta=%.3f source=%s" % (delta, source), xbmc.LOGWARNING)
            return False
        current = float(player.getTime() or 0.0)
        duration = float(player.getTotalTime() or 0.0)
        _ensure_player_overlay_meta(player=player, duration=duration, reason="seek_request")
        if dynamic_requested:
            if seekbar_scrub_v2225:
                # v2231: scrub preview acceleration is independent of the main
                # +/- seek-button bitrate table. A fresh chain starts at 10 s;
                # from the fifth continuous LEFT/RIGHT input onward it uses 30 s.
                same_chain_v2231 = (
                    prev_active and prev_seekbar_scrub_v2225 and
                    prev_source in ("videoosd_seekbar_left", "videoosd_seekbar_right") and
                    prev_last_input_ms > 0 and now > 0 and (now - prev_last_input_ms) <= 2500
                )
                inherit_wait_v2231 = (
                    _get_prop("SeekWaitActive") == "1" and
                    "videoosd_seekbar_" in _get_prop("SeekWaitSource", "")
                )
                next_count_v2231 = (_get_int("InputCount", 0) + 1) if (same_chain_v2231 or inherit_wait_v2231) else 1
                step_v2231 = (
                    SEEKBAR_SCRUB_BIG_STEP_SEC_V2231
                    if next_count_v2231 >= SEEKBAR_SCRUB_BIG_FROM_INPUT_V2231
                    else SEEKBAR_SCRUB_SMALL_STEP_SEC_V2231
                )
                sign_v2231 = -1.0 if direction_param in ("left", "back", "backward", "prev", "rewind") else 1.0
                delta = sign_v2231 * float(step_v2231)
                _set_prop("ScrubStepSecV2231", int(step_v2231))
                _set_prop("ScrubStepModeV2231", "big" if step_v2231 == SEEKBAR_SCRUB_BIG_STEP_SEC_V2231 else "small")
                _log(
                    "PKM_SEEKBAR_ACCEL_V2231 source=%s dir=%s input=%d step=%ds mode=%s chain=%d inherit_wait=%d" % (
                        source, direction_param or "-", next_count_v2231, int(step_v2231),
                        "big" if step_v2231 == SEEKBAR_SCRUB_BIG_STEP_SEC_V2231 else "small",
                        1 if same_chain_v2231 else 0, 1 if inherit_wait_v2231 else 0
                    ), xbmc.LOGINFO,
                )
            else:
                delta = _dynamic_delta_for_dir(direction_param, player=player, duration=duration, reason="seek_request_%s" % (direction_param or source))
        else:
            _publish_dynamic_seek_steps(player=player, duration=duration, reason="seek_request_static")
        if abs(delta) < 0.001:
            _log("PKM_SEEK_QUICK_REQUEST_SKIP reason=zero_dynamic_delta direction=%s source=%s params=%s" % (direction_param, source, params), xbmc.LOGWARNING)
            return False
    except Exception:
        _log("PKM_SEEK_QUICK_REQUEST_FAILED stage=read_player delta=%.3f source=%s\n%s" % (delta, source, traceback.format_exc()), xbmc.LOGERROR)
        return False

    last_input_ms = prev_last_input_ms
    last_target = prev_target if prev_target_raw != "" else current
    if seekbar_scrub_v2225:
        # v2225: the progress bar is a continuous visual scrub surface.  Never
        # issue a real seek for each repeat.  Accumulate from the last visual
        # target even while the decoder is busy/caching, and allow travel all
        # the way to either end of the title.
        burst_alive = (
            prev_active and prev_seekbar_scrub_v2225 and
            prev_source in ("videoosd_seekbar_left", "videoosd_seekbar_right") and
            last_input_ms > 0 and now > 0 and (now - last_input_ms) <= 2500
        )
        # v2230: if a previous final seek is still landing, Player.Time can
        # remain at the old range for seconds. A new RIGHT/LEFT must continue
        # from the *visual/committed target*, never from that stale clock.
        inherit_seek_wait_v2230 = (
            _get_prop("SeekWaitActive") == "1" and
            "videoosd_seekbar_" in _get_prop("SeekWaitSource", "")
        )
        if inherit_seek_wait_v2230 and not burst_alive:
            base = _get_float("SeekWaitTargetSec", last_target if prev_target_raw != "" else current)
            burst_alive = True
            _log(
                "PKM_SEEKBAR_BASE_INHERIT_ACTIVE_TARGET_V2230 source=%s current=%.3f active_target=%.3f" % (
                    source, current, base
                ), xbmc.LOGINFO,
            )
        else:
            base = last_target if burst_alive else current
        burst_base = base
        max_total = 0.0
        candidate_target = base + delta
    elif NATIVE_KODI_SEEK_ENABLED:
        # v1431: native Seek(seconds) is relative and Kodi owns accumulation.
        # Main +/- seek buttons remain immediate.
        burst_alive = False
        base = current
        burst_base = current
        max_total = 0.0
        candidate_target = current + delta
    elif jump_requested:
        # v1428: +/-30s jump is a separate convenience command, not the
        # instant-FF burst.  Do not apply the short-seek 3x/60s burst cap.
        burst_alive = False
        base = current
        burst_base = current
        max_total = 0.0
        candidate_target = current + delta
    else:
        burst_alive = (prev_active and last_input_ms > 0 and now > 0 and (now - last_input_ms) <= 2500)
        base = last_target if burst_alive else current
        burst_base = _get_float("BurstBaseSec", current) if burst_alive else current
        max_total = _burst_max_for_step(abs(delta))
        candidate_target = base + delta
        if max_total > 0.0:
            candidate_target = max(burst_base - max_total, min(burst_base + max_total, candidate_target))
    target = _clamp_target(candidate_target, duration)
    try:
        if (not seekbar_scrub_v2225) and str(source).startswith("fullscreen_") and str(source).endswith("_short"):
            _seek_osd_show_r172(delta)
    except Exception:
        pass

    seq = _get_int("Seq", 0) + 1
    input_count = (_get_int("InputCount", 0) + 1) if burst_alive else 1
    last_commit_ms = _get_int("LastCommitMs", 0)
    cooldown_until = _get_int("CooldownUntilMs", 0)

    # v1431 native branch: no debounce, no target latch commit, no player.seekTime().
    # Each key/button sends exactly one Kodi native relative seek action using the
    # measured PKM step.  The computed target below is display-only for the PKM
    # marker; Kodi owns the actual demuxer/decoder seek path.
    if seekbar_scrub_v2225:
        jump_prewarm_started = False
        cooldown_left = 0
        commit_delay = SEEKBAR_SCRUB_COMMIT_IDLE_MS_V2225
        commit_at = now + commit_delay
    elif NATIVE_KODI_SEEK_ENABLED:
        jump_prewarm_started = False
        cooldown_left = 0
        commit_delay = 0
        commit_at = now
    else:
        # Legacy absolute seek path, kept disabled for rollback only.
        jump_prewarm_started = False
        if jump_requested and LONG_JUMP_PREWARM_ENABLED:
            jump_prewarm_started = _start_jump_prewarm(player, target, duration, seq, source)
        cooldown_left = max(0, cooldown_until - now) if now else 0
        commit_delay = (LONG_JUMP_PREWARM_DELAY_MS if jump_requested and jump_prewarm_started else (0 if jump_requested else DYNAMIC_SEEK_DEBOUNCE_MS))
        commit_at = now + commit_delay

    percent = 0.0
    if duration > 0:
        percent = max(0.0, min(100.0, (target / duration) * 100.0))
    _set_osd_nib_index(percent, reason="seek_request")
    # R140: OSD 위 좌/우 탐색도 "손댐"이다. 처음 열린 시각 기준 3초 자동 닫힘이
    # 탐색 중에 OSD 를 닫아 버려 다음 키가 배속 화면으로 가던 것을 막는다.
    # 마지막 탐색 뒤 3초가 지나면 서비스 틱(v1944)이 닫는다.
    try:
        if _get_osd_prop("AutoCloseArmed") == "1" and _get_osd_prop("AutoClosing") != "1":
            _set_osd_prop("AutoCloseSessionV1961", "seek_touch_%d" % now)
            _set_osd_prop("AutoCloseAtMs", now + OSD_AUTO_CLOSE_MS_V1943)
    except Exception:
        pass

    direction = "right" if delta > 0 else "left"
    for name, value in (
        ("Active", "1"),
        ("SuppressOsd", "0"),
        ("UseVideoOSD", "1"),
        ("Pending", "1"),
        ("Seq", seq),
        ("CurrentSec", "%.3f" % current),
        ("CurrentLabel", _format_time(current)),
        ("TargetSec", "%.3f" % target),
        ("TargetLabel", _format_time(target)),
        ("TargetSimpleLabelV2231", _format_seek_target_ko_v2231(target) if seekbar_scrub_v2225 else ""),
        ("TimeBubbleIndexV2231", _seek_time_bubble_index_v2231(percent) if seekbar_scrub_v2225 else ""),
        ("TargetPercent", "%.3f" % percent),
        ("DurationSec", "%.3f" % duration),
        ("DurationLabel", _format_time(duration)),
        ("CommitAtMs", commit_at),
        ("LastInputMs", now),
        ("InputCount", input_count),
        ("Dir", direction),
        ("State", "pending"),
        ("HideAtMs", now + SEEK_TARGET_HOLD_MS),
        ("TargetHoldUntilMs", now + SEEK_TARGET_HOLD_MS),
        ("HideOsdAtMs", now + 6500),
        ("Source", source),
        ("SeekbarScrubV2225", "1" if seekbar_scrub_v2225 else "0"),
        ("JumpMode", "1" if jump_requested else "0"),
        ("JumpPrewarm", "1" if jump_requested and jump_prewarm_started else "0"),
        ("BurstBaseSec", "%.3f" % burst_base),
        ("BurstMaxSec", "%.3f" % max_total),
    ):
        _set_prop(name, value)

    # v1380: the real VideoOSD is the seek overlay.  Do not close it here;
    # DialogSeekBar is hidden while UseVideoOSD=1.
    _log("PKM_SEEK_QUICK_UI_TARGET seq=%d target_label=%s target_percent=%.3f duration_label=%s use_videoosd=1" % (seq, _format_time(target), percent, _format_time(duration)), xbmc.LOGINFO)

    _log(
        "PKM_SEEK_QUICK_REQUEST seq=%d source=%s dir=%s delta=%.3f current=%.3f base=%.3f target=%.3f duration=%.3f percent=%.2f count=%d burst=%s jump=%s commit_delay_ms=%d immediate=%s last_commit_age_ms=%d cooldown_left_ms=%d window_fullscreen=%s window_videoosd=%s" % (
            seq, source, direction, delta, current, base, target, duration, percent, input_count,
            "1" if burst_alive else "0", "1" if jump_requested else "0", commit_delay, "1" if commit_delay <= 0 else "0",
            (now - last_commit_ms) if (now and last_commit_ms) else -1,
            max(0, cooldown_until - now) if now else 0,
            "1" if _bool_cond("Window.IsActive(fullscreenvideo)") else "0",
            "1" if _bool_cond("Window.IsActive(videoosd)") else "0",
        ),
        xbmc.LOGINFO,
    )
    if seekbar_scrub_v2225:
        # v2227: progress-bar interaction owns a renewable 3-second OSD idle
        # deadline. Repeated Left/Right only moves the preview and refreshes this
        # deadline. When input stops, the real VideoOSD fades away; another
        # fullscreen Left/Right reopens it and starts a fresh scrub session.
        _set_osd_prop("SeekbarIdleCloseAtMsV2227", now + OSD_AUTO_CLOSE_MS_V1943)
        _set_osd_prop("SeekbarIdleLastInputMsV2227", now)
        _clear_osd_prop("AutoCloseCancelled")
        _set_prop("State", "seekbar_scrub_preview_v2225")
        _log("PKM_VIDEOOSD_SEEKBAR_IDLE_ARM_V2227 seq=%d timeout_ms=%d focus=87" % (
            seq, OSD_AUTO_CLOSE_MS_V1943
        ), xbmc.LOGINFO)
        _log(
            "PKM_SEEKBAR_SCRUB_PREVIEW_V2225 seq=%d dir=%s current=%.3f base=%.3f target=%.3f duration=%.3f count=%d commit_after_idle_ms=%d real_seek=0" % (
                seq, direction, current, base, target, duration, input_count, SEEKBAR_SCRUB_COMMIT_IDLE_MS_V2225
            ),
            xbmc.LOGINFO,
        )
        return True

    if NATIVE_KODI_SEEK_ENABLED:
        _set_prop("Pending", "0")
        _set_prop("Committing", "0")
        _set_prop("State", "native_seek_dispatched")
        _set_prop("LastCommitMs", _now_ms())
        _set_prop("CooldownUntilMs", _now_ms() + 80)
        _set_prop("HideAtMs", _now_ms() + 1800)
        _set_prop("TargetHoldUntilMs", _now_ms() + 1200)
        _set_prop("HideOsdAtMs", _now_ms())
        ok = _execute_native_seek_seconds(delta, seq=seq, source=source, target=target, duration=duration)
        # v1478: when a side-menu value is selected, keep focus on the
        # corresponding main seek icon immediately.  No sleep/delayed SetFocus:
        # delayed focus allowed Kodi to flash focus through id=602 play/pause.
        if is_step_menu_source:
            try:
                _clear_osd_prop("FocusSeekBar")
                main_focus_id = step_menu_main_focus_id or ("620" if delta < 0 else "621")
                xbmc.executebuiltin("SetFocus(%s)" % main_focus_id)
                _log("PKM_SEEK_STEP_MENU_SELECTED_FOCUS_V1478 focus_id=%s source=%s delta=%.3f no_sleep=1" % (main_focus_id, source, delta), xbmc.LOGINFO)
            except Exception:
                _log("PKM_SEEK_STEP_MENU_SELECTED_FOCUS_FAILED_V1478 source=%s\n%s" % (source, traceback.format_exc()), xbmc.LOGWARNING)
        if not ok:
            _set_prop("State", "native_seek_failed")
            _set_prop("LastError", "native_seek_failed")
        return True

    if prev_committing:
        _log("PKM_SEEK_QUICK_DEBOUNCE_WAIT seq=%d reason=prev_committing target=%.3f count=%d source=%s" % (seq, target, input_count, source), xbmc.LOGINFO)
    else:
        _log("PKM_SEEK_QUICK_DEBOUNCE_WAIT seq=%d delay_ms=%d target=%.3f count=%d source=%s burst_base=%.3f burst_max=%.3f" % (seq, commit_delay, target, input_count, source, burst_base, max_total), xbmc.LOGINFO)
    return True


def service_tick(monitor=None):
    """Commit the latest pending target when its debounce has elapsed.

    Returns True while the seek overlay is active/pending so service.py can poll
    faster only during a seek burst.
    """
    now = _now_ms()
    active = _get_prop("Active") == "1"
    suppress_osd = _get_prop("SuppressOsd") == "1"
    pending = _get_prop("Pending") == "1"
    committing = _get_prop("Committing") == "1"
    # v2226: monitor the *actual* player landing/clock advance independently
    # from Kodi's brief Player.Seeking flag. This never performs another seek.
    seek_wait_active_v2226 = _seek_wait_tick_v2226(now)

    step_menu_hide_at = _get_int("StepMenuHideAtMs", 0)
    if step_menu_hide_at > 0 and now > step_menu_hide_at:
        _clear_step_menu("timeout_v1460")

    # v1944: opening idle policy. The untouched initial OSD still closes after
    # 3 seconds. v2326 adds one deliberate exception to the old session-wide
    # cancellation rule: while a subtitle/audio/video/native settings child owns
    # the UI the timer is held, and when that child closes the parent VideoOSD
    # receives a fresh 3-second idle window from the exact focus it returned to.
    # A subsequent focus move cancels that return timer, so this never steals
    # active navigation. Step-menu behavior remains unchanged.
    osd_visible_v1943 = _is_video_osd_visible()
    child_dialog_active_v2326 = _video_osd_subdialog_active_v1943()
    child_return_pending_v2326 = _get_osd_prop("ChildReturnPendingV2326") == "1"
    if child_dialog_active_v2326:
        if not child_return_pending_v2326:
            _set_osd_prop("ChildReturnPendingV2326", "1")
            _clear_osd_prop("ChildReturnAutoCloseV2326")
            _clear_osd_prop("ChildReturnFocusV2326")
            _log("PKM_VIDEOOSD_CHILD_RETURN_TRACK_V2326 active=1 action=hold_timer", xbmc.LOGINFO)
        child_return_pending_v2326 = True
    elif child_return_pending_v2326 and osd_visible_v1943:
        if (not _bool_cond("Player.Paused") and
                _get_osd_prop("NoAutoClose") != "1"):
            return_focus_v2326 = _video_osd_focus_token_v1943()
            if return_focus_v2326:
                _clear_osd_prop("ChildReturnPendingV2326")
                child_return_pending_v2326 = False
                _clear_osd_prop("AutoCloseCancelled")
                _set_osd_prop("AutoCloseArmed", "1")
                _set_osd_prop("AutoCloseAtMs", now + OSD_AUTO_CLOSE_MS_V1943)
                _set_osd_prop("AutoCloseLastMs", now)
                _set_osd_prop("AutoCloseFocus", return_focus_v2326)
                _set_osd_prop("ChildReturnAutoCloseV2326", "1")
                _set_osd_prop("ChildReturnFocusV2326", return_focus_v2326)
                _log("PKM_VIDEOOSD_AUTOCLOSE_REARM_V2326 reason=child_dialog_return timeout_ms=%d focus=%s" % (
                    OSD_AUTO_CLOSE_MS_V1943, return_focus_v2326), xbmc.LOGINFO)
        else:
            _clear_osd_prop("ChildReturnPendingV2326")
            child_return_pending_v2326 = False
            _clear_osd_prop("ChildReturnAutoCloseV2326")
            _clear_osd_prop("ChildReturnFocusV2326")
            _log("PKM_VIDEOOSD_AUTOCLOSE_REARM_SKIP_V2326 reason=paused_or_noautoclose paused=%d noautoclose=%d" % (
                1 if _bool_cond("Player.Paused") else 0,
                1 if _get_osd_prop("NoAutoClose") == "1" else 0), xbmc.LOGINFO)

    osd_armed_v1944 = _get_osd_prop("AutoCloseArmed") == "1"
    osd_cancelled_v1944 = _get_osd_prop("AutoCloseCancelled") == "1"
    child_return_autoclose_v2326 = _get_osd_prop("ChildReturnAutoCloseV2326") == "1"
    if osd_visible_v1943:
        # Direct native OSD opening must override any stale quick-seek suppression.
        if osd_armed_v1944 and suppress_osd:
            _clear_seek_suppression_for_osd("native_enter_open_v1944")
            suppress_osd = False
            active = _get_prop("Active") == "1"
            _log("PKM_VIDEOOSD_NATIVE_ENTER_SUPPRESSION_CLEAR_V1944 playback_action=none", xbmc.LOGINFO)

        if _get_osd_prop("AutoClosing") == "1":
            force_at_v1944 = _get_osd_int("AutoCloseForceAtMs", 0)
            if force_at_v1944 > 0 and now >= force_at_v1944:
                try:
                    xbmc.executebuiltin("Dialog.Close(videoosd,true)")
                    _log("PKM_VIDEOOSD_AUTOCLOSE_FORCE_V1944 reason=windowclose_timeout playback_action=none", xbmc.LOGWARNING)
                except Exception:
                    pass
        elif osd_cancelled_v1944:
            if _get_osd_int("AutoCloseAtMs", 0) > 0 or osd_armed_v1944:
                _clear_osd_prop("AutoCloseAtMs")
                _clear_osd_prop("AutoCloseArmed")
        elif osd_armed_v1944 and _bool_cond("Player.Paused"):
            _set_osd_prop("AutoCloseCancelled", "1")
            _clear_osd_prop("AutoCloseArmed")
            _clear_osd_prop("AutoCloseAtMs")
            _clear_osd_prop("ChildReturnAutoCloseV2326")
            _clear_osd_prop("ChildReturnFocusV2326")
            _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1946 reason=native_playpause_state paused=1 focus=602", xbmc.LOGINFO)
        elif osd_armed_v1944:
            focus_v1944 = _video_osd_focus_token_v1943()
            if child_dialog_active_v2326 or _get_prop("StepMenuVisible") == "1":
                _set_osd_prop("AutoCloseCancelled", "1")
                _clear_osd_prop("AutoCloseArmed")
                _clear_osd_prop("AutoCloseAtMs")
                _clear_osd_prop("ChildReturnAutoCloseV2326")
                _clear_osd_prop("ChildReturnFocusV2326")
                _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1944 reason=child_or_step_menu", xbmc.LOGINFO)
            elif child_return_autoclose_v2326:
                return_focus_v2326 = _get_osd_prop("ChildReturnFocusV2326")
                if return_focus_v2326 and focus_v1944 and focus_v1944 != return_focus_v2326:
                    _set_osd_prop("AutoCloseCancelled", "1")
                    _clear_osd_prop("AutoCloseArmed")
                    _clear_osd_prop("AutoCloseAtMs")
                    _clear_osd_prop("ChildReturnAutoCloseV2326")
                    _clear_osd_prop("ChildReturnFocusV2326")
                    _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V2326 reason=child_return_focus_moved from=%s to=%s" % (
                        return_focus_v2326 or "-", focus_v1944 or "-"), xbmc.LOGINFO)
                else:
                    deadline_v1944 = _get_osd_int("AutoCloseAtMs", 0)
                    if deadline_v1944 <= 0:
                        _set_osd_prop("AutoCloseAtMs", now + OSD_AUTO_CLOSE_MS_V1943)
                        _set_osd_prop("AutoCloseLastMs", now)
                        _log("PKM_VIDEOOSD_AUTOCLOSE_REARM_V2326 reason=child_return_missing_deadline timeout_ms=%d focus=%s" % (
                            OSD_AUTO_CLOSE_MS_V1943, return_focus_v2326 or focus_v1944 or "-"), xbmc.LOGINFO)
                    elif now >= deadline_v1944:
                        _clear_osd_prop("ChildReturnAutoCloseV2326")
                        _clear_osd_prop("ChildReturnFocusV2326")
                        _close_video_osd_smooth_v1943("child_dialog_return_idle_3000ms_v2326")
            elif focus_v1944 and focus_v1944 != "602":
                _set_osd_prop("AutoCloseCancelled", "1")
                _clear_osd_prop("AutoCloseArmed")
                _clear_osd_prop("AutoCloseAtMs")
                _log("PKM_VIDEOOSD_AUTOCLOSE_CANCEL_V1944 reason=focus_left_play target=%s" % focus_v1944, xbmc.LOGINFO)
            else:
                deadline_v1944 = _get_osd_int("AutoCloseAtMs", 0)
                if deadline_v1944 <= 0:
                    _set_osd_prop("AutoCloseAtMs", now + OSD_AUTO_CLOSE_MS_V1943)
                    _set_osd_prop("AutoCloseFocus", "602")
                    _log("PKM_VIDEOOSD_AUTOCLOSE_ARM_V1944 reason=initial_enter_untouched timeout_ms=%d focus=602" % OSD_AUTO_CLOSE_MS_V1943, xbmc.LOGINFO)
                elif now >= deadline_v1944:
                    _close_video_osd_smooth_v1943("initial_enter_idle_3000ms_v1944")
    else:
        if (_get_osd_int("AutoCloseAtMs", 0) > 0 or
                _get_osd_prop("AutoClosing") == "1" or
                _get_osd_prop("AutoCloseArmed") == "1" or
                _get_osd_prop("AutoCloseCancelled") == "1"):
            _clear_video_osd_autoclose_v1943("osd_not_visible_v1944")

    # v2227: seekbar focus has its own renewable idle-close policy. The legacy
    # one-shot OSD policy intentionally treats navigation as cancellation, which
    # is correct for buttons/settings but wrong for continuous scrubbing.
    seekbar_idle_at_v2227 = _get_osd_int("SeekbarIdleCloseAtMsV2227", 0)
    if osd_visible_v1943 and seekbar_idle_at_v2227 > 0:
        focus_v2227 = _video_osd_focus_token_v1943()
        if focus_v2227 != "87":
            _clear_osd_prop("SeekbarIdleCloseAtMsV2227")
            _clear_osd_prop("SeekbarIdleLastInputMsV2227")
            _log("PKM_VIDEOOSD_SEEKBAR_IDLE_CANCEL_V2227 reason=focus_left_seekbar focus=%s" % (focus_v2227 or "-"), xbmc.LOGINFO)
        elif now >= seekbar_idle_at_v2227 and not _video_osd_subdialog_active_v1943():
            _clear_osd_prop("SeekbarIdleCloseAtMsV2227")
            _clear_osd_prop("SeekbarIdleLastInputMsV2227")
            _log("PKM_VIDEOOSD_SEEKBAR_IDLE_CLOSE_V2227 reason=no_input_3000ms pending=%d committing=%d seek_wait=%d" % (
                int(pending), int(committing), int(bool(seek_wait_active_v2226))
            ), xbmc.LOGINFO)
            _close_video_osd_smooth_v1943("seekbar_idle_3000ms_v2227")
    elif not osd_visible_v1943 and seekbar_idle_at_v2227 > 0:
        _clear_osd_prop("SeekbarIdleCloseAtMsV2227")
        _clear_osd_prop("SeekbarIdleLastInputMsV2227")

    # v1371: only close VideoOSD during the actual seek-suppression window.
    # Do not close it merely because the seek target overlay is still active;
    # ENTER after a seek must be able to open the native OSD immediately.
    if suppress_osd:
        _close_video_osd("service_tick_seek_only")

    # v1319: keep OSD suppression longer than the visible target overlay.
    # Kodi can reopen VideoOSD/HasPerformedSeek after seekTime() returns, so the
    # full button strip must remain blocked for a few seconds after commit.
    hide_at = _get_int("HideAtMs", 0)
    if active and not pending and not committing and hide_at > 0 and now > hide_at:
        _set_prop("Active", "0")
        _set_prop("Pending", "0")
        _set_prop("Committing", "0")
        _set_prop("State", "overlay_hidden_videoosd_kept")
        _clear_prop("UseVideoOSD")
        _log("PKM_SEEK_QUICK_ACTIVE_CLEAR reason=hide_timeout_keep_videoosd")
        active = False

    hide_osd_at = _get_int("HideOsdAtMs", 0)
    if suppress_osd and not active and not pending and not committing and hide_osd_at > 0 and now > hide_osd_at:
        _clear_runtime_props("suppress_osd_timeout")
        return bool(seek_wait_active_v2226)

    if not pending:
        try:
            # v1395: while a PKM seek target is visible, never drive the bar/marker
            # from Kodi Player.Time.  On high-bitrate 4K/DXVA seek, Player.Time can
            # momentarily report the previous/decoder-catching-up position, making
            # the bar jump forward/backward.  Keep the UI latched to TargetPercent
            # until the hold expires, then return to real Player.Progress.
            target_percent = _get_prop("TargetPercent", "")
            target_hold_until = _get_int("TargetHoldUntilMs", 0)
            if target_percent:
                if active or committing or (target_hold_until > 0 and now <= target_hold_until):
                    _set_osd_nib_index(target_percent, reason="")
                    return True
                _clear_target_props("target_hold_timeout")
            # Normal non-seek OSD: marker follows the real progress end.
            osd_visible = (_get_osd_prop("Visible") == "1") or _bool_cond("Window.IsVisible(videoosd)") or _bool_cond("Window.IsActive(videoosd)")
            if osd_visible:
                # v1945: the old 50 ms service path re-resolved the same plugin
                # URL and recomputed identical dynamic seek steps dozens of times
                # while OSD was visible.  Keep the progress nib live, but refresh
                # the stable seek-step metadata at most once per second.
                # R140b: OSD 탐색은 10초 고정(적응형 폐기) — 단계 계산·주소 재조회 안 함.
                _set_osd_nib_from_player(reason="")
            else:
                _clear_prop("OsdStepRefreshAtMsV1945")
        except Exception:
            pass
        return active or suppress_osd or osd_visible_v1943 or seek_wait_active_v2226

    commit_at = _get_int("CommitAtMs", 0)
    if commit_at > 0 and now < commit_at:
        return True

    if _get_prop("Committing") == "1":
        return True

    seq = _get_int("Seq", 0)
    target = _get_float("TargetSec", 0.0)
    input_count = _get_int("InputCount", 0)
    source = _get_prop("Source", "")

    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            _clear_runtime_props("commit_not_playing_video")
            _log("PKM_SEEK_QUICK_COMMIT_SKIP seq=%d reason=not_playing_video target=%.3f count=%d source=%s" % (seq, target, input_count, source), xbmc.LOGWARNING)
            return False
        if not _bool_cond("Player.SeekEnabled"):
            _set_prop("Pending", "0")
            _set_prop("State", "seek_disabled")
            _set_prop("LastError", "seek_disabled")
            _set_prop("HideAtMs", now + 2500)
            _log("PKM_SEEK_QUICK_COMMIT_SKIP seq=%d reason=seek_disabled target=%.3f count=%d source=%s" % (seq, target, input_count, source), xbmc.LOGWARNING)
            return True
        before = float(player.getTime() or 0.0)
        duration = float(player.getTotalTime() or 0.0)
        target = _clamp_target(target, duration)
    except Exception:
        _set_prop("Pending", "0")
        _set_prop("State", "read_player_failed")
        _set_prop("LastError", "read_player_failed")
        _set_prop("HideAtMs", now + 2500)
        _log("PKM_SEEK_QUICK_COMMIT_FAILED seq=%d stage=read_player target=%.3f count=%d source=%s\n%s" % (seq, target, input_count, source, traceback.format_exc()), xbmc.LOGERROR)
        return True

    _set_prop("Committing", "1")
    _set_prop("State", "committing")
    _set_prop("Pending", "0")
    commit_start = _now_ms()
    _log("PKM_SEEK_QUICK_COMMIT_BEGIN seq=%d before=%.3f target=%.3f duration=%.3f count=%d source=%s" % (seq, before, target, duration, input_count, source), xbmc.LOGINFO)

    call_elapsed = -1
    seekbar_scrub_commit_v2225 = (_get_prop("SeekbarScrubV2225") == "1" and source in ("videoosd_seekbar_left", "videoosd_seekbar_right"))
    try:
        if seekbar_scrub_commit_v2225:
            # v2225: one and only one native Kodi seek after the user stops
            # moving the progress bar.  Compute the final relative delta at
            # commit time so playback may continue normally during preview.
            commit_delta = float(target) - float(before)
            _log(
                "PKM_SEEKBAR_SCRUB_COMMIT_BEGIN_V2225 seq=%d before=%.3f target=%.3f delta=%.3f count=%d source=%s" % (
                    seq, before, target, commit_delta, input_count, source
                ),
                xbmc.LOGINFO,
            )
            if abs(commit_delta) >= 0.25:
                _clear_seek_wait_v2226("superseded_by_scrub_commit")
                _arm_seek_wait_v2226(
                    target, before, source=source + "_final_v2226", duration=duration,
                    managed_pause_v2230=True,
                )
                ok_v2225 = _execute_native_seek_seconds(commit_delta, seq=seq, source=source + "_final_v2225", target=target, duration=duration)
                if not ok_v2225:
                    _clear_seek_wait_v2226("scrub_native_seek_failed")
                    raise RuntimeError("native_seek_failed_v2225")
            call_elapsed = max(0, _now_ms() - commit_start)
            _log(
                "PKM_SEEKBAR_SCRUB_COMMIT_DONE_V2225 seq=%d before=%.3f target=%.3f delta=%.3f real_seek_count=1 elapsed_ms=%d" % (
                    seq, before, target, commit_delta, call_elapsed
                ),
                xbmc.LOGINFO,
            )
        else:
            # Disabled legacy absolute path retained only for rollback callers.
            player.seekTime(float(target))
            call_elapsed = max(0, _now_ms() - commit_start)

        _set_prop("LastCommitMs", _now_ms())
        _set_prop("CooldownUntilMs", _now_ms() + 260)
        _set_prop("State", "committed")
        _set_prop("Committing", "0")
        _set_prop("Pending", "0")
        _set_prop("SuppressOsd", "0")
        _set_prop("SeekbarScrubV2225", "0")
        _set_prop("HideAtMs", _now_ms() + SEEK_TARGET_HOLD_MS)
        _set_prop("TargetHoldUntilMs", _now_ms() + SEEK_TARGET_HOLD_MS)
        _set_prop("HideOsdAtMs", _now_ms())
    except Exception:
        _set_prop("Committing", "0")
        _set_prop("Pending", "0")
        _set_prop("SeekbarScrubV2225", "0")
        _set_prop("State", "seek_failed")
        _set_prop("LastError", "seek_failed")
        _set_prop("HideAtMs", _now_ms() + 3000)
        _log("PKM_SEEK_QUICK_COMMIT_FAILED seq=%d stage=%s before=%.3f target=%.3f count=%d source=%s\n%s" % (seq, "native_scrub_v2225" if seekbar_scrub_commit_v2225 else "seekTime", before, target, input_count, source, traceback.format_exc()), xbmc.LOGERROR)
        return True

    # v1425: no readiness polling after seekTime.  Python reference probe only
    # sends an absolute seek and then observes playback externally; PKM should
    # not add internal post-seek Player.Time polling loops.
    ready_ms = -1
    after = -1.0

    # If another key arrived while seekTime was being issued, keep the newest
    # pending target.  Otherwise leave the overlay active briefly then clear.
    latest_seq = _get_int("Seq", seq)
    pending_after = _get_prop("Pending") == "1"
    _log(
        "PKM_SEEK_QUICK_COMMIT_DONE seq=%d latest_seq=%d pending_after=%s before=%.3f target=%.3f after=%.3f call_elapsed_ms=%d ready_ms=%d count=%d source=%s" % (
            seq, latest_seq, "1" if pending_after else "0", before, target, after, call_elapsed, ready_ms, input_count, source
        ),
        xbmc.LOGINFO,
    )
    return True
