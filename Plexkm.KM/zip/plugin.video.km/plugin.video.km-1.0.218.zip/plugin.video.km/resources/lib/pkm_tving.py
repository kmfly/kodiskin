# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM TVING data (V2806).

Reads plugin.video.tvingm (TVING MINI) directories through Kodi JSON-RPC
Files.GetDirectory and turns them into PKM widget rows.  TVING MINI keeps
login, stream URLs and DRM; PKM only lists and hands plugin:// paths back to
Kodi for playback.  Directory/param shapes are taken from TVING MINI 2.8.1
(tvingRun.py: BAND_VODLIST, CHANNEL, GN2_LIST, EPISODE, WATCH, LOCAL_SEARCH,
APPLE_GROUP).
"""

import json
import os
import re
import threading
import time

try:
    from urllib.parse import unquote, urlencode
except ImportError:  # pragma: no cover
    from urllib import unquote, urlencode

try:
    import xbmc
    import xbmcaddon
except Exception:  # pragma: no cover - lets the converter run in tests
    xbmc = None
    xbmcaddon = None

ADDON_ID = "plugin.video.tvingm"
BASE_URL = "plugin://%s/" % ADDON_ID
CACHE_TTL_SEC = 15 * 60
LIVE_TTL_SEC = 3 * 60
MAX_ROW_ITEMS = 60

CHIPS = (
    ("home", "홈"),
    ("live", "실시간 TV"),
    ("drama", "드라마"),
    ("enter", "예능"),
    ("movie", "영화"),
    ("apple", "Apple TV+"),
    ("watch", "시청목록"),
)
CHIP_LABELS = dict(CHIPS)

# TVING MINI menu items that are actions, not content.
_SKIP_LABEL_RE = re.compile(r"정렬순서변경|전체삭제|^\*\*|^-{3,}")
_SKIP_MODES = ("ORDER_BY", "MYVIEW_REMOVE", "SEARCH_REMOVE", "XXX", "SET_BOOKMARK")
_MORE_LABEL = "다음 페이지"
_LIVE_LABEL_RE = re.compile(r"^(.*?) < (.*) >$")   # add_dir(channel, sublabel=program)
_TAG_RE = re.compile(r"\[/?(?:B|I|COLOR[^\]]*)\]")

_CACHE_LOCK = threading.Lock()
_CACHE = None


def log(msg, level=None):
    if xbmc is not None:
        xbmc.log("[plugin.video.km] OTT %s" % msg, xbmc.LOGINFO if level is None else level)


def url(mode, **params):
    q = [("mode", mode)] + [(k, v) for k, v in params.items() if v is not None]
    return BASE_URL + "?" + urlencode(q)


def _band(key="", group=""):
    return url("BAND_VODLIST", bandKey=key or "-", bandGroup=group, page="1", nextApiUrl="-")


def _gn2(genre, stype, orderby="hit"):
    return url("GN2_LIST", genre=genre, stype=stype, orderby=orderby, page="1")


def _channel(stype):
    return url("CHANNEL", stype=stype, page="1")


def _row(key, title, src, shape="poster", rank=False, live=False):
    return {"key": key, "title": title, "url": src, "shape": shape, "rank": rank, "live": live}


ROWS = {
    "home": [
        _row("band_drama", "실시간 인기 드라마", _band("HM218820"), rank=True),
        _row("live_onair", "실시간 TV", _channel("onair"), shape="wide", live=True),
        _row("band_enter", "실시간 인기 예능", _band("HM156521"), rank=True),
        _row("band_apple", "Apple TV+ 실시간 인기", _band(group="TVING_APPLE_HOUR"), rank=True),
    ],
    "live": [
        _row("live_onair", "실시간 TV", _channel("onair"), shape="wide", live=True),
        _row("live_tvingtv", "TVING TV", _channel("tvingtv"), shape="wide", live=True),
    ],
    "drama": [
        _row("drama_hit", "인기 드라마", _gn2("PCA", "tvshow")),
        _row("drama_update", "최신 업데이트", _gn2("PCA", "tvshow", "update")),
        _row("drama_romance", "로맨스", _gn2("PCA007", "tvshow")),
        _row("drama_comedy", "코미디", _gn2("PCA020", "tvshow")),
        _row("drama_crime", "범죄 스릴러", _gn2("PCA015", "tvshow")),
        _row("drama_foreign", "해외드라마", _gn2("PCPOS", "tvshow")),
    ],
    "enter": [
        _row("enter_hit", "버라이어티 인기", _gn2("PCD005", "tvshow")),
        _row("enter_update", "버라이어티 최신", _gn2("PCD005", "tvshow", "update")),
        _row("enter_observe", "관찰리얼리티", _gn2("PCD024", "tvshow")),
        _row("enter_talk", "토크쇼", _gn2("PCD011", "tvshow")),
        _row("enter_survival", "서바이벌", _gn2("PCD025", "tvshow")),
        _row("enter_docu", "다큐멘터리", _gn2("PCT", "tvshow")),
    ],
    "movie": [
        _row("movie_update", "최신 업데이트", _gn2("MG100", "movie", "update")),
        _row("movie_drama", "드라마", _gn2("MG100", "movie")),
        _row("movie_action", "액션", _gn2("MG120", "movie")),
        _row("movie_comedy", "코미디", _gn2("MG110", "movie")),
        _row("movie_thriller", "스릴러", _gn2("MG140", "movie")),
        _row("movie_anim", "애니메이션", _gn2("MG240", "movie")),
    ],
    # Apple TV+ bands are only known at run time: expand this folder into rows.
    "apple": [{"key": "apple_group", "expand": url("APPLE_GROUP", stype="-", orderby="-", ordernm="-", page="1")}],
    "watch": [
        _row("watch_vod", "VOD 시청내역", url("WATCH", stype="vod")),
        _row("watch_movie", "영화 시청내역", url("WATCH", stype="movie")),
    ],
}


def rows_for(chip):
    return [dict(r) for r in ROWS.get(chip, ())]


def search_rows(query):
    q = (query or "").strip()
    return [
        _row("search_vod:%s" % q, "프로그램 검색 결과", url("LOCAL_SEARCH", stype="vod", search_key=q, page="1")),
        _row("search_movie:%s" % q, "영화 검색 결과", url("LOCAL_SEARCH", stype="movie", search_key=q, page="1")),
    ]


def episode_rows(programcode):
    return [_row("ep:%s" % programcode, "회차", url("EPISODE", programcode=programcode, page="1"), shape="wide")]


# ------------------------------------------------------------ add-on state
# (installed/enabled check for every OTT add-on: pkm_ott.installed)

def account_set():
    """TVING MINI pops its own login dialog when id/pw are empty; check first."""
    try:
        a = xbmcaddon.Addon(ADDON_ID)
        return bool(a.getSetting("id")) and bool(a.getSetting("pw"))
    except Exception:
        return False


def open_addon_settings(addon_id=ADDON_ID):
    if xbmc is not None:
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id)


def episode_order():
    try:
        return xbmcaddon.Addon(ADDON_ID).getSetting("tving_orderby") or "desc"
    except Exception:
        return "desc"


def set_episode_order(order):
    """Same storage TVING MINI's ORDER_BY mode writes (tving_orderby + window prop)."""
    order = "asc" if order == "asc" else "desc"
    try:
        xbmcaddon.Addon(ADDON_ID).setSetting("tving_orderby", order)
        import xbmcgui
        xbmcgui.Window(10000).setProperty("TVING_M_ORDERBY", order)
    except Exception:
        log("SET_ORDER_FAILED order=%s" % order)


# ------------------------------------------------------------ directory -> rows

def _clean(text):
    return _TAG_RE.sub("", str(text or "")).strip()


def _mode_of(path):
    m = re.search(r"[?&]mode=([A-Za-z_]+)", path or "")
    return m.group(1) if m else ""


_DATE_TITLE_RE = re.compile(r"^\d{4}[-./]\d{1,2}[-./]\d{1,2}$")
_TIME_LINE_RE = re.compile(r"^\[\s*(\d{1,2}:\d{2})\s*~\s*(\d{1,2}:\d{2})\s*\]$")
_RAW_TYPE_LINES = ("tvshow", "movie", "episode", "season", "vod", "live", "(all)")
_KV_LINE_RE = re.compile(r"^(year|season|seasons|rating|age)\s*:", re.I)


def _tidy_plot(plot, title, sub):
    """R112: add-on plots repeat the label, carry raw type tokens ("tvshow"),
    key/value dumps ("Year : 2025") or a live EPG.  Returns (plot, on_air):
    the EPG becomes "now" (into meta) plus a short "이후" list."""
    lines = [l.strip() for l in str(plot or "").replace("\r", "").split("\n")]
    lines = [l for l in lines if l]
    drop = {str(title or "").strip().lower(), str(sub or "").strip().lower()}
    kept = []
    for l in lines:
        low = l.lower()
        if low in _RAW_TYPE_LINES or _KV_LINE_RE.match(l):
            continue
        kept.append(l)
    # live EPG: "<program>" then "[hh:mm ~ hh:mm]"
    pairs, rest = [], []
    i = 0
    while i < len(kept):
        t = _TIME_LINE_RE.match(kept[i + 1]) if i + 1 < len(kept) else None
        if t:
            pairs.append((kept[i], "%s ~ %s" % t.groups()))
            i += 2
        else:
            rest.append(kept[i])
            i += 1
    rest = [l for l in rest if l.lower() not in drop]
    on_air = ""
    if pairs:
        if pairs[0][0].lower() in drop:
            on_air = pairs[0][1]
            pairs = pairs[1:]
        nxt = ["%s  %s" % (p, t) for p, t in pairs[:3]]
        if nxt:
            rest.append("이후  " + "  ·  ".join(nxt))
    return "\n".join(rest), on_air


def convert(files, live=False):
    """GetDirectory files -> ({items}, more_url).  Pure: no Kodi calls."""
    items, more = [], ""
    for f in files or []:
        label = _clean(f.get("label") or f.get("title"))
        path = f.get("file") or ""
        if not label or not path:
            continue
        if _MORE_LABEL in label:
            more = path
            continue
        if _SKIP_LABEL_RE.search(label) or _mode_of(path) in _SKIP_MODES:
            continue
        art = f.get("art") or {}
        thumb = art.get("poster") or art.get("thumb") or f.get("thumbnail") or ""
        title, sub = label, ""
        ftype = str(f.get("type") or "").lower()
        m = _LIVE_LABEL_RE.match(label)
        if m:
            if ftype in ("tvshow", "movie") and not live:
                # R112: Coupang style "<title> < <category> >" (titles, not channels)
                title, sub = m.group(1).strip(), m.group(2).strip()
            else:
                sub, title = m.group(1).strip(), m.group(2).strip()
        year = str(f.get("year") or "").strip()
        if year and year != "0":
            # R112: "태풍이 지나가고  (2016)" -> the year is shown in meta already
            title = re.sub(r"\s*\(%s\)\s*$" % re.escape(year), "", title).strip() or title
        title = re.sub(r"\s{2,}", " ", title)
        on_air = ""
        plot = _clean(f.get("plot"))
        plot, on_air = _tidy_plot(plot, title, sub)
        if _DATE_TITLE_RE.match(title) and sub:
            # R112: TVING episodes are labelled by air date; the episode name is the title
            title, sub = sub, title
        meta = []
        for v in (sub or f.get("studio"), on_air, year if year != "0" else "", f.get("genre")):
            if isinstance(v, (list, tuple)):
                v = ", ".join(str(x) for x in v if x)
            if v and str(v) not in ("0",) and not any(str(v) in m_ for m_ in meta):
                meta.append(str(v))
        dur = int(f.get("duration") or 0)
        if dur > 0:
            meta.append("%d분" % max(1, dur // 60))
        kind = "folder" if f.get("filetype") == "directory" else "play"
        items.append({
            "title": title,
            "sub": sub,
            "file": path,
            "kind": kind,
            "thumb": thumb,
            "fanart": art.get("fanart") or thumb,
            "plot": plot,
            "meta": "  ·  ".join(meta),
            "live": bool(live),
            "type": f.get("type") or "",
            # V2807: a folder with its own artwork is a title (show/program);
            # one without is a menu category that becomes a row of its own.
            "content": kind == "play" or _real_art(thumb),
        })
        if len(items) >= MAX_ROW_ITEMS:
            break
    return items, more


def get_directory(path):
    """Raw Files.GetDirectory; raises RuntimeError on a JSON-RPC error."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": path, "media": "video",
                      "properties": ["title", "art", "thumbnail", "plot", "genre", "year",
                                     "studio", "duration"]}}
    t0 = time.time()
    raw = xbmc.executeJSONRPC(json.dumps(req))
    res = json.loads(raw or "{}")
    if "error" in res:
        raise RuntimeError(str(res["error"]))
    files = (res.get("result") or {}).get("files") or []
    log("DIR mode=%s n=%d ms=%d" % (_mode_of(path), len(files), int((time.time() - t0) * 1000)))
    return files


def fetch(path, live=False):
    items, more = convert(get_directory(path), live=live)
    return {"items": items, "more": more}


def expand_rows(path, title="", key_prefix="dyn"):
    """Menu folder -> row definitions: each category sub-folder becomes a row.

    V2807: titles/episodes listed directly in the folder become one first row
    (already fetched here, so it is cached and not fetched again).
    shape=None: the screen picks poster/wide from what the row holds.
    """
    items, more = convert(get_directory(path))
    rows = []
    direct = [it for it in items if it["content"]]
    if direct:
        key = "%s:items:%s" % (key_prefix, path)
        cache_put(key, {"items": direct, "more": more})
        rows.append(_row(key, title or "목록", path, shape=None))
    for it in items:
        if not it["content"]:
            rows.append(_row("%s:%s" % (key_prefix, it["file"]), it["title"], it["file"], shape=None))
    return rows


def _real_art(url):
    """False for empty/Kodi default/add-on menu icons (NightRain img/*.png)."""
    u = unquote(str(url or ""))
    if u.startswith("image://"):
        u = u[len("image://"):]
    u = u.rstrip("/").replace("\\", "/")
    if not u or u.startswith("Default"):
        return False
    return not ("/plugin.video." in u and "/img/" in u)


# ------------------------------------------------------------ cache

def _cache_path():
    try:
        import xbmcvfs
        base = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    except Exception:
        base = xbmc.translatePath("special://profile/addon_data/plugin.video.km/")
    if not os.path.isdir(base):
        os.makedirs(base)
    return os.path.join(base, "tving_rows_r112.json")


def _load():
    global _CACHE
    if _CACHE is None:
        try:
            with open(_cache_path(), "r", encoding="utf-8") as f:
                _CACHE = json.load(f)
        except Exception:
            _CACHE = {}
    return _CACHE


def cache_get(key):
    with _CACHE_LOCK:
        return _load().get(key)


def cache_put(key, data):
    with _CACHE_LOCK:
        cache = _load()
        cache[key] = dict(data, t=time.time())
        # Directories churn (search keys, episode pages): keep the newest 80.
        if len(cache) > 80:
            for old in sorted(cache, key=lambda k: cache[k].get("t", 0))[:-80]:
                cache.pop(old, None)
        path = _cache_path()
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cache, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
        except Exception:
            log("CACHE_WRITE_FAILED")


def is_fresh(entry, live=False):
    if not entry:
        return False
    return time.time() - float(entry.get("t") or 0) < (LIVE_TTL_SEC if live else CACHE_TTL_SEC)
