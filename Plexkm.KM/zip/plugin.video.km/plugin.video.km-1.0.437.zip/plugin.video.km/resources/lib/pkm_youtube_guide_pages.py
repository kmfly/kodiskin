# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Phone pages for PKM YouTube setup (R79): one step per screen.

Each kind is a small wizard: progress dots, [이전]/[다음], one console
button per step, and the pitfalls KM actually hit folded into a
"막혔나요?" box on the step where they happen.
  apikey  - 3단계 API 키 (form at the end)
  oauth   - 3단계 내 구독 연결 (client form, then the google.com/device step)
  perm    - 4단계 영구 연결 (GitHub Pages + 브랜딩 + 게시); site files served
  backup  - 백업 파일 받기 / 올려서 복원
"""

import json

C = "https://console.cloud.google.com"

CSS = """
:root{color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:#0f0f0f;color:#f1f1f1;font:16px/1.55 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}
main{max-width:520px;margin:0 auto;padding:22px 18px 120px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:18px}
.logo{width:28px;height:20px;border-radius:6px;background:#ff0033;display:inline-flex;align-items:center;justify-content:center}
.logo:after{content:"";border-left:8px solid #fff;border-top:5px solid transparent;border-bottom:5px solid transparent;margin-left:2px}
.sub{color:#aaa;font-size:13px;margin-top:2px}
.dots{display:flex;gap:6px;margin:18px 0 6px}
.dot{flex:1;height:4px;border-radius:2px;background:#303030}.dot.done{background:#3ea6ff}.dot.on{background:#f1f1f1}
.prog{color:#aaa;font-size:13px}
h1{font-size:22px;margin:10px 0 8px;line-height:1.3}
p{color:#cfcfcf;margin:10px 0}
b{color:#fff}
.go{display:block;text-align:center;margin:16px 0;padding:14px;border-radius:24px;background:#263850;color:#3ea6ff;text-decoration:none;font-weight:700}
.go.dl{background:#1f3324;color:#7cdb8a}
.do{margin:12px 0;padding:12px 14px;border-radius:12px;background:#1c1c1c;border-left:3px solid #3ea6ff}
.do li{margin:6px 0}.do ol{margin:0;padding-left:20px;color:#e6e6e6}
.warn{color:#ffb74d}.nx{margin:12px 0;padding:10px 12px;border-radius:10px;background:#12351f;color:#8be0a4}
.okline{margin:12px 0;padding:10px 14px;border-radius:12px;background:#12261a;color:#8be0a4;font-size:14px}
details{margin:14px 0;border-radius:12px;background:#1e1e1e;border:1px solid #3a3020}
summary{padding:12px 14px;color:#ffb74d;font-weight:700;cursor:pointer}
details div{padding:0 14px 6px}details p{font-size:14px}
label{display:block;margin:16px 0 6px;color:#aaa;font-size:14px}
input,textarea{width:100%;padding:13px;border-radius:12px;border:1px solid #3f3f3f;background:#212121;color:#fff;font:15px ui-monospace,Menlo,monospace}
input:focus,textarea:focus{outline:2px solid #3ea6ff;border-color:transparent}
.btn{width:100%;margin-top:14px;padding:14px;border:0;border-radius:24px;background:#f1f1f1;color:#0f0f0f;font-weight:700;font-size:16px}
.copy{display:flex;gap:8px;align-items:center;margin:8px 0}
.copy input{flex:1;font-size:13px;padding:10px}
.copy button{flex:none;padding:10px 12px;border:0;border-radius:10px;background:#303030;color:#fff;font-size:13px}
.msg{margin:14px 0;padding:14px;border-radius:12px;background:#212121}
.ok{border-left:4px solid #2ba640}.bad{border-left:4px solid #ff4e45}
.nav{position:fixed;left:0;right:0;bottom:0;background:#0f0f0fee;border-top:1px solid #222;padding:12px 18px calc(12px + env(safe-area-inset-bottom))}
.nav div{max-width:520px;margin:0 auto;display:flex;gap:10px}
.nav button{flex:1;padding:14px;border-radius:24px;border:0;font-weight:700;font-size:16px}
.prev{background:#272727;color:#ddd}.next{background:#3ea6ff;color:#06121f}
.done-box{text-align:center;padding:26px 10px}.big{font-size:44px}
.foot{color:#777;font-size:12px;margin-top:26px}
"""

JS = """
(function(){
var S=[].slice.call(document.querySelectorAll('.wz')),i=0,K='pkmyt_wz_'+document.body.getAttribute('data-k');
var P=document.getElementById('prev'),N=document.getElementById('next');
function show(n){i=Math.max(0,Math.min(S.length-1,n));S.forEach(function(e,j){e.style.display=j===i?'block':'none'});
 var d=document.querySelectorAll('.dot');for(var j=0;j<d.length;j++){d[j].className='dot'+(j<i?' done':(j===i?' on':''))}
 document.getElementById('prog').textContent=(i+1)+' / '+S.length+'  ·  '+(S[i].getAttribute('data-t')||'');
 P.style.visibility=i===0?'hidden':'visible';var last=i===S.length-1;N.style.display=(last||S[i].hasAttribute('data-form'))?'none':'block';
 N.textContent=i===0?(document.body.getAttribute('data-k')==='backup'?'복원 화면으로':'시작하기'):'완료했어요 · 다음';try{localStorage.setItem(K,String(i))}catch(e){}window.scrollTo(0,0)}
P.onclick=function(){show(i-1)};N.onclick=function(){show(i+1)};
document.addEventListener('click',function(e){var t=e.target;while(t&&t!==document){if(t.getAttribute&&t.getAttribute('data-goto')){e.preventDefault();show(+t.getAttribute('data-goto'));return}
 if(t.getAttribute&&t.getAttribute('data-copytext')){e.preventDefault();var el=document.getElementById(t.getAttribute('data-copytext')),ta=document.createElement('textarea');ta.value=(el.textContent||'').trim();if(ta.value.indexOf('준비')===0||ta.value.length<6){t.textContent='아직 코드가 없어요 · 앞 화면에서 [저장하고 TV에서 로그인 시작]';return}ta.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(ta);ta.focus();ta.select();ta.setSelectionRange(0,99);
 try{document.execCommand('copy');t.textContent='복사됨 · 이제 google.com/device 에 붙여넣기'}catch(x){t.textContent='코드를 길게 눌러 복사'}document.body.removeChild(ta);return}
 if(t.getAttribute&&t.getAttribute('data-copy')){e.preventDefault();var inp=document.getElementById(t.getAttribute('data-copy'));inp.select();inp.setSelectionRange(0,999);
 try{document.execCommand('copy');t.textContent='복사됨'}catch(x){t.textContent='길게 눌러 복사'}return}t=t.parentNode}});
var gid=document.getElementById('gid');
function gh(){var v=(gid&&gid.value||'').trim().toLowerCase();try{localStorage.setItem('pkmyt_gid',v)}catch(e){}
 var id=v||'내아이디';[].forEach.call(document.querySelectorAll('[data-g]'),function(e){var s=e.getAttribute('data-g').replace(/ID/g,id);
 if(e.tagName==='INPUT')e.value=s;else if(e.tagName==='A')e.href=s;else e.textContent=s})}
if(gid){try{gid.value=localStorage.getItem('pkmyt_gid')||''}catch(e){}gid.oninput=gh;gh()}
var ls=document.getElementById('ls');
if(ls){var base=location.pathname.replace(/\\/$/,'');var lc=document.getElementById('lc'),lm=document.getElementById('lm');
 function tick(){var x=new XMLHttpRequest();x.open('GET',base+'/status.json?'+Date.now());x.onload=function(){try{var d=JSON.parse(x.responseText)||{};
  if(d.code)lc.textContent=d.code;
  var m={code:'코드를 입력하고 계정을 허용하세요. 허용하면 자동으로 이어집니다.',syncing:d.msg,done:'✅ '+(d.msg||'연결되었습니다')+' · TV를 확인하세요',error:'⚠ '+(d.msg||'실패했습니다')}[d.state];
  if(m)lm.textContent=m;ls.style.borderLeftColor=d.state==='done'?'#2ba640':(d.state==='error'?'#ff4e45':'#3ea6ff')}catch(e){}};x.send()}
 setInterval(tick,2000);tick()}
var st=0;try{st=+(localStorage.getItem(K)||0)}catch(e){}
var ok=document.querySelector('.msg.ok'),bad=document.querySelector('.msg.bad');
if(ok){var a=document.querySelector('[data-after]');st=a?+a.getAttribute('data-after'):S.length-1}
else if(bad){var f=document.querySelector('[data-form]');st=f?S.indexOf(f):st}
show(st);
})();
"""


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _stuck(items):
    if not items:
        return ""
    body = "".join("<p><b>%s</b><br>%s</p>" % (q, a) for q, a in items)
    return '<details><summary>막혔나요?</summary><div>%s</div></details>' % body


def _step(title, short, html, button=None, stuck=None, attrs=""):
    btn = ""
    if button:
        label, url = button[0], button[1]
        cls = "go dl" if len(button) > 2 and button[2] == "dl" else "go"
        extra = ' download' if cls == "go dl" else ' target="_blank" rel="noopener"'
        btn = '<a class="%s" href="%s"%s>%s</a>' % (cls, url, extra, label)
    return '<section class="wz" data-t="%s"%s><h1>%s</h1>%s%s%s</section>' % (
        _esc(short), attrs, title, html, btn, _stuck(stuck))


def _page(kind, title, subtitle, steps, msg_html=""):
    dots = "".join('<span class="dot"></span>' for _ in steps)
    return ('<!doctype html><html lang="ko"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>%s</title><style>%s</style></head><body data-k="%s"><main>'
            '<div class="brand"><span class="logo"></span>PlexKM YouTube</div><div class="sub">%s</div>'
            '<div class="dots">%s</div><div class="prog" id="prog"></div>%s%s'
            '</main><div class="nav"><div><button class="prev" id="prev">이전</button>'
            '<button class="next" id="next">다음</button></div></div><script>%s</script></body></html>') % (
        _esc(title), CSS, kind, subtitle, dots, msg_html, "".join(steps), JS)


# ------------------------------------------------------------------ 3단계 API 키

def apikey_page(msg_html=""):
    steps = [
        _step("API 키 넣기", "소개",
              "<p>API 키를 넣으면 PlexKM 유튜브에 <b>실제 한국 인기 차트</b>(인기 급상승, 뉴스·음악·스포츠·게임 순위)가 나옵니다.</p>"
              "<div class='do'><ol><li><b>구글 로그인:</b> 이 휴대폰 브라우저에서 구글에 로그인돼 있어야 합니다. 이미 로그인했으면 바로 아래 <b>시작하기</b>, 아직이면 <b>구글 로그인 열기</b>로 로그인한 뒤 뒤로가기로 돌아오세요</li>"
              "<li>이 안내 페이지는 TV의 QR로 연 것입니다. 이제 <b>TV 화면의 안내</b>를 보면서 진행합니다</li>"
              "<li>각 단계에서 이 페이지의 <b>열기 버튼</b>으로 구글 화면을 열어 작업하고, 뒤로가기로 돌아와 TV 안내대로 오른쪽 아래 <b>다음</b>을 누릅니다</li></ol></div>"
              "<p>API 키 생성은 무료입니다.</p>"
              "<p>API 키는 <b>만료되지 않습니다.</b> 한 번 넣으면 끝.</p>",
              ("구글 로그인 열기", "https://accounts.google.com/")),
        _step("구글 클라우드 콘솔 열기", "콘솔",
              "<div class='do'><ol><li>아래 버튼으로 콘솔을 엽니다 (구글 로그인은 앞 단계에서 끝낸 상태)</li>"
              "<li>처음이면 국가 <b>대한민국</b> · 약관 동의 → [동의 및 계속]</li></ol></div>"
              "<p class='nx'>▶ <b>이렇게 되면 아래 [다음]</b>: 구글 클라우드 첫 화면(시작하기, 작업 중인 프로젝트가 보이는 화면)이 나오면</p>",
              ("콘솔 열기", C + "/"),
              [("화면이 영어예요", "오른쪽 위 ⋮ → Preferences → Language에서 한국어로 바꿀 수 있습니다. 영어로 해도 순서는 같습니다.")]),
        _step("프로젝트 준비", "프로젝트",
              "<p>휴대폰 구글 클라우드 첫 화면의 <b>작업 중인 프로젝트:</b> 옆 <b>파란 이름 버튼</b>(예: pkm-youtube)을 확인하세요.</p>"
              "<div class='do'><ol><li><b>이미 있는 프로젝트를 쓸 때:</b> 그 이름 그대로 두면 됩니다</li>"
              "<li><b>새로 만들 때:</b> 그 <b>파란 이름 버튼</b>을 누르고 → 프로젝트 선택 창의 <b>[새 프로젝트]</b> → 이름 입력(예: pkm-youtube) → <b>[만들기]</b></li>"
              "<li>만든 뒤 위쪽 알림이 뜨면 <b>프로젝트 선택</b>을 눌러 새 프로젝트로 바꿉니다</li></ol></div>"
              "<p class='nx'>▶ <b>이렇게 되면 아래 [다음]</b>: \"작업 중인 프로젝트\"에 쓸 프로젝트 이름이 보이면 (새로 만들었다면 새 이름인지 확인)</p>",
              ("새 프로젝트 만들기", C + "/projectcreate"),
              [("새 프로젝트 화면의 노란 경고 \"projects 할당량이 N개 남았습니다\"", "아직 더 만들 수 있다는 안내입니다. 무시하고 진행하세요."),
               ("프로젝트 이름과 ID", "이름은 pkm-youtube 처럼 알아볼 이름이면 됩니다. 아래 프로젝트 ID는 자동으로 정해지며 나중에 바꿀 수 없습니다."),
               ("상위 리소스가 \"조직 없음\"이에요", "개인 구글 계정에는 조직이 없어서 정상입니다. 건드리지 말고 그대로 [만들기]를 누르세요."),
               ("왼쪽 위에 프로젝트 버튼이 없어요", "휴대폰 화면에는 없습니다. 콘솔 첫 화면의 <b>작업 중인 프로젝트</b>를 보세요. ☰ 메뉴를 열면 맨 위에도 프로젝트 이름이 있습니다.")]),
        _step("YouTube Data API v3 켜기", "API 켜기",
              "<p class='warn'>★ 이 단계를 꼭 먼저 하세요.</p>"
              "<div class='do'><ol><li>아래 버튼으로 엽니다</li><li>파란 <b>[사용]</b></li></ol></div>"
              "<p class='nx'>▶ <b>이렇게 되면 아래 [다음]</b>: 화면에 <b>상태: 사용 설정됨</b>이 보이거나 [사용] 대신 [관리]가 보이면</p>",
              ("YouTube Data API v3 열기", C + "/apis/library/youtube.googleapis.com"),
              [("[사용] 대신 [관리]가 보여요", "이미 켜져 있습니다. 다음으로 가세요."),
               ("다른 프로젝트가 선택돼 있어요", "위쪽(☰ 메뉴 맨 위) 프로젝트 이름을 눌러 쓸 프로젝트로 바꾼 뒤 다시 여세요.")]),
        _step("API 키 만들기", "키 만들기",
              "<div class='do'><ol><li>아래 버튼 → 위쪽 <b>[+ 사용자 인증 정보 만들기]</b></li><li><b>[API 키]</b> 선택 (OAuth 클라이언트 ID 아님)</li>"
              "<li>파란 \"서비스 계정 필요\" 안내는 Gemini용이라 <b>무시</b></li></ol></div>"
              "<p class='nx'>▶ <b>이렇게 되면 아래 [다음]</b>: [API 키]를 고르고 <b>API 키 만들기</b> 설정 화면(이름·제한 선택)이 나오면</p>",
              ("사용자 인증 정보 열기", C + "/apis/credentials"),
              [("\"동의 화면 구성\"이 나와요", "OAuth 쪽으로 잘못 들어간 것입니다. API 키에는 필요 없습니다. 닫고 [API 키]를 고르세요."),
               ("\"어떤 데이터에 액세스?\"를 물어봐요", "<b>공개 데이터</b>를 고르세요. (사용자 데이터를 고르면 동의 화면으로 갑니다)")]),
        _step("제한 고르고 만들기", "제한",
              "<div class='do'><ol><li><b>API 제한사항 선택</b> → 필터에 <b>youtube</b> → <b>YouTube Data API v3</b> 체크 → [확인]</li>"
              "<li>아래 <b>애플리케이션 유형</b>(웹사이트 · IP · Android · iOS)은 <span class='warn'>아무것도 고르지 않기</span></li>"
              "<li>[만들기]</li></ol></div>"
              "<p class='nx'>▶ <b>이렇게 되면 아래 [다음]</b>: <b>API 키 생성됨</b> 창에 키가 보이면</p>",
              None,
              [("목록에 YouTube가 없어요", "아직 API를 안 켠 것입니다. <a href='#' data-goto='3'>← API 켜기 단계로</a>"),
               ("애플리케이션 유형을 골랐어요", "키 수정 → 애플리케이션 제한사항 <b>없음</b>으로 바꾸세요. 제한이 있으면 안드로이드 기기에서 키가 거부됩니다."),
               ("\"프로덕션에서 사용하기 전에 이 키를 제한\" 경고", "보안 권고일 뿐입니다. 위처럼 API 제한을 걸었으면 끝입니다.")]),
        _step("복사해서 붙여넣기", "붙여넣기",
              "<div class='do'><ol><li>만들어진 키 옆 <b>복사 아이콘</b> (화면엔 일부만 보여도 39자 전체가 복사됨)</li>"
              "<li>아래 칸에 붙여넣기 → <b>저장</b></li></ol></div>"
              "<p class='nx'>▶ 저장을 누르면 TV가 확인하고 자동으로 완료 화면으로 넘어갑니다.</p>"
              "<form method='post' autocomplete='off'><label for='k'>API 키</label>"
              "<input id='k' name='key' placeholder='AIza…' autocapitalize='off' autocorrect='off' spellcheck='false'>"
              "<button class='btn' type='submit'>저장</button></form>",
              None,
              [("키를 다시 보고 싶어요", "사용자 인증 정보 → <b>API 키 1개</b> → [키 표시]")],
              attrs=" data-form"),
        _step("완료", "완료",
              "<div class='done-box'><div class='big'>✅</div><p><b>TV 화면을 보세요.</b> 설정에서 뒤로 나가면 인기 차트를 새로 불러옵니다.</p>"
              "<p>내 유튜브 구독도 보고 싶다면 TV 설정 → <b>3 내 구독 연결</b>.</p></div>",
              attrs=" data-after='7'"),
    ]
    return _page("apikey", "PlexKM · API 키", "3단계 · API 키", steps, msg_html)


# ------------------------------------------------------------------ 3단계 내 구독 연결

def oauth_page(msg_html=""):
    # R360: the manual steps live in the TV guide; the phone only receives ID/secret and shows the code.
    steps = [
        _step("ID와 비밀번호 붙여넣기", "붙여넣기",
              "<p>방금 창의 <b>클라이언트 ID</b>와 <b>클라이언트 보안 비밀번호</b>를 각각 복사해 붙여넣으세요.</p>"
              "<form method='post' autocomplete='off'><label for='c'>클라이언트 ID</label>"
              "<input id='c' name='client_id' placeholder='….apps.googleusercontent.com' autocapitalize='off' autocorrect='off' spellcheck='false'>"
              "<label for='s'>클라이언트 보안 비밀번호</label>"
              "<input id='s' name='client_secret' placeholder='GOCSPX-…' autocapitalize='off' autocorrect='off' spellcheck='false'>"
              "<button class='btn' type='submit'>저장하고 TV에서 로그인 시작</button></form>",
              None,
              [("인증에 실패했어요 · 처음부터 다시 · 비밀번호가 안 보여요",
                "구글 콘솔 → 돋보기에 <b>클라이언트</b> 검색 → <b>TV 클라이언트 1개</b> 누르기 → <b>⋮ 삼선 메뉴 → ⓘ 정보 표시</b>에서 클라이언트 ID를 확인합니다. "
                "<b>보안 비밀번호는 다시 볼 수 없어요.</b> 같은 화면 아래 <b>[+ Add secret]</b>으로 새로 만들고 바로 복사해 위 칸에 붙여넣은 뒤 다시 인증하세요."),
               ("붙여넣은 비밀번호에 * 가 섞였어요", "같은 화면 <b>[+ Add secret]</b>으로 새로 만들고 바로 복사하세요.")],
              attrs=" data-form"),
        _step("TV 코드로 로그인", "로그인",
              "<div class='do'><ol><li>아래 버튼 → TV에 뜬 <b>코드</b> 입력 → 계정 선택</li>"
              "<li><b>\"Google에서 확인하지 않은 앱\"</b> → <b>[고급]</b> → <b>[(앱 이름)(으)로 이동(안전하지 않음)]</b></li>"
              "<li>[계속] / [허용] → TV에 \"연결됨 · 구독 N개\"</li></ol></div>"
              "<p>내가 만든 내 앱이라 경고는 정상입니다.</p>"
              "<div class='do' id='ls'><p>TV 코드</p><b id='lc' style='font-size:32px;letter-spacing:4px;user-select:all;-webkit-user-select:all'>코드 대기 중</b>"
              "<button data-copytext='lc' style='display:block;width:100%;margin-top:12px;padding:14px;border:0;border-radius:14px;background:#3ea6ff;color:#06121f;font-size:17px;font-weight:700'>코드 복사</button>"
              "<p id='lm'>값을 저장하면 여기에 코드가 나타납니다.</p></div>",
              ("google.com/device 열기", "https://www.google.com/device"),
              [("\"액세스 차단됨 … 테스트 중\"", "앱이 아직 <b>테스트</b> 상태입니다. TV 안내의 \"프로덕션으로 게시\" 단계를 먼저 끝내세요."),
               ("연결이 풀렸어요", "TV 설정 → <b>3 내 구독 연결</b> → OK → 새 코드 입력(1분).")],
              attrs=" data-after='1'"),
    ]
    return _page("oauth", "PlexKM · 내 구독 연결", "내 구독 연결 · 처음부터 순서대로", steps, msg_html)


# ------------------------------------------------------------------ 4단계 영구 연결

def perm_page(msg_html=""):
    rows = lambda: (
        "<label>홈페이지</label><div class='copy'><input id='u1' readonly data-g='https://ID.github.io/'><button data-copy='u1'>복사</button></div>"
        "<label>개인정보처리방침</label><div class='copy'><input id='u2' readonly data-g='https://ID.github.io/privacy.html'><button data-copy='u2'>복사</button></div>"
        "<label>승인된 도메인</label><div class='copy'><input id='u3' readonly data-g='ID.github.io'><button data-copy='u3'>복사</button></div>")
    steps = [
        _step("계정 연결을 영구로", "소개",
              "<p>3단계 계정 연결은 \"테스트\" 상태라 7일마다 풀립니다. 앱을 <b>프로덕션</b>으로 게시하면 안 풀립니다.</p>"
              "<p>게시하려면 구글이 <b>홈페이지와 개인정보처리방침 페이지</b>를 요구합니다. GitHub에서 무료로 만듭니다(약 15분). 올릴 파일은 PlexKM이 준비해 둡니다.</p>"),
        _step("GitHub 아이디", "GitHub",
              "<div class='do'><ol><li>아래 버튼으로 GitHub 로그인 (없으면 Sign up)</li><li>오른쪽 위 프로필의 <b>아이디</b>를 아래에 입력</li></ol></div>"
              "<label for='gid'>GitHub 아이디</label><input id='gid' placeholder='예: kmfly' autocapitalize='off' autocorrect='off' spellcheck='false'>"
              "<p>이 아이디로 이후 주소가 자동으로 만들어집니다.</p>",
              ("github.com 열기", "https://github.com/login")),
        _step("저장소 만들기", "저장소",
              "<div class='do'><ol><li>아래 버튼 → Repository name에 정확히 <b data-g='ID.github.io'></b></li><li><b>Public</b> → [Create repository]</li></ol></div>",
              ("새 저장소 만들기", "https://github.com/new"),
              [("다른 이름으로 만들었어요", "저장소 Settings → Repository name을 <b data-g='ID.github.io'></b>로 바꾸고 [Rename]. 이름이 아이디와 다르면 사이트가 열리지 않습니다.")]),
        _step("파일 두 개 올리기", "파일",
              "<div class='do'><ol><li>아래 두 버튼으로 파일을 휴대폰에 받기</li>"
              "<li>저장소 화면의 <b>uploading an existing file</b> → 두 파일 선택 → [Commit changes]</li></ol></div>"
              "<a class='go dl' href='site/index.html' download>index.html 받기</a>",
              ("privacy.html 받기", "site/privacy.html", "dl")),
        _step("사이트 켜기", "Pages",
              "<div class='do'><ol><li>저장소 <b>Settings → Pages</b></li><li>Deploy from a branch · <b>main</b> · <b>/(root)</b> → Save</li>"
              "<li>1~2분 뒤 아래 버튼으로 열어 PlexKM YouTube 페이지가 보이면 완료</li></ol></div>"
              "<a class='go' data-g='https://ID.github.io/' target='_blank' rel='noopener'>내 사이트 열기</a>",
              None,
              [("404 \"There isn't a GitHub Pages site here\"", "① Code 탭에 두 파일이 있는지 ② Settings → Pages가 main/(root)인지 ③ Actions 탭 배포가 초록 체크인지 확인 후 새로고침.")]),
        _step("브랜딩에 넣기", "브랜딩",
              "<p>아래 값을 복사해 브랜딩 화면의 같은 칸에 넣고 맨 아래 <b>[저장]</b>.</p>" + rows() +
              "<p class='warn'>로고와 서비스 약관은 비워 두세요 (로고 = 구글 심사 대상).</p>",
              ("브랜딩 열기", C + "/auth/branding"),
              [("[저장]이 회색이에요", "바뀐 내용이 없을 때 회색입니다. 칸을 채우면 파랗게 바뀝니다.")]),
        _step("프로덕션으로 게시", "게시",
              "<div class='do'><ol><li>아래 버튼(대상) → 게시 상태 아래 <b>[앱 게시]</b></li><li>\"프로덕션으로 푸시하시겠어요?\" → <b>[확인]</b></li>"
              "<li><b>프로덕션 단계</b>로 바뀌면 완료 (개인용은 심사 필요 없음)</li></ol></div>",
              ("대상(Audience) 열기", C + "/auth/audience"),
              [("[앱 게시]가 회색이에요", "브랜딩에 홈페이지 · 개인정보처리방침 · 승인된 도메인이 다 들어가 저장됐는지 확인하세요. <a href='#' data-goto='5'>← 브랜딩 단계</a>")]),
        _step("완료", "완료",
              "<div class='done-box'><div class='big'>✅</div><p>이제 7일마다 풀리지 않습니다.</p>"
              "<p>TV 설정 → <b>3 내 구독 연결</b> → OK → 새 코드로 한 번만 다시 로그인하세요.</p></div>"),
    ]
    return _page("perm", "PlexKM · 영구 연결", "4단계 · 영구 연결", steps, msg_html)


# ------------------------------------------------------------------ backup

def backup_page(msg_html="", summary="", created=""):
    has = bool(summary)
    steps = [
        _step("설정 백업 · 복원", "백업",
              "<p>PlexKM은 설정이 바뀔 때마다 기기에 자동으로 백업합니다. 휴대폰에도 한 부 받아 두면 Kodi를 지우거나 다른 기기에서도 불러올 수 있습니다.</p>"
              + ("<div class='do'><ol><li>지금 백업: <b>%s</b></li><li>%s</li></ol></div>" % (_esc(summary), _esc(created)) if has else
                 "<p class='warn'>아직 백업할 설정이 없습니다.</p>")
              + ("<a class='go dl' href='backup.json' download='pkm_youtube_backup.json'>백업 파일 받기</a>" if has else "")
              + "<p class='warn'>백업 파일에는 API 키와 계정 로그인 정보가 들어 있습니다. 다른 사람과 공유하지 마세요.</p>"),
        _step("백업에서 복원", "복원",
              "<p>휴대폰에 받아 둔 <b>pkm_youtube_backup.json</b>을 골라 올리면 TV에 바로 복원됩니다.</p>"
              "<input type='file' id='bf' accept='.json,application/json'>"
              "<form method='post' id='rf'><input type='hidden' name='backup' id='bt'>"
              "<button class='btn' type='submit'>복원하기</button></form>"
              "<script>document.getElementById('rf').onsubmit=function(e){var f=document.getElementById('bf').files[0];"
              "if(!f){alert('파일을 고르세요');return false}e.preventDefault();var r=new FileReader();"
              "r.onload=function(){document.getElementById('bt').value=r.result;document.getElementById('rf').submit()};r.readAsText(f)}</script>",
              attrs=" data-form data-after='1'"),
    ]
    return _page("backup", "PlexKM · 백업", "설정 백업 · 복원", steps, msg_html)


def build(kind, msg_html="", **kw):
    if kind == "oauth":
        return oauth_page(msg_html)
    if kind == "perm":
        return perm_page(msg_html)
    if kind == "backup":
        return backup_page(msg_html, **kw)
    return apikey_page(msg_html)


# ------------------------------------------------------------------ GitHub site files (generic)

SITE_INDEX = """<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PlexKM YouTube</title>
<style>body{margin:0;background:#0f0f0f;color:#f1f1f1;font:16px/1.7 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}main{max-width:720px;margin:0 auto;padding:48px 20px}p,li{color:#cfcfcf}a{color:#3ea6ff}</style></head>
<body><main><h1>PlexKM YouTube</h1>
<p>PlexKM YouTube is a personal add-on for the Kodi media center (PlexKM skin) on Android TV devices. It shows YouTube videos, search results and the user's own subscriptions in a TV layout and hands playback to the official YouTube app.</p>
<p>PlexKM YouTube는 안드로이드 TV 기기의 Kodi(PlexKM 스킨)에서 동작하는 개인용 애드온입니다. 유튜브 영상, 검색 결과, 사용자 본인의 구독 채널을 TV 화면에 맞게 보여 주고 재생은 공식 YouTube 앱으로 넘깁니다.</p>
<h2>Google account access</h2>
<ul><li>Sign-in uses Google's OAuth device flow (google.com/device) with the read-only scope <code>youtube.readonly</code>.</li>
<li>It reads only the signed-in user's subscription list and channel name/avatar to show them on the user's own TV.</li>
<li>It never posts, comments, subscribes, unsubscribes or changes anything in the account.</li></ul>
<p><a href="privacy.html">Privacy Policy / 개인정보처리방침</a></p></main></body></html>
"""

SITE_PRIVACY = """<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PlexKM YouTube - Privacy Policy</title>
<style>body{margin:0;background:#0f0f0f;color:#f1f1f1;font:16px/1.7 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}main{max-width:720px;margin:0 auto;padding:48px 20px}p{color:#cfcfcf}a{color:#3ea6ff}</style></head>
<body><main><h1>Privacy Policy / 개인정보처리방침</h1>
<h2>Data accessed</h2><p>With the read-only scope <code>https://www.googleapis.com/auth/youtube.readonly</code> the add-on reads the user's YouTube subscription list (channel IDs, titles, thumbnails) and the user's own channel name and avatar.</p>
<h2>Use</h2><p>Only to display the user's subscriptions and new videos from them inside PlexKM on the user's own TV device.</p>
<h2>Storage</h2><p>Tokens and the subscription list are stored only on the user's own device. Nothing is sent to any server operated by the developer; the add-on talks only to Google/YouTube APIs and public YouTube RSS feeds.</p>
<h2>Sharing</h2><p>Data is not sold, shared or transferred to third parties and is not used for advertising.</p>
<h2>Revoking access</h2><p>Unlink in PlexKM (YouTube 설정 → 계정 연결 해제) or at <a href="https://myaccount.google.com/permissions">myaccount.google.com/permissions</a>.</p>
<h2>Google API Services User Data Policy</h2><p>Use of information received from Google APIs adheres to the <a href="https://developers.google.com/terms/api-services-user-data-policy">Google API Services User Data Policy</a>, including the Limited Use requirements, and the <a href="https://www.youtube.com/t/terms">YouTube Terms of Service</a>.</p>
<h2>한국어 요약</h2><p>읽기 전용 권한으로 본인의 유튜브 구독 목록과 채널 이름만 읽어 본인 TV에 표시합니다. 정보는 사용자 기기에만 저장되며 개발자 서버로 전송되거나 제3자와 공유되지 않습니다. PlexKM의 계정 연결 해제 또는 myaccount.google.com/permissions 에서 언제든 해제할 수 있습니다.</p>
<p><a href="index.html">← PlexKM YouTube</a></p></main></body></html>
"""
