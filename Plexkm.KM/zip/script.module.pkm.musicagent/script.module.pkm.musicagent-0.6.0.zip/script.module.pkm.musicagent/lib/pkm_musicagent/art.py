# -*- coding: utf-8 -*-
"""PlexKM 뮤직 에이전트 - 앨범아트·가수 사진·팬아트·곡 정보 수집(0.6.0).

0.6.0: 찾은 곡의 정식 곡명(t)·가수 이름들(ar)을 저장, item_art 가 title/artist_id 도 준다.
       곡 판정 강화(다른 가수의 비슷한 곡명·노래방/일본어/리마스터 버전·가수 이름이 곡명인 경우 거름).

색인(parser/store 결과)의 가수·곡 이름으로 국내·해외 소스(sources.py)를 차례로 조회해
캐시 파일 두 개에 저장하고, 쓰는 쪽(플러그인)은 item_art() 로 최종 결과만 받는다. Kodi 없이도 동작한다.

  1단계 enrich_fast(idx)    : 가수별 사진·별칭(국내 VIBE→멜론→FLO, 해외 Deezer→VIBE) + 해외 가수 앨범 목록
  2단계 enrich_songs(idx)   : 곡별 앨범아트·앨범명·발매연도·장르·재생시간
                               국내 곡 VIBE→FLO→멜론→Deezer, 해외 곡 Deezer→VIBE→FLO→iTunes(미국)
  3단계 enrich_artists(idx) : 가수 가로 배경·로고(MusicBrainz → fanart.tv), 느리므로 백그라운드
  item_art(item)            : 포스터·배경·가수 사진·로고·앨범·연도·장르·길이 (못 찾은 곡의 대체 규칙 포함)

국내 곡 판단: 가수·제목·파일 이름에 한글이 있거나 가수가 국내 소스에서 확인된 경우.
못 찾은 곡: 같은 제목의 앨범·싱글 자켓 → 그 곡을 부른 가수 사진(곡 검색에서 얻은 것) → 가수 사진 → (쓰는 쪽에서 영상 장면).
캐시는 이어받기된다. 못 찾은 곡은 14일, 못 찾은 가수 배경은 30일 뒤 다시 찾는다.

configure(data_dir, log=None, aborted=None, wait=None, fanart_key=None)
"""
import json
import os
import re
import threading
import time
import unicodedata
from collections import Counter

from . import parser as P
from . import sources as S

VERSION = "0.6.0"
SONG_V = 7
ARTIST_V = 5
MISS_RETRY = 14 * 86400
FANART_RETRY = 30 * 86400

_CFG = {"dir": ".", "log": None, "aborted": None, "wait": None}


def configure(data_dir, log=None, aborted=None, wait=None, fanart_key=None):
    """data_dir: 캐시 json 을 둘 폴더. log(msg, warn=False). aborted() -> 종료 요청 여부. wait(sec) -> 종료 요청이면 True."""
    _CFG["dir"] = data_dir
    _CFG["log"] = log
    _CFG["aborted"] = aborted
    _CFG["wait"] = wait
    S.ABORTED[0] = aborted
    if fanart_key:
        S.FANART_KEY[0] = fanart_key
    _ART_CACHE[0] = None
    _SONG_CACHE[0] = None


def _log(msg, warn=False):
    f = _CFG.get("log")
    if f:
        try:
            f(msg, warn)
        except Exception:
            pass


def _aborted():
    f = _CFG.get("aborted")
    try:
        return bool(f and f())
    except Exception:
        return False


def _wait(sec):
    f = _CFG.get("wait")
    if f:
        return bool(f(sec))
    time.sleep(sec)
    return False


# ------------------------------------------------------------------ 이름 다루기
_KO = re.compile(r"[가-힣]")


def _nfc(x):
    return unicodedata.normalize("NFC", str(x or ""))


def _norm_name(x):
    return re.sub(r"[^0-9a-z가-힣]+", "", _nfc(x).lower())


def _has_ko(x):
    return bool(_KO.search(_nfc(x)))


def _core(x):
    return _norm_name(re.sub(r"[\(\[][^)\]]*[\)\]]", " ", _nfc(x)))


def _name_parts(x):
    """'ITZY(있지)' -> ['itzy있지', '있지', 'itzy'] (정규화한 이름 조각, 2글자 이상)."""
    x = _nfc(x)
    parts = [_norm_name(x)] + [_norm_name(g) for g in re.findall(r"[\(\[]([^\)\]]+)[\)\]]", x)] + [_norm_name(re.sub(r"[\(\[][^\)\]]*[\)\]]", "", x))]
    return [p for p in dict.fromkeys(parts) if len(p) >= 2]


_COLLAB = re.compile(r"\s+[xX]\s+|(?<=\))[xX](?=\S)|(?<=[가-힣])[xX](?=[가-힣])|\s*,\s*|\s*&\s*|\s+with\s+|\s+[Ff]eat\.?\s+|\s*\([Ff]eat")


def _top_split(name):
    """괄호 밖에서만 협업 구분자(X, ',', '&', with, feat)로 나눈다. 'CHEN(첸)XPunch(펀치)' -> ['CHEN(첸)', 'Punch(펀치)']"""
    mask, depth = [], 0
    for c in name:
        if c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        mask.append(c if depth == 0 or c == ")" else "\x00")
    flat = "".join(mask)
    out, pos = [], 0
    for m in _COLLAB.finditer(flat):
        out.append(name[pos:m.start()].strip())
        pos = m.end()
    out.append(name[pos:].strip())
    return [x for x in out if x] or [name]


def _artist_forms(name):
    """'(여자)아이들((G)I-DLE)' -> 시험해 볼 이름들(영문 우선). 끝의 괄호 묶음을 짝을 맞춰 떼어 낸다."""
    name = _nfc(name).strip()
    forms = []
    if name.endswith(")"):
        depth = 0
        for i in range(len(name) - 1, -1, -1):
            c = name[i]
            depth += 1 if c == ")" else (-1 if c == "(" else 0)
            if depth == 0:
                head, inner = name[:i].strip(), name[i + 1:-1].strip()
                if head and inner:
                    pair = (inner, head) if (re.search(r"[A-Za-z]", inner) and not re.search(r"[A-Za-z]", head)) else (head, inner)
                    forms.extend(pair)
                break
    if name not in forms:
        forms.append(name)
    first = _top_split(name)[0]
    if first and first != name:                 # 'A X B', 'A, B' 같은 협업은 첫 가수 이름도 시험한다
        forms.extend(_artist_forms(first)[:2])
    out = []
    for f in forms:
        if f and f not in out:
            out.append(f)
    return out[:4]


_GROUP_MEMBER = re.compile(r"^([A-Za-z0-9][A-Za-z0-9.!'&\-]*(?:\s*\([^)]*\))?)\s+((?:[가-힣]{1,4}|단체)(?:\s*\([^)]*\))?|[A-Z]{2,8}\s*\([^)]*[가-힣][^)]*\))$")


def artist_terms(name):
    """검색에 쓸 가수 이름 후보(앞일수록 우선). 'AOA 민아' -> ['AOA 민아', 'AOA'], 'Kwon Ji Ahn(권지안)' -> ['Kwon Ji Ahn', '권지안', ...]"""
    name = _nfc(name).strip()
    out = []

    def add(x):
        x = re.sub(r"\s+", " ", (x or "")).strip(" -_,&")
        if x and len(_norm_name(x)) >= 1 and x not in out:
            out.append(x)
    for f in _artist_forms(name):
        add(f)
    for piece in dict.fromkeys([name, _top_split(name)[0]]):
        m = _GROUP_MEMBER.match(piece)
        if m:                                   # 'AOA 민아', '9MUSES(나인뮤지스) 세라', '2NE1 BOM(박봄)' -> 그룹 이름
            for f in _artist_forms(m.group(1)):
                add(f)
    for inner in re.findall(r"(?<=\S)\(([^()]*[가-힣][^()]*)\)", name):   # '(정아영-비비드)', '(심은경 & 장미여관)'
        for piece in re.split(r"\s*[-,&]\s*|\s+[xX]\s+|(?<=[가-힣])[xX](?=[가-힣])", inner):
            if _has_ko(piece):
                add(piece)
    return out[:6]


def _want(terms):
    w = set()
    for t in terms:
        for p in _name_parts(t):
            w.add(p)
    return w


def _title_vars(title):
    try:
        tv = set(P.title_variants(title))
    except Exception:
        tv = set()
    tv.add(_norm_name(title))
    tv.add(_core(title))
    return set(x for x in tv if x)


# ------------------------------------------------------------------ 캐시
_ART_LOCK = threading.Lock()
_ART_CACHE = [None]
_SONG_CACHE = [None]


def _art_path():
    return os.path.join(_CFG["dir"], "pkm_mv_artist_art.json")


def _song_path():
    return os.path.join(_CFG["dir"], "pkm_mv_song_cover.json")


def _load(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _dump(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data or {}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass


def artist_art_cache():
    if _ART_CACHE[0] is None:
        _ART_CACHE[0] = _load(_art_path())
    return _ART_CACHE[0]


def song_cover_cache():
    if _SONG_CACHE[0] is None:
        _SONG_CACHE[0] = _load(_song_path())
    return _SONG_CACHE[0]


def _save_art_cache():
    with _ART_LOCK:
        _dump(_art_path(), _ART_CACHE[0])


def _save_song_cache():
    _dump(_song_path(), _SONG_CACHE[0])


def _pkey(path):
    import hashlib
    return hashlib.md5(path.encode("utf-8")).hexdigest()[:12]


def _artists_of(idx):
    """색인의 가수 -> (표시 이름, [곡 제목], 국내 여부)"""
    out = {}
    for it in idx.get("items", []):
        a = (it.get("artist") or "").strip()
        k = _norm_name(a)
        if not (a and k):
            continue
        e = out.setdefault(k, [a, [], False])
        e[1].append(it.get("title") or "")
        if _has_ko(a) or _has_ko(it.get("title")) or _has_ko(os.path.basename(it.get("path") or "")):
            e[2] = True
    return out


# ------------------------------------------------------------------ 1단계: 가수
def _pick_artist(cands, want):
    """이름이 맞는 후보(이미지 있는 것 우선). 같은 이름이 여럿이면 ambiguous=True."""
    hits = [c for c in cands if want.intersection(_name_parts(c.get("name")))]
    if not hits:
        return None, False
    withimg = [c for c in hits if c.get("img")]
    best = (withimg or hits)[0]
    names = set(_norm_name(c.get("name")) for c in hits)
    return best, len(hits) > 1 and len(names) == 1


def _overlap(albums, titles):
    """앨범·싱글 제목 중 우리 곡 제목과 겹치는 개수(동명이인을 가려내는 데 쓴다)."""
    from difflib import SequenceMatcher
    n = 0
    for t in titles:
        tv = _title_vars(t)
        for al in albums:
            av = _title_vars(al.get("t"))
            if any(x == y or (len(x) >= 4 and (x in y or y in x)) or SequenceMatcher(None, x, y).ratio() >= 0.88 for x in tv for y in av):
                n += 1
                break
    return n


def _deezer_artist(terms, want, titles):
    cands, seen = [], set()
    for form in terms[:3]:
        for dz in S.deezer_artists(form):
            if want.intersection(_name_parts(dz.get("name"))) and dz["id"] not in seen:
                seen.add(dz["id"])
                cands.append(dz)
        if cands:
            break
    if not cands:
        return None
    cands.sort(key=lambda d: -d.get("fans", 0))
    best, best_albums, best_n = None, [], -1
    for dz in cands[:3]:
        albums = S.deezer_artist_albums(dz["id"])
        n = _overlap(albums, titles)
        if n > best_n or (n == best_n and len(albums) > len(best_albums)):
            best, best_albums, best_n = dz, albums, n
    if len(cands) > 1 and best_n <= 0:
        return None                     # 동명 가수를 가릴 근거가 없으면 쓰지 않는다
    return {"dz": best["id"], "img": best.get("img") or "", "albums": best_albums, "ov": best_n, "name": best.get("name")}


def _artist_from(src, term, terms, want, titles, ent):
    if src == "vibe":
        return _pick_artist(S.vibe_artists(term), want)
    if src == "melon":
        return _pick_artist(S.melon_suggest(term)["artists"], want)
    if src == "flo":
        return _pick_artist(S.flo_artists(term), want)
    d = _deezer_artist(terms, want, titles)
    if not d:
        return None, False
    ent["albums"] = d["albums"]
    ent["ov"] = d["ov"]
    ent["dz"] = d["dz"]
    return {"id": d["dz"], "img": d["img"], "name": d["name"]}, False


def resolve_artist(name, titles=(), kr=None):
    """가수 한 팀의 사진·별칭·앨범 목록. 네트워크 오류는 예외(다음 실행에서 다시)."""
    terms = artist_terms(name)
    want = _want(terms)
    if kr is None:
        kr = _has_ko(name) or any(_has_ko(t) for t in titles)
    ent = {"v": ARTIST_V, "at": int(time.time()), "kr": bool(kr), "names": [], "albums": []}

    def take(c, src, amb=False):
        ent["thumb"] = c.get("img") or ""
        ent["src"] = src
        ent[src[:3]] = c.get("id") or ""
        ent["cn"] = c.get("name") or ""
        if amb:
            ent["amb"] = 1
        for p in _name_parts(c.get("name")):
            if p not in ent["names"]:
                ent["names"].append(p)
    order = ("vibe", "melon", "flo", "deezer") if kr else ("deezer", "vibe", "flo")
    for src in order:
        if ent.get("thumb"):
            break
        for term in terms[:3]:
            try:
                c, amb = _artist_from(src, term, terms, want, titles, ent)
            except Exception as e:          # 한 소스가 실패해도 다음 소스로 넘어간다
                ent.setdefault("err", []).append(src)
                _log("artist_src_err %s %s %s" % (src, term, str(e)[:60]), True)
                c, amb = None, False
            if c and c.get("img"):
                take(c, src, amb)
                break
            if src == "deezer":
                break
    if ent.get("err") and not ent.get("thumb") and len(set(ent["err"])) >= len(order):
        raise RuntimeError("all sources failed")
    ent.pop("err", None)
    return ent


def enrich_fast(idx, progress=None, only_missing=False):
    """가수 사진·별칭(+해외 가수 앨범 목록). 이미 받은 가수는 건너뛴다(이어받기).
    only_missing=True 면 곡 검색에서 사진을 얻지 못한 가수만 찾는다(scrape 가 쓴다)."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = artist_art_cache()
    arts = _artists_of(idx)
    now = time.time()
    for e in cache.values():                     # 예전에 받은 빈 그림(사람 아이콘)은 없는 것으로 본다
        if e.get("thumb") and S.bad_img(e["thumb"]):
            e.pop("thumb", None)
            e.pop("looked", None)
    if only_missing:
        todo = [(k, v) for k, v in arts.items()
                if (not (cache.get(k) or {}).get("thumb") or (cache.get(k) or {}).get("amb"))
                and ((cache.get(k) or {}).get("v") != ARTIST_V or (cache.get(k) or {}).get("src", "").startswith("song")
                     or now - (cache.get(k) or {}).get("at", 0) > MISS_RETRY or not (cache.get(k) or {}).get("looked"))]
    else:
        todo = [(k, v) for k, v in arts.items()
                if (cache.get(k) or {}).get("v") != ARTIST_V or not (cache.get(k) or {}).get("looked")
                or (not (cache.get(k) or {}).get("thumb") and now - (cache.get(k) or {}).get("at", 0) > MISS_RETRY)]
    _log("fast_start artists=%d todo=%d" % (len(arts), len(todo)))
    done = hit = fail = 0
    changed = set()

    def one(item):
        k, (a, titles, kr) = item
        if _aborted():
            return k, None
        try:
            return k, resolve_artist(a, titles, kr)
        except Exception as e:
            _log("artist_err %s %s" % (a, str(e)[:80]), True)
            return k, None
    with ThreadPoolExecutor(max_workers=6) as ex:
        for k, ent in ex.map(one, todo):
            done += 1
            if ent is None:
                fail += 1
                continue
            old = cache.get(k) or {}
            ent["looked"] = 1
            for key in ("fanart", "fanart2", "banner", "logo", "mbid", "fv", "fat"):     # 3단계 결과는 이어 쓴다
                if old.get(key) and key not in ent:
                    ent[key] = old[key]
            if not ent.get("thumb") and old.get("thumb"):        # 곡 검색에서 얻은 사진은 지우지 않는다
                for key in ("thumb", "src", "cn"):
                    if old.get(key):
                        ent[key] = old[key]
            for p in old.get("names") or []:
                if p not in ent["names"]:
                    ent["names"].append(p)
            if ent.get("cn") != old.get("cn") or set(ent["names"]) != set(old.get("names") or []):
                changed.add(k)
            if not ent.get("albums") and old.get("albums") and (old.get("dz") or old.get("it")):
                ent["albums"] = old["albums"]
            with _ART_LOCK:
                cache[k] = ent
            hit += 1 if ent.get("thumb") else 0
            if done % 50 == 0:
                _save_art_cache()
                if progress:
                    progress(done, len(todo))
    _save_art_cache()
    _log("fast_done looked=%d hits=%d fail=%d changed=%d sec=%.1f" % (done, hit, fail, len(changed), time.time() - t0))
    return {"looked": done, "hits": hit, "failed": fail, "changed": changed}


# ------------------------------------------------------------------ 2단계: 곡
_CLEAN_FN = re.compile(r"\(1080p\)|\(720p\)|\(Official[^)]*\)|\bOfficial\b|\bM_?V\b|Music Video|Performance Video|멀티캠|단체풀샷|[\[\]「」『』【】-_]")


def _song_queries(it, ent):
    artist = _nfc(it.get("artist"))
    title = re.sub(r"(?<=[A-Za-z])_(?=[A-Z])", ".", _nfc(it.get("title"))).replace("_", " ")   # 'L_I_E' -> 'L.I.E
    title = re.sub(r"\s+", " ", title).strip()
    fn = _nfc(os.path.splitext(os.path.basename(it.get("path") or ""))[0])
    tcore = re.sub(r"\s*[\(\[][^)\]]*[\)\]]", "", title).strip() or title
    tcore = re.sub(r"\s+l\s+.*$|\s*(OST|ost)\s*(Part|PART)?\.?\s*\d*$", "", tcore).strip() or tcore
    t_in = [x.strip() for x in re.findall(r"[\(\[]([^)\]]+)[\)\]]", title) if not re.search(r"(?i)feat|with|ost|ver\.?|prod|song by|part", x)]
    tko = [x for x in t_in if _has_ko(x)] or ([tcore] if _has_ko(tcore) else [])
    ten = [x for x in t_in if not _has_ko(x) and re.search(r"[A-Za-z]", x)] or ([tcore] if not _has_ko(tcore) else [])
    terms = artist_terms(artist)
    a_ko = [t for t in terms if _has_ko(t)] + [n for n in ((ent or {}).get("cn") and [(ent or {}).get("cn")] or []) if _has_ko(n)]
    a_en = [t for t in terms if not _has_ko(t)]
    qs = []

    def add(a, t):
        q = re.sub(r"\s+", " ", ("%s %s" % (a or "", t or ""))).strip()
        if a and t and q not in qs:
            qs.append(q)
    first = terms[0] if terms else ""
    add(a_en[0] if a_en else first, tcore)
    add(a_ko[0] if a_ko else first, tko[0] if tko else tcore)
    if ten:
        add(a_en[0] if a_en else first, ten[0])
    if (ent or {}).get("cn"):
        add(ent["cn"], tko[0] if tko else tcore)
    if len(terms) > 1:
        add(terms[-1] if _GROUP_MEMBER.match(artist) else terms[1], tcore)
    # 협업: 괄호 안 한글 이름들을 띄어 쓴 검색어 ('YURI X SEOHYUN(유리 X 서현)' -> '유리 서현 Secret')
    for inner in re.findall(r"(?<=\S)\(([^()]*[가-힣][^()]*)\)", artist):
        names = [x for x in re.split(r"\s*[,&]\s*|\s+[xX]\s+|(?<=[가-힣])[xX](?=[가-힣])", inner) if x.strip()]
        if len(names) >= 2:
            add(" ".join(names[:3]), tko[0] if tko else tcore)
            break
    clean = re.sub(r"\s+", " ", _CLEAN_FN.sub(" ", fn)).strip()
    clean = re.sub(r"\s*\((?:[^()]*\b(?:ver|version|feat|with|from|OST)\b[^()]*)\)", " ", clean, flags=re.I).strip()
    if clean and clean not in qs:
        qs.insert(min(2, len(qs)), clean)       # 파일 이름 그대로의 검색어도 앞쪽에서 한 번 시험한다
    return qs


_NOT_ORIG = re.compile(r"(?i)\binst\b|instrumental|\bMR\b|반주|melody|karaoke|노래방|커버|\bcover\b|remix|\(live\)|originally performed|made famous|오르골|music ?box|lullaby|자장가|태교")
_ALT_VER = re.compile(r"(?i)japan|\bjpn?\b|\(\s*live\b|\blive\s+(?:19|20)\d\d|@|\bjp\.? ver|english ver|chinese ver|\bremaster|\bacoustic|\bpiano ver|\borchestra|\bsped up|\bslowed|\b(?:19|20)\d\d\s*$|\b(?:19|20)\d\d ver")
_MR_MAKERS = set(["musicsum뮤직섬", "musicsum", "뮤직섬", "musicen", "모두의mr", "mr제작소", "karaokekpopbar", "kpopkaraoke"])


def _title_keys(title):
    """검색 결과 곡명의 비교용 키들: 'Decalcomanie (데칼코마니)' -> ['decalcomanie', 'decalcomanie데칼코마니', '데칼코마니']"""
    core = _core(title) or _norm_name(title)
    out = [core, _norm_name(title)]
    for x in re.findall(r"[\(\[]([^)\]]+)[\)\]]", _nfc(title)):
        if not re.search(r"(?i)feat|ver\b|version|prod|solo|with\s|from\s|ost|part", x):
            # 괄호 안은 같은 곡의 다른 글자 표기일 때만('Decalcomanie (데칼코마니)'). 'Dance Twice (Cheer Up)' 은 다른 곡이다
            if _has_ko(x) != _has_ko(core):
                out.append(_norm_name(x))
    return [x for x in dict.fromkeys(out) if len(x) >= 2]


def _accept(r, fnn, aliases, tvars, fnt=None, tsub=None):
    """검색 결과가 이 영상의 곡이면 (가수, 점수), 아니면 None.
    곡명: 결과 곡명(또는 괄호 안 다른 표기)이 우리 곡명 표기와 같으면 2점, 가수 이름을 뺀 파일 이름 안에 들어 있으면 1점.
          1점짜리는 4글자 이상이고 우리 곡명의 절반 이상이어야 한다('The Vow' 에 'Vow' 를 받지 않는다).
    가수: 결과 가수 이름이 파일 이름·별칭과 맞아야 한다. 그룹 명의 솔로곡('덤덤해지네 (Solo 화사)')은 곡명이 같을 때만.
    반주(MR)·Inst.·커버·노래방 음원, 파일에 없는 일본어·리마스터·연도 버전은 받지 않는다."""
    title = r.get("title") or ""
    if _NOT_ORIG.search(title) and not _NOT_ORIG.search(fnn):
        return None
    if _ALT_VER.search(title) and not _ALT_VER.search(fnn):
        return None
    fnt = fnt if fnt is not None else fnn
    tsub = tsub if tsub is not None else "".join(sorted(tvars, key=len)[-1:])
    score = 0
    for tk in _title_keys(title):
        if tk in tvars:
            score = 2
            break
        near = any(v.startswith(tk) for v in tvars) or (_has_ko(tk) and any(v.endswith(tk) for v in tvars))
        if (tk in tsub and (len(tk) >= 4 or near)) or (tk in fnt and len(tk) >= 7):
            score = max(score, 1)
    if not score:
        return None
    long_alias = [x for x in aliases if len(x) >= 3]
    for a in r.get("artists") or []:
        parts = _name_parts(a.get("name"))
        if any(p in _MR_MAKERS for p in parts):
            return None
    for a in r.get("artists") or []:
        parts = _name_parts(a.get("name"))
        if any(p in aliases for p in parts):
            return a, score
        if any((len(p) >= 4 or (len(p) >= 3 and _has_ko(p))) and p in fnn for p in parts):
            return a, score
        if any(x in p for p in parts for x in long_alias):          # '화요비' -> '박화요비'
            return a, score
    tn = _norm_name(title)
    if score == 2 and any(len(x) >= 2 and x in tn for x in aliases):
        return (r.get("artists") or [{}])[0], score               # 그룹 명의 솔로곡
    return None


def _pack(r, a):
    y = (r.get("date") or "")[:4]
    return {"t": r.get("title") or "", "ar": [x.get("name") for x in (r.get("artists") or []) if x.get("name")],
            "c": r.get("cover") or "", "a": r.get("album") or "", "y": y if y.isdigit() else "", "g": r.get("genre") or "",
            "d": int(r.get("sec") or 0), "an": (a or {}).get("name") or "", "ai": (a or {}).get("img") or "",
            "aid": "%s:%s" % (r.get("src"), (a or {}).get("id") or ""), "src": r.get("src")}


def _search(src, q):
    if src == "vibe":
        return S.vibe_tracks(q)
    if src == "flo":
        return S.flo_tracks(q)
    if src == "melon":
        return S.melon_suggest(q)["songs"]
    if src == "deezer":
        return S.deezer_tracks(q)
    if src == "itunes":
        return S.itunes_tracks(q)
    return []


_MAXQ = {"vibe": 5, "flo": 3, "melon": 2, "deezer": 2, "itunes": 1}


def resolve_song(it, ent=None, kr=None):
    """한 영상의 곡 정보. 국내/해외에 따라 소스 순서를 바꾼다. 못 찾으면 {} (네트워크 오류는 예외)."""
    fn = _nfc(os.path.splitext(os.path.basename(it.get("path") or ""))[0])
    fnn = _norm_name(fn)
    ent = ent or {}
    aliases = set(ent.get("names") or [])
    aliases.update(_want(artist_terms(it.get("artist"))))
    tvars = _title_vars(it.get("title"))
    for x in re.findall(r"[\(\[]([^)\]]+)[\)\]]", _nfc(it.get("title"))):
        if not re.search(r"(?i)feat|prod|ver\b|ost|part|from\s", x) and len(_norm_name(x)) >= 2:
            tvars.add(_norm_name(x))               # 'Mr.애매모호(Mr.Ambiguous)' 의 다른 표기
    tvars.add(_core(re.sub(r"(?<=\w)_(?=\w)", "", _nfc(it.get("title")))))
    tvars.discard("")
    tsub = _norm_name(re.sub(r"(?<=\w)_(?=\w)", "", _nfc(it.get("title"))))
    fnt = fnn
    for al in sorted((x for x in aliases if len(x) >= 2), key=len, reverse=True):
        fnt = fnt.replace(al, " ")
    fnt = fnt.replace(" ", "")
    if kr is None:
        kr = _has_ko(fn) or _has_ko(it.get("artist")) or bool(ent.get("kr"))
    order = ("vibe", "flo", "melon", "deezer") if kr else ("deezer", "vibe", "flo", "itunes")
    qs = _song_queries(it, ent)
    errs = 0
    partial = None
    for src in order:
        for q in qs[:_MAXQ[src]]:
            try:
                rs = _search(src, q)
            except Exception:
                errs += 1
                continue
            got = None
            for r in rs:
                a = _accept(r, fnn, aliases, tvars, fnt, tsub)
                if a and r.get("cover") and (got is None or a[1] > got[1][1]):
                    got = (r, a)
                    if a[1] == 2:
                        break
            if got and got[1][1] == 2:
                return _pack(got[0], got[1][0])
            if got and not partial:
                partial = got
    if partial:
        return _pack(partial[0], partial[1][0])
    if _aborted() or (errs and errs * 2 >= sum(min(len(qs), _MAXQ[s]) for s in order)):
        raise RuntimeError("lookup incomplete")   # 일부 요청이 실패했으면 '못 찾음'으로 남기지 않고 다음에 다시 찾는다
    if errs and errs >= sum(min(len(qs), _MAXQ[s]) for s in order):
        raise RuntimeError("all sources failed")
    return {}


def _skey(it):
    return _norm_name(it.get("artist")) + "|" + _norm_name(it.get("title"))


def _song_todo(cache, it):
    e = cache.get(_pkey(it["path"])) or {}
    if e.get("k") and e["k"] != _skey(it):
        return True                      # 이름 해석이 바뀐 영상은 다시 찾는다
    if e.get("v") == SONG_V:
        return bool(e.get("miss")) and time.time() - e.get("at", 0) > MISS_RETRY
    return True                          # 0.6.0: 예전 결과는 정식 곡명이 없어 한 번 다시 찾는다


def enrich_songs(idx, progress=None, only=None):
    """2단계: 곡별 앨범아트·앨범·연도·장르·길이. 찾은 곡의 가수 사진으로 가수 사진이 없거나 애매한 가수를 보충한다."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    cache = song_cover_cache()
    acache = artist_art_cache()
    items = [it for it in idx.get("items", []) if it.get("kind") in ("mv", "broadcast", "concert", "disc", None)]
    if only is not None:
        todo = [it for it in items if _pkey(it["path"]) in only]
    else:
        todo = [it for it in items if _song_todo(cache, it)]
    _log("songs_start total=%d todo=%d" % (len(items), len(todo)))
    S.STATS.clear()

    def one(it):
        if _aborted():
            return it, None
        try:
            return it, resolve_song(it, acache.get(_norm_name(it.get("artist"))))
        except Exception:
            return it, None
    done = hit = fail = 0
    srcs = Counter()
    with ThreadPoolExecutor(max_workers=8) as ex:
        for it, res in ex.map(one, todo):
            done += 1
            if res is None:
                fail += 1
                continue
            res = dict(res, at=int(time.time()), v=SONG_V, k=_skey(it))
            if not res.get("c"):
                res["miss"] = 1
            cache[_pkey(it["path"])] = res
            if res.get("c"):
                hit += 1
                srcs[res.get("src")] += 1
            if done % 100 == 0:
                _save_song_cache()
                if progress:
                    try:
                        progress(done, len(todo))
                    except Exception:
                        pass
    _save_song_cache()
    fixed = _artist_from_songs(idx)
    _log("songs_done looked=%d hits=%d fail=%d src=%s artist_fix=%d req=%s sec=%.1f" % (
        done, hit, fail, ",".join("%s:%d" % kv for kv in srcs.most_common()), fixed,
        ",".join("%s:%d" % kv for kv in sorted(S.STATS.items())), time.time() - t0))
    return {"looked": done, "hits": hit, "failed": fail, "src": dict(srcs)}


def _artist_from_songs(idx):
    """곡 검색에서 확인된 가수 사진(그 곡을 실제로 부른 가수)을 가수 사진이 없거나 동명이인이 애매한 가수에 넣는다."""
    cache = song_cover_cache()
    acache = artist_art_cache()
    votes = {}
    for it in idx.get("items", []):
        e = cache.get(_pkey(it.get("path") or "")) or {}
        k = _norm_name(it.get("artist"))
        if k and e.get("ai") and not S.bad_img(e["ai"]):
            votes.setdefault(k, Counter())[(e["ai"], e.get("an") or "", e.get("aid") or "")] += 1
    n = 0
    with _ART_LOCK:
        for k, cnt in votes.items():
            ent = acache.setdefault(k, {"v": ARTIST_V, "at": int(time.time()), "names": [], "albums": []})
            ent.setdefault("v", ARTIST_V)
            (img, an, aid), c = cnt.most_common(1)[0]
            for p in _name_parts(an):
                if p not in ent.setdefault("names", []):
                    ent["names"].append(p)
            if not ent.get("thumb") or (ent.get("amb") and ent.get("thumb") != img):
                ent["thumb"] = img
                ent["cn"] = ent.get("cn") or an
                ent.pop("amb", None)
                ent["src"] = "song:" + aid
                n += 1
    if n:
        _save_art_cache()
    return n


# ------------------------------------------------------------------ 전체 수집(쓰는 쪽은 이것만 부르면 된다)
def scrape(idx, on_stage=None, every=500):
    """곡(앨범아트·정보·그 곡 가수 사진) → 사진을 못 얻은 가수만 따로 → 가수 별칭이 새로 생긴 못 찾은 곡 재시도.
    on_stage(name): 'songs'(진행 중 every 곡마다·끝), 'artists', 'retry' 때 불린다(쓰는 쪽이 화면을 갱신).
    -> {"total", "art"(그림을 얻은 영상 수), "song", "album", "artist", "sec"}"""
    t0 = time.time()

    def stage(name):
        if on_stage:
            try:
                on_stage(name)
            except Exception:
                pass
    last = [0]

    def prog(done, n):
        if done - last[0] >= every:
            last[0] = done
            stage("songs")
    enrich_songs(idx, progress=prog)
    stage("songs")
    if _aborted():
        return None
    fr = enrich_fast(idx, only_missing=True)
    stage("artists")
    changed = fr.get("changed") or set()
    if changed and not _aborted():
        sc = song_cover_cache()
        retry = set()
        for it in idx.get("items", []):
            pk = _pkey(it.get("path") or "")
            if _norm_name(it.get("artist")) in changed and (sc.get(pk) or {}).get("miss"):
                retry.add(pk)
        if retry:
            enrich_songs(idx, only=retry)
            stage("retry")
    cov = coverage(idx)
    total = len(idx.get("items", []))
    res = {"total": total, "art": total - cov.get("none", 0), "song": cov.get("song", 0), "album": cov.get("album", 0),
           "artist": cov.get("artist", 0), "sec": round(time.time() - t0, 1)}
    _log("scrape_done %s" % json.dumps(res))
    return res


# ------------------------------------------------------------------ 3단계: 가수 배경·로고 (MusicBrainz → fanart.tv)
_KR_DIS = re.compile(r"(?i)korea|k-pop|kpop|girl group|boy group")


def _mb_pick(cands, want, kr):
    hits = [c for c in cands if c["score"] >= 85 and want.intersection(set(p for n in c["names"] for p in _name_parts(n)))]
    if not hits:
        return None
    if kr:
        ko = [c for c in hits if c.get("country") == "KR" or _KR_DIS.search(c.get("dis") or "")]
        if len(ko) > 1:
            names = [set(_norm_name(n) for n in c["names"]) for c in ko[:2]]
            if names[0] & names[1] and ko[0]["score"] - ko[1]["score"] < 10:
                return None              # 같은 이름의 국내 가수가 여럿이면(예: '지연') 가릴 근거가 없어 쓰지 않는다
        if ko:
            return ko[0]
        return hits[0] if len(hits) == 1 and not hits[0].get("country") else None
    exact = [c for c in hits if c["score"] == 100]
    if len(exact) > 1 and not any(c.get("country") for c in exact[1:]):
        return exact[0]
    return (exact or hits)[0] if len(exact) <= 1 else None


def _fanart_one(name, ent):
    terms = artist_terms(name)
    want = _want(terms) | set(ent.get("names") or [])
    qnames = []
    for t in ([ent.get("cn")] if ent.get("cn") else []) + terms:
        if t and t not in qnames:
            qnames.append(t)
    en = [t for t in qnames if not _has_ko(t)]
    ko = [t for t in qnames if _has_ko(t)]
    mb = None
    for i, q in enumerate((en + ko)[:2]):
        cands = S.mb_artists(q)
        mb = _mb_pick(cands, want, ent.get("kr"))
        if mb or (i == 0 and cands and not ko):
            break
    out = {"fv": 1, "fat": int(time.time())}
    if not mb:
        return out
    out["mbid"] = mb["id"]
    fa = S.fanart_artist(mb["id"])
    if fa.get("fanart"):
        out["fanart"] = fa["fanart"][0]
        if len(fa["fanart"]) > 1:
            out["fanart2"] = fa["fanart"][1]
    if fa.get("logo"):
        out["logo"] = fa["logo"][0]
    if fa.get("banner"):
        out["banner"] = fa["banner"][0]
    if fa.get("thumb"):
        out["fthumb"] = fa["thumb"][0]
    return out


def enrich_artists(idx, tick=None):
    """3단계(느림, 백그라운드): 가수 가로 배경·로고. 같은 가수(그룹·멤버 영상)는 한 번만 찾는다. tick(n) 은 80팀마다."""
    t0 = time.time()
    cache = artist_art_cache()
    arts = _artists_of(idx)
    groups = {}
    for k, (a, titles, kr) in arts.items():
        ent = cache.get(k) or {}
        gk = _norm_name(ent.get("cn")) or _norm_name((artist_terms(a) or [a])[-1] if _GROUP_MEMBER.match(a) else a)
        groups.setdefault(gk, []).append((k, a))
    now = time.time()
    todo = []
    for gk, members in groups.items():
        ent = cache.get(members[0][0]) or {}
        if ent.get("fv") and (ent.get("fanart") or now - ent.get("fat", 0) < FANART_RETRY):
            continue
        todo.append((gk, members))
    _log("fanart_start groups=%d todo=%d" % (len(groups), len(todo)))
    n = hits = errs = 0
    for gk, members in todo:
        if _aborted():
            break
        k0, a0 = members[0]
        if _GROUP_MEMBER.match(a0):
            a0 = artist_terms(a0)[-1] if not (cache.get(k0) or {}).get("cn") else a0
        try:
            res = _fanart_one(a0, cache.get(k0) or {"kr": arts[k0][2]})
            errs = 0
        except Exception as e:
            if _aborted():
                break
            errs += 1
            _log("fanart_err %s %s" % (a0, str(e)[:80]), True)
            if errs >= 6:
                _log("fanart_stopped errs=%d" % errs, True)
                break
            if _wait(5.0):
                break
            continue
        with _ART_LOCK:
            for k, _a in members:
                ent = cache.setdefault(k, {"v": ARTIST_V, "at": int(time.time()), "names": [], "albums": []})
                ent.update(res)
                if not ent.get("thumb") and res.get("fthumb"):
                    ent["thumb"] = res["fthumb"]
        hits += 1 if res.get("fanart") else 0
        n += 1
        if n % 10 == 0:
            _save_art_cache()
        if n % 80 == 0 and tick:
            tick(n)
    _save_art_cache()
    _log("fanart_done looked=%d hits=%d sec=%.1f" % (n, hits, time.time() - t0))
    return {"looked": n, "hits": hits}


def enrich_itunes(idx, tick=None):
    """0.4.0 호환용: iTunes 는 이제 해외 곡 검색(2단계)에서 필요한 곡만 쓴다. 여기서는 할 일이 없다."""
    _log("itunes_skip (folded into songs stage)")
    return {"looked": 0, "hits": 0}


# ------------------------------------------------------------------ 결과 조립
def _album_cover_exact(ent, title):
    """확인된 가수의 앨범·싱글 중 제목이 거의 같은 것의 자켓."""
    albums = (ent or {}).get("albums") or []
    if not albums:
        return ""
    from difflib import SequenceMatcher
    tv = _title_vars(title)
    for al in albums:
        av = _title_vars(al.get("t"))
        if any(x and y and (x == y or SequenceMatcher(None, x, y).ratio() >= 0.92) for x in tv for y in av):
            return al.get("c") or ""
    return ""


def _best_cover(ent, title):
    """0.4.0 호환: 같은 제목 앨범 자켓, 없으면 가수 사진(엉뚱한 앨범 자켓은 쓰지 않는다)."""
    return _album_cover_exact(ent, title) or (ent or {}).get("thumb") or ""


def item_art(it):
    """영상 한 개의 최종 그림·정보.
    -> {poster, fanart, artist_thumb, logo, album, year, genre, duration(초), artist_name, src}
       src: song(곡 자켓) / album(같은 제목 앨범) / artist(가수 사진) / "" (못 찾음: 쓰는 쪽에서 영상 장면)"""
    sc = dict(song_cover_cache().get(_pkey(it.get("path") or "")) or {})
    ent = dict(artist_art_cache().get(_norm_name(it.get("artist"))) or {})
    for d in (sc, ent):                          # 예전에 받은 빈 그림(사람 아이콘)은 쓰지 않는다
        for key in ("c", "ai", "thumb", "fanart", "fanart2", "logo"):
            if d.get(key) and S.bad_img(d[key]):
                d.pop(key)
    title = it.get("title") or ""
    poster, src = sc.get("c") or "", "song"
    if not poster:
        poster, src = (it.get("meta") or {}).get("cover") or "", "song"
    if not poster:
        poster, src = _album_cover_exact(ent, title), "album"
    if not poster:
        poster, src = sc.get("ai") or ent.get("thumb") or "", "artist"
    if not poster:
        src = ""
    athumb = ent.get("thumb") or sc.get("ai") or ""
    return {"poster": poster, "fanart": ent.get("fanart") or ent.get("fanart2") or "", "artist_thumb": athumb,
            "logo": ent.get("logo") or "", "album": sc.get("a") or "", "year": sc.get("y") or "", "genre": sc.get("g") or "",
            "duration": int(sc.get("d") or 0), "artist_name": sc.get("an") or ent.get("cn") or "", "src": src,
            "title": sc.get("t") or "", "artists": list(sc.get("ar") or []),
            "artist_id": sc.get("aid") or ent.get("src") or ""}


def coverage(idx):
    """진단용: 포스터 출처별 개수."""
    c = Counter()
    for it in idx.get("items", []):
        r = item_art(it)
        c[r["src"] or "none"] += 1
        c["fanart"] += 1 if r["fanart"] else 0
        c["year"] += 1 if r["year"] else 0
    return dict(c)
