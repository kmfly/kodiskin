# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM OTT add-ons (V2807).

Each add-on below gets a PKM sidebar entry while it is installed and enabled,
and opens the shared OTT screen (pkm_tving_window).  TVING keeps its tuned
chips/rows (pkm_tving).  Every other add-on uses only the menu it shows in
Kodi itself: its root folders become the chips, a chip's category folders
become widget rows, and titles listed directly become one row.  Playback is
always handed back to the add-on via its own plugin:// path.
"""

import re

try:
    import xbmc
except Exception:  # pragma: no cover - tests
    xbmc = None

from resources.lib import pkm_tving as tv

# (id, add-on id, sidebar label, sidebar icon, header colour)
PROVIDERS = (
    ("tving", "plugin.video.tvingm", "TVING", "sb_tving", "FFFF153C"),
    ("wavve", "plugin.video.wavvem", "웨이브", "sb_wavve", "FF1F6BFF"),
    ("watcha", "plugin.video.watcham", "왓챠", "sb_watcha", "FFFF0558"),
    ("coupang", "plugin.video.coupangm", "쿠팡플레이", "sb_coupang", "FF5AA9FF"),
    ("disney", "plugin.video.disneym", "디즈니+", "sb_disney", "FF2F8CFF"),
    ("spotv", "plugin.video.spotvm", "SPOTV", "sb_spotv", "FFE5B400"),
    ("nsports", "plugin.video.nsportsm", "네이버 스포츠", "sb_nsports", "FF03C75A"),
    ("broadcast", "plugin.video.broadcastm", "지상파 LIVE", "sb_tv", "FFF1F1F1"),
)
BY_ID = {p[0]: {"id": p[0], "addon": p[1], "label": p[2], "icon": p[3], "color": p[4]} for p in PROVIDERS}
MAX_CHIPS = 10

# Root entries that open a keyboard, jump to another add-on or log out: never
# list them (GetDirectory on a search entry would pop the add-on's keyboard).
_SKIP_CHIP_RE = re.compile(r"검색|search|찜|bookmark|로그아웃|logout|설정", re.I)


def get(pid):
    return BY_ID.get(pid) or BY_ID["tving"]


def installed(addon_id):
    if xbmc is None:
        return False
    return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)
                and xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id))


def installed_providers():
    return [BY_ID[p[0]] for p in PROVIDERS if installed(p[1])]


def root_chips_from(items):
    """Root listing -> [(path, label)] chips.  Pure."""
    chips = []
    for it in items:
        if it["kind"] == "folder" and not _SKIP_CHIP_RE.search(it["title"]):
            chips.append((it["file"], it["title"]))
    return chips[:MAX_CHIPS]


def root_key(pid):
    return "%s:root" % pid


def fetch_root_chips(pid):
    items, _ = tv.convert(tv.get_directory("plugin://%s/" % get(pid)["addon"]))
    chips = root_chips_from(items)
    tv.cache_put(root_key(pid), {"chips": chips})
    return chips


def cached_root_chips(pid):
    return [tuple(c) for c in ((tv.cache_get(root_key(pid)) or {}).get("chips") or [])]


def folder_defs(pid, path, title):
    """Row definition for a menu folder: expanded into rows by the screen."""
    return [{"key": "%s:x:%s" % (pid, path), "expand": path, "title": title, "prefix": pid}]


# ------------------------------------------------------------ R112 login state

def login_ready(pid):
    """False when listing this add-on would make it pop its own login UI.

    TVING MINI asks for id/pw; Disney+ MINI browses for a browser cookie file
    (Kodi file dialog) whenever its session file is empty.  Other add-ons list
    without an account (only playback needs one)."""
    p = get(pid)
    if p["id"] == "tving":
        return tv.account_set()
    if p["id"] == "disney":
        try:
            import json
            import os
            import xbmcvfs
            path = xbmcvfs.translatePath("special://profile/addon_data/%s/dz_cookies.json" % p["addon"])
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return bool(isinstance(data, dict) and data.get("account"))
        except Exception:
            return False
    return True


def login_hint(pid):
    p = get(pid)
    if p["id"] == "disney":
        return "디즈니+ 로그인이 필요합니다.  오른쪽 위 설정에서 '로그인'을 선택하세요."
    return "%s 로그인이 필요합니다.  오른쪽 위 설정에서 계정을 입력하세요." % p["label"]


def settings_extra(pid):
    """Extra rows for the PKM settings card (actions the add-on has no setting for)."""
    p = get(pid)
    if p["id"] == "disney":
        return [{"id": "_pkm_login", "kind": "action", "virtual": True,
                 "label": "로그인 (브라우저 쿠키 파일 불러오기)",
                 "data": "RunPlugin(plugin://%s/)" % p["addon"]}]
    return []

