# -*- coding: utf-8 -*-
"""TV episode intro/next-episode flow for PKM v2223.

Scope is intentionally narrow:
- prepare the selected episode and exact same-season E+1 from local state before PlayMedia;
- reuse one bounded resolver metadata read for Plex intro/credits markers;
- show a small selectable playback overlay without changing the native playback path;
- use Plex credits marker when present; otherwise use a duration fallback;
- never infer an intro: without a Plex marker, only a per-show intro the user
  confirmed on the R165 learn card is used (never applied before confirmation).
"""
from __future__ import absolute_import, unicode_literals

import math
import time
import traceback
import threading
import json
import os
import sqlite3
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ACTION_XML = "plexkm_episode_action_v2222.xml"
LEARN_XML_R165 = "plexkm_intro_learn_r165.xml"

FLOW_PREFIX = "PlexKM.EpisodeFlowV2222."

# v2237 policy: the per-show value is only a fallback when Plex has no current
# credits marker. Plex marker data is authoritative and is read fresh at each
# playback boundary. The stored value is seconds before episode end.
_TIMING_LOCK_V2236 = threading.RLock()
_TIMING_FILENAME_V2236 = "next_episode_timing_v2236.json"


def _timing_path_v2236():
    try:
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile") or "")
        if profile:
            try:
                os.makedirs(profile, exist_ok=True)
            except Exception:
                pass
            return os.path.join(profile, _TIMING_FILENAME_V2236)
    except Exception:
        pass
    return ""


def _load_timing_map_v2236():
    path = _timing_path_v2236()
    if not path or not os.path.exists(path):
        return {}
    try:
        with _TIMING_LOCK_V2236:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        shows = raw.get("shows", {}) if isinstance(raw, dict) else {}
        if not isinstance(shows, dict):
            return {}
        out = {}
        for key, value in shows.items():
            try:
                sec = int(value)
            except Exception:
                continue
            if 5 <= sec <= 600:
                out[str(key)] = sec
        return out
    except Exception:
        return {}


def _save_timing_map_v2236(shows):
    path = _timing_path_v2236()
    if not path:
        return False
    tmp = path + ".tmp"
    try:
        payload = {"version": 1, "shows": dict(shows or {})}
        with _TIMING_LOCK_V2236:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, path)
        return True
    except Exception as exc:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _log("EPISODE_FLOW_NEXT_TIMING_SAVE_FAILED_V2236 err=%s" % exc, xbmc.LOGWARNING)
        return False


def get_show_next_offset_seconds_v2236(show_rating_key):
    key = str(show_rating_key or "").strip()
    if not key:
        return None
    return _load_timing_map_v2236().get(key)


def set_show_next_offset_seconds_v2236(show_rating_key, seconds):
    key = str(show_rating_key or "").strip()
    if not key:
        return False
    shows = _load_timing_map_v2236()
    if seconds is None:
        shows.pop(key, None)
        ok = _save_timing_map_v2236(shows)
        if ok:
            _log("EPISODE_FLOW_NEXT_TIMING_CLEAR_V2236 show=%s mode=auto" % key)
        return ok
    try:
        sec = max(5, min(600, int(seconds)))
    except Exception:
        return False
    shows[key] = sec
    ok = _save_timing_map_v2236(shows)
    if ok:
        _log("EPISODE_FLOW_NEXT_TIMING_SET_V2236 show=%s seconds_before_end=%s" % (key, sec))
    return ok


# R97B: per-show intro skip mode (off / button / auto). "button" is the
# long-standing behaviour (skip prompt while inside the Plex intro marker).
_INTRO_MODE_FILENAME_R97 = "intro_skip_mode_r97.json"
_INTRO_MODES_R97 = ("off", "button", "auto")


def _intro_mode_path_r97():
    try:
        base = _timing_path_v2236()
        if base:
            return os.path.join(os.path.dirname(base), _INTRO_MODE_FILENAME_R97)
    except Exception:
        pass
    return ""


def _load_intro_modes_r97():
    path = _intro_mode_path_r97()
    if not path or not os.path.exists(path):
        return {}
    try:
        with _TIMING_LOCK_V2236:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        shows = raw.get("shows", {}) if isinstance(raw, dict) else {}
        return dict((str(k), str(v)) for k, v in shows.items() if str(v) in _INTRO_MODES_R97) if isinstance(shows, dict) else {}
    except Exception:
        return {}


def get_show_intro_mode_r97(show_rating_key):
    key = str(show_rating_key or "").strip()
    if not key:
        return "button"
    return _load_intro_modes_r97().get(key, "button")


def set_show_intro_mode_r97(show_rating_key, mode):
    key = str(show_rating_key or "").strip()
    mode = str(mode or "button")
    if not key or mode not in _INTRO_MODES_R97:
        return False
    path = _intro_mode_path_r97()
    if not path:
        return False
    shows = _load_intro_modes_r97()
    if mode == "button":
        shows.pop(key, None)
    else:
        shows[key] = mode
    tmp = path + ".tmp"
    try:
        with _TIMING_LOCK_V2236:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "shows": shows}, fh, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, path)
        _log("EPISODE_FLOW_INTRO_MODE_SET_R97 show=%s mode=%s" % (key, mode))
        return True
    except Exception as exc:
        _log("EPISODE_FLOW_INTRO_MODE_SAVE_FAILED_R97 err=%s" % exc, xbmc.LOGWARNING)
        return False


# R165: per-show skip profile = the intro range the user confirmed on the learn
# card, the ending (next-card) mode and next-episode autoplay.  Same folder,
# lock and tmp->replace write as the r97 intro-mode file.  A learned intro is
# never guessed: it is applied only after the user confirmed it, and only when
# the episode has no Plex intro marker.
_SKIP_PROFILE_FILENAME_R165 = "skip_profile_r165.json"
_ENDING_MODES_R165 = ("off", "button", "auto")
_INTRO_LEARN_MIN_MS_R165 = 5000
_INTRO_LEARN_MAX_MS_R165 = 300000
_INTRO_LEARN_MAX_END_MS_R165 = 15 * 60 * 1000
_INTRO_SAMPLES_MAX_R165 = 10


def _skip_profile_path_r165():
    try:
        base = _timing_path_v2236()
        if base:
            return os.path.join(os.path.dirname(base), _SKIP_PROFILE_FILENAME_R165)
    except Exception:
        pass
    return ""


def _load_skip_profiles_r165():
    path = _skip_profile_path_r165()
    if not path or not os.path.exists(path):
        return {}
    try:
        with _TIMING_LOCK_V2236:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        shows = raw.get("shows", {}) if isinstance(raw, dict) else {}
        if not isinstance(shows, dict):
            return {}
        return dict((str(k), v) for k, v in shows.items() if isinstance(v, dict))
    except Exception:
        return {}


def _update_skip_profile_r165(show_rating_key, edit):
    """Read-modify-write one show's entry under the lock.  edit(entry) changes it in place."""
    key = str(show_rating_key or "").strip()
    path = _skip_profile_path_r165()
    if not key or not path:
        return False
    tmp = path + ".tmp"
    try:
        with _TIMING_LOCK_V2236:
            shows = _load_skip_profiles_r165()
            entry = dict(shows.get(key) or {})
            edit(entry)
            if entry:
                shows[key] = entry
            else:
                shows.pop(key, None)
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "shows": shows}, fh, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, path)
        return True
    except Exception as exc:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _log("EPISODE_FLOW_SKIP_PROFILE_SAVE_FAILED_R165 err=%s" % exc, xbmc.LOGWARNING)
        return False


def _valid_intro_range_r165(start_ms, end_ms, duration_ms=0):
    try:
        start = int(start_ms)
        end = int(end_ms)
    except Exception:
        return False
    if start < 0 or end > _INTRO_LEARN_MAX_END_MS_R165:
        return False
    if not (_INTRO_LEARN_MIN_MS_R165 <= end - start <= _INTRO_LEARN_MAX_MS_R165):
        return False
    return not (int(duration_ms or 0) > 0 and end >= int(duration_ms))


def _show_entry_r165(show_rating_key):
    key = str(show_rating_key or "").strip()
    return _load_skip_profiles_r165().get(key) or {} if key else {}


def get_show_intro_profile_r165(show_rating_key):
    """-> {"start_ms", "end_ms", "source"} for a confirmed, sane profile, else None."""
    intro = _show_entry_r165(show_rating_key).get("intro")
    if not isinstance(intro, dict) or not intro.get("confirmed") or intro.get("declined"):
        return None
    start = _to_int(intro.get("start_ms"), -1)
    end = _to_int(intro.get("end_ms"), -1)
    if not _valid_intro_range_r165(start, end):
        return None
    return {"start_ms": start, "end_ms": end, "source": str(intro.get("source") or "")}


def set_show_intro_profile_r165(show_rating_key, start_ms, end_ms, source, sample=None):
    if not _valid_intro_range_r165(start_ms, end_ms):
        return False

    def edit(entry):
        old = entry.get("intro") if isinstance(entry.get("intro"), dict) else {}
        samples = [s for s in (old.get("samples") or []) if isinstance(s, dict)]
        if isinstance(sample, dict):
            samples.append(sample)
        entry["intro"] = {
            "start_ms": int(start_ms), "end_ms": int(end_ms), "confirmed": True, "declined": False,
            "source": str(source or "seek"), "samples": samples[-_INTRO_SAMPLES_MAX_R165:],
            "updated": int(time.time()),
        }
    ok = _update_skip_profile_r165(show_rating_key, edit)
    if ok:
        _log("EPISODE_FLOW_INTRO_PROFILE_SAVE_R165 show=%s start=%s end=%s source=%s" % (
            show_rating_key, start_ms, end_ms, source))
    return ok


def clear_show_intro_profile_r165(show_rating_key, declined=False):
    """Forget the learned intro.  declined=True also stops asking for this drama."""
    def edit(entry):
        entry.pop("intro", None)
        if declined:
            entry["intro"] = {"declined": True, "confirmed": False, "updated": int(time.time())}
    ok = _update_skip_profile_r165(show_rating_key, edit)
    if ok:
        _log("EPISODE_FLOW_INTRO_PROFILE_CLEAR_R165 show=%s declined=%d" % (show_rating_key, 1 if declined else 0))
    return ok


def mark_show_intro_declined_r165(show_rating_key):
    return clear_show_intro_profile_r165(show_rating_key, declined=True)


def is_show_intro_declined_r165(show_rating_key):
    intro = _show_entry_r165(show_rating_key).get("intro")
    return isinstance(intro, dict) and bool(intro.get("declined"))


def get_show_ending_mode_r165(show_rating_key):
    mode = str(_show_entry_r165(show_rating_key).get("ending_mode") or "button")
    return mode if mode in _ENDING_MODES_R165 else "button"


def set_show_ending_mode_r165(show_rating_key, mode):
    mode = str(mode or "button")
    if mode not in _ENDING_MODES_R165:
        return False

    def edit(entry):
        if mode == "button":
            entry.pop("ending_mode", None)
        else:
            entry["ending_mode"] = mode
    return _update_skip_profile_r165(show_rating_key, edit)


def get_show_autoplay_r165(show_rating_key):
    return _show_entry_r165(show_rating_key).get("autoplay", True) is not False


def set_show_autoplay_r165(show_rating_key, enabled):
    def edit(entry):
        if enabled:
            entry.pop("autoplay", None)
        else:
            entry["autoplay"] = False
    return _update_skip_profile_r165(show_rating_key, edit)


def intro_profile_text_r165(show_rating_key):
    """One line for the episode-settings sheet."""
    prof = get_show_intro_profile_r165(show_rating_key)
    if prof:
        def clock(ms):
            sec = max(0, int(ms) // 1000)
            return "%d:%02d" % (sec // 60, sec % 60)
        return "이 드라마 인트로: %s → %s (학습됨)" % (clock(prof["start_ms"]), clock(prof["end_ms"]))
    if is_show_intro_declined_r165(show_rating_key):
        return "이 드라마 인트로: 학습 안 함 (다시 묻지 않음)"
    return "이 드라마 인트로: 학습 안 됨"


def _apply_intro_profile_r165(show_key, duration_ms, rating_key=""):
    """No Plex intro marker: publish the user-confirmed per-show intro instead."""
    prof = get_show_intro_profile_r165(show_key)
    if not prof or not _valid_intro_range_r165(prof["start_ms"], prof["end_ms"], duration_ms):
        return False
    _set("HasIntro", "1")
    _set("IntroStartMs", prof["start_ms"])
    _set("IntroEndMs", prof["end_ms"])
    _set("IntroSource", "learned")
    _log("EPISODE_FLOW_INTRO_PROFILE_APPLY_R165 show=%s rk=%s start=%s end=%s" % (
        show_key, rating_key, prof["start_ms"], prof["end_ms"]))
    return True


def _resolve_next_trigger_v2236(show_key, duration_ms, has_credits, credits_start):
    # v2237 authoritative priority:
    #   1) a current Plex credits marker always wins;
    #   2) only when Plex has no credits marker, use the saved per-show value;
    #   3) otherwise use PKM's duration fallback.
    # A user setting is therefore a fallback for marker-less episodes, never an
    # override of data that Plex later learned/updated.
    if has_credits:
        return max(0, int(credits_start)), "plex_credits_v2237", None
    custom_sec = get_show_next_offset_seconds_v2236(show_key)
    if custom_sec is not None and int(duration_ms or 0) > 0:
        return max(0, int(duration_ms) - (int(custom_sec) * 1000)), "show_fallback_v2237", custom_sec
    if int(duration_ms or 0) > 0:
        fallback_before = 30000 if int(duration_ms) < (30 * 60 * 1000) else 45000
        return max(0, int(duration_ms) - fallback_before), "pkm_default_v2237", None
    return -1, "", None


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _to_int(value, default=0):
    try:
        if value is None or str(value).strip() == "":
            return int(default)
        return int(float(value))
    except Exception:
        return int(default)


def _win():
    return xbmcgui.Window(10000)


def _set(name, value):
    try:
        _win().setProperty(FLOW_PREFIX + name, str(value if value is not None else ""))
    except Exception:
        pass


def _get(name):
    try:
        return _win().getProperty(FLOW_PREFIX + name) or ""
    except Exception:
        return ""


def _clear(name):
    try:
        _win().clearProperty(FLOW_PREFIX + name)
    except Exception:
        pass


def _arm_next_opening_v2227(next_rating_key=""):
    """Arm the established native opening cover for episode-to-episode handoff.

    Keep the playback contract unchanged: the actual next title is still opened by
    Kodi PlayMedia(plugin://...) and resolved by setResolvedUrl.  This helper only
    publishes the same Window(10000) lifecycle properties used by Info playback,
    with the spinner visible immediately because the user explicitly requested
    the next episode transition and the old video surface is about to disappear.
    """
    try:
        win = _win()
        rk = str(next_rating_key or "").strip()
        token = "%s-%d" % (rk, int(time.time() * 1000))
        # Match service.py::_resolver_pre_avstarted_v1547 ownership exactly so
        # Kodi's resolver placeholder Start/Stop cannot be mistaken for a real
        # playback stop during the replacement.
        win.setProperty("PlexKM.Playback.OpeningActive", "1")
        win.setProperty("PlexKM.Playback.OpeningRatingKey", rk)
        win.setProperty("PlexKM.Playback.NativeOpening.Pending", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.RatingKey", rk)
        win.setProperty("PlexKM.Playback.NativeOpening.Token", token)
        win.setProperty("PlexKM.Playback.NativeOpening.Source", "info_playmedia_native_v1454_locked")
        win.setProperty("PlexKM.Playback.NativeOpening.ArmedAtMs", str(int(time.time() * 1000)))
        win.setProperty("PlexKM.Playback.ResolverTokenV1547", token)
        win.setProperty("PlexKM.Playback.ResolverPhaseV1547", "armed")
        for name in (
            "PlexKM.Playback.ResolverHandoffStopAtMsV1547",
            "PlexKM.Playback.ResolverAVStartedAtMsV1547",
            "PlexKM.Playback.ResolverTickHoldLoggedV1547",
            "PlexKM.Playback.OpenFailureCandidateV2224",
            "PlexKM.Playback.OpenFailureCandidateAtMsV2224",
            "PlexKM.Playback.FailureHomeRequestV2224",
            "PlexKM.Playback.FailureHomeRequestSourceV2224",
            "PlexKM.Playback.NativeOpening.HoldClear",
            "PlexKM.Playback.NativeOpening.WaitResumeV1551",
            "PlexKM.Playback.NativeOpening.ResumeVerifiedHoldV1551",
        ):
            win.clearProperty(name)
        # FullscreenVideo already renders the native-opening spinner from the
        # opening flag.  Home's overlay gates its ring separately, so publish
        # SpinnerVisible immediately to guarantee there is never a visible Home
        # frame during a slow next-episode replacement.
        win.setProperty("PlexKM.Playback.NativeOpening", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.SpinnerVisible", "1")
        win.setProperty("PlexKM.Playback.NativeOpening.ShownAtMs", str(int(time.time() * 1000)))
        win.setProperty("PlexKM.Playback.NextHandoffV2227", "1")
        win.setProperty("PlexKM.Playback.NextHandoffRatingKeyV2227", rk)
        _log("EPISODE_FLOW_NEXT_OPENING_ARM_V2227 next_rk=%s token=%s cover=1 spinner=1 native_playback_unchanged=1" % (rk, token))

        def _failure_watch(_token):
            try:
                monitor = xbmc.Monitor()
                if monitor.waitForAbort(15.0):
                    return
                w = _win()
                if w.getProperty("PlexKM.Playback.NativeOpening.Token") != _token:
                    return
                phase = w.getProperty("PlexKM.Playback.ResolverPhaseV1547") or ""
                candidate = w.getProperty("PlexKM.Playback.OpenFailureCandidateV2224") == "1"
                try:
                    video = bool(xbmc.Player().isPlayingVideo()) or bool(xbmc.getCondVisibility("Player.HasVideo"))
                except Exception:
                    video = False
                if candidate and phase == "handoff_stop_blocked" and not video:
                    w.setProperty("PlexKM.Playback.FailureHomeRequestV2224", "1")
                    w.setProperty("PlexKM.Playback.FailureHomeRequestSourceV2224", "next_timeout_15s_v2227")
                    _log("EPISODE_FLOW_NEXT_OPENING_FAILURE_TIMEOUT_V2227 token=%s action=home" % _token)
                    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.km/?action=playback_failure_home_v2224&source=next_timeout_15s_v2227)")
            except Exception:
                pass
        threading.Thread(target=_failure_watch, args=(token,), name="PKMNextOpeningV2227", daemon=True).start()
        return token
    except Exception:
        _log("EPISODE_FLOW_NEXT_OPENING_ARM_FAILED_V2227 next_rk=%s err=%s" % (
            next_rating_key or "", traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return ""


def clear_prepared(reason=""):
    for name in (
        "Prepared", "RatingKey", "DurationMs", "IntroStartMs", "IntroEndMs",
        "HasIntro", "CreditsStartMs", "HasCredits", "NextTriggerMs", "NextSource",
        "NextRatingKey", "NextPartKey", "NextSeason", "NextEpisode", "NextTitle",
        "NextPlayUrl", "CurrentPartKey", "PreparedAtMs", "ShowRatingKey", "SectionId",
        "IntroSource", "NextThumbPath",
    ):
        _clear(name)
    _log("EPISODE_FLOW_CLEAR_V2223 reason=%s" % (reason or ""))


def _first_video(root):
    try:
        if root is None:
            return None
        if getattr(root, "tag", "") == "Video":
            return root
        for node in list(root):
            if getattr(node, "tag", "") == "Video":
                return node
        for node in root.iter("Video"):
            return node
    except Exception:
        pass
    return None


def _marker_ranges(video):
    intros = []
    credits = []
    if video is None:
        return intros, credits
    try:
        for marker in video.iter("Marker"):
            mtype = str(marker.get("type") or "").strip().lower()
            start = _to_int(marker.get("startTimeOffset"), -1)
            end = _to_int(marker.get("endTimeOffset"), -1)
            if start < 0:
                continue
            entry = (start, end)
            if mtype == "intro":
                intros.append(entry)
            elif mtype == "credits":
                credits.append(entry)
    except Exception:
        pass
    intros.sort(key=lambda x: (x[0], x[1]))
    credits.sort(key=lambda x: (x[0], x[1]))
    return intros, credits



def _part_id_from_key_v2223(part_key):
    try:
        bits = [x for x in str(part_key or "").strip().split("/") if x]
        if len(bits) >= 3 and bits[0] == "library" and bits[1] == "parts":
            return str(bits[2] or "").strip()
    except Exception:
        pass
    return ""


def _part_key_from_video_v2223(video, preferred_part_key=""):
    if video is None:
        return ""
    preferred = str(preferred_part_key or "").strip()
    preferred_id = _part_id_from_key_v2223(preferred)
    parts = []
    try:
        for part in video.iter("Part"):
            key = str(part.get("key") or "").strip()
            if not key:
                continue
            pid = str(part.get("id") or _part_id_from_key_v2223(key) or "").strip()
            parts.append((pid, key))
    except Exception:
        parts = []
    if preferred:
        for pid, key in parts:
            if key == preferred:
                return key
        if preferred_id:
            for pid, key in parts:
                if pid == preferred_id:
                    return key
    if len(parts) == 1:
        return parts[0][1]
    return ""


def _find_video_by_rating_key_v2223(root, rating_key):
    target = str(rating_key or "").strip()
    if root is None or not target:
        return None
    try:
        for video in root.iter("Video"):
            if str(video.get("ratingKey") or "").strip() == target:
                return video
    except Exception:
        pass
    return None


def _row_field(row, index, default=""):
    try:
        if row is None or len(row) <= index:
            return default
        value = row[index]
        return default if value is None else value
    except Exception:
        return default


def _next_episode_from_rows(rows, current_rating_key, season, episode):
    """Return exact E+1 inside the exact season only (v2237 policy)."""
    current_rating_key = str(current_rating_key or "")
    season_i = _to_int(season, -1)
    episode_i = _to_int(episode, -1)
    if season_i < 0 or episode_i < 0:
        return None
    for row in list(rows or []):
        rk = str(_row_field(row, 0, "") or "")
        if not rk or rk == current_rating_key:
            continue
        s = _to_int(_row_field(row, 19, -1), -1)
        e = _to_int(_row_field(row, 20, -1), -1)
        if s == season_i and e == episode_i + 1:
            return row
    return None


def _build_start_url(core, rating_key, part_key):
    try:
        return core.build_plugin_url({
            "action": "play",
            "rating_key": str(rating_key or ""),
            "part_key": str(part_key or ""),
            "start": "0",
            "noresume": "1",
            "pkm_resume_policy": "start",
        })
    except Exception:
        return ""


def prepare_for_playback(core, item, actual_rating_key=""):
    """Prepare episode playback without network work on the click path (v2380).

    The Info click must reach native PlayMedia immediately.  Current duration,
    ownership and the exact E+1 candidate come from the selected ListItem/local
    DB only.  The resolver performs one bounded metadata read and calls
    refresh_prepared_from_metadata_v2380() before setResolvedUrl so Plex intro /
    credits markers still become authoritative when available.
    """
    clear_prepared(reason="prepare_begin_v2380")
    if core is None or item is None:
        return False

    source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
    rating_key = str(actual_rating_key or source_rk or "").strip()
    if not rating_key:
        return False

    item_type = str(item.getProperty("PlexKM.Type") or "").strip().lower()
    if item_type and item_type != "episode":
        return False

    section_id = str(item.getProperty("PlexKM.SectionId") or "").strip()
    show_key = str(item.getProperty("PlexKM.GrandparentRatingKey") or "").strip()
    season = str(item.getProperty("PlexKM.Season") or "").strip()
    episode = str(item.getProperty("PlexKM.Episode") or "").strip()
    duration_ms = _to_int(item.getProperty("PlexKM.Duration"), 0)
    preferred_part_key = str(
        item.getProperty("PlexKM.VersionSelectedPartKey")
        or item.getProperty("PlexKM.PartKey")
        or ""
    ).strip()

    next_row = None
    rows = []
    if show_key and section_id:
        try:
            rows = list(core.query_episodes_for_show(section_id, show_key) or [])
            next_row = _next_episode_from_rows(rows, rating_key, season, episode)
        except Exception as exc:
            _log("EPISODE_FLOW_NEXT_LOCAL_FAILED_V2380 rk=%s show=%s err=%s" % (
                rating_key, show_key, exc
            ), xbmc.LOGWARNING)

    next_rk = next_part = next_season = next_episode = next_title = next_url = ""
    next_thumb_path = ""
    next_trigger = -1
    next_source = ""
    if next_row is not None:
        next_rk = str(_row_field(next_row, 0, "") or "").strip()
        next_title = str(_row_field(next_row, 4, "") or "").strip()
        next_thumb_path = str(_row_field(next_row, 12, "") or "").strip()
        next_part = str(_row_field(next_row, 15, "") or "").strip()
        next_season = str(_row_field(next_row, 19, "") or "").strip()
        next_episode = str(_row_field(next_row, 20, "") or "").strip()
        if next_rk and next_part:
            next_url = _build_start_url(core, next_rk, next_part)
            next_trigger, next_source, custom_sec_v2236 = _resolve_next_trigger_v2236(
                show_key, duration_ms, False, -1
            )
            if custom_sec_v2236 is not None:
                _log("EPISODE_FLOW_NEXT_TIMING_LOCAL_V2380 show=%s rk=%s seconds_before_end=%s trigger=%s source=%s" % (
                    show_key, rating_key, custom_sec_v2236, next_trigger, next_source
                ))

    _set("RatingKey", rating_key)
    _set("CurrentPartKey", preferred_part_key)
    _set("DurationMs", duration_ms)
    _set("HasIntro", "")
    _set("IntroStartMs", "")
    _set("IntroEndMs", "")
    _set("HasCredits", "")
    _set("CreditsStartMs", "")
    _set("IntroSource", "")
    _set("NextTriggerMs", next_trigger if next_trigger >= 0 and next_url else "")
    _set("NextSource", next_source if next_url else "")
    _set("NextRatingKey", next_rk)
    _set("NextPartKey", next_part)
    _set("NextSeason", next_season)
    _set("NextEpisode", next_episode)
    _set("NextTitle", next_title)
    _set("NextPlayUrl", next_url)
    _set("NextThumbPath", next_thumb_path)
    _set("ShowRatingKey", show_key)
    _set("SectionId", section_id)
    _apply_intro_profile_r165(show_key, duration_ms, rating_key)
    _set("PreparedAtMs", int(time.time() * 1000))
    _set("Prepared", "1")

    _log(
        "EPISODE_FLOW_PREPARED_LOCAL_V2380 rk=%s source_rk=%s s=%s e=%s duration=%s "
        "next_rk=%s next_s=%s next_e=%s next_trigger=%s next_source=%s local_rows=%s network=0" % (
            rating_key, source_rk, season, episode, duration_ms,
            next_rk, next_season, next_episode, next_trigger, next_source or "none", len(rows)
        )
    )
    return True


def refresh_prepared_from_metadata_v2380(root, rating_key, preferred_part_key=""):
    """Refresh prepared marker state from the resolver's single Plex XML read.

    No request is made here.  The resolver owns the bounded metadata request and
    supplies the parsed XML before Kodi receives setResolvedUrl.
    """
    rk = str(rating_key or "").strip()
    if root is None or not rk:
        return False
    if _get("Prepared") != "1" or str(_get("RatingKey") or "").strip() != rk:
        return False
    video = _find_video_by_rating_key_v2223(root, rk)
    if video is None:
        video = _first_video(root)
    if video is None:
        return False

    duration_ms = _to_int(video.get("duration"), _to_int(_get("DurationMs"), 0))
    show_key = str(video.get("grandparentRatingKey") or _get("ShowRatingKey") or "").strip()
    live_part_key = _part_key_from_video_v2223(video, preferred_part_key or _get("CurrentPartKey"))
    intros, credits = _marker_ranges(video)
    has_intro = bool(intros)
    intro_start = intros[0][0] if has_intro else -1
    intro_end = intros[0][1] if has_intro else -1
    has_credits = bool(credits)
    credits_start = credits[0][0] if has_credits else -1

    next_url = str(_get("NextPlayUrl") or "").strip()
    next_trigger = -1
    next_source = ""
    if next_url:
        next_trigger, next_source, custom_sec_v2236 = _resolve_next_trigger_v2236(
            show_key, duration_ms, has_credits, credits_start
        )
        if custom_sec_v2236 is not None:
            _log("EPISODE_FLOW_NEXT_TIMING_RESOLVER_V2380 show=%s rk=%s seconds_before_end=%s trigger=%s source=%s" % (
                show_key, rk, custom_sec_v2236, next_trigger, next_source
            ))

    _set("CurrentPartKey", live_part_key or preferred_part_key or _get("CurrentPartKey"))
    _set("DurationMs", duration_ms)
    plex_intro_r165 = has_intro and intro_end > intro_start >= 0
    _set("HasIntro", "1" if plex_intro_r165 else "")
    _set("IntroStartMs", intro_start if has_intro else "")
    _set("IntroEndMs", intro_end if has_intro else "")
    _set("IntroSource", "plex" if plex_intro_r165 else "")
    if not plex_intro_r165:
        _apply_intro_profile_r165(show_key, duration_ms, rk)
    _set("HasCredits", "1" if has_credits else "")
    _set("CreditsStartMs", credits_start if has_credits else "")
    _set("NextTriggerMs", next_trigger if next_trigger >= 0 and next_url else "")
    _set("NextSource", next_source if next_url else "")
    _set("ShowRatingKey", show_key)
    _set("PreparedAtMs", int(time.time() * 1000))
    _log("EPISODE_FLOW_RESOLVER_METADATA_APPLY_V2380 rk=%s duration=%s intro=%s-%s credits=%s next_trigger=%s next_source=%s network=0_reuse" % (
        rk, duration_ms, intro_start, intro_end, credits_start, next_trigger, next_source or "none"
    ))
    return True


def _build_start_url_runtime_v2227(rating_key, part_key):
    try:
        return "plugin://%s/?%s" % (ADDON_ID, urlencode({
            "action": "play",
            "rating_key": str(rating_key or ""),
            "part_key": str(part_key or ""),
            "start": "0",
            "noresume": "1",
            "pkm_resume_policy": "start",
        }))
    except Exception:
        return ""


def _query_local_episode_rows_v2380(show_key, section_id):
    """Read the cached show episode rows without importing default.py or Plex."""
    show_key = str(show_key or "").strip()
    section_id = str(section_id or "").strip()
    if not show_key or not section_id:
        return []
    db_path = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/plex_km.db" % ADDON_ID
    )
    if not db_path or not os.path.exists(db_path):
        return []
    conn = None
    try:
        conn = sqlite3.connect(db_path, timeout=0.15)
        # v2380R1: chained playback must also work against an older-but-valid
        # local DB.  Read only columns that have existed throughout the episode
        # cache lifetime; do not depend on later resume/view-offset migrations.
        # Empty literals keep the established row indexes used by _row_field().
        return conn.execute("""
            SELECT rating_key, '', '', '', title, '', '', '', '', '', '', '', thumb, '', '', part_key,
                   '', '', '', season, episode
            FROM items
            WHERE section_id=? AND plex_type='episode' AND grandparent_rating_key=?
            ORDER BY season ASC, episode ASC, title COLLATE NOCASE ASC
        """, (section_id, show_key)).fetchall()
    except Exception as exc:
        _log("EPISODE_FLOW_LOCAL_DB_QUERY_FAILED_V2380 show=%s section=%s err=%s" % (
            show_key, section_id, exc
        ), xbmc.LOGWARNING)
        return []
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass


def _prepare_runtime_episode_v2227(rating_key, preferred_part_key=""):
    """Prepare chained next-episode playback without pre-PlayMedia network I/O.

    The previous prepared state already contains the selected next episode's
    show/season/episode identity.  Preserve that identity, find E+1 from the
    local DB, and let the resolver's one bounded metadata read refresh current
    markers/duration before setResolvedUrl.
    """
    rk = str(rating_key or "").strip()
    if not rk:
        return False

    # Capture the selected-next identity before clearing the previous episode.
    show_key = str(_get("ShowRatingKey") or "").strip()
    section_id = str(_get("SectionId") or "").strip()
    season = str(_get("NextSeason") or "").strip()
    episode = str(_get("NextEpisode") or "").strip()
    next_title_current = str(_get("NextTitle") or "").strip()
    part_key = str(preferred_part_key or _get("NextPartKey") or "").strip()

    clear_prepared(reason="next_runtime_prepare_local_v2380")
    try:
        rows = _query_local_episode_rows_v2380(show_key, section_id)
        next_row = _next_episode_from_rows(rows, rk, season, episode)
        next_rk = next_part = next_season = next_episode = next_title = next_url = ""
        next_thumb_path = ""
        if next_row is not None:
            next_rk = str(_row_field(next_row, 0, "") or "").strip()
            next_title = str(_row_field(next_row, 4, "") or "").strip()
            next_thumb_path = str(_row_field(next_row, 12, "") or "").strip()
            next_part = str(_row_field(next_row, 15, "") or "").strip()
            next_season = str(_row_field(next_row, 19, "") or "").strip()
            next_episode = str(_row_field(next_row, 20, "") or "").strip()
            if next_rk and next_part:
                next_url = _build_start_url_runtime_v2227(next_rk, next_part)

        _set("RatingKey", rk)
        _set("CurrentPartKey", part_key)
        _set("DurationMs", "")
        _set("HasIntro", "")
        _set("IntroStartMs", "")
        _set("IntroEndMs", "")
        _set("HasCredits", "")
        _set("CreditsStartMs", "")
        _set("IntroSource", "")
        _set("NextTriggerMs", "")
        _set("NextSource", "")
        _set("NextRatingKey", next_rk)
        _set("NextPartKey", next_part)
        _set("NextSeason", next_season)
        _set("NextEpisode", next_episode)
        _set("NextTitle", next_title)
        _set("NextPlayUrl", next_url)
        _set("NextThumbPath", next_thumb_path)
        _set("ShowRatingKey", show_key)
        _set("SectionId", section_id)
        # Duration is unknown until the resolver; it re-applies with the real one.
        _apply_intro_profile_r165(show_key, 0, rk)
        _set("PreparedAtMs", int(time.time() * 1000))
        _set("Prepared", "1")
        _log("EPISODE_FLOW_NEXT_RUNTIME_PREPARED_LOCAL_V2380 rk=%s title=%s s=%s e=%s next_rk=%s next_s=%s next_e=%s local_rows=%d network=0" % (
            rk, next_title_current, season, episode, next_rk, next_season, next_episode, len(rows)
        ))
        return True
    except Exception:
        _log("EPISODE_FLOW_NEXT_RUNTIME_PREPARE_FAILED_V2380 rk=%s err=%s" % (
            rk, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING)
        return False




class PKMEpisodeActionDialogV2222(xbmcgui.WindowXMLDialog):
    """R165 B-card prompt.

    intro: one full-card button (100).  next: [지금 재생] 102 / [엔딩 보기] 101.
    choice: False (open) | "primary" | "secondary" | "cancel" (BACK).
    """
    BUTTON_ID = 100
    SECONDARY_ID = 101
    NEXT_PRIMARY_ID = 102

    def __init__(self, *args, **kwargs):
        self.choice = False
        self.kind = str(kwargs.pop("kind", "") or "")
        super(PKMEpisodeActionDialogV2222, self).__init__(*args, **kwargs)

    def onInit(self):
        if self.kind == "next":
            try:
                self.setFocusId(self.NEXT_PRIMARY_ID)
            except Exception:
                pass

    def onClick(self, control_id):
        cid = int(control_id or 0)
        if cid in (self.BUTTON_ID, self.NEXT_PRIMARY_ID):
            self.choice = "primary"
            self.close()
        elif cid == self.SECONDARY_ID:
            self.choice = "secondary"
            self.close()

    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = -1
        if aid in (9, 10, 92, 216, 247):
            self.choice = "cancel"
            self.close()


def _fmt_clock_r165(ms):
    sec = max(0, int(ms or 0) // 1000)
    return "%d:%02d" % (sec // 60, sec % 60)


def _fmt_len_r165(ms):
    sec = max(0, int(round(float(ms or 0) / 1000.0)))
    if sec >= 60:
        return "%d분 %d초" % (sec // 60, sec % 60) if sec % 60 else "%d분" % (sec // 60)
    return "%d초" % sec


class PKMIntroLearnDialogR165(xbmcgui.WindowXMLDialog):
    """R165 learn card (Learn_Confirm / Learn_Adjust).  Playback keeps running.

    result: "" (open) | "save" | "once" | "cancel".  The runtime closes it after
    LEARN_IDLE_SEC without input and never saves in that case.
    """
    SAVE_ID = 201
    ADJUST_ID = 202
    ONCE_ID = 203
    FIELD_ID = 210
    BAR_ID = 220
    STEP_SMALL_MS = 1000
    STEP_BIG_MS = 5000

    def __init__(self, *args, **kwargs):
        self.start_ms = int(kwargs.pop("start_ms", 0) or 0)
        self.end_ms = int(kwargs.pop("end_ms", 0) or 0)
        self.duration_ms = int(kwargs.pop("duration_ms", 0) or 0)
        self.source = str(kwargs.pop("source", "seek") or "seek")
        self.kind = str(kwargs.pop("kind", "intro") or "intro")
        super(PKMIntroLearnDialogR165, self).__init__(*args, **kwargs)
        self.result = ""
        self.mode = "confirm"
        self.field = "start"
        self.adjusted = False
        self._undo = (self.start_ms, self.end_ms)
        self.last_input = time.time()

    def onInit(self):
        self._publish()
        try:
            self.setFocusId(self.SAVE_ID)
        except Exception:
            pass

    def _publish(self):
        self.setProperty("PlexKM.IntroLearn.Start", _fmt_clock_r165(self.start_ms))
        self.setProperty("PlexKM.IntroLearn.End", _fmt_clock_r165(self.end_ms))
        self.setProperty("PlexKM.IntroLearn.Mode", self.mode)
        self.setProperty("PlexKM.IntroLearn.Kind", self.kind)
        self.setProperty("PlexKM.IntroLearn.Focus", self.field if self.mode == "adjust" else "")
        if self.kind == "ending":
            off = max(0, int(round((self.end_ms - self.start_ms) / 1000.0)))
            self.setProperty("PlexKM.IntroLearn.Title", "이 드라마의 엔딩을 언제부터로 할까요?")
            self.setProperty("PlexKM.IntroLearn.Len", "끝에서 %d초 전" % off)
            self.setProperty("PlexKM.IntroLearn.Sub", "방금 건너뛴 지점입니다 · 다음 화부터 여기서 다음 화 카드가 나옵니다")
            self.setProperty("PlexKM.IntroLearn.Hint", "◀ ▶ 1초 · ▲ ▼ 5초 · OK 저장")
        else:
            self.setProperty("PlexKM.IntroLearn.Title", "이 드라마의 인트로를 몇 초로 설정할까요?")
            self.setProperty("PlexKM.IntroLearn.Len", "길이 %s" % _fmt_len_r165(self.end_ms - self.start_ms))
            self.setProperty("PlexKM.IntroLearn.Sub", (
                "표시한 구간입니다 · 다음 화부터 건너뛰기 버튼이 나옵니다" if self.source == "osd_mark"
                else "방금 건너뛴 구간입니다 · 다음 화부터 건너뛰기 버튼이 나옵니다"))
            self.setProperty("PlexKM.IntroLearn.Hint", (
                "◀ ▶ 1초 · ▲ ▼ 5초 · OK 끝 시간으로" if self.field == "start"
                else "◀ ▶ 1초 · ▲ ▼ 5초 · OK 저장"))

    def _nudge(self, delta_ms):
        limit = _INTRO_LEARN_MAX_END_MS_R165
        if self.duration_ms > 0:
            limit = min(limit, self.duration_ms - 1000)
        if self.field == "start":
            self.start_ms = max(0, min(self.end_ms - _INTRO_LEARN_MIN_MS_R165, self.start_ms + delta_ms))
        else:
            self.end_ms = max(self.start_ms + _INTRO_LEARN_MIN_MS_R165, min(limit, self.end_ms + delta_ms))
        self.adjusted = True
        self._publish()

    def onClick(self, control_id):
        self.last_input = time.time()
        cid = int(control_id or 0)
        if cid == self.SAVE_ID:
            self.result = "save"
            self.close()
        elif cid == self.ADJUST_ID:
            self._undo = (self.start_ms, self.end_ms)
            self.mode = "adjust"
            self.field = "start"
            self._publish()
            try:
                self.setFocusId(self.FIELD_ID)
            except Exception:
                pass
        elif cid == self.ONCE_ID:
            self.result = "once"
            self.close()
        elif cid == self.FIELD_ID:
            if self.kind != "ending" and self.field == "start":
                self.field = "end"
                self._publish()
            else:
                self.result = "save"
                self.close()

    def onAction(self, action):
        self.last_input = time.time()
        try:
            aid = action.getId()
        except Exception:
            aid = -1
        if aid in (9, 10, 92, 216, 247):
            if self.mode == "adjust":
                # BACK in adjust = 취소: drop the edits, back to the confirm card.
                self.start_ms, self.end_ms = self._undo
                self.mode = "confirm"
                self.field = "start"
                self._publish()
                try:
                    self.setFocusId(self.ADJUST_ID)
                except Exception:
                    pass
                return
            self.result = "cancel"
            self.close()
            return
        if self.mode != "adjust":
            return
        delta = {1: -self.STEP_SMALL_MS, 2: self.STEP_SMALL_MS,
                 3: self.STEP_BIG_MS, 4: -self.STEP_BIG_MS}.get(aid)
        if delta:
            self._nudge(delta)


class EpisodeFlowRuntimeV2222(object):
    """Small service-owned runtime for one currently playing episode."""

    PROMPT_RING_FRAMES_R165 = 20
    INTRO_BAR_W_R165 = 604     # intro card 660 - 2*28
    NEXT_BAR_W_R165 = 724      # next card 780 - 2*28
    LEARN_BAR_W_R165 = 540     # learn card 600 - 2*30
    LEARN_IDLE_SEC_R165 = 10.0
    # R165 burst learn: a skip burst (one or more forward jumps + small back
    # corrections) early in the episode, then SETTLE_SEC of normal playback.
    # The settled position is the intro end; works with R165-0 fixed 30/10 s
    # jumps because it follows the resting point, not one big seek.
    BURST_SETTLE_SEC_R165 = 4.0
    BURST_MIN_FWD_MS_R165 = 20000
    BURST_EARLY_MAX_MS_R165 = 600000
    ENDING_NEAR_END_MS_R165 = 120000   # a late skip landing in the last 2 min = ending
    OSD_WIN_ID_R165 = 12901
    OSD_BAR_W_R165 = 1728      # VideoOSD seek group width (same as R140_BAR_W)

    def __init__(self):
        self.rating_key = ""
        self.intro_shown = False
        self.next_shown = False
        self.prompt = None
        self.prompt_kind = ""
        self.prompt_until = 0.0
        self.prompt_auto_r165 = False
        self.prompt_total_r165 = 0.0
        self.prompt_bar_id_r165 = 0
        self.prompt_bar_w_r165 = 0
        self._bar_px_r165 = -1
        self.learn = None
        self._learn_show_r165 = ""
        self._learn_candidate_r165 = None
        self._learn_asked_r165 = False
        self._learn_asked_ending_r165 = False
        self._burst_active_r165 = False
        self._burst_origin_ms_r165 = 0
        self._burst_land_ms_r165 = 0
        self._burst_last_t_r165 = 0.0
        self._learn_bar_px_r165 = -1
        self._learn_from_r165 = 0
        self._osd_open_r165 = False
        self._osd_token_r165 = ""
        self._session_started = False

    # ------------------------------------------------------------ prompt
    def _close_prompt(self, reason=""):
        try:
            if self.prompt is not None:
                self.prompt.close()
        except Exception:
            pass
        self.prompt = None
        self.prompt_kind = ""
        self.prompt_until = 0.0
        self.prompt_auto_r165 = False
        self._bar_px_r165 = -1
        for key in ("PromptVisible", "PromptKind", "PromptLabel", "PromptDetail", "PromptAuto",
                    "PromptCountdownSec", "PromptRingFrame", "PromptHeadline", "PromptEpisodeLabel",
                    "PromptThumb"):
            _clear(key)
        if reason:
            _log("EPISODE_FLOW_PROMPT_CLOSE_V2222 reason=%s" % reason)

    def _close_learn_r165(self, reason=""):
        try:
            if self.learn is not None:
                self.learn.close()
        except Exception:
            pass
        if self.learn is not None and reason:
            _log("EPISODE_FLOW_INTRO_LEARN_SKIP_R165 reason=%s" % reason)
        self.learn = None
        self._learn_bar_px_r165 = -1

    def _clear_session_props_r165(self):
        for key in ("MarkStartMsR165", "LearnRequestR165", "OsdSkipRequestR165", "OsdInIntroR165",
                    "OsdMarkersR165", "OsdIntroBarR165", "OsdEndBarR165"):
            _clear(key)
        self._osd_open_r165 = False
        self._osd_token_r165 = ""

    def reset(self, reason=""):
        self._close_prompt(reason="reset_%s" % (reason or ""))
        self._close_learn_r165(reason="reset")
        self._learn_candidate_r165 = None
        self._learn_asked_r165 = False
        self._learn_asked_ending_r165 = False
        self._burst_active_r165 = False
        self._clear_session_props_r165()
        self.rating_key = ""
        self.intro_shown = False
        self.next_shown = False
        self._session_started = False

    def on_av_started(self, rating_key):
        self._close_prompt(reason="new_av_started")
        self._close_learn_r165(reason="new_av_started")
        self._learn_candidate_r165 = None
        self._learn_asked_r165 = False
        self._learn_asked_ending_r165 = False
        self._burst_active_r165 = False
        self._clear_session_props_r165()
        self.rating_key = str(rating_key or "").strip()
        self.intro_shown = False
        self.next_shown = False
        self._session_started = True
        prepared_rk = _get("RatingKey")
        _log("EPISODE_FLOW_SESSION_BEGIN_V2223 playing_rk=%s prepared_rk=%s prepared=%s" % (
            self.rating_key, prepared_rk, _get("Prepared") or "0"
        ))

    def _open_prompt(self, kind, label, detail, timeout_sec, auto=False):
        if self.prompt is not None:
            return False
        try:
            timeout = max(0.25, float(timeout_sec or 0.25))
            _set("PromptVisible", "1")
            _set("PromptKind", kind)
            _set("PromptLabel", label)
            _set("PromptDetail", detail)
            _set("PromptAuto", "1" if auto else "")
            _set("PromptCountdownSec", int(math.ceil(timeout)))
            _set("PromptRingFrame", "%02d" % self.PROMPT_RING_FRAMES_R165)
            if kind == "next":
                s = _to_int(_get("NextSeason"), 0)
                e = _to_int(_get("NextEpisode"), 0)
                _set("PromptHeadline", "다음 화 · 시즌 %d" % s if s > 1 else "다음 화")
                _set("PromptEpisodeLabel", "%d화" % e if e > 0 else "다음 화")
                _set("PromptThumb", self._next_thumb_url_r165())
            self.prompt = PKMEpisodeActionDialogV2222(
                ACTION_XML, ADDON.getAddonInfo("path"), "Default", "1080i", kind=kind
            )
            self.prompt_kind = kind
            self.prompt_until = time.time() + timeout
            self.prompt_total_r165 = timeout
            self.prompt_auto_r165 = bool(auto)
            self.prompt_bar_id_r165 = 121 if kind == "next" else 120
            self.prompt_bar_w_r165 = self.NEXT_BAR_W_R165 if kind == "next" else self.INTRO_BAR_W_R165
            self._bar_px_r165 = -1
            self.prompt.show()
            _log("EPISODE_FLOW_PROMPT_OPEN_V2223 kind=%s timeout=%.2f auto=%d detail=%s" % (
                kind, timeout, 1 if auto else 0, detail or ""
            ))
            return True
        except Exception:
            self._close_prompt(reason="open_failed")
            _log("EPISODE_FLOW_PROMPT_OPEN_FAILED_V2222 kind=%s err=%s" % (
                kind, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _next_thumb_url_r165(self):
        # Converted only when the card opens (once per episode), never on the
        # prepare/click path.  pkm_plex_client builds the URL locally.
        path = _get("NextThumbPath")
        if not path:
            return ""
        try:
            from resources.lib import pkm_plex_client
            return pkm_plex_client.art_url(path, width=480, height=270) or ""
        except Exception:
            return ""

    def _update_prompt_progress_r165(self, frac, remaining_sec):
        frac = max(0.0, min(1.0, float(frac)))
        sec = str(int(math.ceil(max(0.0, remaining_sec))))
        if _get("PromptCountdownSec") != sec:
            _set("PromptCountdownSec", sec)
        frame = "%02d" % int(round(frac * self.PROMPT_RING_FRAMES_R165))
        if _get("PromptRingFrame") != frame:
            _set("PromptRingFrame", frame)
        px = int(round(self.prompt_bar_w_r165 * frac))
        if px != self._bar_px_r165 and self.prompt is not None:
            try:
                # getControl per update: control objects are never cached.
                self.prompt.getControl(self.prompt_bar_id_r165).setWidth(px)
                self._bar_px_r165 = px
            except Exception:
                pass

    def _skip_intro_r165(self, source):
        end_ms = _to_int(_get("IntroEndMs"), -1)
        if end_ms < 0:
            return False
        owner = "learned" if _get("IntroSource") == "learned" else "plex"
        seek_source = "%s_intro_%s_r165" % (owner, source)
        try:
            # v2226: exact absolute target, dispatched through the same
            # Kodi-native relative Seek() path as PKM VideoOSD.
            from resources.lib import pkm_seek_quick
            ok = bool(pkm_seek_quick.request_absolute_native_seek_v2226(
                float(end_ms) / 1000.0, source=seek_source
            ))
            _log("EPISODE_FLOW_INTRO_SKIP_R165 rk=%s target_ms=%s owner=%s source=%s ok=%d" % (
                self.rating_key, end_ms, owner, source, 1 if ok else 0))
            return ok
        except Exception as exc:
            _log("EPISODE_FLOW_INTRO_SKIP_FAILED_R165 rk=%s err=%s" % (self.rating_key, exc), xbmc.LOGWARNING)
            return False

    def _play_next_r165(self, source):
        play_url = _get("NextPlayUrl")
        next_rk = _get("NextRatingKey")
        if not play_url:
            return False
        try:
            next_part = _get("NextPartKey")
            _arm_next_opening_v2227(next_rk)
            # Prepare E(n+1)'s own intro/end plan behind the spinner so
            # chained next-episode playback keeps working without an
            # intervening Info page. The already-resolved play_url is
            # retained locally, so preparation failure never blocks play.
            _prepare_runtime_episode_v2227(next_rk, next_part)
            xbmc.executebuiltin("PlayMedia(%s,noresume)" % play_url)
            _log("EPISODE_FLOW_NEXT_PLAY_V2227 from_rk=%s next_rk=%s source=%s native_playmedia=1 opening_cover=1 spinner=1 runtime_prepared=%s" % (
                self.rating_key, next_rk, source, "1" if _get("RatingKey") == str(next_rk or "") else "0"
            ))
            return True
        except Exception as exc:
            _log("EPISODE_FLOW_NEXT_PLAY_FAILED_V2222 from_rk=%s next_rk=%s err=%s" % (
                self.rating_key, next_rk, exc
            ), xbmc.LOGWARNING)
            return False

    def _run_prompt_action_r165(self, kind, source):
        if kind == "intro":
            return self._skip_intro_r165(source)
        if kind == "next":
            return self._play_next_r165(source)
        return False

    def _consume_prompt(self, player):
        if self.prompt is None:
            return False
        choice = getattr(self.prompt, "choice", False)
        kind = self.prompt_kind
        auto = self.prompt_auto_r165
        if choice == "primary":
            self._close_prompt(reason="selected_%s" % kind)
            self._run_prompt_action_r165(kind, "select")
            return True
        if choice in ("secondary", "cancel"):
            self._close_prompt(reason="%s_%s" % (choice, kind))
            return True
        now = time.time()
        if kind == "intro":
            try:
                pos_ms = int(float(player.getTime() or 0) * 1000.0)
            except Exception:
                pos_ms = 0
            intro_start = _to_int(_get("IntroStartMs"), -1)
            intro_end = _to_int(_get("IntroEndMs"), -1)
            if intro_end >= 0 and (pos_ms >= intro_end or (intro_start >= 0 and pos_ms < intro_start)):
                self._close_prompt(reason="marker_exit_intro")
                return True
            if auto:
                if now >= self.prompt_until:
                    self._close_prompt(reason="auto_timeout_intro")
                    self._run_prompt_action_r165("intro", "auto")
                    return True
                remaining = self.prompt_until - now
                self._update_prompt_progress_r165(remaining / max(0.25, self.prompt_total_r165), remaining)
                return False
            # Wall-clock deadline is only a safety net; normal lifetime follows
            # the intro range so pausing the video does not consume skip time.
            if now >= self.prompt_until + 30.0:
                self._close_prompt(reason="safety_timeout_intro")
                return True
            if intro_end > intro_start >= 0:
                left_ms = max(0, intro_end - pos_ms)
                self._update_prompt_progress_r165(float(left_ms) / float(intro_end - intro_start), left_ms / 1000.0)
            return False
        if now >= self.prompt_until:
            self._close_prompt(reason="timeout_%s" % kind)
            if auto:
                self._run_prompt_action_r165(kind, "auto")
            return True
        remaining = self.prompt_until - now
        self._update_prompt_progress_r165(remaining / max(0.25, self.prompt_total_r165), remaining)
        return False

    # ------------------------------------------------------------- learn
    def on_user_seek_r165(self, time_ms, offset_ms):
        """onPlayBackSeek hook: track an intro-skip burst.  Opens nothing here;
        the card is opened from tick() once the burst settles (service thread:
        condition checks only)."""
        try:
            t = int(float(time_ms or 0))
            off = int(float(offset_ms or 0))
            if not self._session_started or self.learn is not None:
                return False
            if self._learn_asked_r165 and self._learn_asked_ending_r165:
                return False
            if self._learn_candidate_r165 is not None:
                return False
            if not self.rating_key or _get("RatingKey") != self.rating_key or _get("Prepared") != "1":
                return False
            if not _get("ShowRatingKey"):
                return False
            source = _win().getProperty("PlexKM.SeekQuick.SeekWaitSource") or ""
            if source.startswith(("plex_intro", "learned_intro")):
                return False
            now = time.time()
            if not self._burst_active_r165:
                # A burst only begins on a forward skip (R165-0 +30 s, a trickplay
                # commit, or a seekbar drag).  Back-only seeks never start one.
                if off <= 0:
                    return False
                self._burst_active_r165 = True
                self._burst_origin_ms_r165 = max(0, t - off)
            # Every later seek (forward or small back correction) moves the
            # resting point; the latest landing is the candidate intro end.
            self._burst_land_ms_r165 = max(0, t)
            self._burst_last_t_r165 = now
            return True
        except Exception:
            return False

    def _burst_tick_r165(self):
        """Close a settled skip burst into a learn candidate (tick/GUI thread)."""
        if not self._burst_active_r165 or self.learn is not None or self._learn_asked_r165:
            return
        if self._learn_candidate_r165 is not None:
            self._burst_active_r165 = False
            return
        if time.time() - self._burst_last_t_r165 < self.BURST_SETTLE_SEC_R165:
            return
        origin = self._burst_origin_ms_r165
        land = self._burst_land_ms_r165
        self._burst_active_r165 = False
        if land - origin < self.BURST_MIN_FWD_MS_R165:
            _log("EPISODE_FLOW_LEARN_BURST_DROP_R165 origin=%s land=%s reason=small_net" % (origin, land))
            return
        dur = _to_int(_get("DurationMs"), 0)
        # Ending: a late skip that lands in the last 2 min -> credits start = origin.
        if dur > 0 and land >= dur - self.ENDING_NEAR_END_MS_R165 and not self._learn_asked_ending_r165:
            off_sec = int(round((dur - origin) / 1000.0))
            if 10 <= off_sec <= 600:
                self._learn_candidate_r165 = (origin, dur, "seek", origin, "ending")
                _log("EPISODE_FLOW_ENDING_LEARN_CANDIDATE_R165 show=%s origin=%s dur=%s offset_sec=%s" % (
                    _get("ShowRatingKey"), origin, dur, off_sec))
                return
        # Intro: an early skip burst -> intro end = the resting point.
        if origin <= self.BURST_EARLY_MAX_MS_R165 and _get("HasIntro") != "1" and not self._learn_asked_r165:
            start = max(0, origin - 5000)
            self._learn_candidate_r165 = (start, land, "seek", origin, "intro")
            _log("EPISODE_FLOW_INTRO_LEARN_CANDIDATE_R165 show=%s origin=%s end=%s start=%s" % (
                _get("ShowRatingKey"), origin, land, start))
            return
        _log("EPISODE_FLOW_LEARN_BURST_DROP_R165 origin=%s land=%s dur=%s reason=no_window" % (origin, land, dur))

    def _duration_ms_r165(self, player):
        dur = _to_int(_get("DurationMs"), 0)
        if dur <= 0:
            try:
                dur = int(float(player.getTotalTime() or 0) * 1000.0)
            except Exception:
                dur = 0
        return dur

    def _learn_open_pending_r165(self, player):
        forced = False
        cand = None
        req = _get("LearnRequestR165")
        if req:
            _clear("LearnRequestR165")
            try:
                a, b = [int(x) for x in req.split(",")[:2]]
                cand = (a, b, "osd_mark", a, "intro")
                forced = True
            except Exception:
                cand = None
        if cand is None:
            cand = self._learn_candidate_r165
            self._learn_candidate_r165 = None
        if cand is None:
            return False
        start, end, source, from_ms, kind = cand
        show = _get("ShowRatingKey")
        if not show:
            return False
        dur = self._duration_ms_r165(player)
        if kind == "ending":
            if get_show_ending_mode_r165(show) == "off":
                _log("EPISODE_FLOW_ENDING_LEARN_SKIP_R165 reason=ending_off show=%s" % show)
                return False
            if _get("HasCredits") == "1":
                _log("EPISODE_FLOW_ENDING_LEARN_SKIP_R165 reason=plex_credits show=%s" % show)
                return False
            if get_show_next_offset_seconds_v2236(show) is not None:
                _log("EPISODE_FLOW_ENDING_LEARN_SKIP_R165 reason=already_learned show=%s" % show)
                return False
            off_sec = int(round((end - start) / 1000.0)) if end > start else 0
            if not (dur > 0 and 0 <= start < end and 10 <= off_sec <= 600):
                _log("EPISODE_FLOW_ENDING_LEARN_SKIP_R165 reason=range start=%s end=%s dur=%s" % (start, end, dur))
                return False
        else:
            if not forced:
                if get_show_intro_mode_r97(show) == "off":
                    _log("EPISODE_FLOW_INTRO_LEARN_SKIP_R165 reason=intro_mode_off show=%s" % show)
                    return False
                if is_show_intro_declined_r165(show):
                    _log("EPISODE_FLOW_INTRO_LEARN_SKIP_R165 reason=declined show=%s" % show)
                    return False
                if get_show_intro_profile_r165(show):
                    _log("EPISODE_FLOW_INTRO_LEARN_SKIP_R165 reason=already_learned show=%s" % show)
                    return False
            if not _valid_intro_range_r165(start, end, dur):
                _log("EPISODE_FLOW_INTRO_LEARN_SKIP_R165 reason=range start=%s end=%s duration=%s" % (start, end, dur))
                return False
        try:
            self.learn = PKMIntroLearnDialogR165(
                LEARN_XML_R165, ADDON.getAddonInfo("path"), "Default", "1080i",
                start_ms=start, end_ms=end, duration_ms=dur, source=source, kind=kind,
            )
            self._learn_show_r165 = show
            self._learn_from_r165 = from_ms
            self._learn_bar_px_r165 = -1
            if kind == "ending":
                self._learn_asked_ending_r165 = True
            elif not forced:
                self._learn_asked_r165 = True
            self.learn.show()
            _log("EPISODE_FLOW_LEARN_OPEN_R165 kind=%s rk=%s show=%s start=%s end=%s source=%s" % (
                kind, self.rating_key, show, start, end, source))
            return True
        except Exception:
            self.learn = None
            _log("EPISODE_FLOW_INTRO_LEARN_OPEN_FAILED_R165 err=%s" % traceback.format_exc().replace(chr(10), " | "),
                 xbmc.LOGWARNING)
            return False

    def _learn_tick_r165(self):
        dlg = self.learn
        if dlg is None:
            return
        result = getattr(dlg, "result", "")
        idle = time.time() - float(getattr(dlg, "last_input", 0.0) or 0.0)
        if not result and idle >= self.LEARN_IDLE_SEC_R165:
            self._close_learn_r165(reason="idle_timeout")
            return
        if result:
            self.learn = None
            if result == "save" and getattr(dlg, "kind", "intro") == "ending":
                off = max(0, int(round((dlg.end_ms - dlg.start_ms) / 1000.0)))
                ok = set_show_next_offset_seconds_v2236(self._learn_show_r165, off)
                _log("EPISODE_FLOW_ENDING_LEARN_SAVE_R165 show=%s offset_sec=%d ok=%d" % (
                    self._learn_show_r165, off, 1 if ok else 0))
            elif result == "save":
                source = "manual_adjust" if dlg.adjusted else dlg.source
                sample = {"rk": self.rating_key, "from_ms": int(getattr(self, "_learn_from_r165", dlg.start_ms)),
                          "to_ms": dlg.end_ms, "t": int(time.time())}
                ok = set_show_intro_profile_r165(self._learn_show_r165, dlg.start_ms, dlg.end_ms, source, sample)
                _log("EPISODE_FLOW_INTRO_LEARN_SAVE_R165 show=%s start=%s end=%s source=%s ok=%d" % (
                    self._learn_show_r165, dlg.start_ms, dlg.end_ms, source, 1 if ok else 0))
            else:
                _log("EPISODE_FLOW_LEARN_SKIP_R165 reason=%s" % result)
            return
        px = int(round(self.LEARN_BAR_W_R165 * max(0.0, 1.0 - idle / self.LEARN_IDLE_SEC_R165)))
        if px != self._learn_bar_px_r165:
            try:
                dlg.getControl(dlg.BAR_ID).setWidth(px)
                self._learn_bar_px_r165 = px
            except Exception:
                pass

    # --------------------------------------------------------------- OSD
    def _osd_tick_r165(self, player):
        try:
            osd = bool(xbmc.getCondVisibility("Window.IsActive(videoosd)"))
        except Exception:
            osd = False
        prepared = bool(self.rating_key) and _get("RatingKey") == self.rating_key and _get("Prepared") == "1"
        if not osd or not prepared:
            if self._osd_open_r165:
                self._osd_open_r165 = False
                self._osd_token_r165 = ""
                for key in ("OsdMarkersR165", "OsdInIntroR165", "OsdIntroBarR165", "OsdEndBarR165"):
                    _clear(key)
            return
        self._osd_open_r165 = True
        dur = self._duration_ms_r165(player)
        has_intro = _get("HasIntro") == "1"
        istart = _to_int(_get("IntroStartMs"), -1) if has_intro else -1
        iend = _to_int(_get("IntroEndMs"), -1) if has_intro else -1
        estart = _to_int(_get("CreditsStartMs"), -1) if _get("HasCredits") == "1" else -1
        if estart < 0 and _get("NextPlayUrl"):
            estart = _to_int(_get("NextTriggerMs"), -1)
        token = "%s|%s|%s|%s|%s" % (self.rating_key, dur, istart, iend, estart)
        if token != self._osd_token_r165 and dur > 0:
            if self._apply_osd_geom_r165(dur, istart, iend, estart):
                self._osd_token_r165 = token
                _set("OsdMarkersR165", "1")
        try:
            pos_ms = int(float(player.getTime() or 0) * 1000.0)
        except Exception:
            pos_ms = -1
        in_intro = (iend > istart >= 0 and istart <= pos_ms < iend
                    and get_show_intro_mode_r97(_get("ShowRatingKey")) != "off") if has_intro else False
        if in_intro != (_get("OsdInIntroR165") == "1"):
            if in_intro:
                _set("OsdInIntroR165", "1")
            else:
                _clear("OsdInIntroR165")
                # The pill is about to hide: never leave the OSD without a focused control.
                try:
                    if xbmc.getCondVisibility("Control.HasFocus(8795)"):
                        xbmc.executebuiltin("SetFocus(87)")
                except Exception:
                    pass
        if _get("OsdSkipRequestR165") == "1":
            _clear("OsdSkipRequestR165")
            _clear("OsdInIntroR165")
            if self.prompt is not None and self.prompt_kind == "intro":
                self._close_prompt(reason="osd_skip_intro")
            self.intro_shown = True
            self._skip_intro_r165("osd")

    def _apply_osd_geom_r165(self, dur, istart, iend, estart):
        """Place the intro/ending range bars on the VideoOSD seekbar (one image each)."""
        try:
            win = xbmcgui.Window(self.OSD_WIN_ID_R165)
            width = self.OSD_BAR_W_R165

            def px(ms):
                return int(round(max(0, min(dur, ms)) * width / float(dur)))

            if iend > istart >= 0 and istart < dur:
                x = min(px(istart), width - 6)
                win.getControl(8790).setPosition(x, 111)
                win.getControl(8790).setWidth(max(6, px(iend) - x))
                _set("OsdIntroBarR165", "1")
            else:
                _clear("OsdIntroBarR165")
            if 0 <= estart < dur:
                x = min(px(estart), width - 6)
                win.getControl(8792).setPosition(x, 111)
                win.getControl(8792).setWidth(max(6, width - x))
                _set("OsdEndBarR165", "1")
            else:
                _clear("OsdEndBarR165")
            return True
        except Exception:
            return False

    # -------------------------------------------------------------- tick
    def tick(self, player):
        try:
            if player is None or not player.isPlayingVideo():
                if self.prompt is not None:
                    self._close_prompt(reason="not_playing")
                if self.learn is not None:
                    self._close_learn_r165(reason="not_playing")
                return
        except Exception:
            return

        if not self._session_started:
            return

        self._osd_tick_r165(player)

        if self.learn is not None:
            self._learn_tick_r165()
            return

        if self.prompt is not None:
            self._consume_prompt(player)
            if self.prompt is not None:
                return

        prepared_rk = _get("RatingKey")
        if not prepared_rk or prepared_rk != self.rating_key or _get("Prepared") != "1":
            return

        self._burst_tick_r165()
        if self._learn_open_pending_r165(player):
            return

        try:
            pos_ms = int(float(player.getTime() or 0) * 1000.0)
        except Exception:
            pos_ms = 0

        if not self.intro_shown and _get("HasIntro") == "1":
            intro_start = _to_int(_get("IntroStartMs"), -1)
            intro_end = _to_int(_get("IntroEndMs"), -1)
            if intro_start >= 0 and intro_end > intro_start and intro_start <= pos_ms < intro_end:
                # R97B: per-show intro mode from the Info episode-settings sheet.
                intro_mode_r97 = get_show_intro_mode_r97(_get("ShowRatingKey"))
                self.intro_shown = True
                if intro_mode_r97 == "off":
                    _log("EPISODE_FLOW_INTRO_OFF_R97 rk=%s show=%s" % (self.rating_key, _get("ShowRatingKey")))
                    return
                remaining_sec = max(0.5, float(intro_end - pos_ms) / 1000.0)
                if intro_mode_r97 == "auto":
                    # R165: 5 s ring countdown, BACK cancels, OK skips now.
                    self._open_prompt("intro", "인트로 건너뛰기", "", min(5.0, remaining_sec), auto=True)
                    return
                # Button mode: the card stays for the rest of the intro range.
                self._open_prompt("intro", "인트로 건너뛰기", "", remaining_sec)
                return

        if not self.next_shown:
            next_url = _get("NextPlayUrl")
            trigger_ms = _to_int(_get("NextTriggerMs"), -1)
            if next_url and trigger_ms >= 0 and pos_ms >= trigger_ms:
                show = _get("ShowRatingKey")
                self.next_shown = True
                ending_mode = get_show_ending_mode_r165(show)
                if ending_mode == "off":
                    _log("EPISODE_FLOW_NEXT_OFF_R165 rk=%s show=%s" % (self.rating_key, show))
                    return
                s = _to_int(_get("NextSeason"), 0)
                e = _to_int(_get("NextEpisode"), 0)
                title = _get("NextTitle")
                detail_parts = []
                if s > 0 and e > 0:
                    detail_parts.append("S%02d E%02d" % (s, e))
                if title:
                    detail_parts.append(title)
                if ending_mode == "auto":
                    self._open_prompt("next", "다음 화 재생", "  ".join(detail_parts), 5.0, auto=True)
                else:
                    self._open_prompt("next", "다음 화 재생", "  ".join(detail_parts), 10.0,
                                      auto=get_show_autoplay_r165(show))
                _log("EPISODE_FLOW_NEXT_TRIGGER_V2223 rk=%s pos=%s trigger=%s source=%s next_rk=%s ending_mode=%s" % (
                    self.rating_key, pos_ms, trigger_ms, _get("NextSource") or "", _get("NextRatingKey") or "", ending_mode
                ))
                return
