# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Movie media-version chooser used by PKM Info (v2103).

This dialog is intentionally UI-only.  The Home window discovers the concrete
Plex media/part rows and applies the chosen playback target.  The dialog merely
shows those rows in a compact popup positioned directly above the movie action
bar and returns the selected row.
"""

import os
import traceback

import xbmc
import xbmcaddon
import xbmcgui

XML_NAME = "plexkm_media_version_select.xml"
LIST_ID = 7400
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_PARENT_DIR = 9


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] MEDIA_VERSION_DIALOG_V2103 %s" % msg, level)
    except Exception:
        pass


def _addon_path():
    try:
        return xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")
    except Exception:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


class PKMMediaVersionSelectWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.rows = list(kwargs.pop("rows", []) or [])
        self.selected_key = str(kwargs.pop("selected_key", "") or "")
        self.anchor_resume = bool(kwargs.pop("anchor_resume", False))
        self.result = None
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        try:
            self.setProperty("PlexKM.MediaVersion.Count", str(len(self.rows)))
            self.setProperty("PlexKM.MediaVersion.AnchorResume", "1" if self.anchor_resume else "")
            ctrl = self.getControl(LIST_ID)
            ctrl.reset()
            selected_pos = 0
            items = []
            for pos, row in enumerate(self.rows):
                resolution = str(row.get("resolution") or "").strip().upper()
                video_codec = str(row.get("video_codec") or "").strip()
                audio_label = str(row.get("audio_label") or "").strip()
                display_label = " ".join(x for x in (resolution, video_codec, audio_label) if x).strip()
                if not display_label:
                    display_label = str(row.get("main_label") or "미디어 버전")
                li = xbmcgui.ListItem(label=display_label)
                li.setProperty("variant_key", str(row.get("variant_key") or ""))
                member_keys = [str(x or "") for x in (row.get("member_variant_keys") or []) if str(x or "")]
                row_key = str(row.get("variant_key") or "")
                is_selected = bool(self.selected_key and (row_key == self.selected_key or self.selected_key in member_keys))
                li.setProperty("selected", "1" if is_selected else "")
                li.setProperty("badge", str(row.get("badge") or ""))
                if is_selected:
                    selected_pos = pos
                items.append(li)
            if items:
                ctrl.addItems(items)
                self.setFocusId(LIST_ID)
                ctrl.selectItem(max(0, min(len(items) - 1, selected_pos)))
            else:
                self.close()
        except Exception:
            _log("init_failed err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
            self.close()

    def onClick(self, control_id):
        try:
            if int(control_id) != LIST_ID:
                return
            ctrl = self.getControl(LIST_ID)
            pos = int(ctrl.getSelectedPosition())
            if 0 <= pos < len(self.rows):
                self.result = dict(self.rows[pos])
                _log("select pos=%s key=%s rk=%s part=%s" % (
                    pos, self.result.get("variant_key") or "", self.result.get("rating_key") or "",
                    self.result.get("part_key") or ""
                ))
            self.close()
        except Exception:
            _log("click_failed err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            self.close()

    def onAction(self, action):
        try:
            aid = int(action.getId())
        except Exception:
            aid = 0
        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_PARENT_DIR):
            self.result = None
            self.close()


def show(rows, selected_key="", anchor_resume=False):
    """Open the compact movie media-version popup and return the chosen row."""
    window = None
    try:
        window = PKMMediaVersionSelectWindow(
            XML_NAME, _addon_path(), "Default", "1080i",
            rows=list(rows or []), selected_key=str(selected_key or ""),
            anchor_resume=bool(anchor_resume),
        )
        window.doModal()
        return dict(window.result) if isinstance(window.result, dict) else None
    except Exception:
        _log("show_failed err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGERROR)
        return None
    finally:
        try:
            del window
        except Exception:
            pass
