# -*- coding: utf-8 -*-
"""PKM home window part (R73): TV 인포(시즌/에피소드).

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartInfoTvR73
    def _info_tv_episode_summary_display_text_v2327(self, text):
        """v2511: TV episode synopsis uses the same 740px Home three-line surface.

        The XML synopsis card has been Home-parity 740x156 since v2444, while the
        old helper still wrapped for an 860px surface.  Reuse the exact Home
        formatter so entering Info and the initially selected episode remain
        pixel-stationary; later episode changes keep the same geometry.
        """
        try:
            return self._home_summary_display_text_v2179(text)
        except Exception:
            return self._summary_display_text(text, 84)


    def _home_episode_show_summary_value_v2264(self, parent_rating_key="", grandparent_rating_key="", section_id="", show_title=""):
        """Return the parent SHOW synopsis from the local PKM DB only.

        V2264 deliberately avoids Plex/network work here. Home episode cards can
        therefore carry the show synopsis before they become focusable. Exact
        show ratingKey is preferred; section+show-title is the local fallback.
        """
        parent = str(parent_rating_key or "").strip()
        grandparent = str(grandparent_rating_key or "").strip()
        sid = str(section_id or "").strip()
        show_name = str(show_title or "").strip()

        cache = getattr(self, "_home_episode_show_summary_cache_v2264", None)
        if cache is None:
            cache = {}
            self._home_episode_show_summary_cache_v2264 = cache

        cache_key = "%s|%s|%s|%s" % (
            grandparent, parent, sid, self._dedup_text_key(show_name)
        )
        if cache_key in cache:
            return cache.get(cache_key) or ""

        dbp = self._profile_db_path()
        if not dbp or not os.path.exists(dbp):
            cache[cache_key] = ""
            return ""

        conn = None

        def _raw_summary(raw_json):
            if not raw_json:
                return ""
            try:
                raw = json.loads(raw_json) if isinstance(raw_json, str) else raw_json
            except Exception:
                return ""
            if not isinstance(raw, dict):
                return ""
            for key in ("summary", "plot"):
                value = str(raw.get(key) or "").strip()
                if value:
                    return value
            return ""

        def _summary_for_show_key(show_key):
            nonlocal conn
            show_key = str(show_key or "").strip()
            if not show_key:
                return "", ""
            if conn is None:
                conn = _pkm_ro_connect(dbp, timeout=2.0)
            row = conn.execute(
                """SELECT rating_key, title, summary, raw_json
                   FROM items
                   WHERE rating_key=? AND plex_type='show'
                   LIMIT 1""",
                (show_key,),
            ).fetchone()
            if not row:
                return "", ""
            result = str(row[2] or "").strip() or _raw_summary(row[3])
            return result, str(row[0] or "").strip()

        try:
            # Exact parent SHOW identity first. For an episode, grandparent is
            # normally the show while parent is normally the season.
            seen = set()
            for show_key in (grandparent, parent):
                if not show_key or show_key in seen:
                    continue
                seen.add(show_key)
                result, source_key = _summary_for_show_key(show_key)
                if result:
                    cache[cache_key] = result
                    _log("HOME_EPISODE_SUMMARY_LOCAL_INHERIT_V2264 show_key=%s show=%s source=rating_key chars=%d" % (
                        source_key,
                        _short_log_value(show_name, 100),
                        len(result),
                    ))
                    return result

            # Some old/local tuples can miss the grandparent key. Resolve the
            # SHOW by section + title, still entirely inside the local DB.
            if show_name:
                if conn is None:
                    conn = _pkm_ro_connect(dbp, timeout=2.0)
                if sid:
                    rows = conn.execute(
                        """SELECT rating_key, title, summary, raw_json
                           FROM items
                           WHERE section_id=? AND plex_type='show'
                           LIMIT 800""",
                        (sid,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        """SELECT rating_key, title, summary, raw_json
                           FROM items
                           WHERE plex_type='show'
                           LIMIT 1600"""
                    ).fetchall()

                wanted = self._dedup_text_key(show_name)
                for row in rows or []:
                    if self._dedup_text_key(row[1] or "") != wanted:
                        continue
                    result = str(row[2] or "").strip() or _raw_summary(row[3])
                    if result:
                        source_key = str(row[0] or "").strip()
                        cache[cache_key] = result
                        _log("HOME_EPISODE_SUMMARY_LOCAL_INHERIT_V2264 show_key=%s show=%s source=section_title chars=%d" % (
                            source_key,
                            _short_log_value(show_name, 100),
                            len(result),
                        ))
                        return result

            cache[cache_key] = ""
            return ""
        except Exception:
            cache[cache_key] = ""
            _log("HOME_EPISODE_SUMMARY_LOCAL_INHERIT_FAILED_V2264 show=%s err=%s" % (
                _short_log_value(show_name, 100),
                traceback.format_exc().replace(chr(10), " | "),
            ), xbmc.LOGWARNING)
            return ""
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass

    def _episode_fallback_title(self, episode):
        return pkm_info_data.episode_fallback_title(episode)

    def _merge_episode_with_show_metadata_props(self, episode_props, show_props, reason=""):
        """Merge show-level Plex metadata into an episode Info record.

        Plex episode nodes often contain the episode title/summary only, while
        the TV show's genres, rating, and actors live on the grandparent show
        metadata node.  PKM Info should display the episode under its show title
        and use show-level metadata where the episode node is naturally empty.
        """
        try:
            if not isinstance(episode_props, dict):
                return episode_props
            if not isinstance(show_props, dict) or not show_props:
                return episode_props
            merged = dict(episode_props)
            show_title = show_props.get("Title") or episode_props.get("ShowTitle") or episode_props.get("Title") or ""
            episode_title = episode_props.get("EpisodeTitle") or ""
            if show_title:
                merged["Title"] = show_title
                merged["TitleDisplay"] = self._title_display_text(show_title)
                merged["ShowTitle"] = show_title
            if episode_title:
                merged["EpisodeTitle"] = episode_title
            for key in ("Genre", "GenreLine", "Director", "DirectorLine", "DirectorLineUseOpenSans", "ContentRating", "Rating", "Premiered"):
                if not merged.get(key) and show_props.get(key):
                    merged[key] = show_props.get(key)
            if not merged.get("CastSlots") and show_props.get("CastSlots"):
                merged["CastSlots"] = show_props.get("CastSlots")
                merged["Cast"] = show_props.get("Cast") or ""
            if not merged.get("Summary") and show_props.get("Summary"):
                merged["Summary"] = show_props.get("Summary")
                merged["SummaryDisplay"] = self._home_summary_display_text_v2179(show_props.get("Summary") or "")
                merged["SummaryLineCount"] = str(self._home_summary_line_count_v2240(merged.get("SummaryDisplay") or ""))
            # For TV episodes, poster/fanart should stay at show level.
            if show_props.get("Poster"):
                merged["Poster"] = show_props.get("Poster")
            if show_props.get("Fanart"):
                merged["Fanart"] = show_props.get("Fanart")
            merged["TmdbRating"] = self._home_tmdb_rating_value(merged.get("Rating") or "")
            merged["MetaLine"] = self._home_meta_line(
                "episode", merged.get("ShowTitle") or merged.get("Title") or "",
                merged.get("Season") or "", merged.get("Episode") or "",
                merged.get("Year") or "", merged.get("DurationText") or "",
                merged.get("ContentRating") or "", "",
                merged.get("AddedAt") or merged.get("Premiered") or ""
            )
            merged["MetaLineBaseV2291"] = self._home_meta_line_base_v2291(
                "episode", merged.get("Season") or "", merged.get("Episode") or "",
                merged.get("Year") or "", merged.get("DurationText") or ""
            )
            merged["PlexType"] = "episode"
            merged["_Sparse"] = not self._meta_props_useful(merged)
            _log("INFO_EPISODE_SHOW_MERGE source=plex episode_key=%s show_key=%s title=%s genre=%s cast=%d reason=%s" % (
                episode_props.get("_SourceRatingKey") or "",
                show_props.get("_SourceRatingKey") or show_props.get("_CanonicalRatingKey") or "",
                _short_log_value(merged.get("Title") or "", 80),
                "1" if merged.get("Genre") else "0",
                len(merged.get("CastSlots") or []),
                reason or "",
            ))
            return merged
        except Exception:
            _log("INFO_EPISODE_SHOW_MERGE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return episode_props

    def _is_tv_recommend_section(self, section_id, section_type=""):
        """Return True for Plex TV/show sections without title/name hardcoding."""
        try:
            sid = str(section_id or "").strip()
            stype = str(section_type or "").lower().strip() or self._section_type_for_id(sid)
            if stype in ("show", "tv", "episode"):
                _speed_log("section_recommend_tv_detect", section=sid, source="section_type", section_type=stype, result=1)
                return True
            if stype:
                _speed_log("section_recommend_tv_detect", section=sid, source="section_type", section_type=stype, result=0)
                return False
            try:
                conn = core.init_db()
                row = conn.execute(
                    "SELECT SUM(CASE WHEN plex_type IN ('show','episode') THEN 1 ELSE 0 END), COUNT(*) FROM items WHERE section_id=?",
                    (sid,),
                ).fetchone()
                tv_count = int((row[0] if row else 0) or 0)
                total_count = int((row[1] if row else 0) or 0)
                result = bool(total_count > 0 and tv_count >= max(1, int(total_count * 0.8)))
                _speed_log("section_recommend_tv_detect", section=sid, source="db_ratio", tv_count=tv_count, total=total_count, result=1 if result else 0)
                return result
            except Exception:
                return False
        except Exception:
            return False

    def _is_tv_library_section_v1870(self, section_id):
        """Return True when Library wall rows must be grouped into season folders."""
        sid = str(section_id or "").strip()
        if not sid:
            return False
        try:
            stype = str(self._section_type_for_id(sid) or "").lower().strip()
            if stype in ("show", "tv", "tvshow", "series", "episode"):
                return True
            if stype:
                return False
            conn = None
            try:
                conn = core.init_db()
                row = conn.execute(
                    "SELECT SUM(CASE WHEN plex_type IN ('show','episode','season') THEN 1 ELSE 0 END), COUNT(*) FROM items WHERE section_id=?",
                    (sid,),
                ).fetchone()
                tv_count = int((row[0] if row else 0) or 0)
                total_count = int((row[1] if row else 0) or 0)
                return bool(total_count > 0 and tv_count >= max(1, int(total_count * 0.8)))
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
        except Exception:
            return False

    def _tv_visual_dedup_key_from_row(self, row):
        """Return a visual TV de-dup key for poster rows.

        The user-visible rule is one poster per drama in Home/section rows.
        Plex can expose multiple episode rows, and in some libraries even more
        than one show/rating key can share the same visible drama title.  For
        TV rows prefer the normalized show/title first, then fall back to the
        show rating key.  Movies are not affected.
        """
        try:
            t = tuple(row or ())
            plex_type = str(t[2] if len(t) > 2 else "").strip()
            if plex_type not in ("episode", "show"):
                return ""
            sid = str(t[1] if len(t) > 1 else "").strip()
            title = str(t[18] if (plex_type == "episode" and len(t) > 18) else (t[4] if len(t) > 4 else "")).strip()
            norm_title = self._dedup_text_key(title)
            if norm_title:
                return "title:%s:%s" % (sid, norm_title)
            show_key = str((t[22] if len(t) > 22 else "") or (t[0] if len(t) > 0 else "") or "").strip()
            if show_key:
                return "show:%s:%s" % (sid, show_key)
        except Exception:
            pass
        return ""

    def _dedup_tv_visual_rows(self, rows, reason="", limit=None):
        try:
            max_rows = int(limit or HOME_ROW_ITEM_LIMIT)
        except Exception:
            max_rows = HOME_ROW_ITEM_LIMIT
        out = []
        seen = set()
        for row in rows or []:
            key = self._tv_visual_dedup_key_from_row(row)
            if key:
                if key in seen:
                    try:
                        t = tuple(row or ())
                        _log("TV_VISUAL_DEDUP_SKIP reason=%s key=%s rating_key=%s title=%s" % (reason, key, str(t[0] if len(t) > 0 else ""), str(t[4] if len(t) > 4 else "")))
                    except Exception:
                        pass
                    continue
                seen.add(key)
            out.append(row)
            if len(out) >= max_rows:
                break
        return out


    def _tv_episode_row_columns_sql(self, alias="i"):
        return pkm_tv_recommend.tv_episode_row_columns_sql(alias)

    def _tv_first_episode_row_map_from_show_keys(self, conn, section_id, show_keys):
        started_v2631 = _pkm_speed_ms()
        out_v2631 = pkm_tv_recommend.tv_first_episode_row_map_from_show_keys(
            conn,
            section_id,
            show_keys,
            columns_sql=self._tv_episode_row_columns_sql("i"),
        )
        _speed_log("tv_first_episode_index_seek_v2631", section=str(section_id or ""), shows=len(list(show_keys or [])), rows=len(out_v2631 or {}), total_ms=_pkm_speed_ms()-started_v2631, library_specific=0)
        return out_v2631

    def _tv_rows_from_episode_map(self, episode_map, show_keys, exclude_keys=None, limit=None, allow_duplicate_fallback=False):
        rows = pkm_tv_recommend.tv_rows_from_episode_map(
            episode_map,
            show_keys,
            exclude_keys=exclude_keys,
            limit=limit,
            row_item_limit=HOME_ROW_ITEM_LIMIT,
            allow_duplicate_fallback=allow_duplicate_fallback,
            speed_log=_speed_log,
        )
        return self._dedup_tv_visual_rows(rows, reason="tv_episode_map", limit=limit or HOME_ROW_ITEM_LIMIT)

    def _tv_cache_limit(self, limit=None):
        return pkm_tv_recommend.tv_cache_limit(limit, row_item_limit=HOME_ROW_ITEM_LIMIT)

    def _tv_candidate_limit(self, limit=None):
        return pkm_tv_recommend.tv_candidate_limit(limit, row_item_limit=HOME_ROW_ITEM_LIMIT)

    def _tv_cached_show_keys(self, cache_name, section_id, limit, builder):
        sid = str(section_id or "").strip()
        row_limit = self._tv_cache_limit(limit)
        cache_key = "%s:%s" % (sid, cache_name)
        try:
            cached = list(self._tv_show_key_cache.get(cache_key) or [])
        except Exception:
            cached = []
        if not cached:
            _t0_r59 = time.perf_counter()
            try:
                cached = [str(x or "").strip() for x in (builder() or []) if str(x or "").strip()]
                self._tv_show_key_cache[cache_key] = cached
            except Exception:
                cached = []
            _ms_r59 = (time.perf_counter() - _t0_r59) * 1000.0
            if _ms_r59 >= 300:
                _log("TV_SHOW_KEYS_BUILD_SLOW_R59 cache=%s section=%s keys=%d ms=%d" % (
                    cache_name, sid, len(cached), int(_ms_r59)))
        if cache_name in ("start_random", "top_rated"):
            try:
                out = list(cached)
                random.SystemRandom().shuffle(out)
                return out[:self._tv_candidate_limit(row_limit)]
            except Exception:
                out = list(cached)
                random.shuffle(out)
                return out[:self._tv_candidate_limit(row_limit)]
        return cached[:self._tv_candidate_limit(row_limit)]

    def _tv_show_keys_by_recent_airing(self, conn, section_id, limit=None):
        sid = str(section_id or "").strip()
        max_keys = self._tv_candidate_limit(limit)
        def _build():
            # v475: use show rows first.  Episode GROUP BY on very large sections
            # can block first paint; show updated/added timestamps are enough for
            # the sidebar recommendation landing page and preserve DB-only flow.
            rows = []
            try:
                rows = conn.execute("""
                    SELECT rating_key
                    FROM items
                    WHERE section_id=? AND plex_type='show'
                    ORDER BY COALESCE(updated_at,0) DESC,
                             COALESCE(added_at,0) DESC,
                             rating_key
                    LIMIT ?
                """, (sid, max_keys)).fetchall()
            except Exception:
                rows = []
            if rows:
                return [str(r[0] or "") for r in rows]
            rows = conn.execute("""
                SELECT COALESCE(NULLIF(grandparent_rating_key,''), rating_key) AS show_key,
                       MAX(COALESCE(updated_at,0)) AS last_updated,
                       MAX(COALESCE(added_at,0)) AS last_added
                FROM items
                WHERE section_id=? AND plex_type='episode'
                GROUP BY show_key
                ORDER BY last_updated DESC, last_added DESC, show_key
                LIMIT ?
            """, (sid, max_keys)).fetchall()
            return [str(r[0] or "") for r in rows]
        return self._tv_cached_show_keys("recent_airing", sid, limit, _build)

    def _tv_show_keys_random(self, conn, section_id, limit=None):
        sid = str(section_id or "").strip()
        max_keys = self._tv_candidate_limit(limit)
        def _build():
            rows = []
            try:
                rows = conn.execute("""
                    SELECT rating_key
                    FROM items
                    WHERE section_id=? AND plex_type='show'
                    ORDER BY COALESCE(updated_at,0) DESC,
                             COALESCE(added_at,0) DESC,
                             rating_key
                    LIMIT ?
                """, (sid, max(max_keys * 4, 128))).fetchall()
            except Exception:
                rows = []
            if rows:
                return [str(r[0] or "") for r in rows]
            rows = conn.execute("""
                SELECT COALESCE(NULLIF(grandparent_rating_key,''), rating_key) AS show_key,
                       MAX(COALESCE(updated_at,0)) AS last_updated,
                       MAX(COALESCE(added_at,0)) AS last_added
                FROM items
                WHERE section_id=? AND plex_type='episode'
                GROUP BY show_key
                ORDER BY last_updated DESC, last_added DESC, show_key
                LIMIT ?
            """, (sid, max(max_keys * 3, 96))).fetchall()
            return [str(r[0] or "") for r in rows]
        return self._tv_cached_show_keys("start_random", sid, limit, _build)

    def _tv_show_keys_rewatch(self, conn, section_id, limit=None):
        """R154: combine actually watched shows AND watched episodes.

        The old code returned immediately after finding any watched show rows,
        hiding episode-only watch histories in Plex databases. Never synthesize
        unwatched recommendations to fill the desired 20 cards.
        """
        sid = str(section_id or "").strip()
        max_keys = self._tv_candidate_limit(limit)

        def _build():
            watched = {}
            try:
                show_rows = conn.execute("""
                    SELECT rating_key, COALESCE(last_viewed_at,0) AS last_seen
                    FROM items
                    WHERE section_id=? AND plex_type='show' AND view_count > 0
                    ORDER BY last_seen DESC, rating_key
                    LIMIT ?
                """, (sid, max_keys * 2)).fetchall()
                for key, when in show_rows:
                    key = str(key or "").strip()
                    if key:
                        watched[key] = max(watched.get(key, 0), int(when or 0))
            except Exception:
                pass
            try:
                episode_rows = conn.execute("""
                    SELECT COALESCE(NULLIF(grandparent_rating_key,''),rating_key) AS show_key,
                           MAX(COALESCE(last_viewed_at,0)) AS last_seen
                    FROM items
                    WHERE section_id=? AND plex_type='episode' AND view_count > 0
                    GROUP BY show_key
                    ORDER BY last_seen DESC, show_key
                    LIMIT ?
                """, (sid, max_keys * 2)).fetchall()
                for key, when in episode_rows:
                    key = str(key or "").strip()
                    if key:
                        watched[key] = max(watched.get(key, 0), int(when or 0))
            except Exception:
                pass
            keys = sorted(watched, key=lambda key: (-watched[key], key))[:max_keys]
            _log("SECTION_REWATCH_MERGED_R154 section=%s watched_shows=%d limit=%d" % (
                sid, len(watched), max_keys
            ))
            return keys
        return self._tv_cached_show_keys("rewatch_r154", sid, limit, _build)

    def _tv_show_keys_top_rated(self, conn, section_id, limit=None):
        sid = str(section_id or "").strip()
        max_keys = self._tv_candidate_limit(limit)
        def _build():
            rows = []
            try:
                rows = conn.execute("""
                    SELECT s.rating_key AS show_key,
                           COALESCE(r.score, r.audience_rating, r.rating, r.user_rating, 0) AS score
                    FROM items s
                    LEFT JOIN item_ratings r ON r.rating_key=s.rating_key
                    WHERE s.section_id=? AND s.plex_type='show' AND score > 0
                    ORDER BY score DESC, s.rating_key
                    LIMIT ?
                """, (sid, max_keys)).fetchall()
            except Exception:
                rows = []
            if not rows:
                try:
                    rows = conn.execute("""
                        SELECT COALESCE(NULLIF(e.grandparent_rating_key,''), e.rating_key) AS show_key,
                               MAX(COALESCE(r.score, r.audience_rating, r.rating, r.user_rating, 0)) AS score
                        FROM items e
                        LEFT JOIN item_ratings r ON r.rating_key=e.rating_key
                        WHERE e.section_id=? AND e.plex_type='episode'
                        GROUP BY show_key
                        HAVING score > 0
                        ORDER BY score DESC, show_key
                        LIMIT ?
                    """, (sid, max_keys)).fetchall()
                except Exception:
                    rows = []
            return [str(r[0] or "") for r in rows]
        return self._tv_cached_show_keys("top_rated", sid, limit, _build)

    def _build_tv_requested_rows_cache(self, sid, title, home_columns, added_start, exclude_keys=None):
        """Build the first-paint TV recommendation rows only.

        v476: actor/studio rows are intentionally not built here. They are the
        remaining first-entry bottleneck on large TV libraries, so the initial
        menu activation paints Continue + four stable TV rows first, then a
        background data worker appends actor/studio rows into the existing
        8460/8470 XML controls. This keeps 24 items per row and does not touch
        XML focus/downscroll/navigation.
        """
        speed_start = _pkm_speed_ms()
        rows_cache = []
        added = int(added_start or 0)
        sid = str(sid or "").strip()
        section_title = str(title or "라이브러리").strip() or "라이브러리"
        exclude = set(str(x) for x in (exclude_keys or []) if str(x or "").strip())
        row_limit = SECTION_RECOMMEND_DEFAULT_LIMIT_R154
        conn = None
        try:
            conn = core.init_db()

            row_defs = []
            row_defs.append(("최근 방영-%s에 추가됨" % section_title, self._tv_show_keys_by_recent_airing(conn, sid, row_limit), "recent_airing"))
            row_defs.append(("보기 시작", self._tv_show_keys_random(conn, sid, row_limit), "start_random"))
            row_defs.append(("다시 보기", self._tv_show_keys_rewatch(conn, sid, SECTION_RECOMMEND_RESUME_REWATCH_LIMIT_R154), "rewatch"))

            top_keys = self._tv_show_keys_top_rated(conn, sid, row_limit)
            if not top_keys:
                top_keys = self._tv_show_keys_random(conn, sid, row_limit)
            row_defs.append(("최고 평점 TV", top_keys, "top_rated"))

            all_show_keys = []
            for _title, _keys, _type in row_defs:
                all_show_keys.extend(list(_keys or []))
            episode_map = self._tv_first_episode_row_map_from_show_keys(conn, sid, all_show_keys)

            def _append_row(row_title, show_keys, rec_type):
                nonlocal added
                cap_r154 = (SECTION_RECOMMEND_RESUME_REWATCH_LIMIT_R154
                            if rec_type == "rewatch" else row_limit)
                rows = self._tv_rows_from_episode_map(episode_map, show_keys, exclude_keys=exclude, limit=cap_r154, allow_duplicate_fallback=True)
                before = added
                added = self._append_recommend_row_items(None, rows_cache, row_title, rows, sid, added)
                for r in rows or []:
                    try:
                        rk = str(tuple(r)[0] or "")
                        if rk:
                            exclude.add(rk)
                    except Exception:
                        pass
                _speed_log("tv_requested_row_append", section=sid, type=rec_type, title=row_title, shows=len(show_keys or []), rows=len(rows or []), added_delta=added-before, source="db_local_batch_base")

            for row_title, show_keys, rec_type in row_defs:
                _append_row(row_title, show_keys, rec_type)
        except Exception:
            _log("TV_REQUESTED_ROWS_BUILD_FAILED section=%s\n%s" % (sid, traceback.format_exc()), xbmc.LOGWARNING)
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
        _speed_log("tv_requested_rows_build_end", section=sid, title=title, rows=len(rows_cache or []), total_ms=_pkm_speed_ms()-speed_start, result="ok" if rows_cache else "empty", dynamic="deferred")
        return rows_cache

    def _tv_season_row_poster_sources_v1871(self, row):
        """Mirror the v1870 season-card poster/fallback order without ListItems."""
        try:
            t = tuple(row or ())
            thumb = str(t[12] if len(t) > 12 else "").strip()
            art = str(t[13] if len(t) > 13 else "").strip()
            season_key = str(t[21] if len(t) > 21 else "").strip()
            primary = thumb
            if season_key and ":season:" not in season_key:
                primary = _plex_art(
                    "/library/metadata/%s/thumb" % season_key,
                    width=720, height=1080,
                ) or thumb
            sources = []
            # v2498: season portrait prewarm never considers landscape art.
            for value in (primary, thumb):
                value = str(value or "").strip()
                if value and value not in sources:
                    sources.append(value)
            return tuple(sources)
        except Exception:
            return tuple()

    def _start_tv_season_first12_texture_prewarm_v1871(self, section_id, reason=""):
        """Warm the current TV Library first viewport while Recommendation is visible.

        This deliberately uses cached source files only. A background warm-up must
        never compete with navigation by downloading from Plex. Any uncached source
        is left for the normal delayed-spinner Library gate.
        """
        sid = str(section_id or "").strip()
        if not sid or not self._is_tv_library_section_v1870(sid):
            return False
        # PKM_PATCH_ACTIVE v2578 tv_season_prewarm_defer_user_input_priority
        # UHD3/PC traces showed this recommendation-side speculative prewarm can
        # stay alive for 2-7 seconds while the user is rapidly moving between TV
        # sections.  It provides no currently visible pixels; the Library wall
        # already has its own foreground first-viewport gate and V2576 append
        # runway.  Do not spend SQLite/filesystem scheduling budget on this work
        # while Recommendation is visible.
        if str(reason or "").startswith("recommend_visible:"):
            _log("TV_SEASON_FIRST12_PREWARM_SUPPRESS_V2578 section=%s reason=%s action=library_foreground_only" % (
                sid, reason or ""
            ))
            return False
        sort_key = self._normalize_section_sort(getattr(self, "sort", "title"))
        sort_dir = str(getattr(self, "sort_dir", "asc") or "asc")
        genre = str(getattr(self, "_active_genre_filter", "") or "")
        genre_owner = str(getattr(self, "_active_genre_section_id", "") or "")
        if genre_owner != sid:
            genre = ""
        cache_key = "%s|sort=%s|dir=%s|genre=%s" % (sid, sort_key, sort_dir, genre)
        try:
            with self._tv_season_first12_prewarm_lock_v1871:
                state = self._tv_season_first12_prewarm_state_v1871.get(cache_key)
                if state in ("running", "done"):
                    _log("TV_SEASON_FIRST12_PREWARM_SKIP_V1871 section=%s key=%s state=%s reason=%s" % (
                        sid, cache_key, state, reason or ""
                    ))
                    return True
                self._tv_season_first12_prewarm_state_v1871[cache_key] = "running"
        except Exception:
            return False

        generation_v1871 = int(getattr(self, "_lifecycle_generation_v1841", 0) or 0)

        def worker_v1871():
            started_v1871 = _pkm_speed_ms()
            rows_v1871 = []
            requested_v1871 = 0
            source_hits_v1871 = 0
            exact_ready_v1871 = 0
            prewarm_limit_v1934 = self._library_wall_viewport_count_v1865()
            try:
                if not self._worker_alive_v1841(generation_v1871):
                    return
                rows_v1871 = list(self._query_library_wall_rows_v1870(
                    sid, sort=sort_key, sort_dir=sort_dir, limit=prewarm_limit_v1934, offset=0,
                    random_seed=self._wall_random_seed_v1644, genre=(genre or None)
                ) or [])
                payloads_v1871 = []
                for row_v1871 in rows_v1871[:prewarm_limit_v1934]:
                    sources_v1871 = self._tv_season_row_poster_sources_v1871(row_v1871)
                    cached_source_v1871 = ""
                    for source_v1871 in sources_v1871:
                        cached_source_v1871 = self._cached_poster_source_path_v1871(source_v1871)
                        if cached_source_v1871:
                            break
                    if cached_source_v1871:
                        source_hits_v1871 += 1
                        payloads_v1871.append(cached_source_v1871)
                requested_v1871 = min(prewarm_limit_v1934, len(rows_v1871))
                if payloads_v1871 and self._worker_alive_v1841(generation_v1871):
                    # v2147: cached files are already complete images. No background
                    # decode/resize worker is needed; Kodi owns the 240x360 geometry.
                    exact_ready_v1871 = sum(
                        1 for path_v1871 in payloads_v1871
                        if self._local_poster_file_ready_v1865(path_v1871)
                    )
                with self._tv_season_first12_prewarm_lock_v1871:
                    self._tv_season_first12_prewarm_state_v1871[cache_key] = (
                        "done" if requested_v1871 > 0 and exact_ready_v1871 >= requested_v1871 else "partial"
                    )
                _log("TV_SEASON_FIRST12_PREWARM_DONE_V1871 section=%s key=%s requested=%d source_cache_hit=%d exact_ready=%d wait_ms=%d network=0 workers=0 pil=0 reason=%s" % (
                    sid, cache_key, requested_v1871, source_hits_v1871, exact_ready_v1871,
                    _pkm_speed_ms() - started_v1871, reason or ""
                ))
                _log("TV_LIBRARY_WALL_PREWARM_V1937 section=%s prepared_target=%d visible=12 ahead=%d network=0 platform_shared=1 device_branch=0" % (
                    sid, prewarm_limit_v1934, max(0, prewarm_limit_v1934 - 12)
                ))
            except Exception:
                try:
                    with self._tv_season_first12_prewarm_lock_v1871:
                        self._tv_season_first12_prewarm_state_v1871.pop(cache_key, None)
                except Exception:
                    pass
                _log("TV_SEASON_FIRST12_PREWARM_FAILED_V1871 section=%s key=%s err=%s" % (
                    sid, cache_key, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        try:
            thread_v1871 = _PKMHomeThreadV2151(
                target=worker_v1871, name="pkm-tv-season-first12-v1871", daemon=True
            )
            thread_v1871.start()
            _log("TV_SEASON_FIRST12_PREWARM_START_V1871 section=%s key=%s network=0 reason=%s" % (
                sid, cache_key, reason or ""
            ))
            return True
        except Exception:
            try:
                with self._tv_season_first12_prewarm_lock_v1871:
                    self._tv_season_first12_prewarm_state_v1871.pop(cache_key, None)
            except Exception:
                pass
            return False

    # PKM_PATCH_ACTIVE v2706 tv_show_thumb_revision_authority
    def _prime_episode_show_poster_authority_v2706(self, rows_cache):
        """Bulk-prime revision-bearing show poster URLs for TV episode cards.

        Older code synthesized /library/metadata/<show>/thumb, which is stable even
        when Plex changes the poster and therefore can collide with Kodi/PKM image
        caches.  The synchronized show row already owns Plex's real thumb path
        (normally including its revision).  Read those paths once and cache them in
        memory; no network request is made here.
        """
        cache = getattr(self, "_episode_show_poster_authority_v2706", None)
        if not isinstance(cache, dict):
            cache = {}
            self._episode_show_poster_authority_v2706 = cache
        keys = []
        seen = set()
        for entry in list(rows_cache or []):
            try:
                row = entry.get("row") if isinstance(entry, dict) else entry
                t = tuple(row or ())
                if len(t) <= 22 or str(t[2] or "").strip().lower() != "episode":
                    continue
                key = str(t[22] or "").strip()
                if key and key not in seen and key not in cache:
                    seen.add(key)
                    keys.append(key)
            except Exception:
                continue
        if not keys:
            return 0

        conn = None
        found = 0
        try:
            conn = core.init_db()
            step = 200
            for start in range(0, len(keys), step):
                chunk = keys[start:start + step]
                marks = ",".join("?" for _ in chunk)
                sql = "SELECT rating_key, thumb, updated_at FROM items WHERE plex_type='show' AND rating_key IN (%s)" % marks
                rows = conn.execute(sql, tuple(chunk)).fetchall()
                returned = set()
                for row in rows or []:
                    try:
                        key = str(row[0] or "").strip()
                        thumb = str(row[1] or "").strip()
                    except Exception:
                        continue
                    if not key:
                        continue
                    returned.add(key)
                    if thumb:
                        cache[key] = _plex_art(thumb, width=720, height=1080) or thumb
                        found += 1
                    else:
                        cache[key] = _plex_art("/library/metadata/%s/thumb" % key, width=720, height=1080)
                for key in chunk:
                    if key not in returned:
                        cache[key] = _plex_art("/library/metadata/%s/thumb" % key, width=720, height=1080)
            _log("TV_SHOW_POSTER_AUTHORITY_PRIME_V2706 requested=%d revision_thumb=%d canonical_fallback=%d network=0" % (
                len(keys), found, max(0, len(keys) - found)
            ))
            return found
        except Exception:
            _log("TV_SHOW_POSTER_AUTHORITY_PRIME_FAIL_V2706 requested=%d err=%s" % (
                len(keys), traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass

    def _episode_show_poster_from_key(self, grandparent_rating_key):
        try:
            key = str(grandparent_rating_key or "").strip()
            if not key:
                return ""
            authority_v2706 = getattr(self, "_episode_show_poster_authority_v2706", {}) or {}
            if key in authority_v2706 and str(authority_v2706.get(key) or "").strip():
                return str(authority_v2706.get(key) or "").strip()
            cached = getattr(self, "_episode_show_poster_cache", {}).get(key)
            if cached:
                return cached
            poster = _plex_art("/library/metadata/%s/thumb" % key, width=720, height=1080)
            if not hasattr(self, "_episode_show_poster_cache"):
                self._episode_show_poster_cache = {}
            self._episode_show_poster_cache[key] = poster
            return poster
        except Exception:
            return ""

    def _episode_show_art_from_key(self, grandparent_rating_key, section_id="", show_title="", fallback_title=""):
        try:
            key = str(grandparent_rating_key or "").strip()
            sid = str(section_id or "").strip()
            title_key = self._dedup_text_key(show_title or fallback_title or "")
            cache_key = "%s|%s|%s" % (key, sid, title_key)
            cache = getattr(self, "_episode_show_art_cache", {})
            if cache_key in cache:
                return cache.get(cache_key) or ""
            art_path = ""
            conn = None
            try:
                conn = core.init_db()
                if key:
                    row = conn.execute("""
                        SELECT art
                        FROM items
                        WHERE rating_key=? AND plex_type='show' AND COALESCE(art,'') <> ''
                        LIMIT 1
                    """, (key,)).fetchone()
                    if row and row[0]:
                        art_path = str(row[0] or "").strip()
                if not art_path and sid and title_key:
                    rows = conn.execute("""
                        SELECT art, title
                        FROM items
                        WHERE section_id=? AND plex_type='show' AND COALESCE(art,'') <> ''
                        LIMIT 300
                    """, (sid,)).fetchall()
                    for r in rows or []:
                        if self._dedup_text_key(r[1] if len(r) > 1 else "") == title_key:
                            art_path = str(r[0] or "").strip()
                            break
            except Exception:
                art_path = ""
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass
            art = _plex_art(art_path, width=1920, height=1080) if art_path else ""
            if not hasattr(self, "_episode_show_art_cache"):
                self._episode_show_art_cache = {}
            self._episode_show_art_cache[cache_key] = art
            return art
        except Exception:
            return ""

    def _li_from_tv_wall_append_v2622(self, row):
        """Compact live TV-wall card for append/rebind.

        It preserves wall text, poster authority and the identity fields required
        by Info, but batches properties with setProperties() and skips Home-only
        decoration work. Focus/Info can still enrich from the local authority.
        """
        try:
            t = tuple(row or ())
            if len(t) < 21:
                return self._li_from_row(row)
            rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = t[:21]
            parent_rating_key = t[21] if len(t) > 21 else ""
            grandparent_rating_key = t[22] if len(t) > 22 else ""
            view_offset = t[23] if len(t) > 23 else ""
            resume_duration_ms = t[24] if len(t) > 24 else ""
            resume_updated_at = t[25] if len(t) > 25 else ""
            resume_source = t[26] if len(t) > 26 else ""
            tv_meta_json = t[28] if len(t) > 28 else ""
            try:
                tv_meta = pkm_library_sort.parse_tv_sort_meta(tv_meta_json)
            except Exception:
                tv_meta = {}
            plex_type = str(plex_type or "").strip().lower()
            if plex_type == "show":
                url = core.build_plugin_url({"action": "show", "rating_key": rating_key, "section_id": section_id})
            elif part_key and plex_type == "episode":
                url = _pkm_play_url(rating_key, part_key, mode="start")
            else:
                url = core.build_plugin_url({"action": "noop"})
            li = xbmcgui.ListItem(label=str(title or ""), path=url)
            try:
                li.setPath(url)
            except Exception:
                pass
            canonical = self._library_row_poster_canonical_v2580(row) or str(thumb or "")
            li.setArt({"poster": canonical, "thumb": canonical, "icon": canonical, "fanart": ""})
            progress = 0
            watched = "1" if _safe_int(view_count, 0) > 0 else ""
            try:
                if tv_meta:
                    progress = int(max(0, min(100, int(tv_meta.get("progress_percent") or 0))))
                    watched = "1" if bool(tv_meta.get("is_watched")) else ""
            except Exception:
                progress = 0
            comp350 = ""
            comp370 = ""
            try:
                if progress > 0:
                    pprops = getattr(_ensure_core(), "_pkm_resume_progress_props_v2330")(progress) or {}
                    comp350 = str(pprops.get("ResumeProgressComposite350x10") or "")
                    comp370 = str(pprops.get("ResumeProgressComposite370x10") or "")
            except Exception:
                pass
            try:
                wall_title = pkm_library_sort.wall_title_layout(title or "")
            except Exception:
                wall_title = {"line1": str(title or ""), "full": str(title or "")}
            wall_year = pkm_library_sort.wall_year_text(year)
            try:
                wall_sort = pkm_library_sort.wall_sort_meta(
                    getattr(self, "sort", "title"), year=year, added_at=added_at,
                    last_viewed_at=last_viewed_at, progress_percent=progress,
                    is_watched=bool(watched), media_kind="tv", tv_meta=tv_meta
                )
            except Exception:
                wall_sort = ""
            mediatype = kodi_type or ("tvshow" if plex_type in ("show", "season") else plex_type or "video")
            props = {
                "PlexKM.RatingKey": rating_key, "PlexKM.SectionId": section_id,
                "PlexKM.Type": plex_type, "PlexKM.KodiType": mediatype,
                "PlexKM.Title": title, "PlexKM.OriginalTitle": original_title,
                "PlexKM.SortTitle": sort_title, "PlexKM.Year": year,
                "PlexKM.Summary": summary, "PlexKM.Duration": duration,
                "PlexKM.AddedAt": added_at, "PlexKM.UpdatedAt": updated_at,
                "PlexKM.Thumb": thumb, "PlexKM.Art": art, "PlexKM.PartKey": part_key,
                "PlexKM.ViewCount": view_count, "PlexKM.IsWatched": watched,
                "PlexKM.ShowTitle": show_title, "PlexKM.Season": season, "PlexKM.Episode": episode,
                "PlexKM.ParentRatingKey": parent_rating_key, "PlexKM.GrandparentRatingKey": grandparent_rating_key,
                "PlexKM.ViewOffset": view_offset, "PlexKM.ResumeDurationMs": resume_duration_ms,
                "PlexKM.ResumeUpdatedAt": resume_updated_at, "PlexKM.ResumeSource": resume_source,
                "PlexKM.ResumePercent": progress, "PlexKM.ResumeProgressComposite350x10": comp350,
                "PlexKM.ResumeProgressComposite370x10": comp370,
                "PlexKM.WallTitleLine1": str(wall_title.get("line1") or ""),
                "PlexKM.WallTitleFull": str(wall_title.get("full") or wall_title.get("line1") or ""),
                "PlexKM.WallYearLine": str(wall_year or ""), "PlexKM.WallSortLine": str(wall_sort or ""),
                "PlexKM.WallMetaLine": str(wall_sort or ""), "PlexKM.Is4K": "",
                "PlexKM.WallPosterRemoteV1644": canonical, "PlexKM.WallPosterDisplayV1644": canonical,
                "PlexKM.PosterAuthorityV2498": canonical, "PlexKM.PosterLocalSourceV2498": "",
                "PlexKM.PosterFallbackArt": "", "PlexKM.PosterFallbackRoleV2498": "",
                "PlexKM.PosterMissingV1963": "", "PlexKM.PosterMissingReasonV1963": "",
                "PlexKM.PlayUrl": url if (part_key and plex_type == "episode") else "",
                "PlexKM.ShowUrl": url if plex_type == "show" else "",
                "PlexKM.OpenEpisodeInfo": "1" if plex_type == "season" else "",
            }
            try:
                li.setProperties({k: str(v or "") for k, v in props.items()})
            except Exception:
                for k, v in props.items():
                    li.setProperty(k, str(v or ""))
            if part_key and plex_type == "episode":
                li.setProperty("IsPlayable", "true")
            self._remember_meta_hint(rating_key, title=title, year=year, section_id=section_id, plex_type=plex_type)
            return self._overlay_gate_register_r56(li, art_key="poster")
        except Exception:
            _log("LIBRARY_TV_COMPACT_BUILD_FALLBACK_V2622 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return self._li_from_row(row)

    def _info_tv_set_mode(self, mode, back_mode=""):
        """Set TV Info view mode for XML visible conditions.

        Modes are intentionally simple properties so Kodi XML owns which native
        panel is currently visible.  Python does not intercept arrow keys.
        """
        mode = str(mode or "")
        back_mode = str(back_mode or "")
        try:
            self._info_set_property_all("PlexKM.Info.TVMode", mode)
            self._info_set_property_all("PlexKM.Info.TVBackMode", back_mode)
            self._info_set_property_all("PlexKM.Info.TVModeSeasons", "1" if mode == "seasons" else "")
            self._info_set_property_all("PlexKM.Info.TVModeEpisodes", "1" if mode == "episodes" else "")
        except Exception:
            pass


    # TV_INFO_EPISODE_4CARD_WINDOW_R20A
    def _info_tv_episode_nav_schedule_r20a(self, control_id, action_id):
        """Schedule one GUI-thread reframe after native episode-panel navigation.

        TV Info shows four episode cards. A Continue-Watching target may be
        initially anchored in visual slot 3. On the first LEFT from that special
        anchor, the row is rebased once so the newly focused previous episode is
        the right-most card of the preceding five-card window. After that, the
        normal Kodi panel moves focus inside the five visible cards without
        continuously sliding the row.
        """
        try:
            cid = int(control_id or 0)
            if cid not in (5712, 5713) or action_id not in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
                return False
            state_map = getattr(self, "_info_tv_episode_nav_state_r20a", {}) or {}
            state = dict(state_map.get(cid) or {})
            if not state:
                return False
            ctrl = self.getControl(cid)
            before = int(ctrl.getSelectedPosition())
            real_count = int(state.get("real_count") or 0)
            anchor_index = int(state.get("anchor_index") if state.get("anchor_index") is not None else -1)
            initial_armed = bool(state.get("initial_armed"))
            tail_pad = bool(state.get("tail_pad"))
            needs_post = bool(
                (initial_armed and before == anchor_index)
                or (tail_pad and action_id == ACTION_MOVE_RIGHT and before == real_count - 1)
            )
            if not needs_post:
                return False
            token = int(getattr(self, "_info_tv_episode_nav_token_r20a", 0) or 0) + 1
            self._info_tv_episode_nav_token_r20a = token
            self._info_tv_episode_nav_pending_r20a = (
                token, cid, int(action_id), before, real_count, anchor_index
            )
            _log("INFO_TV_EPISODE_NAV_POST_R20A token=%d control=%d action=%s before=%d real=%d anchor=%d initial=%d tail_pad=%d" % (
                token, cid, "left" if action_id == ACTION_MOVE_LEFT else "right",
                before, real_count, anchor_index, 1 if initial_armed else 0, 1 if tail_pad else 0
            ))

            def _post_r20a():
                try:
                    # Existing PKM GUI-post pattern: wait one frame, then commit
                    # through the existing GUI-thread SendClick lane.
                    if self._closing_event_v1841.wait(0.020):
                        return
                    xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                except Exception:
                    pass

            _PKMHomeThreadV2151(
                target=_post_r20a, name="PKMTVEpisodeNavR20A", daemon=True
            ).start()
            return True
        except Exception:
            _log("INFO_TV_EPISODE_NAV_POST_FAILED_R20A err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_episode_nav_commit_r20a(self):
        """Apply the one-time five-card reframe on Kodi's GUI thread."""
        pending = getattr(self, "_info_tv_episode_nav_pending_r20a", None)
        if not pending:
            return False
        self._info_tv_episode_nav_pending_r20a = None
        try:
            token, cid, action_id, before, real_count, anchor_index = pending
            if int(token) != int(getattr(self, "_info_tv_episode_nav_token_r20a", 0) or 0):
                return False
            if self._safe_focus_id() != int(cid):
                return False
            ctrl = self.getControl(int(cid))
            after = int(ctrl.getSelectedPosition())
            state_map = getattr(self, "_info_tv_episode_nav_state_r20a", {}) or {}
            state = dict(state_map.get(int(cid)) or {})
            if not state:
                return False

            # The tail pad is visual runway only. It must never become a
            # user-selectable pseudo episode.
            if bool(state.get("tail_pad")) and action_id == ACTION_MOVE_RIGHT and after >= int(real_count):
                ctrl.selectItem(max(0, int(real_count) - 1))
                state["initial_armed"] = False
                state_map[int(cid)] = state
                self._info_tv_episode_nav_state_r20a = state_map
                _log("INFO_TV_EPISODE_NAV_TAIL_BLOCK_R20A token=%d control=%d before=%d after=%d restored=%d" % (
                    token, cid, before, after, max(0, int(real_count) - 1)
                ))
                return True

            # TV_INFO_EPISODE_FIVE_CARD_CENTER_R20B navigation:
            # total=5 / target=5
            #   entry      [3] [4] [5*] [ ] [ ]
            #   first LEFT [2] [3] [4*] [5] [ ]   <- one slide
            #   next LEFT  [2] [3*] [4] [5] [ ]   <- focus only
            # RIGHT is symmetric: center the first neighbor once, then native.
            if (
                bool(state.get("initial_armed"))
                and int(before) == int(anchor_index)
                and action_id == ACTION_MOVE_LEFT
                and int(after) == int(anchor_index) - 1
            ):
                desired = int(after)
                window_start = max(0, desired - 2)
                ctrl.selectItem(window_start)
                ctrl.selectItem(desired)
                state["initial_armed"] = False
                state["window_start"] = window_start
                state_map[int(cid)] = state
                self._info_tv_episode_nav_state_r20a = state_map
                _log("INFO_TV_EPISODE_NAV_LEFT_CENTER_R20B token=%d control=%d anchor=%d desired=%d window_start=%d visual_slot=3 policy=first_move_center_then_native" % (
                    token, cid, anchor_index, desired, window_start
                ))
                return True

            if (
                bool(state.get("initial_armed"))
                and int(before) == int(anchor_index)
                and action_id == ACTION_MOVE_RIGHT
                and int(after) == int(anchor_index) + 1
                and int(after) < int(real_count)
            ):
                desired = int(after)
                prime = desired + 2
                if prime < ctrl.size():
                    ctrl.selectItem(prime)
                    ctrl.selectItem(desired)
                state["initial_armed"] = False
                state["window_start"] = max(0, desired - 2)
                state_map[int(cid)] = state
                self._info_tv_episode_nav_state_r20a = state_map
                _log("INFO_TV_EPISODE_NAV_RIGHT_CENTER_R20B token=%d control=%d anchor=%d desired=%d window_start=%d visual_slot=3 policy=first_move_center_then_native" % (
                    token, cid, anchor_index, desired, max(0, desired - 2)
                ))
                return True

            if bool(state.get("initial_armed")) and int(before) == int(anchor_index):
                state["initial_armed"] = False
                state_map[int(cid)] = state
                self._info_tv_episode_nav_state_r20a = state_map
                _log("INFO_TV_EPISODE_NAV_ANCHOR_RELEASE_R20B token=%d control=%d action=%s before=%d after=%d" % (
                    token, cid, "left" if action_id == ACTION_MOVE_LEFT else "right", before, after
                ))
            return False
        except Exception:
            _log("INFO_TV_EPISODE_NAV_COMMIT_FAILED_R20A err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_active_episode_control_id(self):
        """Return the visible TV episode buffer panel id.

        v1883 uses two real Kodi panels: 5712 (buffer A) and 5713 (buffer B).
        Python fills the inactive buffer first, then flips TVActiveBuffer only
        after the target buffer has all ListItems. No skeleton, transition mask,
        delayed focus timer, or blank intermediate panel is exposed.
        """
        try:
            buf = (self.getProperty("PlexKM.Info.TVActiveBuffer") or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVActiveBuffer") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVActiveBuffer") or "A").strip().upper()
            return 5713 if buf == "B" else 5712
        except Exception:
            return 5712

    def _info_tv_inactive_episode_control_id(self):
        try:
            return 5712 if self._info_tv_active_episode_control_id() == 5713 else 5713
        except Exception:
            return 5713

    def _episode_thumb_miss_r63(self, rating_key, raw_thumb=None):
        try:
            rec = self._tmdb_plot_cache_load_r35().get("thumbmiss:%s" % rating_key)
            if not isinstance(rec, dict):
                return False
            if time.time() - float(rec.get("t") or 0) >= float(rec.get("ttl") or self._THUMB_MISS_TTL_R63):
                return False
            # Plex refreshed the episode (new thumb path): try Plex again.
            if raw_thumb is not None and str(rec.get("raw") or "") and str(raw_thumb or "") \
                    and str(rec.get("raw")) != str(raw_thumb):
                return False
            return True
        except Exception:
            return False

    def _episode_thumb_miss_mark_r63(self, rating_key):
        raw = ""
        try:
            dbp = self._profile_db_path()
            if dbp and os.path.exists(dbp):
                conn = _pkm_ro_connect(dbp, timeout=0.5)
                try:
                    row = conn.execute("SELECT raw_json FROM items WHERE rating_key=? LIMIT 1",
                                       (str(rating_key),)).fetchone()
                finally:
                    conn.close()
                if row and row[0]:
                    raw = str((json.loads(row[0]) or {}).get("thumb") or "")
        except Exception:
            raw = ""
        with self._THUMB_LOCK_R63:
            cache = self._tmdb_plot_cache_load_r35()
            cache["thumbmiss:%s" % rating_key] = {"t": time.time(), "ttl": self._THUMB_MISS_TTL_R63, "raw": raw}
        _log("EPISODE_THUMB_MISS_MARK_R63 rating_key=%s plex_thumb=%s ttl_hours=6" % (rating_key, raw or "-"))
        try:
            self._tmdb_plot_cache_save_r35()
        except Exception:
            pass

    def _info_tv_publish_episode_buffer(self, target_control_id, reason=""):
        try:
            target = 5713 if int(target_control_id or 0) == 5713 else 5712
            # v1789: the episode rail is already a true A/B ListItem buffer.  Never
            # draw a fixed-count visual placeholder over it: a title with one or two
            # episodes must expose exactly one or two cards, with no temporary traces
            # for nonexistent slots.  Populate the inactive bank, then flip once.
            self._info_set_property_all("PlexKM.Info.TVActiveBuffer", "B" if target == 5713 else "A")
            self._info_set_property_all("PlexKM.Info.TVRowsReady", "1")
            self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
            try:
                count = int(self.getControl(target).size())
            except Exception:
                count = -1
            try:
                self._info_tv_publish_selected_version_state_v2123(
                    self.getControl(target).getSelectedItem(),
                    reason="buffer_publish_%s" % (reason or "")
                )
            except Exception:
                pass
            _log("INLINE_INFO_TV_BUFFER_PUBLISH_V1789 target=%s active=%s reason=%s rows=%s fixed_placeholder=0 single_flip=1" % (
                target, "B" if target == 5713 else "A", reason or "", count))
            try:
                hits_r39 = int(getattr(self, "_tmdb_plot_row_hits_r39", 0) or 0)
                self._tmdb_plot_row_hits_r39 = 0
                if hits_r39:
                    _log("TMDB_EPISODE_PLOT_ROW_CACHE_R39 target=%s reason=%s filled_at_build=%d" % (target, reason or "", hits_r39))
            except Exception:
                pass
            try:
                self._tmdb_episode_plot_schedule_r35(target, reason="buffer_publish_%s" % (reason or ""))
            except Exception:
                pass
            try:
                self._tmdb_episode_still_schedule_r63(target, reason="buffer_publish_%s" % (reason or ""))
            except Exception:
                pass
            return target
        except Exception:
            _log("INLINE_INFO_TV_BUFFER_PUBLISH_FAILED target=%s reason=%s\n%s" % (target_control_id, reason or "", traceback.format_exc()), xbmc.LOGWARNING)
            try:
                return self._info_tv_active_episode_control_id()
            except Exception:
                return 5712

    def _info_tv_current_mode_or_fallback(self):
        """Return the current TV Info mode, inferring it during transient republish gaps."""
        try:
            win_home = xbmcgui.Window(10000)
            win_xml = xbmcgui.Window(13000)
            mode = (self.getProperty("PlexKM.Info.TVMode") or win_home.getProperty("PlexKM.Info.TVMode") or win_xml.getProperty("PlexKM.Info.TVMode") or "").strip()
            if mode in ("episodes", "seasons"):
                return mode
            is_tv = (self.getProperty("PlexKM.Info.IsTV") == "1" or win_home.getProperty("PlexKM.Info.IsTV") == "1" or win_xml.getProperty("PlexKM.Info.IsTV") == "1")
            if not is_tv:
                return ""
            is_episode = (self.getProperty("PlexKM.Info.IsEpisode") == "1" or win_home.getProperty("PlexKM.Info.IsEpisode") == "1" or win_xml.getProperty("PlexKM.Info.IsEpisode") == "1")
            if is_episode:
                return "episodes"
            rows = list(getattr(self, "_info_tv_rows", []) or [])
            season_cards = list(getattr(self, "_info_tv_season_cards", []) or [])
            seasons = list(getattr(self, "_info_tv_seasons", []) or [])
            effective_season_count = len(season_cards) or len(seasons)
            if rows and effective_season_count <= 1:
                return "episodes"
            try:
                ep_size = int(self.getControl(self._info_tv_active_episode_control_id()).size())
            except Exception:
                ep_size = 0
            try:
                season_size = int(self.getControl(5711).size())
            except Exception:
                season_size = 0
            if ep_size > 0 and season_size <= 1:
                return "episodes"
            if season_size > 0:
                return "seasons"
            if ep_size > 0:
                return "episodes"
        except Exception:
            pass
        return ""

    def _info_tv_control_focusable_v2409(self, control_id):
        """Return True only when a TV panel is currently visible and has real items.

        Kodi logs a hard ERROR before Python can catch an invalid setFocus/getControl
        request. Therefore every TV A/B focus handoff must prove native visibility
        first instead of trusting a possibly stale TVActiveBuffer property.
        """
        try:
            cid = int(control_id or 0)
            if cid not in (5711, 5712, 5713):
                return False
            if not xbmc.getCondVisibility("Control.IsVisible(%d)" % cid):
                return False
            ctrl = self.getControl(cid)
            try:
                if int(ctrl.size()) <= 0:
                    return False
            except Exception:
                return False
            return True
        except Exception:
            return False

    def _info_tv_focus_panel(self, control_id, reason=""):
        """Focus only a proven-visible TV Info panel; never request a hidden A/B bank.

        v2409 makes invalid-control focus structurally impossible for this path.
        LEFT/RIGHT/UP/DOWN inside the actual panel remains Kodi XML-owned.
        """
        try:
            requested = int(control_id or 0)
            if requested not in (5711, 5712, 5713):
                return False
            active = (self.getProperty("PlexKM.Info.InlineActive") == "1" or
                      xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1")
            if not active:
                _log("INLINE_INFO_TV_FOCUS_SKIP_V2409 reason=%s requested=%s inline_inactive=1" % (reason or "", requested))
                return False
            if getattr(self, "_info_tv_defer_focus", False):
                _log("INLINE_INFO_TV_FOCUS_SKIP_V2409 reason=%s requested=%s tv_publish_deferred=1" % (reason or "", requested))
                return False

            if not self._pkm_window_owned_r34():
                _log("INLINE_INFO_TV_FOCUS_SKIP reason=window_not_active requested=%s" % requested)
                return False
            candidates = []
            if requested == 5711:
                candidates = [5711]
            else:
                # Only the declared active bank may take focus. A second bank
                # can be momentarily reported visible during A/B animation but
                # Kodi rejects focus if it is not the published owner.
                preferred = self._info_tv_active_episode_control_id()
                candidates = [preferred]

            cid = 0
            for candidate in candidates:
                if self._info_tv_control_focusable_v2409(candidate):
                    cid = candidate
                    break
            if not cid:
                _log("INLINE_INFO_TV_FOCUS_SKIP_V2409 reason=%s requested=%s no_visible_nonempty_target=1" % (reason or "", requested), xbmc.LOGWARNING)
                return False

            try:
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
            except Exception:
                pass
            ctrl = self.getControl(cid)
            self.setFocus(ctrl)
            self._info_mark_entry_target_focus_ready_v2123(
                cid, reason="tv_focus_set_v2409_%s" % (reason or "")
            )
            _log("INLINE_INFO_TV_FOCUS_SET_V2409 reason=%s requested=%s control=%s visibility_proven=1" % (reason or "", requested, cid))
            return True
        except Exception:
            _log("INLINE_INFO_TV_FOCUS_FAILED_V2409 reason=%s requested=%s err=%s" % (
                reason or "", control_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _pkm_tv_focus_after_window_active_vnext(self):
        """GUI-thread only, one deferred TV focus after Kodi window handoff."""
        rec = getattr(self, "_pkm_tv_focus_pending_vnext", None)
        if not isinstance(rec, dict):
            return False
        rk = str(rec.get("rating_key") or "")
        active = str(self.getProperty("PlexKM.Info.RatingKey") or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "")
        if active != rk or self.getProperty("PlexKM.Info.InlineActive") != "1":
            self._pkm_tv_focus_pending_vnext = None
            return False
        try:
            current = int(self.getFocusId())
        except Exception:
            current = -1
        if current in (5711, 5712, 5713):
            self._pkm_tv_focus_pending_vnext = None
            return True
        if current not in (8610, 8611, 8612, 8613, 8614, 8615) and not self._focus_on_retired_surface_r34(current):
            # User selected another real UI control: never steal their focus.
            # R34: focus parked on a hidden surface (actor works 6500 after an
            # actor-work Info) is not a user choice, so keep retrying.
            self._pkm_tv_focus_pending_vnext = None
            _log("INFO_TV_FOCUS_RETRY_STOP_VNEXT rating_key=%s focus=%s reason=user_control_changed" % (rk, current))
            return False
        if self._pkm_window_owned_r34():
            target = int(rec.get("control") or 0)
            ok = self._info_tv_focus_panel(target, reason="deferred_visible_vnext")
            if ok:
                self._pkm_tv_focus_pending_vnext = None
                self._last_focus_id = target
                _log("INFO_TV_FOCUS_RETRY_OK_VNEXT rating_key=%s target=%d" % (rk, target))
                return True
        count = int(rec.get("attempts") or 0) + 1
        if count >= 4:
            self._pkm_tv_focus_pending_vnext = None
            _log("INFO_TV_FOCUS_RETRY_UNPROVEN_VNEXT rating_key=%s focus=%d attempts=%d" % (rk, current, count), xbmc.LOGWARNING)
            return False
        rec["attempts"] = count
        self._pkm_tv_focus_pending_vnext = rec
        self._pkm_tv_focus_retry_ping_vnext(delay_ms=75)
        return False

    def _pkm_tv_focus_retry_ping_vnext(self, delay_ms=75):
        """Posts only a GUI ping; never changes a control from a background thread."""
        try:
            if getattr(self, "_pkm_tv_focus_retry_posted_vnext", False):
                return
            self._pkm_tv_focus_retry_posted_vnext = True
            def _post():
                try:
                    if not self._closing_event_v1841.wait(max(0, int(delay_ms)) / 1000.0):
                        self._pkm_tv_focus_retry_posted_vnext = False
                        xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                finally:
                    self._pkm_tv_focus_retry_posted_vnext = False
            _PKMHomeThreadV2151(target=_post, name="PKMTVFocusRetryVNext", daemon=True).start()
        except Exception:
            self._pkm_tv_focus_retry_posted_vnext = False

    def _info_tv_episode_code(self, season, episode):
        return pkm_info_data.episode_identity_text(season, episode)

    def _info_tv_episode_badge_label(self, episode):
        """Return the Plex episode index unchanged as a thumbnail badge.

        Cross-library metadata probes confirmed that 345, 842 and 1088 are real
        episode indexes, not encoded season/episode values.  Only season indexes
        use PKM's 100-series 4K convention; episode indexes must never be modulo 100.
        """
        try:
            e = _safe_int(episode, 0)
            if e <= 0:
                return ""
            return "%d화" % int(e)
        except Exception:
            return ""

    def _info_tv_episode_badge_size(self, episode):
        """Classify the episode badge width for XML-native Plex-style badges."""
        try:
            label = self._info_tv_episode_badge_label(episode)
            digits = "".join([ch for ch in str(label or "") if ch.isdigit()])
            count = len(digits)
            if count >= 3:
                return "triple"
            if count == 2:
                return "double"
            if count == 1:
                return "single"
        except Exception:
            pass
        return ""

    def _info_tv_normalize_season_label(self, label, season):
        """Prefer Plex's authoritative season title without inventing edition names.

        v2347: 100-series season indexes remain PKM's established 4K aliases
        (101 -> 시즌 1 4K).  Other season numbers are *not* interpreted by PKM.
        If Plex supplies a meaningful non-generic title such as
        ``시즌 1 감독판``, preserve it verbatim.  This lets GDS/shared-folder
        naming exposed by Plex survive without globally assuming that e.g. 201
        always means a director's cut.
        """
        try:
            s = _safe_int(season, -1)
            raw = str(label or "").strip()
            if s == 0:
                return raw or "스페셜"

            # PKM's only numeric alias contract is the 100-series 4K namespace.
            if 101 <= s <= 199:
                season_text = pkm_info_data.season_display_text(s)
                return "시즌 %s" % season_text if season_text else (raw or "시즌 %s" % s)

            if raw:
                compact = re.sub(r"\s+", "", raw).lower()
                generic = {
                    ("시즌%s" % s).lower(),
                    ("season%s" % s).lower(),
                }
                # A title that carries anything beyond the physical index is
                # authoritative metadata (edition/cut/etc.) and must not be
                # rewritten to the raw number.
                if compact not in generic:
                    return raw

            if s > 0:
                return "시즌 %s" % s
            return raw or "스페셜"
        except Exception:
            return str(label or "") or "스페셜"

    def _info_tv_media_badges_for_rating_key(self, rating_key):
        """Return cached TV media badges without blocking Info publish.

        v877: Do not call Plex while building each episode ListItem.  v875/v876
        spent 400~800ms here because every visible episode performed a synchronous
        /library/metadata/<ratingKey> request before the rail could be shown.
        The lower rail must appear first; detailed media badges can be blank rather
        than delaying TV rows.
        """
        rk = str(rating_key or "").strip()
        if not rk:
            return {"video": "", "audio": "", "subtitle": "", "video_size": "", "audio_size": "", "subtitle_size": ""}
        cache = getattr(self, "_info_tv_media_badge_cache", None)
        if cache is None:
            cache = {}
            self._info_tv_media_badge_cache = cache
        if rk in cache:
            return cache.get(rk) or {"video": "", "audio": "", "subtitle": "", "video_size": "", "audio_size": "", "subtitle_size": ""}
        out = {"video": "", "audio": "", "subtitle": "", "video_size": "", "audio_size": "", "subtitle_size": ""}
        cache[rk] = out
        return out

    def _info_tv_episode_thumb_candidates_v2355(self, row):
        """Return ordered episode-still candidates without doing network I/O.

        Episode cards are small 16:9 surfaces.  A Plex metadata ``thumb`` can
        point at a large original image, so loading that original for every
        visible card wastes bandwidth and decode time.  Prefer a Plex-generated
        500x281 thumbnail when the source belongs to the configured Plex server,
        then retain the original/direct URL as a fallback.

        The raw episode metadata thumb remains authoritative. Canonical episode
        endpoints follow it, and the normalized DB thumb remains legacy-only.
        """
        try:
            import json as _json
        except Exception:
            _json = None

        out = []
        seen = set()

        def _append(source, value):
            final = str(value or "").strip()
            if not final or final in seen:
                return
            seen.add(final)
            out.append((str(source or ""), final))

        def _plex_small(value):
            """Return a small Plex transcode URL, or the original external URL."""
            text = str(value or "").strip()
            if not text:
                return ""
            lower = text.lower()
            if lower.startswith(("special://", "resource://", "image://", "file://")):
                return text
            try:
                c = _ensure_core()
                server = str(c.clean_server_url() or "").rstrip("/")
                server_parts = urlsplit(server) if server else None
                original_path = ""

                if text.startswith("/"):
                    parsed = urlsplit(text)
                    original_path = parsed.path or ""
                    query = dict(parse_qsl(parsed.query or "", keep_blank_values=True))
                elif lower.startswith(("http://", "https://")):
                    cleaned = _clean_external_image_url(text)
                    parsed = urlsplit(cleaned)
                    same_server = bool(
                        server_parts and parsed.netloc
                        and parsed.netloc.lower() == server_parts.netloc.lower()
                    )
                    if not same_server:
                        return cleaned
                    original_path = parsed.path or ""
                    query = dict(parse_qsl(parsed.query or "", keep_blank_values=True))
                else:
                    original_path = text if text.startswith("/") else "/" + text
                    query = {}

                # If the stored value is already a Plex transcode URL, preserve
                # its nested source path but request the exact episode-card size.
                if original_path.rstrip("/") == "/photo/:/transcode":
                    nested = str(query.get("url") or "").strip()
                    if nested:
                        nested_parts = urlsplit(nested)
                        original_path = nested_parts.path or nested

                if not original_path:
                    return ""
                return c.plex_url(
                    "/photo/:/transcode",
                    params={
                        "width": 500,
                        "height": 281,
                        "minSize": 1,
                        "upscale": 0,
                        "url": original_path,
                    },
                    include_token=True,
                )
            except Exception:
                return ""

        def _direct(value):
            text = str(value or "").strip()
            if not text:
                return ""
            try:
                return str(_plex_art(text, width=500, height=281) or "").strip()
            except Exception:
                return text

        try:
            r = tuple(row or ())
            rating_key = str((r[0] if len(r) > 0 else "") or "").strip()
            updated_at = str((r[11] if len(r) > 11 else "") or "").strip()
            stored_thumb = str((r[12] if len(r) > 12 else "") or "").strip()
            raw_json = str((r[27] if len(r) > 27 else "") or "").strip()

            raw_thumb = ""
            if raw_json and _json:
                try:
                    data = _json.loads(raw_json) or {}
                    raw_thumb = str(data.get("thumb") or "").strip()
                except Exception:
                    raw_thumb = ""

            # R63: Plex can list an episode thumb that its own image store no
            # longer has (every URL returns 404, e.g. 나인 퍼즐 E2..E11).  Once
            # all candidates failed, skip Plex for a few days and use the TMDb
            # episode still instead of re-requesting four 404 URLs per open.
            still_r63 = self._episode_still_r63(rating_key) if rating_key else ""
            if rating_key and self._episode_thumb_miss_r63(rating_key, raw_thumb):
                if still_r63:
                    _append("tmdb_still_r63", still_r63)
                # R65: the timestamp-less endpoint always serves Plex's
                # CURRENT thumb, so a Plex metadata refresh is picked up even
                # while the local DB still holds the old (404) path.
                _append("plex_episode_canonical_small_r65", _plex_small("/library/metadata/%s/thumb" % rating_key))
                return out

            if raw_thumb:
                _append("plex_metadata_thumb_small", _plex_small(raw_thumb))
                _append("plex_metadata_thumb_direct", _direct(raw_thumb))

            if still_r63:
                _append("tmdb_still_r63", still_r63)

            if rating_key:
                bare = "/library/metadata/%s/thumb" % rating_key
                _append("plex_episode_canonical_small", _plex_small(bare))
                _append("plex_episode_canonical_direct", _direct(bare))

                if updated_at and updated_at not in ("0", "None", "none", "null"):
                    stamped = "/library/metadata/%s/thumb/%s" % (rating_key, updated_at)
                    _append("plex_episode_stamped_small", _plex_small(stamped))
                    _append("plex_episode_stamped_direct", _direct(stamped))

            # R64: the legacy DB thumb of an episode row is the SHOW poster.
            # R63 widened the download slice to five and this poster then
            # "succeeded" for every 404 episode (identical cards).  Never use
            # it as an episode still.

            try:
                _log(
                    "INFO_TV_THUMB_CANDIDATES rating_key=%s metadata_thumb=%d candidates=%d first=%s" % (
                        rating_key,
                        1 if raw_thumb else 0,
                        len(out),
                        str(out[0][0] if out else "none"),
                    )
                )
            except Exception:
                pass
        except Exception:
            pass
        return out

    def _info_tv_episode_thumb_from_row(self, row):
        """Return the best non-blocking episode still URL for the Info rail."""
        try:
            candidates = list(self._info_tv_episode_thumb_candidates_v2355(row) or [])
            if candidates:
                r = tuple(row or ())
                rating_key = str((r[0] if r else "") or "")
                source, final = candidates[0]
                try:
                    _log("INLINE_INFO_TV_EPISODE_THUMB_SOURCE_V2355 rating_key=%s source=%s candidates=%d final=%s" % (
                        rating_key, source, len(candidates), _short_log_value(re.sub(r"(?i)(x-plex-token=)[^&\s]+", r"\1***", str(final or "")))))
                except Exception:
                    pass
                return final
        except Exception:
            pass
        return ""

    @staticmethod
    def _info_tv_image_format_v2356(data):
        """Return a fully decodable image format, not just a matching header.

        v2355 only checked the first bytes of the persistent episode-thumb cache.
        A truncated JPEG/PNG can still have a perfect header and was therefore
        counted as ``local_ready`` even though Kodi renders it as a black card.
        Use Pillow's verify path when available (script.module.pil is already a
        PKM/Kodi dependency in this build), with a strict structural fallback.
        """
        try:
            b = bytes(data or b"")
        except Exception:
            b = b""
        if len(b) < 1024:
            return ""

        # Full compressed-stream verification.  Image.verify() does not decode
        # pixels, so this remains cheap for the six visible episode stills.
        try:
            from PIL import Image
            im = Image.open(BytesIO(b))
            fmt = str(getattr(im, "format", "") or "").strip().lower()
            im.verify()
            if fmt in ("jpeg", "jpg"):
                return "jpg"
            if fmt in ("png", "gif", "webp"):
                return fmt
        except Exception:
            pass

        # Pillow can be unavailable on unusual Kodi installs.  The fallback is
        # deliberately stricter than v2355: both the header and an end-of-file
        # marker/declared container length must be present.
        try:
            if b.startswith(b"\xff\xd8\xff"):
                tail = b[-128:]
                if b"\xff\xd9" in tail:
                    return "jpg"
            if b.startswith(b"\x89PNG\r\n\x1a\n"):
                if b.endswith(b"\x00\x00\x00\x00IEND\xaeB`\x82"):
                    return "png"
            if b.startswith((b"GIF87a", b"GIF89a")) and b.endswith(b";"):
                return "gif"
            if len(b) >= 12 and b[:4] == b"RIFF" and b[8:12] == b"WEBP":
                declared = int.from_bytes(b[4:8], "little") + 8
                if declared <= len(b) and (len(b) - declared) <= 16:
                    return "webp"
        except Exception:
            pass
        return ""

    def _info_tv_cached_image_probe_v2356(self, path):
        """Return the verified image format for a persistent cache file."""
        try:
            if not path or not os.path.isfile(path):
                return ""
            size = int(os.path.getsize(path) or 0)
            if size < 1024 or size > 16 * 1024 * 1024:
                return ""
            with open(path, "rb") as f:
                data = f.read()
            return self._info_tv_image_format_v2356(data)
        except Exception:
            return ""

    def _info_tv_version_props_v2099(self, source_rating_key, result):
        props = {}
        try:
            versions = list((result or {}).get("versions") or [])
            versions = [v for v in versions if str(v.get("resolution") or "") in ("720p", "1080p", "2160p")]
            if not versions:
                return props
            default_resolution = str((result or {}).get("default_resolution") or "").strip()
            selected = None
            for v in versions:
                if str(v.get("resolution") or "") == default_resolution:
                    selected = v
                    break
            if selected is None:
                selected = versions[0]
                default_resolution = str(selected.get("resolution") or "")
            compact = []
            for v in versions:
                compact.append({
                    "resolution": str(v.get("resolution") or ""),
                    "rating_key": str(v.get("rating_key") or ""),
                    "section_id": str(v.get("section_id") or ""),
                    "part_key": str(v.get("part_key") or ""),
                    "match_reason": str(v.get("match_reason") or ""),
                })
            props.update({
                "VersionAvailable": "1",
                "VersionMultiple": "1" if len(versions) >= 2 else "",
                "VersionCount": str(len(versions)),
                "VersionLabel": default_resolution,
                "VersionIconLabel": default_resolution.upper(),
                "VersionSelectedRatingKey": str(selected.get("rating_key") or source_rating_key or ""),
                "VersionSelectedSectionId": str(selected.get("section_id") or ""),
                "VersionSelectedPartKey": str(selected.get("part_key") or ""),
                "VersionSelectedMatchReason": str(selected.get("match_reason") or ""),
                "VersionCandidatesJSON": json.dumps(compact, ensure_ascii=False, separators=(",", ":")),
            })
            for res, key in (("720p", "VersionHas720"), ("1080p", "VersionHas1080"), ("2160p", "VersionHas2160")):
                props[key] = "1" if any(str(v.get("resolution") or "") == res for v in versions) else ""
        except Exception:
            return {}
        return props

    def _info_tv_version_thumb_for_rating_key_v2325(self, rating_key, reason=""):
        """Resolve one TV episode version's still image from local data only.

        Media-version identity may point at an episode in a hidden 100-series
        4K season or in another selected TV library.  The visible episode rail
        must follow that concrete playback target without a Plex request or a
        rail rebuild, so prefer the already-loaded show rows and fall back to
        one local DB lookup by ratingKey.
        """
        rk = str(rating_key or "").strip()
        if not rk:
            return ""
        try:
            cache = getattr(self, "_info_tv_version_thumb_cache_v2325", None)
            if not isinstance(cache, dict):
                cache = {}
                self._info_tv_version_thumb_cache_v2325 = cache
            if rk in cache:
                return str(cache.get(rk) or "")
        except Exception:
            cache = {}

        row = None
        try:
            for candidate in list(getattr(self, "_info_tv_rows", []) or []):
                rr = tuple(candidate or ())
                if str((rr[0] if rr else "") or "").strip() == rk:
                    row = candidate
                    break
        except Exception:
            row = None

        if row is None:
            conn = None
            try:
                conn = _pkm_ro_connect(self._profile_db_path(), timeout=1.0)
                row = conn.execute(
                    "SELECT rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, "
                    "year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, "
                    "view_count, last_viewed_at, show_title, season, episode, parent_rating_key, "
                    # R36: items has no resume columns (R30 class) - keep row positions.
                    "grandparent_rating_key, 0 AS view_offset, 0 AS resume_duration_ms, '' AS resume_updated_at, "
                    "'' AS resume_source, raw_json FROM items WHERE rating_key=? AND plex_type='episode' LIMIT 1",
                    (rk,),
                ).fetchone()
            except Exception:
                row = None
            finally:
                try:
                    if conn is not None:
                        conn.close()
                except Exception:
                    pass

        thumb = ""
        try:
            if row is not None:
                thumb = str(self._info_tv_episode_thumb_from_row(row) or "")
        except Exception:
            thumb = ""
        try:
            cache[rk] = thumb
        except Exception:
            pass
        _log("INFO_TV_VERSION_THUMB_RESOLVE_V2325 target_rk=%s thumb=%s source=%s reason=%s" % (
            rk, 1 if thumb else 0, "memory_or_db" if row is not None else "miss", reason or ""
        ))
        return thumb

    def _info_tv_apply_selected_version_thumb_v2325(self, item, target_rating_key, reason=""):
        """Apply the selected TV playback target's still to the existing rail item.

        This intentionally performs no Info rebuild and no focus write.  It is
        shared by the quick resolution cycle and the detailed media-version
        selector, so every TV show follows the same artwork policy.
        """
        if item is None:
            return False
        target_rk = str(target_rating_key or "").strip()
        if not target_rk:
            return False
        thumb = self._info_tv_version_thumb_for_rating_key_v2325(
            target_rk, reason="apply_%s" % (reason or "")
        )
        if not thumb:
            _log("INFO_TV_VERSION_THUMB_APPLY_V2325 target_rk=%s applied=0 reason=%s" % (
                target_rk, reason or ""
            ), xbmc.LOGWARNING)
            return False
        try:
            art = {"thumb": thumb, "icon": thumb}
            fanart = str(item.getArt("fanart") or "")
            if fanart:
                art["fanart"] = fanart
            item.setArt(art)
            item.setProperty("PlexKM.Thumb", thumb)
            item.setProperty("PlexKM.EpisodeThumb", thumb)
            item.setProperty("PlexKM.VersionSelectedThumbV2325", thumb)
            self._info_set_property_all("PlexKM.Info.TVVersionThumbV2325", thumb)
            _log("INFO_TV_VERSION_THUMB_APPLY_V2325 target_rk=%s applied=1 reason=%s" % (
                target_rk, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_VERSION_THUMB_APPLY_FAILED_V2325 target_rk=%s reason=%s err=%s" % (
                target_rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_publish_selected_version_state_v2123(self, item=None, reason=""):
        """Publish the selected episode version from one authoritative state.

        Kodi may keep Container(...).ListItem.Property visually cached after a
        Python-side ListItem mutation.  v2123 therefore snapshots the selected
        episode's actual playback target into Window properties and playback
        reads the same snapshot.  No rail rebuild, focus write, or navigation is
        performed here.
        """
        try:
            item = item or self._info_tv_selected_episode_item()
            if not item:
                return {}
            source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
            if not source_rk:
                return {}

            state = {
                "owner_rating_key": source_rk,
                "available": str(item.getProperty("PlexKM.VersionAvailable") or ""),
                "multiple": str(item.getProperty("PlexKM.VersionMultiple") or ""),
                "count": str(item.getProperty("PlexKM.VersionCount") or ""),
                "label": str(item.getProperty("PlexKM.VersionLabel") or "").strip().lower(),
                "icon_label": str(item.getProperty("PlexKM.VersionIconLabel") or "").strip().upper(),
                "rating_key": str(item.getProperty("PlexKM.VersionSelectedRatingKey") or source_rk).strip(),
                "section_id": str(item.getProperty("PlexKM.VersionSelectedSectionId") or "").strip(),
                "part_key": str(item.getProperty("PlexKM.VersionSelectedPartKey") or item.getProperty("PlexKM.PartKey") or "").strip(),
                "match_reason": str(item.getProperty("PlexKM.VersionSelectedMatchReason") or "").strip(),
                "media_available": str(item.getProperty("PlexKM.MediaVersionAvailable") or ""),
                "media_selected_key": str(item.getProperty("PlexKM.MediaVersionSelectedKey") or "").strip(),
                "media_video": str(item.getProperty("PlexKM.MediaVersionVideo") or "").strip(),
                "media_audio": str(item.getProperty("PlexKM.MediaVersionAudio") or "").strip(),
                "audio_stream_index": str(item.getProperty("PlexKM.MediaVersionAudioStreamIndex") or "").strip(),
            }

            # Detailed media-variant selection is the strongest owner.  Overlay
            # it even if Kodi's native ListItem cache has not visually repainted.
            choice = dict((getattr(self, "_info_tv_media_choice_v2112", {}) or {}).get(source_rk) or {})
            if choice and str(choice.get("owner_rating_key") or "") == source_rk:
                resolution = str(choice.get("resolution") or "").strip().lower()
                if resolution:
                    state["label"] = resolution
                    state["icon_label"] = resolution.upper()
                state["rating_key"] = str(choice.get("rating_key") or state["rating_key"] or source_rk).strip()
                state["section_id"] = str(choice.get("section_id") or state["section_id"] or "").strip()
                state["part_key"] = str(choice.get("part_key") or state["part_key"] or "").strip()
                state["match_reason"] = str(choice.get("match_reason") or "MEDIA_VARIANT").strip()
                state["media_available"] = "1"
                state["media_selected_key"] = str(choice.get("variant_key") or state["media_selected_key"] or "%s|%s" % (state["rating_key"], state["part_key"]))
                state["media_video"] = str(choice.get("main_label") or state["media_video"] or "")
                state["media_audio"] = str(choice.get("audio_label") or state["media_audio"] or "")
                state["audio_stream_index"] = str(choice.get("audio_stream_index") if choice.get("audio_stream_index") is not None else state["audio_stream_index"] or "")

            if not state["icon_label"] and state["label"]:
                state["icon_label"] = state["label"].upper()
            self._info_tv_selected_version_state_v2123 = dict(state)
            prop_map = {
                "PlexKM.Info.TVVersionOwnerRatingKey": state["owner_rating_key"],
                "PlexKM.Info.TVVersionAvailable": state["available"],
                "PlexKM.Info.TVVersionMultiple": state["multiple"],
                "PlexKM.Info.TVVersionCount": state["count"],
                "PlexKM.Info.TVVersionLabel": state["label"],
                "PlexKM.Info.TVVersionIconLabel": state["icon_label"],
                "PlexKM.Info.TVVersionRatingKey": state["rating_key"],
                "PlexKM.Info.TVVersionSectionId": state["section_id"],
                "PlexKM.Info.TVVersionPartKey": state["part_key"],
                "PlexKM.Info.TVVersionMatchReason": state["match_reason"],
                "PlexKM.Info.TVMediaVersionAvailableV2123": state["media_available"],
                "PlexKM.Info.TVMediaVersionSelectedKeyV2123": state["media_selected_key"],
                "PlexKM.Info.TVMediaVersionVideoV2123": state["media_video"],
                "PlexKM.Info.TVMediaVersionAudioV2123": state["media_audio"],
                "PlexKM.Info.TVMediaVersionAudioStreamIndexV2123": state["audio_stream_index"],
            }
            for key, value in prop_map.items():
                self._info_set_property_all(key, value)
            _log("INFO_TV_SELECTED_VERSION_STATE_V2123 owner=%s resolution=%s target_rk=%s part=%s multiple=%s media=%s reason=%s" % (
                source_rk, state["label"] or "-", state["rating_key"] or "-",
                state["part_key"] or "-", state["multiple"] or "0",
                state["media_selected_key"] or "-", reason or ""
            ))
            return dict(state)
        except Exception:
            _log("INFO_TV_SELECTED_VERSION_STATE_FAILED_V2123 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return {}

    def _info_tv_clear_selected_version_state_v2123(self, reason=""):
        try:
            self._info_tv_selected_version_state_v2123 = {}
            for key in (
                "PlexKM.Info.TVVersionOwnerRatingKey", "PlexKM.Info.TVVersionAvailable",
                "PlexKM.Info.TVVersionMultiple", "PlexKM.Info.TVVersionCount",
                "PlexKM.Info.TVVersionLabel", "PlexKM.Info.TVVersionIconLabel",
                "PlexKM.Info.TVVersionRatingKey", "PlexKM.Info.TVVersionSectionId",
                "PlexKM.Info.TVVersionPartKey", "PlexKM.Info.TVVersionMatchReason",
                "PlexKM.Info.TVMediaVersionAvailableV2123",
                "PlexKM.Info.TVMediaVersionSelectedKeyV2123",
                "PlexKM.Info.TVMediaVersionVideoV2123",
                "PlexKM.Info.TVMediaVersionAudioV2123",
                "PlexKM.Info.TVMediaVersionAudioStreamIndexV2123",
                "PlexKM.Info.TVVersionThumbV2325",
            ):
                self._info_clear_property_all(key)
            _log("INFO_TV_SELECTED_VERSION_STATE_CLEAR_V2123 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _info_tv_cycle_version_v2099(self, reason=""):
        """Cycle only the selected episode's playback target; never rebuild Info."""
        item = self._info_tv_selected_episode_item()
        if not item:
            return False
        try:
            raw = item.getProperty("PlexKM.VersionCandidatesJSON") or "[]"
            candidates = json.loads(raw)
            if not isinstance(candidates, list):
                candidates = []
            by_resolution = {}
            for entry in candidates:
                if not isinstance(entry, dict):
                    continue
                res = str(entry.get("resolution") or "").strip()
                if res in ("720p", "1080p", "2160p") and res not in by_resolution:
                    by_resolution[res] = entry
            ordered = [r for r in ("720p", "1080p", "2160p") if r in by_resolution]
            if len(ordered) < 2:
                return False
            current = str(item.getProperty("PlexKM.VersionLabel") or "").strip()
            try:
                pos = ordered.index(current)
            except ValueError:
                pos = -1
            next_resolution = ordered[(pos + 1) % len(ordered)]
            selected = by_resolution[next_resolution]
            item.setProperty("PlexKM.VersionLabel", next_resolution)
            item.setProperty("PlexKM.VersionIconLabel", next_resolution.upper())
            item.setProperty("PlexKM.VersionSelectedRatingKey", str(selected.get("rating_key") or ""))
            item.setProperty("PlexKM.VersionSelectedSectionId", str(selected.get("section_id") or ""))
            item.setProperty("PlexKM.VersionSelectedPartKey", str(selected.get("part_key") or ""))
            item.setProperty("PlexKM.VersionSelectedMatchReason", str(selected.get("match_reason") or ""))
            source_rk = str(item.getProperty("PlexKM.RatingKey") or "")
            if not hasattr(self, "_info_tv_version_choice_v2099") or not isinstance(getattr(self, "_info_tv_version_choice_v2099", None), dict):
                self._info_tv_version_choice_v2099 = {}
            self._info_tv_version_choice_v2099[source_rk] = next_resolution
            # v2112: quick resolution selection returns to that resolution's
            # representative Part; clear any detailed codec/Part override.
            try:
                if isinstance(getattr(self, "_info_tv_media_choice_v2112", None), dict):
                    self._info_tv_media_choice_v2112.pop(source_rk, None)
                item.setProperty("PlexKM.MediaVersionSelectedKey", "")
                item.setProperty("PlexKM.MediaVersionVideo", "")
                item.setProperty("PlexKM.MediaVersionAudio", "")
                item.setProperty("PlexKM.MediaVersionAudioStreamIndex", "")
            except Exception:
                pass
            self._info_tv_apply_selected_version_thumb_v2325(
                item, selected.get("rating_key") or source_rk,
                reason="cycle_v2099_%s" % (reason or "")
            )
            self._info_tv_publish_selected_version_state_v2123(
                item, reason="cycle_v2099_%s" % (reason or "")
            )
            _log("INFO_TV_VERSION_ICON_CYCLE_V2099 source_rk=%s from=%s to=%s target_rk=%s target_section=%s available=%s no_refresh=1 thumb_follow_v2325=1 reason=%s" % (
                source_rk, current or "-", next_resolution,
                selected.get("rating_key") or "", selected.get("section_id") or "",
                ",".join(ordered), reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_VERSION_ICON_CYCLE_FAILED_V2099 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_row_to_li(self, row, thumb_override="", version_info_v2099=None):
        row = tuple(row or ())
        rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = row[:21]
        display_title = pkm_info_data.normalize_episode_title(title, episode)
        url = ""
        try:
            if part_key and plex_type == "episode":
                url = _pkm_play_url(rating_key, part_key, mode="start")
        except Exception:
            url = ""
        parent_rating_key = row[21] if len(row) > 21 else ""
        grandparent_rating_key = row[22] if len(row) > 22 else ""
        view_offset = row[23] if len(row) > 23 else ""
        resume_duration_ms = row[24] if len(row) > 24 else ""
        resume_updated_at = row[25] if len(row) > 25 else ""
        resume_source = row[26] if len(row) > 26 else ""

        # v544: DB episode rows do not always carry live resume offset.
        # Merge Kodi local resume sidecar and startup continue-preload without network
        # so the episode action button can show 재생/이어서 재생 correctly.
        try:
            if _safe_int(view_offset, 0) <= 0 and rating_key:
                states = getattr(_ensure_core(), "_read_local_resume_states", lambda: {})() or {}
                st = states.get(str(rating_key)) or {}
                if st:
                    view_offset = st.get("time") or view_offset
                    resume_duration_ms = st.get("duration") or resume_duration_ms
                    resume_updated_at = st.get("updated_at") or resume_updated_at
                    resume_source = resume_source or "kodi_local_resume"
        except Exception:
            pass
        try:
            if _safe_int(view_offset, 0) <= 0 and rating_key:
                reader = getattr(_ensure_core(), "_read_continue_preload_items", None)
                items_age = reader(max_age=86400) if reader else ([], 0)
                items = items_age[0] if isinstance(items_age, tuple) else items_age
                for it in list(items or []):
                    if str((it or {}).get("rating_key") or "") == str(rating_key):
                        view_offset = (it or {}).get("view_offset") or view_offset
                        resume_duration_ms = (it or {}).get("resume_duration_ms") or resume_duration_ms
                        resume_updated_at = (it or {}).get("resume_updated_at") or resume_updated_at
                        resume_source = resume_source or ((it or {}).get("resume_source") or "continue_preload")
                        break
        except Exception:
            pass
        watched_flag = "1" if _safe_int(view_count, 0) > 0 else ""
        # v2327: watched is historical state, not a command to erase a new replay
        # position. A valid 60s..90% replay resume remains active even when
        # Plex view_count is already non-zero.
        active_resume_ms_v2327 = self._resume_offset_ms_for_ui(
            view_offset, duration, resume_duration_ms
        )
        has_active_resume_v2327 = bool(active_resume_ms_v2327 > 0)
        if watched_flag and not has_active_resume_v2327:
            try:
                if _safe_int(view_offset, 0) > 0 or _safe_int(resume_duration_ms, 0) > 0:
                    _log("INLINE_INFO_TV_WATCHED_RESUME_SUPPRESS_V2327 rating_key=%s view_count=%s view_offset=%s resume_duration=%s source=%s reason=no_valid_active_resume" % (
                        rating_key or "", view_count or "", view_offset or "", resume_duration_ms or "", resume_source or ""))
            except Exception:
                pass
            view_offset = ""
            resume_duration_ms = ""
            resume_updated_at = ""
            resume_source = "watched_complete"
        elif watched_flag and has_active_resume_v2327:
            try:
                _log("INLINE_INFO_TV_WATCHED_REPLAY_RESUME_KEEP_V2327 rating_key=%s view_count=%s view_offset=%s active_resume_ms=%s resume_duration=%s source=%s" % (
                    rating_key or "", view_count or "", view_offset or "", active_resume_ms_v2327,
                    resume_duration_ms or "", resume_source or "plex_or_local"))
            except Exception:
                pass

        play_button_label = self._play_button_label(view_offset, duration, resume_duration_ms)
        remaining_text, remaining_icon = self._remaining_time_props(duration, view_offset)

        # v1563: the TV Info rail is an episode rail, so its yellow bar must be
        # calculated from this episode's own viewOffset/duration pair.  Do not use
        # show-level watched/total aggregation here; that remains correct only for
        # representative TV-show posters on Home/Wall/Search.
        #
        # The previous local <=86400 heuristic treated a Plex offset such as
        # 74784ms as 74784 seconds when the DB duration was 3631 seconds.  That
        # inflated a roughly 2% episode position to 100%.  Reuse the single
        # context-aware normalizer already used by movie/Home progress.
        progress_percent = 0
        progress_step2 = 0
        progress_composite_350x10 = ""
        progress_composite_370x10 = ""
        try:
            off_raw = _safe_int(view_offset, 0)
            dur_raw = _safe_int(duration, 0)
            resume_dur_raw = _safe_int(resume_duration_ms, 0)
            core_mod = _ensure_core()
            off_ms, dur_ms, progress_percent = getattr(core_mod, "_pkm_progress_pair")(
                off_raw, dur_raw, resume_dur_raw
            )
            progress_percent = int(max(0, min(100, _safe_int(progress_percent, 0))))
            if progress_percent > 0:
                progress_props_v2330 = getattr(core_mod, "_pkm_resume_progress_props_v2330")(progress_percent) or {}
                progress_composite_350x10 = str(progress_props_v2330.get("ResumeProgressComposite350x10") or "")
                progress_composite_370x10 = str(progress_props_v2330.get("ResumeProgressComposite370x10") or "")
                progress_step2 = int(max(2, min(100, ((progress_percent + 1) // 2) * 2)))
            try:
                _log(
                    "INLINE_INFO_TV_EPISODE_PROGRESS_V1563 rating_key=%s source=individual_episode "
                    "offset_raw=%s duration_raw=%s resume_duration_raw=%s offset_ms=%s duration_ms=%s "
                    "pct=%s step=%s width350=%s watched=%s" % (
                        rating_key or "", off_raw, dur_raw, resume_dur_raw, off_ms, dur_ms,
                        progress_percent, progress_step2, int(round(350.0 * float(progress_percent or 0) / 100.0)), watched_flag or "0"
                    )
                )
            except Exception:
                pass
        except Exception:
            progress_percent = 0
            progress_step2 = 0
            progress_composite_350x10 = ""
            progress_composite_370x10 = ""
            try:
                _log("INLINE_INFO_TV_EPISODE_PROGRESS_V1563_FAILED rating_key=%s\n%s" % (rating_key or "", traceback.format_exc()), xbmc.LOGWARNING)
            except Exception:
                pass

        # v2327: fill the actual 860x128 three-line episode synopsis surface.
        # Truncation is rendered-width based; append "..." only when a fourth
        # line would be required instead of cutting at the old fixed 108 chars.
        tmdb_src_r39 = ""
        if plex_type == "episode" and not str(summary or "").strip():
            try:
                plot_r39 = self._tmdb_plot_for_rk_r39(rating_key)
                if plot_r39:
                    summary = plot_r39
                    tmdb_src_r39 = "tmdb"
                    self._tmdb_plot_row_hits_r39 = int(getattr(self, "_tmdb_plot_row_hits_r39", 0) or 0) + 1
            except Exception:
                pass
        summary3 = self._info_tv_episode_summary_display_text_v2327(summary)

        episode_thumb = str(thumb_override or "") or self._info_tv_episode_thumb_from_row(row)
        # v2325: the rail artwork follows the concrete selected playback copy,
        # not the source ListItem. This also preserves the chosen 1080p/2160p
        # still when the A/B episode rail is rebuilt later in the same session.
        try:
            _version_result_v2325 = dict(version_info_v2099 or {})
            _default_res_v2325 = str(_version_result_v2325.get("default_resolution") or "").strip().lower()
            _target_rk_v2325 = str(rating_key or "").strip()
            for _candidate_v2325 in list(_version_result_v2325.get("versions") or []):
                if str((_candidate_v2325 or {}).get("resolution") or "").strip().lower() == _default_res_v2325:
                    _target_rk_v2325 = str((_candidate_v2325 or {}).get("rating_key") or _target_rk_v2325).strip()
                    break
            if _target_rk_v2325 and _target_rk_v2325 != str(rating_key or "").strip():
                _selected_thumb_v2325 = self._info_tv_version_thumb_for_rating_key_v2325(
                    _target_rk_v2325, reason="row_build_%s" % _default_res_v2325
                )
                if _selected_thumb_v2325:
                    episode_thumb = _selected_thumb_v2325
        except Exception:
            pass
        thumb_fallback_r63 = ""
        try:
            if self._episode_thumb_miss_r63(rating_key):
                _et = str(episode_thumb or "")
                _local = bool(_et) and not _et.lower().startswith(("http://", "https://"))
                if not _local and "image.tmdb.org" not in _et:
                    # Not pre-downloaded and Plex returned 404 recently: show
                    # an empty card with its badge instead of a dead URL.
                    episode_thumb = ""
                    thumb_fallback_r63 = "none"
        except Exception:
            pass
        media_badges = self._info_tv_media_badges_for_rating_key(rating_key)
        li = xbmcgui.ListItem(label=display_title or self._episode_fallback_title(episode), path=url)
        try:
            li.setPath(url)
        except Exception:
            pass
        try:
            # Kodi-native thumbnail art for the episode rail.
            # Do not set poster art here.  The XML binds to the ListItem thumbnail
            # property so Kodi cannot fall back to the TV-show poster.
            li.setArt({"thumb": episode_thumb or "", "icon": episode_thumb or "", "fanart": art or ""})
        except Exception:
            pass
        props = {
            "RatingKey": rating_key, "SectionId": section_id, "Type": plex_type, "Title": display_title,
            "ShowTitle": show_title, "Season": season, "Episode": episode, "PartKey": part_key,
            "ParentRatingKey": parent_rating_key, "GrandparentRatingKey": grandparent_rating_key,
            "ViewOffset": view_offset, "ResumeDurationMs": resume_duration_ms,
            "ResumeUpdatedAt": resume_updated_at, "ResumeSource": resume_source,
            "HasActiveResume": "1" if self._resume_offset_ms_for_ui(view_offset, duration, resume_duration_ms) > 0 else "",
            "PlayButtonLabel": play_button_label, "RemainingText": remaining_text,
            "RemainingIcon": remaining_icon, "ResumePercent": progress_percent,
            "ResumeProgressComposite350x10": progress_composite_350x10,
            "ResumeProgressComposite370x10": progress_composite_370x10,
            "Summary3": summary3,
            "PlayUrl": url, "EpisodeCode": self._info_tv_episode_code(season, episode),
            "EpisodeBadgeLabel": self._info_tv_episode_badge_label(episode),
            "EpisodeBadgeSize": self._info_tv_episode_badge_size(episode),
            "IsWatched": watched_flag,
            "VideoResolutionLabel": (media_badges or {}).get("video", ""),
            "VideoBadgeSize": (media_badges or {}).get("video_size", ""),
            "AudioLabel": (media_badges or {}).get("audio", ""),
            "AudioBadgeSize": (media_badges or {}).get("audio_size", ""),
            "SubtitleLabel": (media_badges or {}).get("subtitle", ""),
            "SubtitleBadgeSize": (media_badges or {}).get("subtitle_size", ""),
            "DurationText": self._duration_text(duration), "Summary": summary,
            "SummarySourceR35": tmdb_src_r39,
            "Thumb": episode_thumb, "EpisodeThumb": episode_thumb,
            "VersionSelectedThumbV2325": episode_thumb,
        }
        # v2099: episode version state lives on the selected ListItem itself.
        # Kodi panel navigation can therefore change episodes without a Python
        # focus callback, while the action row still reflects the correct current
        # library resolution immediately.
        try:
            props.update(self._info_tv_version_props_v2099(rating_key, version_info_v2099 or {}))
        except Exception:
            pass
        # v2112: every playable episode gets the same media-version action as movies.
        if part_key:
            props["MediaVersionAvailable"] = "1"
        try:
            choice = dict((getattr(self, "_info_tv_media_choice_v2112", {}) or {}).get(str(rating_key or "")) or {})
            if choice and str(choice.get("owner_rating_key") or "") == str(rating_key or ""):
                resolution = str(choice.get("resolution") or "").strip().lower()
                if resolution:
                    props["VersionLabel"] = resolution
                    props["VersionIconLabel"] = resolution.upper()
                props["VersionSelectedRatingKey"] = str(choice.get("rating_key") or rating_key or "")
                props["VersionSelectedSectionId"] = str(choice.get("section_id") or "")
                props["VersionSelectedPartKey"] = str(choice.get("part_key") or part_key or "")
                props["VersionSelectedMatchReason"] = str(choice.get("match_reason") or "MEDIA_VARIANT")
                props["MediaVersionSelectedKey"] = str(choice.get("variant_key") or "%s|%s" % (props["VersionSelectedRatingKey"], props["VersionSelectedPartKey"]))
                props["MediaVersionVideo"] = str(choice.get("main_label") or "")
                props["MediaVersionAudio"] = str(choice.get("audio_label") or "")
                props["MediaVersionHDR"] = str(choice.get("hdr_type") or "")
                props["MediaVersionAudioStreamIndex"] = str(choice.get("audio_stream_index") if choice.get("audio_stream_index") is not None else "")
        except Exception:
            pass
        for k, v in props.items():
            try:
                li.setProperty("PlexKM.%s" % k, str(v or ""))
            except Exception:
                pass
        if url:
            try:
                li.setProperty("IsPlayable", "true")
            except Exception:
                pass
        li = self._overlay_gate_register_r56(li, art_key="thumb", ready_prop="")
        if thumb_fallback_r63:
            try:
                li.setProperty("PlexKM.ThumbFallbackR63", thumb_fallback_r63)
                li.setProperty("PlexKM.OverlayReadyR56", "1")
            except Exception:
                pass
        return li

    def _info_tv_logical_season_v2303(self, season):
        """Return the logical season number, folding PKM 4K aliases into it.

        PKM stores duplicate 4K season nodes in the 100-series namespace
        (101 -> season 1, 102 -> season 2, ...).  Those numbers identify a
        media version, not a different story season, and playback already has
        its own version selector.
        """
        try:
            value = int(float(season or 0))
        except Exception:
            return 0
        if 101 <= value <= 199:
            return value - 100
        return value if value >= 0 else 0

    def _info_tv_logical_season_count_v2303(self, cards=None):
        cards = list(cards if cards is not None else (getattr(self, "_info_tv_season_cards", []) or []))
        logical = set()
        for card in cards:
            try:
                logical.add(self._info_tv_logical_season_v2303(card.get("season")))
            except Exception:
                pass
        return len(logical)

    def _info_tv_visible_season_cards_v2303(self, selected_season=""):
        """Expose story seasons while preserving authoritative named editions.

        100-series nodes remain hidden media-version aliases.  v2347 keeps a
        Plex-provided descriptive title for other physical season nodes instead
        of rewriting it to a numeric label.  When such a named alternate exists
        (for example Plex title ``시즌 1 감독판`` on physical season 201), expose
        base season 1 as a selectable card too so users can move both directions.
        """
        cards = list(getattr(self, "_info_tv_season_cards", []) or [])

        # v2396: keep the agreed TV Info policy strict: the ordinary base
        # season 1 card is never shown as a folder, even when Plex also has a
        # named alternate edition such as a mobile/director cut.  Named
        # alternates keep their own physical season node and remain visible.
        visible_by_logical = {}
        order = []
        for raw_card in cards:
            try:
                card = dict(raw_card or {})
                physical = int(float(card.get("season") or 0))
                logical = self._info_tv_logical_season_v2303(physical)
            except Exception:
                continue
            # v2396: base season 1 and 100-series aliases fold to logical 1
            # and stay hidden. Named alternate editions on distinct physical
            # nodes (for example a Plex-titled mobile edition) remain visible.
            if logical == 1:
                continue
            if logical not in visible_by_logical:
                order.append(logical)
                visible_by_logical[logical] = card
            else:
                current = visible_by_logical[logical]
                try:
                    current_physical = int(float(current.get("season") or 0))
                except Exception:
                    current_physical = 0
                if physical == logical and current_physical != logical:
                    visible_by_logical[logical] = card

            chosen = visible_by_logical[logical]
            try:
                chosen_physical = int(float(chosen.get("season") or 0))
            except Exception:
                chosen_physical = 0
            chosen["logical_season"] = str(logical)
            if 101 <= chosen_physical <= 199:
                chosen["label"] = "스페셜" if logical == 0 else "시즌 %d" % logical
            else:
                chosen["label"] = str(chosen.get("label") or ("스페셜" if logical == 0 else "시즌 %d" % logical))

        visible = []
        for logical in order:
            card = visible_by_logical.get(logical)
            if not card:
                continue
            try:
                physical = int(float(card.get("season") or 0))
            except Exception:
                physical = 0
            card["logical_season"] = str(logical)
            if 101 <= physical <= 199:
                card["label"] = "스페셜" if logical == 0 else "시즌 %d" % logical
            else:
                card["label"] = str(card.get("label") or ("스페셜" if logical == 0 else "시즌 %d" % logical))
            visible.append(card)
        return visible

    def _info_tv_populate_season_control(self, selected_season=""):
        all_cards = list(getattr(self, "_info_tv_season_cards", []) or [])
        cards = self._info_tv_visible_season_cards_v2303(selected_season)
        # v2303: season folders represent logical story seasons only.
        # Base season 1 and 100-series media-version aliases are never separate folders.
        try:
            if cards:
                self._info_set_property_all("PlexKM.Info.HasSeasonCards", "1")
            else:
                self._info_clear_property_all("PlexKM.Info.HasSeasonCards")
            if self._info_tv_logical_season_count_v2303(all_cards) > 1:
                self._info_set_property_all("PlexKM.Info.HasSeasonTabs", "1")
            else:
                self._info_clear_property_all("PlexKM.Info.HasSeasonTabs")
        except Exception:
            pass
        try:
            ctrl = self.getControl(5711)
            ctrl.reset()
        except Exception:
            return
        selected_index = 0
        for idx, card in enumerate(cards):
            try:
                season = str(card.get("season") or "")
                label = card.get("label") or ("시즌 %s" % season if season and season != "0" else "스페셜")
                li = xbmcgui.ListItem(label=label)
                thumb = card.get("thumb") or ""
                season_thumb = card.get("season_thumb") or ""
                show_thumb = card.get("show_thumb") or ""
                final_art = thumb or show_thumb or season_thumb or ""
                try:
                    li.setArt({"thumb": final_art, "icon": final_art, "poster": final_art, "fanart": card.get("art") or ""})
                except Exception:
                    pass
                logical_season = str(card.get("logical_season") or self._info_tv_logical_season_v2303(season))
                selected_logical = str(self._info_tv_logical_season_v2303(selected_season))
                li.setProperty("PlexKM.Season", season)
                li.setProperty("PlexKM.LogicalSeason", logical_season)
                li.setProperty("PlexKM.IsSelected", "1" if logical_season == selected_logical else "")
                li.setProperty("PlexKM.SeasonThumb", season_thumb or final_art)
                li.setProperty("PlexKM.SeasonShowThumb", show_thumb)
                li.setProperty("PlexKM.SeasonFinalArt", final_art)
                li.setProperty("PlexKM.SeasonCount", str(card.get("episode_count") or ""))
                li.setProperty("PlexKM.SeasonViewedCount", str(card.get("viewed_count") or ""))
                ctrl.addItem(li)
                if str(card.get("logical_season") or self._info_tv_logical_season_v2303(season)) == str(self._info_tv_logical_season_v2303(selected_season)):
                    selected_index = idx
            except Exception:
                pass
        try:
            if ctrl.size() > 0:
                ctrl.selectItem(min(selected_index, ctrl.size() - 1))
        except Exception:
            pass
        _log("INLINE_INFO_TV_SEASONS_V2303 raw=%d logical=%d visible_story_seasons=%d selected=%d physical_season=%s media_alias_folders=0" % (len(all_cards), self._info_tv_logical_season_count_v2303(all_cards), len(cards), selected_index, selected_season or ""))

    def _info_tv_late_rows_commit_v2601(self):
        """GUI-thread commit for V2601 late TV rows. Never changes focus."""
        try:
            rec = getattr(self, "_info_tv_late_rows_pending_v2601", None)
            if not isinstance(rec, dict) or rec.get("state") not in ("ready", "failed"):
                return False
            rk = str(rec.get("rating_key") or "")
            active = str(self.getProperty("PlexKM.Info.RatingKey") or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey") or "")
            if not rk or active != rk:
                self._info_tv_late_rows_pending_v2601 = None
                _log("INFO_TV_LATE_ROWS_STALE_DROP_V2601 rating_key=%s active=%s" % (rk, active))
                return False
            li = getattr(self, "_inline_info_item", None)
            if li is None or str(li.getProperty("PlexKM.RatingKey") or "") != rk:
                return False
            if rec.get("state") == "failed" or int(rec.get("rows") or 0) <= 0:
                self._info_set_property_all("PlexKM.Info.TVEpisodeHint", "에피소드 정보를 불러올 수 없습니다")
                self._info_tv_late_rows_pending_v2601 = None
                _log("INFO_TV_LATE_ROWS_COMMIT_V2601 rating_key=%s result=failed spinner=0 focus_write=0" % rk)
                return False
            t0 = self._now_ms()
            rows_snapshot_v2608 = list(rec.get("row_snapshot_v2608") or [])
            if rows_snapshot_v2608:
                self._info_prepared_tv_payload_v2510 = {
                    "rating_key": rk,
                    "section_id": str(rec.get("section_id") or ""),
                    "show_key": str(rec.get("show_key") or ""),
                    "rows": list(rows_snapshot_v2608),
                    "season_cards": [],
                    "refresh_payload": {},
                }
                _log("INFO_TV_LATE_ROWS_SNAPSHOT_COMMIT_V2608 rating_key=%s rows=%d local_requery=0 network=0" % (
                    rk, len(rows_snapshot_v2608)
                ))
            ok = self._prepare_info_tv_rows(li, preserve_previous_surface=True, allow_network=False)
            self._info_tv_late_rows_pending_v2601 = None
            if ok is False:
                return False
            self._info_clear_property_all("PlexKM.Info.TVEpisodeHint")
            _log("INFO_TV_LATE_ROWS_COMMIT_V2608 rating_key=%s rows=%d bind_ms=%d spinner=0 focus_write=0 network=0 snapshot_reuse=1" % (
                rk, len(getattr(self, "_info_tv_rows", []) or []), self._now_ms() - t0
            ))
            return True
        except Exception:
            _log("INFO_TV_LATE_ROWS_COMMIT_FAILED_V2601 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_tv_prepare_visible_episode_local_thumbs_v1791(self, rows, max_wait_ms=700, allow_download=True):
        """Prepare decode-verified local stills for visible episode cards.

        v2356 fixes the remaining black-card case observed after v2355:
        old cache files could contain a truncated image with a valid header, or
        a PNG/WEBP/GIF body stored under a forced ``.jpg`` filename.  Kodi may
        reject those files even though v2355 counted them as ready.  Cache hits
        are now fully verified and stored/migrated with their real extension.
        """
        try:
            # TV Info has exactly five visible 360px episode-card slots.
            # Do not reuse the six-column library-wall geometry here: the sixth
            # download competes with the five images the user can actually see.
            visible_columns = min(5, max(0, len(rows or [])))
            selected = list(rows or [])[:visible_columns]
            if not selected:
                return {}, 0, 0
            profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/episode_thumb_cache_v1791")
            os.makedirs(profile, exist_ok=True)
            result = {}
            pending = []
            invalid_cache = 0
            format_migrated = 0
            metadata_thumb_present = 0
            metadata_thumb_absent = 0
            allowed_exts = ("jpg", "jpeg", "png", "webp", "gif")

            def _base_for(url):
                return os.path.join(profile, hashlib.sha1(str(url).encode("utf-8", "ignore")).hexdigest())

            def _canonical_ext(fmt):
                return "jpg" if str(fmt or "").lower() in ("jpg", "jpeg") else str(fmt or "").lower()

            def _cache_paths(url):
                base = _base_for(url)
                return [base + "." + ext for ext in allowed_exts]

            def _purge_variants(url, keep=""):
                for candidate_path in _cache_paths(url):
                    if keep and os.path.normcase(candidate_path) == os.path.normcase(keep):
                        continue
                    try:
                        if os.path.isfile(candidate_path):
                            os.remove(candidate_path)
                    except Exception:
                        pass

            def _existing_cache(url, rk, source):
                nonlocal invalid_cache, format_migrated
                for path in _cache_paths(url):
                    if not os.path.isfile(path):
                        continue
                    fmt = self._info_tv_cached_image_probe_v2356(path)
                    if not fmt:
                        try:
                            os.remove(path)
                            invalid_cache += 1
                            _log("INLINE_INFO_TV_THUMB_BAD_CACHE_PURGE_V2356 rating_key=%s source=%s file=%s reason=decode_or_truncated" % (
                                rk, source, os.path.basename(path)), xbmc.LOGWARNING)
                        except Exception:
                            pass
                        continue
                    wanted = _base_for(url) + "." + _canonical_ext(fmt)
                    current_ext = os.path.splitext(path)[1].lower().lstrip(".")
                    if current_ext == "jpeg":
                        current_ext = "jpg"
                    if current_ext != _canonical_ext(fmt):
                        try:
                            if os.path.exists(wanted) and os.path.normcase(wanted) != os.path.normcase(path):
                                os.remove(wanted)
                            os.replace(path, wanted)
                            path = wanted
                            format_migrated += 1
                            _log("INLINE_INFO_TV_THUMB_CACHE_FORMAT_MIGRATE_V2356 rating_key=%s source=%s format=%s file=%s" % (
                                rk, source, fmt, os.path.basename(path)))
                        except Exception:
                            # If rename fails, the verified source file is still
                            # usable for JPEG.  For non-JPEG mismatches do not feed
                            # a misleading extension to Kodi; force redownload.
                            if _canonical_ext(fmt) != current_ext:
                                try:
                                    os.remove(path)
                                    invalid_cache += 1
                                except Exception:
                                    pass
                                continue
                    _purge_variants(url, keep=path)
                    try:
                        _log("INLINE_INFO_TV_THUMB_CACHE_HIT_V2356 rating_key=%s source=%s format=%s decoder_ok=1" % (
                            rk, source, fmt))
                    except Exception:
                        pass
                    return path
                return ""

            for row in selected:
                r = tuple(row or ())
                rk = str((r[0] if r else "") or "")
                if not rk:
                    continue
                candidates = list(self._info_tv_episode_thumb_candidates_v2355(row) or [])
                has_metadata_thumb = any(
                    str(source or "").startswith("plex_metadata_thumb_")
                    for source, _url in candidates
                )
                if has_metadata_thumb:
                    metadata_thumb_present += 1
                else:
                    metadata_thumb_absent += 1
                if not candidates:
                    _log(
                        "INFO_TV_THUMB_UNAVAILABLE rating_key=%s classification=no_candidates metadata_thumb=0" % rk,
                        xbmc.LOGWARNING,
                    )
                    continue
                cached = ""
                for source, url in candidates:
                    cached = _existing_cache(url, rk, source)
                    if cached:
                        break
                if cached:
                    result[rk] = cached
                elif allow_download:
                    pending.append((rk, candidates))

            if pending and allow_download and int(max_wait_ms or 0) > 0:
                deadline = time.time() + max(0.01, int(max_wait_ms or 0) / 1000.0)
                ex = ThreadPoolExecutor(max_workers=min(2 if self._is_android_v2591() else 6, len(pending)))
                futures = []
                try:
                    def _download(job):
                        rk, candidates = job
                        for fallback_index, (source, url) in enumerate(list(candidates or [])[:5]):
                            # Another coalesced worker may have completed the same
                            # candidate while this job was queued.
                            cached_now = _existing_cache(url, rk, source)
                            if cached_now:
                                return rk, cached_now
                            tmp = ""
                            try:
                                data = pkm_artwork_scheduler.fetch_bytes(
                                    url, timeout=0.65, max_bytes=8 * 1024 * 1024,
                                    headers={"User-Agent": "Kodi-PKM/1.0"},
                                    priority=pkm_artwork_scheduler.PRIORITY_VISIBLE,
                                    tag="info_episode_thumb_v2356",
                                    cancel_check=self._closing_event_v1841.is_set,
                                    pause_when_playing=False,
                                )
                                fmt = self._info_tv_image_format_v2356(data)
                                if not fmt:
                                    try:
                                        _log("INLINE_INFO_TV_THUMB_RESPONSE_REJECT_V2356 rating_key=%s source=%s bytes=%d reason=full_decode_failed" % (
                                            rk, source, len(data or b"")), xbmc.LOGWARNING)
                                    except Exception:
                                        pass
                                    continue
                                dst = _base_for(url) + "." + _canonical_ext(fmt)
                                tmp = "%s.%s.tmp" % (dst, threading.get_ident())
                                with open(tmp, "wb") as f:
                                    f.write(data)
                                # Verify the actual on-disk object once as well;
                                # this catches short writes before atomic publish.
                                disk_fmt = self._info_tv_cached_image_probe_v2356(tmp)
                                if not disk_fmt:
                                    continue
                                os.replace(tmp, dst)
                                _purge_variants(url, keep=dst)
                                try:
                                    _log("INLINE_INFO_TV_THUMB_DOWNLOAD_OK_V2356 rating_key=%s source=%s format=%s bytes=%d fallback_index=%d" % (
                                        rk, source, disk_fmt, len(data or b""), fallback_index))
                                except Exception:
                                    pass
                                return rk, dst
                            except Exception as exc:
                                try:
                                    code = int(getattr(exc, "code", 0) or 0)
                                except Exception:
                                    code = 0
                                reason = str(exc or exc.__class__.__name__).replace(chr(10), " ")[:180]
                                try:
                                    _log(
                                        "INFO_TV_THUMB_FETCH_FAILED rating_key=%s source=%s http=%s fallback_index=%d reason=%s" % (
                                            rk, source, code or "-", fallback_index, reason
                                        ),
                                        xbmc.LOGWARNING,
                                    )
                                except Exception:
                                    pass
                                continue
                            finally:
                                try:
                                    if tmp and os.path.exists(tmp):
                                        os.remove(tmp)
                                except Exception:
                                    pass
                        try:
                            metadata_declared = any(
                                str(source or "").startswith("plex_metadata_thumb_")
                                for source, _url in (candidates or [])
                            )
                            classification = (
                                "plex_metadata_has_thumb_but_fetch_failed"
                                if metadata_declared
                                else "plex_metadata_has_no_thumb_and_canonical_failed"
                            )
                            try:
                                if not any(str(src or "") == "tmdb_still_r63" for src, _u in (candidates or [])):
                                    self._episode_thumb_miss_mark_r63(rk)
                            except Exception:
                                pass
                            _log(
                                "INFO_TV_THUMB_UNAVAILABLE rating_key=%s classification=%s candidates=%d" % (
                                    rk, classification, len(candidates or [])
                                ),
                                xbmc.LOGWARNING,
                            )
                        except Exception:
                            pass
                        return rk, ""

                    futures = [ex.submit(_download, j) for j in pending]
                    remaining = set(futures)
                    while remaining and time.time() < deadline:
                        done_now = [f for f in list(remaining) if f.done()]
                        if not done_now:
                            time.sleep(min(0.01, max(0.0, deadline - time.time())))
                            continue
                        for fut in done_now:
                            remaining.discard(fut)
                            try:
                                rk, dst = fut.result()
                                if dst and self._info_tv_cached_image_probe_v2356(dst):
                                    result[rk] = dst
                            except Exception:
                                pass
                    for fut in list(remaining):
                        if fut.done():
                            remaining.discard(fut)
                            try:
                                rk, dst = fut.result()
                                if dst and self._info_tv_cached_image_probe_v2356(dst):
                                    result[rk] = dst
                            except Exception:
                                pass
                    for fut in remaining:
                        try:
                            fut.cancel()
                        except Exception:
                            pass
                    _log("INLINE_INFO_TV_VISIBLE_THUMBS_BOUNDED_V2356 actual_rows=%d visible=%d ready=%d pending_after_deadline=%d bad_cache_purged=%d format_migrated=%d budget_ms=%d executor_wait=0" % (
                        len(rows or []), len(selected), len(result), len(remaining), invalid_cache, format_migrated, int(max_wait_ms or 0)
                    ))
                finally:
                    try:
                        ex.shutdown(wait=False, cancel_futures=True)
                    except TypeError:
                        ex.shutdown(wait=False)
                    except Exception:
                        pass
            elif pending and allow_download:
                _log("INLINE_INFO_TV_VISIBLE_THUMBS_BOUNDED_V2356 actual_rows=%d visible=%d ready=%d pending_after_deadline=%d bad_cache_purged=%d format_migrated=%d budget_ms=0 executor_wait=0" % (
                    len(rows or []), len(selected), len(result), len(pending), invalid_cache, format_migrated
                ))
            elif not allow_download:
                _log("INLINE_INFO_TV_VISIBLE_THUMBS_COMMIT_V2356 actual_rows=%d visible=%d ready=%d bad_cache_purged=%d format_migrated=%d mode=cached_only network_wait=0" % (
                    len(rows or []), len(selected), len(result), invalid_cache, format_migrated
                ))
            _log(
                "INFO_TV_THUMB_VISIBLE_PREP rows=%d visible=%d ready=%d metadata_thumb=%d metadata_missing=%d bad_cache=%d migrated=%d" % (
                    len(rows or []), len(selected), len(result),
                    metadata_thumb_present, metadata_thumb_absent,
                    invalid_cache, format_migrated,
                )
            )
            _log("INLINE_INFO_TV_VISIBLE_THUMBS_LOCAL_V2356 actual_rows=%d visible=%d ready=%d bad_cache_purged=%d format_migrated=%d fixed_count=0" % (
                len(rows or []), len(selected), len(result), invalid_cache, format_migrated))
            return result, len(selected), len(result)
        except Exception:
            _log("INLINE_INFO_TV_VISIBLE_THUMBS_LOCAL_FAILED_V2356 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return {}, 0, 0

    def _info_tv_prestage_scene_assets_v2160(self, li, max_wait_ms=700):
        """Warm slow TV scene assets while the previous Info is still visible.

        This helper is intentionally UI-free: it never changes Info properties,
        never resets 5711/5712/5713, and never arms EntrySwap/Cover.  It only
        ensures episode rows exist in the local DB and gives the first visible
        episode stills one bounded opportunity to reach the persistent cache.
        The later atomic commit can therefore build the inactive TV bank without
        a network wait under the transition cover.
        """
        started = self._now_ms()
        rk = li.getProperty("PlexKM.RatingKey") or ""
        plex_type = (li.getProperty("PlexKM.Type") or "").lower()
        kodi_type = (li.getProperty("PlexKM.KodiType") or "").lower()
        is_tv = plex_type in ("show", "season", "episode", "tv") or kodi_type in ("tvshow", "episode")
        if not is_tv:
            return False
        show_key = rk if plex_type == "show" else (li.getProperty("PlexKM.GrandparentRatingKey") or "")
        section_id = li.getProperty("PlexKM.SectionId") or ""
        if not show_key or not section_id:
            return False
        rows = []
        source = "local"
        try:
            rows = list(_ensure_core().query_episodes_for_show(section_id, show_key) or [])
        except Exception:
            rows = []
        if not rows:
            try:
                source = "plex_fallback"
                core_mod = _ensure_core()
                items = core_mod.fetch_show_episodes(show_key, section_id, upsert=True, timeout=1.5) or []
                rows = [core_mod.row_from_item_dict(x) for x in items if x]
            except Exception:
                rows = []
                _log("INFO_TV_SCENE_PRESTAGE_ROWS_FAILED_V2160 rating_key=%s show=%s section=%s err=%s" % (
                    rk, show_key, section_id, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        if not rows:
            self._info_tv_scene_prestage_v2160 = {
                "rating_key": rk, "show_key": show_key, "rows": 0,
                "selected_season": "", "thumb_ready": 0, "visible": 0,
                "ts": self._now_ms(),
            }
            _log("INFO_TV_SCENE_PRESTAGE_V2160 rating_key=%s show=%s rows=0 source=%s previous_info_visible=1 cover=0 elapsed_ms=%d" % (
                rk, show_key, source, self._now_ms() - started
            ), xbmc.LOGWARNING)
            return False
        selected_season = str(li.getProperty("PlexKM.Season") or "")
        if not selected_season:
            try:
                for row in rows:
                    rr = tuple(row or ())
                    season = str((rr[19] if len(rr) > 19 else "") or "")
                    if season:
                        selected_season = season
                        break
            except Exception:
                selected_season = ""
        first_rows = []
        for row in rows:
            try:
                rr = tuple(row or ())
                season = str((rr[19] if len(rr) > 19 else "") or "")
            except Exception:
                season = ""
            if not selected_season or season == selected_season:
                first_rows.append(row)
        thumb_map, visible, ready = self._info_tv_prepare_visible_episode_local_thumbs_v1791(
            first_rows, max_wait_ms=max_wait_ms, allow_download=True
        )
        self._info_tv_scene_prestage_v2160 = {
            "rating_key": rk, "show_key": show_key, "rows": len(rows),
            "selected_season": selected_season, "thumb_ready": ready,
            "visible": visible, "ts": self._now_ms(),
        }
        _log("INFO_TV_SCENE_PRESTAGE_V2160 rating_key=%s show=%s rows=%d season=%s source=%s visible=%d ready=%d budget_ms=%d previous_info_visible=1 cover=0 elapsed_ms=%d" % (
            rk, show_key, len(rows), selected_season, source, visible, ready,
            int(max_wait_ms or 0), self._now_ms() - started
        ))
        return True

    # v2399: TV episode rail sort is a lightweight, global user preference.
    # It is persisted outside settings.xml so no public setting surface/version
    # migration is required.  The rail remains Kodi-native; only ListItem order
    # changes and all existing LEFT/DOWN focus rules stay in XML.
    def _info_tv_episode_sort_state_v2399(self):
        try:
            cached = getattr(self, "_info_tv_episode_sort_desc_v2399", None)
            if cached in (True, False):
                desc = bool(cached)
            else:
                desc = False
                path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/tv_episode_sort_v2399.json")
                try:
                    if os.path.exists(path):
                        with open(path, "r", encoding="utf-8") as fh:
                            payload = json.load(fh) or {}
                        desc = str(payload.get("order") or "asc").strip().lower() == "desc"
                except Exception:
                    desc = False
                self._info_tv_episode_sort_desc_v2399 = bool(desc)
            self._info_set_property_all("PlexKM.Info.TVEpisodeSortDesc", "1" if desc else "")
            self._info_set_property_all("PlexKM.Info.TVEpisodeSortGlyph", "▼" if desc else "▲")
            return bool(desc)
        except Exception:
            return False

    def _info_tv_save_episode_sort_v2399(self, desc):
        try:
            path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/tv_episode_sort_v2399.json")
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent, exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"order": "desc" if desc else "asc"}, fh, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
            return True
        except Exception:
            _log("INFO_TV_EPISODE_SORT_SAVE_FAILED_V2399 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_tv_sort_episode_rows_v2399(self, rows):
        desc = self._info_tv_episode_sort_state_v2399()
        def _key(row):
            try:
                rr = tuple(row or ())
                ep = _safe_int(rr[20] if len(rr) > 20 else 0, 0)
                rk = str(rr[0] if rr else "")
                return (ep, rk)
            except Exception:
                return (0, "")
        try:
            ordered = sorted(list(rows or []), key=_key, reverse=bool(desc))
        except Exception:
            ordered = list(rows or [])
        return ordered

    def _info_tv_initial_episode_target(self, rows, plex_type="", explicit_rating_key="", selected_season=""):
        """Choose the episode that TV Info should initially focus.

        Active resume is authoritative for the episode rail. If more than one
        episode is in progress, the later episode wins. When Info was opened
        from a concrete episode, candidates from that same physical season are
        preferred so alternate media-season folders are not crossed needlessly.
        If there is no active resume, a concrete episode stays concrete; show or
        season entry falls back to first unwatched, then first episode.
        """
        try:
            source_rows = list(rows or [])
            if not source_rows:
                return "", str(selected_season or ""), "no_rows"

            explicit = str(explicit_rating_key or "").strip()
            ptype = str(plex_type or "").strip().lower()
            wanted_season = str(selected_season or "")
            explicit_row = None

            if ptype == "episode" and explicit:
                for row in source_rows:
                    rr = tuple(row or ())
                    if str((rr[0] if rr else "") or "") == explicit:
                        explicit_row = rr
                        break
                if explicit_row is not None:
                    explicit_season = str((explicit_row[19] if len(explicit_row) > 19 else "") or "")
                    if explicit_season:
                        wanted_season = explicit_season

            scope = source_rows
            if ptype == "season" and wanted_season:
                same_season = []
                for row in source_rows:
                    rr = tuple(row or ())
                    if str((rr[19] if len(rr) > 19 else "") or "") == wanted_season:
                        same_season.append(row)
                if same_season:
                    scope = same_season

            try:
                local_states = getattr(_ensure_core(), "_read_local_resume_states", lambda: {})() or {}
            except Exception:
                local_states = {}

            def _resume_record(row):
                rr = tuple(row or ())
                if len(rr) < 21:
                    return None
                if _safe_int(rr[16] if len(rr) > 16 else 0, 0) > 0:
                    return None

                rk = str((rr[0] if rr else "") or "")
                season_text = str((rr[19] if len(rr) > 19 else "") or "")
                season_num = _safe_int(season_text, 0)
                episode_num = _safe_int(rr[20] if len(rr) > 20 else 0, 0)
                off = _safe_int(rr[23] if len(rr) > 23 else 0, 0)
                resume_duration = _safe_int(rr[24] if len(rr) > 24 else 0, 0)
                stamp = max(
                    _safe_int(rr[25] if len(rr) > 25 else 0, 0),
                    _safe_int(rr[17] if len(rr) > 17 else 0, 0),
                )

                if off <= 0 and rk:
                    state = local_states.get(rk) or {}
                    off = _safe_int(state.get("time") or 0, 0)
                    resume_duration = _safe_int(
                        state.get("duration") or resume_duration,
                        resume_duration,
                    )
                    stamp = max(stamp, _safe_int(state.get("updated_at") or 0, 0))

                duration = _safe_int(rr[9] if len(rr) > 9 else 0, 0)
                off_ms, dur_ms, pct = getattr(_ensure_core(), "_pkm_progress_pair")(
                    off, duration, resume_duration
                )
                off_ms = max(0, _safe_int(off_ms, 0))
                dur_ms = max(0, _safe_int(dur_ms, 0))
                pct = int(max(0, min(100, _safe_int(pct, 0))))

                if off_ms < 30000 or dur_ms <= 0 or not (0 < pct < 90):  # R31 (was 60 s)
                    return None

                story_season = season_num - 100 if 101 <= season_num <= 199 else season_num
                return {
                    "row": rr,
                    "rating_key": rk,
                    "season": season_text,
                    "season_num": season_num,
                    "story_season": story_season,
                    "episode": episode_num,
                    "pct": pct,
                    "stamp": stamp,
                    "offset_ms": off_ms,
                }

            resume_candidates = []
            for row in scope:
                rec = _resume_record(row)
                if rec:
                    resume_candidates.append(rec)

            # For a concrete episode entry, stay inside the same physical season
            # whenever that season has an active resume. This handles parallel
            # base/4K season folders without choosing the wrong media edition.
            if explicit_row is not None and wanted_season and resume_candidates:
                same_physical_season = [
                    rec for rec in resume_candidates
                    if str(rec.get("season") or "") == wanted_season
                ]
                if same_physical_season:
                    resume_candidates = same_physical_season

            if resume_candidates:
                resume_candidates.sort(
                    key=lambda rec: (
                        _safe_int(rec.get("story_season"), 0),
                        _safe_int(rec.get("episode"), 0),
                        _safe_int(rec.get("stamp"), 0),
                        _safe_int(rec.get("offset_ms"), 0),
                        str(rec.get("rating_key") or ""),
                    ),
                    reverse=True,
                )
                chosen = resume_candidates[0]
                _log(
                    "INFO_TV_ACTIVE_RESUME_TARGET explicit=%s target=%s season=%s episode=%s pct=%s candidates=%d policy=higher_episode" % (
                        explicit,
                        str(chosen.get("rating_key") or ""),
                        str(chosen.get("season") or wanted_season),
                        _safe_int(chosen.get("episode"), 0),
                        _safe_int(chosen.get("pct"), 0),
                        len(resume_candidates),
                    )
                )
                return (
                    str(chosen.get("rating_key") or ""),
                    str(chosen.get("season") or wanted_season),
                    "active_resume",
                )

            if ptype == "episode" and explicit:
                if explicit_row is not None:
                    return (
                        explicit,
                        str((explicit_row[19] if len(explicit_row) > 19 else wanted_season) or wanted_season),
                        "explicit_episode_no_active_resume",
                    )
                return explicit, wanted_season, "explicit_episode_missing_row"

            def _row_key(row):
                rr = tuple(row or ())
                season = _safe_int(rr[19] if len(rr) > 19 else 0, 0)
                episode = _safe_int(rr[20] if len(rr) > 20 else 0, 0)
                alias_rank = 1 if 101 <= season <= 199 else 0
                zero_rank = 1 if season == 0 else 0
                rk = str((rr[0] if rr else "") or "")
                return (alias_rank, zero_rank, season, episode, rk)

            ordered = sorted(scope, key=_row_key)
            for row in ordered:
                rr = tuple(row or ())
                if _safe_int(rr[16] if len(rr) > 16 else 0, 0) <= 0:
                    return (
                        str((rr[0] if rr else "") or ""),
                        str((rr[19] if len(rr) > 19 else wanted_season) or wanted_season),
                        "first_unwatched",
                    )

            rr = tuple(ordered[0] or ())
            return (
                str((rr[0] if rr else "") or ""),
                str((rr[19] if len(rr) > 19 else wanted_season) or wanted_season),
                "all_watched_first_episode",
            )
        except Exception:
            _log(
                "INFO_TV_INITIAL_TARGET_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "),
                xbmc.LOGWARNING,
            )
            return str(explicit_rating_key or ""), str(selected_season or ""), "fallback"

    def _info_tv_toggle_episode_sort_v2399(self, reason=""):
        try:
            current = self._info_tv_episode_sort_state_v2399()
            new_desc = not bool(current)
            self._info_tv_episode_sort_desc_v2399 = bool(new_desc)
            self._info_set_property_all("PlexKM.Info.TVEpisodeSortDesc", "1" if new_desc else "")
            self._info_set_property_all("PlexKM.Info.TVEpisodeSortGlyph", "▼" if new_desc else "▲")
            self._info_tv_save_episode_sort_v2399(new_desc)

            active_id = self._info_tv_active_episode_control_id()
            # v2404: repeated header clicks must keep the same logical episode
            # anchor. Only when the user has actually re-entered the native rail
            # since the last sort do we adopt Kodi's current selected ListItem.
            focus_rk = str(getattr(self, "_info_tv_sort_anchor_rk_v2404", "") or "")
            _rail_was_used_v2404 = bool(getattr(self, "_info_tv_sort_user_rail_focus_v2404", False))
            if _rail_was_used_v2404 or not focus_rk:
                try:
                    selected = self.getControl(active_id).getSelectedItem()
                    _native_rk_v2404 = selected.getProperty("PlexKM.RatingKey") if selected else ""
                    if _native_rk_v2404:
                        focus_rk = str(_native_rk_v2404)
                except Exception:
                    pass
            if not focus_rk:
                try:
                    focus_rk = str(
                        xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey")
                        or self.getProperty("PlexKM.Info.RatingKey")
                        or ""
                    )
                except Exception:
                    focus_rk = ""
            self._info_tv_sort_anchor_rk_v2404 = focus_rk
            self._info_tv_sort_user_rail_focus_v2404 = False
            season = str(getattr(self, "_info_tv_selected_season", "") or "")
            target_id = self._info_tv_inactive_episode_control_id()
            prepared = self._info_tv_populate_episode_control(
                season=season,
                focus_rating_key=focus_rk,
                target_control_id=target_id,
                allow_download=True,
            )
            if prepared:
                self._info_tv_publish_episode_buffer(prepared, reason="sort_toggle_v2399")
            # v2400: keep the compact sort toggle focused after the A/B rail flip so
            # Enter can be pressed repeatedly without the button appearing to lose selection.
            try:
                self.setFocusId(5708)
            except Exception:
                pass
            _log("INFO_TV_EPISODE_SORT_TOGGLE_V2399 order=%s season=%s focus=%s target=%s reason=%s nav_chain_unchanged=1" % (
                "desc" if new_desc else "asc", season or "", focus_rk or "", prepared or "", reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_EPISODE_SORT_TOGGLE_FAILED_V2399 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_populate_episode_control(self, season="", focus_rating_key="", target_control_id=None, allow_download=True):
        try:
            target_id = int(target_control_id or self._info_tv_inactive_episode_control_id())
            if target_id not in (5712, 5713):
                target_id = 5713
            ctrl = self.getControl(target_id)
            ctrl.reset()
        except Exception:
            return None
        target_season = str(season or "")
        rows = []
        for row in getattr(self, "_info_tv_rows", []) or []:
            try:
                r_season = str((tuple(row)[19] if len(tuple(row)) > 19 else "") or "")
            except Exception:
                r_season = ""
            if not target_season or r_season == target_season:
                rows.append(row)
        # v2399: sort the complete real episode rail before any thumbnail/version
        # preparation so A/B buffers, selection index and rendered order agree.
        rows = self._info_tv_sort_episode_rows_v2399(rows)
        # v2401: when an existing episode must remain selected (notably after an
        # ASC/DESC flip), prefetch the viewport that Kodi will actually reveal
        # around that selected item.  The old first-N prefetch left the newly
        # revealed cards blank until LEFT/RIGHT moved focus over them.
        _thumb_prepare_rows_v2401 = list(rows or [])
        _selected_hint_v2401 = 0
        if focus_rating_key and rows:
            try:
                for _idx_v2401, _row_v2401 in enumerate(rows):
                    _rr_v2401 = tuple(_row_v2401 or ())
                    if str((_rr_v2401[0] if _rr_v2401 else "") or "") == str(focus_rating_key):
                        _selected_hint_v2401 = _idx_v2401
                        break
                # TV_INFO_EPISODE_FIVE_CARD_CENTER_R20B:
                # The active TV Info rail is five 360px item slots wide in the
                # 1920px layout. Prewarm the five-card window centered on the
                # selected Continue-Watching target (two before, two after).
                _visible_cols_v2401 = min(len(rows), 5)
                _anchor_before_v18 = 2
                _start_v2401 = max(0, _selected_hint_v2401 - _anchor_before_v18)
                _focus_slice_v2401 = list(rows[_start_v2401:_start_v2401 + _visible_cols_v2401])
                _rest_v2401 = list(rows[:_start_v2401]) + list(rows[_start_v2401 + _visible_cols_v2401:])
                _thumb_prepare_rows_v2401 = _focus_slice_v2401 + _rest_v2401
                _log("INLINE_INFO_TV_THUMB_VIEWPORT_R20B focus=%s selected=%d start=%d visible=%d rows=%d visual_slot=%d tail_blank_allowed=1" % (
                    focus_rating_key or "", _selected_hint_v2401, _start_v2401,
                    _visible_cols_v2401, len(rows), min(3, _selected_hint_v2401 + 1)
                ))
            except Exception:
                _thumb_prepare_rows_v2401 = list(rows or [])
        # v1791: prepare local files for exactly the real visible cards.  The
        # inactive A/B bank is then populated entirely and flipped once.
        _bank_prepare_started = time.perf_counter()
        # v2160: a same-surface TV child pre-stages slow still downloads while
        # the previous Info is still visible.  The final inactive-bank build must
        # never start a second network wait under EntrySwap/Cover; consume only
        # files that are already local from that pre-stage.
        _prestage_v2160 = getattr(self, "_info_tv_scene_prestage_v2160", {}) or {}
        _target_rk_v2160 = ""
        try:
            _target_rk_v2160 = (
                xbmcgui.Window(10000).getProperty("PlexKM.Info.EntryTargetRatingKeyV2123")
                or (getattr(self, "_inline_info_item", None).getProperty("PlexKM.RatingKey") if getattr(self, "_inline_info_item", None) is not None else "")
                or ""
            )
        except Exception:
            _target_rk_v2160 = ""
        _use_prestage_v2160 = bool(
            _target_rk_v2160
            and str(_prestage_v2160.get("rating_key") or "") == str(_target_rk_v2160)
            and (self._now_ms() - int(_prestage_v2160.get("ts") or 0)) < 15000
        )
        _episode_thumb_download_v2380r1 = bool(allow_download and (not _use_prestage_v2160))
        _local_thumb_map_v1791, _visible_count_v1791, _local_ready_v1791 = self._info_tv_prepare_visible_episode_local_thumbs_v1791(
            _thumb_prepare_rows_v2401,
            max_wait_ms=(700 if _episode_thumb_download_v2380r1 else 0),
            allow_download=_episode_thumb_download_v2380r1,
        )
        if not allow_download:
            _log("INLINE_INFO_TV_EPISODE_THUMB_NETWORK_SKIP_V2380R1 target=%s season=%s reason=network_disabled" % (
                target_id, target_season
            ))
        if _use_prestage_v2160:
            _log("INLINE_INFO_TV_EPISODE_BANK_COMMIT_V2160 target=%s rating_key=%s mode=prestaged_cached_only network_wait=0 visible=%d local_ready=%d" % (
                target_id, _target_rk_v2160, _visible_count_v1791, _local_ready_v1791
            ))
            # Scene pre-stage is a one-shot contract. Normal later season changes
            # keep the established v1791 behavior.
            try:
                self._info_tv_scene_prestage_v2160 = {}
            except Exception:
                pass
        _log("INLINE_INFO_TV_EPISODE_BANK_PREPARE_V1791 phase=begin target=%s season=%s rows=%d visible=%d local_ready=%d fixed_count=0" % (
            target_id, target_season, len(rows), _visible_count_v1791, _local_ready_v1791))
        # v2428: never block first paint by resolving playback versions for every
        # episode in the season. The selected episode is already prewarmed after
        # the A/B rail is published by _schedule_info_tv_media_version_prewarm_v2112;
        # this preserves the popup while removing the synchronous whole-rail scan.
        _tv_version_map_v2099 = {}
        _log("INFO_TV_VERSION_GROUPS_DEFER_V2428 target=%s season=%s rows=%d policy=selected_episode_postpublish" % (
            target_id, target_season, len(rows)
        ))
        selected_index = 0
        _episode_items_v2510 = []
        _episode_build_t0_v2510 = self._now_ms()
        for idx, row in enumerate(rows):
            try:
                rk_v1791 = str((tuple(row)[0] if tuple(row) else "") or "")
                li = self._info_tv_row_to_li(row, thumb_override=_local_thumb_map_v1791.get(rk_v1791, ""), version_info_v2099=_tv_version_map_v2099.get(rk_v1791) or {})
                if li is not None:
                    _episode_items_v2510.append(li)
                    if focus_rating_key and li.getProperty("PlexKM.RatingKey") == str(focus_rating_key):
                        selected_index = len(_episode_items_v2510) - 1
            except Exception:
                pass
        # TV_INFO_EPISODE_FIVE_CARD_CENTER_R20B:
        # The native PANEL exposes five episode slots. Entry centering needs
        # target+2. Symmetric first-RIGHT centering needs target+3 when a real
        # next episode exists. Append only the missing invisible runway items
        # (maximum two).
        _real_episode_count_r20a = len(_episode_items_v2510)
        _tail_pad_count_r20b = 0
        if _real_episode_count_r20a >= 5 and selected_index >= 2:
            try:
                _real_last_r20b = _real_episode_count_r20a - 1
                _needed_last_r20b = int(selected_index) + (
                    2 if int(selected_index) >= _real_last_r20b else 3
                )
                _tail_pad_count_r20b = max(
                    0, min(2, _needed_last_r20b - _real_last_r20b)
                )
                for _pad_no_r20b in range(_tail_pad_count_r20b):
                    _pad_li_r20b = xbmcgui.ListItem(label="")
                    _pad_li_r20b.setProperty("PlexKM.TVEpisodeTailPadR20A", "1")
                    _pad_li_r20b.setProperty("PlexKM.TVEpisodeTailPadR20B", "1")
                    _pad_li_r20b.setProperty("PlexKM.RatingKey", "")
                    _episode_items_v2510.append(_pad_li_r20b)
            except Exception:
                _tail_pad_count_r20b = 0
        _tail_pad_r20a = bool(_tail_pad_count_r20b)

        if _episode_items_v2510:
            try:
                ctrl.addItems(_episode_items_v2510)
                _episode_additems_v2510 = 1
            except Exception:
                _episode_additems_v2510 = 0
                for _episode_li_v2510 in _episode_items_v2510:
                    try:
                        ctrl.addItem(_episode_li_v2510)
                    except Exception:
                        pass
            _log("INFO_TV_EPISODE_BATCH_BIND_V2510 target=%s season=%s items=%d build_bind_ms=%d additems=%d" % (
                target_id, target_season, len(_episode_items_v2510),
                self._now_ms() - _episode_build_t0_v2510, _episode_additems_v2510
            ))
        # TV_INFO_EPISODE_FIVE_CARD_CENTER_R20B:
        # Keep episode order and logical selected index unchanged. The skin is
        # a native five-card PANEL. Entry target is centered in slot 3.
        # The first LEFT/RIGHT recenters the newly focused neighbor once; after
        # that Kodi owns normal focus movement inside the five-card window.
        selection_index_v2406 = selected_index
        if focus_rating_key:
            try:
                self._info_tv_sort_anchor_rk_v2404 = str(focus_rating_key)
                self._info_tv_sort_user_rail_focus_v2404 = False
            except Exception:
                pass
        try:
            if ctrl.size() > 0:
                _target_pos_r20a = min(selection_index_v2406, max(0, _real_episode_count_r20a - 1))
                _initial_anchor_r20a = bool(_real_episode_count_r20a >= 5 and _target_pos_r20a >= 2)
                if _initial_anchor_r20a:
                    # Actual viewport is FIVE items. Prime target+2 to the last
                    # visible slot, then select target: same offset => target slot 3.
                    # R20A used target+1, which yields slot 4 with five items/page.
                    _prime_pos_r20b = _target_pos_r20a + 2
                    if _prime_pos_r20b < ctrl.size():
                        ctrl.selectItem(_prime_pos_r20b)
                    ctrl.selectItem(_target_pos_r20a)
                else:
                    ctrl.selectItem(_target_pos_r20a)

                _state_map_r20a = getattr(self, "_info_tv_episode_nav_state_r20a", {}) or {}
                _state_map_r20a[int(target_id)] = {
                    "real_count": int(_real_episode_count_r20a),
                    "anchor_index": int(_target_pos_r20a),
                    "initial_armed": bool(_initial_anchor_r20a),
                    "tail_pad": bool(_tail_pad_r20a),
                    "tail_pad_count": int(_tail_pad_count_r20b),
                    "window_start": max(0, int(_target_pos_r20a) - 2) if _initial_anchor_r20a else 0,
                }
                self._info_tv_episode_nav_state_r20a = _state_map_r20a
                _log("INFO_TV_EPISODE_INITIAL_ANCHOR_R20B control=%d rows=%d selected=%d visual_slot=%d tail_pad=%d window_start=%d viewport=5 prime_plus=2 policy=five_visible_center" % (
                    int(target_id), int(_real_episode_count_r20a), int(_target_pos_r20a),
                    min(3, int(_target_pos_r20a) + 1), int(_tail_pad_count_r20b),
                    max(0, int(_target_pos_r20a) - 2) if _initial_anchor_r20a else 0
                ))
        except Exception:
            pass
        _log("INFO_TV_EPISODE_GEOMETRY_R20B anchor=%s selected=%d logical_anchor=%d rows=%d target=%s width=100pct item=360 panel=1 viewport_cards=5 visual_slot=%d prime_plus=2 order_only=1" % (
            focus_rating_key or "", selection_index_v2406, selected_index, len(rows), target_id,
            min(3, int(selection_index_v2406) + 1)
        ))
        try:
            self._info_set_property_all("PlexKM.Info.TVEpisodeHint", "확인/엔터: 선택한 에피소드 재생 · 좌/우: Kodi 패널 이동 · 좌측 끝: 사이드메뉴")
        except Exception:
            pass
        _bank_prepare_ms = int((time.perf_counter() - _bank_prepare_started) * 1000.0) if '_bank_prepare_started' in locals() else 0
        _log("INLINE_INFO_TV_EPISODE_BANK_PREPARE_V1791 phase=ready target=%s season=%s rows=%d selected=%d logical_anchor=%d visible=%d local_ready=%d total_ms=%d fixed_count=0" % (
            target_id, target_season, len(rows), selection_index_v2406, selected_index, _visible_count_v1791, _local_ready_v1791, _bank_prepare_ms))
        _log("INLINE_INFO_TV_EPISODES target=%s season=%s rows=%d selected=%d logical_anchor=%d focus=%s native_edge_v2405=1 geometry_v2406=slot570_100pct" % (target_id, target_season, len(rows), selection_index_v2406, selected_index, focus_rating_key or ""))
        return target_id

    def _info_tv_select_focused_season(self, reason=""):
        """Select one visible story-season folder without exposing an idle/dead click.

        v2346 rules:
        * clicking the season that already owns the visible episode rail is an
          instant focus handoff to that rail; never rebuild the same 8/20/etc rows;
        * a real season change keeps the completed current rail visible while the
          inactive A/B episode bank is prepared;
        * the shared global-busy broker supplies delayed spinner feedback for a
          slow switch, so there is no blank/half-built season page;
        * a preparation exception keeps the previous completed rail instead of
          clearing TVRowsReady and exposing an empty surface.
        """
        try:
            item = self.getControl(5711).getSelectedItem()
            season = str(item.getProperty("PlexKM.Season") or "")
        except Exception:
            season = ""
        if not season:
            return

        rating_key = ""
        try:
            rating_key = (
                self.getProperty("PlexKM.Info.RatingKey")
                or xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey")
                or ""
            )
        except Exception:
            pass

        previous_season = str(getattr(self, "_info_tv_selected_season", "") or "")
        try:
            active_episode_id = int(self._info_tv_active_episode_control_id() or 0)
        except Exception:
            active_episode_id = 0
        try:
            active_episode_size = int(self.getControl(active_episode_id).size()) if active_episode_id in (5712, 5713) else 0
        except Exception:
            active_episode_size = 0

        # v2346: this is the exact case from the 2026-08-24 trace.  Season 201
        # was already the visible rail, but clicking its folder rebuilt the same
        # rows for 1662 ms before focus moved.  Treat that as navigation, not a
        # refresh: move focus immediately to the already-complete active bank.
        if season == previous_season and active_episode_size > 0:
            focused = self._info_tv_focus_panel(
                active_episode_id, reason="season_select_same_fast_v2346"
            )
            _log(
                "INLINE_INFO_TV_SEASON_SELECT_FAST_V2346 "
                "reason=%s season=%s active=%s rows=%d rebuild=0 busy=0 focus=%d" % (
                    reason or "", season, active_episode_id, active_episode_size,
                    1 if focused else 0,
                )
            )
            return

        busy_token_v2346 = ""
        committed_v2346 = False
        try:
            busy_token_v2346 = self._scene_busy_arm_v2482(
                reason="tv_season_select:%s:%s" % (rating_key or "unknown", season),
                scope="info_tv_season_select", owner=season,
                replace_scope=True, threshold_ms=1000,
            )
            _log(
                "INLINE_INFO_TV_SEASON_PREPARE_BEGIN_V2346 "
                "reason=%s from=%s to=%s active=%s rows=%d busy_token=%s "
                "source_surface_held=1 blank=0" % (
                    reason or "", previous_season, season, active_episode_id,
                    active_episode_size, busy_token_v2346 or "",
                )
            )
        except Exception:
            busy_token_v2346 = ""

        try:
            # Prepare only the inactive episode bank.  Do not change the visible
            # season selection or active rail until the target rows are complete.
            self._info_tv_defer_focus = True
            _episode_buffer_id = self._info_tv_populate_episode_control(
                season=season, focus_rating_key=""
            )
            try:
                ep_size = int(
                    self.getControl(
                        _episode_buffer_id or self._info_tv_inactive_episode_control_id()
                    ).size()
                )
            except Exception:
                ep_size = 0

            if ep_size > 0:
                # Atomic commit boundary: the target bank is complete.  Update the
                # selected season card, flip the A/B rail once, then transfer focus.
                self._info_tv_selected_season = season
                self._info_tv_populate_season_control(selected_season=season)
                self._info_tv_set_mode("episodes", back_mode="")
                try:
                    self._info_set_property_all("PlexKM.Info.TVSectionTitle", "에피소드")
                except Exception:
                    pass
                self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                self._info_tv_defer_focus = False
                _published_ep_id = self._info_tv_publish_episode_buffer(
                    _episode_buffer_id or self._info_tv_inactive_episode_control_id(),
                    reason="season_select_atomic_publish_v2346",
                )
                self._info_tv_focus_panel(
                    _published_ep_id, reason="season_select_atomic_publish_v2346"
                )
                committed_v2346 = True
                _log(
                    "INLINE_INFO_TV_SEASON_SELECT_COMMIT_V2346 "
                    "reason=%s from=%s to=%s target=%s rows=%d blank=0" % (
                        reason or "", previous_season, season, _published_ep_id, ep_size
                    )
                )
            else:
                # A real empty season is a valid completed target state.  Commit
                # the selected folder and the explicit empty message together.
                self._info_tv_selected_season = season
                self._info_tv_populate_season_control(selected_season=season)
                self._info_tv_set_mode("episodes", back_mode="")
                self._info_tv_defer_focus = False
                self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                self._info_set_property_all("PlexKM.Info.TVRowsEmpty", "1")
                self._info_set_property_all(
                    "PlexKM.Info.TVEpisodeHint", "선택한 시즌의 에피소드 정보가 없습니다"
                )
                try:
                    self.setFocusId(5711)
                except Exception:
                    pass
                committed_v2346 = True
                _log(
                    "INLINE_INFO_TV_SEASON_SELECT_EMPTY_V2346 "
                    "reason=%s season=%s blank=0 explicit_empty=1" % (
                        reason or "", season
                    )
                )

            _log(
                "INLINE_INFO_TV_SEASON_SELECT reason=%s season=%s rows=%d" % (
                    reason or "", season, ep_size
                )
            )
        except Exception:
            # Preparation failed before commit: preserve the previous visible bank.
            # Never clear TVRowsReady here; that would create the blank rail the
            # global PREPARE -> READY -> COMMIT policy forbids.
            try:
                self._info_tv_defer_focus = False
                self._info_tv_selected_season = previous_season
                self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                if active_episode_size > 0:
                    self._info_set_property_all("PlexKM.Info.TVRowsReady", "1")
                self._info_tv_populate_season_control(selected_season=previous_season)
            except Exception:
                pass
            _log(
                "INLINE_INFO_TV_SEASON_SELECT_FAILED_V2346 "
                "reason=%s from=%s to=%s previous_surface_retained=1 committed=%d\n%s" % (
                    reason or "", previous_season, season,
                    1 if committed_v2346 else 0, traceback.format_exc()
                ),
                xbmc.LOGWARNING,
            )
        finally:
            try:
                self._info_tv_defer_focus = False
            except Exception:
                pass
            if busy_token_v2346:
                try:
                    self._scene_busy_finish_v2482(
                        busy_token_v2346, reason="tv_season_select_done:%s" % season
                    )
                except Exception:
                    pass

    def _info_tv_back_to_seasons_if_needed(self, reason=""):
        try:
            active = self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1"
            if not active:
                return False
            is_tv = self.getProperty("PlexKM.Info.IsTV") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.IsTV") == "1"
            if not is_tv:
                return False
            back_mode = self.getProperty("PlexKM.Info.TVBackMode") or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVBackMode") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVBackMode")
            mode = self.getProperty("PlexKM.Info.TVMode") or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVMode") or xbmcgui.Window(13000).getProperty("PlexKM.Info.TVMode")
            # v734 root fix: the standalone seasons mode is obsolete after the
            # Plex-style inline season tabs were introduced.  Back should close
            # the inline Info to the originating Home/section item, not switch to
            # an empty seasons screen.  Keep the function for older call sites but
            # never consume Back in this layout.
            if mode == "episodes" and back_mode == "seasons":
                self._info_tv_set_mode("episodes", back_mode="")
                self._info_set_property_all("PlexKM.Info.TVSectionTitle", "에피소드")
                _log("INLINE_INFO_TV_BACK_TO_SEASONS_BYPASS reason=%s mode=%s back_mode=%s" % (reason or "back", mode or "", back_mode or ""))
            return False
        except Exception:
            _log("INLINE_INFO_TV_BACK_TO_SEASONS_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return False

    def _info_tv_current_episode_item_v2115(self):
        """Return the episode currently shown by Info, not a stale list selection.

        During atomic TV row publication Kodi can keep the list's selected item
        one frame behind PlexKM.Info.RatingKey.  The media-version owner must be
        the Info episode or the wrong episode cache is built/opened.
        """
        control = None
        try:
            control = self.getControl(self._info_tv_active_episode_control_id())
        except Exception:
            control = None
        current_rk = ""
        try:
            current_rk = str(
                xbmcgui.Window(10000).getProperty("PlexKM.Info.RatingKey")
                or self.getProperty("PlexKM.Info.RatingKey")
                or xbmcgui.Window(13000).getProperty("PlexKM.Info.RatingKey")
                or ""
            ).strip()
        except Exception:
            current_rk = ""
        if control is not None and current_rk:
            try:
                for pos in range(int(control.size())):
                    candidate = control.getListItem(pos)
                    if str(candidate.getProperty("PlexKM.RatingKey") or "").strip() == current_rk:
                        return candidate
            except Exception:
                pass
        try:
            return control.getSelectedItem() if control is not None else None
        except Exception:
            return None

    def _info_tv_selected_episode_item(self):
        return self._info_tv_current_episode_item_v2115()

    def _info_tv_user_selected_episode_item_v2222(self):
        """Return the native episode rail selection for explicit user actions.

        v2115 intentionally prefers PlexKM.Info.RatingKey to protect background
        media-version publication from a one-frame stale list selection. That is
        the wrong owner for an explicit Play click after XML-native rail movement:
        the panel selection is the user's authoritative episode. Keep v2115 for
        background/version work and use this helper only for direct user actions.
        """
        try:
            ctrl = self.getControl(self._info_tv_active_episode_control_id())
            selected = ctrl.getSelectedItem() if ctrl is not None else None
            if selected is not None and str(selected.getProperty("PlexKM.RatingKey") or "").strip():
                _log("INFO_TV_USER_EPISODE_OWNER_V2222 selected_rk=%s season=%s episode=%s panel=%s" % (
                    selected.getProperty("PlexKM.RatingKey") or "",
                    selected.getProperty("PlexKM.Season") or "",
                    selected.getProperty("PlexKM.Episode") or "",
                    self._info_tv_active_episode_control_id(),
                ))
                return selected
        except Exception:
            pass
        return self._info_tv_current_episode_item_v2115()

    def _info_tv_media_clear_v2112(self, reason=""):
        """Clear TV detailed Media/Part state without touching movie state."""
        try:
            self._info_tv_media_cache_v2112 = {}
            self._info_tv_media_choice_v2112 = {}
            self._info_tv_media_popup_rows_v2112 = []
            self._info_tv_media_popup_origin_v2112 = 0
            try:
                with self._info_tv_media_prewarm_lock_v2112:
                    self._info_tv_media_prewarm_generation_v2112 += 1
                    self._info_tv_media_prewarm_inflight_v2112.clear()
            except Exception:
                pass
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionPopupOpen")
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionCount")
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionResume")
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionPopupBgColor")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingPopupOpen")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingLabel")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingMode")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingShowLabel")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingShowKey")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingPriorityLabel")
            self._info_tv_next_timing_popup_origin_v2236 = 0
            self._info_tv_next_timing_show_key_v2236 = ""
            self._info_tv_next_timing_draft_v2237 = None
            self._info_tv_next_timing_draft_default_v2237 = True
            self._info_tv_next_timing_default_v2237 = 45
            self._info_tv_next_timing_show_title_v2237 = ""
            self._info_tv_next_timing_duration_v2237 = 0
            _log("INFO_TV_MEDIA_VERSION_CLEAR_V2112 reason=%s" % (reason or ""))
        except Exception:
            pass

    def _info_tv_build_media_variants_v2112(self, source_rk, source_part="", reason="", expected_generation=None):
        """Build unique codec combinations for one TV episode across selected libs.

        Matching is folder-agnostic: same show plus the same Plex episode GUID,
        with exact season/episode only as a metadata fallback. Same-resolution copies stay available long enough
        to expand their Plex Media/Part rows, then identical codec combinations are
        collapsed to one UI row exactly like movie Info.
        """
        source_rk = str(source_rk or "").strip()
        source_part = str(source_part or "").strip()
        if not source_rk:
            return []
        started = time.monotonic()
        try:
            core_mod = _ensure_core()
            selected, configured = core_mod.selected_sections_state()
            selected = [str(x) for x in (selected or []) if str(x)] if configured else []
            if not selected:
                return []
            conn = _pkm_ro_connect(self._profile_db_path(), timeout=2.0)
            try:
                result = pkm_media_versions.find_tv_episode_copy_candidates(
                    conn, source_rk, selected, show_cache={}
                ) or {}
            finally:
                conn.close()
            copies = list(result.get("copies") or [])

            rows = []
            if len(copies) > 1:
                workers = max(1, min(2 if self._is_android_v2591() else 4, len(copies)))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    futures = [
                        executor.submit(self._info_movie_expand_media_copy_v2100, copy_entry, core_mod)
                        for copy_entry in copies
                    ]
                    for future in futures:
                        try:
                            rows.extend(list(future.result() or []))
                        except Exception:
                            pass
            else:
                for copy_entry in copies:
                    rows.extend(self._info_movie_expand_media_copy_v2100(copy_entry, core_mod))

            exact_rows = []
            seen_exact = set()
            for row in rows:
                variant_key = str(row.get("variant_key") or "")
                if not variant_key or variant_key in seen_exact:
                    continue
                seen_exact.add(variant_key)
                exact_rows.append(row)

            grouped = {}
            group_order = []
            for row in exact_rows:
                combo_key = self._info_movie_media_combo_key_v2103(row)
                if not combo_key:
                    continue
                variant_key = str(row.get("variant_key") or "")
                if combo_key not in grouped:
                    rep = dict(row)
                    rep["combo_key"] = combo_key
                    rep["member_variant_keys"] = [variant_key] if variant_key else []
                    rep["member_count"] = 1
                    grouped[combo_key] = rep
                    group_order.append(combo_key)
                else:
                    rep = grouped[combo_key]
                    members = list(rep.get("member_variant_keys") or [])
                    if variant_key and variant_key not in members:
                        members.append(variant_key)
                    rep["member_variant_keys"] = members
                    rep["member_count"] = len(members)
                    current_is_source = (
                        str(rep.get("rating_key") or "") == source_rk
                        and str(rep.get("part_key") or "") == source_part
                    )
                    candidate_is_source = (
                        str(row.get("rating_key") or "") == source_rk
                        and str(row.get("part_key") or "") == source_part
                    )
                    current_audio_rank = int(rep.get("audio_preferred_rank") if rep.get("audio_preferred_rank") is not None else 9)
                    candidate_audio_rank = int(row.get("audio_preferred_rank") if row.get("audio_preferred_rank") is not None else 9)
                    if candidate_is_source and (not current_is_source or candidate_audio_rank < current_audio_rank):
                        keep_members = list(rep.get("member_variant_keys") or [])
                        keep_count = int(rep.get("member_count") or len(keep_members))
                        rep = dict(row)
                        rep["combo_key"] = combo_key
                        rep["member_variant_keys"] = keep_members
                        rep["member_count"] = keep_count
                        grouped[combo_key] = rep

            rows = [grouped[key] for key in group_order]
            rank = {"2160p": 0, "1080p": 1, "720p": 2, "480p": 3}
            rows.sort(key=lambda row: (
                rank.get(str(row.get("resolution") or "").lower(), 9),
                str(row.get("video_codec") or ""), str(row.get("hdr_type") or ""),
                str(row.get("audio_codec") or ""), int(row.get("audio_atmos") or 0),
                int(row.get("audio_channels") or 0), int(row.get("audio_preferred_rank") if row.get("audio_preferred_rank") is not None else 9),
                str(row.get("section_id") or ""), str(row.get("rating_key") or ""),
                str(row.get("part_key") or ""),
            ))

            if expected_generation is not None:
                with self._info_tv_media_prewarm_lock_v2112:
                    if int(expected_generation) != int(self._info_tv_media_prewarm_generation_v2112):
                        _log("INFO_TV_MEDIA_VERSION_PREWARM_STALE_V2112 source_rk=%s expected=%s actual=%s reason=%s" % (
                            source_rk, expected_generation, self._info_tv_media_prewarm_generation_v2112, reason or ""
                        ))
                        return []
            try:
                with self._info_tv_media_prewarm_lock_v2112:
                    cache = dict(getattr(self, "_info_tv_media_cache_v2112", {}) or {})
                    cache[source_rk] = [dict(x) for x in rows]
                    self._info_tv_media_cache_v2112 = cache
            except Exception:
                self._info_tv_media_cache_v2112 = {source_rk: [dict(x) for x in rows]}
            _log("INFO_TV_MEDIA_VERSION_BUILD_V2112 source_rk=%s copies=%d codec_variants=%d elapsed_ms=%d selected_scope=%s reason=%s" % (
                source_rk, len(copies), len(rows), int((time.monotonic() - started) * 1000),
                ",".join(selected), reason or ""
            ))
            return rows
        except Exception:
            _log("INFO_TV_MEDIA_VERSION_BUILD_FAILED_V2112 source_rk=%s reason=%s err=%s" % (
                source_rk, reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return []

    def _info_tv_schedule_media_prewarm_v2112(self, li=None, reason=""):
        """Warm the selected episode codec list after the Info surface is visible."""
        try:
            li = li or self._info_tv_selected_episode_item()
            if not li:
                return False
            source_rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            source_part = str(li.getProperty("PlexKM.PartKey") or "").strip()
            if not source_rk or not source_part:
                return False
            with self._info_tv_media_prewarm_lock_v2112:
                cache = getattr(self, "_info_tv_media_cache_v2112", {}) or {}
                if source_rk in cache:
                    return True
                if source_rk in self._info_tv_media_prewarm_inflight_v2112:
                    return True
                generation = int(self._info_tv_media_prewarm_generation_v2112)
                self._info_tv_media_prewarm_inflight_v2112.add(source_rk)

            def _worker():
                try:
                    xbmc.Monitor().waitForAbort(0.03)
                    self._info_tv_build_media_variants_v2112(
                        source_rk, source_part=source_part,
                        reason="prewarm_%s" % (reason or "info"),
                        expected_generation=generation,
                    )
                finally:
                    try:
                        with self._info_tv_media_prewarm_lock_v2112:
                            self._info_tv_media_prewarm_inflight_v2112.discard(source_rk)
                    except Exception:
                        pass
            _PKMHomeThreadV2151(target=_worker, name="PKMTVMediaVersionV2112", daemon=True).start()
            _log("INFO_TV_MEDIA_VERSION_PREWARM_START_V2112 source_rk=%s generation=%s reason=%s" % (
                source_rk, generation, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_MEDIA_VERSION_PREWARM_START_FAILED_V2112 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_media_variants_v2112(self, reason=""):
        item = self._info_tv_selected_episode_item()
        if not item:
            return []
        source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
        source_part = str(item.getProperty("PlexKM.PartKey") or "").strip()
        if not source_rk:
            return []
        try:
            cache = getattr(self, "_info_tv_media_cache_v2112", {}) or {}
            if source_rk in cache:
                rows = [dict(x) for x in (cache.get(source_rk) or [])]
                _log("INFO_TV_MEDIA_VERSION_CACHE_HIT_V2112 source_rk=%s rows=%d reason=%s" % (
                    source_rk, len(rows), reason or ""
                ))
                return rows
        except Exception:
            pass
        _log("INFO_TV_MEDIA_VERSION_CACHE_MISS_V2112 source_rk=%s reason=%s" % (source_rk, reason or ""))
        return self._info_tv_build_media_variants_v2112(
            source_rk, source_part=source_part,
            reason="click_fallback_%s" % (reason or "open"), expected_generation=None,
        )

    def _info_tv_apply_media_variant_v2112(self, entry, reason=""):
        if not isinstance(entry, dict):
            return False
        item = self._info_tv_selected_episode_item()
        if not item:
            return False
        try:
            source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
            rating_key = str(entry.get("rating_key") or "").strip()
            part_key = str(entry.get("part_key") or "").strip()
            if not source_rk or not rating_key or not part_key:
                return False
            selected = dict(entry)
            selected["owner_rating_key"] = source_rk
            resolution = str(selected.get("resolution") or "").strip().lower()
            if resolution:
                item.setProperty("PlexKM.VersionLabel", resolution)
                item.setProperty("PlexKM.VersionIconLabel", resolution.upper())
            item.setProperty("PlexKM.VersionSelectedRatingKey", rating_key)
            item.setProperty("PlexKM.VersionSelectedSectionId", str(selected.get("section_id") or ""))
            item.setProperty("PlexKM.VersionSelectedPartKey", part_key)
            item.setProperty("PlexKM.VersionSelectedMatchReason", str(selected.get("match_reason") or "MEDIA_VARIANT"))
            item.setProperty("PlexKM.MediaVersionAvailable", "1")
            item.setProperty("PlexKM.MediaVersionSelectedKey", str(selected.get("variant_key") or "%s|%s" % (rating_key, part_key)))
            item.setProperty("PlexKM.MediaVersionVideo", str(selected.get("main_label") or ""))
            item.setProperty("PlexKM.MediaVersionAudio", str(selected.get("audio_label") or ""))
            item.setProperty("PlexKM.MediaVersionAudioStreamIndex", str(selected.get("audio_stream_index") if selected.get("audio_stream_index") is not None else ""))
            if not isinstance(getattr(self, "_info_tv_media_choice_v2112", None), dict):
                self._info_tv_media_choice_v2112 = {}
            self._info_tv_media_choice_v2112[source_rk] = dict(selected)
            if not isinstance(getattr(self, "_info_tv_version_choice_v2099", None), dict):
                self._info_tv_version_choice_v2099 = {}
            if resolution:
                self._info_tv_version_choice_v2099[source_rk] = resolution
            self._info_tv_apply_selected_version_thumb_v2325(
                item, rating_key, reason="media_variant_v2112_%s" % (reason or "")
            )
            self._info_tv_publish_selected_version_state_v2123(
                item, reason="media_variant_v2112_%s" % (reason or "")
            )
            _log("INFO_TV_MEDIA_VERSION_SELECT_V2112 source_rk=%s target_rk=%s part=%s resolution=%s video=%s audio=%s no_refresh=1 thumb_follow_v2325=1 reason=%s" % (
                source_rk, rating_key, part_key, resolution, selected.get("video_codec") or "",
                selected.get("audio_label") or "", reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_MEDIA_VERSION_SELECT_FAILED_V2112 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_next_timing_context_v2236(self):
        """Return selected episode's show identity for the show-wide fallback."""
        try:
            item = self._info_tv_selected_episode_item()
            if item is None:
                return "", "", 0
            show_key = str(item.getProperty("PlexKM.GrandparentRatingKey") or "").strip()
            show_title = str(item.getProperty("PlexKM.ShowTitle") or "").strip()
            try:
                duration_ms = int(float(item.getProperty("PlexKM.Duration") or 0))
            except Exception:
                duration_ms = 0
            return show_key, show_title, duration_ms
        except Exception:
            return "", "", 0

    @staticmethod
    def _info_tv_next_timing_text_v2236(seconds):
        try:
            sec = max(0, int(seconds))
        except Exception:
            sec = 0
        if sec < 60:
            return "%d초" % sec
        minute, remain = divmod(sec, 60)
        if remain:
            return "%d분 %d초" % (minute, remain)
        return "%d분" % minute

    @staticmethod
    def _info_tv_next_default_seconds_v2237(duration_ms):
        try:
            duration_ms = int(duration_ms or 0)
        except Exception:
            duration_ms = 0
        return 30 if (duration_ms > 0 and duration_ms < 30 * 60 * 1000) else 45

    def _info_tv_publish_next_timing_v2236(self, show_key, show_title="", duration_ms=0, reason=""):
        """Publish the popup draft; this method never persists a value."""
        try:
            draft = getattr(self, "_info_tv_next_timing_draft_v2237", None)
            is_default = bool(getattr(self, "_info_tv_next_timing_draft_default_v2237", True))
            if draft is None:
                saved = pkm_episode_flow_v2222.get_show_next_offset_seconds_v2236(show_key)
                default_sec = self._info_tv_next_default_seconds_v2237(duration_ms)
                draft = default_sec if saved is None else int(saved)
                is_default = saved is None
            draft = max(5, min(600, int(draft)))
            if is_default:
                label = "기본값 · 끝나기 %s 전" % self._info_tv_next_timing_text_v2236(draft)
                mode = "default"
            else:
                label = "끝나기 %s 전" % self._info_tv_next_timing_text_v2236(draft)
                mode = "custom"
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingLabel", label)
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingMode", mode)
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingShowLabel", "%s 전체" % (show_title or "현재 드라마"))
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingShowKey", show_key)
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingPriorityLabel", "")
            _log("INFO_TV_NEXT_TIMING_DRAFT_PUBLISH_V2237 show=%s mode=%s value=%s reason=%s" % (
                show_key, mode, draft, reason or ""
            ))
            return draft
        except Exception:
            return None

    def _info_tv_close_next_timing_v2236(self, restore_focus=True, reason=""):
        try:
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingPopupOpen")
            self._info_clear_property_all("PlexKM.Info.NextEpisodeTimingResume")
            origin = int(getattr(self, "_info_tv_next_timing_popup_origin_v2236", 0) or 0)
            self._info_tv_next_timing_popup_origin_v2236 = 0
            self._info_tv_next_timing_show_key_v2236 = ""
            self._info_tv_next_timing_draft_v2237 = None
            self._info_tv_next_timing_draft_default_v2237 = True
            self._info_tv_next_timing_show_title_v2237 = ""
            self._info_tv_next_timing_duration_v2237 = 0
            if restore_focus and origin in (5729, 5730):
                try:
                    self.setFocusId(origin)
                except Exception:
                    pass
            _log("INFO_TV_NEXT_TIMING_CLOSE_V2237 reason=%s focus=%s" % (reason or "", origin))
            return True
        except Exception:
            return False

    def _info_tv_open_next_timing_v2236(self, control_id=0, reason=""):
        try:
            if self.getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1":
                return self._info_tv_close_next_timing_v2236(restore_focus=True, reason="toggle_discard")
            if self.getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1":
                self._info_tv_close_media_versions_v2112(restore_focus=False, reason="next_timing_open")
            show_key, show_title, duration_ms = self._info_tv_next_timing_context_v2236()
            if not show_key:
                self._show_pkm_notice("Plex KM", "드라마 정보를 찾지 못했습니다", "", ms=1800)
                return False
            saved = pkm_episode_flow_v2222.get_show_next_offset_seconds_v2236(show_key)
            default_sec = self._info_tv_next_default_seconds_v2237(duration_ms)
            self._info_tv_next_timing_show_key_v2236 = show_key
            self._info_tv_next_timing_popup_origin_v2236 = int(control_id or 5729)
            # v2424: TV action popups follow the button-row end exactly like Movie.
            # 5730 is +82px from 5729, and the popup follows by the same amount.
            next_timing_resume_v2337 = self._info_tv_next_timing_popup_origin_v2236 == 5730
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingResume", "1" if next_timing_resume_v2337 else "")
            self._info_tv_next_timing_default_v2237 = int(default_sec)
            self._info_tv_next_timing_draft_default_v2237 = saved is None
            self._info_tv_next_timing_draft_v2237 = int(default_sec if saved is None else saved)
            self._info_tv_next_timing_show_title_v2237 = show_title
            self._info_tv_next_timing_duration_v2237 = int(duration_ms or 0)
            self._info_publish_media_popup_bg_color_v2209(reason="next_timing_%s" % (reason or "open"))
            self._info_tv_publish_next_timing_v2236(show_key, show_title, duration_ms, reason="open")
            self._info_set_property_all("PlexKM.Info.NextEpisodeTimingPopupOpen", "1")
            try:
                self.setFocusId(7433)
            except Exception:
                pass
            _log("INFO_TV_NEXT_TIMING_OPEN_V2424 show=%s title=%s saved=%s default=%s origin=%s popup_y=357 popup_x=%s icon_gap=23 relative_to_action_end=1 pill=0 reason=%s" % (
                show_key, show_title, "default" if saved is None else saved, default_sec,
                self._info_tv_next_timing_popup_origin_v2236,
                496 if next_timing_resume_v2337 else 414,
                reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_NEXT_TIMING_OPEN_FAILED_V2237 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _info_tv_adjust_next_timing_v2236(self, delta_seconds, reason=""):
        try:
            show_key = str(getattr(self, "_info_tv_next_timing_show_key_v2236", "") or "").strip()
            if not show_key:
                return False
            current = getattr(self, "_info_tv_next_timing_draft_v2237", None)
            if current is None:
                current = int(getattr(self, "_info_tv_next_timing_default_v2237", 45) or 45)
            value = max(5, min(600, int(current) + int(delta_seconds)))
            self._info_tv_next_timing_draft_v2237 = value
            self._info_tv_next_timing_draft_default_v2237 = False
            self._info_tv_publish_next_timing_v2236(
                show_key,
                getattr(self, "_info_tv_next_timing_show_title_v2237", "") or "",
                getattr(self, "_info_tv_next_timing_duration_v2237", 0) or 0,
                reason=reason or "adjust",
            )
            _log("INFO_TV_NEXT_TIMING_DRAFT_ADJUST_V2237 show=%s delta=%s value=%s saved=0" % (show_key, delta_seconds, value))
            return True
        except Exception:
            _log("INFO_TV_NEXT_TIMING_DRAFT_ADJUST_FAILED_V2237 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_tv_set_next_timing_default_v2237(self, reason=""):
        try:
            show_key = str(getattr(self, "_info_tv_next_timing_show_key_v2236", "") or "").strip()
            if not show_key:
                return False
            value = int(getattr(self, "_info_tv_next_timing_default_v2237", 45) or 45)
            self._info_tv_next_timing_draft_v2237 = value
            self._info_tv_next_timing_draft_default_v2237 = True
            self._info_tv_publish_next_timing_v2236(
                show_key,
                getattr(self, "_info_tv_next_timing_show_title_v2237", "") or "",
                getattr(self, "_info_tv_next_timing_duration_v2237", 0) or 0,
                reason=reason or "default_draft",
            )
            _log("INFO_TV_NEXT_TIMING_DRAFT_DEFAULT_V2237 show=%s value=%s saved=0" % (show_key, value))
            return True
        except Exception:
            return False

    def _info_tv_confirm_next_timing_v2237(self, reason=""):
        try:
            show_key = str(getattr(self, "_info_tv_next_timing_show_key_v2236", "") or "").strip()
            if not show_key:
                return False
            is_default = bool(getattr(self, "_info_tv_next_timing_draft_default_v2237", True))
            value = int(getattr(self, "_info_tv_next_timing_draft_v2237", 45) or 45)
            if is_default:
                ok = pkm_episode_flow_v2222.set_show_next_offset_seconds_v2236(show_key, None)
                stored = "default"
            else:
                ok = pkm_episode_flow_v2222.set_show_next_offset_seconds_v2236(show_key, value)
                stored = str(value)
            if not ok:
                self._show_pkm_notice("Plex KM", "설정을 저장하지 못했습니다", "", ms=1800)
                return False
            title = str(getattr(self, "_info_tv_next_timing_show_title_v2237", "") or "현재 드라마")
            _log("INFO_TV_NEXT_TIMING_CONFIRM_SAVE_V2237 show=%s value=%s plex_marker_priority=1 scope=whole_show reason=%s" % (
                show_key, stored, reason or "confirm"
            ))
            self._info_tv_close_next_timing_v2236(restore_focus=True, reason="confirm_saved")
            self._show_pkm_notice("크레딧 설정", "%s 전체에 저장했습니다" % title, "", ms=1800)
            return True
        except Exception:
            _log("INFO_TV_NEXT_TIMING_CONFIRM_FAILED_V2237 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _info_tv_close_media_versions_v2112(self, restore_focus=True, reason=""):
        """Close only the TV inline codec popup and restore its action focus."""
        try:
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionPopupOpen")
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionCount")
            self._info_clear_property_all("PlexKM.Info.TVMediaVersionResume")
            origin = int(getattr(self, "_info_tv_media_popup_origin_v2112", 0) or 0)
            self._info_tv_media_popup_rows_v2112 = []
            self._info_tv_media_popup_origin_v2112 = 0
            if restore_focus and origin in (5727, 5728):
                try:
                    self.setFocusId(origin)
                except Exception:
                    pass
            _log("INFO_TV_MEDIA_VERSION_INLINE_CLOSE_V2112 reason=%s focus=%s" % (reason or "", origin))
            return True
        except Exception:
            return False

    def _info_tv_select_media_version_inline_v2112(self, reason=""):
        try:
            rows = list(getattr(self, "_info_tv_media_popup_rows_v2112", []) or [])
            ctrl = self.getControl(7420)
            pos = int(ctrl.getSelectedPosition())
            if not (0 <= pos < len(rows)):
                return False
            ok = self._info_tv_apply_media_variant_v2112(dict(rows[pos]), reason="inline_select_v2112")
            self._info_tv_close_media_versions_v2112(restore_focus=True, reason=reason or "select_tv")
            return bool(ok)
        except Exception:
            _log("INFO_TV_MEDIA_VERSION_INLINE_SELECT_FAILED_V2112 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            self._info_tv_close_media_versions_v2112(restore_focus=True, reason="select_tv_failed")
            return False

    def _info_tv_open_media_versions_v2112(self, control_id=0, reason=""):
        """Open the selected episode codec-combination list in the shared inline popup."""
        try:
            if self.getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.TVMediaVersionPopupOpen") == "1":
                return self._info_tv_close_media_versions_v2112(restore_focus=True, reason="toggle_tv")
            if self.getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.NextEpisodeTimingPopupOpen") == "1":
                self._info_tv_close_next_timing_v2236(restore_focus=False, reason="media_version_open")
            item = self._info_tv_selected_episode_item()
            rows = self._info_tv_media_variants_v2112(reason=reason or "open")
            if not item or not rows:
                self._show_pkm_notice("Plex KM", "미디어 버전 정보를 찾지 못했습니다", "", ms=2200)
                return False
            source_rk = str(item.getProperty("PlexKM.RatingKey") or "").strip()
            selected_key = str(item.getProperty("PlexKM.MediaVersionSelectedKey") or "").strip()
            if not selected_key:
                selected_key = "%s|%s" % (
                    item.getProperty("PlexKM.VersionSelectedRatingKey") or source_rk,
                    item.getProperty("PlexKM.VersionSelectedPartKey") or item.getProperty("PlexKM.PartKey") or "",
                )
            self._info_set_property_all("PlexKM.Info.TVMediaVersionCount", str(len(rows)))
            self._info_publish_media_popup_bg_color_v2209(reason="tv_open_%s" % (reason or "open"))
            if selected_key and "|a:" not in selected_key:
                base = selected_key + "|a:"
                matches = [r for r in rows if any(str(v or "").startswith(base) for v in (r.get("member_variant_keys") or [r.get("variant_key")]))]
                if matches:
                    matches.sort(key=lambda r: int(r.get("audio_preferred_rank") if r.get("audio_preferred_rank") is not None else 9))
                    selected_key = str(matches[0].get("variant_key") or selected_key)
            ctrl = self.getControl(7420)
            ctrl.reset()
            items = []
            selected_pos = 0
            for pos, row in enumerate(rows):
                resolution = str(row.get("resolution") or "").strip().upper()
                video_codec = str(row.get("video_codec") or "").strip()
                hdr_type = str(row.get("hdr_type") or "").strip()
                audio_label = str(row.get("audio_label") or "").strip()
                hdr_display = "" if hdr_type.upper() in ("", "SDR") else hdr_type
                display_label = " ".join(x for x in (resolution, video_codec, hdr_display, audio_label) if x).strip()
                li = xbmcgui.ListItem(label=display_label or "미디어 버전")
                row_key = str(row.get("variant_key") or "")
                members = [str(x or "") for x in (row.get("member_variant_keys") or []) if str(x or "")]
                is_selected = bool(selected_key and (row_key == selected_key or selected_key in members))
                li.setProperty("selected", "1" if is_selected else "")
                li.setProperty("variant_key", row_key)
                if is_selected:
                    selected_pos = pos
                items.append(li)
            ctrl.addItems(items)
            self._info_tv_media_popup_rows_v2112 = [dict(x) for x in rows]
            resume = str(item.getProperty("PlexKM.PlayButtonLabel") or "") == "이어서 재생"
            self._info_tv_media_popup_origin_v2112 = int(control_id or (5728 if resume else 5727))
            self._info_set_property_all("PlexKM.Info.TVMediaVersionResume", "1" if resume else "")
            self._info_set_property_all("PlexKM.Info.TVMediaVersionPopupOpen", "1")
            self.setFocusId(7420)
            ctrl.selectItem(max(0, min(len(items) - 1, selected_pos)))
            _log("INFO_TV_MEDIA_VERSION_INLINE_OPEN_V2112 source_rk=%s codec_variants=%s selected_pos=%s origin=%s no_modal=1 no_dim=1 reason=%s" % (
                source_rk, len(rows), selected_pos, self._info_tv_media_popup_origin_v2112, reason or ""
            ))
            return True
        except Exception:
            _log("INFO_TV_MEDIA_VERSION_INLINE_OPEN_FAILED_V2112 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            try:
                self._info_clear_property_all("PlexKM.Info.TVMediaVersionPopupOpen")
                if int(control_id or 0) in (5727, 5728):
                    self.setFocusId(int(control_id))
            except Exception:
                pass
            return False

    def _info_tv_episode_play_url(self, item, play_mode="play"):
        try:
            if not item:
                return ""
            source_rating_key = item.getProperty("PlexKM.RatingKey") or ""
            state_v2123 = self._info_tv_publish_selected_version_state_v2123(
                item, reason="play_url"
            )
            if str(state_v2123.get("owner_rating_key") or "") == str(source_rating_key or ""):
                rating_key = str(state_v2123.get("rating_key") or source_rating_key)
                part_key = str(state_v2123.get("part_key") or item.getProperty("PlexKM.PartKey") or "")
                _audio_index_v2123 = str(state_v2123.get("audio_stream_index") or "")
            else:
                rating_key = item.getProperty("PlexKM.VersionSelectedRatingKey") or source_rating_key
                part_key = item.getProperty("PlexKM.VersionSelectedPartKey") or item.getProperty("PlexKM.PartKey") or ""
                _audio_index_v2123 = item.getProperty("PlexKM.MediaVersionAudioStreamIndex") or ""
            if not rating_key or not part_key:
                return _pkm_no_resume_url(item.getProperty("PlexKM.PlayUrl") or item.getPath() or "")
            mode = str(play_mode or "play").lower()
            offset = item.getProperty("PlexKM.ViewOffset") or ""
            duration_raw = item.getProperty("PlexKM.Duration") or ""
            resume_duration_ms = item.getProperty("PlexKM.ResumeDurationMs") or ""
            safe_resume_ms = self._resume_offset_ms_for_ui(offset, duration_raw, resume_duration_ms)
            if mode == "resume" and safe_resume_ms <= 0:
                # R155: the Info episode rail and Home Continue can obtain an
                # offset from local Plex playstate that a light ListItem lacks.
                # Read by EXACT ratingKey, never manufacture a seek from 30%.
                try:
                    states_r155 = getattr(_ensure_core(), "_read_local_resume_states", lambda: {})() or {}
                    state_r155 = (states_r155.get(str(rating_key)) or
                                  states_r155.get(str(source_rating_key)) or {})
                    saved_ms_r155 = state_r155.get("time") or 0
                    saved_dur_r155 = state_r155.get("duration") or resume_duration_ms or duration_raw
                    safe_resume_ms = self._resume_offset_ms_for_ui(saved_ms_r155, duration_raw, saved_dur_r155)
                    if safe_resume_ms > 0:
                        resume_duration_ms = saved_dur_r155
                        _log("R155_TV_RESUME_LOCAL_FALLBACK rk=%s source=%s offset_ms=%s" % (
                            rating_key, source_rating_key, safe_resume_ms))
                except Exception:
                    pass
            effective_mode = "resume" if mode == "resume" and safe_resume_ms > 0 else "start"
            _native_resume_duration_ms = resume_duration_ms or duration_raw or ""
            if rating_key != source_rating_key or item.getProperty("PlexKM.VersionMultiple") == "1":
                _log("INFO_TV_VERSION_PLAY_TARGET_V2099 source_rk=%s target_rk=%s target_section=%s resolution=%s match=%s" % (
                    source_rating_key, rating_key,
                    state_v2123.get("section_id") or item.getProperty("PlexKM.VersionSelectedSectionId") or "",
                    state_v2123.get("label") or item.getProperty("PlexKM.VersionLabel") or "",
                    state_v2123.get("match_reason") or item.getProperty("PlexKM.VersionSelectedMatchReason") or ""
                ))
            return _pkm_play_url(rating_key, part_key, mode=effective_mode, view_offset=str(safe_resume_ms), duration_ms=_native_resume_duration_ms, audio_stream_index=_audio_index_v2123)
        except Exception:
            try:
                return _pkm_no_resume_url(item.getProperty("PlexKM.PlayUrl") or item.getPath() or "")
            except Exception:
                return ""

    def _info_tv_play_focused_episode(self, play_mode="resume"):
        item = self._info_tv_user_selected_episode_item_v2222()
        if not item:
            return
        try:
            self._arm_playback_priority_v2118(
                item.getProperty("PlexKM.RatingKey") or "", reason="tv_episode_play_click"
            )
        except Exception:
            pass
        play_url = self._info_tv_episode_play_url(item, play_mode=play_mode)
        source_rating_key = item.getProperty("PlexKM.RatingKey") or ""
        state_v2123 = dict(getattr(self, "_info_tv_selected_version_state_v2123", {}) or {})
        if str(state_v2123.get("owner_rating_key") or "") == str(source_rating_key or ""):
            rating_key = str(state_v2123.get("rating_key") or source_rating_key)
            resolution_v2123 = str(state_v2123.get("label") or item.getProperty("PlexKM.VersionLabel") or "")
        else:
            rating_key = item.getProperty("PlexKM.VersionSelectedRatingKey") or source_rating_key
            resolution_v2123 = item.getProperty("PlexKM.VersionLabel") or ""
        if not play_url:
            self._clear_playback_priority_v2118(reason="tv_play_no_url")
            _log("INLINE_INFO_TV_EPISODE_PLAY_SKIPPED reason=no_url mode=%s rating_key=%s" % (play_mode, rating_key), xbmc.LOGWARNING)
            return
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.InfoPlaybackRequested", "1")
            win.setProperty("PlexKM.InfoPlaybackRatingKey", rating_key)
            win.setProperty("PlexKM.InfoPlaybackUrl", play_url)
            win.setProperty("PlexKM.InfoDirectPlaybackStarting", "1")
            # v2222: marker timing must be known before the real AV session can
            # enter a 1-2 second intro marker. This is one bounded metadata read
            # for the exact selected/actual playback ratingKey. Failure never
            # blocks playback; intro simply stays disabled and next uses fallback.
            try:
                pkm_episode_flow_v2222.prepare_for_playback(
                    _ensure_core(), item, actual_rating_key=rating_key
                )
            except Exception:
                _log("EPISODE_FLOW_PREPARE_CALL_FAILED_V2222 rk=%s err=%s" % (
                    rating_key, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            self._handle_info_playback_request(item)
            _log("INLINE_INFO_TV_EPISODE_PLAY rating_key=%s source_rating_key=%s mode=%s resolution=%s state_owner=v2123" % (rating_key, source_rating_key, play_mode, resolution_v2123))
        except Exception:
            self._clear_playback_priority_v2118(reason="tv_play_exception")
            _log("INLINE_INFO_TV_EPISODE_PLAY_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _info_tv_mark_focused_episode_watched(self):
        """PKM_WATCHED_TOGGLE_R60: watched episode -> unscrobble, otherwise scrobble."""
        item = self._info_tv_user_selected_episode_item_v2222()
        if not item:
            return
        rating_key = item.getProperty("PlexKM.RatingKey") or ""
        if not rating_key:
            _log("INLINE_INFO_TV_MARK_WATCHED_SKIPPED reason=no_rating_key", xbmc.LOGWARNING)
            return
        currently_watched = str(item.getProperty("PlexKM.IsWatched") or "") == "1"
        try:
            ok = False
            try:
                if currently_watched:
                    ok = bool(_ensure_core().plex_unscrobble(rating_key, reason="inline_episode_unwatch_r60"))
                else:
                    ok = bool(_ensure_core().plex_scrobble(rating_key, reason="inline_episode_action"))
            except Exception:
                ok = False
            if ok:
                new_watched = "" if currently_watched else "1"
                try:
                    item.setProperty("PlexKM.IsWatched", new_watched)
                    item.setProperty("PlexKM.ViewCount", "1" if new_watched else "0")
                    item.setProperty("PlexKM.ViewOffset", "")
                    item.setProperty("PlexKM.RemainingText", "")
                    item.setProperty("PlexKM.ResumePercent", "")
                    item.setProperty("PlexKM.PlayButtonLabel", "재생")
                except Exception:
                    pass
                self._watched_toggle_local_resume_drop_r60(rating_key)
                self._watched_toggle_after_r60(
                    rating_key, new_watched,
                    reason="inline_episode_mark_watched" if new_watched else "inline_episode_mark_unwatched_r60")
                try:
                    self._show_pkm_notice("Plex KM", "시청함으로 표시했습니다" if new_watched else "미시청으로 표시했습니다", "", ms=1800)
                except Exception:
                    pass
                _log("INLINE_INFO_TV_WATCHED_TOGGLE_R60 rating_key=%s watched=%s" % (rating_key, new_watched or "0"))
            else:
                try:
                    self._show_pkm_notice("Plex KM", "미시청 표시 실패" if currently_watched else "시청함 표시 실패", "Plex 상태를 확인해주세요", ms=2500)
                except Exception:
                    pass
                _log("INLINE_INFO_TV_WATCHED_TOGGLE_FAILED_R60 rating_key=%s to_watched=%s" % (
                    rating_key, "0" if currently_watched else "1"), xbmc.LOGWARNING)
        except Exception:
            _log("INLINE_INFO_TV_MARK_WATCHED_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _info_tv_build_season_cards(self, show_key, rows, show_thumb="", show_art="", allow_network=False):
        """Build Plex-style season cards for the TV Info season panel.

        Initial Info uses local episode rows and the show poster only. Optional
        Plex season Directory art is fetched after the completed screen is visible.
        """
        show_key = str(show_key or "").strip()
        show_thumb = str(show_thumb or "").strip()
        show_art = str(show_art or "").strip()
        try:
            # Info season posters must always have a poster fallback.  Opening Info
            # from some Home rows can provide TV metadata without PlexKM.Thumb, so
            # derive the show poster directly from the show ratingKey before cards
            # are created.  This is data preparation only; XML still owns focus/UI.
            if not show_thumb and show_key:
                show_thumb = self._episode_show_poster_from_key(show_key) or _plex_art("/library/metadata/%s/thumb" % show_key, width=720, height=1080)
            if not show_art and show_key:
                show_art = _plex_art("/library/metadata/%s/art" % show_key, width=1280, height=720)
        except Exception:
            pass
        cards_by_season = {}
        order = []
        try:
            if show_key and allow_network:
                _season_auth_cache_hit_v2351 = False
                try:
                    _season_auth_cache_v2351 = getattr(self, "_info_tv_season_auth_cache_v2351", None)
                    if not isinstance(_season_auth_cache_v2351, dict):
                        _season_auth_cache_v2351 = {}
                        self._info_tv_season_auth_cache_v2351 = _season_auth_cache_v2351
                    _season_auth_entry_v2351 = _season_auth_cache_v2351.get(show_key)
                    if isinstance(_season_auth_entry_v2351, dict):
                        _season_auth_age_v2351 = max(0.0, time.time() - float(_season_auth_entry_v2351.get("ts") or 0.0))
                        if _season_auth_age_v2351 <= 180.0:
                            for _season_v2351, _card_v2351 in dict(_season_auth_entry_v2351.get("cards") or {}).items():
                                cards_by_season[str(_season_v2351)] = dict(_card_v2351 or {})
                            order.extend([str(x) for x in list(_season_auth_entry_v2351.get("order") or [])])
                            _season_auth_cache_hit_v2351 = bool(cards_by_season)
                            if _season_auth_cache_hit_v2351:
                                _log("INFO_TV_SEASON_AUTH_CACHE_HIT_V2351 show=%s cards=%d age_ms=%d network=0" % (
                                    show_key, len(cards_by_season), int(_season_auth_age_v2351 * 1000.0)
                                ))
                except Exception:
                    _season_auth_cache_v2351 = {}
                if not _season_auth_cache_hit_v2351:
                    core_mod = _ensure_core()
                    root = core_mod.plex_request_xml("/library/metadata/%s/children" % show_key, params={"skipRefresh": 1}, timeout=0.75)
                else:
                    root = []
                for node in list(root):
                    if node.tag != "Directory":
                        continue
                    ntype = (node.get("type") or "").lower()
                    if ntype and ntype != "season":
                        continue
                    season = str(node.get("index") or "")
                    if season == "":
                        continue
                    rk = str(node.get("ratingKey") or "")
                    node_thumb = node.get("thumb") or node.get("parentThumb") or ""
                    generated_thumb = ("/library/metadata/%s/thumb" % rk) if rk else ""
                    raw_thumb = node_thumb or generated_thumb
                    season_thumb = _plex_art(raw_thumb, width=300, height=450) if raw_thumb else ""
                    # Keep a guaranteed show-poster fallback property separate from
                    # the season-specific art.  XML binds to SeasonFinalArt, so an
                    # empty/late season image cannot leave a blank white card.
                    final_thumb = season_thumb or show_thumb or ""
                    art = _plex_art(node.get("art") or node.get("parentArt") or "", width=1280, height=720) or show_art or ""
                    raw_title_v2347 = str(node.get("title") or "").strip()
                    label = self._info_tv_normalize_season_label(raw_title_v2347, season)
                    cards_by_season[season] = {
                        "season": season,
                        "label": label,
                        "plex_title": raw_title_v2347,
                        "title_authoritative": "1" if raw_title_v2347 else "",
                        "thumb": final_thumb,
                        "season_thumb": season_thumb,
                        "show_thumb": show_thumb,
                        "art": art,
                        "episode_count": node.get("leafCount") or node.get("viewedLeafCount") or "",
                        "viewed_count": node.get("viewedLeafCount") or "",
                    }
                    _log("INFO_TV_SEASON_TITLE_AUTH_V2347 season=%s raw=%s display=%s source=plex_children" % (
                        season, _short_log_value(raw_title_v2347, 120), _short_log_value(label, 120)
                    ))
                    _log("INLINE_INFO_SEASON_ART season=%s title=%s season_thumb=%s show_thumb=%s final_art=%s source=plex_children" % (season, label, _short_log_value(season_thumb), _short_log_value(show_thumb), _short_log_value(final_thumb)))
                    order.append(season)
                if show_key and allow_network and not _season_auth_cache_hit_v2351 and cards_by_season:
                    try:
                        _season_auth_cache_v2351[show_key] = {
                            "ts": time.time(),
                            "cards": {k: dict(v or {}) for k, v in cards_by_season.items()},
                            "order": list(order),
                        }
                    except Exception:
                        pass
        except Exception:
            _log("INLINE_INFO_TV_SEASON_FETCH_FAILED show=%s\n%s" % (show_key, traceback.format_exc()), xbmc.LOGWARNING)
        if show_key and not allow_network:
            _log("INLINE_INFO_TV_SEASON_CARDS_LOCAL_FIRST_V1883 show=%s rows=%d network=0" % (show_key, len(rows or [])))
        counts = {}
        first_episode_thumb = {}
        for row in rows or []:
            try:
                r = tuple(row)
                season = str((r[19] if len(r) > 19 else "") or "")
                if season == "":
                    continue
                counts[season] = counts.get(season, 0) + 1
                if season not in first_episode_thumb:
                    first_episode_thumb[season] = self._info_tv_episode_thumb_from_row(row)
                if season not in cards_by_season:
                    episode_thumb = first_episode_thumb.get(season, "") or ""
                    final_thumb = show_thumb or episode_thumb or ""
                    label = self._info_tv_normalize_season_label("", season)
                    cards_by_season[season] = {
                        "season": season,
                        "label": label,
                        "plex_title": "",
                        "title_authoritative": "",
                        "thumb": final_thumb,
                        "season_thumb": "",
                        "show_thumb": show_thumb,
                        "art": show_art or "",
                        "episode_count": "",
                        "viewed_count": "",
                    }
                    _log("INLINE_INFO_SEASON_ART season=%s title=%s season_thumb=%s show_thumb=%s final_art=%s source=db_fallback" % (season, label, _short_log_value(episode_thumb), _short_log_value(show_thumb), _short_log_value(final_thumb)))
                    order.append(season)
            except Exception:
                pass
        for season, count in counts.items():
            try:
                cards_by_season[season]["episode_count"] = str(count)
                if not cards_by_season[season].get("thumb"):
                    cards_by_season[season]["thumb"] = show_thumb or first_episode_thumb.get(season, "") or ""
                    cards_by_season[season]["show_thumb"] = show_thumb or ""
            except Exception:
                pass
        def _season_sort_key(value):
            try:
                return (0, int(value))
            except Exception:
                return (1, str(value))
        ordered = []
        seen = set()
        for season in order:
            if season not in seen and season in cards_by_season:
                seen.add(season)
                ordered.append(cards_by_season[season])
        # Ensure DB-derived seasons remain numerically ordered even when Plex children
        # returned nothing or omitted a season.
        for season in sorted(cards_by_season.keys(), key=_season_sort_key):
            if season not in seen:
                seen.add(season)
                ordered.append(cards_by_season[season])
        return ordered

    def _schedule_info_tv_season_art_refresh_v1883(self):
        """Retired visible-page season mutation; v2347 resolves it previsible.

        PKM first-paint policy does not allow season titles/posters to change after
        the target Info page is visible.  Keep this entry point for compatibility,
        but do not mutate the current page here.
        """
        try:
            payload = dict(getattr(self, "_info_tv_season_refresh_payload_v1883", {}) or {})
            _log("INFO_TV_SEASON_POSTVISIBLE_SKIP_V2347 rating_key=%s show=%s authoritative=%s mutation=0" % (
                payload.get("rating_key") or "", payload.get("show_key") or "",
                payload.get("authoritative_ready_v2347") or "0"
            ))
        except Exception:
            pass
        return False

    # PKM_CUMULATIVE_STAGE3_TV_INFO_ASYNC
    def _info_tv_async_retry_commit_cumulative(self):
        """Retry only when exact section and selected poster are unchanged."""
        pending = getattr(self, "_info_tv_async_retry_cumulative", None)
        if not isinstance(pending, dict):
            return False
        key = pending.get("key")
        jobs = getattr(self, "_info_tv_async_jobs_cumulative", {})
        job = jobs.get(key) if isinstance(jobs, dict) else None
        if not job or not job["event"].is_set():
            return False
        self._info_tv_async_retry_cumulative = None
        if job.get("error") or not job.get("rows"):
            _log("INFO_TV_ASYNC_RETRY_ABORT reason=fetch_failed_or_empty key=%s" % key, xbmc.LOGWARNING)
            return False
        try:
            # R36: the old gate called the non-existent Window.getId() and
            # aborted EVERY retry, so a cold TV show click (allLeaves slower
            # than the 0.65 s SHIELD budget) was silently lost.
            if not self._pkm_window_owned_r34():
                _log("INFO_TV_ASYNC_RETRY_ABORT reason=kodi_window_changed key=%s" % key)
                return False
            focus_id = int(self._safe_focus_id())
            if (focus_id != int(pending.get("focus") or -1)
                    or str(getattr(self, "active_section_id", "") or "") != pending.get("section_owner")):
                _log("INFO_TV_ASYNC_RETRY_ABORT reason=focus_or_section_changed key=%s" % key)
                return False
            # The focused row can change its selected poster without moving focus.
            selected = self.getControl(focus_id).getSelectedItem()
            if selected is None:
                _log("INFO_TV_ASYNC_RETRY_ABORT reason=selected_row_unavailable key=%s" % key)
                return False
            selected_key = str(selected.getProperty("PlexKM.RatingKey") or "")
            # Missing identity is not proof that the user still owns this row.
            if not selected_key or selected_key != str(pending.get("rating_key") or ""):
                _log("INFO_TV_ASYNC_RETRY_ABORT reason=poster_changed_or_unverified key=%s" % key)
                return False
            if getattr(self, "_info_dialog_active", False):
                return False
            _log("INFO_TV_ASYNC_RETRY_GUI key=%s rows=%d" % (key, len(job.get("rows") or [])))
            self._show_info(li=pending["li"])
            return True
        except Exception:
            _log("INFO_TV_ASYNC_RETRY_ABORT reason=exception err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _info_tv_fetch_bounded_cumulative(self, show_key, section_id, wait_seconds=0.65):
        """Single-flight Plex allLeaves on a worker; no Kodi controls off-thread.

        Returns (rows, state). 'pending' retains previous complete Info rather
        than freezing the Kodi GUI while Plex/upsert runs for many seconds.
        """
        key = "%s:%s" % (section_id, show_key)
        lock = getattr(self, "_info_tv_async_lock_cumulative", None)
        if lock is None:
            lock = threading.RLock()
            self._info_tv_async_lock_cumulative = lock
            self._info_tv_async_jobs_cumulative = {}
        with lock:
            jobs = self._info_tv_async_jobs_cumulative
            # Finished entries are small; the main SQLite DB is the authority.
            for old_key in list(jobs):
                old = jobs.get(old_key) or {}
                if old.get("event") is not None and old["event"].is_set() and old_key != key:
                    jobs.pop(old_key, None)
            job = jobs.get(key)
            if job is None:
                job = {"event": threading.Event(), "rows": [], "error": "", "started": time.monotonic()}
                jobs[key] = job
                def _read_allleaves():
                    try:
                        core_mod = _ensure_core()
                        items = core_mod.fetch_show_episodes(
                            show_key, section_id, upsert=True, timeout=1.5
                        ) or []
                        job["rows"] = [core_mod.row_from_item_dict(x) for x in items if x]
                    except Exception as exc:
                        job["error"] = str(exc)
                    finally:
                        job["event"].set()
                        # Signal GUI only once the duplicate-click guard has passed.
                        if not self._closing_event_v1841.wait(0.95):
                            try:
                                xbmc.executebuiltin("SendClick(%d)" % SIDEBAR_COMMIT_PING_ID_V2595)
                            except Exception:
                                pass
                        _log("INFO_TV_ASYNC_ALLLEAVES_DONE show=%s section=%s rows=%d elapsed_ms=%d ok=%d" % (
                            show_key, section_id, len(job.get("rows") or []),
                            int((time.monotonic() - job["started"]) * 1000),
                            0 if job.get("error") else 1
                        ))
                _PKMHomeThreadV2151(target=_read_allleaves, name="PKMInfoEpisodes", daemon=True).start()
        if not job["event"].wait(max(0.0, float(wait_seconds))):
            _log("INFO_TV_ASYNC_ALLLEAVES_PENDING show=%s section=%s gui_wait_ms=%d previous_surface=kept" % (
                show_key, section_id, int(wait_seconds * 1000)
            ), xbmc.LOGWARNING)
            return [], "pending"
        if job.get("error"):
            # Do not poison later clicks after a transient Plex failure.
            with lock:
                if jobs.get(key) is job:
                    jobs.pop(key, None)
            return [], "error"
        return list(job.get("rows") or []), "done"

    def _prepare_info_tv_rows(self, li, preserve_previous_surface=False, allow_network=True):
        """Prepare Plex-style TV show/episode rows for inline Info.

        Kodi XML owns the visual containers and navigation. Python only reads the
        already available local DB, falling back to Plex allLeaves when a show has
        not been cached yet.
        """
        win = xbmcgui.Window(10000)
        # v1884: a background/same-surface repair must be transactional.  The
        # v1883 failure branch kept InlineActive but had already cleared TV mode,
        # rail lists and shared properties, so the supposedly preserved page could
        # still become empty.  Snapshot the active native controls/properties only
        # for those repair paths and restore them on any failure.
        _tv_previous_v1884 = None
        if preserve_previous_surface:
            try:
                _tv_prop_names_v1884 = (
                    "PlexKM.Info.TVRowsEmpty", "PlexKM.Info.TVRowsFailedV1841",
                    "PlexKM.Info.IsTV", "PlexKM.Info.IsShow", "PlexKM.Info.IsSeason",
                    "PlexKM.Info.IsEpisode", "PlexKM.Info.HasSeasonTabs",
                    "PlexKM.Info.HasSeasonCards", "PlexKM.Info.TVSectionTitle",
                    "PlexKM.Info.TVEpisodeHint", "PlexKM.Info.TVShowTitle",
                    "PlexKM.Info.Title", "PlexKM.Info.TitleDisplay",
                    "PlexKM.Info.TVMode", "PlexKM.Info.TVBackMode",
                    "PlexKM.Info.TVModeSeasons", "PlexKM.Info.TVModeEpisodes",
                    "PlexKM.Info.TVActiveBuffer", "PlexKM.Info.TVRowsReady",
                )
                _tv_props_v1884 = {}
                for _name_v1884 in _tv_prop_names_v1884:
                    _tv_props_v1884[_name_v1884] = (
                        win.getProperty(_name_v1884) or self.getProperty(_name_v1884) or ""
                    )
                _tv_controls_v1884 = {}
                for _cid_v1884 in (5711, 5712, 5713):
                    try:
                        _ctrl_v1884 = self.getControl(_cid_v1884)
                        _size_v1884 = int(_ctrl_v1884.size())
                        _items_v1884 = [_ctrl_v1884.getListItem(_i_v1884) for _i_v1884 in range(_size_v1884)]
                        _pos_v1884 = int(_ctrl_v1884.getSelectedPosition()) if _size_v1884 > 0 else -1
                        _tv_controls_v1884[_cid_v1884] = (_items_v1884, _pos_v1884)
                    except Exception:
                        _tv_controls_v1884[_cid_v1884] = ([], -1)
                _tv_previous_v1884 = {
                    "props": _tv_props_v1884,
                    "controls": _tv_controls_v1884,
                    "rows": list(getattr(self, "_info_tv_rows", []) or []),
                    "seasons": list(getattr(self, "_info_tv_seasons", []) or []),
                    "cards": list(getattr(self, "_info_tv_season_cards", []) or []),
                    "selected_season": getattr(self, "_info_tv_selected_season", "") or "",
                    "refresh_payload": dict(getattr(self, "_info_tv_season_refresh_payload_v1883", {}) or {}),
                    "defer_focus": bool(getattr(self, "_info_tv_defer_focus", False)),
                }
                _log("INLINE_INFO_TV_TRANSACTION_SNAPSHOT_V1884 controls=%d rows=%d" % (
                    len(_tv_controls_v1884), len(_tv_previous_v1884["rows"])
                ))
            except Exception:
                _tv_previous_v1884 = None
                _log("INLINE_INFO_TV_TRANSACTION_SNAPSHOT_FAILED_V1884 err=%s" % (
                    traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
        # v1883 true TV rail double-buffer: populate the inactive 5712/5713
        # panel completely before the one visible-buffer flip. The inactive
        # buffer is reset only inside _info_tv_populate_episode_control().
        self._info_tv_rows = []
        self._info_tv_seasons = []
        self._info_tv_season_cards = []
        try:
            self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
            self._info_clear_property_all("PlexKM.Info.TVRowsFailedV1841")
        except Exception:
            pass
        try:
            plex_type = li.getProperty("PlexKM.Type") or ""
            is_tv = plex_type in ("show", "season", "episode", "tv") or (li.getProperty("PlexKM.KodiType") in ("tvshow", "episode"))
            for k in ("IsTV", "IsShow", "IsSeason", "IsEpisode"):
                self._info_clear_property_all("PlexKM.Info.%s" % k)
            if not is_tv:
                return True
            self._info_set_property_all("PlexKM.Info.IsTV", "1")
            is_show = "1" if plex_type == "show" else ""
            is_season = "1" if plex_type == "season" else ""
            is_episode = "1" if plex_type == "episode" else ""
            self._info_set_property_all("PlexKM.Info.IsShow", is_show)
            self._info_set_property_all("PlexKM.Info.IsSeason", is_season)
            self._info_set_property_all("PlexKM.Info.IsEpisode", is_episode)
            show_key = (
                li.getProperty("PlexKM.RatingKey")
                if plex_type == "show"
                else (li.getProperty("PlexKM.GrandparentRatingKey") or "")
            )
            section_id = li.getProperty("PlexKM.SectionId") or ""
            focus_rating_key = li.getProperty("PlexKM.RatingKey") if plex_type == "episode" else ""
            selected_season = li.getProperty("PlexKM.Season") or ""
            if not show_key or not section_id:
                _log("INLINE_INFO_TV_PREPARE_INVALID_KEYS_V1841 section=%s show=%s type=%s action=cancel_restore" % (
                    section_id, show_key, plex_type
                ), xbmc.LOGERROR)
                raise RuntimeError(
                    "TV info keys missing: show=%s section=%s type=%s" %
                    (show_key, section_id, plex_type)
                )
            rows = []
            _prepared_tv_payload_v2510 = getattr(self, "_info_prepared_tv_payload_v2510", None)
            if isinstance(_prepared_tv_payload_v2510, dict):
                try:
                    _payload_rk_v2510 = str(_prepared_tv_payload_v2510.get("rating_key") or "").strip()
                    _payload_sid_v2510 = str(_prepared_tv_payload_v2510.get("section_id") or "").strip()
                    _payload_show_v2510 = str(_prepared_tv_payload_v2510.get("show_key") or "").strip()
                    _current_rk_v2510 = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                    if (_payload_rk_v2510 == _current_rk_v2510 and _payload_sid_v2510 == str(section_id)
                            and _payload_show_v2510 == str(show_key)):
                        rows = [tuple(x) if isinstance(x, list) else x for x in list(_prepared_tv_payload_v2510.get("rows") or [])]
                        if rows:
                            _log("INFO_TV_ROWS_PREPARED_CACHE_HIT_V2510 rating_key=%s show=%s section=%s rows=%d local_db=0 plex_allleaves=0" % (
                                _current_rk_v2510, show_key, section_id, len(rows)
                            ))
                    else:
                        _prepared_tv_payload_v2510 = None
                        self._info_prepared_tv_payload_v2510 = None
                except Exception:
                    rows = []
                    _prepared_tv_payload_v2510 = None
                    self._info_prepared_tv_payload_v2510 = None
            _tv_rows_cache_key_v2351 = "%s:%s" % (section_id, show_key)
            try:
                _tv_rows_cache_v2351 = getattr(self, "_info_tv_rows_memory_cache_v2351", None)
                if not isinstance(_tv_rows_cache_v2351, dict):
                    _tv_rows_cache_v2351 = {}
                    self._info_tv_rows_memory_cache_v2351 = _tv_rows_cache_v2351
                # v2510: a section-authority-validated persisted TV payload is
                # already the stronger reusable snapshot. Do not overwrite it
                # with the older 180s memory row cache.
                if not rows:
                    _tv_rows_entry_v2351 = _tv_rows_cache_v2351.get(_tv_rows_cache_key_v2351)
                    if isinstance(_tv_rows_entry_v2351, dict):
                        _tv_rows_age_v2351 = max(0.0, time.time() - float(_tv_rows_entry_v2351.get("ts") or 0.0))
                        if _tv_rows_age_v2351 <= 180.0:
                            rows = list(_tv_rows_entry_v2351.get("rows") or [])
                            if rows:
                                _log("INFO_TV_ROWS_MEMORY_CACHE_HIT_V2351 show=%s section=%s rows=%d age_ms=%d db_query=0 plex_fallback=0" % (
                                    show_key, section_id, len(rows), int(_tv_rows_age_v2351 * 1000.0)
                                ))
            except Exception:
                _tv_rows_cache_v2351 = {}
            if not rows:
                try:
                    rows = list(_ensure_core().query_episodes_for_show(section_id, show_key) or [])
                except Exception:
                    rows = []
            fallback_failed_v1841 = False
            _async_state = ""
            if not rows and allow_network:
                # v868: Local rows can be absent even when Plex has normal episode
                # metadata (for example a show that has not been fully cached yet).
                # v863-v867 skipped the Plex fallback here to avoid a perceived
                # transition delay, but that created a permanent "loading" shell.
                # Restore the original functional fallback: fetch allLeaves once,
                # upsert it into the local DB, then publish the rows atomically.
                # The previous completed surface remains visible and the global
                # busy broker handles a slow fallback, so no empty TV shell is exposed.
                try:
                    core_mod = _ensure_core()
                    # v2428: a local-row miss is not itself a slow path. The
                    # supplied traces complete allLeaves in 30-46ms, so promoting
                    # the spinner before the request only flashes a ring on a fast
                    # result. Keep the normal delayed token for genuinely slow work.
                    _log("INFO_TV_ALLLEAVES_DELAYED_SPINNER_V2428 rating_key=%s show=%s section=%s promote=0" % (
                        li.getProperty("PlexKM.RatingKey") or "", show_key, section_id
                    ))
                    _fallback_start_ms = self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)
                    _atomic_timeout_v2609 = 0.60 if self._uhd_kpi_proxy_v2605() else 1.5
                    if self._uhd_kpi_proxy_v2605():
                        rows, _async_state = self._info_tv_fetch_bounded_cumulative(
                            show_key, section_id, wait_seconds=0.65
                        )
                        if _async_state != "done":
                            if _async_state == "pending":
                                self._info_tv_async_retry_cumulative = {
                                    "key": "%s:%s" % (section_id, show_key),
                                    "focus": int(self._safe_focus_id()),
                                    "section_owner": str(getattr(self, "active_section_id", "") or ""),
                                    "rating_key": str(li.getProperty("PlexKM.RatingKey") or ""),
                                    "li": li,
                                }
                            raise RuntimeError("TV allLeaves %s (background fetch retains previous surface)" % _async_state)
                    else:
                        items = core_mod.fetch_show_episodes(show_key, section_id, upsert=True, timeout=_atomic_timeout_v2609) or []
                        rows = [core_mod.row_from_item_dict(x) for x in items if x]
                    _fallback_step_ms = (self._now_ms() if hasattr(self, "_now_ms") else int(time.time() * 1000)) - _fallback_start_ms
                    _log("INLINE_INFO_TV_LOCAL_ROWS_FALLBACK_FETCH_V2609 show=%s section=%s type=%s rows=%d step=%dms timeout_ms=%d atomic_source_hold=%d" % (
                        show_key, section_id, plex_type, len(rows or []), _fallback_step_ms, int(_atomic_timeout_v2609 * 1000.0),
                        1 if self._uhd_kpi_proxy_v2605() else 0
                    ))
                except Exception:
                    rows = []
                    fallback_failed_v1841 = True
                    if _async_state == "pending":
                        _log("INFO_TV_LOCAL_MISS_BACKGROUND_IN_PROGRESS show=%s section=%s previous_surface=kept awaiting_gui_retry=1" % (
                            show_key, section_id
                        ), xbmc.LOGINFO)
                    else:
                        _log("INLINE_INFO_TV_LOCAL_ROWS_FALLBACK_FAILED show=%s section=%s type=%s\n%s" % (
                            show_key, section_id, plex_type, traceback.format_exc()
                        ), xbmc.LOGWARNING)
            elif not rows and not allow_network:
                _log("INLINE_INFO_TV_LOCAL_ROWS_MISS_V2380R1 show=%s section=%s type=%s action=no_network_fallback" % (
                    show_key, section_id, plex_type
                ), xbmc.LOGINFO)
            if rows:
                try:
                    if isinstance(_tv_rows_cache_v2351, dict):
                        _tv_rows_cache_v2351[_tv_rows_cache_key_v2351] = {"ts": time.time(), "rows": list(rows)}
                        if len(_tv_rows_cache_v2351) > 12:
                            _oldest_tv_rows_key_v2351 = min(
                                _tv_rows_cache_v2351,
                                key=lambda k: float((_tv_rows_cache_v2351.get(k) or {}).get("ts") or 0.0)
                            )
                            if _oldest_tv_rows_key_v2351 != _tv_rows_cache_key_v2351:
                                _tv_rows_cache_v2351.pop(_oldest_tv_rows_key_v2351, None)
                except Exception:
                    pass
            if fallback_failed_v1841:
                # A transport/DB exception is not proof that the show has zero
                # episodes.  Let the terminal handler cancel the transition and
                # restore the previous complete surface.
                raise RuntimeError(
                    "TV episode fallback failed for show=%s section=%s" %
                    (show_key, section_id)
                )
            if not rows:
                self._info_tv_rows = []
                self._info_tv_seasons = []
                self._info_tv_season_cards = []
                self._info_tv_selected_season = selected_season or ""
                self._info_set_property_all("PlexKM.Info.TVRowsEmpty", "1")
                self._info_clear_property_all("PlexKM.Info.HasSeasonTabs")
                self._info_clear_property_all("PlexKM.Info.HasSeasonCards")
                self._info_set_property_all("PlexKM.Info.TVSectionTitle", "에피소드")
                self._info_set_property_all("PlexKM.Info.TVEpisodeHint", "에피소드 정보를 불러올 수 없습니다")
                self._info_tv_set_mode("episodes", back_mode="")
                _log("INLINE_INFO_TV_NO_ROWS_AFTER_FALLBACK show=%s section=%s type=%s" % (show_key, section_id, plex_type), xbmc.LOGWARNING)
                return True
            self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
            self._info_clear_property_all("PlexKM.Info.TVEpisodeHint")
            try:
                tv_show_title = str(li.getProperty("PlexKM.ShowTitle") or "").strip()
                if not tv_show_title and plex_type == "show":
                    tv_show_title = str(li.getProperty("PlexKM.Title") or li.getLabel() or "").strip()
                if not tv_show_title and rows:
                    first_row = tuple(rows[0] or ())
                    tv_show_title = str((first_row[18] if len(first_row) > 18 else "") or "").strip()
                if tv_show_title:
                    self._info_set_property_all("PlexKM.Info.TVShowTitle", tv_show_title)
                    self._info_set_property_all("PlexKM.Info.Title", tv_show_title)
                    self._info_set_property_all("PlexKM.Info.TitleDisplay", self._title_display_text(tv_show_title))
                    _log("INFO_TV_SHOW_TITLE_V1567 show_key=%s title=%s source=episode_rows" % (
                        show_key or "", _short_log_value(tv_show_title, 100)
                    ))
            except Exception:
                _log("INFO_TV_SHOW_TITLE_V1567_FAILED show_key=%s err=%s" % (
                    show_key or "", traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            self._info_tv_rows = rows
            seasons = []
            seen = set()
            for row in rows:
                try:
                    season = str((tuple(row)[19] if len(tuple(row)) > 19 else "") or "")
                except Exception:
                    season = ""
                if season not in seen:
                    seen.add(season)
                    seasons.append(season)
            # Episode rail focus is derived from the rows already prepared for
            # this Info page. No extra DB query or network request is needed.
            try:
                focus_rating_key, target_season, target_reason = self._info_tv_initial_episode_target(
                    rows,
                    plex_type=plex_type,
                    explicit_rating_key=focus_rating_key,
                    selected_season=selected_season,
                )
                if target_season:
                    selected_season = target_season
                _log(
                    "INFO_TV_INITIAL_EPISODE_TARGET show=%s type=%s episode=%s season=%s reason=%s" % (
                        show_key or "",
                        plex_type or "",
                        focus_rating_key or "",
                        selected_season or "",
                        target_reason or "",
                    )
                )
            except Exception:
                _log(
                    "INFO_TV_INITIAL_EPISODE_TARGET_FAILED show=%s err=%s" % (
                        show_key or "",
                        traceback.format_exc().replace(chr(10), " | "),
                    ),
                    xbmc.LOGWARNING,
                )


            if not selected_season and seasons:
                selected_season = seasons[0]
            self._info_tv_seasons = seasons
            self._info_tv_selected_season = selected_season
            show_thumb = li.getProperty("PlexKM.Thumb") or li.getArt("thumb") or li.getArt("poster") or ""
            if not show_thumb and show_key:
                show_thumb = self._episode_show_poster_from_key(show_key) or _plex_art("/library/metadata/%s/thumb" % show_key, width=720, height=1080)
            show_art = li.getProperty("PlexKM.Art") or li.getArt("fanart") or ""
            if not show_art and show_key:
                show_art = _plex_art("/library/metadata/%s/art" % show_key, width=1280, height=720)
            _log("INLINE_INFO_SHOW_ART show=%s show_thumb=%s show_art=%s source=prepare_tv" % (show_key, _short_log_value(show_thumb), _short_log_value(show_art)))
            # v2347: build a local snapshot first, then resolve Plex's authoritative
            # season Directory titles *before visible* whenever a season selector
            # will be shown.  This is required for named GDS/shared-folder editions
            # such as a physical season 201 that Plex labels "시즌 1 감독판".  We do
            # not infer that label from 201; Plex metadata is the authority.
            _prepared_season_cards_v2510 = []
            _prepared_refresh_v2510 = {}
            if isinstance(_prepared_tv_payload_v2510, dict) and rows:
                try:
                    _prepared_season_cards_v2510 = [dict(x) for x in list(_prepared_tv_payload_v2510.get("season_cards") or []) if isinstance(x, dict)]
                    _prepared_refresh_v2510 = dict(_prepared_tv_payload_v2510.get("refresh_payload") or {})
                except Exception:
                    _prepared_season_cards_v2510 = []
                    _prepared_refresh_v2510 = {}
            if _prepared_season_cards_v2510:
                self._info_tv_season_cards = _prepared_season_cards_v2510
                _season_titles_authoritative_v2347 = bool(str(_prepared_refresh_v2510.get("authoritative_ready_v2347") or "") == "1")
                _local_visible_v2347 = len(self._info_tv_visible_season_cards_v2303(selected_season))
                _log("INFO_TV_SEASON_CARDS_PREPARED_CACHE_HIT_V2510 show=%s cards=%d authoritative=%d plex_children=0" % (
                    show_key, len(self._info_tv_season_cards), 1 if _season_titles_authoritative_v2347 else 0
                ))
            else:
                self._info_tv_season_cards = self._info_tv_build_season_cards(
                    show_key, rows, show_thumb=show_thumb, show_art=show_art, allow_network=False
                )
                _local_visible_v2347 = len(self._info_tv_visible_season_cards_v2303(selected_season))
                _season_titles_authoritative_v2347 = False
                if _local_visible_v2347 > 0 and show_key and allow_network:
                    try:
                        _authoritative_cards_v2347 = self._info_tv_build_season_cards(
                            show_key, rows, show_thumb=show_thumb, show_art=show_art, allow_network=True
                        )
                        if _authoritative_cards_v2347:
                            self._info_tv_season_cards = _authoritative_cards_v2347
                            _season_titles_authoritative_v2347 = True
                    except Exception:
                        _log("INFO_TV_SEASON_PREVISIBLE_AUTH_FAILED_V2347 show=%s err=%s" % (
                            show_key, traceback.format_exc().replace(chr(10), " | ")
                        ), xbmc.LOGWARNING)
            self._info_tv_season_refresh_payload_v1883 = {
                "rating_key": li.getProperty("PlexKM.RatingKey") or "",
                "show_key": show_key, "rows": list(rows or []),
                "show_thumb": show_thumb, "show_art": show_art,
                "selected_season": selected_season or "",
                "authoritative_ready_v2347": "1" if _season_titles_authoritative_v2347 else "",
            }
            season_card_count = len(getattr(self, "_info_tv_season_cards", []) or [])
            visible_season_card_count_v2303 = len(self._info_tv_visible_season_cards_v2303(selected_season))
            _log("INFO_TV_SEASON_PREVISIBLE_READY_V2347 show=%s cards=%d visible=%d authoritative=%d selected=%s" % (
                show_key, season_card_count, visible_season_card_count_v2303,
                1 if _season_titles_authoritative_v2347 else 0, selected_season or ""
            ))
            logical_season_count_v2303 = self._info_tv_logical_season_count_v2303(getattr(self, "_info_tv_season_cards", []) or [])
            has_season_tabs = "1" if logical_season_count_v2303 > 1 else ""
            has_season_cards = "1" if visible_season_card_count_v2303 > 0 else ""
            self._info_set_property_all("PlexKM.Info.HasSeasonTabs", has_season_tabs)
            self._info_set_property_all("PlexKM.Info.HasSeasonCards", has_season_cards)
            _log("INLINE_INFO_TV_SEASON_VISIBILITY_V2303 raw=%d logical=%d visible_story_seasons=%d selected_physical=%s base_season1_hidden=1 media_alias_folders=0" % (
                season_card_count, logical_season_count_v2303, visible_season_card_count_v2303, selected_season or ""
            ))

            # v456: TV show with exactly one season should open the episode panel directly.
            # Keep Kodi XML/panel navigation intact: Python only chooses the initial TV Info mode.
            # Multi-season shows still open the season panel, and episode items still open episodes.
            effective_season_count = logical_season_count_v2303 or len(seasons)
            single_season_show = (plex_type == "show" and effective_season_count == 1 and bool(selected_season))

            # v726: Plex-style inline season tabs.  Shows with multiple real seasons
            # stay in episode mode and expose 5711 as a small top tab strip.  This is
            # not navigation flow control; Kodi XML still owns UP/DOWN/LEFT/RIGHT and
            # Python only selects the initial visible data mode.
            self._info_tv_set_mode("episodes", back_mode="")
            self._info_set_property_all("PlexKM.Info.TVSectionTitle", "에피소드")
            target_focus_control = self._info_tv_active_episode_control_id()
            target_focus_reason = (
                "open_episode" if plex_type == "episode"
                else ("open_season_folder_v1870" if plex_type == "season"
                      else ("open_single_season_show" if single_season_show else "open_show_episode_tabs"))
            )

            self._info_tv_populate_season_control(selected_season=selected_season)
            _episode_buffer_id = self._info_tv_populate_episode_control(
                season=selected_season, focus_rating_key=focus_rating_key, allow_download=allow_network
            )
            if _episode_buffer_id:
                target_focus_control = self._info_tv_publish_episode_buffer(_episode_buffer_id, reason=target_focus_reason)
            # v2406: preparation selects the target episode only inside the hidden
            # A/B bank.  The visible-boundary handoff later gives keyboard focus
            # to that published episode panel; preparation itself never steals it.
            _log("INLINE_INFO_TV_PREPARE_SELECTION_ONLY_V2344 type=%s show=%s selected_episode=%s active_buffer_control=%s focus_write=0" % (
                plex_type, show_key, focus_rating_key or "", target_focus_control
            ))
            if allow_network:
                try:
                    self._info_tv_schedule_media_prewarm_v2112(self._info_tv_selected_episode_item(), reason="tv_rows_publish")
                except Exception:
                    pass
            else:
                _log("INFO_TV_MEDIA_PREWARM_SKIP_V2380R1 show=%s reason=network_disabled" % (show_key or ""))
            _log("INLINE_INFO_TV_READY type=%s show=%s section=%s seasons=%d season_cards=%d episodes=%d selected_season=%s focus=%s single_season=%s mode=%s" % (
                plex_type, show_key, section_id, len(seasons), len(getattr(self, "_info_tv_season_cards", []) or []), len(rows), selected_season or "", focus_rating_key or "", "1" if single_season_show else "0", self.getProperty("PlexKM.Info.TVMode") or ""))
            try:
                self._info_prepared_tv_payload_v2510 = None
            except Exception:
                pass
            return True
        except Exception:
            try:
                self._info_clear_property_all("PlexKM.Info.TVRowsReady")
                self._info_clear_property_all("PlexKM.Info.TVRowsEmpty")
                self._info_set_property_all("PlexKM.Info.TVRowsFailedV1841", "1")
                self._info_tv_defer_focus = False
                if not preserve_previous_surface:
                    self._info_clear_property_all("PlexKM.Info.InlineActive")
                    pkm_transition_manager.cancel_info_transition(self)
                    self._restore_inline_info_origin_focus(reason="tv_prepare_failed_v1841")
                elif _tv_previous_v1884 is not None:
                    self._info_tv_rows = list(_tv_previous_v1884.get("rows") or [])
                    self._info_tv_seasons = list(_tv_previous_v1884.get("seasons") or [])
                    self._info_tv_season_cards = list(_tv_previous_v1884.get("cards") or [])
                    self._info_tv_selected_season = _tv_previous_v1884.get("selected_season") or ""
                    self._info_tv_season_refresh_payload_v1883 = dict(_tv_previous_v1884.get("refresh_payload") or {})
                    self._info_tv_defer_focus = bool(_tv_previous_v1884.get("defer_focus", False))
                    for _name_v1884, _value_v1884 in (_tv_previous_v1884.get("props") or {}).items():
                        if _value_v1884:
                            self._info_set_property_all(_name_v1884, _value_v1884)
                        else:
                            self._info_clear_property_all(_name_v1884)
                    for _cid_v1884, _state_v1884 in (_tv_previous_v1884.get("controls") or {}).items():
                        try:
                            _items_v1884, _pos_v1884 = _state_v1884
                            _ctrl_v1884 = self.getControl(int(_cid_v1884))
                            _ctrl_v1884.reset()
                            if _items_v1884:
                                _ctrl_v1884.addItems(_items_v1884)
                                if 0 <= int(_pos_v1884) < len(_items_v1884):
                                    _ctrl_v1884.selectItem(int(_pos_v1884))
                        except Exception:
                            pass
                    _log("INLINE_INFO_TV_TRANSACTION_RESTORE_V1884 previous_surface=1 rows=%d" % (
                        len(self._info_tv_rows or [])
                    ))
                else:
                    _log("INLINE_INFO_TV_PREPARE_FAILURE_PRESERVE_UNAVAILABLE_V1884 previous_surface=1", xbmc.LOGWARNING)
            except Exception:
                pass
            _log("INLINE_INFO_TV_PREPARE_FAILED_V1841 action=cancel_transition_restore_previous no_empty_publish=1\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            return False

    def _info_focus_tv_rows_prewarm_v2609(self, data, token_v2508, event=None):
        """Prepare TV episode rows before Info without touching the GUI.

        Local DB wins.  A local miss immediately performs one bounded allLeaves
        request; unlike V2601 there is no deliberate 550ms post-visible sleep.
        Results are stored in the existing prepared-TV payload consumed by the
        atomic Info compose path.
        """
        rk = str((data or {}).get("rating_key") or "").strip()
        sid = str((data or {}).get("section_id") or "").strip()
        ptype = str((data or {}).get("type") or "").strip().lower()
        show_key = rk if ptype in ("show", "tv", "tvshow", "series") else str((data or {}).get("grandparent_rating_key") or "").strip()
        t0 = self._now_ms()
        rows = []
        network = 0
        try:
            if not rk or not sid or not show_key or ptype not in ("show", "tv", "tvshow", "series", "episode", "season"):
                return 0
            try:
                rows = list(_ensure_core().query_episodes_for_show(sid, show_key) or [])
            except Exception:
                rows = []
            if not rows:
                network = 1
                core_mod = _ensure_core()
                items = core_mod.fetch_show_episodes(show_key, sid, upsert=True, timeout=0.60) or []
                rows = [core_mod.row_from_item_dict(x) for x in items if x]
            if token_v2508 != int(getattr(self, "_cast_focus_idle_token_v1642", 0) or 0):
                _log("INFO_TV_FOCUS_PREWARM_DROP_V2609 rating_key=%s rows=%d network=%d reason=focus_moved" % (rk, len(rows), network))
                return 0
            if rows:
                payload = {
                    "rating_key": rk, "section_id": sid, "show_key": show_key,
                    "rows": list(rows), "season_cards": [], "refresh_payload": {},
                }
                with self._info_atomic_asset_lock_v2609:
                    self._info_prepared_tv_payload_v2510 = payload
                    cache = getattr(self, "_info_tv_rows_memory_cache_v2351", None)
                    if not isinstance(cache, dict):
                        cache = {}
                        self._info_tv_rows_memory_cache_v2351 = cache
                    cache["%s:%s" % (sid, show_key)] = {"ts": time.time(), "rows": list(rows)}
                # Warm the five cards most likely to be shown if this focused
                # TV item is opened. This uses the same persistent cache as the
                # Info rail and performs no GUI mutation.
                thumb_rows = list(rows)
                if ptype == "episode" and rk:
                    try:
                        selected_index = 0
                        selected_season = ""
                        for idx, row in enumerate(rows):
                            rr = tuple(row or ())
                            if str((rr[0] if rr else "") or "") == rk:
                                selected_index = idx
                                selected_season = str((rr[19] if len(rr) > 19 else "") or "")
                                break
                        same_season = [
                            row for row in rows
                            if str((tuple(row)[19] if len(tuple(row)) > 19 else "") or "") == selected_season
                        ] if selected_season else list(rows)
                        local_index = 0
                        for idx, row in enumerate(same_season):
                            rr = tuple(row or ())
                            if str((rr[0] if rr else "") or "") == rk:
                                local_index = idx
                                break
                        start_index = max(0, local_index - 2)
                        window = list(same_season[start_index:start_index + 5])
                        rest = list(same_season[:start_index]) + list(same_season[start_index + 5:])
                        thumb_rows = window + rest
                    except Exception:
                        thumb_rows = list(rows)
                try:
                    thumb_map, thumb_visible, thumb_ready = self._info_tv_prepare_visible_episode_local_thumbs_v1791(
                        thumb_rows,
                        max_wait_ms=650,
                        allow_download=True,
                    )
                    _log(
                        "INFO_TV_THUMB_FOCUS_PREWARM rating_key=%s show=%s visible=%d ready=%d elapsed_ms=%d gui_mutation=0" % (
                            rk, show_key, thumb_visible, thumb_ready, self._now_ms() - t0
                        )
                    )
                except Exception:
                    _log(
                        "INFO_TV_THUMB_FOCUS_PREWARM_FAILED rating_key=%s show=%s err=%s" % (
                            rk, show_key, traceback.format_exc().replace(chr(10), " | ")
                        ),
                        xbmc.LOGWARNING,
                    )

                _log("INFO_TV_FOCUS_PREWARM_READY_V2609 rating_key=%s show=%s rows=%d network=%d elapsed_ms=%d gui_mutation=0" % (
                    rk, show_key, len(rows), network, self._now_ms() - t0
                ))
                return len(rows)
            _log("INFO_TV_FOCUS_PREWARM_EMPTY_V2609 rating_key=%s show=%s network=%d elapsed_ms=%d" % (
                rk, show_key, network, self._now_ms() - t0
            ))
            return 0
        except Exception:
            _log("INFO_TV_FOCUS_PREWARM_FAILED_V2609 rating_key=%s show=%s elapsed_ms=%d err=%s" % (
                rk, show_key, self._now_ms() - t0, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return 0
        finally:
            try:
                if event is not None:
                    event.set()
            except Exception:
                pass
