# PlexKM entry stub (R332): the 11k-line router lives in resources/lib/pkm_default_impl.py so Kodi
# can use its cached bytecode.  A script file itself is recompiled on every RunScript (~0.5 s).
import sys as _sys
from resources.lib import pkm_default_impl as _impl
_sys.modules["default"] = _impl
if __name__ == "__main__":
    _impl._boot331('module_loaded_main')
    _impl.run()
