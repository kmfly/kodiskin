# -*- coding: utf-8 -*-
"""PlexKM 설치 도우미 - 6 pages: 시작 / 구성 설치 / 선택 키 / 서버·라이브러리 / 취향 / 완료."""
import json
import os
import random
import ssl
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
except Exception:  # pragma: no cover
    from urllib2 import Request, urlopen, HTTPError

from resources.lib import dialogs
from resources.lib import posters
from resources.lib.taste_data import CATEGORIES

ADDON = xbmcaddon.Addon()
PKM_ID = "plugin.video.km"
SKIN_ID = "skin.plex.km"
ACTION_BACK = (9, 10, 92, 216, 247, 257, 275)
ACTION_UP = 3
ACTION_DOWN = 4

STEPS = ["시작", "구성 설치", "선택 키 입력", "서버·라이브러리", "취향 선택", "완료"]
TITLES = [
    ("PlexKM 설치 도우미", "몇 가지 정보만 입력하면 나머지는 자동으로 설치하고 설정합니다."),
    ("필요한 구성을 설치합니다", "필요한 애드온과 유튜브·인풋스트림을 한 번에 설치합니다. 확인 창은 자동으로 승인됩니다."),
    ("선택 키를 입력합니다", "자막·유튜브 키는 항목을 선택하고 확인 키를 눌러 진행합니다. 유튜브에 로그인하면 트레일러 화질이 좋아집니다. 건너뛰어도 됩니다."),
    ("서버와 라이브러리를 설정합니다", "Plex 연결, 사용자, 라이브러리 선택과 동기화는 PlexKM이 이어서 안내합니다."),
    ("좋아하는 영화와 드라마를 골라 주세요", "고르면 내 취향 추천이, 건너뛰면 무작위 추천이 만들어집니다."),
    ("설치가 끝났습니다", "PlexKM 스킨으로 전환하면 바로 사용할 수 있습니다."),
]
NEXT = ["시작하기", "다음: 선택 키 입력", "다음: 서버·라이브러리", "다음: 취향 선택", "취향 저장", "PlexKM 스킨으로 전환"]

INSTALLS = [
    (PKM_ID, "PlexKM 플러그인 (평점·배우 서비스, TMDb Helper 포함)", True),
    (SKIN_ID, "PlexKM 스킨", True),
    ("plugin.video.youtube", "YouTube 애드온 (트레일러·관련 영상)", False),
    ("inputstream.adaptive", "인풋스트림 어댑티브 (고화질 재생)", False),
]


def enable_addon(aid):
    """Make sure an installed addon is enabled (inputstream.adaptive is often installed but disabled)."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
            return
        if xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % aid):
            return
        xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                        "params": {"addonid": aid, "enabled": True}}))
    except Exception:
        pass


def preset_youtube():
    """Pick the YouTube add-on's own first-run choices (device capabilities, ISA, 4K) so its Kodi-style wizard never shows."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            return
        a = xbmcaddon.Addon("plugin.video.youtube")
        if a.getSettingInt("kodion.setup_wizard.forced_runs") >= 1767970800 and not a.getSettingBool("kodion.setup_wizard"):
            return
        for fn, key, val in (
            (a.setSettingBool, "kodion.video.quality.isa", True),
            (a.setSettingBool, "kodion.mpd.videos", True),
            (a.setSettingInt, "kodion.mpd.stream.select", 3),
            (a.setSettingInt, "kodion.mpd.quality.selection", 6),
            (a.setSettingInt, "kodion.content.max_per_page", 50),
            (a.setSettingStringList, "kodion.mpd.stream.features",
             ["avc1", "vp9", "hdr", "hfr", "3d", "vr", "prefer_dub", "prefer_auto_dub", "no_hfr_max", "vorbis", "mp4a",
              "ssa", "ac-3", "ec-3", "dts", "vtt", "filter"]),
            (a.setSettingInt, "kodion.setup_wizard.forced_runs", 1767970800),
            (a.setSettingBool, "kodion.setup_wizard", False),
        ):
            try:
                fn(key, val)
            except Exception:
                log("youtube preset failed %s" % key, xbmc.LOGWARNING)
        log("youtube preset applied (4K, ISA on, wizard off)")
    except Exception:
        log("youtube preset error %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


YT_FILES = ("youtube_settings_r79.json", "youtube_subs_r79.json", "youtube_account_r79.json", "youtube_account_subs_r79.json")


def restore_youtube_backup():
    """After a reset / Kodi reinstall: bring back the YouTube key + login that PlexKM backed up outside Kodi.
    Returns True when something was restored."""
    try:
        prof = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km")
        sp = os.path.join(prof, "youtube_settings_r79.json")
        if os.path.exists(sp):
            with open(sp, "rb") as f:
                if str(json.loads(f.read().decode("utf-8")).get("api_key") or "").strip():
                    return False
        cands = [os.path.join(b, "PKM", "pkm_youtube_backup.json") for b in ("/storage/emulated/0/Download", "/sdcard/Download")]
        cands.append(os.path.join(xbmcvfs.translatePath("special://home/pkm_backup"), "pkm_youtube_backup.json"))
        for c in cands:
            if not os.path.exists(c):
                continue
            with open(c, "rb") as f:
                pl = json.loads(f.read().decode("utf-8"))
            d = pl.get("data") if isinstance(pl, dict) and pl.get("format") == "pkm-youtube-backup" else None
            if not d or not ((d.get(YT_FILES[0]) or {}).get("api_key") or (d.get(YT_FILES[2]) or {}).get("client_id")):
                continue
            if not os.path.isdir(prof):
                os.makedirs(prof)
            for name in YT_FILES:
                if name in d:
                    with open(os.path.join(prof, name), "wb") as f:
                        f.write(json.dumps(d[name], ensure_ascii=False).encode("utf-8"))
            try:
                sk = str(((d.get("pkm_subdl_r332") or {}).get("api_key")) or "").strip()
                if sk and not (xbmcaddon.Addon("plugin.video.km").getSetting("pkm_subdl_api_key") or "").strip():
                    xbmcaddon.Addon("plugin.video.km").setSetting("pkm_subdl_api_key", sk)
            except Exception:
                log("subdl key restore error %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            log("youtube backup restored from %s" % c)
            return True
    except Exception:
        log("youtube backup restore error %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return False


def backup_unreadable():
    """True when a key backup exists but Kodi may not read it (Android reset the
    'all files access' permission together with the app data)."""
    try:
        for b in ("/storage/emulated/0/Download", "/sdcard/Download"):
            c = os.path.join(b, "PKM", "pkm_youtube_backup.json")
            if os.path.exists(c):
                try:
                    with open(c, "rb") as f:
                        f.read(1)
                    return False
                except Exception:
                    return True
    except Exception:
        pass
    return False


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[PKM SETUP] %s" % msg, level)


def auto_yes(stop_fn, seconds):
    """Kodi raises its own yes/no box for add-on installs and skin changes (default focus 'No').
    The wizard has already asked in PlexKM style, so answer Yes for the user right away."""
    mon = xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < seconds and not stop_fn() and not mon.abortRequested():
        try:
            if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
                log("AUTO_YES kodi confirm")
                xbmc.executebuiltin("SendClick(11)")
                mon.waitForAbort(0.6)
                continue
        except Exception:
            pass
        mon.waitForAbort(0.1)


def pkm_profile():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/" % PKM_ID)


def pkm_setup_completed():
    try:
        with open(os.path.join(pkm_profile(), "state.json"), "r", encoding="utf-8") as f:
            st = json.load(f)
        return bool(st.get("initial_setup_completed_v2562") or st.get("initial_sync_done"))
    except Exception:
        return False


def _own_profile():
    p = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


def load_progress():
    try:
        with open(os.path.join(_own_profile(), "progress.json"), "r", encoding="utf-8") as f:
            return int(json.load(f).get("step", 1))
    except Exception:
        return 1


def save_progress(step):
    try:
        with open(os.path.join(_own_profile(), "progress.json"), "w", encoding="utf-8") as f:
            json.dump({"step": int(step), "ts": int(time.time())}, f)
    except Exception:
        pass


def net_check():
    """(ok, reason). Checks general internet + the KM repository host."""
    for url, what in (("https://github.com", "인터넷"), ("https://kmfly.github.io/kodiskin/", "KM 저장소 서버")):
        try:
            urlopen(Request(url, headers={"User-Agent": "PKM-Setup"}), timeout=7).close()
        except HTTPError:
            pass  # server answered
        except Exception as exc:
            return False, "%s에 연결할 수 없습니다 (%s)" % (what, str(exc)[:60])
    return True, ""


def diagnose_plex():
    """(ok, message) describing what is wrong with the Plex setup, in plain Korean."""
    try:
        a = xbmcaddon.Addon(PKM_ID)
    except Exception:
        return False, "PlexKM 플러그인이 설치되어 있지 않습니다. 2단계에서 설치를 먼저 끝내 주세요."
    url = (a.getSetting("plex_url") or "").strip().rstrip("/")
    token = (a.getSetting("plex_token") or "").strip()
    if not url:
        return False, "Plex 서버 주소가 입력되지 않았습니다."
    if not token:
        return False, "Plex 계정 인증이 끝나지 않았습니다."
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        urlopen(Request(url + "/library/sections", headers={"X-Plex-Token": token, "Accept": "application/xml"}),
                timeout=5, context=ctx).close()
    except HTTPError as exc:
        if exc.code in (401, 403):
            return False, "Plex가 인증을 받아주지 않습니다 (계정 인증을 다시 해 주세요)."
        return False, "Plex 서버가 오류로 응답했습니다 (HTTP %s)." % exc.code
    except Exception as exc:
        return False, "Plex 서버가 응답하지 않습니다 (%s). 주소와 서버 전원, 같은 네트워크인지 확인해 주세요." % url
    if not pkm_setup_completed():
        return False, "서버 연결은 정상입니다. 라이브러리 선택과 동기화가 아직 끝나지 않았습니다."
    return True, "Plex 연결과 라이브러리 설정이 정상입니다."


def save_taste(picks):
    """Stored where PlexKM can read it: <pkm profile>/pkm_taste.json (picks = titles)."""
    path = os.path.join(pkm_profile(), "pkm_taste.json")
    try:
        if not os.path.isdir(pkm_profile()):
            os.makedirs(pkm_profile())
        out = []
        for cname, kind, films in CATEGORIES:
            for title, year in films:
                if title in picks:
                    out.append({"title": title, "year": year, "kind": kind, "category": cname,
                                "poster": posters.cached(title, year)})
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"v": 1, "ts": int(time.time()), "random": not out, "picks": out}, f, ensure_ascii=False, indent=1)
        log("taste saved n=%d" % len(out))
        return True
    except Exception:
        log("taste save failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False


def load_taste():
    try:
        with open(os.path.join(pkm_profile(), "pkm_taste.json"), "r", encoding="utf-8") as f:
            return set(p["title"] for p in json.load(f).get("picks", []))
    except Exception:
        return set()


class SetupWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(SetupWindow, self).__init__(*args, **kwargs)
        self.step = 1
        self.retake = False
        self.cat = 0
        self.picks = load_taste()
        self.view = self._make_view_r331()
        self.install_items = {}
        self.installing = False
        self.install_done = False
        self.handoff_started = False
        self.finish_switch = False
        self._stop = False

    # ---------- lifecycle
    def onInit(self):
        self.refresh_steps()
        self.fill_categories()
        self.goto(self.step)

    def refresh_steps(self):
        lst = self.getControl(200)
        lst.reset()
        for i, name in enumerate(STEPS, 1):
            it = xbmcgui.ListItem(name)
            it.setProperty("num", str(i))
            it.setProperty("cur", "1" if i == self.step else "")
            it.setProperty("done", "1" if i < self.step else "")
            lst.addItem(it)

    def goto(self, n):
        self.step = max(1, min(6, n))
        s = self.step
        save_progress(s)
        self.setProperty("step", str(s))
        self.setProperty("counter", "%d / 6 단계" % s)
        self.setProperty("title", TITLES[s - 1][0])
        self.setProperty("sub", TITLES[s - 1][1])
        self.setProperty("nextlabel", NEXT[s - 1])
        self.setProperty("canback", "1" if s > 1 and not self.retake else "")
        self.setProperty("canskip", "1" if s == 5 else "")
        self.setProperty("skiplabel", "취소" if self.retake else ("나중에 하기" if s == 3 else "건너뛰기"))
        self.refresh_steps()
        if s == 2:
            self.start_install()
        elif s == 3:
            threading.Thread(target=self.key_status_loop).start()
        elif s == 4:
            self.update_handoff()
        elif s == 5:
            self.fill_films()
            threading.Thread(target=self.poster_worker).start()
            self.update_picked()
        self.focus_main()

    def key_status(self):
        sub = yt = ""
        if self.step == 3 and not getattr(self, "_yt_restore_tried", False):
            self._yt_restore_tried = True
            if restore_youtube_backup():
                self.setProperty("sub", "이전에 저장해 둔 유튜브 키와 로그인을 불러왔습니다.")
            elif backup_unreadable():
                self.setProperty("sub", "키 백업을 읽으려면 Kodi에 모든 파일 접근을 허용해주세요.")
        try:
            sub = (xbmcaddon.Addon("plugin.video.km").getSetting("pkm_subdl_api_key") or "").strip()
        except Exception:
            pass
        try:
            p = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/youtube_settings_r79.json")
            if os.path.exists(p):
                with open(p, "rb") as f:
                    yt = str(json.loads(f.read().decode("utf-8")).get("api_key") or "").strip()
        except Exception:
            pass
        self.setProperty("subdl_state", "   ·   저장됨" if sub else "")
        self.setProperty("yt_state", "   ·   저장됨" if yt else "")
        lk = False
        try:
            p2 = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/youtube_account_r79.json")
            if os.path.exists(p2):
                with open(p2, "rb") as f:
                    lk = bool(json.loads(f.read().decode("utf-8")).get("refresh_token"))
        except Exception:
            pass
        if self.step == 3:
            self.setProperty("nextlabel", "다음: 서버·라이브러리" if (sub or yt) else "키 없이 다음: 서버·라이브러리")

    def key_status_loop(self):
        while self.step == 3 and not self._stop:
            self.key_status()
            xbmc.sleep(1500)

    def focus_main(self):
        try:
            self.setFocusId(self.main_focus_id() if self.step in (3, 4, 5) else 102)
        except Exception:
            pass

    def main_focus_id(self):
        return {3: 310, 4: 320, 5: 410}.get(self.step, 102)

    # ---------- actions
    def onAction(self, action):
        aid = action.getId()
        if aid in ACTION_BACK:
            if self.step > 1 and not self.retake:
                self.goto(self.step - 1)
            else:
                self.close()
            return
        # Kodi runs skin navigation first, so fid is already the NEW focus here.
        fid = self.getFocusId()
        prev = getattr(self, "_prev_fid", 0)
        if aid == ACTION_UP and fid == 200 and prev in (100, 101, 102):
            if self.step == 5:
                tgt = 400 if prev == 100 else 410
            elif self.step == 2:
                tgt = 301 if self.getProperty("canretry") else 300
            else:
                tgt = {3: 311, 4: 320}.get(self.step, prev)
            try:
                self.setFocusId(tgt)
                fid = tgt
            except Exception:
                pass
        elif aid == ACTION_DOWN and fid in (100, 101, 102) and prev == 300 and self.getProperty("canretry"):
            try:
                self.setFocusId(301)
                fid = 301
            except Exception:
                pass
        self._prev_fid = fid
        return
        super(SetupWindow, self).onAction(action)

    def onClick(self, cid):
        try:
            if cid == 102:
                self.on_next()
            elif cid == 100:
                self.goto(self.step - 1)
            elif cid == 101:
                if self.retake:
                    self._stop = True
                    self.close()
                else:
                    self.goto(self.step + 1)
            elif cid == 310:
                self.setProperty("sub", "휴대폰 입력 화면을 여는 중입니다")
                xbmc.executebuiltin("RunPlugin(plugin://%s/?action=subdl_key_qr)" % PKM_ID)
                def _clr():
                    xbmc.sleep(4000)
                    if self.getProperty("sub") == "휴대폰 입력 화면을 여는 중입니다":
                        self.setProperty("sub", TITLES[self.step - 1][1])
                threading.Thread(target=_clr).start()
            elif cid == 311:
                self.setProperty("sub", "휴대폰 입력 화면을 여는 중입니다")
                xbmc.executebuiltin("RunPlugin(plugin://%s/?action=youtube_key_qr)" % PKM_ID)
                def _clr2():
                    xbmc.sleep(4000)
                    if self.getProperty("sub") == "휴대폰 입력 화면을 여는 중입니다":
                        self.setProperty("sub", TITLES[self.step - 1][1])
                threading.Thread(target=_clr2).start()
            elif cid == 320:
                self.start_handoff()
            elif cid == 321:
                self.check_plex(show=True)
            elif cid == 301:
                self.start_install(force=True)
            elif cid == 400:
                pass
            elif cid == 410:
                self.toggle_film()
        except Exception:
            log("click failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def on_next(self):
        s = self.step
        if s == 1 and not self.preflight():
            return
        if s == 2 and not self.install_done:
            if not dialogs.yesno("PlexKM 설치 도우미", "설치가 아직 끝나지 않았습니다.[CR]그래도 다음으로 갈까요?", yes="그래도 다음으로", no="돌아가기", default_yes=False):
                return
        if s == 4:
            ok = self.check_plex()
            msg = self.getProperty("handnote")
            if not ok:
                if not dialogs.yesno("서버·라이브러리 설정", "%s[CR][CR]나중에 PlexKM 설정에서 다시 할 수 있습니다. 다음으로 갈까요?" % msg,
                                     yes="다음으로", no="다시 확인", default_yes=False):
                    return
        if s == 5:
            save_taste(self.picks)
            if self.retake:
                self._stop = True
                self.close()
                return
        if s == 6:
            self.switch_skin()
            return
        self.goto(s + 1)

    def preflight(self):
        """Internet/repository check before installing. True = go on."""
        while True:
            self.setProperty("sub", "연결을 확인하는 중입니다")
            ok, why = net_check()
            self.setProperty("sub", TITLES[0][1])
            if ok:
                return True
            choice = dialogs.choose(
                "연결 확인", "%s[CR]인터넷과 KM 저장소 연결이 필요합니다.[CR]이미 설치를 마친 기기라면 그대로 진행할 수도 있습니다." % why,
                ["다시 시도", "그대로 진행", "종료"], 0)
            if choice == 0:
                continue
            if choice == 1:
                return True
            self.close()
            return False

    def check_plex(self, show=False):
        t0 = time.time()
        self.setProperty("checkbusy", "확인 중 · ")
        try:
            ok, msg = diagnose_plex()
        finally:
            self.setProperty("checkbusy", "")
        log("check_plex ok=%s ms=%d" % (ok, int((time.time() - t0) * 1000)))
        self.setProperty("handnote", msg)
        if show and not ok:
            dialogs.ok("서버·라이브러리 상태", msg)
        return ok

    # ---------- step 2: install
    def start_install(self, force=False):
        self.setProperty("canretry", "")
        lst = self.getControl(300)
        lst.reset()
        self.install_items = {}
        for aid, label, _req in INSTALLS:
            it = xbmcgui.ListItem(label)
            has = xbmc.getCondVisibility("System.HasAddon(%s)" % aid)
            it.setProperty("st", "done" if has else "wait")
            it.setLabel2("설치됨" if has else "대기")
            lst.addItem(it)
            self.install_items[aid] = it
        if self.installing:
            return
        self.install_done = all(xbmc.getCondVisibility("System.HasAddon(%s)" % a) for a, _l, r in INSTALLS if r)
        if self.install_done:
            preset_youtube()
            self.setProperty("sub", "필요한 구성이 이미 설치되어 있습니다. 다음으로 이동하세요.")
            return
        self.installing = True
        threading.Thread(target=auto_yes, args=(lambda: not self.installing or self._stop, 1800)).start()
        threading.Thread(target=self.install_worker).start()

    def _mark(self, aid, st, text):
        it = self.install_items.get(aid)
        if it is not None:
            it.setProperty("st", st)
            it.setLabel2(text)

    def install_worker(self):
        mon = xbmc.Monitor()
        ok_all = True
        try:
            net_ok, net_why = net_check()
            for aid, _label, required in INSTALLS:
                if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                    enable_addon(aid)
                    self._mark(aid, "done", "설치됨")
                    continue
                if not net_ok:
                    self._mark(aid, "fail" if required else "wait", "인터넷 연결 안 됨")
                    if required:
                        ok_all = False
                    continue
                self._mark(aid, "now", "설치 중")
                xbmc.executebuiltin("InstallAddon(%s)" % aid)
                t0 = time.time()
                while time.time() - t0 < 300 and not self._stop and not mon.abortRequested():
                    if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                        break
                    mon.waitForAbort(1.0)
                if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                    enable_addon(aid)
                    self._mark(aid, "done", "설치됨")
                else:
                    has_repo = xbmc.getCondVisibility("System.HasAddon(repository.km)") or xbmc.getCondVisibility("System.HasAddon(repository_omega.km)")
                    why = "저장소 미설치" if not has_repo else "확인 창에서 취소했거나 시간 초과"
                    self._mark(aid, "fail" if required else "wait", why if required else "건너뜀")
                    if required:
                        ok_all = False
                if self._stop:
                    return
        finally:
            self.installing = False
            preset_youtube()
        self.install_done = ok_all
        if ok_all and not self._stop and self.step == 2:
            self.setProperty("sub", "설치가 끝났습니다. 다음으로 이동하세요.")
            try:
                self.setFocusId(102)
            except Exception:
                pass
        elif not ok_all:
            self.setProperty("sub", "일부 설치에 실패했습니다. 이유를 확인하고 '실패한 항목 다시 시도'를 눌러 주세요.")
            self.setProperty("canretry", "1")

    # ---------- step 4: hand-off to PlexKM's own first-run flow
    def update_handoff(self):
        if pkm_setup_completed():
            self.setProperty("handoff", "설정 완료됨 (다시 열려면 확인)")
            self.setProperty("handnote", "서버 연결과 라이브러리 설정이 이미 끝났습니다. 다음으로 이동하세요.")
        else:
            self.setProperty("handoff", "PlexKM 서버·라이브러리 설정 시작")
            self.setProperty("handnote", "버튼을 누르면 Plex 주소 입력, 계정 인증, 사용자와 라이브러리 선택,[CR]동기화를 차례로 안내합니다.[CR]끝나면 이 화면으로 돌아와 [B]다음[/B]을 누르세요.")

    def start_handoff(self):
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % PKM_ID):
            dialogs.ok("PlexKM 설치 도우미", "PlexKM 플러그인이 아직 설치되지 않았습니다.[CR]이전 단계에서 설치를 먼저 끝내 주세요.")
            return
        self.setProperty("sub", "PlexKM 설정을 여는 중입니다")
        xbmc.executebuiltin("RunPlugin(plugin://%s/?action=pkm_settings)" % PKM_ID)
        threading.Thread(target=self.handoff_watch).start()

    def handoff_watch(self):
        mon = xbmc.Monitor()
        t0 = time.time()
        while time.time() - t0 < 3600 and not self._stop and not mon.abortRequested():
            if pkm_setup_completed():
                if self.step == 4:
                    self.update_handoff()
                return
            mon.waitForAbort(2.0)

    # ---------- step 5: taste
    def _make_view_r331(self):
        """Per category: show up to 10 titles; picked ones always stay, rest random."""
        out = []
        for cname, kind, films in CATEGORIES:
            picked = [f for f in films if f[0] in self.picks][:10]
            rest = [f for f in films if f not in picked]
            random.shuffle(rest)
            out.append((cname, kind, (picked + rest)[:10]))
        return out

    def fill_categories(self):
        lst = self.getControl(400)
        lst.reset()
        for cname, _k, films in self.view:
            n = sum(1 for t, _y in films if t in self.picks)
            it = xbmcgui.ListItem(cname)
            it.setLabel2(str(n) if n else "")
            lst.addItem(it)

    def fill_films(self):
        pan = self.getControl(410)
        pan.reset()
        cname, kind, films = self.view[self.cat]
        for title, year in films:
            it = xbmcgui.ListItem(title)
            p = posters.cached(title, year)
            if p:
                it.setArt({"thumb": p})
            it.setProperty("sel", "1" if title in self.picks else "")
            it.setProperty("year", str(year))
            pan.addItem(it)

    def poster_worker(self):
        cname, kind, films = self.view[self.cat]
        cat = self.cat
        for title, year in films:
            if self._stop or cat != self.cat or self.step != 5:
                return
            if not posters.cached(title, year):
                posters.fetch(title, year, kind)
        if cat == self.cat and self.step == 5:
            self.refresh_posters()

    def refresh_posters(self):
        try:
            pan = self.getControl(410)
            _c, _k, films = self.view[self.cat]
            for i, (title, year) in enumerate(films):
                p = posters.cached(title, year)
                if p and i < pan.size():
                    pan.getListItem(i).setArt({"thumb": p})
        except Exception:
            pass

    def onFocus(self, cid):
        pass

    def toggle_film(self):
        pan = self.getControl(410)
        pos = pan.getSelectedPosition()
        _c, _k, films = self.view[self.cat]
        if pos < 0 or pos >= len(films):
            return
        title = films[pos][0]
        if title in self.picks:
            self.picks.discard(title)
        else:
            self.picks.add(title)
        pan.getListItem(pos).setProperty("sel", "1" if title in self.picks else "")
        cl = self.getControl(400)
        n = sum(1 for t, _y in films if t in self.picks)
        cl.getListItem(self.cat).setLabel2(str(n) if n else "")
        self.update_picked()

    def update_picked(self):
        n = len(self.picks)
        self.setProperty("picked", "선택하지 않으면 다양한 작품이 무작위로 추천됩니다. 나중에 다시 고를 수 있습니다." if n == 0 else "%d개 선택됨 · 몇 개만 골라도 괜찮습니다" % n)

    def onAction_cat_poll(self):
        pass

    # ---------- step 6
    def switch_skin(self):
        self._stop = True
        save_progress(1)
        try:
            if not os.path.exists(os.path.join(pkm_profile(), "pkm_taste.json")):
                save_taste(self.picks)  # skipped taste: mark the helper as finished
        except Exception:
            pass
        try:
            self.close()
        except Exception:
            pass
        threading.Thread(target=auto_yes, args=(lambda: False, 25)).start()
        xbmc.sleep(300)
        try:
            xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                                            "params": {"setting": "lookandfeel.skin", "value": SKIN_ID}}))
        except Exception:
            log("skin switch failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


class _CatWatcher(object):
    """Category list has no click side effect; follow focus to fill the film panel."""

    def __init__(self, win):
        self.win = win

    def run(self):
        mon = xbmc.Monitor()
        last = -1
        while not self.win._stop and not mon.abortRequested():
            try:
                if self.win.step == 5 and self.win.getFocusId() in (400, 410):
                    pos = self.win.getControl(400).getSelectedPosition()
                    if pos >= 0 and pos != self.win.cat:
                        self.win.cat = pos
                        self.win.fill_films()
                        threading.Thread(target=self.win.poster_worker).start()
            except Exception:
                pass
            mon.waitForAbort(0.12)


def run(start=1, retake=False):
    path = ADDON.getAddonInfo("path")
    win = SetupWindow("pkm_setup.xml", path, "Default", "1080i")
    if start == 1:
        saved = load_progress()
        if saved > 1 and dialogs.yesno("PlexKM 설치 도우미", "이전에 %d단계(%s)까지 진행했습니다.[CR]이어서 할까요?" % (saved, STEPS[min(saved, 6) - 1]),
                                       yes="이어서", no="처음부터"):
            start = saved
    win.retake = bool(retake)
    win.step = start
    watcher = _CatWatcher(win)
    th = threading.Thread(target=watcher.run)
    th.daemon = True
    th.start()
    try:
        xbmcgui.Window(10000).setProperty("PlexKM.SetupHelperOpen", "1")
    except Exception:
        pass
    try:
        from . import notify_mute
        notify_mute.mute()
    except Exception:
        notify_mute = None
    try:
        win.doModal()
    finally:
        try:
            if notify_mute is not None:
                notify_mute.restore()
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.SetupHelperOpen")
        except Exception:
            pass
    win._stop = True
    del win
