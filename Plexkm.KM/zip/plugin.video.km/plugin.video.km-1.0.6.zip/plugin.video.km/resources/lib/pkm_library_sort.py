# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import calendar
import json
import re
import time

"""
PKM library wall sort helpers.

This module is intentionally data-only:
- no Kodi focus/navigation control
- no WindowXML control access
- no DB execution

WindowXML/Python UI code calls these helpers to calculate sort labels, arrows,
cache keys, poster metadata text, and SQL ORDER BY fragments.
"""

MOVIE_SORT_OPTIONS = (
    ("title", "제목별"),
    ("added", "최신순"),
    ("year", "연도별"),
    ("release", "개봉일"),
    ("cine21", "씨네21 평점"),
    ("watcha", "왓챠 평점순"),
    ("imdb", "IMDb 평점"),
    ("progress", "진행상황"),
    ("viewed", "감상한 날짜"),
    ("resolution", "해상도"),
    ("bitrate", "비트레이트"),
    ("random", "무작위"),
)

TV_SORT_OPTIONS = (
    ("title", "제목별"),
    ("added", "최신순"),
    ("year", "연도별"),
    ("first_air", "첫 방영일"),
    ("recent_air", "최근 방영순"),
    ("tmdb", "TMDB 평점"),
    ("progress", "진행상황"),
    ("unwatched", "미시청 에피소드"),
    ("viewed", "감상한 날짜"),
    ("seasons", "시즌 수"),
    ("status", "방영 상태"),
    ("random", "무작위"),
)

# Backward-compatible movie default for old callers that do not pass a media kind.
SORT_OPTIONS = MOVIE_SORT_OPTIONS

SORT_ALIASES = {
    "name": "title",
    "dateadded": "added",
    "updated": "added",
    "recent": "added",
    "lastviewed": "viewed",
    "recentlyviewed": "viewed",
    "randomly": "random",
    "rand": "random",
    "shuffle": "random",
    "released": "release",
    "originallyavailable": "release",
    "firstaired": "first_air",
    "firstair": "first_air",
    "recentaired": "recent_air",
    "recentair": "recent_air",
    "unviewed": "unwatched",
    "unwatchedepisodes": "unwatched",
    "seasoncount": "seasons",
    "showstatus": "status",
}

_ALL_SORT_KEYS = set([key for key, _label in MOVIE_SORT_OPTIONS + TV_SORT_OPTIONS])

# v1911: one fixed button is sized from the longest TV label
# ("미시청 에피소드"). XML gives the text 184px and keeps a separate arrow field.
SORT_BOX_WIDTHS = {key: "240" for key in _ALL_SORT_KEYS}


def normalize_media_kind(media_kind):
    value = str(media_kind or "").strip().lower()
    return "tv" if value in ("tv", "show", "tvshow", "series", "episode", "season") else "movie"


def sort_options(media_kind="movie"):
    return list(TV_SORT_OPTIONS if normalize_media_kind(media_kind) == "tv" else MOVIE_SORT_OPTIONS)


def valid_sort_keys(media_kind="movie"):
    return tuple([key for key, _label in sort_options(media_kind)])


def normalize_sort_key(sort_key, media_kind=None):
    try:
        key = str(sort_key or "").strip().lower()
    except Exception:
        key = ""
    key = SORT_ALIASES.get(key, key)
    if media_kind is None:
        return key if key in _ALL_SORT_KEYS else "title"
    valid = set(valid_sort_keys(media_kind))
    return key if key in valid else "title"


def normalize_sort_dir(sort_dir):
    value = str(sort_dir or "").strip().lower()
    return "desc" if value in ("desc", "descending", "down") else "asc"


def default_sort_dir(sort_key):
    key = normalize_sort_key(sort_key)
    if key == "title":
        return "asc"
    return "desc"


def sort_label(sort_key, media_kind="movie"):
    key = normalize_sort_key(sort_key, media_kind=media_kind)
    for candidate, label in sort_options(media_kind):
        if candidate == key:
            return label
    return "제목별"


def sort_box_width(sort_key, media_kind="movie"):
    key = normalize_sort_key(sort_key, media_kind=media_kind)
    return SORT_BOX_WIDTHS.get(key, "240")


def sort_arrow(sort_dir):
    return "▼" if normalize_sort_dir(sort_dir) == "desc" else "▲"


def sort_state(sort_key, sort_dir=None, media_kind="movie"):
    key = normalize_sort_key(sort_key, media_kind=media_kind)
    direction = normalize_sort_dir(sort_dir if sort_dir else default_sort_dir(key))
    return {
        "key": key,
        "dir": direction,
        "label": sort_label(key, media_kind=media_kind),
        "arrow": sort_arrow(direction),
        "box_width": sort_box_width(key, media_kind=media_kind),
        "media_kind": normalize_media_kind(media_kind),
    }


def cache_key(section_id, sort_key, sort_dir):
    return "%s|sort=%s|dir=%s" % (
        str(section_id or "").strip(),
        normalize_sort_key(sort_key),
        normalize_sort_dir(sort_dir),
    )


def next_sort_key(current_sort_key, media_kind="movie"):
    keys = list(valid_sort_keys(media_kind))
    current = normalize_sort_key(current_sort_key, media_kind=media_kind)
    try:
        idx = keys.index(current)
    except Exception:
        idx = 0
    return keys[(idx + 1) % len(keys)]


def toggle_sort_dir(sort_dir):
    cur = normalize_sort_dir(sort_dir)
    return "asc" if cur == "desc" else "desc"


# Library poster title helper. The title stays one line. XML clips it inside
# the normal poster width and scrolls the full title only in focusedlayout.
def no_ellipsis_text(value):
    """Remove ellipsis glyphs/sequences from non-plot UI text."""
    try:
        text = str(value or "")
    except Exception:
        text = ""
    text = text.replace("…", " ").replace("⋯", " ")
    text = re.sub(r"\.{2,}", " ", text)
    return " ".join(text.split()).strip()


# NotoSansKR-Medium 23px conservative advances for printable ASCII.
# Each value includes one extra safety pixel. Non-ASCII glyphs use a safe 23px.
_ASCII_ADVANCE_23 = (
    7, 9, 13, 15, 15, 23, 18, 8, 10, 10, 13, 15, 8, 10, 8, 10,
    15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 8, 8, 15, 15, 15, 13,
    24, 16, 17, 16, 18, 15, 15, 18, 19, 9, 14, 17, 14, 21, 18, 19,
    16, 19, 17, 15, 16, 18, 15, 22, 15, 14, 15, 10, 10, 10, 15, 14,
    16, 15, 16, 13, 16, 15, 9, 15, 16, 8, 8, 15, 8, 23, 16, 16,
    16, 16, 11, 13, 11, 16, 14, 21, 14, 14, 13, 10, 8, 10, 15,
)


def _title_char_advance_23(ch):
    try:
        code = ord(ch)
    except Exception:
        return 23
    if 32 <= code <= 126:
        return _ASCII_ADVANCE_23[code - 32]
    # Combining marks and zero-width joiners do not consume a full glyph cell.
    if 0x0300 <= code <= 0x036F or code in (0x200B, 0x200C, 0x200D, 0xFE0F):
        return 0
    return 23


def clip_title_no_ellipsis(value, max_width=232):
    """Fit the non-focused title without asking Kodi to synthesize an ellipsis.

    The focused layout receives the untouched full title and scrolls it. The
    normal layout receives only a clean prefix that is conservatively bounded
    inside the 240px poster width.
    """
    text = no_ellipsis_text(value)
    used = 0
    out = []
    for ch in text:
        advance = _title_char_advance_23(ch)
        if out and used + advance > int(max_width):
            break
        if not out and advance > int(max_width):
            break
        out.append(ch)
        used += advance
    return "".join(out).rstrip()


def wall_title_layout(value):
    full = no_ellipsis_text(value)
    return {"line1": clip_title_no_ellipsis(full), "full": full}


def sort_raw_values(raw_json):
    try:
        data = json.loads(raw_json or "{}")
    except Exception:
        data = {}
    try:
        bitrate = float(data.get("bitrate") or 0)
    except Exception:
        bitrate = 0.0
    rating = ""
    for key in ("rating", "audienceRating", "userRating"):
        if data.get(key) not in (None, ""):
            rating = str(data.get(key))
            break
    return {
        "release": str(data.get("originallyAvailableAt") or "").strip(),
        "resolution": str(data.get("videoResolution") or data.get("height") or "").strip(),
        "height": str(data.get("height") or "").strip(),
        "bitrate": bitrate,
        "rating": rating,
        "status": str(data.get("status") or data.get("showStatus") or "").strip(),
    }


def parse_tv_sort_meta(raw_json):
    try:
        data = json.loads(raw_json or "{}")
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _full_epoch_date(value):
    try:
        stamp = int(float(value or 0))
        if stamp <= 0:
            return ""
        tm = time.localtime(stamp)
        return "%04d.%02d.%02d" % (int(tm.tm_year), int(tm.tm_mon), int(tm.tm_mday))
    except Exception:
        return ""


def _relative_time_text(value, now=None):
    """Natural Korean age text: exact hours, days under 10, then weeks/months."""
    try:
        stamp = int(float(value or 0))
    except Exception:
        stamp = 0
    if stamp <= 0:
        return ""
    try:
        current = int(float(now if now is not None else time.time()))
    except Exception:
        current = int(time.time())
    age = max(0, current - stamp)
    hour = 60 * 60
    day = 24 * hour
    if age < hour:
        return "방금 전"
    if age < day:
        return "%d시간 전" % max(1, int(age // hour))
    days = int(age // day)
    if days == 1:
        return "하루 전"
    if days < 10:
        return "%d일 전" % days
    if days < 28:
        return "%d주 전" % max(1, int(days // 7))
    if days < 365:
        return "%d달 전" % max(1, int(days // 30))
    return "%d년 전" % max(1, int(days // 365))


def _date_text_to_epoch(value):
    text = str(value or "").strip()
    match = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", text)
    if not match:
        return 0
    try:
        year, month, day = [int(match.group(i)) for i in (1, 2, 3)]
        return int(calendar.timegm((year, month, day, 0, 0, 0)))
    except Exception:
        return 0


def _date_num_to_text(value):
    try:
        number = int(float(value or 0))
    except Exception:
        number = 0
    if number <= 0:
        return ""
    text = "%08d" % number
    try:
        return "%s-%s-%s" % (text[0:4], text[4:6], text[6:8])
    except Exception:
        return ""


def _relative_air_text(value):
    text = _date_num_to_text(value) if str(value or "").strip().isdigit() else str(value or "").strip()
    stamp = _date_text_to_epoch(text)
    relative = _relative_time_text(stamp) if stamp > 0 else ""
    return ("%s 방영" % relative) if relative else ""


def _release_month_text(value, fallback_year="", tv=False):
    text = str(value or "").strip()
    match = re.match(r"^(\d{4})-(\d{1,2})(?:-(\d{1,2}))?", text)
    suffix = "첫방" if tv else "개봉"
    if match:
        year = int(match.group(1))
        month = int(match.group(2))
        if 1 <= month <= 12:
            return "%d.%d월 %s" % (year, month, suffix)
    try:
        year = int(float(fallback_year or 0))
    except Exception:
        year = 0
    return ("%d년 %s" % (year, suffix)) if year > 0 else ""


def _rating_text(value):
    try:
        score = float(value or 0)
        if score <= 0:
            return ""
        return "%.1f" % score
    except Exception:
        return ""


def _resolution_text(value, height=""):
    text = str(value or "").strip().lower()
    try:
        numeric_height = int(float(height or 0))
    except Exception:
        numeric_height = 0
    if "4k" in text or "2160" in text or numeric_height >= 2000:
        return "4K UHD"
    if "1080" in text or numeric_height >= 1000:
        return "1080p"
    if "720" in text or numeric_height >= 700:
        return "720p"
    if text == "sd" or numeric_height > 0 or any(token in text for token in ("576", "480", "360", "240")):
        return "SD"
    return ""


def _bitrate_text(value):
    try:
        raw = float(value or 0)
    except Exception:
        raw = 0.0
    if raw <= 0:
        return ""
    mbps = raw / 1000.0 if raw >= 1000.0 else raw
    return "%.1f Mbps" % mbps


def wall_year_text(year):
    try:
        value = int(float(year or 0))
        return str(value) if value > 0 else ""
    except Exception:
        return no_ellipsis_text(year)


def _progress_text(progress_percent=0, is_watched=False):
    try:
        pct = int(max(0, min(100, round(float(progress_percent or 0)))))
    except Exception:
        pct = 0
    if bool(is_watched) or pct >= 100:
        return "감상 완료"
    if pct > 0:
        return "%d%% 시청" % pct
    return "미시청"


def _tv_status_text(value):
    text = str(value or "").strip().lower()
    if not text:
        return ""
    if any(token in text for token in ("ended", "cancel", "canceled", "cancelled", "종영", "완결")):
        return "종영"
    if any(token in text for token in ("returning", "continuing", "in production", "planned", "airing", "방영")):
        return "방영 중"
    return no_ellipsis_text(value)


def wall_sort_meta(sort_key, year="", added_at=0, last_viewed_at=0,
                   release_date="", resolution="", height="", bitrate=0,
                   cine21="", watcha="", imdb="", progress_percent=0,
                   is_watched=False, media_kind="movie", tv_meta=None):
    """Return only the active sort value for the third poster line.

    The year is now a dedicated second line, so title/year/random do not repeat it.
    """
    kind = normalize_media_kind(media_kind)
    key = normalize_sort_key(sort_key, media_kind=kind)
    value = ""
    if key in ("title", "year", "random"):
        return ""

    if kind == "tv":
        meta = dict(tv_meta or {})
        latest_added = meta.get("latest_added_at") or added_at
        latest_viewed = meta.get("latest_viewed_at") or last_viewed_at
        first_air = meta.get("first_air_date") or release_date
        if key == "added":
            value = _relative_time_text(latest_added)
        elif key == "first_air":
            value = _release_month_text(first_air, fallback_year=year, tv=True)
        elif key == "recent_air":
            value = _relative_air_text(meta.get("latest_air_date_num") or meta.get("latest_air_date") or "")
        elif key == "tmdb":
            value = _rating_text(meta.get("tmdb_rating") or imdb)
        elif key == "progress":
            value = _progress_text(meta.get("progress_percent", progress_percent), meta.get("is_watched", is_watched))
        elif key == "unwatched":
            try:
                total = int(meta.get("episode_count") or 0)
                unwatched = int(meta.get("unwatched_count") or 0)
            except Exception:
                total, unwatched = 0, 0
            if total > 0:
                value = "감상 완료" if unwatched <= 0 else "%d화 남음" % unwatched
        elif key == "viewed":
            date = _full_epoch_date(latest_viewed)
            value = ("감상 %s" % date) if date else ""
        elif key == "seasons":
            try:
                count = int(meta.get("season_count") or 0)
            except Exception:
                count = 0
            value = ("시즌 %d" % count) if count > 0 else ""
        elif key == "status":
            value = _tv_status_text(meta.get("status") or "")
        return no_ellipsis_text(value)

    if key == "added":
        value = _relative_time_text(added_at)
    elif key == "release":
        value = _release_month_text(release_date, fallback_year=year, tv=False)
    elif key == "cine21":
        score = _rating_text(cine21)
        value = ("전문가 %s" % score) if score else ""
    elif key == "watcha":
        value = _rating_text(watcha)
    elif key == "imdb":
        value = _rating_text(imdb)
    elif key == "progress":
        value = _progress_text(progress_percent, is_watched)
    elif key == "viewed":
        date = _full_epoch_date(last_viewed_at)
        value = ("감상 %s" % date) if date else ""
    elif key == "resolution":
        value = _resolution_text(resolution, height=height)
    elif key == "bitrate":
        value = _bitrate_text(bitrate)
    return no_ellipsis_text(value)


def order_by(sort_key, sort_dir):
    """Return ORDER BY expression for local movie/general wall query."""
    sort = normalize_sort_key(sort_key)
    desc = normalize_sort_dir(sort_dir) == "desc"
    d = "DESC" if desc else "ASC"
    order_map = {
        "title": "sort_title COLLATE NOCASE %s" % d,
        "name": "sort_title COLLATE NOCASE %s" % d,
        "added": "added_at %s, sort_title COLLATE NOCASE ASC" % d,
        "dateadded": "added_at %s, sort_title COLLATE NOCASE ASC" % d,
        "updated": "updated_at %s, sort_title COLLATE NOCASE ASC" % d,
        "year": "year %s, sort_title COLLATE NOCASE ASC" % d,
        "release": "pkm_sort_num(raw_json,'release') %s, year %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "first_air": "pkm_sort_num(raw_json,'release') %s, year %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "rating": "pkm_sort_num(raw_json,'rating') %s, sort_title COLLATE NOCASE ASC" % d,
        "tmdb": "pkm_sort_num(raw_json,'rating') %s, sort_title COLLATE NOCASE ASC" % d,
        "cine21": "pkm_cine21_score(rating_key) %s, sort_title COLLATE NOCASE ASC" % d,
        "watcha": "pkm_watcha_score(rating_key) %s, sort_title COLLATE NOCASE ASC" % d,
        "imdb": "pkm_imdb_score(rating_key) %s, sort_title COLLATE NOCASE ASC" % d,
        "content_rating": "pkm_content_rating_rank(raw_json) %s, sort_title COLLATE NOCASE ASC" % d,
        "duration": "duration %s, sort_title COLLATE NOCASE ASC" % d,
        # v1915: actual viewOffset lives in resume sidecars. default.py applies
        # final per-rating_key progress ordering after attaching those states.
        "progress": "COALESCE(view_count,0) %s, sort_title COLLATE NOCASE ASC" % d,
        "viewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "lastviewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "recentlyviewed": "last_viewed_at %s, updated_at %s, sort_title COLLATE NOCASE ASC" % (d, d),
        "resolution": "pkm_sort_num(raw_json,'resolution') %s, sort_title COLLATE NOCASE ASC" % d,
        "bitrate": "pkm_sort_num(raw_json,'bitrate') %s, sort_title COLLATE NOCASE ASC" % d,
        "random": "RANDOM()",
    }
    return order_map.get(sort, order_map["title"])
