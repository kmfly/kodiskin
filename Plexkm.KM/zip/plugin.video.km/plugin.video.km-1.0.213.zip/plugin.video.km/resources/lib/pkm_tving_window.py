# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM TVING / OTT screen (V2806, generic add-ons V2807: see pkm_ott).

Opened by the PKM sidebar item "TVING" (only listed when plugin.video.tvingm
is installed) through default.py?action=tving, in its own script like the
YouTube screen (pkm_youtube_window.py), whose frame it follows: collapsed rail
copy on the left, header, chips, Plex-style widget rows.  LEFT at the edge or
Back on the top view closes it; PKM Home is still underneath on "TVING".

Views: main(chip) / program(episodes) / search.  Cached rows paint at once,
stale rows refresh in one worker, one TVING MINI call at a time (it may show
its own login dialogs, so never several at once).  Playback closes this
dialog, lets TVING MINI resolve the stream, and reopens the same view when
playback ends.
"""

import json
import threading
import traceback

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import pkm_tving as tv
from resources.lib import pkm_ott as ott

XML_NAME = "plexkm_tving_v2806.xml"
ROW_SLOTS = 8
RAIL_ID = 8801
CHIPS_ID = 8870
CHIP_CIRCLE_ID = 8871          # search (main view only)
CHIP_FIRST_ID = 8872
CHIP_SLOTS = 10
CHIP_TEXT_IDS = tuple(range(CHIP_FIRST_ID, CHIP_FIRST_ID + CHIP_SLOTS))
CHIP_REFRESH_ID = 8885
CHIP_SETTINGS_ID = 8886
EXIT_ID = 8999
CHIP_BG = "FF272727"
CHIP_BG_SELECTED = "FFF1F1F1"


def _poster_id(slot):
    return 8911 + slot * 20


def _wide_id(slot):
    return 8912 + slot * 20


LIST_IDS = tuple(i for s in range(ROW_SLOTS) for i in (_poster_id(s), _wide_id(s)))
assert not set(LIST_IDS) & (set(CHIP_TEXT_IDS) | {CHIPS_ID, CHIP_CIRCLE_ID, CHIP_REFRESH_ID,
                                                  CHIP_SETTINGS_ID, EXIT_ID, RAIL_ID})

ACTION_PREVIOUS_MENU = 10
ACTION_PARENT_DIR = 9
ACTION_NAV_BACK = 92
BACK_ACTIONS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_PARENT_DIR)
NAV_ACTIONS = (1, 2, 3, 4, 5, 6, 107)   # left/right/up/down/page up/page down/mouse move

PLAY_START_TIMEOUT_SEC = 25


def _log(msg, level=xbmc.LOGINFO):
    tv.log("WIN " + msg, level)


def _addon_path():
    return xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")


def _slot_of(control_id):
    return LIST_IDS.index(control_id) // 2 if control_id in LIST_IDS else -1


class PKMTvingWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._rail = kwargs.pop("rail", None) or []
        self._rail_pos = int(kwargs.pop("rail_pos", 0) or 0)
        self._restore = kwargs.pop("state", None)
        self._prov = ott.get(kwargs.pop("provider", "tving"))
        self._tving = self._prov["id"] == "tving"
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self._lock = threading.RLock()
        self._view = None             # {"kind": main|program|search|folder, ...}
        self._stack = []              # previous views; Back pops
        self._defs = []               # row definitions of the current view
        self._data = {}               # row key -> {"items", "more"}
        self._bound = []              # rows bound to slots: [{"key","shape","items"}]
        self._token = 0               # bumps on every view change; stale workers stop
        self._chip_actions = []
        self._closing = False
        self._focus_first_pending = False
        self.play_request = None      # plugin:// path to play after close

    # ------------------------------------------------------------ lifecycle

    def onInit(self):
        # PKM Home underneath keeps its sidebar expanded on "TVING" (see YouTube R79).
        self.setProperty("PlexKM.Sidebar.Expanded", "1")
        try:
            self._bind_rail()
        except Exception:
            _log("RAIL_BIND_FAILED err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        state, self._restore = self._restore, None
        start = {"kind": "main", "chip": "home" if self._tving else None}
        if state:
            self._stack = list(state.get("stack") or [])
            self._show_view(state.get("view") or start, focus=state.get("focus"))
        else:
            self._show_view(start, focus_first=True)

    def _bind_rail(self):
        ctl = self.getControl(RAIL_ID)
        ctl.reset()
        items = []
        for icon in self._rail:
            li = xbmcgui.ListItem(label="")
            li.setArt({"icon": icon})
            items.append(li)
        if items:
            ctl.addItems(items)
            ctl.selectItem(max(0, min(self._rail_pos, len(items) - 1)))

    def _close(self, reason):
        if self._closing:
            return
        self._closing = True
        self._token += 1
        _log("CLOSE reason=%s view=%s" % (reason, (self._view or {}).get("kind")))
        self.close()

    def export_state(self):
        return {"view": self._view, "stack": self._stack, "focus": self._capture_focus()}

    # ------------------------------------------------------------ chips

    def _set_chips(self, entries, selected=None, main=False):
        """entries: [(action, label)]; the selected chip is drawn filled."""
        self._chip_actions = [a for a, _ in entries][:CHIP_SLOTS]
        for i in range(CHIP_SLOTS):
            label, bg = "", CHIP_BG
            if i < len(entries):
                action, label = entries[i]
                if action == selected:
                    label, bg = "[COLOR FF0F0F0F]%s[/COLOR]" % label, CHIP_BG_SELECTED
            self.setProperty("PKMTV.Chip%d.Label" % i, label)
            self.setProperty("PKMTV.Chip%d.Bg" % i, bg)
        self.setProperty("PKMTV.MainView", "1" if main else "")
        idx = self._chip_actions.index(selected) if selected in self._chip_actions else -1
        self.setProperty("PKMTV.SelectedChip", str(idx) if idx >= 0 else "")

    def _focus_chips(self):
        sel = self.getProperty("PKMTV.SelectedChip")
        self.setFocusId(CHIP_TEXT_IDS[int(sel)] if sel.isdigit() else
                        (CHIP_TEXT_IDS[0] if self._chip_actions else CHIP_REFRESH_ID))

    def _has_rows(self):
        return any(b["items"] for b in self._bound)

    # ------------------------------------------------------------ views

    def _push(self, view):
        if self._view is not None:
            self._view["focus"] = self._capture_focus()
            self._stack.append(self._view)
        self._show_view(view, focus_first=True)

    def _show_view(self, view, focus=None, focus_first=False, force=False):
        self._view = dict(view)
        self._token += 1
        kind = view.get("kind")
        if kind == "program":
            order = tv.episode_order()
            self._set_chips([("sort:desc", "최신화부터"), ("sort:asc", "1회부터")], "sort:%s" % order)
            context = "회차"
            self._defs = tv.episode_rows(view.get("code"))
            self._header(view.get("title"), view.get("meta"), view.get("plot"), view.get("thumb"))
        elif kind == "search":
            self._set_chips([("search", "다시 검색")])
            context = "검색 · %s" % view.get("query", "")
            self._defs = tv.search_rows(view.get("query"))
            self._header("‘%s’ 검색 결과" % view.get("query", ""), "", "", "")
        elif kind == "folder":
            # V2807: a menu folder of a generic add-on (its titles/categories as rows).
            self._set_chips([("back", "‹ 뒤로")])
            context = view.get("title") or ""
            self._defs = ott.folder_defs(self._prov["id"], view.get("path"), view.get("title"))
            self._header(view.get("title"), view.get("meta"), view.get("plot"), view.get("thumb"))
        elif not self._tving:
            # V2807: generic add-on: its own root folders are the chips.
            chips = ott.cached_root_chips(self._prov["id"])
            path = view.get("chip") or (chips[0][0] if chips else "")
            title = dict(chips).get(path, "")
            self._view["chip"] = path
            self._set_chips([("chip:%s" % p, label) for p, label in chips], "chip:%s" % path)
            context = title
            if path:
                self._defs = ott.folder_defs(self._prov["id"], path, title)
            else:
                self._defs = [{"key": ott.root_key(self._prov["id"]), "root": True, "want": view.get("want")}]
            self._header(self._prov["label"], "", "", "")
        else:
            chip = view.get("chip") or "home"
            self._set_chips([("chip:%s" % k, label) for k, label in tv.CHIPS], "chip:%s" % chip, main=True)
            context = tv.CHIP_LABELS.get(chip, "")
            self._defs = tv.rows_for(chip)
            self._header("TVING", "", "", "")
        self.setProperty("PKMTV.Context", "[COLOR %s][B]%s[/B][/COLOR]  ·  %s" % (
            self._prov["color"], self._prov["label"], context))
        if self._tving and not tv.account_set():
            # TVING MINI would pop its own login dialog for every row; ask once here.
            self._bind_rows([])
            self.setProperty("PKMTV.Status", "TVING 로그인이 필요합니다.  오른쪽 위 ⚙ 에서 TVING MINI 계정을 설정하세요.")
            self.setFocusId(CHIP_SETTINGS_ID)
            return
        self.setProperty("PKMTV.Status", "")
        self._focus_first_pending = False
        self._bind_rows(self._rows_from_cache(), focus=focus, focus_first=focus_first)
        if not self._has_rows():
            self.setProperty("PKMTV.Status", "불러오는 중…")
            self._focus_first_pending = bool(focus_first or focus)
            self._focus_chips()
        self._refresh_bg(self._token, force=force)

    def _header(self, title, meta, plot, backdrop):
        self.setProperty("PKMTV.Title", title or "")
        self.setProperty("PKMTV.Meta", meta or "")
        self.setProperty("PKMTV.Plot", plot or "")
        self.setProperty("PKMTV.Backdrop", backdrop or "")

    # ------------------------------------------------------------ rows

    def _rows_from_cache(self):
        rows = []
        for d in self._defs:
            if d.get("expand"):
                cached = tv.cache_get(d["key"])
                for sub in (cached or {}).get("rows") or []:
                    self._data.setdefault(sub["key"], tv.cache_get(sub["key"]) or {})
                    rows.append(dict(sub, **(self._data.get(sub["key"]) or {})))
                continue
            data = self._data.get(d["key"]) or tv.cache_get(d["key"]) or {}
            self._data[d["key"]] = data
            rows.append(dict(d, **data))
        return rows

    def _refresh_bg(self, token, force=False):
        defs = list(self._defs)

        def worker():
            failed_first = True
            just_fetched = set()
            for d in defs:
                if token != self._token or self._closing:
                    return
                try:
                    if d.get("root"):
                        # V2807: generic add-on opened for the first time: learn its menu.
                        chips = ott.fetch_root_chips(self._prov["id"])
                        if token == self._token and not self._closing:
                            if chips:
                                want = d.get("want") if d.get("want") in dict(chips) else chips[0][0]
                                self._show_view({"kind": "main", "chip": want}, focus_first=True)
                            else:
                                self.setProperty("PKMTV.Status", "표시할 메뉴가 없습니다.")
                        return
                    if d.get("expand"):
                        cached = tv.cache_get(d["key"])
                        subs = (cached or {}).get("rows")
                        if force or not subs or not tv.is_fresh(cached):
                            subs = tv.expand_rows(d["expand"], d.get("title", ""),
                                                  d.get("prefix", "dyn"))[:ROW_SLOTS]
                            tv.cache_put(d["key"], {"rows": subs})
                            # expand_rows already stored its direct-titles row
                            just_fetched.update(r["key"] for r in subs if ":items:" in r["key"])
                            if token == self._token and not self._closing:
                                self._bind_rows(self._rows_from_cache(), keep_focus=True)
                        targets = subs
                    else:
                        targets = [d]
                    for row in targets:
                        if token != self._token or self._closing:
                            return
                        cached = tv.cache_get(row["key"])
                        if row["key"] in just_fetched:
                            continue
                        if force or not tv.is_fresh(cached, live=row.get("live")):
                            data = tv.fetch(row["url"], live=row.get("live"))
                            tv.cache_put(row["key"], data)
                            self._data[row["key"]] = data
                            if token == self._token and not self._closing:
                                self._bind_rows(self._rows_from_cache(), keep_focus=True)
                        failed_first = False
                except Exception:
                    _log("ROW_FAILED key=%s err=%s" % (d.get("key"), traceback.format_exc().replace("\n", " | ")),
                         xbmc.LOGWARNING)
                    if failed_first:
                        # First call failed: the add-on is not logged in or unreachable.
                        # Don't fire more calls that would each fail the same way.
                        if token == self._token and not self._has_rows():
                            self.setProperty("PKMTV.Status", "%s 목록을 불러오지 못했습니다.  ⚙ 에서 로그인 상태를 확인하세요."
                                             % self._prov["label"])
                        return
            if token == self._token and not self._closing:
                self._bind_rows(self._rows_from_cache(), keep_focus=True)
                if not self._has_rows():
                    self.setProperty("PKMTV.Status", "표시할 항목이 없습니다.")

        t = threading.Thread(target=worker, name="PKMTvingRowsV2806")
        t.daemon = True
        t.start()

    def _make_item(self, row, pos, it):
        li = xbmcgui.ListItem(label=it.get("title") or "")
        art = it.get("thumb") or ""
        li.setArt({"thumb": art, "poster": art, "fanart": it.get("fanart") or art})
        li.setProperty("PKMTV.Kind", it.get("kind") or "")
        li.setProperty("PKMTV.Meta", it.get("meta") or "")
        li.setProperty("PKMTV.Plot", it.get("plot") or "")
        li.setProperty("PKMTV.Sub", it.get("sub") or "")
        li.setProperty("PKMTV.Live", "1" if it.get("live") else "")
        if row.get("rank") and it.get("kind") != "more":
            li.setProperty("PKMTV.Rank", str(pos + 1))
        return li

    def _row_items(self, row):
        items = list(row.get("items") or [])
        if items and row.get("more"):
            items.append({"kind": "more", "title": "", "file": row["more"]})
        return items

    def _bind_rows(self, rows, focus=None, focus_first=False, keep_focus=False):
        rows = [r for r in rows if r.get("items")][:ROW_SLOTS]
        with self._lock:
            keep = self._capture_focus() if keep_focus else None
            old = self._bound
            self._bound = []
            for slot in range(ROW_SLOTS):
                row = rows[slot] if slot < len(rows) else None
                items = self._row_items(row) if row else []
                wide = bool(row) and self._row_wide(row)
                self._bound.append({"key": (row or {}).get("key"), "shape": "wide" if wide else "poster",
                                    "items": items, "row": row})
                self.setProperty("PKMTV.Row%d.Title" % slot, (row or {}).get("title") or "")
                prev = old[slot] if slot < len(old) else None
                same = (prev is not None and prev["key"] == self._bound[slot]["key"]
                        and prev["shape"] == self._bound[slot]["shape"]
                        and [i.get("file") for i in prev["items"]] == [i.get("file") for i in items])
                if same:
                    continue
                used = self.getControl(_wide_id(slot) if wide else _poster_id(slot))
                other = self.getControl(_poster_id(slot) if wide else _wide_id(slot))
                other.reset()
                used.reset()
                if items:
                    used.addItems([self._make_item(row, pos, it) for pos, it in enumerate(items)])
            if any(b["items"] for b in self._bound):
                self.setProperty("PKMTV.Status", "")
            if self._focus_first_pending and rows and keep is None:
                # opened with nothing cached: first rows arrived while the chips had focus
                self._focus_first_pending = False
                self._focus_slot(0, 0)
            elif keep and keep[0] in LIST_IDS:
                self._restore_focus(keep, quiet=True)
            elif focus:
                self._restore_focus(focus)
            elif focus_first and rows:
                self._focus_slot(0, 0)
        self._remember_focused_item()

    @staticmethod
    def _row_wide(row):
        """TVING rows say their shape; generic rows: episodes/channels wide, titles poster."""
        if row.get("shape"):
            return row["shape"] == "wide"
        items = row.get("items") or []
        plays = [i for i in items if i.get("kind") == "play" and i.get("type") != "movie"]
        return bool(items) and len(plays) * 2 > len(items)

    def _list_id_for(self, slot):
        b = self._bound[slot] if slot < len(self._bound) else None
        if not b or not b["items"]:
            return None
        return _wide_id(slot) if b["shape"] == "wide" else _poster_id(slot)

    def _focus_slot(self, slot, pos):
        lid = self._list_id_for(slot)
        if lid is None:
            return False
        ctl = self.getControl(lid)
        ctl.selectItem(max(0, min(pos, ctl.size() - 1)))
        if self.getFocusId() != lid:
            self.setFocusId(lid)
        return True

    # ------------------------------------------------------------ focus

    def _focused_item(self):
        fid = self.getFocusId()
        slot = _slot_of(fid)
        if slot < 0:
            return None, -1, -1
        try:
            pos = self.getControl(fid).getSelectedPosition()
            return self._bound[slot]["items"][pos], slot, pos
        except Exception:
            return None, slot, -1

    def _remember_focused_item(self):
        it, slot, pos = self._focused_item()
        if it and it.get("kind") != "more":
            # shown while the chips have focus: the last card stays up
            self._header(it.get("title"), it.get("meta"), it.get("plot"), it.get("fanart"))

    def _capture_focus(self):
        it, slot, pos = self._focused_item()
        if slot < 0:
            return None
        return [self.getFocusId(), slot, pos, (self._bound[slot].get("key") if slot < len(self._bound) else None)]

    def _restore_focus(self, focus, quiet=False):
        try:
            fid, slot, pos, key = focus
            for s, b in enumerate(self._bound):
                if key and b.get("key") == key and self._focus_slot(s, pos):
                    return
            if quiet:
                return
            if not self._focus_slot(min(slot, max(0, len(self._bound) - 1)), pos):
                self._focus_chips()
        except Exception:
            if not quiet:
                self._focus_chips()

    # ------------------------------------------------------------ events

    def onFocus(self, control_id):
        if control_id == EXIT_ID:
            self._close("left_edge")

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK_ACTIONS:
            self._back()
            return
        if aid in NAV_ACTIONS:
            self._remember_focused_item()

    def onClick(self, control_id):
        if control_id in LIST_IDS:
            it, slot, pos = self._focused_item()
            if not it:
                return
            if it.get("kind") == "more":
                self._load_more(slot)
            elif it.get("kind") == "folder":
                base = {"title": it.get("title"), "meta": it.get("meta"), "plot": it.get("plot"),
                        "thumb": it.get("fanart")}
                code = self._program_code(it.get("file")) if self._tving else ""
                if code:
                    self._push(dict(base, kind="program", code=code))
                else:
                    self._push(dict(base, kind="folder", path=it.get("file")))
            else:
                self._request_play(it)
            return
        if control_id == CHIP_CIRCLE_ID:
            self._search()
        elif control_id == CHIP_REFRESH_ID:
            if not self._tving and (self._view or {}).get("kind") == "main":
                # the root menu is cached for good; refresh relearns it too
                tv.cache_put(ott.root_key(self._prov["id"]), {"chips": []})
                self._show_view(dict(self._view, chip=None, want=self._view.get("chip")), force=True)
                return
            self._show_view(self._view, focus=self._capture_focus(), force=True)
        elif control_id == CHIP_SETTINGS_ID:
            tv.open_addon_settings(self._prov["addon"])
            # settings may have logged in/out: repaint once it closes
            xbmc.sleep(300)
            while xbmc.getCondVisibility("Window.IsActive(addonsettings)") and not self._closing:
                xbmc.sleep(250)
            self._show_view(self._view, focus=self._capture_focus())
        elif control_id in CHIP_TEXT_IDS:
            try:
                action = self._chip_actions[CHIP_TEXT_IDS.index(control_id)]
            except Exception:
                return
            if action.startswith("chip:"):
                self._show_view({"kind": "main", "chip": action.split(":", 1)[1]})
            elif action == "back":
                self._back()
            elif action.startswith("sort:"):
                tv.set_episode_order(action.split(":", 1)[1])
                self._data.clear()
                self._show_view(self._view, force=True)
            elif action == "search":
                self._search(replace=True)

    def _back(self):
        if not self._stack:
            self._close("back")
            return
        prev = self._stack.pop()
        self._show_view(prev, focus=prev.get("focus"))

    @staticmethod
    def _program_code(path):
        import re
        m = re.search(r"[?&]programcode=([^&]+)", path or "")
        return m.group(1) if m else ""

    def _search(self, replace=False):
        query = xbmcgui.Dialog().input("TVING 검색", (self._view or {}).get("query", "") if replace else "")
        query = (query or "").strip()
        if not query:
            return
        view = {"kind": "search", "query": query}
        if replace and (self._view or {}).get("kind") == "search":
            self._show_view(view, focus_first=True)
        else:
            self._push(view)

    def _load_more(self, slot):
        b = self._bound[slot] if slot < len(self._bound) else None
        row = (b or {}).get("row")
        if not row or not row.get("more"):
            return
        token, key, more = self._token, row["key"], row["more"]
        self.setProperty("PKMTV.Status", "")

        def worker():
            try:
                data = tv.fetch(more, live=row.get("live"))
            except Exception:
                _log("MORE_FAILED key=%s" % key, xbmc.LOGWARNING)
                return
            if token != self._token or self._closing:
                return
            cur = self._data.get(key) or {}
            new = data["items"]
            if ":items:" in key:
                # direct-titles row of a menu folder: later pages may list categories too
                new = [i for i in new if i.get("content")]
            merged = {"items": list(cur.get("items") or []) + new, "more": data["more"]}
            self._data[key] = merged
            tv.cache_put(key, merged)
            self._bind_rows(self._rows_from_cache(), keep_focus=True)
        t = threading.Thread(target=worker, name="PKMTvingMoreV2806")
        t.daemon = True
        t.start()

    def _request_play(self, it):
        self.play_request = it.get("file")
        _log("PLAY title=%s live=%d" % (it.get("title"), 1 if it.get("live") else 0))
        self._close("play")


def _play_and_wait(path):
    """PlayMedia an add-on path; return once playback has ended (or never started)."""
    mon = xbmc.Monitor()
    player = xbmc.Player()
    xbmc.executebuiltin('PlayMedia("%s")' % path)
    started = False
    waited = 0.0
    while not mon.abortRequested() and waited < PLAY_START_TIMEOUT_SEC:
        if player.isPlaying():
            started = True
            break
        if mon.waitForAbort(0.25):
            return False
        waited += 0.25
    if not started:
        _log("PLAY_NOT_STARTED waited_s=%.1f" % waited, xbmc.LOGWARNING)
        return True
    while not mon.abortRequested() and player.isPlaying():
        if mon.waitForAbort(0.5):
            return False
    return not mon.abortRequested()


def open_window(params=None):
    """Entry point for default.py?action=tving / action=ott&id=<provider>."""
    provider = (params or {}).get("id") or "tving"
    rail, rail_pos = [], 0
    try:
        raw = xbmcgui.Window(10000).getProperty("PlexKM.YouTube.RailR79")
        data = json.loads(raw) if raw else {}
        rail = list(data.get("icons") or [])
        rail_pos = int(data.get("pos") or 0)
    except Exception:
        pass
    state = None
    try:
        while True:
            win = PKMTvingWindow(XML_NAME, _addon_path(), "Default", "1080i",
                                 rail=rail, rail_pos=rail_pos, state=state, provider=provider)
            win.doModal()
            path, state = win.play_request, win.export_state()
            del win
            if not path:
                break
            # The modal dialog would sit above the video; play with it closed and
            # come back to the same view afterwards.
            if not _play_and_wait(path):
                break
    finally:
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Sidebar.Expanded", "1")
            xbmc.executebuiltin("SetProperty(PlexKM.Sidebar.Expanded,1,13000)")
        except Exception:
            pass
    return True
