# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM YouTube screen (R79b).

Opened by the PKM sidebar item "유튜브" (OK/Enter only) through
default.py?action=youtube, so it runs in its own script and never blocks the
PKM Home callbacks.  The window covers the content area and mirrors Home's
collapsed rail on the left; LEFT at the left edge or Back closes it and the
PKM sidebar is focused again on "유튜브".

Layout = PKM (header + widget rows that slide like Plex) with YouTube chips:
  [검색] 전체 구독 뉴스 음악 스포츠 게임 라이브 ... [새로고침] [설정]
A chip works like a PKM tab: ENTER swaps the widget rows below it.
Views: main(chip), channel, search.  Cached rows paint immediately;
refreshes run in a worker thread.
"""

import json
import os
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import pkm_youtube as yt
from resources.lib import pkm_youtube_account as acct
from resources.lib import pkm_youtube_backup as backup
from resources.lib.pkm_search_keyboard import SearchKeyboard
from resources.lib.pkm_youtube_keyserver import KeyServer, clean_key, mask_key, write_qr

try:
    from resources.lib import pkm_notify
except Exception:  # pragma: no cover
    pkm_notify = None


def _notice(title, line1="", ms=2600):
    """PKM notice (top-right PKM card), never Kodi's native toast."""
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(title, line1, "", ms=ms):
            return
    except Exception:
        pass
    _log("NOTICE_FALLBACK_LOG_ONLY title=%s line1=%s" % (title, line1))

XML_NAME = "plexkm_youtube_r79.xml"
ROW_SLOTS = 12
CHIPS_ID = 7870            # grouplist of text chips
CHIP_SEARCH_ID = 7871
CHIP_FIRST_ID = 7872
CHIP_SLOTS = 10
CHIP_TEXT_IDS = tuple(range(CHIP_FIRST_ID, CHIP_FIRST_ID + CHIP_SLOTS))
CHIP_REFRESH_ID = 7885
CHIP_SETTINGS_ID = 7886
CHIP_ALL_IDS = (CHIPS_ID, CHIP_SEARCH_ID, CHIP_REFRESH_ID, CHIP_SETTINGS_ID) + CHIP_TEXT_IDS
EXIT_ID = 7999
SEARCH_KB_ID = 7600
SEARCH_HISTORY_ID = 7650
SEARCH_RESULTS_ID = 7700
ITEM_MENU_ID = 7660        # inline PKM popup replacing Kodi's context menu (gen_xml item_menu)
SEARCH_DEBOUNCE_SEC = 0.6
RAIL_ID = 7801
SET_MENU_ID = 7510         # settings panel: menu list
SET_KB_ID = 7520           # settings panel: API key keyboard


ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_PARENT_DIR = 9
ACTION_NAV_BACK = 92
ACTION_CONTEXT_MENU = 117
ACTION_MOUSE_MOVE = 107

BACK_ACTIONS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_PARENT_DIR)


def _log(msg, level=xbmc.LOGINFO):
    yt.log("WIN " + msg, level)


def _list_id(slot):
    return 7911 + slot * 10


LIST_IDS = tuple(_list_id(i) for i in range(ROW_SLOTS))
assert not set(LIST_IDS) & (set(CHIP_ALL_IDS) | {EXIT_ID, RAIL_ID})

def _profile_path():
    try:
        import xbmcvfs
        path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    except Exception:
        path = xbmc.translatePath("special://profile/addon_data/plugin.video.km/")
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


class KeyEntryKeyboard(object):
    """Case-sensitive keyboard for API keys (A-Z / a-z / 0-9, - _)."""

    TAIL = ["-", "_", "Del", "Clear", "저장"]
    PAGES = {
        "ABC": list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["abc", "123"],
        "abc": list("abcdefghijklmnopqrstuvwxyz") + ["ABC", "123"],
        "123": list("1234567890") + ["ABC", "abc"],
    }
    DISPLAY = {"Del": "Delete", "Clear": "지우기"}

    def __init__(self):
        self.page = "ABC"
        self.text = ""

    def keys(self):
        return self.PAGES[self.page] + self.TAIL

    @classmethod
    def label(cls, key):
        return cls.DISPLAY.get(key, key)

    def set_text(self, text):
        self.text = str(text or "")

    def press(self, key):
        if key in self.PAGES:
            self.page = key
            return "page"
        if key == "저장":
            return "done"
        if key == "Del":
            self.text = self.text[:-1]
        elif key == "Clear":
            self.text = ""
        elif len(self.text) < 60:
            self.text += key
        return "text"


CHIP_BG = "FF272727"
CHIP_BG_SELECTED = "FFF1F1F1"


def _addon_path():
    return xbmcaddon.Addon("plugin.video.km").getAddonInfo("path")


class PKMYouTubeWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._rail = kwargs.pop("rail", None) or []
        self._rail_pos = int(kwargs.pop("rail_pos", 0) or 0)
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self._lock = threading.RLock()
        self._view = None          # current view dict
        self._stack = []           # previous views (Back pops)
        self._rows = []            # rows currently bound: [{key, title, items, ...}]
        self._token = 0            # bumps on every view change
        self._closing = False
        self._last_item = None
        self._loading_more = set()
        self._chip = "all"
        self._chip_actions = []    # action per chip list position
        self._focus_rows_on_load = False
        self._sp = None            # inline search panel state (None = closed)
        self._st = None            # inline settings panel state (None = closed)
        self._menu = None          # inline PKM item popup state (None = closed)
        self._swallow_back_r79 = 0.0   # set when playback was handed to the YouTube app
        self._opened = time.time()

    # ------------------------------------------------------------ lifecycle

    def onInit(self):
        t0 = time.time()
        # PKM Home stays underneath with its sidebar expanded on "유튜브".  Its
        # XML reads Window.Property(PlexKM.Sidebar.*) from the window on top
        # while this dialog is open, so mirror the Home sidebar state here;
        # otherwise Home renders a collapsed sidebar under us and pops it open
        # (the "flash") the moment this dialog closes.
        self.setProperty("PlexKM.Sidebar.Expanded", "1")
        try:
            self._bind_rail()
        except Exception:
            _log("RAIL_BIND_FAILED err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        if self._view is None:
            self._open_main(initial=True)
        self._account_sync_bg()
        _log("OPEN ms=%d mode=%s subs=%d" % (int((time.time() - t0) * 1000), yt.api_mode(), len(yt.list_subs())))

    def _bind_rail(self):
        ctl = self.getControl(RAIL_ID)
        ctl.reset()
        items = []
        for icon in self._rail:
            li = xbmcgui.ListItem(label="")
            li.setArt({"icon": icon})
            items.append(li)
        if items:
            ctl.addItems(items)
            try:
                ctl.selectItem(max(0, min(self._rail_pos, len(items) - 1)))
            except Exception:
                pass

    def _close(self, reason):
        if self._closing:
            return
        self._closing = True
        self._token += 1
        try:
            self._settings_close("window")
        except Exception:
            pass
        _log("CLOSE reason=%s view=%s open_s=%.1f" % (reason, (self._view or {}).get("kind"), time.time() - self._opened))
        self.close()

    # ------------------------------------------------------------ chips

    def _on_chips(self):
        return self.getFocusId() in CHIP_ALL_IDS

    def _set_chips(self, entries, select_action=None, main=False):
        """entries: [(action, label)] for the text chips (auto-width buttons)."""
        keep = None
        fid = self.getFocusId()
        if fid in CHIP_TEXT_IDS:
            try:
                keep = self._chip_actions[CHIP_TEXT_IDS.index(fid)]
            except Exception:
                keep = None
        self._chip_actions = [a for a, _ in entries][:CHIP_SLOTS]
        for i in range(CHIP_SLOTS):
            if i < len(entries):
                action, label = entries[i]
                selected = action == select_action
                self.setProperty("PKMYT.Chip%d.Label" % i,
                                 "[COLOR FF0F0F0F]%s[/COLOR]" % label if selected else label)
                self.setProperty("PKMYT.Chip%d.Bg" % i, CHIP_BG_SELECTED if selected else CHIP_BG)
            else:
                self.setProperty("PKMYT.Chip%d.Label" % i, "")
                self.setProperty("PKMYT.Chip%d.Bg" % i, CHIP_BG)
        self.setProperty("PKMYT.MainView", "1" if main else "")
        sel_idx = self._chip_actions.index(select_action) if select_action in self._chip_actions else -1
        self.setProperty("PKMYT.SelectedChip", str(sel_idx) if sel_idx >= 0 else "")
        if fid in CHIP_TEXT_IDS or (fid in (CHIP_REFRESH_ID, CHIP_SETTINGS_ID) and not main):
            target = keep if keep in self._chip_actions else select_action
            idx = self._chip_actions.index(target) if target in self._chip_actions else 0
            self.setFocusId(CHIP_TEXT_IDS[idx])

    def _focus_chips(self):
        sel = None
        for i in range(len(self._chip_actions)):
            if self.getProperty("PKMYT.Chip%d.Bg" % i) == CHIP_BG_SELECTED:
                sel = i
        self.setFocusId(CHIP_TEXT_IDS[sel] if sel is not None else CHIP_SEARCH_ID)

    def _main_chips(self):
        self._set_chips([("chip:%s" % key, label) for key, label in yt.CHIPS], "chip:%s" % self._chip, main=True)

    def _channel_chips(self):
        view = self._view or {}
        sub = yt.is_subscribed(view.get("channel_id"))
        self._set_chips([("subscribe", "구독 중" if sub else "구독")], "subscribe" if sub else None)

    def _search_chips(self):
        self._set_chips([("search", "다시 검색")])

    # ------------------------------------------------------------ views

    def _context_line(self):
        if acct.is_linked():
            info = acct.account_info()
            mode = "계정 %s" % (info.get("name") or "연결됨")
        else:
            mode = "API 키 사용" if yt.get_api_key() else "API 키 없음"
        n = len(yt.list_subs())
        return "YouTube  ·  구독 %d  ·  %s" % (n, mode)

    def _push(self, view):
        if self._view is not None:
            if self._view.get("kind") != "search_panel":
                try:
                    self._view["focus"] = self._capture_focus()
                except Exception:
                    pass
            self._stack.append(self._view)
        self._view = view

    def _open_main(self, initial=False, force=False, chip=None, focus_rows=False):
        """Paint the chip's cached rows at once; refresh in the background."""
        if chip:
            self._chip = chip
        chip = self._chip
        self._view = {"kind": "main", "chip": chip}
        self._token += 1
        token = self._token
        self._main_chips()
        self.setProperty("PKMYT.Context", self._context_line())
        cached = yt.cached_rows(chip)
        if cached and cached.get("rows"):
            self._bind_rows(cached["rows"], focus_first=(initial or focus_rows))
            self._header_default("YouTube", self._main_note(cached))
        else:
            self._bind_rows([], focus_first=False)
            self._header_default("YouTube", self._main_note(None))
            self.setProperty("PKMYT.Status", "" if (chip == "subs" and not yt.list_subs()) else "불러오는 중…")
            if initial:
                self._focus_chips()
                self._focus_rows_on_load = True
        if force or not cached or yt.rows_stale(chip):
            self._run_bg("main", token, lambda: yt.build_rows(
                chip, progress=lambda n, total: self._progress(token, n, total)))

    def _account_sync_bg(self):
        """Linked account: refresh the subscription list every few hours."""
        if not acct.subs_stale():
            return
        token = self._token

        def worker():
            ok, msg = acct.sync()
            _log("ACCOUNT_AUTO_SYNC ok=%d msg=%s" % (1 if ok else 0, msg))
            if ok and not self._closing and self._st is None and self._token == token \
                    and (self._view or {}).get("kind") == "main" and self._chip in ("all", "subs"):
                self._open_main(force=True)
        t = threading.Thread(target=worker, name="PKMYTAccountSyncWin")
        t.daemon = True
        t.start()

    def _main_note(self, cached):
        subs = yt.list_subs()
        if self._chip == "subs" and not subs:
            return ("구독한 채널이 없습니다. ⚙ 설정 → 구글 계정 연결로 내 구독을 가져오거나, "
                    "영상에서 메뉴키 → '구독'으로 PKM에 직접 모을 수 있습니다.")
        if cached and cached.get("built"):
            age = int(time.time() - cached["built"])
            return "%s 갱신" % (yt.age_label(age) or "방금")
        return ""

    def _progress(self, token, n, total):
        if token != self._token or self._closing:
            return
        if not self._rows:
            self.setProperty("PKMYT.Status", "불러오는 중… (%d/%d)" % (n, total))

    def _open_channel(self, channel_id, title="", thumb=""):
        if not channel_id:
            return
        self._push({"kind": "channel", "channel_id": channel_id, "title": title, "thumb": thumb})
        self._token += 1
        token = self._token
        self._channel_chips()
        self.setProperty("PKMYT.Context", "YouTube  ·  채널")
        cached = yt.cached_channel(channel_id)
        if cached and cached.get("videos"):
            self._bind_channel(cached, focus_first=True)
        else:
            self._bind_rows([], focus_first=False)
            self._header_default(title or "채널", "")
            self.setProperty("PKMYT.Backdrop", "")
            self.setProperty("PKMYT.Status", "불러오는 중…")
            self._focus_chips()
        self._run_bg("channel", token, lambda: yt.channel(channel_id, force=bool(cached)))

    def _bind_channel(self, res, focus_first=False):
        view = self._view or {}
        hdr = res.get("channel") or {}
        if hdr.get("title"):
            view["title"] = hdr["title"]
        if hdr.get("thumb"):
            view["thumb"] = hdr["thumb"]
        view["continuation"] = res.get("continuation") or ""
        sub = yt.is_subscribed(view.get("channel_id"))
        rows = [{"key": "channel_videos", "title": "최신 동영상", "items": list(res.get("videos") or []),
                 "continuation": view["continuation"], "source": "channel"}]
        self._bind_rows(rows, focus_first=focus_first)
        note = (hdr.get("description") or "").strip().replace("\r", "")
        if len(note) > 220:
            note = note[:220].rstrip() + "…"
        self._header_default(view.get("title") or "채널", note,
                             meta="구독 중" if sub else "")
        self.setProperty("PKMYT.Backdrop", "")
        if not rows[0]["items"]:
            self.setProperty("PKMYT.Status", "영상이 없습니다")

    def _open_search(self):
        self._search_panel_open()

    # ------------------------------------------------------------ search panel (PKM style)

    def _search_panel_open(self, query="", results=None, focus=None):
        prev = self._capture_focus() if self._sp is None else self._sp.get("prev_focus")
        kb = SearchKeyboard()
        if query:
            kb.set_text(query)
        self._sp = {"kb": kb, "items": [], "continuation": "", "token": 0, "prev_focus": prev,
                    "timer": None, "ran": "", "loading_more": False}
        self.setProperty("PKMYT.SearchActive", "1")
        self._search_panel_keys()
        self._search_panel_history()
        self._search_panel_query_label()
        self._search_panel_bind(query if results else "", results)
        if query and not results:
            self._search_panel_schedule(0)
        if focus and focus[0] == SEARCH_RESULTS_ID and results:
            ctl = self.getControl(SEARCH_RESULTS_ID)
            ctl.selectItem(max(0, min(focus[1], ctl.size() - 1)))
            self.setFocusId(SEARCH_RESULTS_ID)
        else:
            self.getControl(SEARCH_KB_ID).selectItem(0)
            self.setFocusId(SEARCH_KB_ID)
        _log("SEARCH_PANEL_OPEN query=%s" % query)

    def _search_panel_close(self, reason):
        sp = self._sp
        if not sp:
            return
        if sp.get("timer"):
            try:
                sp["timer"].cancel()
            except Exception:
                pass
        self._sp = None
        self.setProperty("PKMYT.SearchActive", "")
        _log("SEARCH_PANEL_CLOSE reason=%s" % reason)
        prev = sp.get("prev_focus")
        if prev and prev[0] in LIST_IDS:
            self._restore_focus(prev)
        elif prev and prev[0] in CHIP_ALL_IDS:
            self.setFocusId(prev[0])
        else:
            self.setFocusId(CHIP_SEARCH_ID)

    def _search_panel_keys(self):
        sp = self._sp
        ctl = self.getControl(SEARCH_KB_ID)
        try:
            pos = max(0, ctl.getSelectedPosition())
        except Exception:
            pos = 0
        ctl.reset()
        items = []
        for key in sp["kb"].keys():
            li = xbmcgui.ListItem(label=SearchKeyboard.label(key))
            li.setProperty("PKMYT.Key", key)
            items.append(li)
        ctl.addItems(items)
        if items:
            ctl.selectItem(min(pos, len(items) - 1))

    def _search_panel_history(self):
        ctl = self.getControl(SEARCH_HISTORY_ID)
        ctl.reset()
        ctl.addItems([xbmcgui.ListItem(label=q) for q in yt.search_history()])

    def _search_panel_query_label(self):
        q = self._sp["kb"].query if self._sp else ""
        self.setProperty("PKMYT.Search.QueryDisplay", (q + " |") if q else "|")

    def _search_panel_schedule(self, delay=SEARCH_DEBOUNCE_SEC):
        sp = self._sp
        if not sp:
            return
        if sp.get("timer"):
            try:
                sp["timer"].cancel()
            except Exception:
                pass
        sp["token"] += 1
        token = sp["token"]
        query = sp["kb"].query.strip()
        if not query:
            self._search_panel_bind("", None)
            return
        self.setProperty("PKMYT.Search.Status", "검색 중…  '%s'" % query)

        def run():
            if self._sp is not sp or sp["token"] != token or self._closing:
                return
            try:
                res = yt.search(query)
            except Exception:
                _log("SEARCH_PANEL_FAILED query=%s err=%s" % (query, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
                res = None
            if self._sp is not sp or sp["token"] != token or self._closing:
                return
            if res is None:
                self.setProperty("PKMYT.Search.Status", "검색하지 못했습니다. 네트워크를 확인하세요")
                return
            self._search_panel_bind(query, res)
            if sp.get("focus_results_token") == token and sp["items"] \
                    and self.getFocusId() in (SEARCH_KB_ID, SEARCH_HISTORY_ID):
                try:
                    self.getControl(SEARCH_RESULTS_ID).selectItem(0)
                    self.setFocusId(SEARCH_RESULTS_ID)
                except Exception:
                    pass
        t = threading.Timer(max(0.0, delay), run)
        t.daemon = True
        sp["timer"] = t
        t.start()

    def _search_panel_bind(self, query, res):
        sp = self._sp
        ctl = self.getControl(SEARCH_RESULTS_ID)
        ctl.reset()
        if not res:
            sp["items"] = []
            sp["continuation"] = ""
            self.setProperty("PKMYT.Search.HasResults", "")
            self.setProperty("PKMYT.Search.Status", "검색어를 입력하세요" if not query else "검색 결과가 없습니다")
            return
        items = list(res.get("channels") or [])[:3] + list(res.get("videos") or [])
        sp["items"] = items
        sp["continuation"] = res.get("continuation") or ""
        sp["ran"] = query
        ctl.addItems([self._make_item(0, i, it) for i, it in enumerate(items)])
        self.setProperty("PKMYT.Search.HasResults", "1" if items else "")
        n_ch = len([i for i in items if i.get("kind") == "channel"])
        self.setProperty("PKMYT.Search.Status", "'%s'  ·  동영상 %d  ·  채널 %d" % (query, len(items) - n_ch, n_ch)
                         if items else "검색 결과가 없습니다")

    def _search_panel_more(self):
        sp = self._sp
        if not sp or sp["loading_more"] or not sp["continuation"]:
            return
        ctl = self.getControl(SEARCH_RESULTS_ID)
        if ctl.getSelectedPosition() < ctl.size() - 6:
            return
        sp["loading_more"] = True
        cont = sp["continuation"]
        query = sp["ran"]

        def worker():
            try:
                res = yt.search(query, continuation=cont)
            except Exception:
                res = None
            if self._sp is not sp:
                return
            sp["loading_more"] = False
            if not res:
                return
            seen = set(i.get("id") for i in sp["items"])
            add = [v for v in (res.get("videos") or []) if v.get("id") not in seen]
            start = len(sp["items"])
            sp["items"].extend(add)
            sp["continuation"] = res.get("continuation") or ""
            if add:
                ctl.addItems([self._make_item(0, start + i, it) for i, it in enumerate(add)])
        t = threading.Thread(target=worker, name="PKMYouTubeSearchMoreR79")
        t.daemon = True
        t.start()

    def _search_panel_click(self, control_id):
        sp = self._sp
        if control_id == SEARCH_KB_ID:
            try:
                key = self.getControl(SEARCH_KB_ID).getSelectedItem().getProperty("PKMYT.Key")
            except Exception:
                return
            result = sp["kb"].press(key)
            if result == "page":
                self._search_panel_keys()
            elif result == "text":
                self._search_panel_query_label()
                self._search_panel_schedule()
            elif result == "done":
                yt.add_search_history(sp["kb"].query)
                if sp["items"]:
                    self.getControl(SEARCH_RESULTS_ID).selectItem(0)
                    self.setFocusId(SEARCH_RESULTS_ID)
            return
        if control_id == SEARCH_HISTORY_ID:
            try:
                q = self.getControl(SEARCH_HISTORY_ID).getSelectedItem().getLabel()
            except Exception:
                return
            sp["kb"].set_text(q)
            self._search_panel_query_label()
            # A recent search is a request for its results: once they arrive the
            # results take focus.  Meanwhile park the keyboard cursor on 완료 (not
            # on whatever key was last selected, e.g. Clear, which one more OK
            # would wipe the query with).
            # (cached results can come back before this handler returns, so the
            # focus/token are set before the search is scheduled)
            try:
                keys = sp["kb"].keys()
                if "완료" in keys:
                    self.getControl(SEARCH_KB_ID).selectItem(keys.index("완료"))
            except Exception:
                pass
            self.setFocusId(SEARCH_KB_ID)
            sp["focus_results_token"] = sp["token"] + 1
            self._search_panel_schedule(0)
            return
        if control_id == SEARCH_RESULTS_ID:
            pos = self.getControl(SEARCH_RESULTS_ID).getSelectedPosition()
            try:
                it = sp["items"][pos]
            except Exception:
                return
            yt.add_search_history(sp["ran"])
            if it.get("kind") == "channel":
                # remember the panel so Back from the channel returns here
                self._stack_search_panel(pos)
                self._open_channel(it.get("id"), it.get("title"), it.get("thumb"))
            else:
                self._play(it)

    def _stack_search_panel(self, pos):
        sp = self._sp
        saved = {"kind": "search_panel", "query": sp["ran"] or sp["kb"].query,
                 "focus": (SEARCH_RESULTS_ID, pos), "prev_focus": sp.get("prev_focus")}
        self._search_panel_close("open_channel")
        if self._view is not None:
            self._stack.append(dict(self._view, focus=saved["prev_focus"]))
        self._view = saved

    def _bind_search(self, res):
        view = self._view or {}
        rows = []
        if res.get("channels"):
            rows.append({"key": "search_channels", "title": "채널", "items": list(res["channels"])})
        if res.get("videos"):
            rows.append({"key": "search_videos", "title": "동영상", "items": list(res["videos"]),
                         "continuation": res.get("continuation") or "", "source": "search"})
        # videos first unless the query is clearly a channel name
        if len(rows) == 2 and len(res.get("videos") or []) > 0:
            rows.reverse()
        self._bind_rows(rows, focus_first=True)
        src = "YouTube Data API" if res.get("source") == "api" else "키 없음"
        self._header_default("'%s'" % view.get("query", ""),
                             "동영상 %d · 채널 %d  (%s)" % (len(res.get("videos") or []), len(res.get("channels") or []), src))
        if not rows:
            self.setProperty("PKMYT.Status", "검색 결과가 없습니다")
            self._focus_chips()

    def _back(self):
        if self._sp is not None:
            if self.getFocusId() in (SEARCH_RESULTS_ID, SEARCH_HISTORY_ID):
                self.setFocusId(SEARCH_KB_ID)
            else:
                self._search_panel_close("back")
            return
        if not self._stack:
            self._close("back")
            return
        prev = self._stack.pop()
        kind = prev.get("kind")
        focus = prev.get("focus")
        if kind == "search_panel":
            # back from a channel opened in the search panel: reopen the panel
            under = self._stack.pop() if self._stack else {"kind": "main", "chip": self._chip}
            self._view = under
            if under.get("kind") == "main":
                self._open_main(chip=under.get("chip"))
            q = prev.get("query") or ""
            self._search_panel_open(q, yt.cache_get("search:%s" % q), focus=prev.get("focus"))
            if self._sp is not None:
                self._sp["prev_focus"] = prev.get("prev_focus")
            return
        if kind == "main":
            self._open_main(chip=prev.get("chip"))
        elif kind == "channel":
            self._view = prev
            self._token += 1
            self._channel_chips()
            self.setProperty("PKMYT.Context", "YouTube  ·  채널")
            cached = yt.cached_channel(prev.get("channel_id"))
            if cached:
                self._bind_channel(cached)
        elif kind == "search":
            self._view = prev
            self._token += 1
            self._search_chips()
            self.setProperty("PKMYT.Context", "YouTube  ·  검색")
            cached = yt.cache_get("search:%s" % prev.get("query", ""))
            if cached:
                self._bind_search(cached)
        self._restore_focus(focus)

    # ------------------------------------------------------------ background

    def _run_bg(self, what, token, fn):
        def worker():
            t0 = time.time()
            try:
                res = fn()
            except Exception:
                _log("BG_FAILED what=%s err=%s" % (what, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
                res = None
            if token != self._token or self._closing:
                _log("BG_DROP what=%s stale=1" % what)
                return
            try:
                self._apply_bg(what, res)
            except Exception:
                _log("BG_APPLY_FAILED what=%s err=%s" % (what, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
            _log("BG_DONE what=%s ms=%d ok=%d" % (what, int((time.time() - t0) * 1000), 1 if res else 0))
        t = threading.Thread(target=worker, name="PKMYouTubeBgR79")
        t.daemon = True
        t.start()

    def _apply_bg(self, what, res):
        if what == "main":
            if not res:
                if not self._rows:
                    self.setProperty("PKMYT.Status", "불러오지 못했습니다. 네트워크를 확인하세요")
                return
            had_rows = bool(self._rows)
            on_chips = self._on_chips() and not self._focus_rows_on_load
            self._focus_rows_on_load = False
            self._bind_rows(res.get("rows") or [], focus_first=not had_rows and not on_chips, keep_focus=had_rows)
            self.setProperty("PKMYT.Context", self._context_line())
            if self.getFocusId() not in LIST_IDS:
                self._header_default("YouTube", self._main_note(res))
            if not res.get("rows"):
                # the header note already explains an empty 구독 tab
                self.setProperty("PKMYT.Status", "" if self._main_note(res) else "표시할 영상이 없습니다")
        elif what == "channel":
            if not res:
                if not self._rows:
                    self.setProperty("PKMYT.Status", "채널을 불러오지 못했습니다")
                return
            had_rows = bool(self._rows)
            self._bind_channel(res, focus_first=not had_rows)
        elif what == "search":
            if not res:
                self.setProperty("PKMYT.Status", "검색하지 못했습니다. 네트워크를 확인하세요")
                return
            self._bind_search(res)

    # ------------------------------------------------------------ binding

    def _make_item(self, slot, pos, it):
        kind = it.get("kind") or "video"
        li = xbmcgui.ListItem(label=it.get("title") or "")
        li.setProperty("PKMYT.Kind", kind)
        thumb = it.get("thumb") or ""
        art = {"thumb": thumb}
        if kind == "video":
            vid = it.get("id")
            art["fanart"] = yt.video_backdrop(vid)
            li.setProperty("PKMYT.ThumbFallback", yt.video_thumb_fallback(vid))
            li.setProperty("PKMYT.BackdropFallback", thumb or yt.video_thumb_fallback(vid))
            badge = "LIVE" if it.get("live") else (it.get("duration") or "")
            li.setProperty("PKMYT.Badge", badge)
            li.setProperty("PKMYT.Live", "1" if it.get("live") else "")
            meta = [x for x in (it.get("channel"), it.get("views"), it.get("published")) if x]
            li.setProperty("PKMYT.Meta", "  ·  ".join(meta))
        elif kind == "playlist":
            art["fanart"] = thumb
            li.setProperty("PKMYT.Badge", it.get("duration") or "재생목록")
            li.setProperty("PKMYT.Meta", "  ·  ".join(x for x in ("재생목록", it.get("channel")) if x))
        else:  # channel
            sub = yt.is_subscribed(it.get("id"))
            li.setProperty("PKMYT.New", "1" if it.get("new") else "")
            extra = "새 영상" if it.get("new") else ""
            li.setProperty("PKMYT.Meta", "  ·  ".join(
                x for x in ("채널", it.get("views"), "구독 중" if sub else "", extra) if x))
        li.setArt(art)
        return li

    def _bind_rows(self, rows, focus_first=False, keep_focus=False):
        rows = [r for r in (rows or []) if r.get("items")][:ROW_SLOTS]
        with self._lock:
            focus_id = self.getFocusId()
            focus_slot = LIST_IDS.index(focus_id) if focus_id in LIST_IDS else -1
            focus_pos = -1
            focus_ref = None
            if keep_focus and focus_slot >= 0:
                try:
                    focus_pos = self.getControl(focus_id).getSelectedPosition()
                    old = self._rows[focus_slot]["items"][focus_pos]
                    focus_ref = (self._rows[focus_slot].get("key"), old.get("kind"), old.get("id"))
                except Exception:
                    focus_ref = None
            old_rows = self._rows
            self._rows = rows
            for slot in range(ROW_SLOTS):
                ctl = self.getControl(_list_id(slot))
                row = rows[slot] if slot < len(rows) else None
                old = old_rows[slot] if slot < len(old_rows) else None
                same = (row is not None and old is not None and row.get("key") == old.get("key")
                        and [(i.get("kind"), i.get("id")) for i in row["items"]]
                        == [(i.get("kind"), i.get("id")) for i in old["items"]]
                        and ctl.size() == len(row["items"]))
                self.setProperty("PKMYT.Row%d.Title" % slot, (row or {}).get("title") or "")
                if same:
                    continue
                ctl.reset()
                if row:
                    ctl.addItems([self._make_item(slot, pos, it) for pos, it in enumerate(row["items"])])
            if rows:
                self.setProperty("PKMYT.Status", "")
            target_slot = -1
            target_pos = 0
            if focus_ref is not None:
                for slot, row in enumerate(rows):
                    if row.get("key") != focus_ref[0]:
                        continue
                    for pos, it in enumerate(row["items"]):
                        if (it.get("kind"), it.get("id")) == focus_ref[1:]:
                            target_slot, target_pos = slot, pos
                            break
                    if target_slot < 0:
                        target_slot, target_pos = slot, min(focus_pos, len(row["items"]) - 1)
                    break
                if target_slot < 0 and rows:
                    target_slot = min(focus_slot, len(rows) - 1)
            elif focus_first and rows:
                target_slot = 0
            if target_slot >= 0:
                try:
                    ctl = self.getControl(_list_id(target_slot))
                    ctl.selectItem(max(0, target_pos))
                    if self.getFocusId() != _list_id(target_slot):
                        self.setFocusId(_list_id(target_slot))
                except Exception:
                    pass
            elif focus_slot >= len(rows) and focus_slot >= 0:
                self._focus_chips()
        self._remember_focused_item()

    def _header_default(self, title, note, meta=""):
        self.setProperty("PKMYT.Title", title or "")
        self.setProperty("PKMYT.Meta", meta or "")
        self.setProperty("PKMYT.Note", note or "")
        self.setProperty("PKMYT.Backdrop", "")

    # ------------------------------------------------------------ focus

    def _focused_item(self):
        fid = self.getFocusId()
        if fid not in LIST_IDS:
            return None, -1, -1
        slot = LIST_IDS.index(fid)
        try:
            pos = self.getControl(fid).getSelectedPosition()
            return self._rows[slot]["items"][pos], slot, pos
        except Exception:
            return None, slot, -1

    def _remember_focused_item(self):
        it, slot, pos = self._focused_item()
        if not it:
            return
        self._last_item = it
        # header shown while the chips are focused: the last card stays up
        self.setProperty("PKMYT.Title", it.get("title") or "")
        if it.get("kind") == "video":
            meta = [x for x in (it.get("channel"), it.get("views"), it.get("published")) if x]
            self.setProperty("PKMYT.Meta", "  ·  ".join(meta))
            self.setProperty("PKMYT.Backdrop", yt.video_backdrop(it.get("id")))
            self.setProperty("PKMYT.BackdropFallback", it.get("thumb") or "")
        else:
            self.setProperty("PKMYT.Meta", it.get("channel") or "")
            self.setProperty("PKMYT.Backdrop", "")
        self._maybe_load_more(slot, pos)

    def _capture_focus(self):
        fid = self.getFocusId()
        pos = -1
        if fid in LIST_IDS:
            try:
                pos = self.getControl(fid).getSelectedPosition()
            except Exception:
                pos = -1
        return (fid, pos)

    def _restore_focus(self, focus):
        if not focus:
            return
        fid, pos = focus
        try:
            if fid in LIST_IDS:
                ctl = self.getControl(fid)
                if ctl.size() > 0:
                    ctl.selectItem(max(0, min(pos, ctl.size() - 1)))
                    self.setFocusId(fid)
                    return
            self._focus_chips()
        except Exception:
            pass

    def _maybe_load_more(self, slot, pos):
        try:
            row = self._rows[slot]
        except Exception:
            return
        token_c = row.get("continuation") or ""
        if not token_c or pos < len(row["items"]) - 6 or token_c in self._loading_more:
            return
        self._loading_more.add(token_c)
        source = row.get("source")
        view = dict(self._view or {})
        view_token = self._token

        def worker():
            try:
                if source == "channel":
                    res = yt.channel(view.get("channel_id"), continuation=token_c)
                else:
                    res = yt.search(view.get("query", ""), continuation=token_c)
                more = res.get("videos") or []
            except Exception:
                _log("LOAD_MORE_FAILED source=%s err=%s" % (source, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
                return
            if view_token != self._token or self._closing:
                return
            with self._lock:
                try:
                    cur = self._rows[slot]
                except Exception:
                    return
                if cur is not row:
                    return
                seen = set(i.get("id") for i in cur["items"])
                add = [m for m in more if m.get("id") not in seen]
                start = len(cur["items"])
                cur["items"].extend(add)
                cur["continuation"] = res.get("continuation") or ""
                if add:
                    self.getControl(_list_id(slot)).addItems(
                        [self._make_item(slot, start + i, it) for i, it in enumerate(add)])
            _log("LOAD_MORE source=%s added=%d total=%d" % (source, len(add), len(cur["items"])))
        t = threading.Thread(target=worker, name="PKMYouTubeMoreR79")
        t.daemon = True
        t.start()

    # ------------------------------------------------------------ input

    def onFocus(self, control_id):
        if self._menu is not None:
            if control_id != ITEM_MENU_ID:
                self.setFocusId(ITEM_MENU_ID)
            return
        if control_id == EXIT_ID:
            self._close("left_edge")

    def onAction(self, action):
        aid = action.getId()
        if self._swallow_back_r79:
            since = time.time() - self._swallow_back_r79
            self._swallow_back_r79 = 0.0
            if aid in BACK_ACTIONS and since > 1.5:
                _log("BACK_AFTER_EXTERNAL_PLAY_SWALLOWED since_s=%.1f" % since)
                return
        if self._menu is not None:
            if aid in BACK_ACTIONS or aid == ACTION_CONTEXT_MENU:
                self._menu_close("back" if aid in BACK_ACTIONS else "menu_key")
            elif self.getFocusId() != ITEM_MENU_ID:
                self.setFocusId(ITEM_MENU_ID)
            return
        if aid in BACK_ACTIONS:
            if self._st is not None:
                self._settings_back()
                return
            self._back()
            return
        if self._st is not None:
            if self.getFocusId() == SET_MENU_ID:
                # any navigation (arrows, page, Home/End, mouse) previews the entry
                self._settings_follow_menu()
            return
        if self._sp is not None:
            if self.getFocusId() == SEARCH_RESULTS_ID and aid in (ACTION_MOVE_DOWN, ACTION_PAGE_DOWN, ACTION_MOVE_RIGHT):
                self._search_panel_more()
            if aid in (ACTION_CONTEXT_MENU, ACTION_SHOW_INFO) and self.getFocusId() == SEARCH_RESULTS_ID:
                try:
                    self._item_menu(self._sp["items"][self.getControl(SEARCH_RESULTS_ID).getSelectedPosition()])
                except Exception:
                    pass
            return
        if aid in (ACTION_CONTEXT_MENU, ACTION_SHOW_INFO):
            it, slot, pos = self._focused_item()
            if it:
                self._item_menu(it)
            return
        if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
                   ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_MOUSE_MOVE):
            self._remember_focused_item()

    def onClick(self, control_id):
        if self._menu is not None:
            if control_id == ITEM_MENU_ID:
                self._menu_click()
            return
        if self._st is not None:
            if control_id == SET_MENU_ID:
                self._settings_menu_click()
            elif control_id == SET_KB_ID:
                self._settings_kb_click()
            return
        if self._sp is not None and control_id in (SEARCH_KB_ID, SEARCH_HISTORY_ID, SEARCH_RESULTS_ID):
            self._search_panel_click(control_id)
            return
        if control_id in LIST_IDS:
            it, slot, pos = self._focused_item()
            if not it:
                return
            if it.get("kind") == "channel":
                self._open_channel(it.get("id"), it.get("title"), it.get("thumb"))
                return
            self._play(it)
            return
        if control_id == CHIP_SEARCH_ID:
            action = "search"
        elif control_id == CHIP_REFRESH_ID:
            action = "refresh"
        elif control_id == CHIP_SETTINGS_ID:
            action = "settings"
        elif control_id in CHIP_TEXT_IDS:
            try:
                action = self._chip_actions[CHIP_TEXT_IDS.index(control_id)]
            except Exception:
                return
        else:
            return
        view = self._view or {}
        if action == "search":
            self._open_search()
        elif action.startswith("chip:"):
            chip = action.split(":", 1)[1]
            if chip == self._chip and view.get("kind") == "main":
                # same tab again: jump to its first row
                if self._rows:
                    self.getControl(LIST_IDS[0]).selectItem(0)
                    self.setFocusId(LIST_IDS[0])
                return
            _log("CHIP chip=%s" % chip)
            self._open_main(chip=chip)
        elif action == "refresh":
            self.setProperty("PKMYT.Note", "새로고침 중…")
            self._open_main(force=True)
        elif action == "settings":
            self._settings()
        elif action == "subscribe" and view.get("kind") == "channel":
            self._toggle_subscribe(view.get("channel_id"), view.get("title"), view.get("thumb"))

    def _play(self, it):
        ok = yt.play(it)
        if ok and yt.plays_externally():
            # Shield: the BACK that closes the YouTube app also reaches Kodi.
            # The first BACK after returning is swallowed so the user lands on
            # this screen instead of PKM Home.  Any other key cancels it.
            self._swallow_back_r79 = time.time()
            return
        if not ok:
            _notice("YouTube 재생", "안드로이드 기기에서만 재생됩니다")

    def _toggle_subscribe(self, channel_id, title, thumb):
        if not channel_id:
            return
        if yt.is_account_sub(channel_id):
            _notice("계정 구독 채널", "해지는 YouTube 앱에서 하세요")
            return
        if yt.is_subscribed(channel_id):
            yt.unsubscribe(channel_id)
            msg = "구독을 해지했습니다"
        else:
            yt.subscribe({"id": channel_id, "title": title, "thumb": thumb})
            msg = "구독했습니다"
        _notice(msg, title or "채널", ms=2000)
        view = self._view or {}
        if view.get("kind") == "channel":
            self._channel_chips()
            self.setProperty("PKMYT.Meta", "구독 중" if yt.is_subscribed(channel_id) else "")
        self.setProperty("PKMYT.Context", self._context_line())

    def _item_menu(self, it):
        opts = []
        if it.get("kind") == "channel":
            cid, title, thumb = it.get("id"), it.get("title"), it.get("thumb")
        else:
            cid, title, thumb = it.get("channel_id"), it.get("channel"), ""
            opts.append(("play", "재생"))
        if cid:
            opts.append(("channel", "채널 보기"))
            opts.append(("sub", "구독 해지" if yt.is_subscribed(cid) else "구독"))
        if not opts:
            return
        heading = it.get("title") if it.get("kind") != "channel" else title
        self._menu_open(heading or title or "YouTube", opts, (it, cid, title, thumb))

    # ------------------------------------------------------------ item popup (PKM style)

    def _menu_open(self, heading, opts, ctx):
        prev = self.getFocusId()
        try:
            ctl = self.getControl(ITEM_MENU_ID)
            ctl.reset()
            ctl.addItems([xbmcgui.ListItem(label=o[1]) for o in opts])
            ctl.selectItem(0)
        except Exception:
            _log("MENU_OPEN_FAILED err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            return
        self._menu = {"opts": opts, "ctx": ctx, "prev": prev}
        self.setProperty("PKMYT.Menu.Title", heading or "")
        self.setProperty("PKMYT.Menu.N", str(len(opts)))
        self.setProperty("PKMYT.MenuActive", "1")
        self.setFocusId(ITEM_MENU_ID)
        _log("MENU_OPEN n=%d prev=%s" % (len(opts), prev))

    def _menu_close(self, reason):
        menu = self._menu
        if not menu:
            return
        self._menu = None
        self.setProperty("PKMYT.MenuActive", "")
        self.setProperty("PKMYT.Menu.N", "")
        prev = menu.get("prev")
        try:
            if prev and prev != ITEM_MENU_ID:
                self.setFocusId(prev)
        except Exception:
            pass
        _log("MENU_CLOSE reason=%s" % reason)

    def _menu_click(self):
        menu = self._menu
        if not menu:
            return
        try:
            idx = self.getControl(ITEM_MENU_ID).getSelectedPosition()
            what = menu["opts"][idx][0]
        except Exception:
            self._menu_close("bad_pos")
            return
        it, cid, title, thumb = menu["ctx"]
        self._menu_close("select:%s" % what)
        if what == "play":
            self._play(it)
        elif what == "channel":
            self._open_channel(cid, title, thumb)
        elif what == "sub":
            self._toggle_subscribe(cid, title, thumb)
            if (self._view or {}).get("kind") == "main" and self._chip in ("all", "subs"):
                self._open_main()

    # ------------------------------------------------------------ settings panel (PKM style)

    def _settings(self):
        self._settings_open()

    def _settings_menu_entries(self):
        """Stages 1-4 first (focus = explanation on the right, OK = run it),
        then maintenance entries."""
        key = yt.get_api_key()
        linked = acct.is_linked()
        out = [("t1", "1   그냥 쓰기", "사용 중"),
               ("t2", "2   YouTube 앱 로그인", "앱 열기"),
               ("phone", "3   API 키", "완료" if key else "휴대폰 QR"),
               ("account", "3   내 구독 연결", "연결됨" if linked else ("코드 받기" if acct.has_client() else "휴대폰 QR")),
               ("t4", "4   영구 연결", "github.io"),
               ("remote", "리모컨으로 API 키 입력", "")]
        if linked:
            out.append(("resync", "구독 다시 가져오기", "%d개" % len(acct.account_subs())))
            out.append(("unlink", "계정 연결 해제", ""))
        elif acct.has_client():
            out.append(("reclient", "OAuth 클라이언트 다시 입력", ""))
        if key:
            out.append(("delete", "API 키 삭제", "키 없이 사용"))
        bk = backup.read()
        out.append(("backup", "백업 · 복원", (bk or {}).get("created_text", "")[5:] if bk else "자동"))
        out.append(("cache", "캐시 비우기", ""))
        return out

    def _settings_open(self):
        prev = self._capture_focus()
        self._st = {"prev_focus": prev, "mode": "", "server": None, "qr": "", "kb": KeyEntryKeyboard(),
                    "changed": False, "busy": False, "entries": [], "device": None, "acc_token": 0}
        self.setProperty("PKMYT.SettingsActive", "1")
        self._settings_status_line()
        self._settings_menu()
        self._settings_kb_keys()
        self._settings_kb_label()
        start = 0
        if not backup.is_meaningful(backup.collect()) and backup.read():
            start = [e[0] for e in self._st["entries"]].index("backup")
        self.getControl(SET_MENU_ID).selectItem(start)
        self.setFocusId(SET_MENU_ID)
        self._settings_follow_menu()
        if start:
            self._settings_msg("이전 백업이 있습니다 · OK를 두 번 누르면 불러옵니다", "ok")
        _log("SETTINGS_OPEN mode=%s" % yt.api_mode())

    def _settings_close(self, reason):
        st = self._st
        if st is None:
            return
        self._settings_stop_server()
        st["acc_token"] += 1          # stops a running device-flow poll
        self._st = None
        self.setProperty("PKMYT.SettingsActive", "")
        self.setProperty("PKMYT.Set.Mode", "")
        _log("SETTINGS_CLOSE reason=%s changed=%d" % (reason, 1 if st.get("changed") else 0))
        if reason == "window":
            return
        if st.get("changed"):
            self._stack = []
            self._open_main(force=True)
            self.setFocusId(CHIP_SETTINGS_ID)
            return
        prev = st.get("prev_focus")
        if prev and prev[0] in LIST_IDS:
            self._restore_focus(prev)
        else:
            self.setFocusId(CHIP_SETTINGS_ID)

    def _settings_status_line(self):
        key = yt.get_api_key()
        if acct.is_linked():
            info = acct.account_info()
            self.setProperty("PKMYT.Set.Current", "계정 연결됨  ·  %s" % (info.get("name") or "YouTube"))
            self.setProperty("PKMYT.Set.CurrentNote", "내 구독 채널 %d개를 가져와 구독 탭에 보여 줍니다. %s" % (
                info.get("subs") or 0, ("API 키도 사용 중 (%s)." % mask_key(key)) if key
                else "API 키 없이도 인기 차트가 나옵니다."))
            return
        if acct.token_error():
            self.setProperty("PKMYT.Set.Current", "계정 연결이 풀렸습니다")
            self.setProperty("PKMYT.Set.CurrentNote", "동의 화면 게시 상태가 '테스트'면 7일마다 풀립니다. "
                             "프로덕션으로 바꾼 뒤 다시 연결하세요.")
            return
        if key:
            self.setProperty("PKMYT.Set.Current", "API 키 사용 중  ·  %s" % mask_key(key))
            self.setProperty("PKMYT.Set.CurrentNote", "인기 차트(KR)와 카테고리 순위를 YouTube Data API로 가져옵니다.")
        else:
            self.setProperty("PKMYT.Set.Current", "API 키 없음  ·  기본 모드")
            self.setProperty("PKMYT.Set.CurrentNote", "검색, 채널, 로컬 구독은 키 없이 동작합니다. 키를 넣으면 실제 인기 차트가 추가됩니다.")

    def _settings_menu(self):
        st = self._st
        ctl = self.getControl(SET_MENU_ID)
        try:
            pos = max(0, ctl.getSelectedPosition())
        except Exception:
            pos = 0
        st["entries"] = self._settings_menu_entries()
        ctl.reset()
        items = []
        for what, label, label2 in st["entries"]:
            li = xbmcgui.ListItem(label=label, label2=label2)
            li.setProperty("PKMYT.Set.What", what)
            items.append(li)
        ctl.addItems(items)
        ctl.selectItem(min(pos, len(items) - 1))

    def _settings_follow_menu(self):
        """The right side previews the focused menu entry (phone QR, remote
        keyboard, help) like a PKM settings page."""
        st = self._st
        if st is None:
            return
        try:
            what = st["entries"][self.getControl(SET_MENU_ID).getSelectedPosition()][0]
        except Exception:
            return
        if what in ("resync", "unlink", "reclient"):
            what = "account"
        if what in ("phone", "remote", "account", "t1", "t2", "t4", "backup"):
            self._settings_mode(what)
        else:
            self._settings_mode("info")

    def _settings_mode(self, mode):
        st = self._st
        if st["mode"] == mode:
            return
        st["mode"] = mode
        self.setProperty("PKMYT.Set.Mode", mode)
        if mode == "account":
            self._account_show()
            return
        if mode == "t4":
            self._settings_start_server("perm")
            if st.get("qr_ready"):
                self._settings_msg("휴대폰으로 QR → 한 화면씩 따라 하면 됩니다 (약 15분)", "")
            return
        if mode == "backup":
            self._backup_show()
            self._settings_start_server("backup")
            return
        if mode in ("t1", "t2"):
            self._settings_msg("", "")
            return
        if mode == "phone":
            self._settings_start_server("apikey")
            srv = st.get("server")
            if srv is not None and srv.running and st.get("qr_ready"):
                self._settings_msg("휴대폰 카메라로 QR을 찍고 키를 붙여넣은 뒤 저장하세요. (같은 Wi-Fi)", "")
        elif mode == "info":
            self._settings_msg("", "")
        elif mode == "remote":
            self._settings_msg("오른쪽 키보드로 입력한 뒤 [저장]을 누르세요. 대소문자를 구분합니다.", "")

    # ---- phone

    def _settings_start_server(self, kind="apikey"):
        st = self._st
        srv = st.get("server")
        if srv is not None and srv.running and srv.kind == kind:
            return
        if srv is not None:
            self._settings_stop_server()
        self.setProperty("PKMYT.Set.QR", "")
        self.setProperty("PKMYT.Set.URL", "")
        self._settings_msg("휴대폰 입력을 준비하는 중…", "")
        handler = {"oauth": self._settings_phone_client, "backup": self._settings_phone_backup}.get(
            kind, self._settings_phone_key)
        srv = KeyServer(handler, self._settings_phone_event, kind=kind)
        st["server"] = srv
        if not srv.start():
            st["server"] = None
            self._settings_msg("휴대폰 입력을 시작하지 못했습니다. 리모컨 입력을 사용하세요.", "bad")
            return
        qr = os.path.join(_profile_path(), "yt_key_qr_%s.png" % srv.token)
        if write_qr(srv.url, qr):
            st["qr"] = qr
            self.setProperty("PKMYT.Set.QR", qr)
        self.setProperty("PKMYT.Set.URL", srv.url.replace("http://", ""))
        st["qr_ready"] = True
        if kind == "perm":
            self._settings_msg("휴대폰으로 QR → 한 화면씩 따라 하면 됩니다 (약 15분)", "")
        elif kind == "backup":
            self._settings_msg("휴대폰으로 QR → 백업 파일 받기 / 올려서 복원", "")
        elif kind == "oauth":
            self._settings_msg("휴대폰으로 QR을 찍어 안내대로 클라이언트를 만들고 붙여넣으세요. (같은 Wi-Fi)", "")
        else:
            self._settings_msg("휴대폰 카메라로 QR을 찍고 키를 붙여넣은 뒤 저장하세요. (같은 Wi-Fi)", "")

    def _settings_stop_server(self):
        st = self._st
        if not st:
            return
        srv = st.get("server")
        st["server"] = None
        if srv is not None:
            srv.stop()
        qr = st.get("qr")
        st["qr"] = ""
        if qr:
            try:
                os.remove(qr)
            except Exception:
                pass

    def _settings_phone_event(self, kind, text):
        if self._st is None:
            return
        if kind == "open":
            self._settings_msg(text, "")
        elif kind == "checking":
            self._settings_msg(text, "")
        elif kind in ("error", "idle"):
            self._settings_msg(text, "bad")

    def _settings_phone_key(self, key):
        """HTTP thread: validate + store, then refresh the panel."""
        ok, msg = yt.test_api_key(key)
        if ok:
            self._settings_saved(key, msg, "phone")
        return ok, msg

    # ---- remote keyboard

    def _settings_kb_keys(self):
        st = self._st
        ctl = self.getControl(SET_KB_ID)
        try:
            pos = max(0, ctl.getSelectedPosition())
        except Exception:
            pos = 0
        ctl.reset()
        items = []
        for k in st["kb"].keys():
            li = xbmcgui.ListItem(label=KeyEntryKeyboard.label(k))
            li.setProperty("PKMYT.Key", k)
            items.append(li)
        ctl.addItems(items)
        if items:
            ctl.selectItem(min(pos, len(items) - 1))

    def _settings_kb_label(self):
        text = self._st["kb"].text if self._st else ""
        self.setProperty("PKMYT.Set.Input", (text + " |") if text else "|")
        self.setProperty("PKMYT.Set.InputCount", "%d자" % len(text) if text else "")

    def _settings_kb_click(self):
        st = self._st
        try:
            key = self.getControl(SET_KB_ID).getSelectedItem().getProperty("PKMYT.Key")
        except Exception:
            return
        result = st["kb"].press(key)
        if result == "page":
            self._settings_kb_keys()
        elif result == "text":
            self._settings_kb_label()
        elif result == "done":
            self._settings_remote_save()

    def _settings_remote_save(self):
        st = self._st
        if st["busy"]:
            return
        key, err = clean_key(st["kb"].text)
        if err:
            self._settings_msg(err, "bad")
            return
        st["busy"] = True
        self._settings_msg("키를 확인하는 중…", "")

        def worker():
            try:
                ok, msg = yt.test_api_key(key)
                if self._st is not st:
                    return
                if ok:
                    self._settings_saved(key, msg, "remote")
                else:
                    self._settings_msg(msg + "  ·  키를 저장하지 않았습니다", "bad")
            finally:
                st["busy"] = False
        t = threading.Thread(target=worker, name="PKMYTKeyCheck")
        t.daemon = True
        t.start()

    # ---- shared

    def _settings_saved(self, key, msg, source):
        st = self._st
        yt.set_api_key(key)
        _log("SETTINGS_KEY_SAVED source=%s key=%s" % (source, mask_key(key)))
        if st is None:
            return
        st["changed"] = True
        st["kb"].set_text("")
        self._settings_kb_label()
        self._settings_status_line()
        self._settings_menu()
        self._settings_msg("%s  ·  저장했습니다. 뒤로 가면 인기 차트가 새로 고쳐집니다." % msg, "ok")

    def _settings_msg(self, text, tone):
        self.setProperty("PKMYT.Set.Msg", text or "")
        self.setProperty("PKMYT.Set.MsgTone", tone or "")

    def _settings_menu_click(self):
        st = self._st
        try:
            what = st["entries"][self.getControl(SET_MENU_ID).getSelectedPosition()][0]
        except Exception:
            return
        if what == "t1":
            self._settings_close("stage1")
            self._open_main(chip="all", focus_rows=True)
            return
        if what == "t2":
            if yt.plays_externally():
                xbmc.executebuiltin('StartAndroidActivity("%s")' % yt.YT_ANDROID_TV)
                self._swallow_back_r79 = time.time()
                self._settings_msg("YouTube 앱에서 로그인한 뒤 백키로 돌아오세요", "ok")
            else:
                self._settings_msg("안드로이드 기기에서만 됩니다 (이 기기는 YouTube 앱 없음)", "bad")
            return
        if what == "t4":
            srv = st.get("server")
            if srv is None or not srv.running or srv.kind != "perm":
                st["mode"] = ""
                self._settings_mode("t4")
            return
        if what == "backup":
            self._backup_click()
            return
        if what == "remote":
            self._settings_mode("remote")
            self.setFocusId(SET_KB_ID)
        elif what == "phone":
            srv = st.get("server")
            if srv is None or not srv.running or srv.kind != "apikey":
                st["mode"] = ""
                self._settings_mode("phone")
        elif what == "account":
            if acct.is_linked():
                self._account_show()
            elif acct.has_client():
                self._account_start_device()
            else:
                st["mode"] = ""
                self._settings_mode("account")
        elif what == "reclient":
            st["acc_token"] += 1
            self._settings_mode("account_client")
            self.setProperty("PKMYT.Set.Mode", "account")
            self._account_state("noclient")
            self._settings_start_server("oauth")
        elif what == "resync":
            self._account_sync_now()
        elif what == "unlink":
            st["acc_token"] += 1
            acct.unlink()
            st["changed"] = True
            self._settings_status_line()
            self._settings_menu()
            self.getControl(SET_MENU_ID).selectItem(0)
            st["mode"] = ""
            self._settings_mode("account")
            self._settings_msg("계정 연결을 해제했습니다. PKM에 직접 구독한 채널은 그대로 남습니다.", "ok")
        elif what == "delete":
            yt.set_api_key("")
            st["changed"] = True
            self._settings_status_line()
            self._settings_menu()
            self._settings_follow_menu()
            self._settings_mode("info")
            self._settings_msg("API 키를 삭제했습니다. 키 없이 기본 모드로 동작합니다.", "ok")
        elif what == "cache":
            yt.cache_clear()
            st["changed"] = True
            self._settings_mode("info")
            self._settings_msg("캐시를 비웠습니다. 뒤로 가면 목록을 새로 불러옵니다.", "ok")
        elif what == "help":
            self._settings_mode("help")

    # ---- backup / restore

    def _backup_show(self):
        bk = backup.read()
        cur = backup.collect()
        self.setProperty("PKMYT.Bk.Device", ("%s  ·  %s" % (bk.get("created_text", ""), backup.summary(bk))) if bk else "아직 없음")
        self.setProperty("PKMYT.Bk.Path", backup.backup_path() or backup.planned_path() or "백업 폴더 없음")
        self.setProperty("PKMYT.Bk.Current", backup.summary(cur) if backup.is_meaningful(cur) else "설정 없음")

    def _backup_click(self):
        st = self._st
        bk = backup.read()
        cur = backup.collect()
        if not bk:
            ok, msg = backup.write_now("manual")
            self._backup_show()
            self._settings_menu()
            self._settings_msg("백업했습니다" if ok else msg, "ok" if ok else "bad")
            return
        armed = st.get("restore_armed") or 0
        if time.time() - armed > 8:
            st["restore_armed"] = time.time()
            what = backup.summary(bk)
            self._settings_msg("한 번 더 OK → %s 백업으로 복원 (%s)" % (bk.get("created_text", ""), what), "")
            return
        st["restore_armed"] = 0
        ok, msg = backup.restore(bk)
        self._backup_restored(ok, msg)

    def _backup_restored(self, ok, msg):
        st = self._st
        if st is None:
            return
        if ok:
            st["changed"] = True
        self._settings_status_line()
        self._settings_menu()
        self._backup_show()
        self._settings_msg(msg, "ok" if ok else "bad")

    def _settings_phone_backup(self, payload):
        """HTTP thread: restore an uploaded backup."""
        ok, msg = backup.restore(payload)
        if self._st is not None:
            self._backup_restored(ok, msg)
        return ok, msg

    # ---- Google account (device flow)

    def _account_state(self, state):
        self.setProperty("PKMYT.Acc.State", state)

    def _account_show(self):
        st = self._st
        self.setProperty("PKMYT.Set.Mode", "account")
        if acct.is_linked():
            info = acct.account_info()
            self.setProperty("PKMYT.Acc.Name", info.get("name") or "YouTube 계정")
            self.setProperty("PKMYT.Acc.Thumb", info.get("thumb") or "")
            synced = info.get("synced") or 0
            self.setProperty("PKMYT.Acc.Detail", "구독 채널 %d개  ·  %s 가져옴" % (
                info.get("subs") or 0, (yt.age_label(int(time.time() - synced)) or "방금") if synced else "아직 안"))
            self._account_state("linked")
            if not st.get("device"):
                self._settings_msg("", "")
            return
        if st.get("device"):
            self._account_state("code")
            return
        if acct.has_client():
            self._account_state("ready")
            self._settings_msg("OK를 누르면 로그인 코드가 나옵니다.", "")
            return
        self._account_state("noclient")
        self._settings_start_server("oauth")

    def _settings_phone_client(self, value):
        """HTTP thread (oauth page): store the client, start the device flow."""
        cid, sec = value
        ok, info = acct.device_start(cid)
        if not ok:
            return False, info
        acct.set_client(cid, sec)
        if self._st is not None:
            self._account_begin_poll(info)
        return True, "저장했습니다. TV에 뜬 코드로 google.com/device 에서 로그인하세요"

    def _account_start_device(self):
        st = self._st
        st["acc_token"] += 1
        self.setProperty("PKMYT.Set.Mode", "account")
        self._settings_msg("로그인 코드를 받는 중…", "")

        def worker():
            ok, info = acct.device_start()
            if self._st is not st:
                return
            if not ok:
                self._account_state("ready")
                self._settings_msg(info, "bad")
                return
            self._account_begin_poll(info)
        t = threading.Thread(target=worker, name="PKMYTDeviceStart")
        t.daemon = True
        t.start()

    def _account_begin_poll(self, info):
        st = self._st
        if st is None:
            return
        self._settings_stop_server()
        st["acc_token"] += 1
        token = st["acc_token"]
        st["device"] = info
        url = info.get("verification_url") or "https://www.google.com/device"
        self.setProperty("PKMYT.Acc.Code", info.get("user_code") or "")
        self.setProperty("PKMYT.Acc.URL", url.replace("https://", "").replace("http://", ""))
        qr = os.path.join(_profile_path(), "yt_device_qr.png")
        if write_qr(url, qr):
            self.setProperty("PKMYT.Acc.QR", "")
            self.setProperty("PKMYT.Acc.QR", qr)
        self.setProperty("PKMYT.Set.Mode", "account")
        self._account_state("code")
        self._settings_msg("휴대폰에서 코드를 입력하고 계정을 허용하면 자동으로 연결됩니다.", "")

        def poll():
            interval = info.get("interval") or 5
            while True:
                time.sleep(interval)
                if self._st is not st or st["acc_token"] != token or self._closing:
                    return
                state, msg = acct.device_poll(info)
                if self._st is not st or st["acc_token"] != token:
                    return
                if state == "pending":
                    continue
                if state == "slow":
                    interval += 5
                    continue
                st["device"] = None
                if state != "ok":
                    self._account_state("ready" if acct.has_client() else "noclient")
                    self._settings_msg(msg, "bad")
                    return
                st["changed"] = True
                self._account_state("syncing")
                self._settings_msg("연결됨 · 구독 채널을 가져오는 중…", "")
                ok, smsg = acct.sync(progress=lambda n: self._settings_msg(
                    "연결됨 · 구독 채널을 가져오는 중… %d" % n, ""))
                if self._st is not st:
                    return
                self._settings_status_line()
                self._settings_menu()
                self._account_show()
                self._settings_msg(("%s · 뒤로 가면 구독 탭에 반영됩니다." % smsg) if ok else smsg,
                                   "ok" if ok else "bad")
                return
        t = threading.Thread(target=poll, name="PKMYTDevicePoll")
        t.daemon = True
        t.start()

    def _account_sync_now(self):
        st = self._st
        if st.get("busy"):
            return
        st["busy"] = True
        self._settings_mode("account")
        self._account_state("syncing")
        self._settings_msg("구독 채널을 가져오는 중…", "")

        def worker():
            try:
                ok, msg = acct.sync(progress=lambda n: self._settings_msg("구독 채널을 가져오는 중… %d" % n, ""))
                if self._st is not st:
                    return
                if ok:
                    st["changed"] = True
                self._settings_status_line()
                self._settings_menu()
                self._account_show()
                self._settings_msg(msg, "ok" if ok else "bad")
            finally:
                st["busy"] = False
        t = threading.Thread(target=worker, name="PKMYTAccountSyncNow")
        t.daemon = True
        t.start()

    def _settings_back(self):
        if self.getFocusId() == SET_KB_ID:
            self.setFocusId(SET_MENU_ID)
            return
        self._settings_close("back")



def open_window(params=None):
    """Entry point for default.py?action=youtube."""
    rail = []
    rail_pos = 0
    try:
        raw = xbmcgui.Window(10000).getProperty("PlexKM.YouTube.RailR79")
        data = json.loads(raw) if raw else {}
        rail = list(data.get("icons") or [])
        rail_pos = int(data.get("pos") or 0)
    except Exception:
        pass
    win = PKMYouTubeWindow(XML_NAME, _addon_path(), "Default", "1080i", rail=rail, rail_pos=rail_pos)
    try:
        win.doModal()
    finally:
        try:
            del win
        except Exception:
            pass
        # Back on PKM Home: the sidebar owns focus (on "유튜브") again.
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Sidebar.Expanded", "1")
            xbmc.executebuiltin("SetProperty(PlexKM.Sidebar.Expanded,1,13000)")
            xbmcgui.Window(10000).clearProperty("PlexKM.YouTube.ActiveR79")
        except Exception:
            pass
    return True
