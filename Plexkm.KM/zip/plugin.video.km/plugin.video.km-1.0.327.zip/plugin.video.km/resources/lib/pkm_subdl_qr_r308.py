# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""R308: enter the SubDL API key from a phone (QR -> paste -> save).

Reuses the YouTube key server (kind="subdl"): the TV shows a QR for
http://<lan-ip>:<port>/<token>, the phone opens a page, pastes the key and the
key is verified against SubDL before it is stored in pkm_subdl_api_key.
"""

import os
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
CLOSE_ID = 10
QR_ID = 20


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[PlexKM] SUBDL QR %s" % msg, level)
    except Exception:
        pass


def clean_subdl_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    ok = all(ch.isalnum() or ch in "-_" for ch in key)
    if len(key) < 20 or len(key) > 120 or not ok:
        return "", "SubDL API 키 형식이 아닙니다 (subdl.com > API 페이지의 키를 그대로 붙여넣으세요)"
    return key, ""


def verify_key(key):
    """(ok, message). Network errors are not treated as a bad key."""
    try:
        from resources.lib import pkm_subdl
        pkm_subdl._get_json({"api_key": key, "film_name": "Parasite", "type": "movie",
                             "languages": "KO", "subs_per_page": 1}, timeout=12)
        return True, "SubDL 키를 저장했습니다"
    except Exception as exc:
        text = str(exc)
        if "401" in text or "403" in text or "400" in text:
            return False, "SubDL이 이 키를 받아주지 않습니다. 키를 다시 확인하세요"
        return True, "키를 저장했습니다 (SubDL 확인은 건너뜀: 네트워크)"


def page_html(msg_html=""):
    return (
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'><title>PlexKM SubDL 키</title>"
        "<style>body{margin:0;background:#15171a;color:#f1f1f1;font:17px/1.6 -apple-system,'Apple SD Gothic Neo','Noto Sans KR',sans-serif}"
        "main{max-width:560px;margin:0 auto;padding:28px 18px}h1{font-size:22px}"
        "textarea{width:100%;box-sizing:border-box;height:96px;border-radius:12px;border:1px solid #444;background:#23272c;color:#fff;padding:12px;font-size:16px}"
        "button{margin-top:14px;width:100%;padding:15px;border:0;border-radius:12px;background:#e5b400;color:#111;font-size:18px;font-weight:700}"
        ".msg{margin:14px 0;padding:12px 14px;border-radius:10px}.ok{background:#12351f;color:#8be0a4}.bad{background:#401a1a;color:#ff9c9c}"
        "a{color:#e5b400}</style></head><body><main>"
        "<h1>SubDL API 키 입력</h1>" + (msg_html or "") +
        "<ol style='padding-left:20px'>"
        "<li>아래 <b>[SubDL 열기]</b>를 누르세요. 로그인 화면이 나오면 로그인하세요(계정이 없으면 Register로 무료 가입). 로그인하면 API 키 페이지가 바로 열립니다.<br>"
        "<a href='https://subdl.com/panel/login?page=/panel/api' target='_blank' style='display:inline-block;margin:8px 0;padding:10px 16px;border-radius:10px;background:#23272c;font-weight:700'>SubDL 열기 (API 키 페이지)</a></li>"
        "<li>열린 페이지의 <b>API Key</b> 화면에서 <b>Copy API Code</b> 버튼을 누르면 키가 복사됩니다.</li>"
        "<li>이 화면(브라우저 탭)으로 돌아와 아래 입력칸을 길게 눌러 <b>붙여넣기</b>하고 <b>저장</b>을 누르세요.</li>"
        "</ol><p style='color:#a3a8b3;font-size:15px'>저장하면 TV에 바로 적용됩니다. TV에서 키를 직접 칠 필요가 없습니다.</p>"
        "<form method='post'><textarea name='key' placeholder='subdl_...' autocomplete='off' autocapitalize='off' spellcheck='false'></textarea>"
        "<button type='submit'>저장</button></form></main></body></html>"
    )


def _profile_dir():
    p = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


class SubdlQrDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.pop("url", "")
        self.texts = kwargs.pop("texts", None) or ("PlexKM 자막 · SubDL", "SubDL API 키를 휴대폰으로 입력하세요", "Copy API Code 복사 → 붙여넣고 저장")
        self.qr = kwargs.pop("qr", "")
        super(SubdlQrDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty("PKM.SubdlQR.URL", self.url)
        self.setProperty("PKM.SubdlQR.Head", self.texts[0])
        self.setProperty("PKM.SubdlQR.Title", self.texts[1])
        self.setProperty("PKM.SubdlQR.Step2", self.texts[2])
        self.setProperty("PKM.SubdlQR.Msg", "휴대폰이 TV와 같은 Wi-Fi여야 합니다")
        self.setProperty("PKM.SubdlQR.Done", "")
        if self.qr and os.path.exists(self.qr):
            try:
                self.getControl(QR_ID).setImage(self.qr, False)
            except Exception:
                pass
        try:
            self.setFocusId(CLOSE_ID)
        except Exception:
            pass

    def say(self, text, done=False):
        try:
            self.setProperty("PKM.SubdlQR.Msg", text)
            if done:
                self.setProperty("PKM.SubdlQR.Done", "1")
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == CLOSE_ID:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


def run(youtube=False):
    """Blocking. Returns the saved key ('' if cancelled). youtube=True: YouTube API key guide."""
    from resources.lib.pkm_youtube_keyserver import KeyServer, write_qr
    saved = {"key": ""}
    dlg_ref = {}

    def on_key(key):
        if youtube:
            from resources.lib import pkm_youtube as yt
            ok, msg = yt.test_api_key(key)
            if ok:
                yt.set_api_key(key)
                saved["key"] = key
                d = dlg_ref.get("dlg")
                if d is not None:
                    d.say("저장되었습니다. 창을 닫는 중…", done=True)
            return ok, msg
        ok, msg = verify_key(key)
        if ok:
            try:
                xbmcaddon.Addon(ADDON_ID).setSetting("pkm_subdl_api_key", key)
                saved["key"] = key
            except Exception:
                return False, "저장 중 오류가 발생했습니다"
            d = dlg_ref.get("dlg")
            if d is not None:
                d.say("저장되었습니다. 창을 닫는 중…", done=True)
        return ok, msg

    def on_event(kind, text):
        d = dlg_ref.get("dlg")
        if d is not None and kind in ("open", "checking", "error", "idle"):
            d.say(text)

    srv = KeyServer(on_key, on_event, kind="apikey" if youtube else "subdl")
    if not srv.start():
        xbmcgui.Dialog().ok("SubDL", "휴대폰 입력 서버를 시작하지 못했습니다.[CR]설정에서 키를 직접 입력해주세요.")
        return ""
    qr = os.path.join(_profile_dir(), "subdl_key_qr_%s.png" % srv.token)
    write_qr(srv.url, qr)
    try:
        dlg = SubdlQrDialog("plexkm_subdl_qr_r308.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                            "Default", "1080i", url=srv.url, qr=qr,
                            texts=("PlexKM 유튜브 · API 키", "YouTube API 키를 휴대폰으로 입력하세요", "안내 페이지 따라 키 발급 → 붙여넣고 저장") if youtube else None)
        dlg_ref["dlg"] = dlg

        def _watch():
            t0 = time.time()
            while dlg_ref.get("dlg") is not None and not xbmc.Monitor().abortRequested():
                if saved["key"]:
                    xbmc.sleep(1200)
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                if time.time() - t0 > 15 * 60 or not srv.running:
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                xbmc.sleep(400)

        import threading
        th = threading.Thread(target=_watch)
        th.daemon = True
        th.start()
        dlg.doModal()
    except Exception:
        _log("DIALOG_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    finally:
        dlg_ref["dlg"] = None
        srv.stop()
        try:
            os.remove(qr)
        except Exception:
            pass
    return saved["key"]
