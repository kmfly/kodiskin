# -*- coding: utf-8 -*-
"""R331: first-install order = library setup -> restart on the PlexKM skin ->
logo loading (bar full) -> setup helper taste step -> "초기 화면 구성" (last)."""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs


def taste_pending():
    try:
        if not xbmcvfs.exists("special://home/addons/script.pkm.setup/addon.xml"):
            return False
        root = xbmcvfs.translatePath("special://profile/addon_data/")
        prof = os.path.join(root, "plugin.video.km")
        if os.path.exists(os.path.join(prof, "pkm_taste.json")):
            return False
        try:
            with open(os.path.join(root, "script.pkm.setup", "progress.json"), "r", encoding="utf-8") as f:
                if int(json.load(f).get("step", 1)) >= 5:
                    return True
        except Exception:
            pass
        with open(os.path.join(prof, "state.json"), "r", encoding="utf-8") as f:
            st = json.load(f)
        return bool(st.get("initial_setup_completed_v2562") or st.get("initial_sync_done"))
    except Exception:
        return False


def run_taste_step_blocking(log=None):
    """Open the helper's taste step and wait until it closes."""
    try:
        mon = xbmc.Monitor()
        win = xbmcgui.Window(10000)
        win.clearProperty("PlexKM.SetupHelperOpen")
        win.setProperty("PlexKM.SetupTasteGateR462", "1")
        if log:
            log("SETUP_HELPER_AUTO_RESUME_R331 at=after_logo_loading")
        xbmc.executebuiltin("RunScript(script.pkm.setup,taste)")
        t0 = time.time()
        opened = False
        while not mon.abortRequested() and time.time() - t0 < 1800:
            if win.getProperty("PlexKM.SetupHelperOpen"):
                opened = True
            elif opened or (time.time() - t0) > 20:
                break
            mon.waitForAbort(0.4)
        win.clearProperty("PlexKM.SetupTasteGateR462")
        if log:
            log("SETUP_HELPER_DONE_R331 opened=%d waited_ms=%d" % (1 if opened else 0, int((time.time() - t0) * 1000)))
        return opened
    except Exception:
        try:
            xbmcgui.Window(10000).clearProperty("PlexKM.SetupTasteGateR462")
        except Exception:
            pass
        return False
