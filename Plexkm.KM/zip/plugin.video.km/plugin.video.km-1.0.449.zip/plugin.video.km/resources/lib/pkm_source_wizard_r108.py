# -*- coding: utf-8 -*-
"""R108 content-source wizard (first run, and Settings > 콘텐츠 소스 > 추가).

Steps
  source      Plex 서버 / Kodi 라이브러리 cards
  kodi_found  Kodi library already has items -> 이대로 사용 / 폴더 추가
  browse      PKM folder browser (Kodi video sources, drives, storage)
  content     영화 / 드라마·TV
  scan        register folder (TMDB ko-KR) + Kodi library scan with live count

run_wizard() returns:
  {"choice": "plex"}                         -> caller opens the Plex connection flow
  {"choice": "kodi", "content": ..., "path": ...}
  None                                       -> closed with back
"""
from __future__ import absolute_import, unicode_literals

import json
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import pkm_sources

ADDON = xbmcaddon.Addon("plugin.video.km")
XML_NAME = "plexkm_pkm_source_wizard_r108.xml"
MEDIA = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r97s/"

ACTION_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)

CARD_PLEX, CARD_KODI = 401, 402
BTN_USE, BTN_ADD = 501, 502
LIST_BROWSE = 600
BTN_MOVIES, BTN_TV = 701, 702
BTN_SCAN_DONE = 801
LIST_SCAN_R465 = 820
MULTI_MODES_R465 = ("add_movies", "add_tvshows")
BAR_R465 = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r465/bar_%02d.png"
ACTION_RIGHT_R465 = 2


def _bar_r465(pct):
    try:
        return BAR_R465 % max(0, min(20, int(round(float(pct) / 5.0))))
    except Exception:
        return BAR_R465 % 0
BTN_EXIT = 403   # R113: first-run "나가기" -> Kodi main menu
NET_CHIPS, NET_KEYS, NET_CANCEL, NET_OK, NET_HELP = 450, 460, 470, 471, 472   # R338: PlexKM network-path input

_NET_SCHEMES = (
    ("smb://", "윈도우"), ("nfs://", "NFS"), ("sftp://", "SSH"), ("ftp://", "FTP"), ("dav://", "WebDAV"),
    ("davs://", "보안"), ("http://", "웹"), ("https://", "보안"), ("upnp://", "UPnP"), ("", "전체"),
)
_NET_KEY_ROWS = (
    list("1234567890"), list("qwertyuiop"), list("asdfghjkl:"), list("zxcvbnm./@"),
    ["Aa", "-", "_", "~", "!", "#", "&", "%", "공백", "지움"],
)

# R339: 도움말 — 프로토콜별 (입력 형식, 예, NAS에서 확인할 것, 안 열릴 때)
_NET_GUIDE = {
    "smb://": ("smb://아이디:비밀번호@NAS주소/공유폴더", "smb://admin:1234@192.168.0.10/영화",
               "NAS 관리 화면에서 IP 주소와 공유 폴더 이름을 확인하세요.",
               "NAS에서 SMB2 이상을 켜야 합니다. 비밀번호에 @ : / 가 있으면 %40 %3A %2F 로 바꿔 입력하세요."),
    "nfs://": ("nfs://NAS주소/공유경로", "nfs://192.168.0.10/volume1/영화",
               "아이디와 비밀번호는 없습니다. 공유경로는 NAS의 NFS 설정에 적힌 경로 그대로 쓰세요.",
               "NAS의 NFS 권한에 이 기기의 IP를 읽기 허용으로 넣어야 열립니다."),
    "sftp://": ("sftp://아이디:비밀번호@NAS주소/폴더", "sftp://admin:1234@192.168.0.10/volume1/영화",
                "NAS에서 SSH(SFTP) 서비스를 켜야 합니다. 포트가 22가 아니면 주소 뒤에 :포트를 붙이세요.",
                "암호화 때문에 큰 영상은 끊길 수 있습니다. 가능하면 NFS나 SMB를 쓰세요."),
    "ftp://": ("ftp://아이디:비밀번호@NAS주소/폴더", "ftp://admin:1234@192.168.0.10/영화",
               "NAS에서 FTP 서비스를 켜야 합니다. 기본 포트는 21입니다.",
               "비밀번호가 암호화 없이 오갑니다. 집 안 네트워크에서만 쓰세요."),
    "dav://": ("dav://아이디:비밀번호@NAS주소:포트/폴더", "dav://admin:1234@192.168.0.10:5005/영화",
               "NAS의 WebDAV 서버 설정에서 포트를 확인하세요. rclone serve webdav도 이 방식입니다.",
               "포트를 빼면 안 열립니다. 보안 연결을 켰다면 davs:// 를 쓰세요."),
    "davs://": ("davs://아이디:비밀번호@NAS주소:포트/폴더", "davs://admin:1234@192.168.0.10:5006/영화",
                "WebDAV를 https로 켠 경우입니다. 포트는 NAS의 WebDAV 설정에서 확인하세요.",
                "인증서가 자체 발급이면 연결이 거부될 수 있습니다."),
    "http://": ("http://주소:포트/폴더/", "http://192.168.0.10:8080/영화/",
                "웹 서버가 파일 목록을 보여 주는 주소여야 합니다.",
                "서버에 따라 폴더 탐색만 되고 라이브러리 스캔은 안 될 수 있습니다."),
    "https://": ("https://주소:포트/폴더/", "https://nas.example.com/영화/",
                 "http:// 와 같고 보안 연결만 다릅니다.",
                 "서버에 따라 폴더 탐색만 되고 라이브러리 스캔은 안 될 수 있습니다."),
    "upnp://": ("upnp://", "upnp://",
                "주소를 입력하지 않습니다. NAS의 미디어 서버(DLNA) 기능을 켜 두면 같은 네트워크에서 자동으로 나옵니다.",
                "찾지 못하면 NAS와 이 기기가 같은 공유기에 연결됐는지 확인하세요."),
}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.km] PKM_SOURCE_WIZARD_R108 %s" % msg, level)


def _fmt(n):
    try:
        return "{:,}".format(int(n))
    except Exception:
        return str(n)


def _browse_roots():
    rows, seen = [], set()

    def add(label, path, sub):
        key = (path or "").rstrip("/\\").lower()
        if not path or key in seen:
            return
        seen.add(key)
        rows.append({"kind": "dir", "label": label, "path": path, "sub": sub})

    for src in pkm_sources.kodi_video_sources():
        add(src.get("label") or src.get("file"), src.get("file") or "", "Kodi 비디오 소스")
    try:
        from resources.lib import pkm_settings_flow as sf
        for label, path in sf._kodi_file_sources_v1700():
            add(label, path, "Kodi 소스")
        for label, path in sf._local_storage_roots_v1700():
            if path.startswith("special://"):
                continue
            add(label, path, "이 기기")
    except Exception:
        _log("roots_fallback err=%s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return rows


def _join(path, name):
    base = pkm_sources.normalize_folder(path)
    sep = "\\" if base.endswith("\\") else "/"
    return base + name.rstrip("/\\") + sep


def _list_dirs(path):
    dirs, _files = xbmcvfs.listdir(pkm_sources.normalize_folder(path))
    names = sorted([str(d).rstrip("/\\") for d in (dirs or []) if str(d).strip() and not str(d).startswith(".")],
                   key=lambda s: s.lower())
    return [{"kind": "dir", "label": n, "path": _join(path, n), "sub": ""} for n in names]


def _real_parent(path):
    """상위 폴더 경로. 저장소 최상위이면 빈 문자열."""
    p = str(path or "").replace("\\", "/").rstrip("/")
    if not p:
        return ""
    head = p.rpartition("/")[0]
    if "://" in p:
        rest = head.split("://", 1)[1] if "://" in head else ""
        return head + "/" if rest.count("/") >= 1 and rest.split("/")[1] != "" else ""
    if head in ("", "/storage", "/storage/emulated", "/mnt"):
        return ""
    return head + "/"


class SourceWizardDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.mode = kwargs.pop("mode", "first_run")
        self.result = None
        self._step = "source"
        self._history = []
        self._browse_stack = []      # visited folder paths ("" = roots)
        self._rows = []
        self._content_path = ""
        self._scan_thread = None
        self._scan_stop = threading.Event()
        self._closing = False
        self._sel_r465 = {}          # path -> checked (R465 multi-select)
        self._counts_r465 = {}       # path -> count_folder() result
        self._count_stop_r465 = threading.Event()
        super(SourceWizardDialog, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- setup
    def onInit(self):
        self._opened_ts = time.time()
        try:
            self.setProperty("PlexKM.Wiz.Header", "PlexKM 시작 설정" if self.mode == "first_run" else "라이브러리 추가")
            self.setProperty("PlexKM.Wiz.SourceTitle", "어디에서 콘텐츠를 불러올까요?" if self.mode == "first_run"
                             else "어떤 라이브러리를 추가할까요?")
            self.setProperty("PlexKM.Wiz.SourceHint", "설정을 마치면 PlexKM설정 › 라이브러리에서 다른 라이브러리를 추가할 수 있습니다"
                             if self.mode == "first_run" else "추가한 라이브러리는 홈과 검색에 함께 나옵니다")
            self.setProperty("PlexKM.Wiz.PlexConnected", "1" if (pkm_sources.has_plex() and pkm_sources.plex_credentials_ready()) else "")
            self.setProperty("PlexKM.Wiz.KodiConnected", "1" if pkm_sources.has_kodi() else "")
            try:  # R256: Plex signed in but no library chosen yet -> not "연결됨"
                from resources.lib import pkm_sync as _sync256
                pend256 = bool(self.getProperty("PlexKM.Wiz.PlexConnected") == "1" and not _sync256.initial_setup_completed())
            except Exception:
                pend256 = False
            self.setProperty("PlexKM.Wiz.PlexPending", "1" if pend256 else "")
            self.setProperty("PlexKM.Wiz.CanExit", "1" if self.mode == "first_run" else "")
            # Adding from Settings: the already-connected Plex card is not the likely target.
            first = CARD_KODI if (self.mode != "first_run" and self.getProperty("PlexKM.Wiz.PlexConnected") == "1") else CARD_PLEX
            if self.mode == "scan_queue":
                # R465: 라이브러리 관리 > 스캔 대기 폴더 스캔 -> straight to the progress screen.
                self.setProperty("PlexKM.Wiz.Header", "라이브러리 스캔")
                self._start_queue_watch_r465(self._run_id_r465 if hasattr(self, "_run_id_r465") else "")
            elif self.mode in ("add_folder", "add_movies", "add_tvshows", "add_videos", "add_auto", "add_musicvideos"):
                # R334: opened from 내 저장소 > 폴더 추가 - straight to the folder browser.
                # R335: from 라이브러리 > 라이브러리 추가 the type is already chosen.
                self.setProperty("PlexKM.Wiz.Header", {"add_movies": "영화 폴더 추가", "add_tvshows": "드라마 폴더 추가", "add_videos": "영상 폴더 추가", "add_musicvideos": "뮤직비디오 폴더 추가", "add_auto": "상위 폴더로 추가"}.get(self.mode, "폴더 추가"))
                self._browse_stack = []
                self._show_browse("", push=False)
            else:
                self._goto("source", push=False, focus=first)
            _log("open mode=%s plex=%s kodi=%s" % (self.mode, self.getProperty("PlexKM.Wiz.PlexConnected") or "0",
                                                  self.getProperty("PlexKM.Wiz.KodiConnected") or "0"))
        except Exception:
            _log("init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            self.close()

    def _goto(self, step, push=True, focus=None):
        if push and self._step != step:
            self._history.append(self._step)
        self._step = step
        dot = {"source": 1, "kodi_found": 2, "browse": 2, "content": 2, "netpath": 2, "scan": 3}.get(step, 1)  # R255: step 1 of 3 (Plex path continues in PKM settings: 2, 3)
        self.setProperty("PlexKM.Wiz.Dot", str(dot))
        self.setProperty("PlexKM.Wiz.Step", step)
        target = focus or {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                           "content": BTN_MOVIES, "netpath": NET_KEYS, "scan": BTN_SCAN_DONE}.get(step)
        if step == "scan" and self.getProperty("PlexKM.Wiz.ScanMulti") == "1":
            target = 803
        if step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            xbmc.sleep(10)
            self.setFocusId(target)
        except Exception:
            pass

    def _refocus(self):
        target = {"source": CARD_PLEX, "kodi_found": BTN_USE, "browse": LIST_BROWSE,
                  "content": BTN_MOVIES, "netpath": NET_KEYS, "scan": BTN_SCAN_DONE}.get(self._step, CARD_PLEX)
        if self._step == "scan" and self.getProperty("PlexKM.Wiz.ScanMulti") == "1":
            target = 803
        if self._step == "kodi_found" and self.getProperty("PlexKM.Wiz.FoundHasItems") != "1":
            target = BTN_ADD
        try:
            self.setFocusId(target)
            _log("refocus step=%s control=%d" % (self._step, target))
        except Exception:
            pass

    def _back(self):
        if self._step == "scan":
            if self.getProperty("PlexKM.Wiz.ScanMulti") == "1":
                # R465: Back = 백그라운드로 계속 (or 확인 when done).
                self._background_notice_r465()
                self._close(getattr(self, "_scan_result", None))
            return  # the old single scan step only closes through its button
        if self._step == "browse" and self._browse_stack:
            self._browse_stack.pop()
            self._show_browse(self._browse_stack[-1] if self._browse_stack else "", push=False)
            return
        if self._history:
            prev = self._history.pop()
            self._goto(prev, push=False)
            return
        if self.mode == "first_run":
            # R259: a stray/late Back (e.g. from closing the settings page) closed the first-run
            # wizard within 0.2 s and left PKM Home dead. Leave only via a card or "Kodi 종료".
            # Back on the very first screen has nothing to go back to: ask instead of ignoring.
            # Ignore a stray Back right after opening, and never stack two confirmations.
            if time.time() - float(getattr(self, "_opened_ts", 0) or 0) < 1.5 or getattr(self, "_back_confirm_open", False):
                _log("back_ignored_first_run")
                return
            self._back_confirm_open = True

            def _ask():
                leave = False
                try:
                    from resources.lib import pkm_settings_flow as _psf
                    keep = _psf.open_pkm_confirm_dialog(
                        "설정을 마치지 않았습니다",
                        "지금 나가면 Kodi가 종료됩니다.[CR]설정을 계속할까요?",
                        yes_label="설정 계속", no_label="Kodi 종료")
                    leave = not keep
                except Exception:
                    _log("back_confirm_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                finally:
                    self._back_confirm_open = False
                if leave and not self._closing:
                    _log("back_confirm_exit")
                    self._exit_under_card()

            threading.Thread(target=_ask, daemon=True).start()
            return
        self._close(None)

    def _exit_under_card(self):
        """R339: 'Kodi 종료' — show the 3-2-1 card first and close the wizard only once the card
        is on screen, so the old UI underneath never flashes between the two windows."""
        if self._closing:
            return
        self._closing = True

        def _run():
            try:
                from resources.lib.pkm_kodi_exit_v2171 import request_kodi_exit_v2171 as _quit
                _quit(reason="first_run_exit_r339", title="Kodi 종료",
                      detail="설정을 마치지 않아 Kodi를 종료합니다.",
                      on_shown=lambda: self._close({"choice": "exit"}))
            except Exception:
                _log("exit_under_card_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            finally:
                try:
                    self._close({"choice": "exit"})
                except Exception:
                    pass

        threading.Thread(target=_run, name="PKMWizExitR339", daemon=True).start()

    def _close(self, result):
        try:
            self._count_stop_r465.set()
        except Exception:
            pass
        self.result = result
        self._closing = True
        self._scan_stop.set()
        self.close()

    # ---------------------------------------------------------------- input
    def onAction(self, action):
        try:
            if self._step == "netpath" and (self._net_help_nav(action) or self._net_action(action)):
                return
            if action.getId() in ACTION_BACK:
                self._back()
                return
            if (action.getId() == ACTION_RIGHT_R465 and self._step == "browse" and self.mode in MULTI_MODES_R465
                    and self.getFocusId() == LIST_BROWSE):
                self._toggle_r465()
                return
            # Focus lost (e.g. a mouse move over empty space): any key restores it.
            if action.getId() not in (107, 100, 101, 102, 103, 104, 105, 106) and not self.getFocusId():
                self._refocus()
            elif action.getId() not in (107, 100, 101, 102, 103, 104, 105, 106):
                allowed = self._step_controls_r465()
                if allowed and self.getFocusId() not in allowed:
                    self._refocus()
        except Exception:
            _log("action_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def _step_controls_r465(self):
        return {"source": (CARD_PLEX, CARD_KODI, BTN_EXIT), "kodi_found": (BTN_USE, BTN_ADD),
                "browse": (LIST_BROWSE,), "content": (BTN_MOVIES, BTN_TV),
                "netpath": (NET_CHIPS, NET_KEYS, NET_CANCEL, NET_OK, NET_HELP),
                "scan": (BTN_SCAN_DONE, 803, LIST_SCAN_R465)}.get(self._step, ())

    def onClick(self, controlId):
        try:
            # R465: a control of a hidden step can catch focus (mouse left the list,
            # Kodi fell back to defaultcontrol 401 = Plex card).  Never act on it.
            allowed = self._step_controls_r465()
            if allowed and controlId not in allowed:
                _log("click_ignored_hidden control=%s step=%s" % (controlId, self._step))
                self._refocus()
                return
            if controlId == BTN_EXIT:
                _log("choice=exit_to_kodi")
                self._exit_under_card()
                return
            if controlId == CARD_PLEX:
                _log("choice=plex")
                self._close({"choice": "plex"})
            elif controlId == CARD_KODI:
                self._show_kodi_found()
            elif controlId == BTN_USE:
                pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_LIBRARY, "", label="Kodi 라이브러리",
                                            reason="wizard_use_existing")
                self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_LIBRARY, "path": ""})
            elif controlId == BTN_ADD:
                self._browse_stack = []
                self._show_browse("", push=True)
            elif controlId == LIST_BROWSE:
                self._browse_click()
            elif controlId == NET_CHIPS:
                self._net_chip()
            elif controlId == NET_KEYS:
                self._net_key()
            elif controlId == NET_CANCEL:
                self._back()
            elif controlId == NET_OK:
                self._net_confirm()
            elif controlId == NET_HELP:
                self._net_help_toggle()
            elif controlId in (BTN_MOVIES, BTN_TV):
                content = pkm_sources.KODI_CONTENT_MOVIES if controlId == BTN_MOVIES else pkm_sources.KODI_CONTENT_TVSHOWS
                self._start_scan(content)
            elif controlId in (BTN_SCAN_DONE, 803):
                self._background_notice_r465()
                self._close(getattr(self, "_scan_result", None))
        except Exception:
            _log("click_failed control=%s %s" % (controlId, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)

    # ---------------------------------------------------------------- kodi
    def _show_kodi_found(self):
        movies, shows = pkm_sources.kodi_library_counts()
        has = (movies + shows) > 0
        self.setProperty("PlexKM.Wiz.FoundHasItems", "1" if has else "")
        if has:
            parts = []
            if movies:
                parts.append("영화 %s편" % _fmt(movies))
            if shows:
                parts.append("드라마 %s개" % _fmt(shows))
            self.setProperty("PlexKM.Wiz.FoundTitle", "Kodi 라이브러리를 찾았습니다")
            self.setProperty("PlexKM.Wiz.FoundSub", " · ".join(parts) + "\n이대로 쓰거나 폴더를 더 추가할 수 있습니다")
            self.setProperty("PlexKM.Wiz.FoundUse", "이대로 사용")
        else:
            self.setProperty("PlexKM.Wiz.FoundTitle", "영상 폴더를 추가하세요")
            self.setProperty("PlexKM.Wiz.FoundSub", "영화나 드라마가 들어 있는 폴더를 고르면\n정보와 포스터를 자동으로 가져옵니다")
        _log("kodi_found movies=%d shows=%d" % (movies, shows))
        self._goto("kodi_found")

    def _show_browse(self, path, push=False):
        self.setProperty("PlexKM.Wiz.Busy", "1")
        rows = []
        try:
            if not path:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영화·드라마 폴더가 모여 있는 폴더를 고르세요" if self.mode == "add_auto" else "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", "저장소")
                rows = _browse_roots()
                rows.append({"kind": "manual", "label": "네트워크 경로 직접 입력", "path": "",
                             "sub": "smb · nfs · ftp · WebDAV 등"})
            elif self.mode in MULTI_MODES_R465:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "추가할 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", path)
                rows = self._multi_rows_r465(path)
            else:
                self.setProperty("PlexKM.Wiz.BrowseTitle", "영화·드라마 폴더가 모여 있는 폴더를 고르세요" if self.mode == "add_auto" else "영상이 있는 폴더를 고르세요")
                self.setProperty("PlexKM.Wiz.BrowsePath", path)
                rows = [{"kind": "select", "label": "이 폴더 선택", "path": path, "sub": ""},
                        {"kind": "up", "label": "상위 폴더", "path": "", "sub": ""}]
                try:
                    rows += _list_dirs(path)
                except Exception:
                    rows.append({"kind": "none", "label": "폴더를 열 수 없습니다", "path": "", "sub": ""})
        finally:
            self.setProperty("PlexKM.Wiz.Busy", "")
        self._rows = rows
        items = []
        multi = bool(path) and self.mode in MULTI_MODES_R465
        self.setProperty("PlexKM.Wiz.MultiR465", "1" if multi else "")
        for row in rows:
            li = xbmcgui.ListItem(label=row["label"], label2=row.get("sub", ""))
            icon = {"select": "check_32.png", "up": "up_32.png", "manual": "cat_server_48.png",
                    "addsel": "check_32.png", "selall": "check_32.png"}.get(row["kind"], "cat_folder_48.png")
            li.setArt({"icon": MEDIA + icon})
            if multi and row["kind"] == "dir":
                li.setProperty("check", "1" if self._sel_r465.get(row["path"], True) else "0")
            items.append(li)
        lst = self.getControl(LIST_BROWSE)
        lst.reset()
        lst.addItems(items)
        if self._step != "browse":
            self._goto("browse", push=push)
        else:
            self.setFocusId(LIST_BROWSE)
        lst.selectItem(0)
        if multi and getattr(self, "_open_failed_r465", "") == path:
            self._open_failed_r465 = ""
            threading.Thread(target=self._open_failed_ask_r465, args=(path,), name="PKMWizOpenFailR465").start()
        elif multi:
            self._start_count_r465(path)

    def _browse_click(self):
        try:
            pos = int(self.getControl(LIST_BROWSE).getSelectedPosition())
            row = self._rows[pos]
        except Exception:
            return
        kind = row.get("kind")
        if kind == "addsel":
            self._add_selected_r465()
            return
        if kind == "selall":
            dirs = [r for r in self._rows if r.get("kind") == "dir"]
            want = not all(self._sel_r465.get(r["path"], True) for r in dirs)
            for r in dirs:
                self._sel_r465[r["path"]] = want
            self._refresh_multi_r465()
            return
        if kind == "dir":
            self._count_stop_r465.set()
            self._browse_stack.append(row["path"])
            self._show_browse(row["path"])
        elif kind == "up":
            # R336: 등록된 폴더로 바로 들어온 경우에도 실제 상위 폴더로 올라간다.
            cur = self._browse_stack[-1] if self._browse_stack else ""
            parent = _real_parent(cur) if len(self._browse_stack) == 1 else ""
            if parent:
                self._browse_stack[-1] = parent
                self._show_browse(parent, push=False)
            else:
                self._back()
        elif kind == "manual":
            self._manual_path()
        elif kind == "select":
            self._content_path = pkm_sources.normalize_folder(row["path"])
            self.setProperty("PlexKM.Wiz.ContentPath", self._content_path)
            if self.mode == "add_videos":
                label = self._content_path.rstrip("/\\").replace("\\", "/").split("/")[-1] or self._content_path
                pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_VIDEOS, self._content_path, label=label,
                                            reason="wizard_videos")
                self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_VIDEOS, "path": self._content_path})
                return
            if self.mode == "add_auto":
                self._auto_detect_and_scan(self._content_path)
                return
            if self.mode == "add_musicvideos":
                self._add_musicvideos_r337(self._content_path)
                return
            preset = {"add_movies": pkm_sources.KODI_CONTENT_MOVIES,
                      "add_tvshows": pkm_sources.KODI_CONTENT_TVSHOWS}.get(self.mode)
            if preset:
                self._goto("scan")
                self._start_scan(preset)
            else:
                self._goto("content")

    # ---------------------------------------------------------------- R465 multi-select
    def _multi_rows_r465(self, path):
        rows = [{"kind": "addsel", "label": "", "path": path, "sub": ""},
                {"kind": "selall", "label": "전체 선택 · 해제", "path": path, "sub": ""},
                {"kind": "up", "label": "상위 폴더", "path": "", "sub": ""}]
        from resources.lib import pkm_scan_queue_r465 as _sq0
        if not _sq0.readable(path):
            self._open_failed_r465 = path
        try:
            subs = _list_dirs(path)
        except Exception:
            subs = []
            self._open_failed_r465 = path
        if getattr(self, "_open_failed_r465", "") == path:
            rows.append({"kind": "none", "label": "폴더를 열 수 없습니다", "path": "", "sub": ""})
        from resources.lib import pkm_scan_queue_r465 as sq
        subs = [r for r in subs if not sq._skip_dir(r["label"])]
        for r in subs:
            c = self._counts_r465.get(r["path"])
            r["sub"] = self._count_text_r465(c) if c else "목록 읽는 중"
            rows.append(r)
        self._rows = rows
        rows[0]["label"] = self._addsel_label_r465()
        return rows

    def _content_r465(self):
        return pkm_sources.KODI_CONTENT_TVSHOWS if self.mode == "add_tvshows" else pkm_sources.KODI_CONTENT_MOVIES

    def _count_text_r465(self, c):
        if not c:
            return "목록 읽는 중"
        if c.get("error"):
            return "폴더를 읽지 못함"
        if self._content_r465() == pkm_sources.KODI_CONTENT_TVSHOWS:
            return "드라마 %s작품" % _fmt(c.get("total", 0))
        return "영화 %s편" % _fmt(c.get("total", 0))

    def _picked_r465(self):
        """(paths, all_selected).  Every sub-folder checked = the current folder itself."""
        cur = self._browse_stack[-1] if self._browse_stack else ""
        dirs = [r for r in self._rows if r.get("kind") == "dir"]
        chosen = [r["path"] for r in dirs if self._sel_r465.get(r["path"], True)]
        if dirs and self._content_r465() == pkm_sources.KODI_CONTENT_TVSHOWS:
            # Kodi reads a TV folder as "one sub-folder = one show".  When the
            # sub-folders are groups (미국 드라마, 일본 드라마) each one is its own root.
            groups = getattr(self, "_tv_groups_r465", {})
            if cur not in groups:
                groups[cur] = not all(self._is_show_r465(r["path"]) for r in dirs[:12])
                self._tv_groups_r465 = groups
            if groups[cur]:
                return chosen, False
        if not dirs or len(chosen) == len(dirs):
            return [cur], True
        return chosen, False

    def _addsel_label_r465(self):
        paths, whole = self._picked_r465()
        dirs = [r for r in self._rows if r.get("kind") == "dir"]
        kind = "영화" if self._content_r465() == pkm_sources.KODI_CONTENT_MOVIES else "드라마"
        unit = "편" if kind == "영화" else "작품"
        if whole:
            cur = paths[0]
            c = self._counts_r465.get(cur)
            if c is None and dirs:
                parts = [self._counts_r465.get(r["path"]) for r in dirs]
                c = None if any(x is None for x in parts) else {"total": sum(x["total"] for x in parts)}
            n = ("%s %s%s" % (kind, _fmt(c["total"]), unit)) if c else "목록 읽는 중"
            return ("선택한 폴더 추가 · %d개 · %s" % (len(dirs), n)) if dirs else ("이 폴더 추가 · %s" % n)
        if not paths:
            return "추가할 폴더를 고르세요"
        cs = [self._counts_r465.get(p) for p in paths]
        n = "목록 읽는 중" if any(x is None for x in cs) else "%s %s%s" % (kind, _fmt(sum(x["total"] for x in cs)), unit)
        bad = len([x for x in cs if x and x.get("error")])
        return "선택한 폴더 추가 · %d개 · %s%s" % (len(paths), n, (" · 읽지 못함 %d개" % bad) if bad else "")

    def _toggle_r465(self):
        try:
            pos = int(self.getControl(LIST_BROWSE).getSelectedPosition())
            row = self._rows[pos]
        except Exception:
            return
        if row.get("kind") != "dir":
            return
        self._sel_r465[row["path"]] = not self._sel_r465.get(row["path"], True)
        self._refresh_multi_r465()

    def _refresh_multi_r465(self):
        try:
            lst = self.getControl(LIST_BROWSE)
            for i, row in enumerate(self._rows):
                li = lst.getListItem(i)
                if row.get("kind") == "dir":
                    li.setProperty("check", "1" if self._sel_r465.get(row["path"], True) else "0")
                    c = self._counts_r465.get(row["path"])
                    li.setLabel2(self._count_text_r465(c) if c else "목록 읽는 중")
                elif row.get("kind") == "addsel":
                    li.setLabel(self._addsel_label_r465())
        except Exception:
            pass

    def _start_count_r465(self, path):
        self._count_stop_r465.set()
        stop = threading.Event()
        self._count_stop_r465 = stop
        content = self._content_r465()
        targets = [r["path"] for r in self._rows if r.get("kind") == "dir" and r["path"] not in self._counts_r465]
        if not [r for r in self._rows if r.get("kind") == "dir"] and path not in self._counts_r465:
            targets = [path]
        lock = threading.Lock()

        def _work():
            from resources.lib import pkm_scan_queue_r465 as sq
            while not stop.is_set():
                with lock:
                    if not targets:
                        return
                    t = targets.pop(0)
                c = sq.count_folder(t, content, stop)
                if stop.is_set():
                    return
                self._counts_r465[t] = c
                self._refresh_multi_r465()
        # R465: cloud drives answer each folder listing slowly -> 6 folders at once.
        for i in range(min(6, len(targets))):
            th = threading.Thread(target=_work, name="PKMWizCountR465_%d" % i)
            th.daemon = True
            th.start()

    def _open_failed_ask_r465(self, path):
        from resources.lib import pkm_settings_flow as psf
        from resources.lib import pkm_scan_queue_r465 as sq
        pick = psf.open_pkm_choice_dialog_r465(
            "폴더를 열 수 없습니다", "%s[CR]네트워크나 클라우드 드라이브 연결을 확인하세요" % sq.label_of(path),
            yes_label="다시 시도", no_label="이전으로")
        _log("r465_open_failed choice=%s" % (pick or "back"))
        if pick == "yes":
            self._show_browse(path, push=False)
        else:
            self._back()

    def _retry_count_r465(self, paths):
        content = self._content_r465()

        def _work():
            from resources.lib import pkm_scan_queue_r465 as sq
            for p in paths:
                self._counts_r465[p] = sq.count_folder(p, content)
                self._refresh_multi_r465()
        th = threading.Thread(target=_work, name="PKMWizRecountR465")
        th.daemon = True
        th.start()

    def _add_selected_r465(self):
        from resources.lib import pkm_scan_queue_r465 as sq
        from resources.lib import pkm_settings_flow as psf
        paths, whole = self._picked_r465()
        if not paths or not paths[0]:
            return
        content = self._content_r465()
        kind = "영화" if content == pkm_sources.KODI_CONTENT_MOVIES else "드라마"
        unit = "편" if kind == "영화" else "작품"
        # counts the background thread has not reached yet
        self.setProperty("PlexKM.Wiz.Busy", "1")
        self.setProperty("PlexKM.Wiz.BusyText", "작품 개수를 확인하는 중")
        try:
            picked = []
            for p in paths:
                c = self._counts_r465.get(p)
                if c is None and whole:
                    subs = [r["path"] for r in self._rows if r.get("kind") == "dir"]
                    parts = [self._counts_r465.get(x) or sq.count_folder(x, content) for x in subs]
                    if parts:
                        c = {"total": sum(x["total"] for x in parts), "episodes": sum(x.get("episodes", 0) for x in parts),
                             "files": [f for x in parts for f in x.get("files", [])]}
                if c is None:
                    c = sq.count_folder(p, content)
                self._counts_r465[p] = c
                picked.append((p, c))
        finally:
            self.setProperty("PlexKM.Wiz.Busy", "")
            self.setProperty("PlexKM.Wiz.BusyText", "")
        bad = [p for p, c in picked if c.get("error")]
        if bad:
            names = " · ".join(sq.label_of(p) for p in bad[:3]) + (" 외 %d개" % (len(bad) - 3) if len(bad) > 3 else "")
            if len(bad) == len(picked):
                pick = psf.open_pkm_choice_dialog_r465(
                    "폴더를 읽지 못했습니다", "%s[CR]네트워크나 클라우드 드라이브 연결을 확인하세요" % names,
                    yes_label="다시 시도", no_label="이전으로")
            else:
                pick = psf.open_pkm_choice_dialog_r465(
                    "읽지 못한 폴더가 %d개 있습니다" % len(bad),
                    "%s[CR]다시 시도하거나, 이 폴더를 빼고 나머지 %d개만 추가할 수 있습니다" % (names, len(picked) - len(bad)),
                    yes_label="다시 시도", no_label="나머지만 추가")
            _log("r465_count_error folders=%d choice=%s" % (len(bad), pick or "back"))
            if pick == "yes":
                for p in bad:
                    self._counts_r465.pop(p, None)
                self._refresh_multi_r465()
                self._retry_count_r465(bad)
                return
            if pick is None:
                self.setFocusId(LIST_BROWSE)
                return
            if len(bad) == len(picked):      # 이전으로
                self._back()
                return
            picked = [(p, c) for p, c in picked if not c.get("error")]
        total = sum(c["total"] for _p, c in picked)
        names = " · ".join(sq.label_of(p) for p, _c in picked[:4]) + (" 외 %d개" % (len(picked) - 4) if len(picked) > 4 else "")
        body = "%s[CR]%s %s%s" % (names, kind, _fmt(total), unit)
        choice = psf.open_pkm_choice_dialog_r465("%s 폴더 %d개를 추가합니다" % (kind, len(picked)), body,
                                                 yes_label="지금 스캔", no_label="나중에 스캔")
        _log("r465_add choice=%s folders=%d total=%d" % (choice or "back", len(picked), total))
        if choice is None:
            self.setFocusId(LIST_BROWSE)
            return
        single = (content == pkm_sources.KODI_CONTENT_TVSHOWS and not whole)
        ids = []
        for p, c in picked:
            fid = sq.add(content, p, c["total"], files=c.get("files"), single_show=single and self._is_show_r465(p))
            if fid:
                ids.append(fid)
        if not ids:
            psf.open_pkm_confirm_dialog("폴더를 등록하지 못했습니다", "Kodi 비디오 데이터베이스를 열 수 없습니다", yes_label="확인", no_label="")
            return
        if choice == "no":
            self._notice_r465("ok", "%s 폴더 %d개를 등록했습니다" % (kind, len(ids)),
                              "라이브러리 관리에서 '스캔 대기 폴더 스캔'으로 스캔하세요")
            self._close({"choice": "kodi", "content": content, "path": paths[0], "queued": ids, "later": True})
            return
        run_id = sq.request_run(ids)
        self._scan_result = {"choice": "kodi", "content": content, "path": paths[0], "queued": ids}
        self._start_queue_watch_r465(run_id)

    def _is_show_r465(self, path):
        """A folder holding episodes (or season folders) is one show."""
        try:
            dirs, files = xbmcvfs.listdir(pkm_sources.normalize_folder(path))
        except Exception:
            return False
        from resources.lib import pkm_scan_queue_r465 as sq
        if any(sq._is_video(str(f)) for f in files or []):
            return True
        import re
        return any(re.match(r"(?i)^(season|시즌|s)\s*\d+", str(d).strip()) for d in dirs or [])

    def _notice_r465(self, kind, title, line1="", line2=""):
        try:
            from resources.lib import pkm_notify
            if hasattr(pkm_notify, "pkm_notice_kind"):
                pkm_notify.pkm_notice_kind(kind, title, line1, line2)
            else:
                tok = pkm_notify.pkm_notice_set(title, line1, line2, force_replace=True)
                pkm_notify.pkm_notice_clear_later(tok, ms=6000)
        except Exception:
            pass

    # ---------------------------------------------------------------- R465 progress
    def _start_queue_watch_r465(self, run_id):
        from resources.lib import pkm_scan_queue_r465 as sq
        if not run_id:
            run_id = sq.request_run()
        self._run_id_r465 = run_id
        if not getattr(self, "_scan_result", None):
            self._scan_result = {"choice": "kodi", "content": "", "path": "", "queued": [], "run": run_id}
        self.setProperty("PlexKM.Wiz.ScanMulti", "1")
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        self._scan_stop.clear()
        th = threading.Thread(target=self._queue_watch_r465, args=(run_id,), name="PKMWizQueueWatchR465")
        th.daemon = True
        th.start()

    def _queue_watch_r465(self, run_id):
        from resources.lib import pkm_scan_queue_r465 as sq
        monitor = xbmc.Monitor()
        win = xbmcgui.Window(10000)
        built = False
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            rows = sq.run_rows(run_id)
            done = win.getProperty(sq.PROP_DONE) == run_id
            self._render_progress_r465(rows, done, rebuild=not built)
            built = True
            if done:
                self.setProperty("PlexKM.Wiz.ScanDone", "1")
                self.setProperty("PlexKM.Wiz.ScanButton", "확인")
                errs = [r["id"] for r in rows if r.get("status") == "error"]
                if errs and not self._scan_stop.is_set():
                    from resources.lib import pkm_settings_flow as psf
                    pick = psf.open_pkm_choice_dialog_r465(
                        "읽지 못한 폴더가 %d개 있습니다" % len(errs),
                        "네트워크나 클라우드 드라이브 연결을 확인한 뒤[CR]그 폴더만 다시 스캔할 수 있습니다",
                        yes_label="다시 시도", no_label="닫기")
                    _log("r465_scan_error folders=%d choice=%s" % (len(errs), pick or "back"))
                    if pick == "yes":
                        run_id = sq.request_run(errs)
                        self._start_queue_watch_r465(run_id)
                return
            if monitor.waitForAbort(1.0):
                return

    def _render_progress_r465(self, rows, done, rebuild=False):
        from resources.lib import pkm_scan_queue_r465 as sq
        d, t, pct = sq.progress(rows)
        kinds = set(r.get("content") for r in rows)
        if len(kinds) == 1 and pkm_sources.KODI_CONTENT_MOVIES in kinds:
            unit_txt, head = "편", "영화 "
        elif len(kinds) == 1:
            unit_txt, head = "작품", "드라마 "
        else:
            unit_txt, head = "", "전체 "
        if done:
            self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
            self.setProperty("PlexKM.Wiz.ScanTotal", "")
        else:
            self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
            self.setProperty("PlexKM.Wiz.ScanTotal", "%s%s / %s%s · %d%%" % (head, _fmt(min(d, t)), _fmt(t), unit_txt, pct))
        self.setProperty("PlexKM.Wiz.ScanBar", _bar_r465(100 if done else pct))
        items = []
        for r in rows:
            tot, add = int(r.get("total") or 0), int(r.get("added") or 0)
            u = sq.unit(r.get("content"))
            st = r.get("status")
            if st == "error":
                txt, state, p = "폴더를 읽지 못했습니다", "오류", 0
            elif done or st == "done":
                txt = "%s%s 추가" % (_fmt(add), u)
                if r.get("content") == pkm_sources.KODI_CONTENT_TVSHOWS and r.get("episodes"):
                    txt = "%s%s · %s화 추가" % (_fmt(add), u, _fmt(r.get("episodes")))
                if r.get("unmatched"):
                    txt += " · 정보 못 찾음 %d개" % int(r.get("unmatched"))
                state, p = ("완료" if not done else ""), 100
            elif st == "scanning":
                txt, state, p = "%s / %s%s" % (_fmt(min(add, tot)), _fmt(tot), u), "스캔 중", (min(add, tot) * 100 // tot if tot else 0)
            else:
                txt, state, p = "%s / %s%s" % (0, _fmt(tot), u), "대기", 0
            li = xbmcgui.ListItem(label=r.get("label") or "", label2=txt)
            li.setProperty("kind", sq.kind_label(r.get("content")))
            li.setProperty("state", state)
            li.setProperty("active", "1" if st == "scanning" and not done else "")
            li.setArt({"bar": _bar_r465(p)})
            items.append(li)
        try:
            lst = self.getControl(LIST_SCAN_R465)
            if rebuild or lst.size() != len(items):
                lst.reset()
                lst.addItems(items)
            else:
                for i, li in enumerate(items):
                    cur = lst.getListItem(i)
                    cur.setLabel(li.getLabel())
                    cur.setLabel2(li.getLabel2())
                    for k in ("kind", "state", "active"):
                        cur.setProperty(k, li.getProperty(k))
                    cur.setArt({"bar": li.getArt("bar")})
        except Exception:
            _log("progress_render_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)

    def _background_notice_r465(self):
        """Leaving the progress screen while the scan still runs: say so once (chip stays)."""
        try:
            win = xbmcgui.Window(10000)
            if self.getProperty("PlexKM.Wiz.ScanMulti") != "1" or self.getProperty("PlexKM.Wiz.ScanDone") == "1":
                return
            if win.getProperty("PlexKM.Scan.Active") != "1":
                return
            from resources.lib import pkm_notify
            tok = pkm_notify.pkm_notice_kind("busy", win.getProperty("PlexKM.Scan.Title") or "라이브러리 스캔 중",
                                             win.getProperty("PlexKM.Scan.Line") or "",
                                             "스캔 중에는 홈 화면이 조금 느릴 수 있습니다",
                                             progress=int(win.getProperty("PlexKM.Scan.Pct") or 0))
            pkm_notify.pkm_notice_clear_later(tok, ms=7000)
        except Exception:
            pass

    def _install_musicagent_r463(self):
        """R463: the agent is an optional import, so Kodi never installs it by
        itself.  Install it from the KM repository right here and continue."""
        aid = "script.module.pkm.musicagent"
        mon = xbmc.Monitor()
        _log("MUSICAGENT_INSTALL_R463 begin has=%d" % (1 if xbmc.getCondVisibility("System.HasAddon(%s)" % aid) else 0))
        self.setProperty("PlexKM.Wiz.Busy", "1")
        self.setProperty("PlexKM.Wiz.BusyText", "뮤직비디오 구성 요소를 설치하고 있습니다")
        done = []

        def _auto_yes():
            t0 = time.time()
            while not done and time.time() - t0 < 90 and not mon.abortRequested():
                try:
                    if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
                        xbmc.executebuiltin("SendClick(11)")
                        mon.waitForAbort(0.6)
                        continue
                except Exception:
                    pass
                mon.waitForAbort(0.1)
        threading.Thread(target=_auto_yes, daemon=True).start()
        try:
            if not xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                xbmc.executebuiltin("InstallAddon(%s)" % aid)
            t0 = time.time()
            while time.time() - t0 < 90 and not mon.abortRequested():
                if xbmc.getCondVisibility("System.HasAddon(%s)" % aid):
                    break
                mon.waitForAbort(0.5)
            try:
                xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                                "params": {"addonid": aid, "enabled": True}}))
            except Exception:
                pass
            mon.waitForAbort(0.5)
            from resources.lib import pkm_musicvideo
            ok = pkm_musicvideo.available()
        finally:
            done.append(1)
            self.clearProperty("PlexKM.Wiz.Busy")
            self.clearProperty("PlexKM.Wiz.BusyText")
        _log("MUSICAGENT_INSTALL_R463 done ok=%d" % (1 if ok else 0))
        return ok

    def _add_musicvideos_r337(self, path):
        """R337: 뮤직비디오 폴더를 등록하고 바로 스캔한다. 읽기 모듈이 없으면 등록하지 않는다."""
        from resources.lib import pkm_musicvideo
        if not pkm_musicvideo.available() and not self._install_musicagent_r463():
            # R463: the notice sat behind this dialog, so the click looked dead.
            from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
            open_pkm_confirm_dialog("뮤직비디오 폴더 추가",
                                    "뮤직비디오를 읽는 구성 요소를 설치하지 못했습니다.[CR]"
                                    "KM 저장소가 설치되어 있는지, 인터넷이 연결되어 있는지 확인한 뒤 다시 선택해 주세요.",
                                    yes_label="확인", no_label="닫기", default_focus="yes")
            self.setFocusId(LIST_BROWSE)
            return
        from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
        if not open_pkm_confirm_dialog(pkm_musicvideo.GUIDE_TITLE, pkm_musicvideo.GUIDE_BODY,
                                       yes_label="스캔 시작", no_label="다시 고르기", default_focus="yes"):
            self.setFocusId(LIST_BROWSE)
            return
        label = path.rstrip("/\\").replace("\\", "/").split("/")[-1] or path
        pkm_sources.add_kodi_source(pkm_sources.KODI_CONTENT_MUSICVIDEOS, path, label=label, reason="wizard_musicvideos")
        sid = pkm_sources.kodi_source_id(pkm_sources.KODI_CONTENT_MUSICVIDEOS, path)
        src = next((s for s in pkm_musicvideo.sources() if s.get("id") == sid), None)
        if src is not None:
            pkm_musicvideo.scan_source(src)
        self._close({"choice": "kodi", "content": pkm_sources.KODI_CONTENT_MUSICVIDEOS, "path": path})

    def _auto_detect_and_scan(self, root):
        """R336: 고른 상위 폴더 아래의 영화/드라마 폴더를 자동으로 나눠 한 번에 등록한다."""
        from resources.lib import pkm_folder_detect
        from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
        try:
            found = pkm_folder_detect.detect(root)
        except Exception:
            _log("auto_detect_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
            found = []
        if not found:
            try:
                from resources.lib import pkm_notify
                pkm_notify.pkm_show_notice("상위 폴더로 추가", "영화·드라마 폴더가 없습니다",
                                           "폴더를 하나씩 직접 골라 추가하세요", ms=4200)
            except Exception:
                pass
            self.setFocusId(LIST_BROWSE)
            return
        movies = [f for f in found if f[2] == "movies"]
        shows = [f for f in found if f[2] == "tvshows"]
        lines = []
        if movies:
            lines.append("영화 %d개    %s" % (len(movies), ", ".join(f[1] for f in movies[:3]) + (" 외" if len(movies) > 3 else "")))
        if shows:
            lines.append("드라마 %d개    %s" % (len(shows), ", ".join(f[1] for f in shows[:3]) + (" 외" if len(shows) > 3 else "")))
        ok = open_pkm_confirm_dialog("이 폴더들을 추가할까요?", "\n".join(lines),
                                     yes_label="추가", no_label="다시 고르기", default_focus="yes")
        if not ok:
            self.setFocusId(LIST_BROWSE)
            return
        for path, label, kind in found:
            pkm_sources.add_kodi_source(kind, path, label=label, reason="wizard_auto")
            pkm_sources.kodi_register_path(path, kind)
        self._scan_result = {"choice": "kodi", "content": "auto", "path": root}
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
        self.setProperty("PlexKM.Wiz.ScanSub", "창을 닫아도 스캔은 계속됩니다")
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        before = pkm_sources.kodi_library_counts()
        pkm_sources.kodi_scan(None)
        self._scan_stop.clear()
        self._scan_thread = threading.Thread(target=self._scan_watch_auto, args=(before,), name="PKMSourceWizardAutoR336")
        self._scan_thread.daemon = True
        self._scan_thread.start()

    def _scan_watch_auto(self, before):
        started = False
        t0 = time.time()
        monitor = xbmc.Monitor()
        am = at = 0
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            scanning = pkm_sources.kodi_scanning()
            started = started or scanning
            now = pkm_sources.kodi_library_counts()
            am, at = max(0, now[0] - before[0]), max(0, now[1] - before[1])
            if scanning:
                self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 스캔하고 있습니다")
                self.setProperty("PlexKM.Wiz.ScanSub", "지금까지 영화 %s편 · 드라마 %s개 추가됨\n창을 닫아도 스캔은 계속됩니다" % (_fmt(am), _fmt(at)))
            if (started and not scanning) or (not started and time.time() - t0 > 8):
                break
            if monitor.waitForAbort(1.0):
                return
        if not self._scan_stop.is_set():
            self.setProperty("PlexKM.Wiz.ScanDone", "1")
            if am or at:
                self.setProperty("PlexKM.Wiz.ScanTitle", "영화 %s편 · 드라마 %s개를 추가했습니다" % (_fmt(am), _fmt(at)))
                self.setProperty("PlexKM.Wiz.ScanSub", "")
            else:
                self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
                self.setProperty("PlexKM.Wiz.ScanSub", "새로 찾은 작품이 없습니다\n폴더 이름이 작품 제목과 같은지 확인하세요")
            self.setProperty("PlexKM.Wiz.ScanButton", "완료")

    # ------------------------------------------------------- network path input (R338)
    def _manual_path(self):
        """smb/nfs/ftp/sftp/dav/... address typed in the PlexKM input step (no Kodi keyboard)."""
        self._net_text = getattr(self, "_manual_last", "") or "smb://"
        self._net_upper = False
        try:
            chips = self.getControl(NET_CHIPS)
            chips.reset()
            for scheme, desc in _NET_SCHEMES:
                it = xbmcgui.ListItem(scheme or "지우기")
                it.setLabel2(desc)
                chips.addItem(it)
            keys = self.getControl(NET_KEYS)
            keys.reset()
            for row in _NET_KEY_ROWS:
                for k in row:
                    keys.addItem(xbmcgui.ListItem(k))
        except Exception:
            _log("netpath_init_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self.setProperty("PlexKM.Wiz.NetHelp", "")
        self.setProperty("PlexKM.Wiz.NetHelpLabel", "도움말")
        self._net_refresh()
        self._goto("netpath")

    def _net_refresh(self):
        text = getattr(self, "_net_text", "")
        shown = text if len(text) <= 56 else text[-56:]
        self.setProperty("PlexKM.Wiz.NetShown", shown + "|")

    def _net_add(self, ch):
        self._net_text = getattr(self, "_net_text", "") + ch
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self._net_refresh()

    def _net_chip(self):
        try:
            pos = int(self.getControl(NET_CHIPS).getSelectedPosition())
            scheme = _NET_SCHEMES[pos][0]
        except Exception:
            return
        text = getattr(self, "_net_text", "")
        if not scheme:
            self._net_text = ""
        else:
            rest = text.split("://", 1)[1] if "://" in text else text
            self._net_text = scheme + rest
        self.setProperty("PlexKM.Wiz.NetNote", "")
        self._net_refresh()
        if scheme:
            self._net_fill_guide(scheme)

    def _net_scheme_now(self):
        text = str(getattr(self, "_net_text", "") or "")
        if "://" in text:
            sch = text.split("://", 1)[0].lower() + "://"
            if sch in _NET_GUIDE:
                return sch
        return "smb://"

    def _net_fill_guide(self, scheme):
        g = _NET_GUIDE.get(scheme) or _NET_GUIDE["smb://"]
        self.setProperty("PlexKM.Wiz.NetG1", "%s\n예  %s" % (g[0], g[1]))
        self.setProperty("PlexKM.Wiz.NetG2", g[2])
        self.setProperty("PlexKM.Wiz.NetG3", g[3])

    def _net_help_on(self):
        return self.getProperty("PlexKM.Wiz.NetHelp") == "1"

    def _net_help_toggle(self):
        if self._net_help_on():
            self.setProperty("PlexKM.Wiz.NetHelp", "")
            self.setProperty("PlexKM.Wiz.NetHelpLabel", "도움말")
            return
        self._net_fill_guide(self._net_scheme_now())
        self.setProperty("PlexKM.Wiz.NetHelp", "1")
        self.setProperty("PlexKM.Wiz.NetHelpLabel", "키보드")

    def _net_help_nav(self, action):
        """도움말 화면: Back closes it; Up/Down skip the hidden keyboard. True = handled."""
        if not self._net_help_on():
            return False
        aid = int(action.getId())
        if aid in ACTION_BACK:
            self._net_help_toggle()
            self.setFocusId(NET_HELP)
            return True
        fid = self.getFocusId()
        if aid == 4 and fid == NET_CHIPS:
            self.setFocusId(NET_HELP)
            return True
        if aid == 3 and fid in (NET_HELP, NET_CANCEL, NET_OK):
            self.setFocusId(NET_CHIPS)
            return True
        return False

    def _net_key(self):
        try:
            item = self.getControl(NET_KEYS).getSelectedItem()
            label = item.getLabel()
        except Exception:
            return
        if label == "지움":
            self._net_text = getattr(self, "_net_text", "")[:-1]
            self.setProperty("PlexKM.Wiz.NetNote", "")
            self._net_refresh()
        elif label == "공백":
            self._net_add(" ")
        elif label == "Aa":
            self._net_upper = not getattr(self, "_net_upper", False)
            try:
                keys = self.getControl(NET_KEYS)
                for n in range(keys.size()):
                    it = keys.getListItem(n)
                    lab = it.getLabel()
                    if len(lab) == 1 and lab.isalpha():
                        it.setLabel(lab.upper() if self._net_upper else lab.lower())
            except Exception:
                pass
        else:
            self._net_add(label)

    def _net_action(self, action):
        """Physical keyboard in the netpath step. True = handled."""
        try:
            aid, btn = int(action.getId()), int(action.getButtonCode())
        except Exception:
            return False
        if btn == 61448:   # Backspace key (also arrives as nav-back): delete one char, don't leave the step
            self._net_text = getattr(self, "_net_text", "")[:-1]
            self._net_refresh()
            return True
        for code in (aid, btn):
            ch = ""
            if 0xF100 <= code < 0xF200:
                ch = chr(code - 0xF100)
            elif 0xF200 <= code < 0xF400:
                ch = chr(code - 0xF200)
            if ch and ch.isprintable():
                self._net_add(ch)
                return True
        return False

    def _net_confirm(self):
        text = str(getattr(self, "_net_text", "") or "").strip()
        if not text or text in [s for s, _d in _NET_SCHEMES if s]:
            self.setProperty("PlexKM.Wiz.NetNote", "주소를 입력하세요")
            return
        if "://" not in text:
            text = "smb://" + text.lstrip("/\\")
        self._manual_last = text
        path = pkm_sources.normalize_folder(text)
        self.setProperty("PlexKM.Wiz.NetNote", "경로를 확인하는 중입니다")
        ok = False
        try:
            dirs, files = xbmcvfs.listdir(path)
            ok = bool(dirs or files) or xbmcvfs.exists(path)
        except Exception:
            ok = False
        if not ok:
            _log("manual_path_unreachable")
            self.setProperty("PlexKM.Wiz.NetNote", "그 경로를 열 수 없습니다. 주소, 계정, 공유 권한을 확인하세요")
            return
        _log("manual_path_ok scheme=%s" % path.split("://", 1)[0])
        self.setProperty("PlexKM.Wiz.NetNote", "")
        if self._history and self._history[-1] == "browse":
            self._history.pop()
        self._browse_stack.append(path)
        self._show_browse(path)

    # ---------------------------------------------------------------- scan
    def _start_scan(self, content):
        path = self._content_path
        label = path.rstrip("/\\").replace("\\", "/").split("/")[-1] or path
        pkm_sources.add_kodi_source(content, path, label=label, reason="wizard_folder")
        registered = pkm_sources.kodi_register_path(path, content)
        kind = "영화" if content == pkm_sources.KODI_CONTENT_MOVIES else "드라마"
        self._scan_result = {"choice": "kodi", "content": content, "path": path}
        self.setProperty("PlexKM.Wiz.ScanDone", "")
        self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
        self.setProperty("PlexKM.Wiz.ScanSub", "%s\n창을 닫아도 스캔은 계속됩니다" % label)
        self.setProperty("PlexKM.Wiz.ScanButton", "백그라운드로 계속")
        self._history = []
        self._goto("scan", push=False)
        if not registered:
            self._scan_finish(kind, 0, failed=True)
            return
        before = pkm_sources.kodi_library_counts()
        pkm_sources.kodi_scan(path)
        self._scan_stop.clear()
        self._scan_thread = threading.Thread(target=self._scan_watch, args=(kind, content, before),
                                             name="PKMSourceWizardScanR108")
        self._scan_thread.daemon = True
        self._scan_thread.start()

    def _scan_watch(self, kind, content, before):
        idx = 0 if content == pkm_sources.KODI_CONTENT_MOVIES else 1
        started = False
        t0 = time.time()
        monitor = xbmc.Monitor()
        added = 0
        while not self._scan_stop.is_set() and not monitor.abortRequested():
            scanning = pkm_sources.kodi_scanning()
            started = started or scanning
            now = pkm_sources.kodi_library_counts()
            added = max(0, now[idx] - before[idx])
            unit = "편" if idx == 0 else "개"
            if scanning:
                self.setProperty("PlexKM.Wiz.ScanTitle", "%s 폴더를 스캔하고 있습니다" % kind)
                self.setProperty("PlexKM.Wiz.ScanSub", "지금까지 %s %s%s 추가됨\n창을 닫아도 스캔은 계속됩니다" % (kind, _fmt(added), unit))
            if (started and not scanning) or (not started and time.time() - t0 > 8):
                break
            if monitor.waitForAbort(1.0):
                return
        if not self._scan_stop.is_set():
            self._scan_finish(kind, added)

    def _scan_finish(self, kind, added, failed=False):
        unit = "편" if kind == "영화" else "개"
        self.setProperty("PlexKM.Wiz.ScanDone", "1")
        if failed:
            self.setProperty("PlexKM.Wiz.ScanTitle", "폴더를 등록하지 못했습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "Kodi 비디오 데이터베이스를 열 수 없습니다")
        elif added:
            self.setProperty("PlexKM.Wiz.ScanTitle", "%s %s%s%s 추가했습니다" % (kind, _fmt(added), unit, "을" if unit == "편" else "를"))
            self.setProperty("PlexKM.Wiz.ScanSub", "")
        else:
            self.setProperty("PlexKM.Wiz.ScanTitle", "스캔을 마쳤습니다")
            self.setProperty("PlexKM.Wiz.ScanSub", "새로 찾은 %s가 없습니다\n폴더 이름이 작품 제목과 같은지 확인하세요" % kind)
        self.setProperty("PlexKM.Wiz.ScanButton", "완료")
        _log("scan_done kind=%s added=%d failed=%s" % (kind, added, "1" if failed else "0"))


def run_wizard(mode="first_run", run_id=""):
    dlg = None
    try:
        dlg = SourceWizardDialog(XML_NAME, ADDON.getAddonInfo("path"), "Default", "1080i", mode=mode)
        if mode == "scan_queue" and run_id:
            dlg._run_id_r465 = run_id
        dlg.doModal()
        result = dlg.result
        _log("closed mode=%s result=%s" % (mode, (result or {}).get("choice", "none")))
        return result
    except Exception:
        _log("run_failed %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return None
    finally:
        try:
            del dlg
        except Exception:
            pass
