# -*- coding: utf-8 -*-
"""PKM last-resort startup recovery owned by the SKIN, not plugin service.

Scheduled by Kodi's native AlarmClock in Startup.xml. Does not import PKM.
"""
import xbmc
import xbmcgui

LOG = "[PKM_BOOT_GUARD_R2] "

def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log(LOG + message, level)
    except Exception:
        pass

def main():
    try:
        w = xbmcgui.Window(10000)
        if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
            log("SKIP reason=home_ready")
            return
        if xbmc.Player().isPlayingVideo():
            log("SKIP reason=video_playing")
            return
        if w.getProperty("PlexKM.FullResetInProgressV2150") == "1":
            log("SKIP reason=full_reset")
            return
        try:
            if xbmc.getCondVisibility("Window.IsActive(addonsettings)"):
                log("SKIP reason=settings_dialog_active")
                return
        except Exception:
            pass
        w.setProperty("PlexKM.Startup.RecoveryArmedR2", "1")
        w.setProperty("PlexKM.Startup.RecoveryReasonR2", "native_deadline_90s")
        w.clearProperty("PlexKM.SkinStartupSplash")
        w.clearProperty("PlexKM.Startup.SlowVisibleV2365")
        w.clearProperty("PlexKM.Startup.UpdateBlockV2375")
        log("TRIGGER action=reveal_skin_recovery_buttons preserve_state=1", xbmc.LOGERROR)
        # Do not rely solely on this dialog: Home.xml contains native buttons.
        try:
            xbmc.executebuiltin("ActivateWindow(home)")
            xbmc.sleep(250)
            xbmc.executebuiltin("SetFocus(16501)")
        except Exception as exc:
            log("FOCUS_FAIL error=%s" % exc, xbmc.LOGWARNING)
    except Exception as exc:
        log("FAIL error=%s" % exc, xbmc.LOGERROR)

if __name__ == "__main__":
    main()
