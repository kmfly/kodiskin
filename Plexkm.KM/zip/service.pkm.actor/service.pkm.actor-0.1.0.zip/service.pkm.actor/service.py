# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function

import hashlib
import json
import os
import time

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
VERSION = ADDON.getAddonInfo("version")

MANIFEST_URL = (
    "https://raw.githubusercontent.com/"
    "kmfly/kodiskin/master/Plexkm.KM/actor/manifest.json"
)

CHECK_SECONDS = 6 * 60 * 60
TIMEOUT = 60
CHUNK = 1024 * 1024

PROFILE = xbmcvfs.translatePath(
    ADDON.getAddonInfo("profile")
)

STATE = os.path.join(
    PROFILE,
    "state.json"
)

LOCAL_MANIFEST = os.path.join(
    PROFILE,
    "manifest.json"
)

RUNNING_PROP = "PKM.Actor.ServiceRunning"
INSTANCE_PROP = "PKM.Actor.ServiceInstance"
PHASE_PROP = "PKM.Actor.ServicePhase"
DETAIL_PROP = "PKM.Actor.ServiceDetail"

DB_PROP = "PKM.Actor.DB"
READY_PROP = "PKM.Actor.Ready"
STATE_PROP = "PKM.Actor.StateFile"


def log(message, level=xbmc.LOGINFO):
    xbmc.log(
        "[service.pkm.actor %s] %s"
        % (VERSION, message),
        level
    )


def ensure_dir():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def set_phase(phase, detail=""):
    try:
        win = xbmcgui.Window(10000)

        win.setProperty(
            PHASE_PROP,
            str(phase or "")
        )

        win.setProperty(
            DETAIL_PROP,
            str(detail or "")
        )

        win.setProperty(
            "PKM.Actor.ServiceVersion",
            str(VERSION or "")
        )

        log(
            "ACTOR_SERVICE_PHASE "
            "phase=%s detail=%s"
            % (
                phase or "",
                detail or ""
            )
        )

    except Exception:
        pass


def atomic_json(path, data):
    tmp = path + ".tmp"

    with open(
        tmp,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            ensure_ascii=False,
            indent=2
        )

    os.replace(
        tmp,
        path
    )


def fetch_json(url):
    req = Request(
        url,
        headers={
            "User-Agent":
                "PKM-Actor-Service/%s"
                % VERSION,

            "Cache-Control":
                "no-cache"
        }
    )

    with urlopen(
        req,
        timeout=TIMEOUT
    ) as response:

        return json.loads(
            response.read().decode(
                "utf-8"
            )
        )


def sha256_file(path):
    h = hashlib.sha256()

    with open(
        path,
        "rb"
    ) as f:

        while True:
            block = f.read(CHUNK)

            if not block:
                break

            h.update(block)

    return h.hexdigest().lower()


def valid_existing(
    path,
    entry,
    old_entry
):
    if not os.path.isfile(path):
        return False

    expected_size = int(
        entry.get("size", 0)
        or 0
    )

    expected_sha = str(
        entry.get("sha256", "")
        or ""
    ).lower()

    actual_size = os.path.getsize(
        path
    )

    if (
        expected_size
        and actual_size != expected_size
    ):
        return False

    if (
        old_entry
        and old_entry.get("sha256")
            == expected_sha
        and int(
            old_entry.get(
                "size",
                -1
            )
        ) == actual_size
    ):
        return True

    if not expected_sha:
        return False

    return (
        sha256_file(path)
        == expected_sha
    )


def download(entry, path):
    url = str(
        entry.get("url")
        or ""
    )

    expected_sha = str(
        entry.get("sha256", "")
        or ""
    ).lower()

    expected_size = int(
        entry.get("size", 0)
        or 0
    )

    if not url or not expected_sha:
        raise RuntimeError(
            "manifest entry missing "
            "url/sha256"
        )

    part = path + ".part"

    try:
        if os.path.isfile(part):
            os.remove(part)
    except Exception:
        pass

    set_phase(
        "downloading",
        "Actor Master DB"
    )

    h = hashlib.sha256()
    total = 0

    req = Request(
        url,
        headers={
            "User-Agent":
                "PKM-Actor-Service/%s"
                % VERSION
        }
    )

    try:

        with urlopen(
            req,
            timeout=TIMEOUT
        ) as response, open(
            part,
            "wb"
        ) as f:

            while True:
                block = response.read(
                    CHUNK
                )

                if not block:
                    break

                f.write(block)
                h.update(block)

                total += len(block)

        if (
            expected_size
            and total != expected_size
        ):
            raise RuntimeError(
                "size mismatch "
                "expected=%d actual=%d"
                % (
                    expected_size,
                    total
                )
            )

        actual_sha = (
            h.hexdigest().lower()
        )

        if actual_sha != expected_sha:
            raise RuntimeError(
                "sha256 mismatch"
            )

        # 완전히 다운로드되고 SHA 검증까지
        # 끝난 파일만 실제 DB로 교체한다.
        os.replace(
            part,
            path
        )

        return {
            "sha256": actual_sha,
            "size": total
        }

    except Exception:

        try:
            if os.path.isfile(part):
                os.remove(part)
        except Exception:
            pass

        raise


def publish_state(state):
    try:

        actor = (
            (state or {}).get(
                "database"
            )
            or {}
        )

        path = (
            actor.get("path")
            or ""
        )

        win = xbmcgui.Window(10000)

        win.setProperty(
            STATE_PROP,
            STATE
        )

        win.setProperty(
            DB_PROP,
            path
        )

        win.setProperty(
            READY_PROP,
            "1"
            if (
                path
                and os.path.isfile(path)
            )
            else "0"
        )

    except Exception:
        pass


def publish_existing():
    try:

        if not os.path.isfile(STATE):
            return False

        with open(
            STATE,
            "r",
            encoding="utf-8"
        ) as f:

            state = json.load(f)

        publish_state(state)

        return True

    except Exception:
        return False


def sync():
    ensure_dir()

    try:

        if os.path.isfile(STATE):

            with open(
                STATE,
                "r",
                encoding="utf-8"
            ) as f:

                old = json.load(f)

        else:
            old = {}

    except Exception:
        old = {}

    set_phase(
        "checking_manifest",
        "PKM Actor manifest"
    )

    manifest = fetch_json(
        MANIFEST_URL
    )

    if int(
        manifest.get(
            "schema",
            0
        )
        or 0
    ) != 1:

        raise RuntimeError(
            "unsupported manifest"
        )

    entry = manifest.get(
        "actor"
    )

    if not isinstance(
        entry,
        dict
    ):
        raise RuntimeError(
            "actor entry missing"
        )

    filename = os.path.basename(
        str(
            entry.get(
                "filename"
            )
            or ""
        )
    )

    if not filename:
        raise RuntimeError(
            "actor filename missing"
        )

    path = os.path.join(
        PROFILE,
        filename
    )

    old_entry = (
        old.get("database")
        or {}
    )

    if valid_existing(
        path,
        entry,
        old_entry
    ):

        meta = {
            "sha256":
                str(
                    entry.get(
                        "sha256"
                    )
                    or ""
                ).lower(),

            "size":
                os.path.getsize(
                    path
                )
        }

        log(
            "existing Actor DB valid"
        )

    else:

        meta = download(
            entry,
            path
        )

        log(
            "Actor DB downloaded "
            "size=%d"
            % meta["size"]
        )

    state = {
        "schema": 1,

        "manifest_url":
            MANIFEST_URL,

        "manifest_updated_at":
            manifest.get(
                "updated_at"
            ),

        "last_checked_at":
            int(time.time()),

        "database": {
            "version":
                entry.get(
                    "version"
                ),

            "filename":
                filename,

            "path":
                path,

            "sha256":
                meta["sha256"],

            "size":
                meta["size"],

            "source_url":
                entry.get(
                    "url"
                )
        }
    }

    atomic_json(
        LOCAL_MANIFEST,
        manifest
    )

    atomic_json(
        STATE,
        state
    )

    publish_state(
        state
    )

    set_phase(
        "ready",
        "Actor Master DB"
    )

    log(
        "sync complete "
        "size=%d sha256=%s"
        % (
            meta["size"],
            meta["sha256"]
        )
    )


def main():
    ensure_dir()

    win = xbmcgui.Window(
        10000
    )

    token = "%d-%d" % (
        int(
            time.time()
            * 1000
        ),
        id(win)
    )

    if (
        win.getProperty(
            RUNNING_PROP
        )
        == "1"
    ):

        log(
            "ACTOR_SERVICE_DUPLICATE_SKIP "
            "existing=%s"
            % (
                win.getProperty(
                    INSTANCE_PROP
                )
                or "unknown"
            ),
            xbmc.LOGWARNING
        )

        return

    win.setProperty(
        RUNNING_PROP,
        "1"
    )

    win.setProperty(
        INSTANCE_PROP,
        token
    )

    win.setProperty(
        "PKM.Actor.ServiceVersion",
        str(VERSION or "")
    )

    log(
        "ACTOR_SERVICE_START "
        "token=%s"
        % token
    )

    try:

        # 기존 DB가 있으면 Kodi 시작 즉시 공개한다.
        # GitHub 확인 때문에 PKM UI 시작을 기다리게 하지 않는다.
        publish_existing()

        monitor = xbmc.Monitor()

        while not monitor.abortRequested():

            try:
                sync()

            except Exception as exc:

                log(
                    "sync failed; "
                    "keep existing DB: %r"
                    % exc,
                    xbmc.LOGERROR
                )

                publish_existing()

                set_phase(
                    "error",
                    repr(exc)
                )

            if monitor.waitForAbort(
                CHECK_SECONDS
            ):
                break

    finally:

        try:

            current = xbmcgui.Window(
                10000
            )

            if (
                current.getProperty(
                    INSTANCE_PROP
                )
                == token
            ):

                current.clearProperty(
                    RUNNING_PROP
                )

                current.clearProperty(
                    INSTANCE_PROP
                )

                current.setProperty(
                    PHASE_PROP,
                    "stopped"
                )

        except Exception:
            pass

        log(
            "ACTOR_SERVICE_STOP "
            "token=%s"
            % token
        )


if __name__ == "__main__":
    main()
