# -*- coding: utf-8 -*-
"""R94: one Plex-style popup that holds every PKM playback setting.

The gear (and the subtitle icon) open this window.  Pages are swapped inside
the same window, so no old PKM dialog is shown any more:

  설정
   +- 오디오   : 트랙 / 싱크(좌우 조정) / 음량 증폭
   +- 자막     : 자막 선택 / 싱크(좌우 조정) / 크기 / 스타일 / 위치 / 폰트
   +- 비디오   : 비디오 스트림 선택
   +- 화면 모드: 모드 선택 / 기본값 저장
   +- 스트림 정보
   +- 네트워크 상태 (네트워크 표시가 켜져 있을 때만)

No playback logic is re-implemented here.  Every action calls the helper that
the old dialogs already used (pkm_audio_select / pkm_subtitle_select /
pkm_video_select), so Kodi settings, native audio-delay actions and the
subtitle renderer refresh behave exactly as before.
"""
from __future__ import absolute_import, unicode_literals

import time
import traceback
import types

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_osd_menu_r94.xml"
LIST_ID = 200
MAX_VISIBLE_ROWS = 7

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_SELECT_ITEM = 7
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

SYNC_LIMIT_MS = 5000
SYNC_STEP_FINE = 10
SYNC_STEP_FAST = 100
SYNC_REPEAT_GAP = 0.35      # seconds: presses closer than this count as "held"
SYNC_FAST_AFTER = 8         # held presses before the step grows to 100 ms

_BASE = "special://home/addons/plugin.video.km/"
NETWORK_CMD = "RunScript(%sresources/lib/pkm_network_health_entry.py)" % _BASE


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][osd_menu] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _set_osd_child_dialog(active):
    """Same hold the old dialogs used so the OSD does not auto-close."""
    try:
        home = xbmcgui.Window(10000)
        if active:
            home.setProperty("PlexKM.PlayerOSD.ChildDialogActive", "1")
            home.setProperty("PlexKM.PlayerOSD.AutoCloseCancelled", "1")
            home.clearProperty("PlexKM.PlayerOSD.AutoCloseArmed")
            home.clearProperty("PlexKM.PlayerOSD.AutoCloseAtMs")
        else:
            home.clearProperty("PlexKM.PlayerOSD.ChildDialogActive")
    except Exception:
        pass


def _import_helpers():
    from resources.lib import pkm_audio_select as audio
    from resources.lib import pkm_subtitle_select as sub
    from resources.lib import pkm_video_select as video
    return audio, sub, video


def _sync_text(ms):
    ms = int(ms)
    if ms == 0:
        return "0.00초"
    return "%s%.2f초" % ("+" if ms > 0 else "-", abs(ms) / 1000.0)


class _Row(object):
    """kind: sub | radio | stepper | action | info"""

    def __init__(self, label, kind, value="", data=None, selected=False, target=""):
        self.label = label
        self.kind = kind
        self.value = value
        self.data = data
        self.selected = selected
        self.target = target     # page id for kind == "sub"


class PKMOsdMenuWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self.audio, self.sub, self.video = _import_helpers()
        self.stack = []             # [(page_id, focus_pos)]
        self.page = "root"
        self.rows = []
        self.after_close = ""       # builtin to run once the window is closed
        self.start_page = "root"      # set by open_osd_menu() after construction
        self._last_step_ts = 0.0
        self._held = 0
        self.audio_ms = None
        self.sub_ms = None
        self._audio_dirty = False
        self._sub_dirty = False

    # ---------------------------------------------------------- lifecycle
    def onInit(self):
        try:
            if self.start_page and self.start_page != "root":
                self.stack.append(("root", 0))
            self._show_page(self.start_page, 0)
        except Exception:
            _log("init_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            self.close()

    def _persist_pending(self):
        try:
            if self._audio_dirty and self.audio_ms is not None:
                self.audio._set_setting("pkm_audio_sync_ms", str(int(self.audio_ms)))
            if self._sub_dirty and self.sub_ms is not None:
                self.sub._set_setting("pkm_subtitle_sync_ms", str(int(self.sub_ms)))
        except Exception:
            _log("persist_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        self._audio_dirty = False
        self._sub_dirty = False

    # ------------------------------------------------------------- pages
    def _build(self, page):
        fn = getattr(self, "_page_" + page, None)
        if fn is None:
            fn = self._page_root
        return fn()

    def _show_page(self, page, focus_pos=0):
        self.page = page
        title, rows, hint = self._build(page)
        self.rows = rows
        self.setProperty("PlexKM.OsdMenu.Title", title)
        self.setProperty("PlexKM.OsdMenu.Hint", hint or "")
        self.setProperty("PlexKM.OsdMenu.Rows", str(max(2, min(MAX_VISIBLE_ROWS, len(rows)))))
        ctrl = self.getControl(LIST_ID)
        ctrl.reset()
        items = []
        selected_pos = -1
        for pos, r in enumerate(rows):
            li = xbmcgui.ListItem(r.label, r.value)
            li.setProperty("kind", r.kind)
            li.setProperty("selected", "1" if r.selected else "0")
            items.append(li)
            if r.selected and selected_pos < 0:
                selected_pos = pos
        ctrl.addItems(items)
        if focus_pos is None:
            focus_pos = selected_pos if selected_pos >= 0 else 0
        focus_pos = max(0, min(len(rows) - 1, int(focus_pos)))
        try:
            ctrl.selectItem(focus_pos)
        except Exception:
            pass
        self.setFocusId(LIST_ID)

    def _go(self, page):
        pos = self._selected_pos()
        self.stack.append((self.page, pos))
        # radio pages open on the currently chosen row
        self._show_page(page, None)

    def _back(self):
        self._persist_pending()
        if not self.stack:
            self.close()
            return
        page, pos = self.stack.pop()
        self._show_page(page, pos)

    def _selected_pos(self):
        try:
            return int(self.getControl(LIST_ID).getSelectedPosition())
        except Exception:
            return 0

    def _selected_row(self):
        pos = self._selected_pos()
        if 0 <= pos < len(self.rows):
            return pos, self.rows[pos]
        return -1, None

    def _refresh_row(self, pos):
        """Update one row's text in place (no list rebuild, focus stays)."""
        try:
            r = self.rows[pos]
            li = self.getControl(LIST_ID).getListItem(pos)
            li.setLabel(r.label)
            li.setLabel2(r.value)
            li.setProperty("selected", "1" if r.selected else "0")
        except Exception:
            pass

    def _mark_selected(self, pos):
        for i, r in enumerate(self.rows):
            if r.kind == "radio":
                r.selected = (i == pos)
                self._refresh_row(i)

    # --------------------------------------------------------------- root
    def _network_active(self):
        try:
            return xbmc.getCondVisibility("String.IsEqual(Window(home).Property(PlexKM.Network.Active),1)")
        except Exception:
            return False

    def _page_root(self):
        rows = [
            _Row("오디오", "sub", self._audio_track_label(), target="audio"),
            _Row("자막", "sub", self._subtitle_current_label(), target="subtitle"),
            _Row("비디오", "sub", "", target="video"),
            _Row("화면 모드", "sub", self._view_mode_text(), target="viewmode"),
            _Row("스트림 정보", "sub", "", target="info"),
        ]
        if self._network_active():
            rows.append(_Row("네트워크 상태", "action", data="network"))
        return "설정", rows, ""

    # -------------------------------------------------------------- audio
    def _audio_streams(self):
        try:
            return list(self.audio._streams() or []), self.audio._current_idx()
        except Exception:
            _log("audio_streams_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return [], -1

    def _audio_track_label(self):
        try:
            streams, cur = self._audio_streams()
            used = {}
            for idx, stream in enumerate(streams):
                label, _d = self.audio._audio_label_detail(stream, idx, used)
                stream_index = self._stream_index(stream, idx)
                if idx == cur or stream_index == cur:
                    return label
        except Exception:
            pass
        return ""

    @staticmethod
    def _stream_index(stream, fallback):
        try:
            if isinstance(stream, dict) and stream.get("index") not in ("", None):
                return int(stream.get("index"))
        except Exception:
            pass
        return fallback

    def _audio_sync_now(self):
        if self.audio_ms is None:
            raw = self.audio._get_setting("pkm_audio_sync_ms", "0")
            try:
                self.audio_ms = max(-SYNC_LIMIT_MS, min(SYNC_LIMIT_MS, int(float(raw))))
            except Exception:
                self.audio_ms = 0
        return self.audio_ms

    def _page_audio(self):
        vol = self.audio._get_setting("pkm_audio_volume_boost_db", "0")
        vol_label = dict(self.audio.VOLUME_OPTIONS).get(str(vol), "기본")
        rows = [
            _Row("오디오 트랙", "sub", self._audio_track_label(), target="audio_tracks"),
            _Row("오디오 싱크", "stepper", _sync_text(self._audio_sync_now()), data="audio_sync"),
            _Row("음량 증폭", "sub", vol_label, target="audio_volume"),
        ]
        return "오디오", rows, "싱크: 좌우로 조정 · 길게 누르면 빠르게 · 확인 0으로"

    def _page_audio_tracks(self):
        streams, cur = self._audio_streams()
        rows = []
        used = {}
        for idx, stream in enumerate(streams):
            label, _d = self.audio._audio_label_detail(stream, idx, used)
            stream_index = self._stream_index(stream, idx)
            rows.append(_Row(label, "radio", data=idx, selected=(idx == cur or stream_index == cur)))
        if not rows:
            rows.append(_Row("사용할 수 있는 오디오 트랙이 없습니다", "info"))
        return "오디오 트랙", rows, ""

    def _page_audio_volume(self):
        cur = str(self.audio._get_setting("pkm_audio_volume_boost_db", "0"))
        rows = [_Row(label, "radio", data=key, selected=(str(key) == cur))
                for key, label in self.audio.VOLUME_OPTIONS]
        return "음량 증폭", rows, ""

    def _set_audio_track(self, idx, pos):
        try:
            streams, cur = self._audio_streams()
            if idx == cur:
                return
            xbmc.Player().setAudioStream(int(idx))
            _log("audio_track_selected index=%s" % idx)
            self._mark_selected(pos)
        except Exception:
            _log("audio_track_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _set_audio_volume(self, value, pos):
        old = str(self.audio._get_setting("pkm_audio_volume_boost_db", "0"))
        try:
            delta = int(float(value)) - int(float(old))
        except Exception:
            delta = 0
        ok = True
        if delta:
            action = "volampup" if delta > 0 else "volampdown"
            for _ in range(abs(delta)):
                if not self.audio._input_action(action, tag="osd_menu_volume_amp"):
                    ok = False
                    break
        if ok:
            self.audio._set_setting("pkm_audio_volume_boost_db", str(value))
            self._mark_selected(pos)
        _log("audio_volume_boost value=%s old=%s ok=%s" % (value, old, ok))

    def _shift_audio_sync(self, delta):
        old = int(self._audio_sync_now())
        target = max(-SYNC_LIMIT_MS, min(SYNC_LIMIT_MS, old + int(delta)))
        actual = target - old
        if not actual:
            return old
        action = "audiodelayminus" if actual < 0 else "audiodelayplus"
        steps = max(1, int(round(abs(actual) / 10.0)))
        self.audio_ms = target            # update first (guards against re-entry)
        for _ in range(steps):
            self.audio._input_action(action, tag="osd_menu_audio_delay")
        self.audio._close_sliderdialog(tag="osd_menu_audio_sync")
        self._audio_dirty = True
        _log("audio_sync old=%d new=%d action=%s steps=%d" % (old, target, action, steps))
        return target

    # ----------------------------------------------------------- subtitle
    def _subtitle_streams(self):
        try:
            return list(self.sub._streams() or [])
        except Exception:
            _log("subtitle_streams_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return []

    def _subtitle_state(self):
        """(visible, current_index, source, external_url, manual_internal_index)"""
        win = xbmcgui.Window(10000)
        visible = self.sub._subs_visible()
        source = win.getProperty("PlexKM.CurrentSubtitle.Source") or ""
        url = win.getProperty("PlexKM.CurrentSubtitle.Url") or ""
        try:
            manual = int(win.getProperty("PlexKM.CurrentSubtitle.Index") or "-1") if source == "internal" else -1
        except Exception:
            manual = -1
        return visible, self.sub._current_idx(), source, url, manual

    def _subtitle_rows(self):
        visible, cur, source, url, manual = self._subtitle_state()
        rows = [_Row("끄기", "radio", data="-1", selected=not visible)]
        used = {}
        for idx, stream in enumerate(self._subtitle_streams()):
            actual = self.sub._stream_actual_index(stream, idx)
            ext = self.sub._stream_external_url(stream)
            if ext:
                selected = bool(visible and source == "external" and ext == url)
                value = "plex_external::" + ext
            else:
                selected = bool(visible and source != "external" and (actual == cur or actual == manual))
                value = str(actual)
            rows.append(_Row(self.sub._label(stream, idx, used), "radio", data=value, selected=selected))
        return rows

    def _subtitle_current_label(self):
        """Cheap summary for the parent rows (no Plex lookup)."""
        try:
            if not self.sub._subs_visible():
                return "끄기"
            return xbmcgui.Window(10000).getProperty("PlexKM.CurrentSubtitle.Label") or "켜짐"
        except Exception:
            return ""

    def _sub_sync_now(self):
        if self.sub_ms is None:
            ms = 0
            for sid in ("subtitles.delay", "videoscreen.subtitledelay"):
                val = self.sub._get_kodi_setting_value(sid)
                if val is None:
                    continue
                try:
                    ms = int(round(float(val) * 1000.0))
                    break
                except Exception:
                    pass
            else:
                try:
                    ms = int(float(self.sub._get_setting("pkm_subtitle_sync_ms", "0")))
                except Exception:
                    ms = 0
            self.sub_ms = max(-SYNC_LIMIT_MS, min(SYNC_LIMIT_MS, ms))
        return self.sub_ms

    def _shift_sub_sync(self, delta):
        old = int(self._sub_sync_now())
        target = max(-SYNC_LIMIT_MS, min(SYNC_LIMIT_MS, old + int(delta)))
        if target == old:
            return old
        seconds = round(float(target) / 1000.0, 3)
        applied = False
        for sid in ("subtitles.delay", "videoscreen.subtitledelay"):
            if self.sub._get_kodi_setting_value(sid) is None:
                continue
            res = self.sub._jsonrpc("Settings.SetSettingValue", {"setting": sid, "value": seconds})
            if "error" not in res:
                eff = self.sub._get_kodi_setting_value(sid)
                try:
                    target = int(round(float(eff if eff is not None else seconds) * 1000.0))
                except Exception:
                    pass
                applied = True
                break
        if not applied:
            _log("subtitle_sync_setting_unavailable target=%d" % target, xbmc.LOGWARNING)
        self.sub_ms = target
        self._sub_dirty = True
        _log("subtitle_sync old=%d new=%d applied=%s" % (old, target, applied))
        return target

    def _option_label(self, options, key, default):
        for item in options:
            if item[0] == key:
                return item[1]
        return default

    def _page_subtitle(self):
        S = self.sub
        size_key = S._get_setting("pkm_subtitle_size", "normal") or "normal"
        style_key = S._get_setting("pkm_subtitle_style", "default") or "default"
        font_key = S._normalize_font_key(S._get_setting("pkm_subtitle_font", "default"))
        pos_label = self._position_label()
        rows = [
            _Row("자막", "sub", self._subtitle_current_label(), target="subtitle_tracks"),
            _Row("자막 싱크", "stepper", _sync_text(self._sub_sync_now()), data="sub_sync"),
            _Row("크기", "sub", self._option_label(S.SIZE_OPTIONS, size_key, "보통"), target="subtitle_size"),
            _Row("스타일", "sub", self._option_label(S.STYLE_OPTIONS, style_key, "기본"), target="subtitle_style"),
            _Row("위치", "sub", pos_label, target="subtitle_position"),
            _Row("폰트", "sub", self._option_label(S.FONT_OPTIONS, font_key, "PKM 기본 폰트"), target="subtitle_font"),
        ]
        return "자막", rows, "싱크: 좌우로 조정 · 길게 누르면 빠르게 · 확인 0으로"

    def _page_subtitle_tracks(self):
        return "자막", self._subtitle_rows(), ""

    def _page_subtitle_size(self):
        cur = self.sub._get_setting("pkm_subtitle_size", "normal") or "normal"
        rows = [_Row(label, "radio", data=key, selected=(key == cur))
                for key, label, _s in self.sub.SIZE_OPTIONS]
        return "자막 크기", rows, ""

    def _page_subtitle_style(self):
        cur = self.sub._get_setting("pkm_subtitle_style", "default") or "default"
        rows = [_Row(label, "radio", data=key, selected=(key == cur))
                for key, label, _s in self.sub.STYLE_OPTIONS]
        return "자막 스타일", rows, ""

    def _position_step(self):
        S = self.sub
        raw = S._get_setting("pkm_subtitle_position_step", "1")
        try:
            step = int(raw)
        except Exception:
            mapping = {"very_bottom": 0, "bottom": 1, "up1": 2, "up2": 3, "middle": 4, "upper_middle": 5, "top": 6}
            step = mapping.get(S._get_setting("pkm_subtitle_position", "bottom"), 1)
        return max(0, min(len(S.POSITION_STEPS) - 1, step))

    def _position_label(self):
        return self.sub.POSITION_STEPS[self._position_step()][1]

    def _page_subtitle_position(self):
        cur = self._position_step()
        rows = [_Row(label, "radio", data=i, selected=(i == cur))
                for i, (_k, label, _m) in enumerate(self.sub.POSITION_STEPS)]
        return "자막 위치", rows, ""

    def _page_subtitle_font(self):
        cur = self.sub._normalize_font_key(self.sub._get_setting("pkm_subtitle_font", "default"))
        rows = [_Row(label, "radio", data=key, selected=(key == cur))
                for key, label, _s in self.sub.FONT_OPTIONS]
        return "자막 폰트", rows, ""

    def _select_subtitle(self, value, label, pos):
        S = self.sub
        raw = str(value or "")
        win = xbmcgui.Window(10000)
        is_external = raw.startswith("plex_external::")
        try:
            idx = int(raw or "-1") if not is_external else -2
        except Exception:
            idx = -1

        def clear_pending():
            for key in ("PlexKM.PendingSubtitle.Url", "PlexKM.PendingSubtitle.Label", "PlexKM.PendingSubtitle.Source"):
                win.clearProperty(key)

        try:
            if is_external:
                url = raw.split("::", 1)[1]
                xbmc.Player().setSubtitles(url)
                xbmc.Player().showSubtitles(True)
                win.setProperty("PlexKM.CurrentSubtitle.Source", "external")
                win.setProperty("PlexKM.CurrentSubtitle.Url", url)
                win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                clear_pending()
            elif idx < 0:
                xbmc.Player().showSubtitles(False)
                win.setProperty("PlexKM.CurrentSubtitle.Source", "off")
                win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                for key in ("PlexKM.CurrentSubtitle.Url", "PlexKM.CurrentSubtitle.Label"):
                    win.clearProperty(key)
                clear_pending()
            else:
                S._set_internal_subtitle_stream(idx, label or "")
                win.setProperty("PlexKM.CurrentSubtitle.Source", "internal")
                win.setProperty("PlexKM.CurrentSubtitle.Index", str(idx))
                win.setProperty("PlexKM.CurrentSubtitle.Label", label or "")
                win.setProperty("PlexKM.CurrentSubtitle.Manual", "1")
                win.clearProperty("PlexKM.CurrentSubtitle.Url")
                clear_pending()
            _log("subtitle_selected value=%s label=%s" % (raw[:80], label))
            self._mark_selected(pos)
        except Exception:
            _log("subtitle_select_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)

    def _set_sub_option(self, typ, value, pos):
        S = self.sub
        try:
            if typ == "size":
                settings = {}
                for key, _label, opt in S.SIZE_OPTIONS:
                    if key == value:
                        settings = dict(opt or {})
                S._set_setting("pkm_subtitle_size", value)
                if settings:
                    S._apply_settings(settings)
                    eff = S._fontsize_to_size_key(S._get_kodi_setting_value("subtitles.fontsize"))
                    if eff and eff != value:
                        S._set_setting("pkm_subtitle_size", eff)
            elif typ == "style":
                settings = {}
                for key, _label, opt in S.STYLE_OPTIONS:
                    if key == value:
                        settings = dict(opt or {})
                S._set_setting("pkm_subtitle_style", value)
                if settings:
                    S._apply_settings(settings)
            elif typ == "position":
                step = max(0, min(len(S.POSITION_STEPS) - 1, int(value)))
                key, _label, margin = S.POSITION_STEPS[step]
                S._set_setting("pkm_subtitle_position", key)
                S._set_setting("pkm_subtitle_position_step", str(step))
                if S._apply_settings({"subtitles.align": 0, "subtitles.marginvertical": float(margin)}):
                    win = xbmcgui.Window(10000)
                    try:
                        win.setProperty("PlexKM.Subtitle.NativeFile", xbmc.Player().getPlayingFile() or "")
                    except Exception:
                        pass
                    win.setProperty("PlexKM.Subtitle.NativeStep", str(step))
            elif typ == "font":
                settings = {}
                for key, _label, opt in S.FONT_OPTIONS:
                    if key == value:
                        settings = dict(opt or {})
                S._set_setting("pkm_subtitle_font", value)
                if settings:
                    S._apply_settings(settings)
                    shim = types.SimpleNamespace(
                        current_external_label="", current_external_url="",
                        manual_internal_index=-1, manual_internal_label="",
                        current_index=-1, subs_visible=S._subs_visible())
                    shim._font_refresh_url = types.MethodType(S.PKMSubtitleSelectWindow._font_refresh_url, shim)
                    S.PKMSubtitleSelectWindow._refresh_active_subtitle_after_font_apply(
                        shim, value=value, reason="osd_menu_font")
            self._mark_selected(pos)
            _log("subtitle_option typ=%s value=%s" % (typ, value))
        except Exception:
            _log("subtitle_option_failed typ=%s value=%s\n%s" % (typ, value, traceback.format_exc()), xbmc.LOGERROR)

    # -------------------------------------------------------------- video
    def _video_snapshot(self):
        try:
            return self.video._video_snapshot()
        except Exception:
            _log("video_snapshot_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return -1, [], -1

    def _view_mode_text(self):
        try:
            return self.video._view_mode_label(self.video._get_view_mode())
        except Exception:
            return ""

    def _page_video(self):
        pid, streams, cur = self._video_snapshot()
        self._video_player_id = pid
        rows = []
        for position, stream in enumerate(streams):
            idx = position
            try:
                idx = int((stream or {}).get("index", position))
            except Exception:
                pass
            selected = (idx == cur)
            rows.append(_Row(self.video._stream_label(stream, current=selected), "radio", data=idx, selected=selected))
        if not rows:
            rows.append(_Row("선택할 수 있는 비디오 스트림이 없습니다", "info"))
        return "비디오", rows, ""

    def _page_viewmode(self):
        cur = self.video._get_view_mode()
        rows = [_Row(label, "radio", data=mode, selected=(mode == cur))
                for mode, label in self.video.VIEW_MODES]
        rows.append(_Row("모든 영상의 기본값으로 설정", "action", "설정됨" if self.video._default_matches(cur) else "",
                         data="save_default"))
        return "화면 모드", rows, ""

    def _page_info(self):
        pid, streams, cur = self._video_snapshot()
        shim = types.SimpleNamespace(streams=streams, current_stream_index=cur)
        shim._current_stream = types.MethodType(self.video.PKMVideoSelectWindow._current_stream, shim)
        try:
            data = self.video.PKMVideoSelectWindow._stream_info_rows(shim)
        except Exception:
            _log("stream_info_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            data = []
        rows = [_Row(label, "info", value) for label, value in data]
        if not rows:
            rows.append(_Row("정보를 가져올 수 없습니다", "info"))
        return "스트림 정보", rows, ""

    # ------------------------------------------------------------ input
    def onClick(self, control_id):
        if control_id != LIST_ID:
            return
        pos, row = self._selected_row()
        if row is None:
            return
        try:
            if row.kind == "sub":
                self._go(row.target)
            elif row.kind == "stepper":
                self._reset_stepper(pos, row)
            elif row.kind == "radio":
                self._on_radio(pos, row)
            elif row.kind == "action":
                self._on_action(pos, row)
        except Exception:
            _log("click_failed page=%s\n%s" % (self.page, traceback.format_exc()), xbmc.LOGERROR)

    def _on_radio(self, pos, row):
        page = self.page
        if page == "audio_tracks":
            self._set_audio_track(row.data, pos)
        elif page == "audio_volume":
            self._set_audio_volume(row.data, pos)
        elif page == "subtitle_tracks":
            self._select_subtitle(row.data, row.label, pos)
        elif page == "subtitle_size":
            self._set_sub_option("size", row.data, pos)
        elif page == "subtitle_style":
            self._set_sub_option("style", row.data, pos)
        elif page == "subtitle_position":
            self._set_sub_option("position", row.data, pos)
        elif page == "subtitle_font":
            self._set_sub_option("font", row.data, pos)
        elif page == "video":
            if self.video._set_video_stream(getattr(self, "_video_player_id", -1), int(row.data)):
                self._mark_selected(pos)
        elif page == "viewmode":
            if self.video._set_view_mode(str(row.data)):
                self._mark_selected(pos)
                for i, r in enumerate(self.rows):
                    if r.kind == "action":
                        r.value = "설정됨" if self.video._default_matches(str(row.data)) else ""
                        self._refresh_row(i)

    def _on_action(self, pos, row):
        if row.data == "network":
            self.after_close = NETWORK_CMD
            self.close()
        elif row.data == "save_default":
            mode = self.video._get_view_mode()
            if self.video._confirm_default():
                self.video._write_default_view_mode(mode)
                row.value = "설정됨"
                self._refresh_row(pos)

    def _reset_stepper(self, pos, row):
        if row.data == "audio_sync":
            if self._audio_sync_now():
                self._shift_audio_sync(-self._audio_sync_now())
            row.value = _sync_text(self._audio_sync_now())
        elif row.data == "sub_sync":
            if self._sub_sync_now():
                self._shift_sub_sync(-self._sub_sync_now())
            row.value = _sync_text(self._sub_sync_now())
        self._refresh_row(pos)

    def _step_size(self):
        now = time.time()
        if now - self._last_step_ts <= SYNC_REPEAT_GAP:
            self._held += 1
        else:
            self._held = 0
        self._last_step_ts = now
        return SYNC_STEP_FAST if self._held >= SYNC_FAST_AFTER else SYNC_STEP_FINE

    def _on_stepper(self, direction):
        pos, row = self._selected_row()
        if row is None or row.kind != "stepper":
            return False
        step = self._step_size() * direction
        if row.data == "audio_sync":
            row.value = _sync_text(self._shift_audio_sync(step))
        elif row.data == "sub_sync":
            row.value = _sync_text(self._shift_sub_sync(step))
        self._refresh_row(pos)
        return True

    def onAction(self, action):
        try:
            aid = action.getId()
            if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_BACKSPACE):
                self._back()
            elif aid == ACTION_MOVE_LEFT:
                self._on_stepper(-1)
            elif aid == ACTION_MOVE_RIGHT:
                self._on_stepper(1)
        except Exception:
            _log("action_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)


def open_osd_menu(page="root"):
    window = None
    follow = ""
    try:
        if not xbmc.Player().isPlayingVideo():
            return False
        addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        _set_osd_child_dialog(True)
        window = PKMOsdMenuWindow(XML_NAME, addon_path, "Default", "1080i")
        window.start_page = page or "root"
        window.doModal()
        follow = window.after_close
        window._persist_pending()
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
    finally:
        try:
            if window is not None:
                del window
        except Exception:
            pass
        _set_osd_child_dialog(False)
    if follow:
        xbmc.executebuiltin(follow)
    return True
