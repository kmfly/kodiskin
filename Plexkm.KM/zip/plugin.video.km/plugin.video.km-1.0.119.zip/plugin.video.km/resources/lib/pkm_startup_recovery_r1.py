# -*- coding: utf-8 -*-
"""PKM startup watchdog R1.

The Kodi service's autostart UI owner is deliberately one-shot.  This watchdog
only intervenes when no usable PKM Home/first-install surface is ever published;
it NEVER treats a failed Plex network probe as a reason to reset user state.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui


def start_watchdog(monitor, home_thread, core_loader, settings_ready, logger):
    def log(message, level=xbmc.LOGINFO):
        try:
            logger("[plugin.video.km] " + message, level)
        except Exception:
            pass

    def run():
        started = time.monotonic()
        # Keep the first-run budget shorter, but do not treat a real in-progress
        # library import as a quick-boot failure. All budgets are finite.
        recovery_armed = False
        try:
            configured = bool(settings_ready())
        except Exception:
            configured = False
        base_timeout = 90.0 if configured else 55.0
        log("STARTUP_RECOVERY_ARM_R1 configured=%d base_timeout_s=%d" % (
            1 if configured else 0, int(base_timeout)))
        while not monitor.abortRequested():
            if monitor.waitForAbort(0.40):
                return
            try:
                w = xbmcgui.Window(10000)
                if w.getProperty("PlexKM.Home.StartupReadyV1619") == "1":
                    log("STARTUP_RECOVERY_DISARM_R1 reason=home_ready elapsed_ms=%d" % (
                        int((time.monotonic()-started)*1000)))
                    return
                if w.getProperty("PlexKM.FullResetInProgressV2150") == "1" or w.getProperty("PlexKM.FullResetInProgressV2149") == "1":
                    return
                if xbmc.Player().isPlayingVideo():
                    return
                elapsed = time.monotonic() - started
                live = bool(home_thread.is_alive())
                setup_busy = (w.getProperty("PlexKM.InitialSetupSyncActiveV1736") == "1")
                # Active Kodi/Plex setup dialogs remain user-owned; no overlays.
                modal = bool(xbmc.getCondVisibility("System.HasModalDialog") or
                             xbmc.getCondVisibility("Window.IsActive(addonsettings)"))
                update_busy = (w.getProperty("PlexKM.Startup.UpdateBlockV2375") == "1")
                if modal:
                    continue
                update_phase = str(w.getProperty("PlexKM.Startup.UpdatePhaseV2375") or "")
                # Give an actual package installation more room than a normal
                # Home paint; a broken checker still cannot block forever.
                budget = (240.0 if (setup_busy or update_phase in (
                    "install_addon", "finalize", "repo_refresh", "repo_auto_install"
                )) else base_timeout)
                if update_busy and elapsed < budget:
                    continue
                # A worker that returned without ever publishing Home is an
                # actual dead-end. Give Kodi's UI a short chance to settle.
                if live and elapsed < budget:
                    continue
                if (not live) and elapsed < 7.0:
                    continue
                if recovery_armed:
                    return
                recovery_armed = True
                reason = "ui_worker_ended" if not live else ("initial_import_timeout" if setup_busy else "home_reveal_timeout")
                log("STARTUP_RECOVERY_TRIGGER_R1 reason=%s elapsed_ms=%d worker_alive=%d setup_busy=%d" % (
                    reason, int(elapsed*1000), int(live), int(setup_busy)), xbmc.LOGERROR)
                w.setProperty("PlexKM.Startup.RecoveryFailureR1", reason)
                # Release *only* the failed splash and its text/animation. Do not
                # pretend that an uncommitted library is present or clear DBs.
                w.clearProperty("PlexKM.SkinStartupSplash")
                w.clearProperty("PlexKM.Startup.SlowVisibleV2365")
                w.clearProperty("PlexKM.Startup.SlowTextV2365")
                try:
                    answer = xbmcgui.Dialog().yesno(
                        "PKM 시작 실패",
                        "PKM 초기 화면을 준비하지 못했습니다. 설정을 다시 진행하시겠습니까?",
                        nolabel="나중에", yeslabel="설정 다시 하기")
                except Exception as dialog_exc:
                    log("STARTUP_RECOVERY_DIALOG_FAILED_R1 error=%s" % dialog_exc, xbmc.LOGERROR)
                    try:
                        xbmc.executebuiltin("Notification(PKM,초기 화면 로딩에 실패했습니다. PKM 설정을 확인해주세요.,8000)")
                    except Exception:
                        pass
                    return
                if not answer:
                    log("STARTUP_RECOVERY_DEFER_R1 reason=user_later", xbmc.LOGWARNING)
                    return
                log("STARTUP_RECOVERY_SETTINGS_R1 action=existing_pkm_settings_flow preserve_db=1")
                # Run on this separate watchdog thread; the service's update
                # tick and Plex health monitor remain alive.
                try:
                    core = core_loader()
                    core.open_pkm_settings_dialog()
                    if monitor.abortRequested():
                        return
                    w = xbmcgui.Window(10000)
                    if (w.getProperty("PlexKM.Home.StartupReadyV1619") != "1" and
                            w.getProperty("PlexKM.HomeWindowActive") != "true" and
                            w.getProperty("PlexKM.HomeWindowOpening") != "true"):
                        log("STARTUP_RECOVERY_HOME_REOPEN_R1 source=settings_finished")
                        core.open_window_home({"index":"home", "sort":"added", "autostart":"1",
                                               "no_interactive_sync":"1", "source":"recovery_r1"})
                    else:
                        log("STARTUP_RECOVERY_HOME_REOPEN_SKIP_R1 reason=home_present_or_opening")
                except Exception as exc:
                    log("STARTUP_RECOVERY_SETTINGS_FAILED_R1 err=%s" % exc, xbmc.LOGERROR)
                    try:
                        xbmcgui.Dialog().ok("PKM 설정 오류", "설정 화면을 열지 못했습니다. Kodi 로그를 확인해주세요.")
                    except Exception:
                        pass
                return
            except Exception as exc:
                log("STARTUP_RECOVERY_WATCH_ERROR_R1 err=%s" % exc, xbmc.LOGWARNING)
        log("STARTUP_RECOVERY_STOP_R1 reason=service_abort")

    thread = threading.Thread(target=run, name="PKMStartupRecoveryR1", daemon=True)
    thread.start()
    return thread
