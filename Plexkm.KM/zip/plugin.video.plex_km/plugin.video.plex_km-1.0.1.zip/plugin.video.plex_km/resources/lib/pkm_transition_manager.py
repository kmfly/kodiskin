# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui


_PREFIX = "PlexKM.Info.Transition"


def _win():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return None


def _set_prop(owner, key, value):
    try:
        if owner is not None:
            owner.setProperty(key, value)
    except Exception:
        pass
    try:
        w = _win()
        if w is not None:
            w.setProperty(key, value)
    except Exception:
        pass


def _clear_prop(owner, key):
    try:
        if owner is not None:
            owner.clearProperty(key)
    except Exception:
        pass
    try:
        w = _win()
        if w is not None:
            w.clearProperty(key)
    except Exception:
        pass


def _global_prop(key):
    try:
        w = _win()
        return (w.getProperty(key) if w is not None else "") or ""
    except Exception:
        return ""


def _clear_global_prop(key):
    """Clear a global transition property without retaining WindowXML.

    Delayed transition workers can outlive the PlexKM WindowXML instance that
    started them.  They must therefore never call owner.clearProperty().
    """
    try:
        w = _win()
        if w is not None:
            w.clearProperty(key)
    except Exception:
        pass


def _transition_matches(token="", rating_key=""):
    current_token = _global_prop(_PREFIX + ".Token")
    current_key = _global_prop("PlexKM.Info.RatingKey")
    if token and current_token and current_token != token:
        return False
    if rating_key and current_key and current_key != rating_key:
        return False
    return True


def _transition_target_ready():
    """Return True only when the complete inline Info target can be revealed."""
    if _global_prop("PlexKM.Info.InlineActive") != "1":
        return False
    if _global_prop("PlexKM.Info.IsTV") != "1":
        return True
    return (
        _global_prop("PlexKM.Info.TVRowsReady") == "1"
        or _global_prop("PlexKM.Info.TVRowsEmpty") == "1"
    )


def begin_info_transition(owner, rating_key="", mode="info", cover=True):
    """Start a PKM Info readiness transaction.

    Cover is a logical publish gate, not a painted blank layer. The previous
    completed Home/Info surface stays visible until the target is complete; the
    shared delayed busy broker supplies the only foreground wait spinner.
    """
    token = "%s:%s:%d" % (rating_key or "", mode or "info", int(time.time() * 1000))
    _set_prop(owner, _PREFIX + ".Token", token)
    _set_prop(owner, _PREFIX + ".RatingKey", rating_key or "")
    _set_prop(owner, _PREFIX + ".Mode", mode or "info")
    # v1841: Active marks one composed Info transaction.  cover=False keeps the
    # previous Home/Info screen visible during local preparation; the caller
    # enables Cover only for the final property/control swap.
    _set_prop(owner, _PREFIX + ".Active", "1")
    if cover:
        _set_prop(owner, _PREFIX + ".Cover", "1")
    else:
        _clear_prop(owner, _PREFIX + ".Cover")
    return token


def activate_info_transition_cover(owner, token=""):
    """Arm the compatibility publish gate for an atomic Info swap.

    XML does not paint an opaque cover in v1883. The property temporarily keeps
    the target Info overlay hidden while the previous completed surface remains.
    """
    try:
        current_token = _global_prop(_PREFIX + ".Token")
        if token and current_token and current_token != token:
            return False
        if token:
            _set_prop(owner, _PREFIX + ".Token", token)
        _set_prop(owner, _PREFIX + ".Active", "1")
        _set_prop(owner, _PREFIX + ".Cover", "1")
        return True
    except Exception:
        return False


def commit_info_transition_gate(owner, token="", rating_key=""):
    """Synchronously release the logical gate immediately before InlineActive.

    The caller finishes all target properties and native A/B controls first,
    clears this gate while the previous surface is still visible, and only then
    publishes InlineActive.  That ordering prevents a one-frame state where both
    Home and Info are hidden.  No timer or painted cover is involved.
    """
    try:
        if not _transition_matches(token, rating_key):
            return False
        _clear_prop(owner, _PREFIX + ".Cover")
        return True
    except Exception:
        return False


def finish_info_transition(owner, token="", rating_key="", delay_ms=80):
    """Release the logical transition gate after the target is complete.

    This never blocks the Kodi UI thread.  Token/rating_key checks prevent a late
    release from an older Info open from exposing a newer screen too early.
    """
    def _worker():
        try:
            monitor = xbmc.Monitor()
            wait_s = max(0, int(delay_ms or 0)) / 1000.0
            if wait_s > 0 and monitor.waitForAbort(wait_s):
                return

            # v1883: callers compose TV A/B rows first, synchronously clear the
            # logical gate, and then publish InlineActive. This worker only retires
            # the transaction marker after the complete target is visible.
            while not monitor.abortRequested():
                if not _transition_matches(token, rating_key):
                    return
                cover_now = _global_prop(_PREFIX + ".Cover")
                active_now = _global_prop(_PREFIX + ".Active")
                if cover_now != "1" and active_now != "1":
                    return
                if _transition_target_ready():
                    # Give Kodi two frames to bind the final properties and
                    # inactive TV buffer before starting the XML reveal.
                    if monitor.waitForAbort(0.04):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    if not _transition_target_ready():
                        continue
                    _clear_global_prop(_PREFIX + ".Cover")
                    # The active marker outlives the 140/160ms skin reveal.
                    if monitor.waitForAbort(0.22):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    _clear_global_prop(_PREFIX + ".Active")
                    return
                if monitor.waitForAbort(0.025):
                    return
        except Exception:
            # A delayed worker must not dereference the originating WindowXML;
            # cancellation or the property-aware failsafe owns recovery.
            return

    threading.Thread(target=_worker, name="PlexKMInfoTransitionRelease", daemon=True).start()



def schedule_transition_failsafe(owner, token="", rating_key="", max_ms=700):
    """Wake a secondary release watcher if the normal path takes too long.

    The watchdog never treats elapsed time as proof that a TV/episode target is
    complete.  It releases only after the same Ready/Empty condition as the
    normal worker, preventing a timeout from exposing a half-built Info shell.
    """
    def _worker():
        try:
            monitor = xbmc.Monitor()
            wait_s = max(0, int(max_ms or 0)) / 1000.0
            if wait_s > 0 and monitor.waitForAbort(wait_s):
                return

            # v1841: max_ms is a watchdog wake-up, not permission to reveal a
            # half-built TV page.  If preparation is still valid, continue to
            # wait for the same Ready/Empty contract as the normal release.
            deferred_logged = False
            while not monitor.abortRequested():
                if not _transition_matches(token, rating_key):
                    return
                cover_now = _global_prop(_PREFIX + ".Cover")
                active_now = _global_prop(_PREFIX + ".Active")
                if cover_now != "1" and active_now != "1":
                    return
                if _transition_target_ready():
                    _clear_global_prop(_PREFIX + ".Cover")
                    if monitor.waitForAbort(0.22):
                        return
                    if not _transition_matches(token, rating_key):
                        return
                    _clear_global_prop(_PREFIX + ".Active")
                    try:
                        xbmc.log("[plugin.video.plex_km] INFO_TRANSITION_FAILSAFE_RELEASE_V1841 rating_key=%s wake_ms=%s ready=1" % (rating_key or "", max_ms), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    return
                if not deferred_logged:
                    deferred_logged = True
                    try:
                        xbmc.log("[plugin.video.plex_km] INFO_TRANSITION_FAILSAFE_DEFER_V1841 rating_key=%s wake_ms=%s reason=target_not_ready" % (rating_key or "", max_ms), xbmc.LOGINFO)
                    except Exception:
                        pass
                if monitor.waitForAbort(0.10):
                    return
        except Exception:
            return

    threading.Thread(target=_worker, name="PlexKMInfoTransitionFailsafe", daemon=True).start()


def cancel_info_transition(owner):
    for suffix in (".Cover", ".Active", ".Token", ".RatingKey", ".Mode"):
        _clear_prop(owner, _PREFIX + suffix)
