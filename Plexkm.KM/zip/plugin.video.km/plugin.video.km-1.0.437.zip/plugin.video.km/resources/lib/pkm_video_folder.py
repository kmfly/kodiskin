# -*- coding: utf-8 -*-
"""PlexKM 영상 폴더: 개인 영상·뮤직비디오 폴더를 썸네일 + 파일명만으로 보여 준다.
스크래핑/인포 페이지 없음. 항목을 누르면 바로 재생. 하위 폴더 지원."""
import os
import sys
import time

try:
    from urllib.parse import quote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

PLUGIN = "plugin://plugin.video.km/"
VIDEO_EXT = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".wmv", ".ts", ".m2ts",
             ".flv", ".webm", ".mpg", ".mpeg", ".3gp", ".iso", ".vob")


def folder_url(path):
    return PLUGIN + "?" + urlencode({"action": "videofolder", "path": path})


def _mtime(full):
    try:
        st = xbmcvfs.Stat(full)
        return int(st.st_mtime())
    except Exception:
        return 0


def _title(name):
    base = os.path.splitext(name)[0]
    return base.replace("_", " ").strip() or name


def _thumb(full):
    return "image://video@%s/" % quote(full, safe="")


def list_folder(handle, path):
    path = path if path.endswith(("/", "\\")) else path + "/"
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception:
        dirs, files = [], []
    rows = []
    for d in dirs:
        full = path + d + "/"
        rows.append((0, _mtime(full), d, full, True))
    for f in files:
        if not f.lower().endswith(VIDEO_EXT):
            continue
        full = path + f
        rows.append((1, _mtime(full), f, full, False))
    # 폴더 먼저, 그 안에서 최신(수정일) 순
    rows.sort(key=lambda r: (r[0], -r[1], r[2].lower()))
    items = []
    for _k, ts, name, full, isdir in rows:
        li = xbmcgui.ListItem(label=_title(name) if not isdir else name)
        if isdir:
            li.setArt({"icon": "DefaultFolder.png"})
            items.append((folder_url(full), li, True))
            continue
        li.setArt({"thumb": _thumb(full), "icon": _thumb(full)})
        tag = li.getVideoInfoTag()
        tag.setTitle(_title(name))
        tag.setMediaType("video")
        if ts:
            try:
                tag.setDateAdded(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)))
            except Exception:
                pass
        li.setProperty("IsPlayable", "true")
        li.setProperty("PlexKM.VideoFolder", "true")
        items.append((full, li, False))
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
