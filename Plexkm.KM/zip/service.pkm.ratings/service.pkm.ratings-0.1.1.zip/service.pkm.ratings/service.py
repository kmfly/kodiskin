# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function
import hashlib, json, os, time
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen
import xbmc, xbmcaddon, xbmcgui, xbmcvfs

ADDON = xbmcaddon.Addon()
VERSION = ADDON.getAddonInfo("version")
MANIFEST_URL = "https://raw.githubusercontent.com/kmfly/PKM-Ratings/main/manifest.json"
CHECK_SECONDS = 6 * 60 * 60
TIMEOUT = 30
CHUNK = 1024 * 1024
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
STATE = os.path.join(PROFILE, "state.json")
LOCAL_MANIFEST = os.path.join(PROFILE, "manifest.json")
RUNNING_PROP = "PKM.Ratings.ServiceRunningV2375"
INSTANCE_PROP = "PKM.Ratings.ServiceInstanceV2375"
PHASE_PROP = "PKM.Ratings.ServicePhaseV2375"
DETAIL_PROP = "PKM.Ratings.ServiceDetailV2375"


def log(m, level=xbmc.LOGINFO):
    xbmc.log("[service.pkm.ratings %s] %s" % (VERSION, m), level)


def set_phase(phase, detail=""):
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(PHASE_PROP, str(phase or ""))
        win.setProperty(DETAIL_PROP, str(detail or ""))
        win.setProperty("PKM.Ratings.ServiceVersionV2375", str(VERSION or ""))
        log("RATINGS_SERVICE_PHASE_V2375 phase=%s detail=%s" % (phase or "", detail or ""))
    except Exception:
        pass


def ensure_dir():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def atomic_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def fetch_json(url):
    req = Request(url, headers={"User-Agent": "PKM-Ratings-Service/%s" % VERSION, "Cache-Control": "no-cache"})
    with urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def valid_existing(path, entry, old):
    if not os.path.isfile(path):
        return False
    size = int(entry.get("size", 0) or 0)
    sha = str(entry.get("sha256", "") or "").lower()
    if size and os.path.getsize(path) != size:
        return False
    if old and old.get("sha256") == sha and int(old.get("size", -1)) == os.path.getsize(path):
        return True
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(CHUNK)
            if not b:
                break
            h.update(b)
    return bool(sha and h.hexdigest().lower() == sha)


def download(kind, entry, path):
    url = entry.get("url") or ""
    sha = str(entry.get("sha256", "") or "").lower()
    size = int(entry.get("size", 0) or 0)
    if not url or not sha:
        raise RuntimeError("manifest entry missing url/sha256")
    part = path + ".part"
    h = hashlib.sha256()
    total = 0
    set_phase("downloading", "%s Master DB" % kind)
    req = Request(url, headers={"User-Agent": "PKM-Ratings-Service/%s" % VERSION})
    with urlopen(req, timeout=TIMEOUT) as r, open(part, "wb") as f:
        while True:
            b = r.read(CHUNK)
            if not b:
                break
            f.write(b)
            h.update(b)
            total += len(b)
    if size and total != size:
        try:
            os.remove(part)
        except Exception:
            pass
        raise RuntimeError("size mismatch")
    if h.hexdigest().lower() != sha:
        try:
            os.remove(part)
        except Exception:
            pass
        raise RuntimeError("sha256 mismatch")
    os.replace(part, path)
    return {"sha256": sha, "size": total}


def publish_state(state):
    try:
        dbs = (state or {}).get("databases") or {}
        win = xbmcgui.Window(10000)
        win.setProperty("PKM.Ratings.StateFile", STATE)
        win.setProperty("PKM.Ratings.Cine21DB", (dbs.get("cine21") or {}).get("path") or "")
        win.setProperty("PKM.Ratings.WatchaDB", (dbs.get("watcha") or {}).get("path") or "")
        win.setProperty("PKM.Ratings.Ready", "1" if dbs else "0")
    except Exception:
        pass


def sync():
    ensure_dir()
    try:
        old = json.load(open(STATE, "r", encoding="utf-8")) if os.path.isfile(STATE) else {}
    except Exception:
        old = {}
    set_phase("checking_manifest", "PKM-Ratings manifest")
    manifest = fetch_json(MANIFEST_URL)
    if int(manifest.get("schema", 0) or 0) != 1:
        raise RuntimeError("unsupported manifest")
    databases = {}
    for kind in ("cine21", "watcha"):
        entry = manifest.get(kind)
        if not isinstance(entry, dict):
            continue
        fn = os.path.basename(str(entry.get("filename") or ""))
        if not fn:
            continue
        path = os.path.join(PROFILE, fn)
        olde = (old.get("databases") or {}).get(kind) or {}
        if not valid_existing(path, entry, olde):
            meta = download(kind, entry, path)
        else:
            meta = {"sha256": str(entry.get("sha256") or "").lower(), "size": os.path.getsize(path)}
        databases[kind] = {
            "version": entry.get("version"),
            "filename": fn,
            "path": path,
            "sha256": meta["sha256"],
            "size": meta["size"],
            "source_url": entry.get("url"),
        }
    state = {
        "schema": 1,
        "manifest_url": MANIFEST_URL,
        "manifest_updated_at": manifest.get("updated_at"),
        "last_checked_at": int(time.time()),
        "databases": databases,
    }
    atomic_json(LOCAL_MANIFEST, manifest)
    atomic_json(STATE, state)
    publish_state(state)
    set_phase("ready", "cine21=%d watcha=%d" % (1 if "cine21" in databases else 0, 1 if "watcha" in databases else 0))
    log("sync complete cine21=%d watcha=%d" % (1 if "cine21" in databases else 0, 1 if "watcha" in databases else 0))


def publish_existing():
    try:
        if not os.path.isfile(STATE):
            return False
        state = json.load(open(STATE, "r", encoding="utf-8"))
        publish_state(state)
        return True
    except Exception:
        return False


def main():
    ensure_dir()
    win = xbmcgui.Window(10000)
    token = "%d-%d" % (int(time.time() * 1000), id(win))
    if win.getProperty(RUNNING_PROP) == "1":
        log("RATINGS_SERVICE_DUPLICATE_SKIP_V2375 existing=%s" % (win.getProperty(INSTANCE_PROP) or "unknown"), xbmc.LOGWARNING)
        return
    win.setProperty(RUNNING_PROP, "1")
    win.setProperty(INSTANCE_PROP, token)
    win.setProperty("PKM.Ratings.ServiceVersionV2375", str(VERSION or ""))
    log("RATINGS_SERVICE_START_V2375 token=%s" % token)
    try:
        publish_existing()
        mon = xbmc.Monitor()
        while not mon.abortRequested():
            try:
                sync()
            except Exception as e:
                log("sync failed; keep existing DB: %r" % e, xbmc.LOGERROR)
                publish_existing()
                set_phase("error", repr(e))
            if mon.waitForAbort(CHECK_SECONDS):
                break
    finally:
        try:
            cur = xbmcgui.Window(10000)
            if cur.getProperty(INSTANCE_PROP) == token:
                cur.clearProperty(RUNNING_PROP)
                cur.clearProperty(INSTANCE_PROP)
                cur.setProperty(PHASE_PROP, "stopped")
        except Exception:
            pass
        log("RATINGS_SERVICE_STOP_V2375 token=%s" % token)


if __name__ == "__main__":
    main()
