# -*- coding: utf-8 -*-
"""R82: Plex Home profile switching ("누가 보고 있나요?").

Flow
    sidebar profile row -> ProfilePickerDialog -> (PinDialog for protected users)
    -> plex.tv /api/home/users/<id>/switch -> per-server access token from
    plex.tv resources (a managed user's plex.tv token is NOT accepted by PMS)
    -> publish token/account to every live wrapper -> per-user local playstate
    files swapped -> watched state (view_count / viewedLeafCount) resynced from
    PMS for the new user -> caller rebuilds sidebar + Home.

State (addon_data/profile_r82.json):
    plextv_token  plex.tv token of the current user (used for the next switch)
    user_id/title/thumb  current profile
    users          last /api/home/users list (picker paints from it)
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import shutil
import sqlite3
import threading
import time
import traceback
import xml.etree.ElementTree as ET
from urllib.error import HTTPError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
STATE_FILE = "profile_r82.json"
# Files that describe ONE user's viewing (resume sidecar, continue rows, Home
# render snapshot).  They are parked per user on switch and restored on return.
PER_USER_FILES = (
    "playstate_resume.json",
    "playstate_continue_preload.json",
    "continue_episode_db_rows_u7.json",
    "continue_membership_validated_u5.json",
    "home_render_snapshot_v2500.json",
)

ACTION_SELECT = (7, 100)
ACTION_BACK = (9, 10, 92, 216, 247)
ACTION_DIGITS = dict((58 + i, str(i)) for i in range(10))  # REMOTE_0..9
ACTION_BACKSPACE = (110, 61448)


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] PROFILE_R82 %s" % msg, level)
    except Exception:
        pass


def _profile_dir():
    p = xbmcvfs.translatePath(_addon().getAddonInfo("profile"))
    if not os.path.isdir(p):
        os.makedirs(p, exist_ok=True)
    return p


def _addon_path():
    return _addon().getAddonInfo("path")


def load_state():
    try:
        with open(os.path.join(_profile_dir(), STATE_FILE), "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_state(data):
    try:
        path = os.path.join(_profile_dir(), STATE_FILE)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        _log("STATE_SAVE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def _cache_tokens(st, uid, server_tok, tv_tok=""):
    """R83: remember each Home user's server/plex.tv tokens so switching back to
    a profile without a PIN needs no plex.tv round trip (was ~3 s)."""
    uid = str(uid or "")
    if not uid or not server_tok:
        return
    toks = st.get("tokens") if isinstance(st.get("tokens"), dict) else {}
    old = toks.get(uid) if isinstance(toks.get(uid), dict) else {}
    toks[uid] = {"server": server_tok, "plextv": tv_tok or old.get("plextv") or "", "at": int(time.time())}
    st["tokens"] = toks


_HOME_PROP_KEYS_R83 = None


def _home_window_prop_keys():
    """Every Window.Property(...) the PKM Home XML reads (parsed once)."""
    global _HOME_PROP_KEYS_R83
    if _HOME_PROP_KEYS_R83 is None:
        keys = set()
        try:
            import re
            path = os.path.join(xbmcvfs.translatePath(_addon_path()), "resources", "skins", "Default",
                                "1080i", "plexkm_home_window.xml")
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                keys = set(re.findall(r"Window\.Property\(([^()\s]+)\)", f.read()))
        except Exception:
            _log("HOME_PROP_KEYS_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        _HOME_PROP_KEYS_R83 = sorted(keys)
    return _HOME_PROP_KEYS_R83


def mirror_home_props(dlg, home):
    """R83: while a dialog is the active window, Kodi resolves the Home XML's
    Window.Property(...) against the DIALOG.  Every colour came back empty ->
    colordiffuse="" = white, so the sidebar card / summary box flashed white
    under the picker's fade-in.  Copy the Home values onto the dialog first."""
    if dlg is None or home is None:
        return 0
    n = 0
    for k in _home_window_prop_keys():
        try:
            v = home.getProperty(k)
            if v:
                dlg.setProperty(k, v)
                n += 1
        except Exception:
            pass
    return n


def _client_headers(token, accept="application/xml"):
    try:
        from resources.lib import pkm_token_import as ti
        headers = ti._plex_headers(ti._client_identifier())
    except Exception:
        headers = {"X-Plex-Product": "PlexKM", "X-Plex-Client-Identifier": "plexkm-r82"}
    headers["Accept"] = accept
    if token:
        headers["X-Plex-Token"] = token
    return headers


def _http(url, token, data=None, accept="application/xml", timeout=12):
    req = Request(url, data=data, headers=_client_headers(token, accept))
    return urlopen(req, timeout=timeout).read()


def plextv_token():
    st = load_state()
    tok = str(st.get("plextv_token") or "").strip()
    if tok:
        return tok
    # Installs from before R82: the saved token is the plex.tv token of the
    # account chosen at login (owner -> also valid on its own server).
    return (_addon().getSetting("plex_token") or "").strip()


def record_login(plextv_tok, user=None, server_token=""):
    """Called by the Plex link/login flow after the Home user was chosen."""
    st = load_state()
    st["plextv_token"] = plextv_tok
    if server_token:
        st["server_token"] = server_token
    if isinstance(user, dict):
        st["user_id"] = str(user.get("id") or "")
        st["title"] = str(user.get("title") or user.get("username") or "")
        st["thumb"] = str(user.get("thumb") or "")
        _cache_tokens(st, st["user_id"], server_token, plextv_tok)
    save_state(st)


def _users_from_xml(body):
    root = ET.fromstring(body)
    users = []
    for u in root:
        if u.tag != "User":
            continue
        users.append({
            "id": str(u.get("id") or ""),
            "title": (u.get("title") or u.get("username") or "Plex").strip(),
            "thumb": u.get("thumb") or "",
            "protected": "1" if u.get("protected") == "1" else "0",
            "admin": "1" if u.get("admin") == "1" else "0",
            "restricted": "1" if u.get("restricted") == "1" else "0",
        })
    return users


def list_users():
    """Plex Home users for the picker.  Falls back to the cached list offline."""
    st = load_state()
    tok = plextv_token()
    try:
        users = _users_from_xml(_http("https://plex.tv/api/home/users/", tok, timeout=10))
        st["users"] = users
        if not st.get("user_id"):
            st.update(_identify_current(tok, users))
        save_state(st)
        return users, st
    except Exception:
        _log("USERS_FETCH_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return list(st.get("users") or []), st


class _UsersRefreshR83(threading.Thread):
    """R83: the picker paints from the cached list at once; plex.tv is asked in
    the background while the user looks at it (was a blocking call first)."""

    def __init__(self):
        super(_UsersRefreshR83, self).__init__(name="PKMProfileUsersR83")
        self.daemon = True
        self.users = None

    def run(self):
        try:
            self.users = _users_from_xml(_http("https://plex.tv/api/home/users/", plextv_token(), timeout=8))
        except Exception:
            _log("USERS_REFRESH_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def _identify_current(tok, users):
    """First run after the upgrade: which Home user does the saved token belong to?"""
    try:
        root = ET.fromstring(_http("https://plex.tv/users/account", tok, timeout=10))
        uid = str(root.get("id") or "")
        for u in users:
            if u.get("id") == uid:
                return {"user_id": uid, "title": u.get("title") or "", "thumb": u.get("thumb") or "",
                        "plextv_token": tok}
        return {"user_id": uid, "title": root.get("title") or root.get("username") or "",
                "thumb": root.get("thumb") or "", "plextv_token": tok}
    except Exception:
        return {}


def _server_machine_id(core):
    try:
        root = core.plex_request_xml("/identity", timeout=6, log_failures=False, bypass_cache=True)
        return str(root.get("machineIdentifier") or "")
    except Exception:
        return ""


def _server_access_token(core, new_tv_token, mid=None):
    if mid is None:
        mid = _server_machine_id(core)
    try:
        body = _http("https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=0",
                     new_tv_token, accept="application/json", timeout=12)
        for dev in json.loads(body.decode("utf-8")):
            if not mid or str(dev.get("clientIdentifier") or "") == mid:
                if "server" in str(dev.get("provides") or "") and dev.get("accessToken"):
                    return str(dev.get("accessToken")), mid
    except Exception:
        _log("RESOURCES_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return "", mid


def _verify_server_token(core, token):
    try:
        url = core.plex_url("/library/sections", include_token=False)
        sep = "&" if "?" in url else "?"
        req = Request(url + sep + "X-Plex-Token=" + quote(token),
                      headers={"Accept": "application/xml", "X-Plex-Product": "PlexKM"})
        urlopen(req, timeout=8).read(64)
        return True
    except Exception:
        return False


def switch_user(core, user, pin=""):
    """Returns {"ok": True, ...} or {"ok": False, "err": "pin"|"net"|"server"}."""
    uid = str(user.get("id") or "")
    # R83: profile without a PIN that was used before on this device -> its
    # server token is cached; one local /library/sections check replaces the
    # three plex.tv round trips.  Protected profiles always go through plex.tv.
    if not pin and user.get("protected") != "1":
        cached = (load_state().get("tokens") or {}).get(uid) or {}
        tok = str(cached.get("server") or "")
        if tok and _verify_server_token(core, tok):
            _log("SWITCH_OK user=%s title=%s token_source=cache_r83" % (uid, user.get("title")))
            return {"ok": True, "server_token": tok, "plextv_token": str(cached.get("plextv") or ""),
                    "user": user, "cached": True}
    mid_box = {}
    mid_th = threading.Thread(target=lambda: mid_box.__setitem__("mid", _server_machine_id(core)),
                              name="PKMProfileMidR83")
    mid_th.daemon = True
    mid_th.start()
    url = "https://plex.tv/api/home/users/%s/switch" % quote(uid, safe="")
    if pin:
        url += "?" + urlencode({"pin": pin})
    try:
        root = ET.fromstring(_http(url, plextv_token(), data=b"", timeout=12))
        new_tv = (root.get("authenticationToken") or root.get("authToken") or "").strip()
        if not new_tv:
            return {"ok": False, "err": "net"}
    except HTTPError as e:
        _log("SWITCH_HTTP_%s user=%s" % (e.code, uid), xbmc.LOGWARNING)
        return {"ok": False, "err": "pin" if e.code in (401, 403) else "net"}
    except Exception:
        _log("SWITCH_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return {"ok": False, "err": "net"}
    mid_th.join(6)
    access, mid = _server_access_token(core, new_tv, mid_box.get("mid", ""))
    candidates = [t for t in (access, new_tv) if t]
    for tok in candidates:
        if _verify_server_token(core, tok):
            _log("SWITCH_OK user=%s title=%s server=%s token_source=%s" % (
                uid, user.get("title"), mid or "-", "resources" if tok == access else "plextv"))
            return {"ok": True, "server_token": tok, "plextv_token": new_tv, "user": user}
    _log("SWITCH_NO_SERVER_ACCESS user=%s mid=%s" % (uid, mid or "-"), xbmc.LOGWARNING)
    return {"ok": False, "err": "server"}


def _park_user_files(old_uid, new_uid):
    base = _profile_dir()
    root = os.path.join(base, "profiles_r82")
    try:
        if old_uid:
            od = os.path.join(root, old_uid)
            os.makedirs(od, exist_ok=True)
            for name in PER_USER_FILES:
                src = os.path.join(base, name)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(od, name))
        for name in PER_USER_FILES:
            dst = os.path.join(base, name)
            parked = os.path.join(root, new_uid or "-", name)
            if os.path.exists(parked):
                shutil.copy2(parked, dst)
            elif os.path.exists(dst):
                os.remove(dst)
    except Exception:
        _log("PARK_FILES_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)


def apply_switch(result):
    """Persist and publish the new profile (settings, runtime properties, files)."""
    user = result.get("user") or {}
    st = load_state()
    old_uid = str(st.get("user_id") or "")
    new_uid = str(user.get("id") or "")
    try:
        old_server = str(st.get("server_token") or _addon().getSetting("plex_token") or "").strip()
    except Exception:
        old_server = str(st.get("server_token") or "")
    _park_user_files(old_uid, new_uid)
    title = str(user.get("title") or "")
    try:
        from resources.lib import pkm_settings_flow
        pkm_settings_flow._publish_live_plex_settings_v1922(
            token=result["server_token"], account=title, reason="profile_switch_r82")
    except Exception:
        _log("PUBLISH_FALLBACK %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        a = _addon()
        a.setSetting("plex_token", result["server_token"])
        a.setSetting("plex_account_name", title)
        w = xbmcgui.Window(10000)
        w.setProperty("PlexKM.Runtime.PlexToken", result["server_token"])
        w.setProperty("PlexKM.Runtime.PlexAccount", title)
    _cache_tokens(st, old_uid, old_server, str(st.get("plextv_token") or ""))
    _cache_tokens(st, new_uid, result["server_token"], result.get("plextv_token") or "")
    st.update({
        "plextv_token": result.get("plextv_token") or st.get("plextv_token") or "",
        "server_token": result["server_token"],
        "user_id": new_uid,
        "title": title,
        "thumb": str(user.get("thumb") or ""),
        "switched_at": int(time.time()),
    })
    save_state(st)
    _log("APPLY old=%s new=%s title=%s" % (old_uid or "-", new_uid, title))


def _fetch_watched_section(core, sid, kinds):
    """One library: watched leaves (unwatched=0) and shows with viewedLeafCount>0."""
    watched = {}
    shows = {}
    for t in kinds:
        params = {"type": str(t), "includeGuids": "0", "includeCollections": "0",
                  "X-Plex-Container-Start": "0", "X-Plex-Container-Size": "20000"}
        if t == 2:
            params["viewedLeafCount>>"] = "0"
        else:
            params["unwatched"] = "0"
        root = core.plex_request_xml("/library/sections/%s/all" % sid, params=params,
                                     timeout=30, log_failures=False, bypass_cache=True)
        if root is None:
            raise RuntimeError("no response")
        for node in root:
            rk = str(node.get("ratingKey") or "")
            if not rk:
                continue
            if t == 2:
                shows[rk] = str(node.get("viewedLeafCount") or "0")
            else:
                watched[rk] = (int(node.get("viewCount") or 1), int(node.get("lastViewedAt") or 0))
    return watched, shows


def resync_watched(core):
    """Make the shared library DB reflect the NEW user's watched state.

    Only watched rows are transferred (unwatched=0 filters), so this is a few
    small requests per library; shows get their viewedLeafCount refreshed.
    R83: the per-library requests run in parallel (23 libraries were fetched
    one after another: 2.6 s on PC); DB writes stay on this thread."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    db = core.db_path()
    conn = sqlite3.connect(db, timeout=20)
    stats = {"sections": 0, "watched": 0, "shows": 0}
    try:
        jobs = []
        for sid, stype in list(conn.execute("SELECT section_id, section_type FROM sections")):
            kinds = (1,) if stype == "movie" else (4, 2) if stype == "show" else ()
            if kinds:
                jobs.append((str(sid), kinds))
        with ThreadPoolExecutor(max_workers=6) as ex:
            futs = [(sid, kinds, ex.submit(_fetch_watched_section, core, sid, kinds)) for sid, kinds in jobs]
            for sid, kinds, fut in futs:
                try:
                    watched, shows = fut.result()
                    with conn:
                        conn.execute("UPDATE items SET view_count=0, last_viewed_at=0 WHERE section_id=? "
                                     "AND plex_type IN ('movie','episode') AND (view_count>0 OR last_viewed_at>0)", (sid,))
                        conn.executemany("UPDATE items SET view_count=?, last_viewed_at=? WHERE rating_key=?",
                                         [(vc, lv, rk) for rk, (vc, lv) in watched.items()])
                        if 2 in kinds:
                            rows = list(conn.execute("SELECT rating_key, raw_json FROM items WHERE section_id=? AND plex_type='show'", (sid,)))
                            upd = []
                            for rk, raw in rows:
                                try:
                                    d = json.loads(raw or "{}")
                                except Exception:
                                    continue
                                want = shows.get(str(rk), "0")
                                if str(d.get("viewedLeafCount") or "0") != want:
                                    d["viewedLeafCount"] = want
                                    upd.append((json.dumps(d, ensure_ascii=False), rk))
                            conn.executemany("UPDATE items SET raw_json=? WHERE rating_key=?", upd)
                            stats["shows"] += len(upd)
                    stats["sections"] += 1
                    stats["watched"] += len(watched)
                except Exception:
                    _log("RESYNC_SECTION_FAILED section=%s %s" % (sid, traceback.format_exc().replace("\n", " | ")), xbmc.LOGWARNING)
    finally:
        conn.close()
    _log("RESYNC_DONE sections=%d watched=%d shows_updated=%d ms=%d parallel_r83=1" % (
        stats["sections"], stats["watched"], stats["shows"], int((time.time() - t0) * 1000)))
    return stats


# ------------------------------------------------------------------ dialogs
def _initial(name):
    try:
        return (name or "?").strip()[:1].upper()
    except Exception:
        return "?"


class ProfilePickerDialog(xbmcgui.WindowXMLDialog):
    LIST_ID = 300
    SLOT = 300

    def __init__(self, *args, **kwargs):
        self.users = list(kwargs.pop("users", []) or [])
        self.current_id = str(kwargs.pop("current_id", "") or "")
        self.result = None
        super(ProfilePickerDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.setProperty("PlexKM.Profile.Hint", "좌우로 이동  ·  선택: 전환  ·  뒤로: 닫기")
            ctl = self.getControl(self.LIST_ID)
            ctl.reset()
            sel = 0
            for i, u in enumerate(self.users):
                li = xbmcgui.ListItem(label=u.get("title") or "Plex")
                li.setProperty("PlexKM.Profile.Initial", _initial(u.get("title")))
                li.setProperty("PlexKM.Profile.Thumb", u.get("thumb") or "")
                li.setProperty("PlexKM.Profile.Protected", "1" if u.get("protected") == "1" else "0")
                cur = str(u.get("id") or "") == self.current_id
                li.setProperty("PlexKM.Profile.Current", "1" if cur else "0")
                if cur:
                    sel = i
                ctl.addItem(li)
            n = max(1, len(self.users))
            width = min(1920, self.SLOT * n)
            ctl.setPosition(int((1920 - width) / 2), 360)
            ctl.setWidth(width)
            ctl.selectItem(sel)
            self.setFocusId(self.LIST_ID)
        except Exception:
            _log("PICKER_INIT_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGERROR)
            self.close()

    def onClick(self, control_id):
        if control_id == self.LIST_ID:
            try:
                pos = int(self.getControl(self.LIST_ID).getSelectedPosition())
            except Exception:
                pos = -1
            self.result = pos if 0 <= pos < len(self.users) else None
            self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.result = None
            self.close()


class PinDialog(xbmcgui.WindowXMLDialog):
    PAD_ID = 400
    KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "back", "0", "cancel"]

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", {}) or {}
        self.verify = kwargs.pop("verify", None)
        self.result = None
        self.pin = ""
        self._busy = False
        super(PinDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        name = self.user.get("title") or "Plex"
        self.setProperty("PlexKM.Pin.Name", name)
        self.setProperty("PlexKM.Pin.Initial", _initial(name))
        self.setProperty("PlexKM.Pin.Thumb", self.user.get("thumb") or "")
        self._paint()
        pad = self.getControl(self.PAD_ID)
        pad.reset()
        for code in self.KEYS:
            label = code if code.isdigit() else ("취소" if code == "cancel" else "")
            li = xbmcgui.ListItem(label=label)
            li.setProperty("PlexKM.Key.Code", code)
            pad.addItem(li)
        pad.selectItem(0)
        self.setFocusId(self.PAD_ID)

    def _paint(self, msg=""):
        self.setProperty("PlexKM.Pin.Len", str(len(self.pin)))
        self.setProperty("PlexKM.Pin.Message", msg)

    def _press(self, code):
        if self._busy:
            return
        if code == "cancel":
            self.result = None
            self.close()
            return
        if code == "back":
            self.pin = self.pin[:-1]
            self._paint()
            return
        if code.isdigit() and len(self.pin) < 4:
            self.pin += code
            self._paint()
            if len(self.pin) == 4:
                self._submit()

    def _submit(self):
        self._busy = True
        self._paint("확인 중…")
        res = None
        try:
            res = self.verify(self.pin) if self.verify else None
        except Exception:
            res = {"ok": False, "err": "net"}
        self._busy = False
        if res and res.get("ok"):
            self.result = res
            self.close()
            return
        err = (res or {}).get("err")
        self.pin = ""
        self._paint("PIN이 올바르지 않습니다" if err == "pin" else "전환하지 못했습니다. 잠시 후 다시 시도해 주세요")
        self.setProperty("PlexKM.Pin.Shake", "1")
        xbmc.sleep(320)
        self.clearProperty("PlexKM.Pin.Shake")

    def onClick(self, control_id):
        if control_id == self.PAD_ID:
            try:
                li = self.getControl(self.PAD_ID).getSelectedItem()
                self._press(li.getProperty("PlexKM.Key.Code"))
            except Exception:
                pass

    def onAction(self, action):
        aid = action.getId()
        if aid in ACTION_DIGITS:
            self._press(ACTION_DIGITS[aid])
        elif aid in ACTION_BACKSPACE:
            self._press("back")
        elif aid in ACTION_BACK:
            if self.pin and aid != 10:
                self._press("back")
            else:
                self.result = None
                self.close()


def _notice(title, line1="", line2="", ms=2600):
    try:
        from resources.lib import pkm_notify
        pkm_notify.pkm_show_notice(title, line1, line2, ms=ms)
    except Exception:
        pass


def _notice_set(title, line1="", line2="", sticky=False):
    try:
        from resources.lib import pkm_notify
        return pkm_notify.pkm_notice_set(title, line1, line2, sticky=sticky, force_replace=True)
    except Exception:
        return ""


def _notice_clear(token):
    if not token:
        return
    try:
        from resources.lib import pkm_notify
        pkm_notify.pkm_notice_clear(expected_token=token, force=True)
    except Exception:
        pass


def run_switch_flow(core, home_win=None):
    """Picker -> PIN -> switch -> apply.  Returns the applied result or None."""
    st = load_state()
    users = list(st.get("users") or [])
    refresh = None
    if users and st.get("user_id"):
        refresh = _UsersRefreshR83()
        refresh.start()
    else:
        users, st = list_users()
    if not users:
        _notice("프로필", "Plex 사용자 목록을 불러오지 못했습니다.", "네트워크 연결을 확인해 주세요.")
        return None
    current_id = str(st.get("user_id") or "")
    dlg = ProfilePickerDialog("plexkm_profile_picker_r82.xml", _addon_path(), "Default", "1080i",
                              users=users, current_id=current_id)
    mirrored = mirror_home_props(dlg, home_win)
    _log("PICKER_OPEN users=%d cached=%d mirrored_props=%d" % (len(users), int(refresh is not None), mirrored))
    dlg.doModal()
    choice = dlg.result
    del dlg
    if refresh is not None:
        # Usually long finished while the picker was on screen.
        refresh.join(2.0 if choice is not None else 0.01)
        fresh = refresh.users
        if fresh:
            st = load_state()
            st["users"] = fresh
            save_state(st)
            if choice is not None:
                picked_id = str(users[int(choice)].get("id") or "")
                match = [u for u in fresh if str(u.get("id") or "") == picked_id]
                if not match:
                    _notice("프로필", "Plex 사용자 목록이 바뀌었습니다.", "다시 선택해 주세요.")
                    return None
                users = fresh
                choice = fresh.index(match[0])
    if choice is None:
        return None
    user = users[int(choice)]
    if str(user.get("id") or "") == current_id:
        _log("PICK_SAME_USER %s" % current_id)
        return None
    if user.get("protected") == "1":
        pin_dlg = PinDialog("plexkm_profile_pin_r82.xml", _addon_path(), "Default", "1080i",
                            user=user, verify=lambda pin: switch_user(core, user, pin))
        mirror_home_props(pin_dlg, home_win)
        pin_dlg.doModal()
        result = pin_dlg.result
        del pin_dlg
        if not result:
            return None
    else:
        busy = _notice_set("프로필 전환", "%s 프로필로 전환 중…" % (user.get("title") or ""), "", sticky=True)
        result = switch_user(core, user)
        if not result.get("ok"):
            _notice_clear(busy)
            _notice("프로필 전환", "%s(으)로 전환하지 못했습니다." % (user.get("title") or ""),
                    "서버 접근 권한이 없거나 네트워크 오류입니다." if result.get("err") == "server" else "잠시 후 다시 시도해 주세요.")
            return None
    apply_switch(result)
    return result


# ------------------------------------------------------------------ login flow helpers
def server_token_for_login(plextv_tok):
    """At Plex link/login time: per-server access token for the configured server.
    Owner tokens work as-is; a managed Home user's plex.tv token does not."""
    try:
        server = (_addon().getSetting("plex_url") or "").strip().rstrip("/")
        mid = ""
        if server:
            try:
                root = ET.fromstring(urlopen(Request(server + "/identity", headers={"Accept": "application/xml"}), timeout=6).read())
                mid = str(root.get("machineIdentifier") or "")
            except Exception:
                mid = ""
        body = _http("https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=0",
                     plextv_tok, accept="application/json", timeout=12)
        servers = [d for d in json.loads(body.decode("utf-8"))
                   if "server" in str(d.get("provides") or "") and d.get("accessToken")]
        for d in servers:
            if mid and str(d.get("clientIdentifier") or "") == mid:
                return str(d["accessToken"])
        if not mid and len(servers) == 1:
            return str(servers[0]["accessToken"])
    except Exception:
        _log("LOGIN_SERVER_TOKEN_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    return ""


def login_pin_switch(user, owner_token):
    """PKM PIN pad for a protected Home user during login.  Returns plex.tv token or ""."""
    uid = str(user.get("id") or "")

    def _verify(pin):
        url = "https://plex.tv/api/home/users/%s/switch?%s" % (quote(uid, safe=""), urlencode({"pin": pin}))
        try:
            root = ET.fromstring(_http(url, owner_token, data=b"", timeout=12))
            tok = (root.get("authenticationToken") or root.get("authToken") or "").strip()
            return {"ok": bool(tok), "plextv_token": tok, "err": "" if tok else "net"}
        except HTTPError as e:
            return {"ok": False, "err": "pin" if e.code in (401, 403) else "net"}
        except Exception:
            return {"ok": False, "err": "net"}

    u = dict(user)
    u.setdefault("title", user.get("username") or "Plex")
    dlg = PinDialog("plexkm_profile_pin_r82.xml", _addon_path(), "Default", "1080i", user=u, verify=_verify)
    dlg.doModal()
    res = dlg.result
    del dlg
    return (res or {}).get("plextv_token") or ""
