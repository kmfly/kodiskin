# -*- coding: utf-8 -*-
"""PKM home window part (R73): 재생 시작/복귀.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartPlaybackR73
    def _r26_is_replayed(self, now):
        try:
            last_end = float(getattr(self, "_r26_last_end", 0.0) or 0.0)
            last_dur = float(getattr(self, "_r26_last_dur", 0.0) or 0.0)
            chain = bool(getattr(self, "_r26_chain", False))
            gap = now - last_end
            if last_end <= 0.0 or gap < 0.0 or gap > self._R26_REPLAY_GAP_S:
                return False, gap
            return (last_dur >= self._R26_LONG_HANDLER_S or chain), gap
        except Exception:
            return False, 0.0

    def _is_pkm_playback_handoff_active(self):
        """v600: legacy compatibility stub.

        Older patches used this as a playback shield/handoff detector and then
        skipped Home refresh, swallowed keys, restored Info, or hid PKM/skin Home.
        That was the root of the post-playback black screen / lost focus / skin
        Home exposure loop.  Normal Kodi playback must not alter PKM Home flow.
        """
        return False


    def _resume_offset_ms_for_ui(self, view_offset_ms, duration_raw=0, resume_duration_ms=0):
        """Return a safe resume offset for Info/Home button decisions.

        v1506: the visible 이어서 재생 button and the actual PlayMedia URL must
        use the same normalized resume rule. Local resume save already discards
        positions under 60 seconds and positions at 90% or later, so Info must
        not advertise a resume action for those states.
        """
        try:
            pair = getattr(_ensure_core(), "_pkm_progress_pair", None)
            if pair:
                off_ms, dur_ms, pct = pair(view_offset_ms, duration_raw, resume_duration_ms)
            else:
                off_ms = int(float(view_offset_ms or 0))
                dur_ms = int(float(resume_duration_ms or duration_raw or 0))
                pct = int(round((float(off_ms) * 100.0) / float(dur_ms))) if off_ms > 0 and dur_ms > 0 else 0
        except Exception:
            off_ms, dur_ms, pct = 0, 0, 0
        try:
            off_ms = int(float(off_ms or 0))
            dur_ms = int(float(dur_ms or 0))
            pct = int(float(pct or 0))
        except Exception:
            return 0
        if off_ms < 30000:  # R31 (was 60 s)
            return 0
        if dur_ms <= 0 or pct <= 0:
            return 0
        if pct >= 90:
            return 0
        return off_ms

    def _play_button_label(self, view_offset_ms, duration_raw=0, resume_duration_ms=0):
        try:
            return "이어서 재생" if self._resume_offset_ms_for_ui(view_offset_ms, duration_raw, resume_duration_ms) > 0 else "재생"
        except Exception:
            return "재생"

    def _summary_display_text(self, text, limit=150):
        return pkm_info_data.summary_display_text(text, limit)

    def _home_summary_display_text_v2179(self, text):
        """Return a Home synopsis guaranteed to fit the 720px / 3-line surface.

        v2179: the old Home path used a fixed 108-character budget.  That does
        not correspond to rendered width: Korean glyphs are much wider than
        spaces/Latin punctuation, so some plots reached a clipped fourth line
        without an ellipsis.  Keep the legacy truncator everywhere else and
        use this width-aware wrapper only for PlexKM.Home.SummaryDisplay.

        The Home font is NotoSansKR-Medium 25px in a 720px textbox.  Width
        units below mirror that font's practical advances with a small safety
        margin (about 690px usable per line) so Kodi never has to expose a
        fourth clipped line.  No font/PIL/runtime image processing is used.
        """
        try:
            value = " ".join((text or "").replace("\r", " " ).replace("\n", " " ).split())
            if not value:
                return ""

            line_limit = 27600  # font-em/1000 units: ~= 690px at 25px
            max_lines = 3

            def _cw(ch):
                if not ch:
                    return 0
                if ch.isspace():
                    return 225
                # Noto Sans KR Korean/CJK glyphs are about 0.92em wide.
                if unicodedata.east_asian_width(ch) in ("W", "F"):
                    return 920
                if ch in ".,'`":
                    return 300
                if ch in "()[]{}":
                    return 360
                if ch in "!?:;":
                    return 360
                if ch in "·/\\|-_":
                    return 500
                if "A" <= ch <= "Z":
                    return 620
                if "a" <= ch <= "z":
                    return 560
                if "0" <= ch <= "9":
                    return 570
                cat = unicodedata.category(ch)
                if cat.startswith("P"):
                    return 500
                return 600

            def _word_width(word):
                return sum(_cw(ch) for ch in word)

            def _line_count(candidate):
                if not candidate:
                    return 0
                lines = 1
                used = 0
                for word in candidate.split(" " ):
                    if not word:
                        continue
                    ww = _word_width(word)
                    sw = 225 if used else 0
                    if ww <= line_limit:
                        if used and used + sw + ww > line_limit:
                            lines += 1
                            used = ww
                        else:
                            used += sw + ww
                    else:
                        if used:
                            lines += 1
                            used = 0
                        for ch in word:
                            cw = _cw(ch)
                            if used and used + cw > line_limit:
                                lines += 1
                                used = 0
                            used += cw
                    if lines > max_lines:
                        return lines
                return lines

            if _line_count(value) <= max_lines:
                return value

            ellipsis = "..."
            lo, hi, best = 0, len(value), 0
            while lo <= hi:
                mid = (lo + hi) // 2
                cut = value[:mid].rstrip()
                probe = cut.rstrip(" .,;:·/") + ellipsis if cut else ellipsis
                if _line_count(probe) <= max_lines:
                    best = mid
                    lo = mid + 1
                else:
                    hi = mid - 1

            cut = value[:best].rstrip().rstrip(" .,;:·/")
            # Defensive final fit check for punctuation/word-boundary changes.
            while cut and _line_count(cut + ellipsis) > max_lines:
                cut = cut[:-1].rstrip().rstrip(" .,;:·/")
            return (cut + ellipsis) if cut else ellipsis
        except Exception:
            return self._summary_display_text(text, 84)

    def _title_display_text(self, text, limit_units=51):
        return pkm_info_data.title_display_text(text, limit_units)

    def _genre_display_text(self, text, limit=62):
        return pkm_info_data.genre_display_text(text, limit)

    def _home_fanart_display_url(self, fanart):
        """Return the hero fanart texture URL used by the Home XML.

        v717: keep original-quality Plex art, but make sure the displayed
        texture URL is authenticated.  v716 restored the original direct art URL
        for quality, but some ListItem rows reached Home without X-Plex-Token;
        Kodi then tried to load /library/metadata/.../art/... anonymously and
        logged HTTP 401, so the fanart disappeared.

        This keeps the original /library/metadata/.../art/... path instead of
        using low-quality /photo/:/transcode, and only appends the Plex token
        when the URL is a Plex library URL that does not already contain one.
        This is data/display preparation only, not navigation/focus/playback
        flow control.
        """
        try:
            text = str(fanart or "").strip()
        except Exception:
            text = str(fanart or "")
        if not text:
            return text
        try:
            parts = urlsplit(text)
            if not parts.scheme or not parts.netloc:
                return text
            path = parts.path or ""
            if not path.startswith("/library/metadata/"):
                return text
            for k, _v in parse_qsl(parts.query, keep_blank_values=True):
                if str(k or "").lower() == "x-plex-token":
                    return text
            c = _ensure_core()
            if c is not None and hasattr(c, "append_token"):
                authed = c.append_token(text)
                if authed:
                    return str(authed)
        except Exception:
            pass
        return text

    def _home_hero_fanart_url_r115(self, fanart):
        """R115: Home hero fanart sized to its 1360x765 box.

        Plex art originals are often 3840x2160 (2 MB); Kodi cached them at
        1920x1080 and rescaled every focus change, which cost 2-6 frames when the
        hero switched on SHIELD.  Ask Plex for exactly the displayed size at
        quality 90 (v716's soft look came from the default transcode quality).
        Non-Plex or unexpected URLs fall back to _home_fanart_display_url.
        """
        authed = self._home_fanart_display_url(fanart)
        # R116: TMDb fallback backdrops arrive as /t/p/original/ (often 3840 px,
        # several MB); the 1360x765 hero only needs the w1280 rendition.
        try:
            low_r116 = str(authed or "")
            if "image.tmdb.org" in low_r116.lower():
                for src_r116, dst_r116 in (("/t/p/original/", "/t/p/w1280/"), ("%2ft%2fp%2foriginal%2f", "%2ft%2fp%2fw1280%2f"),
                                           ("%2Ft%2Fp%2Foriginal%2F", "%2Ft%2Fp%2Fw1280%2F")):
                    low_r116 = low_r116.replace(src_r116, dst_r116)
                return low_r116
        except Exception:
            pass
        try:
            parts = urlsplit(str(authed or ""))
            if not parts.scheme or not parts.netloc or not (parts.path or "").startswith("/library/metadata/"):
                return authed
            token = ""
            for k, v in parse_qsl(parts.query, keep_blank_values=True):
                if str(k or "").lower() == "x-plex-token":
                    token = v
            if not token:
                return authed
            inner = parts.path + ("?" + parts.query if parts.query else "")
            q = urlencode([("width", "1360"), ("height", "765"), ("minSize", "1"), ("upscale", "1"),
                           ("quality", "90"), ("url", inner), ("X-Plex-Token", token)])
            return urlunsplit((parts.scheme, parts.netloc, "/photo/:/transcode", q, ""))
        except Exception:
            return authed

    def _home_watcha_bar_display(self, watcha_props=None):
        """Return only Watcha score/count text; the XML supplies the existing logo image."""
        try:
            watcha_props = watcha_props if isinstance(watcha_props, dict) else {}

            def _clean(value):
                text = str(value or "").strip()
                return "" if text in ("...", "…", "-", "--") else text

            rating = _clean(watcha_props.get("Rating"))
            count = _clean(watcha_props.get("Count"))
            display = _clean(watcha_props.get("Display"))
            bits = []

            def _gold_score(value):
                return "[COLOR FFD4AF37]%s[/COLOR]" % value

            if rating:
                bits.extend(("평점", _gold_score(rating)))
            elif display:
                # Fallback rows can contain a combined value such as 6.2(2.5만명).
                # Color only the first numeric rating, not the participation count.
                display = re.sub(
                    r"(?<![0-9])([0-9]+(?:\.[0-9]+)?)(?![0-9])",
                    lambda m: _gold_score(m.group(1)),
                    display,
                    count=1,
                )
                bits.append(display)
            if count:
                bits.extend(("참여", count))
            return "  ".join(bits)
        except Exception:
            return ""

    def _home_rating_bar_display(self, cine21_props=None, watcha_props=None, imdb_rating=""):
        """Build the full Home movie rating row without fixed-width truncation.

        v1579 rules:
        - IMDb is independent and is shown whenever the current movie has a score.
        - Cine21 and Watcha are added when present; they never suppress IMDb.
        - Missing sub-values are omitted instead of rendering literal ellipsis.
        - XML renders this single string inside an auto-width button, so the
          background bar grows and shrinks with the actual content.
        """
        try:
            cine21_props = cine21_props if isinstance(cine21_props, dict) else {}
            watcha_props = watcha_props if isinstance(watcha_props, dict) else {}

            def _clean(value):
                s = str(value or "").strip()
                if s in ("...", "…", "-", "--"):
                    return ""
                return s

            parts = []
            critic = _clean(cine21_props.get("CriticRating"))
            audience = _clean(cine21_props.get("AudienceRating"))
            if critic or audience:
                cine_bits = ["씨네21"]
                if critic:
                    cine_bits.extend(("전문가", critic))
                if audience:
                    cine_bits.extend(("관객", audience))
                parts.append("  ".join(cine_bits))

            watcha_rating = _clean(watcha_props.get("Rating"))
            watcha_count = _clean(watcha_props.get("Count"))
            watcha_display = _clean(watcha_props.get("Display"))
            if watcha_rating or watcha_count or watcha_display:
                watcha_bits = ["왓챠"]
                if watcha_rating:
                    watcha_bits.extend(("평점", watcha_rating))
                elif watcha_display:
                    watcha_bits.append(watcha_display)
                if watcha_count:
                    watcha_bits.extend(("참여", watcha_count))
                parts.append("  ".join(watcha_bits))

            imdb = _clean(imdb_rating)
            if imdb:
                parts.append("IMDb  " + imdb)

            return "    |    ".join(parts)
        except Exception:
            return ""

    def _consume_playstate_dirty(self, reason="home"):
        """Queue a Home-only Continue Watching refresh without touching current UI.

        v1632: this method runs at the beginning of onAction/onFocus. Rebuilding
        Home here blocks the exact key that should move into a sidebar library.
        Preserve the completed scene and refresh once on the next natural Home
        entry instead.
        """
        try:
            win = xbmcgui.Window(10000)
            dirty = win.getProperty("PlexKM.PlayStateDirty") == "1"
            pending = win.getProperty("PlexKM.PlayStateUpdatePending") == "1"
            queued = win.getProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632") == "1"
            runtime_updates_disabled = win.getProperty("PlexKM.RuntimeWidgetUpdatesDisabledV1644") == "1"
            # v1938: v1644 blocks background library/runtime churn, but a completed
            # playback stop is an explicit local state change and must survive until
            # the next natural Home entry.  The previous order cleared the dedicated
            # PostStop flag before v1632 could rebuild 이어보기, even though the local
            # resume sidecar had been written successfully.
            if runtime_updates_disabled and not queued:
                win.clearProperty("PlexKM.PlayStateDirty")
                win.clearProperty("PlexKM.PlayStateDirtyRatingKey")
                win.clearProperty("PlexKM.PlayStateUpdatePending")
                self._playstate_home_refresh_pending_v1632 = False
                return False
            if runtime_updates_disabled and queued:
                _log("PLAYSTATE_HOME_REFRESH_PRESERVE_V1938 reason=%s queued=1 runtime_updates_disabled=1 action=next_natural_home_entry" % reason)
            if pending and not dirty and not queued:
                _log("PLAYSTATE_HOME_REFRESH_WAIT reason=%s pending=1" % reason)
                return False
            if not dirty and not queued:
                return False
            rating_key = win.getProperty("PlexKM.PlayStateDirtyRatingKey") or ""
            self._playstate_home_refresh_pending_v1632 = True
            win.setProperty("PlexKM.Playback.PostStopHomeRefreshPendingV1632", "1")
            if rating_key:
                win.setProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632", rating_key)
            win.clearProperty("PlexKM.PlayStateDirty")
            win.clearProperty("PlexKM.PlayStateDirtyRatingKey")
            _log("PLAYSTATE_HOME_REFRESH_QUEUED_V1632 reason=%s rating_key=%s action=keep_current_scene no_immediate_rebuild=1" % (
                reason, rating_key
            ))
            return True
        except Exception:
            _log("PLAYSTATE_HOME_REFRESH_QUEUE_FAILED_V1632\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            return False


    def _playstate_refresh_visible_surface_v2575(self, target_surface="", reason=""):
        """Refresh the exact visible owner after playback using local state only.

        v2575 is intentionally user-action-bound: no background Plex request is
        started.  A completed Stop writes the local resume sidecar first; when
        Info closes, rebuild only the surface the user is returning to.  This
        reclassifies a resumed item out of "최근 추가됨" into "이어보기" and
        regenerates the progress composite on Home/Recommend/Library.
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Playback.LocalResumeReadyV2575") != "1":
                return False
            rating_key = win.getProperty("PlexKM.Playback.LocalResumeRatingKeyV2575") or win.getProperty("PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632") or ""
            sid = win.getProperty("PlexKM.Playback.ReturnInline.SectionId") or ""
            surface = str(target_surface or "")
            menu_item = None
            try:
                menu = self.getControl(MENU_ID)
                menu_item = menu.getSelectedItem() if menu is not None else None
                if not sid and menu_item is not None:
                    sid = menu_item.getProperty("section_id") or ""
            except Exception:
                menu_item = None
            if surface == "section_recommend" and sid and menu_item is not None:
                cache_key = "recommend:%s" % sid
                self._section_persistent_scene_invalidate_v2467(cache_key, reason="playstate_v2575")
                self._show_section_recommend_widgets(menu_item, force=True)
                _log("PLAYSTATE_VISIBLE_REFRESH_V2575 surface=section_recommend section=%s rating_key=%s local_only=1 force_reclassify=1 reason=%s" % (sid, rating_key, reason or ""))
            elif surface == "section_library" and sid and menu_item is not None:
                try:
                    self._library_persistent_scene_invalidate_section_v2470(sid, reason="playstate_v2575")
                except Exception:
                    pass
                self._show_section_wall(menu_item, force=True)
                _log("PLAYSTATE_VISIBLE_REFRESH_V2575 surface=section_library section=%s rating_key=%s local_only=1 progress_rebind=1 reason=%s" % (sid, rating_key, reason or ""))
            elif surface == "home":
                self._home_rows_cache = None
                self._home_wall_ready = False
                self._show_home_wall(force=True)
                _log("PLAYSTATE_VISIBLE_REFRESH_V2575 surface=home rating_key=%s local_only=1 force_reclassify=1 reason=%s" % (rating_key, reason or ""))
            else:
                return False
            # This explicit refresh consumed the post-stop UI work; do not repeat
            # it on the next key or natural Home entry.
            self._playstate_home_refresh_pending_v1632 = False
            for prop in (
                "PlexKM.Playback.LocalResumeReadyV2575",
                "PlexKM.Playback.LocalResumeRatingKeyV2575",
                "PlexKM.Playback.LocalResumeReadyAtV2575",
                "PlexKM.Playback.PostStopHomeRefreshPendingV1632",
                "PlexKM.Playback.PostStopHomeRefreshRatingKeyV1632",
                "PlexKM.Playback.PostStopHomeRefreshTokenV1632",
                "PlexKM.PlayStateDirty",
                "PlexKM.PlayStateDirtyRatingKey",
            ):
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            return True
        except Exception:
            _log("PLAYSTATE_VISIBLE_REFRESH_FAILED_V2575 surface=%s reason=%s err=%s" % (
                target_surface or "", reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _sidebar_enter_replay_r34(self):
        """Replay a sidebar ENTER that arrived before its TV data was ready.

        Runs on the GUI ping (WindowXML callback thread).  Publishes through the
        exact ENTER path (_show_section_recommend_widgets(force=True)) only if
        the same section is still selected, the sidebar still has focus and no
        Info/Search surface is up.  Otherwise the pending ENTER is dropped and
        the previous scene stays, exactly as before.
        """
        pending = getattr(self, "_sidebar_enter_pending_r34", None)
        if not pending:
            return False
        try:
            sid, t0 = pending
            key = "recommend:%s" % sid
            lock = self._sidebar_prepare_state()
            with lock:
                ready = key in self._sidebar_prepare_ready
                failed = key in self._sidebar_prepare_failed
            if not ready and not failed:
                return False  # still building; keep the pending ENTER
            self._sidebar_enter_pending_r34 = None
            reason = ""
            item = None
            if failed and not ready:
                reason = "prepare_failed"
            elif time.monotonic() - float(t0 or 0) > 30.0:
                reason = "stale"
            elif not self._pkm_window_owned_r34():
                reason = "window_not_owned"
            elif ((self.getProperty("PlexKM.Info.InlineActive") == "1" or xbmcgui.Window(10000).getProperty("PlexKM.Info.InlineActive") == "1")
                    and str((getattr(self, "_section_enter_overlay_r35", None) or ("",))[0]) != str(sid)):
                # R35: an ENTER made FROM Info on this section is armed and may proceed.
                reason = "info_active"
            elif self.getProperty("PlexKM.Search.InlineActive") == "1":
                reason = "search_active"
            elif self._safe_focus_id() != MENU_ID:
                reason = "focus_moved:%s" % self._safe_focus_id()
            else:
                item = self._selected_menu_item()
                if (not item or str(item.getProperty("kind") or "") != "section"
                        or str(item.getProperty("section_id") or "").strip() != sid):
                    reason = "selection_moved"
                elif self._section_last_tab(sid, default="recommend") == "library":
                    reason = "tab_library"
            if reason:
                _log("SIDEBAR_ENTER_REPLAY_DROP_R34 section=%s reason=%s previous_scene_kept=1" % (sid, reason))
                return False
            _log("SIDEBAR_ENTER_REPLAY_R34 section=%s waited_ms=%d" % (
                sid, int((time.monotonic() - float(t0 or 0)) * 1000)))
            try:
                for _w_r34 in (self, xbmcgui.Window(10000)):
                    _w_r34.setProperty("PlexKM.Section.LastFocusRow", "8410")
            except Exception:
                pass
            self._show_section_recommend_widgets(item, force=True)
            return True
        except Exception:
            self._sidebar_enter_pending_r34 = None
            _log("SIDEBAR_ENTER_REPLAY_FAILED_R34 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _inline_playback_return_keys(self):
        return [
            "Pending", "SavedAt", "Type", "RatingKey", "SectionId", "PartKey", "PlayUrl",
            "ParentRatingKey", "GrandparentRatingKey", "Season", "Episode", "Title", "ShowTitle",
            "Thumb", "Art", "Summary", "SummaryDisplay", "Year", "Duration", "DurationText",
            "ViewOffset", "PlayButtonLabel", "RemainingText", "RemainingIcon",
            "OriginFocusId", "OriginPos", "OriginRatingKey", "InfoBgColorR38",
        ]

    def _close_playback_loading_overlay(self, overlay):
        if not overlay:
            return
        try:
            overlay.close()
            xbmc.sleep(40)
            _log("PLAYBACK_LOADING_OVERLAY_CLOSED")
        except Exception:
            pass
        try:
            del overlay
        except Exception:
            pass

    def _request_playback_native_stop_v1545(self, reason="", focus_target=0):
        """v1545: stop the current video immediately with Kodi's native command.

        This path intentionally has no overlay, fade, sleep, pause, settle wait,
        Home cover, RunScript delegation, or background stop worker.  The only
        action is one PlayerControl(Stop), guarded against duplicate leaked Back
        delivery while Kodi returns from fullscreen video to the PKM WindowXML.
        """
        try:
            win = xbmcgui.Window(10000)
            if win.getProperty("PlexKM.Playback.BackStopRequested") == "1":
                _log("PLAYBACK_PLAIN_NATIVE_STOP_SKIP_V1545 reason=%s already_requested=1 focus=%s" % (
                    reason or "", focus_target or ""))
                return True
            win.setProperty("PlexKM.Playback.BackStopRequested", "1")
            # A previous build may have left one of the old fade properties set.
            # Clear them before stopping so no skin/overlay fade can be activated.
            for key in (
                "PlexKM.Playback.ReturnFade",
                "PlexKM.Playback.ReturnFade.Stopping",
                "PlexKM.Playback.ReturnFade.Token",
                "PlexKM.Playback.ReturnFade.Source",
                "PlexKM.Playback.ReturnFade.StartedAtMs",
                "PlexKM.Playback.ReturnFade.FadeStartedAtMs",
                "PlexKM.Playback.ReturnFade.PauseHold",
                "PlexKM.Playback.ReturnFade.SuppressPreread",
                "PlexKM.Playback.ReturnFade.DialogMode",
                "PlexKM.Playback.ReturnFade.DialogActive",
                "PlexKM.Playback.ReturnFade.TopLayer",
                "PlexKM.Playback.ReturnFade.HomeCoverReady",
            ):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
            xbmc.executebuiltin("PlayerControl(Stop)")
            _log("PLAYBACK_PLAIN_NATIVE_STOP_REQUEST_V1545 reason=%s focus=%s attempt_seq=%s command=PlayerControl(Stop) fade=0 overlay=0 wait=0" % (
                reason or "", focus_target or "", win.getProperty("PlexKM.Playback.ActiveAttemptSeqV1545") or ""))
            return True
        except Exception:
            _log("PLAYBACK_PLAIN_NATIVE_STOP_FAILED_V1545 reason=%s %s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            return False

    def _arm_playback_priority_v2118(self, rating_key="", reason=""):
        """Make the Play command outrank every nonessential PKM background job.

        This is intentionally armed before Plex/Kodi has produced a video
        surface. Existing workers already poll the passive playback guards, so
        this property makes them yield at their next safe boundary. Sidebar
        spinners are also retired immediately; playback owns its own delayed
        opening spinner and must never inherit a previous menu's ring.
        """
        try:
            win = xbmcgui.Window(10000)
            win.setProperty("PlexKM.Playback.PriorityV2118", "1")
            win.setProperty("PlexKM.Playback.PriorityRatingKeyV2118", str(rating_key or ""))
            win.setProperty("PlexKM.Playback.PriorityArmedAtMsV2118", str(int(time.time() * 1000)))
        except Exception:
            pass
        try:
            pkm_global_busy.cancel_scope("sidebar", reason="playback_priority_v2118")
        except Exception:
            pass
        try:
            self._section_first_visit_gate_cancel_v1620(reason="playback_priority_v2118")
        except Exception:
            pass
        try:
            # Do not destroy the current ready-wall owner just to play a video;
            # it is needed for exact native append continuity after playback.
            # Only prevent new append scheduling during the handoff.
            self._library_append_request_v2070 = False
        except Exception:
            pass
        try:
            self._info_prewarm_token = int(getattr(self, "_info_prewarm_token", 0) or 0) + 1
            self._search_cast_prewarm_token_v1781 = "playback-priority:%d" % self._now_ms()
        except Exception:
            pass
        try:
            with self._info_cast_prewarm_lock:
                self._info_cast_prewarm_queue = []
        except Exception:
            pass
        try:
            with self._wall_poster_prefetch_lock_v1644:
                self._wall_poster_prefetch_queue_v1644 = []
        except Exception:
            pass
        _log("PLAYBACK_PRIORITY_ARM_V2118 rating_key=%s reason=%s sidebar_spinner_cancel=1 background_yield=1 focus_write=0" % (
            rating_key or "", reason or ""
        ))
        return True

    def _clear_playback_priority_v2118(self, reason=""):
        try:
            win = xbmcgui.Window(10000)
            for key in (
                "PlexKM.Playback.PriorityV2118",
                "PlexKM.Playback.PriorityRatingKeyV2118",
                "PlexKM.Playback.PriorityArmedAtMsV2118",
            ):
                win.clearProperty(key)
            _log("PLAYBACK_PRIORITY_CLEAR_V2118 reason=%s" % (reason or ""))
            return True
        except Exception:
            return False
