# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
from resources.lib.pkm_focus_audit import audit_event, start_focus_monitor

import sys
import time
import traceback

import xbmc
import xbmcgui
try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

WALL_ID = 9500
HOME_MENU_ID = 9000

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_NAV_BACK = 92
ACTION_CONTEXT_MENU = 117


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


_KODI_DISPLAY_TRANSLATE = {
    ord("\u007C"): "|",
    ord("\u00A6"): "|",
    ord("\u01C0"): "|",
    ord("\u2016"): "|",
    ord("\u2223"): "|",
    ord("\u2225"): "|",
    ord("\u23AA"): "|",
    ord("\u23D0"): "|",
    ord("\u2502"): "|",
    ord("\u2503"): "|",
    ord("\u2758"): "|",
    ord("\u2759"): "|",
    ord("\u275A"): "|",
    ord("\u3163"): "|",
    ord("\u4E28"): "|",
    ord("\uFF5C"): "|",
    ord("\uFFE8"): "|",
}

def _display_text_for_kodi(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def _addon_path():
    return xbmcvfs.translatePath(ADDON.getAddonInfo("path"))


def _ensure_core_imported():
    addon_path = _addon_path()
    if addon_path and addon_path not in sys.path:
        sys.path.insert(0, addon_path)
    import default as core
    return core


class PlexKMWallWindow(xbmcgui.WindowXMLDialog):
    """Right-side lazy wall for Plex KM Home sidebar.

    No second sidebar is created. The existing Home sidebar stays visible behind
    the right-side dialog. LEFT closes this dialog and returns focus to Home id
    9000. OK/Enter and Info open Kodi's normal video info dialog for the focused
    ListItem, so skin.estuary.km/DialogVideoInfo.xml can keep being used.
    """

    def __init__(self, *args, **kwargs):
        self.section_index = kwargs.pop("section_index", "")
        self.section_id = kwargs.pop("section_id", "")
        self.section_title = _display_text_for_kodi(kwargs.pop("section_title", ""))
        self.sort = kwargs.pop("sort", "added") or "added"
        self.initial = int(kwargs.pop("initial", 180) or 180)
        self.batch = int(kwargs.pop("batch", 240) or 240)
        self.near_end = int(kwargs.pop("near_end", 40) or 40)
        self.columns = int(kwargs.pop("columns", 7) or 7)
        self.core = None
        self.section = None
        self.total = 0
        self.offset = 0
        self.loaded = 0
        self.loading = False
        self.closed_for_left = False
        self._last_selected_pos = 0
        super(PlexKMWallWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        audit_event(self, "onInit", class_name=self.__class__.__name__)
        start_focus_monitor(self, self.__class__.__name__)
        t0 = time.time()
        self.core = _ensure_core_imported()
        home = xbmcgui.Window(10000)
        home.setProperty("PlexKM.WindowWallActive", "true")
        home.setProperty("PlexKM.WindowWallSectionIndex", str(self.section_index or ""))
        try:
            self._resolve_section()
            self._clear_wall()
            self._append_items(reason="initial", count=self.initial)
            self._focus_wall_when_ready()
            elapsed = (time.time() - t0) * 1000.0
            _log("WINDOW_WALL_OPEN section=%s title=%s first_batch=%d elapsed=%.3fms" % (
                self.section.get("section_id", "") if self.section else "",
                self.section.get("title", "") if self.section else "",
                self.loaded,
                elapsed,
            ))
        except Exception:
            _log("WINDOW_WALL_INIT_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            try:
                if pkm_notify:
                    pkm_notify.pkm_show_notice(ADDON.getAddonInfo("name"), "월 화면 초기화 실패", "kodi.log를 확인해주세요", ms=4000)
            except Exception:
                pass
            self.close()

    def _resolve_section(self):
        core = self.core
        section = None
        if self.section_id:
            section = core.find_section(section_id=self.section_id, refresh=False)
        if not section and self.section_title:
            section = core.find_section(section_title=self.section_title, refresh=False)
        if not section and str(self.section_index) != "":
            try:
                idx = int(self.section_index)
                sections = core.apply_section_order(core.fetch_sections(refresh=False), save_merged=False)
                if 0 <= idx < len(sections):
                    section = sections[idx]
            except Exception:
                section = None
        if not section:
            raise RuntimeError("Plex section not found: index=%s section_id=%s title=%s" % (
                self.section_index, self.section_id, self.section_title
            ))
        self.section = section
        self.section_id = str(section.get("section_id", ""))
        self.section_title = _display_text_for_kodi(section.get("title", ""))
        self.total = int(core.count_items(self.section_id) or 0)
        home = xbmcgui.Window(10000)
        home.setProperty("PlexKM.LastSectionId", self.section_id)
        home.setProperty("PlexKM.LastSectionTitle", _display_text_for_kodi(self.section_title))
        home.setProperty("PlexKM.LastTotalCount", str(self.total))
        _log("WINDOW_WALL_INDEX index=%s section=%s title=%s total=%d sort=%s" % (
            self.section_index, self.section_id, self.section_title, self.total, self.sort
        ))
        _log("WINDOW_WALL_REQUEST section=%s title=%s total=%d initial=%d batch=%d" % (
            self.section_id, self.section_title, self.total, self.initial, self.batch
        ))

    def _clear_wall(self):
        try:
            self.getControl(WALL_ID).reset()
        except Exception:
            pass
        self.offset = 0
        self.loaded = 0

    def _append_items(self, reason="near_end", count=None):
        if self.loading:
            return
        if self.total and self.loaded >= self.total:
            return
        self.loading = True
        t0 = time.time()
        try:
            count = int(count or self.batch)
            rows = self.core.query_items(self.section_id, sort=self.sort, limit=count, offset=self.offset, plex_type=None)
            wall = self.getControl(WALL_ID)
            added = 0
            for row in rows:
                li = self._make_window_item(row)
                wall.addItem(li)
                added += 1
            old_offset = self.offset
            self.offset += added
            self.loaded += added
            elapsed = (time.time() - t0) * 1000.0
            _log("WINDOW_WALL_APPEND section=%s title=%s reason=%s offset=%d added=%d loaded=%d total=%d elapsed=%.3fms" % (
                self.section_id, self.section_title, reason, old_offset, added, self.loaded, self.total, elapsed
            ))
        except Exception:
            _log("WINDOW_WALL_APPEND_FAILED\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        finally:
            self.loading = False

    def _make_window_item(self, row):
        li, is_playable = self.core.make_listitem_from_row(row, wall_light=False)
        (rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year,
         summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count,
         last_viewed_at, show_title, season, episode) = row
        play_url = li.getPath() or self.core.build_plugin_url({"action": "play", "rating_key": rating_key, "part_key": part_key})
        li.setPath(play_url)
        li.setProperty("PlexKM.PlayUrl", play_url)
        li.setProperty("PlexKM.SectionIndex", str(self.section_index or ""))
        li.setProperty("PlexKM.SectionId", str(section_id or self.section_id or ""))
        li.setProperty("PlexKM.SectionTitle", _display_text_for_kodi(self.section_title or ""))
        li.setProperty("PlexKM.RatingKey", str(rating_key or ""))
        li.setProperty("PlexKM.Type", str(plex_type or ""))
        li.setProperty("PlexKM.Title", title or "")
        li.setProperty("PlexKM.Year", str(year or ""))
        li.setProperty("PlexKM.Thumb", thumb or "")
        li.setProperty("PlexKM.Poster", thumb or "")
        li.setProperty("PlexKM.Art", art or "")
        li.setProperty("PlexKM.Fanart", art or "")
        li.setProperty("PlexKM.File", media_file or "")
        li.setProperty("PlexKM.PartKey", part_key or "")
        li.setProperty("PlexKM.Summary", summary or "")
        if is_playable:
            li.setProperty("IsPlayable", "true")
        return li

    def _focus_wall_when_ready(self):
        """Focus wall after the panel has been populated."""
        try:
            wall = self.getControl(WALL_ID)
            if int(wall.size()) <= 0:
                return False
            xbmc.sleep(80)
            try:
                self.setFocus(wall)
            except Exception:
                self.setFocusId(WALL_ID)
            self._remember_selected_position()
            _log("WINDOW_WALL_FOCUS_READY control=%d size=%d pos=%d" % (WALL_ID, int(wall.size()), int(getattr(self, "_last_selected_pos", 0))))
            return True
        except Exception as exc:
            _log("WINDOW_WALL_FOCUS_DELAYED_FAILED control=%d error=%s" % (WALL_ID, exc), xbmc.LOGWARNING)
            return False

    def _current_selected_position(self):
        try:
            return int(self.getControl(WALL_ID).getSelectedPosition())
        except Exception:
            return int(getattr(self, "_last_selected_pos", 0) or 0)

    def _remember_selected_position(self):
        try:
            self._last_selected_pos = self._current_selected_position()
        except Exception:
            pass

    def _is_first_column_position(self, pos):
        try:
            pos = int(pos)
            if pos <= 0:
                return True
            return (pos % max(1, int(self.columns or 7))) == 0
        except Exception:
            return True

    def _is_first_column_selected_before_action(self):
        # Use the last remembered position. Kodi may already move the panel
        # selection before Python receives ACTION_MOVE_LEFT.
        return self._is_first_column_position(getattr(self, "_last_selected_pos", 0))

    def _selected_item(self):
        try:
            return self.getControl(WALL_ID).getSelectedItem()
        except Exception:
            return None

    def _sync_home_meta_properties(self, li):
        if not li:
            return
        try:
            home = xbmcgui.Window(10000)
            title = li.getProperty("PlexKM.Title") or li.getLabel()
            year = li.getProperty("PlexKM.Year")
            poster = li.getProperty("PlexKM.Poster") or li.getProperty("PlexKM.Thumb")
            fanart = li.getProperty("PlexKM.Fanart") or li.getProperty("PlexKM.Art")
            rating_key = li.getProperty("PlexKM.RatingKey")
            play_url = li.getProperty("PlexKM.PlayUrl") or li.getPath()
            pairs = (
                ("PlexMeta.Title", title),
                ("PlexMeta.Year", year),
                ("PlexMeta.Poster", poster),
                ("PlexMeta.Thumb", poster),
                ("PlexMeta.Fanart", fanart),
                ("PlexKM.RatingKey", rating_key),
                ("PlexKM.PlayUrl", play_url),
                ("PlexKM.SectionId", li.getProperty("PlexKM.SectionId")),
                ("PlexKM.SectionIndex", li.getProperty("PlexKM.SectionIndex")),
                ("PlexKM.Title", title),
                ("PlexKM.Year", year),
            )
            for key, value in pairs:
                if value is not None:
                    home.setProperty(key, str(value))
        except Exception:
            pass

    def _duration_text(self, duration_ms):
        try:
            sec = int(duration_ms or 0) // 1000
        except Exception:
            sec = 0
        if sec <= 0:
            return ""
        h = sec // 3600
        m = (sec % 3600) // 60
        if h > 0 and m > 0:
            return "%d시간 %d분" % (h, m)
        if h > 0:
            return "%d시간" % h
        return "%d분" % m

    def _summary_display_text(self, text, limit=170):
        text = (text or "").strip()
        if len(text) > limit:
            return text[:max(0, limit - 3)].rstrip() + "..."
        return text

    def _set_info_prop(self, key, value):
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Info.%s" % key, str(value or ""))
        except Exception:
            pass

    def _clear_info_props_for_wall_movie(self):
        win = xbmcgui.Window(10000)
        base_keys = ["InlineActive", "IsTV", "IsShow", "IsEpisode", "RatingKey", "SectionId", "Type", "KodiType", "Title", "Summary", "SummaryDisplay", "Year", "Duration", "DurationText", "ViewOffset", "PlayButtonLabel", "Genre", "Director", "Writer", "Cast", "Studio", "Rating", "ContentRating", "Thumb", "Art", "PartKey", "PlayUrl", "VideoResolutionLabel", "AudioLabel", "SubtitleLabel"]
        for key in base_keys:
            try:
                win.clearProperty("PlexKM.Info.%s" % key)
            except Exception:
                pass
        for idx in range(1, 9):
            for prefix in ("Cast", "DisplayCast"):
                for subkey in ("Name", "Role", "Thumb"):
                    try:
                        win.clearProperty("PlexKM.Info.%s%d.%s" % (prefix, idx, subkey))
                    except Exception:
                        pass
        try:
            win.clearProperty("PlexKM.Info.CastReady")
        except Exception:
            pass

    def _publish_wall_movie_info_props(self, li):
        self._clear_info_props_for_wall_movie()
        core = self.core or _ensure_core_imported()
        rk = li.getProperty("PlexKM.RatingKey") or ""
        node = None
        if rk:
            try:
                root = core.plex_request_xml("/library/metadata/%s" % rk, params={"skipRefresh": 1}, timeout=5)
                for child in list(root):
                    if child.tag in ("Video", "Directory"):
                        node = child
                        break
            except Exception:
                _log("WINDOW_WALL_INFO_META_FETCH_FAILED rating_key=%s\n%s" % (rk, traceback.format_exc()), xbmc.LOGWARNING)
        def attr(name, fallback=""):
            try:
                return (node.get(name) if node is not None else "") or fallback or ""
            except Exception:
                return fallback or ""
        plex_type = (attr("type", li.getProperty("PlexKM.Type")) or "movie").lower()
        title = attr("title", li.getProperty("PlexKM.Title") or li.getLabel())
        summary = attr("summary", li.getProperty("PlexKM.Summary"))
        year = attr("year", li.getProperty("PlexKM.Year"))
        duration = attr("duration", li.getProperty("PlexKM.Duration"))
        duration_text = self._duration_text(duration) or li.getProperty("PlexKM.DurationText")
        rating = attr("rating", li.getProperty("PlexKM.Rating"))
        content_rating = pkm_info_data.localize_content_rating(attr("contentRating", li.getProperty("PlexKM.ContentRating")))
        thumb_raw = attr("thumb", li.getProperty("PlexKM.Thumb") or li.getProperty("PlexKM.Poster"))
        art_raw = attr("art", li.getProperty("PlexKM.Art") or li.getProperty("PlexKM.Fanart"))
        thumb = core.plex_url(thumb_raw, params={"width": 720, "height": 1080}) if thumb_raw and thumb_raw.startswith("/") else thumb_raw
        art = core.plex_url(art_raw, params={"width": 1920, "height": 1080}) if art_raw and art_raw.startswith("/") else art_raw
        genres = []
        directors = []
        cast_names = []
        if node is not None:
            try:
                for ch in list(node):
                    if ch.tag == "Genre" and ch.get("tag"):
                        genres.append(ch.get("tag"))
                    elif ch.tag == "Director" and ch.get("tag"):
                        directors.append(ch.get("tag"))
                    elif ch.tag == "Role":
                        name = ch.get("tag") or ""
                        role = ch.get("role") or ""
                        raw_thumb = ch.get("thumb") or ""
                        thumb_url = core.plex_url(raw_thumb, params={"width": 360, "height": 360}) if raw_thumb.startswith("/") else raw_thumb
                        if len(cast_names) < 8 and name:
                            idx = len(cast_names) + 1
                            cast_names.append(name)
                            self._set_info_prop("Cast%d.Name" % idx, name)
                            self._set_info_prop("Cast%d.Role" % idx, role)
                            self._set_info_prop("Cast%d.Thumb" % idx, thumb_url)
                            self._set_info_prop("DisplayCast%d.Name" % idx, name)
                            self._set_info_prop("DisplayCast%d.Role" % idx, role)
                            self._set_info_prop("DisplayCast%d.Thumb" % idx, thumb_url)
            except Exception:
                pass
        self._set_info_prop("RatingKey", rk)
        self._set_info_prop("SectionId", li.getProperty("PlexKM.SectionId") or self.section_id)
        self._set_info_prop("Type", plex_type or "movie")
        self._set_info_prop("KodiType", "movie" if plex_type == "movie" else plex_type)
        self._set_info_prop("Title", title)
        self._set_info_prop("Summary", summary)
        self._set_info_prop("SummaryDisplay", self._summary_display_text(summary))
        self._set_info_prop("Year", year)
        self._set_info_prop("Duration", duration)
        self._set_info_prop("DurationText", duration_text)
        self._set_info_prop("PlayButtonLabel", li.getProperty("PlexKM.PlayButtonLabel") or "재생")
        self._set_info_prop("Genre", " / ".join(genres) if genres else li.getProperty("PlexKM.Genre"))
        self._set_info_prop("Director", " / ".join(directors) if directors else li.getProperty("PlexKM.Director"))
        self._set_info_prop("Rating", rating)
        self._set_info_prop("ContentRating", content_rating)
        self._set_info_prop("Thumb", thumb)
        self._set_info_prop("Art", art)
        self._set_info_prop("PartKey", li.getProperty("PlexKM.PartKey"))
        self._set_info_prop("PlayUrl", li.getProperty("PlexKM.PlayUrl") or li.getPath())
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Info.CastReady", "1")
        except Exception:
            pass

    def _open_info_for_selected(self):
        # Modal Info was removed. The supported Info UI is the HomeWindow
        # inline overlay; this legacy standalone wall has no modal fallback.
        _log("WINDOW_WALL_INFO_SKIPPED reason=legacy_standalone_wall", xbmc.LOGINFO)

    def _maybe_append(self, reason="near_end"):
        try:
            wall = self.getControl(WALL_ID)
            pos = int(wall.getSelectedPosition())
            size = int(wall.size())
            if size <= 0:
                return
            if (size - pos) <= self.near_end:
                self._append_items(reason=reason, count=self.batch)
        except Exception:
            pass

    def _return_focus_to_home_menu(self):
        self.closed_for_left = True
        self.close()
        try:
            xbmc.sleep(80)
            xbmc.executebuiltin("ActivateWindow(Home)")
            xbmc.executebuiltin("SetFocus(%d)" % HOME_MENU_ID)
        except Exception:
            pass

    def onClick(self, control_id):
        audit_event(self, "onClick", control_id=control_id)
        if control_id == WALL_ID:
            self._open_info_for_selected()

    def onFocus(self, control_id):
        audit_event(self, "onFocus", control_id=control_id)
        if control_id == WALL_ID:
            self._remember_selected_position()
            self._maybe_append(reason="focus")

    def onAction(self, action):
        audit_event(self, "onAction", action_id=getattr(action, "getId", lambda: -1)())
        action_id = action.getId()
        if action_id in (ACTION_NAV_BACK, ACTION_PREVIOUS_MENU):
            self.close()
            return
        if action_id == ACTION_MOVE_LEFT:
            # Do not close here. The panel XML <onleft> fires only at the first column.
            xbmc.sleep(1)
            self._remember_selected_position()
            self._maybe_append(reason="near_end")
            return
        if action_id == ACTION_SHOW_INFO:
            self._open_info_for_selected()
            return
        if action_id == ACTION_CONTEXT_MENU:
            xbmc.executebuiltin("Action(ContextMenu)")
            return
        if action_id in (ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
            xbmc.sleep(1)
            self._remember_selected_position()
            self._maybe_append(reason="near_end")
            return

    def close(self):
        try:
            home = xbmcgui.Window(10000)
            home.setProperty("PlexKM.WindowWallReturn", "true")
            home.clearProperty("PlexKM.WindowWallActive")
            home.clearProperty("PlexKM.WindowWallOpening")
        except Exception:
            pass
        _log("WINDOW_WALL_CLOSED section=%s loaded=%d total=%d left_return=%s" % (
            self.section_id, self.loaded, self.total, str(self.closed_for_left).lower()
        ))
        super(PlexKMWallWindow, self).close()
