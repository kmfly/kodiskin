# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_video_select.xml"

MAIN_LIST_ID = 7000
STREAM_LIST_ID = 7010
MODE_LIST_ID = 7020
INFO_LIST_ID = 7030

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

VIEW_MODES = [
    ("normal", "비율 유지"),
    ("zoom", "확대 채우기 · 화면 일부 잘림"),
    ("original", "원본 해상도"),
    ("stretch16x9", "16:9 강제 늘이기"),
]
VIEW_MODE_LABELS = dict(VIEW_MODES)
DEFAULTS_FILE = "special://profile/addon_data/%s/pkm_video_defaults.json" % ADDON_ID


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][video_select] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


def _addon_path():
    try:
        return xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
    except Exception:
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload)) or "{}"
        return json.loads(raw)
    except Exception:
        _log("jsonrpc_failed method=%s\n%s" % (method, traceback.format_exc()), xbmc.LOGWARNING)
        return {}


def _active_video_player_id():
    for item in (_jsonrpc("Player.GetActivePlayers").get("result") or []):
        try:
            if item.get("type") == "video":
                return int(item.get("playerid"))
        except Exception:
            pass
    return -1


def _video_snapshot():
    player_id = _active_video_player_id()
    if player_id < 0:
        return player_id, [], -1
    result = (_jsonrpc(
        "Player.GetProperties",
        {"playerid": player_id, "properties": ["videostreams", "currentvideostream"]},
    ).get("result") or {})
    streams = result.get("videostreams") or []
    current = result.get("currentvideostream") or {}
    try:
        current_index = int(current.get("index"))
    except Exception:
        current_index = -1
    if current_index < 0 and len(streams) == 1:
        try:
            current_index = int((streams[0] or {}).get("index", 0))
        except Exception:
            current_index = 0
    return player_id, streams, current_index


def _get_view_mode():
    result = _jsonrpc("Player.GetViewMode").get("result") or {}
    return str(result.get("viewmode") or "normal").lower()


def _set_view_mode(viewmode):
    response = _jsonrpc("Player.SetViewMode", {"viewmode": str(viewmode)})
    ok = "error" not in response
    _log("set_view_mode mode=%s ok=%s result=%s" % (viewmode, "1" if ok else "0", response), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok


VIEW_MODE_TOAST_TEXT = "PlexKM.VideoMode.Toast"
VIEW_MODE_TOAST_TOKEN = "PlexKM.VideoMode.ToastToken"
VIEW_MODE_TOAST_MS = 1350


def _show_view_mode_toast(label, duration_ms=VIEW_MODE_TOAST_MS):
    """Show the selected mode in the center of the active PKM VideoOSD."""
    try:
        window = xbmcgui.Window(10000)
        token = "%d-%d" % (int(time.time() * 1000), threading.current_thread().ident or 0)
        window.setProperty(VIEW_MODE_TOAST_TEXT, str(label or ""))
        window.setProperty(VIEW_MODE_TOAST_TOKEN, token)
        xbmc.sleep(max(300, int(duration_ms)))
        if window.getProperty(VIEW_MODE_TOAST_TOKEN) == token:
            window.clearProperty(VIEW_MODE_TOAST_TEXT)
            window.clearProperty(VIEW_MODE_TOAST_TOKEN)
    except Exception:
        _log("view_mode_toast_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)


def cycle_view_mode(show_toast=True):
    """Cycle the compact Kodi view modes with explicit user-facing labels."""
    if not xbmc.Player().isPlayingVideo():
        return False
    current = _get_view_mode()
    order = [mode for mode, _label in VIEW_MODES]
    try:
        next_mode = order[(order.index(current) + 1) % len(order)]
    except ValueError:
        # Any Kodi-native mode outside the compact PKM set enters at Zoom.
        next_mode = "zoom"
    ok = _set_view_mode(next_mode)
    label = _view_mode_label(next_mode)
    _log("cycle_view_mode current=%s next=%s label=%s ok=%s" % (current, next_mode, label, "1" if ok else "0"), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    if ok and show_toast:
        _show_view_mode_toast(label)
    return ok


def _set_video_stream(player_id, stream_index):
    response = _jsonrpc("Player.SetVideoStream", {"playerid": int(player_id), "stream": int(stream_index)})
    ok = "error" not in response
    _log("set_video_stream playerid=%s stream=%s ok=%s result=%s" % (player_id, stream_index, "1" if ok else "0", response), xbmc.LOGINFO if ok else xbmc.LOGWARNING)
    return ok


def _codec_label(codec):
    key = str(codec or "").strip().lower().replace("_", "").replace("-", "")
    return {
        "h264": "H.264", "avc": "H.264", "avc1": "H.264",
        "hevc": "HEVC", "h265": "HEVC", "hev1": "HEVC", "hvc1": "HEVC",
        "av1": "AV1", "vp9": "VP9", "vp8": "VP8",
        "mpeg2video": "MPEG-2", "mpeg2": "MPEG-2", "mpeg4": "MPEG-4", "vc1": "VC-1",
    }.get(key, str(codec or "").upper() or "VIDEO")


def _resolution_label(width, height):
    try:
        width = int(width or 0)
    except Exception:
        width = 0
    try:
        height = int(height or 0)
    except Exception:
        height = 0
    if height >= 2160 or width >= 3840:
        return "2160p"
    if height >= 1440 or width >= 2560:
        return "1440p"
    if height >= 1080 or width >= 1920:
        return "1080p"
    if height >= 720 or width >= 1280:
        return "720p"
    if height >= 576:
        return "576p"
    if height >= 480:
        return "480p"
    if height > 0:
        return "%dp" % height
    return "비디오"


def _info_label(name):
    """Return a resolved Kodi info label, never the unresolved expression itself."""
    expression = str(name or "").strip()
    try:
        value = str(xbmc.getInfoLabel(expression) or "").strip()
    except Exception:
        return ""
    if not value:
        return ""
    # Kodi returns the literal expression for some unsupported labels.  Never
    # surface those implementation strings in the user-facing stream menu.
    low = value.lower()
    if value == expression or low in (expression.lower(),):
        return ""
    if low.startswith(("videoplayer.", "player.process(", "player.")) and value == expression:
        return ""
    return value


def _window_property(name):
    try:
        return str(xbmcgui.Window(10000).getProperty(str(name)) or "").strip()
    except Exception:
        return ""


def _truthy(value):
    return str(value or "").strip().lower() in ("1", "true", "yes", "on", "hw")


def _format_hdr(value):
    text = str(value or "").strip()
    key = text.lower().replace(" ", "").replace("_", "").replace("-", "")
    if not key or key in ("none", "unknown", "off", "false", "0", "sdr"):
        return "SDR"
    if key in ("dolbyvision", "dolbyvisionprofile5", "dv") or "dolbyvision" in key:
        return "Dolby Vision"
    if "hdr10plus" in key or "hdr10+" in text.lower():
        return "HDR10+"
    if "hdr10" in key:
        return "HDR10"
    if "hlg" in key:
        return "HLG"
    if key == "hdr" or key.startswith("hdr"):
        return text.upper()
    return text


def _first_value(*values):
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _format_number(value, digits=3):
    try:
        number = float(value)
    except Exception:
        return str(value or "").strip()
    text = ("%%.%df" % int(digits)) % number
    return text.rstrip("0").rstrip(".")


def _format_bitrate(value):
    text = str(value or "").strip()
    if not text:
        return ""
    lower = text.lower()
    if any(unit in lower for unit in ("mbps", "mib/s", "kbps", "kbit", "mbit")):
        return text
    try:
        number = float(text.replace(",", ""))
    except Exception:
        return text
    # Kodi/Plex fields are commonly bits/s or kbit/s.  Keep the conversion
    # deterministic instead of guessing from the title/resolution.
    if number >= 1000000.0:
        return "%s Mbps" % _format_number(number / 1000000.0, 2)
    if number >= 1000.0:
        return "%s Mbps" % _format_number(number / 1000.0, 2)
    return "%s kbps" % _format_number(number, 0)


def _format_fps(value):
    text = str(value or "").strip()
    if not text:
        return ""
    if "fps" in text.lower():
        return text
    return "%s fps" % _format_number(text, 3)


def _format_aspect(value):
    text = str(value or "").strip()
    if not text:
        return ""
    if ":" in text:
        return text
    try:
        ratio = float(text)
    except Exception:
        return text
    return "%s:1" % _format_number(ratio, 2)


def _stream_label(stream, current=False):
    stream = stream if isinstance(stream, dict) else {}
    label = "%s · %s" % (
        _resolution_label(stream.get("width"), stream.get("height")),
        _codec_label(stream.get("codec")),
    )
    if current:
        label += " (현재)"
    return label


def _view_mode_label(viewmode):
    return VIEW_MODE_LABELS.get(str(viewmode or "").lower(), "기타")


def _defaults_path():
    try:
        return xbmcvfs.translatePath(DEFAULTS_FILE)
    except Exception:
        try:
            return xbmc.translatePath(DEFAULTS_FILE)
        except Exception:
            return DEFAULTS_FILE


def _read_defaults():
    path = _defaults_path()
    try:
        if not xbmcvfs.exists(path):
            return {}
        handle = xbmcvfs.File(path, "r")
        raw = handle.read()
        handle.close()
        data = json.loads(raw or "{}")
        return data if isinstance(data, dict) else {}
    except Exception:
        _log("read_defaults_failed path=%s\n%s" % (path, traceback.format_exc()), xbmc.LOGWARNING)
        return {}


def _write_default_view_mode(viewmode):
    path = _defaults_path()
    try:
        folder = os.path.dirname(path)
        if folder and not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        data = {"enabled": True, "viewmode": str(viewmode or "normal")}
        handle = xbmcvfs.File(path, "w")
        handle.write(json.dumps(data, ensure_ascii=False, sort_keys=True))
        handle.close()
        _log("video_default_saved path=%s viewmode=%s" % (path, data["viewmode"]))
        return True
    except Exception:
        _log("write_default_failed path=%s\n%s" % (path, traceback.format_exc()), xbmc.LOGERROR)
        return False


def _default_matches(viewmode):
    data = _read_defaults()
    return bool(data.get("enabled")) and str(data.get("viewmode") or "") == str(viewmode or "")


def apply_saved_video_defaults(reason="", delayed=True):
    """Apply the PKM view-mode default to a newly started video."""
    data = _read_defaults()
    if not data.get("enabled"):
        return False

    def _worker():
        try:
            if delayed:
                xbmc.sleep(180)
            if not xbmc.Player().isPlayingVideo():
                return
            mode = str(data.get("viewmode") or "normal")
            ok = _set_view_mode(mode)
            _log("video_default_applied reason=%s mode=%s ok=%s" % (reason, mode, "1" if ok else "0"))
        except Exception:
            _log("apply_default_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)

    try:
        thread = threading.Thread(target=_worker, name="PlexKMVideoDefault")
        thread.daemon = True
        thread.start()
    except Exception:
        _worker()
    return True


def _pause_video_for_modal(reason="video_default_confirm_v1653"):
    """Pause only when video is actively running; never toggle an already paused player."""
    try:
        player_id = _active_video_player_id()
        if player_id < 0:
            _log("video_modal_pause_skip reason=%s active_player=0" % reason)
            return False
        result = (_jsonrpc("Player.GetProperties", {"playerid": player_id, "properties": ["speed"]}).get("result") or {})
        speed = int(result.get("speed", 0) or 0)
        if speed == 0:
            _log("video_modal_pause_skip reason=%s already_paused=1 player_id=%s" % (reason, player_id))
            return False
        response = _jsonrpc("Player.PlayPause", {"playerid": player_id, "play": False})
        ok = not bool(response.get("error"))
        _log("video_modal_pause reason=%s player_id=%s old_speed=%s ok=%s" % (reason, player_id, speed, "1" if ok else "0"))
        return ok
    except Exception:
        _log("video_modal_pause_failed reason=%s\n%s" % (reason, traceback.format_exc()), xbmc.LOGWARNING)
        return False


def _confirm_default():
    message = "현재 화면 모드를\n모든 영상의 기본값으로 설정할까요?"
    _pause_video_for_modal()
    try:
        from resources.lib.pkm_settings_flow import open_pkm_confirm_dialog
        return bool(open_pkm_confirm_dialog(
            "비디오 기본값",
            message,
            yes_label="설정",
            no_label="취소",
            windowed_video=True,
        ))
    except Exception:
        _log("pkm_confirm_fallback\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        try:
            return bool(xbmcgui.Dialog().yesno("비디오 기본값", message, yeslabel="설정", nolabel="취소"))
        except Exception:
            return False


class PKMVideoSelectWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.initial_page = str(kwargs.pop("initial_page", "main") or "main")
        self.page = self.initial_page
        self.player_id = -1
        self.streams = []
        self.current_stream_index = -1
        self.viewmode = "normal"
        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def onInit(self):
        try:
            self._refresh_state()
            if self.player_id < 0:
                self.close()
                return
            self._show_page(self.initial_page)
        except Exception:
            _log("window_init_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
            self.close()

    def _refresh_state(self):
        self.player_id, self.streams, self.current_stream_index = _video_snapshot()
        self.viewmode = _get_view_mode()

    def _show_page(self, page, preferred_row_type="", preferred_raw_value="", fallback=0, reason=""):
        self.page = page
        self.setProperty("PlexKM.Video.Page", page)
        if page == "main":
            self._populate_main()
            self._focus_matching_row(MAIN_LIST_ID, preferred_row_type, preferred_raw_value, fallback, reason or "show_main")
        elif page == "streams":
            self._populate_streams()
            raw = preferred_raw_value if preferred_raw_value != "" else self.current_stream_index
            self._focus_matching_row(STREAM_LIST_ID, preferred_row_type or "video_stream", raw, fallback, reason or "show_streams")
        elif page == "modes":
            self._populate_modes()
            raw = preferred_raw_value if preferred_raw_value != "" else self.viewmode
            self._focus_matching_row(MODE_LIST_ID, preferred_row_type or "view_mode", raw, fallback, reason or "show_modes")
        else:
            self._populate_info()
            self._focus_list_position(INFO_LIST_ID, fallback, reason=reason or "show_info")

    def _clear(self, control_id):
        self.getControl(control_id).reset()

    def _focus_list_position(self, control_id, position, reason=""):
        """Focus a list and then restore its selected row.

        Kodi may reset a list to row 0 when setFocusId() is called after a
        repopulation.  Always focus first and select the requested row last so
        the white focus bar stays on the row the user just activated.
        """
        try:
            ctrl = self.getControl(int(control_id))
            size = int(ctrl.size())
            if size <= 0:
                return -1
            pos = max(0, min(size - 1, int(position)))
            self.setFocusId(int(control_id))
            ctrl.selectItem(pos)
            _log("focus_row_restore control=%s pos=%s reason=%s" % (control_id, pos, reason))
            return pos
        except Exception:
            _log("focus_row_restore_failed control=%s pos=%s reason=%s\n%s" % (control_id, position, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _find_row_position(self, control_id, row_type="", raw_value="", fallback=0):
        try:
            ctrl = self.getControl(int(control_id))
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if row_type and (item.getProperty("row_type") or "") != str(row_type):
                    continue
                if raw_value != "" and (item.getProperty("raw_value") or "") != str(raw_value):
                    continue
                return pos
        except Exception:
            pass
        return int(fallback)

    def _focus_matching_row(self, control_id, row_type="", raw_value="", fallback=0, reason=""):
        pos = self._find_row_position(control_id, row_type=row_type, raw_value=raw_value, fallback=fallback)
        return self._focus_list_position(control_id, pos, reason=reason)

    def _update_selected_rows_in_place(self, control_id, row_type, raw_value, update_stream_labels=False, reason=""):
        """Update checkmarks/labels without resetting the list control.

        Resetting and rebuilding a focused Kodi list makes the whole popup briefly
        repaint, which looks like a shake.  Selection-only changes can be applied
        directly to the existing ListItems, preserving the focused row and panel.
        """
        try:
            ctrl = self.getControl(int(control_id))
            stream_by_index = {}
            if update_stream_labels:
                for pos, stream in enumerate(self.streams or []):
                    try:
                        idx = int((stream or {}).get("index", pos))
                    except Exception:
                        idx = pos
                    stream_by_index[str(idx)] = stream
            matched_pos = -1
            target = str(raw_value)
            for pos in range(int(ctrl.size())):
                item = ctrl.getListItem(pos)
                if (item.getProperty("row_type") or "") != str(row_type):
                    continue
                item_value = item.getProperty("raw_value") or ""
                selected = str(item_value) == target
                item.setProperty("selected", "1" if selected else "0")
                if selected:
                    matched_pos = pos
                if update_stream_labels:
                    stream = stream_by_index.get(str(item_value))
                    if stream is not None:
                        item.setLabel(_stream_label(stream, current=selected))
            _log("selection_update_in_place control=%s row_type=%s value=%s pos=%s reason=%s" % (control_id, row_type, target, matched_pos, reason))
            return matched_pos
        except Exception:
            _log("selection_update_in_place_failed control=%s row_type=%s value=%s reason=%s\n%s" % (control_id, row_type, raw_value, reason, traceback.format_exc()), xbmc.LOGWARNING)
            return -1

    def _add(self, control_id, label, row_type, value="", selected=False, arrow=False, raw_value=""):
        item = xbmcgui.ListItem(label=str(label))
        item.setProperty("row_type", str(row_type))
        item.setProperty("value", str(value or ""))
        item.setProperty("selected", "1" if selected else "0")
        item.setProperty("arrow", "1" if arrow else "0")
        item.setProperty("raw_value", str(raw_value if raw_value is not None else ""))
        self.getControl(control_id).addItem(item)

    def _current_stream_label(self):
        for stream in self.streams:
            try:
                index = int((stream or {}).get("index"))
            except Exception:
                index = -1
            if index == self.current_stream_index:
                return _stream_label(stream, current=True)
        return _stream_label(self.streams[0], current=True) if self.streams else "정보 없음"

    def _current_stream(self):
        for position, stream in enumerate(self.streams or []):
            try:
                index = int((stream or {}).get("index", position))
            except Exception:
                index = position
            if index == self.current_stream_index:
                return stream if isinstance(stream, dict) else {}
        if self.streams:
            stream = self.streams[0]
            return stream if isinstance(stream, dict) else {}
        return {}

    def _stream_info_rows(self):
        stream = self._current_stream()
        width = stream.get("width") or _info_label("Player.Process(videowidth)") or 0
        height = stream.get("height") or _info_label("Player.Process(videoheight)") or 0
        try:
            width_i = int(float(width or 0))
        except Exception:
            width_i = 0
        try:
            height_i = int(float(height or 0))
        except Exception:
            height_i = 0

        resolution = ""
        if width_i > 0 and height_i > 0:
            resolution = "%d × %d · %s" % (width_i, height_i, _resolution_label(width_i, height_i))
            if height_i >= 2160 or width_i >= 3840:
                resolution += " (4K)"
            elif height_i >= 720:
                resolution += " (HD)"
        if not resolution:
            resolution = _first_value(_info_label("VideoPlayer.VideoResolution"), "정보 없음")

        codec = _first_value(
            _codec_label(stream.get("codec")) if stream.get("codec") else "",
            _info_label("VideoPlayer.VideoCodec"),
            "정보 없음",
        )

        # Kodi's live process labels are the authoritative source for the actual
        # output frame rate and decoder.  The former VideoPlayer.VideoFps and
        # VideoPlayer.VideoDecoder expressions are not valid on Kodi 21 and were
        # being displayed literally.
        fps = _format_fps(_first_value(
            _info_label("Player.Process(videofps)"),
            stream.get("framerate"), stream.get("fps"),
        )) or "정보 없음"

        cached_bitrate_mbps = _window_property("PlexKM.SeekQuick.DynamicBitrateMbps")
        if cached_bitrate_mbps:
            cached_bitrate_mbps = "%s Mbps" % _format_number(cached_bitrate_mbps, 2)
        bitrate = _format_bitrate(_first_value(
            stream.get("bitrate"), stream.get("bit_rate"),
            cached_bitrate_mbps,
            _info_label("VideoPlayer.VideoBitrate"),
        )) or "정보 없음"

        hdr = _format_hdr(_first_value(
            stream.get("hdrtype"), stream.get("hdr_type"),
            stream.get("dynamicrange"), stream.get("dynamic_range"),
            _info_label("VideoPlayer.HdrType"),
            _info_label("ListItem.HdrType"),
        ))

        decoder = _first_value(
            _info_label("Player.Process(videodecoder)"),
            stream.get("decoder"),
        )
        if decoder:
            hw = _info_label("Player.Process(videohwdecoder)")
            if _truthy(hw) and "hardware" not in decoder.lower() and "하드웨어" not in decoder:
                decoder += " · 하드웨어"

        rows = [
            ("해상도", resolution),
            ("비디오 코덱", codec),
            ("프레임 레이트", fps),
            ("비트레이트", bitrate),
            ("HDR 형식", hdr),
        ]
        # Show the decoder only when Kodi exposes a concrete runtime decoder
        # name such as ff-hevc-d3d11va.  Do not show a generic placeholder.
        if decoder:
            rows.append(("재생 디코더", decoder))
        return rows

    def _populate_main(self):
        self._clear(MAIN_LIST_ID)
        self._add(MAIN_LIST_ID, "비디오 스트림", "stream_page", self._current_stream_label(), arrow=True)
        # v1627: keep the full PKM video-settings path.  The VideoOSD cycle
        # button changes only the currently playing title; this page remains
        # available for explicit selection and saving the selected mode as the
        # default for every media item.
        self._add(MAIN_LIST_ID, "화면 모드", "mode_page", _view_mode_label(self.viewmode), arrow=True)
        self._add(
            MAIN_LIST_ID,
            "모든 항목에 기본값으로 설정",
            "save_default",
            "설정됨" if _default_matches(self.viewmode) else "",
        )

    def _populate_streams(self):
        self._clear(STREAM_LIST_ID)
        if not self.streams:
            self._add(STREAM_LIST_ID, "선택 가능한 비디오 스트림이 없습니다", "disabled")
            return
        for position, stream in enumerate(self.streams):
            try:
                index = int((stream or {}).get("index", position))
            except Exception:
                index = position
            selected = index == self.current_stream_index
            self._add(STREAM_LIST_ID, _stream_label(stream, current=selected), "video_stream", selected=selected, raw_value=index)

    def _populate_modes(self):
        self._clear(MODE_LIST_ID)
        for mode, label in VIEW_MODES:
            self._add(MODE_LIST_ID, label, "view_mode", selected=(mode == self.viewmode), raw_value=mode)

    def _populate_info(self):
        self._clear(INFO_LIST_ID)
        for label, value in self._stream_info_rows():
            self._add(INFO_LIST_ID, label, "stream_info", value=value)
        _log("video_stream_info_populated rows=%d current_stream=%s" % (
            self.getControl(INFO_LIST_ID).size(), self.current_stream_index,
        ))

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            if self.page == "main" or (self.page == "info" and self.initial_page == "info"):
                self.close()
            else:
                previous_page = self.page
                self._refresh_state()
                parent_type = "stream_page" if previous_page == "streams" else "mode_page"
                self._show_page("main", preferred_row_type=parent_type, reason="back_from_%s" % previous_page)

    def onClick(self, control_id):
        control_id = int(control_id)
        if control_id not in (MAIN_LIST_ID, STREAM_LIST_ID, MODE_LIST_ID, INFO_LIST_ID):
            return
        try:
            ctrl = self.getControl(control_id)
            clicked_pos = int(ctrl.getSelectedPosition())
            item = ctrl.getSelectedItem()
        except Exception:
            clicked_pos = 0
            item = None
        if not item:
            return
        row_type = item.getProperty("row_type") or ""
        raw_value = item.getProperty("raw_value") or ""

        if row_type == "stream_page":
            self._show_page("streams", reason="open_streams")
        elif row_type == "mode_page":
            self._show_page("modes", reason="open_modes")
        elif row_type == "save_default":
            if _confirm_default():
                _write_default_view_mode(self.viewmode)
                try:
                    item.setProperty("value", "설정됨")
                except Exception:
                    pass
            # No list reset: the focused white bar remains on the activated row.
        elif row_type == "video_stream":
            try:
                stream_index = int(raw_value)
            except Exception:
                return
            if _set_video_stream(self.player_id, stream_index):
                self.current_stream_index = stream_index
                self._update_selected_rows_in_place(
                    STREAM_LIST_ID, "video_stream", raw_value,
                    update_stream_labels=True, reason="video_stream_apply_no_rebuild",
                )
        elif row_type == "view_mode":
            mode = str(raw_value or "normal")
            if _set_view_mode(mode):
                self.viewmode = mode
                self._update_selected_rows_in_place(
                    MODE_LIST_ID, "view_mode", raw_value,
                    reason="view_mode_apply_no_rebuild",
                )
        elif row_type == "stream_info":
            # Informational menu rows are intentionally non-destructive.
            _log("video_stream_info_row_selected label=%s value=%s no_action=1" % (
                item.getLabel(), item.getProperty("value") or "",
            ))


def open_video_select():
    try:
        if not xbmc.Player().isPlayingVideo():
            return False
        window = PKMVideoSelectWindow(XML_NAME, _addon_path(), "Default", "1080i")
        window.doModal()
        del window
        return True
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False


def open_video_stream_info():
    try:
        if not xbmc.Player().isPlayingVideo():
            return False
        window = PKMVideoSelectWindow(
            XML_NAME, _addon_path(), "Default", "1080i", initial_page="info"
        )
        window.doModal()
        del window
        return True
    except Exception:
        _log("open_stream_info_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
