# -*- coding: utf-8 -*-
"""PKM library selection flow split from default.py.

This module is intentionally data/settings-flow only. It must not import
``default.py`` or Home WindowXML modules. The caller supplies every project
callback through an env dictionary so importing this module cannot trigger a
second default.py instance or change Home/Section startup order.
"""
from __future__ import absolute_import, unicode_literals

import traceback

import xbmc
import xbmcgui

try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None


def _call(env, name, *args, **kwargs):
    fn = env.get(name)
    if not callable(fn):
        raise RuntimeError("missing library selection callback: %s" % name)
    return fn(*args, **kwargs)


def _log(env, message, level=xbmc.LOGINFO):
    fn = env.get("log")
    try:
        if callable(fn):
            fn(message, level)
            return
    except Exception:
        pass
    xbmc.log("[plugin.video.km] %s" % message, level)


def _notify(env, message, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    fn = env.get("notify")
    heading = env.get("addon_name") or "Plex KM"
    try:
        if callable(fn):
            fn(message, icon=icon, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(heading, message, "", ms=ms):
            return
    except Exception:
        pass
    _log(env, "PKM_NATIVE_NOTIFICATION_SUPPRESSED heading=%s message=%s" % (str(heading or ""), str(message or "")), xbmc.LOGINFO)



def _offline_or_server_switch_pending():
    """v1382: settings/library list must not block on Plex HTTP while offline."""
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("PlexKM.PlexOffline") == "1":
            return True
        if win.getProperty("PlexKM.Home.ServerSwitchPending") == "1":
            return True
    except Exception:
        pass
    return False

def _display_library_title(value):
    """Display Plex library titles with pipe-like separators rendered safely.

    Do not delete separators and do not replace them with hyphens/spaces.
    Only vertical-line lookalike code points are normalized to ASCII '|'
    for the settings-list display so Kodi does not show missing-glyph boxes.
    """
    text = str(value or "")
    try:
        table = {
            ord("\u2223"): "|",  # DIVIDES
            ord("\u2758"): "|",  # LIGHT VERTICAL BAR
            ord("\u2759"): "|",  # MEDIUM VERTICAL BAR
            ord("\u275A"): "|",  # HEAVY VERTICAL BAR
            ord("\uFFE8"): "|",  # HALFWIDTH FORMS LIGHT VERTICAL
            ord("\uFF5C"): "|",  # FULLWIDTH VERTICAL LINE
            ord("\u2502"): "|",  # BOX DRAWINGS LIGHT VERTICAL
            ord("\u2503"): "|",  # BOX DRAWINGS HEAVY VERTICAL
            ord("\u23AA"): "|",  # CURLY BRACKET EXTENSION
            ord("\u23D0"): "|",  # VERTICAL LINE EXTENSION
            ord("\u2016"): "|",  # DOUBLE VERTICAL LINE
            ord("\u01C0"): "|",  # LATIN LETTER DENTAL CLICK
            ord("\u00A6"): "|",  # BROKEN BAR
            ord("\u4E28"): "|",  # CJK UNIFIED IDEOGRAPH vertical stroke
            ord("\u3163"): "|",  # HANGUL LETTER I
        }
        text = text.translate(table)
    except Exception:
        pass
    return text


def library_selection_rows(env, live_required=False):
    """Build labels/preselect rows for the PKM library checkbox dialog."""
    try:
        if not _call(env, "clean_server_url") or not _call(env, "plex_token"):
            _notify(env, "Plex 서버 설정이 먼저 필요합니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
            return None, [], []
        # v1382: When Plex is already known offline or server-switch-pending,
        # never issue /library/sections from the settings dialog.  The old
        # refresh=True path used a long Plex timeout and made PKM 설정 feel
        # frozen exactly when the user needed to fix the connection.
        # v1688: plex.tv/link authentication may open the initial chooser only
        # after the newly saved token has successfully reached the configured PMS.
        # Never satisfy that gate from cached sections or a stale PlexOffline flag.
        offline_fast = _offline_or_server_switch_pending() and not bool(live_required)
        if offline_fast:
            _log(env, "LIBRARY_SELECTION_ROWS_OFFLINE_FAST_CACHE reason=v1382_no_live_refresh", xbmc.LOGWARNING)
        if live_required:
            _log(env, "TOKEN_AUTH_PMS_SECTIONS_LIVE_BEGIN_V1688", xbmc.LOGINFO)
        sections = _call(env, "fetch_sections", refresh=True if live_required else (False if offline_fast else True), selected_only=False)
        all_sections = _call(env, "apply_section_order", sections, save_merged=not offline_fast)
        if live_required:
            _log(env, "TOKEN_AUTH_PMS_SECTIONS_LIVE_OK_V1688 count=%d" % len(all_sections or []), xbmc.LOGINFO)
        if not all_sections:
            if live_required:
                _notify(env, "토큰 인증은 완료됐지만 Plex 서버의 라이브러리를 확인하지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4200)
            elif offline_fast:
                _show_notice(env, "Plex 오프라인", "Plex 서버에 연결할 수 없습니다", "연결 설정에서 주소를 수정해주세요", ms=3200)
            else:
                _notify(env, "Plex 라이브러리를 찾지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
            return None, [], []
        selected, configured = _call(env, "selected_sections_state")
        selected_set = set(selected if configured else [])
        labels = []
        preselect = []
        for i, section in enumerate(all_sections):
            sid = str(section.get("section_id", ""))
            title = _display_library_title(section.get("title", "") or sid)
            stype = section.get("section_type", "")
            labels.append("%s  (%s / id=%s)" % (title, stype, sid))
            if sid in selected_set:
                preselect.append(i)
        return all_sections, labels, preselect
    except Exception:
        _log(env, "LIBRARY_SELECTION_ROWS_FAILED\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
        _notify(env, "라이브러리 목록을 만들지 못했습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=3500)
        return None, [], []


def _section_names(all_sections, ids):
    idset = set(str(x) for x in (ids or []) if str(x))
    names = []
    for section in all_sections or []:
        sid = str(section.get("section_id", ""))
        if sid in idset:
            names.append(_display_library_title(section.get("title", "") or sid))
    return names


def _show_notice(env, title, line1="", line2="", ms=3000):
    fn = env.get("show_notice")
    try:
        if callable(fn):
            fn(title, line1, line2, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice(title or (env.get("addon_name") or "Plex KM"), line1, line2, ms=ms):
            return
    except Exception:
        pass
    _notify(env, "%s %s" % (line1 or "", line2 or ""), icon=xbmcgui.NOTIFICATION_INFO, ms=ms)


def _open_message(env, title, message, ok_label="확인"):
    fn = env.get("open_message")
    try:
        if callable(fn):
            return fn(title, message, ok_label=ok_label)
    except Exception:
        pass
    _show_notice(env, title, message, "", ms=3200)
    return True


def apply_library_selection(env, all_sections, chosen, force=False, auth_initial=False):
    """Persist selected library ids and run selection/sync side effects.

    v637 root-cause fix: unselecting a library must not delete its local cache.
    The selected_sections state is the source of truth for visibility; cached
    rows stay available so re-enabling a large library can use the fast verifier
    instead of rebuilding tens of thousands of rows from scratch.
    """
    all_sections = list(all_sections or [])
    new_ids = [str(all_sections[int(i)].get("section_id", "")) for i in (chosen or []) if 0 <= int(i) < len(all_sections)]
    if auth_initial:
        if not new_ids:
            _log(env, "TOKEN_AUTH_LIBRARY_SELECTION_REQUIRED_V1688", xbmc.LOGINFO)
            _notify(env, "사용할 라이브러리를 1개 이상 선택하세요", icon=xbmcgui.NOTIFICATION_WARNING, ms=3000)
            return False
        # The initial authenticated flow is intentionally transactional: save the
        # explicit choice, synchronise exactly those libraries, and report success
        # only after the normal sync path marks initial_sync_done.
        _call(env, "save_selected_sections", new_ids)
        _call(env, "set_initial_sync_done", False)
        _log(env, "TOKEN_AUTH_LIBRARY_SELECTION_SAVED_V1688 selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        try:
            _call(
                env,
                "sync_all_sections",
                show_prompt=False,
                show_progress=True,
                mark_auto_sync=True,
                section_ids=new_ids,
                progress_title="초기 라이브러리 싱크",
                completion_confirm=True,
            )
        except Exception:
            _log(env, "TOKEN_AUTH_INITIAL_SYNC_FAILED_V1688\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            _notify(env, "선택한 라이브러리의 초기 싱크에 실패했습니다", icon=xbmcgui.NOTIFICATION_ERROR, ms=4200)
            return False
        if not bool(_call(env, "initial_sync_done")):
            _log(env, "TOKEN_AUTH_INITIAL_SYNC_INCOMPLETE_V1688 selected=%s" % ",".join(new_ids), xbmc.LOGWARNING)
            _notify(env, "초기 싱크가 완료되지 않았습니다", icon=xbmcgui.NOTIFICATION_WARNING, ms=4200)
            return False
        _call(env, "signal_home_data_refresh", reason="token_auth_initial_sync_v1688")
        _log(env, "TOKEN_AUTH_INITIAL_FLOW_COMPLETE_V1688 selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        return True
    if not new_ids:
        ok = _call(
            env,
            "open_confirm",
            env.get("addon_name") or "Plex KM",
            "선택된 라이브러리가 없습니다.\nPKM 홈/검색/동기화 대상이 비게 됩니다.\n그대로 저장할까요?",
            yes_label="저장",
            no_label="취소",
        )
        if not ok:
            return False
    # v1819: the checkbox page is only a proposed selection until any newly
    # added libraries pass the follow-up Sync/Later decision.  Keep the prior
    # committed selection so choosing "Later" cannot leave an unsynced library
    # checked on the next visit.
    old_selected_v1819, old_configured_v1819 = _call(env, "selected_sections_state")
    old_selected_v1819 = [str(x) for x in (old_selected_v1819 or []) if str(x)]
    added, removed = _call(env, "save_selected_sections", new_ids)
    _log(env, "LIBRARY_SELECTION_CACHE_RETAIN selected=%s added=%s removed=%s" % (",".join(new_ids), ",".join(added), ",".join(removed)), xbmc.LOGINFO)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    if added:
        added_names = _section_names(all_sections, added)
        cached_added = []
        uncached_added = []
        for sid in added:
            try:
                if int(_call(env, "local_section_count", sid) or 0) > 0:
                    cached_added.append(sid)
                else:
                    uncached_added.append(sid)
            except Exception:
                uncached_added.append(sid)
        prearmed_v1747 = {"progress": None}
        _log(env, "LIBRARY_SELECTION_SYNC_CLASSIFY_V1747 added=%s cached=%s uncached=%s" % (
            ",".join(added), ",".join(cached_added), ",".join(uncached_added)
        ), xbmc.LOGINFO)

        def _prepare_added_sync_v1747():
            # v1747: cached verification also opens the progress window.  Prearm
            # it while the confirmation dialog is still visible so the in-place
            # library selection page can never become the top frame.
            progress = _call(
                env,
                "prearm_sync_progress",
                "추가 라이브러리 싱크",
                "싱크 준비 중...",
            )
            if progress is None:
                _log(env, "LIBRARY_SELECTION_SYNC_PREARM_FAILED_V1747 added=%s cached=%s uncached=%s" % (
                    ",".join(added), ",".join(cached_added), ",".join(uncached_added)
                ), xbmc.LOGWARNING)
                return False
            prearmed_v1747["progress"] = progress
            _log(env, "LIBRARY_SELECTION_SYNC_PREARM_READY_V1747 added=%s cached=%s uncached=%s" % (
                ",".join(added), ",".join(cached_added), ",".join(uncached_added)
            ), xbmc.LOGINFO)
            return True

        ok = force or _call(
            env,
            "open_confirm",
            env.get("addon_name") or "Plex KM",
            "추가된 라이브러리가 있습니다.\n기존 캐시가 있으면 빠른 확인만 수행합니다.\n지금 확인/싱크할까요?",
            yes_label="싱크",
            no_label="나중에",
            yes_prepare=_prepare_added_sync_v1747,
            default_focus="yes",
        )
        if not ok:
            # v1819: "Later" means do not activate the newly added libraries.
            # Preserve deliberate removals from this edit, but restore every
            # newly added id to unchecked.  A library becomes checked only after
            # the user accepts the sync/verification path.
            added_set_v1819 = set(str(x) for x in (added or []) if str(x))
            committed_ids_v1819 = [str(x) for x in new_ids if str(x) not in added_set_v1819]
            _call(env, "save_selected_sections", committed_ids_v1819)
            try:
                xbmc.executebuiltin("Container.Refresh")
            except Exception:
                pass
            _log(env, "LIBRARY_SELECTION_ADDED_ROLLBACK_V1819 reason=sync_later added=%s committed=%s previous=%s" % (
                ",".join(added), ",".join(committed_ids_v1819), ",".join(old_selected_v1819)
            ), xbmc.LOGINFO)
            return True
        if ok:
            # v1754: keep the library-selection page fully covered from the
            # progress handoff through the completion modal.  The modal must
            # appear as the next visible state after sync, never after a flash
            # of the selection page.
            try:
                xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
            except Exception:
                pass
            _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=added", xbmc.LOGINFO)
            progress_v1747 = prearmed_v1747.get("progress")
            if uncached_added:
                _call(env, "set_initial_sync_done", False)
                _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=uncached_full progress_reused=%d sections=%s" % (
                    1 if progress_v1747 is not None else 0, ",".join(uncached_added)
                ), xbmc.LOGINFO)
                _call(
                    env,
                    "sync_all_sections",
                    show_prompt=False,
                    show_progress=True,
                    mark_auto_sync=True,
                    section_ids=uncached_added,
                    progress_title="추가 라이브러리 싱크",
                    precreated_progress=progress_v1747,
                )
                # The full-sync path owns and closes the prearmed window.  Any
                # already-cached sections are verified quietly in the same
                # transaction to avoid opening a second progress dialog.
                if cached_added:
                    _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=cached_verify_quiet_after_full sections=%s" % ",".join(cached_added), xbmc.LOGINFO)
                    _call(env, "verify_selected_library_cache", precreated_progress=None, show_progress=False)
            elif cached_added:
                _call(env, "set_initial_sync_done", True)
                _log(env, "LIBRARY_SELECTION_SYNC_EXECUTE_V1747 mode=cached_verify progress_reused=%d sections=%s" % (
                    1 if progress_v1747 is not None else 0, ",".join(cached_added)
                ), xbmc.LOGINFO)
                _call(env, "verify_selected_library_cache", precreated_progress=progress_v1747, show_progress=True)
            # v1753: a completed library operation must stop at an explicit
            # completion boundary.  The user confirms the finished result, and
            # only then does the settings stack close and return to Home.
            added_line_v1753 = ", ".join(added_names[:2]) if added_names else ", ".join(added[:2])
            complete_msg_v1753 = "라이브러리 추가 및 싱크가 완료되었습니다."
            if added_line_v1753:
                complete_msg_v1753 += "\n추가: %s" % added_line_v1753
            complete_msg_v1753 += "\n확인을 누르면 홈으로 이동합니다."
            _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V1753 action=added sections=%s" % ",".join(added), xbmc.LOGINFO)
            _open_message(env, "PKM 라이브러리 완료", complete_msg_v1753, ok_label="확인")
            _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V1753 action=added sections=%s" % ",".join(added), xbmc.LOGINFO)
            try:
                _w_v1754 = xbmcgui.Window(10000)
                _w_v1754.setProperty("PlexKM.Home.LibraryApplyBusyV1754", "1")
                _w_v1754.setProperty("PlexKM.Home.LibraryApplyTextV1754", "라이브러리 반영 중 (10%)")
                _w_v1754.clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
            except Exception:
                pass
            _log(env, "LIBRARY_HOME_APPLY_SPINNER_ARM_V1754 action=%s" % "added", xbmc.LOGINFO)
            _call(env, "signal_home_data_refresh", reason="library_added_sync")
            _log(env, "LIBRARY_SELECTION_SYNC_COMPLETE_OPEN_HOME_V1753 added=%s" % ",".join(added), xbmc.LOGINFO)
            return "open_home"
    elif removed:
        _call(env, "set_initial_sync_done", True)
        removed_names = _section_names(all_sections, removed)
        removed_line_v1753 = ", ".join(removed_names[:2]) if removed_names else ", ".join(removed[:2])
        msg = "라이브러리 해제가 완료되었습니다.\n캐시는 유지되어 재추가가 빠릅니다."
        if removed_line_v1753:
            msg += "\n제거: %s" % removed_line_v1753
        msg += "\n확인을 누르면 홈으로 이동합니다."
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
        except Exception:
            pass
        _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=removed", xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V1753 action=removed sections=%s" % ",".join(removed), xbmc.LOGINFO)
        _open_message(env, "PKM 라이브러리 완료", msg, ok_label="확인")
        _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V1753 action=removed sections=%s" % ",".join(removed), xbmc.LOGINFO)
        try:
            _w_v1754 = xbmcgui.Window(10000)
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyBusyV1754", "1")
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyTextV1754", "라이브러리 반영 중 (10%)")
            _w_v1754.clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
        except Exception:
            pass
        _log(env, "LIBRARY_HOME_APPLY_SPINNER_ARM_V1754 action=removed", xbmc.LOGINFO)
        _call(env, "signal_home_data_refresh", reason="library_removed")
        _log(env, "LIBRARY_SELECTION_REMOVE_COMPLETE_OPEN_HOME_V1753 removed=%s" % ",".join(removed), xbmc.LOGINFO)
        return "open_home"
    elif force:
        _call(env, "sync_all_sections", show_prompt=False, show_progress=True, mark_auto_sync=True, section_ids=new_ids, progress_title="선택 라이브러리 재싱크")
        selected_names_v1753 = _section_names(all_sections, new_ids)
        selected_line_v1753 = ", ".join(selected_names_v1753[:2]) if selected_names_v1753 else ", ".join(new_ids[:2])
        msg_v1753 = "선택 라이브러리 재싱크가 완료되었습니다."
        if selected_line_v1753:
            msg_v1753 += "\n대상: %s" % selected_line_v1753
        msg_v1753 += "\n확인을 누르면 홈으로 이동합니다."
        try:
            xbmcgui.Window(10000).setProperty("PlexKM.Settings.LibraryCompletionBackdropV1754", "1")
        except Exception:
            pass
        _log(env, "LIBRARY_COMPLETION_BACKDROP_ARM_V1754 action=resync", xbmc.LOGINFO)
        _log(env, "LIBRARY_SELECTION_COMPLETION_MODAL_BEGIN_V1753 action=resync sections=%s" % ",".join(new_ids), xbmc.LOGINFO)
        _open_message(env, "PKM 라이브러리 완료", msg_v1753, ok_label="확인")
        _log(env, "LIBRARY_SELECTION_COMPLETION_CONFIRMED_V1753 action=resync sections=%s" % ",".join(new_ids), xbmc.LOGINFO)
        try:
            _w_v1754 = xbmcgui.Window(10000)
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyBusyV1754", "1")
            _w_v1754.setProperty("PlexKM.Home.LibraryApplyTextV1754", "라이브러리 반영 중 (10%)")
            _w_v1754.clearProperty("PlexKM.Settings.LibraryCompletionBackdropV1754")
        except Exception:
            pass
        _log(env, "LIBRARY_HOME_APPLY_SPINNER_ARM_V1754 action=resync", xbmc.LOGINFO)
        _call(env, "signal_home_data_refresh", reason="library_selected_resync")
        _log(env, "LIBRARY_SELECTION_RESYNC_COMPLETE_OPEN_HOME_V1753 selected=%s" % ",".join(new_ids), xbmc.LOGINFO)
        return "open_home"
    else:
        _open_message(env, "PKM 라이브러리 선택", "변경된 라이브러리가 없습니다.", ok_label="확인")
    return True


def choose_libraries_dialog(env, force=False):
    all_sections, labels, preselect = library_selection_rows(env)
    if not all_sections:
        return False
    chosen = _call(env, "open_list", "PKM 라이브러리 선택", labels, multiselect=True, preselect=preselect)
    if chosen is None:
        _log(env, "LIBRARY_SELECTION_CANCEL", xbmc.LOGINFO)
        return False
    return apply_library_selection(env, all_sections, chosen, force=force)
