# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""R308: enter the SubDL API key from a phone (QR -> paste -> save).

Reuses the YouTube key server (kind="subdl"): the TV shows a QR for
http://<lan-ip>:<port>/<token>, the phone opens a page, pastes the key and the
key is verified against SubDL before it is stored in pkm_subdl_api_key.
"""

import os
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
CLOSE_ID = 10
QR_ID = 20


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[PlexKM] SUBDL QR %s" % msg, level)
    except Exception:
        pass


def clean_subdl_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    ok = all(ch.isalnum() or ch in "-_" for ch in key)
    if len(key) < 20 or len(key) > 120 or not ok:
        return "", "SubDL API 키 형식이 아닙니다 (subdl.com > API 페이지의 키를 그대로 붙여넣으세요)"
    return key, ""


def verify_key(key):
    """(ok, message). Network errors are not treated as a bad key."""
    try:
        from resources.lib import pkm_subdl
        pkm_subdl._get_json({"api_key": key, "film_name": "Parasite", "type": "movie",
                             "languages": "KO", "subs_per_page": 1}, timeout=12)
        return True, "SubDL 키를 저장했습니다"
    except Exception as exc:
        text = str(exc)
        if "401" in text or "403" in text or "400" in text:
            return False, "SubDL이 이 키를 받아주지 않습니다. 키를 다시 확인하세요"
        return True, "키를 저장했습니다 (SubDL 확인은 건너뜀: 네트워크)"


def page_html(msg_html=""):
    return (
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'><title>PlexKM SubDL 키</title>"
        "<style>body{margin:0;background:#15171a;color:#f1f1f1;font:17px/1.6 -apple-system,'Apple SD Gothic Neo','Noto Sans KR',sans-serif}"
        "main{max-width:560px;margin:0 auto;padding:28px 18px}h1{font-size:22px}"
        "textarea{width:100%;box-sizing:border-box;height:96px;border-radius:12px;border:1px solid #444;background:#23272c;color:#fff;padding:12px;font-size:16px}"
        "button{margin-top:14px;width:100%;padding:15px;border:0;border-radius:12px;background:#e5b400;color:#111;font-size:18px;font-weight:700}"
        ".msg{margin:14px 0;padding:12px 14px;border-radius:10px}.ok{background:#12351f;color:#8be0a4}.bad{background:#401a1a;color:#ff9c9c}"
        "a{color:#e5b400}</style></head><body><main>"
        "<h1>SubDL API 키 입력</h1>" + (msg_html or "") +
        "<ol style='padding-left:20px'>"
        "<li>아래 <b>[SubDL 열기]</b>를 누르세요. 로그인 화면이 나오면 로그인하세요(계정이 없으면 Register로 무료 가입). 로그인하면 API 키 페이지가 바로 열립니다.<br>"
        "<a href='https://subdl.com/panel/login?page=/panel/api' target='_blank' style='display:inline-block;margin:8px 0;padding:10px 16px;border-radius:10px;background:#23272c;font-weight:700'>SubDL 열기 (API 키 페이지)</a></li>"
        "<li>열린 페이지의 <b>API Key</b> 화면에서 <b>Copy API Code</b> 버튼을 누르면 키가 복사됩니다.</li>"
        "<li>이 화면(브라우저 탭)으로 돌아와 아래 입력칸을 길게 눌러 <b>붙여넣기</b>하고 <b>저장</b>을 누르세요.</li>"
        "</ol><p style='color:#a3a8b3;font-size:15px'>저장하면 TV에 바로 적용됩니다. TV에서 키를 직접 칠 필요가 없습니다.</p>"
        "<form method='post'><textarea name='key' placeholder='subdl_...' autocomplete='off' autocapitalize='off' spellcheck='false'></textarea>"
        "<button type='submit'>저장</button></form></main></body></html>"
    )


def page_html_yt(msg_html=""):
    return (
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'><title>PlexKM YouTube 키</title>"
        "<style>body{margin:0;background:#15171a;color:#f1f1f1;font:17px/1.6 -apple-system,'Apple SD Gothic Neo','Noto Sans KR',sans-serif}"
        "main{max-width:560px;margin:0 auto;padding:28px 18px}h1{font-size:22px}"
        "textarea{width:100%;box-sizing:border-box;height:96px;border-radius:12px;border:1px solid #444;background:#23272c;color:#fff;padding:12px;font-size:16px}"
        "button{margin-top:14px;width:100%;padding:15px;border:0;border-radius:12px;background:#e5b400;color:#111;font-size:18px;font-weight:700}"
        ".msg{margin:14px 0;padding:12px 14px;border-radius:10px}.ok{background:#12351f;color:#8be0a4}.bad{background:#401a1a;color:#ff9c9c}"
        "</style></head><body><main>"
        "<h1>YouTube API 키 입력</h1>" + (msg_html or "") +
        "<p>구글 콘솔에서 복사한 API 키를 아래 칸에 길게 눌러 <b>붙여넣기</b>하고 <b>저장</b>을 누르세요.</p>"
        "<form method='post'><textarea name='key' placeholder='AIza...' autocomplete='off' autocapitalize='off' spellcheck='false'></textarea>"
        "<button type='submit'>저장</button></form>"
        "<p style='color:#a3a8b3;font-size:15px'>저장하면 TV가 키를 확인하고 바로 적용합니다.</p></main></body></html>"
    )


def _profile_dir():
    p = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


class SubdlQrDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.pop("url", "")
        self.texts = kwargs.pop("texts", None) or ("PlexKM 자막 · SubDL", "SubDL API 키를 휴대폰으로 입력하세요", "Copy API Code 복사 → 붙여넣고 저장")
        self.qr = kwargs.pop("qr", "")
        super(SubdlQrDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty("PKM.SubdlQR.URL", self.url)
        self.setProperty("PKM.SubdlQR.Head", self.texts[0])
        self.setProperty("PKM.SubdlQR.Title", self.texts[1])
        self.setProperty("PKM.SubdlQR.Step2", self.texts[2])
        self.setProperty("PKM.SubdlQR.Msg", "휴대폰이 TV와 같은 Wi-Fi여야 합니다")
        self.setProperty("PKM.SubdlQR.Done", "")
        if self.qr and os.path.exists(self.qr):
            try:
                self.getControl(QR_ID).setImage(self.qr, False)
            except Exception:
                pass
        try:
            self.setFocusId(CLOSE_ID)
        except Exception:
            pass

    def say(self, text, done=False):
        try:
            self.setProperty("PKM.SubdlQR.Msg", text)
            if done:
                self.setProperty("PKM.SubdlQR.Done", "1")
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == CLOSE_ID:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


YT_STEPS = [
    ("시작", "API 키 생성은 무료입니다.[CR][CR]이 화면의 안내를 보면서 휴대폰 브라우저에서 직접 만듭니다. 마지막 단계에서만 만든 키를 보냅니다.[CR][CR]먼저 휴대폰 브라우저에서 구글에 로그인하세요. 이미 로그인돼 있으면 그대로 두세요.[CR][CR][COLOR FF7FD6A0]▶ 로그인이 끝났으면 아래 [다음]을 누르세요[/COLOR]"),
    ("구글 클라우드 콘솔 열기", "휴대폰 브라우저 주소창에 console.cloud.google.com 을 입력해 엽니다.[CR]새 계정이면 처음에 약관 화면이 나옵니다. 국가 [대한민국] 선택, 약관 체크 → [동의 및 계속하기][CR]구글 광고(예: '$300 무료 크레딧')가 나오면 [무료 체험]이나 [무료로 시작하기]는 누르지 말고 위쪽의 [닫기]를 누릅니다. 광고는 키 발급과 상관없습니다.[CR][CR][COLOR FF7FD6A0]▶ 광고를 닫았으면 아래 [다음]을 누르세요[/COLOR]"),
    ("프로젝트 메뉴 열기", "휴대폰 콘솔 왼쪽 위의 삼선 메뉴(☰)를 누릅니다.[CR]열린 메뉴 맨 위에 [프로젝트 선택] 버튼이 있습니다. 그 버튼을 누릅니다.[CR][CR][COLOR FF7FD6A0]▶ [프로젝트 선택] 창이 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("새 프로젝트 누르기", "[프로젝트 선택] 창이 열렸습니다. 새 계정은 목록에 '조직 없음'만 보이는 것이 정상입니다.[CR]창 오른쪽 위의 파란 [새 프로젝트]를 누릅니다.[CR][CR]이미 만들어 둔 프로젝트가 있으면 목록에서 골라 그대로 써도 됩니다.[CR][CR][COLOR FF7FD6A0]▶ [새 프로젝트] 화면이 열렸으면 아래 [다음]을 누르세요.[CR]기존 프로젝트를 골랐으면 [다음]을 두 번 누르세요[/COLOR]"),
    ("새 프로젝트 화면", "휴대폰 [새 프로젝트] 화면에서:[CR]- 프로젝트 이름: 알아볼 이름을 넣습니다 (예: plexkm-youtube, 다른 이름도 됩니다)[CR]- 위쪽 노란 경고와 [Manage Quotas]는 무시하세요. 더 만들 수 있다는 안내일 뿐입니다[CR]- 상위 리소스 '조직 없음'은 그대로 둡니다[CR]- 파란 [만들기]를 누릅니다[CR][CR][COLOR FF7FD6A0]▶ [만들기]를 눌렀으면 아래 [다음]을 누르세요. 구글 광고 화면이 떠도 정상입니다[/COLOR]"),
    ("만든 프로젝트 선택하기", "[만들기] 뒤에 구글 광고 화면이 떠도 정상입니다. [무료 체험]은 누르지 마세요.[CR]1. 위쪽 종 모양 알림을 누릅니다.[CR]2. '프로젝트 (내가 정한 이름) 만들기' 알림 아래의 파란 [프로젝트 선택]을 누릅니다.[CR]알림이 비어 있으면 프로젝트가 안 만들어진 것입니다. 다른 구글 계정으로 로그인해 처음부터 다시 해 보세요.[CR][CR][COLOR FF7FD6A0]▶ [대시보드] 화면이 열렸습니다. 'Go to Cloud Hub' 안내는 무시하세요. 아래 [프로젝트 정보]에 내 프로젝트 이름이 보이면 [다음]을 누르세요[/COLOR]"),
    ("API 검색하기", "[대시보드] 화면 위쪽의 돋보기(검색)를 누르고 youtube 를 입력합니다.[CR]검색 결과 맨 위의 'YouTube Data API v3' (Marketplace 제품)를 누릅니다. 'YouTube Reporting API'나 'AI Applications'가 아닙니다.[CR][CR][COLOR FF7FD6A0]▶ [제품 세부정보] 화면이 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("YouTube Data API v3 켜기", "열린 [제품 세부정보] 화면에서 빨간 유튜브 로고 아래의 파란 [사용] 버튼을 누릅니다. 옆의 [API 사용해 보기]는 누르지 않습니다.[CR]누르면 화면이 잠시 로딩된 뒤 바뀝니다.[CR][CR][COLOR FF7FD6A0]▶ [사용]을 눌렀으면 화면이 바뀔 때까지 기다린 뒤 아래 [다음]을 누르세요[/COLOR]"),
    ("사용자 인증 정보 만들기 누르기", "화면이 [API/서비스 세부정보]로 바뀌었습니다. 아래쪽 상태에 [사용 설정됨]이 보이면 API가 켜진 것입니다.[CR]위쪽 파란 상자의 [사용자 인증 정보 만들기]를 누릅니다.[CR][CR][COLOR FF7FD6A0]▶ [사용자 인증 정보 만들기]를 눌렀으면 아래 [다음]을 누르세요[/COLOR]"),
    ("API 키 만들기", "앞 화면의 [사용자 인증 정보 만들기]를 누르면 '사용자 인증 정보 만들기' 화면이 열립니다. 1번 [사용자 인증 정보 유형]에서:[CR]- API 선택: YouTube Data API v3 가 들어 있으면 그대로 둡니다[CR]- 액세스할 데이터: [공개 데이터]를 고릅니다. [사용자 데이터]는 고르지 않습니다[CR]- 그 아래 [다음]을 누릅니다[CR][CR][이미 보유 중인 API 키 목록] 창이 열리면 창 아래 [만들기]를 누릅니다. 키가 하나 더 생겨도 상관없습니다.[CR][CR][COLOR FF7FD6A0]▶ 2번 [내 사용자 인증 정보]에 [API 키]와 키 입력칸이 보이면 아래 [다음]을 누르세요[/COLOR]"),
    ("키 복사하기", "1. 2번 [내 사용자 인증 정보] 화면의 [API 키] 아래 입력칸(AIza로 시작하는 긴 글자) 오른쪽 복사 아이콘(겹친 네모)을 눌러 키를 복사합니다. 복사한 키는 마지막 단계에서 붙여넣습니다.[CR]2. 맨 아래 파란 [완료]를 누릅니다[CR][CR]노란 경고의 [Restrict key]는 PlexKM에 필요 없습니다. [COLOR FFFF6E6E]누르지 말고 무시하세요.[/COLOR][CR][CR][COLOR FF7FD6A0]▶ 키를 복사하고 [완료]를 눌렀으면 아래 [다음]을 누르세요[/COLOR]"),
    ("완료 후 화면", "[완료]를 누르면 YouTube Data API v3 화면([사용 설정됨])으로 돌아옵니다. 이 화면이 보이면 구글 쪽 작업은 모두 끝난 것입니다.[CR]이 화면에서는 더 누를 것이 없습니다. 복사한 키는 휴대폰에 들어 있으니 다른 글자를 복사하지 마세요.[CR][CR]이제 키를 보내겠습니다. 아래 [다음]을 눌러 주세요.[CR][CR]키가 복사되지 않았거나 잊었으면 왼쪽 위 ☰ → [API 및 서비스] → [사용자 인증 정보]에서 [API 키]의 [키 표시]를 눌러 다시 복사합니다.[CR][CR][COLOR FF7FD6A0]▶ 아래 [다음]을 누르세요[/COLOR]"),
    ("키 보내기", "1. 휴대폰 카메라로 오른쪽 QR을 스캔하고 나오는 주소를 엽니다[CR]2. 열린 페이지의 키 입력칸을 길게 눌러 [붙여넣기]를 선택합니다[CR]3. [저장]을 누릅니다[CR][CR]키가 비어 있으면 구글 화면으로 돌아가 키를 다시 복사한 뒤 붙여넣습니다. 방법은 11단계에 있습니다.[CR][CR]저장하면 이어서 [로그인 연결] 안내가 자동으로 열립니다. 7일마다 풀리지 않게 하는 마지막 작업입니다.[CR][CR][COLOR FF7FD6A0]▶ 키를 이미 저장했다면 아래 [다음]을 눌러 로그인 연결을 이어가세요[/COLOR]"),
]


_BRAND_STEPS = [
    ('브랜딩 주소 입력', '돋보기를 누르고 브랜딩 을 입력합니다. (그림처럼 Google 인증 만 쳐도 보입니다)[CR]결과에서 [브랜딩] (제품 페이지 · Google 인증 플랫폼)을 눌러 엽니다.[CR]아래 [앱 도메인]에서:[CR]- 애플리케이션 홈페이지: https://plexkm.github.io/[CR]- 개인정보처리방침 링크: https://plexkm.github.io/privacy.html[CR]- 서비스 약관 링크와 앱 로고는 비워 둡니다[CR][CR][CR][COLOR FF7FD6A0]▶ 주소를 입력했으면 아래 [다음]을 누르세요[/COLOR]'),
    ('승인된 도메인 추가', '주소를 넣으면 [승인된 도메인] 아래에 빨간 글씨 [누락된 도메인: plexkm.github.io]가 나옵니다. 정상이며 추가하라는 뜻입니다.[CR]1. 그 아래 [+ 도메인 추가]를 누르고 칸에 plexkm.github.io 를 넣습니다[CR]2. 아래 [개발자 연락처 정보]의 이메일 칸에는 본인 메일 주소를 넣습니다. 이미 내 메일이 들어 있으면 그대로 둡니다[CR]3. 맨 아래 파란 [저장]을 누릅니다[CR]아래에 [브랜딩 변경사항이 저장되었습니다.] 알림이 나오면 되고 빨간 글씨는 사라집니다.[CR][CR][COLOR FF7FD6A0]▶ [저장]이 끝났으면 아래 [다음]을 누르세요[/COLOR]'),
]

_PUBLISH_STEP = ("프로덕션으로 게시", "1. 휴대폰 콘솔 돋보기를 누르고 대상 을 입력합니다. 맨 위 [대상] (제품 페이지 · Google 인증 플랫폼)을 누릅니다.[CR]2. [게시 상태]가 [테스트 중]이면 바로 아래 [앱 게시]를 누릅니다.[CR]개인용은 구글 심사가 필요 없습니다. 프로덕션으로 바꾸면 7일마다 연결이 풀리지 않습니다.[CR][CR][COLOR FF7FD6A0]▶ [앱 게시]를 눌러 확인 창이 나오면 아래 [다음]을 누르세요[/COLOR]")
_PUBLISH_STEP2 = ("프로덕션 확인", "[프로덕션으로 푸시하시겠어요?] 창이 나오면 오른쪽 [확인]을 누릅니다. [취소]가 아닙니다.[CR]게시 상태가 [프로덕션 단계]로 바뀌고 그 아래 버튼이 [테스트로 돌아가기]로 바뀌면 끝입니다.[CR][COLOR FFFF6E6E][테스트로 돌아가기]는 누르지 마세요.[/COLOR][CR][CR]다음 25단계에서 갑니다: 돋보기에 클라이언트 를 입력해 [클라이언트] 화면을 엽니다.[CR][CR][COLOR FF7FD6A0]▶ 게시 상태가 [프로덕션 단계]로 바뀌었으면 아래 [다음]을 누르세요[/COLOR]")

OAUTH_STEPS = [
    ("시작", "방금 저장한 키로 검색은 됩니다. 이제 내 유튜브 구독 채널과 로그인 기능을 7일마다 풀리지 않게 연결합니다. 읽기 전용이고 무료입니다.[CR][CR]연결을 한 번만 만들고 프로덕션 게시까지 함께 합니다. 약 15분 걸립니다. 지금 하기 싫으면 오른쪽 위 [닫기]를 누르세요. 나중에 PlexKM 설정에서 할 수 있습니다.[CR][CR]키를 만들 때 쓴 구글 계정과 프로젝트를 그대로 씁니다.[CR][CR][COLOR FF7FD6A0]▶ 준비가 됐으면 아래 [다음]을 누르세요[/COLOR]"),
    ("프로젝트 확인", "휴대폰 구글 클라우드 콘솔 왼쪽 위 ☰ 를 누릅니다.[CR]메뉴 맨 위 노란 테두리 칸에 선택된 프로젝트 이름이 보입니다. 이 칸을 누릅니다. (그림은 예시이며 이름은 plexkm-youtube)[CR][CR][COLOR FF7FD6A0]▶ [프로젝트 선택] 창이 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("프로젝트 고르기", "[프로젝트 선택] 창에서 키를 만들 때 만든 내 프로젝트 이름 옆에 파란 체크 ✓가 있으면 이미 선택된 것입니다. 아래 [취소]를 눌러 창을 닫습니다.[CR]체크가 없거나 다른 프로젝트에 있으면 내 프로젝트 이름을 눌러 선택합니다.[CR]여러 개가 보여도 키를 만든 프로젝트 하나만 고르면 됩니다.[CR][CR][COLOR FF7FD6A0]▶ 내 프로젝트가 선택됐으면 아래 [다음]을 누르세요[/COLOR]"),
    ("Google 인증 플랫폼 열기", "휴대폰 콘솔 위쪽 돋보기를 누르고 입력칸에 Google 인증 플랫폼 이라고 입력합니다.[CR]검색 결과 맨 위 [Google 인증 플랫폼] (제품 · OAuth 구성 및 사용자 인증 정보)를 누릅니다. 문서나 라이브러리 항목이 아닙니다.[CR][CR][COLOR FF7FD6A0]▶ [OAuth 개요] 화면이 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("시작하기 누르기", "'Google 인증 플랫폼이 아직 구성되지 않음' 이라고 나오면 가운데 파란 [시작하기]를 누릅니다.[CR]이미 만들어져 있어 다른 화면(클라이언트, 대상 같은 메뉴)이 보이면 이 단계는 건너뜁니다.[CR][CR][COLOR FF7FD6A0]▶ [시작하기]를 눌렀으면 아래 [다음]을 누르세요[/COLOR]"),
    ('앱 정보 · 대상 · 연락처', '[프로젝트 구성] 화면에서 위에서부터 순서대로 입력하고, 칸마다 [다음]을 누릅니다.[CR]1. 앱 정보: 앱 이름은 plexkmyoutube 처럼 알아볼 이름 (예시이며 다른 이름도 됩니다), 사용자 지원 이메일은 목록에서 내 메일 → [다음][CR]2. 대상: [외부] 선택 → [다음] ([내부]는 아닙니다)[CR]3. 연락처 정보: 이메일 주소에 내 메일 → [다음][CR][CR][COLOR FF7FD6A0]▶ 3번까지 [다음]을 눌렀으면 아래 [다음]을 누르세요[/COLOR]'),
    ('동의하고 만들기', '4. 완료: 동의 체크 → [계속] → 1~4번이 모두 체크되면 맨 아래 [만들기][CR][CR][COLOR FFFF6E6E]위쪽 [OAuth 클라이언트 만들기]는 지금 누르지 마세요.[/COLOR] 프로덕션 게시 뒤 26단계에서 누릅니다. 만든 직후 나오는 ID와 비밀번호를 바로 TV로 보내기 위해서입니다.[CR][CR][COLOR FF7FD6A0]▶ [OAuth 구성 생성됨]이 보이면 아래 [다음]을 누르세요[/COLOR]'),
    *_BRAND_STEPS,
    _PUBLISH_STEP,
    _PUBLISH_STEP2,
    ("클라이언트 열기", "휴대폰 콘솔 돋보기를 누르고 클라이언트 를 입력합니다.[CR]맨 위 [클라이언트] (제품 페이지 · Google 인증 플랫폼)를 누릅니다. [사용자 인증 정보]나 Endpoints가 아닙니다.[CR]처음에는 [표시할 OAuth 클라이언트가 없습니다.] 라고 나오는 것이 정상입니다.[CR][CR][COLOR FF7FD6A0]▶ [클라이언트] 화면이 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("클라이언트 만들기", "1. [클라이언트] 화면 제목 옆 점 세 개 ⋮ 를 누르고 [+ 클라이언트 만들기]를 누릅니다.[CR]2. [애플리케이션 유형]을 [TV 및 입력 제한 기기]로 선택합니다. (Android가 아닙니다)[CR]3. 이름은 처음 들어 있는 TV 클라이언트 1개 그대로 둬도 됩니다.[CR]4. [AI 기반 에이전트에 이 클라이언트 사용]은 체크하지 않고 맨 아래 파란 [만들기]를 누릅니다.[CR][CR][COLOR FF7FD6A0]▶ 클라이언트 ID와 보안 비밀번호 창이 열리면, 닫지 말고 아래 [다음]을 누르세요[/COLOR]"),
    ("ID와 비밀번호 복사", "[OAuth 클라이언트 생성됨] 창에 클라이언트 ID와 클라이언트 보안 비밀번호가 나옵니다. 값이 길어서 창을 옆으로 밀어야 끝까지 보입니다.[CR]각 값 오른쪽의 복사 아이콘을 누르면 복사됩니다. 다음 단계의 페이지에 두 값을 각각 붙여넣습니다.[CR][COLOR FFFF6E6E]이 창을 닫으면 보안 비밀번호를 다시 볼 수 없습니다. 모두 보낼 때까지 닫지 마세요.[/COLOR][CR][CR][COLOR FF7FD6A0]▶ 두 값이 보이는 창을 열어 둔 채 아래 [다음]을 누르세요[/COLOR]"),
    ("QR 스캔하기", "휴대폰 카메라로 오른쪽 QR을 스캔하고 나오는 주소를 엽니다. 휴대폰과 TV가 같은 Wi-Fi여야 합니다.[CR]구글 콘솔의 [OAuth 클라이언트 생성됨] 창은 닫지 말고 브라우저의 다른 탭에 그대로 둡니다.[CR][CR][COLOR FF7FD6A0]▶ 휴대폰에 [ID와 비밀번호 붙여넣기] 페이지가 열렸으면 아래 [다음]을 누르세요[/COLOR]"),
    ("ID와 비밀번호 입력", "휴대폰에 열린 페이지에서 입력합니다.[CR]1. 구글 콘솔 창으로 돌아가 클라이언트 ID 복사 아이콘을 누르고, 이 페이지로 와서 [클라이언트 ID] 칸을 길게 눌러 [붙여넣기]를 합니다[CR]2. 같은 방식으로 클라이언트 보안 비밀번호를 [클라이언트 보안 비밀번호] 칸에 붙여넣습니다[CR]3. 흰색 [저장하고 TV에서 로그인 시작]을 누릅니다[CR][CR][COLOR FF7FD6A0]▶ TV에 로그인 코드가 뜨면 아래 [다음]을 누르세요[/COLOR]"),
    ("코드 입력", "휴대폰 페이지의 [코드 복사]를 누르고 [google.com/device 열기]를 누릅니다.[CR]열린 [기기 연결] 화면의 입력칸에 복사한 TV 코드를 붙여넣고 [계속]을 누릅니다.[CR]키를 만든 같은 구글 계정을 선택하세요."),
    ("경고 넘기기", "[Google에서 확인하지 않은 앱] 화면이 나오면 [고급]을 누르고 맨 아래 [이동(안전하지 않음)]을 누릅니다. 내가 만든 앱이라 정상입니다.[CR]다음 화면에서 YouTube 계정 보기 권한을 확인하고 [계속]을 누릅니다."),
    ("연결 완료", "[기기에 연결됨] 화면이 나오면 성공입니다. 휴대폰은 닫아도 됩니다.[CR]TV에 연결됨과 구독 개수가 나오면 [다음]으로 끝냅니다.[CR][CR]인증이 실패했다면 다음 단계를 보세요."),
    ("인증이 안 될 때", "인증이 실패해 다시 할 때:[CR]1. 콘솔 돋보기에 클라이언트 입력 → [클라이언트] → [TV 클라이언트 1개][CR]2. 오른쪽 위 ⋮ → ⓘ 를 누르면 클라이언트 ID가 보입니다[CR]3. 보안 비밀번호는 다시 볼 수 없으니 아래쪽 [+ Add secret]으로 새로 만들어 바로 복사[CR]4. 28단계 QR부터 다시 붙여넣기"),
]

OAUTH_IMGS = {
    "브랜딩 주소 입력": ["g_oa_br0", "g_oa_br1"],
    "승인된 도메인 추가": ["g_oa_br5", "g_oa_br6"],
    "프로덕션으로 게시": ["g_oa_pub1", "g_oa_pub2"],
    "프로덕션 확인": ["g_oa_pub3", "g_oa_pub4"],
    "클라이언트 열기": ["g_oa_cl1", "g_oa_cl2"],
    "클라이언트 만들기": ["g_oa_cm1", "g_oa_cm2"],
    "ID와 비밀번호 복사": ["g_oa_id1", "g_oa_id2"],
    "ID와 비밀번호 입력": ["g_oa_send1", "g_oa_send2"],
    "코드 입력": ["g_oa_dv1", "g_oa_dv2"],
    "경고 넘기기": ["g_oa_dv3", "g_oa_dv4"],
    "연결 완료": ["g_oa_dv5"],
    "인증이 안 될 때": ["g_oa_re3", "g_oa_re4"],
    "프로젝트 확인": ["g_oa_proj"],
    "프로젝트 고르기": ["g_oa_pick"],
    "Google 인증 플랫폼 열기": ["g_oa_search"],
    "시작하기 누르기": ["g_oa_start"],
    "앱 정보 · 대상 · 연락처": ["g_oa_p1a", "g_oa_p1b"],
    "동의하고 만들기": ["g_oa_p2a", "g_oa_done2"],
}

PUBLISH_STEPS = [
    ("시작", "이미 구독 연결을 했는데 7일마다 풀린다면 프로덕션 게시만 하면 됩니다.[CR][CR]브랜딩 입력 → 프로덕션 게시, 두 단계입니다. 약 5분 걸립니다.[CR]휴대폰 브라우저에서 구글에 로그인하고 console.cloud.google.com 을 열어 두세요.[CR][CR][COLOR FF7FD6A0]▶ 준비가 됐으면 아래 [다음]을 누르세요[/COLOR]"),
    *_BRAND_STEPS,
    _PUBLISH_STEP,
    _PUBLISH_STEP2,
    ("완료", "이제 7일마다 풀리지 않습니다.[CR][CR]이미 풀려 있다면 설정의 \'내 구독 연결\'에서 OK를 누르고 새 코드로 한 번만 다시 로그인하세요.[CR][CR][COLOR FF7FD6A0]▶ 아래 [닫기]를 누르면 끝납니다[/COLOR]"),
]


_IMG_DIR = "special://home/addons/plugin.video.km/resources/skins/Default/media/yt_guide/"
# phone screenshots (highlighted) shown beside the step text; at most two per step
YT_IMGS = {
    "구글 클라우드 콘솔 열기": ["g_terms", "g_credit"],
    "프로젝트 메뉴 열기": ["g_menu"],
    "새 프로젝트 누르기": ["g_picker"],
    "새 프로젝트 화면": ["g_newproj2", "g_ad"],
    "만든 프로젝트 선택하기": ["g_notify2", "g_dash"],
    "API 검색하기": ["g_search"],
    "YouTube Data API v3 켜기": ["g_api_detail2"],
    "사용자 인증 정보 만들기 누르기": ["g_api_on2"],
    "API 키 만들기": ["g_type2", "g_haskey"],
    "키 복사하기": ["g_keyshown2", "g_restrict4"],
    "완료 후 화면": ["g_done"],
}


_GUIDE_FINISHED = [False]


class YtGuideDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.pop("url", "")
        self.qr = kwargs.pop("qr", "")
        self.steps = kwargs.pop("steps", None) or YT_STEPS
        self.head = kwargs.pop("head", "PlexKM 유튜브 · API 키 만들기")
        self.qr_last = kwargs.pop("qr_last", True)
        self.imgs = kwargs.pop("imgs", None)
        if self.imgs is None:
            self.imgs = YT_IMGS if self.steps is YT_STEPS else {}
        self.offset = kwargs.pop("offset", 0)
        self.total = kwargs.pop("total", None)
        self.i = 0
        super(YtGuideDialog, self).__init__(*args, **kwargs)

    def _show(self):
        n = len(self.steps)
        t, b = self.steps[self.i]
        self.setProperty("PKM.YtG.Head", self.head)
        _im = self.imgs.get(t) or []
        for _k in (0, 1):
            self.setProperty("PKM.YtG.Img%d" % (_k + 1), (_IMG_DIR + _im[_k] + ".jpg") if _k < len(_im) else "")
        self.setProperty("PKM.YtG.Count", "%d / %d 단계" % (self.offset + self.i + 1, self.total or n))
        self.setProperty("PKM.YtG.Title", t)
        self.setProperty("PKM.YtG.Body", b)
        _q = self.qr_last and (t == "QR 스캔하기" or (self.i == n - 1 and t == "키 보내기"))
        self.setProperty("PKM.YtG.QR", "1" if _q else "")
        self.setProperty("PKM.YtG.Msg", "휴대폰이 TV와 같은 Wi-Fi여야 합니다" if _q else "")

    def onInit(self):
        self.setProperty("PKM.YtG.URL", self.url.replace("http://", ""))
        self._show()
        if self.qr and os.path.exists(self.qr):
            try:
                self.getControl(QR_ID).setImage(self.qr, False)
            except Exception:
                pass

    def say(self, text, done=False):
        try:
            self.setProperty("PKM.YtG.Msg", text)
        except Exception:
            pass

    def onClick(self, cid):
        if cid == 10:
            self.close()
        elif cid == 11 and self.i > 0:
            self.i -= 1
            self._show()
        elif cid == 12:
            if self.i < len(self.steps) - 1:
                self.i += 1
                self._show()
            else:
                _GUIDE_FINISHED[0] = True
                self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


def run(youtube=False):
    """Blocking. Returns the saved key ('' if cancelled). youtube=True: YouTube API key guide."""
    from resources.lib.pkm_youtube_keyserver import KeyServer, write_qr
    saved = {"key": ""}
    dlg_ref = {}

    def on_key(key):
        if youtube:
            from resources.lib import pkm_youtube as yt
            ok, msg = yt.test_api_key(key)
            if ok:
                yt.set_api_key(key)
                saved["key"] = key
                d = dlg_ref.get("dlg")
                if d is not None:
                    d.say("저장되었습니다. 창을 닫는 중…", done=True)
            return ok, msg
        ok, msg = verify_key(key)
        if ok:
            try:
                xbmcaddon.Addon(ADDON_ID).setSetting("pkm_subdl_api_key", key)
                saved["key"] = key
            except Exception:
                return False, "저장 중 오류가 발생했습니다"
            d = dlg_ref.get("dlg")
            if d is not None:
                d.say("저장되었습니다. 창을 닫는 중…", done=True)
        return ok, msg

    def on_event(kind, text):
        d = dlg_ref.get("dlg")
        if d is not None and kind in ("open", "checking", "error", "idle"):
            d.say(text)

    srv = KeyServer(on_key, on_event, kind="ytkey" if youtube else "subdl")
    if not srv.start():
        xbmcgui.Dialog().ok("SubDL", "휴대폰 입력 서버를 시작하지 못했습니다.[CR]설정에서 키를 직접 입력해주세요.")
        return ""
    qr = os.path.join(_profile_dir(), "subdl_key_qr_%s.png" % srv.token)
    write_qr(srv.url, qr)
    try:
        if youtube:
            dlg = YtGuideDialog("plexkm_ytkey_guide_r330.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                                "Default", "1080i", url=srv.url, qr=qr,
                                total=len(YT_STEPS) + len(OAUTH_STEPS))
        else:
          dlg = SubdlQrDialog("plexkm_subdl_qr_r308.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                            "Default", "1080i", url=srv.url, qr=qr,
                            texts=("PlexKM 유튜브 · API 키", "YouTube API 키를 휴대폰으로 입력하세요", "안내 페이지 따라 키 발급 → 붙여넣고 저장") if youtube else None)
        dlg_ref["dlg"] = dlg

        def _watch():
            t0 = time.time()
            while dlg_ref.get("dlg") is not None and not xbmc.Monitor().abortRequested():
                if saved["key"]:
                    xbmc.sleep(1200)
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                if time.time() - t0 > 15 * 60 or not srv.running:
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                xbmc.sleep(400)

        import threading
        th = threading.Thread(target=_watch)
        th.daemon = True
        th.start()
        _GUIDE_FINISHED[0] = False
        dlg.doModal()
    except Exception:
        _log("DIALOG_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    finally:
        dlg_ref["dlg"] = None
        srv.stop()
        try:
            os.remove(qr)
        except Exception:
            pass
    return saved["key"] or ("1" if (youtube and _GUIDE_FINISHED[0]) else "")


def run_oauth(chained=False):
    """Blocking. Standalone 구독 연결 guide (installer): TV step guide, then QR page for client ID/secret,
    device-code login and first sync, all without the YouTube settings window."""
    import threading
    from resources.lib.pkm_youtube_keyserver import KeyServer, write_qr
    from resources.lib import pkm_youtube_account as acct
    ref = {"dlg": None, "done": False, "srv": None, "token": 0}

    def say(text):
        d = ref.get("dlg")
        if d is not None:
            d.say(text)

    def status(**kw):
        srv = ref.get("srv")
        if srv is not None and srv.running:
            srv.status.update(kw)

    def poll(info, token):
        interval = info.get("interval") or 5
        end = float(info.get("expires_at") or (time.time() + 1800))
        while time.time() < end and ref["token"] == token and not xbmc.Monitor().abortRequested():
            xbmc.sleep(int(interval * 1000))
            state, msg = acct.device_poll(info)
            if state == "pending":
                continue
            if state == "slow":
                interval += 5
                continue
            if state != "ok":
                status(state="error", msg=msg)
                say(msg)
                return
            status(state="syncing", msg="연결됨 · 구독 채널을 가져오는 중")
            say("연결됨 · 구독 채널을 가져오는 중입니다")
            ok, smsg = acct.sync()
            status(state="done" if ok else "error", msg=smsg)
            say(smsg)
            ref["done"] = bool(ok)
            return

    def on_client(value):
        cid, sec = value
        ok, info = acct.device_start(cid)
        if not ok:
            return False, info
        acct.set_client(cid, sec)
        ref["token"] += 1
        code = info.get("user_code") or ""
        url = info.get("verification_url") or "https://www.google.com/device"
        status(state="code", code=code, url=url, msg="")
        say("로그인 코드: %s  (google.com/device)" % code)
        th = threading.Thread(target=poll, args=(info, ref["token"]))
        th.daemon = True
        th.start()
        return True, "저장했습니다. 이 TV에 뜬 코드로 google.com/device 에서 로그인하세요"

    def on_event(kind, text):
        if kind in ("open", "checking", "error", "idle"):
            say(text)

    srv = KeyServer(on_client, on_event, kind="oauth")
    if not srv.start():
        xbmcgui.Dialog().ok("PlexKM", "휴대폰 입력 서버를 시작하지 못했습니다.[CR]잠시 후 다시 시도해주세요.")
        return False
    ref["srv"] = srv
    qr = os.path.join(_profile_dir(), "oauth_guide_qr_%s.png" % srv.token)
    write_qr(srv.url, qr)
    try:
        dlg = YtGuideDialog("plexkm_ytkey_guide_r330.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                            "Default", "1080i", url=srv.url, qr=qr, steps=OAUTH_STEPS,
                            head="PlexKM 유튜브 · 로그인 연결", qr_last=True,
                            imgs=OAUTH_IMGS,
                            offset=(len(YT_STEPS) if chained else 0),
                            total=((len(YT_STEPS) + len(OAUTH_STEPS)) if chained else None))
        ref["dlg"] = dlg

        def _watch():
            t0 = time.time()
            while ref.get("dlg") is not None and not xbmc.Monitor().abortRequested():
                if ref["done"]:
                    xbmc.sleep(2500)
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                if time.time() - t0 > 45 * 60 or not srv.running:
                    return
                xbmc.sleep(500)

        th = threading.Thread(target=_watch)
        th.daemon = True
        th.start()
        dlg.doModal()
    except Exception:
        _log("OAUTH_GUIDE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    finally:
        ref["dlg"] = None
        srv.stop()
        try:
            os.remove(qr)
        except Exception:
            pass
    return ref["done"]
