# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""R308: enter the SubDL API key from a phone (QR -> paste -> save).

Reuses the YouTube key server (kind="subdl"): the TV shows a QR for
http://<lan-ip>:<port>/<token>, the phone opens a page, pastes the key and the
key is verified against SubDL before it is stored in pkm_subdl_api_key.
"""

import os
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
CLOSE_ID = 10
QR_ID = 20


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[PlexKM] SUBDL QR %s" % msg, level)
    except Exception:
        pass


def clean_subdl_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    ok = all(ch.isalnum() or ch in "-_" for ch in key)
    if len(key) < 20 or len(key) > 120 or not ok:
        return "", "SubDL API 키 형식이 아닙니다 (subdl.com > API 페이지의 키를 그대로 붙여넣으세요)"
    return key, ""


def verify_key(key):
    """(ok, message). Network errors are not treated as a bad key."""
    try:
        from resources.lib import pkm_subdl
        pkm_subdl._get_json({"api_key": key, "film_name": "Parasite", "type": "movie",
                             "languages": "KO", "subs_per_page": 1}, timeout=12)
        return True, "SubDL 키를 저장했습니다"
    except Exception as exc:
        text = str(exc)
        if "401" in text or "403" in text or "400" in text:
            return False, "SubDL이 이 키를 받아주지 않습니다. 키를 다시 확인하세요"
        return True, "키를 저장했습니다 (SubDL 확인은 건너뜀: 네트워크)"


def page_html(msg_html=""):
    return (
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'><title>PlexKM SubDL 키</title>"
        "<style>body{margin:0;background:#15171a;color:#f1f1f1;font:17px/1.6 -apple-system,'Apple SD Gothic Neo','Noto Sans KR',sans-serif}"
        "main{max-width:560px;margin:0 auto;padding:28px 18px}h1{font-size:22px}"
        "textarea{width:100%;box-sizing:border-box;height:96px;border-radius:12px;border:1px solid #444;background:#23272c;color:#fff;padding:12px;font-size:16px}"
        "button{margin-top:14px;width:100%;padding:15px;border:0;border-radius:12px;background:#e5b400;color:#111;font-size:18px;font-weight:700}"
        ".msg{margin:14px 0;padding:12px 14px;border-radius:10px}.ok{background:#12351f;color:#8be0a4}.bad{background:#401a1a;color:#ff9c9c}"
        "a{color:#e5b400}</style></head><body><main>"
        "<h1>SubDL API 키 입력</h1>" + (msg_html or "") +
        "<ol style='padding-left:20px'>"
        "<li>아래 <b>[SubDL 열기]</b>를 누르세요. 로그인 화면이 나오면 로그인하세요(계정이 없으면 Register로 무료 가입). 로그인하면 API 키 페이지가 바로 열립니다.<br>"
        "<a href='https://subdl.com/panel/login?page=/panel/api' target='_blank' style='display:inline-block;margin:8px 0;padding:10px 16px;border-radius:10px;background:#23272c;font-weight:700'>SubDL 열기 (API 키 페이지)</a></li>"
        "<li>열린 페이지의 <b>API Key</b> 화면에서 <b>Copy API Code</b> 버튼을 누르면 키가 복사됩니다.</li>"
        "<li>이 화면(브라우저 탭)으로 돌아와 아래 입력칸을 길게 눌러 <b>붙여넣기</b>하고 <b>저장</b>을 누르세요.</li>"
        "</ol><p style='color:#a3a8b3;font-size:15px'>저장하면 TV에 바로 적용됩니다. TV에서 키를 직접 칠 필요가 없습니다.</p>"
        "<form method='post'><textarea name='key' placeholder='subdl_...' autocomplete='off' autocapitalize='off' spellcheck='false'></textarea>"
        "<button type='submit'>저장</button></form></main></body></html>"
    )


def page_html_yt(msg_html=""):
    return (
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'><title>PlexKM YouTube 키</title>"
        "<style>body{margin:0;background:#15171a;color:#f1f1f1;font:17px/1.6 -apple-system,'Apple SD Gothic Neo','Noto Sans KR',sans-serif}"
        "main{max-width:560px;margin:0 auto;padding:28px 18px}h1{font-size:22px}"
        "textarea{width:100%;box-sizing:border-box;height:96px;border-radius:12px;border:1px solid #444;background:#23272c;color:#fff;padding:12px;font-size:16px}"
        "button{margin-top:14px;width:100%;padding:15px;border:0;border-radius:12px;background:#e5b400;color:#111;font-size:18px;font-weight:700}"
        ".msg{margin:14px 0;padding:12px 14px;border-radius:10px}.ok{background:#12351f;color:#8be0a4}.bad{background:#401a1a;color:#ff9c9c}"
        "</style></head><body><main>"
        "<h1>YouTube API 키 입력</h1>" + (msg_html or "") +
        "<p>구글 콘솔에서 복사한 API 키를 아래 칸에 길게 눌러 <b>붙여넣기</b>하고 <b>저장</b>을 누르세요.</p>"
        "<form method='post'><textarea name='key' placeholder='AIza...' autocomplete='off' autocapitalize='off' spellcheck='false'></textarea>"
        "<button type='submit'>저장</button></form>"
        "<p style='color:#a3a8b3;font-size:15px'>저장하면 TV가 키를 확인하고 바로 적용합니다.</p></main></body></html>"
    )


def _profile_dir():
    p = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except Exception:
            pass
    return p


class SubdlQrDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.pop("url", "")
        self.texts = kwargs.pop("texts", None) or ("PlexKM 자막 · SubDL", "SubDL API 키를 휴대폰으로 입력하세요", "Copy API Code 복사 → 붙여넣고 저장")
        self.qr = kwargs.pop("qr", "")
        super(SubdlQrDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty("PKM.SubdlQR.URL", self.url)
        self.setProperty("PKM.SubdlQR.Head", self.texts[0])
        self.setProperty("PKM.SubdlQR.Title", self.texts[1])
        self.setProperty("PKM.SubdlQR.Step2", self.texts[2])
        self.setProperty("PKM.SubdlQR.Msg", "휴대폰이 TV와 같은 Wi-Fi여야 합니다")
        self.setProperty("PKM.SubdlQR.Done", "")
        if self.qr and os.path.exists(self.qr):
            try:
                self.getControl(QR_ID).setImage(self.qr, False)
            except Exception:
                pass
        try:
            self.setFocusId(CLOSE_ID)
        except Exception:
            pass

    def say(self, text, done=False):
        try:
            self.setProperty("PKM.SubdlQR.Msg", text)
            if done:
                self.setProperty("PKM.SubdlQR.Done", "1")
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == CLOSE_ID:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


YT_STEPS = [
    ("시작", "API 키 생성은 무료입니다.[CR][CR]이 화면의 안내를 보면서 휴대폰 브라우저에서 직접 만듭니다. 마지막 단계에서만 만든 키를 보냅니다.[CR][CR]먼저 휴대폰 브라우저에서 구글에 로그인하세요. 이미 로그인돼 있으면 그대로 두세요.[CR][CR][COLOR FF7FD6A0]▶ 로그인이 끝났으면 아래 [다음]을 누르세요[/COLOR]"),
    ("구글 클라우드 콘솔 열기", "휴대폰 브라우저 주소창에 console.cloud.google.com 을 입력해 엽니다.[CR]처음이면 국가 [대한민국] 선택, 약관 동의 → [동의 및 계속][CR][CR][COLOR FF7FD6A0]▶ 휴대폰에 [시작하기]와 '작업 중인 프로젝트'가 보이면 아래 [다음]을 누르세요[/COLOR]"),
    ("프로젝트 준비", "휴대폰 첫 화면의 '작업 중인 프로젝트:' 옆에 파란 버튼이 있습니다. 누르면 프로젝트 선택 창이 열립니다.[CR][CR]이미 프로젝트가 있으면 그대로 쓰고, 없거나 새로 만들고 싶으면 아래대로 합니다.[CR][CR]새로 만들기: 파란 버튼 → 선택 창 오른쪽 위 [새 프로젝트][CR][CR][COLOR FF7FD6A0]▶ [새 프로젝트] 화면이 열렸으면 아래 [다음]을 누르세요.[CR]기존 프로젝트를 쓰면 [다음]을 두 번 누르세요[/COLOR]"),
    ("새 프로젝트 화면", "휴대폰 [새 프로젝트] 화면에서:[CR]- 노란 경고 'projects 할당량이 N개 남았습니다': 아직 만들 수 있다는 뜻입니다. 무시하세요[CR]- 프로젝트 이름: pkm-youtube 처럼 알아볼 이름을 넣습니다 (아래 프로젝트 ID는 자동으로 정해집니다)[CR]- 상위 리소스 '조직 없음': 개인 계정은 정상입니다. 그대로 두세요[CR]- 맨 아래 파란 [만들기]를 누릅니다[CR][CR][COLOR FF7FD6A0]▶ 위쪽 종 모양 알림을 누르고 [프로젝트 선택]을 누릅니다. 아래에 '현재 pkm-youtube 프로젝트를 보는 중입니다' 알림이 뜨면 아래 [다음]을 누르세요[/COLOR]"),
    ("YouTube Data API v3 켜기", "이 단계를 꼭 먼저 하세요.[CR]1. 휴대폰 콘솔 위쪽 돋보기(검색)에 YouTube Data API v3 를 입력하고, 검색 결과의 YouTube Data API v3 를 누릅니다.[CR]2. 열린 [제품 세부정보] 화면에서 빨간 유튜브 로고 아래의 파란 [사용] 버튼을 누릅니다. 옆의 [API 사용해 보기]는 누르지 않습니다.[CR][CR][COLOR FF7FD6A0]▶ 화면이 [API/서비스 세부정보]로 바뀌고 아래쪽 상태에 [사용 설정됨]이 보이면 아래 [다음]을 누르세요[/COLOR]"),
    ("API 키 만들기", "[사용자 인증 정보 만들기] 화면 1번에서:[CR]- API 선택: YouTube Data API v3 가 이미 들어 있으면 그대로 둡니다[CR]- 액세스할 데이터는 무엇인가요?: [공개 데이터]를 고릅니다[CR]- 그 아래 휴대폰 화면의 [다음]을 누릅니다[CR][CR][이미 보유 중인 API 키 목록] 창이 열리면 창 아래 [만들기]를 누릅니다. 키가 하나 더 생겨도 상관없습니다.[CR][CR][COLOR FF7FD6A0]▶ 2번 [내 사용자 인증 정보]에 [API 키]와 키 입력칸이 보이면 아래 [다음]을 누르세요[/COLOR]"),
    ("키 복사하기", "휴대폰 화면의 키 입력칸(AIza로 시작하는 긴 글자) 오른쪽 복사 아이콘을 누르면 키가 복사됩니다. 복사한 키는 마지막 단계에서 붙여넣습니다.[CR][CR]주의: 노란 경고의 [Restrict key]는 다음 단계의 선택 사항입니다. 누르면 이 화면에서 벗어납니다.[CR][CR][COLOR FF7FD6A0]▶ 키를 복사했으면 아래 [다음]을 누르세요[/COLOR]"),
    ("키 제한하기 (선택)", "노란 경고 '프로덕션에서 사용하기 전에 이 키를 제한하는 것이 좋습니다'는 필수가 아닙니다. 제한하면 키가 유출돼도 유튜브 용도로만 쓰입니다. 건너뛰어도 PlexKM은 똑같이 작동합니다.[CR]제한하려면: [Restrict key] → 'API 제한사항'에서 [키 제한] → YouTube Data API v3 만 체크 → [저장][CR][CR][COLOR FF7FD6A0]▶ 제한을 마쳤거나 건너뛰려면 아래 [다음]을 누르세요[/COLOR]"),
    ("키 보내기", "1. 휴대폰 카메라로 오른쪽 QR을 스캔합니다[CR]2. 열린 페이지의 입력칸에 방금 복사한 키를 붙여넣고 [저장]을 누릅니다[CR]복사한 키가 없어졌으면 [이미 보유 중인 API 키 목록] 창이나 사용자 인증 정보 목록에서 [키 표시]를 눌러 다시 복사합니다[CR][CR][COLOR FF7FD6A0]▶ 저장하면 키를 확인하고 이 창이 자동으로 닫힙니다[/COLOR]"),
]


_BRAND_STEP = ("브랜딩 입력", "휴대폰 콘솔 돋보기에 브랜딩 을 입력해 열고, 아래 칸을 채웁니다.[CR]- 앱 홈페이지: https://kmfly.github.io/[CR]- 앱 개인정보처리방침 링크: https://kmfly.github.io/privacy.html[CR]- 승인된 도메인: [+ 도메인 추가] → kmfly.github.io[CR]앱 로고와 서비스 약관 링크는 비워 둡니다.[CR]맨 아래 [저장]을 누릅니다.[CR][CR][COLOR FF7FD6A0]▶ [저장]이 끝났으면 아래 [다음]을 누르세요[/COLOR]")

_PUBLISH_STEP = ("프로덕션으로 게시", "휴대폰 콘솔 돋보기에 대상 을 입력해 엽니다.[CR]'게시 상태'가 [테스트]이면 [앱 게시]를 누르고, \'프로덕션으로 푸시하시겠어요?\' 창에서 [확인]을 누릅니다.[CR]개인용은 구글 심사가 필요 없습니다.[CR]프로덕션으로 바꾸면 7일마다 연결이 풀리지 않습니다.[CR][CR][COLOR FF7FD6A0]▶ 게시 상태가 [프로덕션]으로 바뀌면 아래 [다음]을 누르세요[/COLOR]")

OAUTH_STEPS = [
    ("시작", "내 유튜브 구독 채널을 PlexKM 구독 탭으로 가져오는 연결입니다. 읽기 전용이고 무료입니다.[CR][CR]한 번만 만들면 7일마다 다시 연결하지 않도록 프로덕션 게시까지 함께 합니다. 약 15분 걸립니다.[CR][CR]API 키를 만들 때 쓴 구글 로그인과 프로젝트를 그대로 씁니다. 휴대폰 브라우저에서 구글에 로그인돼 있어야 합니다.[CR][CR][COLOR FF7FD6A0]▶ 준비가 됐으면 아래 [다음]을 누르세요[/COLOR]"),
    ("프로젝트 확인", "휴대폰 브라우저 주소창에 console.cloud.google.com 을 입력해 엽니다.[CR]첫 화면의 \'작업 중인 프로젝트:\' 옆 파란 버튼이 API 키를 만들 때 쓴 프로젝트(예: pkm-youtube)인지 확인합니다.[CR]다른 프로젝트이면 그 파란 버튼을 눌러 선택 창에서 원래 프로젝트를 고릅니다.[CR][CR][COLOR FF7FD6A0]▶ 내 프로젝트 이름이 보이면 아래 [다음]을 누르세요[/COLOR]"),
    ("동의 화면 만들기", "휴대폰 콘솔 돋보기에 Google 인증 플랫폼 을 입력해 열고 [시작하기]를 누릅니다.[CR]1. 앱 이름: pkmyoutube (아무 이름), 사용자 지원 이메일: 내 메일 → [다음][CR]2. 대상: [외부] → [다음][CR]3. 연락처 이메일: 내 메일 → [다음][CR]4. 정책 동의 체크 → [계속] → [만들기][CR]이미 만들어져 있다고 나오면 그대로 다음으로 갑니다.[CR][CR][COLOR FF7FD6A0]▶ [OAuth 구성 생성됨]이 보이면 아래 [다음]을 누르세요[/COLOR]"),
    _BRAND_STEP,
    _PUBLISH_STEP,
    ("클라이언트 만들기", "휴대폰 콘솔 돋보기에 클라이언트 를 입력해 열고 [+ 클라이언트 만들기]를 누릅니다.[CR]애플리케이션 유형: [TV 및 입력 제한 기기] (Android가 아닙니다)[CR]이름을 넣고 [만들기]를 누릅니다.[CR][CR][COLOR FF7FD6A0]▶ 클라이언트 ID와 클라이언트 보안 비밀번호가 보이는 창이 열리면, 닫지 말고 아래 [다음]을 누르세요[/COLOR]"),
    ("ID와 비밀번호 보내기", "1. 휴대폰 카메라로 오른쪽 QR을 스캔합니다[CR]2. 열린 페이지에 클라이언트 ID와 클라이언트 보안 비밀번호를 각각 복사해 붙여넣고 [저장]을 누릅니다[CR]3. 이 화면이 닫히면 뜨는 코드를 google.com/device 에 입력해 로그인합니다[CR][CR][COLOR FF7FD6A0]▶ \'Google에서 확인하지 않은 앱\'이 나오면 [고급] → [이동(안전하지 않음)]을 누르세요. 내가 만든 앱이라 정상입니다[/COLOR]"),
]

PUBLISH_STEPS = [
    ("시작", "이미 구독 연결을 했는데 7일마다 풀린다면 프로덕션 게시만 하면 됩니다.[CR][CR]브랜딩 입력 → 프로덕션 게시, 두 단계입니다. 약 5분 걸립니다.[CR]휴대폰 브라우저에서 구글에 로그인하고 console.cloud.google.com 을 열어 두세요.[CR][CR][COLOR FF7FD6A0]▶ 준비가 됐으면 아래 [다음]을 누르세요[/COLOR]"),
    _BRAND_STEP,
    _PUBLISH_STEP,
    ("완료", "이제 7일마다 풀리지 않습니다.[CR][CR]이미 풀려 있다면 설정의 \'내 구독 연결\'에서 OK를 누르고 새 코드로 한 번만 다시 로그인하세요.[CR][CR][COLOR FF7FD6A0]▶ 아래 [닫기]를 누르면 끝납니다[/COLOR]"),
]


class YtGuideDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.pop("url", "")
        self.qr = kwargs.pop("qr", "")
        self.steps = kwargs.pop("steps", None) or YT_STEPS
        self.head = kwargs.pop("head", "PlexKM 유튜브 · API 키 만들기")
        self.qr_last = kwargs.pop("qr_last", True)
        self.i = 0
        super(YtGuideDialog, self).__init__(*args, **kwargs)

    def _show(self):
        n = len(self.steps)
        t, b = self.steps[self.i]
        self.setProperty("PKM.YtG.Head", self.head)
        self.setProperty("PKM.YtG.Count", "%d / %d 단계" % (self.i + 1, n))
        self.setProperty("PKM.YtG.Title", t)
        self.setProperty("PKM.YtG.Body", b)
        _q = self.qr_last and self.i == n - 1
        self.setProperty("PKM.YtG.QR", "1" if _q else "")
        self.setProperty("PKM.YtG.Msg", "휴대폰이 TV와 같은 Wi-Fi여야 합니다" if _q else "")

    def onInit(self):
        self.setProperty("PKM.YtG.URL", self.url.replace("http://", ""))
        self._show()
        if self.qr and os.path.exists(self.qr):
            try:
                self.getControl(QR_ID).setImage(self.qr, False)
            except Exception:
                pass

    def say(self, text, done=False):
        try:
            self.setProperty("PKM.YtG.Msg", text)
        except Exception:
            pass

    def onClick(self, cid):
        if cid == 10:
            self.close()
        elif cid == 11 and self.i > 0:
            self.i -= 1
            self._show()
        elif cid == 12:
            if self.i < len(self.steps) - 1:
                self.i += 1
                self._show()
            else:
                self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


def run(youtube=False):
    """Blocking. Returns the saved key ('' if cancelled). youtube=True: YouTube API key guide."""
    from resources.lib.pkm_youtube_keyserver import KeyServer, write_qr
    saved = {"key": ""}
    dlg_ref = {}

    def on_key(key):
        if youtube:
            from resources.lib import pkm_youtube as yt
            ok, msg = yt.test_api_key(key)
            if ok:
                yt.set_api_key(key)
                saved["key"] = key
                d = dlg_ref.get("dlg")
                if d is not None:
                    d.say("저장되었습니다. 창을 닫는 중…", done=True)
            return ok, msg
        ok, msg = verify_key(key)
        if ok:
            try:
                xbmcaddon.Addon(ADDON_ID).setSetting("pkm_subdl_api_key", key)
                saved["key"] = key
            except Exception:
                return False, "저장 중 오류가 발생했습니다"
            d = dlg_ref.get("dlg")
            if d is not None:
                d.say("저장되었습니다. 창을 닫는 중…", done=True)
        return ok, msg

    def on_event(kind, text):
        d = dlg_ref.get("dlg")
        if d is not None and kind in ("open", "checking", "error", "idle"):
            d.say(text)

    srv = KeyServer(on_key, on_event, kind="ytkey" if youtube else "subdl")
    if not srv.start():
        xbmcgui.Dialog().ok("SubDL", "휴대폰 입력 서버를 시작하지 못했습니다.[CR]설정에서 키를 직접 입력해주세요.")
        return ""
    qr = os.path.join(_profile_dir(), "subdl_key_qr_%s.png" % srv.token)
    write_qr(srv.url, qr)
    try:
        if youtube:
            dlg = YtGuideDialog("plexkm_ytkey_guide_r330.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                                "Default", "1080i", url=srv.url, qr=qr)
        else:
          dlg = SubdlQrDialog("plexkm_subdl_qr_r308.xml", xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                            "Default", "1080i", url=srv.url, qr=qr,
                            texts=("PlexKM 유튜브 · API 키", "YouTube API 키를 휴대폰으로 입력하세요", "안내 페이지 따라 키 발급 → 붙여넣고 저장") if youtube else None)
        dlg_ref["dlg"] = dlg

        def _watch():
            t0 = time.time()
            while dlg_ref.get("dlg") is not None and not xbmc.Monitor().abortRequested():
                if saved["key"]:
                    xbmc.sleep(1200)
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                if time.time() - t0 > 15 * 60 or not srv.running:
                    try:
                        dlg.close()
                    except Exception:
                        pass
                    return
                xbmc.sleep(400)

        import threading
        th = threading.Thread(target=_watch)
        th.daemon = True
        th.start()
        dlg.doModal()
    except Exception:
        _log("DIALOG_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
    finally:
        dlg_ref["dlg"] = None
        srv.stop()
        try:
            os.remove(qr)
        except Exception:
            pass
    return saved["key"]
