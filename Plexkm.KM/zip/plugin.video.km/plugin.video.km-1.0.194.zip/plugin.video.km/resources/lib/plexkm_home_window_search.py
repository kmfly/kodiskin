# -*- coding: utf-8 -*-
"""PKM home window part (R73): 검색.

Pure move out of plexkm_home_window.py.  plexkm_home_window adopts every
function below into the real PlexKMHomeWindow and rebinds it to that
module's globals, so module-level names used here (imports, constants,
helpers, shared state) resolve in plexkm_home_window.py.  Do not add
imports or module-level state here; put them in plexkm_home_window.py.
The class name matches the real class so qualified names stay identical.
"""
from __future__ import absolute_import, unicode_literals


class PlexKMHomeWindow(object):  # adopted as _PKMHomePartSearchR73
    def _search_info_sidebar_retire_search_v2284(self, reason=""):
        """Retire Search without Home/focus handoff after a destination is ready."""
        try:
            win = xbmcgui.Window(10000)
            try:
                self._search_commit_history(self._search_query, reason=reason or "info_sidebar_ab_v2284")
            except Exception:
                pass
            self._search_inline_active = False
            now_ms = self._now_ms()
            self._search_poster_render_token_v1881 = "info_sidebar_ab_v2284:%d" % now_ms
            self._search_focus_cast_token_v1878 = "info_sidebar_ab_v2284:%d" % now_ms
            try:
                lock = getattr(self, "_search_actual_focus_lock_v1883", None)
                if lock is not None:
                    with lock:
                        self._search_actual_focus_pending_v1883 = {}
                else:
                    self._search_actual_focus_pending_v1883 = {}
            except Exception:
                self._search_actual_focus_pending_v1883 = {}
            for prop in (
                "PlexKM.Search.InlineActive",
                "PlexKM.Search.SurfaceExclusiveV2054",
                "PlexKM.Search.Closing",
            ):
                try:
                    self.clearProperty(prop)
                except Exception:
                    pass
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            try:
                if getattr(self, "_search_index_refresh_deferred_v1879", False):
                    self._search_schedule_index_refresh(reason=reason or "info_sidebar_ab_v2284")
            except Exception:
                pass
            return True
        except Exception:
            _log("SEARCH_INFO_SIDEBAR_RETIRE_FAILED_V2284 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _search_info_sidebar_ab_commit_v2284(self, section_id="", reason=""):
        """Release Search/Info only after the owning section is fully committed.

        The visible Info scene is the transition hold. Section Recommend composes
        into the hidden A/B bank; Library/Category use their existing
        ready-before-visible commit. This helper is called only after those
        destination commits have completed, and never writes focus.
        """
        try:
            hold = getattr(self, "_search_info_sidebar_ab_hold_v2284", None)
            if not isinstance(hold, dict) or not hold:
                return False
            target_sid = str(hold.get("section_id") or "").strip()
            committed_sid = str(section_id or "").strip()
            if committed_sid.startswith("recommend:"):
                committed_sid = committed_sid.split(":", 1)[1]
            if not committed_sid:
                active_sid = str(getattr(self, "active_section_id", "") or "").strip()
                committed_sid = active_sid.split(":", 1)[1] if active_sid.startswith("recommend:") else active_sid
            if not target_sid or committed_sid != target_sid:
                return False

            # Destination properties/control contents are already complete at
            # this point. Cross one GUI frame while complete Info is still the
            # visible source, then retire Search+Info in this same callback.
            win_v2479 = xbmcgui.Window(10000)
            if self.getProperty("PlexKM.Window.IsSectionWall") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionWall") == "1":
                target_surface_v2479 = "section_library"
            elif self.getProperty("PlexKM.Window.IsSectionCategory") == "1" or win_v2479.getProperty("PlexKM.Window.IsSectionCategory") == "1":
                target_surface_v2479 = "section_category"
            else:
                target_surface_v2479 = "section_recommend"
            search_info_swap_v2479 = self._pkm_swap_settle_v2479(
                "info", target_surface_v2479, reason="search_info_destination_ready:%s" % (reason or ""), wait_ms=16
            )
            self._search_info_sidebar_retire_search_v2284(
                reason="destination_commit:%s" % (reason or "")
            )
            try:
                self._clear_inline_info(
                    reason="search_info_sidebar_ab_commit_v2479:%s" % (reason or "")
                )
            except Exception:
                pass
            self._pkm_swap_finish_v2479(
                search_info_swap_v2479, "info", target_surface_v2479, reason="search_info_sidebar_commit:%s" % (reason or "")
            )
            try:
                self._clear_inline_info_playback_return_state(
                    reason="search_info_sidebar_ab_commit_v2284:%s" % (reason or "")
                )
            except Exception:
                pass
            try:
                self._info_clear_property_all("PlexKM.Info.SidebarOpen")
            except Exception:
                pass
            self._search_info_sidebar_ab_hold_v2284 = None
            win = xbmcgui.Window(10000)
            for target in (self, win):
                try:
                    target.clearProperty("PlexKM.SearchInfoSidebarABHoldV2284")
                    target.clearProperty("PlexKM.SearchInfoSidebarABTargetSectionV2284")
                except Exception:
                    pass
            elapsed = max(0, self._now_ms() - int(hold.get("armed_ms") or self._now_ms()))
            _log("SEARCH_INFO_SIDEBAR_AB_COMMIT_V2284 section=%s elapsed_ms=%s reason=%s complete_info_to_complete_section=1 blank_frame=0 home_detour=0 focus_write=0" % (
                target_sid, elapsed, reason or ""
            ))
            return True
        except Exception:
            _log("SEARCH_INFO_SIDEBAR_AB_COMMIT_FAILED_V2284 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False

    def _search_info_sidebar_ab_cancel_v2285(self, reason="", retire_search=True):
        """Cancel the pending hold when the sidebar leaves Plex section items."""
        try:
            if retire_search:
                try:
                    self._search_info_sidebar_retire_search_v2284(
                        reason="ab_cancel_v2285:%s" % (reason or "")
                    )
                except Exception:
                    pass
            self._search_info_sidebar_ab_hold_v2284 = None
            win = xbmcgui.Window(10000)
            for target in (self, win):
                try:
                    target.clearProperty("PlexKM.SearchInfoSidebarABHoldV2284")
                    target.clearProperty("PlexKM.SearchInfoSidebarABTargetSectionV2284")
                except Exception:
                    pass
            _log("SEARCH_INFO_SIDEBAR_AB_CANCEL_V2285 reason=%s retire_search=%s focus_write=0" % (
                reason or "", 1 if retire_search else 0
            ))
            return True
        except Exception:
            _log("SEARCH_INFO_SIDEBAR_AB_CANCEL_FAILED_V2285 reason=%s err=%s" % (
                reason or "", traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGERROR)
            return False


    def _open_inline_search(self):
        """Open the search panel in the right content area.

        Only OK/Enter on the Search sidebar item opens this panel.  It is not
        tied to sidebar focus, so normal focus on other sidebar items remains
        unchanged.  Keyboard/results directional movement is XML-only.
        """
        # v2479: Search is a full scene, so never hide Home/Section first.
        # Clear only stale section swap ownership now; Search remains invisible
        # until keyboard/history/results are fully bound and one GUI frame passes.
        source_mode_v2479 = self._pkm_surface_mode_v2479()
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.clearProperty("PlexKM.Section.BankSwapInProgressV1615")
                target.clearProperty("PlexKM.Section.BankSwapTargetV1615")
                target.clearProperty("PlexKM.Section.BankSwapTokenV1615")
            self._clear_home_trailer_preview(reason="inline_search_stage_v2479", stop_player=True)
            _log("INLINE_SEARCH_AB_STAGE_V2479 source=%s old_scene_hidden=0 search_visible=0" % source_mode_v2479)
        except Exception:
            _log("INLINE_SEARCH_AB_STAGE_FAILED_V2479 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        try:
            self._clear_sidebar_empty_view(reason="inline_search_open")
        except Exception:
            pass
        try:
            self.setProperty("PlexKM.Search.Closing", "")
            self.clearProperty("PlexKM.Search.Closing")
            xbmcgui.Window(10000).clearProperty("PlexKM.Search.Closing")
        except Exception:
            pass
        self._search_inline_active = True
        try:
            self._search_prewarm_db_r95(reason="inline_search_open")
        except Exception:
            pass
        self._search_query = ""
        self._search_query_tokens = []
        self._search_mode = "KO"
        self._search_shift = False
        self._search_results = []
        self._search_scope = "all"
        self._search_yt_items = []
        self._search_yt_loading = False
        self._search_yt_skipped = False
        self._search_yt_token = int(getattr(self, "_search_yt_token", 0) or 0) + 1
        self._search_publish_scope(reason="open_default")
        # v1883: use the existing search DB for the whole inline Search session.
        # Any index refresh is recorded as deferred and starts only after Search
        # closes, so queries never contend with a writer on the same SQLite DB.
        self._search_populate_keyboard()
        self._search_populate_history()
        self._search_clear_results("")
        self._search_schedule_index_refresh(reason="inline_search_open")
        self._search_refresh_query_label()
        search_swap_token_v2479 = self._pkm_swap_settle_v2479(
            source_mode_v2479, "search", reason="search_controls_ready", wait_ms=16
        )
        try:
            win = xbmcgui.Window(10000)
            for target in (self, win):
                target.setProperty("PlexKM.Search.SurfaceExclusiveV2054", "1")
                target.setProperty("PlexKM.Search.InlineActive", "1")
            if source_mode_v2479 in ("actor_profile", "info"):
                self._pkm_overlay_retire_for_target_v2479("search", reason="search_active_commit")
            self._pkm_swap_finish_v2479(
                search_swap_token_v2479, source_mode_v2479, "search", reason="search_active_commit"
            )
            _log("INLINE_SEARCH_EXCLUSIVE_SURFACE_BEGIN_V2479 old_scene_hidden_after_target_ready=1 swap_guard=0")
        except Exception:
            pass
        try:
            kb = self.getControl(SEARCH_KEYBOARD_ID)
            if kb.size() > 0:
                kb.selectItem(0)
            # Initial entry only.  After this, XML onleft/onright/onup/ondown owns navigation.
            self.setProperty("PlexKM.Search.KbOpen", "1")
            self.setFocusId(SEARCH_KEYBOARD_ID)
        except Exception:
            _log("INLINE_SEARCH_INITIAL_FOCUS_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        _log("INLINE_SEARCH_OPEN focus=%s" % self._safe_focus_id())

    def _search_prewarm_db_r95(self, reason=""):
        """R95: read the search DB file once, sequentially, off the GUI thread.

        Shield measurement: the first query after start read the 58MB DB as
        random pages from /sdcard and took 31.4s (the next query: 87ms).  A
        sequential read fills the OS page cache in a few seconds, so the first
        key press already hits a warm DB.  Read-only; no SQLite handle."""
        now = time.time()
        if now - float(getattr(self, "_search_prewarm_at_r95", 0) or 0) < 300:
            return
        self._search_prewarm_at_r95 = now

        def _w():
            t0 = time.time()
            total = 0
            try:
                path = _ensure_core().search_db_path()
                for fp in (path, path + "-wal"):
                    try:
                        with open(fp, "rb") as fh:
                            while True:
                                chunk = fh.read(1024 * 1024)
                                if not chunk:
                                    break
                                total += len(chunk)
                    except (IOError, OSError):
                        pass
                _log("INLINE_SEARCH_DB_PREWARM_R95 reason=%s mb=%.1f ms=%d" % (reason or "", total / 1048576.0, int((time.time() - t0) * 1000)))
            except Exception:
                self._search_prewarm_at_r95 = 0
                _log("INLINE_SEARCH_DB_PREWARM_FAILED_R95 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        threading.Thread(target=_w, name="PKMSearchPrewarmR95", daemon=True).start()

    def _search_schedule_index_refresh(self, reason=""):
        """Refresh the search DB only after Search is closed.

        v1883 rule:
        - never run a search-index refresh while inline Search is open
        - keep the current DB usable for immediate querying
        - defer the refresh until the user closes Search
        """
        try:
            _reason_v1883 = str(reason or "")
            if _reason_v1883 in ("search_fixed_focus", "inline_search_open") or getattr(self, "_search_inline_active", False):
                self._search_index_refresh_deferred_v1879 = True
                _log("INLINE_SEARCH_INDEX_REFRESH_DEFER_V1883 reason=%s active_or_entering_search=1" % (_reason_v1883 or ""))
                return
            if getattr(self, "_search_index_refresh_running", False):
                _log("INLINE_SEARCH_INDEX_REFRESH_SKIP reason=%s state=running" % (reason or ""))
                return
            self._search_index_refresh_running = True
            self._search_index_ready = False
            try:
                self.setProperty("PlexKM.Search.Indexing", "1")
                xbmcgui.Window(10000).setProperty("PlexKM.Search.Indexing", "1")
            except Exception:
                pass
        except Exception:
            pass

        def _worker():
            started = time.time()
            try:
                _log("INLINE_SEARCH_INDEX_REFRESH_BEGIN reason=%s mode=background" % (reason or ""))
                _ensure_core().ensure_search_db_from_items(force=False, show_progress=False)
                elapsed = int((time.time() - started) * 1000)
                try:
                    self._search_index_ready = True
                    self._search_index_refresh_deferred_v1879 = False
                    self._search_index_last_done_v1879 = time.monotonic()
                except Exception:
                    pass
                _log("INLINE_SEARCH_INDEX_REFRESH_DONE reason=%s ms=%d ready=1" % (reason or "", elapsed))
            except Exception:
                try:
                    self._search_index_ready = True
                except Exception:
                    pass
                _log("INLINE_SEARCH_INDEX_REFRESH_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            finally:
                try:
                    self._search_index_refresh_running = False
                    self.setProperty("PlexKM.Search.Indexing", "")
                    self.clearProperty("PlexKM.Search.Indexing")
                    xbmcgui.Window(10000).clearProperty("PlexKM.Search.Indexing")
                except Exception:
                    pass
                try:
                    if getattr(self, "_search_inline_active", False):
                        # Do not disturb the current results when the background
                        # refresh finishes.  It is only a silent DB refresh; the
                        # next key/input will query the latest index.
                        self._search_refresh_query_label()
                        _log("INLINE_SEARCH_INDEX_REFRESH_UI_CLEAR reason=%s active=1" % (reason or ""))
                except Exception:
                    _log("INLINE_SEARCH_INDEX_REFRESH_UI_CLEAR_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

        try:
            t = _PKMHomeThreadV2151(target=_worker, name="PlexKMSearchIndexRefresh", daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            try:
                self._search_index_refresh_running = False
                self._search_index_ready = True
                self.setProperty("PlexKM.Search.Indexing", "")
                self.clearProperty("PlexKM.Search.Indexing")
                xbmcgui.Window(10000).clearProperty("PlexKM.Search.Indexing")
            except Exception:
                pass
            _log("INLINE_SEARCH_INDEX_REFRESH_THREAD_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _close_inline_search(self, reason=""):
        try:
            self.clearProperty("PlexKM.Search.KbOpen")
            for _n_r96 in range(1, 9):
                self.clearProperty("PlexKM.Search.Sug%d" % _n_r96)
        except Exception:
            pass
        # v2479: Search remains the visible source until the Home target below it
        # has been restored and crossed a GUI frame.
        try:
            self._search_commit_history(self._search_query, reason="close")
        except Exception:
            pass
        # Keep the logical Search session active until the visual A/B commit.
        self._search_poster_render_token_v1881 = "search_close:%d" % self._now_ms()
        # v1883: invalidate both stages of the Search cast debounce before the
        # deferred index worker starts. A worker armed by the final arrow key
        # must never begin metadata/image work after Search has closed.
        self._search_focus_cast_token_v1878 = "search_close:%d" % self._now_ms()
        try:
            _actual_lock_v1883 = getattr(self, "_search_actual_focus_lock_v1883", None)
            if _actual_lock_v1883 is not None:
                with _actual_lock_v1883:
                    self._search_actual_focus_pending_v1883 = {}
            else:
                self._search_actual_focus_pending_v1883 = {}
        except Exception:
            self._search_actual_focus_pending_v1883 = {}
        # v2479: deferred index refresh starts only after Search has visually
        # retired; it must not compete with the hidden Home target bind.
        try:
            self.setProperty("PlexKM.Search.Closing", "1")
            xbmcgui.Window(10000).setProperty("PlexKM.Search.Closing", "1")
        except Exception:
            pass
        def _clear_search_closing_flag():
            try:
                xbmc.sleep(230)
                self.setProperty("PlexKM.Search.Closing", "")
                self.clearProperty("PlexKM.Search.Closing")
                xbmcgui.Window(10000).clearProperty("PlexKM.Search.Closing")
            except Exception:
                pass

        try:
            t = _PKMHomeThreadV2151(target=_clear_search_closing_flag, name="PlexKMSearchCloseOverlay", daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            _clear_search_closing_flag()
        try:
            # v618: Leaving search returns to the Home item in MENU_ID. Search itself is a fixed XML button.
            menu = self.getControl(MENU_ID)
            target = 0
            menu.selectItem(target)
            try:
                self.getControl(MENU_COLLAPSED_ID).selectItem(target)
            except Exception:
                pass
            self._last_menu_pos = target
            # v620: Closing inline search returns to the same Home menu index.
            # _refresh_for_menu_focus() intentionally skips same-index focus events,
            # so restore the Home content state here instead of relying on a duplicate
            # menu refresh.  This is not a focus workaround: search is an overlay and
            # closing it must leave the underlying Home view visible.
            try:
                self._show_home_wall(force=False)
                _log("INLINE_SEARCH_CLOSE_HOME_RESTORE_V2479 reason=%s target=home search_source_held=1" % (reason or ""))
            except Exception:
                _log("INLINE_SEARCH_CLOSE_HOME_RESTORE_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            search_close_swap_v2479 = self._pkm_swap_settle_v2479(
                "search", "home", reason="search_close_home_ready:%s" % (reason or ""), wait_ms=16
            )
            win_v2479 = xbmcgui.Window(10000)
            for target_v2479 in (self, win_v2479):
                target_v2479.clearProperty("PlexKM.Search.InlineActive")
                target_v2479.clearProperty("PlexKM.Search.SurfaceExclusiveV2054")
            self._pkm_swap_finish_v2479(
                search_close_swap_v2479, "search", "home", reason="search_close_commit:%s" % (reason or "")
            )
            self._search_inline_active = False
            try:
                if getattr(self, "_search_index_refresh_deferred_v1879", False):
                    self._search_schedule_index_refresh(reason="search_close_deferred_v2479")
            except Exception:
                pass
            self._focus_menu_control_v1993(reason="direct_menu_handoff_v1993")
        except Exception:
            pass
        # Search native lists are retired only after the target is visible.
        self._search_yt_token = int(getattr(self, "_search_yt_token", 0) or 0) + 1
        for _cid_pkm in SEARCH_RESULT_IDS:
            try:
                self.getControl(_cid_pkm).reset()
            except Exception:
                pass
        _log("INLINE_SEARCH_CLOSE reason=%s focus=%s ab_swap_v2479=1" % (reason or "", self._safe_focus_id()))

    def _search_set_status(self, text):
        try:
            self.getControl(SEARCH_MODE_LABEL_ID).setLabel(text or "")
        except Exception:
            pass

    def _search_set_empty(self, text):
        # Status/help text is shown beside the simple input cursor, aligned to the
        # folded search icon height. The additional-results count uses 4100 and
        # is handled separately so it does not appear when there are no results.
        try:
            self.getControl(SEARCH_MODE_LABEL_ID).setLabel(text or "")
        except Exception:
            pass

    def _search_set_more_count(self, total_count=0):
        try:
            count = int(total_count or 0)
            label = ("추가 %d개 결과" % count) if count > 0 else ""
            self.getControl(SEARCH_EMPTY_LABEL_ID).setLabel(label)
        except Exception:
            pass

    def _search_refresh_query_label(self):
        try:
            query = self._search_query or ""
            self.getControl(SEARCH_QUERY_LABEL_ID).setLabel((query + " |") if query else "|")
        except Exception:
            pass
        try:
            self.setProperty("PlexKM.Search.QueryText", query or "검색어 입력")
        except Exception:
            pass
        # Keep the input area minimal like the reference layout.
        self._search_set_status("")


    def _search_history_path(self):
        try:
            profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
        except Exception:
            try:
                profile = xbmc.translatePath("special://profile/addon_data/plugin.video.km/")
            except Exception:
                profile = os.path.join(os.path.expanduser("~"), ".kodi", "userdata", "addon_data", "plugin.video.km")
        try:
            if profile and not os.path.isdir(profile):
                os.makedirs(profile, exist_ok=True)
        except Exception:
            pass
        return os.path.join(profile, "search_history.json")

    def _search_load_history(self):
        if getattr(self, "_search_history_loaded", False):
            return list(getattr(self, "_search_history", []) or [])
        items = []
        try:
            path = self._search_history_path()
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    for value in data:
                        text = " ".join(str(value or "").split())
                        if text and text not in items:
                            items.append(text)
        except Exception:
            _log("INLINE_SEARCH_HISTORY_LOAD_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        self._search_history = items[:8]
        self._search_history_loaded = True
        return list(self._search_history)

    def _search_save_history(self):
        try:
            path = self._search_history_path()
            with open(path, "w", encoding="utf-8") as f:
                json.dump(list(getattr(self, "_search_history", []) or [])[:8], f, ensure_ascii=False, indent=2)
        except Exception:
            _log("INLINE_SEARCH_HISTORY_SAVE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_history_should_save(self, query):
        q = " ".join(str(query or "").split())
        if not q:
            return False
        # Avoid saving single ASCII/numeric intermediate key presses, but keep
        # short Korean searches such as a one-syllable title.
        if len(q) < 2 and all(ord(ch) < 128 for ch in q):
            return False
        return True

    def _search_commit_history(self, query, reason=""):
        q = " ".join(str(query or "").split())
        if not self._search_history_should_save(q):
            return
        items = self._search_load_history()
        items = [v for v in items if v != q]
        items.insert(0, q)
        self._search_history = items[:8]
        self._search_history_loaded = True
        self._search_save_history()
        self._search_populate_history()
        _log("INLINE_SEARCH_HISTORY_SAVE reason=%s query=%s count=%d" % (reason or "", _short_log_value(q), len(self._search_history)))

    def _search_populate_history(self):
        try:
            ctrl = self.getControl(SEARCH_HISTORY_ID)
        except Exception:
            return
        try:
            ctrl.reset()
        except Exception:
            pass
        items = self._search_load_history()
        if not items:
            try:
                self.setProperty("PlexKM.Search.HasHistory", "")
                self.clearProperty("PlexKM.Search.HasHistory")
            except Exception:
                pass
            return
        try:
            for q in items[:8]:
                li = xbmcgui.ListItem(label=q)
                li.setProperty("SearchHistoryQuery", q)
                li.setProperty("SearchHistoryKind", "query")
                li.setArt({"icon": "special://home/addons/plugin.video.km/resources/skins/Default/media/search/keyboard/history_icon.png"})
                ctrl.addItem(li)
            self.setProperty("PlexKM.Search.HasHistory", "1")
            _log("INLINE_SEARCH_HISTORY_POPULATE rows=%d clear=fixed_bottom" % len(items[:8]))
        except Exception:
            _log("INLINE_SEARCH_HISTORY_POPULATE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_handle_history_click(self):
        try:
            ctrl = self.getControl(SEARCH_HISTORY_ID)
            li = ctrl.getSelectedItem()
        except Exception:
            li = None
        if not li:
            return
        kind = li.getProperty("SearchHistoryKind") or "query"
        if kind == "clear":
            self._search_clear_history(reason="history_panel_legacy")
            return
        q = li.getProperty("SearchHistoryQuery") or li.getLabel() or ""
        q = " ".join(str(q or "").split())
        if not q:
            return
        self._search_query = q
        self._search_query_tokens = list(q)
        self._search_refresh_query_label()
        self._search_run_query()
        self._search_commit_history(q, reason="history_select")
        _log("INLINE_SEARCH_HISTORY_SELECT query=%s" % _short_log_value(q))

    def _search_clear_history(self, reason=""):
        try:
            self._search_history = []
            self._search_history_loaded = True
            self._search_save_history()
            self._search_populate_history()
            self._search_set_empty("")
            _log("INLINE_SEARCH_HISTORY_CLEAR reason=%s clear=fixed_bottom" % (reason or ""))
            try:
                self.setFocusId(SEARCH_KEYBOARD_ID)
            except Exception:
                pass
        except Exception:
            _log("INLINE_SEARCH_HISTORY_CLEAR_FAILED reason=%s err=%s" % (reason or "", traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)

    def _search_get_keys(self):
        if self._search_mode == "KO":
            return self._SEARCH_KEYS_KO_SHIFT if getattr(self, "_search_shift", False) else self._SEARCH_KEYS_KO_NORMAL
        return self._SEARCH_KEYS.get(self._search_mode, [])

    def _search_populate_keyboard(self):
        try:
            ctrl = self.getControl(SEARCH_KEYBOARD_ID)
            old_pos = 0
            try:
                old_pos = max(0, ctrl.getSelectedPosition())
            except Exception:
                old_pos = 0
            ctrl.reset()
            for key in self._search_get_keys():
                display = self._SEARCH_KEY_DISPLAY_LABELS.get(key, key)
                li = xbmcgui.ListItem(label=display)
                li.setProperty("SearchKey", key)
                li.setProperty("SearchLabel", display)
                li.setProperty("SearchMode", self._search_mode)
                ctrl.addItem(li)
            if ctrl.size() > 0:
                ctrl.selectItem(min(old_pos, ctrl.size() - 1))
        except Exception:
            _log("INLINE_SEARCH_KEYBOARD_POPULATE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_clear_results(self, text=""):
        self._search_poster_render_token_v1881 = "search_clear:%d" % self._now_ms()
        self._search_yt_token = int(getattr(self, "_search_yt_token", 0) or 0) + 1
        for cid in SEARCH_RESULT_IDS:
            try:
                self.getControl(cid).reset()
            except Exception:
                pass
        self._search_results = []
        self._search_yt_items = []
        self._search_yt_loading = False
        self._search_yt_skipped = False
        self._search_set_more_count(0)
        self._search_publish_state()
        self._search_set_empty(text or "")

    def _search_compose_syllable(self, cho, jung, jong=""):
        try:
            return chr(0xAC00 + (self._SEARCH_CHO.index(cho) * 21 + self._SEARCH_JUNG.index(jung)) * 28 + self._SEARCH_JONG.index(jong or ""))
        except Exception:
            return (cho or "") + (jung or "") + (jong or "")

    def _search_recompose_query(self):
        out = []
        L = V = T = None

        def commit():
            nonlocal L, V, T
            if L and V:
                out.append(self._search_compose_syllable(L, V, T or ""))
            elif L:
                out.append(L)
            elif V:
                out.append(V)
            L = V = T = None

        for token in self._search_query_tokens:
            ch = token or ""
            if len(ch) != 1:
                commit(); out.append(ch); continue

            if ch in self._SEARCH_KO_CONSONANTS:
                if L is None:
                    L = ch
                elif V is None:
                    combined = self._SEARCH_CHO_COMBINE.get((L, ch))
                    if combined:
                        L = combined
                    else:
                        out.append(L); L = ch
                elif T is None and ch in self._SEARCH_JONG:
                    T = ch
                elif T is not None:
                    combined = self._SEARCH_JONG_COMBINE.get((T, ch))
                    if combined:
                        T = combined
                    else:
                        commit(); L = ch
                else:
                    commit(); L = ch

            elif ch in self._SEARCH_KO_VOWELS:
                if L is None:
                    if V is None:
                        V = ch
                    else:
                        combined = self._SEARCH_VOWEL_COMBINE.get((V, ch))
                        if combined:
                            V = combined
                        else:
                            commit(); V = ch
                elif V is None:
                    V = ch
                elif T is None:
                    combined = self._SEARCH_VOWEL_COMBINE.get((V, ch))
                    if combined:
                        V = combined
                    else:
                        commit(); V = ch
                else:
                    # Final consonant followed by a vowel starts the next syllable.
                    # 겹받침이면 앞부분은 이전 글자의 받침으로 남기고 뒷부분만 다음 초성으로 보낸다.
                    if T in self._SEARCH_JONG_SPLIT:
                        left_final, next_initial = self._SEARCH_JONG_SPLIT[T]
                        out.append(self._search_compose_syllable(L, V, left_final))
                        L, V, T = next_initial, ch, None
                    else:
                        next_initial = T
                        out.append(self._search_compose_syllable(L, V, ""))
                        L, V, T = next_initial, ch, None
            else:
                commit(); out.append(ch)

        commit()
        self._search_query = "".join(out)

    def _search_append_token(self, token):
        self._search_query_tokens.append(token)
        self._search_recompose_query()

    def _search_delete_token(self):
        if self._search_query_tokens:
            self._search_query_tokens.pop()
            self._search_recompose_query()
        else:
            self._search_query = self._search_query[:-1]

    # R74: on Kodi PC (and some Android builds) one physical OK on the inline
    # search keyboard reaches Python twice: onClick(3000) and, right after it
    # returns, onAction(SELECT).  R29 pairing only clears the commit flag, so
    # both routes ran the key: ㄱ became ㄲ (ㄱ+ㄱ), ㄴ became ㄴㄴ, and the scope
    # toggle moved two steps.  A press runs once: the *other* route on the same
    # control within 0.25 s after the first route finished is the same press.
    # Two real presses each produce their own first route, so fast typing of
    # the same key still works; a platform that sends only one route is
    # unaffected because the drop needs a route switch.
    def _search_select_begin_r74(self, control_id, route):
        now = time.monotonic()
        last = getattr(self, "_search_select_last_r74", None)
        if (last and last[0] == control_id and last[1] != route
                and 0.0 <= now - last[2] <= 0.25):
            self._search_select_last_r74 = None
            _log("INLINE_SEARCH_SELECT_PAIR_DROP_R74 control=%s route=%s first_route=%s gap_ms=%d" % (
                control_id, route, last[1], int((now - last[2]) * 1000)))
            return False
        self._search_select_last_r74 = (control_id, route, now)
        return True

    def _search_select_end_r74(self, control_id, route):
        last = getattr(self, "_search_select_last_r74", None)
        if last and last[0] == control_id and last[1] == route:
            self._search_select_last_r74 = (control_id, route, time.monotonic())

    def _search_handle_key_click(self):
        try:
            li = self.getControl(SEARCH_KEYBOARD_ID).getSelectedItem()
            key = li.getProperty("SearchKey") or li.getLabel()
        except Exception:
            return
        if key == "한글":
            self._search_mode = "KO"; self._search_shift = False; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "영문":
            self._search_mode = "EN"; self._search_shift = False; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "숫자":
            self._search_mode = "NUM"; self._search_shift = False; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "기호":
            self._search_mode = "SYM"; self._search_shift = False; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "Shift" and self._search_mode == "KO":
            # Toggle to the Korean Shift page. Navigation remains XML-owned;
            # Python only rebuilds the key list for the inline keyboard.
            self._search_shift = True; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "기본" and self._search_mode == "KO":
            self._search_shift = False; self._search_populate_keyboard(); self._search_refresh_query_label(); return
        if key == "완료":
            self._search_commit_history(self._search_query, reason="complete")
            self._search_focus_results_from_complete(); return
        if key == "Space":
            self._search_append_token(" ")
        elif key == "Del":
            self._search_delete_token()
        elif key == "Clear":
            self._search_query_tokens = []
            self._search_query = ""
        else:
            # Keep the Shift page open until the user explicitly presses 기본.
            # This matches a visible alternate-keyboard page instead of one-shot
            # auto-return behavior.
            self._search_append_token(key)
        self._search_refresh_query_label()
        self._search_run_query_debounced_r82()

    def _search_run_query_debounced_r82(self, delay_ms=260):
        """R82: a keyboard press only updates the text; the search itself runs a
        moment later off the key handler.  A synchronous ~1s query made the R26
        input guard drop the NEXT key press as a replay (fast typing lost keys)."""
        tok = int(getattr(self, "_search_query_token_r82", 0) or 0) + 1
        self._search_query_token_r82 = tok
        lock = getattr(self, "_search_query_lock_r82", None)
        if lock is None:
            lock = threading.Lock()
            self._search_query_lock_r82 = lock

        def _w():
            try:
                xbmc.sleep(delay_ms)
                if tok != int(getattr(self, "_search_query_token_r82", 0) or 0):
                    return
                with lock:
                    if tok != int(getattr(self, "_search_query_token_r82", 0) or 0):
                        return
                    if not getattr(self, "_search_inline_active", False):
                        return
                    self._search_run_query()
            except Exception:
                _log("INLINE_SEARCH_DEBOUNCE_FAILED_R82 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        threading.Thread(target=_w, name="PKMSearchQueryR82", daemon=True).start()

    def _search_focus_results_from_complete(self):
        """Move focus from the inline keyboard to the first search result.

        This is only for the explicit 완료 key. Directional navigation is still
        handled by XML onleft/onright/onup/ondown.  PlexKM.Search.Enter (set by
        _search_publish_state) names the panel that should receive focus.
        """
        try:
            if not (self._search_query or "").strip():
                self._search_set_empty("검색어를 입력하세요")
                return
            if not getattr(self, "_search_results", None) and not getattr(self, "_search_yt_items", None):
                self._search_run_query()
            enter = str(self.getProperty("PlexKM.Search.Enter") or "")
            if not enter.isdigit() or int(enter) not in SEARCH_RESULT_IDS:
                self._search_set_empty("검색 결과 없음")
                _log("INLINE_SEARCH_COMPLETE_NO_RESULTS query=%s" % _short_log_value(self._search_query))
                return
            cid = int(enter)
            try:
                self.getControl(cid).selectItem(0)
            except Exception:
                pass
            self.clearProperty("PlexKM.Search.KbOpen")
            # R96: the same OK press reaches Python twice (onClick + onAction).
            # The second half must not land on the result we just focused
            # (Shield: 결과▶ started playing the best match 34ms later).
            self._search_enter_guard_ms_r96 = self._now_ms()
            self.setFocusId(cid)
            _log("INLINE_SEARCH_COMPLETE_TO_RESULTS query=%s focus=%s" % (_short_log_value(self._search_query), self._safe_focus_id()))
        except Exception:
            _log("INLINE_SEARCH_COMPLETE_TO_RESULTS_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_youtube_enabled(self):
        """설정 '통합 검색에 YouTube 포함' (기본 켬). 끄면 탭/줄/네트워크 호출 모두 없음."""
        try:
            v = xbmcaddon.Addon().getSetting("search_youtube")
        except Exception:
            v = ""
        return str(v or "").strip().lower() not in ("false", "0", "no", "off")

    def _search_publish_scope(self, reason=""):
        yt_on = self._search_youtube_enabled()
        scope = str(getattr(self, "_search_scope", "all") or "all")
        if scope not in ("all", "movie", "tv", "youtube") or (scope == "youtube" and not yt_on):
            scope = "all"
            self._search_scope = scope
        try:
            scope_label = {"all": "전체", "movie": "영화", "tv": "드라마", "youtube": "YouTube"}.get(scope, "전체")
            self.setProperty("PlexKM.Search.Scope", scope)
            self.setProperty("PlexKM.Search.ScopeLabel", scope_label)
            self.setProperty("PlexKM.Search.YtEnabled", "1" if yt_on else "")
            xbmcgui.Window(10000).setProperty("PlexKM.Search.Scope", scope)
            xbmcgui.Window(10000).setProperty("PlexKM.Search.ScopeLabel", scope_label)
        except Exception:
            pass
        _log("INLINE_SEARCH_SCOPE_PUBLISH_V1763 scope=%s yt=%d reason=%s" % (scope, 1 if yt_on else 0, reason or ""))

    def _search_set_scope(self, scope, reason=""):
        scope = str(scope or "all")
        if scope not in ("all", "movie", "tv", "youtube"):
            scope = "all"
        if scope == "youtube" and not self._search_youtube_enabled():
            scope = "all"
        changed = scope != str(getattr(self, "_search_scope", "all") or "all")
        self._search_scope = scope
        self._search_publish_scope(reason=reason or "set")
        if changed and (self._search_query or "").strip():
            # 이미 가져온 결과를 탭에 맞게 다시 배치할 뿐, 재검색하지 않는다.
            self._search_populate_results(list(getattr(self, "_search_results", []) or []))
        elif changed:
            self._search_clear_results("")
        _log("INLINE_SEARCH_SCOPE_CHANGED_V1763 scope=%s changed=%d query=%s" % (scope, 1 if changed else 0, _short_log_value(self._search_query or "")))

    def _search_filter_rows_for_scope(self, rows):
        # 통합 검색: 라이브러리 결과는 항상 movie/show 전체를 보관하고 탭에서 나눠 보여준다.
        out = []
        for row in rows or []:
            if self._search_row_type(row) in ("movie", "show"):
                out.append(row)
        return out

    def _search_row_type(self, row):
        try:
            return str((tuple(row or ()) + ("", "", ""))[2] or "").lower()
        except Exception:
            return ""

    def _search_run_query(self):
        q = (self._search_query or "").strip()
        if not q:
            self._search_clear_results("")
            return
        _search_busy_token_v1883 = ""
        try:
            _search_busy_token_v1883 = self._scene_busy_arm_v2482(
                reason="search_query:%s" % q, scope="search", owner=q,
                replace_scope=True, threshold_ms=1000
            )
        except Exception:
            pass
        try:
            # v1883: query the stable existing index. Refresh is deferred until
            # Search closes, so this foreground read never contends with a writer.
            if getattr(self, "_search_index_refresh_running", False) and not getattr(self, "_search_index_ready", False):
                try:
                    _log("INLINE_SEARCH_QUERY_DURING_INDEX query=%s mode=existing_index" % _short_log_value(q))
                except Exception:
                    pass
            raw_rows = _ensure_core().query_search_index(q, limit=240, scope="all") or []
            scoped_rows = self._search_filter_rows_for_scope(raw_rows)
            rows = self._search_dedupe_rows_by_title(scoped_rows)[:80]
            try:
                _log("INLINE_SEARCH_QUERY_COUNTS_V1763 query=%s scope=%s raw=%d scoped=%d unique=%d best=%d more=%d" % (_short_log_value(q), getattr(self, "_search_scope", "movie"), len(raw_rows or []), len(scoped_rows or []), len(rows or []), 1 if rows else 0, max(0, len(rows or []) - 1)))
            except Exception:
                pass
            self._search_results = rows
            self._search_start_youtube(q)
            self._search_populate_results(rows)
            self._search_schedule_visible_cast_prewarm_v1781(rows, q)
            self._search_set_empty("" if (rows or getattr(self, "_search_yt_items", None)) else "검색 결과 없음")
        except Exception:
            self._search_clear_results("검색 실패 - kodi.log 확인")
            _log("INLINE_SEARCH_QUERY_FAILED query=%s err=%s" % (_short_log_value(q), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGERROR)
        finally:
            try:
                self._scene_busy_finish_v2482(_search_busy_token_v1883, reason="search_query_done")
            except Exception:
                pass

    def _search_schedule_visible_cast_prewarm_v1781(self, rows, query):
        """Reset Search cast state without preparing any result speculatively.

        v1878 rule:
        - Publishing Search results must spend zero actor-photo work.
        - Best match and lower results are treated the same until the user focuses
          them with native Kodi navigation.
        - A focused item is prepared only after the shared 650ms focus-settle
          debounce, so fast directional movement cancels stale work instead of downloading actors
          for results the user may never open.
        """
        try:
            token = "%s:%s:%d" % (
                str(query or ""), str(getattr(self, "_search_scope", "movie") or "movie"), self._now_ms()
            )
            self._search_cast_prewarm_token_v1781 = token
            self._search_focus_cast_token_v1878 = ""
            removed = 0
            try:
                with self._info_cast_prewarm_lock:
                    old_q = list(getattr(self, "_info_cast_prewarm_queue", []) or [])
                    new_q = []
                    for item in old_q:
                        if str((item or {}).get("reason") or "").startswith("search_"):
                            removed += 1
                            continue
                        new_q.append(item)
                    self._info_cast_prewarm_queue = new_q
            except Exception:
                pass
            _log("INLINE_SEARCH_CAST_SPECULATIVE_DISABLED_V1878 query=%s results=%d removed=%d best_auto=0 lower_auto=0 focus_settle_ms=650" % (
                _short_log_value(query or "", 80), len(list(rows or [])), removed
            ))
        except Exception:
            _log("INLINE_SEARCH_CAST_SPECULATIVE_RESET_FAILED_V1878 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _search_schedule_focused_cast_v1878(self, li, reason="focus", settle_ms=650):
        """Prepare only the Search result the user has actually focused.

        The ListItem snapshot is captured on Kodi's GUI thread.  The worker waits
        briefly and checks a generation token before touching metadata/network, so
        rapid arrow-key movement produces no stale actor downloads and never moves
        focus from Python.
        """
        try:
            if li is None or not getattr(self, "_search_inline_active", False):
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            query_token = str(getattr(self, "_search_cast_prewarm_token_v1781", "") or "")
            focus_token = "%s:%s:%d" % (query_token, rk, self._now_ms())
            self._search_focus_cast_token_v1878 = focus_token
            data = {
                "rating_key": rk,
                "type": li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "",
                "title": li.getProperty("PlexKM.Title") or li.getLabel() or "",
                "parent_rating_key": li.getProperty("PlexKM.ParentRatingKey") or "",
                "grandparent_rating_key": li.getProperty("PlexKM.GrandparentRatingKey") or "",
                "section_id": li.getProperty("PlexKM.SectionId") or "",
                "reason": "search_focus_settled_v1878:%s" % (reason or "focus"),
                "priority": True,
                "search_token": query_token,
                "focus_token_v1883": focus_token,
            }
            _log("INLINE_SEARCH_CAST_FOCUS_ARM_V1878 rating_key=%s reason=%s settle_ms=%d" % (
                rk, reason or "focus", int(settle_ms or 0)
            ))
        except Exception:
            _log("INLINE_SEARCH_CAST_FOCUS_ARM_FAILED_V1878 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

        def _worker():
            claimed = False
            try:
                xbmc.sleep(max(0, int(settle_ms or 0)))
                if focus_token != str(getattr(self, "_search_focus_cast_token_v1878", "") or ""):
                    _log("INLINE_SEARCH_CAST_FOCUS_CANCEL_V1878 rating_key=%s reason=focus_changed" % rk)
                    return
                if query_token != str(getattr(self, "_search_cast_prewarm_token_v1781", "") or ""):
                    _log("INLINE_SEARCH_CAST_FOCUS_CANCEL_V1878 rating_key=%s reason=query_changed" % rk)
                    return
                if not getattr(self, "_search_inline_active", False):
                    return
                rec = (getattr(self, "_info_cast_prewarm_cache", {}) or {}).get(rk) or {}
                if isinstance(rec, dict) and _safe_int(rec.get("ready"), 0) > 0:
                    _log("INLINE_SEARCH_CAST_FOCUS_READY_V1878 rating_key=%s source=memory_cache" % rk)
                    return
                with self._info_cast_prewarm_lock:
                    running = getattr(self, "_info_cast_prewarm_running", None)
                    if not isinstance(running, set):
                        running = set()
                        self._info_cast_prewarm_running = running
                    if rk in running:
                        _log("INLINE_SEARCH_CAST_FOCUS_JOIN_V1878 rating_key=%s" % rk)
                        return
                    running.add(rk)
                    claimed = True
                started = time.time()
                ok = self._info_cast_prewarm_build_one(data)
                rec = (getattr(self, "_info_cast_prewarm_cache", {}) or {}).get(rk) or {}
                _log("INLINE_SEARCH_CAST_FOCUS_DONE_V1878 rating_key=%s ok=%d ready=%d elapsed_ms=%.1f reason=%s" % (
                    rk, 1 if ok else 0, _safe_int(rec.get("ready"), 0),
                    (time.time() - started) * 1000.0, reason or "focus"
                ))
            except Exception:
                _log("INLINE_SEARCH_CAST_FOCUS_FAILED_V1878 rating_key=%s err=%s" % (
                    rk, traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)
            finally:
                if claimed:
                    try:
                        with self._info_cast_prewarm_lock:
                            self._info_cast_prewarm_running.discard(rk)
                    except Exception:
                        pass

        _PKMHomeThreadV2151(target=_worker, name="PKMSearchFocusCastV1878", daemon=True).start()
        return True

    def _search_schedule_direction_target_cast_v1878(self, control_id, action_id):
        """Debounce native XML navigation, then read the actual focused item.

        No target is predicted and no focus is written from Python. Every new
        direction key invalidates the prior token immediately. One scheduler
        thread observes the final Kodi selection after 650ms of inactivity.
        """
        try:
            control_id = int(control_id or 0)
            action_id = int(action_id or 0)
            if control_id not in SEARCH_RESULT_IDS:
                return False
            lock = getattr(self, "_search_actual_focus_lock_v1883", None)
            if lock is None:
                self._search_actual_focus_lock_v1883 = threading.RLock()
                lock = self._search_actual_focus_lock_v1883
            token = "actual-focus:%s:%s:%d" % (control_id, action_id, self._now_ms())
            with lock:
                self._search_actual_focus_pending_v1883 = {
                    "token": token, "armed": time.monotonic(), "settle_ms": 650,
                    "reason": "direction_%s" % action_id,
                }
                # Invalidate an actor build that has not yet reached its next
                # cancellation checkpoint.
                self._search_focus_cast_token_v1878 = token
                if getattr(self, "_search_actual_focus_worker_running_v1883", False):
                    _log("INLINE_SEARCH_CAST_ACTUAL_REARM_V1883 token=%s action=%s" % (token, action_id))
                    return True
                self._search_actual_focus_worker_running_v1883 = True

            def _worker():
                try:
                    monitor = xbmc.Monitor()
                    while not monitor.abortRequested():
                        with lock:
                            pending = dict(getattr(self, "_search_actual_focus_pending_v1883", {}) or {})
                        if not pending:
                            return
                        elapsed = int((time.monotonic() - float(pending.get("armed") or 0.0)) * 1000.0)
                        remain = max(0, int(pending.get("settle_ms") or 650) - elapsed)
                        if remain > 0:
                            if monitor.waitForAbort(min(0.08, float(remain) / 1000.0)):
                                return
                            continue
                        with lock:
                            current = dict(getattr(self, "_search_actual_focus_pending_v1883", {}) or {})
                            if current.get("token") != pending.get("token"):
                                continue
                            self._search_actual_focus_pending_v1883 = {}
                        if not getattr(self, "_search_inline_active", False):
                            return
                        fid = self._safe_focus_id()
                        if fid not in SEARCH_RESULT_IDS:
                            _log("INLINE_SEARCH_CAST_ACTUAL_CANCEL_V1883 token=%s reason=focus_left_results focus=%s" % (pending.get("token"), fid))
                            continue
                        try:
                            li = self.getControl(fid).getSelectedItem()
                        except Exception:
                            li = None
                        if li is None:
                            continue
                        rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
                        _log("INLINE_SEARCH_CAST_ACTUAL_SETTLED_V1883 token=%s focus=%s rating_key=%s settle_ms=650" % (pending.get("token"), fid, rk))
                        self._search_schedule_focused_cast_v1878(
                            li, reason="actual_focus_v1883", settle_ms=0
                        )
                finally:
                    with lock:
                        self._search_actual_focus_worker_running_v1883 = False
                        restart = bool(getattr(self, "_search_actual_focus_pending_v1883", {}) or {})
                    if restart and getattr(self, "_search_inline_active", False):
                        # Re-enter through the same single-worker gate.
                        self._search_schedule_direction_target_cast_v1878(self._safe_focus_id(), 0)

            _PKMHomeThreadV2151(target=_worker, name="PKMSearchActualFocusV1883", daemon=True).start()
            return True
        except Exception:
            _log("INLINE_SEARCH_CAST_ACTUAL_ARM_FAILED_V1883 control=%s action=%s err=%s" % (
                control_id, action_id, traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _search_start_selected_cast_direct_v1875(self, li, reason=""):
        """Give the clicked Search result its own cast-prewarm lane.

        The visible Search prewarm is speculative and may still be occupied by
        earlier results.  Capture the selected ListItem on the GUI thread, cancel
        stale Search-only queue entries, and prepare only this rating key in a
        dedicated background thread.  No focus or ListItem mutation happens in
        the worker.
        """
        try:
            if li is None:
                return False
            rk = str(li.getProperty("PlexKM.RatingKey") or "").strip()
            if not rk:
                return False
            # Reuse the current query token. Replacing it here would mark an
            # already-running prewarm for this same selected item as stale, while
            # the direct lane sees the key as running and waits on nothing.
            token = str(getattr(self, "_search_cast_prewarm_token_v1781", "") or "")
            if not token:
                token = "search-selected-v1875:%s:%d" % (rk, self._now_ms())
                self._search_cast_prewarm_token_v1781 = token
            # v1883: a click supersedes any debounced focus-only actor job.
            # The stale worker observes this token at its next metadata/image
            # checkpoint and exits without publishing.
            self._search_focus_cast_token_v1878 = "selected:%s:%d" % (rk, self._now_ms())
            try:
                lock_v1883 = getattr(self, "_search_actual_focus_lock_v1883", None)
                if lock_v1883 is not None:
                    with lock_v1883:
                        self._search_actual_focus_pending_v1883 = {}
            except Exception:
                pass
            data = {
                "rating_key": rk,
                "type": li.getProperty("PlexKM.Type") or li.getProperty("PlexKM.KodiType") or "",
                "title": li.getProperty("PlexKM.Title") or li.getLabel() or "",
                "parent_rating_key": li.getProperty("PlexKM.ParentRatingKey") or "",
                "grandparent_rating_key": li.getProperty("PlexKM.GrandparentRatingKey") or "",
                "section_id": li.getProperty("PlexKM.SectionId") or "",
                "reason": "search_selected_direct_v1875:%s" % (reason or "click"),
                "priority": True,
                "search_token": token,
            }
            removed = 0
            try:
                with self._info_cast_prewarm_lock:
                    old_q = list(getattr(self, "_info_cast_prewarm_queue", []) or [])
                    new_q = []
                    for item in old_q:
                        item_rk = str((item or {}).get("rating_key") or "").strip()
                        item_reason = str((item or {}).get("reason") or "")
                        if item_rk == rk or item_reason.startswith("search_"):
                            removed += 1
                            continue
                        new_q.append(item)
                    self._info_cast_prewarm_queue = new_q
            except Exception:
                pass
            _log("INLINE_SEARCH_SELECTED_CAST_DIRECT_BEGIN_V1875 rating_key=%s removed=%d reason=%s" % (
                rk, removed, reason or "click"
            ))

            def _worker():
                started = time.time()
                claimed = False
                try:
                    # v1883: a stale focus worker may still be returning from its
                    # bounded Plex request. Wait briefly for its cancellation instead
                    # of abandoning the selected fast lane.
                    wait_started_v1883 = time.time()
                    while True:
                        with self._info_cast_prewarm_lock:
                            running = getattr(self, "_info_cast_prewarm_running", None)
                            if not isinstance(running, set):
                                running = set()
                                self._info_cast_prewarm_running = running
                            if rk not in running:
                                running.add(rk)
                                claimed = True
                                break
                        if (time.time() - wait_started_v1883) >= 0.75:
                            rec_wait = (getattr(self, "_info_cast_prewarm_cache", {}) or {}).get(rk) or {}
                            _log("INLINE_SEARCH_SELECTED_CAST_DIRECT_JOIN_V1883 rating_key=%s wait_ms=750 ready=%d" % (
                                rk, _safe_int(rec_wait.get("ready"), 0)
                            ))
                            return
                        xbmc.sleep(25)
                    ok = self._info_cast_prewarm_build_one(data)
                    rec = (getattr(self, "_info_cast_prewarm_cache", {}) or {}).get(rk) or {}
                    _log("INLINE_SEARCH_SELECTED_CAST_DIRECT_DONE_V1875 rating_key=%s ok=%d ready=%d elapsed_ms=%.1f" % (
                        rk, 1 if ok else 0, _safe_int(rec.get("ready"), 0), (time.time() - started) * 1000.0
                    ))
                except Exception:
                    _log("INLINE_SEARCH_SELECTED_CAST_DIRECT_FAILED_V1875 rating_key=%s err=%s" % (
                        rk, traceback.format_exc().replace(chr(10), " | ")
                    ), xbmc.LOGWARNING)
                finally:
                    if claimed:
                        try:
                            with self._info_cast_prewarm_lock:
                                self._info_cast_prewarm_running.discard(rk)
                        except Exception:
                            pass

            _PKMHomeThreadV2151(target=_worker, name="PKMSearchSelectedCastV1875", daemon=True).start()
            return True
        except Exception:
            _log("INLINE_SEARCH_SELECTED_CAST_DIRECT_START_FAILED_V1875 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return False

    def _search_row_title_key(self, row):
        try:
            row = tuple(row or ())
            title = row[4] if len(row) > 4 else ""
            original_title = row[5] if len(row) > 5 else ""
            sort_title = row[6] if len(row) > 6 else ""
            rating_key = row[0] if len(row) > 0 else ""
            text = title or original_title or sort_title or ""
            text = " ".join(str(text or "").split()).casefold()
            if text:
                return text
            return "rating:%s" % str(rating_key or id(row))
        except Exception:
            return "row:%s" % id(row)

    def _search_dedupe_rows_by_title(self, rows):
        unique_rows = []
        seen = set()
        removed = 0
        try:
            for row in rows or []:
                key = self._search_row_title_key(row)
                if key in seen:
                    removed += 1
                    continue
                seen.add(key)
                unique_rows.append(row)
            if removed:
                _log("INLINE_SEARCH_DEDUPE_TITLE raw=%d unique=%d removed=%d" % (len(rows or []), len(unique_rows), removed))
        except Exception:
            _log("INLINE_SEARCH_DEDUPE_TITLE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return list(rows or [])
        return unique_rows

    def _search_trim_summary_3lines(self, text, limit=112):
        """Return a visual 3-line summary with an explicit ellipsis.

        Kodi textbox controls clip overflowing text without adding an ellipsis, so
        the search card prepares a shorter 3-line string here. 112 chars is tuned
        for the current 850px/font12 summary area.
        """
        text = " ".join(str(text or "").split())
        if len(text) > limit:
            return text[:max(0, limit - 3)].rstrip() + "..."
        return text

    def _search_duration_text(self, seconds):
        try:
            sec = int(float(seconds or 0))
        except Exception:
            sec = 0
        if sec <= 0:
            return ""
        minutes = sec // 60
        if minutes <= 0:
            return ""
        return "%d분" % minutes

    def _search_poster_remote_url_v1879(self, source, rating_key=""):
        """Return a small Plex transcode URL for Search posters only.

        Global PKM artwork stays in the configured direct/transcode mode. Search
        cards are much smaller than Home artwork, so sending an original PMS
        poster through Kodi's image loader wastes network and decode time. This
        helper normalizes only URLs belonging to the configured Plex server and
        requests a fixed 360x540 image. External/local artwork is left unchanged.
        """
        value = str(source or "").strip()
        if not value:
            return ""
        lower = value.lower()
        if lower.startswith(("special://", "resource://", "image://", "file://")):
            return value
        try:
            c = _ensure_core()
            server = str(c.clean_server_url() or "").rstrip("/")
            original_path = ""
            if value.startswith("/"):
                parsed = urlsplit(value)
                original_path = parsed.path or ""
                query = dict(parse_qsl(parsed.query or "", keep_blank_values=True))
            elif lower.startswith(("http://", "https://")):
                parsed = urlsplit(value)
                server_parts = urlsplit(server) if server else None
                same_server = bool(
                    server_parts and parsed.netloc and
                    parsed.netloc.lower() == server_parts.netloc.lower()
                )
                if not same_server:
                    return _clean_external_image_url(value)
                original_path = parsed.path or ""
                query = dict(parse_qsl(parsed.query or "", keep_blank_values=True))
            else:
                return value

            if original_path.rstrip("/") == "/photo/:/transcode":
                nested = str(query.get("url") or "").strip()
                if nested:
                    nested_parts = urlsplit(nested)
                    original_path = nested_parts.path or nested
            if not original_path and rating_key:
                original_path = "/library/metadata/%s/thumb" % str(rating_key)
            if not original_path:
                return value
            return c.plex_url(
                "/photo/:/transcode",
                params={
                    "width": 360,
                    "height": 540,
                    "minSize": 1,
                    "upscale": 0,
                    "url": original_path,
                },
                include_token=True,
            )
        except Exception:
            return value

    def _search_prepare_cached_visible_exact_v1879(self, listitems):
        """Mark already-local Search posters ready without conversion.

        v2147 keeps the historical function name/property contract for callers but
        removes the former worker-side PIL conversion entirely. A verified local
        image is bound directly and Kodi owns final poster geometry.
        """
        started = _pkm_speed_ms()
        ready = 0
        for li in list(listitems or []):
            try:
                kind = str(li.getProperty("PlexKM.SearchPosterCacheV1877") or "remote")
                source = str(li.getArt("poster") or "").strip()
                if kind != "source" or not self._local_portrait_poster_file_ready_v2498(source):
                    continue
                fanart = li.getArt("fanart") or ""
                li.setArt({"poster": source, "thumb": source, "icon": source, "fanart": fanart})
                li.setProperty("PlexKM.Thumb", source)
                li.setProperty("PlexKM.SearchPosterCacheV1877", "source")
                li.setProperty("PlexKM.ViewportTextureV1866", "1")
                ready += 1
            except Exception:
                pass
        _log("INLINE_SEARCH_LOCAL_READY_V2147 requested=%d ready=%d wait_ms=%d network=0 pil=0 workers=0 kodi_geometry_owner=1" % (
            len(list(listitems or [])), ready, _pkm_speed_ms() - started
        ))
        return ready

    def _search_texture_ready_flags_v1881(self, items):
        """Return per-poster readiness from local files and Kodi Textures13.

        This function is worker-safe: it operates only on immutable snapshots,
        filesystem state, and Textures13.db. A remote poster is counted ready only
        when Textures13 points to a non-empty thumbnail file on disk, not merely
        when the URL row exists.
        """
        snapshots = list(items or [])
        if not snapshots:
            return []
        remote_values = []
        local_ready = set()
        for item in snapshots:
            for value in (item.get("primary"), item.get("fallback")):
                value = str(value or "").strip()
                if not value:
                    continue
                if value.startswith(("http://", "https://")):
                    if value not in remote_values:
                        remote_values.append(value)
                else:
                    try:
                        translated = xbmcvfs.translatePath(value)
                    except Exception:
                        translated = value
                    try:
                        if translated and (xbmcvfs.exists(translated) or os.path.exists(translated)):
                            if os.path.exists(translated):
                                if os.path.getsize(translated) > 0:
                                    local_ready.add(value)
                            else:
                                local_ready.add(value)
                    except Exception:
                        pass

        cached_ready = set()
        if remote_values:
            try:
                db_path = xbmcvfs.translatePath("special://database/Textures13.db")
            except Exception:
                db_path = ""
            if db_path and os.path.exists(db_path):
                try:
                    conn = _pkm_ro_connect(db_path, timeout=0.08)
                    try:
                        step = 80
                        for start in range(0, len(remote_values), step):
                            chunk = remote_values[start:start + step]
                            marks = ",".join("?" for _ in chunk)
                            query = "SELECT url,cachedurl FROM texture WHERE url IN (%s)" % marks
                            for url, cachedurl in conn.execute(query, tuple(chunk)).fetchall():
                                cachedurl = str(cachedurl or "").strip()
                                if not cachedurl:
                                    continue
                                try:
                                    thumb_path = xbmcvfs.translatePath(
                                        "special://thumbnails/" + cachedurl.replace("\\", "/")
                                    )
                                except Exception:
                                    thumb_path = ""
                                try:
                                    if thumb_path and os.path.exists(thumb_path) and os.path.getsize(thumb_path) > 0:
                                        cached_ready.add(str(url or ""))
                                except Exception:
                                    pass
                    finally:
                        conn.close()
                except Exception:
                    # Texture DB can be briefly locked by Kodi while it commits a
                    # newly downloaded image. The next monitor poll retries.
                    pass

        flags = []
        for item in snapshots:
            values = [str(item.get("primary") or "").strip(), str(item.get("fallback") or "").strip()]
            values = [value for value in values if value]
            flags.append(bool(values and any(value in local_ready or value in cached_ready for value in values)))
        return flags

    def _search_start_visible_poster_monitor_v1881(self, listitems, query="", scope=""):
        """Measure when all currently visible Search poster textures are ready.

        The timer begins immediately after Kodi's result controls receive the new
        ListItems. Completion means every primary/fallback poster has a real local
        file (direct PKM cache or Kodi Textures13 cache) and the complete state has
        remained stable for 160ms. This excludes query/ListItem construction time
        and captures the asynchronous Kodi image-download/decode interval that was
        missing from v1879 logs.
        """
        try:
            snapshots = []
            for position, li in enumerate(list(listitems or [])):
                try:
                    snapshots.append({
                        "position": int(position),
                        "rating_key": str(li.getProperty("PlexKM.RatingKey") or ""),
                        "title": str(li.getProperty("PlexKM.Title") or li.getLabel() or ""),
                        "primary": str(li.getArt("poster") or li.getArt("thumb") or "").strip(),
                        "fallback": str(li.getProperty("PlexKM.PosterFallbackArt") or "").strip(),
                        "kind": str(li.getProperty("PlexKM.SearchPosterCacheV1877") or "remote"),
                    })
                except Exception:
                    pass
            if not snapshots:
                return
            self._search_poster_render_seq_v1881 = int(getattr(self, "_search_poster_render_seq_v1881", 0) or 0) + 1
            started_ms = self._now_ms()
            token = "%s:%s:%d:%d" % (
                str(query or ""), str(scope or ""), self._search_poster_render_seq_v1881, started_ms
            )
            self._search_poster_render_token_v1881 = token
            initial_flags = self._search_texture_ready_flags_v1881(snapshots)
            initial_ready = sum(1 for value in initial_flags if value)
            total = len(snapshots)
            remote_total = sum(1 for item in snapshots if item.get("kind") == "remote")
            _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_BEGIN_V1881 query=%s scope=%s requested=%d initial_ready=%d remote_total=%d pending_total=%d panel_attached=1 measurement=textures13_file_plus_160ms_settle" % (
                _short_log_value(query or "", 80), str(scope or ""), total, initial_ready,
                remote_total, max(0, total - initial_ready)
            ))
        except Exception:
            _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_BEGIN_FAILED_V1881 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)
            return

        generation_v1841 = int(getattr(self, "_lifecycle_generation_v1841", 0) or 0)

        def _worker():
            monitor_v1881 = xbmc.Monitor()
            last_flags = list(initial_flags)
            first_remote_ready_ms = -1
            first_row_ready_ms = -1
            stable_since_ms = 0
            last_ready = initial_ready
            try:
                while self._worker_alive_v1841(generation_v1841):
                    now_ms = self._now_ms()
                    elapsed_ms = now_ms - started_ms
                    if token != str(getattr(self, "_search_poster_render_token_v1881", "") or ""):
                        _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_CANCEL_V1881 query=%s reason=new_query elapsed_ms=%d ready=%d requested=%d" % (
                            _short_log_value(query or "", 80), elapsed_ms, last_ready, total
                        ))
                        return
                    if not bool(getattr(self, "_search_inline_active", False)):
                        _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_CANCEL_V1881 query=%s reason=search_closed elapsed_ms=%d ready=%d requested=%d" % (
                            _short_log_value(query or "", 80), elapsed_ms, last_ready, total
                        ))
                        return

                    flags = self._search_texture_ready_flags_v1881(snapshots)
                    ready = sum(1 for value in flags if value)
                    newly_ready = [idx for idx, value in enumerate(flags) if value and (idx >= len(last_flags) or not last_flags[idx])]
                    for idx in newly_ready:
                        item = snapshots[idx]
                        if first_remote_ready_ms < 0 and item.get("kind") == "remote":
                            first_remote_ready_ms = elapsed_ms
                        _log("INLINE_SEARCH_POSTER_TEXTURE_READY_V1881 query=%s position=%d ready=%d/%d elapsed_ms=%d rating_key=%s title=%s source=%s" % (
                            _short_log_value(query or "", 80), idx, ready, total, elapsed_ms,
                            str(item.get("rating_key") or ""), _short_log_value(item.get("title") or "", 80),
                            str(item.get("kind") or "")
                        ))
                    first_row_count = min(7, total)
                    if first_row_ready_ms < 0 and first_row_count > 0 and all(flags[:first_row_count]):
                        first_row_ready_ms = elapsed_ms
                        _log("INLINE_SEARCH_POSTER_FIRST_ROW_VISIBLE_V1881 query=%s ready=%d requested=%d elapsed_ms=%d" % (
                            _short_log_value(query or "", 80), first_row_count, total, elapsed_ms
                        ))

                    if ready == total:
                        if not stable_since_ms:
                            stable_since_ms = now_ms
                        if now_ms - stable_since_ms >= 160:
                            total_elapsed_ms = now_ms - started_ms
                            _log("INLINE_SEARCH_POSTER_VISIBLE_COMPLETE_V1881 query=%s scope=%s requested=%d ready=%d initial_ready=%d remote_total=%d first_remote_ms=%d first_row_ms=%d elapsed_ms=%d settle_ms=%d measurement=textures13_file_plus_render_settle" % (
                                _short_log_value(query or "", 80), str(scope or ""), total, ready,
                                initial_ready, remote_total, first_remote_ready_ms, first_row_ready_ms,
                                total_elapsed_ms, now_ms - stable_since_ms
                            ))
                            return
                    else:
                        stable_since_ms = 0
                    last_flags = list(flags)
                    last_ready = ready
                    if elapsed_ms >= 15000:
                        missing = []
                        for idx, value in enumerate(flags):
                            if value:
                                continue
                            item = snapshots[idx]
                            missing.append("%d:%s:%s" % (
                                idx, str(item.get("rating_key") or ""),
                                str(item.get("title") or "").replace("|", " ")[:40]
                            ))
                        _log("INLINE_SEARCH_POSTER_VISIBLE_TIMEOUT_V1881 query=%s requested=%d ready=%d elapsed_ms=%d missing=%s" % (
                            _short_log_value(query or "", 80), total, ready, elapsed_ms,
                            "|".join(missing)
                        ), xbmc.LOGWARNING)
                        return
                    if monitor_v1881.waitForAbort(0.08):
                        return
            except Exception:
                _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_FAILED_V1881 query=%s err=%s" % (
                    _short_log_value(query or "", 80), traceback.format_exc().replace(chr(10), " | ")
                ), xbmc.LOGWARNING)

        try:
            t = _PKMHomeThreadV2151(target=_worker, name="PlexKMSearchPosterVisibleV1881", daemon=True)
            t.daemon = True
            t.start()
        except Exception:
            _log("INLINE_SEARCH_POSTER_VISIBLE_MONITOR_THREAD_FAILED_V1881 err=%s" % (
                traceback.format_exc().replace(chr(10), " | ")
            ), xbmc.LOGWARNING)

    def _search_cached_poster_display_v1877(self, thumb, art):
        """Return a cached portrait poster only; ``art`` is never poster authority.

        v2498 keeps Search under the same poster/fanart role contract as Home and
        Library. The second argument is retained for call compatibility only.
        """
        try:
            source = str(thumb or "").strip()
            if source:
                cached_source = self._cached_poster_source_path_v1871(source)
                if cached_source and self._local_portrait_poster_file_ready_v2498(cached_source):
                    return cached_source, "source"
        except Exception:
            pass
        return "", "remote"

    def _search_row_to_listitem(self, row, check_local_cache_v1879=True):
        row = tuple(row or ())
        rating_key, section_id, plex_type, kodi_type, title, original_title, sort_title, year, summary, duration, added_at, updated_at, thumb, art, media_file, part_key, view_count, last_viewed_at, show_title, season, episode = row[:21]
        parent_rating_key = row[21] if len(row) > 21 else ""
        grandparent_rating_key = row[22] if len(row) > 22 else ""
        section_title = row[23] if len(row) > 23 else ""
        if part_key and plex_type in ("movie", "episode"):
            url = _pkm_play_url(rating_key, part_key, mode="start")
        elif plex_type == "show":
            url = _ensure_core().build_plugin_url({"action": "show", "rating_key": rating_key, "section_id": section_id})
        else:
            url = _ensure_core().build_plugin_url({"action": "noop"})
        li = xbmcgui.ListItem(label=title or "", path=url)
        try:
            li.setPath(url)
        except Exception:
            pass
        search_remote_v1879 = self._search_poster_remote_url_v1879(thumb, rating_key) or thumb or ""
        if check_local_cache_v1879:
            display_poster_v1877, poster_cache_kind_v1877 = self._search_cached_poster_display_v1877(thumb, art)
        else:
            display_poster_v1877, poster_cache_kind_v1877 = "", "remote"
        display_poster_v1877 = display_poster_v1877 or search_remote_v1879 or thumb or ""
        # v2498: never substitute Search fanart for a portrait result card.
        fallback_poster_v1877 = search_remote_v1879 if search_remote_v1879 else ""
        li.setArt({"poster": display_poster_v1877, "thumb": display_poster_v1877, "icon": display_poster_v1877, "fanart": art or ""})
        mediatype = kodi_type or ("tvshow" if plex_type in ("show", "season") else plex_type or "video")
        apply_video_info(li, {
            "title": title or "",
            "sorttitle": sort_title or title or "",
            "originaltitle": original_title or "",
            "year": int(year or 0),
            "plot": summary or "",
            "duration": int(duration or 0),
            "mediatype": mediatype,
        })
        duration_text = self._search_duration_text(duration)
        meta_parts = []
        if year:
            meta_parts.append(str(year))
        if duration_text:
            meta_parts.append(duration_text)
        meta_line = " · ".join(meta_parts)
        summary3 = self._search_trim_summary_3lines(summary, limit=112)
        props = {"RatingKey": rating_key, "SectionId": section_id, "Type": plex_type, "KodiType": mediatype, "Title": title, "OriginalTitle": original_title, "SortTitle": sort_title, "Year": year, "Summary": summary, "SummaryDisplay": summary, "Summary3": summary3, "Duration": duration, "DurationText": duration_text, "MetaLine": meta_line, "AddedAt": added_at, "UpdatedAt": updated_at, "Thumb": display_poster_v1877, "OriginalThumbV1877": thumb, "SearchPosterRemoteV1879": search_remote_v1879, "WallPosterRemoteV1644": search_remote_v1879, "PosterAuthorityV2498": search_remote_v1879, "Art": art, "PosterFallbackArt": fallback_poster_v1877, "PosterFallbackRoleV2498": "poster" if fallback_poster_v1877 else "", "SearchPosterCacheV1877": poster_cache_kind_v1877, "PartKey": part_key, "ViewCount": view_count, "ShowTitle": show_title, "Season": season, "Episode": episode, "ParentRatingKey": parent_rating_key, "GrandparentRatingKey": grandparent_rating_key, "PlayUrl": url if part_key and plex_type in ("movie", "episode") else "", "ShowUrl": url if plex_type == "show" else "", "SectionTitle": _display_library_title(section_title), "TypeLabel": ("드라마" if plex_type == "show" else ("영화" if plex_type == "movie" else ""))}
        for k, v in props.items():
            try:
                li.setProperty("PlexKM.%s" % k, str(v or ""))
            except Exception:
                pass
        if part_key and plex_type in ("movie", "episode"):
            li.setProperty("IsPlayable", "true")
        return li

    def _search_populate_results(self, rows):
        """통합 결과를 현재 탭(scope)에 맞게 패널에 배치한다.

        all    : 4200(가장 일치) + 가로 줄 4000(영화)/4010(드라마)/4020(YouTube)
        movie  : 4001 전체보기   tv: 4011 전체보기   youtube: 4021 전체보기
        """
        try:
            started_v1879 = _pkm_speed_ms()
            scope = str(getattr(self, "_search_scope", "all") or "all")
            rows = list(rows or [])
            movies = [r for r in rows if self._search_row_type(r) == "movie"]
            shows = [r for r in rows if self._search_row_type(r) == "show"]
            for cid in (4200, 4000, 4010, 4001, 4011):
                try:
                    self.getControl(cid).reset()
                except Exception:
                    pass
            checked = [0]
            probe = []

            def _items(lst, limit):
                out = []
                for row in lst[:limit]:
                    li = self._search_row_to_listitem(row, check_local_cache_v1879=(checked[0] < 13))
                    if checked[0] < 13:
                        probe.append(li)
                    checked[0] += 1
                    out.append(li)
                return out

            plan = []  # (control id, items)
            if scope == "all":
                if rows:
                    # R90: 가장 일치하는 결과 카드 = [재생] [상세정보] 두 개의 액션 항목
                    best_play = _items(rows, 1)
                    for _li_best in best_play:
                        _li_best.setProperty("PlexKM.SearchAction", "play")
                    best_info = self._search_row_to_listitem(rows[0], check_local_cache_v1879=False)
                    best_info.setProperty("PlexKM.SearchAction", "info")
                    plan.append((4200, best_play + [best_info]))
                if movies:
                    plan.append((4000, self._search_with_more_tile_r90(_items(movies, SEARCH_ALL_ROW_LIMIT), len(movies), "movie")))
                if shows:
                    plan.append((4010, self._search_with_more_tile_r90(_items(shows, SEARCH_ALL_ROW_LIMIT), len(shows), "tv")))
            elif scope == "movie":
                plan.append((4001, _items(movies, 80)))
            elif scope == "tv":
                plan.append((4011, _items(shows, 80)))
            self._search_prepare_cached_visible_exact_v1879(probe)
            for cid, items in plan:
                if not items:
                    continue
                try:
                    ctrl = self.getControl(cid)
                    ctrl.addItems(items)
                    ctrl.selectItem(0)
                except Exception:
                    _log("INLINE_SEARCH_PANEL_FILL_FAILED cid=%s err=%s" % (cid, traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            self._search_fill_youtube_panels()
            self._search_publish_state()
            self._search_start_visible_poster_monitor_v1881(
                probe, query=str(getattr(self, "_search_query", "") or ""), scope=scope
            )
            _log("INLINE_SEARCH_RESULT_COUNTS_V2 scope=%s movies=%d shows=%d yt=%d probe=%d elapsed_ms=%d" % (
                scope, len(movies), len(shows), len(getattr(self, "_search_yt_items", []) or []),
                len(probe), _pkm_speed_ms() - started_v1879))
        except Exception:
            _log("INLINE_SEARCH_RESULTS_POPULATE_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_with_more_tile_r90(self, items, total, scope):
        """전체 탭 줄 끝에 "+N 더 보기" 타일을 붙인다. 선택하면 해당 탭으로 이동한다."""
        limit = SEARCH_ALL_YT_LIMIT if scope == "youtube" else SEARCH_ALL_ROW_LIMIT
        out = list(items or [])[:limit]
        remain = int(total or 0) - limit
        if remain > 0:
            tile = xbmcgui.ListItem(label="+%d" % remain)
            tile.setProperty("PlexKM.SearchMore", "1")
            tile.setProperty("PlexKM.MoreScope", str(scope or ""))
            out.append(tile)
        return out

    def _search_play_best_r90(self, li):
        """가장 일치하는 결과의 [재생]. 영화만 바로 재생하고, 그 외(드라마 등)는 False를 돌려 상세정보로 넘긴다."""
        try:
            if (li.getProperty("PlexKM.Type") or "") != "movie" or not (li.getProperty("PlexKM.PlayUrl") or ""):
                return False
            try:
                self._search_commit_history(self._search_query, reason="play_best")
            except Exception:
                pass
            _log("INLINE_SEARCH_BEST_PLAY_R90 rating_key=%s" % (li.getProperty("PlexKM.RatingKey") or ""))
            self._handle_info_playback_request(li)
            return True
        except Exception:
            _log("INLINE_SEARCH_BEST_PLAY_FAILED_R90 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _search_yt_to_listitem(self, v):
        v = v or {}
        li = xbmcgui.ListItem(label=str(v.get("title") or ""))
        thumb = str(v.get("thumb") or "")
        try:
            li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb})
        except Exception:
            pass
        dur = str(v.get("duration") or "")
        if v.get("live"):
            dur = "LIVE"
        props = {
            "Type": "youtube", "YtId": v.get("id") or "", "YtKind": v.get("kind") or "video",
            "Channel": v.get("channel") or "", "Duration": dur,
            "Views": v.get("views") or "", "Published": v.get("published") or "",
        }
        for k, val in props.items():
            try:
                li.setProperty("PlexKM.%s" % k, str(val or ""))
            except Exception:
                pass
        return li

    def _search_fill_youtube_panels(self):
        scope = str(getattr(self, "_search_scope", "all") or "all")
        for cid in SEARCH_YT_IDS:
            try:
                self.getControl(cid).reset()
            except Exception:
                pass
        if not self._search_youtube_enabled():
            return
        items = list(getattr(self, "_search_yt_items", []) or [])
        if scope == "all":
            cid, limit = 4020, SEARCH_ALL_YT_LIMIT
        elif scope == "youtube":
            cid, limit = 4021, 40
        else:
            return
        lis = [self._search_yt_to_listitem(v) for v in items[:limit]]
        if not lis:
            return
        if scope == "all":
            lis = self._search_with_more_tile_r90(lis, len(items), "youtube")
        try:
            ctrl = self.getControl(cid)
            ctrl.addItems(lis)
            ctrl.selectItem(0)
        except Exception:
            _log("INLINE_SEARCH_YT_FILL_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    def _search_start_youtube(self, q):
        """같은 검색어로 YouTube를 비동기 검색한다. 설정이 꺼져 있으면 아무것도 하지 않는다."""
        self._search_yt_items = []
        self._search_yt_loading = False
        self._search_yt_skipped = False
        tok = int(getattr(self, "_search_yt_token", 0) or 0) + 1
        self._search_yt_token = tok
        if not self._search_youtube_enabled():
            return
        q = (q or "").strip()
        try:
            from resources.lib.pkm_search_index import is_chosung_query
            skip = is_chosung_query(q)
        except Exception:
            skip = False
        self._search_yt_via = ""
        if skip:
            # R96: YouTube는 초성을 이해하지 못한다. 내 라이브러리에서 그 초성으로
            # 찾은 첫 제목(가장 일치)으로 대신 검색한다. 후보가 없으면 건너뛴다.
            cand = self._search_library_candidates_r96("all", limit=1)
            if cand:
                self._search_yt_via = "‘%s’(으)로 찾은 결과" % cand[0]
                q = cand[0]
                skip = False
        if skip or len(q) < 2:
            self._search_yt_skipped = True
            return
        self._search_yt_query_r96 = q
        self._search_fetch_yt_suggest_r96(q)
        cache = getattr(self, "_search_yt_cache", None)
        if cache is None:
            cache = {}
            self._search_yt_cache = cache
        if q in cache:
            self._search_yt_items = list(cache[q])
            return
        self._search_yt_loading = True

        def _w():
            items = []
            try:
                xbmc.sleep(350)
                if tok != int(getattr(self, "_search_yt_token", 0) or 0) or not getattr(self, "_search_inline_active", False):
                    return
                from resources.lib import pkm_youtube as yt
                res = yt.search(q) or {}
                items = [v for v in (res.get("videos") or []) if v.get("id")][:40]
            except Exception:
                _log("INLINE_SEARCH_YT_FAILED query=%s err=%s" % (_short_log_value(q), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            if tok != int(getattr(self, "_search_yt_token", 0) or 0) or not getattr(self, "_search_inline_active", False):
                return
            if len(cache) > 20:
                cache.clear()
            cache[q] = list(items)
            self._search_yt_items = items
            self._search_yt_loading = False
            try:
                self._search_fill_youtube_panels()
                self._search_publish_state()
            except Exception:
                _log("INLINE_SEARCH_YT_PUBLISH_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

        threading.Thread(target=_w, name="PKMSearchYouTube", daemon=True).start()

    def _search_publish_state(self):
        """탭 개수/섹션 표시/포커스 진입 위치/빈 화면 문구를 window property로 게시한다."""
        q = (getattr(self, "_search_query", "") or "").strip()
        scope = str(getattr(self, "_search_scope", "all") or "all")
        yt_on = self._search_youtube_enabled()
        rows = list(getattr(self, "_search_results", []) or [])
        movies = [r for r in rows if self._search_row_type(r) == "movie"]
        shows = [r for r in rows if self._search_row_type(r) == "show"]
        yts = list(getattr(self, "_search_yt_items", []) or []) if yt_on else []
        loading = bool(getattr(self, "_search_yt_loading", False)) and yt_on
        skipped = bool(getattr(self, "_search_yt_skipped", False)) and yt_on
        n_m, n_t, n_y = len(movies), len(shows), len(yts)
        # 결과가 1개뿐이면 "가장 일치" 카드와 줄이 중복되므로 줄을 숨긴다.
        dup_m = bool(rows) and n_m == 1 and rows[0] == movies[0]
        dup_t = bool(rows) and n_t == 1 and rows[0] == shows[0]
        if scope == "all":
            show = {"Best": bool(rows), "Movie": n_m > 0 and not dup_m, "Tv": n_t > 0 and not dup_t, "Yt": n_y > 0}
            has = bool(rows) or n_y > 0
            if show["Best"]:
                enter = 4200
            elif show["Movie"]:
                enter = 4000
            elif show["Tv"]:
                enter = 4010
            elif show["Yt"]:
                enter = 4020
            else:
                enter = 0
        else:
            show = {"Best": False, "Movie": scope == "movie" and n_m > 0, "Tv": scope == "tv" and n_t > 0, "Yt": scope == "youtube" and n_y > 0}
            has = any(show.values())
            enter = {"movie": 4001, "tv": 4011, "youtube": 4021}.get(scope, 0) if has else 0

        if yt_on and (loading and n_y == 0):
            tab_yt = "YouTube …"
            cnt_yt = "…"
        elif skipped:
            tab_yt = "YouTube -"
            cnt_yt = "-"
        else:
            tab_yt = "YouTube %d" % n_y
            cnt_yt = str(n_y)
        props = {
            "TabAll": "전체 %d" % (n_m + n_t + n_y),
            "TabMovie": "영화 %d" % n_m,
            "TabTv": "드라마 %d" % n_t,
            "TabYt": tab_yt,
            "LblMovie": "영화 %d" % n_m,
            "LblTv": "드라마 %d" % n_t,
            "LblYt": "YouTube %d" % n_y,
            # R90: 이름/개수를 따로 게시해 개수만 연한 색으로 그린다.
            "TabAllName": "전체", "TabAllCnt": str(n_m + n_t + n_y),
            "TabMovieName": "영화", "TabMovieCnt": str(n_m),
            "TabTvName": "드라마", "TabTvCnt": str(n_t),
            "TabYtName": "YouTube", "TabYtCnt": cnt_yt,
            "LblMovieName": "영화", "LblMovieCnt": str(n_m),
            "LblTvName": "드라마", "LblTvCnt": str(n_t),
            "LblYtName": "YouTube", "LblYtCnt": str(n_y),
            "ShowBest": "1" if show["Best"] else "",
            "ShowMovie": "1" if show["Movie"] else "",
            "ShowTv": "1" if show["Tv"] else "",
            "ShowYt": "1" if show["Yt"] else "",
            "HasResults": "1" if has else "",
            "Enter": str(enter) if enter else ("2110" if q else ""),
            "YtEnabled": "1" if yt_on else "",
        }
        # 빈 화면 문구
        yt_word = " · YouTube" if yt_on else ""
        if not q:
            state = "intro"
            props.update({
                "StateTitle": "무엇을 찾으세요?",
                "StateSub": ("내 라이브러리의 영화·드라마와 YouTube를 한 번에 찾습니다." if yt_on else "내 라이브러리의 영화·드라마를 한 번에 찾습니다."),
                "StateTip1": "· 초성으로도 찾을 수 있어요. 예) ㅍㅎ → 평화",
                "StateTip2": "· 결과가 나오면 위쪽 탭에서 전체 · 영화 · 드라마%s를 고를 수 있어요." % (" · YouTube" if yt_on else ""),
                "StateTip3": "",
            })
        elif has:
            state = "results"
            props.update({"StateTitle": "", "StateSub": "", "StateTip1": "", "StateTip2": "", "StateTip3": ""})
        elif loading:
            state = "searching"
            props.update({"StateTitle": "검색 중…", "StateSub": "", "StateTip1": "", "StateTip2": "", "StateTip3": ""})
        else:
            state = "none"
            others = {"all": 0, "movie": n_t + n_y, "tv": n_m + n_y, "youtube": n_m + n_t}.get(scope, 0)
            where = {"all": "내 라이브러리%s에서" % (" 와 YouTube" if yt_on else ""), "movie": "영화에서", "tv": "드라마에서", "youtube": "YouTube에서"}.get(scope, "")
            sub = ("%s 찾지 못했어요." % where).replace("라이브러리 와", "라이브러리와")
            if others > 0:
                sub = "%s 찾지 못했어요. 다른 탭에서 %d개를 찾았어요." % (where, others)
            props.update({
                "StateTitle": "‘%s’에 대한 결과가 없습니다" % q,
                "StateSub": sub,
                "StateTip1": "· 초성을 줄여서 입력해 보세요. 예) ㅈㅌㅇ",
                "StateTip2": "· 띄어쓰기나 철자를 확인해 보세요.",
                "StateTip3": "· 원제로 찾으려면 영문 키보드로 바꿔 보세요.",
            })
        props["State"] = state
        props["YtVia"] = str(getattr(self, "_search_yt_via", "") or "") if yt_on else ""
        try:
            for k, v in props.items():
                self.setProperty("PlexKM.Search.%s" % k, v)
        except Exception:
            pass
        try:
            self._search_publish_suggestions_r96()
        except Exception:
            _log("INLINE_SEARCH_SUGGEST_PUBLISH_FAILED_R96 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)

    # ------------------------------------------------------------ R96 helpers
    def _search_kb_set_r96(self, open_kb, reason=""):
        """Keyboard drawer.  Open: focus the keyboard.  Close: focus the results
        (or keep the drawer when there is nothing to show)."""
        try:
            if open_kb:
                self.setProperty("PlexKM.Search.KbOpen", "1")
                self.setFocusId(SEARCH_KEYBOARD_ID)
            else:
                if self.getProperty("PlexKM.Search.HasResults") != "1":
                    return False
                self.clearProperty("PlexKM.Search.KbOpen")
                self._search_enter_guard_ms_r96 = self._now_ms()
                self.setFocusId(4900)
            _log("INLINE_SEARCH_KB_R96 open=%d reason=%s focus=%s" % (1 if open_kb else 0, reason or "", self._safe_focus_id()))
            return True
        except Exception:
            _log("INLINE_SEARCH_KB_FAILED_R96 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return False

    def _search_library_candidates_r96(self, scope, limit=6):
        """Library titles for the chips: current results of that type, watched
        and recently added first (rank order is kept inside each group)."""
        q = (getattr(self, "_search_query", "") or "").strip()
        rows = list(getattr(self, "_search_results", []) or [])
        if scope == "movie":
            rows = [r for r in rows if self._search_row_type(r) == "movie"]
        elif scope == "tv":
            rows = [r for r in rows if self._search_row_type(r) == "show"]
        top = rows[:30]

        def _key(item):
            idx, r = item
            try:
                watched = 1 if int(r[16] or 0) > 0 else 0
            except Exception:
                watched = 0
            return (-watched, idx)

        out, seen = [], set()
        for _idx, r in sorted(enumerate(top), key=_key):
            title = str((tuple(r) + ("",) * 6)[4] or "").strip()
            k = title.lower()
            if not title or k in seen or k == q.lower():
                continue
            seen.add(k)
            out.append(title)
            if len(out) >= limit:
                break
        return out

    def _search_fetch_yt_suggest_r96(self, q):
        """YouTube autocomplete for the (effective) YouTube query, off the GUI thread."""
        q = (q or "").strip()
        cache = getattr(self, "_search_yt_suggest_r96", None)
        if cache is None:
            cache = {}
            self._search_yt_suggest_r96 = cache
        if not q or q in cache:
            return

        def _w():
            items = []
            try:
                import json
                try:
                    from urllib.request import urlopen, Request
                    from urllib.parse import quote
                except ImportError:
                    from urllib2 import urlopen, Request
                    from urllib import quote
                url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=ko&q=%s" % quote(q.encode("utf-8"))
                raw = urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=4).read()
                data = json.loads(raw.decode("utf-8", "replace"))
                items = [str(x) for x in (data[1] if len(data) > 1 else []) if str(x).strip() and str(x).strip() != q][:6]
            except Exception:
                _log("INLINE_SEARCH_YT_SUGGEST_FAILED_R96 query=%s err=%s" % (_short_log_value(q), traceback.format_exc().replace(chr(10), " | ")), xbmc.LOGWARNING)
            if len(cache) > 40:
                cache.clear()
            cache[q] = items
            if getattr(self, "_search_inline_active", False):
                try:
                    self._search_publish_suggestions_r96()
                except Exception:
                    pass

        threading.Thread(target=_w, name="PKMSearchYtSuggestR96", daemon=True).start()

    def _search_publish_suggestions_r96(self):
        """Chips follow the tab: 영화/드라마 = library titles of that type,
        전체 = mixed (+2 YouTube), YouTube = library word + autocomplete."""
        q = (getattr(self, "_search_query", "") or "").strip()
        scope = str(getattr(self, "_search_scope", "all") or "all")
        chips = []
        if q:
            yt_on = self._search_youtube_enabled()
            ytq = str(getattr(self, "_search_yt_query_r96", "") or "")
            yts = list((getattr(self, "_search_yt_suggest_r96", None) or {}).get(ytq, []) or []) if yt_on else []
            if scope in ("movie", "tv"):
                chips = self._search_library_candidates_r96(scope, limit=8)
            elif scope == "youtube":
                chips = self._search_library_candidates_r96("all", limit=3) + yts
            else:
                chips = self._search_library_candidates_r96("all", limit=6) + yts[:2]
        seen, final = set(), []
        for c in chips:
            if c and c.lower() not in seen and c.strip() != q:
                seen.add(c.lower())
                final.append(c)
        final = final[:8]
        self._search_chips_r96 = final
        for n in range(8):
            try:
                if n < len(final):
                    self.setProperty("PlexKM.Search.Sug%d" % (n + 1), final[n])
                else:
                    self.clearProperty("PlexKM.Search.Sug%d" % (n + 1))
            except Exception:
                pass
        try:
            self.setProperty("PlexKM.Search.SugTitle", "추천" if final else "")
        except Exception:
            pass

    def _search_apply_suggestion_r96(self, control_id):
        try:
            idx = list(range(2121, 2129)).index(int(control_id))
        except ValueError:
            idx = list(range(2141, 2147)).index(int(control_id))
        word = str(self.getProperty("PlexKM.Search.Sug%d" % (idx + 1)) or "").strip()
        if not word:
            return
        self._search_query_tokens = list(word)
        self._search_recompose_query()
        self._search_refresh_query_label()
        _log("INLINE_SEARCH_SUGGEST_APPLY_R96 control=%s word=%s" % (control_id, _short_log_value(word)))
        self._search_run_query_debounced_r82(delay_ms=0)

    def _search_play_youtube(self, li):
        vid = str(li.getProperty("PlexKM.YtId") or "")
        if not vid:
            return
        try:
            self._search_commit_history(self._search_query, reason="play_youtube")
        except Exception:
            pass
        try:
            from resources.lib import pkm_youtube as yt
            ok = yt.play({"id": vid, "kind": li.getProperty("PlexKM.YtKind") or "video"})
        except Exception:
            ok = False
            _log("INLINE_SEARCH_YT_PLAY_FAILED err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
        _log("INLINE_SEARCH_YT_PLAY id=%s ok=%d" % (vid, 1 if ok else 0))
        if not ok:
            try:
                self._show_pkm_notice("YouTube", "재생할 수 있는 YouTube 앱/애드온이 없습니다", "", ms=3000)
            except Exception:
                pass

    def _search_open_selected_result_info(self, control_id=None, reason="onclick"):
        if self._now_ms() - int(getattr(self, "_search_enter_guard_ms_r96", 0) or 0) < 600:
            _log("INLINE_SEARCH_ENTER_ECHO_DROP_R96 control=%s reason=%s" % (control_id, reason or ""))
            return
        # v1771: both onAction(SELECT) and onClick can arrive for one press.
        # Debounce only the duplicate delivery; never use a timer to fake the
        # actual Info transition.
        now_ms = self._now_ms()
        if now_ms - int(getattr(self, "_search_info_open_guard_ms_v1771", 0) or 0) < 650:
            _log("INLINE_SEARCH_INFO_OPEN_DUPLICATE_SKIP_V1771 control=%s reason=%s" % (control_id or SEARCH_RESULTS_ID, reason or ""))
            return
        try:
            li = self.getControl(control_id or SEARCH_RESULTS_ID).getSelectedItem()
        except Exception:
            li = None
        if not li:
            _log("INLINE_SEARCH_INFO_OPEN_FAILED_V1771 control=%s reason=no_selected_item source=%s" % (control_id or SEARCH_RESULTS_ID, reason or ""), xbmc.LOGWARNING)
            return
        if (li.getProperty("PlexKM.SearchMore") or "") == "1":
            # R90: "+N 더 보기" 타일 -> 해당 탭(영화/드라마/YouTube)으로 이동하고 첫 결과에 포커스
            self._search_info_open_guard_ms_v1771 = now_ms
            self._search_set_scope(li.getProperty("PlexKM.MoreScope") or "all", reason="more_tile_r90")
            try:
                enter = str(self.getProperty("PlexKM.Search.Enter") or "")
                if enter.isdigit() and int(enter) in SEARCH_RESULT_IDS:
                    self.setFocusId(int(enter))
            except Exception:
                _log("INLINE_SEARCH_MORE_FOCUS_FAILED_R90 err=%s" % traceback.format_exc().replace(chr(10), " | "), xbmc.LOGWARNING)
            return
        if int(control_id or 0) == SEARCH_BEST_ID and (li.getProperty("PlexKM.SearchAction") or "") == "play":
            self._search_info_open_guard_ms_v1771 = now_ms
            if self._search_play_best_r90(li):
                return
            # 영화가 아니거나 재생 경로가 없으면 상세정보 화면으로 연다.
        if int(control_id or 0) in SEARCH_YT_IDS:
            self._search_info_open_guard_ms_v1771 = now_ms
            self._search_play_youtube(li)
            return
        rating_key = li.getProperty("PlexKM.RatingKey") or ""
        if not rating_key:
            _log("INLINE_SEARCH_INFO_OPEN_FAILED_V1771 control=%s reason=missing_rating_key source=%s title=%s" % (control_id or SEARCH_RESULTS_ID, reason or "", _short_log_value(li.getLabel() or "")), xbmc.LOGWARNING)
            return
        self._search_info_open_guard_ms_v1771 = now_ms
        try:
            self._search_commit_history(self._search_query, reason="open_info")
        except Exception:
            pass
        # Keep Search alive underneath Info so Back returns to the same query.
        _log("INLINE_SEARCH_INFO_OPEN_V1771 control=%s rating_key=%s source=%s" % (control_id or SEARCH_RESULTS_ID, rating_key, reason or ""))
        # v1875: the clicked result outranks speculative Search prewarm. Capture
        # the ListItem here on the GUI thread, then use a dedicated background
        # lane so actor circles are not blocked behind unrelated lower results.
        self._search_start_selected_cast_direct_v1875(li, reason=reason or "onclick")
        self._show_info(li=li)
