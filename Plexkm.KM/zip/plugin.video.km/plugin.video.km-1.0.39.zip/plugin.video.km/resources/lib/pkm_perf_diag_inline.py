# -*- coding: utf-8 -*-
# PKM UHD3 PERF DIAG V5 EXTENDED
# Lightweight in-process diagnostics for PKM/UHD3 tuning.

from __future__ import absolute_import, unicode_literals

import collections
import os
import re
import sys
import threading
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

MARKER = "PKM_UHD3_PERF_DIAG_V2617_KPI"
POLL_SEC = 0.50
ACTIVITY_SAMPLE_SEC = 1.00
CONTENT_SAMPLE_SEC = 0.40
SETTLE_SEC = 0.65
BURST_GAP_SEC = 0.80
KPI_LOG_SEC = 1.00
KPI_SUMMARY_SEC = 10.00
KPI_PROFILE = "PC_REFERENCE_R5_NONACTOR"
KPI_WARMUP_SEC = 2.50

_started = False
_start_lock = threading.Lock()
_stop_event = threading.Event()


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (MARKER, msg), level)
    except Exception:
        pass


def _label(name, default="-"):
    try:
        value = xbmc.getInfoLabel(name)
        value = str(value or "").replace("\r", " ").replace("\n", " ").strip()
        return value if value else default
    except Exception:
        return default


def _prop(win, name, default=""):
    try:
        value = win.getProperty(name)
        return str(value or default)
    except Exception:
        return default


def _short(value, limit=54):
    text = str(value or "-")
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)] + "..."


def _set(win, name, value):
    try:
        win.setProperty(name, str(value))
    except Exception:
        pass


def _bool_prop(win, name):
    return _prop(win, name, "").lower() in ("1", "true", "yes", "on")


def _cond(expr):
    try:
        return bool(xbmc.getCondVisibility(expr))
    except Exception:
        return False


def _num(text, default=None):
    try:
        m = re.search(r"[-+]?\d+(?:\.\d+)?", str(text or ""))
        return float(m.group(0)) if m else default
    except Exception:
        return default


def _fmt_ms(value):
    if value is None:
        return "-"
    try:
        return "%.0f" % float(value)
    except Exception:
        return "-"


def _state(win):
    wall_opening = _bool_prop(win, "PlexKM.WindowWallOpening")
    wall_active = _bool_prop(win, "PlexKM.WindowWallActive")
    home_opening = _bool_prop(win, "PlexKM.HomeWindowOpening")
    home_active = _bool_prop(win, "PlexKM.HomeWindowActive")
    startup_ready = _prop(win, "PlexKM.Home.StartupReadyV1619", "")
    if wall_active:
        return "WALL ACTIVE"
    if wall_opening:
        return "WALL OPENING"
    if home_active and startup_ready == "1":
        return "HOME READY"
    if home_active:
        return "HOME LOADING"
    if home_opening:
        return "HOME OPENING"
    return "PKM STARTUP"


def _translate(path):
    try:
        if xbmcvfs is not None and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
        return xbmc.translatePath(path)
    except Exception:
        return path


def _discover_home_containers():
    """Best-effort discovery only. Limited to a few list/panel IDs to keep cost low."""
    ids = []
    candidates = [
        "special://skin/xml/Home.xml",
        "special://home/addons/skin.plex.km/xml/Home.xml",
    ]
    for raw in candidates:
        path = _translate(raw)
        if not path or not os.path.isfile(path):
            continue
        try:
            root = ET.parse(path).getroot()
            for ctl in root.iter("control"):
                typ = str(ctl.attrib.get("type", "")).lower()
                cid = str(ctl.attrib.get("id", "")).strip()
                if typ not in ("list", "panel", "fixedlist", "wraplist"):
                    continue
                if not cid.isdigit() or cid == "9000":
                    continue
                n = int(cid)
                # PKM uses high IDs heavily; prefer those and avoid core/utility controls.
                if n < 1000:
                    continue
                if cid not in ids:
                    ids.append(cid)
                if len(ids) >= 8:
                    break
        except Exception as exc:
            _log("HOME_CONTAINER_DISCOVERY_FAILED %s" % exc, xbmc.LOGWARNING)
        if ids:
            break
    return ids


def _content_signature(container_ids):
    if not container_ids:
        return ""
    parts = []
    for cid in container_ids:
        # Current label + number of items is cheap enough at 0.4 s cadence and detects most row swaps.
        lbl = _label("Container(%s).ListItem.Label" % cid, "")
        num = _label("Container(%s).NumItems" % cid, "")
        pos = _label("Container(%s).CurrentItem" % cid, "")
        if lbl or num or pos:
            parts.append("%s:%s:%s:%s" % (cid, num, pos, lbl[:24]))
    return "|".join(parts)


def _thread_activity(diag_thread_id=None):
    """Sample thread names + shallow Python stacks. Read-only and once per second."""
    counts = {"bg": 0, "plex": 0, "sql": 0, "warm": 0, "sync": 0}
    hot = []
    try:
        threads = list(threading.enumerate())
        counts["bg"] = max(0, len(threads) - 1)  # exclude current diagnostic worker below if possible
        frames = sys._current_frames() if hasattr(sys, "_current_frames") else {}
        for th in threads:
            ident = getattr(th, "ident", None)
            if ident == diag_thread_id:
                counts["bg"] = max(0, counts["bg"] - 1)
                continue
            name = str(getattr(th, "name", "") or "thread")
            bits = [name.lower()]
            top_fn = ""
            frame = frames.get(ident)
            depth = 0
            while frame is not None and depth < 10:
                try:
                    fn = str(frame.f_code.co_name or "")
                    file_name = str(frame.f_code.co_filename or "")
                    if not top_fn and fn not in ("wait", "waitForAbort", "sleep", "_bootstrap", "_bootstrap_inner"):
                        top_fn = fn
                    bits.append(fn.lower())
                    bits.append(os.path.basename(file_name).lower())
                except Exception:
                    pass
                frame = getattr(frame, "f_back", None)
                depth += 1
            hay = " ".join(bits)
            if any(k in hay for k in ("plex", "request", "urllib", "http", "network", "fetch", "tmdb")):
                counts["plex"] += 1
            if any(k in hay for k in ("sqlite", "database", "db_", "query", "index", "authority")):
                counts["sql"] += 1
            if any(k in hay for k in ("prewarm", "warm", "thumb", "image", "artwork", "cache", "season", "snapshot")):
                counts["warm"] += 1
            if any(k in hay for k in ("sync", "refresh", "repair", "rebuild")):
                counts["sync"] += 1
            if top_fn and len(hot) < 3:
                hot.append("%s:%s" % (_short(name, 16), _short(top_fn, 20)))
    except Exception as exc:
        return counts, "activity_err:%s" % type(exc).__name__
    return counts, " | ".join(hot) if hot else "-"


def _kpi_grade_le(value, pass_max, warn_max):
    if value is None:
        return "NA"
    try:
        value = float(value)
        if value <= float(pass_max):
            return "PASS"
        if value <= float(warn_max):
            return "WARN"
        return "FAIL"
    except Exception:
        return "NA"


def _kpi_grade_ge(value, pass_min, warn_min):
    if value is None:
        return "NA"
    try:
        value = float(value)
        if value >= float(pass_min):
            return "PASS"
        if value >= float(warn_min):
            return "WARN"
        return "FAIL"
    except Exception:
        return "NA"


def _kpi_overall(grades):
    vals = [str(x or "NA") for x in grades if str(x or "NA") != "NA"]
    if not vals:
        return "NA"
    if "FAIL" in vals:
        return "FAIL"
    if "WARN" in vals:
        return "WARN"
    return "PASS"


def _kpi_p95(values):
    try:
        vals = sorted(float(v) for v in values if v is not None)
        if not vals:
            return None
        idx = max(0, min(len(vals) - 1, int((len(vals) * 0.95) + 0.999999) - 1))
        return vals[idx]
    except Exception:
        return None


def _kpi_fmt(value, digits=1):
    if value is None:
        return "-"
    try:
        if digits <= 0:
            return "%.0f" % float(value)
        return ("%%.%df" % int(digits)) % float(value)
    except Exception:
        return "-"


def _diag_worker():
    monitor = xbmc.Monitor()
    win = xbmcgui.Window(10000)
    diag_tid = threading.current_thread().ident
    t0 = time.monotonic()
    last_tick = t0
    next_tick_v2617 = t0
    max_lag_ms = 0.0
    last_cost_ms = 0.0
    max_cost_ms = 0.0
    lag_hist = collections.deque(maxlen=max(10, int(3.0 / POLL_SEC)))
    cost_hist = collections.deque(maxlen=max(10, int(3.0 / POLL_SEC)))

    fps_hist = collections.deque(maxlen=max(10, int(10.0 / POLL_SEC)))
    cpu_hist = collections.deque(maxlen=max(10, int(10.0 / POLL_SEC)))
    fps_session_min = None
    cpu_session_max = None

    last_window_id = ""
    last_window_name = ""
    last_control_id = ""
    last_sidebar_index = ""
    last_sidebar_label = ""
    last_wall_state = ""
    last_home_state = ""
    last_state = ""
    last_event = "START extended inline diagnostic"
    last_event_at = t0

    # Sidebar timing / burst metrics. This starts when Kodi reports the new focused item.
    sidebar_change_at = None
    sidebar_prev_change_at = None
    sidebar_settle_ms = None
    sidebar_burst = 0
    sidebar_burst_max = 0
    sidebar_last_gap_ms = None
    sidebar_content_first_ms = None
    sidebar_content_last_ms = None
    sidebar_pending = False

    # Startup / wall transition timings.
    home_ready_ms = None
    wall_open_at = None
    wall_open_ms = None
    state_enter_at = t0

    # Best-effort content change tracking.
    container_ids = _discover_home_containers()
    last_content_sig = ""
    last_content_sample = 0.0

    # Thread activity, sampled slowly.
    last_activity_sample = 0.0
    activity = {"bg": 0, "plex": 0, "sql": 0, "warm": 0, "sync": 0}
    hot = "-"

    # V2605 PC->U+ proxy KPI state. Home/Info/Actor event timings come from the
    # runtime. Runtime jitter is graded only after a short post-Home warmup. FPS
    # and diagnostic self-cost remain observation-only because Kodi can render
    # static UI below display refresh and the diagnostic sampler has measurable cost.
    last_kpi_log = t0
    last_summary_log = t0
    last_info_stamp = ""
    last_actor_stamp = ""
    last_actor_upgrade_stamp = ""
    last_actor_meta_stamp = ""
    last_sort_stamp = ""
    last_sidebar_stamp = ""
    last_library_stamp = ""
    last_append_violation_stamp = ""
    info_samples = collections.deque(maxlen=128)
    actor_samples = collections.deque(maxlen=128)
    actor_complete_samples = collections.deque(maxlen=128)
    actor_works_ready_samples = collections.deque(maxlen=128)
    actor_upgrade_samples = collections.deque(maxlen=128)
    actor_meta_samples = collections.deque(maxlen=128)
    sidebar_samples = collections.deque(maxlen=256)
    library_samples = collections.deque(maxlen=256)
    sort_warm_samples = collections.deque(maxlen=256)
    sort_cold_samples = collections.deque(maxlen=256)
    library_spinner_uses = 0
    sort_spinner_uses = 0
    sort_movie_n = 0
    sort_tv_n = 0
    actor_portrait_violations = 0
    actor_placeholder_visible = 0
    actor_previsible_net_violations = 0
    actor_upgrade_failures = 0
    actor_upgrade_visual_commits = 0
    actor_meta_failures = 0
    actor_meta_unavailable = 0
    actor_meta_ready_events = 0
    steady_lag_samples = collections.deque(maxlen=1024)
    steady_fps_low2_min = None
    steady_cost_max2_peak = 0.0
    steady_py_threads_peak = 0
    steady_bg_threads_peak = 0
    steady_plex_threads_peak = 0
    steady_sql_threads_peak = 0
    steady_warm_threads_peak = 0
    kpi_steady_after = None
    info_pre_sql_violations = 0
    info_pre_net_violations = 0
    actor_busy_violations = 0
    append_fg_violations = 0
    info_proxy_misses = 0
    actor_proxy_misses = 0

    _set(win, "PlexKM.Diag.Active", "1")
    _set(win, "PlexKM.Diag.KPIProxyV2605", "0")
    _set(win, "PlexKM.Diag.EnableRuntimeProxyV2613", "0")
    _set(win, "PlexKM.Diag.Version", "V2617 Replacement Non-Actor KPI")
    _set(win, "PlexKM.Diag.Event", last_event)
    _set(win, "PlexKM.Diag.TrackContainers", ",".join(container_ids) if container_ids else "-")
    _log("START poll_ms=%d track_containers=%s kpi_profile=%s kpi_log_ms=%d warmup_ms=%d reference_mode=1 runtime_proxy=0 android_reduction=0 screen_capture_required=0 fps_grade=observe_only diag_cost_grade=observe_only library_transition_grade=500_1000 sort_kpi=v2612 actor_kpi=v2612 actor_meta_kpi=v2616 heartbeat=v2617_deadline_based nonactor_result=1" % (
        int(POLL_SEC * 1000), ",".join(container_ids) if container_ids else "none", KPI_PROFILE,
        int(KPI_LOG_SEC * 1000), int(KPI_WARMUP_SEC * 1000)
    ))

    try:
        while not monitor.abortRequested() and not _stop_event.is_set():
            started = time.monotonic()
            elapsed_ms = max(0.0, (started - last_tick) * 1000.0)
            last_tick = started
            # V2617: measure wake lateness against an absolute deadline. The old
            # implementation added this diagnostic loop's own processing cost to
            # every 500ms wait, so a 47ms diagnostic pass became a fake 47ms
            # "heartbeat" warning and a 204ms pass became a fake runtime failure.
            lag_ms = max(0.0, (started - next_tick_v2617) * 1000.0)
            next_tick_v2617 += POLL_SEC
            max_lag_ms = max(max_lag_ms, lag_ms)
            lag_hist.append((started, lag_ms))
            while lag_hist and started - lag_hist[0][0] > 2.2:
                lag_hist.popleft()
            lag_max2 = max((v for _, v in lag_hist), default=0.0)

            # Lightweight runtime metrics.
            fps = _num(_label("System.FPS", ""), None)
            cpu = _num(_label("System.CPUUsage", ""), None)
            if fps is not None:
                fps_hist.append((started, fps))
                fps_session_min = fps if fps_session_min is None else min(fps_session_min, fps)
            if cpu is not None:
                cpu_hist.append((started, cpu))
                cpu_session_max = cpu if cpu_session_max is None else max(cpu_session_max, cpu)
            while fps_hist and started - fps_hist[0][0] > 2.2:
                fps_hist.popleft()
            while cpu_hist and started - cpu_hist[0][0] > 2.2:
                cpu_hist.popleft()
            fps_low2 = min((v for _, v in fps_hist), default=None)
            cpu_max2 = max((v for _, v in cpu_hist), default=None)

            try:
                window_id = str(xbmcgui.getCurrentWindowId())
            except Exception:
                window_id = _label("System.CurrentWindowId", "-")
            window_name = _label("System.CurrentWindow", "-")
            control_id = _label("System.CurrentControlID", "-")
            control_name = _label("System.CurrentControl", "-")

            sidebar_index = _label("Container(9000).CurrentItem", "-")
            sidebar_label = _label("Container(9000).ListItem.Label", "-")
            if sidebar_label in ("", "-"):
                sidebar_label = _prop(win, "PlexKM.SidebarOverlayLabel", "-")
            if sidebar_index in ("", "-"):
                sidebar_index = _prop(win, "PlexKM.SidebarOverlayIndex", "-")

            state = _state(win)
            wall_opening = _bool_prop(win, "PlexKM.WindowWallOpening")
            wall_active = _bool_prop(win, "PlexKM.WindowWallActive")
            wall_state = "%s/%s" % ("1" if wall_opening else "0", "1" if wall_active else "0")
            home_ready = _prop(win, "PlexKM.Home.StartupReadyV1619", "-") == "1"
            home_state = "%s/%s/%s" % (
                "1" if _bool_prop(win, "PlexKM.HomeWindowOpening") else "0",
                "1" if _bool_prop(win, "PlexKM.HomeWindowActive") else "0",
                "1" if home_ready else "0",
            )

            # Busy indicator is independent from the skin's custom spinner.
            gui_busy = (
                _cond("Window.IsActive(busydialog)") or
                _cond("Window.IsActive(busydialognocancel)") or
                _cond("Window.IsVisible(busydialog)") or
                _cond("Window.IsVisible(busydialognocancel)")
            )

            # Home ready time from diagnostic/service start.
            if home_ready and home_ready_ms is None:
                home_ready_ms = (started - t0) * 1000.0
                kpi_steady_after = started + KPI_WARMUP_SEC
                last_summary_log = started
                lag_hist.clear()
                cost_hist.clear()
                fps_hist.clear()
                _log("HOME_READY_MS %.0f" % home_ready_ms)
                _log("KPI_STEADY_WARMUP_ARM_V2605 delay_ms=%d startup_samples_excluded=1" % int(KPI_WARMUP_SEC * 1000))

            # Wall opening -> active time.
            if wall_opening and wall_open_at is None:
                wall_open_at = started
                wall_open_ms = None
            if wall_active and wall_open_at is not None and wall_open_ms is None:
                wall_open_ms = (started - wall_open_at) * 1000.0
                _log("WALL_OPEN_MS %.0f" % wall_open_ms)
            if not wall_opening and not wall_active and last_wall_state == "0/1":
                wall_open_at = None

            # Event detection. Sidebar item change is our earliest reliable in-Kodi focus signal.
            event = None
            sidebar_changed = bool(last_sidebar_label) and (
                sidebar_index != last_sidebar_index or sidebar_label != last_sidebar_label
            )
            if sidebar_changed:
                sidebar_prev_change_at = sidebar_change_at
                sidebar_change_at = started
                sidebar_pending = True
                sidebar_settle_ms = None
                sidebar_content_first_ms = None
                sidebar_content_last_ms = None
                if sidebar_prev_change_at is not None:
                    gap = started - sidebar_prev_change_at
                    sidebar_last_gap_ms = gap * 1000.0
                    if gap <= BURST_GAP_SEC:
                        sidebar_burst += 1
                    else:
                        sidebar_burst = 1
                else:
                    sidebar_burst = 1
                sidebar_burst_max = max(sidebar_burst_max, sidebar_burst)
                event = "SIDEBAR %s %s" % (sidebar_index, _short(sidebar_label, 30))
            elif last_window_id and (window_id != last_window_id or window_name != last_window_name):
                event = "WINDOW %s/%s -> %s/%s" % (
                    last_window_id, _short(last_window_name, 18),
                    window_id, _short(window_name, 18),
                )
            elif last_wall_state and wall_state != last_wall_state:
                event = "WALL opening/active %s -> %s" % (last_wall_state, wall_state)
            elif last_home_state and home_state != last_home_state:
                event = "HOME opening/active/ready %s -> %s" % (last_home_state, home_state)
            elif last_control_id and control_id != last_control_id:
                event = "FOCUS CTRL %s -> %s" % (last_control_id, control_id)

            if state != last_state:
                state_enter_at = started
                last_state = state

            if event:
                last_event = event
                last_event_at = started
                _log("EVENT %s" % event)

            # Content signature is sampled at a slower cadence. It gives a best-effort
            # FOCUS->CONTENT timing without modifying PKM data paths.
            if started - last_content_sample >= CONTENT_SAMPLE_SEC:
                last_content_sample = started
                sig = _content_signature(container_ids)
                if sig and sig != last_content_sig:
                    if sidebar_pending and sidebar_change_at is not None:
                        age_ms = (started - sidebar_change_at) * 1000.0
                        if sidebar_content_first_ms is None:
                            sidebar_content_first_ms = age_ms
                        sidebar_content_last_ms = age_ms
                    last_content_sig = sig

            # A sidebar move is considered quiet/stable after no further sidebar focus
            # changes for SETTLE_SEC. If content containers changed later, include that tail.
            if sidebar_pending and sidebar_change_at is not None:
                focus_quiet_age = started - sidebar_change_at
                content_tail_sec = 0.0
                if sidebar_content_last_ms is not None:
                    content_tail_sec = sidebar_content_last_ms / 1000.0
                if focus_quiet_age >= max(SETTLE_SEC, content_tail_sec + SETTLE_SEC):
                    sidebar_settle_ms = focus_quiet_age * 1000.0
                    sidebar_pending = False
                    _log(
                        "SIDEBAR_SETTLE_MS %.0f burst=%d content_first=%s content_last=%s" % (
                            sidebar_settle_ms, sidebar_burst,
                            _fmt_ms(sidebar_content_first_ms), _fmt_ms(sidebar_content_last_ms),
                        )
                    )

            # Low-rate Python activity sampler.
            if started - last_activity_sample >= ACTIVITY_SAMPLE_SEC:
                last_activity_sample = started
                activity, hot = _thread_activity(diag_tid)

            # Exact transition samples emitted by the Home runtime.
            info_stamp = _prop(win, "PlexKM.KPI.InfoStamp", "")
            if info_stamp and info_stamp != last_info_stamp:
                last_info_stamp = info_stamp
                value = _num(_prop(win, "PlexKM.KPI.InfoVisibleMs", ""), None)
                if value is not None:
                    info_samples.append(value)
                pre_sql = int(_num(_prop(win, "PlexKM.KPI.InfoPreSql", "0"), 0) or 0)
                pre_net = int(_num(_prop(win, "PlexKM.KPI.InfoPreNet", "0"), 0) or 0)
                proxy_ok = (_prop(win, "PlexKM.KPI.InfoProxy", "0") == "1")
                info_pre_sql_violations += 1 if pre_sql else 0
                info_pre_net_violations += 1 if pre_net else 0
                info_proxy_misses += 0  # V2613 PC reference: proxy is intentionally off
                _log("KPI_INFO_SAMPLE_V2610 visible_ms=%s pre_sql=%d pre_net=%d proxy=%d" % (
                    _kpi_fmt(value, 0), pre_sql, pre_net, 1 if proxy_ok else 0
                ))
            actor_stamp = _prop(win, "PlexKM.KPI.ActorStamp", "")
            if actor_stamp and actor_stamp != last_actor_stamp:
                last_actor_stamp = actor_stamp
                value = _num(_prop(win, "PlexKM.KPI.ActorVisibleMs", ""), None)
                complete = _num(_prop(win, "PlexKM.KPI.ActorCompleteMs", ""), None)
                works_ready = _num(_prop(win, "PlexKM.KPI.ActorWorksReadyMs", ""), None)
                if value is not None:
                    actor_samples.append(value)
                if complete is not None:
                    actor_complete_samples.append(complete)
                if works_ready is not None:
                    actor_works_ready_samples.append(works_ready)
                busy_used = int(_num(_prop(win, "PlexKM.KPI.ActorBusyUsed", "0"), 0) or 0)
                proxy_ok = (_prop(win, "PlexKM.KPI.ActorProxy", "0") == "1")
                portrait_violation = int(_num(_prop(win, "PlexKM.KPI.ActorPortraitViolation", "0"), 0) or 0)
                placeholder_visible = int(_num(_prop(win, "PlexKM.KPI.ActorPlaceholderAtVisible", "0"), 0) or 0)
                previsible_net = int(_num(_prop(win, "PlexKM.KPI.ActorPrevisibleNet", "0"), 0) or 0)
                actor_busy_violations += 1 if busy_used else 0
                actor_proxy_misses += 0  # V2613 PC reference: proxy is intentionally off
                actor_portrait_violations += 1 if portrait_violation else 0
                actor_placeholder_visible += 1 if placeholder_visible else 0
                actor_previsible_net_violations += 1 if previsible_net else 0
                _log("KPI_ACTOR_SAMPLE_V2612 actor=%s open_seq=%s visible_ms=%s complete_ms=%s works_ready_ms=%s works=%s first_portrait=%s info_cast_available=%s placeholder_at_visible=%d portrait_violation=%d busy_used=%d previsible_net=%d meta_status=%s proxy=%d" % (
                    _short(_prop(win, "PlexKM.KPI.ActorName", "-"), 50), _prop(win, "PlexKM.KPI.ActorOpenSeq", "-"),
                    _kpi_fmt(value, 0), _kpi_fmt(complete, 0), _kpi_fmt(works_ready, 0),
                    _prop(win, "PlexKM.KPI.ActorWorks", "-"), _short(_prop(win, "PlexKM.KPI.ActorFirstPortraitSource", "-"), 60),
                    _prop(win, "PlexKM.KPI.ActorInfoCastAvailable", "0"), placeholder_visible, portrait_violation, busy_used, previsible_net,
                    _short(_prop(win, "PlexKM.KPI.ActorMetaStatus", "pending"), 32), 1 if proxy_ok else 0
                ))
            actor_upgrade_stamp = _prop(win, "PlexKM.KPI.ActorUpgradeStamp", "")
            if actor_upgrade_stamp and actor_upgrade_stamp != last_actor_upgrade_stamp:
                last_actor_upgrade_stamp = actor_upgrade_stamp
                upgrade_ms = _num(_prop(win, "PlexKM.KPI.ActorUpgradeMs", ""), None)
                status = _prop(win, "PlexKM.KPI.ActorUpgradeStatus", "")
                visual = int(_num(_prop(win, "PlexKM.KPI.ActorUpgradeVisual", "0"), 0) or 0)
                if upgrade_ms is not None and status in ("ready_local", "visual_commit"):
                    actor_upgrade_samples.append(upgrade_ms)
                if str(status).startswith("failed"):
                    actor_upgrade_failures += 1
                actor_upgrade_visual_commits += 1 if (status == "visual_commit" and visual) else 0
                _log("KPI_ACTOR_UPGRADE_V2610 actor=%s status=%s upgrade_ms=%s visual=%d source=%s" % (
                    _short(_prop(win, "PlexKM.KPI.ActorName", "-"), 50), status or "-", _kpi_fmt(upgrade_ms, 0), visual,
                    _short(_prop(win, "PlexKM.KPI.ActorUpgradeSource", "-"), 60)
                ))
            actor_meta_stamp = _prop(win, "PlexKM.KPI.ActorMetaStamp", "")
            if actor_meta_stamp and actor_meta_stamp != last_actor_meta_stamp:
                last_actor_meta_stamp = actor_meta_stamp
                meta_ms = _num(_prop(win, "PlexKM.KPI.ActorMetaReadyMs", ""), None)
                meta_status = _prop(win, "PlexKM.KPI.ActorMetaStatus", "")
                if meta_ms is not None and str(meta_status).startswith("ready"):
                    actor_meta_samples.append(meta_ms)
                    actor_meta_ready_events += 1
                if str(meta_status).startswith("failed"):
                    actor_meta_failures += 1
                if meta_status == "unavailable":
                    actor_meta_unavailable += 1
                _log("KPI_ACTOR_META_V2611 actor=%s status=%s meta_ready_ms=%s tmdb=%s bio=%s birthday=%s source=%s" % (
                    _short(_prop(win, "PlexKM.KPI.ActorName", "-"), 50), meta_status or "-", _kpi_fmt(meta_ms, 0),
                    _prop(win, "PlexKM.KPI.ActorMetaTmdb", "0"), _prop(win, "PlexKM.KPI.ActorMetaHasBio", "0"),
                    _prop(win, "PlexKM.KPI.ActorMetaHasBirthday", "0"), _short(_prop(win, "PlexKM.KPI.ActorMetaSource", "-"), 60)
                ))
            sort_stamp = _prop(win, "PlexKM.KPI.SortStamp", "")
            if sort_stamp and sort_stamp != last_sort_stamp:
                last_sort_stamp = sort_stamp
                sort_ms = _num(_prop(win, "PlexKM.KPI.SortVisibleMs", ""), None)
                cold = int(_num(_prop(win, "PlexKM.KPI.SortCold", "0"), 0) or 0)
                spinner = int(_num(_prop(win, "PlexKM.KPI.SortSpinnerUsed", "0"), 0) or 0)
                media = _prop(win, "PlexKM.KPI.SortMedia", "-")
                if sort_ms is not None:
                    (sort_cold_samples if cold else sort_warm_samples).append(sort_ms)
                sort_spinner_uses += 1 if spinner else 0
                sort_movie_n += 1 if media == "movie" else 0
                sort_tv_n += 1 if media == "tv" else 0
                _log("KPI_SORT_SAMPLE_V2610 media=%s section=%s sort=%s dir=%s cold=%d visible_ms=%s spinner=%d warm_source=%s reason=%s" % (
                    media, _prop(win, "PlexKM.KPI.SortSection", "-"), _prop(win, "PlexKM.KPI.SortKey", "-"),
                    _prop(win, "PlexKM.KPI.SortDir", "-"), cold, _kpi_fmt(sort_ms, 0), spinner,
                    _prop(win, "PlexKM.KPI.SortWarmSource", "-"), _short(_prop(win, "PlexKM.KPI.SortReason", "-"), 80)
                ))
            sidebar_stamp = _prop(win, "PlexKM.KPI.SidebarStamp", "")
            if sidebar_stamp and sidebar_stamp != last_sidebar_stamp:
                last_sidebar_stamp = sidebar_stamp
                value = _num(_prop(win, "PlexKM.KPI.SidebarSceneMs", ""), None)
                if value is not None:
                    sidebar_samples.append(value)
            library_stamp = _prop(win, "PlexKM.KPI.LibraryStamp", "")
            if library_stamp and library_stamp != last_library_stamp:
                last_library_stamp = library_stamp
                value = _num(_prop(win, "PlexKM.KPI.LibraryVisibleMs", ""), None)
                spinner_used = int(_num(_prop(win, "PlexKM.KPI.LibrarySpinnerUsed", "0"), 0) or 0)
                if value is not None:
                    library_samples.append(value)
                library_spinner_uses += 1 if spinner_used else 0
                _log("KPI_LIBRARY_SAMPLE_V2610 visible_ms=%s spinner=%d reason=%s" % (
                    _kpi_fmt(value, 0), spinner_used, _short(_prop(win, "PlexKM.KPI.LibraryReason", "-"), 80)
                ))
            append_violation_stamp = _prop(win, "PlexKM.KPI.AppendFgViolationStamp", "")
            if append_violation_stamp and append_violation_stamp != last_append_violation_stamp:
                last_append_violation_stamp = append_violation_stamp
                append_fg_violations += 1
                _log("KPI_APPEND_FOREGROUND_VIOLATION_V2610 count=%d stamp=%s" % (append_fg_violations, append_violation_stamp))

            # Publish properties consumed directly by skin XML.
            _set(win, "PlexKM.Diag.State", state)
            _set(win, "PlexKM.Diag.StateAge", "%.1fs" % max(0.0, started - state_enter_at))
            _set(win, "PlexKM.Diag.Event", _short(last_event, 78))
            _set(win, "PlexKM.Diag.EventAge", "%.1fs" % max(0.0, started - last_event_at))
            _set(win, "PlexKM.Diag.HeartbeatLagMs", "%.0f" % lag_ms)
            _set(win, "PlexKM.Diag.HeartbeatMaxMs", "%.0f" % max_lag_ms)
            _set(win, "PlexKM.Diag.CostMs", "%.1f" % last_cost_ms)
            _set(win, "PlexKM.Diag.CostMaxMs", "%.1f" % max_cost_ms)
            _set(win, "PlexKM.Diag.Threads", str(threading.active_count()))
            _set(win, "PlexKM.Diag.WindowId", window_id)
            _set(win, "PlexKM.Diag.Window", _short(window_name, 34))
            _set(win, "PlexKM.Diag.ControlId", control_id)
            _set(win, "PlexKM.Diag.Control", _short(control_name, 34))
            _set(win, "PlexKM.Diag.SidebarIndex", sidebar_index)
            _set(win, "PlexKM.Diag.SidebarLabel", _short(sidebar_label, 34))
            _set(win, "PlexKM.Diag.WallState", wall_state)
            _set(win, "PlexKM.Diag.HomeState", home_state)
            _set(win, "PlexKM.Diag.GuiBusy", "ON" if gui_busy else "OFF")

            _set(win, "PlexKM.Diag.FpsLow2", "%.1f" % fps_low2 if fps_low2 is not None else "-")
            _set(win, "PlexKM.Diag.FpsMin", "%.1f" % fps_session_min if fps_session_min is not None else "-")
            _set(win, "PlexKM.Diag.CpuMax2", "%.0f%%" % cpu_max2 if cpu_max2 is not None else "-")
            _set(win, "PlexKM.Diag.CpuMax", "%.0f%%" % cpu_session_max if cpu_session_max is not None else "-")

            _set(win, "PlexKM.Diag.SidebarSettleMs", _fmt_ms(sidebar_settle_ms))
            _set(win, "PlexKM.Diag.SidebarBurst", str(sidebar_burst))
            _set(win, "PlexKM.Diag.SidebarBurstMax", str(sidebar_burst_max))
            _set(win, "PlexKM.Diag.SidebarGapMs", _fmt_ms(sidebar_last_gap_ms))
            _set(win, "PlexKM.Diag.SidebarContentFirstMs", _fmt_ms(sidebar_content_first_ms))
            _set(win, "PlexKM.Diag.SidebarContentLastMs", _fmt_ms(sidebar_content_last_ms))
            _set(win, "PlexKM.Diag.SidebarPending", "1" if sidebar_pending else "0")

            _set(win, "PlexKM.Diag.HomeReadyMs", _fmt_ms(home_ready_ms))
            _set(win, "PlexKM.Diag.WallOpenMs", _fmt_ms(wall_open_ms))
            _set(win, "PlexKM.Diag.Uptime", "%.1fs" % max(0.0, started - t0))

            _set(win, "PlexKM.Diag.BgThreads", str(activity.get("bg", 0)))
            _set(win, "PlexKM.Diag.PlexThreads", str(activity.get("plex", 0)))
            _set(win, "PlexKM.Diag.SqlThreads", str(activity.get("sql", 0)))
            _set(win, "PlexKM.Diag.WarmThreads", str(activity.get("warm", 0)))
            _set(win, "PlexKM.Diag.SyncThreads", str(activity.get("sync", 0)))
            _set(win, "PlexKM.Diag.Hot", _short(hot, 88))

            last_window_id = window_id
            last_window_name = window_name
            last_control_id = control_id
            last_sidebar_index = sidebar_index
            last_sidebar_label = sidebar_label
            last_wall_state = wall_state
            last_home_state = home_state

            last_cost_ms = max(0.0, (time.monotonic() - started) * 1000.0)
            max_cost_ms = max(max_cost_ms, last_cost_ms)
            cost_now = time.monotonic()
            cost_hist.append((cost_now, last_cost_ms))
            while cost_hist and cost_now - cost_hist[0][0] > 2.2:
                cost_hist.popleft()
            cost_max2 = max((v for _, v in cost_hist), default=0.0)
            _set(win, "PlexKM.Diag.CostMs", "%.1f" % last_cost_ms)
            _set(win, "PlexKM.Diag.CostMaxMs", "%.1f" % max_cost_ms)

            py_threads_now = int(threading.active_count())
            steady_active = bool(home_ready and kpi_steady_after is not None and started >= kpi_steady_after)
            if steady_active:
                steady_lag_samples.append(lag_ms)
                if fps_low2 is not None:
                    steady_fps_low2_min = fps_low2 if steady_fps_low2_min is None else min(steady_fps_low2_min, fps_low2)
                steady_cost_max2_peak = max(steady_cost_max2_peak, cost_max2)
                steady_py_threads_peak = max(steady_py_threads_peak, py_threads_now)
                steady_bg_threads_peak = max(steady_bg_threads_peak, int(activity.get("bg", 0) or 0))
                steady_plex_threads_peak = max(steady_plex_threads_peak, int(activity.get("plex", 0) or 0))
                steady_sql_threads_peak = max(steady_sql_threads_peak, int(activity.get("sql", 0) or 0))
                steady_warm_threads_peak = max(steady_warm_threads_peak, int(activity.get("warm", 0) or 0))

            # One compact KPI line per second. FPS/CPU/diagnostic cost are
            # observation-only. Runtime grade reflects steady heartbeat only.
            if cost_now - last_kpi_log >= KPI_LOG_SEC:
                last_kpi_log = cost_now
                lag_grade = _kpi_grade_le(lag_max2, 30.0, 80.0) if steady_active else "WARMUP"
                runtime_grade = lag_grade
                info_last = info_samples[-1] if info_samples else None
                actor_last = actor_samples[-1] if actor_samples else None
                sidebar_last = sidebar_samples[-1] if sidebar_samples else None
                library_last = library_samples[-1] if library_samples else None
                _log(
                    "[PKM_KPI_V2617] profile=%s runtime=%s steady=%d state=%s fps_low2_obs=%s fps_min_obs=%s "
                    "cpu_max2_obs=%s lag_ms=%.0f lag_max2=%.0f lag_grade=%s lag_p95_steady=%s "
                    "diag_cost_ms_obs=%.1f diag_cost_max2_obs=%.1f home_ready_ms=%s wall_open_ms=%s "
                    "sidebar_quiet_ms_obs=%s sidebar_scene_ms=%s library_visible_ms=%s library_spinner_uses=%d info_visible_ms=%s actor_visible_ms=%s "
                    "info_pre_sql_violations=%d info_pre_net_violations=%d actor_busy_violations=%d append_fg_violations=%d "
                    "proxy_info_miss=%d proxy_actor_miss=%d gui_busy=%d py_threads=%d bg=%d plex_net=%d sql_db=%d warm=%d sync=%d" % (
                        KPI_PROFILE, runtime_grade, 1 if steady_active else 0, state.replace(" ", "_"),
                        _kpi_fmt(fps_low2, 1), _kpi_fmt(fps_session_min, 1), _kpi_fmt(cpu_max2, 0),
                        lag_ms, lag_max2, lag_grade, _kpi_fmt(_kpi_p95(steady_lag_samples), 0),
                        last_cost_ms, cost_max2, _kpi_fmt(home_ready_ms, 0), _kpi_fmt(wall_open_ms, 0),
                        _kpi_fmt(sidebar_settle_ms, 0), _kpi_fmt(sidebar_last, 1), _kpi_fmt(library_last, 0), library_spinner_uses, _kpi_fmt(info_last, 0), _kpi_fmt(actor_last, 0),
                        info_pre_sql_violations, info_pre_net_violations, actor_busy_violations, append_fg_violations,
                        info_proxy_misses, actor_proxy_misses, 1 if gui_busy else 0, py_threads_now,
                        int(activity.get("bg", 0) or 0), int(activity.get("plex", 0) or 0), int(activity.get("sql", 0) or 0),
                        int(activity.get("warm", 0) or 0), int(activity.get("sync", 0) or 0)
                    )
                )

            # Rolling summary: only meaningful device-proxy signals are graded.
            if home_ready and steady_active and cost_now - last_summary_log >= KPI_SUMMARY_SEC:
                last_summary_log = cost_now
                info_p95 = _kpi_p95(info_samples)
                actor_p95 = _kpi_p95(actor_samples)
                actor_complete_p95 = _kpi_p95(actor_complete_samples)
                actor_works_ready_p95 = _kpi_p95(actor_works_ready_samples)
                actor_upgrade_p95 = _kpi_p95(actor_upgrade_samples)
                actor_meta_p95 = _kpi_p95(actor_meta_samples)
                sidebar_p95 = _kpi_p95(sidebar_samples)
                library_p95 = _kpi_p95(library_samples)
                sort_warm_p95 = _kpi_p95(sort_warm_samples)
                sort_cold_p95 = _kpi_p95(sort_cold_samples)
                lag_p95 = _kpi_p95(steady_lag_samples)
                home_grade = _kpi_grade_le(home_ready_ms, 3000.0, 3500.0)
                lag_grade = _kpi_grade_le(lag_p95, 30.0, 80.0)
                info_grade = _kpi_grade_le(info_p95, 300.0, 350.0)
                actor_grade = _kpi_grade_le(actor_p95, 200.0, 250.0)
                actor_complete_grade = _kpi_grade_le(actor_complete_p95, 250.0, 350.0)
                # V2613 PC reference: pre-visible network is allowed because the
                # desktop is the full-function reference.  What matters here is
                # visible completeness and how quickly metadata/portrait are ready.
                actor_portrait_grade = "PASS" if actor_portrait_violations == 0 else "FAIL"
                actor_upgrade_time_grade = _kpi_grade_le(actor_upgrade_p95, 500.0, 1500.0)
                actor_upgrade_grade = "FAIL" if actor_upgrade_failures else actor_upgrade_time_grade
                actor_meta_time_grade = _kpi_grade_le(actor_meta_p95, 300.0, 1000.0)
                actor_meta_grade = "FAIL" if actor_meta_failures else actor_meta_time_grade
                sidebar_grade = _kpi_grade_le(sidebar_p95, 200.0, 250.0)
                library_grade = _kpi_grade_le(library_p95, 500.0, 1000.0)
                sort_warm_grade = _kpi_grade_le(sort_warm_p95, 250.0, 400.0)
                sort_cold_grade = _kpi_grade_le(sort_cold_p95, 500.0, 1000.0)
                _sort_sample_n_v2612 = len(sort_warm_samples) + len(sort_cold_samples)
                sort_spinner_grade = ("PASS" if sort_spinner_uses == 0 else "FAIL") if _sort_sample_n_v2612 else "NA"
                sort_grade = _kpi_overall([sort_warm_grade, sort_cold_grade, sort_spinner_grade]) if _sort_sample_n_v2612 else "NA"
                # U+ structural restrictions are observation-only on PC reference.
                io_grade = "OBS"
                busy_grade = "OBS"
                append_grade = "OBS"
                proxy_grade = "OFF"
                grades = [home_grade, lag_grade, info_grade, actor_grade, actor_complete_grade, actor_portrait_grade, actor_upgrade_grade, actor_meta_grade, sidebar_grade, library_grade, sort_grade]
                nonactor_grade = _kpi_overall([home_grade, lag_grade, info_grade, sidebar_grade, library_grade, sort_grade])
                _log(
                    "[PKM_KPI_SUMMARY_V2617] profile=%s result=%s nonactor_result=%s home_ready_ms=%s home_grade=%s "
                    "heartbeat_p95_ms=%s heartbeat_grade=%s info_p95_ms=%s info_n=%d info_grade=%s "
                    "actor_p95_ms=%s actor_n=%d actor_grade=%s actor_complete_p95_ms=%s actor_complete_grade=%s actor_works_ready_p95_ms=%s "
                    "actor_portrait_violations=%d actor_placeholder_visible=%d actor_previsible_net_violations=%d actor_portrait_grade=%s "
                    "actor_upgrade_p95_ms=%s actor_upgrade_n=%d actor_upgrade_failures=%d actor_upgrade_visual_commits=%d actor_upgrade_grade=%s "
                    "actor_meta_p95_ms=%s actor_meta_n=%d actor_meta_ready=%d actor_meta_unavailable=%d actor_meta_failures=%d actor_meta_grade=%s "
                    "sidebar_scene_p95_ms=%s sidebar_n=%d sidebar_grade=%s library_visible_p95_ms=%s library_n=%d library_grade=%s library_spinner_uses=%d "
                    "sort_warm_p95_ms=%s sort_warm_n=%d sort_warm_grade=%s sort_cold_p95_ms=%s sort_cold_n=%d sort_cold_grade=%s "
                    "sort_movie_n=%d sort_tv_n=%d sort_spinner_uses=%d sort_spinner_grade=%s sort_grade=%s "
                    "info_pre_sql_violations=%d info_pre_net_violations=%d io_grade=%s actor_busy_violations=%d busy_grade=%s "
                    "append_fg_violations=%d append_grade=%s proxy_info_miss=%d proxy_actor_miss=%d proxy_grade=%s fps_low2_steady_min_obs=%s diag_cost_peak_obs=%.1f "
                    "py_threads_peak=%d bg_peak=%d plex_net_peak=%d sql_db_peak=%d warm_peak=%d note=fps_cpu_diag_cost_sidebar_quiet_observe_only" % (
                        KPI_PROFILE, _kpi_overall(grades), nonactor_grade, _kpi_fmt(home_ready_ms, 0), home_grade,
                        _kpi_fmt(lag_p95, 0), lag_grade, _kpi_fmt(info_p95, 0), len(info_samples), info_grade,
                        _kpi_fmt(actor_p95, 0), len(actor_samples), actor_grade, _kpi_fmt(actor_complete_p95, 0), actor_complete_grade, _kpi_fmt(actor_works_ready_p95, 0),
                        actor_portrait_violations, actor_placeholder_visible, actor_previsible_net_violations, actor_portrait_grade,
                        _kpi_fmt(actor_upgrade_p95, 0), len(actor_upgrade_samples), actor_upgrade_failures, actor_upgrade_visual_commits, actor_upgrade_grade,
                        _kpi_fmt(actor_meta_p95, 0), len(actor_meta_samples), actor_meta_ready_events, actor_meta_unavailable, actor_meta_failures, actor_meta_grade,
                        _kpi_fmt(sidebar_p95, 1), len(sidebar_samples), sidebar_grade, _kpi_fmt(library_p95, 0), len(library_samples), library_grade, library_spinner_uses,
                        _kpi_fmt(sort_warm_p95, 0), len(sort_warm_samples), sort_warm_grade, _kpi_fmt(sort_cold_p95, 0), len(sort_cold_samples), sort_cold_grade,
                        sort_movie_n, sort_tv_n, sort_spinner_uses, sort_spinner_grade, sort_grade,
                        info_pre_sql_violations, info_pre_net_violations, io_grade, actor_busy_violations, busy_grade,
                        append_fg_violations, append_grade, info_proxy_misses, actor_proxy_misses, proxy_grade, _kpi_fmt(steady_fps_low2_min, 1), steady_cost_max2_peak,
                        steady_py_threads_peak, steady_bg_threads_peak, steady_plex_threads_peak, steady_sql_threads_peak, steady_warm_threads_peak
                    )
                )

            _wait_v2617 = max(0.0, next_tick_v2617 - time.monotonic())
            if monitor.waitForAbort(_wait_v2617):
                break
    except Exception as exc:
        _log("WORKER_FAILED %s: %s" % (type(exc).__name__, exc), xbmc.LOGERROR)
    finally:
        _set(win, "PlexKM.Diag.KPIProxyV2605", "0")
        _set(win, "PlexKM.Diag.EnableRuntimeProxyV2613", "0")
        _set(win, "PlexKM.Diag.Active", "0")
        try:
            info_p95 = _kpi_p95(info_samples)
            actor_p95 = _kpi_p95(actor_samples)
            actor_complete_p95 = _kpi_p95(actor_complete_samples)
            actor_works_ready_p95 = _kpi_p95(actor_works_ready_samples)
            actor_upgrade_p95 = _kpi_p95(actor_upgrade_samples)
            actor_meta_p95 = _kpi_p95(actor_meta_samples)
            sidebar_p95 = _kpi_p95(sidebar_samples)
            library_p95 = _kpi_p95(library_samples)
            sort_warm_p95 = _kpi_p95(sort_warm_samples)
            sort_cold_p95 = _kpi_p95(sort_cold_samples)
            lag_p95 = _kpi_p95(steady_lag_samples)
            home_grade = _kpi_grade_le(home_ready_ms, 3000.0, 3500.0)
            lag_grade = _kpi_grade_le(lag_p95, 30.0, 80.0)
            info_grade = _kpi_grade_le(info_p95, 300.0, 350.0)
            actor_grade = _kpi_grade_le(actor_p95, 200.0, 250.0)
            actor_complete_grade = _kpi_grade_le(actor_complete_p95, 250.0, 350.0)
            actor_portrait_grade = "PASS" if actor_portrait_violations == 0 else "FAIL"
            actor_upgrade_grade = "FAIL" if actor_upgrade_failures else _kpi_grade_le(actor_upgrade_p95, 500.0, 1500.0)
            actor_meta_time_grade = _kpi_grade_le(actor_meta_p95, 300.0, 1000.0)
            actor_meta_grade = "FAIL" if actor_meta_failures else actor_meta_time_grade
            sidebar_grade = _kpi_grade_le(sidebar_p95, 200.0, 250.0)
            library_grade = _kpi_grade_le(library_p95, 500.0, 1000.0)
            sort_warm_grade = _kpi_grade_le(sort_warm_p95, 250.0, 400.0)
            sort_cold_grade = _kpi_grade_le(sort_cold_p95, 500.0, 1000.0)
            _sort_sample_n_v2612 = len(sort_warm_samples) + len(sort_cold_samples)
            sort_spinner_grade = ("PASS" if sort_spinner_uses == 0 else "FAIL") if _sort_sample_n_v2612 else "NA"
            sort_grade = _kpi_overall([sort_warm_grade, sort_cold_grade, sort_spinner_grade]) if _sort_sample_n_v2612 else "NA"
            io_grade = "OBS"
            busy_grade = "OBS"
            append_grade = "OBS"
            proxy_grade = "OFF"
            grades = [home_grade, lag_grade, info_grade, actor_grade, actor_complete_grade, actor_portrait_grade, actor_upgrade_grade, actor_meta_grade, sidebar_grade, library_grade, sort_grade]
            nonactor_grade = _kpi_overall([home_grade, lag_grade, info_grade, sidebar_grade, library_grade, sort_grade])
            _log(
                "[PKM_KPI_SUMMARY_V2617] profile=%s result=%s nonactor_result=%s final=1 home_ready_ms=%s heartbeat_p95_ms=%s "
                "info_p95_ms=%s info_n=%d actor_p95_ms=%s actor_n=%d actor_complete_p95_ms=%s actor_works_ready_p95_ms=%s "
                "actor_portrait_violations=%d actor_placeholder_visible=%d actor_previsible_net_violations=%d actor_upgrade_p95_ms=%s actor_upgrade_n=%d actor_upgrade_failures=%d actor_upgrade_visual_commits=%d "
                "actor_meta_p95_ms=%s actor_meta_n=%d actor_meta_ready=%d actor_meta_unavailable=%d actor_meta_failures=%d actor_meta_grade=%s "
                "sidebar_scene_p95_ms=%s sidebar_n=%d library_visible_p95_ms=%s library_n=%d library_spinner_uses=%d "
                "sort_warm_p95_ms=%s sort_warm_n=%d sort_cold_p95_ms=%s sort_cold_n=%d sort_movie_n=%d sort_tv_n=%d sort_spinner_uses=%d sort_grade=%s "
                "info_pre_sql_violations=%d info_pre_net_violations=%d actor_busy_violations=%d append_fg_violations=%d "
                "proxy_info_miss=%d proxy_actor_miss=%d fps_low2_steady_min_obs=%s diag_cost_peak_obs=%.1f py_threads_peak=%d" % (
                    KPI_PROFILE, _kpi_overall(grades), nonactor_grade, _kpi_fmt(home_ready_ms, 0), _kpi_fmt(lag_p95, 0),
                    _kpi_fmt(info_p95, 0), len(info_samples), _kpi_fmt(actor_p95, 0), len(actor_samples), _kpi_fmt(actor_complete_p95, 0), _kpi_fmt(actor_works_ready_p95, 0),
                    actor_portrait_violations, actor_placeholder_visible, actor_previsible_net_violations, _kpi_fmt(actor_upgrade_p95, 0), len(actor_upgrade_samples), actor_upgrade_failures, actor_upgrade_visual_commits,
                    _kpi_fmt(actor_meta_p95, 0), len(actor_meta_samples), actor_meta_ready_events, actor_meta_unavailable, actor_meta_failures, actor_meta_grade,
                    _kpi_fmt(sidebar_p95, 1), len(sidebar_samples), _kpi_fmt(library_p95, 0), len(library_samples), library_spinner_uses,
                    _kpi_fmt(sort_warm_p95, 0), len(sort_warm_samples), _kpi_fmt(sort_cold_p95, 0), len(sort_cold_samples), sort_movie_n, sort_tv_n, sort_spinner_uses, sort_grade,
                    info_pre_sql_violations, info_pre_net_violations, actor_busy_violations, append_fg_violations, info_proxy_misses, actor_proxy_misses, _kpi_fmt(steady_fps_low2_min, 1),
                    steady_cost_max2_peak, steady_py_threads_peak
                )
            )
        except Exception as exc:
            _log("KPI_FINAL_SUMMARY_FAILED %s" % exc, xbmc.LOGWARNING)
        _log("STOP max_lag_ms=%.0f max_diag_cost_ms=%.1f" % (max_lag_ms, max_cost_ms))


def start():
    global _started
    with _start_lock:
        if _started:
            return True
        _started = True
        t = threading.Thread(target=_diag_worker, name="PKMUHD3PerfDiagV5Extended")
        t.daemon = True
        t.start()
        return True


def stop():
    try:
        _stop_event.set()
    except Exception:
        pass
