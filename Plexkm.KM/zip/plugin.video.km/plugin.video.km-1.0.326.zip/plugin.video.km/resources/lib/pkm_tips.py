# -*- coding: utf-8 -*-
"""R315: PKM 팁 엔진 - 숨은 기능(길게 누르기 등)을 가끔 한 줄로 알려준다.

규칙
  * 하루 최대 daily_max(기본 1)번, 아직 안 본 팁 중 랜덤.  같은 팁은 최대 3번.
  * 사용자가 그 기능을 직접 쓰면(mark_used) 팁은 졸업(다시 안 뜸).
  * 설정 pkm_tips_enabled=false 이면 아무것도 안 뜸.  초기화: `reset()`.
  * 화면 포커스를 가져가지 않는다(기존 PlexKM 알림 카드 / 재생 중 얇은 띠만 사용).

구성
  * state: addon profile/tips_state.json
  * start_ticker(): service 가 한 번 호출. 1초마다 포커스/재생 상태만 보고 조건이 맞으면 show().
  * mark_used(tip_id) / note_event(name): 기능 사용 지점에서 호출(실패해도 무시).
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import random
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.km"
MAX_SHOWN = 3            # 같은 팁 최대 노출 횟수
DWELL_TICKS = 5          # 같은 컨트롤에 이만큼(초) 머물면 후보
WARMUP_SEC = 90          # 서비스 시작 직후에는 띄우지 않음
SHOW_PROB = 0.6          # 후보 한 번당 실제로 띄울 확률(랜덤)
NOTICE_MS = 6500
PLAY_TIP_MS = 6000
PLAY_PROP = "PlexKM.Tip.Play"

# Home 행/월(wall)/사이드 메뉴/정렬 버튼 컨트롤 id (plexkm_home_window.py 상수와 동일)
_MENU_ID = 9000
_SORT_ID = 7730
_WALL_ID = 9100
_HOME_ROW_IDS = tuple(range(9410, 9610, 10))

CATALOG = {
    "menu_reorder": {
        "area": "home", "ids": (_MENU_ID,),
        "line1": "메뉴 항목에서 OK를 길게 누르면", "line2": "순서를 바꿀 수 있어요",
    },
    "sort_dir": {
        "area": "home", "ids": (_SORT_ID,),
        "line1": "정렬 버튼을 길게 누르면", "line2": "오름/내림이 바뀌어요",
    },
    "card_menu": {
        "area": "home", "ids": _HOME_ROW_IDS + (_WALL_ID,),
        "line1": "포스터를 길게 누르면", "line2": "즐겨찾기·메타 새로고침 메뉴가 나와요",
    },
    "quick_seek": {
        "area": "play", "need_events": ("short_seek", 3),
        "line1": "← → 나 FF·REW 키를 길게 누르면 빠르게 이동해요",
        "line2": "",
    },
}

_LOCK = threading.RLock()
_EVENTS = {}
_STARTED = time.time()
_TICKER = None


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] TIPS_R315 %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _win():
    return xbmcgui.Window(10000)


def _path():
    try:
        base = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(base):
            os.makedirs(base)
        return os.path.join(base, "tips_state.json")
    except Exception:
        return ""


def _load():
    p = _path()
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("tips", {})
            return data
    except Exception:
        pass
    return {"tips": {}, "day": "", "day_count": 0}


def _save(data):
    p = _path()
    if not p:
        return
    try:
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        pass


def _setting(key, default=""):
    try:
        v = xbmcaddon.Addon(ADDON_ID).getSetting(key)
        return v if v != "" else default
    except Exception:
        return default


def enabled():
    return _setting("pkm_tips_enabled", "true").lower() != "false"


def daily_max():
    try:
        return max(0, int(_setting("pkm_tips_daily_max", "1")))
    except Exception:
        return 1


def mark_used(tip_id):
    """사용자가 그 기능을 직접 썼다 -> 팁 졸업."""
    try:
        with _LOCK:
            d = _load()
            t = d["tips"].setdefault(tip_id, {})
            if not t.get("learned"):
                t["learned"] = True
                _save(d)
                _log("learned id=%s" % tip_id)
    except Exception:
        pass


def dismiss(tip_id):
    """'다시 보지 않기'."""
    try:
        with _LOCK:
            d = _load()
            d["tips"].setdefault(tip_id, {})["dismissed"] = True
            _save(d)
    except Exception:
        pass


def reset():
    """본 팁/졸업/다시 보지 않기 초기화."""
    try:
        with _LOCK:
            _save({"tips": {}, "day": "", "day_count": 0})
        _log("reset")
        return True
    except Exception:
        return False


def note_event(name):
    """재생 중 구간 이동 같은 사건 횟수 기록(세션 메모리)."""
    try:
        _EVENTS[name] = int(_EVENTS.get(name, 0)) + 1
    except Exception:
        pass


def _eligible(tip_id, d):
    t = d["tips"].get(tip_id) or {}
    if t.get("learned") or t.get("dismissed"):
        return False
    if int(t.get("shown", 0)) >= MAX_SHOWN:
        return False
    return True


def _day_ok(d):
    today = time.strftime("%Y-%m-%d")
    if d.get("day") != today:
        d["day"] = today
        d["day_count"] = 0
    return int(d.get("day_count", 0)) < daily_max()


def _account_shown(d, tip_id):
    t = d["tips"].setdefault(tip_id, {})
    t["shown"] = int(t.get("shown", 0)) + 1
    t["last"] = int(time.time())
    d["day_count"] = int(d.get("day_count", 0)) + 1
    d["day"] = time.strftime("%Y-%m-%d")


def _show_home(tip):
    try:
        from resources.lib import pkm_notify
        token = str(int(time.time() * 1000))
        pkm_notify.pkm_notice_set("알아두세요", tip["line1"], tip.get("line2", ""), token=token)
        pkm_notify.pkm_notice_clear_later(token, ms=NOTICE_MS)
        return True
    except Exception as exc:
        _log("show_home_failed %s" % exc, xbmc.LOGWARNING)
        return False


def _show_play(tip):
    try:
        w = _win()
        text = (tip["line1"] + " " + tip.get("line2", "")).strip()
        stamp = "%.3f" % time.time()
        w.setProperty(PLAY_PROP, text)
        w.setProperty(PLAY_PROP + ".Stamp", stamp)

        def _clear():
            try:
                ww = _win()
                if ww.getProperty(PLAY_PROP + ".Stamp") == stamp:
                    ww.clearProperty(PLAY_PROP)
                    ww.clearProperty(PLAY_PROP + ".Stamp")
            except Exception:
                pass
        t = threading.Timer(PLAY_TIP_MS / 1000.0, _clear)
        t.daemon = True
        t.start()
        return True
    except Exception:
        return False


def show(tip_id):
    """조건 확인 후 팁 표시. 표시했으면 True."""
    tip = CATALOG.get(tip_id)
    if not tip or not enabled():
        return False
    with _LOCK:
        d = _load()
        if not _eligible(tip_id, d) or not _day_ok(d):
            return False
        ok = _show_play(tip) if tip["area"] == "play" else _show_home(tip)
        if ok:
            _account_shown(d, tip_id)
            _save(d)
            _log("shown id=%s area=%s" % (tip_id, tip["area"]))
        return ok


# ------------------------------------------------------------------ ticker
def _focused_tip_id():
    """홈 계열 창에서 지금 포커스된 컨트롤에 해당하는 팁 id (없으면 '')."""
    for tid, tip in CATALOG.items():
        if tip["area"] != "home":
            continue
        cond = " | ".join("Control.HasFocus(%d)" % i for i in tip["ids"])
        try:
            if xbmc.getCondVisibility(cond):
                return tid
        except Exception:
            pass
    return ""


def _busy_home():
    w = _win()
    try:
        if w.getProperty("PlexKM.Notify.Active") == "1":
            return True
        if w.getProperty("PlexKM.MainPlaybackActive") == "1":
            return True
    except Exception:
        pass
    return False


def _loop(stop_event=None):
    mon = xbmc.Monitor()
    last_tid, dwell, decided = "", 0, False
    while not mon.abortRequested() and not (stop_event is not None and stop_event.is_set()):
        if mon.waitForAbort(1.0):
            break
        try:
            if time.time() - _STARTED < WARMUP_SEC or not enabled():
                continue
            player = xbmc.Player()
            if player.isPlayingVideo():
                last_tid, dwell, decided = "", 0, False
                tip = CATALOG["quick_seek"]
                name, need = tip["need_events"]
                if (int(_EVENTS.get(name, 0)) >= need
                        and xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
                        and not xbmc.getCondVisibility("Window.IsActive(videoosd)")
                        and not _win().getProperty(PLAY_PROP)
                        and _win().getProperty("PlexKM.SeekOsd.Active") != "1"):
                    _EVENTS[name] = 0
                    if random.random() < SHOW_PROB:
                        show("quick_seek")
                continue
            tid = _focused_tip_id()
            if tid != last_tid:
                last_tid, dwell, decided = tid, 0, False
                continue
            if not tid or decided:
                continue
            dwell += 1
            if dwell >= DWELL_TICKS and not _busy_home():
                decided = True
                if random.random() < SHOW_PROB:
                    show(tid)
        except Exception:
            pass


def start_ticker(stop_event=None):
    global _TICKER
    try:
        if _TICKER is not None and _TICKER.is_alive():
            return
        _TICKER = threading.Thread(target=_loop, args=(stop_event,), name="PKMTipsR315", daemon=True)
        _TICKER.start()
        _log("ticker_started")
    except Exception as exc:
        _log("ticker_failed %s" % exc, xbmc.LOGWARNING)


# ---------------------------------------------------- 로그인 안내 (트레일러 페이지)
def youtube_logged_in():
    """Kodi YouTube 애드온에 구글 로그인이 돼 있는지 (access_manager.json 검사)."""
    try:
        p = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.youtube/access_manager.json")
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        users = (data.get("access_manager") or {}).get("users") or {}
        cur = (data.get("access_manager") or {}).get("current_user", "0")
        u = users.get(cur) or {}
        return bool(u.get("access_token") or u.get("refresh_token"))
    except Exception:
        return False


def login_banner_wanted():
    """트레일러 페이지 배너를 보여줄까 (로그인 안 됨 + 최근에 '나중에'를 누르지 않음)."""
    try:
        if not enabled() or youtube_logged_in():
            return False
        d = _load()
        t = d["tips"].get("yt_login") or {}
        if t.get("dismissed"):
            return False
        return time.time() >= float(t.get("snooze_until", 0))
    except Exception:
        return False


def login_banner_later(days=3):
    try:
        with _LOCK:
            d = _load()
            d["tips"].setdefault("yt_login", {})["snooze_until"] = time.time() + days * 86400
            _save(d)
    except Exception:
        pass


def login_banner_never():
    dismiss("yt_login")


def start_youtube_login():
    """Kodi YouTube 애드온 로그인 창을 띄운다 (애드온이 코드를 보여주면 휴대폰에서 승인)."""
    try:
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.youtube/sign/in/)")
        _log("youtube_login_started")
        return True
    except Exception:
        return False


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "reset":
        reset()
        try:
            xbmcgui.Dialog().notification("PlexKM", "팁을 다시 보여줍니다", xbmcgui.NOTIFICATION_INFO, 2500)
        except Exception:
            pass
