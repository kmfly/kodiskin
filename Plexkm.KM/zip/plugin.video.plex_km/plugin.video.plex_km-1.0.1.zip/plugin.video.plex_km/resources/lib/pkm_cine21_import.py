# -*- coding: utf-8 -*-
"""PKM Cine21 ratings DB import/match helpers.

Data-only Python. This module never controls Kodi focus/navigation/playback and
never runs from Wall/Info drawing.  Wall/Info must read the resulting SQLite
cache only.
"""
from __future__ import absolute_import, unicode_literals

import csv
import datetime
import html
import json
import os
import re
import sqlite3
import time
import traceback

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
except Exception:  # pragma: no cover - legacy fallback
    from urllib2 import Request, urlopen
    from urllib import urlencode

try:
    import xbmc
except Exception:
    xbmc = None

VERSION = "v777"
ADDON_ID = "plugin.video.plex_km"

CINE21_POINT_URL = "https://cine21.com/movie/point/list_items"
CINE21_POINT_ORDERS = (
    "review20_dt", "review20_avg", "review20_cnt",
    "nz_dt", "nz_avg", "nz_cnt",
)

_ROMAN_NUMERAL_MAP = {
    "Ⅰ": "1", "Ⅱ": "2", "Ⅲ": "3", "Ⅳ": "4", "Ⅴ": "5",
    "Ⅵ": "6", "Ⅶ": "7", "Ⅷ": "8", "Ⅸ": "9", "Ⅹ": "10",
}
_FILE_MARKER_RE = re.compile(
    r"(?ix)(\b(19|20)\d{2}\b|\b(480p|720p|1080p|2160p|4k|uhd|hdr|hdr10|dv|dolby|atmos)\b|"
    r"\b(web[-_. ]?dl|webrip|bluray|brrip|dvdrip|hdrip|xvid|x264|x265|h264|hevc)\b|"
    r"\b(aac|dts|truehd|flac|mp3)\b|\b(rarbg|yts|vxt|evo|etrg|ganool|amiable|sparks|criterion)\b|"
    r"\.(mkv|mp4|avi|mov|wmv|m2ts|ts)$)"
)
_VIDEO_EXT_RE = re.compile(r"(?i)\.(mkv|mp4|avi|mov|wmv|m2ts|ts|flv|webm)$")
_BRACKET_RE = re.compile(r"[\[\]\(\)【】『』《》〈〉]")
_PUNCT_TO_SPACE_RE = re.compile(r"[·ㆍ・:：;；,，.!?？／/\\|_+=~`“”\"'‘’]")
_DASH_RE = re.compile(r"[-–—]+")
_MULTI_SPACE_RE = re.compile(r"\s+")
_SEASON_EP_RE = re.compile(r"(?i)\b(s\d{1,2}e\d{1,3}|s\d{1,2}|e\d{1,3})\b")


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log("[%s] [PKM_CINE21_IMPORT] %s" % (ADDON_ID, message), level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _safe_str(value):
    if value is None:
        return ""
    return str(value).strip()

def _row_get(row, key, index=None, default=None):
    """Return a value from sqlite3.Row, dict, or tuple/list.

    v774 assumed sqlite3.Row in build_matches(), but PKM init_db() can return
    tuple rows.  This caused TypeError when importing cine21_rate_build.db from
    the real settings menu.  v775 keeps the matching rules unchanged and only
    makes row access compatible.
    """
    if row is None:
        return default
    try:
        if isinstance(row, dict):
            return row.get(key, default)
    except Exception:
        pass
    try:
        return row[key]
    except Exception:
        pass
    if index is not None:
        try:
            return row[index]
        except Exception:
            pass
    return default


def _nfkc(text):
    try:
        text = html.unescape(_safe_str(text))
    except Exception:
        text = _safe_str(text)
    try:
        import unicodedata
        text = unicodedata.normalize("NFKC", text)
    except Exception:
        pass
    for k, v in _ROMAN_NUMERAL_MAP.items():
        text = text.replace(k, v)
    return text


def normalize_title(text):
    text = _nfkc(text).lower()
    text = _VIDEO_EXT_RE.sub("", text)
    text = _BRACKET_RE.sub(" ", text)
    text = _DASH_RE.sub(" ", text)
    text = _PUNCT_TO_SPACE_RE.sub(" ", text)
    text = re.sub(r"\s*&\s*", " and ", text)
    text = _SEASON_EP_RE.sub(" ", text)
    text = _MULTI_SPACE_RE.sub(" ", text).strip()
    return text


def normalize_no_space(text):
    return normalize_title(text).replace(" ", "")


def normalize_main_title(text):
    text = _nfkc(text)
    parts = re.split(r"\s*[:：]\s*|\s+[–—-]\s+", text, maxsplit=1)
    return normalize_title(parts[0] if parts else text)


def normalize_main_no_space(text):
    return normalize_main_title(text).replace(" ", "")


def is_probably_filename(title):
    t = _safe_str(title)
    if not t:
        return False
    dot_count = t.count(".")
    has_marker = bool(_FILE_MARKER_RE.search(t))
    has_video_ext = bool(_VIDEO_EXT_RE.search(t))
    release_like = dot_count >= 3 and bool(re.search(r"\b(19|20)\d{2}\b", t)) and has_marker
    return has_video_ext or release_like or (dot_count >= 4 and has_marker)


def filename_to_guess(media_file):
    base = os.path.basename(_safe_str(media_file))
    base = _VIDEO_EXT_RE.sub("", base)
    base = re.sub(r"(?i)\b(19|20)\d{2}\b.*$", "", base)
    base = re.sub(r"(?i)\b(480p|720p|1080p|2160p|4k|uhd|web[-_. ]?dl|webrip|bluray|brrip|x264|x265|h264|hevc).*$", "", base)
    base = re.sub(r"[-_.]+", " ", base)
    base = _MULTI_SPACE_RE.sub(" ", base).strip()
    return base


def _norm_path_for_quality(path):
    text = _nfkc(path).lower()
    text = _VIDEO_EXT_RE.sub(" ", text)
    text = _BRACKET_RE.sub(" ", text)
    text = _DASH_RE.sub(" ", text)
    text = _PUNCT_TO_SPACE_RE.sub(" ", text)
    text = re.sub(r"[^0-9a-z가-힣]+", " ", text)
    return _MULTI_SPACE_RE.sub(" ", text).strip()


def _title_candidates_for_quality(pkm):
    vals = [
        pkm.get("title", ""), pkm.get("original_title", ""), pkm.get("sort_title", ""),
        normalize_main_title(pkm.get("title", "")),
        normalize_main_title(pkm.get("original_title", "")),
        normalize_main_title(pkm.get("sort_title", "")),
    ]
    out = []
    seen = set()
    for v in vals:
        n = normalize_title(v)
        ns = normalize_no_space(v)
        if not n:
            continue
        if len(ns) < 4 and not re.fullmatch(r"[가-힣]{2,3}", ns):
            continue
        if ns in seen:
            continue
        seen.add(ns)
        out.append(v)
    return out


def titles_look_related(pkm, media_file):
    media_path_space = _norm_path_for_quality(media_file)
    media_path_ns = media_path_space.replace(" ", "")
    basename_guess_space = normalize_title(filename_to_guess(media_file))
    basename_guess_ns = basename_guess_space.replace(" ", "")
    if not media_path_ns and not basename_guess_ns:
        return True
    for cand in _title_candidates_for_quality(pkm):
        cand_space = normalize_title(cand)
        cand_ns = cand_space.replace(" ", "")
        if not cand_ns:
            continue
        if len(cand_ns) < 4 and not re.fullmatch(r"[가-힣]{2,3}", cand_ns):
            continue
        if cand_ns in media_path_ns or media_path_ns in cand_ns:
            return True
        if basename_guess_ns and (cand_ns in basename_guess_ns or basename_guess_ns in cand_ns):
            return True
        cand_tokens = set(cand_space.split())
        path_tokens = set(media_path_space.split())
        if cand_tokens and path_tokens:
            overlap = len(cand_tokens & path_tokens)
            smaller = max(1, min(len(cand_tokens), len(path_tokens)))
            if float(overlap) / float(smaller) >= 0.60:
                return True
    return False


def _table_exists(conn, name):
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    return row is not None


def _columns(conn, table):
    try:
        return [str(r[1]) for r in conn.execute("PRAGMA table_info(%s)" % table).fetchall()]
    except Exception:
        return []


def _drop_or_rename_incompatible_cine21_tables(conn):
    required_ratings = set(["movie_id", "title", "critic_rating", "audience_rating", "image", "updated_at"])
    required_matches = set([
        "rating_key", "cine21_movie_id", "match_status", "match_type", "match_score", "pkm_quality_status",
        "pkm_title", "pkm_original_title", "pkm_year", "pkm_section_id", "pkm_media_file", "cine21_title",
        "critic_rating", "audience_rating", "updated_at",
    ])
    reset = False
    if _table_exists(conn, "cine21_ratings"):
        cols = set(_columns(conn, "cine21_ratings"))
        if not required_ratings.issubset(cols):
            reset = True
            _log("incompatible cine21_ratings schema=%s" % sorted(cols))
    if _table_exists(conn, "cine21_matches"):
        cols = set(_columns(conn, "cine21_matches"))
        if not required_matches.issubset(cols):
            reset = True
            _log("incompatible cine21_matches schema=%s" % sorted(cols))
    if reset:
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        try:
            if _table_exists(conn, "cine21_ratings"):
                conn.execute("ALTER TABLE cine21_ratings RENAME TO cine21_legacy_ratings_%s" % stamp)
        except Exception:
            conn.execute("DROP TABLE IF EXISTS cine21_ratings")
        try:
            if _table_exists(conn, "cine21_matches"):
                conn.execute("DROP TABLE IF EXISTS cine21_matches")
        except Exception:
            pass
        try:
            if _table_exists(conn, "cine21_match_summary"):
                conn.execute("DROP TABLE IF EXISTS cine21_match_summary")
        except Exception:
            pass
        conn.commit()


def ensure_schema(conn):
    _drop_or_rename_incompatible_cine21_tables(conn)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS cine21_ratings (
            movie_id TEXT PRIMARY KEY,
            title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            image TEXT,
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS cine21_matches (
            rating_key TEXT PRIMARY KEY,
            cine21_movie_id TEXT,
            match_status TEXT,
            match_type TEXT,
            match_score REAL,
            pkm_quality_status TEXT,
            pkm_title TEXT,
            pkm_original_title TEXT,
            pkm_year TEXT,
            pkm_section_id TEXT,
            pkm_media_file TEXT,
            cine21_title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS cine21_match_summary (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_cine21_matches_rating_key ON cine21_matches(rating_key);
        CREATE INDEX IF NOT EXISTS idx_cine21_matches_status ON cine21_matches(match_status);
        CREATE INDEX IF NOT EXISTS idx_cine21_matches_critic ON cine21_matches(critic_rating);
        CREATE INDEX IF NOT EXISTS idx_cine21_matches_audience ON cine21_matches(audience_rating);
        CREATE INDEX IF NOT EXISTS idx_cine21_matches_quality ON cine21_matches(pkm_quality_status);
    """)
    conn.commit()


def _to_float(value):
    s = _safe_str(value)
    if not s:
        return None
    try:
        return float(s)
    except Exception:
        return None


def _source_columns(src, table):
    return [str(r[1]) for r in src.execute("PRAGMA table_info(%s)" % table).fetchall()]


def _first_col(cols, names):
    low = {c.lower(): c for c in cols}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def import_ratings_from_db(conn, ratings_db_path, clear_existing=True, progress_cb=None):
    ensure_schema(conn)
    if not ratings_db_path or not os.path.exists(ratings_db_path):
        raise RuntimeError("ratings DB not found: %s" % ratings_db_path)
    src = sqlite3.connect(ratings_db_path)
    src.row_factory = sqlite3.Row
    try:
        if not _table_exists(src, "cine21_ratings"):
            raise RuntimeError("source DB has no cine21_ratings table")
        cols = _source_columns(src, "cine21_ratings")
        movie_col = _first_col(cols, ["movie_id", "id", "cine21_movie_id"])
        title_col = _first_col(cols, ["title", "movie_title", "cine21_title"])
        critic_col = _first_col(cols, ["critic_rating", "critic", "review20_avg", "review_avg"])
        audience_col = _first_col(cols, ["audience_rating", "audience", "nz_avg", "netizen_rating"])
        image_col = _first_col(cols, ["image", "thumb", "poster"])
        if not movie_col or not title_col:
            raise RuntimeError("source cine21_ratings requires movie_id/title columns; found=%s" % cols)
        select_cols = [
            "%s AS movie_id" % movie_col,
            "%s AS title" % title_col,
            "%s AS critic_rating" % critic_col if critic_col else "NULL AS critic_rating",
            "%s AS audience_rating" % audience_col if audience_col else "NULL AS audience_rating",
            "%s AS image" % image_col if image_col else "'' AS image",
        ]
        rows = src.execute("SELECT %s FROM cine21_ratings" % ", ".join(select_cols)).fetchall()
    finally:
        src.close()
    now = datetime.datetime.now().isoformat(timespec="seconds") if hasattr(datetime.datetime.now(), "isoformat") else str(int(time.time()))
    if progress_cb:
        progress_cb(10, "씨네21 ratings import 준비\n%d개" % len(rows))
    with conn:
        if clear_existing:
            conn.execute("DELETE FROM cine21_ratings")
        batch = []
        done = 0
        for r in rows:
            movie_id = _safe_str(_row_get(r, "movie_id", 0))
            title = _safe_str(_row_get(r, "title", 1))
            if not movie_id or not title:
                continue
            batch.append((movie_id, title, _to_float(_row_get(r, "critic_rating", 2)), _to_float(_row_get(r, "audience_rating", 3)), _safe_str(_row_get(r, "image", 4)), now))
            if len(batch) >= 500:
                conn.executemany("INSERT OR REPLACE INTO cine21_ratings(movie_id,title,critic_rating,audience_rating,image,updated_at) VALUES(?,?,?,?,?,?)", batch)
                done += len(batch)
                batch = []
                if progress_cb:
                    progress_cb(10 + min(25, int(done * 25.0 / max(1, len(rows)))), "씨네21 ratings import 중\n%d / %d" % (done, len(rows)))
        if batch:
            conn.executemany("INSERT OR REPLACE INTO cine21_ratings(movie_id,title,critic_rating,audience_rating,image,updated_at) VALUES(?,?,?,?,?,?)", batch)
            done += len(batch)
    total = conn.execute("SELECT COUNT(*) FROM cine21_ratings").fetchone()[0]
    return int(total or 0)


def load_pkm_movies(conn):
    cols = _columns(conn, "items")
    if "rating_key" not in cols or "title" not in cols:
        raise RuntimeError("items table missing rating_key/title")
    def expr(name, default="''"):
        return name if name in cols else "%s AS %s" % (default, name)
    where = "plex_type='movie'" if "plex_type" in cols else "kodi_type='movie'" if "kodi_type" in cols else "1=1"
    rows = conn.execute("""
        SELECT %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
        FROM items WHERE %s
    """ % (
        expr("rating_key"), expr("section_id"), expr("plex_type"), expr("kodi_type"), expr("title"),
        expr("original_title"), expr("sort_title"), expr("year"), expr("media_file"), expr("raw_json"), expr("thumb"), expr("art"), where
    )).fetchall()
    out = []
    for r in rows:
        rating_key = _safe_str(_row_get(r, "rating_key", 0))
        title = _safe_str(_row_get(r, "title", 4))
        if not rating_key or not title:
            continue
        out.append({
            "rating_key": rating_key,
            "section_id": _safe_str(_row_get(r, "section_id", 1)),
            "title": title,
            "original_title": _safe_str(_row_get(r, "original_title", 5)),
            "sort_title": _safe_str(_row_get(r, "sort_title", 6)),
            "year": _safe_str(_row_get(r, "year", 7)),
            "media_file": _safe_str(_row_get(r, "media_file", 8)),
        })
    return out


class RatingIndex(object):
    def __init__(self, ratings):
        self.by_exact = {}
        self.by_nospace = {}
        self.by_main = {}
        self.by_main_nospace = {}
        for r in ratings:
            for mp, key in ((self.by_exact, normalize_title(r["title"])), (self.by_nospace, normalize_no_space(r["title"])), (self.by_main, normalize_main_title(r["title"])), (self.by_main_nospace, normalize_main_no_space(r["title"]))):
                if key:
                    mp.setdefault(key, []).append(r)

    def _cands(self, items, match_type, score):
        return [dict(i, match_type=match_type, match_score=score) for i in items]

    def _dedup(self, cands):
        seen = set()
        out = []
        for c in cands:
            if c["movie_id"] in seen:
                continue
            seen.add(c["movie_id"])
            out.append(c)
        return out

    def match(self, pkm):
        variants = [pkm.get("title", ""), pkm.get("original_title", ""), pkm.get("sort_title", "")]
        variants = [v for v in variants if _safe_str(v)]
        exact_cands = []
        for t in variants:
            exact_cands.extend(self._cands(self.by_exact.get(normalize_title(t), []), "EXACT_MATCH", 1.0))
        exact_cands = self._dedup(exact_cands)
        if len(exact_cands) == 1:
            return "MATCHED", exact_cands[0], exact_cands
        if len(exact_cands) > 1:
            return "AMBIGUOUS", None, exact_cands
        nospace_cands = []
        for t in variants:
            nospace_cands.extend(self._cands(self.by_nospace.get(normalize_no_space(t), []), "NOSPACE_MATCH", 0.96))
        nospace_cands = self._dedup(nospace_cands)
        if len(nospace_cands) == 1:
            return "MATCHED", nospace_cands[0], nospace_cands
        if len(nospace_cands) > 1:
            return "AMBIGUOUS", None, nospace_cands
        main_cands = []
        for t in variants:
            key = normalize_main_title(t)
            if len(key.replace(" ", "")) < 4:
                continue
            main_cands.extend(self._cands(self.by_main.get(key, []), "MAIN_TITLE_SPACE_MATCH", 0.90))
        main_cands = self._dedup(main_cands)
        if len(main_cands) == 1:
            return "MATCHED", main_cands[0], main_cands
        if len(main_cands) > 1:
            return "AMBIGUOUS", None, main_cands
        main_ns_cands = []
        for t in variants:
            key = normalize_main_no_space(t)
            if len(key) < 4:
                continue
            main_ns_cands.extend(self._cands(self.by_main_nospace.get(key, []), "MAIN_TITLE_NOSPACE_MATCH", 0.88))
        main_ns_cands = self._dedup(main_ns_cands)
        if len(main_ns_cands) == 1:
            return "MATCHED", main_ns_cands[0], main_ns_cands
        if len(main_ns_cands) > 1:
            return "AMBIGUOUS", None, main_ns_cands
        return "NO_MATCH_NOT_IN_CINE21", None, []


def classify_quality(pkm, matched):
    if is_probably_filename(pkm.get("title", "")):
        return "PKM_TITLE_FILENAME"
    if pkm.get("media_file") and not titles_look_related(pkm, pkm.get("media_file")):
        return "MATCHED_BUT_PKM_METADATA_MISMATCH" if matched else "PKM_METADATA_MISMATCH"
    return "PKM_METADATA_OK"


def build_matches(conn, progress_cb=None):
    ensure_schema(conn)
    rating_rows = conn.execute("SELECT movie_id,title,critic_rating,audience_rating,image FROM cine21_ratings").fetchall()
    ratings = []
    for r in rating_rows:
        movie_id = _safe_str(_row_get(r, "movie_id", 0))
        title = _safe_str(_row_get(r, "title", 1))
        if movie_id and title:
            ratings.append({
                "movie_id": movie_id,
                "title": title,
                "critic_rating": _row_get(r, "critic_rating", 2),
                "audience_rating": _row_get(r, "audience_rating", 3),
                "image": _safe_str(_row_get(r, "image", 4)),
            })
    movies = load_pkm_movies(conn)
    idx = RatingIndex(ratings)
    now = datetime.datetime.now().isoformat(timespec="seconds") if hasattr(datetime.datetime.now(), "isoformat") else str(int(time.time()))
    counters = {
        "PKM_MOVIE_ROWS": len(movies), "CINE21_RATINGS_ROWS": len(ratings), "MATCHED": 0, "AMBIGUOUS": 0,
        "NO_MATCH_NOT_IN_CINE21": 0, "PKM_METADATA_OK": 0, "PKM_METADATA_MISMATCH": 0,
        "PKM_TITLE_FILENAME": 0, "MATCHED_BUT_PKM_METADATA_MISMATCH": 0,
        "RATING_CONFIRMED": 0,
    }
    inserts = []
    for i, pkm in enumerate(movies, 1):
        status, chosen, candidates = idx.match(pkm)
        matched = status == "MATCHED" and chosen is not None
        quality = classify_quality(pkm, matched=matched)
        counters[status] = counters.get(status, 0) + 1
        counters[quality] = counters.get(quality, 0) + 1
        if matched:
            cine21_movie_id = chosen["movie_id"]
            match_type = chosen.get("match_type", "")
            match_score = chosen.get("match_score", 0.0)
            cine21_title = chosen["title"]
            critic = chosen.get("critic_rating")
            audience = chosen.get("audience_rating")
            if critic is not None or audience is not None:
                counters["RATING_CONFIRMED"] += 1
        else:
            cine21_movie_id = ""
            match_type = "AMBIGUOUS_CANDIDATES" if status == "AMBIGUOUS" else ""
            match_score = 0.0
            cine21_title = ""
            critic = None
            audience = None
        inserts.append((pkm["rating_key"], cine21_movie_id, status, match_type, match_score, quality, pkm["title"], pkm.get("original_title", ""), pkm.get("year", ""), pkm.get("section_id", ""), pkm.get("media_file", ""), cine21_title, critic, audience, now))
        if progress_cb and (i % 500 == 0 or i == len(movies)):
            progress_cb(40 + min(55, int(i * 55.0 / max(1, len(movies)))), "씨네21 매칭 테이블 생성 중\n%d / %d" % (i, len(movies)))
    with conn:
        conn.execute("DELETE FROM cine21_matches")
        conn.executemany("""
            INSERT OR REPLACE INTO cine21_matches(
                rating_key,cine21_movie_id,match_status,match_type,match_score,pkm_quality_status,
                pkm_title,pkm_original_title,pkm_year,pkm_section_id,pkm_media_file,cine21_title,
                critic_rating,audience_rating,updated_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, inserts)
        conn.execute("DELETE FROM cine21_match_summary")
        for k, v in sorted(counters.items()):
            conn.execute("INSERT OR REPLACE INTO cine21_match_summary(key,value,updated_at) VALUES(?,?,?)", (k, str(v), now))
    return counters


def run_import_and_match(conn, ratings_db_path, progress_cb=None):
    imported = import_ratings_from_db(conn, ratings_db_path, clear_existing=True, progress_cb=progress_cb)
    stats = build_matches(conn, progress_cb=progress_cb)
    stats["imported_ratings_rows"] = imported
    return stats


def get_db_status(conn):
    """Return Cine21 DB build status without creating tables.

    v777: Settings "현재 씨네21 매칭 상태 확인" must not silently create empty
    Cine21 tables and look like a valid DB.  This helper only inspects existing
    tables, so the UI can clearly say that the DB has not been generated/imported.
    """
    status = {
        "has_ratings_table": False,
        "has_matches_table": False,
        "has_summary_table": False,
        "ratings_count": 0,
        "matches_count": 0,
        "summary_count": 0,
        "summary": {},
    }
    try:
        status["has_ratings_table"] = bool(_table_exists(conn, "cine21_ratings"))
        status["has_matches_table"] = bool(_table_exists(conn, "cine21_matches"))
        status["has_summary_table"] = bool(_table_exists(conn, "cine21_match_summary"))
        if status["has_ratings_table"]:
            status["ratings_count"] = int(conn.execute("SELECT COUNT(*) FROM cine21_ratings").fetchone()[0] or 0)
        if status["has_matches_table"]:
            status["matches_count"] = int(conn.execute("SELECT COUNT(*) FROM cine21_matches").fetchone()[0] or 0)
        if status["has_summary_table"]:
            rows = conn.execute("SELECT key,value FROM cine21_match_summary").fetchall()
            status["summary_count"] = len(rows)
            for r in rows:
                status["summary"][str(r[0])] = str(r[1])
    except Exception:
        _log("get_db_status_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc is not None else None)
    status["is_built"] = bool(status.get("ratings_count", 0) > 0 and status.get("matches_count", 0) > 0 and status.get("summary"))
    return status


def get_summary(conn):
    # Keep this for callers that expect schema creation after an import/build path.
    ensure_schema(conn)
    out = {}
    for r in conn.execute("SELECT key,value FROM cine21_match_summary").fetchall():
        out[str(r[0])] = str(r[1])
    return out


def _fmt_rating_value(value):
    try:
        if value is None or _safe_str(value) == "":
            return "-"
        return ("%.2f" % float(value)).rstrip("0").rstrip(".")
    except Exception:
        return _safe_str(value) or "-"


def get_recent_matched_samples(conn, limit=3):
    """Return recent PKM movies that have Cine21 critic/audience ratings.

    v787: root-cause fix for settings freeze.
    Do NOT use a CAST() JOIN between items and cine21_matches.  The previous
    query joined both sides with CAST(i.rating_key AS TEXT)=CAST(m.rating_key AS
    TEXT), which prevents SQLite from using indexes and can scan tens/hundreds
    of millions of row pairs on large libraries.  This helper now performs two
    small bounded SELECTs:
      1) read recent movie candidates from items only
      2) lookup those rating_keys in cine21_matches with an IN list
    No network, no rebuild, no writes.
    """
    ensure_schema(conn)
    try:
        limit = max(1, min(10, int(limit or 3)))
    except Exception:
        limit = 3

    cols = set(_columns(conn, "items"))
    if "rating_key" not in cols or "title" not in cols:
        return []

    # Keep this bounded but wide enough so recent movies with no Cine21 rating
    # do not make the test look empty.
    candidate_limit = max(60, limit * 40)

    def expr(name, default="''"):
        return ("%s" % name) if name in cols else ("%s AS %s" % (default, name))

    movie_where = "plex_type='movie'" if "plex_type" in cols else "kodi_type='movie'" if "kodi_type" in cols else "1=1"
    added_expr = "COALESCE(added_at,0)" if "added_at" in cols else "0"

    movie_sql = """
        SELECT
            %s,
            %s,
            %s,
            %s,
            %s AS added_at
        FROM items
        WHERE %s
        ORDER BY %s DESC, rating_key DESC
        LIMIT ?
    """ % (
        expr("rating_key"), expr("title"), expr("original_title"), expr("year"),
        added_expr, movie_where, added_expr
    )
    movie_rows = conn.execute(movie_sql, (candidate_limit,)).fetchall()
    movies = []
    keys = []
    for r in movie_rows:
        key = _safe_str(_row_get(r, "rating_key", 0))
        if not key:
            continue
        movies.append({
            "rating_key": key,
            "title": _safe_str(_row_get(r, "title", 1)),
            "original_title": _safe_str(_row_get(r, "original_title", 2)),
            "year": _safe_str(_row_get(r, "year", 3)),
            "added_at": _row_get(r, "added_at", 4, 0),
        })
        keys.append(key)
    if not keys:
        return []

    placeholders = ",".join(["?"] * len(keys))
    match_sql = """
        SELECT
            rating_key,
            cine21_movie_id,
            cine21_title,
            critic_rating,
            audience_rating,
            match_type,
            pkm_quality_status
        FROM cine21_matches
        WHERE rating_key IN (%s)
          AND match_status='MATCHED'
          AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
    """ % placeholders
    match_rows = conn.execute(match_sql, keys).fetchall()
    match_by_key = {}
    for r in match_rows:
        key = _safe_str(_row_get(r, "rating_key", 0))
        if key:
            match_by_key[key] = r

    out = []
    for m in movies:
        r = match_by_key.get(m["rating_key"])
        if not r:
            continue
        out.append({
            "rating_key": m["rating_key"],
            "title": m["title"],
            "original_title": m["original_title"],
            "year": m["year"],
            "added_at": m["added_at"],
            "cine21_movie_id": _safe_str(_row_get(r, "cine21_movie_id", 1)),
            "cine21_title": _safe_str(_row_get(r, "cine21_title", 2)),
            "critic_rating": _fmt_rating_value(_row_get(r, "critic_rating", 3)),
            "audience_rating": _fmt_rating_value(_row_get(r, "audience_rating", 4)),
            "match_type": _safe_str(_row_get(r, "match_type", 5)),
            "pkm_quality_status": _safe_str(_row_get(r, "pkm_quality_status", 6)),
        })
        if len(out) >= limit:
            break
    return out


def _strip_tags(s):
    s = re.sub(r"(?is)<script\b.*?</script>", " ", s)
    s = re.sub(r"(?is)<style\b.*?</style>", " ", s)
    s = re.sub(r"(?is)<[^>]+>", " ", s)
    try:
        s = html.unescape(s)
    except Exception:
        pass
    return _MULTI_SPACE_RE.sub(" ", s).strip()


def _http_post(url, data, timeout=10):
    body = urlencode(data).encode("utf-8")
    req = Request(url, data=body, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "text/html, */*; q=0.01",
        "Referer": "https://cine21.com/",
    })
    resp = urlopen(req, timeout=timeout)
    raw = resp.read()
    try:
        return raw.decode("utf-8", "replace")
    except Exception:
        return raw.decode("euc-kr", "replace")


def _parse_point_list_items(html_text):
    # Conservative parser for Cine21 point list fragments.
    # It is used only by the optional long-running generator, not Wall/Info.
    items = []
    links = list(re.finditer(r"/movie/info/\?movie_id=([0-9]+)[^\"']*[\"'][^>]*>(.*?)</a>", html_text, re.I | re.S))
    for m in links:
        movie_id = m.group(1)
        title = _strip_tags(m.group(2))
        if not movie_id or not title or len(title) > 80:
            continue
        start = max(0, m.start() - 500)
        end = min(len(html_text), m.end() + 1200)
        chunk = _strip_tags(html_text[start:end])
        nums = [float(x) for x in re.findall(r"(?<![0-9])([0-9](?:\.[0-9]{1,2})?|10(?:\.0{1,2})?)(?![0-9])", chunk)]
        critic = None
        audience = None
        # Ratings-only list pages usually contain critic/audience in the nearby chunk.
        if nums:
            if len(nums) >= 1:
                critic = nums[0]
            if len(nums) >= 2:
                audience = nums[1]
        image = ""
        im = re.search(r"<img[^>]+src=[\"']([^\"']+)[\"']", html_text[start:end], re.I | re.S)
        if im:
            image = im.group(1)
        items.append({"movie_id": movie_id, "title": title, "critic_rating": critic, "audience_rating": audience, "image": image})
    # de-dup by movie_id preserving order
    seen = set()
    out = []
    for item in items:
        if item["movie_id"] in seen:
            continue
        seen.add(item["movie_id"])
        out.append(item)
    return out


def generate_ratings_db_from_web(out_db_path, progress_cb=None, cancel_cb=None, max_pages_per_order=0, timeout=10):
    if not out_db_path:
        raise RuntimeError("output DB path is empty")
    out_dir = os.path.dirname(out_db_path)
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir)
    conn = sqlite3.connect(out_db_path)
    conn.row_factory = sqlite3.Row
    try:
        ensure_schema(conn)
        conn.execute("DELETE FROM cine21_ratings")
        conn.commit()
        total_pages = 0
        total_rows = 0
        page_errors = 0
        max_pages = int(max_pages_per_order or 0)
        for order_index, order in enumerate(CINE21_POINT_ORDERS, 1):
            page = 1
            empty_streak = 0
            while True:
                if cancel_cb and cancel_cb():
                    return {"cancelled": True, "rows": total_rows, "pages": total_pages, "errors": page_errors, "out_db": out_db_path}
                if max_pages > 0 and page > max_pages:
                    break
                pct = min(95, int(((order_index - 1) / float(len(CINE21_POINT_ORDERS))) * 95.0))
                if progress_cb:
                    progress_cb(pct, "씨네21 평점 DB 새로 생성 중\n%s page %d | 누적 %d개" % (order, page, total_rows))
                try:
                    html_text = _http_post(CINE21_POINT_URL, {"order": order, "p": str(page)}, timeout=timeout)
                    rows = _parse_point_list_items(html_text)
                except Exception as exc:
                    page_errors += 1
                    _log("generate_page_error order=%s page=%s error=%s" % (order, page, exc), xbmc.LOGWARNING if xbmc else None)
                    if page_errors > 20:
                        break
                    page += 1
                    time.sleep(0.3)
                    continue
                total_pages += 1
                if not rows:
                    empty_streak += 1
                    if empty_streak >= 2:
                        break
                else:
                    empty_streak = 0
                    now = datetime.datetime.now().isoformat(timespec="seconds") if hasattr(datetime.datetime.now(), "isoformat") else str(int(time.time()))
                    with conn:
                        for r in rows:
                            # Merge order pages: keep non-null existing ratings.
                            old = conn.execute("SELECT critic_rating,audience_rating FROM cine21_ratings WHERE movie_id=?", (r["movie_id"],)).fetchone()
                            critic = r.get("critic_rating")
                            audience = r.get("audience_rating")
                            if old:
                                if critic is None:
                                    critic = old[0]
                                if audience is None:
                                    audience = old[1]
                            conn.execute("INSERT OR REPLACE INTO cine21_ratings(movie_id,title,critic_rating,audience_rating,image,updated_at) VALUES(?,?,?,?,?,?)", (r["movie_id"], r["title"], critic, audience, r.get("image", ""), now))
                    total_rows = int(conn.execute("SELECT COUNT(*) FROM cine21_ratings").fetchone()[0] or 0)
                page += 1
                time.sleep(0.15)
        return {"rows": total_rows, "pages": total_pages, "errors": page_errors, "out_db": out_db_path}
    finally:
        try:
            conn.close()
        except Exception:
            pass
