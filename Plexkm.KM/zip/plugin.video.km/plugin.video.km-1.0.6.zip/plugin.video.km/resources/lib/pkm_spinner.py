# -*- coding: utf-8 -*-
"""Single source of truth for the PKM Apple ring spinner profile.

The actual animation frames live in the active PKM skin.  This module owns the
persistent add-on setting and mirrors it to Window(10000) properties so every
PKM WindowXML surface (Home, playback opening and fullscreen buffering) uses
exactly the same size without separate per-window defaults.
"""
from __future__ import absolute_import, unicode_literals

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
ADDON = xbmcaddon.Addon(id=ADDON_ID)

STYLE_KEY = "apple_ring"
DEFAULT_SIZE = "medium"
SIZE_ORDER = ("small", "medium", "large")
SIZE_PIXELS = {
    "small": 64,
    "medium": 128,
    "large": 256,
}
SIZE_KO = {
    "small": "소",
    "medium": "중",
    "large": "대",
}


def normalize_size(value):
    value = str(value or "").strip().lower()
    return value if value in SIZE_PIXELS else DEFAULT_SIZE


def get_size():
    try:
        return normalize_size(ADDON.getSetting("spinner_size"))
    except Exception:
        return DEFAULT_SIZE


def get_pixels(size=None):
    return int(SIZE_PIXELS[normalize_size(size if size is not None else get_size())])


def get_label(size=None, include_pixels=True):
    size = normalize_size(size if size is not None else get_size())
    label = "Apple 링 · %s" % SIZE_KO[size]
    if include_pixels:
        label += " (%dpx)" % SIZE_PIXELS[size]
    return label


def set_size(size, reason="settings"):
    size = normalize_size(size)
    try:
        ADDON.setSetting("spinner_size", size)
    except Exception:
        pass
    apply_global_properties(reason=reason or "settings", size=size)
    return size


def apply_global_properties(reason="startup", size=None):
    size = normalize_size(size if size is not None else get_size())
    px = SIZE_PIXELS[size]
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Spinner.Style", STYLE_KEY)
        win.setProperty("PlexKM.Spinner.Size", size)
        win.setProperty("PlexKM.Spinner.PixelSize", str(px))
        win.setProperty("PlexKM.Spinner.Label", get_label(size))
        for candidate in SIZE_ORDER:
            prop = "PlexKM.Spinner.Is%s" % candidate.capitalize()
            if candidate == size:
                win.setProperty(prop, "1")
            else:
                win.clearProperty(prop)
        xbmc.log(
            "[%s] PKM_SPINNER_PROFILE_APPLY_V1636 style=%s size=%s pixels=%d reason=%s" %
            (ADDON_ID, STYLE_KEY, size, px, reason or ""),
            xbmc.LOGINFO,
        )
        return True
    except Exception as exc:
        try:
            xbmc.log(
                "[%s] PKM_SPINNER_PROFILE_APPLY_FAILED_V1636 size=%s reason=%s err=%s" %
                (ADDON_ID, size, reason or "", exc),
                xbmc.LOGWARNING,
            )
        except Exception:
            pass
        return False
