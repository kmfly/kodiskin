# -*- coding: utf-8 -*-
"""R146: resolve a YouTube video id to a stream Kodi's own player can play.

The InnerTube IOS client returns an HLS master playlist (all qualities, muxed
by ffmpeg inside Kodi), ANDROID_VR returns a 360p muxed mp4 as fallback.
Playing inside Kodi means BACK returns straight to the Info page: no YouTube
app, no sign-in screen.
"""
import json
import xbmc

try:
    from urllib.request import Request, urlopen
    from urllib.parse import quote
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen
    from urllib import quote

_API = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"
_CLIENTS = (
    ("ios", {"clientName": "IOS", "clientVersion": "20.10.4", "deviceMake": "Apple",
             "deviceModel": "iPhone16,2", "osName": "iPhone", "osVersion": "18.3.2.22D82"},
     "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"),
    ("android_vr", {"clientName": "ANDROID_VR", "clientVersion": "1.60.19", "deviceMake": "Oculus",
                    "deviceModel": "Quest 3", "osName": "Android", "osVersion": "12L", "androidSdkVersion": 32},
     "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"),
    ("android", {"clientName": "ANDROID", "clientVersion": "20.10.38", "androidSdkVersion": 30,
                 "osName": "Android", "osVersion": "11"},
     "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"),
)


def _log(msg):
    try:
        xbmc.log("[plugin.video.km] YTSTREAM_R146 " + msg, xbmc.LOGINFO)
    except Exception:
        pass


_SKIP_DASH = False
_ISA_ASKED = False
_YT_ASKED = False
_RESTRICTED = False  # last resolve: 1080p exists but needs a PO token (big studios)


def resolve_nodash(video_id):
    global _SKIP_DASH
    _SKIP_DASH = True
    try:
        return resolve(video_id)
    finally:
        _SKIP_DASH = False


def _probe(url, ua, length=0):
    """True when googlevideo serves bytes late in the file.

    Without a PO token YouTube only serves roughly the first minute of the
    adaptive streams of many studio uploads (Netflix, CJ, Warner, Pixar...),
    so probe at 75% of the file, not at the start.
    """
    try:
        a = int(int(length or 0) * 3 // 4)
        req = Request(url, headers={"User-Agent": ua, "Range": "bytes=%d-%d" % (a, a + 2047)})
        r = urlopen(req, timeout=8)
        return r.getcode() in (200, 206)
    except Exception:
        return False


def resolve(video_id):
    """Return (url_with_kodi_headers, mime) or (None, None).

    Order of preference: HLS (all qualities) > validated DASH 1080p (needs
    inputstream.adaptive) > 360p muxed mp4.
    """
    global _RESTRICTED
    _RESTRICTED = False
    muxed = None
    for name, client, ua in _CLIENTS:
        try:
            body = json.dumps({"context": {"client": dict(client, hl="ko", gl="KR")},
                               "videoId": video_id, "contentCheckOk": True, "racyCheckOk": True}).encode("utf-8")
            req = Request(_API, body, {"Content-Type": "application/json", "User-Agent": ua})
            j = json.loads(urlopen(req, timeout=12).read().decode("utf-8"))
            st = (j.get("playabilityStatus") or {}).get("status")
            sd = j.get("streamingData") or {}
            hdr = "|User-Agent=" + quote(ua, safe="")
            if st != "OK":
                _log("no_stream client=%s status=%s id=%s" % (name, st, video_id))
                continue
            if sd.get("hlsManifestUrl"):
                _log("ok client=%s kind=hls id=%s" % (name, video_id))
                return sd["hlsManifestUrl"] + hdr, "application/vnd.apple.mpegurl"
            if sd.get("adaptiveFormats") and not _SKIP_DASH:
                mpd = _build_mpd(sd["adaptiveFormats"], float((j.get("videoDetails") or {}).get("lengthSeconds") or 0), ua)
                if mpd:
                    _log("ok client=%s kind=dash id=%s" % (name, video_id))
                    return ("MPD:" + mpd + hdr), "application/dash+xml"
                _log("dash_rejected client=%s id=%s" % (name, video_id))
            if muxed is None:
                fm = [f for f in (sd.get("formats") or []) if f.get("url")]
                if fm:
                    fm.sort(key=lambda f: int(f.get("height") or 0), reverse=True)
                    muxed = (fm[0]["url"] + hdr, "video/mp4")
                    _log("muxed_candidate client=%s h=%s" % (name, fm[0].get("height")))
        except Exception as exc:
            _log("fail client=%s id=%s err=%s" % (name, video_id, exc))
    if muxed:
        _log("ok kind=mp4 id=%s" % video_id)
        return muxed
    return None, None


def _esc(u):
    return u.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _build_mpd(fmts, seconds, ua=""):
    """Local DASH manifest from the progressive adaptive formats (needs inputstream.adaptive)."""
    try:
        vids = [f for f in fmts if f.get("url") and str(f.get("mimeType", "")).startswith("video/mp4")
                and "avc1" in str(f.get("mimeType", "")) and f.get("indexRange") and f.get("initRange")]
        auds = [f for f in fmts if f.get("url") and str(f.get("mimeType", "")).startswith("audio/mp4")
                and f.get("indexRange") and f.get("initRange")]
        if not vids or not auds:
            return ""
        vids = [f for f in vids if int(f.get("height") or 0) <= 1080] or vids
        vids.sort(key=lambda f: (int(f.get("height") or 0), int(f.get("bitrate") or 0)), reverse=True)
        v = vids[0]
        auds.sort(key=lambda f: int(f.get("bitrate") or 0), reverse=True)
        a = auds[0]
        if ua and not (_probe(v["url"], ua, v.get("contentLength")) and _probe(a["url"], ua, a.get("contentLength"))):
            global _RESTRICTED
            _RESTRICTED = True
            _log("dash_po_restricted video=%sx%s" % (v.get("width"), v.get("height")))
            return ""
        dur = seconds or float(int(v.get("approxDurationMs") or 0)) / 1000.0
        if dur <= 0:
            return ""

        def rep(f, kind):
            codecs = str(f.get("mimeType", "")).split('codecs="')[-1].rstrip('"')
            ir, xr = f["indexRange"], f["initRange"]
            extra = ' width="%s" height="%s" frameRate="%s"' % (f.get("width"), f.get("height"), int(f.get("fps") or 30)) if kind == "video" else ""
            return ('<Representation id="%s" bandwidth="%s" codecs="%s" mimeType="%s"%s>'
                    '<BaseURL>http://127.0.0.1:@PORT@/%s</BaseURL><SegmentBase indexRange="%s-%s"><Initialization range="%s-%s"/></SegmentBase>'
                    '</Representation>') % (f.get("itag"), f.get("bitrate"), codecs,
                                           "video/mp4" if kind == "video" else "audio/mp4", extra, "v" if kind == "video" else "a",
                                           ir["start"], ir["end"], xr["start"], xr["end"])
        mpd = ('<?xml version="1.0" encoding="UTF-8"?>'
               '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT%.3fS" minBufferTime="PT2S" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011">'
               '<Period><AdaptationSet mimeType="video/mp4" subsegmentAlignment="true">%s</AdaptationSet>'
               '<AdaptationSet mimeType="audio/mp4" subsegmentAlignment="true">%s</AdaptationSet></Period></MPD>') % (dur, rep(v, "video"), rep(a, "audio"))
        path = _serve(mpd, {"v": v["url"], "a": a["url"]}, ua)
        _log("mpd video=%sx%s itag=%s audio_itag=%s" % (v.get("width"), v.get("height"), v.get("itag"), a.get("itag")))
        return path
    except Exception as exc:
        _log("mpd_fail %s" % exc)
        return ""


_SRV = None
_UPSTREAM = {}


def _serve(mpd_tpl, urls, ua):
    """Local HTTP server: the manifest plus a tiny reverse proxy for the media.

    googlevideo rejects (403) requests that do not carry the exact client
    User-Agent, and inputstream.adaptive cannot be told to send it for the
    ranged media requests, so the media goes through 127.0.0.1 where the
    right headers are added.  The server is replaced on every new trailer.
    """
    global _SRV, _UPSTREAM
    try:
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    except ImportError:  # pragma: no cover
        return ""
    import threading
    if _SRV is not None:
        try:
            _SRV.shutdown(); _SRV.server_close()
        except Exception:
            pass
    _UPSTREAM = dict(urls)

    class _H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def _go(self, head):
            try:
                if self.path.startswith("/trailer.mpd"):
                    data = mpd_tpl.replace("@PORT@", str(self.server.server_address[1])).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/dash+xml")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    if not head:
                        self.wfile.write(data)
                    return
                up = _UPSTREAM.get(self.path.split("?")[0].strip("/"))
                if not up:
                    self.send_error(404); return
                hdrs = {"User-Agent": ua}
                if self.headers.get("Range"):
                    hdrs["Range"] = self.headers.get("Range")
                if head:
                    hdrs["Range"] = "bytes=0-0"
                try:
                    r = urlopen(Request(up, headers=hdrs), timeout=15)
                except Exception as exc:
                    code = getattr(exc, "code", 502)
                    _log("proxy_upstream_fail %s %s %s rng=%s" % (code, "HEAD" if head else "GET", self.path, hdrs.get("Range")))
                    self.send_error(code if isinstance(code, int) else 502); return
                if head:
                    cr = r.headers.get("Content-Range") or ""
                    total = cr.rpartition("/")[2] or r.headers.get("Content-Length") or "0"
                    self.send_response(200)
                    self.send_header("Content-Type", r.headers.get("Content-Type") or "application/octet-stream")
                    self.send_header("Content-Length", total)
                    self.send_header("Accept-Ranges", "bytes")
                    self.end_headers()
                    return
                self.send_response(r.getcode())
                for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
                    if r.headers.get(k):
                        self.send_header(k, r.headers.get(k))
                self.end_headers()
                if not head:
                    while True:
                        chunk = r.read(65536)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
            except Exception:
                pass

        def do_GET(self):
            self._go(False)

        def do_HEAD(self):
            self._go(True)

        def log_message(self, *a):
            pass

    srv = ThreadingHTTPServer(("127.0.0.1", 0), _H)
    srv.daemon_threads = True
    _SRV = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return "http://127.0.0.1:%d/trailer.mpd" % srv.server_address[1]


def has_isa():
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"))
    except Exception:
        return False


def has_yt_addon():
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"))
    except Exception:
        return False


def play_in_kodi(video_id, title=""):
    import xbmcgui
    isa = has_isa()
    _log("isa_installed=%s" % ("1" if isa else "0"))
    if not isa:
        # Ask Kodi once per session to install inputstream.adaptive (1080p DASH).
        global _ISA_ASKED
        if not _ISA_ASKED:
            _ISA_ASKED = True
            try:
                xbmc.executebuiltin("InstallAddon(inputstream.adaptive)")
                _log("isa_install_requested")
            except Exception:
                pass
    if isa and has_yt_addon():
        # The YouTube add-on gets full-length 1080p (our own resolver only gets
        # ~1 minute of studio uploads without a PO token), so go straight there.
        purl = "plugin://plugin.video.youtube/play/?video_id=%s" % video_id
        _log("route=youtube_addon id=%s" % video_id)
        li = xbmcgui.ListItem(title or "예고편", path=purl)
        li.setInfo("video", {"title": title or "예고편"})
        xbmc.Player().play(purl, li)
        return True
    url, mime = resolve(video_id) if isa else resolve_nodash(video_id)
    if (_RESTRICTED or not url) and isa:
        # 1080p exists but YouTube wants a PO token: the official YouTube
        # add-on (signed in) can play it in full; else keep the 360p stream.
        if has_yt_addon():
            purl = "plugin://plugin.video.youtube/play/?video_id=%s" % video_id
            _log("route=youtube_addon id=%s" % video_id)
            li = xbmcgui.ListItem(title or "예고편", path=purl)
            li.setInfo("video", {"title": title or "예고편"})
            xbmc.Player().play(purl, li)
            return True
        global _YT_ASKED
        if not _YT_ASKED:
            _YT_ASKED = True
            try:
                xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
                _log("yt_addon_install_requested")
            except Exception:
                pass
    if not url:
        return False
    if url.startswith("MPD:"):
        mpd_path, _, hdr = url[4:].partition("|")
        li = xbmcgui.ListItem(title or "예고편", path=mpd_path)
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.stream_headers", hdr)
        li.setProperty("inputstream.adaptive.manifest_headers", hdr)
        li.setMimeType("application/dash+xml"); li.setContentLookup(False)
        li.setInfo("video", {"title": title or "예고편"})
        xbmc.Player().play(mpd_path, li)
        return True
    li = xbmcgui.ListItem(title or "예고편", path=url)
    li.setProperty("IsPlayable", "true")
    if mime:
        li.setMimeType(mime)
        li.setContentLookup(False)
    li.setInfo("video", {"title": title or "예고편"})
    xbmc.Player().play(url, li)
    return True
