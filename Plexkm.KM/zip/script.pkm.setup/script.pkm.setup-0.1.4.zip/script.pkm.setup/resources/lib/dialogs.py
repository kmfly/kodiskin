# -*- coding: utf-8 -*-
"""PlexKM-styled popups for the setup wizard (replaces Kodi's default dialogs)."""
import xbmc
import xbmcaddon
import xbmcgui

_BACK = (9, 10, 92, 216, 247, 257, 275)


class _PkmDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args)
        self.title = ""
        self.msg = ""
        self.buttons = []
        self.default = 0
        self.result = -1

    def onInit(self):
        self.setProperty("title", self.title)
        self.setProperty("msg", self.msg)
        for i in range(3):
            self.setProperty("btn%d" % (i + 1), self.buttons[i] if i < len(self.buttons) else "")
        try:
            self.setFocusId(11 + min(max(self.default, 0), len(self.buttons) - 1))
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId in (11, 12, 13):
            self.result = controlId - 11
            self.close()

    def onAction(self, action):
        if action.getId() in _BACK:
            self.result = -1
            self.close()
            return
        xbmcgui.WindowXMLDialog.onAction(self, action)


def choose(title, msg, buttons, default=0):
    """Returns the 0-based index of the pressed button, or -1 when closed with Back."""
    path = xbmcaddon.Addon("script.pkm.setup").getAddonInfo("path")
    dlg = _PkmDialog("pkm_dialog.xml", path, "Default", "1080i")
    dlg.title, dlg.msg, dlg.buttons, dlg.default = title, msg, list(buttons)[:3], default
    dlg.doModal()
    r = dlg.result
    del dlg
    return r


def ok(title, msg, button="확인"):
    choose(title, msg, [button])


def yesno(title, msg, yes="예", no="아니오", default_yes=True):
    """True when the first (yes) button is chosen. Back counts as no."""
    return choose(title, msg, [yes, no], 0 if default_yes else 1) == 0
