# -*- coding: utf-8 -*-
"""PKM notification property helpers.

Data-only split from default.py / plexkm_home_window.py.
This module only prepares Window(10000) skin properties for the existing
XML overlay.  It must not change focus, navigation, actions, playback,
or window flow.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui

_NOTIFY_KEYS = (
    "PlexKM.Notify.Active",
    "PlexKM.Notify.Title",
    "PlexKM.Notify.Line1",
    "PlexKM.Notify.Line2",
    "PlexKM.Notify.Token",
    "PlexKM.Notify.Sticky",
    "PlexKM.Notify.HomeOnly",
)


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] %s" % message, level)
    except Exception:
        pass


def _display_text_for_kodi(value):
    """Normalize Plex library title separators for Kodi WindowXML text rendering."""
    text = str(value or "")
    try:
        table = {
            ord("\u007C"): "|",
            ord("\u00A6"): "|",
            ord("\u01C0"): "|",
            ord("\u2016"): "|",
            ord("\u2223"): "|",
            ord("\u2225"): "|",
            ord("\u23AA"): "|",
            ord("\u23D0"): "|",
            ord("\u2502"): "|",
            ord("\u2503"): "|",
            ord("\u2758"): "|",
            ord("\u2759"): "|",
            ord("\u275A"): "|",
            ord("\u3163"): "|",
            ord("\u4E28"): "|",
            ord("\uFF5C"): "|",
            ord("\uFFE8"): "|",
        }
        return text.translate(table)
    except Exception:
        return text


def _sanitize_notice_text(value, max_len=54):
    """Keep PKM notice labels clean: no ellipsis glyphs or Kodi-native truncation hints."""
    text = _display_text_for_kodi(value)
    try:
        text = text.replace("…", " ").replace("...", " ")
        text = " ".join(text.split())
        max_len = int(max_len or 54)
        if max_len > 0 and len(text) > max_len:
            text = text[:max_len].rstrip()
        return text
    except Exception:
        return str(value or "")


def _take_notice_units(value, max_units):
    text = str(value or "").strip()
    if not text:
        return "", ""
    used = 0
    cut = 0
    last_space = -1
    for idx, ch in enumerate(text):
        width = 1 if ord(ch) < 128 else 2
        if used + width > int(max_units or 38):
            break
        used += width
        cut = idx + 1
        if ch.isspace():
            last_space = cut
    if cut >= len(text):
        return text, ""
    if last_space > 0:
        cut = last_space
    return text[:cut].rstrip(), text[cut:].lstrip()


def _fit_notice_lines(line1, line2, max_units=38):
    """Fit notice body into two fixed labels without Kodi-generated ellipsis."""
    text = " ".join([x for x in (str(line1 or "").strip(), str(line2 or "").strip()) if x])
    first, rest = _take_notice_units(text, max_units)
    second, _unused = _take_notice_units(rest, max_units)
    return first, second


def pkm_player_has_video():
    """Return True while Kodi is in video playback/OSD state."""
    try:
        return bool(
            xbmc.Player().isPlayingVideo()
            or xbmc.getCondVisibility("Player.HasVideo")
            or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
            or xbmc.getCondVisibility("Window.IsActive(videoosd)")
        )
    except Exception:
        return False




def _is_update_notice_title(title):
    try:
        return str(title or "").startswith("PKM 업데이트")
    except Exception:
        return False


def _update_notice_home_visible_now(win=None):
    """Update progress/completion notices are allowed only on the PKM Home view.

    Plex offline/connection notices are not update notices and keep their normal
    visibility.  This prevents stale update properties from appearing later when
    a widget receives focus in another PKM area.
    """
    try:
        win = win or xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Window.IsHome") == "1"
            and win.getProperty("PlexKM.Info.InlineActive") != "1"
            and win.getProperty("PlexKM.MainPlaybackActive") != "1"
            and not pkm_player_has_video()
        )
    except Exception:
        return False

def _current_notice_is_sticky(win=None):
    try:
        win = win or xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Notify.Active") == "1"
            and win.getProperty("PlexKM.Notify.Sticky") == "1"
        )
    except Exception:
        return False


def pkm_notice_set(title, line1="", line2="", token="", sticky=False, force_replace=False):
    """Show a PKM top-right notice.

    sticky=True is used for blocking/critical states such as Plex offline.
    Sticky notices stay visible until explicitly cleared with force=True or until
    Plex connectivity is restored.  Transient notices must not overwrite them.
    """
    try:
        token = str(token or int(time.time() * 1000))
        display_title = _sanitize_notice_text(title, 24)
        raw_line1 = _sanitize_notice_text(line1, 0)
        raw_line2 = _sanitize_notice_text(line2, 0)
        display_line1, display_line2 = _fit_notice_lines(raw_line1, raw_line2, max_units=38)
        is_update_notice = _is_update_notice_title(display_title)
        if pkm_player_has_video():
            _log(
                "PKM_NOTICE_SUPPRESS reason=player_active title=%s line1=%s"
                % (display_title, display_line1),
                xbmc.LOGINFO,
            )
            return token
        win = xbmcgui.Window(10000)
        if is_update_notice and not _update_notice_home_visible_now(win):
            _log(
                "PKM_UPDATE_NOTICE_SUPPRESS reason=not_home title=%s line1=%s is_home=%s info=%s"
                % (
                    display_title,
                    display_line1,
                    str(win.getProperty("PlexKM.Window.IsHome") or ""),
                    str(win.getProperty("PlexKM.Info.InlineActive") or ""),
                ),
                xbmc.LOGINFO,
            )
            return token
        if _current_notice_is_sticky(win) and not sticky and not force_replace:
            _log(
                "PKM_NOTICE_SET_SKIP reason=sticky_active active_title=%s new_title=%s"
                % (str(win.getProperty("PlexKM.Notify.Title") or ""), display_title),
                xbmc.LOGINFO,
            )
            return str(win.getProperty("PlexKM.Notify.Token") or token)
        for key, value in (
            ("PlexKM.Notify.Title", display_title),
            ("PlexKM.Notify.Line1", display_line1),
            ("PlexKM.Notify.Line2", display_line2),
            ("PlexKM.Notify.Token", token),
            ("PlexKM.Notify.Sticky", "1" if sticky else "0"),
            ("PlexKM.Notify.HomeOnly", "1" if is_update_notice else "0"),
            ("PlexKM.Notify.Active", "1"),
        ):
            win.setProperty(key, value)
        _log(
            "PKM_NOTICE_SET title=%s line1=%s line2=%s token=%s sticky=%s"
            % (display_title, display_line1, display_line2, str(token or ""), "1" if sticky else "0"),
            xbmc.LOGINFO,
        )
        return token
    except Exception:
        return str(token or "")


def pkm_notice_clear(expected_token="", force=False):
    try:
        win = xbmcgui.Window(10000)
        if expected_token and win.getProperty("PlexKM.Notify.Token") != str(expected_token):
            _log(
                "PKM_NOTICE_CLEAR_SKIP reason=token_mismatch expected=%s active=%s"
                % (str(expected_token or ""), str(win.getProperty("PlexKM.Notify.Token") or "")),
                xbmc.LOGINFO,
            )
            return False
        if _current_notice_is_sticky(win) and not force:
            _log(
                "PKM_NOTICE_CLEAR_SKIP reason=sticky_active title=%s token=%s"
                % (str(win.getProperty("PlexKM.Notify.Title") or ""), str(win.getProperty("PlexKM.Notify.Token") or "")),
                xbmc.LOGINFO,
            )
            return False
        title = win.getProperty("PlexKM.Notify.Title") or ""
        token = win.getProperty("PlexKM.Notify.Token") or ""
        for key in _NOTIFY_KEYS:
            win.clearProperty(key)
        _log("PKM_NOTICE_CLEAR title=%s token=%s force=%s" % (str(title or ""), str(token or ""), "1" if force else "0"), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def pkm_notice_force_clear(expected_token=""):
    return pkm_notice_clear(expected_token=expected_token, force=True)


def pkm_notice_clear_later(expected_token="", ms=1800):
    """Clear the current PKM notice after a short delay if the token still matches.

    This is used for transient completion notices only.  It does not touch
    Kodi focus/navigation/window flow.
    """
    try:
        delay = max(500, int(ms or 1800))

        def _clear(expected):
            try:
                xbmc.sleep(delay)
                pkm_notice_clear(expected)
            except Exception:
                pass

        t = threading.Thread(target=_clear, args=(str(expected_token or ""),))
        t.daemon = True
        t.start()
        _log("PKM_NOTICE_CLEAR_LATER ms=%d token=%s" % (delay, str(expected_token or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def pkm_notice_clear_if_title(prefixes, expected_token="", force=False):
    """Clear only PKM update notices whose title matches one of prefixes."""
    try:
        win = xbmcgui.Window(10000)
        title = win.getProperty("PlexKM.Notify.Title") or ""
        if isinstance(prefixes, str):
            prefixes = [prefixes]
        prefixes = [str(x or "") for x in (prefixes or []) if str(x or "")]
        if not title or not any(title.startswith(x) for x in prefixes):
            return False
        return pkm_notice_clear(expected_token=expected_token, force=force)
    except Exception:
        return False


def pkm_show_notice(title, line1="", line2="", ms=2600):
    try:
        token = pkm_notice_set(title, line1, line2)
        delay = max(700, int(ms or 2600))

        def _clear(expected_token):
            try:
                xbmc.sleep(delay)
                pkm_notice_clear(expected_token)
            except Exception:
                pass

        t = threading.Thread(target=_clear, args=(token,))
        t.daemon = True
        t.start()
        return True
    except Exception:
        return False


def format_startup_sync_notice(stats):
    stats = stats or {}
    movies = int(stats.get("movie", 0) or 0)
    shows = int(stats.get("show", 0) or 0)
    episodes = int(stats.get("episode", 0) or 0)
    parts = []
    if movies:
        parts.append("영화 %d개" % movies)
    if shows:
        parts.append("드라마 %d개" % shows)
    if episodes:
        parts.append("에피소드 %d개" % episodes)
    return " · ".join(parts)
