# -*- coding: utf-8 -*-
"""PKM Watcha Pedia rating DB import helpers.

This module is local-DB only.  It imports a prebuilt watcha_rate_build.db into
PKM's main plex_km.db connection.  It does not crawl Watcha from Kodi UI.
"""
from __future__ import absolute_import, unicode_literals

import os
import re
import sqlite3
import time


def _table_exists(conn, name):
    try:
        row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        return bool(row)
    except Exception:
        return False


def _columns(conn, table):
    try:
        return [str(r[1]) for r in conn.execute("PRAGMA table_info(%s)" % table).fetchall()]
    except Exception:
        return []


def init_watcha_schema(conn):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS watcha_ratings (
            rating_key TEXT PRIMARY KEY,
            title TEXT,
            original_title TEXT,
            year INTEGER,
            section_id TEXT,
            watcha_rating REAL,
            watcha_count TEXT,
            watcha_code TEXT,
            watcha_title TEXT,
            watcha_year TEXT,
            match_status TEXT,
            match_type TEXT,
            match_score REAL,
            error TEXT,
            updated_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_watcha_ratings_status ON watcha_ratings(match_status);
        CREATE INDEX IF NOT EXISTS idx_watcha_ratings_rating_key ON watcha_ratings(rating_key);
        CREATE INDEX IF NOT EXISTS idx_watcha_ratings_code ON watcha_ratings(watcha_code);
        CREATE INDEX IF NOT EXISTS idx_watcha_ratings_title_year ON watcha_ratings(title, year);

        CREATE TABLE IF NOT EXISTS watcha_match_summary (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        );
        """
    )


def _source_columns(src):
    if not _table_exists(src, "watcha_ratings"):
        raise RuntimeError("source DB has no watcha_ratings table")
    cols = set(_columns(src, "watcha_ratings"))
    required = {"rating_key", "title", "match_status"}
    missing = sorted(required - cols)
    if missing:
        raise RuntimeError("source watcha_ratings missing columns: %s" % ",".join(missing))
    return cols


def _select_expr(cols, name, default="NULL"):
    return name if name in cols else ("%s AS %s" % (default, name))




def _source_status_counts(src):
    try:
        return dict((str(k or ""), int(v or 0)) for k, v in src.execute(
            "SELECT COALESCE(match_status,''), COUNT(*) FROM watcha_ratings GROUP BY COALESCE(match_status,'')"
        ).fetchall())
    except Exception:
        return {}


def _source_count(src, sql):
    try:
        row = src.execute(sql).fetchone()
        return int(row[0] or 0) if row else 0
    except Exception:
        return 0


def validate_watcha_source_db(src, total_src, cols):
    """Reject old/unsafe Watcha build DB files before touching plex_km.db.

    The final accepted source is the fix10/fix11 style build DB:
    - no PENDING rows
    - no FALLBACK_TOP_YEAR rows
    - release filename rows are preserved as NO_MATCH with
      release_filename_skipped_for_metadata_rematch
    """
    if total_src <= 0:
        raise RuntimeError("source watcha_ratings is empty")
    if total_src < 10000:
        raise RuntimeError("source watcha_ratings looks too small: %d" % total_src)

    counts = _source_status_counts(src)
    pending = counts.get("PENDING", 0)
    matched = counts.get("MATCHED", 0)
    no_match = counts.get("NO_MATCH", 0)
    missing = counts.get("RATING_MISSING", 0)
    if pending > 0:
        raise RuntimeError("source DB still has PENDING rows: %d" % pending)
    if matched <= 0 or no_match <= 0:
        raise RuntimeError("source DB does not look like completed Watcha build DB: %s" % counts)

    fallback_top_year = _source_count(src, "SELECT COUNT(*) FROM watcha_ratings WHERE match_type='FALLBACK_TOP_YEAR'")
    if fallback_top_year > 0:
        raise RuntimeError("source DB contains old unsafe FALLBACK_TOP_YEAR rows: %d" % fallback_top_year)

    release_skipped = _source_count(src, "SELECT COUNT(*) FROM watcha_ratings WHERE error='release_filename_skipped_for_metadata_rematch'")
    if release_skipped <= 0:
        raise RuntimeError("source DB is not final fix10/fix11 style: release_filename_skipped_for_metadata_rematch=0")

    return {
        "total": total_src,
        "MATCHED": matched,
        "NO_MATCH": no_match,
        "RATING_MISSING": missing,
        "release_skipped": release_skipped,
        "FALLBACK_TOP_YEAR": fallback_top_year,
    }


def backup_existing_watcha_table(conn):
    """Create a local backup of current watcha_ratings before replacement."""
    if not _table_exists(conn, "watcha_ratings"):
        return ""
    try:
        existing = int(conn.execute("SELECT COUNT(*) FROM watcha_ratings").fetchone()[0] or 0)
    except Exception:
        existing = 0
    if existing <= 0:
        return ""
    stamp = time.strftime("%Y%m%d_%H%M%S")
    table = "watcha_ratings_backup_%s" % stamp
    # Extra guard, though stamp collision is unlikely.
    table = re.sub(r"[^A-Za-z0-9_]", "_", table)
    conn.execute("CREATE TABLE %s AS SELECT * FROM watcha_ratings" % table)
    return table

def run_import_watcha_build_db(conn, source_db_path, progress_cb=None):
    """Match a public Watcha Master DB to THIS user's Plex library.

    v2374: source Plex rating_key values are intentionally ignored.  Different
    Plex servers assign different rating_keys to the same movie.  Master rows
    are indexed by normalized title/original title + year, then written back
    using the local PKM item's rating_key.
    """
    source_db_path = os.path.abspath(source_db_path or "")
    if not source_db_path or not os.path.exists(source_db_path):
        raise RuntimeError("watcha_rate_build.db not found: %s" % source_db_path)

    if progress_cb:
        progress_cb(5, "Watcha Pedia Master DB 확인 중")

    src = sqlite3.connect("file:%s?mode=ro" % source_db_path, uri=True)
    try:
        cols = _source_columns(src)
        total_src = int(src.execute("SELECT COUNT(*) FROM watcha_ratings").fetchone()[0] or 0)
        source_validation = validate_watcha_source_db(src, total_src, cols)

        select_cols = [
            _select_expr(cols, "title", "''"),
            _select_expr(cols, "original_title", "''"),
            _select_expr(cols, "year"),
            _select_expr(cols, "watcha_rating"),
            _select_expr(cols, "watcha_count"),
            _select_expr(cols, "watcha_code"),
            _select_expr(cols, "watcha_title", "''"),
            _select_expr(cols, "watcha_year"),
            _select_expr(cols, "match_status", "''"),
            _select_expr(cols, "match_type"),
            _select_expr(cols, "match_score"),
            _select_expr(cols, "updated_at", "''"),
        ]
        source_rows = src.execute(
            "SELECT %s FROM watcha_ratings "
            "WHERE watcha_rating IS NOT NULL AND CAST(watcha_rating AS REAL)>0"
            % ", ".join(select_cols)
        ).fetchall()
    finally:
        src.close()

    # Build a cross-library map. Prefer exact title/year; source rating_key is never used.
    master = {}
    for r in source_rows:
        title, original_title, year, rating, count, code, watcha_title, watcha_year, status, match_type, match_score, updated_at = r
        years = []
        for yv in (year, watcha_year):
            y = _master_year_v2374(yv)
            if y and y not in years:
                years.append(y)
        names = []
        for nv in (title, original_title, watcha_title):
            nk = _master_title_key_v2374(nv)
            if nk and nk not in names:
                names.append(nk)
        for nk in names:
            for y in years:
                master.setdefault((nk, y), r)

    item_cols = set(_columns(conn, "items"))
    if "rating_key" not in item_cols or "title" not in item_cols:
        raise RuntimeError("PKM items table is not ready")

    original_expr = "COALESCE(original_title,'')" if "original_title" in item_cols else "''"
    year_expr = "year" if "year" in item_cols else "NULL"
    section_expr = "COALESCE(section_id,'')" if "section_id" in item_cols else "''"
    if "plex_type" in item_cols:
        where = "plex_type='movie'"
    elif "kodi_type" in item_cols:
        where = "kodi_type='movie'"
    else:
        where = "1=1"

    local_rows = conn.execute(
        "SELECT rating_key,title,%s,%s,%s FROM items WHERE %s"
        % (original_expr, year_expr, section_expr, where)
    ).fetchall()

    init_watcha_schema(conn)
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    if progress_cb:
        progress_cb(20, "사용자 Plex 라이브러리와 Watcha Master 매칭 중")

    inserts = []
    matched = 0
    for idx, item in enumerate(local_rows):
        rating_key, title, original_title, year, section_id = item
        ly = _master_year_v2374(year)
        found = None
        if ly:
            for nv in (title, original_title):
                nk = _master_title_key_v2374(nv)
                if nk:
                    found = master.get((nk, ly))
                    if found:
                        break

        if found:
            stitle, soriginal, syear, rating, count, code, watcha_title, watcha_year, status, match_type, match_score, updated_at = found
            matched += 1
            inserts.append((
                str(rating_key or ""), title or "", original_title or "", year, section_id or "",
                rating, count, code, watcha_title or stitle or "", watcha_year or syear,
                "MATCHED", "MASTER_TITLE_YEAR", match_score, "", updated_at or now
            ))
        else:
            inserts.append((
                str(rating_key or ""), title or "", original_title or "", year, section_id or "",
                None, None, None, None, None,
                "PENDING", "MASTER_NOT_FOUND", None, "not_in_public_master", now
            ))

        if progress_cb and idx and idx % 1000 == 0:
            progress_cb(20 + min(70, int(idx * 70.0 / max(1, len(local_rows)))),
                        "Watcha Master 매칭 중\n%d / %d" % (idx, len(local_rows)))

    with conn:
        backup_table = backup_existing_watcha_table(conn)
        conn.execute("DELETE FROM watcha_ratings")
        conn.executemany(
            """
            INSERT OR REPLACE INTO watcha_ratings(
                rating_key,title,original_title,year,section_id,
                watcha_rating,watcha_count,watcha_code,watcha_title,watcha_year,
                match_status,match_type,match_score,error,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            inserts,
        )
        conn.execute("DELETE FROM watcha_match_summary")
        conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                     ("SOURCE_DB", source_db_path, now))
        conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                     ("SOURCE_ROWS", str(total_src), now))
        conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                     ("LOCAL_MOVIES", str(len(local_rows)), now))
        conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                     ("MASTER_MATCHED", str(matched), now))
        conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                     ("MATCH_MODE", "TITLE_ORIGINAL_YEAR_V2374", now))
        if backup_table:
            conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                         ("BACKUP_TABLE", backup_table, now))
        for k, v in source_validation.items():
            conn.execute("INSERT OR REPLACE INTO watcha_match_summary(key,value,updated_at) VALUES(?,?,?)",
                         ("SOURCE_%s" % str(k), str(v), now))

    stats = get_db_status(conn)
    stats["source_rows"] = total_src
    stats["local_movies"] = len(local_rows)
    stats["master_matched"] = matched
    stats["master_unmatched"] = max(0, len(local_rows) - matched)

    if progress_cb:
        progress_cb(100, "Watcha Master 매칭 완료\n%s" % summary_text(stats))
    return stats


def get_db_status(conn):
    init_watcha_schema(conn)
    def one(sql, args=()):
        try:
            row = conn.execute(sql, args).fetchone()
            return int(row[0] or 0) if row else 0
        except Exception:
            return 0
    total = one("SELECT COUNT(*) FROM watcha_ratings")
    matched = one("SELECT COUNT(*) FROM watcha_ratings WHERE match_status='MATCHED'")
    no_match = one("SELECT COUNT(*) FROM watcha_ratings WHERE match_status='NO_MATCH'")
    rating_missing = one("SELECT COUNT(*) FROM watcha_ratings WHERE match_status='RATING_MISSING'")
    rating_filled = one("SELECT COUNT(*) FROM watcha_ratings WHERE watcha_rating IS NOT NULL")
    release_skipped = one("SELECT COUNT(*) FROM watcha_ratings WHERE error='release_filename_skipped_for_metadata_rematch'")
    new_candidates = count_new_item_candidates(conn)
    return {
        "total": total,
        "MATCHED": matched,
        "NO_MATCH": no_match,
        "RATING_MISSING": rating_missing,
        "rating_filled": rating_filled,
        "release_skipped": release_skipped,
        "new_candidates": new_candidates,
        "matched_percent": (100.0 * matched / total) if total else 0.0,
        "identified_percent": (100.0 * (matched + rating_missing) / total) if total else 0.0,
    }


def count_new_item_candidates(conn):
    try:
        item_cols = set(_columns(conn, "items"))
        if "rating_key" not in item_cols:
            return 0
        if "plex_type" in item_cols:
            movie_where = "i.plex_type='movie'"
        elif "kodi_type" in item_cols:
            movie_where = "i.kodi_type='movie'"
        else:
            movie_where = "1=1"
        row = conn.execute(
            """
            SELECT COUNT(*)
            FROM items i
            LEFT JOIN watcha_ratings wr ON CAST(wr.rating_key AS TEXT)=CAST(i.rating_key AS TEXT)
            WHERE %s AND wr.rating_key IS NULL
            """ % movie_where
        ).fetchone()
        return int(row[0] or 0)
    except Exception:
        return -1


def summary_text(stats):
    total = int(stats.get("total", 0) or 0)
    matched = int(stats.get("MATCHED", 0) or 0)
    no_match = int(stats.get("NO_MATCH", 0) or 0)
    missing = int(stats.get("RATING_MISSING", 0) or 0)
    skipped = int(stats.get("release_skipped", 0) or 0)
    newc = int(stats.get("new_candidates", 0) or 0)
    mp = float(stats.get("matched_percent", 0.0) or 0.0)
    ip = float(stats.get("identified_percent", 0.0) or 0.0)
    return "전체 %d개 | 평점매칭 %d개 %.2f%% | 식별포함 %.2f%% | 평점없음 %d | 실패 %d | 릴리즈명보류 %d | 신규후보 %d" % (
        total, matched, mp, ip, missing, no_match, skipped, newc
    )


def sample_rows(conn, limit=20):
    init_watcha_schema(conn)
    return conn.execute(
        """
        SELECT title, year, watcha_title, watcha_year, watcha_rating, watcha_count, match_status, match_type, error
        FROM watcha_ratings
        ORDER BY updated_at DESC
        LIMIT ?
        """,
        (int(limit or 20),),
    ).fetchall()
