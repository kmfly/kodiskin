# -*- coding: utf-8 -*-
"""Tell the user what is going on when playback takes a while (v2701).

Playback itself is untouched (native setResolvedUrl hand-off stays locked).
This module only watches and shows messages:

* opening  - black cover + spinner is up and Kodi has not reached AVStarted.
             After a few seconds a top-right card inside the cover explains
             that the file is still being fetched, then that the server is
             slow, then what to do if nothing arrives.  No time-based
             failure: a slow rclone-backed Plex may legitimately need minutes.
* playing  - Kodi paused to refill its cache.  A Kodi toast (top right) says
             it is buffering and that waiting is expected to resume playback.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui

ADDON_ID = "plugin.video.km"
P = "PlexKM.Playback.OpeningNotice."
_NOTICE_KEYS = ("Active", "Title", "Line1", "Line2")

# Opening stages: (seconds since arm, title, line1, line2).  Korean glyphs are
# double width in the 404px notice label, so each line stays <= 16 characters.
OPENING_STAGES = (
    (5.0, "재생 준비 중", "영상 데이터를 받는 중", "잠시만 기다려 주세요"),
    (15.0, "응답이 느립니다", "서버 응답을 기다리는 중", "기다리면 재생될 수 있어요"),
    (35.0, "아직 준비 중입니다", "계속 응답이 없으면", "뒤로가기 후 다시 시도"),
)
BUFFER_STAGES = (
    (4.0, "버퍼링 중", "데이터를 받는 중입니다. 잠시 후 이어서 재생됩니다."),
    (15.0, "네트워크가 느립니다", "기다리면 다시 재생될 수 있습니다. 계속 기다려 주세요."),
    (40.0, "응답이 없습니다", "오래 걸리면 정지한 뒤 다시 재생해 보세요."),
)
BUFFER_REPEAT_SEC = 60.0

_buffer_gen = [0]
_buffer_lock = threading.Lock()


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def _cache_level():
    """Kodi's cache fill in percent, or 0 when unknown."""
    try:
        raw = (xbmc.getInfoLabel("Player.CacheLevel") or "").strip().rstrip("%")
        return max(0, min(100, int(float(raw))))
    except Exception:
        return 0


def _clear_opening_notice(win=None):
    try:
        win = win or xbmcgui.Window(10000)
        for key in _NOTICE_KEYS:
            win.clearProperty(P + key)
    except Exception:
        pass


# ------------------------------------------------------------------ opening
def start_opening_watch(token):
    """Called when the opening cover is armed (same token as the cover)."""
    # R140(11-16): 사용자 요청 — 재생 준비/버퍼링 안내 메시지는 띄우지 않음. 기다림 정도는 공통 링 스피너 색으로만 표시.
    return False
    def _run():
        monitor = xbmc.Monitor()
        t0 = time.time()
        shown = -1
        last_text = None
        try:
            while not monitor.abortRequested():
                if monitor.waitForAbort(0.5):
                    break
                w = xbmcgui.Window(10000)
                if (w.getProperty("PlexKM.Playback.NativeOpening.Token") != token
                        or w.getProperty("PlexKM.Playback.NativeOpening.Pending") != "1"
                        or w.getProperty("PlexKM.Playback.ResolverPhaseV1547") in ("avstarted", "definitive_failed")):
                    break
                el = time.time() - t0
                if el > 900:
                    break
                stage = -1
                for i, st in enumerate(OPENING_STAGES):
                    if el >= st[0]:
                        stage = i
                if stage < 0:
                    continue
                _t, title, line1, line2 = OPENING_STAGES[stage]
                level = _cache_level()
                if level > 0:
                    line1 = "버퍼 %d%% 채우는 중" % level
                title = "%s · %d초" % (title, int(el))
                text = (title, line1, line2)
                if text == last_text:
                    continue
                last_text = text
                w.setProperty(P + "Title", title)
                w.setProperty(P + "Line1", line1)
                w.setProperty(P + "Line2", line2)
                w.setProperty(P + "Active", "1")
                if stage != shown:
                    shown = stage
                    _log("PLAYBACK_WAIT_NOTICE_OPENING_V2701 stage=%d elapsed_s=%d level=%d" % (stage, int(el), level))
        except Exception as exc:
            _log("PLAYBACK_WAIT_NOTICE_OPENING_FAILED_V2701 err=%s" % exc, xbmc.LOGWARNING)
        finally:
            _clear_opening_notice()

    try:
        th = threading.Thread(target=_run, name="PKMOpeningWaitNotice")
        th.daemon = True
        th.start()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------- buffering
def stop_buffering_watch():
    with _buffer_lock:
        _buffer_gen[0] += 1


def start_buffering_watch():
    """Called on onAVStarted; ends by itself on stop/end or when replaced."""
    # R140(11-16): 사용자 요청 — 재생 준비/버퍼링 안내 메시지는 띄우지 않음. 기다림 정도는 공통 링 스피너 색으로만 표시.
    return False
    with _buffer_lock:
        _buffer_gen[0] += 1
        gen = _buffer_gen[0]

    def _toast(title, message):
        try:
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 5000, False)
        except Exception:
            pass

    def _run():
        monitor = xbmc.Monitor()
        since = None
        stage = -1
        last_toast = 0.0
        try:
            while not monitor.abortRequested():
                if monitor.waitForAbort(0.5):
                    break
                if gen != _buffer_gen[0]:
                    break
                try:
                    if not xbmc.getCondVisibility("Player.HasVideo"):
                        break
                    caching = bool(xbmc.getCondVisibility("Player.Caching")) and not bool(xbmc.getCondVisibility("Player.Paused"))
                except Exception:
                    break
                now = time.time()
                if not caching:
                    since, stage = None, -1
                    continue
                if since is None:
                    since, stage, last_toast = now, -1, 0.0
                el = now - since
                new_stage = -1
                for i, st in enumerate(BUFFER_STAGES):
                    if el >= st[0]:
                        new_stage = i
                due = new_stage > stage or (new_stage == len(BUFFER_STAGES) - 1
                                            and now - last_toast >= BUFFER_REPEAT_SEC)
                if new_stage >= 0 and due:
                    stage, last_toast = new_stage, now
                    _t, title, message = BUFFER_STAGES[new_stage]
                    level = _cache_level()
                    if level > 0:
                        message = "버퍼 %d%% · %s" % (level, message)
                    # R140: 경과 초는 표시하지 않음 (공통 링 스피너 색이 기다림 정도를 보여 줌)
                    _toast(title, message)
                    _log("PLAYBACK_WAIT_NOTICE_BUFFERING_V2701 stage=%d elapsed_s=%d level=%d" % (new_stage, int(el), level))
        except Exception as exc:
            _log("PLAYBACK_WAIT_NOTICE_BUFFERING_FAILED_V2701 err=%s" % exc, xbmc.LOGWARNING)

    try:
        th = threading.Thread(target=_run, name="PKMBufferingWaitNotice")
        th.daemon = True
        th.start()
        return True
    except Exception:
        return False
