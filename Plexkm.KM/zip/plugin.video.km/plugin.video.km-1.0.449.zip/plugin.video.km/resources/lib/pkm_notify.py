# -*- coding: utf-8 -*-
"""PKM notification property helpers.

Data-only split from default.py / plexkm_home_window.py.
This module only prepares Window(10000) skin properties for the existing
XML overlay.  It must not change focus, navigation, actions, playback,
or window flow.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui

_NOTIFY_KEYS = (
    "PlexKM.Notify.Active",
    "PlexKM.Notify.Title",
    "PlexKM.Notify.Line1",
    "PlexKM.Notify.Line2",
    "PlexKM.Notify.Token",
    "PlexKM.Notify.Sticky",
    "PlexKM.Notify.HomeOnly",
    "PlexKM.Notify.Busy",
)


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.km] %s" % message, level)
    except Exception:
        pass


def _display_text_for_kodi(value):
    """Normalize Plex library title separators for Kodi WindowXML text rendering."""
    text = str(value or "")
    try:
        table = {
            ord("\u007C"): "|",
            ord("\u00A6"): "|",
            ord("\u01C0"): "|",
            ord("\u2016"): "|",
            ord("\u2223"): "|",
            ord("\u2225"): "|",
            ord("\u23AA"): "|",
            ord("\u23D0"): "|",
            ord("\u2502"): "|",
            ord("\u2503"): "|",
            ord("\u2758"): "|",
            ord("\u2759"): "|",
            ord("\u275A"): "|",
            ord("\u3163"): "|",
            ord("\u4E28"): "|",
            ord("\uFF5C"): "|",
            ord("\uFFE8"): "|",
        }
        return text.translate(table)
    except Exception:
        return text


def _sanitize_notice_text(value, max_len=54):
    """Keep PKM notice labels clean: no ellipsis glyphs or Kodi-native truncation hints."""
    text = _display_text_for_kodi(value)
    try:
        text = text.replace("…", " ").replace("...", " ")
        text = " ".join(text.split())
        max_len = int(max_len or 54)
        if max_len > 0 and len(text) > max_len:
            text = text[:max_len].rstrip()
        return text
    except Exception:
        return str(value or "")


def _take_notice_units(value, max_units):
    text = str(value or "").strip()
    if not text:
        return "", ""
    used = 0
    cut = 0
    last_space = -1
    for idx, ch in enumerate(text):
        # R466: weights follow the real NotoSansKR widths (Hangul ~2x a
        # narrow Latin glyph, average Latin/digit ~1.2 of a half Hangul).
        width = (0.6 if ch == " " else 1.2) if ord(ch) < 128 else 2
        if used + width > float(max_units or 38):
            break
        used += width
        cut = idx + 1
        if ch.isspace():
            last_space = cut
    if cut >= len(text):
        return text, ""
    if last_space > 0:
        cut = last_space
    return text[:cut].rstrip(), text[cut:].lstrip()


def _fit_notice_lines(line1, line2, max_units=38):
    """Fit notice body while preserving the caller's explicit two-row layout.

    When both rows are supplied they are width-bounded independently.  Do not
    merge them and re-wrap across rows: update notices intentionally use row 1
    for the message and row 2 for the Plugin/Skin version pair.
    """
    first_raw = str(line1 or "").strip()
    second_raw = str(line2 or "").strip()

    if first_raw and second_raw:
        first, _unused_first = _take_notice_units(first_raw, max_units)
        second, _unused_second = _take_notice_units(second_raw, max_units)
        return first, second

    text = first_raw or second_raw
    first, rest = _take_notice_units(text, max_units)
    second, _unused = _take_notice_units(rest, max_units)
    return first, second


def pkm_player_has_video():
    """Return True while Kodi playback is requested/opening/active."""
    try:
        if bool(
            xbmc.Player().isPlayingVideo()
            or xbmc.getCondVisibility("Player.HasVideo")
            or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
            or xbmc.getCondVisibility("Window.IsActive(videoosd)")
        ):
            return True
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Playback.PriorityV2118") == "1"
            or win.getProperty("PlexKM.Playback.OpeningActive") == "1"
            or win.getProperty("PlexKM.Playback.NativeOpening.Pending") == "1"
        )
    except Exception:
        return False




def _is_update_notice_title(title):
    try:
        return str(title or "").startswith("PlexKM 업데이트")
    except Exception:
        return False


def _update_notice_home_visible_now(win=None):
    """Update progress/completion notices are allowed only on the PKM Home view.

    Plex offline/connection notices are not update notices and keep their normal
    visibility.  This prevents stale update properties from appearing later when
    a widget receives focus in another PKM area.
    """
    try:
        win = win or xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Window.IsHome") == "1"
            and win.getProperty("PlexKM.Info.InlineActive") != "1"
            and win.getProperty("PlexKM.MainPlaybackActive") != "1"
            and not pkm_player_has_video()
        )
    except Exception:
        return False

def _current_notice_is_sticky(win=None):
    try:
        win = win or xbmcgui.Window(10000)
        return bool(
            win.getProperty("PlexKM.Notify.Active") == "1"
            and win.getProperty("PlexKM.Notify.Sticky") == "1"
        )
    except Exception:
        return False


_KIND_ERR_R465 = ("실패", "오류", "못했", "못 했", "없어 재생", "중단")
_KIND_WARN_R465 = ("확인 필요", "필요합니다", "주의", "연결 안", "오프라인", "없습니다")
_KIND_OK_R465 = ("완료", "했습니다", "마쳤습니다", "추가됨", "저장", "설치됨")


def _guess_kind_r465(title, body):
    t = "%s %s" % (title or "", body or "")
    if any(w in t for w in _KIND_ERR_R465):
        return "err"
    if any(w in t for w in _KIND_WARN_R465):
        return "warn"
    if any(w in t for w in _KIND_OK_R465):
        return "ok"
    return "info"


def _bar_r465(pct):
    try:
        n = max(0, min(20, int(round(float(pct) / 5.0))))
    except Exception:
        n = 0
    return "special://home/addons/plugin.video.km/resources/skins/Default/media/common/r465/bar_%02d.png" % n


def pkm_notice_kind(kind, title, line1="", line2="", line3="", progress=None, ms=None, token="", sticky=False):
    """R465: one notice card for every PlexKM message.

    kind: info / ok / warn / err / busy.  Up to 3 body lines.  progress (0-100)
    draws a bar.  Transient kinds clear themselves; time grows with length.
    """
    body = " ".join(x for x in (line1, line2, line3) if x)
    tok = pkm_notice_set(title, line1, line2, token=token, sticky=sticky, force_replace=True,
                         busy=(kind == "busy"), kind=kind, line3=line3, progress=progress)
    if kind != "busy" and not sticky:
        wait = ms or (12000 if kind == "err" else min(9000, 3500 + 70 * len(body.replace(" ", ""))))
        pkm_notice_clear_later(tok, ms=wait)
    return tok


def pkm_notice_set(title, line1="", line2="", token="", sticky=False, force_replace=False, busy=False,
                   kind=None, line3="", progress=None):
    """Show a PKM top-right notice.

    sticky=True is used for blocking/critical states such as Plex offline.
    Sticky notices stay visible until explicitly cleared with force=True or until
    Plex connectivity is restored.  Transient notices must not overwrite them.
    """
    try:
        token = str(token or int(time.time() * 1000))
        # v2117: fit the title by rendered-width units, not raw character count.
        # This keeps every PKM notice inside the fixed 404px label so Kodi never
        # has to display its own trailing ellipsis.  Body lines are already
        # width-bounded and are kept as two concise fixed labels.
        raw_title = _sanitize_notice_text(title, 0)
        # 화면에는 애드온 ID(plugin.video.km)나 PKM 대신 항상 PlexKM으로 표시한다.
        if raw_title.strip().lower() in ("plugin.video.km", "pkm", "plex km"):
            raw_title = "PlexKM"
        display_title, _unused_title = _take_notice_units(raw_title, 40)  # R466: 460px @23pt
        # R463: callers may pass "line1\nline2" (or [CR]) as one body string.
        if not str(line2 or "").strip():
            _body = str(line1 or "").replace("[CR]", "\n")
            if "\n" in _body:
                _parts = [x.strip() for x in _body.split("\n") if x.strip()]
                line1 = _parts[0] if _parts else ""
                line2 = " ".join(_parts[1:2])
                line3 = line3 or " ".join(_parts[2:])
        raw_line1 = _sanitize_notice_text(line1, 0)
        raw_line2 = _sanitize_notice_text(line2, 0)
        raw_line3 = _sanitize_notice_text(line3, 0)
        # R465: wider card (560px, 19pt body) -> 40 units a line, up to 3 lines.
        _units_r465 = 45  # R466: 460px @20pt with weighted widths
        if raw_line1 and not raw_line2 and not raw_line3:
            display_line1, _rest = _take_notice_units(raw_line1, _units_r465)
            display_line2, _rest = _take_notice_units(_rest, _units_r465)
            display_line3, _unused = _take_notice_units(_rest, _units_r465)
        else:
            display_line1, _u1 = _take_notice_units(raw_line1, _units_r465)
            display_line2, _u2 = _take_notice_units(raw_line2, _units_r465)
            display_line3, _u3 = _take_notice_units(raw_line3, _units_r465)
            if _u2 and not raw_line3:
                display_line3, _u3 = _take_notice_units(_u2, _units_r465)
            if _u1 or (_u2 and raw_line3):
                # R466: a line that does not fit must not lose its tail; re-flow
                # every given line through the 3 rows instead.
                _merged = " ".join(x for x in (raw_line1, raw_line2, raw_line3) if x)
                display_line1, _rest = _take_notice_units(_merged, _units_r465)
                display_line2, _rest = _take_notice_units(_rest, _units_r465)
                display_line3, _unused = _take_notice_units(_rest, _units_r465)
        if not display_line1 and display_line2:
            display_line1, display_line2, display_line3 = display_line2, display_line3, ""
        if not display_line2 and display_line3:
            display_line2, display_line3 = display_line3, ""
        raw_line2 = (raw_line2 + " " + raw_line3).strip()
        display_line2 = display_line2  # kept for the overflow check below
        try:
            _shown = len((display_line1 + display_line2 + display_line3).replace(" ", ""))
            _given = len((raw_line1 + raw_line2).replace(" ", ""))
            if _shown < _given:
                _log("PKM_NOTICE_OVERFLOW_R463 title=%s line1=%s line2=%s" % (raw_title, raw_line1, raw_line2),
                     xbmc.LOGWARNING)
        except Exception:
            pass
        is_update_notice = _is_update_notice_title(display_title)
        if pkm_player_has_video():
            _log(
                "PKM_NOTICE_SUPPRESS reason=player_active title=%s line1=%s"
                % (display_title, display_line1),
                xbmc.LOGINFO,
            )
            return token
        win = xbmcgui.Window(10000)
        if is_update_notice and not _update_notice_home_visible_now(win):
            _log(
                "PKM_UPDATE_NOTICE_SUPPRESS reason=not_home title=%s line1=%s is_home=%s info=%s"
                % (
                    display_title,
                    display_line1,
                    str(win.getProperty("PlexKM.Window.IsHome") or ""),
                    str(win.getProperty("PlexKM.Info.InlineActive") or ""),
                ),
                xbmc.LOGINFO,
            )
            return token
        if _current_notice_is_sticky(win) and not sticky and not force_replace:
            _log(
                "PKM_NOTICE_SET_SKIP reason=sticky_active active_title=%s new_title=%s"
                % (str(win.getProperty("PlexKM.Notify.Title") or ""), display_title),
                xbmc.LOGINFO,
            )
            return str(win.getProperty("PlexKM.Notify.Token") or token)
        _kind_r465 = kind or ("busy" if busy else _guess_kind_r465(display_title, raw_line1 + " " + raw_line2))
        _lines_r465 = len([x for x in (display_line1, display_line2, display_line3) if x])
        for key, value in (
            ("PlexKM.Notify.Kind", _kind_r465),
            ("PlexKM.Notify.Lines", str(_lines_r465)),
            ("PlexKM.Notify.Line3", display_line3),
            ("PlexKM.Notify.Bar", _bar_r465(progress) if progress is not None else ""),
            ("PlexKM.Notify.Pct", ("%d%%" % int(progress)) if progress is not None else ""),
            ("PlexKM.Notify.Title", display_title),
            ("PlexKM.Notify.Line1", display_line1),
            ("PlexKM.Notify.Line2", display_line2),
            ("PlexKM.Notify.Token", token),
            ("PlexKM.Notify.Sticky", "1" if sticky else "0"),
            ("PlexKM.Notify.HomeOnly", "1" if is_update_notice else "0"),
            # R97: in-progress notices show a small spinner instead of elapsed seconds.
            ("PlexKM.Notify.Busy", "1" if busy else "0"),
            ("PlexKM.Notify.Active", "1"),
        ):
            win.setProperty(key, value)
        _log(
            "PKM_NOTICE_SET title=%s line1=%s line2=%s token=%s sticky=%s"
            % (display_title, display_line1, display_line2, str(token or ""), "1" if sticky else "0"),
            xbmc.LOGINFO,
        )
        return token
    except Exception:
        return str(token or "")


def pkm_notice_clear(expected_token="", force=False):
    try:
        win = xbmcgui.Window(10000)
        if expected_token and win.getProperty("PlexKM.Notify.Token") != str(expected_token):
            _log(
                "PKM_NOTICE_CLEAR_SKIP reason=token_mismatch expected=%s active=%s"
                % (str(expected_token or ""), str(win.getProperty("PlexKM.Notify.Token") or "")),
                xbmc.LOGINFO,
            )
            return False
        if _current_notice_is_sticky(win) and not force:
            _log(
                "PKM_NOTICE_CLEAR_SKIP reason=sticky_active title=%s token=%s"
                % (str(win.getProperty("PlexKM.Notify.Title") or ""), str(win.getProperty("PlexKM.Notify.Token") or "")),
                xbmc.LOGINFO,
            )
            return False
        title = win.getProperty("PlexKM.Notify.Title") or ""
        token = win.getProperty("PlexKM.Notify.Token") or ""
        for key in _NOTIFY_KEYS:
            win.clearProperty(key)
        _log("PKM_NOTICE_CLEAR title=%s token=%s force=%s" % (str(title or ""), str(token or ""), "1" if force else "0"), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def pkm_notice_clear_later(expected_token="", ms=1800):
    """Clear the current PKM notice after a short delay if the token still matches.

    This is used for transient completion notices only.  It does not touch
    Kodi focus/navigation/window flow.
    """
    try:
        delay = max(500, int(ms or 1800))

        def _clear(expected):
            try:
                xbmc.sleep(delay)
                pkm_notice_clear(expected)
            except Exception:
                pass

        t = threading.Thread(target=_clear, args=(str(expected_token or ""),), daemon=True)
        t.daemon = True
        t.start()
        _log("PKM_NOTICE_CLEAR_LATER ms=%d token=%s" % (delay, str(expected_token or "")), xbmc.LOGINFO)
        return True
    except Exception:
        return False


def pkm_notice_clear_if_title(prefixes, expected_token="", force=False):
    """Clear only PKM update notices whose title matches one of prefixes."""
    try:
        win = xbmcgui.Window(10000)
        title = win.getProperty("PlexKM.Notify.Title") or ""
        if isinstance(prefixes, str):
            prefixes = [prefixes]
        prefixes = [str(x or "") for x in (prefixes or []) if str(x or "")]
        if not title or not any(title.startswith(x) for x in prefixes):
            return False
        return pkm_notice_clear(expected_token=expected_token, force=force)
    except Exception:
        return False


def pkm_show_notice(title, line1="", line2="", ms=2600):
    try:
        token = pkm_notice_set(title, line1, line2)
        delay = max(700, int(ms or 2600))

        def _clear(expected_token):
            try:
                xbmc.sleep(delay)
                pkm_notice_clear(expected_token)
            except Exception:
                pass

        t = threading.Thread(target=_clear, args=(token,), daemon=True)
        t.daemon = True
        t.start()
        return True
    except Exception:
        return False


def format_startup_sync_notice(stats):
    stats = stats or {}
    movies = int(stats.get("movie", 0) or 0)
    shows = int(stats.get("show", 0) or 0)
    episodes = int(stats.get("episode", 0) or 0)
    parts = []
    if movies:
        parts.append("영화 %d개" % movies)
    if shows:
        parts.append("드라마 %d개" % shows)
    if episodes:
        parts.append("에피소드 %d개" % episodes)
    return " · ".join(parts)
