# -*- coding: utf-8 -*-
"""R108 step 3: mirror the Kodi video library into PKM's local DB (plex_km.db).

Kodi rows live next to Plex rows with a "k:" key prefix so Home, library walls,
sort indexes and search (built from `items`) work with both sources:

  sections (virtual, never stored in `sections`):  k:movies, k:tvshows
  items.rating_key:  k:movie:<movieid>, k:show:<tvshowid>, k:episode:<episodeid>
  items.parent_rating_key (episodes):  k:season:<seasonid>

The `sections` table is left to Plex on purpose: startup reconcile treats every
stored section as a Plex section.  Kodi sections are added by
`virtual_sections()` where the sidebar is built.

Writes are incremental (checksum per row) so an unchanged library does not bump
`synced_at` and does not trigger a search re-index.
"""
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import os
import sqlite3
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import pkm_sources

ADDON_ID = "plugin.video.km"
PREFIX = pkm_sources.KODI_KEY_PREFIX            # "k:"
SECTION_MOVIES = PREFIX + "movies"
SECTION_TVSHOWS = PREFIX + "tvshows"
SECTION_TITLES = {SECTION_MOVIES: "Kodi 영화", SECTION_TVSHOWS: "Kodi 드라마"}

_SYNC_LOCK = threading.Lock()

MOVIE_PROPS = ["title", "originaltitle", "sorttitle", "year", "plot", "runtime", "dateadded", "file", "art",
               "playcount", "lastplayed", "resume", "genre", "cast", "director", "rating", "uniqueid",
               "streamdetails", "premiered", "country", "studio", "mpaa"]
SHOW_PROPS = ["title", "originaltitle", "sorttitle", "year", "plot", "dateadded", "file", "art", "playcount",
              "lastplayed", "genre", "cast", "rating", "uniqueid", "episode", "watchedepisodes", "season",
              "premiered", "studio", "mpaa"]
EPISODE_PROPS = ["title", "plot", "runtime", "season", "episode", "tvshowid", "showtitle", "file", "art",
                 "playcount", "lastplayed", "resume", "dateadded", "firstaired", "seasonid", "streamdetails",
                 "uniqueid", "rating"]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] PKM_KODI_SOURCE_R108 %s" % (ADDON_ID, msg), level)


def is_kodi_key(value):
    return str(value or "").startswith(PREFIX)


def kodi_id(rating_key):
    """k:movie:12 -> ("movie", 12)."""
    try:
        _p, kind, num = str(rating_key).split(":", 2)
        return kind, int(num)
    except Exception:
        return "", 0


def db_path():
    base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
    return os.path.join(base, "plex_km.db")


def _jsonrpc(method, params=None):
    return pkm_sources._jsonrpc(method, params)


def _epoch(text):
    text = str(text or "").strip()
    if not text:
        return 0
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return int(time.mktime(time.strptime(text, fmt)))
        except Exception:
            pass
    return 0


def _norm_path(p):
    return str(p or "").replace("\\", "/").rstrip("/").lower()


def _scope():
    """Which Kodi paths are PKM sources: (all_library, movie_prefixes, tv_prefixes)."""
    movies, tv, everything = [], [], False
    for src in pkm_sources.kodi_sources():
        content = src.get("content")
        if content == pkm_sources.KODI_CONTENT_LIBRARY:
            everything = True
        elif content == pkm_sources.KODI_CONTENT_MOVIES:
            movies.append(_norm_path(src.get("path")) + "/")
        elif content == pkm_sources.KODI_CONTENT_TVSHOWS:
            tv.append(_norm_path(src.get("path")) + "/")
    return everything, movies, tv


def _in_scope(path, everything, prefixes):
    if everything:
        return True
    p = _norm_path(path) + "/"
    return any(p.startswith(x) for x in prefixes)


def virtual_sections():
    """Kodi sections that currently hold items (for the sidebar / section lists)."""
    if not pkm_sources.has_kodi():
        return []
    out = []
    try:
        conn = sqlite3.connect(db_path(), timeout=5.0)
        try:
            rows = dict(conn.execute(
                "SELECT section_id, COUNT(*) FROM items WHERE section_id IN (?,?) AND plex_type IN ('movie','show') "
                "GROUP BY section_id", (SECTION_MOVIES, SECTION_TVSHOWS)).fetchall())
        finally:
            conn.close()
    except Exception:
        rows = {}
    # The "Kodi" prefix tells the sources apart only when Plex libraries are
    # in the sidebar too; a Kodi-only setup shows plain 영화 / 드라마.
    mixed = pkm_sources.has_plex() and pkm_sources.plex_credentials_ready()
    for sid, stype in ((SECTION_MOVIES, "movie"), (SECTION_TVSHOWS, "show")):
        if int(rows.get(sid, 0) or 0) > 0:
            title = SECTION_TITLES[sid] if mixed else SECTION_TITLES[sid].replace("Kodi ", "")
            out.append({"section_id": sid, "title": title, "section_type": stype, "thumb": "",
                        "art": "", "scanned_at": int(time.time()), "item_count": int(rows.get(sid, 0)),
                        "source": "kodi"})
    return out


def virtual_section_ids():
    return [s["section_id"] for s in virtual_sections()]


def _duration_ms(item):
    """Real file length first (stream details / resume total), scraper runtime last."""
    try:
        v = ((item.get("streamdetails") or {}).get("video") or [])
        if v and int(v[0].get("duration") or 0) > 0:
            return int(v[0]["duration"]) * 1000
    except Exception:
        pass
    try:
        total = float((item.get("resume") or {}).get("total") or 0)
        if total > 0:
            return int(total * 1000)
    except Exception:
        pass
    return int(item.get("runtime") or 0) * 1000


def _resolution(stream):
    try:
        v = (stream or {}).get("video") or []
        if not v:
            return "", "", ""
        w, h = int(v[0].get("width") or 0), int(v[0].get("height") or 0)
        res = "4k" if w >= 3200 or h >= 1700 else ("1080" if w >= 1800 or h >= 1000 else ("720" if w >= 1200 or h >= 700 else ("sd" if w else "")))
        return res, str(h or ""), str(w or "")
    except Exception:
        return "", "", ""


def _unwrap_image(url, size=""):
    """image://<quoted original>/ -> original http(s) URL when there is one.

    PKM's poster/fanart pipeline downloads http(s) art into its own cache, so
    scraped (TMDB) art is handed over as the plain URL, resized for TV use.
    Local art (poster.jpg next to the file) keeps the image:// form.
    """
    url = str(url or "")
    if url.startswith("image://"):
        try:
            from urllib.parse import unquote
        except ImportError:
            from urllib import unquote
        inner = unquote(url[len("image://"):].rstrip("/"))
        if inner.startswith(("http://", "https://")):
            url = inner
    if size and "image.tmdb.org/t/p/original/" in url:
        url = url.replace("/t/p/original/", "/t/p/%s/" % size)
    return url


def _art(art, *keys, **kw):
    for k in keys:
        v = (art or {}).get(k)
        if v:
            return _unwrap_image(v, kw.get("size", ""))
    return ""


def _guid(uid):
    uid = uid or {}
    if uid.get("tmdb"):
        return "tmdb://%s" % uid["tmdb"]
    if uid.get("imdb"):
        return "imdb://%s" % uid["imdb"]
    if uid.get("tvdb"):
        return "tvdb://%s" % uid["tvdb"]
    return ""


def _checksum(row):
    return hashlib.md5(json.dumps(row, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _movie_rows(m):
    rk = "%smovie:%d" % (PREFIX, m["movieid"])
    res, h, w = _resolution(m.get("streamdetails"))
    resume = m.get("resume") or {}
    raw = {"ratingKey": rk, "type": "movie", "source": "kodi", "guid": _guid(m.get("uniqueid")),
           "title": m.get("title", ""), "year": str(m.get("year") or ""), "originallyAvailableAt": m.get("premiered", ""),
           "rating": str(m.get("rating") or ""), "contentRating": m.get("mpaa", ""), "file": m.get("file", ""),
           "part_key": m.get("file", ""), "videoResolution": res, "height": h, "width": w,
           "viewOffset": int(float(resume.get("position") or 0) * 1000), "uniqueid": m.get("uniqueid") or {}}
    item = {"rating_key": rk, "section_id": SECTION_MOVIES, "plex_type": "movie", "kodi_type": "movie",
            "title": m.get("title", ""), "original_title": m.get("originaltitle", ""),
            "sort_title": m.get("sorttitle") or m.get("title", ""), "year": int(m.get("year") or 0),
            "summary": m.get("plot", ""), "duration": _duration_ms(m),
            "added_at": _epoch(m.get("dateadded")), "updated_at": _epoch(m.get("dateadded")),
            "thumb": _art(m.get("art"), "poster", "thumb", size="w500"), "art": _art(m.get("art"), "fanart", size="w1280"),
            "media_file": m.get("file", ""), "part_key": m.get("file", ""),
            "view_count": int(m.get("playcount") or 0), "last_viewed_at": _epoch(m.get("lastplayed")),
            "parent_rating_key": "", "grandparent_rating_key": "", "show_title": "", "season": 0, "episode": 0,
            "raw_json": json.dumps(raw, ensure_ascii=False)}
    extras = {"genres": list(m.get("genre") or []), "countries": list(m.get("country") or []),
              "people": [("director", d, "") for d in (m.get("director") or [])] +
                        [("actor", c.get("name", ""), c.get("role", ""), _unwrap_image(c.get("thumbnail", ""), "w185")) for c in (m.get("cast") or [])[:30]],
              "rating": float(m.get("rating") or 0), "uniqueid": m.get("uniqueid") or {}}
    return item, extras


def _show_rows(s):
    rk = "%sshow:%d" % (PREFIX, s["tvshowid"])
    raw = {"ratingKey": rk, "type": "show", "source": "kodi", "guid": _guid(s.get("uniqueid")),
           "title": s.get("title", ""), "year": str(s.get("year") or ""), "originallyAvailableAt": s.get("premiered", ""),
           "rating": str(s.get("rating") or ""), "leafCount": str(s.get("episode") or 0),
           "viewedLeafCount": str(s.get("watchedepisodes") or 0), "childCount": str(s.get("season") or 0),
           "file": s.get("file", ""), "uniqueid": s.get("uniqueid") or {}}
    item = {"rating_key": rk, "section_id": SECTION_TVSHOWS, "plex_type": "show", "kodi_type": "tvshow",
            "title": s.get("title", ""), "original_title": s.get("originaltitle", ""),
            "sort_title": s.get("sorttitle") or s.get("title", ""), "year": int(s.get("year") or 0),
            "summary": s.get("plot", ""), "duration": 0,
            "added_at": _epoch(s.get("dateadded")), "updated_at": _epoch(s.get("dateadded")),
            "thumb": _art(s.get("art"), "poster", "thumb", size="w500"), "art": _art(s.get("art"), "fanart", size="w1280"),
            "media_file": "", "part_key": "", "view_count": int(s.get("playcount") or 0),
            "last_viewed_at": _epoch(s.get("lastplayed")), "parent_rating_key": "", "grandparent_rating_key": "",
            "show_title": "", "season": 0, "episode": 0, "raw_json": json.dumps(raw, ensure_ascii=False)}
    extras = {"genres": list(s.get("genre") or []), "countries": [],
              "people": [("actor", c.get("name", ""), c.get("role", ""), _unwrap_image(c.get("thumbnail", ""), "w185")) for c in (s.get("cast") or [])[:30]],
              "rating": float(s.get("rating") or 0), "uniqueid": s.get("uniqueid") or {}}
    return item, extras


def _episode_rows(e, show_art):
    rk = "%sepisode:%d" % (PREFIX, e["episodeid"])
    res, h, w = _resolution(e.get("streamdetails"))
    resume = e.get("resume") or {}
    show_rk = "%sshow:%d" % (PREFIX, int(e.get("tvshowid") or 0))
    raw = {"ratingKey": rk, "type": "episode", "source": "kodi", "title": e.get("title", ""),
           "parentIndex": str(e.get("season") or 0), "index": str(e.get("episode") or 0),
           "grandparentTitle": e.get("showtitle", ""), "grandparentRatingKey": show_rk,
           "parentRatingKey": "%sseason:%d" % (PREFIX, int(e.get("seasonid") or 0)),
           "originallyAvailableAt": e.get("firstaired", ""), "file": e.get("file", ""), "part_key": e.get("file", ""),
           "videoResolution": res, "height": h, "width": w,
           "viewOffset": int(float(resume.get("position") or 0) * 1000), "uniqueid": e.get("uniqueid") or {}}
    added = _epoch(e.get("dateadded"))
    item = {"rating_key": rk, "section_id": SECTION_TVSHOWS, "plex_type": "episode", "kodi_type": "episode",
            "title": e.get("title", ""), "original_title": "", "sort_title": e.get("title", ""),
            "year": int(str(e.get("firstaired") or "0")[:4] or 0) if str(e.get("firstaired") or "")[:4].isdigit() else 0,
            "summary": e.get("plot", ""), "duration": _duration_ms(e),
            "added_at": added, "updated_at": added,
            "thumb": _art(e.get("art"), "thumb", size="w780"), "art": show_art.get(show_rk, ""),
            "media_file": e.get("file", ""), "part_key": e.get("file", ""),
            "view_count": int(e.get("playcount") or 0), "last_viewed_at": _epoch(e.get("lastplayed")),
            "parent_rating_key": raw["parentRatingKey"], "grandparent_rating_key": show_rk,
            "show_title": e.get("showtitle", ""), "season": int(e.get("season") or 0),
            "episode": int(e.get("episode") or 0), "raw_json": json.dumps(raw, ensure_ascii=False)}
    return item, None


ITEM_COLS = ["rating_key", "section_id", "plex_type", "kodi_type", "title", "original_title", "sort_title", "year",
             "summary", "duration", "added_at", "updated_at", "checksum", "thumb", "art", "media_file", "part_key",
             "view_count", "last_viewed_at", "parent_rating_key", "grandparent_rating_key", "show_title", "season",
             "episode", "raw_json", "synced_at"]


def _ensure_schema(conn):
    # Same columns as default.init_db(); CREATE IF NOT EXISTS is harmless when
    # PKM already created them (Kodi-only installs may run this first).
    conn.execute("CREATE TABLE IF NOT EXISTS items (rating_key TEXT PRIMARY KEY, section_id TEXT, plex_type TEXT, "
                 "kodi_type TEXT, title TEXT, original_title TEXT, sort_title TEXT, year INTEGER, summary TEXT, "
                 "duration INTEGER, added_at INTEGER, updated_at INTEGER, checksum TEXT, thumb TEXT, art TEXT, "
                 "media_file TEXT, part_key TEXT, view_count INTEGER, last_viewed_at INTEGER, parent_rating_key TEXT, "
                 "grandparent_rating_key TEXT, show_title TEXT, season INTEGER, episode INTEGER, raw_json TEXT, "
                 "synced_at INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS item_people (rating_key TEXT, section_id TEXT, person_type TEXT, "
                 "person_name TEXT, role TEXT, person_thumb TEXT, tag_id TEXT, sort_order INTEGER DEFAULT 0, "
                 "source TEXT DEFAULT '', indexed_at INTEGER DEFAULT 0, "
                 "PRIMARY KEY(rating_key, person_type, person_name, sort_order))")
    conn.execute("CREATE TABLE IF NOT EXISTS item_genres (rating_key TEXT, section_id TEXT, genre TEXT, tag_id TEXT, "
                 "source TEXT DEFAULT '', indexed_at INTEGER DEFAULT 0, PRIMARY KEY(rating_key, genre))")
    conn.execute("CREATE TABLE IF NOT EXISTS item_countries (rating_key TEXT, section_id TEXT, country TEXT, "
                 "tag_id TEXT, source TEXT DEFAULT '', indexed_at INTEGER DEFAULT 0, PRIMARY KEY(rating_key, country))")
    conn.execute("CREATE TABLE IF NOT EXISTS item_ratings (rating_key TEXT PRIMARY KEY, section_id TEXT, rating REAL, "
                 "audience_rating REAL, user_rating REAL, score REAL, source TEXT DEFAULT '', indexed_at INTEGER DEFAULT 0)")
    # R108: external ids for both sources (Kodi now; Plex guid mapping in step 4).
    conn.execute("CREATE TABLE IF NOT EXISTS item_ids_r108 (rating_key TEXT PRIMARY KEY, section_id TEXT, "
                 "tmdb TEXT DEFAULT '', imdb TEXT DEFAULT '', tvdb TEXT DEFAULT '', indexed_at INTEGER DEFAULT 0)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_ids_r108_tmdb ON item_ids_r108(tmdb)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_item_ids_r108_imdb ON item_ids_r108(imdb)")


def _fetch(method, key, props, params=None):
    p = {"properties": props}
    if params:
        p.update(params)
    res = _jsonrpc(method, p) or {}
    return list(res.get(key) or [])


def _write_row(conn, it, ex, now):
    """Write one mirrored item row (+ genres/people/countries/ratings/ids)."""
    rk = it["rating_key"]
    ph = ",".join(["?"] * len(ITEM_COLS))
    conn.execute("INSERT OR REPLACE INTO items(%s) VALUES(%s)" % (",".join(ITEM_COLS), ph),
                 [it.get(c) for c in ITEM_COLS])
    if ex is not None:
        sid = it["section_id"]
        for tbl in ("item_genres", "item_people", "item_countries"):
            conn.execute("DELETE FROM %s WHERE rating_key=?" % tbl, (rk,))
        for g in ex["genres"]:
            conn.execute("INSERT OR REPLACE INTO item_genres(rating_key, section_id, genre, tag_id, source, indexed_at) "
                         "VALUES(?,?,?,?,?,?)", (rk, sid, g, "", "kodi", now))
        for c in ex["countries"]:
            conn.execute("INSERT OR REPLACE INTO item_countries(rating_key, section_id, country, tag_id, source, indexed_at) "
                         "VALUES(?,?,?,?,?,?)", (rk, sid, c, "", "kodi", now))
        for order, p in enumerate(ex["people"]):
            ptype, name, role = p[0], p[1], p[2]
            thumb = p[3] if len(p) > 3 else ""
            if name:
                conn.execute("INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                             "person_thumb, tag_id, sort_order, source, indexed_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                             (rk, sid, ptype, name, role, thumb, "", order, "kodi", now))
        conn.execute("INSERT OR REPLACE INTO item_ratings(rating_key, section_id, rating, audience_rating, user_rating, score, source, indexed_at) "
                     "VALUES(?,?,?,?,?,?,?,?)", (rk, sid, ex["rating"], 0.0, None, 0.0, "kodi", now))
        uid = ex["uniqueid"]
        conn.execute("INSERT OR REPLACE INTO item_ids_r108(rating_key, section_id, tmdb, imdb, tvdb, indexed_at) "
                     "VALUES(?,?,?,?,?,?)", (rk, sid, str(uid.get("tmdb") or ""), str(uid.get("imdb") or ""),
                                             str(uid.get("tvdb") or ""), now))


def sync_one(rating_key):
    """R120: re-read ONE movie/show from Kodi's library and rewrite only its rows.

    Used after a scraper Refresh.  Returns the item dict, or None when the item
    is gone / Kodi did not answer.  Episodes are not handled (cards open shows).
    """
    kind, num = kodi_id(rating_key)
    if kind == "movie":
        res = _jsonrpc("VideoLibrary.GetMovieDetails", {"movieid": num, "properties": MOVIE_PROPS}) or {}
        det = res.get("moviedetails")
        builder = _movie_rows
    elif kind == "show":
        res = _jsonrpc("VideoLibrary.GetTVShowDetails", {"tvshowid": num, "properties": SHOW_PROPS}) or {}
        det = res.get("tvshowdetails")
        builder = _show_rows
    else:
        return None
    if not det:
        return None
    item, ex = builder(det)
    item["checksum"] = _checksum({k: v for k, v in item.items() if k != "checksum"})
    now = int(time.time())
    conn = sqlite3.connect(db_path(), timeout=15.0)
    try:
        _ensure_schema(conn)
        _write_row(conn, dict(item, synced_at=now), ex, now)
        conn.commit()
    finally:
        conn.close()
    return item


def sync(reason=""):
    """Mirror the in-scope Kodi library into plex_km.db.  Returns a summary dict."""
    if not pkm_sources.has_kodi():
        return {"skipped": "no_kodi_source"}
    if not _SYNC_LOCK.acquire(False):
        return {"skipped": "busy"}
    t0 = time.time()
    try:
        everything, movie_pf, tv_pf = _scope()
        rows = {}
        extras = {}
        for m in _fetch("VideoLibrary.GetMovies", "movies", MOVIE_PROPS):
            if _in_scope(m.get("file"), everything, movie_pf):
                item, ex = _movie_rows(m)
                rows[item["rating_key"]], extras[item["rating_key"]] = item, ex
        shows = [s for s in _fetch("VideoLibrary.GetTVShows", "tvshows", SHOW_PROPS)
                 if _in_scope(s.get("file"), everything, tv_pf)]
        show_art = {}
        for s in shows:
            item, ex = _show_rows(s)
            rows[item["rating_key"]], extras[item["rating_key"]] = item, ex
            show_art[item["rating_key"]] = item["art"]
        if shows:
            wanted = set(int(s["tvshowid"]) for s in shows)
            for e in _fetch("VideoLibrary.GetEpisodes", "episodes", EPISODE_PROPS):
                if int(e.get("tvshowid") or 0) in wanted:
                    item, _ex = _episode_rows(e, show_art)
                    rows[item["rating_key"]] = item
        now = int(time.time())
        for item in rows.values():
            item["checksum"] = _checksum({k: v for k, v in item.items() if k != "checksum"})
        conn = sqlite3.connect(db_path(), timeout=15.0)
        try:
            _ensure_schema(conn)
            existing = dict(conn.execute("SELECT rating_key, checksum FROM items WHERE rating_key LIKE 'k:%'").fetchall())
            changed = [rk for rk, it in rows.items() if existing.get(rk) != it["checksum"]]
            removed = [rk for rk in existing if rk not in rows]
            ph = ",".join(["?"] * len(ITEM_COLS))
            for rk in changed:
                _write_row(conn, dict(rows[rk], synced_at=now), extras.get(rk), now)
            for i in range(0, len(removed), 400):
                batch = removed[i:i + 400]
                q = ",".join(["?"] * len(batch))
                for tbl in ("items", "item_genres", "item_people", "item_countries", "item_ratings", "item_ids_r108"):
                    conn.execute("DELETE FROM %s WHERE rating_key IN (%s)" % (tbl, q), batch)
            conn.commit()
        finally:
            conn.close()
        summary = {"total": len(rows), "changed": len(changed), "removed": len(removed),
                   "ms": int((time.time() - t0) * 1000)}
        _log("SYNC reason=%s total=%d changed=%d removed=%d ms=%d" % (reason or "-", summary["total"], summary["changed"],
                                                                     summary["removed"], summary["ms"]))
        if changed or removed:
            try:
                import xbmcgui
                xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.SyncedAtR108", str(int(time.time() * 1000)))
            except Exception:
                pass
        return summary
    except Exception:
        _log("SYNC_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return {"error": True}
    finally:
        _SYNC_LOCK.release()


class _KodiLibraryMonitor(xbmc.Monitor):
    """Re-mirror after Kodi scans/cleans and after watched-state changes."""

    def __init__(self):
        super(_KodiLibraryMonitor, self).__init__()
        self._due = 0.0

    def onScanFinished(self, library):
        if library == "video":
            self._due = time.time() + 1.0

    def onCleanFinished(self, library):
        if library == "video":
            self._due = time.time() + 1.0

    def onNotification(self, sender, method, data):
        if method in ("VideoLibrary.OnUpdate", "VideoLibrary.OnRemove"):
            self._due = max(self._due, time.time() + 3.0)


class _KodiItemPlayer(xbmc.Player):
    """Write watched state / resume point of Kodi-library items back to Kodi.

    PKM starts every item through plugin://...action=play, so Kodi records the
    state on that plugin URL, not on the library movie/episode.  PKM policy:
    30 s or more -> resume point (Continue Watching); 90 %+ or natural end ->
    watched (playcount + 1, resume cleared).
    """

    def __init__(self):
        super(_KodiItemPlayer, self).__init__()
        self.rk = ""
        self.pos = 0.0
        self.total = 0.0

    def _current_rk(self):
        try:
            import xbmcgui
            rk = xbmcgui.Window(10000).getProperty("PlexKM.NowPlaying.RatingKey") or ""
        except Exception:
            rk = ""
        return rk if is_kodi_key(rk) else ""

    def onAVStarted(self):
        self.rk = self._current_rk()
        self.pos, self.total = 0.0, 0.0

    def poll(self):
        if not self.rk:
            return
        try:
            if self.isPlayingVideo():
                self.pos = float(self.getTime() or 0)
                self.total = float(self.getTotalTime() or 0) or self.total
        except Exception:
            pass

    def onPlayBackStopped(self):
        self._commit(ended=False)

    def onPlayBackEnded(self):
        self._commit(ended=True)

    def onPlayBackError(self):
        self.rk = ""

    def _commit(self, ended):
        rk, pos, total = self.rk, self.pos, self.total
        self.rk = ""
        if not rk:
            return
        kind, dbid = kodi_id(rk)
        if kind not in ("movie", "episode") or not dbid:
            return
        watched = ended or (total > 0 and pos >= total * 0.9)
        method = "VideoLibrary.SetMovieDetails" if kind == "movie" else "VideoLibrary.SetEpisodeDetails"
        params = {"movieid" if kind == "movie" else "episodeid": dbid}
        if watched:
            details = _jsonrpc("VideoLibrary.GetMovieDetails" if kind == "movie" else "VideoLibrary.GetEpisodeDetails",
                               dict(params, properties=["playcount"])) or {}
            cur = int(((details.get("moviedetails") or details.get("episodedetails") or {}).get("playcount")) or 0)
            params.update({"playcount": cur + 1, "lastplayed": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "resume": {"position": 0, "total": 0}})
        elif pos >= 30:
            params.update({"lastplayed": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "resume": {"position": int(pos), "total": int(total or 0)}})
        else:
            _log("PLAYSTATE_SKIP rating_key=%s pos=%d reason=under_30s" % (rk, int(pos)))
            try:
                import xbmcgui
                xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.PlaystateWrittenR108", rk)
            except Exception:
                pass
            return
        ok = _jsonrpc(method, params) is not None
        try:
            import xbmcgui
            xbmcgui.Window(10000).setProperty("PlexKM.KodiSource.PlaystateWrittenR108", rk)
        except Exception:
            pass
        _log("PLAYSTATE_WRITE rating_key=%s watched=%d pos=%d total=%d ok=%d" % (rk, 1 if watched else 0, int(pos),
                                                                              int(total), 1 if ok else 0))


def start_background(stop_event=None, initial_delay=4.0):
    """Service hook: one sync after startup, then on library changes."""
    def _run():
        mon = _KodiLibraryMonitor()
        player = _KodiItemPlayer()
        if mon.waitForAbort(initial_delay):
            return
        if pkm_sources.has_kodi():
            sync(reason="service_start")
        while not mon.abortRequested():
            if stop_event is not None and stop_event.is_set():
                return
            player.poll()
            if mon._due and time.time() >= mon._due:
                mon._due = 0.0
                if pkm_sources.has_kodi():
                    sync(reason="library_changed")
            if mon.waitForAbort(1.0):
                return
    t = threading.Thread(target=_run, name="PKMKodiSourceR108")
    t.daemon = True
    t.start()
    return t
