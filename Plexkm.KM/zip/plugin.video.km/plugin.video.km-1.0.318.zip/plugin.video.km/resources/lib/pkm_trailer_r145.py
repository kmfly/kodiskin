# -*- coding: utf-8 -*-
"""R145: official-trailer lookup for Info pages (InnerTube search, no API key)."""
import re
import time

_TTL = 7 * 86400
_CACHE = "trailer_cache_r145.json"


def _cache_path(yt):
    import os
    return os.path.join(yt._data_dir(), _CACHE)


def _cache_load(yt):
    import json
    try:
        with open(_cache_path(yt), "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _cache_save(yt, d):
    import json
    try:
        if len(d) > 300:
            for k, _ in sorted(d.items(), key=lambda kv: kv[1].get("t", 0))[:len(d) - 300]:
                d.pop(k, None)
        with open(_cache_path(yt), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
    except Exception:
        pass
_GOOD = ("공식 예고편", "공식예고편", "메인 예고편", "메인예고편", "official trailer", "official teaser",
         "예고편", "티저", "trailer", "teaser")
_BAD = ("리뷰", "review", "reaction", "리액션", "해석", "결말", "분석", "요약", "줄거리", "리뷰", "shorts",
        "#shorts", "fan made", "fanmade", "팬메이드", "패러디", "parody", "ost", "mv", "하이라이트",
        "명장면", "몰아보기", "정주행", "bgm", "playlist", "episode", "ep.", "full movie", "풀버전")
_OFFICIAL = ("official", "공식", "pictures", "studios", "entertainment", "netflix", "disney", "warner",
             "universal", "sony", "paramount", "넷플릭스", "디즈니", "워너", "쇼박스", "showbox", "cj enm",
             "롯데", "lotte", "NEW", "플러스엠", "tving", "티빙", "wavve", "웨이브", "coupang", "쿠팡",
             "apple tv", "prime video", "hbo", "kbs", "mbc", "sbs", "tvn", "jtbc", "영화사", "배급")


_DOMESTIC = ("cj enm", "cj entertainment", "cj movies", "cj ent", "쇼박스", "showbox", "롯데엔터", "lotte ent", "new 영화",
             "new movie", "마인드마크", "플러스엠", "plus m", "메가박스", "megabox", "키다리", "와우포인트", "wowpoint",
             "워너브러더스 코리아", "warner bros. korea", "소니픽쳐스 코리아", "sony pictures korea", "디즈니코리아",
             "디즈니 코리아", "유니버설 픽쳐스 코리아", "paramount pictures korea", "넷플릭스 코리아", "netflix korea",
             "티빙", "tving", "쿠팡플레이", "coupang play", "웨이브", "wavve", "disney+ korea", "디즈니+", "apple tv korea",
             "스튜디오드래곤", "studio dragon", "jtbc", "tvn", "kbs", "mbc", "sbs", "에이스메이커", "바른손", "트리플픽쳐스")


def _norm(s):
    return re.sub(r"[\s\W_]+", "", str(s or "").lower())


_FILLER = ("공식", "official", "예고편", "예고", "trailer", "teaser", "티저", "메인", "main", "hd", "4k",
           "final", "최종", "본", "개봉", "영화", "movie", "한국어", "자막", "더빙", "국내", "해외", "신작",
           "넷플릭스", "netflix", "드라마", "시리즈", "series", "시즌", "season", "the", "a", "of", "예고영상",
           "스페셜", "special", "새로운", "new", "클립", "영상", "티빙", "tving", "웨이브", "wavve", "디즈니", "disney",
           "공개", "오리지널", "original", "1차", "2차", "3차", "한글", "kr", "korean")


def _remainder(t, title):
    x = re.sub(r"\([^)]*\)", " ", str(t or "").lower())
    x = re.sub(r"\b(19|20)\d{2}\b", " ", x)
    x = x.replace(str(title or "").lower(), " ")
    for w in sorted(_FILLER, key=len, reverse=True):
        x = x.replace(w, " ")
    x = re.sub(r"[\s\W_\d]+", "", x)
    return x


def _dur_sec(d):
    try:
        parts = [int(p) for p in str(d or "").split(":")]
    except Exception:
        return 0
    sec = 0
    for p in parts:
        sec = sec * 60 + p
    return sec


def _score(item, title, year):
    t = str(item.get("title") or "")
    tl = t.lower()
    if _norm(title) not in _norm(t):
        return -1
    if any(b in tl for b in _BAD):
        return -1
    if not any(g in tl for g in _GOOD):
        return -1
    rem = _remainder(t, title)
    if "vs" in rem or len(rem) >= 4:
        return -1
    other = re.findall(r"\b(?:19|20)\d{2}\b", t)
    if year and other and str(year) not in other:
        return -1
    sec = _dur_sec(item.get("duration"))
    if sec and (sec < 30 or sec > 330):
        return -1
    sc = 10
    if "공식" in tl or "official" in tl:
        sc += 6
    if "메인" in tl or "main" in tl:
        sc += 2
    if "티저" in tl or "teaser" in tl:
        sc -= 1
    if year and str(year) in t:
        sc += 2
    sc -= min(4, len(rem))
    ch = str(item.get("channel") or "").lower()
    if any(o in ch for o in _DOMESTIC):
        sc += 9
    if any(o.lower() in ch for o in _OFFICIAL):
        sc += 5
    return sc


def find(title, year="", is_tv=False, extra=""):
    """Return a pkm_youtube video dict for the best official trailer, or None."""
    title = str(title or "").strip()
    if not title:
        return None
    from resources.lib import pkm_youtube as yt
    key = "trailer_r145c:%s:%s:%d" % (_norm(title), year or "", 1 if is_tv else 0)
    cache = _cache_load(yt)
    ent = cache.get(key)
    if isinstance(ent, dict) and (time.time() - float(ent.get("t") or 0)) < _TTL:
        return ent.get("v") or None
    best, best_sc = None, -1
    queries = ["%s %s 공식 예고편" % (title, year or ""), "%s official trailer" % title]
    if extra:
        queries.insert(1, "%s %s 예고편" % (title, extra))
    if is_tv:
        queries[0] = "%s 드라마 공식 예고편" % title
    for q in queries:
        try:
            res = yt.it_search(q.strip())
        except Exception:
            res = {"videos": []}
        for it in (res.get("videos") or [])[:20]:
            if it.get("kind") != "video" or it.get("live"):
                continue
            sc = _score(it, title, year)
            if sc > best_sc:
                best, best_sc = it, sc
        if best_sc >= 16:
            break
    cache[key] = {"t": time.time(), "v": best or {}}
    _cache_save(yt, cache)
    return best


def play(title, year="", is_tv=False, extra=""):
    from resources.lib import pkm_youtube as yt
    from resources.lib import pkm_notify
    # R147: trailers play inside Kodi; no YouTube app, so no adb pairing / debugging prompt.
    v = find(title, year, is_tv, extra)
    if not v:
        pkm_notify.pkm_show_notice("예고편", "공식 예고편을 찾지 못했습니다")
        return False
    try:
        from resources.lib import pkm_ytstream_r146 as _ys
        _ys._log("start id=%s title=%s" % (v.get("id"), title))
        if _ys.play_in_kodi(str(v.get("id") or ""), "%s 예고편" % title):
            return True
        _ys._log("resolve_failed -> youtube app fallback")
    except Exception as exc:
        try:
            import xbmc, traceback
            xbmc.log("[plugin.video.km] YTSTREAM_R146 EXC %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        except Exception:
            pass
    return bool(yt.play(v))  # fallback: YouTube app


def prefetch(win):
    """Background lookup after Info opens; sets Window property TrailerOkR145 to 1/0
    (skin hides the button only when it is 0)."""
    import threading
    try:
        import xbmc
        if not xbmc.getCondVisibility("System.Platform.Android"):
            return
        title = win.getProperty("PlexKM.Info.Title") or ""
        year = win.getProperty("PlexKM.Info.Year") or ""
        is_tv = win.getProperty("PlexKM.Info.IsTV") == "1"
        extra = (win.getProperty("PlexKM.Info.Director") or "").split(",")[0].strip()
        orig = win.getProperty("PlexKM.Info.OriginalTitle") or ""
        rk = win.getProperty("PlexKM.Info.RatingKey") or ""
    except Exception:
        return
    win.clearProperty("PlexKM.Info.TrailerOkR145")
    # R147: no adb pairing (trailers play inside Kodi).
    if not title:
        return

    def run():
        try:
            # R147: the button follows the related-videos page: any trailer, teaser,
            # making-of/interview or intro video enables it (result is cached, so the
            # page then opens instantly).
            from resources.lib import pkm_trailer_page_r147 as _tp
            o = orig
            v = _tp.collect(title, year, is_tv, extra, o, rk)
            _tp._log("prefetch title=%s year=%s orig=%s rk=%s n=%d" % (title, year, o, rk, len(v or [])))
            if (win.getProperty("PlexKM.Info.Title") or "") == title:
                win.setProperty("PlexKM.Info.TrailerOkR145", "1" if v else "0")
        except Exception as exc:
            try:
                from resources.lib import pkm_trailer_page_r147 as _tp2
                _tp2._log("prefetch_err %r" % (exc,), 2)
            except Exception:
                pass
    threading.Thread(target=run, daemon=True).start()


_WARM_SEEN = set()


def warm(rk, title, year, is_tv, orig=""):
    """R148: pre-search trailers while a poster merely rests in focus, so the Info icon is
    ready (cached) when Info opens. Debounced 1.2 s, once per item."""
    import threading
    rk = str(rk or "")
    if not rk or not title or rk in _WARM_SEEN or len(_WARM_SEEN) > 400:
        return
    _WARM_SEEN.add(rk)

    def run():
        try:
            import time
            import xbmc
            import xbmcgui
            if not xbmc.getCondVisibility("System.Platform.Android"):
                return
            time.sleep(1.2)
            w = xbmcgui.Window(10000)
            if str(w.getProperty("PlexKM.Home.RatingKey") or "") != rk:
                _WARM_SEEN.discard(rk)
                return
            from resources.lib import pkm_trailer_page_r147 as _tp
            v = _tp.collect(title, year, is_tv, "", orig, rk)
            _tp._log("warm title=%s rk=%s n=%d" % (title, rk, len(v or [])))
        except Exception:
            _WARM_SEEN.discard(rk)
    threading.Thread(target=run, daemon=True).start()
