# -*- coding: utf-8 -*-
"""R120c: locally chosen metadata that Plex must not overwrite.

One JSON file per Plex profile (pkm_profile_r82 PER_USER_FILES):
  {"version": 1,
   "items":  {rating_key: {"title","year","summary","original_title","thumb","art",
                           "cast": [{"name","role","thumb"}], "directors": [...],
                           "genres": [...], "tmdb_id", "plex_updated_at", "at"}},
   "actors": {actor_key: {"name","thumb","at"}}}

Setting "meta_keep_local_r120" (PKM settings > 메타데이터 > 직접 바꾼 정보 유지):
  on  (default) -> the chosen values win over every Plex write (sync, Info fetch)
  off           -> chosen values are dropped as soon as Plex updates that item;
                   actor photo choices are not applied.

Everything here is plain dict/file/sqlite work: safe on worker threads.
"""
import json
import os
import re
import threading
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except Exception:  # unit tests
    xbmc = xbmcaddon = xbmcvfs = None

ADDON_ID = "plugin.video.km"
FILE_NAME = "meta_override_r120.json"
SETTING_ID = "meta_keep_local_r120"
SOURCE = "override_r120"

_LOCK = threading.RLock()
_CACHE = {"mtime": None, "data": None}


def _log(msg):
    if xbmc is None:
        return
    try:
        xbmc.log("[plugin.video.km] META_OVERRIDE_R120 %s" % msg, xbmc.LOGINFO)
    except Exception:
        pass


_PATH_MEMO = {"p": None}


def _path():
    if _PATH_MEMO["p"]:
        return _PATH_MEMO["p"]
    base = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
    if not os.path.isdir(base):
        os.makedirs(base, exist_ok=True)
    _PATH_MEMO["p"] = os.path.join(base, FILE_NAME)
    return _PATH_MEMO["p"]


def reset_path_memo():
    """Profile switch: the per-user file moves."""
    _PATH_MEMO["p"] = None
    _CACHE["data"] = None
    _CACHE["mtime"] = None


def enabled():
    try:
        return str(xbmcaddon.Addon(ADDON_ID).getSetting(SETTING_ID) or "").strip().lower() != "false"
    except Exception:
        return True


def set_enabled(on):
    try:
        xbmcaddon.Addon(ADDON_ID).setSetting(SETTING_ID, "true" if on else "false")
    except Exception:
        pass


def _load():
    path = _path()
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        mtime = None
    if _CACHE["data"] is not None and _CACHE["mtime"] == mtime:
        return _CACHE["data"]
    data = {"version": 1, "items": {}, "actors": {}}
    if mtime is not None:
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                data["items"] = dict(raw.get("items") or {})
                data["actors"] = dict(raw.get("actors") or {})
        except Exception as exc:
            _log("LOAD_FAILED err=%s" % exc)
    _CACHE["data"] = data
    _CACHE["mtime"] = mtime
    return data


def _save(data):
    path = _path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)
    try:
        _CACHE["mtime"] = os.path.getmtime(path)
    except Exception:
        _CACHE["mtime"] = None
    _CACHE["data"] = data


# ---------------------------------------------------------------- items
def get_item(rating_key):
    with _LOCK:
        rec = _load()["items"].get(str(rating_key))
        return dict(rec) if isinstance(rec, dict) else None


def art_for(rating_key):
    """R120e: fast (stat + dict) lookup for the nav hot path.
    Returns (poster, fanart) the user picked, '' when none."""
    if not rating_key:
        return "", ""
    try:
        rec = _load()["items"].get(str(rating_key))
    except Exception:
        return "", ""
    if not isinstance(rec, dict):
        return "", ""
    return str(rec.get("thumb") or ""), str(rec.get("art") or "")


_PLEX_ART_RE = None


def art_for_plex_url(url):
    """R120e: the Plex art URL names the item that owns it
    (/library/metadata/<rk>/art/...); an episode card usually carries
    its show's art, so this finds the show override without a DB hit."""
    global _PLEX_ART_RE
    if not url or "/library/metadata/" not in url:
        return "", ""
    try:
        if _PLEX_ART_RE is None:
            import re
            _PLEX_ART_RE = re.compile(r"/library/metadata/(\d+)/(?:art|thumb)")
        m = _PLEX_ART_RE.search(url)
        if not m:
            from urllib.parse import unquote
            m = _PLEX_ART_RE.search(unquote(url))
        return art_for(m.group(1)) if m else ("", "")
    except Exception:
        return "", ""


def set_item(rating_key, rec):
    with _LOCK:
        data = _load()
        rec = dict(rec or {})
        rec["at"] = int(time.time())
        data["items"][str(rating_key)] = rec
        _save(data)
    _log("SET_ITEM rating_key=%s fields=%s cast=%d" % (
        rating_key, ",".join(k for k in ("title", "summary", "thumb", "art") if rec.get(k)), len(rec.get("cast") or [])))


def update_item(rating_key, **fields):
    """Merge fields into an item override (creates it)."""
    with _LOCK:
        cur = get_item(rating_key) or {}
        cur.update({k: v for k, v in fields.items() if v is not None})
        set_item(rating_key, cur)


def clear_item(rating_key):
    with _LOCK:
        data = _load()
        if data["items"].pop(str(rating_key), None) is not None:
            _save(data)
            _log("CLEAR_ITEM rating_key=%s" % rating_key)
            return True
    return False


def count():
    with _LOCK:
        data = _load()
        return len(data["items"]), len(data["actors"])


def clear_all():
    with _LOCK:
        _save({"version": 1, "items": {}, "actors": {}})
    _log("CLEAR_ALL")


# ---------------------------------------------------------------- actors
def actor_key(name):
    return re.sub(r"[\s\W_]+", "", str(name or "").casefold(), flags=re.U)


def actor_photo(name):
    """Chosen photo URL for this actor, or "" (also "" when the option is off)."""
    if not name or not enabled():
        return ""
    with _LOCK:
        rec = _load()["actors"].get(actor_key(name))
    return str((rec or {}).get("thumb") or "") if isinstance(rec, dict) else ""


def set_actor_photo(name, url):
    k = actor_key(name)
    if not k:
        return
    with _LOCK:
        data = _load()
        if url:
            data["actors"][k] = {"name": str(name), "thumb": str(url), "at": int(time.time())}
        else:
            data["actors"].pop(k, None)
        _save(data)
    _log("ACTOR_PHOTO name=%s set=%d" % (name, 1 if url else 0))


# ---------------------------------------------------------------- DB enforcement
def reapply(conn, rating_key, plex_updated_at=None):
    """Call right after any Plex write for this item.  Option on: write the
    chosen values back over it.  Option off: drop the choice once Plex has
    really updated the item.  -> True when the row was rewritten."""
    rk = str(rating_key or "").strip()
    if not rk:
        return False
    rec = get_item(rk)
    if not rec:
        return False
    if not enabled():
        base = str(rec.get("plex_updated_at") or "")
        if plex_updated_at is not None and base and str(plex_updated_at) != base:
            clear_item(rk)
        return False
    write_db(conn, rk, rec)
    return True


def write_db(conn, rk, rec):
    sets, vals = [], []
    for col in ("title", "summary", "thumb", "art", "original_title"):
        if rec.get(col):
            sets.append("%s=?" % col)
            vals.append(rec[col])
    try:
        y = int(rec.get("year") or 0)
    except Exception:
        y = 0
    if y > 0:
        sets.append("year=?")
        vals.append(y)
    if sets:
        conn.execute("UPDATE items SET %s WHERE rating_key=?" % ",".join(sets), vals + [rk])
    row = conn.execute("SELECT section_id FROM items WHERE rating_key=?", (rk,)).fetchone()
    sid = str((row or [""])[0] or "")
    now = int(time.time())
    cast = list(rec.get("cast") or [])
    if cast:
        conn.execute("DELETE FROM item_people WHERE rating_key=? AND person_type='actor'", (rk,))
        for i, c in enumerate(cast[:40]):
            conn.execute("INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                         "person_thumb, tag_id, sort_order, source, indexed_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                         (rk, sid, "actor", c.get("name") or "", c.get("role") or "", c.get("thumb") or "",
                          "", i, SOURCE, now))
    directors = list(rec.get("directors") or [])
    if directors:
        conn.execute("DELETE FROM item_people WHERE rating_key=? AND person_type='director'", (rk,))
        for i, d in enumerate(directors[:8]):
            conn.execute("INSERT OR REPLACE INTO item_people(rating_key, section_id, person_type, person_name, role, "
                         "person_thumb, tag_id, sort_order, source, indexed_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                         (rk, sid, "director", d, "", "", "", i, SOURCE, now))
    genres = list(rec.get("genres") or [])
    if genres:
        conn.execute("DELETE FROM item_genres WHERE rating_key=?", (rk,))
        for g in genres[:12]:
            conn.execute("INSERT OR REPLACE INTO item_genres(rating_key, section_id, genre, tag_id, source, indexed_at) "
                         "VALUES (?,?,?,?,?,?)", (rk, sid, g, "", SOURCE, now))


def cast_slots(rating_key):
    """Info cast slots (same shape as the Plex Role fast lane) or []."""
    if not enabled():
        return []
    rec = get_item(rating_key) or {}
    out = []
    for c in list(rec.get("cast") or [])[:8]:
        thumb = actor_photo(c.get("name")) or str(c.get("thumb") or "")
        out.append({"Name": c.get("name") or "", "Role": c.get("role") or "",
                    "OriginalThumb": thumb, "DirectThumb": thumb, "SourceRatingKey": str(rating_key)})
    return out
