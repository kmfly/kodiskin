# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Google account link for PKM YouTube (R79, OAuth device flow).

The user creates an OAuth client of type "TV 및 입력 제한 기기" in their own
Google Cloud project and enters its client ID / secret from the phone page.
PKM then runs the device flow: the TV shows a short code, the phone opens
google.com/device, signs in and allows read-only YouTube access.

What the link is used for (scope youtube.readonly):
  * the user's real subscription list (subscriptions.list mine=true, 1 unit
    per 50 channels) -> merged into PKM's 구독 tab
  * the account's channel name/avatar for the settings panel
  * Data API calls when no API key is set (charts work with login alone)
New uploads of subscribed channels come from the free RSS feeds, so a large
subscription list never eats the daily API quota.
"""

import json
import threading
import time
import traceback

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from urllib.error import HTTPError
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen, HTTPError  # type: ignore
    from urllib import urlencode  # type: ignore

import xbmc

from resources.lib import pkm_youtube as yt

SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
DEVICE_URL = "https://oauth2.googleapis.com/device/code"
TOKEN_URL = "https://oauth2.googleapis.com/token"
REVOKE_URL = "https://oauth2.googleapis.com/revoke"
ACCOUNT_FILE = "youtube_account_r79.json"
ACCOUNT_SUBS_FILE = "youtube_account_subs_r79.json"
SUBS_SYNC_TTL_SEC = 6 * 3600

_lock = threading.RLock()


def _log(msg, level=xbmc.LOGINFO):
    yt.log("ACCOUNT " + msg, level)


def _load():
    with _lock:
        data = yt._load_json(ACCOUNT_FILE, {})
    return data if isinstance(data, dict) else {}


def _save(data):
    with _lock:
        yt._save_json(ACCOUNT_FILE, data)


def _post(url, fields):
    body = urlencode(fields).encode("utf-8")
    req = Request(url, data=body, headers={"Content-Type": "application/x-www-form-urlencoded",
                                           "User-Agent": yt.UA})
    try:
        resp = urlopen(req, timeout=15)
        try:
            return 200, json.loads(resp.read().decode("utf-8", "replace") or "{}")
        finally:
            resp.close()
    except HTTPError as exc:
        try:
            payload = json.loads(exc.read().decode("utf-8", "replace") or "{}")
        except Exception:
            payload = {}
        return getattr(exc, "code", 0), payload


# ------------------------------------------------------------------ client

def clean_client(client_id, client_secret):
    cid = "".join(str(client_id or "").split())
    sec = "".join(str(client_secret or "").split())
    if not cid.endswith(".apps.googleusercontent.com") or len(cid) < 40:
        return "", "", "클라이언트 ID 형식이 아닙니다 (…apps.googleusercontent.com 으로 끝남)"
    if len(sec) < 10:
        return "", "", "클라이언트 보안 비밀번호를 붙여넣으세요 (보통 GOCSPX- 로 시작)"
    return cid, sec, ""


def get_client():
    d = _load()
    return d.get("client_id") or "", d.get("client_secret") or ""


def set_client(client_id, client_secret):
    d = _load()
    if d.get("client_id") != client_id:
        # another client: old tokens are useless
        for k in ("refresh_token", "access_token", "expires_at", "name", "thumb", "channel_id"):
            d.pop(k, None)
    d["client_id"] = client_id
    d["client_secret"] = client_secret
    _save(d)
    _log("CLIENT_SET id=%s…" % client_id[:12])


def has_client():
    cid, sec = get_client()
    return bool(cid and sec)


def is_linked():
    return bool(_load().get("refresh_token"))


def account_info():
    d = _load()
    return {"name": d.get("name") or "", "thumb": d.get("thumb") or "", "channel_id": d.get("channel_id") or "",
            "linked": bool(d.get("refresh_token")), "client": bool(d.get("client_id") and d.get("client_secret")),
            "synced": int(d.get("subs_synced") or 0), "subs": len(account_subs())}


# ------------------------------------------------------------------ device flow

def device_start(client_id=None):
    """-> (ok, info_or_message).  info: user_code, verification_url, device_code, interval, expires_at.
    client_id: try a client that is not stored yet (phone page) -- saved only
    by the caller once Google accepted it."""
    cid = client_id or get_client()[0]
    if not cid:
        return False, "먼저 OAuth 클라이언트를 입력하세요"
    code, d = _post(DEVICE_URL, {"client_id": cid, "scope": SCOPE})
    if code != 200 or not d.get("device_code"):
        err = d.get("error") or code
        _log("DEVICE_START_FAILED err=%s desc=%s" % (err, d.get("error_description") or ""), xbmc.LOGWARNING)
        if err == "invalid_client" and "not found" in str(d.get("error_description") or "").lower():
            return False, "클라이언트 ID를 찾을 수 없습니다. 복사한 ID를 다시 확인하세요"
        if err in ("invalid_client", "unauthorized_client"):
            return False, "클라이언트가 맞지 않습니다. 유형이 'TV 및 입력 제한 기기'인지 확인하세요"
        if err == "invalid_scope":
            return False, "YouTube 권한을 요청할 수 없습니다 (프로젝트에서 YouTube Data API v3 사용 설정 확인)"
        return False, "로그인을 시작하지 못했습니다 (%s)" % err
    info = {"user_code": d.get("user_code") or "", "verification_url": d.get("verification_url") or "https://www.google.com/device",
            "device_code": d["device_code"], "interval": max(5, int(d.get("interval") or 5)),
            "expires_at": time.time() + int(d.get("expires_in") or 1800)}
    _log("DEVICE_START code=%s" % info["user_code"])
    return True, info


def device_poll(info):
    """One poll.  -> ('pending'|'slow'|'ok'|'denied'|'expired'|'error', message)."""
    cid, sec = get_client()
    if time.time() > info.get("expires_at", 0):
        return "expired", "코드 시간이 지났습니다. 다시 시작하세요"
    code, d = _post(TOKEN_URL, {"client_id": cid, "client_secret": sec, "device_code": info["device_code"],
                                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"})
    if code == 200 and d.get("access_token"):
        data = _load()
        data["access_token"] = d["access_token"]
        data["expires_at"] = time.time() + int(d.get("expires_in") or 3600) - 60
        if d.get("refresh_token"):
            data["refresh_token"] = d["refresh_token"]
        data["linked_at"] = int(time.time())
        _save(data)
        _log("DEVICE_LINKED refresh=%d" % (1 if d.get("refresh_token") else 0))
        return "ok", "연결되었습니다"
    err = d.get("error") or ""
    if err == "authorization_pending":
        return "pending", ""
    if err == "slow_down":
        return "slow", ""
    if err == "access_denied":
        return "denied", "휴대폰에서 허용하지 않았습니다. 다시 시작하세요"
    if err == "expired_token":
        return "expired", "코드 시간이 지났습니다. 다시 시작하세요"
    _log("DEVICE_POLL_FAILED code=%s err=%s desc=%s" % (code, err, d.get("error_description") or ""), xbmc.LOGWARNING)
    if err == "invalid_client":
        return "error", "클라이언트 보안 비밀번호가 맞지 않습니다"
    return "error", "로그인 실패 (%s)" % (err or code)


def _access_token(force=False):
    d = _load()
    if not d.get("refresh_token"):
        return ""
    if not force and d.get("access_token") and float(d.get("expires_at") or 0) > time.time():
        return d["access_token"]
    code, r = _post(TOKEN_URL, {"client_id": d.get("client_id"), "client_secret": d.get("client_secret"),
                                "refresh_token": d["refresh_token"], "grant_type": "refresh_token"})
    if code == 200 and r.get("access_token"):
        d = _load()
        d["access_token"] = r["access_token"]
        d["expires_at"] = time.time() + int(r.get("expires_in") or 3600) - 60
        d.pop("token_error", None)
        _save(d)
        return d["access_token"]
    err = r.get("error") or code
    _log("REFRESH_FAILED err=%s desc=%s" % (err, r.get("error_description") or ""), xbmc.LOGWARNING)
    if err in ("invalid_grant", "unauthorized_client", "invalid_client"):
        d = _load()
        d.pop("refresh_token", None)
        d.pop("access_token", None)
        # invalid_grant after ~7 days = consent screen left in "테스트"
        d["token_error"] = "만료" if err == "invalid_grant" else str(err)
        _save(d)
    return ""


def token_error():
    return _load().get("token_error") or ""


def bearer():
    """Access token for pkm_youtube._api (no key needed with a login)."""
    try:
        return _access_token()
    except Exception:
        _log("BEARER_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return ""


def api_get(path, params):
    tok = _access_token()
    if not tok:
        raise RuntimeError("not_linked")
    for attempt in (0, 1):
        url = yt.API_BASE + path + "?" + urlencode(params)
        req = Request(url, headers={"Authorization": "Bearer " + tok, "User-Agent": yt.UA})
        try:
            resp = urlopen(req, timeout=15)
            try:
                return json.loads(resp.read().decode("utf-8", "replace"))
            finally:
                resp.close()
        except HTTPError as exc:
            if getattr(exc, "code", 0) == 401 and attempt == 0:
                tok = _access_token(force=True)
                if tok:
                    continue
            raise


# ------------------------------------------------------------------ data

def account_subs():
    with _lock:
        subs = yt._load_json(ACCOUNT_SUBS_FILE, [])
    return [s for s in subs if isinstance(s, dict) and s.get("id")] if isinstance(subs, list) else []


def subs_stale():
    return is_linked() and time.time() - int(_load().get("subs_synced") or 0) > SUBS_SYNC_TTL_SEC


def sync(progress=None):
    """Fetch channel info + every subscription.  -> (ok, message)."""
    t0 = time.time()
    try:
        me = api_get("channels", {"part": "snippet", "mine": "true"})
        items = me.get("items") or []
        d = _load()
        if items:
            sn = items[0].get("snippet") or {}
            d["name"] = sn.get("title") or ""
            d["thumb"] = ((sn.get("thumbnails") or {}).get("default") or {}).get("url") or ""
            d["channel_id"] = items[0].get("id") or ""
        else:
            d["name"] = d.get("name") or "YouTube 채널 없음"
        _save(d)
        subs = []
        page = ""
        for _ in range(40):            # 2000 channels max
            params = {"part": "snippet", "mine": "true", "maxResults": 50, "order": "alphabetical"}
            if page:
                params["pageToken"] = page
            r = api_get("subscriptions", params)
            for it in r.get("items") or []:
                sn = it.get("snippet") or {}
                cid = ((sn.get("resourceId") or {}).get("channelId")) or ""
                if not cid:
                    continue
                subs.append({"id": cid, "title": sn.get("title") or "",
                             "thumb": yt.small_avatar(((sn.get("thumbnails") or {}).get("high") or
                                                       (sn.get("thumbnails") or {}).get("default") or {}).get("url") or ""),
                             "account": True})
            if progress:
                try:
                    progress(len(subs))
                except Exception:
                    pass
            page = r.get("nextPageToken") or ""
            if not page:
                break
        with _lock:
            yt._save_json(ACCOUNT_SUBS_FILE, subs)
        d = _load()
        d["subs_synced"] = int(time.time())
        _save(d)
        yt.mark_rows_stale("all", "subs")
        _log("SYNC_OK subs=%d ms=%d" % (len(subs), int((time.time() - t0) * 1000)))
        return True, "구독 채널 %d개를 가져왔습니다" % len(subs)
    except HTTPError as exc:
        reason = ""
        try:
            err = json.loads(exc.read().decode("utf-8", "replace"))
            reason = str(((err.get("error") or {}).get("errors") or [{}])[0].get("reason") or "")
        except Exception:
            pass
        _log("SYNC_HTTP_ERROR code=%s reason=%s" % (getattr(exc, "code", 0), reason), xbmc.LOGWARNING)
        if reason in ("accessNotConfigured", "SERVICE_DISABLED"):
            return False, "이 프로젝트에서 YouTube Data API v3가 꺼져 있습니다"
        if reason in ("quotaExceeded", "dailyLimitExceeded"):
            return False, "오늘 API 할당량을 다 썼습니다. 내일 다시 시도하세요"
        return False, "구독을 가져오지 못했습니다 (%s)" % (reason or getattr(exc, "code", "오류"))
    except Exception as exc:
        _log("SYNC_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        if str(exc) == "not_linked":
            return False, "계정 연결이 끊어졌습니다. 다시 연결하세요"
        return False, "구독을 가져오지 못했습니다"


def sync_if_stale_async():
    if not subs_stale():
        return
    t = threading.Thread(target=sync, name="PKMYTAccountSync")
    t.daemon = True
    t.start()


def unlink(forget_client=False):
    d = _load()
    tok = d.get("refresh_token") or d.get("access_token")
    if tok:
        try:
            _post(REVOKE_URL, {"token": tok})
        except Exception:
            pass
    for k in ("refresh_token", "access_token", "expires_at", "name", "thumb", "channel_id", "subs_synced",
              "linked_at", "token_error"):
        d.pop(k, None)
    if forget_client:
        d.pop("client_id", None)
        d.pop("client_secret", None)
    _save(d)
    with _lock:
        yt._save_json(ACCOUNT_SUBS_FILE, [])
    yt.mark_rows_stale("all", "subs")
    _log("UNLINK forget_client=%d" % (1 if forget_client else 0))
