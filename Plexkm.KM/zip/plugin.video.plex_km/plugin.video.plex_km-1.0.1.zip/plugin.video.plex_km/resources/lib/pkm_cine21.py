# -*- coding: utf-8 -*-
"""Cine21 rating cache helpers for Plex KM.

Data-only helpers. This module never controls UI focus/navigation.  Startup
Home drawing must not wait for this module.  Automatic work is designed to run
after Home is already open and only reads/writes the local DB plus optional
Cine21 detail fetches for rows that already have a trusted Cine21 movie_id.
"""
from __future__ import absolute_import, unicode_literals

import json
import re
import time
import traceback

try:
    from urllib.request import Request, urlopen
    from urllib.parse import quote
except Exception:
    from urllib2 import Request, urlopen
    from urllib import quote

try:
    from html import unescape
except Exception:
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except Exception:
        def unescape(value):
            return value

try:
    import xbmc
except Exception:  # allows import outside Kodi for py_compile
    xbmc = None
try:
    import xbmcgui
except Exception:
    xbmcgui = None

_TMDB_FROM_SJVA_RE = re.compile(r"sjva_agent://MT(\d+)", re.IGNORECASE)

# v926: constants were missing in v925 after schema/match refactor.
# Missing _CINE21_BASE_URL caused detail fetch failures; missing search regex/url
# caused movie_id matching to fall into MATCH_ERROR before any rating fetch.
_CINE21_BASE_URL = "https://cine21.com/movie/info/?movie_id=%s"
_CINE21_SEARCH_URL = "https://cine21.com/search/movie/?query=%s"
_SEARCH_MOVIE_RE = re.compile(
    r"""<a[^>]+href=["'](?:https?://(?:www\.)?cine21\.com)?/movie/info/\?movie_id=([0-9]+)[^"']*["'][^>]*>(.*?)</a>""",
    re.IGNORECASE | re.DOTALL
)
_YEAR_RE = re.compile(r"((?:19|20)\d{2})")
_OPEN_YEAR_RE = re.compile(r"(?:개봉|제작|년도|연도)[^0-9]{0,12}((?:19|20)\d{2})")
_TITLE_NORM_RE = re.compile(r"[\W_]+", re.UNICODE)


def _log(message, level=None):
    try:
        if xbmc is not None:
            xbmc.log("[plugin.video.plex_km] [PKM_CINE21] %s" % message, level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def extract_tmdb_id_from_plex_guid(guid):
    """Return TMDb candidate digits from an SJVA Plex guid."""
    try:
        text = str(guid or "")
    except Exception:
        return ""
    m = _TMDB_FROM_SJVA_RE.search(text)
    return m.group(1) if m else ""


def _raw_value(raw_json, key, default=""):
    try:
        data = json.loads(raw_json or "{}")
        value = data.get(key, default)
        return "" if value is None else str(value)
    except Exception:
        return default




def _raw_guid(raw_json):
    return _raw_value(raw_json, "guid", "")


def _raw_tmdb_id(raw_json):
    return extract_tmdb_id_from_plex_guid(_raw_guid(raw_json))


def _register_sql_functions(conn):
    """Register small SQLite UDFs for bulk seed from items.raw_json."""
    try:
        conn.create_function("pkm_cine21_guid", 1, _raw_guid)
    except Exception:
        pass
    try:
        conn.create_function("pkm_cine21_tmdb", 1, _raw_tmdb_id)
    except Exception:
        pass

def _cine21_abort_requested(abort_cb=None):
    """Return True when a background Cine21 worker must stop before any new web work.

    v941: UI playback safety.  Background Cine21 matching/fetching must never
    continue into playback.  Callers may pass an abort callback; this helper also
    checks Kodi player state and service-stop properties directly so a worker
    stops between items even if it was started before playback began.
    """
    try:
        if abort_cb and abort_cb():
            return True
    except Exception:
        pass
    try:
        if xbmc and (xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility("Player.HasVideo") or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)") or xbmc.getCondVisibility("Window.IsActive(videoosd)")):
            return True
    except Exception:
        pass
    try:
        if xbmcgui:
            win = xbmcgui.Window(10000)
            if (win.getProperty("PlexKM.Home.TrailerPreparing") == "1" or
                    win.getProperty("PlexKM.Home.TrailerActive") == "1" or
                    win.getProperty("PlexKM.Home.TrailerFadeHold") == "1"):
                return True
            if win.getProperty("PlexKM.ServiceStopping") == "1":
                return True
            # v1209: Kodi can spend several seconds between plugin handoff and
            # actual Player.HasVideo/VideoPlayer state.  During that opening window
            # background Cine21 DB work must also stop, otherwise duplicate backfill
            # and fetch jobs run exactly while playback is waiting for demux/seek.
            try:
                started_ms = int(float(win.getProperty("PlexKM.NowPlaying.StartedAtMs") or 0))
            except Exception:
                started_ms = 0
            try:
                if started_ms > 0 and (int(time.time() * 1000) - started_ms) <= 60000:
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False


def _table_columns(conn, table_name):
    """Return existing SQLite table columns as a set."""
    try:
        return set([str(row[1]) for row in conn.execute("PRAGMA table_info(%s)" % table_name).fetchall()])
    except Exception:
        return set()


def _ensure_column(conn, table_name, column_name, column_def):
    """Add a missing column to an existing table without rebuilding the DB."""
    try:
        cols = _table_columns(conn, table_name)
        if column_name not in cols:
            conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table_name, column_name, column_def))
            _log("schema_migrate_add_column table=%s column=%s" % (table_name, column_name))
            return 1
    except Exception:
        _log("schema_migrate_add_column_failed table=%s column=%s err=%s" % (
            table_name, column_name, traceback.format_exc().replace(chr(10), " | ")
        ), xbmc.LOGWARNING if xbmc else None)
    return 0



def init_cine21_schema(conn):
    _register_sql_functions(conn)
    """Create/migrate Cine21 tables without breaking the existing imported DB.

    v924: cine21_ratings is the master Cine21 rating table keyed by movie_id.
    Per-Plex-item state must live in cine21_matches.  v923 incorrectly treated
    cine21_ratings as an item table and failed on real user DBs where it has no
    rating_key column.
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_ratings (
            movie_id TEXT PRIMARY KEY,
            title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            image TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_matches (
            rating_key TEXT PRIMARY KEY,
            cine21_movie_id TEXT,
            match_status TEXT,
            match_type TEXT,
            match_score REAL,
            pkm_quality_status TEXT,
            pkm_title TEXT,
            pkm_original_title TEXT,
            pkm_year TEXT,
            pkm_section_id TEXT,
            pkm_media_file TEXT,
            cine21_title TEXT,
            critic_rating REAL,
            audience_rating REAL,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_match_summary (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        )
    """)
    migrated = 0
    for col, coldef in (
        ("movie_id", "TEXT"),
        ("title", "TEXT"),
        ("critic_rating", "REAL"),
        ("audience_rating", "REAL"),
        ("image", "TEXT"),
        ("updated_at", "TEXT"),
    ):
        migrated += _ensure_column(conn, "cine21_ratings", col, coldef)
    for col, coldef in (
        ("rating_key", "TEXT"),
        ("cine21_movie_id", "TEXT"),
        ("match_status", "TEXT"),
        ("match_type", "TEXT"),
        ("match_score", "REAL"),
        ("pkm_quality_status", "TEXT"),
        ("pkm_title", "TEXT"),
        ("pkm_original_title", "TEXT"),
        ("pkm_year", "TEXT"),
        ("pkm_section_id", "TEXT"),
        ("pkm_media_file", "TEXT"),
        ("cine21_title", "TEXT"),
        ("critic_rating", "REAL"),
        ("audience_rating", "REAL"),
        ("updated_at", "TEXT"),
    ):
        migrated += _ensure_column(conn, "cine21_matches", col, coldef)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cine21_expert_reviews (
            rating_key TEXT,
            cine21_movie_id TEXT,
            sort_order INTEGER,
            critic_name TEXT,
            critic_score REAL,
            critic_comment TEXT,
            fetched_at INTEGER,
            PRIMARY KEY (rating_key, critic_name)
        )
    """)
    for col, coldef in (
        ("rating_key", "TEXT"),
        ("cine21_movie_id", "TEXT"),
        ("sort_order", "INTEGER"),
        ("critic_name", "TEXT"),
        ("critic_score", "REAL"),
        ("critic_comment", "TEXT"),
        ("fetched_at", "INTEGER"),
    ):
        migrated += _ensure_column(conn, "cine21_expert_reviews", col, coldef)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_ratings_movie_id ON cine21_ratings(movie_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_rating_key ON cine21_matches(rating_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_movie_id ON cine21_matches(cine21_movie_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_status ON cine21_matches(match_status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_critic ON cine21_matches(critic_rating)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_matches_audience ON cine21_matches(audience_rating)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cine21_expert_rating_key ON cine21_expert_reviews(rating_key)")
    conn.commit()
    try:
        rcols = ",".join(sorted(_table_columns(conn, "cine21_ratings")))
        mcols = ",".join(sorted(_table_columns(conn, "cine21_matches")))
        _log("schema_ready_manual_v924 migrated=%s ratings_cols=%s match_cols=%s" % (migrated, rcols, mcols))
    except Exception:
        _log("schema_ready_manual_v924 migrated=%s" % migrated)


def build_pending_seed_rows(conn, limit=0):
    """Register PKM movie rows missing from cine21_matches.

    v925: use NOT EXISTS instead of NOT IN.  If cine21_matches contains any
    NULL rating_key row, SQL NOT IN returns no rows at all, so existing movies
    such as 9479791/마이클 never become Cine21 candidates.  This is the actual
    first gate before any Cine21 web crawl can happen.
    """
    init_cine21_schema(conn)
    now = int(time.time())
    limit = int(limit or 0)
    before = int(getattr(conn, "total_changes", 0) or 0)
    try:
        try:
            probe = conn.execute("""
                SELECT
                    (SELECT COUNT(*) FROM items WHERE plex_type='movie') AS movie_count,
                    (SELECT COUNT(*) FROM items i WHERE i.plex_type='movie' AND NOT EXISTS (
                        SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key
                    )) AS missing_count,
                    (SELECT COUNT(*) FROM cine21_matches WHERE rating_key IS NULL OR TRIM(COALESCE(rating_key,''))='') AS null_match_key_count,
                    (SELECT COUNT(*) FROM items WHERE rating_key='9479791') AS michael_item_count,
                    (SELECT COUNT(*) FROM cine21_matches WHERE rating_key='9479791') AS michael_match_count
            """).fetchone()
            _log("build_pending_seed_probe movie_count=%s missing_count=%s null_match_key_count=%s michael_item=%s michael_match=%s limit=%s" % (
                probe[0], probe[1], probe[2], probe[3], probe[4], limit
            ))
        except Exception:
            pass
        if limit > 0:
            conn.execute("""
                INSERT OR IGNORE INTO cine21_matches (
                    rating_key, cine21_movie_id, match_status, match_type, match_score,
                    pkm_quality_status, pkm_title, pkm_original_title, pkm_year,
                    pkm_section_id, pkm_media_file, cine21_title, critic_rating,
                    audience_rating, updated_at
                )
                SELECT rating_key, '', 'PENDING_CINE21', '', 0,
                       '', title, original_title, CAST(year AS TEXT), section_id,
                       '', '', NULL, NULL, ?
                FROM (
                    SELECT rating_key, section_id, title, original_title, year, added_at, synced_at
                    FROM items i
                    WHERE i.plex_type='movie'
                      AND NOT EXISTS (SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key)
                    ORDER BY COALESCE(i.added_at,0) DESC, COALESCE(i.synced_at,0) DESC, i.rating_key DESC
                    LIMIT ?
                )
            """, (now, limit))
        else:
            conn.execute("""
                INSERT OR IGNORE INTO cine21_matches (
                    rating_key, cine21_movie_id, match_status, match_type, match_score,
                    pkm_quality_status, pkm_title, pkm_original_title, pkm_year,
                    pkm_section_id, pkm_media_file, cine21_title, critic_rating,
                    audience_rating, updated_at
                )
                SELECT i.rating_key, '', 'PENDING_CINE21', '', 0,
                       '', i.title, i.original_title, CAST(i.year AS TEXT), i.section_id,
                       '', '', NULL, NULL, ?
                FROM items i
                WHERE i.plex_type='movie'
                  AND NOT EXISTS (SELECT 1 FROM cine21_matches cm WHERE cm.rating_key=i.rating_key)
            """, (now,))
        conn.commit()
        count = max(0, int(getattr(conn, "total_changes", 0) or 0) - before)
        try:
            rr = conn.execute("""
                SELECT i.rating_key, i.title, i.year,
                       COALESCE(cm.cine21_movie_id,''), COALESCE(cm.match_status,''),
                       COALESCE(cm.critic_rating,''), COALESCE(cm.audience_rating,'')
                FROM items i
                LEFT JOIN cine21_matches cm ON cm.rating_key=i.rating_key
                WHERE i.rating_key='9479791'
            """).fetchone()
            if rr:
                _log("build_pending_seed_probe_after rating_key=%s title=%s year=%s movie_id=%s status=%s critic=%s audience=%s inserted=%s" % (
                    rr[0], rr[1], rr[2], rr[3], rr[4], rr[5], rr[6], count
                ))
        except Exception:
            pass
        _log("build_pending_seed_rows_matches count=%s limit=%s" % (count, limit))
        return count
    except Exception:
        _log("build_pending_seed_rows_failed %s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
        return 0

def mark_missing_movie_id(conn, limit=1000):
    init_cine21_schema(conn)
    now = int(time.time())
    limit = int(limit or 0)
    try:
        sql = """
            UPDATE cine21_matches
            SET match_status='NEED_MOVIE_ID', updated_at=?
            WHERE COALESCE(cine21_movie_id, '')=''
              AND COALESCE(match_status, '') IN ('', 'PENDING_CINE21')
        """
        if limit > 0:
            rows = conn.execute("""
                SELECT rating_key FROM cine21_matches
                WHERE COALESCE(cine21_movie_id, '')=''
                  AND COALESCE(match_status, '') IN ('', 'PENDING_CINE21')
                ORDER BY updated_at DESC
                LIMIT ?
            """, (limit,)).fetchall()
            keys = [str(r[0] or "") for r in rows if r and r[0]]
            for key in keys:
                conn.execute("UPDATE cine21_matches SET match_status='NEED_MOVIE_ID', updated_at=? WHERE rating_key=?", (now, key))
            count = len(keys)
        else:
            before = int(getattr(conn, "total_changes", 0) or 0)
            conn.execute(sql, (now,))
            count = max(0, int(getattr(conn, "total_changes", 0) or 0) - before)
        conn.commit()
        if count:
            _log("mark_missing_movie_id count=%s limit=%s" % (count, limit))
        return count
    except Exception:
        _log("mark_missing_movie_id_failed %s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
        return 0


def set_cine21_movie_id(conn, rating_key, cine21_movie_id, status="NEED_FETCH"):
    """Persist Cine21 movie_id in cine21_matches for one PKM item."""
    init_cine21_schema(conn)
    rating_key = str(rating_key or "").strip()
    movie_id = str(cine21_movie_id or "").strip()
    if not rating_key or not re.match(r"^[0-9]+$", movie_id):
        return False
    now = int(time.time())
    meta = _item_metadata(conn, rating_key) or {}
    conn.execute("""
        INSERT INTO cine21_matches (
            rating_key, cine21_movie_id, match_status, match_type, match_score,
            pkm_quality_status, pkm_title, pkm_original_title, pkm_year,
            pkm_section_id, pkm_media_file, cine21_title, critic_rating,
            audience_rating, updated_at
        ) VALUES (?, ?, ?, 'EXACT_WEB_MATCH', 1.0, '', ?, ?, ?, ?, '', '', NULL, NULL, ?)
        ON CONFLICT(rating_key) DO UPDATE SET
            cine21_movie_id=excluded.cine21_movie_id,
            match_status=excluded.match_status,
            match_type=excluded.match_type,
            match_score=excluded.match_score,
            pkm_title=excluded.pkm_title,
            pkm_original_title=excluded.pkm_original_title,
            pkm_year=excluded.pkm_year,
            pkm_section_id=excluded.pkm_section_id,
            updated_at=excluded.updated_at
    """, (
        rating_key, movie_id, (status or "NEED_FETCH").upper(),
        meta.get("title", ""), meta.get("original_title", ""), str(meta.get("year", "") or ""),
        meta.get("section_id", ""), now,
    ))
    conn.commit()
    _log("movie_id_set rating_key=%s movie_id=%s status=%s" % (rating_key, movie_id, status or "NEED_FETCH"))
    return True

def count_total_movie_items(conn):
    """Count movie rows in the PKM item cache.  Cine21 is movie-only."""
    row = conn.execute("""
        SELECT COUNT(*)
        FROM items
        WHERE plex_type='movie'
    """).fetchone()
    try:
        return int(row[0] or 0)
    except Exception:
        return 0



def count_ok_ratings(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE match_status='MATCHED' AND (critic_rating IS NOT NULL OR audience_rating IS NOT NULL)
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_seed_candidates(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM items i
        WHERE i.plex_type='movie'
          AND NOT EXISTS (SELECT 1 FROM cine21_matches c WHERE c.rating_key=i.rating_key)
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_pending_without_movie_id(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE COALESCE(cine21_movie_id, '')=''
          AND COALESCE(match_status, '') IN ('', 'PENDING_CINE21', 'NEED_MOVIE_ID')
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_match_candidates_without_movie_id(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE COALESCE(cine21_movie_id, '')=''
          AND COALESCE(match_status, '') IN ('', 'PENDING_CINE21', 'NEED_MOVIE_ID', 'NO_MATCH_NOT_IN_CINE21', 'MATCH_ERROR')
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def count_fetch_candidates_with_movie_id(conn):
    init_cine21_schema(conn)
    row = conn.execute("""
        SELECT COUNT(*) FROM cine21_matches
        WHERE COALESCE(cine21_movie_id, '') <> ''
          AND (COALESCE(match_status, '') IN ('', 'NEED_FETCH', 'MATCH_ERROR')
               OR (match_status='MATCHED' AND critic_rating IS NULL AND audience_rating IS NULL))
    """).fetchone()
    try: return int(row[0] or 0)
    except Exception: return 0


def get_status_counts(conn):
    init_cine21_schema(conn)
    rows = conn.execute("""
        SELECT COALESCE(match_status, ''), COUNT(*)
        FROM cine21_matches
        GROUP BY COALESCE(match_status, '')
        ORDER BY COUNT(*) DESC
    """).fetchall()
    return [(str(status or ""), int(count or 0)) for status, count in rows]

def _normalize_title_for_match(value):
    text = _clean_text(value or "").lower()
    # Drop common decoration used in Plex titles and Cine21 search snippets.
    text = text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return _TITLE_NORM_RE.sub("", text)


def _fetch_cine21_search_html(query, timeout=8):
    query = str(query or "").strip()
    if not query:
        raise ValueError("empty Cine21 search query")
    url = _CINE21_SEARCH_URL % quote(query, safe="")
    _log("movie_id_search_request query=%s url=%s" % (query, url))
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) PlexKM/0.3",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    })
    with urlopen(req, timeout=int(timeout or 8)) as resp:
        raw = resp.read()
    try:
        return raw.decode("utf-8", "replace"), url
    except Exception:
        return raw.decode("euc-kr", "replace"), url


def parse_cine21_movie_search(html):
    """Return movie search candidates from Cine21 search HTML."""
    html = html or ""
    results = []
    matches = list(_SEARCH_MOVIE_RE.finditer(html))
    for idx, match in enumerate(matches):
        movie_id = str(match.group(1) or "").strip()
        title = _clean_text(match.group(2) or "")
        if not movie_id or not title:
            continue
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else min(len(html), start + 1200)
        context = _clean_text(html[start:end])
        year = 0
        m = _YEAR_RE.search(context)
        if not m:
            m = _OPEN_YEAR_RE.search(context)
        if m:
            try:
                year = int(m.group(1))
            except Exception:
                year = 0
        results.append({
            "movie_id": movie_id,
            "title": title,
            "year": year,
            "context": context[:300],
        })
    return results


def _search_queries_for_meta(meta):
    queries = []
    for key in ("title", "original_title"):
        value = str((meta or {}).get(key) or "").strip()
        if value and value not in queries:
            queries.append(value)
    return queries[:2]



# v927 standalone-test fix: Cine21 search pages often do not expose a usable
# year for candidates.  In that case, probe a small number of same-title detail
# pages and confirm by detail page year before accepting the movie_id.
def _parse_cine21_detail_identity(html):
    txt = _clean_text(html or "")
    title = ""
    original = ""
    year = 0
    try:
        m = re.search(r"영화\s+(.{1,80}?)\s+([A-Za-z0-9][^\n\r]{0,120}?)\s*\((19\d{2}|20\d{2})\)", txt)
        if m:
            title = _clean_text(m.group(1))
            original = _clean_text(m.group(2))
            year = int(m.group(3))
        if not title:
            mt = re.search(r"<title>\s*(.*?)\s*</title>", html or "", re.IGNORECASE | re.DOTALL)
            if mt:
                t = _clean_text(mt.group(1))
                mm = re.search(r"(.+?)\s*\((.*?)\)", t)
                if mm:
                    title = _clean_text(mm.group(1))
                    original = _clean_text(mm.group(2))
                else:
                    title = _clean_text(t.split("|")[0].replace("상세정보", ""))
        if not year:
            # Prefer years near the movie-title section at the top of the detail page.
            head = txt[:2500]
            years = re.findall(r"\((19\d{2}|20\d{2})\)", head)
            if years:
                year = int(years[0])
    except Exception:
        pass
    return {"title": title, "original_title": original, "year": int(year or 0)}


def _detail_probe_candidates_for_exact_title(all_candidates, title_norms, max_probe=6):
    out = []
    seen = set()
    for cand in all_candidates or []:
        mid = str(cand.get("movie_id") or "").strip()
        if not mid or mid in seen:
            continue
        cand_norm = _normalize_title_for_match(cand.get("title", ""))
        # Only detail-probe plausible same-title candidates.  This prevents
        # broad keyword searches from crawling unrelated Cine21 result pages.
        if cand_norm in title_norms:
            out.append(cand)
            seen.add(mid)
            if len(out) >= int(max_probe or 6):
                break
    return out


def _try_detail_probe_exact_match(meta, all_candidates, title_norms, timeout=8):
    target_year = int((meta or {}).get("year") or 0)
    detail_exact = []
    for cand in _detail_probe_candidates_for_exact_title(all_candidates, title_norms, max_probe=6):
        movie_id = str(cand.get("movie_id") or "").strip()
        try:
            html, url = _fetch_cine21_html(movie_id, timeout=timeout)
            ident = _parse_cine21_detail_identity(html)
            parsed = parse_cine21_movie_page(html)
            cand_norm = _normalize_title_for_match(cand.get("title", ""))
            detail_norms = set([cand_norm])
            for value in (ident.get("title", ""), ident.get("original_title", "")):
                n = _normalize_title_for_match(value)
                if n:
                    detail_norms.add(n)
            _log("movie_id_detail_probe rating_key=%s movie_id=%s search_title=%s search_year=%s detail_title=%s detail_original=%s detail_year=%s critic=%s audience=%s url=%s" % (
                (meta or {}).get("rating_key", ""), movie_id, cand.get("title", ""), cand.get("year", ""),
                ident.get("title", ""), ident.get("original_title", ""), ident.get("year", 0),
                parsed.get("critic_rating"), parsed.get("audience_rating"), url
            ))
            if target_year and int(ident.get("year") or 0) == target_year and (detail_norms & title_norms):
                cc = dict(cand)
                cc["year"] = int(ident.get("year") or 0)
                cc["detail_title"] = ident.get("title", "")
                cc["detail_original_title"] = ident.get("original_title", "")
                detail_exact.append(cc)
        except Exception as exc:
            _log("movie_id_detail_probe_error rating_key=%s movie_id=%s error=%s" % (
                (meta or {}).get("rating_key", ""), movie_id, exc
            ), xbmc.LOGWARNING if xbmc else None)
    unique = []
    seen = set()
    for cand in detail_exact:
        mid = str(cand.get("movie_id") or "")
        if mid and mid not in seen:
            seen.add(mid)
            unique.append(cand)
    return unique

def find_cine21_movie_id_for_item(conn, rating_key, timeout=8):
    """Find a trusted Cine21 movie_id by exact normalized title + year.

    This deliberately rejects ambiguous/no-year matches to avoid filling the DB
    with wrong ratings.  It returns a structured status for logging and DB state.
    """
    meta = _item_metadata(conn, rating_key)
    if not meta:
        return {"status": "error", "error": "missing_item", "rating_key": str(rating_key or "")}
    target_year = int(meta.get("year") or 0)
    try:
        _log("movie_id_search_start rating_key=%s title=%s original_title=%s year=%s queries=%s" % (
            meta.get("rating_key", ""), meta.get("title", ""), meta.get("original_title", ""),
            target_year, ",".join(_search_queries_for_meta(meta))
        ))
    except Exception:
        pass
    title_norms = set()
    for q in _search_queries_for_meta(meta):
        n = _normalize_title_for_match(q)
        if n:
            title_norms.add(n)
    if not title_norms or not target_year:
        return {"status": "no_match", "error": "missing_title_or_year", "rating_key": meta.get("rating_key", "")}
    all_candidates = []
    errors = []
    for query in _search_queries_for_meta(meta):
        try:
            html, url = _fetch_cine21_search_html(query, timeout=timeout)
            parsed_candidates = parse_cine21_movie_search(html)
            _log("movie_id_search_result rating_key=%s query=%s url=%s html_len=%s candidates=%s" % (
                meta.get("rating_key", ""), query, url, len(html or ""), len(parsed_candidates)
            ))
            for cand in parsed_candidates:
                cand["query"] = query
                cand["search_url"] = url
                all_candidates.append(cand)
            for cand in parsed_candidates[:5]:
                _log("movie_id_search_candidate rating_key=%s query=%s movie_id=%s title=%s year=%s" % (
                    meta.get("rating_key", ""), query, cand.get("movie_id", ""), cand.get("title", ""), cand.get("year", "")
                ))
        except Exception as exc:
            err = "%s:%s" % (query, exc)
            _log("movie_id_search_error rating_key=%s query=%s error=%s" % (meta.get("rating_key", ""), query, err), xbmc.LOGWARNING if xbmc else None)
            errors.append(err)
    if not all_candidates and errors:
        return {"status": "error", "error": "; ".join(errors)[:400], "rating_key": meta.get("rating_key", "")}
    exact = []
    for cand in all_candidates:
        cand_norm = _normalize_title_for_match(cand.get("title", ""))
        cand_year = int(cand.get("year") or 0)
        if cand_norm in title_norms and cand_year == target_year:
            exact.append(cand)
    # Dedupe by movie_id.
    unique = []
    seen = set()
    for cand in exact:
        mid = str(cand.get("movie_id") or "")
        if mid and mid not in seen:
            seen.add(mid)
            unique.append(cand)
    if len(unique) == 1:
        cand = unique[0]
        _log("movie_id_search_exact rating_key=%s movie_id=%s title=%s year=%s query=%s" % (
            meta.get("rating_key", ""), cand.get("movie_id", ""), cand.get("title", ""), cand.get("year", ""), cand.get("query", "")
        ))
        return {
            "status": "matched",
            "rating_key": meta.get("rating_key", ""),
            "movie_id": cand.get("movie_id", ""),
            "title": cand.get("title", ""),
            "year": cand.get("year", 0),
            "query": cand.get("query", ""),
        }
    if len(unique) > 1:
        _log("movie_id_search_ambiguous rating_key=%s exact_count=%s total_candidates=%s" % (
            meta.get("rating_key", ""), len(unique), len(all_candidates)
        ))
        return {"status": "ambiguous", "rating_key": meta.get("rating_key", ""), "count": len(unique)}

    # v927: Cine21 search result pages frequently return year=0.  Probe only
    # same-title candidates and confirm using the detail page year.
    detail_unique = _try_detail_probe_exact_match(meta, all_candidates, title_norms, timeout=timeout)
    if len(detail_unique) == 1:
        cand = detail_unique[0]
        _log("movie_id_search_detail_exact rating_key=%s movie_id=%s title=%s detail_title=%s year=%s query=%s" % (
            meta.get("rating_key", ""), cand.get("movie_id", ""), cand.get("title", ""),
            cand.get("detail_title", ""), cand.get("year", ""), cand.get("query", "")
        ))
        return {
            "status": "matched",
            "rating_key": meta.get("rating_key", ""),
            "movie_id": cand.get("movie_id", ""),
            "title": cand.get("detail_title") or cand.get("title", ""),
            "year": cand.get("year", 0),
            "query": cand.get("query", ""),
        }
    if len(detail_unique) > 1:
        _log("movie_id_search_detail_ambiguous rating_key=%s exact_count=%s total_candidates=%s" % (
            meta.get("rating_key", ""), len(detail_unique), len(all_candidates)
        ))
        return {"status": "ambiguous", "rating_key": meta.get("rating_key", ""), "count": len(detail_unique)}

    _log("movie_id_search_no_exact rating_key=%s title_norms=%s year=%s total_candidates=%s" % (
        meta.get("rating_key", ""), ",".join(sorted(title_norms)), target_year, len(all_candidates)
    ))
    return {"status": "no_match", "rating_key": meta.get("rating_key", ""), "count": len(all_candidates)}



def _match_candidates_without_movie_id(conn, limit=20):
    init_cine21_schema(conn)
    limit = max(1, int(limit or 1))
    rows = conn.execute("""
        SELECT cm.rating_key
        FROM cine21_matches cm
        LEFT JOIN items i ON i.rating_key=cm.rating_key
        WHERE TRIM(COALESCE(cm.rating_key,'')) <> ''
          AND COALESCE(cm.cine21_movie_id, '')=''
          AND COALESCE(cm.match_status, '') IN ('', 'PENDING_CINE21', 'NEED_MOVIE_ID', 'NO_MATCH_NOT_IN_CINE21', 'MATCH_ERROR')
        ORDER BY CASE WHEN cm.rating_key='9479791' THEN 0 ELSE 1 END,
                 COALESCE(i.added_at,0) DESC, COALESCE(i.synced_at,0) DESC,
                 COALESCE(cm.updated_at,0) DESC, cm.rating_key DESC
        LIMIT ?
    """, (limit,)).fetchall()
    try:
        sample = ",".join([str(r[0]) for r in rows[:5]])
        michael = conn.execute("""
            SELECT COUNT(*), COALESCE(MAX(match_status),''), COALESCE(MAX(cine21_movie_id),'')
            FROM cine21_matches WHERE rating_key='9479791'
        """).fetchone()
        _log("match_candidates_without_movie_id count=%s sample=%s michael_count=%s michael_status=%s michael_movie_id=%s" % (
            len(rows), sample, michael[0], michael[1], michael[2]
        ))
    except Exception:
        pass
    return rows

def match_cine21_movie_ids(conn, limit=20, timeout=8, progress_cb=None, total=None, base_done=0, abort_cb=None):
    """Search Cine21 and save movie_id only for exact title/year matches.

    progress_cb is optional and data-only; it lets settings show current/total
    while the user waits.  Existing ok rows are never selected here.
    """
    init_cine21_schema(conn)
    stats = {"checked": 0, "matched": 0, "no_match": 0, "ambiguous": 0, "error": 0}
    now = int(time.time())
    rows = _match_candidates_without_movie_id(conn, limit=limit)
    for row in rows:
        if _cine21_abort_requested(abort_cb):
            stats["aborted"] = 1
            _log("movie_id_match_abort reason=player_or_service_active checked=%s" % stats.get("checked", 0), xbmc.LOGINFO if xbmc else None)
            break
        rating_key = str(row[0] or "")
        if not rating_key:
            continue
        stats["checked"] += 1
        try:
            result = find_cine21_movie_id_for_item(conn, rating_key, timeout=timeout)
            status = result.get("status")
            if status == "matched":
                if set_cine21_movie_id(conn, rating_key, result.get("movie_id"), status="NEED_FETCH"):
                    stats["matched"] += 1
                    _log("movie_id_match_ok rating_key=%s movie_id=%s query=%s title=%s year=%s" % (
                        rating_key, result.get("movie_id"), result.get("query", ""), result.get("title", ""), result.get("year", "")
                    ))
            elif status == "ambiguous":
                stats["ambiguous"] += 1
                conn.execute("UPDATE cine21_matches SET match_status='AMBIGUOUS', match_type=?, updated_at=? WHERE rating_key=?", (
                    "multiple_exact_matches", now, rating_key,
                ))
                conn.commit()
            elif status == "error":
                stats["error"] += 1
                conn.execute("UPDATE cine21_matches SET match_status='MATCH_ERROR', match_type=?, updated_at=? WHERE rating_key=?", (
                    str(result.get("error") or "search_error")[:500], now, rating_key,
                ))
                conn.commit()
            else:
                stats["no_match"] += 1
                conn.execute("UPDATE cine21_matches SET match_status='NO_MATCH_NOT_IN_CINE21', match_type=?, updated_at=? WHERE rating_key=?", (
                    "no_exact_title_year_match", now, rating_key,
                ))
                conn.commit()
        except Exception:
            stats["error"] += 1
            conn.execute("UPDATE cine21_matches SET match_status='MATCH_ERROR', match_type=?, updated_at=? WHERE rating_key=?", (
                traceback.format_exc()[:500], now, rating_key,
            ))
            conn.commit()
        try:
            if progress_cb:
                progress_cb(dict(stats), int(base_done or 0) + int(stats.get("checked", 0) or 0), int(total or limit or 0), rating_key)
        except Exception:
            pass
    _log("movie_id_match_done checked=%s matched=%s no_match=%s ambiguous=%s error=%s limit=%s" % (
        stats["checked"], stats["matched"], stats["no_match"], stats["ambiguous"], stats["error"], int(limit or 0)
    ))
    return stats


_FLOAT_RE = re.compile(r"([0-9]+(?:\.[0-9]+)?)")
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t\r\n]+")


def _clean_text(value):
    text = unescape(value or "")
    text = _TAG_RE.sub(" ", text)
    text = text.replace("\xa0", " ")
    return _WS_RE.sub(" ", text).strip()


def _text_lines_from_html(html):
    text = html or ""
    text = re.sub(r"(?is)<script.*?</script>", " ", text)
    text = re.sub(r"(?is)<style.*?</style>", " ", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</(p|li|div|dt|dd|h[1-6]|span|strong|em|section|article|ul|ol|tr|td|th)>", "\n", text)
    text = _TAG_RE.sub(" ", text)
    text = unescape(text).replace("\xa0", " ")
    lines = []
    for line in text.splitlines():
        line = _WS_RE.sub(" ", line).strip()
        if line:
            lines.append(line)
    return lines


def _first_number_after_label(lines, label):
    for idx, line in enumerate(lines):
        if label in line:
            # prefer next line when the label is isolated, but support same-line text.
            search_area = [line] + lines[idx + 1:idx + 4]
            for candidate in search_area:
                if candidate == label or label in candidate:
                    candidate = candidate.replace(label, " ")
                m = _FLOAT_RE.search(candidate)
                if m:
                    try:
                        return float(m.group(1))
                    except Exception:
                        pass
    return None


def _parse_expert_count(lines):
    for line in lines:
        if "씨네21 전문가 별점" in line and "명 참여" in line:
            m = re.search(r"\(([0-9]+)명", line)
            if m:
                try:
                    return int(m.group(1))
                except Exception:
                    return 0
    return 0


def _parse_expert_reviews(lines):
    try:
        start = None
        for i, line in enumerate(lines):
            if "씨네21 전문가 별점" in line and "명 참여" in line:
                start = i + 1
                break
        if start is None:
            return []
        end = len(lines)
        for j in range(start, len(lines)):
            if lines[j].startswith("관련 기사") or lines[j].startswith("감독과 배우"):
                end = j
                break
        block = lines[start:end]
        reviews = []
        i = 0
        while i < len(block) - 2:
            name = block[i].strip()
            score_text = block[i + 1].strip()
            comment = block[i + 2].strip()
            if re.match(r"^[가-힣A-Za-z·.\s]{2,20}$", name) and re.match(r"^[0-9](?:\.[0-9])?$|^10$", score_text):
                try:
                    score = float(score_text)
                except Exception:
                    score = None
                if score is not None and comment and not comment.startswith("관련"):
                    reviews.append({
                        "critic_name": name,
                        "critic_score": score,
                        "critic_comment": comment,
                    })
                    i += 3
                    continue
            i += 1
        return reviews
    except Exception:
        return []


def parse_cine21_movie_page(html):
    """Parse Cine21 movie detail HTML into ratings and expert reviews."""
    lines = _text_lines_from_html(html or "")
    critic = _first_number_after_label(lines, "씨네21 전문가 별점")
    audience = _first_number_after_label(lines, "관객 별점")
    reviews = _parse_expert_reviews(lines)
    expert_count = _parse_expert_count(lines) or len(reviews)
    return {
        "critic_rating": critic,
        "audience_rating": audience,
        "expert_count": expert_count,
        "expert_reviews": reviews,
    }


def _fetch_cine21_html(movie_id, timeout=8):
    movie_id = str(movie_id or "").strip()
    if not re.match(r"^[0-9]+$", movie_id):
        raise ValueError("invalid Cine21 movie_id: %s" % movie_id)
    url = _CINE21_BASE_URL % movie_id
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) PlexKM/0.3",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    })
    with urlopen(req, timeout=int(timeout or 8)) as resp:
        raw = resp.read()
    try:
        return raw.decode("utf-8", "replace"), url
    except Exception:
        return raw.decode("euc-kr", "replace"), url


def _item_metadata(conn, rating_key):
    row = conn.execute("""
        SELECT rating_key, section_id, title, original_title, year, raw_json
        FROM items
        WHERE rating_key=?
    """, (str(rating_key or ""),)).fetchone()
    if not row:
        return None
    rating_key, section_id, title, original_title, year, raw_json = row
    plex_guid = _raw_value(raw_json, "guid", "")
    return {
        "rating_key": str(rating_key or ""),
        "section_id": str(section_id or ""),
        "title": str(title or ""),
        "original_title": str(original_title or ""),
        "year": int(year or 0),
        "plex_guid": plex_guid,
        "tmdb_id": extract_tmdb_id_from_plex_guid(plex_guid),
    }



def _norm_identity_text(value):
    try:
        return _TITLE_NORM_RE.sub("", str(value or "").lower()).strip()
    except Exception:
        return ""


def _duplicate_movie_identity_matches(meta, row):
    """Return match reason for the same physical movie exposed as another Plex item.

    v931: Plex can expose the same movie multiple times (normal library,
    latest folder, UHD/4K library).  Each copy gets a different rating_key, but
    Cine21 identity must be shared when TMDb id matches, or when title/year is
    exactly the same.
    """
    try:
        if not meta or not row:
            return ""
        src_year = str(meta.get("year", "") or "").strip()
        row_year = str(row.get("year", "") or "").strip()
        if src_year and row_year and src_year != row_year:
            return ""
        src_tmdb = str(meta.get("tmdb_id", "") or "").strip()
        row_tmdb = str(row.get("tmdb_id", "") or "").strip()
        if src_tmdb and row_tmdb and src_tmdb == row_tmdb:
            return "DUPLICATE_TMDB"
        src_titles = set([_norm_identity_text(meta.get("title", "")), _norm_identity_text(meta.get("original_title", ""))])
        row_titles = set([_norm_identity_text(row.get("title", "")), _norm_identity_text(row.get("original_title", ""))])
        src_titles.discard("")
        row_titles.discard("")
        if src_year and row_year and src_titles.intersection(row_titles):
            return "DUPLICATE_TITLE_YEAR"
    except Exception:
        return ""
    return ""


def _candidate_duplicate_items(conn, meta):
    try:
        year = str(meta.get("year", "") or "").strip()
        if not year:
            return []
        rows = conn.execute("""
            SELECT rating_key, section_id, title, original_title, year, raw_json
            FROM items
            WHERE plex_type='movie'
              AND rating_key<>?
              AND CAST(COALESCE(year,'') AS TEXT)=?
        """, (str(meta.get("rating_key", "") or ""), year)).fetchall()
        out = []
        for r in rows:
            raw_json = r[5] if len(r) > 5 else ""
            cand = {
                "rating_key": str(r[0] or ""),
                "section_id": str(r[1] or ""),
                "title": str(r[2] or ""),
                "original_title": str(r[3] or ""),
                "year": str(r[4] or ""),
                "tmdb_id": _raw_tmdb_id(raw_json),
            }
            reason = _duplicate_movie_identity_matches(meta, cand)
            if reason:
                cand["reason"] = reason
                out.append(cand)
        return out
    except Exception:
        _log("duplicate_candidate_scan_failed %s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
        return []


def propagate_cine21_match_to_duplicate_items(conn, rating_key, cine21_movie_id, critic, audience, meta=None, cine21_title="", now=None):
    """Copy a confirmed Cine21 match to duplicate Plex items for the same movie.

    This makes normal/Latest/UHD library copies share one Cine21 identity without
    needing a second crawl, and prevents an empty duplicate row from falling back
    to IMDb on Home, section widgets, or Info.
    """
    init_cine21_schema(conn)
    rating_key = str(rating_key or "").strip()
    movie_id = str(cine21_movie_id or "").strip()
    if not rating_key or not movie_id:
        return 0
    meta = meta or _item_metadata(conn, rating_key) or {}
    if not meta:
        return 0
    now = str(now if now is not None else int(time.time()))
    candidates = _candidate_duplicate_items(conn, meta)
    count = 0
    for cand in candidates:
        try:
            dup_key = str(cand.get("rating_key", "") or "").strip()
            if not dup_key:
                continue
            existing = conn.execute("""
                SELECT COALESCE(cine21_movie_id,''), COALESCE(match_status,''), critic_rating, audience_rating
                FROM cine21_matches
                WHERE rating_key=?
                LIMIT 1
            """, (dup_key,)).fetchone()
            if existing:
                ex_movie = str(existing[0] or "").strip()
                ex_status = str(existing[1] or "").strip()
                ex_has_score = existing[2] is not None or existing[3] is not None
                if ex_status == "MATCHED" and ex_has_score and ex_movie and ex_movie != movie_id:
                    _log("duplicate_propagate_skip_conflict src=%s dup=%s existing_movie_id=%s new_movie_id=%s title=%s year=%s" % (
                        rating_key, dup_key, ex_movie, movie_id, cand.get("title", ""), cand.get("year", "")
                    ))
                    continue
            conn.execute("""
                INSERT INTO cine21_matches(
                    rating_key,cine21_movie_id,match_status,match_type,match_score,pkm_quality_status,
                    pkm_title,pkm_original_title,pkm_year,pkm_section_id,pkm_media_file,cine21_title,
                    critic_rating,audience_rating,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(rating_key) DO UPDATE SET
                    cine21_movie_id=excluded.cine21_movie_id,
                    match_status='MATCHED',
                    match_type=excluded.match_type,
                    match_score=excluded.match_score,
                    pkm_quality_status=excluded.pkm_quality_status,
                    pkm_title=excluded.pkm_title,
                    pkm_original_title=excluded.pkm_original_title,
                    pkm_year=excluded.pkm_year,
                    pkm_section_id=excluded.pkm_section_id,
                    cine21_title=excluded.cine21_title,
                    critic_rating=excluded.critic_rating,
                    audience_rating=excluded.audience_rating,
                    updated_at=excluded.updated_at
            """, (
                dup_key, movie_id, "MATCHED", str(cand.get("reason", "DUPLICATE_TITLE_YEAR") or "DUPLICATE_TITLE_YEAR"), 1.0, "PKM_METADATA_OK",
                cand.get("title", ""), cand.get("original_title", ""), str(cand.get("year", "") or ""), cand.get("section_id", ""), "",
                cine21_title or meta.get("title", ""), critic, audience, now,
            ))
            count += 1
        except Exception:
            _log("duplicate_propagate_item_failed src=%s dup=%s %s" % (rating_key, cand.get("rating_key", ""), traceback.format_exc()), xbmc.LOGWARNING if xbmc else None)
    if count:
        conn.commit()
        _log("duplicate_propagate_done src=%s movie_id=%s count=%s title=%s year=%s tmdb=%s" % (
            rating_key, movie_id, count, meta.get("title", ""), meta.get("year", ""), meta.get("tmdb_id", "")
        ))
    return count


def backfill_duplicate_matches_from_existing(conn, limit=200, abort_cb=None):
    """Backfill duplicate Plex keys from existing MATCHED rows, DB-only."""
    init_cine21_schema(conn)
    try:
        if _cine21_abort_requested(abort_cb):
            _log("duplicate_backfill_abort reason=playback_open_or_active stage=before_select", xbmc.LOGINFO if xbmc else None)
            return 0
        rows = conn.execute("""
            SELECT cm.rating_key, cm.cine21_movie_id, cm.critic_rating, cm.audience_rating, COALESCE(cm.cine21_title, cm.pkm_title, '')
            FROM cine21_matches cm
            LEFT JOIN items i ON i.rating_key=cm.rating_key
            WHERE cm.match_status='MATCHED'
              AND COALESCE(cm.cine21_movie_id,'')<>''
              AND (cm.critic_rating IS NOT NULL OR cm.audience_rating IS NOT NULL)
            ORDER BY COALESCE(i.added_at,0) DESC, COALESCE(i.synced_at,0) DESC, COALESCE(cm.updated_at,0) DESC
            LIMIT ?
        """, (max(1, int(limit or 1)),)).fetchall()
        total = 0
        for rk, mid, critic, audience, ctitle in rows:
            if _cine21_abort_requested(abort_cb):
                _log("duplicate_backfill_abort reason=playback_open_or_active stage=loop source_rows=%s propagated=%s" % (len(rows), total), xbmc.LOGINFO if xbmc else None)
                break
            total += propagate_cine21_match_to_duplicate_items(conn, rk, mid, critic, audience, cine21_title=ctitle)
        if total:
            _log("duplicate_backfill_done source_rows=%s propagated=%s" % (len(rows), total))
        return total
    except Exception:
        _log("duplicate_backfill_failed %s" % traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
        return 0


def fetch_and_save_rating(conn, rating_key, cine21_movie_id, timeout=8):
    """Fetch a Cine21 detail page and save to existing PKM Cine21 schema."""
    init_cine21_schema(conn)
    rating_key = str(rating_key or "").strip()
    movie_id = str(cine21_movie_id or "").strip()
    now = int(time.time())
    meta = _item_metadata(conn, rating_key)
    if not meta:
        raise ValueError("rating_key not found in items: %s" % rating_key)
    try:
        html, url = _fetch_cine21_html(movie_id, timeout=timeout)
        _log("manual_fetch_page rating_key=%s movie_id=%s url=%s html_len=%s" % (rating_key, movie_id, url, len(html or "")))
        parsed = parse_cine21_movie_page(html)
        critic = parsed.get("critic_rating")
        audience = parsed.get("audience_rating")
        reviews = parsed.get("expert_reviews") or []
        expert_count = int(parsed.get("expert_count") or len(reviews) or 0)
        if critic is None and audience is None:
            raise ValueError("rating not found in Cine21 page movie_id=%s" % movie_id)
        # Master Cine21 table keyed by movie_id. UI does not read this directly for items,
        # but keeping it filled lets future full-match rebuilds reuse the rating.
        conn.execute("""
            INSERT OR REPLACE INTO cine21_ratings(movie_id,title,critic_rating,audience_rating,image,updated_at)
            VALUES(?,?,?,?,?,?)
        """, (movie_id, meta.get("title", ""), critic, audience, "", str(now)))
        # Per item match table. Home/Info UI reads Cine21 score from here.
        conn.execute("""
            INSERT INTO cine21_matches(
                rating_key,cine21_movie_id,match_status,match_type,match_score,pkm_quality_status,
                pkm_title,pkm_original_title,pkm_year,pkm_section_id,pkm_media_file,cine21_title,
                critic_rating,audience_rating,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(rating_key) DO UPDATE SET
                cine21_movie_id=excluded.cine21_movie_id,
                match_status='MATCHED',
                match_type=excluded.match_type,
                match_score=excluded.match_score,
                pkm_title=excluded.pkm_title,
                pkm_original_title=excluded.pkm_original_title,
                pkm_year=excluded.pkm_year,
                pkm_section_id=excluded.pkm_section_id,
                cine21_title=excluded.cine21_title,
                critic_rating=excluded.critic_rating,
                audience_rating=excluded.audience_rating,
                updated_at=excluded.updated_at
        """, (
            rating_key, movie_id, 'MATCHED', 'EXACT_WEB_MATCH', 1.0, 'PKM_METADATA_OK',
            meta.get("title", ""), meta.get("original_title", ""), str(meta.get("year", "") or ""),
            meta.get("section_id", ""), "", meta.get("title", ""), critic, audience, str(now)
        ))
        # v931: normal/latest/UHD library copies of the same title/year or same TMDb id
        # must share the confirmed Cine21 match immediately.
        propagate_cine21_match_to_duplicate_items(conn, rating_key, movie_id, critic, audience, meta=meta, cine21_title=meta.get("title", ""), now=now)
        conn.execute("DELETE FROM cine21_expert_reviews WHERE rating_key=?", (rating_key,))
        for idx, review in enumerate(reviews, 1):
            conn.execute("""
                INSERT OR REPLACE INTO cine21_expert_reviews (
                    rating_key, cine21_movie_id, sort_order, critic_name,
                    critic_score, critic_comment, fetched_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                rating_key, movie_id, idx,
                str(review.get("critic_name") or ""),
                review.get("critic_score"),
                str(review.get("critic_comment") or ""),
                now,
            ))
        conn.commit()
        _log("manual_fetch_ok rating_key=%s movie_id=%s critic=%s audience=%s experts=%s" % (rating_key, movie_id, critic, audience, len(reviews)))
        return {"status":"ok", "rating_key":rating_key, "cine21_movie_id":movie_id, "critic_rating":critic, "audience_rating":audience, "expert_count":expert_count, "expert_reviews":reviews, "url":url}
    except Exception as exc:
        error = "%s" % exc
        conn.execute("""
            INSERT INTO cine21_matches(
                rating_key,cine21_movie_id,match_status,match_type,match_score,pkm_quality_status,
                pkm_title,pkm_original_title,pkm_year,pkm_section_id,pkm_media_file,cine21_title,
                critic_rating,audience_rating,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(rating_key) DO UPDATE SET
                cine21_movie_id=excluded.cine21_movie_id,
                match_status='MATCH_ERROR',
                match_type=excluded.match_type,
                updated_at=excluded.updated_at
        """, (
            rating_key, movie_id, 'MATCH_ERROR', error[:500], 0.0, '',
            meta.get("title", ""), meta.get("original_title", ""), str(meta.get("year", "") or ""),
            meta.get("section_id", ""), "", "", None, None, str(now)
        ))
        conn.commit()
        _log("manual_fetch_error rating_key=%s movie_id=%s error=%s" % (rating_key, movie_id, error), xbmc.LOGWARNING if xbmc else None)
        raise


def _fetch_candidates_with_movie_id(conn, limit=5):
    init_cine21_schema(conn)
    limit = max(1, int(limit or 1))
    return conn.execute("""
        SELECT cm.rating_key, cm.cine21_movie_id
        FROM cine21_matches cm
        LEFT JOIN items i ON i.rating_key=cm.rating_key
        WHERE COALESCE(cm.cine21_movie_id, '') <> ''
          AND (COALESCE(cm.match_status, '') IN ('', 'NEED_FETCH', 'MATCH_ERROR')
               OR (cm.match_status='MATCHED' AND cm.critic_rating IS NULL AND cm.audience_rating IS NULL))
        ORDER BY CASE WHEN COALESCE(cm.match_status,'')='NEED_FETCH' THEN 0 ELSE 1 END,
                 COALESCE(i.added_at,0) DESC, COALESCE(i.synced_at,0) DESC, COALESCE(cm.updated_at,0) DESC
        LIMIT ?
    """, (limit,)).fetchall()

def fetch_cine21_ratings_for_candidates(conn, limit=5, timeout=6, progress_cb=None, total=None, base_done=0, abort_cb=None):
    """Fetch ratings for rows with trusted movie_id; already ok rows are skipped."""
    stats = {"candidates": 0, "fetched_ok": 0, "fetched_error": 0}
    rows = _fetch_candidates_with_movie_id(conn, limit=limit)
    stats["candidates"] = len(rows)
    done = 0
    for rating_key, movie_id in rows:
        if _cine21_abort_requested(abort_cb):
            stats["aborted"] = 1
            _log("auto_fetch_abort reason=player_or_service_active done=%s candidates=%s" % (done, stats.get("candidates", 0)), xbmc.LOGINFO if xbmc else None)
            break
        done += 1
        try:
            result = fetch_and_save_rating(conn, rating_key, movie_id, timeout=timeout)
            if result.get("status") == "ok":
                stats["fetched_ok"] += 1
            else:
                stats["fetched_error"] += 1
        except Exception:
            stats["fetched_error"] += 1
            _log("auto_fetch_item_failed rating_key=%s movie_id=%s %s" % (rating_key, movie_id, traceback.format_exc()), xbmc.LOGWARNING if xbmc else None)
        try:
            if progress_cb:
                progress_cb(dict(stats), int(base_done or 0) + done, int(total or limit or 0), str(rating_key or ""))
        except Exception:
            pass
    return stats

def auto_update_cine21_cache(conn, seed_limit=0, fetch_limit=3, timeout=6, mark_missing_limit=0, match_limit=0, abort_cb=None):
    """Build Cine21 DB candidates, safely match movie_id, and fetch ratings.

    Search matching is conservative: only exact normalized title + year matches
    are accepted.  Large full-library runs should use the settings menu with
    progress; background runs should pass small limits.
    """
    stats = {
        "seeded": 0,
        "need_movie_id": 0,
        "matched": 0,
        "match_checked": 0,
        "match_no_match": 0,
        "match_ambiguous": 0,
        "match_error": 0,
        "fetched_ok": 0,
        "fetched_error": 0,
        "candidates": 0,
    }
    try:
        if _cine21_abort_requested(abort_cb):
            stats["aborted"] = 1
            _log("auto_update_skip reason=player_or_service_active stage=before_seed", xbmc.LOGINFO if xbmc else None)
            return stats
        stats["seeded"] = build_pending_seed_rows(conn, limit=seed_limit)
        # v931: if a duplicate Plex item was created for a movie that already has
        # a Cine21 match, copy it DB-only before doing any new web work.
        stats["duplicate_backfilled_before"] = backfill_duplicate_matches_from_existing(conn, limit=200, abort_cb=abort_cb)
        if _cine21_abort_requested(abort_cb):
            stats["aborted"] = 1
            _log("auto_update_abort reason=player_or_service_active stage=after_seed", xbmc.LOGINFO if xbmc else None)
            return stats
        if mark_missing_limit:
            stats["need_movie_id"] = mark_missing_movie_id(conn, limit=mark_missing_limit)
        if match_limit:
            mstats = match_cine21_movie_ids(conn, limit=match_limit, timeout=timeout, abort_cb=abort_cb)
            stats["match_checked"] = int(mstats.get("checked", 0) or 0)
            stats["matched"] = int(mstats.get("matched", 0) or 0)
            stats["match_no_match"] = int(mstats.get("no_match", 0) or 0)
            stats["match_ambiguous"] = int(mstats.get("ambiguous", 0) or 0)
            stats["match_error"] = int(mstats.get("error", 0) or 0)
        if _cine21_abort_requested(abort_cb):
            stats["aborted"] = 1
            _log("auto_update_abort reason=player_or_service_active stage=before_fetch", xbmc.LOGINFO if xbmc else None)
            return stats
        fstats = fetch_cine21_ratings_for_candidates(conn, limit=fetch_limit, timeout=timeout, abort_cb=abort_cb)
        stats["candidates"] = int(fstats.get("candidates", 0) or 0)
        stats["fetched_ok"] = int(fstats.get("fetched_ok", 0) or 0)
        stats["fetched_error"] = int(fstats.get("fetched_error", 0) or 0)
        stats["duplicate_backfilled_after"] = backfill_duplicate_matches_from_existing(conn, limit=200, abort_cb=abort_cb)
        try:
            sample_rows = conn.execute("""
                SELECT cm.rating_key, COALESCE(i.title, cm.pkm_title, ''), COALESCE(cm.match_status,''),
                       COALESCE(cm.cine21_movie_id,''), COALESCE(cm.critic_rating,''), COALESCE(cm.audience_rating,'')
                FROM cine21_matches cm
                LEFT JOIN items i ON i.rating_key=cm.rating_key
                WHERE COALESCE(i.title, cm.pkm_title, '') IN ('마이클') OR cm.rating_key IN ('9479791')
                ORDER BY cm.updated_at DESC
                LIMIT 3
            """).fetchall()
            for rr in sample_rows:
                _log("db_probe_after_update rating_key=%s title=%s status=%s movie_id=%s critic=%s audience=%s" % (
                    rr[0], rr[1], rr[2], rr[3], rr[4], rr[5]
                ))
        except Exception:
            pass
        _log("auto_update_done seeded=%s need_movie_id=%s match_checked=%s matched=%s candidates=%s ok=%s error=%s" % (
            stats["seeded"], stats["need_movie_id"], stats["match_checked"], stats["matched"], stats["candidates"], stats["fetched_ok"], stats["fetched_error"]
        ))
    except Exception:
        stats["error"] = traceback.format_exc()
        _log("auto_update_failed %s" % stats["error"], xbmc.LOGWARNING if xbmc else None)
    return stats

