# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Phone entry for the YouTube Data API key (R79).

While the PKM YouTube settings panel shows "휴대폰으로 입력", a tiny HTTP page
is served on the Shield's LAN address.  The TV shows a QR code for
http://<lan-ip>:<port>/<token>; the phone opens it, pastes the key and taps
저장.  The key is checked with the Data API before it is stored, and the
result is shown on both the phone and the TV.

Only the random token path answers; everything else is 404.  The server
stops when the panel leaves phone mode, when the window closes, or after
IDLE_LIMIT_SEC.
"""

import os
import random
import string
import threading
import time
import traceback

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import parse_qs
except ImportError:  # pragma: no cover - Kodi 18
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import parse_qs

import xbmc

PREFERRED_PORTS = (8738, 8739, 8748, 0)
IDLE_LIMIT_SEC = 15 * 60
KEY_CHARS = set(string.ascii_letters + string.digits + "-_")


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Plex KM] YT KEYSERVER %s" % msg, level)
    except Exception:
        pass


def clean_key(raw):
    key = "".join(ch for ch in str(raw or "").strip() if not ch.isspace())
    if not key:
        return "", "키가 비어 있습니다"
    if len(key) < 30 or len(key) > 60 or any(ch not in KEY_CHARS for ch in key):
        return "", "API 키 형식이 아닙니다 (보통 AIza로 시작하는 39자)"
    return key, ""


def mask_key(key):
    key = str(key or "")
    if len(key) <= 12:
        return key
    return key[:6] + "…" + key[-4:]


PAGE = """<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PKM · YouTube API 키</title>
<style>
:root{color-scheme:dark}
body{margin:0;background:#0f0f0f;color:#f1f1f1;font:16px/1.5 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}
main{max-width:520px;margin:0 auto;padding:28px 18px 40px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:20px}
.dot{width:30px;height:21px;border-radius:6px;background:#ff0033;display:inline-flex;align-items:center;justify-content:center}
.dot:after{content:"";border-left:9px solid #fff;border-top:6px solid transparent;border-bottom:6px solid transparent;margin-left:2px}
p{color:#aaa;margin:14px 0}
label{display:block;margin:22px 0 8px;color:#aaa;font-size:14px}
input{box-sizing:border-box;width:100%%;padding:14px;border-radius:12px;border:1px solid #3f3f3f;background:#212121;color:#fff;font:16px ui-monospace,Menlo,monospace}
input:focus{outline:2px solid #3ea6ff;border-color:transparent}
button{margin-top:16px;width:100%%;padding:14px;border:0;border-radius:24px;background:#f1f1f1;color:#0f0f0f;font-weight:700;font-size:16px}
.msg{margin-top:20px;padding:14px;border-radius:12px;background:#212121}
.ok{border-left:4px solid #2ba640}.bad{border-left:4px solid #ff4e45}
ol{color:#aaa;padding-left:20px;font-size:14px}
a{color:#3ea6ff}
</style></head><body><main>
<div class="brand"><span class="dot"></span>PKM YouTube</div>
<p>YouTube Data API v3 키를 붙여넣고 저장하면 쉴드에 바로 적용됩니다.</p>
%(msg)s
<form method="post" autocomplete="off">
<label for="k">API 키</label>
<input id="k" name="key" placeholder="AIza…" autocapitalize="off" autocorrect="off" spellcheck="false" value="">
<button type="submit">저장</button>
</form>
<p style="margin-top:28px">키 발급 방법</p>
<ol>
<li><a href="https://console.cloud.google.com/apis/library/youtube.googleapis.com">Google Cloud Console</a>에서 프로젝트를 만들고 <b>YouTube Data API v3</b>를 사용 설정</li>
<li>사용자 인증 정보 → 사용자 인증 정보 만들기 → <b>API 키</b></li>
<li>만들어진 키를 복사해 위에 붙여넣기</li>
</ol>
</main></body></html>"""


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class KeyServer(object):
    """on_key(key) -> (ok, message); called from the HTTP thread."""

    def __init__(self, on_key, on_event=None):
        self.on_key = on_key
        self.on_event = on_event or (lambda kind, text: None)
        self.token = "".join(random.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(6))
        self.ip = ""
        self.port = 0
        self.url = ""
        self.httpd = None
        self.thread = None
        self.last_hit = time.time()
        self._stop = threading.Event()

    # -------------------------------------------------------------- start / stop

    def start(self):
        from resources.lib.pkm_token_import import _local_ip
        self.ip = _local_ip()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                return

            def _ok_path(self):
                return self.path.split("?", 1)[0].rstrip("/") == "/" + owner.token

            def _send(self, code, body):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if not self._ok_path():
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                owner.on_event("open", "휴대폰에서 페이지를 열었습니다")
                self._send(200, PAGE % {"msg": ""})

            def do_POST(self):
                if not self._ok_path():
                    self._send(404, "not found")
                    return
                owner.last_hit = time.time()
                try:
                    size = min(int(self.headers.get("Content-Length") or 0), 4096)
                    raw = self.rfile.read(size).decode("utf-8", "replace")
                    key = (parse_qs(raw).get("key") or [""])[0]
                except Exception:
                    key = ""
                key, err = clean_key(key)
                if err:
                    ok, msg = False, err
                else:
                    owner.on_event("checking", "휴대폰에서 받은 키를 확인하는 중…")
                    try:
                        ok, msg = owner.on_key(key)
                    except Exception:
                        _log("ON_KEY_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
                        ok, msg = False, "저장 중 오류가 발생했습니다"
                if not ok:
                    owner.on_event("error", msg)
                box = '<div class="msg %s">%s</div>' % ("ok" if ok else "bad",
                                                       (msg + " · TV 화면을 확인하세요") if ok else msg)
                self._send(200, PAGE % {"msg": box})

        last_err = None
        for port in PREFERRED_PORTS:
            try:
                self.httpd = _Server(("0.0.0.0", port), Handler)
                break
            except Exception as exc:
                last_err = exc
                self.httpd = None
        if self.httpd is None:
            _log("BIND_FAILED err=%s" % last_err, xbmc.LOGWARNING)
            return False
        self.port = self.httpd.server_address[1]
        self.url = "http://%s:%d/%s" % (self.ip, self.port, self.token)
        self.thread = threading.Thread(target=self._serve, name="PKMYTKeyServer")
        self.thread.daemon = True
        self.thread.start()
        _log("STARTED ip=%s port=%d" % (self.ip, self.port))
        return True

    def _serve(self):
        httpd = self.httpd
        try:
            httpd.timeout = 1.0
            while not self._stop.is_set():
                httpd.handle_request()
                if time.time() - self.last_hit > IDLE_LIMIT_SEC:
                    _log("IDLE_STOP")
                    self.on_event("idle", "시간이 지나 휴대폰 입력을 멈췄습니다. 다시 선택하세요")
                    break
        except Exception:
            _log("SERVE_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        finally:
            try:
                httpd.server_close()
            except Exception:
                pass

    def stop(self):
        self._stop.set()
        _log("STOP")

    @property
    def running(self):
        return bool(self.thread and self.thread.is_alive() and not self._stop.is_set())


def write_qr(text, path):
    try:
        from resources.lib.pkm_token_import import _write_qr_png
        if os.path.exists(path):
            os.remove(path)
        return _write_qr_png(text, path, scale=10, border=3)
    except Exception:
        _log("QR_FAILED %s" % traceback.format_exc().replace("\n", " | "), xbmc.LOGWARNING)
        return False
