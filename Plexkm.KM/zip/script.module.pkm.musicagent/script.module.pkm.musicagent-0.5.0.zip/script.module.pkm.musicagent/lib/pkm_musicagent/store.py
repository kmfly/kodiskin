# -*- coding: utf-8 -*-
"""색인 저장, 변경분 갱신, 백그라운드 스캔, 수정 기록.

Kodi 없이 동작한다. 폴더 읽기(listdir)·파일 읽기(read_text)·영상 정보(probe)는 호출하는 쪽이 넘긴다
(Kodi 에서는 xbmcvfs, 시험에서는 일반 파일 시스템). 원본이 느린 rclone 마운트라
'목록 읽기, 보조 파일 읽기, 영상 길이 읽기'만 변경분에 대해 하고, 이름 해석은 매번 전체를 다시 한다(빠름).
"""
import json
import os
import threading
import time

from . import parser as P

_TEXT_NAMES = ("info.json", "show.yaml")
_TEXT_EXT = (".nfo",)


def _atomic_write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def _load(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def walk(listdir, root=""):
    """listdir(상대경로) -> [(이름, 폴더인가, 크기, 수정시각)]. 상대경로 목록과 파일 정보를 돌려준다."""
    out = {}
    stack = [root]
    while stack:
        cur = stack.pop()
        try:
            entries = listdir(cur)
        except Exception:
            continue
        for name, is_dir, size, mtime in entries:
            rel = (cur + "/" + name) if cur else name
            if is_dir:
                stack.append(rel)
            else:
                out[rel] = (int(size or 0), int(mtime or 0))
    return out


def _ikey(it):
    return P.norm_key(it.get("artist", "")) + "|" + P.norm_key(it.get("title", ""))


def _errors():
    try:
        from . import lookup as _L
        return _L.ERRORS[0]
    except Exception:
        return 0


def _compact(c):
    keep = ("source", "artist", "title", "album", "year", "cover", "url", "genre", "score")
    return {k: c[k] for k in keep if c.get(k) not in (None, "", 0)}


class IndexStore(object):
    """소스(=등록한 영상·음악 폴더) 하나당 색인 파일 하나. 수정 기록은 모든 소스가 공유한다."""

    def __init__(self, data_dir):
        self.dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.over_path = os.path.join(data_dir, "musicagent_overrides.json")
        self.cache_path = os.path.join(data_dir, "musicagent_lookup_cache.json")
        self.overrides = _load(self.over_path, {})   # {소스id|경로: {artist,title,...}}
        self._lock = threading.Lock()
        self._threads = {}
        self.progress = {}

    # ------------------------------------------------------------ 파일 위치
    def _idx_path(self, source_id):
        import hashlib, re
        masked = re.sub(r"(?<=://)[^/@]*@", "", source_id)   # 접속 계정·비밀번호는 파일 이름에 넣지 않는다
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in masked)[:80]
        if masked != source_id:
            safe += "_" + hashlib.md5(source_id.encode("utf-8")).hexdigest()[:8]
        new = os.path.join(self.dir, "musicagent_index_%s.json" % safe)
        old = os.path.join(self.dir, "musicagent_index_%s.json" % "".join(c if c.isalnum() or c in "-_" else "_" for c in source_id))
        if old != new and os.path.exists(old) and not os.path.exists(new):
            try:
                os.replace(old, new)    # 예전 이름(계정 포함)의 색인을 새 이름으로 옮긴다
            except Exception:
                pass
        return new

    # ------------------------------------------------------------ 수정 기록
    def set_override(self, source_id, path, fields):
        """사용자가 직접 고친 값(artist, title, year, album, poster ...). 경로와 이름 키 둘 다로 찾는다."""
        with self._lock:
            k = source_id + "|" + path
            cur = self.overrides.get(k, {})
            cur.update({a: b for a, b in fields.items() if b not in (None, "")})
            cur["_key"] = P.norm_key(cur.get("artist", "")) + "|" + P.norm_key(cur.get("title", ""))
            cur["_name"] = os.path.basename(path)
            self.overrides[k] = cur
            _atomic_write(self.over_path, self.overrides)

    def clear_override(self, source_id, path):
        with self._lock:
            if self.overrides.pop(source_id + "|" + path, None) is not None:
                _atomic_write(self.over_path, self.overrides)

    def _apply_overrides(self, source_id, items, old_items=None):
        """경로가 같으면 그 항목에, 파일이 옮겨졌으면(같은 파일 이름) 이름으로 찾아 적용한다."""
        by_name = {}
        for it in items:
            by_name.setdefault(os.path.basename(it["path"]), []).append(it)
        moved = False
        for k in list(self.overrides):
            if not k.startswith(source_id + "|"):
                continue
            path = k.split("|", 1)[1]
            ov = self.overrides[k]
            target = None
            for it in items:
                if it["path"] == path:
                    target = it
                    break
            if target is None:
                cand = by_name.get(ov.get("_name", ""), [])
                if len(cand) == 1:
                    target = cand[0]
                    self.overrides[source_id + "|" + target["path"]] = self.overrides.pop(k)
                    moved = True
            if target is not None:
                for f, v in ov.items():
                    if not f.startswith("_"):
                        target[f] = v
                target["edited"] = True
                target["ok"] = True
                target["key"] = P.norm_key(target.get("artist", "")) + "|" + P.norm_key(target.get("title", ""))
        if moved:
            _atomic_write(self.over_path, self.overrides)

    # ------------------------------------------------------- 온라인 정보
    def _apply_meta(self, items, cache):
        n = 0
        for it in items:
            if it["kind"] not in ("mv", "broadcast") or not it.get("artist") or it.get("edited"):
                continue
            ent = cache.get(_ikey(it))
            if ent and ent.get("hit"):
                it["meta"] = ent["hit"]
                n += 1
        return n

    def _write_meta(self, source_id, cache):
        """스캔이 같은 시간에 색인을 바꿨을 수 있으니, 매번 최신 색인을 다시 읽어 meta 만 붙여 쓴다."""
        with self._lock:
            cur = self.load(source_id)
            n = self._apply_meta(cur.get("items", []), cache)
            _atomic_write(self._idx_path(source_id), cur)
            return n

    def candidates_for(self, artist, title):
        """서브메뉴 '다른 결과 고르기'용: 저장해 둔 후보(앞 3개)."""
        ent = _load(self.cache_path, {}).get(P.norm_key(artist) + "|" + P.norm_key(title)) or {}
        return ent.get("cands", [])

    def enrich(self, source_id, lookup, accept=0.8, miss_days=30, progress=None, cancel=None):
        """아직 조회하지 않은 아티스트·제목만 온라인에서 찾아 캐시에 저장하고, 색인 항목에 meta 로 붙인다.
        lookup(artist, title) -> 점수순 후보 목록. 이어받기: 25건마다 캐시를 저장한다."""
        t0 = time.time()
        idx = self.load(source_id)
        cache = _load(self.cache_path, {})
        todo, seen = [], set()
        for it in idx.get("items", []):
            if it["kind"] not in ("mv", "broadcast") or not (it.get("artist") or it.get("title")):
                continue
            k = _ikey(it)
            if k in seen:
                continue
            seen.add(k)
            ent = cache.get(k)
            if ent and (ent.get("hit") or time.time() - ent.get("at", 0) < miss_days * 86400):
                continue
            todo.append((k, it.get("artist", ""), it.get("title", "")))
        hits = failed = fails = 0
        stopped = False
        for n, (k, a, t) in enumerate(todo, 1):
            if cancel and cancel():
                break
            err0 = _errors()
            try:
                cands = lookup(a, t)
            except Exception:
                cands = []
                fails += 1
            best = cands[0] if cands and cands[0].get("score", 0) >= accept else None
            if best is None and _errors() > err0:
                # 호출 실패가 섞인 '없음'은 저장하지 않는다(다음 실행에서 다시 시도). 연속 실패면 멈춘다.
                fails += 1
                failed += 1
                if fails >= 5:
                    stopped = True
                    break
                continue
            fails = 0
            cache[k] = {"hit": _compact(best) if best else None, "at": int(time.time()),
                        "cands": [_compact(c) for c in cands[:3]]}
            hits += 1 if best else 0
            if progress:
                progress(n, len(todo))
            if n % 25 == 0:
                _atomic_write(self.cache_path, cache)
            if n % 100 == 0:
                self._write_meta(source_id, cache)      # 자켓이 찾는 대로 화면에 나타나게
        _atomic_write(self.cache_path, cache)
        applied = self._write_meta(source_id, cache)
        return {"looked": len(todo), "hits": hits, "failed": failed, "stopped": stopped, "applied": applied,
                "seconds": round(time.time() - t0, 1)}

    def enrich_async(self, source_id, lookup, **kw):
        key = source_id + ":enrich"
        th = self._threads.get(key)
        if th and th.is_alive():
            return False
        self.progress[key] = {"state": "running", "done": 0, "total": 0}

        def prog(d, t):
            self.progress[key].update(done=d, total=t)

        def run():
            try:
                self.progress[key] = {"state": "done", "result": self.enrich(source_id, lookup, progress=prog, **kw)}
            except Exception as e:
                self.progress[key] = {"state": "error", "error": str(e)}
        th = threading.Thread(target=run, name="pkm-musicagent-enrich", daemon=True)
        self._threads[key] = th
        th.start()
        return True

    # --------------------------------------------------------------- 읽기
    def load(self, source_id):
        """화면은 이 함수로 색인만 읽는다(폴더를 다시 읽지 않는다).
        이름 읽기 규칙(parser.PARSER_V)이 바뀐 색인은 저장된 파일 목록으로 이름만 다시 해석해 저장한다."""
        idx = _load(self._idx_path(source_id), {"items": [], "stats": {}, "files": {}, "scanned_at": 0})
        if idx.get("items") and idx.get("files") and idx.get("parser_v") != P.PARSER_V:
            idx = self._reparse(source_id, idx)
        return idx

    def _reparse(self, source_id, old):
        try:
            with self._lock:
                cur = _load(self._idx_path(source_id), old)
                if cur.get("parser_v") == P.PARSER_V:
                    return cur
                kinds = {}
                for it in cur.get("items", []):
                    kinds[it.get("kind")] = kinds.get(it.get("kind"), 0) + 1
                dk = cur.get("default_kind") or (max(kinds, key=kinds.get) if kinds else None)
                files = cur.get("files", {})
                idx = P.build_index(list(files), cur.get("texts", {}), kinds=cur.get("kinds") or None,
                                    template=cur.get("template") or None, default_kind=dk)
                meta = dict((it.get("path"), it.get("meta")) for it in cur.get("items", []) if it.get("meta"))
                for it in idx["items"]:
                    pr = files.get(it["path"], {}).get("probe")
                    if pr:
                        it.update({k: v for k, v in pr.items() if v})
                    if meta.get(it["path"]):
                        it["meta"] = meta[it["path"]]
                self._apply_overrides(source_id, idx["items"])
                cur.update(items=idx["items"], stats=idx["stats"], parser_v=P.PARSER_V, default_kind=dk)
                _atomic_write(self._idx_path(source_id), cur)
                return cur
        except Exception:
            return old

    # --------------------------------------------------------------- 스캔
    def scan(self, source_id, listdir, read_text=None, probe=None, kinds=None, template=None,
             progress=None, cancel=None, default_kind=None):
        """변경분만 갱신한다. read_text(경로)->str, probe(경로)->{'duration':초,'width':..,'height':..}.
        반환: {'added': n, 'removed': n, 'changed': n, 'total': n, 'seconds': s}"""
        t0 = time.time()
        old = self.load(source_id)
        old_files = old.get("files", {})
        now_files = walk(listdir)
        if cancel and cancel():
            return {"cancelled": True}
        added = [p for p in now_files if p not in old_files]
        removed = [p for p in old_files if p not in now_files]
        changed = [p for p in now_files if p in old_files and
                   (old_files[p].get("size"), old_files[p].get("mtime")) != now_files[p]]
        todo = added + changed
        files = {}
        for p, (size, mtime) in now_files.items():
            files[p] = old_files.get(p, {}) if p not in todo else {}
            files[p]["size"], files[p]["mtime"] = size, mtime
        texts = dict(old.get("texts", {}))
        for p in removed:
            texts.pop(p, None)
        n = 0
        for p in todo:
            if cancel and cancel():
                return {"cancelled": True}
            base = p.rsplit("/", 1)[-1]
            if read_text and (base in _TEXT_NAMES or base.lower().endswith(_TEXT_EXT)):
                try:
                    texts[p] = read_text(p) or ""
                except Exception:
                    texts[p] = ""
            elif probe and P.is_video(base):
                try:
                    files[p]["probe"] = probe(p) or {}
                except Exception:
                    files[p]["probe"] = {}
            n += 1
            if progress and n % 50 == 0:
                progress(n, len(todo))
        idx = P.build_index(list(now_files), texts, kinds=kinds, template=template, default_kind=default_kind)
        for it in idx["items"]:
            pr = files.get(it["path"], {}).get("probe")
            if pr:
                it.update({k: v for k, v in pr.items() if v})
        self._apply_overrides(source_id, idx["items"])
        self._apply_meta(idx["items"], _load(self.cache_path, {}))
        out = {"items": idx["items"], "stats": idx["stats"], "files": files, "texts": texts,
               "scanned_at": int(time.time()), "kinds": kinds or {}, "template": template or "",
               "parser_v": P.PARSER_V, "default_kind": default_kind}
        with self._lock:
            _atomic_write(self._idx_path(source_id), out)
        return {"added": len(added), "removed": len(removed), "changed": len(changed),
                "total": len(idx["items"]), "seconds": round(time.time() - t0, 2)}

    def scan_async(self, source_id, *args, **kw):
        """백그라운드 스레드로 스캔. 이미 돌고 있으면 새로 시작하지 않는다. 진행은 self.progress[source_id]."""
        th = self._threads.get(source_id)
        if th and th.is_alive():
            return False
        self.progress[source_id] = {"state": "running", "done": 0, "total": 0}
        cancel = kw.pop("cancel", None)

        def prog(d, t):
            self.progress[source_id].update(done=d, total=t)

        def run():
            try:
                res = self.scan(source_id, *args, progress=prog, cancel=cancel, **kw)
                self.progress[source_id] = {"state": "done", "result": res}
            except Exception as e:  # 화면이 멈추지 않게 오류는 상태로만 남긴다
                self.progress[source_id] = {"state": "error", "error": str(e)}
        th = threading.Thread(target=run, name="pkm-musicagent-scan", daemon=True)
        self._threads[source_id] = th
        th.start()
        return True
