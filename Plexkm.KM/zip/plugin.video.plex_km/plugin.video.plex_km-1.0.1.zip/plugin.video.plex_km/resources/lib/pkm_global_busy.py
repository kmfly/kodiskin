# -*- coding: utf-8 -*-
"""One process-wide delayed busy broker for PKM foreground transitions.

v1885 keeps the global policy and ownership in one module, but deliberately
renders the spinner inside the currently active PKM window instead of opening a
second full-screen WindowXMLDialog.  Kodi 21 on Windows composited that
transparent dialog as a pale/white surface during sidebar transitions.

Runtime contract:
- one daemon scheduler for every PKM foreground operation;
- one common 350 ms threshold;
- independent ownership tokens for overlapping operations;
- the already completed active screen remains untouched underneath;
- active PKM windows read PlexKM.GlobalBusy.* and draw only the Apple ring;
- Home/Search onAction/onClick consult this same broker to block input while the
  spinner is visible;
- feature code never creates a spinner thread or chooses a local delay.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time
import uuid

import xbmc
import xbmcgui

_LOCK = threading.RLock()
_COND = threading.Condition(_LOCK)
_TOKENS = {}
_WORKER = None
_PREFIX = "PlexKM.GlobalBusy"
DEFAULT_DELAY_MS = 350
MAX_TOKEN_AGE_MS = 5 * 60 * 1000
_BLOCKED_ACTION_IDS = frozenset((1, 2, 3, 4, 5, 6, 7, 10, 11, 92, 100, 117))


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[plugin.video.plex_km] %s" % message, level)
    except Exception:
        pass


def _win():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return None


def _set(key, value):
    try:
        win = _win()
        if win is not None:
            win.setProperty(key, str(value or ""))
    except Exception:
        pass


def _clear(key):
    try:
        win = _win()
        if win is not None:
            win.clearProperty(key)
    except Exception:
        pass


def _resolved_size(size=None):
    value = str(size or "").strip().lower()
    if value in ("small", "medium", "large"):
        return value
    try:
        from resources.lib import pkm_spinner
        return pkm_spinner.get_size()
    except Exception:
        return "medium"


def _visible_records_locked():
    return [r for r in _TOKENS.values() if r.get("visible")]


def _is_visible_locked():
    return bool(_visible_records_locked())


def _publish_locked():
    visible = _visible_records_locked()
    _set(_PREFIX + ".Count", str(len(_TOKENS)))
    # v1885: there is intentionally no external dialog.  Clear stale v1884
    # properties so the active-window spinner can never be hidden by an old
    # DialogActive flag left after a crash/restart.
    _clear(_PREFIX + ".DialogActive")
    _clear(_PREFIX + ".DialogReady")
    if visible:
        rec = sorted(visible, key=lambda x: float(x.get("started") or 0.0))[-1]
        _set(_PREFIX + ".Visible", "1")
        _set(_PREFIX + ".Reason", rec.get("reason") or "")
        _set(_PREFIX + ".Token", rec.get("token") or "")
        _set(_PREFIX + ".Size", rec.get("size") or "medium")
        _set(_PREFIX + ".Renderer", "active_window")
    else:
        for suffix in (".Visible", ".Reason", ".Token", ".Size", ".Renderer"):
            _clear(_PREFIX + suffix)


def _ensure_worker_locked():
    global _WORKER
    if _WORKER is not None and _WORKER.is_alive():
        return
    _WORKER = threading.Thread(target=_broker_loop, name="PKMGlobalBusyBrokerV1885", daemon=True)
    _WORKER.start()


def _broker_loop():
    """Single scheduler; it only publishes state and never opens another GUI window."""
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        shown = []
        expired = []
        wait_seconds = 0.50
        with _COND:
            now = time.monotonic()
            changed = False
            next_due = None
            for token, rec in list(_TOKENS.items()):
                started = float(rec.get("started") or now)
                age_ms = int(max(0.0, now - started) * 1000.0)
                if age_ms >= MAX_TOKEN_AGE_MS:
                    expired.append((token, dict(rec), age_ms))
                    _TOKENS.pop(token, None)
                    changed = True
                    continue
                if rec.get("visible"):
                    continue
                due = started + (float(rec.get("delay_ms") or DEFAULT_DELAY_MS) / 1000.0)
                if due <= now:
                    rec["visible"] = True
                    shown.append(dict(rec))
                    changed = True
                elif next_due is None or due < next_due:
                    next_due = due
            if changed:
                _publish_locked()
            if next_due is not None:
                wait_seconds = max(0.01, min(0.50, next_due - time.monotonic()))
            elif not _TOKENS:
                wait_seconds = 1.00
            if not shown and not expired:
                _COND.wait(timeout=wait_seconds)

        for rec in shown:
            _log("GLOBAL_BUSY_SHOW_V1885 token=%s reason=%s delay_ms=%d scheduler=single renderer=active_window external_dialog=0 previous_surface_preserved=1" % (
                rec.get("token") or "", rec.get("reason") or "",
                int(rec.get("delay_ms") or DEFAULT_DELAY_MS)
            ))
        for token, rec, age_ms in expired:
            _log("GLOBAL_BUSY_EXPIRE_V1885 token=%s reason=%s age_ms=%d safety_only=1" % (
                token, rec.get("reason") or "", age_ms
            ), xbmc.LOGWARNING)


def begin(reason=""):
    """Register one foreground wait and return its ownership token."""
    token = "%s:%d:%s" % (str(reason or "busy"), int(time.time() * 1000), uuid.uuid4().hex[:8])
    rec = {
        "token": token,
        "reason": str(reason or "busy"),
        "delay_ms": DEFAULT_DELAY_MS,
        "size": _resolved_size(),
        "started": time.monotonic(),
        "visible": False,
    }
    with _COND:
        _TOKENS[token] = rec
        _publish_locked()
        _ensure_worker_locked()
        _COND.notify_all()
    _log("GLOBAL_BUSY_BEGIN_V1885 token=%s reason=%s delay_ms=%d scheduler=single renderer=active_window" % (
        token, rec["reason"], rec["delay_ms"]
    ))
    return token


def end(token, reason=""):
    """Release exactly one operation token."""
    if not token:
        return False
    with _COND:
        rec = _TOKENS.pop(str(token), None)
        _publish_locked()
        _COND.notify_all()
    if rec is None:
        return False
    elapsed = int((time.monotonic() - float(rec.get("started") or time.monotonic())) * 1000.0)
    _log("GLOBAL_BUSY_END_V1885 token=%s reason=%s elapsed_ms=%d spinner_was_visible=%d renderer=active_window" % (
        token, str(reason or rec.get("reason") or ""), elapsed,
        1 if rec.get("visible") else 0
    ))
    return True


def cancel_all(reason=""):
    with _COND:
        count = len(_TOKENS)
        _TOKENS.clear()
        _publish_locked()
        _COND.notify_all()
    _log("GLOBAL_BUSY_CANCEL_ALL_V1885 reason=%s count=%d renderer=active_window" % (str(reason or ""), count))
    return count


def is_visible():
    with _LOCK:
        return _is_visible_locked()


def is_active():
    with _LOCK:
        return bool(_TOKENS)


def current_reason():
    with _LOCK:
        visible = _visible_records_locked()
        if not visible:
            return ""
        rec = sorted(visible, key=lambda x: float(x.get("started") or 0.0))[-1]
        return str(rec.get("reason") or "")


def should_block_action(action_id):
    """Common input policy used by every PKM foreground WindowXML owner."""
    try:
        return int(action_id) in _BLOCKED_ACTION_IDS and is_visible()
    except Exception:
        return False
