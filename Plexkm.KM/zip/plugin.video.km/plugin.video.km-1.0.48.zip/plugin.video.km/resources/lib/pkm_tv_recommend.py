# PKM_PATCH_ACTIVE v2640 tv_first_episode_hotpath
# SIDEBAR_POLICY_V2640 no_long_correlated_cte=1 bounded_index_seek=1 movie_path_unchanged=1 section_hardcode=0
# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import random


_KODI_DISPLAY_TRANSLATE = {
    ord("\u23D0"): "|",
}

def display_library_title(value):
    try:
        return str(value or "").translate(_KODI_DISPLAY_TRANSLATE)
    except Exception:
        return str(value or "")


def tv_episode_row_columns_sql(alias="i"):
    """Return the common SELECT column list for TV episode recommendation rows."""
    a = (str(alias or "i").strip() or "i") + "."
    return ", ".join([
        a + "rating_key",
        a + "section_id",
        a + "plex_type",
        "'' AS kodi_type",
        a + "title",
        "'' AS original_title",
        a + "title AS sort_title",
        a + "year",
        a + "summary",
        a + "duration",
        a + "added_at",
        a + "updated_at",
        a + "thumb",
        a + "art",
        a + "media_file",
        a + "part_key",
        a + "view_count",
        a + "last_viewed_at",
        a + "show_title",
        a + "season",
        a + "episode",
        a + "parent_rating_key",
        a + "grandparent_rating_key",
    ])


def tv_show_key_from_row(row):
    try:
        t = tuple(row or ())
        return str((t[22] if len(t) > 22 else "") or (t[0] if len(t) > 0 else "") or "").strip()
    except Exception:
        return ""


def tv_rows_from_episode_map(episode_map, show_keys, exclude_keys=None, limit=None, row_item_limit=24, allow_duplicate_fallback=False, speed_log=None):
    """Return episode rows for TV show keys using an existing show->episode map.

    This is data-only. It preserves cross-row duplicate suppression but allows
    duplicate fallback only when duplicate filtering would otherwise remove the
    whole row.
    """
    try:
        max_rows = int(limit or row_item_limit)
    except Exception:
        max_rows = int(row_item_limit or 24)
    excluded = set(str(x) for x in (exclude_keys or []) if str(x or "").strip())
    out = []
    skipped_by_exclude = []
    seen_in_row = set()
    ordered_keys = []
    seen_show = set()
    for show_key in show_keys or []:
        skey = str(show_key or "").strip()
        if skey and skey not in seen_show:
            seen_show.add(skey)
            ordered_keys.append(skey)
    for skey in ordered_keys:
        row = (episode_map or {}).get(skey)
        if not row:
            continue
        try:
            rk = str(tuple(row)[0] or "")
            if rk and rk in seen_in_row:
                continue
            if rk and rk in excluded:
                skipped_by_exclude.append(row)
                continue
            if rk:
                excluded.add(rk)
                seen_in_row.add(rk)
        except Exception:
            pass
        out.append(row)
        if len(out) >= max_rows:
            break
    if (not out) and allow_duplicate_fallback and skipped_by_exclude:
        seen_fallback = set()
        for row in skipped_by_exclude:
            try:
                rk = str(tuple(row)[0] or "")
                if rk and rk in seen_fallback:
                    continue
                if rk:
                    seen_fallback.add(rk)
            except Exception:
                pass
            out.append(row)
            if len(out) >= max_rows:
                break
        if speed_log:
            try:
                speed_log("tv_rows_duplicate_fallback", rows=len(out), skipped=len(skipped_by_exclude), shows=len(ordered_keys), limit=max_rows)
            except Exception:
                pass
    return out


def tv_cache_limit(limit=None, row_item_limit=24):
    try:
        return max(1, min(int(row_item_limit), int(limit or row_item_limit)))
    except Exception:
        return int(row_item_limit or 24)


def tv_candidate_limit(limit=None, row_item_limit=24):
    row_limit = tv_cache_limit(limit, row_item_limit=row_item_limit)
    return min(max(row_limit * 2, int(row_item_limit or 24) + 12), 48)


def tv_section_title_for_id(sections, section_id):
    sid = str(section_id or "").strip()
    if not sid:
        return ""
    try:
        for sec in sections or []:
            cur = str(sec.get("section_id", sec.get("key", "")) or "").strip()
            if cur == sid:
                return display_library_title(sec.get("title", sec.get("name", ""))).strip()
    except Exception:
        pass
    return ""


def tv_all_show_section_ids(sections, section_id=None, max_sections=12):
    """Return TV show section ids for global actor pools without title hardcoding."""
    current = str(section_id or "").strip()
    out = []
    if current:
        out.append(current)
    try:
        for sec in sections or []:
            cur = str(sec.get("section_id", sec.get("key", "")) or "").strip()
            if not cur or cur in out:
                continue
            stype = str(sec.get("type", sec.get("section_type", "")) or "").strip().lower()
            if stype and stype not in ("show", "tv", "tvshow", "series"):
                continue
            out.append(cur)
    except Exception:
        pass
    if not out and current:
        out = [current]
    return list(out[:int(max_sections or 12)])


def tv_studio_section_ids(section_id):
    sid = str(section_id or "").strip()
    return [sid] if sid else []




def tv_section_country_bucket(conn, section_id, min_ratio=0.60):
    """Return dominant coarse country bucket for a TV section: 한국 / 외국 / ''.

    Uses only indexed item_countries buckets. No section-name matching.
    If the section is genuinely mixed or has no country index, returns ''.
    """
    sid = str(section_id or "").strip()
    if not sid:
        return ""
    try:
        rows = conn.execute("""
            SELECT c.country, COUNT(DISTINCT c.rating_key) AS cnt
            FROM item_countries c
            JOIN items i ON i.rating_key=c.rating_key
            WHERE c.section_id=?
              AND i.section_id=?
              AND i.plex_type IN ('show','episode')
              AND c.country IN ('한국','외국')
            GROUP BY c.country
        """, (sid, sid)).fetchall()
    except Exception:
        rows = []
    counts = {}
    total = 0
    for row in rows or []:
        try:
            name = str(row[0] or "").strip()
            cnt = int(row[1] or 0)
            if name in ("한국", "외국") and cnt > 0:
                counts[name] = counts.get(name, 0) + cnt
                total += cnt
        except Exception:
            continue
    if total <= 0:
        return ""
    bucket, cnt = max(counts.items(), key=lambda kv: kv[1])
    try:
        if float(cnt) / float(total) >= float(min_ratio or 0.60):
            return bucket
    except Exception:
        pass
    return ""


def tv_section_ids_by_country_bucket(conn, sections, section_id, bucket=None, max_sections=12):
    """Return TV show section ids whose dominant country bucket matches current.

    The current section is always first.  If the current section has no decisive
    country bucket, keep the pool section-local.  Expanding a mixed/unknown
    bucket to all TV sections causes Korean/foreign actor leakage without any
    title hardcoding, which is the v683 regression fixed in v684.
    """
    current = str(section_id or "").strip()
    out = []
    if current:
        out.append(current)
    target = str(bucket or "").strip()
    if not target:
        target = tv_section_country_bucket(conn, current)
    if target not in ("한국", "외국"):
        return out[:int(max_sections or 12)]
    try:
        for sec in sections or []:
            sid = str(sec.get("section_id", sec.get("key", "")) or "").strip()
            if not sid or sid in out:
                continue
            stype = str(sec.get("type", sec.get("section_type", "")) or "").strip().lower()
            if stype and stype not in ("show", "tv", "tvshow", "series"):
                continue
            b = tv_section_country_bucket(conn, sid)
            if b != target:
                continue
            out.append(sid)
            if len(out) >= int(max_sections or 12):
                break
    except Exception:
        pass
    return out[:int(max_sections or 12)]

def sql_placeholders(values):
    try:
        n = max(1, len(list(values or [])))
    except Exception:
        n = 1
    return ",".join(["?"] * n)


def _ordered_unique(values):
    out = []
    seen = set()
    for value in values or []:
        key = str(value or "").strip()
        if key and key not in seen:
            seen.add(key)
            out.append(key)
    return out


def tv_first_episode_row_for_show(conn, section_id, show_key, columns_sql=None):
    """Return the first episode row for a show, sorted S/E from left to right."""
    sid = str(section_id or "").strip()
    skey = str(show_key or "").strip()
    if not sid or not skey:
        return None
    cols = columns_sql or tv_episode_row_columns_sql("i")
    try:
        return conn.execute("""
            SELECT %s
            FROM items i
            WHERE i.section_id=? AND i.plex_type='episode' AND i.grandparent_rating_key=?
            ORDER BY COALESCE(i.season,0) ASC, COALESCE(i.episode,0) ASC, i.sort_title COLLATE NOCASE ASC
            LIMIT 1
        """ % cols, (sid, skey)).fetchone()
    except Exception:
        return None


def tv_first_episode_row_map_from_show_keys(conn, section_id, show_keys, columns_sql=None):
    """V2640: bounded indexed seeks; never one long correlated CTE on sidebar hotpath.

    The previous V2631 VALUES + correlated-subquery statement could monopolize the
    SQLite call for many seconds on some TV libraries.  One indexed LIMIT 1 seek per
    requested show keeps each DB operation short and preserves identical first-episode
    ordering.  The caller's show-key order remains authoritative.
    """
    sid = str(section_id or "").strip()
    ordered = _ordered_unique(show_keys)
    if not sid or not ordered:
        return {}

    row_by_show = {}
    cols = columns_sql or tv_episode_row_columns_sql("i")
    sql = """
        SELECT %s
        FROM items i
        WHERE i.section_id=?
          AND i.plex_type='episode'
          AND i.grandparent_rating_key=?
        ORDER BY COALESCE(i.season,0) ASC,
                 COALESCE(i.episode,0) ASC,
                 i.rating_key ASC
        LIMIT 1
    """ % cols

    # V2640 deliberately avoids a single long-running SQL statement.  If a library
    # is cold or large, control returns to Python after every tiny indexed seek.
    for skey in ordered:
        try:
            row = conn.execute(sql, (sid, skey)).fetchone()
        except Exception:
            row = None
        if row:
            row_by_show[skey] = row
    return row_by_show

def tv_first_episode_rows_from_show_keys(conn, section_id, show_keys, exclude_keys=None, limit=None, row_item_limit=24, columns_sql=None):
    """Return first-episode rows for show keys with one bulk DB query."""
    try:
        max_rows = int(limit or row_item_limit or 24)
    except Exception:
        max_rows = int(row_item_limit or 24)
    ordered = _ordered_unique(show_keys)
    if not str(section_id or "").strip() or not ordered or max_rows <= 0:
        return []
    excluded = set(str(x) for x in (exclude_keys or []) if str(x or "").strip())
    row_by_show = tv_first_episode_row_map_from_show_keys(conn, section_id, ordered, columns_sql=columns_sql)
    out = []
    for skey in ordered:
        row = row_by_show.get(skey)
        if not row:
            continue
        try:
            rk = str(tuple(row)[0] or "")
            if rk and rk in excluded:
                continue
            if rk:
                excluded.add(rk)
        except Exception:
            pass
        out.append(row)
        if len(out) >= max_rows:
            break
    return out


def tv_first_episode_row_map_from_show_keys_multi(conn, section_ids, show_keys, columns_sql=None):
    """Map show rating_key -> first episode row across several TV sections."""
    ordered = _ordered_unique(show_keys)
    if not ordered:
        return {}
    sids = _ordered_unique(section_ids)
    if not sids:
        return {}
    if len(sids) == 1:
        return tv_first_episode_row_map_from_show_keys(conn, sids[0], ordered, columns_sql=columns_sql)
    row_by_show = {}
    try:
        ph_show = sql_placeholders(ordered)
        ph_sid = sql_placeholders(sids)
        params = list(sids) + list(ordered)
        cols = columns_sql or tv_episode_row_columns_sql("i")
        q = """
            SELECT %s
            FROM items i
            JOIN (
                SELECT grandparent_rating_key AS show_key,
                       MIN(COALESCE(season,999999) * 1000000 + COALESCE(episode,999999)) AS ep_ord
                FROM items
                WHERE section_id IN (%s)
                  AND plex_type='episode'
                  AND grandparent_rating_key IN (%s)
                GROUP BY grandparent_rating_key
            ) x ON x.show_key=i.grandparent_rating_key
               AND (COALESCE(i.season,999999) * 1000000 + COALESCE(i.episode,999999))=x.ep_ord
            WHERE i.section_id IN (%s)
              AND i.plex_type='episode'
              AND i.grandparent_rating_key IN (%s)
            ORDER BY i.grandparent_rating_key, i.rating_key
        """ % (cols, ph_sid, ph_show, ph_sid, ph_show)
        rows = conn.execute(q, params + params).fetchall()
        for row in rows or []:
            try:
                t = tuple(row)
                show = str(t[22] if len(t) > 22 else "").strip()
                if show and show not in row_by_show:
                    row_by_show[show] = row
            except Exception:
                continue
    except Exception:
        row_by_show = {}
        for skey in ordered:
            for sid in sids:
                row = tv_first_episode_row_for_show(conn, sid, skey, columns_sql=columns_sql)
                if row:
                    row_by_show[skey] = row
                    break
    return row_by_show

