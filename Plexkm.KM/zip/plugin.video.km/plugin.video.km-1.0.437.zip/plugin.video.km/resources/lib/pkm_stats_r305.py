# -*- coding: utf-8 -*-
"""R305: 시청 통계 (watch statistics) screen.

Numbers come from the synced Plex library DB (view_count, last_viewed_at,
duration).  Only the last view of a title is known, so a period shows titles
whose last view falls inside it; "전체" multiplies by view_count.
"""
from __future__ import absolute_import, unicode_literals

import datetime
import json
import os
import sqlite3
import threading
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.km"
XML_NAME = "plexkm_stats_r305.xml"
BAR = "special://home/addons/plugin.video.km/resources/skins/Default/media/common/colors/white.png"
PERIODS = {301: "month", 302: "year", 303: "all"}
WEEK = ["월", "화", "수", "목", "금", "토", "일"]
GENRE_COLORS = ["FFFFB300", "FF4AA3FF", "FF6FCF97", "FFC792EA", "FF8A94A0"]
TOP_BAR_W = 748
WK_BAR_MAX_H = 130
WK_BASE = 610
GENRE_X0 = 1000
GENRE_BAR_W = 764


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s][stats] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def fmt_minutes(minutes):
    minutes = int(round(minutes))
    if minutes >= 60:
        h, m = divmod(minutes, 60)
        return "%d시간" % h if (m == 0 or h >= 10) else "%d시간 %d분" % (h, m)
    return "%d분" % minutes


def period_start(period, now=None):
    now = now or datetime.datetime.now()
    if period == "month":
        return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if period == "year":
        return now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    return None


def compute_stats(db_path, period, now=None):
    now = now or datetime.datetime.now()
    start = period_start(period, now)
    start_ts = int(time.mktime(start.timetuple())) if start else 0
    conn = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=2.0)
    try:
        rows = conn.execute(
            "SELECT rating_key, plex_type, duration, view_count, last_viewed_at, show_title, title, "
            "grandparent_rating_key FROM items WHERE COALESCE(view_count,0)>0 AND plex_type IN ('movie','episode') "
            "AND COALESCE(last_viewed_at,0)>=?", (start_ts,)).fetchall()
        genres = {}
        try:
            for rk, g in conn.execute("SELECT rating_key, genre FROM item_genres"):
                if g:
                    genres.setdefault(str(rk), []).append(str(g))
        except Exception:
            pass
    finally:
        conn.close()
    total = 0.0
    movies = 0
    episodes = 0
    titles = {}
    week = [0.0] * 7
    genre_min = {}
    first_ts = 0
    for rk, ptype, dur, vc, last, show_title, title, gp in rows:
        d = float(dur or 0)
        # duration is ms in Plex data, but some synced rows hold seconds (<1,000,000 => seconds)
        minutes = (d * 1000.0 if 0 < d < 1000000 else d) / 60000.0
        if period == "all":
            minutes *= max(1, int(vc or 1))
        if minutes <= 0:
            continue
        total += minutes
        if ptype == "movie":
            movies += 1
            key, name, gkey = "m:%s" % rk, str(title or ""), str(rk)
        else:
            episodes += 1
            key, name, gkey = "s:%s" % (gp or show_title), str(show_title or title or ""), str(gp or "")
        t = titles.setdefault(key, [name, 0.0])
        t[1] += minutes
        try:
            if last:
                week[datetime.datetime.fromtimestamp(int(last)).weekday()] += minutes
                first_ts = int(last) if (not first_ts or int(last) < first_ts) else first_ts
        except Exception:
            pass
        gl = genres.get(gkey) or []
        for g in gl:
            genre_min[g] = genre_min.get(g, 0.0) + minutes / float(len(gl))
    if period == "all":
        days = max(1.0, (time.time() - first_ts) / 86400.0) if first_ts else 1.0
    else:
        days = max(1.0, (now - start).total_seconds() / 86400.0)
    top = sorted(titles.values(), key=lambda x: -x[1])[:5]
    gs = sorted(genre_min.items(), key=lambda x: -x[1])
    gtotal = sum(v for _, v in gs) or 1.0
    glist = [(g, v / gtotal) for g, v in gs[:4]]
    rest = 1.0 - sum(p for _, p in glist)
    if gs and rest > 0.005:
        glist.append(("기타", rest))
    return {"total": total, "movies": movies, "episodes": episodes, "avg": total / days,
            "top": top, "week": week, "genres": glist, "empty": not rows}


class PKMStatsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.db_path = kwargs.pop("db_path", "")
        self.period = "year"
        super(PKMStatsDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.setFocusId(302)
        except Exception:
            pass
        self._load("year")

    def onClick(self, control_id):
        p = PERIODS.get(int(control_id or 0))
        if p and p != self.period:
            self._load(p)

    def _cache_path(self):
        try:
            return os.path.join(os.path.dirname(self.db_path), "stats_cache_r305.json")
        except Exception:
            return ""

    def _cache_get(self, period):
        try:
            with open(self._cache_path(), "r") as fh:
                return (json.load(fh) or {}).get(period)
        except Exception:
            return None

    def _cache_put(self, period, s):
        try:
            data = {}
            try:
                with open(self._cache_path(), "r") as fh:
                    data = json.load(fh) or {}
            except Exception:
                data = {}
            data[period] = s
            with open(self._cache_path(), "w") as fh:
                json.dump(data, fh)
        except Exception:
            pass

    def _load(self, period):
        self.period = period
        self.setProperty("Stats.Period", period)
        cached = self._cache_get(period)
        if cached:
            self._apply(cached)
        else:
            self.setProperty("Stats.Total", "집계 중")
        threading.Thread(target=self._compute_bg, args=(period,)).start()

    def _compute_bg(self, period):
        try:
            s = compute_stats(self.db_path, period)
            s["top"] = [list(t) for t in s["top"]]
            s["genres"] = [list(g) for g in s["genres"]]
        except Exception:
            _log("compute_failed\n%s" % traceback.format_exc(), xbmc.LOGWARNING)
            if period == self.period:
                self.setProperty("Stats.Empty", "1")
            return
        self._cache_put(period, s)
        if period == self.period:
            self._apply(s)

    def _apply(self, s):
        self.setProperty("Stats.Empty", "1" if s["empty"] else "")
        self.setProperty("Stats.Total", fmt_minutes(s["total"]))
        self.setProperty("Stats.Movies", "%d편" % s["movies"])
        self.setProperty("Stats.Episodes", "%d화" % s["episodes"])
        self.setProperty("Stats.Avg", fmt_minutes(s["avg"]))
        topmax = max([t[1] for t in s["top"]] + [1.0])
        for i in range(5):
            name = val = ""
            w = 0
            if i < len(s["top"]):
                name = "%d. %s" % (i + 1, s["top"][i][0])
                val = fmt_minutes(s["top"][i][1])
                w = max(46, int(TOP_BAR_W * s["top"][i][1] / topmax))
            self.setProperty("Stats.Top%d.Name" % i, name)
            self.setProperty("Stats.Top%d.Val" % i, val)
            self._size(401 + i, w, None)
        wmax = max(s["week"] + [1.0])
        for i in range(7):
            h = int(WK_BAR_MAX_H * s["week"][i] / wmax) if s["week"][i] > 0 else 0
            self._size(421 + i, None, h, bottom=WK_BASE)
        x = 0
        for i in range(5):
            txt = ""
            w = 0
            if i < len(s["genres"]):
                g, p = s["genres"][i]
                txt = "%s %d%%" % (g, int(round(p * 100)))
                w = int(GENRE_BAR_W * p)
            self.setProperty("Stats.Genre%d.Text" % i, txt)
            self._place(441 + i, GENRE_X0 + x, w)
            x += w

    def _size(self, cid, w, h, bottom=None):
        try:
            c = self.getControl(cid)
            if w is not None:
                c.setWidth(w)
            if h is not None:
                c.setHeight(max(1, h))
                c.setPosition(c.getX(), bottom - max(1, h) if bottom else c.getY())
                c.setVisible(h > 0)
        except Exception:
            pass

    def _place(self, cid, x, w):
        try:
            c = self.getControl(cid)
            c.setWidth(max(1, w))
            c.setPosition(x, c.getY())
            c.setVisible(w > 0)
        except Exception:
            pass


def open_stats_dialog(db_path):
    dlg = None
    try:
        dlg = PKMStatsDialog(XML_NAME, xbmcaddon.Addon(id=ADDON_ID).getAddonInfo("path"), "Default", "1080i",
                             db_path=db_path)
        dlg.doModal()
        return True
    except Exception:
        _log("open_failed\n%s" % traceback.format_exc(), xbmc.LOGERROR)
        return False
    finally:
        try:
            del dlg
        except Exception:
            pass
