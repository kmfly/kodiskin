# -*- coding: utf-8 -*-
"""Playback and Plex playstate helpers for plugin.video.plex_km.

Large-feature split from default.py.

This module is intentionally limited to playback data/API handling and Kodi's
standard setResolvedUrl handoff. It does not open/close windows, move focus,
handle Back, or reopen Home.

NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
Movie/episode playback must remain Kodi-native plugin playback:
PlayMedia(plugin://plugin.video.plex_km/?action=play...) -> this resolver ->
xbmcplugin.setResolvedUrl(handle, True, ListItem(path=Plex file URL)).
Do NOT use xbmc.Player().play(), direct Python http file playback, proxy
streaming, pipe headers, or any Python-owned player start path here.
"""
from __future__ import absolute_import, unicode_literals

import time
import traceback

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import pkm_plex_client
from resources.lib.pkm_video_info import apply_video_info
try:
    from resources.lib import pkm_notify
except Exception:
    pkm_notify = None

_TRACE_COUNTS = {}


def _log(env, msg, level=xbmc.LOGINFO):
    try:
        func = env.get("log") if env else None
        if func:
            func(msg, level)
            return
    except Exception:
        pass
    try:
        xbmc.log("[plugin.video.plex_km] %s" % msg, level)
    except Exception:
        pass


def _perf_log(env, msg):
    try:
        func = env.get("perf_log") if env else None
        if func:
            func(msg)
            return
    except Exception:
        pass
    _log(env, msg, xbmc.LOGDEBUG)


def _notify(env, message, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    try:
        func = env.get("notify") if env else None
        if func:
            func(message, icon=icon, ms=ms)
            return
    except Exception:
        pass
    try:
        if pkm_notify and pkm_notify.pkm_show_notice("Plex KM", str(message or ""), "", ms=int(ms or 3500)):
            return
    except Exception:
        pass
    _log(env, "PKM_NATIVE_NOTIFICATION_SUPPRESSED message=%s" % str(message or ""), xbmc.LOGINFO)


def _trace(env, key, msg, level=xbmc.LOGINFO, limit=6):
    """Small verification trace with a hard per-key limit."""
    try:
        count = int(_TRACE_COUNTS.get(key, 0))
        if count >= int(limit):
            return
        _TRACE_COUNTS[key] = count + 1
        suffix = " sample=%s/%s" % (_TRACE_COUNTS[key], limit) if limit > 1 else ""
        _log(env, "PLAYBACK_SPLIT_TRACE key=%s%s %s" % (key, suffix, msg), level)
    except Exception:
        pass


def _handle(env):
    try:
        return int(env.get("handle", -1)) if env else -1
    except Exception:
        return -1


def _callback(env, name):
    try:
        func = env.get(name) if env else None
        return func if callable(func) else None
    except Exception:
        return None


def _is_korean_subtitle_stream(stream):
    try:
        vals = []
        for k in ("languageCode", "language", "title", "displayTitle", "extendedDisplayTitle", "name"):
            v = ""
            try:
                if hasattr(stream, "get"):
                    v = stream.get(k) or ""
            except Exception:
                v = ""
            if v:
                vals.append(str(v).lower())
        joined = " ".join(vals)
        return ("kor" in joined) or ("ko" == joined.strip()) or ("korean" in joined) or ("한국" in joined) or ("한글" in joined)
    except Exception:
        return False


def _subtitle_codec_label(codec):
    c = str(codec or "").strip().lower()
    if not c:
        return ""
    mapping = {
        "subrip": "SRT", "srt": "SRT",
        "smi": "SMI", "sami": "SMI",
        "ssa": "SSA", "ass": "ASS",
        "vobsub": "VOBSUB", "dvd_subtitle": "VOBSUB",
        "pgs": "PGS", "hdmv_pgs_subtitle": "PGS",
        "webvtt": "WEBVTT", "vtt": "WEBVTT",
        "mov_text": "TX3G", "tx3g": "TX3G",
    }
    return mapping.get(c, c.upper())


def _subtitle_display_label(label, codec, source="외부"):
    base = str(label or "한국어").strip() or "한국어"
    fmt = _subtitle_codec_label(codec)
    return "%s (%s %s)" % (base, source, fmt) if fmt else "%s (%s)" % (base, source)


def _find_plex_external_korean_subtitle(rating_key, part_key, env=None):
    """Return the best Plex external Korean subtitle URL for direct playback.

    Kodi direct playback can miss Plex-side external SRT streams.  The subtitle
    popup already works around this by reading Plex XML and calling
    Player.setSubtitles().  For default playback, attach the same Plex external
    Korean subtitle to the resolved ListItem and also expose it to service.py as
    a pending fallback.
    """
    rating_key = str(rating_key or "").strip()
    part_key = str(part_key or "").strip()
    if not rating_key:
        return None
    try:
        root = pkm_plex_client.plex_request_xml('/library/metadata/%s' % rating_key, timeout=5, env=env)
        part_nodes = list(root.findall('.//Part')) if root is not None else []
        chosen_parts = []
        if part_key:
            for part in part_nodes:
                try:
                    if (part.get('key') or '') == part_key:
                        chosen_parts.append(part)
                except Exception:
                    pass
        if not chosen_parts:
            chosen_parts = part_nodes
        candidates = []
        seq = 0
        for part in chosen_parts:
            for st in part.findall('.//Stream'):
                try:
                    if str(st.get('streamType') or '') != '3':
                        continue
                    key = st.get('key') or ''
                    if not key:
                        continue
                    if not _is_korean_subtitle_stream(st):
                        continue
                    url = pkm_plex_client.plex_url(key, include_token=True, env=env)
                    label = st.get('title') or st.get('displayTitle') or st.get('extendedDisplayTitle') or st.get('language') or st.get('languageCode') or '한국어'
                    codec = st.get('codec') or ''
                    forced = str(st.get('forced') or '').lower() in ('1','true','yes')
                    candidates.append({
                        'url': url,
                        'label': _subtitle_display_label(label, codec, source='외부'),
                        'raw_label': label,
                        'codec': codec,
                        'forced': forced,
                        'stream_id': st.get('id') or '',
                        'part_key': part.get('key') or '',
                        'seq': seq,
                    })
                    seq += 1
                except Exception:
                    pass
        if not candidates:
            _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_NONE rating_key=%s part_key=%s source=plex_external policy=external_first korean=0' % (rating_key, part_key), xbmc.LOGINFO)
            return None
        # Prefer normal/non-forced Korean subtitles for movie playback.
        candidates.sort(key=lambda x: (1 if x.get('forced') else 0, int(x.get('seq') or 0)))
        chosen = candidates[0]
        _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_FOUND rating_key=%s part_match=%s label=%s codec=%s forced=%s stream_id=%s source=plex_external policy=external_first' % (
            rating_key, '1' if chosen.get('part_key') == part_key else '0', chosen.get('label',''), chosen.get('codec',''), '1' if chosen.get('forced') else '0', chosen.get('stream_id','')
        ), xbmc.LOGINFO)
        return chosen
    except Exception:
        _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_PROBE_FAILED rating_key=%s part_key=%s\n%s' % (rating_key, part_key, traceback.format_exc()), xbmc.LOGWARNING)
        return None


def plex_timeline(rating_key, state="playing", time_ms=0, duration_ms=0, context="playback", env=None):
    """Push Kodi playback progress to PMS so Plex Continue Watching stays correct."""
    rating_key = str(rating_key or "").strip()
    if not rating_key:
        return False
    try:
        t = max(0, int(float(time_ms or 0)))
    except Exception:
        t = 0
    try:
        d = max(0, int(float(duration_ms or 0)))
    except Exception:
        d = 0
    timeline_state = str(state or "playing")
    if timeline_state == "playing" and d <= 0:
        _log(env, "PLAYSTATE_TIMELINE_SKIP reason=playing_duration_zero rating_key=%s time=%s duration=%s" % (rating_key, t, d), xbmc.LOGINFO)
        return False
    params = {
        "ratingKey": rating_key,
        "key": "/library/metadata/%s" % rating_key,
        "state": timeline_state,
        "time": t,
        "duration": d,
        "context": context or "playback",
        "playQueueItemID": 0,
        "hasMDE": 1,
    }
    try:
        pkm_plex_client.plex_request("/:/timeline", params=params, timeout=5, method="GET", env=env)
        _trace(env, "timeline", "rating_key=%s state=%s" % (rating_key, params["state"]), limit=4)
        _log(env, "PLAYSTATE_TIMELINE_PUSH rating_key=%s state=%s time=%s duration=%s" % (rating_key, params["state"], t, d), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log(env, "PLAYSTATE_TIMELINE_PUSH_FAILED rating_key=%s state=%s error=%s" % (rating_key, state, exc), xbmc.LOGWARNING)
        return False


def plex_scrobble(rating_key, reason="playback_ended", env=None):
    """Mark an item watched on PMS after Kodi reports natural playback end."""
    rating_key = str(rating_key or "").strip()
    if not rating_key:
        return False
    try:
        pkm_plex_client.plex_request("/:/scrobble", params={
            "key": rating_key,
            "identifier": "com.plexapp.plugins.library",
        }, timeout=5, method="GET", env=env)
        _trace(env, "scrobble", "rating_key=%s reason=%s" % (rating_key, reason), limit=4)
        _log(env, "PLAYSTATE_SCROBBLE rating_key=%s reason=%s" % (rating_key, reason), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log(env, "PLAYSTATE_SCROBBLE_FAILED rating_key=%s reason=%s error=%s" % (rating_key, reason, exc), xbmc.LOGWARNING)
        return False


def plex_unscrobble(rating_key, reason="playback_resume", env=None):
    """Clear watched state before saving a non-finished resume position."""
    rating_key = str(rating_key or "").strip()
    if not rating_key:
        return False
    try:
        pkm_plex_client.plex_request("/:/unscrobble", params={
            "key": rating_key,
            "identifier": "com.plexapp.plugins.library",
        }, timeout=5, method="GET", env=env)
        _trace(env, "unscrobble", "rating_key=%s reason=%s" % (rating_key, reason), limit=4)
        _log(env, "PLAYSTATE_UNSCROBBLE rating_key=%s reason=%s" % (rating_key, reason), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log(env, "PLAYSTATE_UNSCROBBLE_FAILED rating_key=%s reason=%s error=%s" % (rating_key, reason, exc), xbmc.LOGWARNING)
        return False


def refresh_item_state_from_plex(rating_key, reason="playstate", env=None):
    """Refresh watched/resume-adjacent fields for one item after playback."""
    rating_key = str(rating_key or "").strip()
    if not rating_key:
        return False
    extract_item = _callback(env, "extract_item")
    init_db = _callback(env, "init_db")
    upsert_item = _callback(env, "upsert_item")
    if not (extract_item and init_db and upsert_item):
        _log(env, "PLAYSTATE_ITEM_REFRESH_FAILED reason=%s rating_key=%s error=missing_callbacks" % (reason, rating_key), xbmc.LOGWARNING)
        return False
    try:
        root = pkm_plex_client.plex_request_xml("/library/metadata/%s" % rating_key, timeout=6, env=env)
        node = None
        for child in list(root):
            if child.tag in ("Video", "Directory"):
                node = child
                break
        if node is None:
            return False
        section_id = node.get("librarySectionID") or node.get("librarySectionKey") or ""
        section_type = node.get("librarySectionType") or node.get("type") or ""
        item = extract_item(node, section_id, section_type)
        conn = init_db()
        try:
            upsert_item(conn, item)
            conn.commit()
        finally:
            conn.close()
        _trace(env, "refresh_item", "rating_key=%s reason=%s" % (rating_key, reason), limit=5)
        _log(env, "PLAYSTATE_ITEM_REFRESH reason=%s rating_key=%s view_count=%s last_viewed_at=%s" % (
            reason, rating_key, item.get("view_count", 0), item.get("last_viewed_at", 0)
        ), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log(env, "PLAYSTATE_ITEM_REFRESH_FAILED reason=%s rating_key=%s error=%s" % (reason, rating_key, exc), xbmc.LOGWARNING)
        return False


def sync_play_state_from_plex_light(reason="startup", limit=120, env=None):
    """Pull live PMS playback state without rebuilding large library caches."""
    extract_item = _callback(env, "extract_item")
    init_db = _callback(env, "init_db")
    upsert_item = _callback(env, "upsert_item")
    write_continue_preload = _callback(env, "write_continue_preload_items")
    if not (extract_item and init_db and upsert_item):
        _log(env, "PLAYSTATE_LIGHT_PULL_DONE reason=%s refreshed=0 preload=0 missing_callbacks=1" % reason, xbmc.LOGWARNING)
        return 0

    seen = set()
    refreshed = 0
    continue_preload = []
    endpoints = (
        ("/library/onDeck", "onDeck"),
        ("/library/recentlyViewed", "recentlyViewed"),
    )
    for endpoint, label in endpoints:
        try:
            root = pkm_plex_client.plex_request_xml(endpoint, params={"X-Plex-Container-Start": 0, "X-Plex-Container-Size": int(limit or 60)}, timeout=8, env=env)
            for node in list(root):
                if node.tag not in ("Video", "Directory"):
                    continue
                rk = str(node.get("ratingKey") or node.get("key") or "").strip()
                if not rk or rk in seen:
                    continue
                seen.add(rk)
                section_id = node.get("librarySectionID") or node.get("librarySectionKey") or ""
                section_type = node.get("librarySectionType") or node.get("type") or ""
                try:
                    item = extract_item(node, section_id, section_type)
                    if label == "onDeck":
                        item["resume_updated_at"] = int(item.get("last_viewed_at") or item.get("updated_at") or 0)
                        item["resume_duration_ms"] = 0
                        item["resume_source"] = "plex_ondeck_preload"
                        continue_preload.append(dict(item))
                    conn = init_db()
                    try:
                        upsert_item(conn, item)
                        conn.commit()
                    finally:
                        conn.close()
                    refreshed += 1
                except Exception:
                    continue
        except Exception as exc:
            _log(env, "PLAYSTATE_LIGHT_PULL_SKIP endpoint=%s reason=%s error=%s" % (label, reason, exc), xbmc.LOGDEBUG)
    if continue_preload and write_continue_preload:
        write_continue_preload(continue_preload, reason=reason)
    _trace(env, "light_pull", "reason=%s refreshed=%d preload=%d" % (reason, refreshed, len(continue_preload)), limit=3)
    _log(env, "PLAYSTATE_LIGHT_PULL_DONE reason=%s refreshed=%d preload=%d" % (reason, refreshed, len(continue_preload)), xbmc.LOGINFO)
    return refreshed



def _runtime_ko_v1461(seconds):
    try:
        sec = max(0, int(float(seconds or 0)))
    except Exception:
        sec = 0
    mins = sec // 60
    if mins <= 0:
        return ""
    h = mins // 60
    m = mins % 60
    if h > 0 and m > 0:
        return "%d시간 %d분" % (h, m)
    if h > 0:
        return "%d시간" % h
    return "%d분" % m


def _restore_player_osd_meta_v1461(rating_key, listitem=None, env=None):
    """Restore Plex-style title/year/runtime for VideoOSD.

    v1461: native PlayMedia + setResolvedUrl must not lose OSD metadata.  The
    skin title line uses Window(home).Property(PlexKM.Player.Title/Meta); set it
    again inside the resolver from the local PKM DB so later skin/seek changes
    cannot accidentally remove the movie title/year line.
    """
    try:
        rk = str(rating_key or "").strip()
        if not rk:
            return False
        title = year = ""
        duration_raw = 0
        init_db = _callback(env, "init_db")
        if init_db:
            conn = None
            try:
                conn = init_db()
                row = conn.execute(
                    "SELECT title, year, duration FROM items WHERE CAST(rating_key AS TEXT)=? LIMIT 1",
                    (rk,)
                ).fetchone()
                if row:
                    title = str(row[0] or "").strip()
                    year = str(row[1] or "").strip()
                    try:
                        duration_raw = int(float(row[2] or 0))
                    except Exception:
                        duration_raw = 0
            except Exception as exc:
                _log(env, "PKM_PLAYER_OSD_META_RESTORE_DB_SKIP_V1461 rating_key=%s error=%s" % (rk, exc), xbmc.LOGWARNING)
            finally:
                try:
                    if conn:
                        conn.close()
                except Exception:
                    pass
        if not title:
            return False
        duration_sec = int(duration_raw / 1000) if duration_raw > 100000 else int(duration_raw or 0)
        runtime = _runtime_ko_v1461(duration_sec)
        parts = []
        if year:
            parts.append(year)
        if runtime:
            parts.append(runtime)
        meta = " • ".join(parts)
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.Player.Title", title)
        win.setProperty("PlexKM.Player.Meta", meta)
        win.setProperty("PlexKM.Player.Year", year)
        win.setProperty("PlexKM.Player.Runtime", runtime)
        if listitem is not None:
            try:
                info = {"title": title}
                if year:
                    try:
                        info["year"] = int(year)
                    except Exception:
                        pass
                if duration_sec > 0:
                    info["duration"] = int(duration_sec)
                apply_video_info(listitem, info)
            except Exception:
                pass
            try:
                listitem.setProperty("PlexKM.PlayTitle", title)
                listitem.setProperty("PlexKM.Year", year)
                listitem.setProperty("PlexKM.Duration", str(int(duration_raw or 0)))
            except Exception:
                pass
        _log(env, "PKM_PLAYER_OSD_META_RESTORE_V1461 rating_key=%s title=%s meta=%s" % (rk, title, meta), xbmc.LOGINFO)
        return True
    except Exception as exc:
        _log(env, "PKM_PLAYER_OSD_META_RESTORE_FAILED_V1461 rating_key=%s error=%s" % (rating_key, exc), xbmc.LOGWARNING)
        return False

def play_item(params, env=None):
    """Resolve a Plex media part through Kodi's normal plugin playback handoff.

    NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
    This function is intentionally a setResolvedUrl resolver only.
    It must never call xbmc.Player().play() for movies/episodes.
    """
    t0 = time.time()
    params = params or {}
    rating_key = params.get("rating_key", "")
    part_key = params.get("part_key", "")
    handle = _handle(env)
    if not part_key:
        _notify(env, "No playable Plex part", icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Register the outgoing Plex item for service.py PlayerMonitor only. This is
    # playback-state data, not Home/window/focus/navigation control.
    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.NowPlaying.RatingKey", str(rating_key or ""))
        win.setProperty("PlexKM.NowPlaying.PartKey", str(part_key or ""))
        win.setProperty("PlexKM.NowPlaying.StartedAt", str(int(time.time())))
        win.setProperty("PlexKM.NowPlaying.StartedAtMs", str(int(time.time() * 1000)))
        win.clearProperty("PlexKM.NowPlaying.ExpectedResumeMs")
        # v1548: reset only retry bookkeeping for the new resolver attempt.
        # Do not clear cached player position/duration or the user's resume value.
        for _key in (
            "PlexKM.NowPlaying.ResumeSeekAppliedV1506",
            "PlexKM.NowPlaying.ResumeSeekAppliedAtMs",
            "PlexKM.NowPlaying.ResumeSeekAttemptsV1548",
            "PlexKM.NowPlaying.ResumeSeekLastAtMsV1548",
            "PlexKM.NowPlaying.ResumeSeekPendingV1548",
            "PlexKM.NowPlaying.ResumeSeekExhaustedLoggedV1548",
            "PlexKM.NowPlaying.ResumeSeekMismatchHoldLoggedV1548",
            "PlexKM.NowPlaying.NativeResumeWaitLoggedV1553",
        ):
            win.clearProperty(_key)
    except Exception:
        pass

    # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
    # Keep the same playback method as v1145/v1143: Kodi owns the player.
    # This resolver only hands Kodi a normal Plex part URL with query token via
    # xbmcplugin.setResolvedUrl(). Do not use Kodi pipe headers, forced
    # download, contentLookup changes, MIME hints, proxy/custom stream layers,
    # xbmc.Player().play(), or any Python-owned playback start path.
    stream_url = pkm_plex_client.plex_url(part_key, include_token=True, env=env)
    try:
        _log(env, "PLAYBACK_STREAM_URL_HANDOFF_V1151 rating_key=%s part_key=%s auth_mode=kodi_native_query_token query_token=1 header_token=0 forced_download=0 content_lookup_changed=0 mime_hint=0 proxy=0" % (rating_key, part_key), xbmc.LOGINFO)
    except Exception:
        pass
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty("IsPlayable", "true")
    if rating_key:
        li.setProperty("PlexKM.RatingKey", str(rating_key))
    # v1461: do not let skin/seek patches accidentally remove the OSD movie title/year.
    # Restore these properties at the resolver boundary while preserving native setResolvedUrl playback.
    _restore_player_osd_meta_v1461(rating_key, listitem=li, env=env)
    # v1075: PKM owns resume selection and must suppress Kodi's native resume dialog.
    #
    # Logs from v1074 showed the plugin URL was correct (`start=0`) and this
    # resolver was reached, but Kodi still displayed the stock resume popup using
    # its own local bookmark (example: 00:03:34), not the PKM/Plex offset.
    # Therefore URL parameters alone are not enough on Kodi 21.x.  Apply the
    # resume policy to the resolved ListItem through every supported path:
    # StartOffset, legacy resumetime, and the Kodi 21 InfoTagVideo resume point.
    resume_mode = "start"
    offset_sec = 0
    try:
        if params.get("resume_offset") not in (None, "") and str(params.get("start", "")) != "0":
            offset_sec = max(0, int(float(params.get("resume_offset") or 0)) // 1000)
            resume_mode = "resume"
        else:
            offset_sec = 0
            resume_mode = "start"
    except Exception:
        offset_sec = 0
        resume_mode = "start"

    try:
        win = xbmcgui.Window(10000)
        win.setProperty("PlexKM.NowPlaying.ExpectedResumeMs", str(int(offset_sec * 1000)))
        try:
            _expected_total_ms = max(0, int(float(params.get("resume_duration_ms") or 0)))
        except Exception:
            _expected_total_ms = 0
        if _expected_total_ms <= 0:
            try:
                _raw_total = max(0, int(float(li.getProperty("PlexKM.Duration") or 0)))
                _expected_total_ms = _raw_total if _raw_total > 100000 else (_raw_total * 1000 if _raw_total > 0 else 0)
            except Exception:
                _expected_total_ms = 0
        win.setProperty("PlexKM.NowPlaying.ExpectedDurationMs", str(_expected_total_ms))
        win.setProperty("PlexKM.NowPlaying.StartedAtMs", str(int(time.time() * 1000)))
        _log(env, "PKM_NOWPLAYING_EXPECTED rating_key=%s mode=%s expected_ms=%s total_ms=%s native_resume=1 auto_seek=0" % (rating_key, resume_mode, int(offset_sec * 1000), _expected_total_ms), xbmc.LOGINFO)
    except Exception:
        pass

    try:
        _resume_total_ms = max(0, int(float(params.get("resume_duration_ms") or 0)))
    except Exception:
        _resume_total_ms = 0
    if _resume_total_ms <= 0:
        try:
            _raw_total = max(0, int(float(li.getProperty("PlexKM.Duration") or 0)))
            _resume_total_ms = _raw_total if _raw_total > 100000 else (_raw_total * 1000 if _raw_total > 0 else 0)
        except Exception:
            _resume_total_ms = 0
    resume_total_sec = max(0, int(_resume_total_ms // 1000))

    def _apply_resume_policy_to_li(item, off, total):
        # Set both canonical and legacy/case variants. Kodi versions differ in
        # which layer consumes which property during plugin resolver handoff.
        # v1553: native resume must carry a real total duration. Passing 0 made
        # Kodi 21 intermittently ignore the resume point on a cold different-file
        # switch, which then tempted the service layer to issue post-start seeks.
        val_int = str(int(off or 0))
        val_float = "%.6f" % float(off or 0)
        total_float = "%.6f" % float(total or 0)
        for key, val in (
            ("StartOffset", val_int),
            ("startoffset", val_int),
            ("ResumeTime", val_float),
            ("resumetime", val_float),
            ("TotalTime", total_float),
            ("totaltime", total_float),
        ):
            try:
                item.setProperty(key, val)
            except Exception:
                pass
        try:
            tag = item.getVideoInfoTag()
            # Kodi 21 deprecates ListItem.resumetime and prefers InfoTagVideo.
            if tag is not None and hasattr(tag, "setResumePoint"):
                tag.setResumePoint(float(off or 0), float(total or 0))
                try:
                    item.setProperty("PlexKM.ResumePolicy.InfoTag", "1")
                except Exception:
                    pass
        except Exception:
            try:
                item.setProperty("PlexKM.ResumePolicy.InfoTag", "0")
            except Exception:
                pass

    try:
        _apply_resume_policy_to_li(li, offset_sec, resume_total_sec)
    except Exception:
        pass

    # v1096: apply Korean external subtitle as part of the playback handoff, not
    # only when the subtitle popup is opened.  Dogman exposes Korean SRT in Plex
    # XML but Kodi's native stream list contains only muxed non-Korean streams,
    # so relying on the popup onInit default leaves playback with subtitles off.
    try:
        sub = _find_plex_external_korean_subtitle(rating_key, part_key, env=env)
        if sub and sub.get('url'):
            subtitle_url = str(sub.get('url') or '')
            try:
                li.setSubtitles([subtitle_url])
                li.setProperty('PlexKM.DefaultSubtitleUrl', subtitle_url)
                li.setProperty('PlexKM.DefaultSubtitleLabel', str(sub.get('label') or '한국어'))
                li.setProperty('PlexKM.DefaultSubtitleSource', 'plex_external')
                _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_LISTITEM rating_key=%s label=%s url=1 source=plex_external policy=external_first' % (rating_key, sub.get('label') or '한국어'), xbmc.LOGINFO)
            except Exception:
                _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_LISTITEM_FAILED rating_key=%s label=%s\n%s' % (rating_key, sub.get('label') or '한국어', traceback.format_exc()), xbmc.LOGWARNING)
            try:
                win = xbmcgui.Window(10000)
                win.setProperty('PlexKM.PendingSubtitle.RatingKey', str(rating_key or ''))
                win.setProperty('PlexKM.PendingSubtitle.Url', subtitle_url)
                win.setProperty('PlexKM.PendingSubtitle.Label', str(sub.get('label') or '한국어'))
                win.setProperty('PlexKM.PendingSubtitle.Source', 'plex_external')
                win.clearProperty('PlexKM.CurrentSubtitle.Manual')
                win.setProperty('PlexKM.PendingSubtitle.SetAt', str(int(time.time() * 1000)))
                win.setProperty('PlexKM.PendingSubtitle.Attempt', '0')
                # Keep a stable current-external identity so the subtitle popup
                # can show the check mark on the Plex-style external row even
                # after the pending URL is consumed by the playback monitor.
                win.setProperty('PlexKM.CurrentSubtitle.Source', 'external')
                win.setProperty('PlexKM.CurrentSubtitle.Url', subtitle_url)
                win.setProperty('PlexKM.CurrentSubtitle.Label', str(sub.get('label') or '한국어'))
                _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_PENDING rating_key=%s label=%s url=1 source=plex_external policy=external_first' % (rating_key, sub.get('label') or '한국어'), xbmc.LOGINFO)
            except Exception:
                pass
    except Exception:
        _log(env, 'PLAYBACK_SUBTITLE_DEFAULT_FAILED rating_key=%s\n%s' % (rating_key, traceback.format_exc()), xbmc.LOGWARNING)

    # NATIVE PLAYBACK LOCK v1454 -- DO NOT CHANGE.
    # This is the actual Kodi-native handoff point.  Kodi VideoPlayer opens the
    # Plex file after setResolvedUrl; PKM does not start playback with Python.
    xbmcplugin.setResolvedUrl(handle, True, li)
    try:
        _log(env, "PKM_RESUME_POLICY_APPLIED_V1553 rating_key=%s mode=%s start_offset=%s startoffset=%s resume_time=%s total_time=%s info_tag=%s resume_offset=%s resume_duration_ms=%s start_param=%s auto_seek=0" % (
            rating_key,
            resume_mode,
            li.getProperty("StartOffset"),
            li.getProperty("startoffset"),
            li.getProperty("resumetime") or li.getProperty("ResumeTime"),
            li.getProperty("totaltime") or li.getProperty("TotalTime"),
            li.getProperty("PlexKM.ResumePolicy.InfoTag"),
            str(params.get("resume_offset", "")),
            str(params.get("resume_duration_ms", "")),
            str(params.get("start", "")),
        ), xbmc.LOGINFO)
    except Exception:
        pass
    try:
        _log(env, "PLAYBACK_NATIVE_LOCK_V1454 method=PlayMedia_plugin_setResolvedUrl python_player_play=0 direct_info_http=0 rating_key=%s" % (rating_key,), xbmc.LOGINFO)
    except Exception:
        pass
    _trace(env, "play_item", "rating_key=%s part_key_set=%s" % (rating_key, "1" if part_key else "0"), limit=5)
    _perf_log(env, "PLAY rating_key=%s part_key=%s resolve=%.3fms" % (rating_key, part_key, (time.time() - t0) * 1000.0))
