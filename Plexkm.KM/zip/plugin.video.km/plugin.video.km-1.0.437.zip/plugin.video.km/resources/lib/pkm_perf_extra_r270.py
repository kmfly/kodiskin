# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""PKM R270 extra diagnostics (low overhead, worker-thread logging only).

- SQL_SLOW / SQL_SUMMARY: sqlite statements slower than SLOW_MS (timing wrapper only appends to a deque).
- STORAGE: db / wal / texture db / thumbnail sizes.
- TREND: rss / mem_avail slope since start.
- PREV_EXIT: unclean exit detection (possible LMK kill) via run marker file.
"""

from collections import deque
import os
import sqlite3
import threading
import time

try:
    import xbmc
    import xbmcvfs
except Exception:
    xbmc = None
    xbmcvfs = None

TAG = "[PKM_PERF_R270]"
SLOW_MS = 80.0
_Q = deque(maxlen=400)
_STAT = {"n": 0, "slow": 0, "max": 0.0, "sum": 0.0, "samples": deque(maxlen=2000)}
_LOCK = threading.Lock()
_INSTALLED = False
_STARTED = False
_T0 = time.time()
_ORIG_CONNECT = sqlite3.connect


def _rec(sql, ms, db):
    try:
        with _LOCK:
            _STAT["n"] += 1
            _STAT["sum"] += ms
            if ms > _STAT["max"]:
                _STAT["max"] = ms
            _STAT["samples"].append(ms)
            if ms >= SLOW_MS:
                _STAT["slow"] += 1
                _Q.append((ms, db, " ".join(str(sql or "").split())[:160], threading.current_thread().name))
    except Exception:
        pass


class _Cur(sqlite3.Cursor):
    def execute(self, sql, *a):
        t = time.perf_counter()
        try:
            return sqlite3.Cursor.execute(self, sql, *a)
        finally:
            _rec(sql, (time.perf_counter() - t) * 1000.0, getattr(self.connection, "_pkm_db", "?"))

    def executemany(self, sql, *a):
        t = time.perf_counter()
        try:
            return sqlite3.Cursor.executemany(self, sql, *a)
        finally:
            _rec("MANY " + str(sql), (time.perf_counter() - t) * 1000.0, getattr(self.connection, "_pkm_db", "?"))


class _Conn(sqlite3.Connection):
    def cursor(self, factory=_Cur):
        return sqlite3.Connection.cursor(self, factory)

    def execute(self, sql, *a):
        return self.cursor().execute(sql, *a)

    def executemany(self, sql, *a):
        return self.cursor().executemany(sql, *a)


def _timed_connect(database, *args, **kwargs):
    if "factory" not in kwargs and len(args) < 5:
        kwargs["factory"] = _Conn
    conn = _ORIG_CONNECT(database, *args, **kwargs)
    try:
        conn._pkm_db = os.path.basename(str(database))
    except Exception:
        pass
    return conn


def install_sql_timing():
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    try:
        sqlite3.connect = _timed_connect
    except Exception:
        _INSTALLED = False


def _log(msg):
    try:
        if xbmc is not None:
            xbmc.log("%s %s" % (TAG, msg), xbmc.LOGINFO)
    except Exception:
        pass


def _profile_dir():
    try:
        return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.km/")
    except Exception:
        return ""


def _dir_size(path, limit_files=200000):
    total = 0
    cnt = 0
    for root, _d, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except Exception:
                pass
            cnt += 1
            if cnt >= limit_files:
                return total, cnt
    return total, cnt


def _mb(n):
    return round(float(n) / 1048576.0, 1)


def _storage():
    pdir = _profile_dir()
    parts = []
    try:
        for name in sorted(os.listdir(pdir)):
            p = os.path.join(pdir, name)
            if os.path.isfile(p) and (".db" in name):
                parts.append("%s=%s" % (name, _mb(os.path.getsize(p))))
    except Exception:
        pass
    try:
        total, cnt = _dir_size(pdir, 50000)
        parts.append("addon_data_total_mb=%s files=%d" % (_mb(total), cnt))
    except Exception:
        pass
    try:
        tdb = xbmcvfs.translatePath("special://database/Textures13.db")
        if os.path.exists(tdb):
            parts.append("Textures13.db=%s" % _mb(os.path.getsize(tdb)))
        thumbs = xbmcvfs.translatePath("special://thumbnails/")
        total, cnt = _dir_size(thumbs)
        parts.append("thumbnails_mb=%s thumbnails_files=%d" % (_mb(total), cnt))
    except Exception:
        pass
    _log("event=STORAGE " + " ".join(parts))


def _marker_path():
    return os.path.join(_profile_dir(), "pkm_run_marker_r270.txt")


def _read_marker():
    try:
        with open(_marker_path(), "r") as f:
            return dict(l.strip().split("=", 1) for l in f if "=" in l)
    except Exception:
        return {}


def _write_marker(clean, rss, avail):
    try:
        with open(_marker_path(), "w") as f:
            f.write("clean=%d\nts=%d\nrss_mb=%s\nmem_avail_mb=%s\n" % (clean, int(time.time()), rss, avail))
    except Exception:
        pass


def _flush_sql(final=False):
    items = []
    with _LOCK:
        while _Q:
            items.append(_Q.popleft())
        n, slow, mx, sm = _STAT["n"], _STAT["slow"], _STAT["max"], _STAT["sum"]
        samples = sorted(_STAT["samples"])
        _STAT.update({"n": 0, "slow": 0, "max": 0.0, "sum": 0.0})
        _STAT["samples"].clear()
    for ms, db, sql, th in items[:25]:
        _log("event=SQL_SLOW ms=%.0f db=%s thread=%s sql=%s" % (ms, db, th, sql))
    if n:
        p95 = samples[int(len(samples) * 0.95) - 1] if samples else 0.0
        _log("event=SQL_SUMMARY n=%d slow=%d max_ms=%.0f p95_ms=%.1f avg_ms=%.2f" % (n, slow, mx, p95, sm / n))


def _worker():
    try:
        from resources.lib import pkm_uhd_diag_v2600 as d
    except Exception:
        d = None
    prev = _read_marker()
    if prev:
        _log("event=PREV_EXIT clean=%s last_ts=%s last_rss_mb=%s last_mem_avail_mb=%s%s" % (
            prev.get("clean"), prev.get("ts"), prev.get("rss_mb"), prev.get("mem_avail_mb"),
            "" if prev.get("clean") == "1" else " SUSPECT_KILL_OR_CRASH"))
    base = {}
    monitor = xbmc.Monitor() if xbmc is not None else None
    last_storage = 0.0
    tick = 0
    try:
        _storage()
        last_storage = time.time()
    except Exception:
        pass
    while True:
        if monitor is not None and monitor.waitForAbort(10.0):
            break
        tick += 1
        try:
            _flush_sql()
        except Exception:
            pass
        if tick % 6 == 0 and d is not None:
            try:
                ps = d._proc_status()
                mi = d._meminfo()
                rss, av = ps.get("rss_mb"), mi.get("mem_avail_mb")
                if not base and rss not in (None, -1):
                    base = {"rss": rss, "av": av, "t": time.time()}
                if base:
                    mins = (time.time() - base["t"]) / 60.0
                    _log("event=TREND uptime_min=%.1f rss_mb=%s rss_delta_mb=%s mem_avail_mb=%s avail_delta_mb=%s" % (
                        mins, rss, round(float(rss) - float(base["rss"]), 1), av,
                        round(float(av) - float(base["av"]), 1) if av not in (None, -1) and base["av"] not in (None, -1) else -1))
                _write_marker(0, rss, av)
            except Exception:
                pass
        if time.time() - last_storage > 600:
            try:
                _storage()
            except Exception:
                pass
            last_storage = time.time()
    try:
        _flush_sql(True)
        _write_marker(1, -1, -1)
    except Exception:
        pass


def start():
    global _STARTED
    if _STARTED or xbmc is None:
        return
    _STARTED = True
    install_sql_timing()
    t = threading.Thread(target=_worker, name="PKMPerfR270", daemon=True)
    t.start()
